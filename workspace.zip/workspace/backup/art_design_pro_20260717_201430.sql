/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: art_design_pro
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_beta_users`
--

DROP TABLE IF EXISTS `app_beta_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_beta_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_user` (`app_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_beta_users`
--

LOCK TABLES `app_beta_users` WRITE;
/*!40000 ALTER TABLE `app_beta_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_beta_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_bundle_items`
--

DROP TABLE IF EXISTS `app_bundle_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_bundle_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bundle_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bundle_app` (`bundle_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_bundle_items`
--

LOCK TABLES `app_bundle_items` WRITE;
/*!40000 ALTER TABLE `app_bundle_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_bundle_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_bundles`
--

DROP TABLE IF EXISTS `app_bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_bundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `price_balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_bundles`
--

LOCK TABLES `app_bundles` WRITE;
/*!40000 ALTER TABLE `app_bundles` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_bundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_categories`
--

DROP TABLE IF EXISTS `app_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` char(1) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_categories`
--

LOCK TABLES `app_categories` WRITE;
/*!40000 ALTER TABLE `app_categories` DISABLE KEYS */;
INSERT INTO `app_categories` VALUES
(1,'工具','',1,'1','2026-07-10 22:39:49'),
(2,'创作','',2,'1','2026-07-10 22:39:49'),
(3,'效率','',3,'1','2026-07-10 22:39:49'),
(4,'生活','',4,'1','2026-07-10 22:39:49'),
(5,'游戏','',5,'1','2026-07-10 22:39:49'),
(6,'教育','',6,'1','2026-07-10 22:39:49'),
(7,'社交','',7,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_clicks`
--

DROP TABLE IF EXISTS `app_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_time` (`app_id`,`create_time`),
  KEY `idx_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_clicks`
--

LOCK TABLES `app_clicks` WRITE;
/*!40000 ALTER TABLE `app_clicks` DISABLE KEYS */;
INSERT INTO `app_clicks` VALUES
(1,1,0,'2026-07-10 22:49:26'),
(2,1,0,'2026-07-10 22:49:26'),
(3,1,0,'2026-07-10 22:49:26'),
(4,1,0,'2026-07-10 22:49:26'),
(5,1,0,'2026-07-10 22:49:26'),
(6,1,0,'2026-07-10 22:49:26'),
(7,1,0,'2026-07-10 22:49:26'),
(8,1,0,'2026-07-10 22:49:26'),
(9,1,0,'2026-07-10 22:49:26'),
(10,1,0,'2026-07-10 22:49:26'),
(11,1,0,'2026-07-10 22:49:26'),
(12,1,0,'2026-07-10 22:49:26'),
(13,1,0,'2026-07-10 22:49:26'),
(14,1,0,'2026-07-10 22:49:26'),
(15,1,0,'2026-07-10 22:49:26'),
(16,1,0,'2026-07-10 22:49:26'),
(17,1,0,'2026-07-10 22:49:26'),
(18,1,0,'2026-07-10 22:49:26'),
(19,1,0,'2026-07-10 22:49:26'),
(20,1,0,'2026-07-10 22:49:26'),
(21,3,0,'2026-07-10 22:49:26'),
(22,3,0,'2026-07-10 22:49:26'),
(23,3,0,'2026-07-10 22:49:26'),
(24,3,0,'2026-07-10 22:49:26'),
(25,3,0,'2026-07-10 22:49:26'),
(26,3,0,'2026-07-10 22:49:26'),
(27,3,0,'2026-07-10 22:49:26'),
(28,3,0,'2026-07-10 22:49:26'),
(29,3,0,'2026-07-10 22:49:26'),
(30,3,0,'2026-07-10 22:49:26'),
(31,3,0,'2026-07-10 22:49:26'),
(32,3,0,'2026-07-10 22:49:26'),
(33,3,0,'2026-07-10 22:49:26'),
(34,3,0,'2026-07-10 22:49:26'),
(35,3,0,'2026-07-10 22:49:26'),
(36,3,0,'2026-07-10 22:49:26'),
(37,3,0,'2026-07-10 22:49:26'),
(38,3,0,'2026-07-10 22:49:26'),
(39,6,0,'2026-07-10 22:49:26'),
(40,6,0,'2026-07-10 22:49:26'),
(41,6,0,'2026-07-10 22:49:26'),
(42,6,0,'2026-07-10 22:49:26'),
(43,6,0,'2026-07-10 22:49:26'),
(44,6,0,'2026-07-10 22:49:26'),
(45,6,0,'2026-07-10 22:49:26'),
(46,6,0,'2026-07-10 22:49:26'),
(47,6,0,'2026-07-10 22:49:26'),
(48,6,0,'2026-07-10 22:49:26'),
(49,6,0,'2026-07-10 22:49:26'),
(50,6,0,'2026-07-10 22:49:26'),
(51,6,0,'2026-07-10 22:49:26'),
(52,6,0,'2026-07-10 22:49:26'),
(53,6,0,'2026-07-10 22:49:26'),
(54,4,0,'2026-07-10 22:49:26'),
(55,4,0,'2026-07-10 22:49:26'),
(56,4,0,'2026-07-10 22:49:26'),
(57,4,0,'2026-07-10 22:49:26'),
(58,4,0,'2026-07-10 22:49:26'),
(59,4,0,'2026-07-10 22:49:26'),
(60,4,0,'2026-07-10 22:49:26'),
(61,4,0,'2026-07-10 22:49:26'),
(62,4,0,'2026-07-10 22:49:26'),
(63,4,0,'2026-07-10 22:49:26'),
(64,4,0,'2026-07-10 22:49:26'),
(65,4,0,'2026-07-10 22:49:26'),
(66,2,0,'2026-07-10 22:49:26'),
(67,2,0,'2026-07-10 22:49:26'),
(68,2,0,'2026-07-10 22:49:26'),
(69,2,0,'2026-07-10 22:49:26'),
(70,2,0,'2026-07-10 22:49:26'),
(71,2,0,'2026-07-10 22:49:26'),
(72,2,0,'2026-07-10 22:49:26'),
(73,2,0,'2026-07-10 22:49:26'),
(74,2,0,'2026-07-10 22:49:26'),
(75,2,0,'2026-07-10 22:49:26'),
(76,5,0,'2026-07-10 22:49:26'),
(77,5,0,'2026-07-10 22:49:26'),
(78,5,0,'2026-07-10 22:49:26'),
(79,5,0,'2026-07-10 22:49:26'),
(80,5,0,'2026-07-10 22:49:26'),
(81,5,0,'2026-07-10 22:49:26'),
(82,5,0,'2026-07-10 22:49:26'),
(83,7,0,'2026-07-10 22:49:26'),
(84,7,0,'2026-07-10 22:49:26'),
(85,7,0,'2026-07-10 22:49:26'),
(86,7,0,'2026-07-10 22:49:26'),
(87,7,0,'2026-07-10 22:49:26'),
(88,8,0,'2026-07-10 22:49:26'),
(89,8,0,'2026-07-10 22:49:26'),
(90,8,0,'2026-07-10 22:49:26'),
(91,9,0,'2026-07-10 22:49:26'),
(92,9,0,'2026-07-10 22:49:26'),
(93,9,0,'2026-07-09 22:49:26'),
(94,9,0,'2026-07-09 22:49:26'),
(95,9,0,'2026-07-09 22:49:26'),
(96,9,0,'2026-07-09 22:49:26'),
(97,9,0,'2026-07-09 22:49:26'),
(98,9,0,'2026-07-09 22:49:26'),
(99,9,0,'2026-07-09 22:49:26'),
(100,9,0,'2026-07-09 22:49:26'),
(101,9,0,'2026-07-09 22:49:26'),
(102,9,0,'2026-07-09 22:49:26'),
(103,9,0,'2026-07-09 22:49:26'),
(104,9,0,'2026-07-09 22:49:26'),
(105,9,0,'2026-07-09 22:49:26'),
(106,9,0,'2026-07-09 22:49:26'),
(107,9,0,'2026-07-09 22:49:26'),
(108,9,0,'2026-07-09 22:49:26'),
(109,9,0,'2026-07-09 22:49:26'),
(110,9,0,'2026-07-09 22:49:26'),
(111,9,0,'2026-07-09 22:49:26'),
(112,9,0,'2026-07-09 22:49:26'),
(113,9,0,'2026-07-09 22:49:26'),
(114,9,0,'2026-07-09 22:49:26'),
(115,9,0,'2026-07-09 22:49:26'),
(116,9,0,'2026-07-08 22:49:26'),
(117,9,0,'2026-07-08 22:49:26'),
(118,9,0,'2026-07-08 22:49:26'),
(119,9,0,'2026-07-08 22:49:26'),
(120,9,0,'2026-07-08 22:49:26'),
(121,9,0,'2026-07-08 22:49:26'),
(122,9,0,'2026-07-08 22:49:26'),
(123,9,0,'2026-07-08 22:49:26'),
(124,9,0,'2026-07-08 22:49:26'),
(125,9,0,'2026-07-08 22:49:26'),
(126,9,0,'2026-07-08 22:49:26'),
(127,9,0,'2026-07-08 22:49:26'),
(128,9,0,'2026-07-08 22:49:26'),
(129,9,0,'2026-07-08 22:49:26'),
(130,9,0,'2026-07-08 22:49:26'),
(131,9,0,'2026-07-08 22:49:26'),
(132,9,0,'2026-07-07 22:49:26'),
(133,9,0,'2026-07-07 22:49:26'),
(134,9,0,'2026-07-07 22:49:26'),
(135,9,0,'2026-07-07 22:49:26'),
(136,9,0,'2026-07-07 22:49:26'),
(137,9,0,'2026-07-07 22:49:26'),
(138,9,0,'2026-07-06 22:49:26'),
(139,9,0,'2026-07-06 22:49:26'),
(140,9,0,'2026-07-06 22:49:26'),
(141,9,0,'2026-07-06 22:49:26'),
(142,9,0,'2026-07-05 22:49:26'),
(143,9,0,'2026-07-05 22:49:26'),
(144,9,0,'2026-07-05 22:49:26'),
(145,9,0,'2026-07-04 22:49:26'),
(146,9,0,'2026-07-04 22:49:26'),
(147,8,0,'2026-07-09 22:49:26'),
(148,8,0,'2026-07-09 22:49:26'),
(149,8,0,'2026-07-09 22:49:26'),
(150,8,0,'2026-07-09 22:49:26'),
(151,8,0,'2026-07-09 22:49:26'),
(152,8,0,'2026-07-09 22:49:26'),
(153,8,0,'2026-07-09 22:49:26'),
(154,8,0,'2026-07-09 22:49:26'),
(155,8,0,'2026-07-09 22:49:26'),
(156,8,0,'2026-07-09 22:49:26'),
(157,8,0,'2026-07-09 22:49:26'),
(158,8,0,'2026-07-09 22:49:26'),
(159,8,0,'2026-07-09 22:49:26'),
(160,8,0,'2026-07-09 22:49:26'),
(161,8,0,'2026-07-08 22:49:26'),
(162,8,0,'2026-07-08 22:49:26'),
(163,8,0,'2026-07-08 22:49:26'),
(164,8,0,'2026-07-08 22:49:26'),
(165,8,0,'2026-07-08 22:49:26'),
(166,8,0,'2026-07-08 22:49:26'),
(167,8,0,'2026-07-08 22:49:26'),
(168,8,0,'2026-07-08 22:49:26'),
(169,8,0,'2026-07-08 22:49:26'),
(170,8,0,'2026-07-07 22:49:26'),
(171,8,0,'2026-07-07 22:49:26'),
(172,8,0,'2026-07-07 22:49:26'),
(173,8,0,'2026-07-07 22:49:26'),
(174,8,0,'2026-07-07 22:49:26'),
(175,8,0,'2026-07-07 22:49:26'),
(176,8,0,'2026-07-06 22:49:26'),
(177,8,0,'2026-07-06 22:49:26'),
(178,8,0,'2026-07-06 22:49:26'),
(179,8,0,'2026-07-06 22:49:26'),
(180,8,0,'2026-07-05 22:49:26'),
(181,8,0,'2026-07-05 22:49:26'),
(182,8,0,'2026-07-05 22:49:26'),
(183,8,0,'2026-07-04 22:49:26'),
(184,8,0,'2026-07-04 22:49:26'),
(185,7,0,'2026-07-09 22:49:26'),
(186,7,0,'2026-07-09 22:49:26'),
(187,7,0,'2026-07-09 22:49:26'),
(188,7,0,'2026-07-09 22:49:26'),
(189,7,0,'2026-07-09 22:49:26'),
(190,7,0,'2026-07-09 22:49:26'),
(191,7,0,'2026-07-09 22:49:26'),
(192,7,0,'2026-07-09 22:49:26'),
(193,7,0,'2026-07-09 22:49:26'),
(194,7,0,'2026-07-09 22:49:26'),
(195,7,0,'2026-07-08 22:49:26'),
(196,7,0,'2026-07-08 22:49:26'),
(197,7,0,'2026-07-08 22:49:26'),
(198,7,0,'2026-07-08 22:49:26'),
(199,7,0,'2026-07-08 22:49:26'),
(200,7,0,'2026-07-08 22:49:26'),
(201,7,0,'2026-07-08 22:49:26'),
(202,7,0,'2026-07-08 22:49:26'),
(203,7,0,'2026-07-08 22:49:26'),
(204,7,0,'2026-07-07 22:49:26'),
(205,7,0,'2026-07-07 22:49:26'),
(206,7,0,'2026-07-07 22:49:26'),
(207,7,0,'2026-07-07 22:49:26'),
(208,7,0,'2026-07-07 22:49:26'),
(209,7,0,'2026-07-06 22:49:26'),
(210,7,0,'2026-07-06 22:49:26'),
(211,7,0,'2026-07-06 22:49:26'),
(212,7,0,'2026-07-06 22:49:26'),
(213,7,0,'2026-07-05 22:49:26'),
(214,7,0,'2026-07-05 22:49:26'),
(215,7,0,'2026-07-05 22:49:26'),
(216,7,0,'2026-07-04 22:49:26'),
(217,5,0,'2026-07-09 22:49:26'),
(218,5,0,'2026-07-09 22:49:26'),
(219,5,0,'2026-07-09 22:49:26'),
(220,5,0,'2026-07-09 22:49:26'),
(221,5,0,'2026-07-09 22:49:26'),
(222,5,0,'2026-07-09 22:49:26'),
(223,5,0,'2026-07-09 22:49:26'),
(224,5,0,'2026-07-09 22:49:26'),
(225,5,0,'2026-07-09 22:49:26'),
(226,5,0,'2026-07-09 22:49:26'),
(227,5,0,'2026-07-08 22:49:26'),
(228,5,0,'2026-07-08 22:49:26'),
(229,5,0,'2026-07-08 22:49:26'),
(230,5,0,'2026-07-08 22:49:26'),
(231,5,0,'2026-07-08 22:49:26'),
(232,5,0,'2026-07-08 22:49:26'),
(233,5,0,'2026-07-08 22:49:26'),
(234,5,0,'2026-07-07 22:49:26'),
(235,5,0,'2026-07-07 22:49:26'),
(236,5,0,'2026-07-07 22:49:26'),
(237,5,0,'2026-07-07 22:49:26'),
(238,5,0,'2026-07-06 22:49:26'),
(239,5,0,'2026-07-06 22:49:26'),
(240,5,0,'2026-07-05 22:49:26'),
(241,5,0,'2026-07-05 22:49:26'),
(242,5,0,'2026-07-05 22:49:26'),
(243,5,0,'2026-07-04 22:49:26'),
(244,1,0,'2026-07-09 22:49:26'),
(245,1,0,'2026-07-09 22:49:26'),
(246,1,0,'2026-07-09 22:49:26'),
(247,1,0,'2026-07-09 22:49:26'),
(248,1,0,'2026-07-09 22:49:26'),
(249,1,0,'2026-07-09 22:49:26'),
(250,1,0,'2026-07-09 22:49:26'),
(251,1,0,'2026-07-09 22:49:26'),
(252,1,0,'2026-07-09 22:49:26'),
(253,1,0,'2026-07-09 22:49:26'),
(254,1,0,'2026-07-08 22:49:26'),
(255,1,0,'2026-07-08 22:49:26'),
(256,1,0,'2026-07-08 22:49:26'),
(257,1,0,'2026-07-08 22:49:26'),
(258,1,0,'2026-07-08 22:49:26'),
(259,1,0,'2026-07-08 22:49:26'),
(260,1,0,'2026-07-07 22:49:26'),
(261,1,0,'2026-07-07 22:49:26'),
(262,1,0,'2026-07-07 22:49:26'),
(263,1,0,'2026-07-06 22:49:26'),
(264,1,0,'2026-07-06 22:49:26'),
(265,1,0,'2026-07-06 22:49:26'),
(266,1,0,'2026-07-05 22:49:26'),
(267,1,0,'2026-07-05 22:49:26'),
(268,1,0,'2026-07-04 22:49:26');
/*!40000 ALTER TABLE `app_clicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_collection_items`
--

DROP TABLE IF EXISTS `app_collection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_collection_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_collection_app` (`collection_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_collection_items`
--

LOCK TABLES `app_collection_items` WRITE;
/*!40000 ALTER TABLE `app_collection_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_collection_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_collections`
--

DROP TABLE IF EXISTS `app_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_collections`
--

LOCK TABLES `app_collections` WRITE;
/*!40000 ALTER TABLE `app_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_comments`
--

DROP TABLE IF EXISTS `app_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(20) DEFAULT '#FF5777',
  `device` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '',
  `content` text DEFAULT NULL,
  `likes` int(11) DEFAULT 0,
  `replies` int(11) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_comments_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_comments`
--

LOCK TABLES `app_comments` WRITE;
/*!40000 ALTER TABLE `app_comments` DISABLE KEYS */;
INSERT INTO `app_comments` VALUES
(1,5,0,13,'','#FF5777','','','很好用',0,0,0,0,5.0,'2026-05-13 22:39:54'),
(2,1,0,5,'','#FF5777','','','推荐！',0,0,0,0,5.0,'2026-05-29 22:39:54'),
(4,3,0,10,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-05-12 22:39:54'),
(5,2,0,2,'','#FF5777','','','需要改进',0,0,0,0,5.0,'2026-07-03 22:39:54'),
(6,7,0,7,'','#FF5777','','','很棒的应用',0,0,0,0,5.0,'2026-05-22 22:39:54'),
(8,5,0,6,'','#FF5777','','','推荐！',0,0,0,0,4.0,'2026-07-07 22:39:54'),
(9,4,0,15,'','#FF5777','','','不错',0,0,0,0,4.0,'2026-06-25 22:39:54'),
(10,4,0,7,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-06-05 22:39:54'),
(14,12,0,19,'alexmorgan','#448AFF','','','6',1,0,0,1,5.0,'2026-07-12 21:51:42');
/*!40000 ALTER TABLE `app_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_daily_stats`
--

DROP TABLE IF EXISTS `app_daily_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_daily_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `stat_date` date NOT NULL,
  `downloads` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_app_date` (`app_id`,`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_daily_stats`
--

LOCK TABLES `app_daily_stats` WRITE;
/*!40000 ALTER TABLE `app_daily_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_daily_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorite_group_follows`
--

DROP TABLE IF EXISTS `app_favorite_group_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorite_group_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_follower` (`group_id`,`follower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorite_group_follows`
--

LOCK TABLES `app_favorite_group_follows` WRITE;
/*!40000 ALTER TABLE `app_favorite_group_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_favorite_group_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorite_groups`
--

DROP TABLE IF EXISTS `app_favorite_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorite_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认收藏夹',
  `sort_order` int(11) DEFAULT 0,
  `is_public` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorite_groups`
--

LOCK TABLES `app_favorite_groups` WRITE;
/*!40000 ALTER TABLE `app_favorite_groups` DISABLE KEYS */;
INSERT INTO `app_favorite_groups` VALUES
(1,19,'默认收藏夹',0,0,'2026-07-16 14:16:37'),
(2,10001,'默认收藏夹',0,0,'2026-07-16 15:21:23');
/*!40000 ALTER TABLE `app_favorite_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorites`
--

DROP TABLE IF EXISTS `app_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`app_id`),
  KEY `idx_app_favorites_user` (`user_id`),
  KEY `idx_app_favorites_app` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorites`
--

LOCK TABLES `app_favorites` WRITE;
/*!40000 ALTER TABLE `app_favorites` DISABLE KEYS */;
INSERT INTO `app_favorites` VALUES
(1,9,1,0,'2026-06-05 22:39:54'),
(2,10,5,0,'2026-06-18 22:39:54'),
(3,2,8,0,'2026-07-09 22:39:54'),
(4,4,2,0,'2026-05-12 22:39:54'),
(5,3,6,0,'2026-05-12 22:39:54'),
(6,11,1,0,'2026-05-13 22:39:54'),
(7,6,4,0,'2026-06-29 22:39:54'),
(8,11,6,0,'2026-06-15 22:39:54'),
(9,9,6,0,'2026-06-19 22:39:54'),
(10,6,6,0,'2026-06-12 22:39:54'),
(12,15,4,0,'2026-07-07 22:39:54'),
(13,7,9,0,'2026-07-07 22:39:54'),
(14,7,2,0,'2026-05-25 22:39:54'),
(15,5,3,0,'2026-05-14 22:39:54'),
(19,19,12,8,'2026-07-16 13:58:16'),
(20,10001,12,2,'2026-07-16 15:21:24'),
(21,1,1,1,'2026-07-16 19:28:14');
/*!40000 ALTER TABLE `app_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_official_tags`
--

DROP TABLE IF EXISTS `app_official_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_official_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `color` varchar(20) DEFAULT '#2563eb',
  `bg_color` varchar(20) DEFAULT '#dbeafe',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_official_tags`
--

LOCK TABLES `app_official_tags` WRITE;
/*!40000 ALTER TABLE `app_official_tags` DISABLE KEYS */;
INSERT INTO `app_official_tags` VALUES
(1,'热门','#2563eb','#dbeafe',1,'1','2026-07-10 22:39:49'),
(2,'推荐','#2563eb','#dbeafe',2,'1','2026-07-10 22:39:49'),
(3,'新品','#2563eb','#dbeafe',3,'1','2026-07-10 22:39:49'),
(4,'精品','#2563eb','#dbeafe',4,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_official_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_purchases`
--

DROP TABLE IF EXISTS `app_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'free',
  `original_price` decimal(10,2) DEFAULT 0.00,
  `paid_price` decimal(10,2) DEFAULT 0.00,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_purchases_app` (`app_id`),
  KEY `idx_app_purchases_user` (`user_id`),
  KEY `idx_app_purchases_user_app` (`user_id`,`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_purchases`
--

LOCK TABLES `app_purchases` WRITE;
/*!40000 ALTER TABLE `app_purchases` DISABLE KEYS */;
INSERT INTO `app_purchases` VALUES
(1,9,6,'','free',0.00,12.79,1.0,'2026-05-12 22:39:54'),
(2,3,6,'','free',0.00,5.03,1.0,'2026-05-21 22:39:54'),
(3,7,8,'','free',0.00,16.36,1.0,'2026-06-22 22:39:54'),
(4,9,7,'','free',0.00,28.55,1.0,'2026-05-15 22:39:54'),
(5,1,8,'','free',0.00,14.38,1.0,'2026-07-08 22:39:54'),
(6,2,15,'','free',0.00,17.64,1.0,'2026-06-15 22:39:54');
/*!40000 ALTER TABLE `app_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_store`
--

DROP TABLE IF EXISTS `app_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `description` text DEFAULT NULL,
  `update_content` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `developer` varchar(100) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `categories` text DEFAULT NULL,
  `category_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `is_pinned` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `official_tags` text DEFAULT NULL,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `is_featured` tinyint(1) DEFAULT 0,
  `is_official` tinyint(1) DEFAULT 0,
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_store_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_store`
--

LOCK TABLES `app_store` WRITE;
/*!40000 ALTER TABLE `app_store` DISABLE KEYS */;
INSERT INTO `app_store` VALUES
(1,'Pro Photo Editor','AIGram.pro.editor','1.2.3','120','','camera',0.0,3865,3.7,'专业级照片编辑工具，AI智能修图',NULL,NULL,'[\"photo\",\"editor\",\"AI\"]','',0,0,'bobwang','工具',NULL,0,'1',0,14,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-05-12 22:39:49','2026-07-10 22:39:49'),
(2,'Pixel Draw','Pixel.Draw.app','2.0.1','101','','brush',0.0,791,4.0,'像素风绘画应用，支持图层和动画',NULL,NULL,'[\"draw\",\"pixel\",\"art\"]','',0,0,'pixel_art','工具',NULL,0,'1',0,1,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-08 22:39:49','2026-07-10 22:39:49'),
(3,'Code Helper','Code.Helper.pro','3.5.0','200','','code',0.0,4675,2.9,'智能代码助手，支持多种编程语言',NULL,NULL,'[\"code\",\"dev\",\"tool\"]','',0,0,'code_ninja','工具',NULL,0,'1',0,2,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-22 22:39:49','2026-07-10 22:39:49'),
(4,'Music Maker','Music.Maker.studio','1.0.0','80','','music',0.0,4272,4.1,'AI驱动的音乐创作工作室',NULL,NULL,'[\"music\",\"create\",\"AI\"]','',0,0,'tech_guru','创作',NULL,0,'1',0,7,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-04 22:39:49','2026-07-10 22:39:49'),
(5,'Video Snap','Video.Snap.lite','4.2.1','95','','video',0.0,2168,4.0,'短视频快速剪辑和滤镜工具',NULL,NULL,'[\"video\",\"edit\",\"social\"]','',0,0,'frontend_dev','创作',NULL,0,'1',0,5,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-23 22:39:49','2026-07-10 22:39:49'),
(7,'Mind Map Pro','Mind.Map.visual','1.5.2','75','','mindmap',0.0,2839,3.4,'思维导图可视化工具',NULL,NULL,'[\"mindmap\",\"study\",\"visual\"]','',0,0,'design_master','效率',NULL,0,'1',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(10,'待审核应用','com.demo.pending','0.1.0','30','','default',0.0,1265,3.1,'这是一个待审核的应用',NULL,NULL,'[\"test\"]','',0,0,'mobile_dev','工具',NULL,0,'0',0,4,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(11,'已拒绝应用','com.demo.rejected','0.1.0','20','','default',0.0,648,4.2,'这是一个被拒绝的应用',NULL,NULL,'[\"test\"]','',0,0,'game_dev','工具',NULL,0,'2',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-03 22:39:49','2026-07-10 22:39:49'),
(12,'百变引擎','百变引擎_13.7.07','13.7.07','100','','#00BFA5',19.5,0,5.0,'66',NULL,'[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','6666',0,0,'alexmorgan','工具',NULL,0,'1',1,19,'[]','public',0.00,'free','','',1,0,1,1,0,1,'free',0.00,'2026-07-11 11:50:41','2026-07-11 11:50:41');
/*!40000 ALTER TABLE `app_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_tips`
--

DROP TABLE IF EXISTS `app_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(64) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tip_type` varchar(20) DEFAULT 'balance',
  `message` varchar(255) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_tips_app` (`app_id`),
  KEY `idx_app_tips_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_tips`
--

LOCK TABLES `app_tips` WRITE;
/*!40000 ALTER TABLE `app_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_uploads`
--

DROP TABLE IF EXISTS `app_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `description` text DEFAULT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `download_url` varchar(500) DEFAULT '',
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `version_type` varchar(20) DEFAULT '',
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `review_count` int(11) DEFAULT 0,
  `five_star_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '0',
  `submission_status` varchar(20) DEFAULT 'draft',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `official_tags` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_uploads_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_uploads`
--

LOCK TABLES `app_uploads` WRITE;
/*!40000 ALTER TABLE `app_uploads` DISABLE KEYS */;
INSERT INTO `app_uploads` VALUES
(1,0,0,'','E2E App','com.e2e.test','工具','Test app','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-10 19:34:30','2026-07-10 19:34:30'),
(2,3,0,'','E2E Test App','com.e2e.app','工具','Real E2E test application','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-10 20:07:11','free',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 20:07:11'),
(3,0,0,'','test_crud_app','com.test.crud','工具','CRUD test app','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:09:51','2026-07-10 20:09:51'),
(4,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:11:45','2026-07-10 20:11:45'),
(5,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:26','2026-07-10 20:13:26'),
(6,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:56','2026-07-10 20:13:56'),
(7,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:17:40','2026-07-10 20:17:40'),
(8,12,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','66','','#00BFA5','13.7.07','100',19.5,'6666','[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','官方版',1,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-11 11:50:41','free',0.00,'[]','2026-07-11 11:50:19','2026-07-11 11:50:41'),
(9,0,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','','/uploads/icon-1783816289499-38219570.png','#00BFA5','13.7.07','100',19.5,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk','[]','[\"官方版\"]','官方版',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'[]','2026-07-12 00:32:20','2026-07-12 00:32:20');
/*!40000 ALTER TABLE `app_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_versions`
--

DROP TABLE IF EXISTS `app_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `version` varchar(50) NOT NULL,
  `version_code` varchar(50) DEFAULT '',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `update_content` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `is_current` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `official_tags` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `has_ads` int(11) DEFAULT 0,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `requires_network` int(11) DEFAULT 0,
  `version_type` varchar(20) DEFAULT 'release',
  PRIMARY KEY (`id`),
  KEY `idx_app_versions_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_versions`
--

LOCK TABLES `app_versions` WRITE;
/*!40000 ALTER TABLE `app_versions` DISABLE KEYS */;
INSERT INTO `app_versions` VALUES
(2,3,'3.5.4.5','216',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-30 22:39:54',NULL,NULL,0,0,1,0,'release'),
(4,5,'2.3.7.1','783',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-06-02 22:39:54',NULL,NULL,0,0,1,0,'release'),
(8,4,'3.7.5.2','690',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-16 22:39:54',NULL,NULL,0,0,1,0,'release'),
(9,0,'13.7.07','100',19.5,0,0.0,'','[\"官方版\"]','6666',1,19,'alexmorgan',NULL,'1','2026-07-11 11:50:41','66','[\"/uploads/1783770613292-211438868.jpg\"]',0,0,1,0,'release');
/*!40000 ALTER TABLE `app_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatar_frames`
--

DROP TABLE IF EXISTS `avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(500) DEFAULT '',
  `thumbnail_url` varchar(500) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `obtain_type` varchar(20) DEFAULT 'manual',
  `exp_level_required` int(11) DEFAULT 0,
  `member_level_required` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_frames`
--

LOCK TABLES `avatar_frames` WRITE;
/*!40000 ALTER TABLE `avatar_frames` DISABLE KEYS */;
INSERT INTO `avatar_frames` VALUES
(1,'金色边框','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/frame-1784063200439-382993529.gif','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-14 21:06:43'),
(2,'炫彩边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-11 16:28:24'),
(3,'简约边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(4,'节日边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(5,'金色边框','/frames/gold.png','/frames/gold_thumb.png','金闪闪的会员框','membership',0,0,1,'1','2026-07-11 21:07:13','2026-07-11 21:07:13'),
(6,'钻石边框','/frames/diamond.png','/frames/diamond_thumb.png','钻石边框','membership',0,0,2,'1','2026-07-11 21:07:13','2026-07-11 21:07:13');
/*!40000 ALTER TABLE `avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_records`
--

DROP TABLE IF EXISTS `balance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_balance_records_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_records`
--

LOCK TABLES `balance_records` WRITE;
/*!40000 ALTER TABLE `balance_records` DISABLE KEYS */;
INSERT INTO `balance_records` VALUES
(1,19,'alexmorgan','earn',5000.00,5000.00,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 获得5000元余额',0,'','2026-07-11 08:41:23'),
(2,19,'alexmorgan','expense',10.00,4990.00,'会员购买','购买黄金会员',0,'','2026-07-11 08:56:31'),
(3,19,'alexmorgan','expense',10.00,4980.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:35'),
(4,19,'alexmorgan','expense',10.00,4970.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:38'),
(5,19,'Alex Morgan','expense',1.00,4969.00,'帖子打赏','打赏帖子「开源项目推荐合集」',0,'','2026-07-11 11:39:17'),
(6,1,'bobwang','expense',10.00,78.50,'会员购买','购买黄金会员',0,'','2026-07-11 20:37:08'),
(7,1,'bobwang','earn',3.00,91.50,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:37:08'),
(8,4,'design_master','expense',10.00,0.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:38:36'),
(9,4,'design_master','earn',3.00,13.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:38:36'),
(14,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:48:23'),
(15,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:43'),
(16,21,'testcoupon','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:43'),
(17,21,'testcoupon','expense',10.00,88.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:53'),
(18,21,'testcoupon','earn',3.00,101.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:53'),
(19,22,'titletest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:07:31'),
(20,22,'titletest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:07:31'),
(21,23,'birthdaytest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:08:20'),
(22,23,'birthdaytest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:08:20'),
(23,19,'alexmorgan','expense',5.00,4964.00,'会员购买','购买黄金会员',0,'','2026-07-12 00:11:10'),
(24,19,'alexmorgan','earn',3.00,4972.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 00:11:10'),
(25,19,'alexmorgan','expense',48.00,4919.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:34:02'),
(26,19,'alexmorgan','expense',48.00,4871.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:34:26'),
(27,19,'alexmorgan','expense',20.00,4851.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:35:24'),
(28,19,'alexmorgan','expense',48.00,4803.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:35:40'),
(29,19,'alexmorgan','expense',10.00,4793.00,'会员购买','购买黄金会员',0,'','2026-07-12 10:37:22'),
(30,19,'alexmorgan','earn',3.00,4806.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 10:37:22'),
(31,19,'alexmorgan','expense',20.00,4776.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:37:35'),
(32,19,'alexmorgan','expense',10.00,4766.00,'会员购买','购买黄金会员',0,'','2026-07-12 10:37:47'),
(33,19,'alexmorgan','earn',3.00,4779.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 10:37:47'),
(34,19,'alexmorgan','expense',20.00,4749.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:37:54'),
(35,19,'alexmorgan','expense',10.00,4739.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:12:49'),
(36,19,'alexmorgan','expense',10.00,4729.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:12:58'),
(37,19,'alexmorgan','expense',10.00,4719.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:13:05'),
(38,19,'alexmorgan','expense',20.00,4699.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:13:08'),
(39,19,'alexmorgan','expense',20.00,4679.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:13:13'),
(40,19,'alexmorgan','expense',20.00,4659.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:15:35'),
(41,19,'alexmorgan','expense',10.00,4649.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:15:38'),
(42,19,'alexmorgan','expense',10.00,4639.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:15:40'),
(43,19,'alexmorgan','expense',20.00,4619.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:36'),
(44,19,'alexmorgan','expense',20.00,4599.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:38'),
(45,19,'alexmorgan','expense',20.00,4579.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:40'),
(46,19,'alexmorgan','expense',20.00,4559.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:44'),
(47,19,'alexmorgan','expense',20.00,4539.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:47'),
(48,19,'alexmorgan','expense',48.00,4491.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:21:15'),
(49,19,'alexmorgan','expense',10.00,4481.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:49:54'),
(50,19,'alexmorgan','expense',10.00,4471.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:50:03'),
(51,19,'alexmorgan','expense',10.00,4461.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:50:07'),
(52,19,'alexmorgan','expense',48.00,4413.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:19'),
(53,19,'alexmorgan','expense',48.00,4365.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:22'),
(54,19,'alexmorgan','expense',48.00,4317.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:30'),
(55,19,'alexmorgan','expense',48.00,4269.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:51:41'),
(56,19,'alexmorgan','expense',48.00,4221.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:52:12'),
(57,19,'alexmorgan','expense',15.00,4206.00,'会员购买','购买钻石会员',0,'','2026-07-12 20:36:22'),
(58,19,'alexmorgan','expense',20.00,4186.00,'会员购买','购买至尊会员',0,'','2026-07-12 20:36:40'),
(59,19,'alexmorgan','expense',15.00,4171.00,'会员购买','购买钻石会员',0,'','2026-07-12 20:36:48'),
(60,19,'alexmorgan','expense',48.00,4123.00,'会员购买','购买至尊会员',0,'','2026-07-12 20:46:00'),
(61,19,'alexmorgan','expense',20.00,4103.00,'会员购买','购买至尊会员',0,'','2026-07-12 22:19:55'),
(62,19,'alexmorgan','expense',10.00,4093.00,'会员购买','购买黄金会员',0,'','2026-07-12 23:00:31'),
(63,19,'alexmorgan','expense',48.00,4045.00,'会员购买','购买至尊会员',0,'','2026-07-12 23:01:02'),
(64,7,'user7','earn',87.49,500.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-12 23:39:30'),
(65,19,'alexmorgan','expense',500.00,3545.00,'余额提现','提现申请 alipay 123456',0,'','2026-07-12 23:39:43'),
(66,8,'user8','earn',84.19,180.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-12 23:45:35'),
(67,19,'alexmorgan','earn',500.00,3545.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-13 14:24:58'),
(68,19,'alexmorgan','earn',500.00,3545.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-13 14:24:58'),
(69,1,'bobwang','expense',4.50,77.00,'内容购买','购买帖子 #21 (黄金会员90%折扣)',0,'','2026-07-15 04:20:52'),
(70,19,'alexmorgan','earn',0.45,3545.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-15 04:20:52'),
(71,19,'alexmorgan','earn',10.00,3555.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-15 04:21:03'),
(72,10001,'35735712','earn',2000.00,2000.00,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 获得2000元余额',0,'','2026-07-16 00:16:12'),
(73,10001,'35735712','expense',10.00,1990.00,'内容购买','购买帖子 #22',0,'','2026-07-16 00:16:50'),
(74,19,'alexmorgan','earn',1.00,3556.45,'内容收益','帖子 #22 销售分佣',0,'','2026-07-16 00:16:50'),
(75,19,'alexmorgan','earn',10.00,3566.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-16 00:17:36'),
(76,10001,'35735712','expense',5.00,1985.00,'内容购买','购买帖子 #21',0,'','2026-07-16 00:17:45'),
(77,19,'alexmorgan','earn',0.50,3566.95,'内容收益','帖子 #21 销售分佣',0,'','2026-07-16 00:17:45'),
(78,19,'alexmorgan','earn',5.00,3571.95,'content_purchase','订单结算: 购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',72,'order_settle','2026-07-16 00:19:36'),
(79,10001,'35735712','expense',12.00,1973.00,'余额提现','提现申请 alipay 122',0,'','2026-07-16 00:20:17'),
(80,1,'','consume',-20.00,57.00,'collection_purchase','购买合集《社区功能测试合集》',0,'','2026-07-16 01:12:14'),
(81,19,'','income',20.00,3591.95,'collection_income','合集《社区功能测试合集》销售收入',0,'','2026-07-16 01:12:14'),
(82,10001,'35735712','expense',8.88,1964.12,'内容购买','购买帖子 #23',0,'','2026-07-16 15:43:53'),
(83,19,'alexmorgan','earn',0.89,3592.84,'内容收益','帖子 #23 销售分佣',0,'','2026-07-16 15:43:53'),
(84,19,'alexmorgan','expense',9.00,3583.84,'商城购物','购买商品《移动端组件库》 (优惠券抵扣¥1)',0,'','2026-07-16 19:42:21'),
(85,19,'alexmorgan','earn',10.00,3593.84,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-16 19:42:21'),
(86,19,'alexmorgan','expense',9.20,3584.64,'商城购物','购买商品《移动端组件库》 (优惠券抵扣¥0.8)',0,'','2026-07-16 19:42:28'),
(87,19,'alexmorgan','earn',10.00,3594.64,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-16 19:42:28'),
(88,3,'tech_guru','spend',199.00,301.00,'商城购物','商城下单，共1件商品',0,'','2026-07-17 15:05:59'),
(89,19,'alexmorgan','earn',10.00,3604.64,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:37:47'),
(90,19,'alexmorgan','expense',9.80,3594.84,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 15:39:56'),
(91,19,'alexmorgan','earn',10.00,3604.84,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:39:56'),
(92,19,'alexmorgan','expense',9.80,3595.04,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 15:41:24'),
(93,19,'alexmorgan','earn',10.00,3605.04,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:41:24'),
(94,19,'alexmorgan','spend',2999.00,606.04,'商城购物','商城下单，共1件商品',0,'','2026-07-17 15:52:58'),
(95,19,'alexmorgan','expense',2939.02,23367.02,'商城购物','购买商品《手机》',0,'','2026-07-17 16:35:31'),
(96,3,'tech_guru','expense',13.50,297.45,'推广码生成','生成推广码 带定价测试（2项奖励）',0,'','2026-07-17 17:20:28'),
(97,3,'tech_guru','earn',13.50,310.95,'推广码撤销','撤销推广码 EB571FEE 退款',0,'','2026-07-17 17:20:38'),
(100,10005,'promo_test1','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:41:17'),
(101,10006,'promo_buyer','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:42:42'),
(102,10007,'promo_test2','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:44:52'),
(104,10008,'promo_pts','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:01:17'),
(106,10009,'promo_pts2','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:02:02'),
(107,10009,'promo_pts2','expense',2939.02,7060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:03:44'),
(108,10010,'promo_dbg','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:05:00'),
(109,10011,'promo_dual','expense',9.80,4990.20,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 18:39:28'),
(110,10011,'promo_dual','earn',10.00,5000.20,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:28'),
(111,19,'alexmorgan','earn',0.29,23367.31,'推广返佣','mall #31 返佣',0,'','2026-07-17 18:39:28'),
(112,10011,'promo_dual','earn',10.00,5010.20,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:28'),
(113,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:50'),
(114,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:42:55'),
(115,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:47:26'),
(116,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:47:59'),
(117,19,'alexmorgan','expense',48.00,23319.31,'会员购买','购买至尊会员',0,'','2026-07-17 19:37:42'),
(118,3,'tech_guru','earn',1.44,312.39,'推广返佣','membership #18 返佣',0,'','2026-07-17 19:37:43'),
(119,19,'alexmorgan','expense',15.00,23304.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:46'),
(120,3,'tech_guru','earn',0.45,312.84,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:46'),
(121,19,'alexmorgan','expense',15.00,23289.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:50'),
(122,3,'tech_guru','earn',0.45,313.29,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:50'),
(123,19,'alexmorgan','expense',15.00,23274.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:57'),
(124,3,'tech_guru','earn',0.45,313.74,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:57'),
(125,19,'alexmorgan','expense',10.00,23264.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:38:02'),
(126,19,'alexmorgan','earn',3.00,23277.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:38:02'),
(127,3,'tech_guru','earn',0.30,314.04,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:38:02'),
(128,19,'alexmorgan','expense',48.00,23219.31,'会员购买','购买至尊会员',0,'','2026-07-17 19:38:04'),
(129,3,'tech_guru','earn',1.44,315.48,'推广返佣','membership #18 返佣',0,'','2026-07-17 19:38:04'),
(130,19,'alexmorgan','expense',10.00,23209.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:09'),
(131,19,'alexmorgan','earn',3.00,23222.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:43:09'),
(132,3,'tech_guru','earn',0.30,315.78,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:09'),
(133,19,'alexmorgan','expense',10.00,23202.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:15'),
(134,19,'alexmorgan','earn',3.00,23215.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:43:15'),
(135,3,'tech_guru','earn',0.30,316.08,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:15'),
(136,19,'alexmorgan','expense',10.00,23195.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:19'),
(137,3,'tech_guru','earn',0.30,316.38,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:19'),
(138,19,'alexmorgan','expense',15.00,23180.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:23'),
(139,3,'tech_guru','earn',0.45,316.83,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:23'),
(140,19,'alexmorgan','expense',15.00,23165.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:27'),
(141,3,'tech_guru','earn',0.45,317.28,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:27'),
(142,19,'alexmorgan','expense',15.00,23150.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:32'),
(143,3,'tech_guru','earn',0.45,317.73,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:32');
/*!40000 ALTER TABLE `balance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_transfer_records`
--

DROP TABLE IF EXISTS `balance_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fee` decimal(10,2) DEFAULT 0.00,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_transfer_records`
--

LOCK TABLES `balance_transfer_records` WRITE;
/*!40000 ALTER TABLE `balance_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browse_history`
--

DROP TABLE IF EXISTS `browse_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `browse_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_title` varchar(300) DEFAULT '',
  `item_cover` varchar(500) DEFAULT '',
  `item_url` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browse_history`
--

LOCK TABLES `browse_history` WRITE;
/*!40000 ALTER TABLE `browse_history` DISABLE KEYS */;
INSERT INTO `browse_history` VALUES
(9,19,'post',12,'开源项目推荐合集','','/p/12','2026-07-11 11:38:49'),
(10,19,'app',8,'Weather AI','','/a/8','2026-07-11 11:42:25'),
(11,19,'app',6,'Task Flow','','/a/6','2026-07-11 11:43:03'),
(12,19,'app',9,'Fitness Coach','','/a/9','2026-07-11 11:43:25'),
(22,19,'app',4,'Music Maker','','/a/4','2026-07-12 21:52:05'),
(56,19,'post',15,'测试编辑帖子6','','/p/15','2026-07-13 18:33:15'),
(57,19,'post',14,'2026最新设计资源合集：UI组件库、插画素材、字体包一次性打包','','/p/14','2026-07-13 18:33:28'),
(58,19,'post',13,'从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南','','/p/13','2026-07-13 18:33:43'),
(59,19,'post',3,'React 19 新特性解读','','/p/3','2026-07-13 18:33:48'),
(60,19,'post',7,'Cloud Native架构实践','','/p/7','2026-07-13 18:33:52'),
(61,19,'post',9,'像素艺术创作技巧','','/p/9','2026-07-13 18:33:56'),
(62,19,'post',11,'独立游戏开发日记','','/p/11','2026-07-13 18:33:58'),
(63,19,'post',6,'设计师如何提升审美','','/p/6','2026-07-13 18:34:01'),
(65,19,'post',2,'AI绘画入门指南','','/p/2','2026-07-13 18:34:08'),
(66,19,'post',5,'Vue3 + TypeScript 实战','','/p/5','2026-07-13 18:34:16'),
(67,19,'post',4,'我的应用开发历程','','/p/4','2026-07-13 18:34:20'),
(97,19,'post',1,'666','','/s/1','2026-07-14 10:53:36'),
(100,19,'post',16,'666','','/p/16','2026-07-14 11:43:42'),
(103,19,'post',17,'8888888888','','/p/17','2026-07-14 12:01:25'),
(104,19,'post',10,'面试经历分享','','/p/10','2026-07-14 12:01:36'),
(105,19,'post',8,'移动开发趋势2026','','/p/8','2026-07-14 12:01:42'),
(241,19,'app',1,'Pro Photo Editor','','/a/1','2026-07-15 04:25:43'),
(527,19,'post',23,'【付费解锁测试】精品设计教程 - 从入门到精通','','/p/23','2026-07-15 18:51:37'),
(536,19,'post',27,'【评论解锁】隐藏的设计资源链接 - 评论即可查看','','/p/27','2026-07-15 19:04:51'),
(681,10001,'post',21,'付费内容与权限解锁功能全套测试 - 会员权益篇','','/p/21','2026-07-16 00:18:07'),
(682,10001,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 00:18:10'),
(683,10001,'post',19,'编辑器文字格式功能全面测试 - 基础排版篇','','/p/19','2026-07-16 00:18:24'),
(685,10001,'post',28,'【测试】称号解锁功能 - 设计达人专属内容','','/p/28','2026-07-16 00:23:08'),
(694,19,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 12:33:54'),
(695,19,'post',19,'编辑器文字格式功能全面测试 - 基础排版篇','','/p/19','2026-07-16 12:33:55'),
(696,19,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 12:33:57'),
(697,19,'post',21,'付费内容与权限解锁功能全套测试 - 会员权益篇','','/p/21','2026-07-16 12:33:58'),
(701,19,'post',28,'【测试】称号解锁功能 - 设计达人专属内容','','/p/28','2026-07-16 12:36:49'),
(721,10001,'post',27,'【评论解锁】隐藏的设计资源链接 - 评论即可查看','','/p/27','2026-07-16 15:43:30'),
(723,10001,'post',26,'【登录可见】社区新人必读 - 发帖规范与积分规则详解','','/p/26','2026-07-16 15:43:41'),
(725,10001,'post',23,'【付费解锁测试】精品设计教程 - 从入门到精通','','/p/23','2026-07-16 15:43:54'),
(730,10001,'post',29,'666','','/p/29','2026-07-16 16:41:42'),
(735,10001,'post',22,'666','','/p/22','2026-07-16 19:31:46'),
(737,10001,'app',7,'Mind Map Pro','','/a/7','2026-07-16 19:32:20'),
(738,10001,'app',12,'百变引擎','','/a/12','2026-07-16 19:32:25'),
(740,19,'post',29,'666','','/p/29','2026-07-16 19:42:56'),
(741,19,'post',22,'666','','/p/22','2026-07-16 21:35:50'),
(746,19,'app',7,'Mind Map Pro','','/a/7','2026-07-16 22:54:05'),
(747,19,'post',18,'66666','','/p/18','2026-07-17 02:26:02'),
(748,19,'post',24,'【会员专属】黄金会员专属福利 - 设计素材大礼包','','/p/24','2026-07-17 13:46:45'),
(750,19,'app',12,'百变引擎','','/a/12','2026-07-17 20:03:10');
/*!40000 ALTER TABLE `browse_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_keys`
--

DROP TABLE IF EXISTS `card_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'membership',
  `target_id` int(11) DEFAULT 0,
  `target_name` varchar(100) DEFAULT '',
  `value` int(11) DEFAULT 0,
  `extra_points` int(11) DEFAULT 0,
  `extra_experience` int(11) DEFAULT 0,
  `extra_balance` decimal(10,2) DEFAULT 0.00,
  `duration` int(11) DEFAULT 0,
  `duration_unit` varchar(10) DEFAULT '',
  `status` varchar(2) DEFAULT '0',
  `create_by` varchar(100) DEFAULT '管理员',
  `create_time` datetime DEFAULT current_timestamp(),
  `redeem_by` varchar(100) DEFAULT '',
  `redeem_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_no` (`card_no`),
  KEY `idx_card_keys_card_no` (`card_no`),
  KEY `idx_card_keys_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_keys`
--

LOCK TABLES `card_keys` WRITE;
/*!40000 ALTER TABLE `card_keys` DISABLE KEYS */;
INSERT INTO `card_keys` VALUES
(1,'CDK-KHWVRT97','0kmgb0','points',0,'',462,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(2,'CDK-5290BIZB','hpmpf2','points',0,'',403,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(3,'CDK-RV1LEJFT','0c65nx','points',0,'',153,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(4,'CDK-RZEZXZ38','pjkj1k','points',0,'',211,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(5,'CDK-DHIJ209G','ux6bph','points',0,'',593,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(6,'CDK-B03HO2DX','w2gns1','points',0,'',123,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(7,'CDK-GO78G7ZS','6kxhzr','points',0,'',404,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(8,'CDK-EQI7TQLR','qp3uc1','points',0,'',568,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(9,'CDK-5XH0BZBA','s17s02','points',0,'',512,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(10,'CDK-55Y88WZ9','fpawmz','points',0,'',581,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(11,'CDK-KT12HIH0','0ve3ri','points',0,'',555,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(12,'CDK-YG0XEHLD','1iyd5a','points',0,'',289,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(13,'CDK-VNXEKNE9','vcwhtn','points',0,'',495,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(14,'CDK-8JFVFCN8','yxnsyx','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(15,'CDK-2IQ5GVLW','54fvq5','points',0,'',493,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(16,'CDK-376FCU46','qj8d61','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(17,'CDK-NU7STSR7','7ok43h','points',0,'',342,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(18,'CDK-LSQZ95KR','8kustz','points',0,'',344,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(19,'CDK-V63CBG8O','xznppx','points',0,'',234,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(20,'CDK-38YSP7G6','a1j12m','points',0,'',250,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(21,'CDKEY-MRG47L1VS1EE','VDIR0Q5M','balance',1,'5000元余额',5000,99999,2000,0.00,12,'month','1','管理员','2026-07-11 08:41:04','alexmorgan','2026-07-11 08:41:23'),
(22,'CDKEY-MRMRD84EXRNR','TB75YMFP','balance',1,'2000元余额',2000,10000,5000,0.00,12,'month','1','管理员','2026-07-16 00:15:55','35735712','2026-07-16 00:16:12');
/*!40000 ALTER TABLE `card_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gift_records`
--

DROP TABLE IF EXISTS `chat_gift_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gift_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT 0,
  `gift_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `points_cost` int(11) DEFAULT 0,
  `message_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gift_records`
--

LOCK TABLES `chat_gift_records` WRITE;
/*!40000 ALTER TABLE `chat_gift_records` DISABLE KEYS */;
INSERT INTO `chat_gift_records` VALUES
(1,3,1,2,7,3,0,0,'2026-07-10 22:39:53'),
(2,3,2,15,4,8,0,0,'2026-07-10 22:39:53'),
(3,1,3,15,6,6,0,0,'2026-07-10 22:39:53'),
(4,2,4,9,15,6,0,0,'2026-07-10 22:39:53'),
(5,4,1,3,5,2,0,0,'2026-07-10 22:39:53'),
(6,2,2,14,4,5,0,0,'2026-07-10 22:39:53'),
(7,2,3,12,11,7,0,0,'2026-07-10 22:39:53'),
(8,3,4,9,10,8,0,0,'2026-07-10 22:39:53'),
(9,1,1,8,5,8,0,0,'2026-07-10 22:39:53'),
(10,4,2,11,2,3,0,0,'2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gift_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gifts`
--

DROP TABLE IF EXISTS `chat_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `price` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `animation` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gifts`
--

LOCK TABLES `chat_gifts` WRITE;
/*!40000 ALTER TABLE `chat_gifts` DISABLE KEYS */;
INSERT INTO `chat_gifts` VALUES
(1,'flower','',5,'coin','',0,'active','2026-07-10 22:39:53'),
(2,'heart','',10,'coin','',0,'active','2026-07-10 22:39:53'),
(3,'star','',20,'coin','',0,'active','2026-07-10 22:39:53'),
(4,'rocket','',50,'coin','',0,'active','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_reports`
--

DROP TABLE IF EXISTS `chat_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT 0,
  `target_user_id` int(11) DEFAULT 0,
  `conversation_id` int(11) DEFAULT 0,
  `reason` varchar(50) DEFAULT '',
  `detail` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `handler_id` int(11) DEFAULT 0,
  `handle_notes` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `handle_time` datetime DEFAULT NULL,
  `room_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_reports`
--

LOCK TABLES `chat_reports` WRITE;
/*!40000 ALTER TABLE `chat_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_admin_logs`
--

DROP TABLE IF EXISTS `chat_room_admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_user_id` int(11) DEFAULT 0,
  `target_user_name` varchar(100) DEFAULT '',
  `detail` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_admin_logs`
--

LOCK TABLES `chat_room_admin_logs` WRITE;
/*!40000 ALTER TABLE `chat_room_admin_logs` DISABLE KEYS */;
INSERT INTO `chat_room_admin_logs` VALUES
(1,5,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"1\"','2026-07-12 12:19:47'),
(2,6,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"审批制测试群\"','2026-07-16 20:44:28'),
(3,7,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"审批测试群2\"','2026-07-16 20:50:06'),
(4,7,19,'alexmorgan','approve_join',10003,'test_joiner','审核通过入群申请','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_bans`
--

DROP TABLE IF EXISTS `chat_room_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'temp',
  `reason` text DEFAULT '',
  `ban_until` datetime DEFAULT NULL,
  `banned_by` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_bans`
--

LOCK TABLES `chat_room_bans` WRITE;
/*!40000 ALTER TABLE `chat_room_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_files`
--

DROP TABLE IF EXISTS `chat_room_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT 'other',
  `file_size` int(11) DEFAULT 0,
  `mime_type` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_room_files_room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_files`
--

LOCK TABLES `chat_room_files` WRITE;
/*!40000 ALTER TABLE `chat_room_files` DISABLE KEYS */;
INSERT INTO `chat_room_files` VALUES
(1,5,19,'alexmorgan','chat_1783859261750_1377.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg','image',0,'image/jpg','2026-07-12 12:27:42'),
(2,5,19,'alexmorgan','chat_1783860297159_7139.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg','image',0,'image/jpg','2026-07-12 12:44:57');
/*!40000 ALTER TABLE `chat_room_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_join_requests`
--

DROP TABLE IF EXISTS `chat_room_join_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(200) DEFAULT '',
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_join_requests`
--

LOCK TABLES `chat_room_join_requests` WRITE;
/*!40000 ALTER TABLE `chat_room_join_requests` DISABLE KEYS */;
INSERT INTO `chat_room_join_requests` VALUES
(1,6,10003,'test_joiner','','我对这个群聊话题很感兴趣，希望加入交流','pending',0,'','','2026-07-16 20:47:51',NULL),
(2,7,10003,'test_joiner','','我对这个话题很感兴趣','approved',19,'alexmorgan','欢迎加入我们!','2026-07-16 20:50:06','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_join_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_limit_upgrades`
--

DROP TABLE IF EXISTS `chat_room_limit_upgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_limit_upgrades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `current_limit` int(11) DEFAULT 50,
  `request_limit` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_limit_upgrades`
--

LOCK TABLES `chat_room_limit_upgrades` WRITE;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_members`
--

DROP TABLE IF EXISTS `chat_room_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(20) DEFAULT 'member',
  `muted_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `join_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_members`
--

LOCK TABLES `chat_room_members` WRITE;
/*!40000 ALTER TABLE `chat_room_members` DISABLE KEYS */;
INSERT INTO `chat_room_members` VALUES
(1,1,2,'member',NULL,'active','2026-07-10 22:39:53'),
(2,1,3,'member',NULL,'active','2026-07-10 22:39:53'),
(3,1,4,'owner',NULL,'active','2026-07-10 22:39:53'),
(4,1,7,'member',NULL,'active','2026-07-10 22:39:53'),
(5,1,9,'member',NULL,'active','2026-07-10 22:39:53'),
(6,1,10,'member',NULL,'active','2026-07-10 22:39:53'),
(7,1,11,'member',NULL,'active','2026-07-10 22:39:53'),
(8,1,12,'member',NULL,'active','2026-07-10 22:39:53'),
(9,1,13,'member',NULL,'active','2026-07-10 22:39:53'),
(10,1,14,'member',NULL,'active','2026-07-10 22:39:53'),
(11,2,3,'member',NULL,'active','2026-07-10 22:39:53'),
(12,2,4,'member',NULL,'active','2026-07-10 22:39:53'),
(13,2,5,'owner',NULL,'active','2026-07-10 22:39:53'),
(14,2,6,'member',NULL,'active','2026-07-10 22:39:53'),
(15,2,8,'member',NULL,'active','2026-07-10 22:39:53'),
(16,2,9,'member',NULL,'active','2026-07-10 22:39:53'),
(17,2,11,'member',NULL,'active','2026-07-10 22:39:53'),
(18,2,12,'member',NULL,'active','2026-07-10 22:39:53'),
(19,2,13,'member',NULL,'active','2026-07-10 22:39:53'),
(20,2,14,'member',NULL,'active','2026-07-10 22:39:53'),
(21,2,15,'member',NULL,'active','2026-07-10 22:39:53'),
(22,2,16,'member',NULL,'active','2026-07-10 22:39:53'),
(23,3,2,'owner',NULL,'active','2026-07-10 22:39:53'),
(24,3,3,'member',NULL,'active','2026-07-10 22:39:53'),
(25,3,5,'member',NULL,'active','2026-07-10 22:39:53'),
(26,3,6,'member',NULL,'active','2026-07-10 22:39:53'),
(27,3,7,'member',NULL,'active','2026-07-10 22:39:53'),
(28,3,8,'member',NULL,'active','2026-07-10 22:39:53'),
(29,3,9,'member',NULL,'active','2026-07-10 22:39:53'),
(30,3,10,'member',NULL,'active','2026-07-10 22:39:53'),
(31,3,11,'member',NULL,'active','2026-07-10 22:39:53'),
(32,3,13,'member',NULL,'active','2026-07-10 22:39:53'),
(33,3,14,'member',NULL,'active','2026-07-10 22:39:53'),
(34,3,15,'member',NULL,'active','2026-07-10 22:39:53'),
(35,3,16,'member',NULL,'active','2026-07-10 22:39:53'),
(36,4,5,'member',NULL,'active','2026-07-10 22:39:53'),
(37,4,6,'member',NULL,'active','2026-07-10 22:39:53'),
(38,4,7,'member',NULL,'active','2026-07-10 22:39:53'),
(39,4,9,'member',NULL,'active','2026-07-10 22:39:53'),
(40,4,10,'member',NULL,'active','2026-07-10 22:39:53'),
(41,4,11,'member',NULL,'active','2026-07-10 22:39:53'),
(42,4,12,'member',NULL,'active','2026-07-10 22:39:53'),
(43,4,13,'owner',NULL,'active','2026-07-10 22:39:53'),
(44,4,16,'member',NULL,'active','2026-07-10 22:39:53'),
(45,5,19,'owner',NULL,'active','2026-07-12 12:19:47'),
(46,5,10001,'member',NULL,'active','2026-07-16 19:34:56'),
(47,6,19,'owner',NULL,'active','2026-07-16 20:44:28'),
(48,7,19,'owner',NULL,'active','2026-07-16 20:50:06'),
(49,7,10003,'member',NULL,'active','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_messages`
--

DROP TABLE IF EXISTS `chat_room_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `content` text DEFAULT '',
  `image_url` text DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `mention_ids` text DEFAULT '[]',
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  `order_card` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_messages`
--

LOCK TABLES `chat_room_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_messages` DISABLE KEYS */;
INSERT INTO `chat_room_messages` VALUES
(1,1,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 07:39:53'),
(2,1,13,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 08:39:53'),
(3,1,16,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 09:39:53'),
(4,1,10,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 17:39:53'),
(5,1,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 13:39:53'),
(6,1,6,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-09 11:39:53'),
(7,1,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 22:39:53'),
(8,2,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 15:39:53'),
(9,2,4,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 22:39:53'),
(10,2,13,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-09 18:39:53'),
(11,2,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 13:39:53'),
(12,2,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 23:39:53'),
(13,2,8,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 18:39:53'),
(14,2,11,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 01:39:53'),
(15,2,6,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-10 12:39:53'),
(16,2,4,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 04:39:53'),
(17,3,14,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 10:39:53'),
(18,3,2,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 10:39:53'),
(19,3,14,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 01:39:53'),
(20,3,8,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 10:39:53'),
(21,3,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 12:39:53'),
(22,3,7,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 22:39:53'),
(23,3,12,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 05:39:53'),
(24,4,5,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 08:39:53'),
(25,4,14,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 18:39:53'),
(26,4,4,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 19:39:53'),
(27,4,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 12:39:53'),
(28,4,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 22:39:53'),
(29,4,9,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 00:39:53'),
(30,4,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 14:39:53'),
(31,4,13,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-09 06:39:53'),
(32,4,7,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 22:39:53'),
(33,4,16,'','','这是聊天消息 #10','','text','[]',0,'none','','2026-07-09 20:39:53'),
(34,4,5,'','','这是聊天消息 #11','','text','[]',0,'none','','2026-07-09 10:39:53'),
(35,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','6','','text','[]',0,'none','','2026-07-12 12:27:34'),
(36,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg','text','[]',0,'none','','2026-07-12 12:27:42'),
(37,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg','text','[]',0,'none','','2026-07-12 12:44:57'),
(38,5,10001,'35735712','#448AFF','666','','text','[]',0,'none','','2026-07-16 19:35:02'),
(39,5,10001,'35735712','#448AFF','[投诉反馈]','','text','[]',0,'none','','2026-07-16 19:39:06'),
(40,7,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','6','','text','[]',0,'none','','2026-07-17 03:03:45');
/*!40000 ALTER TABLE `chat_room_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_pinned_messages`
--

DROP TABLE IF EXISTS `chat_room_pinned_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_pinned_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `pinned_by` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_pinned_messages`
--

LOCK TABLES `chat_room_pinned_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_pinned_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_pinned_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `avatar` varchar(500) DEFAULT '',
  `owner_id` int(11) NOT NULL,
  `password` varchar(100) DEFAULT '',
  `max_members` int(11) DEFAULT 500,
  `member_limit` int(11) DEFAULT 50,
  `join_mode` varchar(20) DEFAULT 'public',
  `status` varchar(20) DEFAULT 'active',
  `chat_enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_rooms`
--

LOCK TABLES `chat_rooms` WRITE;
/*!40000 ALTER TABLE `chat_rooms` DISABLE KEYS */;
INSERT INTO `chat_rooms` VALUES
(1,'设计交流群','','',4,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(2,'技术讨论组','','',5,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(3,'综合聊天室','','',2,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(4,'AI爱好者','','',13,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(5,'1','2','',19,'',500,50,'public','active',1,'2026-07-12 12:19:46'),
(6,'审批制测试群','用于测试入群申请流程','',19,'',500,50,'public','active',1,'2026-07-16 20:44:28'),
(7,'审批测试群2','完整测试入群流程','',19,'',500,50,'public','active',1,'2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_groups`
--

DROP TABLE IF EXISTS `checkin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level_id` int(11) DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#409EFF',
  `points` int(11) DEFAULT 5,
  `experience` int(11) DEFAULT 2,
  `balance` decimal(10,2) DEFAULT 0.00,
  `points_consecutive` int(11) DEFAULT 2,
  `experience_consecutive` int(11) DEFAULT 1,
  `balance_consecutive` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_groups`
--

LOCK TABLES `checkin_groups` WRITE;
/*!40000 ALTER TABLE `checkin_groups` DISABLE KEYS */;
INSERT INTO `checkin_groups` VALUES
(1,'默认分组',0,'S','#409EFF',10,2,0.00,2,1,0.00,0,'1','2026-07-10 22:39:54','2026-07-11 17:17:44');
/*!40000 ALTER TABLE `checkin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_milestones`
--

DROP TABLE IF EXISTS `checkin_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `days` int(11) NOT NULL DEFAULT 3,
  `points` int(11) DEFAULT 0,
  `experience` int(11) DEFAULT 0,
  `balance` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `card_key_duration_unit` varchar(10) DEFAULT '',
  `card_key_extra_points` int(11) DEFAULT 0,
  `card_key_extra_experience` int(11) DEFAULT 0,
  `card_key_extra_balance` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_milestones`
--

LOCK TABLES `checkin_milestones` WRITE;
/*!40000 ALTER TABLE `checkin_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_records`
--

DROP TABLE IF EXISTS `checkin_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `checkin_date` date NOT NULL,
  `consecutive_days` int(11) DEFAULT 1,
  `points_earned` int(11) DEFAULT 0,
  `experience_earned` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`checkin_date`),
  KEY `idx_checkin_records_user_date` (`user_id`,`checkin_date`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_records`
--

LOCK TABLES `checkin_records` WRITE;
/*!40000 ALTER TABLE `checkin_records` DISABLE KEYS */;
INSERT INTO `checkin_records` VALUES
(1,3,'','2026-07-10',2,18,0,'2026-07-10 22:39:53'),
(2,7,'','2026-07-10',14,17,0,'2026-07-10 22:39:53'),
(3,9,'','2026-07-10',2,16,0,'2026-07-10 22:39:53'),
(4,6,'','2026-07-10',7,21,0,'2026-07-10 22:39:53'),
(5,10,'','2026-07-10',7,7,0,'2026-07-10 22:39:53'),
(6,14,'','2026-07-09',13,6,0,'2026-07-09 22:39:53'),
(7,11,'','2026-07-09',12,20,0,'2026-07-09 22:39:53'),
(8,12,'','2026-07-09',8,13,0,'2026-07-09 22:39:53'),
(9,2,'','2026-07-09',7,9,0,'2026-07-09 22:39:53'),
(10,8,'','2026-07-08',2,11,0,'2026-07-08 22:39:53'),
(11,11,'','2026-07-08',12,12,0,'2026-07-08 22:39:53'),
(12,2,'','2026-07-08',14,17,0,'2026-07-08 22:39:53'),
(13,6,'','2026-07-07',11,18,0,'2026-07-07 22:39:53'),
(14,13,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(15,8,'','2026-07-07',1,11,0,'2026-07-07 22:39:53'),
(16,2,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(17,5,'','2026-07-06',15,6,0,'2026-07-06 22:39:53'),
(18,12,'','2026-07-06',14,8,0,'2026-07-06 22:39:53'),
(19,13,'','2026-07-06',13,11,0,'2026-07-06 22:39:53'),
(20,10,'','2026-07-06',11,15,0,'2026-07-06 22:39:53'),
(21,9,'','2026-07-06',2,23,0,'2026-07-06 22:39:53'),
(22,4,'','2026-07-06',7,12,0,'2026-07-06 22:39:53'),
(23,11,'','2026-07-05',4,5,0,'2026-07-05 22:39:53'),
(24,13,'','2026-07-05',7,18,0,'2026-07-05 22:39:53'),
(25,6,'','2026-07-05',15,7,0,'2026-07-05 22:39:53'),
(26,3,'','2026-07-05',1,10,0,'2026-07-05 22:39:53'),
(27,11,'','2026-07-04',1,18,0,'2026-07-04 22:39:53'),
(28,2,'','2026-07-04',7,20,0,'2026-07-04 22:39:53'),
(29,4,'','2026-07-04',12,20,0,'2026-07-04 22:39:53'),
(30,12,'','2026-07-04',1,12,0,'2026-07-04 22:39:53'),
(31,12,'','2026-07-03',14,15,0,'2026-07-03 22:39:53'),
(32,14,'','2026-07-03',15,13,0,'2026-07-03 22:39:53'),
(33,2,'','2026-07-03',14,11,0,'2026-07-03 22:39:53'),
(34,13,'','2026-07-03',1,12,0,'2026-07-03 22:39:53'),
(35,3,'','2026-07-03',8,5,0,'2026-07-03 22:39:53'),
(36,15,'','2026-07-02',12,13,0,'2026-07-02 22:39:53'),
(37,4,'','2026-07-02',14,13,0,'2026-07-02 22:39:53'),
(38,2,'','2026-07-02',11,7,0,'2026-07-02 22:39:53'),
(39,11,'','2026-07-01',10,16,0,'2026-07-01 22:39:53'),
(40,8,'','2026-07-01',9,12,0,'2026-07-01 22:39:53'),
(41,7,'','2026-07-01',6,6,0,'2026-07-01 22:39:53'),
(42,5,'','2026-07-01',10,24,0,'2026-07-01 22:39:53'),
(43,14,'','2026-06-30',6,17,0,'2026-06-30 22:39:53'),
(44,2,'','2026-06-30',10,21,0,'2026-06-30 22:39:53'),
(45,7,'','2026-06-30',1,14,0,'2026-06-30 22:39:53'),
(46,13,'','2026-06-30',2,9,0,'2026-06-30 22:39:53'),
(47,11,'','2026-06-29',5,22,0,'2026-06-29 22:39:53'),
(48,14,'','2026-06-29',5,19,0,'2026-06-29 22:39:53'),
(49,10,'','2026-06-29',11,24,0,'2026-06-29 22:39:53'),
(50,8,'','2026-06-29',10,24,0,'2026-06-29 22:39:53'),
(51,11,'','2026-06-28',15,18,0,'2026-06-28 22:39:53'),
(52,14,'','2026-06-28',7,19,0,'2026-06-28 22:39:53'),
(53,7,'','2026-06-28',6,5,0,'2026-06-28 22:39:53'),
(54,8,'','2026-06-28',9,24,0,'2026-06-28 22:39:53'),
(55,12,'','2026-06-28',15,12,0,'2026-06-28 22:39:53'),
(56,2,'','2026-06-28',9,20,0,'2026-06-28 22:39:53'),
(57,15,'','2026-06-27',1,5,0,'2026-06-27 22:39:53'),
(58,2,'','2026-06-27',6,9,0,'2026-06-27 22:39:53'),
(59,4,'','2026-06-27',14,18,0,'2026-06-27 22:39:53'),
(60,13,'','2026-06-26',1,5,0,'2026-06-26 22:39:53'),
(61,9,'','2026-06-26',15,20,0,'2026-06-26 22:39:53'),
(62,2,'','2026-06-26',5,11,0,'2026-06-26 22:39:53'),
(63,5,'','2026-06-25',5,10,0,'2026-06-25 22:39:53'),
(64,10,'','2026-06-25',7,5,0,'2026-06-25 22:39:53'),
(65,15,'','2026-06-25',15,15,0,'2026-06-25 22:39:53'),
(66,5,'','2026-06-24',8,24,0,'2026-06-24 22:39:53'),
(67,6,'','2026-06-24',7,24,0,'2026-06-24 22:39:53'),
(68,15,'','2026-06-24',8,23,0,'2026-06-24 22:39:53'),
(69,2,'','2026-06-24',12,12,0,'2026-06-24 22:39:53'),
(70,14,'','2026-06-23',12,18,0,'2026-06-23 22:39:53'),
(71,15,'','2026-06-23',1,19,0,'2026-06-23 22:39:53'),
(72,6,'','2026-06-23',13,20,0,'2026-06-23 22:39:53'),
(73,5,'','2026-06-23',5,22,0,'2026-06-23 22:39:53'),
(74,2,'','2026-06-23',1,23,0,'2026-06-23 22:39:53'),
(75,14,'','2026-06-22',5,21,0,'2026-06-22 22:39:53'),
(76,5,'','2026-06-22',10,16,0,'2026-06-22 22:39:53'),
(77,9,'','2026-06-22',5,5,0,'2026-06-22 22:39:53'),
(78,10,'','2026-06-22',6,10,0,'2026-06-22 22:39:53'),
(79,15,'','2026-06-22',14,17,0,'2026-06-22 22:39:53'),
(80,8,'','2026-06-22',1,17,0,'2026-06-22 22:39:53'),
(81,6,'','2026-06-21',8,15,0,'2026-06-21 22:39:53'),
(82,4,'','2026-06-21',8,22,0,'2026-06-21 22:39:53'),
(83,14,'','2026-06-21',8,8,0,'2026-06-21 22:39:53'),
(84,10,'','2026-06-21',6,21,0,'2026-06-21 22:39:53'),
(85,7,'','2026-06-21',6,5,0,'2026-06-21 22:39:53'),
(86,12,'','2026-06-21',8,20,0,'2026-06-21 22:39:53'),
(87,9,'','2026-06-21',5,8,0,'2026-06-21 22:39:53'),
(88,8,'','2026-06-21',11,21,0,'2026-06-21 22:39:53'),
(89,4,'','2026-06-20',14,22,0,'2026-06-20 22:39:53'),
(90,5,'','2026-06-20',5,23,0,'2026-06-20 22:39:53'),
(91,15,'','2026-06-20',6,22,0,'2026-06-20 22:39:53'),
(92,6,'','2026-06-20',2,11,0,'2026-06-20 22:39:53'),
(93,7,'','2026-06-20',7,7,0,'2026-06-20 22:39:53'),
(94,9,'','2026-06-20',12,23,0,'2026-06-20 22:39:53'),
(95,14,'','2026-06-20',3,12,0,'2026-06-20 22:39:53'),
(96,14,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(97,7,'','2026-06-19',2,21,0,'2026-06-19 22:39:53'),
(98,15,'','2026-06-19',15,10,0,'2026-06-19 22:39:53'),
(99,2,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(100,12,'','2026-06-19',1,15,0,'2026-06-19 22:39:53'),
(101,9,'','2026-06-18',1,19,0,'2026-06-18 22:39:53'),
(102,6,'','2026-06-18',10,6,0,'2026-06-18 22:39:53'),
(103,3,'','2026-06-18',4,10,0,'2026-06-18 22:39:53'),
(104,10,'','2026-06-18',6,11,0,'2026-06-18 22:39:53'),
(105,2,'','2026-06-17',6,9,0,'2026-06-17 22:39:53'),
(106,7,'','2026-06-17',11,24,0,'2026-06-17 22:39:53'),
(107,9,'','2026-06-17',6,11,0,'2026-06-17 22:39:53'),
(108,15,'','2026-06-17',7,16,0,'2026-06-17 22:39:53'),
(109,5,'','2026-06-17',6,22,0,'2026-06-17 22:39:53'),
(110,8,'','2026-06-16',3,10,0,'2026-06-16 22:39:53'),
(111,15,'','2026-06-16',6,21,0,'2026-06-16 22:39:53'),
(112,10,'','2026-06-16',6,18,0,'2026-06-16 22:39:53'),
(113,2,'','2026-06-16',14,14,0,'2026-06-16 22:39:53'),
(114,4,'','2026-06-15',15,24,0,'2026-06-15 22:39:53'),
(115,11,'','2026-06-15',12,17,0,'2026-06-15 22:39:53'),
(116,13,'','2026-06-15',11,10,0,'2026-06-15 22:39:53'),
(117,8,'','2026-06-15',6,8,0,'2026-06-15 22:39:53'),
(118,13,'','2026-06-14',6,23,0,'2026-06-14 22:39:53'),
(119,5,'','2026-06-14',12,6,0,'2026-06-14 22:39:53'),
(120,12,'','2026-06-14',13,6,0,'2026-06-14 22:39:53'),
(121,9,'','2026-06-14',10,10,0,'2026-06-14 22:39:53'),
(122,11,'','2026-06-14',6,10,0,'2026-06-14 22:39:53'),
(123,7,'','2026-06-13',4,22,0,'2026-06-13 22:39:53'),
(124,6,'','2026-06-13',8,12,0,'2026-06-13 22:39:53'),
(125,5,'','2026-06-13',9,11,0,'2026-06-13 22:39:53'),
(126,2,'','2026-06-13',1,7,0,'2026-06-13 22:39:53'),
(127,13,'','2026-06-13',5,11,0,'2026-06-13 22:39:53'),
(128,13,'','2026-06-12',14,19,0,'2026-06-12 22:39:53'),
(129,2,'','2026-06-12',14,7,0,'2026-06-12 22:39:53'),
(130,6,'','2026-06-12',3,9,0,'2026-06-12 22:39:53'),
(131,8,'','2026-06-12',4,22,0,'2026-06-12 22:39:53'),
(132,15,'','2026-06-12',1,17,0,'2026-06-12 22:39:53'),
(133,7,'','2026-06-12',8,12,0,'2026-06-12 22:39:53'),
(134,15,'','2026-06-11',11,14,0,'2026-06-11 22:39:53'),
(135,4,'','2026-06-11',15,5,0,'2026-06-11 22:39:53'),
(136,7,'','2026-06-11',14,17,0,'2026-06-11 22:39:53'),
(137,19,'alexmorgan','2026-07-12',1,10,2,'2026-07-12 11:19:10');
/*!40000 ALTER TABLE `checkin_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_favorite_groups`
--

DROP TABLE IF EXISTS `collection_favorite_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_favorite_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认收藏夹',
  `sort_order` int(11) DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_favorite_groups`
--

LOCK TABLES `collection_favorite_groups` WRITE;
/*!40000 ALTER TABLE `collection_favorite_groups` DISABLE KEYS */;
INSERT INTO `collection_favorite_groups` VALUES
(1,1,'默认收藏夹',0,0,'2026-07-16 01:23:44'),
(2,1,'编程教程',1,0,'2026-07-16 01:27:18'),
(3,1,'小说合集',2,0,'2026-07-16 01:27:18'),
(4,19,'默认收藏夹',0,0,'2026-07-16 04:06:09'),
(8,19,'266666',1,0,'2026-07-16 11:04:40'),
(9,10001,'默认收藏夹',0,0,'2026-07-16 15:55:13');
/*!40000 ALTER TABLE `collection_favorite_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_favorites`
--

DROP TABLE IF EXISTS `collection_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_collection` (`user_id`,`collection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_favorites`
--

LOCK TABLES `collection_favorites` WRITE;
/*!40000 ALTER TABLE `collection_favorites` DISABLE KEYS */;
INSERT INTO `collection_favorites` VALUES
(2,1,1,2,'2026-07-16 01:11:02');
/*!40000 ALTER TABLE `collection_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_read_progress`
--

DROP TABLE IF EXISTS `collection_read_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_read_progress` (
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `last_post_id` int(11) DEFAULT 0,
  `progress_pct` decimal(5,2) DEFAULT 0.00,
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  UNIQUE KEY `uk_user_collection` (`user_id`,`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_read_progress`
--

LOCK TABLES `collection_read_progress` WRITE;
/*!40000 ALTER TABLE `collection_read_progress` DISABLE KEYS */;
INSERT INTO `collection_read_progress` VALUES
(1,1,1,25.00,'2026-07-16 19:29:20');
/*!40000 ALTER TABLE `collection_read_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_id` (`comment_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
INSERT INTO `comment_likes` VALUES
(4,14,19),
(3,45,19),
(2,47,19);
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_records`
--

DROP TABLE IF EXISTS `commission_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0,
  `order_type` varchar(30) DEFAULT '',
  `order_amount` decimal(10,2) DEFAULT 0.00,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `referrer_id` int(11) NOT NULL,
  `referrer_name` varchar(100) DEFAULT '',
  `rate` decimal(5,2) DEFAULT 0.00,
  `level` int(11) DEFAULT 1,
  `reward_type` varchar(20) DEFAULT 'balance',
  `amount` decimal(10,2) DEFAULT 0.00,
  `points_amount` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_commission_records_user` (`user_id`),
  KEY `idx_commission_records_referrer` (`referrer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_records`
--

LOCK TABLES `commission_records` WRITE;
/*!40000 ALTER TABLE `commission_records` DISABLE KEYS */;
INSERT INTO `commission_records` VALUES
(1,1,'',236.00,9,'user9',10,'user10',0.00,1,'balance',14.81,0.00,'completed','2026-07-01 22:39:54'),
(2,2,'',144.00,11,'user11',12,'user12',0.00,1,'balance',11.19,0.00,'completed','2026-06-18 22:39:54'),
(3,3,'',165.00,8,'user8',9,'user9',0.00,1,'balance',17.71,0.00,'completed','2026-06-24 22:39:54'),
(4,4,'',113.00,8,'user8',9,'user9',0.00,1,'balance',17.55,0.00,'completed','2026-06-23 22:39:54'),
(5,5,'',84.00,5,'user5',6,'user6',0.00,1,'balance',14.54,0.00,'completed','2026-07-05 22:39:54'),
(6,6,'',182.00,8,'user8',9,'user9',0.00,1,'balance',6.23,0.00,'completed','2026-07-08 22:39:54'),
(7,7,'',99.00,12,'user12',13,'user13',0.00,1,'balance',23.75,0.00,'completed','2026-07-01 22:39:54'),
(8,8,'',125.00,3,'user3',4,'user4',0.00,1,'balance',20.88,0.00,'completed','2026-06-25 22:39:54'),
(9,21,'post',4.50,19,'',0,'',10.00,1,'balance',0.45,0.00,'completed','2026-07-15 04:20:52'),
(10,21,'post',100.00,19,'',0,'',10.00,1,'balance',10.00,0.00,'completed','2026-07-15 04:21:03'),
(11,22,'post',10.00,19,'',0,'',10.00,1,'balance',1.00,0.00,'completed','2026-07-16 00:16:50'),
(12,21,'post',100.00,19,'',0,'',10.00,1,'balance',10.00,0.00,'completed','2026-07-16 00:17:36'),
(13,21,'post',5.00,19,'',0,'',10.00,1,'balance',0.50,0.00,'completed','2026-07-16 00:17:45'),
(14,23,'post',8.88,19,'',0,'',10.00,1,'balance',0.89,0.00,'completed','2026-07-16 15:43:53'),
(22,31,'mall',9.80,10011,'',19,'alexmorgan',3.00,1,'balance',0.29,0.00,'completed','2026-07-17 18:39:28'),
(23,36,'mall',980.00,10011,'',19,'alexmorgan',5.00,1,'points',0.00,49.00,'completed','2026-07-17 18:47:59'),
(24,18,'membership',48.00,19,'',3,'tech_guru',3.00,1,'balance',1.44,0.00,'completed','2026-07-17 19:37:43'),
(25,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:46'),
(26,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:50'),
(27,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:57'),
(28,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:38:02'),
(29,18,'membership',48.00,19,'',3,'tech_guru',3.00,1,'balance',1.44,0.00,'completed','2026-07-17 19:38:04'),
(30,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:09'),
(31,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:15'),
(32,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:19'),
(33,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:23'),
(34,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:27'),
(35,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:32');
/*!40000 ALTER TABLE `commission_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `order_type` varchar(30) DEFAULT 'all',
  `rate` decimal(5,2) DEFAULT 0.00,
  `points_rate` decimal(5,2) DEFAULT 0.00,
  `reward_type` varchar(20) DEFAULT 'balance',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `invite_code_id` int(11) DEFAULT 0,
  `invite_code_type` varchar(20) DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `level` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rules`
--

LOCK TABLES `commission_rules` WRITE;
/*!40000 ALTER TABLE `commission_rules` DISABLE KEYS */;
INSERT INTO `commission_rules` VALUES
(1,'一级返佣','all',10.00,0.00,'balance',1,'',0,0,'','1','2026-07-10 22:39:54',1),
(2,'二级返佣','all',5.00,0.00,'balance',2,'',0,0,'','1','2026-07-10 22:39:54',1),
(3,'默认返佣(全局)','all',3.00,1.00,'balance',0,'',0,0,'','1','2026-07-17 17:44:43',0),
(4,'积分返佣(全局)','all',0.00,5.00,'points',0,'',0,0,'','1','2026-07-17 18:01:17',0);
/*!40000 ALTER TABLE `commission_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_attach_purchases`
--

DROP TABLE IF EXISTS `community_attach_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_attach_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attach_url` varchar(500) NOT NULL DEFAULT '',
  `coin_type` varchar(20) NOT NULL DEFAULT 'coin',
  `coin_amount` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_attach_purchases`
--

LOCK TABLES `community_attach_purchases` WRITE;
/*!40000 ALTER TABLE `community_attach_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_attach_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_auto_bans`
--

DROP TABLE IF EXISTS `community_auto_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_auto_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `report_count` int(11) DEFAULT 0 COMMENT '触发时的举报次数',
  `banned_until` datetime DEFAULT NULL,
  `triggered_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_triggered` (`user_id`,`triggered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_auto_bans`
--

LOCK TABLES `community_auto_bans` WRITE;
/*!40000 ALTER TABLE `community_auto_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_auto_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_banned_users`
--

DROP TABLE IF EXISTS `community_banned_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_banned_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `banned_until` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_community_banned_users_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_banned_users`
--

LOCK TABLES `community_banned_users` WRITE;
/*!40000 ALTER TABLE `community_banned_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_banned_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_coin_logs`
--

DROP TABLE IF EXISTS `community_coin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_coin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '',
  `to_user_id` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_coin_logs`
--

LOCK TABLES `community_coin_logs` WRITE;
/*!40000 ALTER TABLE `community_coin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_coin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_collection_posts`
--

DROP TABLE IF EXISTS `community_collection_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_collection_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_preview` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`),
  UNIQUE KEY `collection_id` (`collection_id`,`post_id`),
  KEY `idx_community_collection_posts_collection` (`collection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_collection_posts`
--

LOCK TABLES `community_collection_posts` WRITE;
/*!40000 ALTER TABLE `community_collection_posts` DISABLE KEYS */;
INSERT INTO `community_collection_posts` VALUES
(4,1,28,4,0,'2026-07-15 20:48:23');
/*!40000 ALTER TABLE `community_collection_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_collections`
--

DROP TABLE IF EXISTS `community_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `post_count` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'draft',
  `is_paid` tinyint(1) DEFAULT 0,
  `price_balance` decimal(10,2) DEFAULT 0.00,
  `price_points` int(11) DEFAULT 0,
  `preview_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `subscribe_count` int(11) DEFAULT 0,
  `sort_mode` varchar(20) DEFAULT 'manual',
  `section_id` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `share_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_community_collections_user_id` (`user_id`),
  KEY `idx_community_collections_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_collections`
--

LOCK TABLES `community_collections` WRITE;
/*!40000 ALTER TABLE `community_collections` DISABLE KEYS */;
INSERT INTO `community_collections` VALUES
(1,19,'alexmorgan','','社区功能测试合集','本合集收录了社区各功能模块的测试帖子，方便查阅各功能状态。包括编辑器文字格式、卡片与多媒体、付费内容等功能测试。','',4,'serializing',1,20.00,200,1,0,1,'manual',1,0,'2026-07-15 20:48:18','2026-07-16 01:11:09',1),
(2,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','666','666','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-15 20:57:30','2026-07-15 20:57:30',0),
(3,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','666','666','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-15 20:57:33','2026-07-15 20:57:33',0),
(6,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','1','2','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-16 00:10:18','2026-07-16 00:10:26',0),
(7,10001,'35735712','','666','','',0,'finished',0,0.00,0,0,0,0,'manual',0,0,'2026-07-16 00:20:58','2026-07-16 00:21:32',0);
/*!40000 ALTER TABLE `community_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_comments`
--

DROP TABLE IF EXISTS `community_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `content` text NOT NULL,
  `images` text DEFAULT '[]',
  `like_count` int(11) DEFAULT 0,
  `reply_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `is_pinned` tinyint(1) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'published',
  `is_deleted` tinyint(4) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_community_comments_post_id` (`post_id`),
  KEY `idx_community_comments_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comments`
--

LOCK TABLES `community_comments` WRITE;
/*!40000 ALTER TABLE `community_comments` DISABLE KEYS */;
INSERT INTO `community_comments` VALUES
(54,27,0,10001,'user_10001','','66','[]',0,0,'2026-07-16 15:43:21',0,0,'published',0,NULL);
/*!40000 ALTER TABLE `community_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_drafts`
--

DROP TABLE IF EXISTS `community_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_drafts_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_drafts`
--

LOCK TABLES `community_drafts` WRITE;
/*!40000 ALTER TABLE `community_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_favorites`
--

DROP TABLE IF EXISTS `community_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_favorites_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_favorites`
--

LOCK TABLES `community_favorites` WRITE;
/*!40000 ALTER TABLE `community_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_likes`
--

DROP TABLE IF EXISTS `community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_likes_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_likes`
--

LOCK TABLES `community_likes` WRITE;
/*!40000 ALTER TABLE `community_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderator_bans`
--

DROP TABLE IF EXISTS `community_moderator_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderator_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `banned_user_id` int(11) NOT NULL,
  `banned_user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `ban_type` varchar(20) DEFAULT 'section_mute',
  `ban_until` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section_user` (`section_id`,`banned_user_id`),
  KEY `idx_active` (`is_active`,`ban_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderator_bans`
--

LOCK TABLES `community_moderator_bans` WRITE;
/*!40000 ALTER TABLE `community_moderator_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_moderator_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderator_logs`
--

DROP TABLE IF EXISTS `community_moderator_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderator_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `moderator_id` int(11) NOT NULL,
  `moderator_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_type` varchar(30) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section` (`section_id`),
  KEY `idx_moderator` (`moderator_id`),
  KEY `idx_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderator_logs`
--

LOCK TABLES `community_moderator_logs` WRITE;
/*!40000 ALTER TABLE `community_moderator_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_moderator_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderators`
--

DROP TABLE IF EXISTS `community_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `role` varchar(20) DEFAULT '版主',
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderators`
--

LOCK TABLES `community_moderators` WRITE;
/*!40000 ALTER TABLE `community_moderators` DISABLE KEYS */;
INSERT INTO `community_moderators` VALUES
(1,1,19,'Alex Morgan','','管理员',0,'2026-07-13 18:31:33'),
(7,1,2,'lisa_chen','','审核员',0,'2026-07-15 19:31:36'),
(8,1,10001,'35735712','','管理员',0,'2026-07-16 17:07:01');
/*!40000 ALTER TABLE `community_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_revisions`
--

DROP TABLE IF EXISTS `community_post_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `editor_id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `edit_summary` varchar(500) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_revisions`
--

LOCK TABLES `community_post_revisions` WRITE;
/*!40000 ALTER TABLE `community_post_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_post_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_topics`
--

DROP TABLE IF EXISTS `community_post_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`topic_id`),
  KEY `idx_post_topics_post` (`post_id`),
  KEY `idx_post_topics_topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_topics`
--

LOCK TABLES `community_post_topics` WRITE;
/*!40000 ALTER TABLE `community_post_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_post_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_posts`
--

DROP TABLE IF EXISTS `community_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(500) DEFAULT '',
  `content` longtext DEFAULT '',
  `device` varchar(100) DEFAULT '',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `images` longtext DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `is_pinned` int(11) DEFAULT 0,
  `is_essence` int(11) DEFAULT 0,
  `is_hot` int(11) DEFAULT 0,
  `hot_manually_disabled` tinyint(1) DEFAULT 0,
  `is_global_pinned` tinyint(1) DEFAULT 0,
  `custom_badge` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'published',
  `like_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `coin_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `favorite_count` int(11) DEFAULT 0,
  `topic_id` int(11) DEFAULT 0,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `cover_url` varchar(500) DEFAULT '',
  `is_edited` int(11) DEFAULT 0,
  `edit_count` int(11) DEFAULT 0,
  `edited_at` datetime DEFAULT NULL,
  `avatar_frame` varchar(500) DEFAULT '',
  `name_color` varchar(20) DEFAULT '',
  `is_anonymous` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  `edition` int(11) DEFAULT 1,
  `community_id` int(11) DEFAULT 0,
  `community_name` varchar(100) DEFAULT '',
  `community_icon` varchar(500) DEFAULT '',
  `review_status` varchar(20) DEFAULT 'approved',
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(100) DEFAULT '',
  `review_reason` text DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `locked` int(11) DEFAULT 0,
  `is_locked` int(11) DEFAULT 0,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT 0,
  `locked_reason` varchar(500) DEFAULT '',
  `share_count` int(11) DEFAULT 0,
  `content_type` varchar(20) DEFAULT 'text',
  `attachment_urls` text DEFAULT NULL,
  `hidden_content` text DEFAULT NULL,
  `hidden_attachment_urls` text DEFAULT NULL,
  `free_read` int(11) DEFAULT 0,
  `free_count` int(11) DEFAULT 500,
  `cover_width` int(11) DEFAULT 0,
  `cover_height` int(11) DEFAULT 0,
  `duration_us` int(11) DEFAULT 0,
  `size_mb` decimal(10,2) DEFAULT 0.00,
  `mime_type` varchar(100) DEFAULT '',
  `voice_url` varchar(500) DEFAULT '',
  `voice_duration` int(11) DEFAULT 0,
  `video_width` int(11) DEFAULT 0,
  `video_height` int(11) DEFAULT 0,
  `original_lang` varchar(10) DEFAULT '',
  `translations` text DEFAULT NULL,
  `is_sticky_global` tinyint(1) DEFAULT 0,
  `sticky_order` int(11) DEFAULT 0,
  `sticky_section_id` int(11) DEFAULT 0,
  `sticky_until` datetime DEFAULT NULL,
  `post_uid` varchar(36) DEFAULT '',
  `summary` varchar(200) DEFAULT '',
  `sort_weight` decimal(10,2) DEFAULT 0.00,
  `scheduled_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `reported` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_community_posts_section_id` (`section_id`),
  KEY `idx_community_posts_user_id` (`user_id`),
  KEY `idx_community_posts_status` (`status`),
  KEY `idx_community_posts_is_pinned` (`is_pinned`),
  KEY `idx_community_posts_is_essence` (`is_essence`),
  KEY `idx_community_posts_is_hot` (`is_hot`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_posts`
--

LOCK TABLES `community_posts` WRITE;
/*!40000 ALTER TABLE `community_posts` DISABLE KEYS */;
INSERT INTO `community_posts` VALUES
(24,1,19,'Alex Morgan','','【会员专属】黄金会员专属福利 - 设计素材大礼包','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"本贴为黄金会员专属内容，包含高质量设计素材下载链接和使用教程。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"素材包内包含：矢量图标库、渐变配色方案、UI组件模板等。\"}]},{\"type\":\"memberUnlock\",\"attrs\":{\"levelId\":2,\"levelName\":\"黄金会员\"}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"会员专属素材下载\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接一：完整矢量图标库 (1200+ icons)\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接二：百套渐变配色方案\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接三：Figma UI组件模板合集\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"marks\":[{\"type\":\"textColor\",\"attrs\":{\"color\":\"#d48806\"}}],\"text\":\"感谢您的会员支持，更多福利持续更新中！\"}]}]}','','[\"会员专属\",\"设计素材\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,1,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-15 18:07:20','2026-07-15 18:07:20',0),
(25,1,19,'Alex Morgan','','【等级限制】Lv.2 经验等级专属 - 进阶设计技巧分享','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"本文分享一些进阶设计技巧，需要经验等级达到 Lv.2 才能查看全部内容。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"以下是部分预览：字体排印的技巧与艺术是UI设计中最重要的基础之一。\"}]},{\"type\":\"experienceUnlock\",\"attrs\":{\"level\":2,\"levelName\":\"Lv.2\"}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"进阶技巧一：微交互设计\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"微交互是用户与界面之间最小的交互单元，优秀的微交互能极大提升用户体验。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"关键要素：触发器、规则、反馈、循环与模式。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"进阶技巧二：响应式断点策略\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"合理设置响应式断点是跨设备适配的核心，推荐使用移动优先策略。\"}]}]}','','[\"进阶技巧\",\"等级限制\",\"微交互\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-15 18:07:46','2026-07-15 18:07:46',0),
(26,1,19,'Alex Morgan','','【登录可见】社区新人必读 - 发帖规范与积分规则详解','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"欢迎来到设计社区！本贴详细介绍了社区的发帖规范和积分获取规则。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"登录后即可查看完整的社区指南，帮助你快速上手。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"发帖规范\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"1. 帖子标题应简洁明了，准确描述内容主题。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"2. 内容需原创或有授权转载，禁止搬运他人作品。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"3. 禁止发布广告、色情、暴力等违规内容。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"积分获取规则\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"每日签到：+5积分\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"发布帖子：+10积分\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"优质回复：+3积分\"}]}]}','','[\"社区指南\",\"新人必读\",\"登录可见\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,5,0,0,'login',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-15 18:07:46','2026-07-15 18:07:46',0),
(27,1,19,'Alex Morgan','','【评论解锁】隐藏的设计资源链接 - 评论即可查看','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"我整理了一份超实用的设计资源清单，包含免费工具、灵感网站和学习平台。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"只需要在下方评论区留言，即可解锁查看全部资源链接！\"}]},{\"type\":\"commentUnlock\",\"attrs\":{\"minCommentCount\":1}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"设计工具推荐\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Figma - 在线协作设计工具，免费版功能强大\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Blender - 开源3D建模软件，社区活跃\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Procreate - iPad绘画神器，笔刷丰富\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"灵感网站推荐\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Dribbble - 全球设计师作品展示平台\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Behance - Adobe旗下创意作品社区\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Awwwards - 优秀网站设计评选与展示\"}]}]}','','[\"设计资源\",\"评论解锁\",\"免费工具\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,1,0,16,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-15 18:07:46','2026-07-16 15:43:21',0),
(28,1,19,'alexmorgan','','【测试】称号解锁功能 - 设计达人专属内容','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"这是一段所有人可见的公开内容，欢迎来到称号解锁测试帖！\"}]},{\"type\":\"titleUnlock\",\"attrs\":{\"titleId\":1,\"titleName\":\"设计达人\"}},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"恭喜！你拥有设计达人称号，成功看到了这段隐藏内容。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"这段内容只有被授予了设计达人称号的用户才能查看。\"}]}]}','','[]','[]','[]',0,'','',0,'free','','public',0,1,1,0,0,'','published',0,0,0,124,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,'2026-07-15 20:05:26','2026-07-15 20:05:26',0);
/*!40000 ALTER TABLE `community_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_ratings`
--

DROP TABLE IF EXISTS `community_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `target_type` varchar(50) NOT NULL DEFAULT 'collection',
  `target_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_target` (`user_id`,`target_type`,`target_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_ratings`
--

LOCK TABLES `community_ratings` WRITE;
/*!40000 ALTER TABLE `community_ratings` DISABLE KEYS */;
INSERT INTO `community_ratings` VALUES
(1,1,'collection',1,5,'2026-07-16 19:29:20');
/*!40000 ALTER TABLE `community_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_reports`
--

DROP TABLE IF EXISTS `community_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `reporter_name` varchar(100) DEFAULT '',
  `target_type` varchar(20) NOT NULL,
  `target_id` int(11) NOT NULL,
  `report_reason` varchar(100) DEFAULT '其他',
  `category` varchar(50) DEFAULT 'other',
  `report_detail` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `handled_by` int(11) DEFAULT 0,
  `handled_at` datetime DEFAULT NULL,
  `handle_result` varchar(50) DEFAULT '',
  `appeal_reason` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_reports`
--

LOCK TABLES `community_reports` WRITE;
/*!40000 ALTER TABLE `community_reports` DISABLE KEYS */;
INSERT INTO `community_reports` VALUES
(9,19,'alexmorgan','comment',2,'垃圾广告','other','评论','ignored',0,NULL,'','','2026-07-11 11:36:59'),
(10,19,'alexmorgan','app_comment',13,'6','other','','pending',0,NULL,'','','2026-07-11 11:51:00'),
(11,19,'alexmorgan','comment',46,'色情低俗','other','66','pending',0,NULL,'','','2026-07-15 15:37:37'),
(12,19,'alexmorgan','comment',45,'垃圾广告','other','','pending',0,NULL,'','','2026-07-15 15:59:52');
/*!40000 ALTER TABLE `community_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sections`
--

DROP TABLE IF EXISTS `community_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `description` text DEFAULT '',
  `today_heat` int(11) DEFAULT 0,
  `total_heat` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `visibility` varchar(20) DEFAULT 'public',
  `post_permission` varchar(20) DEFAULT 'all',
  `view_permission` varchar(20) DEFAULT 'all',
  `view_level_required` int(11) DEFAULT 0,
  `hot_threshold` int(11) DEFAULT 100 COMMENT '热帖热度阈值',
  `view_cooldown` int(11) DEFAULT 30 COMMENT '浏览计数冷却时间(秒)',
  `announcement` text DEFAULT '',
  `rules` text DEFAULT '',
  `banner_url` varchar(500) DEFAULT '',
  `review_required` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `comment_review_required` tinyint(4) DEFAULT 0,
  `is_deleted` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sections`
--

LOCK TABLES `community_sections` WRITE;
/*!40000 ALTER TABLE `community_sections` DISABLE KEYS */;
INSERT INTO `community_sections` VALUES
(1,'综合讨论','','#00BFA5','综合讨论版块',0,0,5,0,1,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(2,'技术交流','','#00BFA5','技术交流版块',0,0,5,0,2,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(3,'设计创作','','#00BFA5','设计创作版块',0,0,5,0,3,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(4,'资源分享','','#00BFA5','资源分享版块',0,0,5,0,4,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(5,'反馈建议','','#00BFA5','反馈建议版块',0,0,5,0,5,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0);
/*!40000 ALTER TABLE `community_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sensitive_words`
--

DROP TABLE IF EXISTS `community_sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `replacement` varchar(100) DEFAULT '',
  `category` varchar(50) DEFAULT '',
  `level` varchar(20) DEFAULT 'block',
  `status` tinyint(4) DEFAULT 1,
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_word` (`word`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sensitive_words`
--

LOCK TABLES `community_sensitive_words` WRITE;
/*!40000 ALTER TABLE `community_sensitive_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_settings`
--

DROP TABLE IF EXISTS `community_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_settings`
--

LOCK TABLES `community_settings` WRITE;
/*!40000 ALTER TABLE `community_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_tags`
--

DROP TABLE IF EXISTS `community_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `normalized_name` varchar(50) NOT NULL,
  `post_count` int(11) DEFAULT 0,
  `section_id` int(11) DEFAULT 0,
  `status` tinyint(4) DEFAULT 1 COMMENT '1=active 0=hidden',
  `is_official` tinyint(4) DEFAULT 0 COMMENT '1=official_tag',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_normalized` (`normalized_name`),
  KEY `idx_post_count` (`post_count`),
  KEY `idx_section` (`section_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_tags`
--

LOCK TABLES `community_tags` WRITE;
/*!40000 ALTER TABLE `community_tags` DISABLE KEYS */;
INSERT INTO `community_tags` VALUES
(1,'vue3','vue3',1,0,1,0,'2026-07-16 19:44:26'),
(2,'express','express',1,0,1,0,'2026-07-16 19:44:26'),
(3,'全栈项目','全栈项目',1,0,1,0,'2026-07-16 19:44:26'),
(4,'博客开发','博客开发',1,0,1,0,'2026-07-16 19:44:26'),
(5,'设计资源','设计资源',2,0,1,0,'2026-07-16 19:44:26'),
(6,'ui组件库','ui组件库',1,0,1,0,'2026-07-16 19:44:26'),
(7,'字体包','字体包',1,0,1,0,'2026-07-16 19:44:26'),
(8,'插画素材','插画素材',1,0,1,0,'2026-07-16 19:44:26'),
(9,'测试标签','测试标签',1,0,1,0,'2026-07-16 19:44:26'),
(10,'编辑功能','编辑功能',1,0,1,0,'2026-07-16 19:44:26'),
(11,'前端','前端',1,0,1,0,'2026-07-16 19:44:26'),
(12,'设计教程','设计教程',1,0,1,0,'2026-07-16 19:44:26'),
(13,'ui设计','ui设计',1,0,1,0,'2026-07-16 19:44:26'),
(14,'付费内容','付费内容',1,0,1,0,'2026-07-16 19:44:26'),
(15,'会员专属','会员专属',1,0,1,0,'2026-07-16 19:44:26'),
(16,'设计素材','设计素材',1,0,1,0,'2026-07-16 19:44:26'),
(17,'进阶技巧','进阶技巧',1,0,1,0,'2026-07-16 19:44:26'),
(18,'等级限制','等级限制',1,0,1,0,'2026-07-16 19:44:26'),
(19,'微交互','微交互',1,0,1,0,'2026-07-16 19:44:26'),
(20,'社区指南','社区指南',1,0,1,0,'2026-07-16 19:44:26'),
(21,'新人必读','新人必读',1,0,1,0,'2026-07-16 19:44:26'),
(22,'登录可见','登录可见',1,0,1,0,'2026-07-16 19:44:26'),
(23,'评论解锁','评论解锁',1,0,1,0,'2026-07-16 19:44:26'),
(24,'免费工具','免费工具',1,0,1,0,'2026-07-16 19:44:26');
/*!40000 ALTER TABLE `community_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_topics`
--

DROP TABLE IF EXISTS `community_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `description` text DEFAULT '',
  `creator_id` int(11) DEFAULT 0,
  `creator_name` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_topics`
--

LOCK TABLES `community_topics` WRITE;
/*!40000 ALTER TABLE `community_topics` DISABLE KEYS */;
INSERT INTO `community_topics` VALUES
(1,'AI绘画','','AI绘画相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(2,'前端开发','','前端开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(3,'设计灵感','','设计灵感相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(4,'独立开发','','独立开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(5,'UI/UX','','UI/UX相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(6,'科技资讯','','科技资讯相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(7,'摄影分享','','摄影分享相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(8,'生活记录','','生活记录相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(9,'test_bob_1783772379','','',1,'bobwang',0,0,0,'1','2026-07-11 20:19:39'),
(10,'test_tech_1783772379','','',3,'tech_guru',0,0,0,'1','2026-07-11 20:19:39');
/*!40000 ALTER TABLE `community_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_trust_levels`
--

DROP TABLE IF EXISTS `community_trust_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_trust_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level` tinyint(4) DEFAULT 0 COMMENT '0=新手 1=成员 2=活跃 3=资深',
  `post_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `like_received` int(11) DEFAULT 0,
  `report_count` int(11) DEFAULT 0 COMMENT '被举报次数',
  `ban_count` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  `last_calculated` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_trust_levels`
--

LOCK TABLES `community_trust_levels` WRITE;
/*!40000 ALTER TABLE `community_trust_levels` DISABLE KEYS */;
INSERT INTO `community_trust_levels` VALUES
(1,19,0,0,0,3,0,0,0,NULL,'2026-07-17 02:15:18','2026-07-17 02:20:34'),
(2,10004,0,0,6,0,0,0,0,NULL,'2026-07-17 02:15:18','2026-07-17 02:20:34');
/*!40000 ALTER TABLE `community_trust_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_unlock_requests`
--

DROP TABLE IF EXISTS `community_unlock_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_unlock_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_reply` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_unlock_requests`
--

LOCK TABLES `community_unlock_requests` WRITE;
/*!40000 ALTER TABLE `community_unlock_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_unlock_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_vote_records`
--

DROP TABLE IF EXISTS `community_vote_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_vote_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `option_index` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vote_user_option` (`vote_id`,`user_id`,`option_index`),
  KEY `idx_vote_id` (`vote_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_vote_records`
--

LOCK TABLES `community_vote_records` WRITE;
/*!40000 ALTER TABLE `community_vote_records` DISABLE KEYS */;
INSERT INTO `community_vote_records` VALUES
(1,1,1,0,'2026-07-15 04:33:28'),
(2,1,1,1,'2026-07-15 04:33:37'),
(3,2,19,0,'2026-07-15 06:25:35'),
(4,1,10001,0,'2026-07-16 00:18:11'),
(5,2,10001,0,'2026-07-16 18:59:52');
/*!40000 ALTER TABLE `community_vote_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_votes`
--

DROP TABLE IF EXISTS `community_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL DEFAULT '',
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`options`)),
  `max_select` int(11) NOT NULL DEFAULT 1,
  `total_votes` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_votes`
--

LOCK TABLES `community_votes` WRITE;
/*!40000 ALTER TABLE `community_votes` DISABLE KEYS */;
INSERT INTO `community_votes` VALUES
(1,20,'你最喜欢哪个编辑器功能？','[\"文字格式排版\",\"多媒体嵌入\",\"付费内容设置\",\"互动解锁模块\",\"等级权益卡片\"]',2,3,1,'2026-07-15 04:33:28'),
(2,22,'我是想象问题','[\"你检查什么\",\"我不知道\"]',1,2,1,'2026-07-15 06:25:35');
/*!40000 ALTER TABLE `community_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_access_passwords`
--

DROP TABLE IF EXISTS `content_access_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_access_passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tips` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_access_passwords_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_access_passwords`
--

LOCK TABLES `content_access_passwords` WRITE;
/*!40000 ALTER TABLE `content_access_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_access_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_purchases`
--

DROP TABLE IF EXISTS `content_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT 0,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `commission_amount` decimal(10,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `block_index` int(11) DEFAULT -1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_purchases_user` (`user_id`),
  KEY `idx_content_purchases_content` (`content_type`,`content_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_purchases`
--

LOCK TABLES `content_purchases` WRITE;
/*!40000 ALTER TABLE `content_purchases` DISABLE KEYS */;
INSERT INTO `content_purchases` VALUES
(1,14,'app',2,0,17.20,'balance',0.00,0.00,-1,'2026-07-03 22:39:54'),
(2,5,'app',2,0,20.34,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(3,5,'app',10,0,15.60,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(4,8,'app',6,0,20.23,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(5,9,'app',2,0,15.88,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(6,10,'app',2,0,50.01,'balance',0.00,0.00,-1,'2026-06-25 22:39:54'),
(7,13,'app',8,0,36.22,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(8,13,'app',9,0,11.34,'balance',0.00,0.00,-1,'2026-06-25 22:39:54');
/*!40000 ALTER TABLE `content_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usage_logs`
--

DROP TABLE IF EXISTS `coupon_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `coupon_id` int(11) NOT NULL,
  `coupon_name` varchar(200) DEFAULT '',
  `use_scene` varchar(50) DEFAULT '',
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `before_remaining` decimal(10,2) DEFAULT NULL,
  `after_remaining` decimal(10,2) DEFAULT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `use_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usage_logs`
--

LOCK TABLES `coupon_usage_logs` WRITE;
/*!40000 ALTER TABLE `coupon_usage_logs` DISABLE KEYS */;
INSERT INTO `coupon_usage_logs` VALUES
(1,38,19,'alexmorgan',1,'新人专享券','membership_buy',5.00,NULL,NULL,'购买 1个月 原价¥15.00 余额减¥5.00','2026-07-12 08:11:10');
/*!40000 ALTER TABLE `coupon_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'fixed',
  `value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_order` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) DEFAULT 0.00,
  `scope` varchar(20) NOT NULL DEFAULT 'all',
  `target_ids` text DEFAULT '',
  `target_names` text DEFAULT '',
  `total_count` int(11) DEFAULT 0,
  `claimed_count` int(11) NOT NULL DEFAULT 0,
  `per_user_limit` int(11) NOT NULL DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `valid_days` int(11) DEFAULT 0,
  `category` varchar(20) DEFAULT 'general',
  `is_recommend` tinyint(1) DEFAULT 0,
  `is_new_user` tinyint(1) DEFAULT 0,
  `is_rush` tinyint(1) DEFAULT 0,
  `required_level_ids` text DEFAULT '',
  `required_level_names` text DEFAULT '',
  `is_multi_use` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coupons_status` (`status`),
  KEY `idx_coupons_scope` (`scope`),
  KEY `idx_coupons_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES
(1,'新人专享券','','fixed',5.00,10.00,100.00,'all','','',100,22,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(2,'满减优惠券','','fixed',10.00,50.00,200.00,'all','','',100,21,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(3,'VIP折扣券','','percentage',15.00,0.00,0.00,'all','','',100,8,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(4,'节日特惠券','','fixed',20.00,30.00,500.00,'all','','',100,29,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(5,'限时体验券','','percentage',8.00,0.00,0.00,'all','','',100,23,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(6,'黄金会员','','percent',10.00,1.00,10.00,'all','','',99,1,1,'2026-07-12 04:42:00','2030-07-12 04:42:00',30,'general',0,0,0,'2','',0,5,'1','2026-07-11 20:42:43');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_tasks`
--

DROP TABLE IF EXISTS `custom_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `task_type` varchar(30) NOT NULL DEFAULT 'daily',
  `action_type` varchar(30) NOT NULL DEFAULT 'post',
  `target_count` int(11) DEFAULT 1,
  `section_id` int(11) DEFAULT 0,
  `section_limit` int(11) DEFAULT 0,
  `points_reward` int(11) DEFAULT 0,
  `exp_reward` int(11) DEFAULT 0,
  `balance_reward` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `title_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `sort_order` int(11) DEFAULT 0,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_tasks`
--

LOCK TABLES `custom_tasks` WRITE;
/*!40000 ALTER TABLE `custom_tasks` DISABLE KEYS */;
INSERT INTO `custom_tasks` VALUES
(1,'每日签到','','','daily','checkin',1,0,0,10,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(2,'发帖奖励','','','daily','post',1,0,0,20,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(3,'评论互动','','','daily','comment',1,0,0,5,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53'),
(4,'邀请好友','','','daily','invite',1,0,0,50,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:54'),
(5,'完善资料','','','daily','profile',1,0,0,30,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `custom_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_titles`
--

DROP TABLE IF EXISTS `custom_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `color` varchar(20) DEFAULT '#409EFF',
  `bg_color` varchar(20) DEFAULT '#ecf5ff',
  `description` varchar(500) DEFAULT '',
  `condition_type` varchar(20) DEFAULT 'manual',
  `condition_value` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `category` varchar(20) DEFAULT '',
  `expire_days` int(11) DEFAULT 0,
  `upgrade_to_id` int(11) DEFAULT 0,
  `keep_previous` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_titles`
--

LOCK TABLES `custom_titles` WRITE;
/*!40000 ALTER TABLE `custom_titles` DISABLE KEYS */;
INSERT INTO `custom_titles` VALUES
(1,'设计达人','ri:palette-line','#FF4757','#ecf5ff','','manual','',0,'1','成就',0,0,0,'2026-07-10 22:39:54'),
(2,'技术大牛','ri:code-box-line','#0984E3','#ecf5ff','','manual','',0,'1','成就',0,0,0,'2026-07-10 22:39:54'),
(3,'社区之星','ri:star-line','#FDCB6E','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(4,'创作先锋','ri:quill-pen-line','#00B894','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(5,'活跃分子','ri:flashlight-line','#6C5CE7','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(6,'分享达人','ri:share-line','#E17055','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(7,'至尊会员','','#FFD700','#FFF8E1','会员专属称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(8,'铂金达人','','#E5E4E2','#F5F5F5','高级会员称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(9,'钻石王者','','#00CED1','#E0FFFF','顶级会员称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(10,'蓝V官方认证','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987369006-697144065.png','#409EFF','#ffffff','','manual','',0,'1','管理员',0,0,0,'2026-07-13 21:52:48'),
(11,'官方认证','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783981009908-814127258.png','#409EFF','#ecf5ff','','manual','',0,'1','管理员',0,0,0,'2026-07-13 22:16:52'),
(12,'发帖达人','icon-post-master','#409EFF','#ecf5ff','累计发布帖子数达到50篇','post_count','50',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(13,'百赞之星','icon-like-star','#409EFF','#ecf5ff','累计获得点赞数达到100次','like_received','100',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(14,'评论大师','icon-comment-master','#409EFF','#ecf5ff','累计发表评论数达到200条','comment_count','200',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(15,'签到狂魔','icon-checkin-king','#409EFF','#ecf5ff','累计签到天数达到30天','checkin_days','30',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(16,'万元户','icon-coin-rich','#409EFF','#ecf5ff','累计收到金币数达到10000','coin_received','10000',1,'1','消费',0,0,0,'2026-07-16 22:23:25'),
(19,'实名认证','','#409EFF','#ecf5ff','通过实名认证','verified','1',1,'1','社交',0,0,0,'2026-07-16 22:35:01'),
(20,'管理员','','#409EFF','#ecf5ff','拥有管理员角色 (条件值=R_ADMIN)','has_role','R_ADMIN',1,'1','管理员',0,0,0,'2026-07-16 22:35:01'),
(21,'超级管理员','','#409EFF','#ecf5ff','拥有超级管理员角色 (条件值=R_SUPER)','has_role','R_SUPER',1,'1','管理员',0,0,0,'2026-07-16 22:37:15'),
(22,'社区版主','','#409EFF','#ecf5ff','拥有版主角色的精英用户 (条件值=R_MODERATOR)','has_role','R_MODERATOR',1,'1','管理员',0,0,0,'2026-07-16 22:37:15'),
(23,'审核员','','#409EFF','#ecf5ff','拥有审核员角色 (条件值=R_REVIEWER)','has_role','R_REVIEWER',1,'1','管理员',0,0,0,'2026-07-16 22:37:15');
/*!40000 ALTER TABLE `custom_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_config`
--

DROP TABLE IF EXISTS `email_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(200) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT 465,
  `secure` tinyint(1) DEFAULT 1,
  `user` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) NOT NULL DEFAULT '',
  `from_name` varchar(100) DEFAULT '',
  `from_address` varchar(200) DEFAULT '',
  `test_address` varchar(200) DEFAULT '',
  `register_verify` tinyint(1) DEFAULT 0,
  `enabled` tinyint(1) DEFAULT 1,
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_config`
--

LOCK TABLES `email_config` WRITE;
/*!40000 ALTER TABLE `email_config` DISABLE KEYS */;
INSERT INTO `email_config` VALUES
(1,'smtp.qq.com',465,1,'3020451981@qq.com','leqrhfulklqtdhdc','ArtDesignPro','3020451981@qq.com','844991059@qq.com',0,1,'2026-07-11 16:04:44');
/*!40000 ALTER TABLE `email_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_push_config`
--

DROP TABLE IF EXISTS `email_push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_push_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `template` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `user_group` varchar(20) DEFAULT 'all',
  `level_ids` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `description` varchar(500) DEFAULT '',
  `target` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_push_config`
--

LOCK TABLES `email_push_config` WRITE;
/*!40000 ALTER TABLE `email_push_config` DISABLE KEYS */;
INSERT INTO `email_push_config` VALUES
(1,'user_register','用户注册','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-13 13:35:10','',''),
(2,'order_create','订单创建','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-13 13:35:10','',''),
(3,'new_submission','链接提交邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','前台有新的链接提交向管理员发送邮件','admin'),
(4,'new_order','新订单邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向管理员发送邮件','admin'),
(5,'withdraw_request','提现邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户申请提现向管理员发送邮件','admin'),
(6,'submission_review','投稿待审核通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户投稿待审核时向管理员发送邮件','admin'),
(7,'post_review','帖子待审核通知邮件(管理员)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户发帖待审核时向管理员发送邮件','admin'),
(8,'post_review_moderator','帖子待审核通知邮件(版主)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户发帖待审核时向版主发送邮件','moderator'),
(9,'identity_verify','身份认证通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户申请身份认证向管理员发送邮件','admin'),
(10,'account_appeal','帐号申诉通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户帐号禁封申诉向管理员发送邮件','admin'),
(11,'report_notify','举报通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','收到举报信息向管理员发送邮件','admin'),
(12,'moderator_apply','版主申请通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户申请版主向管理员和超级版主发送邮件','admin'),
(13,'order_paid_user','新订单邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向用户发送邮件','user'),
(14,'withdraw_result','提现通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户提现申请后向用户发送邮件','user'),
(15,'order_paid_referrer','佣金通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向推荐人发送邮件','user'),
(16,'revenue_split','分成通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后有创作分成时向分成作者发送邮件','user'),
(17,'comment_approved','评论审核邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','评论通过审核后向用户发送邮件','user'),
(18,'comment_reply','评论回复通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','评论有新的回复向用户发送邮件','user'),
(19,'content_approved','内容审核邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','投稿、发帖通过审核后向用户发送邮件','user'),
(20,'phone_changed','手机号修改通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户修改绑定手机号向用户发送邮件','user'),
(21,'identity_result','身份认证通知邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户身份认证申请后向用户发送邮件','user'),
(22,'account_ban_user','帐号禁封通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户帐号禁封、解封向用户发送邮件','user'),
(23,'report_result','举报反馈邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户举报后向用户发送邮件','user'),
(24,'moderator_apply_result','版主申请通知邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]处理用户版主申请后向用户发送邮件','user'),
(25,'moderator_removed','版主移出通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]将用户版主身份移出后向用户发送邮件','user'),
(26,'answer_accepted','回答被采纳','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]回答被采纳后向用户发送邮件','user'),
(27,'private_message','私信通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','收到私信后向收信用户发送邮件','user');
/*!40000 ALTER TABLE `email_push_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `code` varchar(50) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `html_content` text DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
(1,'注册验证','register_verify','注册验证邮件','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">您的注册验证码：{{code}}</div>\n      \n      <div>欢迎您的注册！</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',0,'1','2026-07-10 22:39:54','2026-07-13 12:50:20'),
(2,'密码重置','password_reset','密码重置邮件','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">您的验证码：{{code}}</div>\n      \n      <div>{{content}}</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',1,'1','2026-07-10 22:39:54','2026-07-13 12:53:10'),
(5,'通用邮箱模板','all','','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">验证码：{{code}}</div>\n      \n      <div>{{message}}</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',0,'1','2026-07-13 13:08:08','2026-07-13 13:10:02'),
(6,'链接提交邮件','new_submission','网站链接提交通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(7,'新订单邮件','new_order','订单支付通知管理员','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(8,'提现邮件','withdraw_request','提现申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(9,'投稿待审核通知邮件','submission_review','投稿待审核通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(10,'帖子待审核通知邮件(管理员)','post_review','帖子待审核通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(11,'帖子待审核通知邮件(版主)','post_review_moderator','帖子待审核通知版主','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(12,'身份认证通知邮件','identity_verify','身份认证申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(13,'帐号申诉通知邮件','account_appeal','帐号禁封申诉通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(14,'举报通知邮件','report_notify','举报信息通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(15,'版主申请通知邮件','moderator_apply','版主申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(16,'新订单邮件(用户)','order_paid_user','订单支付成功通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(17,'提现通知邮件','withdraw_result','提现处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(18,'佣金通知邮件','order_paid_referrer','推荐佣金通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(19,'分成通知邮件','revenue_split','创作分成通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(20,'评论审核邮件','comment_approved','评论审核通过通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(21,'评论回复通知邮件','comment_reply','评论回复通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(22,'内容审核邮件','content_approved','内容审核通过通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(23,'手机号修改通知邮件','phone_changed','手机号修改通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(24,'身份认证通知邮件(用户)','identity_result','身份认证处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(25,'帐号禁封通知邮件','account_ban_user','帐号禁封/解封通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(26,'举报反馈邮件','report_result','举报处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(27,'版主申请通知邮件(用户)','moderator_apply_result','版主申请处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(28,'版主移出通知邮件','moderator_removed','版主身份移出通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(29,'回答被采纳','answer_accepted','回答被采纳通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(30,'私信通知邮件','private_message','私信通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(31,'订单创建邮件','order_create','订单创建通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(32,'用户注册邮件','user_register','用户注册欢迎通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(33,'修改邮箱验证码','change_email','修改邮箱验证码','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_verifications_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
INSERT INTO `email_verifications` VALUES
(1,'844991059@qq.com','914984','register',1,'2026-07-12 19:27:30','2026-07-12 19:17:30'),
(2,'844991059@qq.com','267026','register',0,'2026-07-13 13:01:07','2026-07-13 12:51:07'),
(3,'844991059@qq.com','426298','password_reset',0,'2026-07-13 13:06:37','2026-07-13 12:56:37'),
(4,'844991059@qq.com','165745','password_reset',0,'2026-07-13 13:07:56','2026-07-13 12:57:56'),
(5,'844991059@qq.com','391456','password_reset',1,'2026-07-13 13:08:57','2026-07-13 12:58:57'),
(6,'844991059@qq.com','154171','change_email',0,'2026-07-13 13:19:16','2026-07-13 13:09:16');
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_levels`
--

DROP TABLE IF EXISTS `experience_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `exp_required` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#00BFA5',
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_levels`
--

LOCK TABLES `experience_levels` WRITE;
/*!40000 ALTER TABLE `experience_levels` DISABLE KEYS */;
INSERT INTO `experience_levels` VALUES
(1,'Lv.1',1,0,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982350949.png','#00BFA5','#FFFFFF','#508DFF','基础等级','1','2026-07-10 22:42:45'),
(2,'Lv.2',2,100,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982360639.png','#42A5F5','#FFFFFF','#508DFF','解锁评论功能','1','2026-07-10 22:42:45'),
(3,'Lv.3',3,180,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982426213.png','#7C4DFF','#FFFFFF','#508DFF','解锁发帖功能','1','2026-07-10 22:42:45'),
(4,'Lv.4',4,300,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982437138.png','#FFB74D','#FFFFFF','#508DFF','解锁自定义头像','1','2026-07-10 22:42:45'),
(5,'Lv.5',5,500,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982444873.png','#FF6B6B','#FFFFFF','#508DFF','解锁高级搜索','1','2026-07-10 22:42:45'),
(6,'Lv.6',6,800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982453777.png','#FFD700','#FFFFFF','#508DFF','专属标识,优先客服','1','2026-07-10 22:42:45'),
(7,'Lv.7',7,1600,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982462674.png','#FF4081','#FFFFFF','#508DFF','全部权益,年度礼品','1','2026-07-10 22:42:45'),
(8,'LV.8',8,2400,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982470785.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 19:17:12'),
(9,'LV.9',9,3800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982478996.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 19:17:49'),
(10,'LV.10',10,5200,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982490516.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:41:32'),
(11,'LV.11',11,6800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982513242.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:41:54'),
(12,'LV.12',12,12000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982529934.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:42:10'),
(13,'LV.13',13,18000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982541798.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:42:22'),
(14,'LV.14',14,23000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982552450.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:42:33'),
(15,'LV.15',15,28000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982561799.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:42:42'),
(16,'LV.16',16,32000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982572800.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:42:53'),
(17,'LV.17',17,38000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982585818.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:43:06'),
(18,'LV.18',18,50000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982597739.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:43:18'),
(19,'LV.19',19,75000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982608548.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:43:29'),
(20,'LV.20',20,100000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982626576.png','#00BFA5','#FFFFFF','#508DFF','','1','2026-07-13 22:43:47');
/*!40000 ALTER TABLE `experience_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_records`
--

DROP TABLE IF EXISTS `experience_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_experience_records_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_records`
--

LOCK TABLES `experience_records` WRITE;
/*!40000 ALTER TABLE `experience_records` DISABLE KEYS */;
INSERT INTO `experience_records` VALUES
(1,7,'',70,'daily','经验值增加','2026-06-16 22:39:54'),
(2,12,'',14,'post','经验值增加','2026-07-03 22:39:54'),
(3,12,'',37,'comment','经验值增加','2026-07-06 22:39:54'),
(4,10,'',10,'checkin','经验值增加','2026-06-12 22:39:54'),
(5,3,'',100,'daily','经验值增加','2026-06-11 22:39:54'),
(6,9,'',107,'post','经验值增加','2026-06-16 22:39:54'),
(7,4,'',40,'comment','经验值增加','2026-07-05 22:39:54'),
(8,10,'',73,'checkin','经验值增加','2026-06-12 22:39:54'),
(9,7,'',94,'daily','经验值增加','2026-06-19 22:39:54'),
(10,8,'',19,'post','经验值增加','2026-07-02 22:39:54'),
(11,14,'',107,'comment','经验值增加','2026-06-18 22:39:54'),
(12,12,'',43,'checkin','经验值增加','2026-06-22 22:39:54'),
(13,2,'',74,'daily','经验值增加','2026-07-08 22:39:54'),
(14,4,'',87,'post','经验值增加','2026-07-08 22:39:54'),
(15,12,'',51,'comment','经验值增加','2026-06-30 22:39:54'),
(16,5,'',52,'checkin','经验值增加','2026-06-26 22:39:54'),
(17,6,'',97,'daily','经验值增加','2026-07-10 22:39:54'),
(18,4,'',96,'post','经验值增加','2026-06-15 22:39:54'),
(19,3,'',99,'comment','经验值增加','2026-07-07 22:39:54'),
(20,5,'',31,'checkin','经验值增加','2026-07-10 22:39:54'),
(21,19,'alexmorgan',2000,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得2000经验值','2026-07-11 08:41:23'),
(22,10001,'35735712',5000,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 额外获得5000经验值','2026-07-16 00:16:12');
/*!40000 ALTER TABLE `experience_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_group_follows`
--

DROP TABLE IF EXISTS `favorite_group_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_group_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_follower` (`group_id`,`follower_id`),
  KEY `idx_group` (`group_id`),
  KEY `idx_follower` (`follower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_group_follows`
--

LOCK TABLES `favorite_group_follows` WRITE;
/*!40000 ALTER TABLE `favorite_group_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_group_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_policies`
--

DROP TABLE IF EXISTS `file_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `role_code` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `max_file_size_mb` int(11) DEFAULT 10,
  `allowed_types` text DEFAULT '',
  `banned_types` text DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_policies`
--

LOCK TABLES `file_policies` WRITE;
/*!40000 ALTER TABLE `file_policies` DISABLE KEYS */;
INSERT INTO `file_policies` VALUES
(1,'默认策略',0,'','',0,10,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-10 22:39:54'),
(2,'图片策略',0,'','',0,5,'jpg,png,gif,webp','','1','2026-07-10 22:39:54'),
(3,'会员用户其他',0,'','*',0,35,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-12 00:50:07');
/*!40000 ALTER TABLE `file_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_repository`
--

DROP TABLE IF EXISTS `file_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_repository` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `file_type` varchar(100) DEFAULT '',
  `mime_type` varchar(200) DEFAULT '',
  `category` varchar(50) DEFAULT 'other',
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `description` varchar(500) DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_file_repository_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_repository`
--

LOCK TABLES `file_repository` WRITE;
/*!40000 ALTER TABLE `file_repository` DISABLE KEYS */;
INSERT INTO `file_repository` VALUES
(1,9,'','avatar1.png','uploads/avatar1.png',102400,'avatar','image/png','other',0,'',NULL,'2026-07-10 22:39:53'),
(2,6,'','design.psd','uploads/design.psd',2048000,'design','application/psd','other',0,'',NULL,'2026-07-10 22:39:53'),
(3,13,'','report.pdf','uploads/report.pdf',512000,'document','application/pdf','other',0,'',NULL,'2026-07-10 22:39:53'),
(4,12,'','video.mp4','uploads/video.mp4',10485760,'video','video/mp4','other',0,'',NULL,'2026-07-10 22:39:53'),
(5,9,'','config.json','uploads/config.json',2048,'data','application/json','other',0,'',NULL,'2026-07-10 22:39:53'),
(6,3,'','image1.jpg','uploads/image1.jpg',307200,'image','image/jpeg','other',0,'',NULL,'2026-07-10 22:39:53'),
(7,13,'','icon.svg','uploads/icon.svg',8192,'icon','image/svg+xml','other',0,'',NULL,'2026-07-10 22:39:53'),
(11,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816158227-389590747.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:30:00'),
(12,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:31:33'),
(13,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816652499-733720586.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:37:33'),
(14,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816659877-185207292.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:37:40'),
(15,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816771159-579246254.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:32'),
(16,0,'','MTç®¡çå¨_2.26.6.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816711324-481531705.apk',31414066,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:37'),
(17,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816784424-968471270.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:45'),
(18,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816799301-792055094.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:40:41'),
(19,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816970054-799912081.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:42:51'),
(20,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816976685-749847013.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:42:57'),
(21,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816985168-866030178.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:43:06'),
(22,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817033491-439544914.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:44:35'),
(23,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817269817-937137091.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:32'),
(24,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817314376-129449829.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:35'),
(25,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817319693-373748131.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:40'),
(26,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817326869-670938906.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:48'),
(28,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817455681-789179466.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:51:38'),
(29,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817623730-286001040.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:53:45'),
(30,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817660872-274220246.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:55:03'),
(31,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817740986-155422684.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:56:23'),
(32,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818420129-251029883.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:07:01'),
(34,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818537796-569073154.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:08:59'),
(35,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818543195-841509947.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:09:04'),
(36,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818558713-835884504.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:09:20'),
(37,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818705199-567193380.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:11:46'),
(39,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818935431-807162032.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:16:18'),
(42,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820609464-226654906.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:43:30'),
(43,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820663960-40996847.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:44:24'),
(44,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821050883-644610594.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:51:33'),
(45,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821067093-396406745.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:51:49'),
(46,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821246989-906727894.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:54:49'),
(49,1,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/zip/1783825047961-519417035.zip',4096,'.zip','application/octet-stream','general',0,'',NULL,'2026-07-12 02:57:28'),
(51,2,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/2/zip/1783825048216-30936901.zip',4096,'.zip','application/octet-stream','general',0,'',NULL,'2026-07-12 02:57:28'),
(52,1,'','test_pic.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825238553-78505961.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:00:38'),
(53,1,'','a.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/img/1783825451126-852761551.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:04:11'),
(54,1,'','u.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825518358-740133764.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:05:18'),
(57,0,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826122044-556763102.jpg',168623,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:22'),
(58,0,'','4502.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123131-672728729.jpg',536774,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:23'),
(59,0,'','4498.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123510-169510965.jpg',112423,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:23'),
(60,0,'','4500.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826124195-863883180.jpg',1008134,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:25'),
(61,0,'','u2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826182866-214372467.png',2048,'.png','image/png','avatar',0,'',NULL,'2026-07-12 03:16:23'),
(66,19,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783858197612_3872.jpg',168623,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:09:58'),
(67,19,'','4498.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783858258905_8390.jpg',112423,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:10:59'),
(68,19,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg',168623,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:27:42'),
(69,19,'','4497.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg',394290,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:44:57'),
(90,19,'','exp_icon_1783971471182.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971471182.png',1860,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:37:51'),
(91,19,'','exp_icon_1783971498625.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971498625.png',2099,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:18'),
(92,19,'','exp_icon_1783971508679.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971508679.png',2104,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:28'),
(93,19,'','exp_icon_1783971532684.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971532684.png',2178,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:52'),
(94,19,'','exp_icon_1783971558823.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971558823.png',2098,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:19'),
(95,19,'','exp_icon_1783971588947.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971588947.png',2086,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:49'),
(96,19,'','exp_icon_1783971599337.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971599337.png',2040,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:59'),
(97,19,'','exp_icon_1783971609738.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971609738.png',1998,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:40:09'),
(98,19,'','exp_icon_1783971622186.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971622186.png',2078,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:40:22'),
(102,19,'','mb_icon_1783978168089.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1783978168089.gif',1584108,'gif','image/gif','membership_icon',0,'membership','membership_icon','2026-07-13 21:29:28'),
(103,19,'','aw_1783978337263.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg',166541,'jpg','image/jpeg','avatar',19,'user','用户#19的用户头像','2026-07-13 21:32:17'),
(104,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783979565742-697628372.png',489216,'png','image/png','general',0,'','通用文件','2026-07-13 21:52:46'),
(105,19,'','4539.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783980997613-49864119.png',532360,'png','image/png','general',0,'','通用文件','2026-07-13 22:16:38'),
(106,19,'','4539.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783981009908-814127258.png',532360,'png','image/png','general',0,'','通用文件','2026-07-13 22:16:50'),
(107,19,'','exp_icon_1783981510656.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783981510656.png',1610,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:25:10'),
(108,19,'','exp_icon_1783982350949.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982350949.png',19043,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:39:11'),
(109,19,'','exp_icon_1783982360639.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982360639.png',20997,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:39:20'),
(110,19,'','exp_icon_1783982426213.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982426213.png',20990,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:26'),
(111,19,'','exp_icon_1783982437138.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982437138.png',19351,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:37'),
(112,19,'','exp_icon_1783982444873.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982444873.png',19555,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:44'),
(113,19,'','exp_icon_1783982453777.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982453777.png',19701,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:53'),
(114,19,'','exp_icon_1783982462674.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982462674.png',19652,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:02'),
(115,19,'','exp_icon_1783982470785.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982470785.png',22759,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:10'),
(116,19,'','exp_icon_1783982478996.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982478996.png',22559,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:19'),
(117,19,'','exp_icon_1783982490516.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982490516.png',22042,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:30'),
(118,19,'','exp_icon_1783982513242.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982513242.png',23850,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:53'),
(119,19,'','exp_icon_1783982529934.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982529934.png',23222,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:10'),
(120,19,'','exp_icon_1783982541798.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982541798.png',24614,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:21'),
(121,19,'','exp_icon_1783982552450.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982552450.png',24721,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:32'),
(122,19,'','exp_icon_1783982561799.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982561799.png',24211,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:41'),
(123,19,'','exp_icon_1783982572800.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982572800.png',24949,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:52'),
(124,19,'','exp_icon_1783982585818.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982585818.png',25533,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:05'),
(125,19,'','exp_icon_1783982597739.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982597739.png',25493,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:17'),
(126,19,'','exp_icon_1783982608548.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982608548.png',27454,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:28'),
(127,19,'','exp_icon_1783982626576.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982626576.png',25053,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:46'),
(128,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783984434038-674480173.png',489216,'png','image/png','general',0,'','通用文件','2026-07-13 23:13:54'),
(129,19,'','4564.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783985386117-824716520.png',400574,'png','image/png','general',0,'','通用文件','2026-07-13 23:29:46'),
(130,19,'','4564.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783985399134-484017465.png',400574,'png','image/png','general',0,'','通用文件','2026-07-13 23:29:59'),
(131,19,'','4565.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987059150-560229395.png',1088831,'png','image/png','general',0,'','通用文件','2026-07-13 23:57:41'),
(132,19,'','4567.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987132246-181511316.png',1088831,'png','image/png','general',0,'','通用文件','2026-07-13 23:58:53'),
(133,19,'','4569.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987284290-565362119.png',519518,'png','image/png','general',0,'','通用文件','2026-07-14 00:01:24'),
(134,19,'','4569.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987337398-396129353.png',519518,'png','image/png','general',0,'','通用文件','2026-07-14 00:02:17'),
(135,19,'','4570.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987369006-697144065.png',457796,'png','image/png','general',0,'','通用文件','2026-07-14 00:02:49'),
(136,0,'','test-img.png','/uploads/community_1784024726849_ske8kx.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:25:27'),
(137,0,'','test-img2.png','/uploads/community_1784025089956_zkomd1.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:31:30'),
(138,0,'','test-img3.png','/uploads/community_1784025131095_q5whgp.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:32:11'),
(139,0,'','test-img4.png','/uploads/community_1784025268395_9frmn0.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:34:28'),
(140,0,'','test-img5.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025301063_kg5n85.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:35:01'),
(141,19,'','test-alex.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784025358286_ratwk9.png',2048,'png','image/png','community_image',0,'','community_image','2026-07-14 10:35:58'),
(142,0,'','test-del.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025595176_v9sryq.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:39:55'),
(143,0,'','test-del2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025619899_6i9nhv.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:40:20'),
(144,0,'','test-quota.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025959936_tthkw0.png',5120,'png','image/png','community_image',0,'','community_image','2026-07-14 10:46:00'),
(146,0,'','migrate_16_1784026548678_mld4.jpeg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784026550127_as2zmr.jpeg',795023,'jpeg','image/jpeg','community_image',0,'','community_image','2026-07-14 10:55:50'),
(147,0,'','migrate_16_1784026550450_28pm.jpeg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784026550470_q9nikx.jpeg',677674,'jpeg','image/jpeg','community_image',0,'','community_image','2026-07-14 10:55:50'),
(149,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784031764362_w7b1xn.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 12:22:45'),
(150,19,'','4522.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784031772804_48egzb.jpg',677674,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 12:22:53'),
(151,19,'','4190.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/frame-1784063200439-382993529.gif',942747,'gif','image/gif','avatar_frame',0,'','头像框图片','2026-07-14 21:06:42'),
(152,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784070665897_pvqsjf.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 23:11:07'),
(153,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784070676176_iezhy3.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 23:11:16'),
(154,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076703399_djixc1.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:51:44'),
(155,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076711453_zm3whr.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:51:51'),
(156,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076984621_vm5uze.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:56:25'),
(157,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077097095_p240s2.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:17'),
(158,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077131092_b8uc6x.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:51'),
(159,0,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077132069_jg82mp.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:52'),
(160,0,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077186617_m2j829.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:59:47'),
(161,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077188028_ls5yjo.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:59:48'),
(162,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077223022_g2qynx.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 01:00:23'),
(163,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077259732_4cvboz.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 01:01:00'),
(164,0,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784086099787_qlcjmt.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 03:28:24'),
(165,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784086186333_8p850z.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 03:29:46'),
(166,19,'','4541.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784097351442_kssori.jpg',40178,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 06:35:51'),
(167,19,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784097744372_ojsxzj.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 06:42:29'),
(168,0,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784098071767_ufnouc.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 06:47:56'),
(169,19,'','4501.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784098128256_hvv3gt.png',2342912,'png','image/png','community_image',0,'','community_image','2026-07-15 06:48:52'),
(170,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111253765_jce1r2.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:34'),
(171,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111255056_20o4up.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:35'),
(172,19,'','4511.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111255931_3tl31a.jpg',166541,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:36'),
(173,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784112470446_3i37oc.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:47:51'),
(174,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784112500785_u85ie0.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:48:21'),
(175,19,'','4541.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113044692_qw3se8.jpg',40178,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:24'),
(176,19,'','4530.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113058114_902pxy.gif',1584108,'gif','image/gif','community_image',0,'','community_image','2026-07-15 10:57:40'),
(177,19,'','4502.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113061397_y68d2p.jpg',536774,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:41'),
(178,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113071582_cgnhsi.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:51'),
(179,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114251731_ebb403.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:32'),
(180,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114260961_nil3ss.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:41'),
(181,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114262066_dd5886.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:42'),
(182,19,'','4566.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114292133_hvrs4h.png',488392,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:12'),
(183,19,'','4567.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114293498_do8udo.png',1088831,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:14'),
(184,19,'','4568.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114296300_c32nth.png',1759232,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:18'),
(185,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114298469_l9bat4.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:19'),
(186,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114299493_gwjc28.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:19'),
(187,19,'','4510.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114311026_aa75uy.jpg',145172,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:31'),
(188,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114325363_6e1e9y.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:45'),
(189,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114326424_9d12oc.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:46'),
(190,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114346637_q3czno.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:19:07'),
(191,0,'','favicon.ico','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784114377190_9uqjod.ico',4286,'ico','application/octet-stream','community_image',0,'','community_image','2026-07-15 11:19:37'),
(192,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114704166_vgx4uh.png',489216,'png','image/png','community_image',0,'','community_image','2026-07-15 11:25:04'),
(193,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114711414_skogwy.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:25:11'),
(194,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784115427495_t7n1zf.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:37:08'),
(195,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784115428991_wkn3gl.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:37:09'),
(196,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116261658_8ksfkz.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:51:02'),
(197,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116263039_we3v6h.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:51:03'),
(198,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116619006_30qob8.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:56:59'),
(199,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116628325_ktxh9v.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:57:08'),
(200,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116628981_c17j00.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:57:09'),
(201,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784117092234_otmvjg.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 12:04:52'),
(202,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784117093715_b2ss9r.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 12:04:54'),
(203,19,'','reply_image.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1784131092996-429930264.jpg',624912,'jpg','image/jpeg','general',0,'','通用文件','2026-07-15 15:58:13'),
(204,19,'','reply_image.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1784131096207-908380383.jpg',624912,'jpg','image/jpeg','general',0,'','通用文件','2026-07-15 15:58:16');
/*!40000 ALTER TABLE `file_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_configs`
--

DROP TABLE IF EXISTS `game_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_type` varchar(30) NOT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`config_data`)),
  `enabled` tinyint(4) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_type` (`game_type`),
  KEY `idx_game_configs_type` (`game_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_configs`
--

LOCK TABLES `game_configs` WRITE;
/*!40000 ALTER TABLE `game_configs` DISABLE KEYS */;
INSERT INTO `game_configs` VALUES
(1,'card_guess','{\"costPerFlip\":10,\"pityCount\":10,\"winMultiplier\":2,\"cards\":[{\"name\":\"A\",\"label\":\"奖\",\"isWin\":true,\"probability\":30},{\"name\":\"B\",\"label\":\"空\",\"isWin\":false,\"probability\":35},{\"name\":\"C\",\"label\":\"空\",\"isWin\":false,\"probability\":35}],\"memberDiscounts\":[]}',1,'2026-07-11 09:42:54','2026-07-11 11:23:53'),
(2,'dice','{\"costPerBet\":10,\"maxNumber\":6,\"threshold\":4,\"winMultiplier\":2,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:31','2026-07-11 11:23:53'),
(3,'rps','{\"costPerPlay\":10,\"winMultiplier\":2,\"drawRefund\":true,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:43','2026-07-11 11:23:54'),
(4,'lottery','{\"costPerDraw\":10,\"costPerDraw10\":100,\"pityCount\":0,\"pityGridIndex\":0,\"grids\":[{\"index\":0,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":1,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":2,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":3,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":4,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":5,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":6,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":7,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":8,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11}],\"memberDiscounts\":[]}',1,'2026-07-11 09:45:49','2026-07-11 11:23:53');
/*!40000 ALTER TABLE `game_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_records`
--

DROP TABLE IF EXISTS `game_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `game_type` varchar(30) NOT NULL,
  `result` varchar(20) NOT NULL,
  `points_spent` int(11) DEFAULT 0,
  `points_won` int(11) DEFAULT 0,
  `detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detail`)),
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_game_records_user` (`user_id`),
  KEY `idx_game_records_type` (`game_type`),
  KEY `idx_game_records_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_records`
--

LOCK TABLES `game_records` WRITE;
/*!40000 ALTER TABLE `game_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_conversations`
--

DROP TABLE IF EXISTS `hidden_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hidden_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`partner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_conversations`
--

LOCK TABLES `hidden_conversations` WRITE;
/*!40000 ALTER TABLE `hidden_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite_codes`
--

DROP TABLE IF EXISTS `invite_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invite_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `used_by` int(11) DEFAULT 0,
  `used_by_name` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 1,
  `use_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT 'one_time',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` int(11) DEFAULT 0,
  `reward_duration` int(11) DEFAULT 0,
  `reward_duration_unit` varchar(10) DEFAULT 'day',
  `reward_target_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_invite_codes_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite_codes`
--

LOCK TABLES `invite_codes` WRITE;
/*!40000 ALTER TABLE `invite_codes` DISABLE KEYS */;
INSERT INTO `invite_codes` VALUES
(1,'INV-3MYOYW',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(2,'INV-TKFVLJ',1,'',0,'',10,0,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(3,'INV-DZQ79K',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(4,'INV-UAZKH9',1,'',0,'',10,1,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(5,'INV-P3V7UN',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(6,'INV-5LP1N0',1,'',0,'',10,4,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(7,'INV-NL5F3Y',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(8,'INV-GL49GY',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(9,'INV-XBL1IK',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(10,'INV-HZYLX9',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0);
/*!40000 ALTER TABLE `invite_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logistics_config`
--

DROP TABLE IF EXISTS `logistics_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logistics_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) NOT NULL DEFAULT 'kdniao',
  `e_business_id` varchar(100) NOT NULL DEFAULT '',
  `api_key_encrypted` varchar(500) NOT NULL DEFAULT '',
  `customer_id` varchar(100) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `callback_url` varchar(500) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logistics_config_provider` (`provider`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logistics_config`
--

LOCK TABLES `logistics_config` WRITE;
/*!40000 ALTER TABLE `logistics_config` DISABLE KEYS */;
INSERT INTO `logistics_config` VALUES
(2,'kdniao','EB123456','5d714b45ae1b17f1ddb47925f02f4a5c02012287852e549bca04f510b586531a','',1,'','2026-07-17 15:30:27','2026-07-17 15:30:27');
/*!40000 ALTER TABLE `logistics_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_after_sales`
--

DROP TABLE IF EXISTS `mall_after_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_after_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'refund',
  `reason` text DEFAULT '',
  `description` text DEFAULT '',
  `images` text DEFAULT '[]',
  `amount` double DEFAULT 0,
  `status` varchar(20) DEFAULT 'pending',
  `seller_reply` text DEFAULT '',
  `seller_reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_after_sales_order` (`order_id`),
  KEY `idx_mall_after_sales_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_after_sales`
--

LOCK TABLES `mall_after_sales` WRITE;
/*!40000 ALTER TABLE `mall_after_sales` DISABLE KEYS */;
INSERT INTO `mall_after_sales` VALUES
(1,1,0,1,'return','test','test','[]',0,'pending','',NULL,'2026-07-16 19:28:14','2026-07-16 19:28:14');
/*!40000 ALTER TABLE `mall_after_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_cart_items`
--

DROP TABLE IF EXISTS `mall_cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`,`option_id`),
  KEY `idx_mall_cart_items_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_cart_items`
--

LOCK TABLES `mall_cart_items` WRITE;
/*!40000 ALTER TABLE `mall_cart_items` DISABLE KEYS */;
INSERT INTO `mall_cart_items` VALUES
(2,19,8,1,2,'2026-07-17 15:14:26');
/*!40000 ALTER TABLE `mall_cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_categories`
--

DROP TABLE IF EXISTS `mall_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `icon` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_categories`
--

LOCK TABLES `mall_categories` WRITE;
/*!40000 ALTER TABLE `mall_categories` DISABLE KEYS */;
INSERT INTO `mall_categories` VALUES
(1,0,'education','',1,'1','2026-07-10 22:39:53'),
(2,0,'design','',2,'1','2026-07-10 22:39:53'),
(3,0,'dev','',3,'1','2026-07-10 22:39:53'),
(4,0,'service','',4,'1','2026-07-10 22:39:53'),
(5,0,'电子产品','',5,'1','2026-07-17 15:50:59');
/*!40000 ALTER TABLE `mall_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_favorites`
--

DROP TABLE IF EXISTS `mall_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_product` (`user_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_favorites`
--

LOCK TABLES `mall_favorites` WRITE;
/*!40000 ALTER TABLE `mall_favorites` DISABLE KEYS */;
INSERT INTO `mall_favorites` VALUES
(1,1,1,'2026-07-16 19:47:09'),
(3,19,8,'2026-07-16 21:58:19'),
(4,3,1,'2026-07-17 15:03:57');
/*!40000 ALTER TABLE `mall_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_items`
--

DROP TABLE IF EXISTS `mall_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `product_name` varchar(200) DEFAULT '',
  `option_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `image` varchar(500) DEFAULT '',
  `virtual_content` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_items_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_items`
--

LOCK TABLES `mall_order_items` WRITE;
/*!40000 ALTER TABLE `mall_order_items` DISABLE KEYS */;
INSERT INTO `mall_order_items` VALUES
(1,16,8,1,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(2,17,8,1,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(3,18,1,0,'AI绘画大师课程','',199,1,'',''),
(4,19,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(5,20,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(6,21,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(7,22,9,3,'手机 (曜石黑)','曜石黑',2999,1,'',''),
(8,23,9,3,'手机','曜石黑',2999,1,'',''),
(16,31,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(17,32,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(18,33,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(19,34,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(20,35,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(21,36,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额');
/*!40000 ALTER TABLE `mall_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_logistics`
--

DROP TABLE IF EXISTS `mall_order_logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_logistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `company` varchar(100) DEFAULT '',
  `tracking_no` varchar(100) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `details` text DEFAULT '[]',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_logistics_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_logistics`
--

LOCK TABLES `mall_order_logistics` WRITE;
/*!40000 ALTER TABLE `mall_order_logistics` DISABLE KEYS */;
INSERT INTO `mall_order_logistics` VALUES
(1,22,'顺丰速运','SF1234567890','picked','【深圳市】顺丰速运 南山科技园营业点已揽收','2026-07-18 08:30:00'),
(2,22,'顺丰速运','SF1234567890','transit','【深圳市】快件已到达 深圳宝安中转场','2026-07-18 12:00:00'),
(3,22,'顺丰速运','SF1234567890','transit','【广州市】快件已到达 广州白云中转场','2026-07-18 18:30:00'),
(4,22,'顺丰速运','SF1234567890','delivering','【广州市】快件由 天河区营业点 派送中，快递员：张师傅 13800138001','2026-07-19 09:15:00'),
(5,22,'顺丰速运','SF1234567890','delivered','【广州市】已签收，签收人：本人签收','2026-07-19 11:30:00'),
(6,23,'中通快递','ZTO87654321','shipped','[]','2026-07-17 16:36:31'),
(7,23,'中通快递','ZTO87654321','picked','【深圳市】中通快递 南山营业厅已揽收','2026-07-20 09:00:00'),
(8,23,'中通快递','ZTO87654321','transit','【深圳市】快件到达 深圳分拨中心','2026-07-20 11:30:00'),
(9,23,'中通快递','ZTO87654321','delivering','【深圳市】快件由 南山区网点 派送中，快递员：李师傅 13900139000','2026-07-20 14:00:00');
/*!40000 ALTER TABLE `mall_order_logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_orders`
--

DROP TABLE IF EXISTS `mall_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `total_amount` double DEFAULT 0,
  `discount_amount` double DEFAULT 0,
  `freight` double DEFAULT 0,
  `payment_method` varchar(20) DEFAULT '',
  `payment_time` datetime DEFAULT NULL,
  `receiver_name` varchar(100) DEFAULT '',
  `receiver_phone` varchar(20) DEFAULT '',
  `receiver_address` varchar(500) DEFAULT '',
  `logistics_company` varchar(100) DEFAULT '',
  `logistics_no` varchar(100) DEFAULT '',
  `user_custom_fields` text DEFAULT '{}',
  `remark` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_mall_orders_status` (`status`),
  KEY `idx_mall_orders_user` (`user_id`),
  KEY `idx_mall_orders_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_orders`
--

LOCK TABLES `mall_orders` WRITE;
/*!40000 ALTER TABLE `mall_orders` DISABLE KEYS */;
INSERT INTO `mall_orders` VALUES
(1,'MAL17837231930',2,'paid',417,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(2,'MAL17837231931',11,'paid',465,0,0,'alipay',NULL,'','','','','','{}','','2026-07-08 22:39:53','2026-07-10 22:39:53'),
(3,'MAL17837231932',10,'paid',169,0,0,'wechat',NULL,'','','','','','{}','','2026-06-21 22:39:53','2026-07-10 22:39:53'),
(4,'MAL17837231933',2,'shipped',141,0,0,'alipay',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(5,'MAL17837231934',9,'completed',194,0,0,'wechat',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(6,'MAL17837231935',6,'cancelled',110,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(7,'MAL17837231936',5,'paid',175,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(8,'MAL17837231937',2,'paid',429,0,0,'alipay',NULL,'','','','','','{}','','2026-06-14 22:39:53','2026-07-10 22:39:53'),
(9,'MAL17837231938',14,'paid',440,0,0,'wechat',NULL,'','','','','','{}','','2026-06-25 22:39:53','2026-07-10 22:39:53'),
(10,'MAL17837231939',11,'shipped',329,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(11,'MAL178372319310',13,'completed',333,0,0,'wechat',NULL,'','','','','','{}','','2026-07-07 22:39:53','2026-07-10 22:39:53'),
(12,'MAL178372319311',2,'cancelled',396,0,0,'alipay',NULL,'','','','','','{}','','2026-07-01 22:39:53','2026-07-10 22:39:53'),
(13,'MAL178372319312',15,'paid',23,0,0,'wechat',NULL,'','','','','','{}','','2026-06-13 22:39:53','2026-07-10 22:39:53'),
(14,'MAL178372319313',11,'paid',496,0,0,'alipay',NULL,'','','','','','{}','','2026-06-12 22:39:53','2026-07-10 22:39:53'),
(15,'MAL178372319314',7,'paid',375,0,0,'wechat',NULL,'','','','','','{}','','2026-06-28 22:39:53','2026-07-10 22:39:53'),
(16,'260716034221QGNCVX',19,'paid',10,1,0,'balance','2026-07-16 19:42:21','','','','','','{}','','2026-07-16 19:42:21','2026-07-16 19:42:21'),
(17,'2607160342282DOSP7',19,'paid',10,0.8,0,'balance','2026-07-16 19:42:28','','','','','','{}','','2026-07-16 19:42:28','2026-07-16 19:42:28'),
(18,'260717230559J8E8H0',3,'paid',199,0,0,'balance','2026-07-17 15:05:59','','','','','','{}','','2026-07-17 15:05:59','2026-07-17 15:05:59'),
(19,'260717233747CR6KVK',19,'paid',980,0,0,'points','2026-07-17 15:37:47','','','','','','{}','','2026-07-17 15:37:47','2026-07-17 15:37:47'),
(20,'2607172339562YJQI0',19,'paid',9.8,0,0,'balance','2026-07-17 15:39:56','','','','','','{}','','2026-07-17 15:39:56','2026-07-17 15:39:56'),
(21,'260717234124R4L57T',19,'paid',9.8,0,0,'balance','2026-07-17 15:41:24','','','','','','{}','','2026-07-17 15:41:24','2026-07-17 15:41:24'),
(22,'260717235258KLLS3D',19,'shipped',2999,0,0,'balance','2026-07-17 15:52:58','Alex Morgan','13800138000','广东省深圳市南山区科技园路1号创新大厦1208','顺丰速运','SF1234567890','{}','请放快递柜','2026-07-17 15:52:58','2026-07-17 15:53:36'),
(23,'260717003531G4MCIF',19,'shipped',2939.02,0,0,'balance','2026-07-17 16:35:31','Alex Morgan','13800138000','广东省深圳市南山区科技园路1号创新大厦1208','中通快递','ZTO87654321','{}','','2026-07-17 16:35:31','2026-07-17 16:38:19'),
(31,'2607170239281O5ABD',10011,'paid',9.8,0,0,'balance','2026-07-17 18:39:28','','','','','','{}','','2026-07-17 18:39:28','2026-07-17 18:39:28'),
(32,'2607170239281ZDA42',10011,'paid',980,0,0,'points','2026-07-17 18:39:28','','','','','','{}','','2026-07-17 18:39:28','2026-07-17 18:39:28'),
(33,'260717023950U8ZRAT',10011,'paid',980,0,0,'points','2026-07-17 18:39:50','','','','','','{}','','2026-07-17 18:39:50','2026-07-17 18:39:50'),
(34,'260717024255BC1QWU',10011,'paid',980,0,0,'points','2026-07-17 18:42:55','','','','','','{}','','2026-07-17 18:42:55','2026-07-17 18:42:55'),
(35,'2607170247267BC3O2',10011,'paid',980,0,0,'points','2026-07-17 18:47:26','','','','','','{}','','2026-07-17 18:47:26','2026-07-17 18:47:26'),
(36,'260717024759FQENHY',10011,'paid',980,0,0,'points','2026-07-17 18:47:59','','','','','','{}','','2026-07-17 18:47:59','2026-07-17 18:47:59');
/*!40000 ALTER TABLE `mall_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_images`
--

DROP TABLE IF EXISTS `mall_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_images_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_images`
--

LOCK TABLES `mall_product_images` WRITE;
/*!40000 ALTER TABLE `mall_product_images` DISABLE KEYS */;
INSERT INTO `mall_product_images` VALUES
(1,9,'https://via.placeholder.com/800x800/333/fff?text=Phone',1);
/*!40000 ALTER TABLE `mall_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_options`
--

DROP TABLE IF EXISTS `mall_product_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `spec_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `points_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `image` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `card_config` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_options_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_options`
--

LOCK TABLES `mall_product_options` WRITE;
/*!40000 ALTER TABLE `mall_product_options` DISABLE KEYS */;
INSERT INTO `mall_product_options` VALUES
(2,8,'10元','10元',10,0,1000,90,'',0,'{\"enabled\":true,\"type\":\"auto_recharge\",\"cardType\":\"balance\",\"targetId\":0,\"targetName\":\"\",\"value\":10,\"durationUnit\":\"day\",\"extraPoints\":0,\"extraBalance\":0,\"extraExperience\":0,\"rewardType\":\"membership\",\"rewardValue\":30,\"rewardDurationUnit\":\"day\",\"inviteCodeCount\":1,\"maxUses\":1,\"customCards\":[]}'),
(3,9,'曜石黑','颜色',2999,0,0,48,'',1,'{}'),
(4,9,'星云蓝','颜色',2999,0,0,30,'',2,'{}'),
(5,9,'樱花粉','颜色',3099,0,0,20,'',3,'{}');
/*!40000 ALTER TABLE `mall_product_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_products`
--

DROP TABLE IF EXISTS `mall_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT 0,
  `name` varchar(200) NOT NULL,
  `subtitle` varchar(200) DEFAULT '',
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `cover_video` varchar(500) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'balance',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `product_type` varchar(20) DEFAULT 'virtual_auto',
  `virtual_content` text DEFAULT '',
  `status` varchar(20) DEFAULT 'draft',
  `sales_count` int(11) DEFAULT 0,
  `is_recommended` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `freight` double DEFAULT 0,
  `services` text DEFAULT '[]',
  `purchase_limit_config` text DEFAULT '[]',
  `commission_config` text DEFAULT '[]',
  `custom_fields` text DEFAULT '[]',
  `after_sales_config` text DEFAULT '{}',
  `tags` text DEFAULT '[]',
  `product_params` text DEFAULT '[]',
  `payment_methods` text DEFAULT '["balance"]',
  `sale_end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `product_subtype` varchar(50) DEFAULT '',
  `preview_images` text DEFAULT NULL,
  `source_file_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mall_products_category` (`category_id`),
  KEY `idx_mall_products_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_products`
--

LOCK TABLES `mall_products` WRITE;
/*!40000 ALTER TABLE `mall_products` DISABLE KEYS */;
INSERT INTO `mall_products` VALUES
(1,1,'AI绘画大师课程','高级','','','','balance',199,299,99,'virtual_auto','','1',69,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(2,1,'Vue3实战视频教程','中级','','','','balance',79,99,0,'virtual_auto','','1',74,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(3,2,'设计素材大礼包','基础','','','','balance',39,49,0,'virtual_auto','','1',50,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(4,4,'代码审查服务','高级','','','','balance',149,199,0,'virtual_auto','','1',30,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(5,2,'UI Kit Pro','中级','','','','balance',99,129,0,'virtual_auto','','1',87,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(6,2,'图标合集 5000+','基础','','','','balance',19,29,0,'virtual_auto','','1',75,0,0,0,'[]','[]','[]','[]','{}','[\"新品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(7,3,'API接口开放平台','高级','','','','balance',799,999,0,'virtual_auto','','1',42,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL),
(8,3,'移动端组件库','中级','','','','balance',149,199,0,'virtual_auto','','published',65,0,0,0,'[]','[]','[]','[]','{\"enableRefund\":false,\"enableReturn\":false,\"enablePrice\":false,\"validDays\":7}','[\"推荐\"]','[]','[\"balance\",\"points\"]',NULL,'2026-07-10 22:39:53','2026-07-17 15:36:40',0,'','',NULL,NULL),
(9,5,'手机','旗舰款','','','','balance',2999,3599,92,'physical','','published',9,0,0,0,'[\"7天无理由\",\"官方正品\",\"全国联保\"]','[]','[]','[]','{\"enableRefund\":true,\"enableReturn\":true,\"enablePrice\":true,\"validDays\":15}','[]','[]','[\"balance\"]',NULL,'2026-07-17 15:50:59','2026-07-17 15:52:12',10004,'admin','',NULL,NULL);
/*!40000 ALTER TABLE `mall_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_gifts`
--

DROP TABLE IF EXISTS `mall_promotion_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `gift_type` varchar(20) DEFAULT 'points',
  `gift_value` double DEFAULT 0,
  `gift_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '{}' CHECK (json_valid(`gift_detail`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_gifts`
--

LOCK TABLES `mall_promotion_gifts` WRITE;
/*!40000 ALTER TABLE `mall_promotion_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_products`
--

DROP TABLE IF EXISTS `mall_promotion_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_id` (`promotion_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_products`
--

LOCK TABLES `mall_promotion_products` WRITE;
/*!40000 ALTER TABLE `mall_promotion_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotions`
--

DROP TABLE IF EXISTS `mall_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) DEFAULT 'discount',
  `discount_value` double DEFAULT 0,
  `min_amount` double DEFAULT 0,
  `user_types` text DEFAULT '[]',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotions`
--

LOCK TABLES `mall_promotions` WRITE;
/*!40000 ALTER TABLE `mall_promotions` DISABLE KEYS */;
INSERT INTO `mall_promotions` VALUES
(1,'666','discount',2,10,'[]','2026-07-12 00:42:00','2026-08-12 00:42:00','1','2026-07-11 16:42:26');
/*!40000 ALTER TABLE `mall_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_review_likes`
--

DROP TABLE IF EXISTS `mall_review_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_review_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `review_id` (`review_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_review_likes`
--

LOCK TABLES `mall_review_likes` WRITE;
/*!40000 ALTER TABLE `mall_review_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_review_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_reviews`
--

DROP TABLE IF EXISTS `mall_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT 5,
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `reply` text DEFAULT '',
  `reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `dim_product_rating` decimal(2,1) DEFAULT 0.0,
  `dim_service_rating` decimal(2,1) DEFAULT 0.0,
  `dim_logistics_rating` decimal(2,1) DEFAULT 0.0,
  `rating_desc` tinyint(4) DEFAULT 5,
  `rating_logistics` tinyint(4) DEFAULT 5,
  `rating_value` tinyint(4) DEFAULT 5,
  `like_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_reviews_product` (`product_id`),
  KEY `idx_mall_reviews_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_reviews`
--

LOCK TABLES `mall_reviews` WRITE;
/*!40000 ALTER TABLE `mall_reviews` DISABLE KEYS */;
INSERT INTO `mall_reviews` VALUES
(1,6,4,1,5,'质量不错，第1次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,1),
(2,2,8,2,4,'质量不错，第2次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(3,8,8,3,4,'质量不错，第3次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(4,7,10,4,5,'质量不错，第4次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(5,4,2,5,5,'质量不错，第5次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(6,5,12,6,5,'质量不错，第6次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(7,7,6,7,5,'质量不错，第7次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(8,6,3,8,5,'质量不错，第8次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(9,2,8,9,5,'质量不错，第9次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(10,2,5,10,5,'质量不错，第10次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0);
/*!40000 ALTER TABLE `mall_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_levels`
--

DROP TABLE IF EXISTS `membership_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `tier` int(11) DEFAULT 1,
  `parent_level_id` int(11) DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `points_required` int(11) DEFAULT 0,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `points_multiplier` decimal(3,1) DEFAULT 1.0,
  `points_discount_rate` decimal(3,1) DEFAULT 1.0,
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#909399',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `data_limit_mb` int(11) DEFAULT 0,
  `file_limit_mb` int(11) DEFAULT 0,
  `file_policy_ids` text DEFAULT NULL,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `perks` text DEFAULT NULL,
  `title_id` int(11) DEFAULT 0,
  `frame_id` int(11) DEFAULT 0,
  `daily_gift_enabled` tinyint(1) DEFAULT 0,
  `daily_gift_interval_days` int(11) DEFAULT 1,
  `daily_gift_points` int(11) DEFAULT 0,
  `daily_gift_balance` decimal(10,2) DEFAULT 0.00,
  `daily_gift_experience` int(11) DEFAULT 0,
  `daily_gift_coupon_ids` text DEFAULT NULL,
  `birthday_gift_points` int(11) DEFAULT 0,
  `birthday_gift_balance` decimal(10,2) DEFAULT 0.00,
  `birthday_gift_experience` int(11) DEFAULT 0,
  `birthday_gift_coupon_ids` text DEFAULT NULL,
  `commission_rule_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_levels`
--

LOCK TABLES `membership_levels` WRITE;
/*!40000 ALTER TABLE `membership_levels` DISABLE KEYS */;
INSERT INTO `membership_levels` VALUES
(1,'普通会员',0,1,0,0.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','基础权益','ri:user-line','#909399','1','2026-07-10 22:42:45',50,100,'1',0,0.00,0,NULL,NULL,0,0,0,1,0,0.00,0,NULL,0,0.00,0,NULL,0),
(2,'黄金会员',1,1,0,299.00,0,0.9,1.5,1.0,'#FFFFFF','#000000','9折优惠,1.5倍积分,专属客服','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783977599947.gif','','1','2026-07-10 22:42:45',50,50,'',100,5.00,200,'[{\"name\":\"黄金专享券\",\"type\":\"fixed\",\"value\":20,\"minOrder\":30,\"maxDiscount\":0,\"scope\":\"membership\",\"category\":\"member\",\"validDays\":30}]','生日礼包|年度礼包',1,1,1,1,10,1.00,50,'[{\"name\":\"每日签到券\",\"type\":\"percent\",\"value\":5,\"minOrder\":0,\"maxDiscount\":20,\"scope\":\"all\",\"category\":\"general\",\"validDays\":7}]',500,50.00,1000,'[{\"name\":\"生日专属券\",\"type\":\"fixed\",\"value\":100,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"category\":\"member\",\"validDays\":30}]',3),
(3,'钻石会员',2,1,0,599.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','8折优惠,2倍积分,专属客服,优先发货,生日礼包','ri:vip-diamond-line','','1','2026-07-10 22:42:45',500,10000,'',0,0.00,0,'[]','',0,0,0,1,0,0.00,0,'[]',0,0.00,0,'[]',0),
(4,'至尊会员',3,1,0,999.00,0,0.7,3.0,3.0,'#FFFFFF','#508DFF','7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1783978168089.gif','#ff6b6b','1','2026-07-10 22:42:45',200,20000,'',200,0.00,200,'[]','',1,1,1,7,50,0.00,50,'[]',500,0.00,500,'[]',0),
(5,'测试会员',5,5,0,10.00,0,6.0,5.0,5.0,'#FFFFFF','#508DFF','','','','0','2026-07-11 22:39:44',500,500,'2,1',500,5.00,500,'[]','',1,1,1,3,10,0.00,30,'[]',500,0.00,500,'[]',0);
/*!40000 ALTER TABLE `membership_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_products`
--

DROP TABLE IF EXISTS `membership_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) DEFAULT '',
  `price` decimal(10,2) DEFAULT 0.00,
  `original_price` decimal(10,2) DEFAULT 0.00,
  `points_price` decimal(10,2) DEFAULT 0.00,
  `points_original_price` decimal(10,2) DEFAULT 0.00,
  `duration_days` int(11) DEFAULT 30,
  `is_promo` tinyint(1) DEFAULT 0,
  `promo_end_time` datetime DEFAULT NULL,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `gift_data_limit_mb` int(11) DEFAULT 0,
  `gift_file_limit_mb` int(11) DEFAULT 0,
  `purchase_limit` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_products`
--

LOCK TABLES `membership_products` WRITE;
/*!40000 ALTER TABLE `membership_products` DISABLE KEYS */;
INSERT INTO `membership_products` VALUES
(7,5,'30天会员',30.00,35.00,3500.00,3600.00,30,1,NULL,100,0.00,200,'[]',10,10,0,'1','2026-07-11 23:02:32'),
(13,3,'月度会员',15.00,18.00,1800.00,2000.00,31,1,NULL,100,0.00,100,'[]',0,0,0,'1','2026-07-12 20:36:06'),
(17,4,'月度会员',20.00,25.00,2500.00,3000.00,31,1,NULL,0,0.00,500,'[]',10,10,0,'1','2026-07-13 21:29:31'),
(18,4,'季度会员',48.00,60.00,5800.00,6000.00,96,1,NULL,120,0.00,2000,'[]',20,20,0,'1','2026-07-13 21:29:31'),
(19,2,'1个月',10.00,12.00,1300.00,0.00,31,1,NULL,50,3.00,100,'[{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"category\":\"general\",\"validDays\":14}]',10,10,3,'1','2026-07-17 19:22:54');
/*!40000 ALTER TABLE `membership_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_purchases`
--

DROP TABLE IF EXISTS `membership_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `purchase_type` varchar(20) DEFAULT 'buy',
  `duration_days` int(11) DEFAULT 0,
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_count` int(11) DEFAULT 0,
  `gift_data_mb` int(11) DEFAULT 0,
  `gift_file_mb` int(11) DEFAULT 0,
  `lower_extended_ids` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_membership_purchases_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_purchases`
--

LOCK TABLES `membership_purchases` WRITE;
/*!40000 ALTER TABLE `membership_purchases` DISABLE KEYS */;
INSERT INTO `membership_purchases` VALUES
(1,14,0,2,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-23 22:39:54',0,0.00,0,0,0,0,NULL),
(2,14,0,3,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54',0,0.00,0,0,0,0,NULL),
(3,4,0,2,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-28 22:39:54',0,0.00,0,0,0,0,NULL),
(4,11,0,4,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54',0,0.00,0,0,0,0,NULL),
(5,11,0,4,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-19 22:39:54',0,0.00,0,0,0,0,NULL),
(6,7,0,4,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-16 22:39:54',0,0.00,0,0,0,0,NULL),
(7,19,1,2,'黄金会员',1300.00,'points','buy',31,'2026-08-11 09:08:18','2026-07-11 09:08:18',0,0.00,0,0,0,0,NULL),
(8,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-09-11 01:08:18','2026-07-11 09:14:35',0,0.00,0,0,0,0,NULL),
(9,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-10-11 17:08:18','2026-07-11 09:14:38',0,0.00,0,0,0,0,NULL),
(10,1,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:37:08','2026-07-11 20:37:08',0,0.00,0,0,0,0,NULL),
(11,4,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:38:36','2026-07-11 20:38:36',0,0.00,0,0,0,0,NULL),
(18,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-11-11 09:08:18','2026-07-12 00:11:10',0,0.00,0,0,0,0,NULL),
(19,19,9,4,'至尊会员',48.00,'balance','buy',96,'2027-02-15 01:08:18','2026-07-12 10:34:02',0,0.00,0,0,0,0,NULL),
(20,19,9,4,'至尊会员',48.00,'balance','renew',96,'2027-05-21 17:08:18','2026-07-12 10:34:26',0,0.00,0,0,0,0,NULL),
(21,19,8,4,'至尊会员',20.00,'balance','renew',31,'2027-06-21 09:08:18','2026-07-12 10:35:24',0,0.00,0,0,0,0,NULL),
(22,19,9,4,'至尊会员',48.00,'balance','renew',96,'2027-09-25 01:08:18','2026-07-12 10:35:40',0,0.00,0,0,0,0,NULL),
(23,19,5,2,'黄金会员',10.00,'balance','buy',31,'2027-10-25 17:08:18','2026-07-12 10:37:22',0,0.00,0,0,0,0,NULL),
(24,19,8,4,'至尊会员',20.00,'balance','buy',31,'2027-11-25 09:08:18','2026-07-12 10:37:35',0,0.00,0,0,0,0,NULL),
(25,19,5,2,'黄金会员',10.00,'balance','buy',31,'2027-12-26 01:08:18','2026-07-12 10:37:47',0,0.00,0,0,0,0,NULL),
(26,19,8,4,'至尊会员',20.00,'balance','buy',31,'2028-01-25 17:08:18','2026-07-12 10:37:54',0,0.00,0,0,0,0,NULL),
(27,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:12:49','2026-07-12 11:12:50',0,0.00,0,0,0,0,NULL),
(28,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:12:58','2026-07-12 11:12:58',0,0.00,0,0,0,0,NULL),
(29,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:13:05','2026-07-12 11:13:05',0,0.00,0,0,0,0,NULL),
(30,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-02-25 09:08:18','2026-07-12 11:13:08',0,0.00,0,0,0,0,NULL),
(31,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-03-27 01:08:18','2026-07-12 11:13:13',0,0.00,0,0,0,0,NULL),
(32,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-04-26 17:08:18','2026-07-12 11:15:35',0,0.00,0,0,0,0,NULL),
(33,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-09-12 03:13:05','2026-07-12 11:15:38',0,0.00,0,0,0,0,NULL),
(34,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-10-12 19:13:05','2026-07-12 11:15:40',0,0.00,0,0,0,0,NULL),
(35,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-05-27 09:08:18','2026-07-12 11:17:36',0,0.00,0,0,0,0,NULL),
(36,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-06-27 01:08:18','2026-07-12 11:17:38',0,0.00,0,0,0,0,NULL),
(37,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-07-27 17:08:18','2026-07-12 11:17:40',0,0.00,0,0,0,0,NULL),
(38,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-08-27 09:08:18','2026-07-12 11:17:44',0,0.00,0,0,0,0,NULL),
(39,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-09-27 01:08:18','2026-07-12 11:17:47',0,0.00,0,0,0,0,NULL),
(40,19,9,4,'至尊会员',5800.00,'points','renew',96,'2028-12-31 17:08:18','2026-07-12 11:21:02',0,0.00,0,0,0,0,NULL),
(41,19,9,4,'至尊会员',5800.00,'points','renew',96,'2029-04-06 09:08:18','2026-07-12 11:21:07',0,0.00,0,0,0,0,NULL),
(42,19,9,4,'至尊会员',5800.00,'points','renew',96,'2029-07-11 01:08:18','2026-07-12 11:21:13',0,0.00,0,0,0,0,NULL),
(43,19,9,4,'至尊会员',48.00,'balance','renew',96,'2029-10-14 17:08:18','2026-07-12 11:21:15',0,0.00,0,0,0,0,NULL),
(44,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-05-01 11:13:05','2026-07-12 16:49:54',0,0.00,0,0,0,0,'[\"3:4:2029-10-14T09:08:18.000Z\"]'),
(45,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-06-01 03:13:05','2026-07-12 16:50:03',0,0.00,0,0,0,0,'[\"3:4:2029-11-14T01:08:18.000Z\"]'),
(46,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-07-01 19:13:05','2026-07-12 16:50:07',0,0.00,0,0,0,0,'[\"3:4:2029-12-14T17:08:18.000Z\"]'),
(47,19,5,2,'黄金会员',1300.00,'points','renew',31,'2028-08-01 11:13:05','2026-07-12 16:50:10',0,0.00,0,0,0,0,'[\"3:4:2030-01-14T09:08:18.000Z\"]'),
(48,19,5,2,'黄金会员',1300.00,'points','renew',31,'2028-09-01 03:13:05','2026-07-12 16:50:15',0,0.00,0,0,0,0,'[\"3:4:2030-02-14T01:08:18.000Z\"]'),
(49,19,9,4,'至尊会员',48.00,'balance','renew',96,'2030-06-20 17:08:18','2026-07-12 16:50:19',120,0.00,2000,0,20,20,'[\"6:2:2028-08-31T19:13:05.000Z\"]'),
(50,19,9,4,'至尊会员',48.00,'balance','renew',96,'2030-09-24 09:08:18','2026-07-12 16:50:22',120,0.00,2000,0,20,20,'[\"6:2:2028-12-05T11:13:05.000Z\"]'),
(51,19,9,4,'至尊会员',5800.00,'points','renew',96,'2030-12-29 01:08:18','2026-07-12 16:50:25',120,0.00,2000,0,20,20,'[\"6:2:2029-03-11T03:13:05.000Z\"]'),
(52,19,9,4,'至尊会员',5800.00,'points','renew',96,'2031-04-03 17:08:18','2026-07-12 16:50:28',120,0.00,2000,0,20,20,'[\"6:2:2029-06-14T19:13:05.000Z\"]'),
(53,19,9,4,'至尊会员',48.00,'balance','renew',96,'2031-07-08 09:08:18','2026-07-12 16:50:30',120,0.00,2000,0,20,20,'[\"6:2:2029-09-18T11:13:05.000Z\"]'),
(54,19,11,4,'至尊会员',48.00,'balance','renew',96,'2031-10-12 01:08:18','2026-07-12 16:51:41',120,0.00,2000,0,20,20,'[\"6:2:2029-12-23T03:13:05.000Z\"]'),
(55,19,11,4,'至尊会员',48.00,'balance','renew',96,'2032-01-15 17:08:18','2026-07-12 16:52:12',120,0.00,2000,0,20,20,'[\"6:2:2030-03-28T19:13:05.000Z\"]'),
(56,19,13,3,'钻石会员',15.00,'balance','buy',31,'2026-08-12 20:36:22','2026-07-12 20:36:22',100,0.00,100,0,0,0,'[\"3:4:2032-01-15T09:08:18.000Z\",\"6:2:2030-07-02T11:13:05.000Z\"]'),
(57,19,10,4,'至尊会员',20.00,'balance','renew',31,'2032-03-17 01:08:18','2026-07-12 20:36:40',0,0.00,500,0,10,10,'[\"6:2:2030-08-02T03:13:05.000Z\",\"7:3:2026-08-12T12:36:22.000Z\"]'),
(58,19,13,3,'钻石会员',15.00,'balance','renew',31,'2026-10-13 04:36:22','2026-07-12 20:36:48',100,0.00,100,0,0,0,'[\"3:4:2032-03-16T17:08:18.000Z\",\"6:2:2030-09-01T19:13:05.000Z\"]'),
(59,19,11,4,'至尊会员',48.00,'balance','renew',96,'2032-07-21 09:08:18','2026-07-12 20:46:00',120,0.00,2000,0,20,20,'[\"6:2:2030-10-02T11:13:05.000Z\",\"7:3:2026-10-12T20:36:22.000Z\"]'),
(60,19,11,4,'至尊会员',5800.00,'points','renew',96,'2032-10-25 01:08:18','2026-07-12 20:48:02',120,0.00,2000,0,20,20,'[\"6:2:2031-01-06T03:13:05.000Z\",\"7:3:2027-01-16T12:36:22.000Z\"]'),
(61,19,10,4,'至尊会员',20.00,'balance','renew',31,'2032-11-24 17:08:18','2026-07-12 22:19:55',0,0.00,500,0,10,10,'[\"6:2:2031-04-11T19:13:05.000Z\",\"7:3:2027-04-22T04:36:22.000Z\"]'),
(62,19,5,2,'黄金会员',10.00,'balance','renew',31,'2031-06-12 11:13:05','2026-07-12 23:00:31',0,0.00,0,0,0,0,'[\"3:4:2032-11-24T09:08:18.000Z\",\"7:3:2027-05-22T20:36:22.000Z\"]'),
(63,19,11,4,'至尊会员',48.00,'balance','renew',96,'2033-03-31 01:08:18','2026-07-12 23:01:02',120,0.00,2000,0,20,20,'[\"6:2:2031-06-12T03:13:05.000Z\",\"7:3:2027-06-22T12:36:22.000Z\"]'),
(64,19,18,4,'至尊会员',48.00,'balance','renew',96,'2033-07-04 17:08:18','2026-07-17 19:37:43',120,0.00,2000,0,20,20,'[\"6:2:2031-09-15T19:13:05.000Z\",\"7:3:2027-09-26T04:36:22.000Z\"]'),
(65,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-01-30 20:36:22','2026-07-17 19:37:46',100,0.00,100,0,0,0,'[\"3:4:2033-07-04T09:08:18.000Z\",\"6:2:2031-12-20T11:13:05.000Z\"]'),
(66,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-03-01 12:36:22','2026-07-17 19:37:50',100,0.00,100,0,0,0,'[\"3:4:2033-08-04T01:08:18.000Z\",\"6:2:2032-01-20T03:13:05.000Z\"]'),
(67,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-04-01 04:36:22','2026-07-17 19:37:57',100,0.00,100,0,0,0,'[\"3:4:2033-09-03T17:08:18.000Z\",\"6:2:2032-02-19T19:13:05.000Z\"]'),
(68,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-04-21 11:13:05','2026-07-17 19:38:02',50,3.00,100,1,10,10,'[\"3:4:2033-10-04T09:08:18.000Z\",\"7:3:2028-03-31T20:36:22.000Z\"]'),
(69,19,18,4,'至尊会员',48.00,'balance','renew',96,'2034-02-08 01:08:18','2026-07-17 19:38:04',120,0.00,2000,0,20,20,'[\"6:2:2032-04-21T03:13:05.000Z\",\"7:3:2028-05-01T12:36:22.000Z\"]'),
(70,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-08-25 19:13:05','2026-07-17 19:43:09',50,3.00,100,1,10,10,NULL),
(71,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-09-25 11:13:05','2026-07-17 19:43:15',50,3.00,100,1,10,10,NULL),
(72,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-10-26 03:13:05','2026-07-17 19:43:19',0,0.00,0,0,0,0,NULL),
(73,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-09-05 04:36:22','2026-07-17 19:43:23',100,0.00,100,0,0,0,NULL),
(74,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-10-05 20:36:22','2026-07-17 19:43:27',100,0.00,100,0,0,0,NULL),
(75,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-11-05 12:36:22','2026-07-17 19:43:32',100,0.00,100,0,0,0,NULL);
/*!40000 ALTER TABLE `membership_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL DEFAULT '',
  `component` varchar(200) DEFAULT '',
  `redirect` varchar(200) DEFAULT '',
  `title` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `is_hidden` tinyint(1) DEFAULT 0,
  `is_full_page` tinyint(1) DEFAULT 0,
  `is_keep_alive` tinyint(1) DEFAULT 1,
  `is_fixed_tab` tinyint(1) DEFAULT 0,
  `auth_list` text DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `mobile_path` varchar(200) DEFAULT '',
  `icon_bg` varchar(20) DEFAULT '#4ECDC4',
  `icon_svg` text DEFAULT NULL,
  `category` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,0,'Dashboard','/dashboard','/index/index','/dashboard/console','仪表盘','ri:pie-chart-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:31:19'),
(2,0,'Operation','/operation','/index/index','','运营管理','ri:settings-3-line',3,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:19'),
(3,0,'System','/system','/index/index','','系统管理','ri:user-3-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:15'),
(4,0,'Result','/result','/index/index','','结果页面','ri:checkbox-circle-line',6,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:30'),
(5,0,'Exception','/exception','/index/index','','异常页面','ri:error-warning-line',7,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:36'),
(6,0,'AppStore','/appstore','/index/index','','审核中心','ri:apps-2-line',1,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\",\"R_USER\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:31:00'),
(7,1,'Console','console','/dashboard/console','','工作台','',1,0,0,1,1,NULL,NULL,1,'/appstore/mobile-console','#F472B6','M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(8,2,'CardKey','cardkey','/operation/cardkey/index','','卡密管理','',1,0,0,1,0,'[{\"title\":\"生成\",\"authMark\":\"add\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"导入\",\"authMark\":\"import\"}]',NULL,1,'/appstore/cardkey-manage','#C4B5FD','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(9,2,'Membership','membership','/operation/membership/index','','会员管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/operation/membership','#86EFAC','M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(10,2,'Coupon','coupon','/operation/coupon/index','','优惠券管理','',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/coupon','#FF6B81','M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-6 4h2v-2h-2v2zm-4 0h2v-2h-2v2zm0-4h2v-2h-2v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(11,2,'Points','points','/operation/points/index','','积分管理','',4,0,0,1,0,'[{\"title\":\"调整\",\"authMark\":\"adjust\"},{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/points','#D946EF','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(12,2,'ExperienceLevel','experience','/operation/experience/index','','经验等级','',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/experience-manage','#14B8A6','M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(13,2,'Plugins','plugins','/operation/plugins/index','','插件管理','',6,0,0,1,0,'[{\"title\":\"上传\",\"authMark\":\"upload\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"配置\",\"authMark\":\"config\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/plugin-manage','#FF6B81','M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-2 .9-2 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7s2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(14,2,'TitleManage','title','/operation/title/index','','称号管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/title-manage','#6366F1','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(15,2,'CommissionManage','commission','/operation/commission/index','','推广返佣','',8,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"配置\",\"authMark\":\"config\"}]',NULL,1,'/appstore/commission-manage','#14B8A6','M20 7h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-6 0h-4V4h4v3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(16,54,'文件上传策略','filepolicy','/operation/filepolicy/index','','文件上传策略','',9,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-policy-manage','#A3E635','M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12','','2026-07-10 22:42:45','2026-07-12 16:09:37'),
(17,2,'Settlement','settlement','/operation/settlement/index','','结算规则','ri:exchange-funds-line',10,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/settlement','#C4B5FD','M21 3H3v18h18V3zm-2 16H5V5h14v14zM17 7h-4v4h4V7zm-6 0H7v4h4V7zm6 6h-4v4h4v-4zm-6 0H7v4h4v-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(18,2,'MembershipProducts','membership-products','/operation/membership-products/index','','会员商品','',11,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/membership-products','#EC4899','M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-5 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 14H4v-2h16v2zm0-5H4V8h16v5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(19,2,'MembershipPurchases','membership-purchases','/operation/membership-purchases/index','','购买记录','',12,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/purchase-records','#F59E0B','M11 17h2v-1h1c.55 0 1-.45 1-1v-3c0-.55-.45-1-1-1h-3v-1h4V8h-2V7h-2v1h-1c-.55 0-1 .45-1 1v3c0 .55.45 1 1 1h3v1H9v2h2v1zm9-13H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(20,2,'ContentPurchases','content-purchases','/operation/content-purchases/index','','付费内容订单','',13,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/content-purchases','#8B5CF6','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(21,3,'User','user','/system/user','','用户管理','',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"重置密码\",\"authMark\":\"reset\"}]',NULL,1,'/appstore/user-manage','#0EA5E9','M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(22,3,'Role','role','/system/role','','角色管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/role-manage','#5352ED','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(23,3,'UserCenter','user-center','/system/user-center','','个人中心','',3,1,0,1,1,NULL,NULL,1,'','#10B981',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(24,3,'Menus','menu','/system/menu','','菜单管理','',4,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/menu-manage','#0EA5E9','M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(25,3,'DeleteReview','delete-review','/system/user/delete-review','','提现注销审核','',6,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'/appstore/delete-review','#70A1FF','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-12 23:50:44'),
(26,3,'Verification','verification','/system/verification/index','','蓝V认证审核','',5,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:50:44'),
(27,3,'InviteManage','invite','/system/invite/index','','邀请码管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"生成\",\"authMark\":\"generate\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/invite-manage','#FB923C','M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(28,70,'EmailConfig','email','','','邮件配置','ri:mail-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-config','#FDBA74','M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(29,54,'文件仓库','filerepo','/system/filerepo/index','','文件仓库','',8,0,0,1,0,'[{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-repo-manage','#14B8A6','M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z','','2026-07-10 22:42:45','2026-07-12 16:09:29'),
(30,3,'RecycleBin','recycle','/system/recycle/index','','回收站','',10,0,0,1,0,'[{\"title\":\"恢复\",\"authMark\":\"restore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/recycle','#FF4757','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(31,3,'SystemLog','syslog','/system/syslog/index','','系统日志','',11,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"},{\"title\":\"清空\",\"authMark\":\"clear\"}]',NULL,1,'/appstore/syslog','#84CC16','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(32,70,'SysConfig','sysconfig','','','系统配置','ri:settings-3-line',1,0,0,0,0,NULL,NULL,0,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:39:02'),
(33,3,'CustomTask','task','/system/task/index','','任务管理','',13,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/task-manage','#A78BFA','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(34,70,'EmailTemplates','email-templates','','','邮件卡片','ri:mail-settings-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-templates','#FF6B81','M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(35,70,'EmailPush','email-push','','','邮件推送','ri:send-plane-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-push','#FCA5A5','M3.4 20.4l17.45-7.48c1.1-.47 1.1-1.97 0-2.44L3.4 3.6c-1.1-.47-2.2.63-1.73 1.73L7 12l-5.33 6.67c-.47 1.1.63 2.2 1.73 1.73z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(36,54,'对象存储','storage-config','/appstore/storage-config','','对象存储','',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/storage-config','#5EEAD4','M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z','','2026-07-10 22:42:45','2026-07-12 16:24:10'),
(37,6,'AppStoreList','list','/appstore/list','','应用管理','',1,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/list','#6366F1','M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(38,6,'AppStoreDetail','detail/:id','/appstore/detail','','应用详情','',2,1,0,0,0,NULL,NULL,1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(39,6,'AppCategory','category-manage','/appstore/category','','应用分类','ri:apps-2-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/category-manage','#818CF8','M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(40,6,'AppReports','reports','/appstore/reports','','举报列表','ri:apps-2-line',4,0,0,1,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/reports','#5352ED','M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(44,6,'OfficialTags','official-tags','/appstore/official-tags','','官方标签','',8,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',0,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-13 15:04:21'),
(45,6,'SectionManage','section-manage','','','板块管理','',9,1,0,0,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"管理版主\",\"authMark\":\"moderate\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"处理解锁\",\"authMark\":\"unlock\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/section-manage','#818CF8','M3 15h8v-2H3v2zm0 4h8v-2H3v2zm0-8h8V9H3v2zm0-6v2h8V5H3zm10 0h8v14h-8V5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(46,6,'CommunityPostManage','community-posts','','','帖子管理','',10,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"加精\",\"authMark\":\"essence\"},{\"title\":\"热帖\",\"authMark\":\"boost\"},{\"title\":\"锁定\",\"authMark\":\"lock\"},{\"title\":\"审核\",\"authMark\":\"approve\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(47,6,'CommunityReportManage','community-reports','','','举报管理','',11,1,0,0,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(48,6,'CommunityCommentManage','community-comments','','','评论管理','',12,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(49,4,'Success','success','/result/success/index','','成功页','',1,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(50,4,'Fail','fail','/result/fail/index','','失败页','',2,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(51,5,'Exception403','403','/exception/403/index','','403','',1,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(52,5,'Exception404','404','/exception/404/index','','404','',2,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(53,5,'Exception500','500','/exception/500/index','','500','',3,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(54,0,'文件管理','/awsdb','/index/index','','文件管理','',4,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 23:24:00','2026-07-12 17:15:51'),
(55,2,'GameCenter','/operation/game-center','','','游戏中心','ri:gamepad-line',19,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/game-center','#22C55E','M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v2H6v-2H4v-2h2V9h2v2h3v2zm7 0h-3v2h-2v-2h-3V9h3V7h2v2h3v2z','','2026-07-11 09:41:21','2026-07-11 09:41:21'),
(56,0,'商城管理','/etnfd','','','商城管理','',5,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-11 16:08:50','2026-07-11 16:09:24'),
(57,56,'商品管理','/appstore/mall-manage','/appstore/admin/mall/mall-manage','','商品管理','ri:shopping-bag-3-line',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-manage','#FDBA74','M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4','','2026-07-11 16:15:17','2026-07-12 16:10:51'),
(58,56,'订单管理','/appstore/mall-orders','/appstore/admin/mall/mall-orders','','订单管理','ri:file-list-3-line',2,0,0,1,0,'[{\"title\":\"查看\",\"authMark\":\"view\"},{\"title\":\"处理\",\"authMark\":\"handle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-orders','#10B981','M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01','','2026-07-11 16:15:17','2026-07-12 16:08:51'),
(59,56,'分类管理','/appstore/mall-categories','/appstore/admin/mall/mall-categories','','分类管理','ri:price-tag-3-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-categories','#26DE81','M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z','','2026-07-11 16:15:17','2026-07-12 16:08:58'),
(60,56,'售后服务','/appstore/mall-after-sales','/appstore/admin/mall/mall-after-sales','','售后服务','ri:customer-service-2-line',4,0,0,1,0,'[{\"title\":\"查看\",\"authMark\":\"view\"},{\"title\":\"处理\",\"authMark\":\"handle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-after-sales','#A3E635','M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z','','2026-07-11 16:15:17','2026-07-12 16:09:06'),
(61,56,'优惠活动','/appstore/mall-promotions','/appstore/admin/mall/mall-promotions','','优惠活动','ri:gift-line',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-promotions','#EF4444','M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7','','2026-07-11 16:15:17','2026-07-12 16:09:13'),
(62,2,'CheckinManage','/operation/checkin','/operation/checkin/index','','签到管理','ri:calendar-check-line',21,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/checkin','#A855F7','M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-6.67 11.93l-3.89 3.89-2.11-2.11 1.41-1.41 1.12 1.12 2.47-2.47 1.51 1.41.04.04z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(63,70,'LayoutThemesManage','layout-themes','','','布局主题','ri:layout-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/layout-themes','#0EA5E9','M3 21h18v-2H3v2zm0-4h12v-2H3v2zm0-4h18v-2H3v2zm0-4h12V7H3v2zm0-6v2h18V3H3z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(64,2,'AvatarFrameManage','/operation/avatar-frame','/operation/avatar-frame/index','','头像框管理','ri:user-smile-line',23,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/avatar-frame','#FFA502','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(65,70,'PaymentConfig','/operation/payment-config','','','支付配置','ri:bank-card-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/payment-config','#7BED9F','M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(66,70,'RechargeAmounts','/operation/recharge-amounts','','','充值金额配置','ri:money-cny-circle-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/recharge-amounts','#FF6348','M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(67,6,'SubmissionReview','/appstore/review','/appstore/review','','投稿审核','ri:audit-line',7,0,0,1,0,'[{\"title\":\"审核\",\"authMark\":\"edit\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/review-mobile','#FACC15','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(68,54,'存储文件','/system/storage-files','/system/storage-files','','存储文件','ri:hard-drive-3-line',4,0,0,1,0,'[{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"下载\",\"authMark\":\"download\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/storage-files','#818CF8','M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z','','2026-07-11 17:31:24','2026-07-12 16:09:23'),
(69,6,'TopicManage','/appstore/topic-manage','','','话题管理','',11,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/topic-manage','#F472B6','M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7V9zm8 0h2v2h-2V9zm-4 0h2v2h-2V9z','','2026-07-12 15:58:19','2026-07-12 15:58:19'),
(70,0,'配置管理','/arccg','','','配置管理','',4,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-12 19:26:16','2026-07-12 19:33:09'),
(72,70,'SmsConfig','/appstore/sms-config','','','短信配置','ri:message-2-line',2,0,0,0,0,NULL,NULL,1,'/appstore/sms-config','#FDBA74','M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7V9zm4 0h2v2h-2V9zm4 0h2v2h-2V9z','','2026-07-12 19:45:16','2026-07-12 19:45:16'),
(73,70,'SiteConfig','/appstore/site-config','','','站点配置','ri:global-line',1,0,0,0,0,NULL,NULL,1,'/appstore/site-config','#D946EF','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z','','2026-07-12 19:47:09','2026-07-12 19:47:09'),
(74,6,'PostReview','/appstore/post-review','/appstore/admin/post-review','','帖子审核','',13,0,0,1,0,NULL,'R_SUPER,R_ADMIN',1,'/appstore/post-review','#4ECDC4',NULL,'','2026-07-13 12:03:04','2026-07-13 12:03:04'),
(75,6,'TagManage','/appstore/tag-manage','','','标签管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/tag-manage','#8B5CF6','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z\"/></svg>','社区管理','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(76,1,'AnalyticsDashboard','/appstore/analytics-dashboard','','','数据分析','',0,0,0,1,0,NULL,NULL,1,'/appstore/analytics-dashboard','#10B981','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z\"/></svg>','仪表盘','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(77,6,'ModeratorApplications','/appstore/moderator-applications','','','版主申请审核','',0,0,0,1,0,NULL,NULL,1,'/appstore/moderator-applications','#F59E0B','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(78,6,'AppealManage','/appstore/appeal-manage','','','举报申诉处理','',0,0,0,1,0,NULL,NULL,1,'/appstore/appeal-manage','#5352ED','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(79,6,'SensitiveWords','/appstore/sensitive-words','','','敏感词管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/sensitive-words','#FACC15','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(80,6,'UnlockRequests','/appstore/unlock-requests','','','解锁申请管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/unlock-requests','#4ECDC4','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(82,70,'OauthConfig','/appstore/oauth-config','','','OAuth登录配置','oauth',9,0,0,1,0,NULL,NULL,1,'/appstore/oauth-config','#9C27B0','<svg width=\"22\" height=\"22\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"white\" stroke-width=\"2\"><path d=\"M15 7h2a5 5 0 010 10h-2m-6 0H7A5 5 0 017 7h2\"/></svg>','auth','2026-07-16 23:35:47','2026-07-16 23:35:47'),
(83,56,'物流配置','','','','物流配置','',11,0,0,1,0,NULL,NULL,1,'/appstore/logistics-config','#FF5722',NULL,'','2026-07-17 15:43:45','2026-07-17 15:43:45');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moderator_applications`
--

DROP TABLE IF EXISTS `moderator_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moderator_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `reason` text DEFAULT '',
  `desired_role` varchar(50) DEFAULT '版主',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moderator_applications`
--

LOCK TABLES `moderator_applications` WRITE;
/*!40000 ALTER TABLE `moderator_applications` DISABLE KEYS */;
INSERT INTO `moderator_applications` VALUES
(7,1,1,'bobwang','','我热爱综合讨论板块','版主','pending',0,'','','2026-07-14 14:00:13',NULL),
(8,3,1,'bobwang','','我是设计师','版主','pending',0,'','','2026-07-14 14:00:13',NULL),
(9,1,2,'lisa_chen','','常年在综合讨论活跃','版主','approved',19,'alexmorgan','','2026-07-14 14:00:20','2026-07-15 19:31:36'),
(10,3,2,'lisa_chen','','从事设计工作多年','审核员','pending',0,'','','2026-07-14 14:00:20',NULL),
(11,1,10001,'35735712','','6666','版主','approved',19,'alexmorgan','','2026-07-16 17:06:35','2026-07-16 17:07:01');
/*!40000 ALTER TABLE `moderator_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_accounts`
--

DROP TABLE IF EXISTS `oauth_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `provider_user_id` varchar(200) NOT NULL,
  `access_token` text DEFAULT NULL,
  `refresh_token` varchar(500) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_user` (`provider`,`provider_user_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_accounts`
--

LOCK TABLES `oauth_accounts` WRITE;
/*!40000 ALTER TABLE `oauth_accounts` DISABLE KEYS */;
INSERT INTO `oauth_accounts` VALUES
(1,10002,'github','mock-github-1784229998022','mock_token_1784229998102',NULL,NULL,'2026-07-16 19:26:38'),
(2,1,'github','mock-github-bind-1784230207655','mock_token_1784230207656',NULL,NULL,'2026-07-16 19:30:07');
/*!40000 ALTER TABLE `oauth_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(100) DEFAULT '',
  `seller_id` int(11) DEFAULT 0,
  `seller_name` varchar(100) DEFAULT '',
  `order_type` varchar(30) NOT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `ref_id` int(11) DEFAULT 0,
  `ref_table` varchar(50) DEFAULT '',
  `pay_type` varchar(20) DEFAULT 'balance',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_id` int(11) DEFAULT 0,
  `coupon_discount` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'shipped',
  `confirm_days` int(11) DEFAULT 7,
  `confirm_deadline` datetime DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `refund_reason` varchar(500) DEFAULT '',
  `refund_requested_at` datetime DEFAULT NULL,
  `refund_responded_at` datetime DEFAULT NULL,
  `refund_reviewed_by` int(11) DEFAULT 0,
  `refund_reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_orders_buyer` (`buyer_id`),
  KEY `idx_orders_seller` (`seller_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,'ORD17837231940',2,'',0,'','purchase','',0,'','balance',92.69,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-02 22:39:54'),
(2,'ORD17837231941',2,'',0,'','purchase','',0,'','balance',191.11,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-24 22:39:54'),
(3,'ORD17837231942',11,'',0,'','purchase','',0,'','balance',112.15,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-17 22:39:54'),
(4,'ORD17837231943',10,'',0,'','purchase','',0,'','balance',210.01,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(5,'ORD17837231944',7,'',0,'','purchase','',0,'','balance',213.23,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-27 22:39:54'),
(6,'ORD17837231945',4,'',0,'','purchase','',0,'','balance',84.35,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-10 22:39:54'),
(7,'ORD17837231946',11,'',0,'','purchase','',0,'','balance',20.66,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-28 22:39:54'),
(8,'ORD17837231947',4,'',0,'','purchase','',0,'','balance',88.74,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-05 22:39:54'),
(9,'ORD17837231948',7,'',0,'','purchase','',0,'','balance',137.37,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(10,'ORD17837231949',13,'',0,'','purchase','',0,'','balance',125.98,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-13 22:39:54'),
(11,'MOMRG56M0YZHEW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-18 09:08:18','2026-07-11 09:08:18','2026-07-11 09:15:07','',NULL,NULL,0,'',NULL,'2026-07-11 09:08:18'),
(12,'MOMRG5EOSU5FWW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:35','2026-07-11 09:14:35','2026-07-11 09:15:06','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:35'),
(13,'MOMRG5ER54XYLJ',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:38','2026-07-11 09:14:38','2026-07-11 09:15:03','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:38'),
(14,'MOMRGTSGBB9TLF',1,'bobwang',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:37:08','2026-07-11 20:37:08',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:37:08'),
(15,'MOMRGTUCDK3DNE',4,'design_master',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:38:36','2026-07-11 20:38:36',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:38:36'),
(16,'MOMRGTUU7OFOKT',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:38:59','2026-07-11 20:38:59',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:38:59'),
(17,'MOMRGTV0LR3ZZX',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:39:07','2026-07-11 20:39:07',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:39:07'),
(18,'MOMRGU8MPOFVJ9',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:49:43','2026-07-11 20:49:43',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:49:43'),
(19,'MOMRGU8UU8DEZE',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 20:49:53','2026-07-11 20:49:53',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 20:49:53'),
(20,'MOMRGUVIXAUQ35',22,'titletest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 21:07:31','2026-07-11 21:07:31',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 21:07:31'),
(21,'MOMRGUWL8VTG0N',23,'birthdaytest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-18 21:08:21','2026-07-11 21:08:21',NULL,'',NULL,NULL,0,'',NULL,'2026-07-11 21:08:21'),
(22,'MOMRH1FPH8CYRU',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,5.00,'shipped',7,'2026-07-19 00:11:10','2026-07-12 00:11:10',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 00:11:10'),
(23,'MOMRHNOPT1BP3Y',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-19 10:34:02','2026-07-12 10:34:02',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:34:02'),
(24,'MOMRHNP8O871VF',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-19 10:34:26','2026-07-12 10:34:26',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:34:26'),
(25,'MOMRHNQHBI7TA1',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 10:35:24','2026-07-12 10:35:24',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:35:24'),
(26,'MOMRHNQTEIBRRW',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-19 10:35:40','2026-07-12 10:35:40',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:35:40'),
(27,'MOMRHNSZUORY40',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 10:37:22','2026-07-12 10:37:22',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:37:22'),
(28,'MOMRHNTAEM554M',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 10:37:35','2026-07-12 10:37:35',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:37:35'),
(29,'MOMRHNTJQ5PTC0',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 10:37:47','2026-07-12 10:37:47',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:37:47'),
(30,'MOMRHNTOL2KPIM',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 10:37:54','2026-07-12 10:37:54',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 10:37:54'),
(31,'MOMRHP2LPAVFWE',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 11:12:50','2026-07-12 11:12:50',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:12:50'),
(32,'MOMRHP2S49AVSK',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 11:12:58','2026-07-12 11:12:58',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:12:58'),
(33,'MOMRHP2XIQK75T',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 11:13:05','2026-07-12 11:13:05',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:13:05'),
(34,'MOMRHP302FHLAF',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:13:08','2026-07-12 11:13:08',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:13:08'),
(35,'MOMRHP33KY17I4',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:13:13','2026-07-12 11:13:13',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:13:13'),
(36,'MOMRHP65DTVO12',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:15:35','2026-07-12 11:15:35',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:15:35'),
(37,'MOMRHP67OWPQL2',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 11:15:38','2026-07-12 11:15:38',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:15:38'),
(38,'MOMRHP69HOG7MF',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-19 11:15:40','2026-07-12 11:15:40',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:15:40'),
(39,'MOMRHP8QGMVXWY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:17:36','2026-07-12 11:17:36',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:17:36'),
(40,'MOMRHP8S58R2CJ',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:17:38','2026-07-12 11:17:38',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:17:38'),
(41,'MOMRHP8TR60BFI',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:17:40','2026-07-12 11:17:40',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:17:40'),
(42,'MOMRHP8X9W5EWQ',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:17:44','2026-07-12 11:17:44',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:17:44'),
(43,'MOMRHP8Z17FW6R',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'shipped',7,'2026-07-19 11:17:47','2026-07-12 11:17:47',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:17:47'),
(44,'MOMRHPD5JRIXA8',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'shipped',7,'2026-07-19 11:21:02','2026-07-12 11:21:02',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:21:02'),
(45,'MOMRHPD9MV9MBY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'shipped',7,'2026-07-19 11:21:07','2026-07-12 11:21:07',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:21:07'),
(46,'MOMRHPDDTLU8TH',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'shipped',7,'2026-07-19 11:21:13','2026-07-12 11:21:13',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:21:13'),
(47,'MOMRHPDFZDSAY5',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-19 11:21:15','2026-07-12 11:21:15',NULL,'',NULL,NULL,0,'',NULL,'2026-07-12 11:21:15'),
(48,'MOMRI143C113BA',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:49:54','2026-07-12 16:49:54','2026-07-12 23:02:42','',NULL,NULL,0,'',NULL,'2026-07-12 16:49:54'),
(49,'MOMRI14A59QD2E',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:50:03','2026-07-12 16:50:03','2026-07-12 23:03:13','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:03'),
(50,'MOMRI14D3E5D8T',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:50:07','2026-07-12 16:50:07','2026-07-12 23:03:12','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:07'),
(51,'MOMRI14FOWY5S0',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-19 16:50:10','2026-07-12 16:50:10','2026-07-12 23:03:11','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:10'),
(52,'MOMRI14IZ91WT3',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-19 16:50:15','2026-07-12 16:50:15','2026-07-12 23:03:09','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:15'),
(53,'MOMRI14MMP09TW',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:19','2026-07-12 16:50:19','2026-07-12 23:03:07','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:19'),
(54,'MOMRI14OMHNEKT',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:22','2026-07-12 16:50:22','2026-07-12 23:03:06','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:22'),
(55,'MOMRI14QW812AM',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 16:50:25','2026-07-12 16:50:25','2026-07-12 23:03:05','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:25'),
(56,'MOMRI14T94C1GY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 16:50:28','2026-07-12 16:50:28','2026-07-12 23:03:04','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:28'),
(57,'MOMRI14UR0XW2W',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:30','2026-07-12 16:50:30','2026-07-12 23:03:03','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:30'),
(58,'MOMRI16D90DUTD',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:51:41','2026-07-12 16:51:41','2026-07-12 23:03:01','',NULL,NULL,0,'',NULL,'2026-07-12 16:51:41'),
(59,'MOMRI171K2B8KL',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:52:12','2026-07-12 16:52:12','2026-07-12 23:03:00','',NULL,NULL,0,'',NULL,'2026-07-12 16:52:12'),
(60,'MOMRI97BPRB96F',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'completed',7,'2026-07-19 20:36:22','2026-07-12 20:36:22','2026-07-12 23:02:58','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:22'),
(61,'MOMRI97PMMFRT5',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 20:36:40','2026-07-12 20:36:40','2026-07-12 23:02:57','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:40'),
(62,'MOMRI97VVZ1PWE',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'completed',7,'2026-07-19 20:36:48','2026-07-12 20:36:48','2026-07-12 23:02:55','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:48'),
(63,'MOMRI9JPVJM0UU',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 20:46:00','2026-07-12 20:46:00','2026-07-12 23:02:53','',NULL,NULL,0,'',NULL,'2026-07-12 20:46:00'),
(64,'MOMRI9MBX4B32A',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 20:48:02','2026-07-12 20:48:02','2026-07-12 23:02:52','',NULL,NULL,0,'',NULL,'2026-07-12 20:48:02'),
(65,'MOMRICWHA7TE0E',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 22:19:55','2026-07-12 22:19:55','2026-07-12 23:02:50','',NULL,NULL,0,'',NULL,'2026-07-12 22:19:55'),
(66,'MOMRIECPK672BU',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 23:00:31','2026-07-12 23:00:31','2026-07-12 23:02:47','',NULL,NULL,0,'',NULL,'2026-07-12 23:00:31'),
(67,'MOMRIEDD7NKYBL',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 23:01:02','2026-07-12 23:01:02','2026-07-12 23:02:46','',NULL,NULL,0,'',NULL,'2026-07-12 23:01:02'),
(68,'COMRLKODKV6MAT',1,'bobwang',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','balance',5.00,0,0.00,4.50,'shipped',7,'2026-07-22 04:20:52','2026-07-15 04:20:52',NULL,'',NULL,NULL,0,'',NULL,'2026-07-15 04:20:52'),
(69,'COMRLKOLQLDJCU',1,'bobwang',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','points',100.00,0,0.00,100.00,'shipped',7,'2026-07-22 04:21:03','2026-07-15 04:21:03',NULL,'',NULL,NULL,0,'',NULL,'2026-07-15 04:21:03'),
(70,'COMRMREE3QBMMQ',10001,'35735712',19,'','content_purchase','购买应用《666》',22,'post','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-23 00:16:50','2026-07-16 00:16:50',NULL,'',NULL,NULL,0,'',NULL,'2026-07-16 00:16:50'),
(71,'COMRMRFDXBU556',10001,'35735712',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','points',100.00,0,0.00,100.00,'completed',7,'2026-07-23 00:17:36','2026-07-16 00:17:36','2026-07-16 00:19:39','',NULL,NULL,0,'',NULL,'2026-07-16 00:17:36'),
(72,'COMRMRFKWLZFRF',10001,'35735712',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','balance',5.00,0,0.00,5.00,'completed',7,'2026-07-23 00:17:45','2026-07-16 00:17:45','2026-07-16 00:19:36','',NULL,NULL,0,'',NULL,'2026-07-16 00:17:45'),
(73,'COMRNOILPE4LIR',10001,'35735712',19,'','content_purchase','购买应用《【付费解锁测试】精品设计教程 - 从入门到精通》',23,'post','balance',8.88,0,0.00,8.88,'shipped',7,'2026-07-23 15:43:53','2026-07-16 15:43:53',NULL,'',NULL,NULL,0,'',NULL,'2026-07-16 15:43:53'),
(74,'MOMRPCB5D7VXKP',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-24 19:37:43','2026-07-17 19:37:43',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:43'),
(75,'MOMRPCB7YPX1WG',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:46','2026-07-17 19:37:46',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:46'),
(76,'MOMRPCBB0LHJZM',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:50','2026-07-17 19:37:50',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:50'),
(77,'MOMRPCBGC7PQYJ',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:57','2026-07-17 19:37:57',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:57'),
(78,'MOMRPCBKJ1PIW6',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:38:02','2026-07-17 19:38:02',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:38:02'),
(79,'MOMRPCBM80JQSG',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-24 19:38:04','2026-07-17 19:38:04',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:38:04'),
(80,'MOMRPCI5IP95BS',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:09','2026-07-17 19:43:09',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:09'),
(81,'MOMRPCIA5NJQBB',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:15','2026-07-17 19:43:15',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:15'),
(82,'MOMRPCICWFJUQO',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:19','2026-07-17 19:43:19',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:19'),
(83,'MOMRPCIFZIUACF',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:23','2026-07-17 19:43:23',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:23'),
(84,'MOMRPCIIRCZ46L',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:27','2026-07-17 19:43:27',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:27'),
(85,'MOMRPCIN6G5QO3',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:32','2026-07-17 19:43:32',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:32');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `version` varchar(50) DEFAULT '1.0.0',
  `author` varchar(100) DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `entry_url` varchar(500) DEFAULT '',
  `component_name` varchar(200) DEFAULT '',
  `plugin_dir` varchar(100) DEFAULT '',
  `manifest` text DEFAULT NULL,
  `enabled` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `points_name` varchar(20) DEFAULT '金币',
  `tags` text DEFAULT NULL,
  `format` varchar(20) DEFAULT 'package',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES
(1,'SEO优化','内置SEO优化工具','1.0.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(2,'数据统计','网站数据统计分析','1.2.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(3,'广告管理','广告位管理插件','0.9.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(4,'第三方登录','支持微信/QQ/微博登录','2.0.1','','','','','',NULL,0,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(5,'地图组件','集成高德地图组件','1.1.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(6,'feature-panel','应用商店浏览页功能入口面板','1.0.0','Admin','','','','feature-panel','{\"name\":\"feature-panel\",\"version\":\"1.0.0\",\"description\":\"应用商店浏览页功能入口面板\",\"author\":\"Admin\",\"styles\":[\"styles/panel.css\"],\"scripts\":[\"scripts/panel.js\"],\"config\":{\"cardShow\":true,\"items\":[{\"label\":\"签到\",\"icon\":\"checkin\",\"color\":\"#FF6B35\",\"url\":\"/app/checkin\",\"show\":true},{\"label\":\"投稿\",\"icon\":\"submit\",\"color\":\"#3B82F6\",\"url\":\"/appstore/submissions\",\"show\":true},{\"label\":\"收藏\",\"icon\":\"fav\",\"color\":\"#EF4444\",\"url\":\"/appstore/favorites\",\"show\":true},{\"label\":\"排行\",\"icon\":\"rank\",\"color\":\"#EC4899\",\"url\":\"/appstore/category\",\"show\":true},{\"label\":\"交流群\",\"icon\":\"group\",\"color\":\"#22C55E\",\"url\":\"/community\",\"show\":true}],\"links\":[{\"label\":\"新贴\",\"url\":\"/community\",\"show\":true},{\"label\":\"发帖子\",\"url\":\"/community/create\",\"show\":true},{\"label\":\"热门话题\",\"url\":\"/community/hot\",\"show\":true}],\"banner\":{\"show\":true,\"text\":\"新手必看教程——发帖指引之基础篇\",\"url\":\"/help/guide\",\"closable\":true},\"mineBanner\":{\"show\":true,\"text\":\"全站规则，快来看看，不然就亏大了\",\"url\":\"https://monkeycode-ai.com/?ic=019f2c74-4064-7d7c-9003-743ce2df5af9\",\"closable\":false}},\"configMeta\":{\"cardShow\":{\"label\":\"图标卡片显示\"},\"items\":{\"label\":\"图标按钮\",\"itemMeta\":{\"label\":{\"label\":\"名称\"},\"icon\":{\"label\":\"图标\"},\"color\":{\"label\":\"颜色\"},\"url\":{\"label\":\"链接\"},\"show\":{\"label\":\"显示\"}}},\"links\":{\"label\":\"底部链接\",\"itemMeta\":{\"label\":{\"label\":\"文字\"},\"url\":{\"label\":\"链接\"},\"show\":{\"label\":\"显示\"}}},\"banner\":{\"label\":\"公告横幅\",\"childrenMeta\":{\"show\":{\"label\":\"显示\"},\"text\":{\"label\":\"文案\"},\"url\":{\"label\":\"链接\"},\"closable\":{\"label\":\"可关闭\"}}}}}',1,0,0,'金币',NULL,'package','1','2026-07-12 14:52:09');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_records`
--

DROP TABLE IF EXISTS `points_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `points` int(11) NOT NULL DEFAULT 0,
  `balance` int(11) DEFAULT 0,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_points_records_user_id` (`user_id`),
  KEY `idx_points_records_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_records`
--

LOCK TABLES `points_records` WRITE;
/*!40000 ALTER TABLE `points_records` DISABLE KEYS */;
INSERT INTO `points_records` VALUES
(1,13,'','checkin',53,0,'','获得积分 +53','2026-06-22 22:39:54',0,''),
(2,5,'','post',14,0,'','获得积分 +14','2026-06-11 22:39:54',0,''),
(3,13,'','comment',43,0,'','获得积分 +43','2026-07-08 22:39:54',0,''),
(4,8,'','invite',11,0,'','获得积分 +11','2026-07-08 22:39:54',0,''),
(5,15,'','purchase',21,0,'','获得积分 +21','2026-06-21 22:39:54',0,''),
(6,12,'','checkin',55,0,'','获得积分 +55','2026-06-11 22:39:54',0,''),
(7,15,'','post',11,0,'','获得积分 +11','2026-06-29 22:39:54',0,''),
(8,2,'','comment',19,0,'','获得积分 +19','2026-07-05 22:39:54',0,''),
(9,15,'','invite',23,0,'','获得积分 +23','2026-06-22 22:39:54',0,''),
(10,10,'','purchase',55,0,'','获得积分 +55','2026-07-10 22:39:54',0,''),
(11,15,'','checkin',34,0,'','获得积分 +34','2026-06-28 22:39:54',0,''),
(12,5,'','post',55,0,'','获得积分 +55','2026-06-12 22:39:54',0,''),
(13,5,'','comment',43,0,'','获得积分 +43','2026-06-13 22:39:54',0,''),
(14,10,'','invite',14,0,'','获得积分 +14','2026-06-19 22:39:54',0,''),
(15,11,'','purchase',47,0,'','获得积分 +47','2026-06-13 22:39:54',0,''),
(16,7,'','checkin',34,0,'','获得积分 +34','2026-06-23 22:39:54',0,''),
(17,2,'','post',22,0,'','获得积分 +22','2026-06-19 22:39:54',0,''),
(18,6,'','comment',11,0,'','获得积分 +11','2026-06-24 22:39:54',0,''),
(19,15,'','invite',12,0,'','获得积分 +12','2026-06-25 22:39:54',0,''),
(20,14,'','purchase',23,0,'','获得积分 +23','2026-06-26 22:39:54',0,''),
(21,3,'','checkin',15,0,'','获得积分 +15','2026-06-16 22:39:54',0,''),
(22,8,'','post',24,0,'','获得积分 +24','2026-06-14 22:39:54',0,''),
(23,6,'','comment',13,0,'','获得积分 +13','2026-06-19 22:39:54',0,''),
(24,13,'','invite',13,0,'','获得积分 +13','2026-07-01 22:39:54',0,''),
(25,4,'','purchase',19,0,'','获得积分 +19','2026-06-18 22:39:54',0,''),
(26,5,'','checkin',22,0,'','获得积分 +22','2026-07-04 22:39:54',0,''),
(27,12,'','post',44,0,'','获得积分 +44','2026-06-17 22:39:54',0,''),
(28,13,'','comment',44,0,'','获得积分 +44','2026-07-01 22:39:54',0,''),
(29,4,'','invite',53,0,'','获得积分 +53','2026-07-01 22:39:54',0,''),
(30,15,'','purchase',27,0,'','获得积分 +27','2026-06-22 22:39:54',0,''),
(31,19,'alexmorgan','earn',99999,99999,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得99999积分','2026-07-11 08:41:23',0,''),
(32,19,'alexmorgan','expense',1300,98699,'会员购买','购买黄金会员','2026-07-11 09:04:46',0,''),
(33,19,'alexmorgan','expense',1300,97399,'会员购买','购买黄金会员','2026-07-11 09:08:18',0,''),
(34,1,'bobwang','earn',50,1550,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:37:08',0,''),
(35,4,'design_master','earn',50,350,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:38:36',0,''),
(38,21,'testcoupon','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:43',0,''),
(39,21,'testcoupon','earn',50,700,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:53',0,''),
(40,22,'titletest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:07:31',0,''),
(41,23,'birthdaytest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:08:20',0,''),
(42,19,'alexmorgan','earn',50,96819,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 00:11:10',0,''),
(43,19,'alexmorgan','earn',320,97139,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:34:02',0,''),
(44,19,'alexmorgan','earn',120,97259,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:34:26',0,''),
(45,19,'alexmorgan','earn',120,97379,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:35:40',0,''),
(46,19,'alexmorgan','earn',50,97429,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 10:37:22',0,''),
(47,19,'alexmorgan','earn',50,97479,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 10:37:47',0,''),
(48,19,'alexmorgan','earn',10,97489,'每日签到','连续签到第1天','2026-07-12 11:19:10',0,''),
(49,19,'alexmorgan','expense',5800,91689,'会员购买','购买至尊会员','2026-07-12 11:21:02',0,''),
(50,19,'alexmorgan','earn',120,97609,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:02',0,''),
(51,19,'alexmorgan','expense',5800,86009,'会员购买','购买至尊会员','2026-07-12 11:21:07',0,''),
(52,19,'alexmorgan','earn',120,91929,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:07',0,''),
(53,19,'alexmorgan','expense',5800,80329,'会员购买','购买至尊会员','2026-07-12 11:21:13',0,''),
(54,19,'alexmorgan','earn',120,86249,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:13',0,''),
(55,19,'alexmorgan','earn',120,80569,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:15',0,''),
(56,1,'bobwang','earn',10,1560,'每日签到','连续签到第1天','2026-07-12 13:51:30',0,''),
(57,1,'bobwang','earn',10,1570,'每日签到','完成任务: 每日签到','2026-07-12 13:51:30',0,''),
(58,19,'alexmorgan','expense',1300,79269,'会员购买','购买黄金会员','2026-07-12 16:50:10',0,''),
(59,19,'alexmorgan','expense',1300,77969,'会员购买','购买黄金会员','2026-07-12 16:50:15',0,''),
(60,19,'alexmorgan','earn',120,78089,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:19',0,''),
(61,19,'alexmorgan','earn',120,78209,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:22',0,''),
(62,19,'alexmorgan','expense',5800,72409,'会员购买','购买至尊会员','2026-07-12 16:50:25',0,''),
(63,19,'alexmorgan','earn',120,78329,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:25',0,''),
(64,19,'alexmorgan','expense',5800,66729,'会员购买','购买至尊会员','2026-07-12 16:50:28',0,''),
(65,19,'alexmorgan','earn',120,72649,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:28',0,''),
(66,19,'alexmorgan','earn',120,66969,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:30',0,''),
(67,19,'alexmorgan','earn',120,67089,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:51:41',0,''),
(68,19,'alexmorgan','earn',120,67209,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:52:12',0,''),
(69,19,'','earn',30,67239,'完善资料','完成任务: 完善资料','2026-07-12 20:31:51',0,''),
(70,19,'alexmorgan','earn',100,67339,'会员开通赠送','开通钻石会员赠送积分','2026-07-12 20:36:22',0,''),
(71,19,'alexmorgan','earn',100,67439,'会员开通赠送','开通钻石会员赠送积分','2026-07-12 20:36:48',0,''),
(72,19,'alexmorgan','earn',120,67559,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 20:46:00',0,''),
(73,19,'alexmorgan','expense',5800,61759,'会员购买','购买至尊会员','2026-07-12 20:48:02',0,''),
(74,19,'alexmorgan','earn',120,67679,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 20:48:02',0,''),
(75,19,'alexmorgan','earn',5,61884,'评论互动','完成任务: 评论互动','2026-07-12 21:51:42',0,''),
(76,19,'alexmorgan','earn',120,62054,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 23:01:02',0,''),
(77,19,'Alex Morgan','earn',20,63174,'发帖奖励','完成任务: 发帖奖励','2026-07-13 18:34:40',0,''),
(78,19,'','earn',30,63204,'完善资料','完成任务: 完善资料','2026-07-13 19:42:23',0,''),
(79,19,'Alex Morgan','earn',20,63224,'发帖奖励','完成任务: 发帖奖励','2026-07-15 04:17:41',0,''),
(80,1,'bobwang','expense',100,1450,'内容购买','购买帖子 #21','2026-07-15 04:21:03',0,''),
(81,19,'Alex Morgan','earn',5,63229,'评论互动','完成任务: 评论互动','2026-07-15 04:26:15',0,''),
(82,10001,'35735712','earn',10000,10000,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 额外获得10000积分','2026-07-16 00:16:12',0,''),
(83,10001,'user_10001','earn',5,10005,'评论互动','完成任务: 评论互动','2026-07-16 00:17:34',0,''),
(84,10001,'35735712','expense',100,9905,'内容购买','购买帖子 #21','2026-07-16 00:17:36',0,''),
(85,19,'alexmorgan','earn',300,63529,'content_purchase','订单结算(3.0倍积分): 购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》','2026-07-16 00:19:39',71,'order_settle'),
(86,19,'Alex Morgan','earn',20,63549,'发帖奖励','完成任务: 发帖奖励','2026-07-16 16:40:43',0,''),
(87,10004,'管理员','earn',5,5,'评论互动','完成任务: 评论互动','2026-07-17 02:15:18',0,''),
(88,19,'alexmorgan','expense',980,62569,'商城购物','购买商品《移动端组件库》','2026-07-17 15:37:47',0,''),
(92,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:39:28',0,''),
(93,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:39:50',0,''),
(94,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:42:55',0,''),
(95,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:47:26',0,''),
(96,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:47:59',0,''),
(97,19,'alexmorgan','earn',49,62530,'推广返佣','mall #36 返佣','2026-07-17 18:47:59',0,''),
(98,19,'alexmorgan','earn',120,62650,'会员开通赠送','开通至尊会员赠送积分','2026-07-17 19:37:43',0,''),
(99,19,'alexmorgan','earn',100,62750,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:46',0,''),
(100,19,'alexmorgan','earn',100,62850,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:50',0,''),
(101,19,'alexmorgan','earn',100,62950,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:57',0,''),
(102,19,'alexmorgan','earn',50,63000,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:38:02',0,''),
(103,19,'alexmorgan','earn',120,63120,'会员开通赠送','开通至尊会员赠送积分','2026-07-17 19:38:04',0,''),
(104,19,'alexmorgan','earn',50,63170,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:43:09',0,''),
(105,19,'alexmorgan','earn',50,63220,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:43:15',0,''),
(106,19,'alexmorgan','earn',100,63320,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:23',0,''),
(107,19,'alexmorgan','earn',100,63420,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:27',0,''),
(108,19,'alexmorgan','earn',100,63520,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:32',0,'');
/*!40000 ALTER TABLE `points_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_transfer_records`
--

DROP TABLE IF EXISTS `points_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `fee` int(11) DEFAULT 0,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_transfer_records`
--

LOCK TABLES `points_transfer_records` WRITE;
/*!40000 ALTER TABLE `points_transfer_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `points_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_favorites`
--

DROP TABLE IF EXISTS `post_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`post_id`),
  KEY `idx_post_favorites_user` (`user_id`),
  KEY `idx_post_favorites_post` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_favorites`
--

LOCK TABLES `post_favorites` WRITE;
/*!40000 ALTER TABLE `post_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_messages`
--

DROP TABLE IF EXISTS `private_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '#448AFF',
  `to_user_id` int(11) NOT NULL,
  `content` text DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `image_url` varchar(500) DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `order_card` text DEFAULT NULL,
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `idx_private_messages_from` (`from_user_id`),
  KEY `idx_private_messages_to` (`to_user_id`),
  KEY `idx_private_messages_conversation` (`from_user_id`,`to_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_messages`
--

LOCK TABLES `private_messages` WRITE;
/*!40000 ALTER TABLE `private_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `private_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion_materials`
--

DROP TABLE IF EXISTS `promotion_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'poster',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_materials`
--

LOCK TABLES `promotion_materials` WRITE;
/*!40000 ALTER TABLE `promotion_materials` DISABLE KEYS */;
INSERT INTO `promotion_materials` VALUES
(1,'618年中大促','https://via.placeholder.com/800x400/FF6B35/fff?text=618','邀请好友注册即送100积分','poster','2026-07-17 17:39:08');
/*!40000 ALTER TABLE `promotion_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_amounts`
--

DROP TABLE IF EXISTS `recharge_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_amounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `label` varchar(100) DEFAULT '',
  `discount` varchar(100) DEFAULT '',
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_amounts`
--

LOCK TABLES `recharge_amounts` WRITE;
/*!40000 ALTER TABLE `recharge_amounts` DISABLE KEYS */;
INSERT INTO `recharge_amounts` VALUES
(5,10.00,'CRUD Test 10','',1,'2026-07-10 20:17:40');
/*!40000 ALTER TABLE `recharge_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_orders`
--

DROP TABLE IF EXISTS `recharge_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pay_method` varchar(20) DEFAULT 'epay',
  `status` varchar(20) DEFAULT 'pending',
  `trade_no` varchar(100) DEFAULT '',
  `paid_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recharge_orders_user` (`user_id`),
  KEY `idx_recharge_orders_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_orders`
--

LOCK TABLES `recharge_orders` WRITE;
/*!40000 ALTER TABLE `recharge_orders` DISABLE KEYS */;
INSERT INTO `recharge_orders` VALUES
(1,'RCH17837231939640',9,10.00,'epay','paid','','2026-07-09 22:39:53','2026-06-13 22:39:53'),
(2,'RCH17837231939651',5,30.00,'epay','paid','','2026-07-02 22:39:53','2026-06-21 22:39:53'),
(3,'RCH17837231939652',2,50.00,'epay','paid','','2026-07-09 22:39:53','2026-06-16 22:39:53'),
(4,'RCH17837231939663',6,98.00,'epay','paid','','2026-06-20 22:39:53','2026-06-26 22:39:53'),
(5,'RCH17837231939664',15,198.00,'epay','paid','','2026-07-06 22:39:53','2026-06-27 22:39:53'),
(6,'RCH17837231939665',8,298.00,'epay','paid','','2026-07-03 22:39:53','2026-07-04 22:39:53'),
(7,'RCH17837231939676',9,10.00,'epay','paid','','2026-06-24 22:39:53','2026-07-07 22:39:53'),
(8,'RCH17837231939677',6,30.00,'epay','paid','','2026-06-20 22:39:53','2026-06-14 22:39:53'),
(9,'RCH17837231939678',14,50.00,'epay','paid','','2026-07-06 22:39:53','2026-06-28 22:39:53'),
(10,'RCH17837231939689',15,98.00,'epay','pending','',NULL,'2026-06-24 22:39:53'),
(11,'RCH178372319396810',14,198.00,'epay','pending','',NULL,'2026-07-04 22:39:53'),
(12,'RCH178372319396911',4,298.00,'epay','pending','',NULL,'2026-06-21 22:39:53');
/*!40000 ALTER TABLE `recharge_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recycle_bin`
--

DROP TABLE IF EXISTS `recycle_bin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycle_bin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_table` varchar(100) NOT NULL,
  `original_id` int(11) NOT NULL,
  `data_json` text NOT NULL,
  `deleted_by` int(11) DEFAULT 0,
  `deleted_by_name` varchar(100) DEFAULT '',
  `delete_reason` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recycle_bin_table` (`original_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recycle_bin`
--

LOCK TABLES `recycle_bin` WRITE;
/*!40000 ALTER TABLE `recycle_bin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recycle_bin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_links`
--

DROP TABLE IF EXISTS `referral_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `mode` varchar(20) DEFAULT 'purchase',
  `discount` decimal(5,2) DEFAULT 0.00,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `purchase_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_referral_links_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_links`
--

LOCK TABLES `referral_links` WRITE;
/*!40000 ALTER TABLE `referral_links` DISABLE KEYS */;
INSERT INTO `referral_links` VALUES
(1,4,'REF-965vi41','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(2,9,'REF-t0omukq','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(4,14,'REF-rnrw7sk','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(5,15,'REF-bjco7s0','purchase',0.00,0,0,0,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `referral_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `auth_mark` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_auth` (`role_id`,`menu_id`,`auth_mark`)
) ENGINE=InnoDB AUTO_INCREMENT=1414 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1196,20,1,NULL),
(1197,20,2,NULL),
(1198,20,3,NULL),
(1199,20,4,NULL),
(1200,20,5,NULL),
(1201,20,6,NULL),
(1202,20,7,NULL),
(1203,20,8,NULL),
(1204,20,8,'add'),
(1205,20,8,'delete'),
(1206,20,8,'import'),
(1207,20,9,NULL),
(1208,20,9,'add'),
(1209,20,9,'delete'),
(1210,20,9,'edit'),
(1211,20,10,NULL),
(1212,20,10,'add'),
(1213,20,10,'delete'),
(1214,20,10,'edit'),
(1215,20,10,'toggle'),
(1216,20,11,NULL),
(1217,20,11,'adjust'),
(1218,20,11,'export'),
(1219,20,12,NULL),
(1220,20,12,'add'),
(1221,20,12,'delete'),
(1222,20,12,'edit'),
(1223,20,13,NULL),
(1224,20,13,'config'),
(1225,20,13,'delete'),
(1226,20,13,'toggle'),
(1227,20,13,'upload'),
(1228,20,14,NULL),
(1229,20,14,'add'),
(1230,20,14,'delete'),
(1231,20,14,'edit'),
(1232,20,15,NULL),
(1233,20,15,'add'),
(1234,20,15,'config'),
(1235,20,15,'delete'),
(1236,20,15,'edit'),
(1237,20,16,NULL),
(1238,20,16,'add'),
(1239,20,16,'delete'),
(1240,20,16,'edit'),
(1241,20,17,NULL),
(1242,20,17,'add'),
(1243,20,17,'delete'),
(1244,20,17,'edit'),
(1245,20,17,'toggle'),
(1246,20,18,NULL),
(1247,20,18,'add'),
(1248,20,18,'delete'),
(1249,20,18,'edit'),
(1250,20,18,'toggle'),
(1251,20,19,NULL),
(1252,20,19,'export'),
(1253,20,20,NULL),
(1254,20,20,'export'),
(1255,20,21,NULL),
(1256,20,21,'add'),
(1257,20,21,'delete'),
(1258,20,21,'edit'),
(1259,20,21,'reset'),
(1260,20,21,'toggle'),
(1261,20,22,NULL),
(1262,20,22,'add'),
(1263,20,22,'delete'),
(1264,20,22,'edit'),
(1265,20,23,NULL),
(1266,20,24,NULL),
(1267,20,24,'add'),
(1268,20,24,'delete'),
(1269,20,24,'edit'),
(1270,20,25,NULL),
(1271,20,25,'approve'),
(1272,20,25,'reject'),
(1273,20,26,NULL),
(1274,20,26,'approve'),
(1275,20,26,'reject'),
(1276,20,27,NULL),
(1277,20,27,'add'),
(1278,20,27,'delete'),
(1279,20,27,'generate'),
(1280,20,28,NULL),
(1281,20,28,'edit'),
(1282,20,28,'test'),
(1283,20,29,NULL),
(1284,20,29,'delete'),
(1285,20,30,NULL),
(1286,20,30,'delete'),
(1287,20,30,'restore'),
(1288,20,31,NULL),
(1289,20,31,'clear'),
(1290,20,31,'export'),
(1291,20,32,NULL),
(1292,20,32,'edit'),
(1293,20,33,NULL),
(1294,20,33,'add'),
(1295,20,33,'delete'),
(1296,20,33,'edit'),
(1297,20,33,'toggle'),
(1298,20,34,NULL),
(1299,20,34,'add'),
(1300,20,34,'delete'),
(1301,20,34,'edit'),
(1302,20,34,'toggle'),
(1303,20,35,NULL),
(1304,20,35,'edit'),
(1305,20,35,'toggle'),
(1306,20,36,NULL),
(1307,20,36,'add'),
(1308,20,36,'delete'),
(1309,20,36,'edit'),
(1310,20,37,NULL),
(1311,20,37,'approve'),
(1312,20,37,'delete'),
(1313,20,37,'edit'),
(1314,20,37,'reject'),
(1315,20,37,'toggle'),
(1316,20,38,NULL),
(1317,20,39,NULL),
(1318,20,39,'add'),
(1319,20,39,'delete'),
(1320,20,39,'edit'),
(1321,20,40,NULL),
(1322,20,40,'delete'),
(1323,20,40,'handle'),
(1324,20,40,'ignore'),
(1325,20,44,NULL),
(1326,20,44,'add'),
(1327,20,44,'delete'),
(1328,20,44,'edit'),
(1329,20,45,NULL),
(1330,20,45,'add'),
(1331,20,45,'delete'),
(1332,20,45,'edit'),
(1333,20,45,'moderate'),
(1334,20,45,'toggle'),
(1335,20,45,'unlock'),
(1336,20,46,NULL),
(1337,20,46,'approve'),
(1338,20,46,'boost'),
(1339,20,46,'delete'),
(1340,20,46,'edit'),
(1341,20,46,'essence'),
(1342,20,46,'lock'),
(1343,20,46,'pin'),
(1344,20,47,NULL),
(1345,20,47,'delete'),
(1346,20,47,'handle'),
(1347,20,47,'ignore'),
(1348,20,48,NULL),
(1349,20,48,'delete'),
(1350,20,48,'pin'),
(1351,20,49,NULL),
(1352,20,50,NULL),
(1353,20,51,NULL),
(1354,20,52,NULL),
(1355,20,53,NULL),
(1356,20,54,NULL),
(1357,20,54,'delete'),
(1358,20,54,'download'),
(1359,20,54,'upload'),
(1360,20,55,NULL),
(1361,20,55,'add'),
(1362,20,55,'delete'),
(1363,20,55,'edit'),
(1364,20,57,NULL),
(1365,20,57,'add'),
(1366,20,57,'delete'),
(1367,20,57,'edit'),
(1368,20,57,'toggle'),
(1369,20,58,NULL),
(1370,20,58,'edit'),
(1371,20,58,'export'),
(1372,20,58,'handle'),
(1373,20,58,'view'),
(1374,20,59,NULL),
(1375,20,59,'add'),
(1376,20,59,'delete'),
(1377,20,59,'edit'),
(1378,20,60,NULL),
(1379,20,60,'edit'),
(1380,20,60,'handle'),
(1381,20,60,'view'),
(1382,20,61,NULL),
(1383,20,61,'add'),
(1384,20,61,'delete'),
(1385,20,61,'edit'),
(1386,20,61,'toggle'),
(1387,20,62,NULL),
(1388,20,62,'add'),
(1389,20,62,'delete'),
(1390,20,62,'edit'),
(1391,20,62,'toggle'),
(1392,20,63,NULL),
(1393,20,63,'add'),
(1394,20,63,'delete'),
(1395,20,63,'edit'),
(1396,20,64,NULL),
(1397,20,64,'add'),
(1398,20,64,'delete'),
(1399,20,64,'edit'),
(1400,20,65,NULL),
(1401,20,65,'edit'),
(1402,20,66,NULL),
(1403,20,66,'add'),
(1404,20,66,'delete'),
(1405,20,66,'edit'),
(1406,20,67,NULL),
(1407,20,67,'edit'),
(1408,20,68,NULL),
(1409,20,68,'add'),
(1410,20,68,'delete'),
(1411,20,69,'add'),
(1412,20,69,'delete'),
(1413,20,69,'edit'),
(984,22,1,NULL),
(985,22,2,NULL),
(986,22,3,NULL),
(987,22,4,NULL),
(988,22,5,NULL),
(989,22,6,NULL),
(990,22,7,NULL),
(991,22,8,NULL),
(992,22,8,'add'),
(993,22,8,'delete'),
(994,22,8,'import'),
(995,22,9,NULL),
(996,22,9,'add'),
(998,22,9,'delete'),
(997,22,9,'edit'),
(999,22,10,NULL),
(1000,22,10,'add'),
(1002,22,10,'delete'),
(1001,22,10,'edit'),
(1003,22,10,'toggle'),
(1004,22,11,NULL),
(1005,22,11,'adjust'),
(1006,22,11,'export'),
(1007,22,12,NULL),
(1008,22,12,'add'),
(1010,22,12,'delete'),
(1009,22,12,'edit'),
(1011,22,13,NULL),
(1014,22,13,'config'),
(1015,22,13,'delete'),
(1013,22,13,'toggle'),
(1012,22,13,'upload'),
(1016,22,14,NULL),
(1017,22,14,'add'),
(1019,22,14,'delete'),
(1018,22,14,'edit'),
(1020,22,15,NULL),
(1021,22,15,'add'),
(1024,22,15,'config'),
(1023,22,15,'delete'),
(1022,22,15,'edit'),
(1025,22,16,NULL),
(1026,22,16,'add'),
(1028,22,16,'delete'),
(1027,22,16,'edit'),
(1029,22,17,NULL),
(1030,22,17,'add'),
(1032,22,17,'delete'),
(1031,22,17,'edit'),
(1033,22,17,'toggle'),
(1034,22,18,NULL),
(1035,22,18,'add'),
(1037,22,18,'delete'),
(1036,22,18,'edit'),
(1038,22,18,'toggle'),
(1039,22,19,NULL),
(1040,22,19,'export'),
(1041,22,20,NULL),
(1042,22,20,'export'),
(1043,22,21,NULL),
(1044,22,21,'add'),
(1046,22,21,'delete'),
(1045,22,21,'edit'),
(1048,22,21,'reset'),
(1047,22,21,'toggle'),
(1049,22,22,NULL),
(1050,22,22,'add'),
(1052,22,22,'delete'),
(1051,22,22,'edit'),
(1053,22,23,NULL),
(1054,22,24,NULL),
(1055,22,24,'add'),
(1057,22,24,'delete'),
(1056,22,24,'edit'),
(1058,22,25,NULL),
(1059,22,25,'approve'),
(1060,22,25,'reject'),
(1061,22,26,NULL),
(1062,22,26,'approve'),
(1063,22,26,'reject'),
(1064,22,27,NULL),
(1065,22,27,'add'),
(1067,22,27,'delete'),
(1066,22,27,'generate'),
(1068,22,28,NULL),
(1069,22,28,'edit'),
(1070,22,28,'test'),
(1071,22,29,NULL),
(1072,22,29,'delete'),
(1073,22,30,NULL),
(1075,22,30,'delete'),
(1074,22,30,'restore'),
(1076,22,31,NULL),
(1078,22,31,'clear'),
(1077,22,31,'export'),
(1079,22,32,NULL),
(1080,22,32,'edit'),
(1081,22,33,NULL),
(1082,22,33,'add'),
(1084,22,33,'delete'),
(1083,22,33,'edit'),
(1085,22,33,'toggle'),
(1086,22,34,NULL),
(1087,22,34,'add'),
(1089,22,34,'delete'),
(1088,22,34,'edit'),
(1090,22,34,'toggle'),
(1091,22,35,NULL),
(1092,22,35,'edit'),
(1093,22,35,'toggle'),
(1094,22,36,NULL),
(1095,22,36,'add'),
(1097,22,36,'delete'),
(1096,22,36,'edit'),
(1098,22,37,NULL),
(1099,22,37,'approve'),
(1102,22,37,'delete'),
(1101,22,37,'edit'),
(1100,22,37,'reject'),
(1103,22,37,'toggle'),
(1104,22,38,NULL),
(1105,22,39,NULL),
(1106,22,39,'add'),
(1108,22,39,'delete'),
(1107,22,39,'edit'),
(1109,22,40,NULL),
(1112,22,40,'delete'),
(1110,22,40,'handle'),
(1111,22,40,'ignore'),
(1113,22,44,NULL),
(1114,22,44,'add'),
(1116,22,44,'delete'),
(1115,22,44,'edit'),
(1117,22,45,NULL),
(1118,22,45,'add'),
(1120,22,45,'delete'),
(1119,22,45,'edit'),
(1121,22,45,'moderate'),
(1122,22,45,'toggle'),
(1123,22,45,'unlock'),
(1124,22,46,NULL),
(1129,22,46,'approve'),
(1127,22,46,'boost'),
(1131,22,46,'delete'),
(1130,22,46,'edit'),
(1126,22,46,'essence'),
(1128,22,46,'lock'),
(1125,22,46,'pin'),
(1132,22,47,NULL),
(1135,22,47,'delete'),
(1133,22,47,'handle'),
(1134,22,47,'ignore'),
(1136,22,48,NULL),
(1138,22,48,'delete'),
(1137,22,48,'pin'),
(1139,22,49,NULL),
(1140,22,50,NULL),
(1141,22,51,NULL),
(1142,22,52,NULL),
(1143,22,53,NULL),
(1144,22,54,NULL),
(1145,22,55,NULL),
(1146,22,55,'add'),
(1148,22,55,'delete'),
(1147,22,55,'edit'),
(1149,22,56,NULL),
(1150,22,57,NULL),
(1151,22,57,'add'),
(1153,22,57,'delete'),
(1152,22,57,'edit'),
(1154,22,58,NULL),
(1156,22,58,'handle'),
(1155,22,58,'view'),
(1157,22,59,NULL),
(1158,22,59,'add'),
(1160,22,59,'delete'),
(1159,22,59,'edit'),
(1161,22,60,NULL),
(1163,22,60,'handle'),
(1162,22,60,'view'),
(1164,22,61,NULL),
(1165,22,61,'add'),
(1167,22,61,'delete'),
(1166,22,61,'edit'),
(1168,22,62,NULL),
(1169,22,62,'add'),
(1171,22,62,'delete'),
(1170,22,62,'edit'),
(1172,22,62,'toggle'),
(1173,22,63,NULL),
(1174,22,63,'add'),
(1176,22,63,'delete'),
(1175,22,63,'edit'),
(1177,22,64,NULL),
(1178,22,64,'add'),
(1180,22,64,'delete'),
(1179,22,64,'edit'),
(1181,22,65,NULL),
(1182,22,65,'edit'),
(1183,22,66,NULL),
(1184,22,66,'add'),
(1186,22,66,'delete'),
(1185,22,66,'edit'),
(1187,22,67,NULL),
(1188,22,67,'edit'),
(1189,22,68,NULL),
(1190,22,68,'delete'),
(1191,22,68,'download'),
(1192,22,69,NULL),
(1193,22,69,'add'),
(1195,22,69,'delete'),
(1194,22,69,'edit');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_code` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `community_moderator` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(20,'管理员','R_ADMIN','系统管理员',1,1,'2026-07-10 22:42:45'),
(21,'普通用户','R_USER','普通用户',1,0,'2026-07-10 22:42:45'),
(22,'系统超级管理员','R_SUPER','系统超级管理员',1,1,'2026-07-11 12:47:10'),
(23,'版主','R_MODERATOR','社区版主',1,1,'2026-07-16 17:22:00'),
(24,'审核员','R_REVIEWER','社区审核员',1,1,'2026-07-16 17:22:00');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_moderators`
--

DROP TABLE IF EXISTS `section_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_moderators`
--

LOCK TABLES `section_moderators` WRITE;
/*!40000 ALTER TABLE `section_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_words`
--

DROP TABLE IF EXISTS `sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `category` varchar(20) DEFAULT 'general',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_words`
--

LOCK TABLES `sensitive_words` WRITE;
/*!40000 ALTER TABLE `sensitive_words` DISABLE KEYS */;
INSERT INTO `sensitive_words` VALUES
(1,'广告推广','text',1,'2026-07-10 22:39:54'),
(2,'虚假信息','text',1,'2026-07-10 22:39:54'),
(3,'恶意攻击','text',1,'2026-07-10 22:39:54'),
(4,'非法内容','text',1,'2026-07-10 22:39:54'),
(5,'侵权内容','text',1,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `token` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `roles` text DEFAULT '[]',
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('1eafc80cd6ec418cafae742421a36155',1,'bobwang','[\"R_USER\"]',1784034714473),
('2fa-mrob0dzv-1c6hqp5n',1,'bobwang','[\"R_USER\"]',1784254415323),
('2fa-mrob0jrm-sdk1dqvg',1,'bobwang','[\"R_USER\"]',1784254422802),
('2fa-mrp2icve-r5szenut',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784300603307),
('2fa-mrp2iga8-pcx8b10z',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784300607728),
('7df985d62c184b888ce2b999161e8ecd',2,'lisa_chen','[\"R_USER\"]',1784037620908),
('cb92d37541894f06b5fdbb021a0288a4',2,'lisa_chen','[\"R_USER\"]',1784037423584),
('d99d5735ccb74f7b814567a96478b91c',2,'lisa_chen','[\"R_USER\"]',1784039037495),
('dc68e2b1688c495c8ff6eb31c9486856',2,'lisa_chen','[\"R_USER\"]',1784034885371),
('e6e1e86d04a84429a1e1fb4af45eb471',19,'alexmorgan','[\"R_SUPER\"]',1784034714473),
('tk-mrfk5okg-129851np',19,'alexmorgan','[\"R_SUPER\"]',1783725583264),
('tk-mrg46qdb-szhx7sqc',19,'alexmorgan','[\"R_SUPER\"]',1783759224575),
('tk-mrgad3qw-rnrp4va8',19,'alexmorgan','[\"R_SUPER\"]',1783769599544),
('tk-mrgc0orx-p0nsa89s',1,'bobwang','[\"R_USER\"]',1783772379501),
('tk-mrgc0ow4-uotcfq2l',3,'tech_guru','[\"R_USER\"]',1783772379652),
('tk-mrgc0p08-pqa1qoo4',4,'design_master','[\"R_USER\"]',1783772379800),
('tk-mrgchwgo-dz58oa1n',19,'alexmorgan','[\"R_SUPER\"]',1783773182616),
('tk-mrgcjyhh-sja3mo7z',19,'alexmorgan','[\"R_SUPER\"]',1783773278549),
('tk-mrgcnsb3-t3h6lw3t',19,'alexmorgan','[\"R_SUPER\"]',1783773457167),
('tk-mrgcpony-68g949q2',19,'alexmorgan','[\"R_SUPER\"]',1783773545758),
('tk-mrgcpzf7-n662s75k',19,'alexmorgan','[\"R_SUPER\"]',1783773559699),
('tk-mrgcq6mv-8z38m2ei',19,'alexmorgan','[\"R_SUPER\"]',1783773569047),
('tk-mrgcsjbk-m4hsv33u',19,'alexmorgan','[\"R_SUPER\"]',1783773678800),
('tk-mrgd3k5l-hmyipn7o',19,'alexmorgan','[\"R_SUPER\"]',1783774193097),
('tk-mrgd6163-xfdq1u97',19,'alexmorgan','[\"R_SUPER\"]',1783774308459),
('tk-mrgjd87i-58ot74sd',19,'alexmorgan','[\"R_SUPER\"]',1783784721870),
('tk-mrgjdea1-cpg9s9kk',19,'alexmorgan','[\"R_SUPER\"]',1783784729737),
('tk-mrgje0bo-4vdtv9wd',19,'alexmorgan','[\"R_SUPER\"]',1783784758308),
('tk-mrgskq3c-h4w2r8p4',19,'alexmorgan','[\"R_SUPER\"]',1783800188184),
('tk-mrgstn55-tt0eerxs',1,'bobwang','[\"R_USER\"]',1783800604265),
('tk-mrgsvtp9-tgtvzqn3',19,'alexmorgan','[\"R_SUPER\"]',1783800706077),
('tk-mrgtrv11-a5zppgie',19,'alexmorgan','[\"R_SUPER\"]',1783802200789),
('tk-mrgts99p-vma1ciui',1,'bobwang','[\"R_USER\"]',1783802219245),
('tk-mrgtucc7-1xz6xtv9',4,'design_master','[\"R_USER\"]',1783802316535),
('tk-mrgtuu63-8c5iku9t',20,'testgift','[]',1783802339643),
('tk-mrgu69ep-98uq3tzm',19,'alexmorgan','[\"R_SUPER\"]',1783802872609),
('tk-mrgu6lr1-5roepkbp',21,'testcoupon','[]',1783802888605),
('tk-mrgu6xgw-746zygcl',21,'testcoupon','[]',1783802903792),
('tk-mrgu8mog-a4nbvjy0',21,'testcoupon','[]',1783802983120),
('tk-mrgu8usw-rh8mlgoa',21,'testcoupon','[]',1783802993648),
('tk-mrguv54m-whr72x3e',19,'alexmorgan','[\"R_SUPER\"]',1783804033462),
('tk-mrguvbql-q0tsuz5j',22,'titletest','[]',1783804042029),
('tk-mrguvivz-6iwhngeh',22,'titletest','[]',1783804051295),
('tk-mrguwd7a-9ktuzfyp',22,'titletest','[]',1783804090582),
('tk-mrguwl7b-gv9tg7jt',23,'birthdaytest','[]',1783804100951),
('tk-mrguzcqy-esg4s3id',23,'birthdaytest','[]',1783804229962),
('tk-mrgvakky-j0i1gyj2',19,'alexmorgan','[\"R_SUPER\"]',1783804753330),
('tk-mrgwwogp-n5paqkpk',19,'alexmorgan','[\"R_SUPER\"]',1783807464409),
('tk-mrh16338-qbd0g9g6',19,'alexmorgan','[\"R_SUPER\"]',1783814621732),
('tk-mrh185ch-oayzmdi1',1,'bobwang','[\"R_USER\"]',1783814717969),
('tk-mrh23uv4-5cohapg8',19,'alexmorgan','[\"R_SUPER\"]',1783816197377),
('tk-mrh711lj-pz1iqkbe',19,'alexmorgan','[\"R_SUPER\"]',1783824464215),
('tk-mrh7czzy-rykk5w4b',1,'bobwang','[\"R_USER\"]',1783825022014),
('tk-mrh7d98a-t5h0d143',1,'bobwang','[\"R_USER\"]',1783825033978),
('tk-mrh7d9bd-a1u7de3u',2,'lisa_chen','[\"R_USER\"]',1783825034089),
('tk-mrh7hn20-d0hoxp4d',1,'bobwang','[\"R_USER\"]',1783825238520),
('tk-mrh7m729-gnizj7pl',1,'bobwang','[\"R_USER\"]',1783825451073),
('tk-mrh7nmyb-y8xdvqbk',1,'bobwang','[\"R_USER\"]',1783825518323),
('tk-mrh81vp3-hkvdsmuj',1,'bobwang','[\"R_USER\"]',1783826182839),
('tk-mrh86kp3-8v7j3txx',1,'bobwang','[\"R_USER\"]',1783826401863),
('tk-mrhijcil-ua6l9ulj',1,'bobwang','[\"R_USER\"]',1783843793949),
('tk-mrhjkkut-2b2wzuzy',1,'bobwang','[\"R_USER\"]',1783845531029),
('tk-mrhjkvhl-7ckkrp8w',1,'bobwang','[\"R_USER\"]',1783845544809),
('tk-mrhjl91d-2fa2mclr',1,'bobwang','[\"R_USER\"]',1783845562369),
('tk-mrhjll17-b1rzt2b3',1,'bobwang','[\"R_USER\"]',1783845577915),
('tk-mrhjm8qq-zhs97kcl',1,'bobwang','[\"R_USER\"]',1783845608642),
('tk-mrhjmi96-gldyh1nq',19,'alexmorgan','[\"R_SUPER\"]',1783845620970),
('tk-mrhjn32t-x8vws6e5',1,'bobwang','[\"R_USER\"]',1783845647957),
('tk-mrhjnc9f-i0w4l3on',19,'alexmorgan','[\"R_SUPER\"]',1783845659859),
('tk-mrhjncgs-n2b1u8aw',1,'bobwang','[\"R_USER\"]',1783845660124),
('tk-mrhjnp9e-w0v3odoc',1,'bobwang','[\"R_USER\"]',1783845676706),
('tk-mrhjnzbq-9uzv4am0',19,'alexmorgan','[\"R_SUPER\"]',1783845689750),
('tk-mrhjohmz-7trp2ig3',1,'bobwang','[\"R_USER\"]',1783845713484),
('tk-mrhjvyfw-j46vyzta',1,'bobwang','[\"R_USER\"]',1783846061852),
('tk-mrhjwobr-j7t1d8xm',1,'bobwang','[\"R_USER\"]',1783846095399),
('tk-mrhjxgkd-42cd76pv',19,'alexmorgan','[\"R_SUPER\"]',1783846131997),
('tk-mrhkhy5x-j74hcico',19,'alexmorgan','[\"R_SUPER\"]',1783847087926),
('tk-mrhl4ytd-kysze6m0',19,'alexmorgan','[\"R_SUPER\"]',1783848161857),
('tk-mrhlcr0g-xbd37u6h',1,'bobwang','[\"R_USER\"]',1783848524992),
('tk-mrhlcw6m-3ifo1fpb',1,'bobwang','[\"R_USER\"]',1783848531694),
('tk-mrhle08a-h6w4ypnt',19,'alexmorgan','[\"R_SUPER\"]',1783848583594),
('tk-mrhm0w7y-5ncf7md0',19,'alexmorgan','[\"R_SUPER\"]',1783849651487),
('tk-mrhmw6sd-8elu4ucx',19,'alexmorgan','[\"R_SUPER\"]',1783851111517),
('tk-mrhnh13n-zemoxe5n',19,'alexmorgan','[\"R_SUPER\"]',1783852083923),
('tk-mrhq4dux-eduq76id',19,'alexmorgan','[\"R_SUPER\"]',1783856532777),
('tk-mrhsctj4-vx2j9fzc',19,'alexmorgan','[\"R_SUPER\"]',1783860285569),
('tk-mrhuhqgm-zsfy5s04',19,'alexmorgan','[\"R_SUPER\"]',1783863874103),
('tk-mrhuqnf2-cjn6s466',1,'bobwang','[\"R_USER\"]',1783864290062),
('tk-mrhvnwr3-9sig8nc2',1,'bobwang','[\"R_USER\"]',1783865841807),
('tk-mrhvp7b4-tv8tfvif',1,'bobwang','[\"R_USER\"]',1783865902144),
('tk-mrhvpczq-0u6bg3e4',19,'alexmorgan','[\"R_SUPER\"]',1783865909510),
('tk-mrhx7vjt-70ca5jwe',19,'alexmorgan','[\"R_SUPER\"]',1783868452985),
('tk-mrhxxaub-ta0denlp',1,'bobwang','[\"R_USER\"]',1783869639203),
('tk-mrhy3qnp-jtycgwtv',19,'alexmorgan','[\"R_SUPER\"]',1783869939637),
('tk-mrhz260i-40bk7jpu',19,'alexmorgan','[\"R_SUPER\"]',1783871545842),
('tk-mri4jl5b-cy2duf71',19,'alexmorgan','[\"R_SUPER\"]',1783880756687),
('tk-mri720d1-619pfy5e',19,'alexmorgan','[\"R_SUPER\"]',1783884975445),
('tk-mri727dn-y4aritup',19,'alexmorgan','[\"R_SUPER\"]',1783884984539),
('tk-mri7dlny-1jn4jtj7',19,'alexmorgan','[\"R_SUPER\"]',1783885516270),
('tk-mri7dq6x-070gypr1',19,'alexmorgan','[\"R_SUPER\"]',1783885522137),
('tk-mri7g0t2-5kiu1mnb',19,'alexmorgan','[\"R_SUPER\"]',1783885629206),
('tk-mri7nu0a-wp8mt16y',19,'alexmorgan','[\"R_SUPER\"]',1783885993642),
('tk-mri7odht-0butrf8q',19,'alexmorgan','[\"R_SUPER\"]',1783886018897),
('tk-mri7rjoy-98ke205m',19,'alexmorgan','[\"R_SUPER\"]',1783886166898),
('tk-mri8738l-euqhq0j4',19,'alexmorgan','[\"R_SUPER\"]',1783886892069),
('tk-mri87y40-8jmqxye9',19,'alexmorgan','[\"R_SUPER\"]',1783886932081),
('tk-mri882fr-b78mncwj',19,'alexmorgan','[\"R_SUPER\"]',1783886937687),
('tk-mri8u3j5-1tt037i7',19,'alexmorgan','[\"R_SUPER\"]',1783887965537),
('tk-mri90fgb-myg3qoio',19,'alexmorgan','[\"R_SUPER\"]',1783888260923),
('tk-mri90jnn-mf30kpla',19,'alexmorgan','[\"R_SUPER\"]',1783888266371),
('tk-mri915np-gn3hjlro',19,'alexmorgan','[\"R_SUPER\"]',1783888294885),
('tk-mri919el-gh0zbeqo',19,'alexmorgan','[\"R_SUPER\"]',1783888299741),
('tk-mri91edh-mu75r9hs',19,'alexmorgan','[\"R_SUPER\"]',1783888306181),
('tk-mri91hs8-uyl7mvrs',19,'alexmorgan','[\"R_SUPER\"]',1783888310600),
('tk-mri937n5-7dblabg9',19,'alexmorgan','[\"R_SUPER\"]',1783888390769),
('tk-mri9935f-n673updo',19,'alexmorgan','[\"R_SUPER\"]',1783888664883),
('tk-mri9dw48-jwp1824g',19,'alexmorgan','[\"R_SUPER\"]',1783888889048),
('tk-mri9fzos-iho4d0t2',19,'alexmorgan','[\"R_SUPER\"]',1783888986989),
('tk-mri9hzb2-hjhnkhfx',19,'alexmorgan','[\"R_SUPER\"]',1783889079806),
('tk-mria1k2h-8v7zzplt',19,'alexmorgan','[\"R_SUPER\"]',1783889993177),
('tk-mriad2ud-6obqaxnv',19,'alexmorgan','[\"R_SUPER\"]',1783890530725),
('tk-mriamxtl-grjxq8wc',19,'alexmorgan','[\"R_SUPER\"]',1783890990777),
('tk-mrifoelr-xekdhe7e',19,'alexmorgan','[\"R_SUPER\"]',1783899457263),
('tk-mrj2pat9-xnsc3zrb',19,'alexmorgan','[\"R_SUPER\"]',1783938130173),
('tk-mrj4jfk1-2vwncww6',19,'alexmorgan','[\"R_SUPER\"]',1783941215617),
('tk-mrj5buxe-0s2s0v5w',19,'alexmorgan','[\"R_SUPER\"]',1783942541906),
('tk-mrj85jzg-g1f0j2jj',19,'alexmorgan','[\"R_SUPER\"]',1783947286636),
('tk-mrj8blxu-5ko5dlpx',19,'alexmorgan','[\"R_SUPER\"]',1783947569106),
('tk-mrjatbmf-84kdx4ok',19,'alexmorgan','[\"R_SUPER\"]',1783951754775),
('tk-mrjb92l1-iexgoei6',19,'alexmorgan','[\"R_SUPER\"]',1783952489557),
('tk-mrjg62ra-inq40n5m',19,'alexmorgan','[\"R_SUPER\"]',1783960747895),
('tk-mrjk5fmr-2yrjaba6',19,'alexmorgan','[\"R_SUPER\"]',1783967436387),
('tk-mrjlb37x-dwbkgwu9',19,'alexmorgan','[\"R_SUPER\"]',1783969379853),
('tk-mrjmjo9d-ity5y86v',19,'alexmorgan','[\"R_SUPER\"]',1783971459985),
('tk-mrjpnqcc-n17i9ewv',19,'alexmorgan','[\"R_SUPER\"]',1783976688156),
('tk-mrjr29iu-e0ou3lm8',19,'alexmorgan','[\"R_SUPER\"]',1783979045815),
('tk-mrjr2g2l-boeund8b',19,'alexmorgan','[\"R_SUPER\"]',1783979054301),
('tk-mrjvnfyn-whodqxd0',19,'alexmorgan','[\"R_SUPER\"]',1783986752399),
('tk-mrkgttmx-by5fo0d2',19,'alexmorgan','[\"R_SUPER\"]',1784022321993),
('tk-mrkimsyl-zeq9mtwf',19,'alexmorgan','[\"R_SUPER\"]',1784025353757),
('tk-mrkmfqeo-yfh0xbzq',19,'alexmorgan','[\"R_SUPER\"]',1784031742320),
('tk-mrknrkgz-5u8gl1xx',19,'alexmorgan','[\"R_SUPER\"]',1784033974115),
('tk-mrkprjs1-z1vj79iv',1,'bobwang','[\"R_USER\"]',1784037332449),
('tk-mrkpxk9v-n8qetfpd',1,'bobwang','[\"R_USER\"]',1784037613027),
('tk-mrkqs3as-kxlv22mx',1,'bobwang','[\"R_USER\"]',1784039037364),
('tk-mrksniad-764y70v3',19,'alexmorgan','[\"R_SUPER\"]',1784042182741),
('tk-mrktbu91-s0n4568q',10001,'35735712','[]',1784043317989),
('tk-mrktcj1t-4xsbah46',10001,'35735712','[]',1784043350129),
('tk-mrlbw0p0-iw0xcyzm',19,'alexmorgan','[\"R_SUPER\"]',1784074492548),
('tk-mrlbw4ra-e02jw8fk',19,'alexmorgan','[\"R_SUPER\"]',1784074497814),
('tk-mrlk7jh7-j15wlw80',19,'alexmorgan','[\"R_SUPER\"]',1784088467035),
('tk-mrlkgbdc-qvpi062t',19,'alexmorgan','[\"R_SUPER\"]',1784088876432),
('tk-mrlkik53-ziw6js2x',19,'alexmorgan','[\"R_SUPER\"]',1784088981111),
('tk-mrlkoaqv-amck7yfp',1,'bobwang','[\"R_USER\"]',1784089248872),
('tk-mrll4kt2-xz29xbtr',1,'bobwang','[\"R_USER\"]',1784090008407),
('tk-mrll4rrx-efl4t1oz',1,'bobwang','[\"R_USER\"]',1784090017437),
('tk-mrllkxd3-1bn7yuas',10001,'35735712','[]',1784090771175),
('tk-mrlnfi5y-1m2rmua3',19,'alexmorgan','[\"R_SUPER\"]',1784093877431),
('tk-mrlq6b02-5c6xtvto',10001,'35735712','[]',1784098487090),
('tk-mrlyh912-s82xze3n',19,'alexmorgan','[\"R_SUPER\"]',1784112434678),
('tk-mrm3egmo-x0d5heyl',19,'alexmorgan','[\"R_SUPER\"]',1784120702641),
('tk-mrmbh8zt-38uqtjtr',10001,'35735712','[]',1784134269641),
('tk-mrmfckdi-2jhxj5rl',19,'alexmorgan','[\"R_SUPER\"]',1784140769574),
('tk-mrmq7uo2-mc9mge1i',19,'alexmorgan','[\"R_SUPER\"]',1784159025410),
('tk-mrmq8w5h-4r2shda1',19,'alexmorgan','[\"R_SUPER\"]',1784159073989),
('tk-mrmrb46m-m1z5h1di',10001,'35735712','[]',1784160857326),
('tk-mrmrgqlo-fr6dj25l',10001,'35735712','[]',1784161119660),
('tk-mrmrhh2i-edev3lqg',10001,'35735712','[]',1784161153962),
('tk-mrmsgel9-6rjp0h5p',19,'alexmorgan','[\"R_SUPER\"]',1784162783709),
('tk-mrmtbpjx-gp4txmuk',1,'bobwang','[\"R_USER\"]',1784164244253),
('tk-mrmtbpmk-ecwqa1un',19,'alexmorgan','[\"R_SUPER\"]',1784164244348),
('tk-mrmtbs4z-nkk9pmk8',1,'bobwang','[\"R_USER\"]',1784164247603),
('tk-mrmtbvd3-sxc5k8rk',1,'bobwang','[\"R_USER\"]',1784164251783),
('tk-mrmtbvfv-e9kzxixe',19,'alexmorgan','[\"R_SUPER\"]',1784164251883),
('tk-mrmtdn2r-lr2jca7a',1,'bobwang','[\"R_USER\"]',1784164334355),
('tk-mrmtdn5h-lgd6oc0v',19,'alexmorgan','[\"R_SUPER\"]',1784164334453),
('tk-mrmtx0kv-qgiupvv5',1,'bobwang','[\"R_USER\"]',1784165238319),
('tk-mrmtx0o5-xhi1qnd0',19,'alexmorgan','[\"R_SUPER\"]',1784165238437),
('tk-mrmtxtw6-duh63vr0',1,'bobwang','[\"R_USER\"]',1784165276310),
('tk-mrmzknax-gtsjfnc8',1,'bobwang','[\"R_USER\"]',1784174738937),
('tk-mrndwb59-amk3hdtu',1,'bobwang','[\"R_USER\"]',1784198797677),
('tk-mrndxtcl-y2sa7dnc',1,'bobwang','[\"R_USER\"]',1784198867925),
('tk-mrndxyco-89r09qco',1,'bobwang','[\"R_USER\"]',1784198874408),
('tk-mrndyre2-a1z07tam',1,'bobwang','[\"R_USER\"]',1784198912042),
('tk-mrndztat-49abbm2t',1,'bobwang','[\"R_USER\"]',1784198961173),
('tk-mrnkl587-i08tq07g',19,'alexmorgan','[\"R_SUPER\"]',1784210034103),
('tk-mrnkl8x8-n2syep1z',19,'alexmorgan','[\"R_SUPER\"]',1784210038892),
('tk-mrnkqch2-d71vw4xp',19,'alexmorgan','[\"R_SUPER\"]',1784210276774),
('tk-mrnnp7lb-0xit735o',10001,'35735712','[]',1784215262640),
('tk-mrnqbzvp-6vjqe0iz',19,'alexmorgan','[\"R_SUPER\"]',1784219684966),
('tk-mrnwfc6h-q40c0rsw',1,'bobwang','[\"R_USER\"]',1784229918569),
('tk-mrnwh1jr-64n4bq8c',10002,'github_user_mrnwh1hi','[]',1784229998103),
('tk-mrnwxgk4-cwyijhk6',19,'alexmorgan','[\"R_SUPER\"]',1784230764052),
('tk-mrnyyin9-2w7go05n',1,'bobwang','[\"R_USER\"]',1784234172645),
('tk-mrnyz855-f0a5erqf',1,'bobwang','[\"R_USER\"]',1784234205690),
('tk-mrnz3u8r-7272idz4',19,'alexmorgan','[\"R_SUPER\"]',1784234420955),
('tk-mrnz4wz1-qmaa1k45',19,'alexmorgan','[\"R_SUPER\"]',1784234471149),
('tk-mrnz51mj-c9p6r4lq',19,'alexmorgan','[\"R_SUPER\"]',1784234477179),
('tk-mrnz6kxo-i9y17dk1',19,'alexmorgan','[\"R_SUPER\"]',1784234548860),
('tk-mrnzdb8m-9r8k4q7r',10003,'test_joiner','[]',1784234862886),
('tk-mrnzeitl-iygedzjd',19,'alexmorgan','[\"R_SUPER\"]',1784234919369),
('tk-mrnzenni-i1kyz0kf',10003,'test_joiner','[]',1784234925630),
('tk-mrnzg6y6-2xhb7eus',19,'alexmorgan','[\"R_SUPER\"]',1784234997294),
('tk-mrnzg70q-rjsvzksz',10003,'test_joiner','[]',1784234997386),
('tk-mrnzlgqm-hqe0meqj',19,'alexmorgan','[\"R_SUPER\"]',1784235243262),
('tk-mrnzo2j8-4yce8eej',19,'alexmorgan','[\"R_SUPER\"]',1784235364820),
('tk-mrnzqa54-vc4rbqg2',19,'alexmorgan','[\"R_SUPER\"]',1784235467992),
('tk-mrnzr9yy-4xlzlcg7',19,'alexmorgan','[\"R_SUPER\"]',1784235514426),
('tk-mro16tw8-fq4526tn',19,'alexmorgan','[\"R_SUPER\"]',1784237919704),
('tk-mro1iom6-zpufixjl',19,'alexmorgan','[\"R_SUPER\"]',1784238472734),
('tk-mro1itp1-it74neri',19,'alexmorgan','[\"R_SUPER\"]',1784238479317),
('tk-mroakatb-9xcirjdg',19,'alexmorgan','[\"R_SUPER\"]',1784253664703),
('tk-mroalnuu-zguki6oq',10004,'admin','[\"R_SUPER\"]',1784253728262),
('tk-mroazw7o-gvekaibe',10004,'admin','[\"R_SUPER\"]',1784254392276),
('tk-mrob0o3n-3ugtdepg',19,'alexmorgan','[\"R_SUPER\"]',1784254428419),
('tk-mrob2lf3-bej4zl37',10004,'admin','[\"R_SUPER\"]',1784254518255),
('tk-mrob2pj3-e0ubps65',10004,'admin','[\"R_SUPER\"]',1784254523583),
('tk-mrob2vk9-envntdyt',19,'alexmorgan','[\"R_SUPER\"]',1784254531401),
('tk-mrob33l4-bj2cvg8e',19,'alexmorgan','[\"R_SUPER\"]',1784254541800),
('tk-mrob7yc6-antg78e8',10004,'admin','[\"R_SUPER\"]',1784254768278),
('tk-mrob8304-1l0e1wrf',19,'alexmorgan','[\"R_SUPER\"]',1784254774324),
('tk-mrob9di6-m3abg131',10004,'admin','[\"R_SUPER\"]',1784254834590),
('tk-mrob9ipr-cncokou3',19,'alexmorgan','[\"R_SUPER\"]',1784254841343),
('tk-mroccoxj-v1zwb4mk',19,'alexmorgan','[\"R_SUPER\"]',1784256668983),
('tk-mroifkse-upf3r6ax',19,'alexmorgan','[\"R_SUPER\"]',1784266881279),
('tk-mrp1iwzd-414cddbt',19,'alexmorgan','[\"R_SUPER\"]',1784298949753),
('tk-mrp2ikof-wokecd9w',3,'tech_guru','[\"R_USER\"]',1784300613423),
('tk-mrp2km8p-t25w0gfe',3,'tech_guru','[\"R_USER\"]',1784300708761),
('tk-mrp2l961-nc7qam3y',3,'tech_guru','[\"R_USER\"]',1784300738474),
('tk-mrp2lf9e-2meqtti1',3,'tech_guru','[\"R_USER\"]',1784300746370),
('tk-mrp2loze-hsyoo757',3,'tech_guru','[\"R_USER\"]',1784300758970),
('tk-mrp3fvep-6tl5ttt6',3,'tech_guru','[\"R_USER\"]',1784302166977),
('tk-mrp3fylu-93y6qxe9',3,'tech_guru','[\"R_USER\"]',1784302171122),
('tk-mrp3g22s-3j6t7532',3,'tech_guru','[\"R_USER\"]',1784302175620),
('tk-mrp3gra7-xdubwph6',10004,'admin','[\"R_SUPER\"]',1784302208287),
('tk-mrp3gw5m-87l511wa',10004,'admin','[\"R_SUPER\"]',1784302214602),
('tk-mrp3h1f9-otfn1f00',10004,'admin','[\"R_SUPER\"]',1784302221429),
('tk-mrp3h5ut-j9deivhh',10004,'admin','[\"R_SUPER\"]',1784302227173),
('tk-mrp47kck-bdo7j7t4',10004,'admin','[\"R_SUPER\"]',1784303459012),
('tk-mrp47ql0-59qpw5qi',10004,'admin','[\"R_SUPER\"]',1784303467092),
('tk-mrp494tw-pll69iog',10004,'admin','[\"R_SUPER\"]',1784303532212),
('tk-mrp49a5y-hgnaaq4a',19,'alexmorgan','[\"R_SUPER\"]',1784303539126),
('tk-mrp4axx3-n1vewq6v',10004,'admin','[\"R_SUPER\"]',1784303616567),
('tk-mrp4qhmq-gb0g8z5l',19,'alexmorgan','[\"R_SUPER\"]',1784304341954),
('tk-mrp5u4cm-4zj9jaru',10004,'admin','[\"R_SUPER\"]',1784306190982),
('tk-mrp6z7ug-ydc0qgnd',3,'tech_guru','[\"R_USER\"]',1784308108408),
('tk-mrp6zawm-ta1e31ed',3,'tech_guru','[\"R_USER\"]',1784308112374),
('tk-mrp6zf9s-6q4ibw6k',3,'tech_guru','[\"R_USER\"]',1784308118032),
('tk-mrp6zjxa-6yud0xwo',3,'tech_guru','[\"R_USER\"]',1784308124062),
('tk-mrp6zoub-zleynq9o',3,'tech_guru','[\"R_USER\"]',1784308130435),
('tk-mrp73t3b-ype7x6kj',3,'tech_guru','[\"R_USER\"]',1784308322567),
('tk-mrp741gr-iwf43l6z',3,'tech_guru','[\"R_USER\"]',1784308333419),
('tk-mrp78j3x-vgbimddz',3,'tech_guru','[\"R_USER\"]',1784308542909),
('tk-mrp78qlm-4q7xmil8',3,'tech_guru','[\"R_USER\"]',1784308552618),
('tk-mrp7dy9z-m42d3zck',3,'tech_guru','[\"R_USER\"]',1784308795847),
('tk-mrp7dyd5-5rh2mo73',3,'tech_guru','[\"R_USER\"]',1784308795961),
('tk-mrp7e26u-bjg5urn5',3,'tech_guru','[\"R_USER\"]',1784308800918),
('tk-mrp7e2a1-2orbinbq',3,'tech_guru','[\"R_USER\"]',1784308801033),
('tk-mrp7e6cf-tbu628gi',3,'tech_guru','[\"R_USER\"]',1784308806303),
('tk-mrp7ea1j-yi574c7r',3,'tech_guru','[\"R_USER\"]',1784308811095),
('tk-mrp7endp-wygjfyxl',3,'tech_guru','[\"R_USER\"]',1784308828381),
('tk-mrp7euqd-7ce2i1qe',3,'tech_guru','[\"R_USER\"]',1784308837909),
('tk-mrp7i3rd-4e1bvs72',3,'tech_guru','[\"R_USER\"]',1784308989577),
('tk-mrp7i90i-7ppuj0yi',3,'tech_guru','[\"R_USER\"]',1784308996386),
('tk-mrp7p3hq-vlplbbvq',3,'tech_guru','[\"R_USER\"]',1784309315822),
('tk-mrp82nfl-anya4srx',10004,'admin','[\"R_SUPER\"]',1784309948193),
('tk-mrp85505-vlclnpgv',19,'alexmorgan','[\"R_SUPER\"]',1784310064277),
('tk-mrp85feu-mmve4p80',10005,'promo_test1','[]',1784310077766),
('tk-mrp878rg-d9fe9j8b',10006,'promo_buyer','[]',1784310162460),
('tk-mrp878xh-ldre7nqa',19,'alexmorgan','[\"R_SUPER\"]',1784310162677),
('tk-mrp8a1ei-3twanj58',10007,'promo_test2','[]',1784310292890),
('tk-mrp8frma-612yn9os',19,'alexmorgan','[\"R_SUPER\"]',1784310560146),
('tk-mrp8jbr8-m2z38745',19,'alexmorgan','[\"R_SUPER\"]',1784310726212),
('tk-mrp8jfup-17zc4wzf',19,'alexmorgan','[\"R_SUPER\"]',1784310731521),
('tk-mrp8k12f-nsouex7z',19,'alexmorgan','[\"R_SUPER\"]',1784310759015),
('tk-mrp8v5gp-nemodlrf',10008,'promo_pts','[]',1784311277930),
('tk-mrp8w3tt-m7114pyf',10009,'promo_pts2','[]',1784311322465),
('tk-mrp8xtzh-raorb9ri',19,'alexmorgan','[\"R_SUPER\"]',1784311403021),
('tk-mrp8y50f-lul93yux',10009,'promo_pts2','[]',1784311417311),
('tk-mrp8yarn-6he2g3kw',10009,'promo_pts2','[]',1784311424771),
('tk-mrp8zxex-co8shokl',10010,'promo_dbg','[]',1784311500777),
('tk-mrpa8953-xwbp8w1g',10011,'promo_dual','[]',1784313568839),
('tk-mrpa8ptw-5kp7plf0',10011,'promo_dual','[]',1784313590468),
('tk-mrpacogd-r2fw7g6p',10011,'promo_dual','[]',1784313775309),
('tk-mrpaihu3-ir8wut5q',10011,'promo_dual','[]',1784314046667),
('tk-mrpaj701-bv02hen7',10011,'promo_dual','[]',1784314079281);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlement_config`
--

DROP TABLE IF EXISTS `settlement_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settlement_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通用户',
  `confirm_days` int(11) DEFAULT 7,
  `enabled` int(11) DEFAULT 1,
  `balance_transfer_enabled` int(11) DEFAULT 1,
  `points_transfer_enabled` int(11) DEFAULT 1,
  `single_min_balance` decimal(10,2) DEFAULT 0.00,
  `single_max_balance` decimal(10,2) DEFAULT 0.00,
  `single_min_points` int(11) DEFAULT 0,
  `single_max_points` int(11) DEFAULT 0,
  `daily_limit_balance_amount` decimal(10,2) DEFAULT 0.00,
  `daily_limit_points_amount` int(11) DEFAULT 0,
  `daily_limit_times` int(11) DEFAULT 0,
  `weekly_limit_times` int(11) DEFAULT 0,
  `yearly_limit_times` int(11) DEFAULT 0,
  `balance_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `points_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `balance_to_points_rate` decimal(10,2) DEFAULT 1.00,
  `points_to_balance_rate` decimal(10,2) DEFAULT 1.00,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlement_config`
--

LOCK TABLES `settlement_config` WRITE;
/*!40000 ALTER TABLE `settlement_config` DISABLE KEYS */;
INSERT INTO `settlement_config` VALUES
(1,0,'默认结算',7,1,1,1,0.00,0.00,0,0,0.00,0,0,0,0,0.00,0.00,1.00,1.00,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `settlement_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '配置名称',
  `provider` varchar(50) NOT NULL COMMENT '短信服务商',
  `config_json` text DEFAULT '{}' COMMENT '服务商配置JSON',
  `sign_name` varchar(100) DEFAULT '' COMMENT '短信签名',
  `template_code` varchar(50) DEFAULT '' COMMENT '短信模板代码',
  `enabled` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES
(1,'云片验证码','yunpian','{\"apiKey\":\"test-key-xxx\"}','ArtDesign','TPL_001',1,0,'2026-07-12 19:45:22','2026-07-12 19:45:22'),
(2,'阿里云测试','aliyun','{\"accessKeyId\":\"LTAI5t6oq445VTWdqXpkw1ud\",\"accessKeySecret\":\"26V7K8ml5mSSsOR7FDy31LrOCqlG4M\"}','恒创联众','10001',1,1,'2026-07-12 19:53:38','2026-07-12 20:01:46'),
(3,'腾讯云测试','tencent','{\"secretId\":\"AKID123456\",\"secretKey\":\"myTencentSecret\",\"appId\":\"1400123456\"}','ArtPro','12345',1,0,'2026-07-12 19:56:06','2026-07-12 19:56:06'),
(4,'华为云测试','huawei','{\"appKey\":\"530b0c2ec52ce142fc62c9af58f21e9b\",\"appSecret\":\"452a129430748e3082afcc027f0d7fc7\",\"sender\":\"8823122800000\"}','ArtPro','T001',1,0,'2026-07-12 20:08:52','2026-07-12 20:08:52');
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_verifications`
--

DROP TABLE IF EXISTS `sms_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_verifications`
--

LOCK TABLES `sms_verifications` WRITE;
/*!40000 ALTER TABLE `sms_verifications` DISABLE KEYS */;
INSERT INTO `sms_verifications` VALUES
(1,'18367164190','315567','register',0,'2026-07-12 19:34:22','2026-07-12 19:24:22'),
(2,'13900000001','821080','register',0,'2026-07-12 20:03:04','2026-07-12 19:53:04'),
(3,'18367164190','553902','register',0,'2026-07-12 20:12:13','2026-07-12 20:02:13'),
(4,'18367164190','834844','register',0,'2026-07-12 20:16:09','2026-07-12 20:06:09'),
(5,'18367164190','755818','register',0,'2026-07-12 20:20:42','2026-07-12 20:10:42'),
(6,'18367164190','670608','register',0,'2026-07-12 20:24:42','2026-07-12 20:14:42');
/*!40000 ALTER TABLE `sms_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standalone_vote_records`
--

DROP TABLE IF EXISTS `standalone_vote_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standalone_vote_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `option_index` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vote_user_option` (`vote_id`,`user_id`,`option_index`),
  KEY `idx_vote_id` (`vote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standalone_vote_records`
--

LOCK TABLES `standalone_vote_records` WRITE;
/*!40000 ALTER TABLE `standalone_vote_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `standalone_vote_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standalone_votes`
--

DROP TABLE IF EXISTS `standalone_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standalone_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `options` text NOT NULL,
  `max_select` int(11) DEFAULT 1,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `total_votes` int(11) DEFAULT 0,
  `create_by` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standalone_votes`
--

LOCK TABLES `standalone_votes` WRITE;
/*!40000 ALTER TABLE `standalone_votes` DISABLE KEYS */;
INSERT INTO `standalone_votes` VALUES
(1,'test vote','[\"a\",\"b\"]',1,NULL,'closed',0,1,'2026-07-16 19:29:20'),
(2,'test vote','[\"a\",\"b\"]',1,'2026-08-01 00:00:00','active',0,1,'2026-07-16 19:30:07');
/*!40000 ALTER TABLE `standalone_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_configs`
--

DROP TABLE IF EXISTS `storage_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'local',
  `name` varchar(100) DEFAULT '',
  `config` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `endpoint` varchar(500) DEFAULT '',
  `region` varchar(100) DEFAULT '',
  `bucket` varchar(200) DEFAULT '',
  `access_key` varchar(500) DEFAULT '',
  `secret_key` varchar(500) DEFAULT '',
  `local_dir` varchar(500) DEFAULT '',
  `remote_dir` varchar(500) DEFAULT '',
  `expiry_seconds` int(11) DEFAULT 0,
  `base_url` varchar(500) DEFAULT '',
  `applicable_roles` text DEFAULT NULL,
  `applicable_levels` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_configs`
--

LOCK TABLES `storage_configs` WRITE;
/*!40000 ALTER TABLE `storage_configs` DISABLE KEYS */;
INSERT INTO `storage_configs` VALUES
(2,'oss','用户-阿里云OSS',NULL,1,'1','2026-07-11 17:38:58','2026-07-12 03:08:16','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','ba007200b77fcd4ae08d875790878c2eba6a579b0226b7000934ced17e5c453a','b418356110428dac2a4860e8c45a9cc359e7584fad13dc57ca523d9c2088c0a0','','user/{userId}',3600,'','','all'),
(3,'oss','后台-阿里云OSS',NULL,0,'1','2026-07-11 17:40:44','2026-07-13 19:20:43','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','ba007200b77fcd4ae08d875790878c2eba6a579b0226b7000934ced17e5c453a','b418356110428dac2a4860e8c45a9cc359e7584fad13dc57ca523d9c2088c0a0','','admin',0,'','','backend');
/*!40000 ALTER TABLE `storage_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text DEFAULT '',
  `description` varchar(200) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES
(1,'system_log_enabled','true','系统日志总开关','2026-07-10 22:42:45'),
(2,'log_enabled_login','true','登录日志开关','2026-07-10 22:42:45'),
(3,'log_enabled_user','true','用户操作日志开关','2026-07-10 22:42:45'),
(4,'log_enabled_operation','true','运营管理日志开关','2026-07-10 22:42:45'),
(5,'log_enabled_content','true','内容管理日志开关','2026-07-10 22:42:45'),
(6,'log_enabled_system','true','系统配置日志开关','2026-07-10 22:42:45'),
(7,'invite_user_enabled','false','用户生成邀请码开关','2026-07-10 22:42:45'),
(8,'invite_user_max','5','用户最大可生成邀请码数','2026-07-10 22:42:45'),
(9,'register_invite_required','false','注册必须邀请码','2026-07-10 22:42:45'),
(10,'commission_enabled','false','推广返佣开关','2026-07-10 22:42:45'),
(11,'commission_mode','purchase','返佣模式','2026-07-10 22:42:45'),
(12,'points_transfer_enabled','false','积分转账开关','2026-07-10 22:42:45'),
(13,'points_transfer_fee','0','积分转账手续费比例%','2026-07-10 22:42:45'),
(14,'balance_transfer_enabled','false','余额转账开关','2026-07-10 22:42:45'),
(15,'balance_transfer_fee','0','余额转账手续费比例%','2026-07-10 22:42:45'),
(16,'points_purchase_enabled','false','积分购买开关','2026-07-10 22:42:45'),
(17,'points_purchase_rate','1','1元等于多少积分','2026-07-10 22:42:45'),
(18,'content_split_enabled','true','创作分成开关','2026-07-10 22:42:45'),
(19,'content_split_global_rate','70','创作分成全局比例%','2026-07-10 22:42:45'),
(20,'checkin_enabled','true','签到功能开关','2026-07-10 22:42:45'),
(21,'topic_create_min_exp_level','3','话题创建最低经验等级','2026-07-11 12:17:24'),
(22,'topic_create_allowed_levels','2,3','允许创建话题的会员等级ID列表','2026-07-11 12:17:24'),
(23,'payment_epay_pid','','','2026-07-11 16:28:08'),
(24,'payment_epay_key','','','2026-07-11 16:28:08'),
(25,'payment_epay_api_url','','','2026-07-11 16:28:08'),
(26,'payment_epay_notify_url','','','2026-07-11 16:28:08'),
(27,'payment_epay_enabled','true','','2026-07-11 16:28:08'),
(28,'payment_alipay_app_id','','','2026-07-11 16:28:08'),
(29,'payment_alipay_private_key','','','2026-07-11 16:28:08'),
(30,'payment_alipay_public_key','','','2026-07-11 16:28:08'),
(31,'payment_alipay_enabled','false','','2026-07-11 16:28:08'),
(32,'payment_wechat_app_id','','','2026-07-11 16:28:08'),
(33,'payment_wechat_mch_id','','','2026-07-11 16:28:08'),
(34,'payment_wechat_api_key','','','2026-07-11 16:28:08'),
(35,'payment_wechat_enabled','false','','2026-07-11 16:28:08'),
(36,'active_pc_layout','pc','激活的PC布局主题ID','2026-07-12 14:18:29'),
(37,'site_theme_mode','auto','主题显示模式','2026-07-17 20:13:04'),
(38,'site_show_theme_switch','false','前端显示主题切换按钮','2026-07-17 20:13:04'),
(39,'site_name','','网站名称','2026-07-17 20:13:04'),
(40,'site_subtitle','','网站副标题','2026-07-17 20:13:04'),
(41,'site_domain','','网站域名','2026-07-17 20:13:04'),
(42,'site_admin_path','/admin','后台入口地址','2026-07-17 20:13:04'),
(43,'site_favicon','','网站favicon','2026-07-17 20:13:04'),
(44,'site_logo_pc','','PC端LOGO','2026-07-17 20:13:04'),
(45,'site_logo_mobile','','移动端LOGO','2026-07-17 20:13:04'),
(46,'site_copyright','','底部版权信息','2026-07-17 20:13:04'),
(47,'site_icp','','ICP备案号','2026-07-17 20:13:04'),
(48,'login_captcha_enabled','true','后台登录验证码','2026-07-17 20:13:04'),
(49,'login_max_errors','5','连续登录错误次数','2026-07-17 20:13:04'),
(50,'login_lock_minutes','15','封号时长(分钟)','2026-07-17 20:13:04'),
(51,'ip_blacklist','','IP黑名单','2026-07-17 20:13:04'),
(52,'api_sign_enabled','true','API请求签名验证','2026-07-17 20:13:04'),
(53,'api_rate_limit','60','接口请求频率限制','2026-07-17 20:13:04'),
(54,'register_enabled','true','开启用户注册','2026-07-17 20:13:04'),
(55,'register_verify_type','email','注册验证方式','2026-07-17 20:13:04'),
(56,'register_default_group','21','新用户默认分组','2026-07-17 20:13:04'),
(57,'password_rule','alphanumeric','密码规则','2026-07-17 20:13:04'),
(58,'site_maintenance_enabled','false','网站维护开关','2026-07-17 20:13:04'),
(59,'site_maintenance_msg','','维护提示文案','2026-07-17 20:13:04'),
(60,'register_email_config_id','1','注册验证邮箱配置ID','2026-07-17 20:13:04'),
(61,'register_default_level','1','新用户默认会员等级','2026-07-17 20:13:04'),
(62,'register_start_id','10001','用户ID起始编号','2026-07-17 20:13:04'),
(63,'register_username_min','8','用户名最小长度','2026-07-17 20:13:04'),
(64,'register_password_min','6','密码最小长度','2026-07-17 20:13:04'),
(65,'sms_channel_enabled','true','短信发送通道开关','2026-07-17 20:13:04'),
(66,'site_auto_refresh','true','自动刷新页面内容','2026-07-17 20:13:04'),
(67,'push_subscription_1','{}','Web Push Subscription for user 1','2026-07-16 19:26:30'),
(69,'title_scan_last','2026-07-17 19:44:13','称号最后扫描时间','2026-07-16 22:45:04'),
(70,'title_scan_interval','1400','称号自动扫描间隔(分钟)','2026-07-16 22:45:26'),
(120,'invite_user_cost_config','{\"enabled\":true,\"pointsPricing\":[{\"maxAmount\":100,\"totalCost\":1,\"quantity\":100},{\"maxAmount\":500,\"totalCost\":4,\"quantity\":400}],\"balancePricing\":[{\"maxAmount\":10,\"totalCost\":5,\"quantity\":10}],\"expPricing\":[{\"maxAmount\":100,\"totalCost\":2,\"quantity\":100}],\"membershipPricing\":{\"30\":10,\"90\":25,\"365\":80},\"vipDiscount\":{\"enabled\":true,\"levelId\":3}}','','2026-07-17 17:20:22'),
(122,'invite_user_max_uses','10','','2026-07-17 17:27:25'),
(142,'site_help_url','','帮助与反馈链接','2026-07-17 20:13:04'),
(143,'site_agreement_url','','用户协议链接','2026-07-17 20:13:04'),
(144,'site_privacy_url','','隐私政策链接','2026-07-17 20:13:04'),
(145,'site_security_url','','安全条款链接','2026-07-17 20:13:04'),
(146,'site_about_url','','关于页链接','2026-07-17 20:13:04'),
(147,'site_community_url','123456','交流群组链接','2026-07-17 20:13:04'),
(148,'site_contact_url','123456','联系我们链接','2026-07-17 20:13:04'),
(149,'site_community_content','123456','交流群组弹窗内容','2026-07-17 20:13:04'),
(150,'site_contact_content','123456','联系我们弹窗内容','2026-07-17 20:13:04');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notifications`
--

DROP TABLE IF EXISTS `sys_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT '',
  `type` varchar(50) DEFAULT 'system',
  `target_url` varchar(500) DEFAULT '',
  `target_user_id` int(11) DEFAULT 0,
  `from_user_id` int(11) DEFAULT 0,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sys_notifications_target_user` (`target_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notifications`
--

LOCK TABLES `sys_notifications` WRITE;
/*!40000 ALTER TABLE `sys_notifications` DISABLE KEYS */;
INSERT INTO `sys_notifications` VALUES
(1,'系统通知 #1','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-07-01 22:39:54'),
(2,'系统通知 #2','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-07-06 22:39:54'),
(3,'系统通知 #3','这是一条重要的系统通知内容。','update','',0,0,'','',1,'2026-07-08 22:39:54'),
(4,'系统通知 #4','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-06-29 22:39:54'),
(5,'系统通知 #5','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-06-29 22:39:54'),
(6,'系统通知 #6','这是一条重要的系统通知内容。','update','',0,0,'','',1,'2026-07-08 22:39:54'),
(7,'系统通知 #7','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-06-27 22:39:54'),
(8,'系统通知 #8','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-07-09 22:39:54'),
(9,'卡密兑换成功','您使用卡密 CDKEY-MRG47L1VS1EE 兑换成功，获得：5000元余额、额外99999积分、额外2000经验值','system','',19,0,'管理员','',1,'2026-07-11 08:41:23'),
(10,'打赏通知','Alex Morgan 打赏了您的帖子「开源项目推荐合集」1余额','system','',7,19,'Alex Morgan','',0,'2026-07-11 11:39:17'),
(11,'打赏成功','您成功打赏了 用户 的帖子「开源项目推荐合集」1余额','system','',19,0,'管理员','',1,'2026-07-11 11:39:17'),
(12,'新粉丝','Alex Morgan 关注了您','system','',7,19,'Alex Morgan','',0,'2026-07-11 11:39:21'),
(13,'帖子被加精','您的帖子《开源项目推荐合集》已被管理员设为精华','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:23'),
(14,'帖子被设为热帖','您的帖子《开源项目推荐合集》已被管理员设为热帖','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:24'),
(15,'帖子被锁定','您的帖子《开源项目推荐合集》已被管理员锁定','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:26'),
(16,'帖子已解锁','您的帖子《开源项目推荐合集》已被管理员解除锁定','system','',7,19,'alexmorgan','',0,'2026-07-11 11:40:52'),
(17,'新粉丝','Alex Morgan 关注了您','system','',12,19,'Alex Morgan','',0,'2026-07-11 11:46:49'),
(18,'应用审核通过','您的应用《百变引擎》已通过审核，现在可以在应用商店中查看了','system','',19,0,'alexmorgan','',1,'2026-07-11 11:50:41'),
(19,'任务完成','恭喜完成\"每日签到\"任务！获得: 10积分','system','',1,0,'管理员','',0,'2026-07-12 13:51:30'),
(20,'任务完成','恭喜完成\"完善资料\"任务！获得: 30积分','system','',19,0,'管理员','',1,'2026-07-12 20:31:51'),
(21,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',19,0,'管理员','',1,'2026-07-12 21:51:42'),
(22,'帖子审核未通过','您的帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》未通过审核，原因：6666','system','',19,19,'alexmorgan','',1,'2026-07-13 12:17:13'),
(23,'新的账号申诉','用户 alexmorgan 提交了账号申诉，申诉理由：我冤枉的，请解封','system','',19,0,'管理员','',1,'2026-07-13 14:21:20'),
(24,'新的账号申诉','用户 alexmorgan 提交了账号申诉，申诉理由：666','system','',19,0,'管理员','',1,'2026-07-13 16:21:15'),
(25,'帖子被编辑','管理员编辑了您的帖子《设计师如何提升审美》','system','',14,19,'alexmorgan','',0,'2026-07-13 18:32:31'),
(26,'帖子被删除','您的帖子《React 19 新特性解读》已被管理员删除','system','',5,19,'alexmorgan','',0,'2026-07-13 18:33:51'),
(27,'帖子被删除','您的帖子《Cloud Native架构实践》已被管理员删除','system','',10,19,'alexmorgan','',0,'2026-07-13 18:33:54'),
(28,'帖子被删除','您的帖子《像素艺术创作技巧》已被管理员删除','system','',6,19,'alexmorgan','',0,'2026-07-13 18:33:57'),
(29,'帖子被删除','您的帖子《独立游戏开发日记》已被管理员删除','system','',9,19,'alexmorgan','',0,'2026-07-13 18:34:00'),
(30,'帖子被删除','您的帖子《设计师如何提升审美》已被管理员删除','system','',14,19,'alexmorgan','',0,'2026-07-13 18:34:03'),
(31,'帖子被删除','您的帖子《分享我的设计作品集》已被管理员删除','system','',2,19,'alexmorgan','',0,'2026-07-13 18:34:06'),
(32,'帖子被删除','您的帖子《AI绘画入门指南》已被管理员删除','system','',3,19,'alexmorgan','',0,'2026-07-13 18:34:10'),
(33,'帖子被删除','您的帖子《Vue3 + TypeScript 实战》已被管理员删除','system','',8,19,'alexmorgan','',0,'2026-07-13 18:34:18'),
(34,'帖子被删除','您的帖子《我的应用开发历程》已被管理员删除','system','',2,19,'alexmorgan','',0,'2026-07-13 18:34:22'),
(35,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-13 18:34:40'),
(36,'任务完成','恭喜完成\"完善资料\"任务！获得: 30积分','system','',19,0,'管理员','',1,'2026-07-13 19:42:23'),
(37,'认证申请已提交','您的蓝V认证申请已提交，请耐心等待管理员审核','verification','',19,0,'系统','',1,'2026-07-13 21:47:11'),
(38,'新的认证申请','1 提交了蓝V认证申请，请及时审核','verification','',19,19,'alexmorgan','',1,'2026-07-13 21:47:11'),
(39,'认证申请通过','恭喜，您的蓝V认证申请已通过审核！','system','',19,0,'管理员','',1,'2026-07-13 21:47:29'),
(40,'帖子被删除','您的帖子《面试经历分享》已被管理员删除','system','',3,19,'alexmorgan','',0,'2026-07-14 12:01:39'),
(41,'新粉丝','Alex Morgan 关注了您','system','',13,19,'Alex Morgan','',0,'2026-07-14 12:01:47'),
(42,'新粉丝','Alex Morgan 关注了您','system','',13,19,'Alex Morgan','',0,'2026-07-14 12:01:50'),
(43,'帖子被删除','您的帖子《移动开发趋势2026》已被管理员删除','system','',13,19,'alexmorgan','',0,'2026-07-14 12:01:54'),
(44,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:12:32'),
(45,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「版主」。','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:14:30'),
(46,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:14:50'),
(47,'版主申请未通过','很遗憾，您的版主申请未被通过。原因: 申请理由不够充分','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-14 13:14:55'),
(48,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:55:32'),
(49,'新版主申请','bobwang 申请成为「设计创作」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:55:32'),
(50,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「审核员」。','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:56:06'),
(51,'版主申请未通过','很遗憾，您的版主申请未被通过。原因: 666','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:56:11'),
(52,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:57:03'),
(53,'新版主申请','lisa_chen 申请成为「设计创作」板块的 审核员','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:57:03'),
(54,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「版主」。','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-14 13:57:25'),
(55,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 14:00:13'),
(56,'新版主申请','bobwang 申请成为「设计创作」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 14:00:13'),
(57,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 14:00:20'),
(58,'新版主申请','lisa_chen 申请成为「设计创作」板块的 审核员','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 14:00:20'),
(59,'新的账号申诉','用户 35735712 提交了账号申诉，申诉理由：66','system','',19,0,'管理员','',1,'2026-07-14 15:25:58'),
(60,'新的账号申诉','用户 35735712 提交了账号申诉，申诉理由：test appeal','system','',19,0,'管理员','',1,'2026-07-14 15:30:56'),
(61,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-15 04:17:41'),
(62,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',19,0,'管理员','',1,'2026-07-15 04:26:15'),
(63,'新粉丝','35735712 关注了您','system','',19,10001,'35735712','',1,'2026-07-15 10:21:50'),
(64,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「审核员」。','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-15 19:31:36'),
(65,'卡密兑换成功','您使用卡密 CDKEY-MRMRD84EXRNR 兑换成功，获得：2000元余额、额外10000积分、额外5000经验值','system','',10001,0,'管理员','',1,'2026-07-16 00:16:12'),
(66,'新粉丝','35735712 关注了您','system','',19,10001,'35735712','',1,'2026-07-16 00:16:45'),
(67,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',10001,0,'管理员','',1,'2026-07-16 00:17:34'),
(68,'买家已确认收货','35735712已确认收货「购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》」，资金已到账。','system','',19,0,'','',1,'2026-07-16 00:19:36'),
(69,'买家已确认收货','35735712已确认收货「购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》」，资金已到账。','system','',19,0,'','',1,'2026-07-16 00:19:39'),
(70,'合集购买通知','用户 bob123 购买了你的合集《社区功能测试合集》','collection_purchase','',19,1,'bob123','',1,'2026-07-16 01:12:14'),
(71,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-16 16:40:43'),
(72,'新版主申请','35735712 申请成为「综合讨论」板块的 版主','moderator_apply','',19,10001,'35735712','',1,'2026-07-16 17:06:35'),
(73,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「管理员」。','moderator_apply_result','',10001,19,'alexmorgan','',0,'2026-07-16 17:07:01'),
(87,'新粉丝','管理员 关注了您','follow','/appstore/profile/10004',19,10004,'管理员','',1,'2026-07-17 02:20:34'),
(92,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:37:47'),
(93,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:39:56'),
(94,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:41:24'),
(95,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',19,1,'管理员','',0,'2026-07-17 16:35:31'),
(96,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10005,1,'管理员','',0,'2026-07-17 17:41:17'),
(97,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10006,1,'管理员','',0,'2026-07-17 17:42:42'),
(98,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10007,1,'管理员','',0,'2026-07-17 17:44:52'),
(99,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10008,1,'管理员','',0,'2026-07-17 18:01:18'),
(100,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10009,1,'管理员','',0,'2026-07-17 18:02:02'),
(101,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10009,1,'管理员','',0,'2026-07-17 18:03:44'),
(102,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10010,1,'管理员','',0,'2026-07-17 18:05:00'),
(103,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:28'),
(104,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:28'),
(105,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:50'),
(106,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:42:55'),
(107,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:47:26'),
(108,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:47:59');
/*!40000 ALTER TABLE `sys_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT 'system',
  `type` varchar(30) NOT NULL,
  `target_type` varchar(50) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` text DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_system_logs_user` (`user_id`),
  KEY `idx_system_logs_type` (`type`),
  KEY `idx_system_logs_create` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=949 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES
(254,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:45:06'),
(255,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:45:13'),
(256,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:10'),
(257,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:38'),
(258,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:57:02'),
(259,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 23:19:43'),
(260,0,'admin','create','menu',54,'新建菜单\"文件管理\"，路径:','223.160.209.169','2026-07-10 23:24:00'),
(261,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-repo-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(262,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":3,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(263,0,'admin','update','menu',16,'更新菜单\"文件上传策略\"。旧数据:{\"id\":16,\"parent_id\":2,\"name\":\"FilePolicyManage\",\"path\":\"filepolicy\",\"component\":\"/operation/filepolicy/index\",\"redirect\":\"\",\"title\":\"文件上传策略\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-policy-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:26:58'),
(264,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:24:27.000Z\"}','223.160.208.169','2026-07-10 23:27:10'),
(265,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":3,\"name\":\"StorageConfig\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/storage-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:27:43'),
(266,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:24:00.000Z\"}','223.160.208.169','2026-07-10 23:28:21'),
(267,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":2,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:28:46'),
(268,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"/a\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:28:21.000Z\"}','223.160.208.169','2026-07-10 23:29:37'),
(269,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.198','2026-07-11 08:40:24'),
(270,19,'alexmorgan','create','cardkey',21,'生成1张卡密(5000元余额)','223.160.215.198','2026-07-11 08:41:04'),
(271,19,'alexmorgan','redeem','cardkey',21,'兑换卡密 CDKEY-MRG47L1VS1EE: 5000元余额、额外99999积分、额外2000经验值','','2026-07-11 08:41:23'),
(272,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.198','2026-07-11 08:42:32'),
(273,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.229','2026-07-11 11:33:19'),
(274,19,'alexmorgan','set_badge','post',12,'设置自定义徽章《开源项目推荐合集》：#','','2026-07-11 11:35:23'),
(275,19,'alexmorgan','essence','post',12,'设为精华帖子《开源项目推荐合集》','','2026-07-11 11:39:23'),
(276,19,'alexmorgan','hot','post',12,'设为热帖帖子《开源项目推荐合集》','','2026-07-11 11:39:24'),
(277,19,'alexmorgan','lock','post',12,'锁定帖子《开源项目推荐合集》','','2026-07-11 11:39:26'),
(278,19,'alexmorgan','unlock','post',12,'解锁帖子《开源项目推荐合集》','','2026-07-11 11:40:52'),
(279,0,'anonymous','update','app',8,'置顶应用ID:8','223.160.213.229','2026-07-11 11:42:47'),
(280,0,'anonymous','update','app',8,'官方认证应用ID:8','223.160.213.229','2026-07-11 11:42:48'),
(281,0,'anonymous','update','app',8,'精品推荐应用ID:8','223.160.213.229','2026-07-11 11:42:49'),
(282,0,'anonymous','delete','app',8,'删除应用ID:8','223.160.213.229','2026-07-11 11:42:53'),
(283,0,'anonymous','delete','app',6,'删除应用ID:6','223.160.213.229','2026-07-11 11:43:05'),
(284,0,'anonymous','delete','app',9,'删除应用ID:9','223.160.213.229','2026-07-11 11:43:27'),
(285,0,'anonymous','update','submission',8,'审核投稿ID:8 通过','223.160.213.229','2026-07-11 11:50:41'),
(286,0,'anonymous','report','app_comment',13,'用户举报评论ID:13, 原因:6','223.160.213.229','2026-07-11 11:51:00'),
(287,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(288,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(289,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(290,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:33:02'),
(291,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:34:38'),
(292,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:37:37'),
(293,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:05'),
(294,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:19'),
(295,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:39:29'),
(296,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:41:18'),
(297,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:26'),
(298,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:30'),
(299,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:33'),
(300,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:46:49'),
(301,0,'anonymous','delete','role',19,'删除角色\"超级管理员\"','117.136.111.145','2026-07-11 12:47:04'),
(302,0,'anonymous','create','role',22,'新建角色\"系统超级管理员\"','117.136.111.145','2026-07-11 12:47:10'),
(303,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:15'),
(304,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:40'),
(305,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:55'),
(306,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:21'),
(307,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:26'),
(308,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:49:53'),
(309,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(310,0,'anonymous','update','role_permission',22,'更新角色权限','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(311,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:21'),
(312,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:29'),
(313,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:58'),
(314,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:08'),
(315,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:24'),
(316,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:45'),
(317,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:56'),
(318,0,'anonymous','update','custom_task',4,'更新自定义任务\"邀请好友\"','117.136.111.145','2026-07-11 16:02:03'),
(319,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:35'),
(320,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:49'),
(321,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:04:44'),
(322,0,'admin','delete','menu',42,'删除菜单\"投稿审核\"。被删除数据:{\"id\":42,\"parent_id\":6,\"name\":\"SubmissionReview\",\"path\":\"review\",\"component\":\"/appstore/review\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:06:23'),
(323,0,'admin','create','menu',56,'新建菜单\"商城管理\"，路径:/etnfd','117.136.111.145','2026-07-11 16:08:50'),
(324,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:50.000Z\"}','117.136.111.145','2026-07-11 16:08:57'),
(325,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:57.000Z\"}','117.136.111.145','2026-07-11 16:09:04'),
(326,0,'admin','update','menu',3,'更新菜单\"系统管理\"。旧数据:{\"id\":3,\"parent_id\":0,\"name\":\"System\",\"path\":\"/system\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"系统管理\",\"icon\":\"ri:user-3-line\",\"sort_order\":3,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:15'),
(327,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:28:46.000Z\"}','117.136.111.145','2026-07-11 16:09:19'),
(328,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:09:04.000Z\"}','117.136.111.145','2026-07-11 16:09:24'),
(329,0,'admin','update','menu',4,'更新菜单\"结果页面\"。旧数据:{\"id\":4,\"parent_id\":0,\"name\":\"Result\",\"path\":\"/result\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"结果页面\",\"icon\":\"ri:checkbox-circle-line\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:30'),
(330,0,'admin','update','menu',5,'更新菜单\"异常页面\"。旧数据:{\"id\":5,\"parent_id\":0,\"name\":\"Exception\",\"path\":\"/exception\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"异常页面\",\"icon\":\"ri:error-warning-line\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:36'),
(331,19,'alexmorgan','update','avatar_frame',2,'更新头像框\"炫彩边框\"','117.136.111.145','2026-07-11 16:28:24'),
(332,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(333,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(334,19,'alexmorgan','create','checkin_group',2,'新建签到规则《》','','2026-07-11 16:43:20'),
(335,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(336,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(337,19,'alexmorgan','delete','checkin_group',2,'删除签到规则《2》','','2026-07-11 16:43:35'),
(338,0,'system','create','checkin_milestone',1,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(339,0,'system','create','checkin_milestone',2,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(340,0,'system','create','checkin_milestone',3,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(341,0,'system','create','checkin_milestone',4,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(342,0,'system','create','checkin_milestone',5,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(343,0,'system','create','checkin_milestone',6,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(344,0,'system','create','checkin_milestone',7,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(345,0,'system','create','checkin_milestone',8,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(346,0,'system','create','checkin_milestone',9,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(347,0,'system','create','checkin_milestone',10,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(348,0,'system','create','checkin_milestone',11,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(349,0,'system','create','checkin_milestone',12,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(350,0,'system','create','checkin_milestone',13,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(351,0,'system','create','checkin_milestone',14,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(352,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(第7天)','','2026-07-11 16:47:45'),
(353,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:47'),
(354,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:49'),
(355,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(第7天)','','2026-07-11 16:47:52'),
(356,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(id=5)','','2026-07-11 16:47:53'),
(357,0,'system','delete','checkin_milestone',1,'删除阶梯奖励(第7天)','','2026-07-11 16:47:55'),
(358,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(第7天)','','2026-07-11 16:53:24'),
(359,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(id=13)','','2026-07-11 16:53:28'),
(360,0,'system','update','checkin_milestone',6,'更新阶梯奖励(第7天)','','2026-07-11 16:53:31'),
(361,0,'system','delete','checkin_milestone',6,'删除阶梯奖励(第7天)','','2026-07-11 16:53:32'),
(362,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:35'),
(363,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:36'),
(364,0,'system','create','checkin_group',3,'新建签到规则《test》','','2026-07-11 16:54:50'),
(365,0,'system','create','checkin_milestone',15,'新增阶梯奖励(第30天)','','2026-07-11 16:55:50'),
(366,0,'system','delete','checkin_group',3,'删除签到规则《test》','','2026-07-11 16:58:46'),
(367,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 16:58:49'),
(368,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(第30天)','','2026-07-11 16:58:54'),
(369,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:56'),
(370,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:58'),
(371,0,'system','delete','checkin_milestone',12,'删除阶梯奖励(第7天)','','2026-07-11 17:02:13'),
(372,0,'system','delete','checkin_milestone',11,'删除阶梯奖励(第7天)','','2026-07-11 17:06:04'),
(373,0,'system','delete','checkin_milestone',10,'删除阶梯奖励(第7天)','','2026-07-11 17:06:12'),
(374,0,'system','delete','checkin_milestone',9,'删除阶梯奖励(第7天)','','2026-07-11 17:06:14'),
(375,0,'system','delete','checkin_milestone',8,'删除阶梯奖励(第7天)','','2026-07-11 17:06:16'),
(376,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 17:07:01'),
(377,19,'alexmorgan','delete','checkin_milestone',4,'删除阶梯奖励(第7天)','','2026-07-11 17:12:00'),
(378,19,'alexmorgan','create','checkin_group',4,'新建签到规则《666》','','2026-07-11 17:12:09'),
(379,19,'alexmorgan','delete','checkin_group',4,'删除签到规则《666》','','2026-07-11 17:12:29'),
(380,19,'alexmorgan','delete','checkin_milestone',7,'删除阶梯奖励(第7天)','','2026-07-11 17:17:38'),
(381,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 17:17:44'),
(382,19,'alexmorgan','delete','checkin_milestone',3,'删除阶梯奖励(第7天)','','2026-07-11 17:30:18'),
(383,19,'alexmorgan','delete','checkin_milestone',2,'删除阶梯奖励(第7天)','','2026-07-11 17:30:35'),
(384,19,'alexmorgan','create','checkin_group',5,'新建签到规则《》','','2026-07-11 17:30:39'),
(385,19,'alexmorgan','delete','checkin_group',5,'删除签到规则《5》','','2026-07-11 17:30:42'),
(386,0,'admin','delete','menu',43,'删除菜单\"投稿审核\"。被删除数据:{\"id\":43,\"parent_id\":6,\"name\":\"SubmissionReviewMobile\",\"path\":\"review-mobile\",\"component\":\"/appstore/review/mobile\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":7,\"is_hidden\":1,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:41:55'),
(387,0,'anonymous','delete','comment',13,'管理员删除评论ID:13','223.160.208.192','2026-07-11 17:53:17'),
(388,0,'anonymous','update','category',7,'更新分类\"社交\"','223.160.208.192','2026-07-11 17:53:34'),
(389,0,'anonymous','update','official_tag',1,'更新官方标签\"热门\"','223.160.208.192','2026-07-11 17:53:46'),
(390,0,'admin','delete','menu',41,'删除菜单\"我的投稿\"。被删除数据:{\"id\":41,\"parent_id\":6,\"name\":\"MySubmissions\",\"path\":\"my-submissions\",\"component\":\"/appstore/submissions\",\"redirect\":\"\",\"title\":\"我的投稿\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/my-submissions\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:54:35'),
(391,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:31'),
(392,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(393,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(394,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:37'),
(395,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:48:40'),
(396,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:48:42'),
(397,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:13'),
(398,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:15'),
(399,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:17'),
(400,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:18'),
(401,0,'anonymous','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 19:50:04'),
(402,0,'anonymous','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.167','2026-07-11 19:55:16'),
(403,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.167','2026-07-11 20:03:08'),
(404,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:10:04'),
(405,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:11:46'),
(406,19,'alexmorgan','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 20:15:21'),
(407,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(408,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(409,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:36:59'),
(410,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 20:38:36'),
(411,0,'anonymous','login','user',20,'用户 testgift 登录','::ffff:127.0.0.1','2026-07-11 20:38:59'),
(412,0,'anonymous','create','coupon',6,'创建优惠券:黄金会员','223.160.215.167','2026-07-11 20:42:43'),
(413,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(414,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(415,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:08'),
(416,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:23'),
(417,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:43'),
(418,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:53'),
(419,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(420,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(421,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:22'),
(422,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:31'),
(423,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:08:10'),
(424,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:08:20'),
(425,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:10:29'),
(426,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:19:13'),
(427,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.211.247','2026-07-11 22:04:24'),
(428,19,'alexmorgan','create','membership',5,'新增会员等级\"测试会员\"','223.160.211.247','2026-07-11 22:39:44'),
(429,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:15'),
(430,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:27'),
(431,19,'alexmorgan','update','membership',5,'更新会员等级\"测试会员\"','39.144.124.125','2026-07-11 23:02:32'),
(432,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','39.144.124.125','2026-07-11 23:07:22'),
(433,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:03:41'),
(434,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 00:05:17'),
(435,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:29:57'),
(436,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 02:47:44'),
(437,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:02'),
(438,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:13'),
(439,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-12 02:57:14'),
(440,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:00:38'),
(441,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:04:11'),
(442,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:05:18'),
(443,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:16:22'),
(444,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:20:01'),
(445,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:09:53'),
(446,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:38:51'),
(447,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:04'),
(448,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:22'),
(449,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:37'),
(450,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:08'),
(451,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:20'),
(452,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:47'),
(453,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:59'),
(454,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:00'),
(455,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:16'),
(456,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:41:29'),
(457,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:53'),
(458,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:47:41'),
(459,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:48:15'),
(460,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:48:52'),
(461,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.171','2026-07-12 09:04:47'),
(462,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.212.78','2026-07-12 09:22:41'),
(463,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 09:28:44'),
(464,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 09:28:51'),
(465,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.78','2026-07-12 09:29:43'),
(466,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.241','2026-07-12 09:47:31'),
(467,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.146','2026-07-12 10:11:51'),
(468,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.146','2026-07-12 10:28:03'),
(469,0,'anonymous','update','app',12,'置顶应用ID:12','39.144.124.146','2026-07-12 11:30:53'),
(470,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.245','2026-07-12 11:42:12'),
(471,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.245','2026-07-12 12:44:45'),
(472,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.81','2026-07-12 13:44:34'),
(473,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 13:51:30'),
(474,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 14:17:21'),
(475,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 14:18:22'),
(476,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 14:18:29'),
(477,0,'anonymous','update','sys_config',0,'切换PC布局主题: pc','::ffff:127.0.0.1','2026-07-12 14:18:29'),
(478,19,'alexmorgan','update','plugin',5,'禁用插件「地图组件」','117.136.111.47','2026-07-12 14:47:30'),
(479,19,'alexmorgan','update','plugin',5,'启用插件「地图组件」','117.136.111.47','2026-07-12 14:47:31'),
(480,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:00:52'),
(481,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 15:20:39'),
(482,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:25:39'),
(483,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:52:25'),
(484,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"MallManage\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"上下架\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-manage\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-8 4c0 .55-.45 1-1 1s-1-.45-1-1V8h2v2zm4-1c.55 0 1-.45 1-1V8h-2v2c0 .55.45 1 1 1z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:43'),
(485,0,'admin','update','menu',58,'更新菜单\"订单管理\"。旧数据:{\"id\":58,\"parent_id\":56,\"name\":\"MallOrders\",\"path\":\"/appstore/mall-orders\",\"component\":\"/appstore/admin/mall/mall-orders\",\"redirect\":\"\",\"title\":\"订单管理\",\"icon\":\"ri:file-list-3-line\",\"sort_order\":2,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"处理\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"导出\\\",\\\"authMark\\\":\\\"export\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-orders\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:51'),
(486,0,'admin','update','menu',59,'更新菜单\"分类管理\"。旧数据:{\"id\":59,\"parent_id\":56,\"name\":\"MallCategories\",\"path\":\"/appstore/mall-categories\",\"component\":\"/appstore/admin/mall/mall-categories\",\"redirect\":\"\",\"title\":\"分类管理\",\"icon\":\"ri:price-tag-3-line\",\"sort_order\":3,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-categories\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.22-1.05-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:58'),
(487,0,'admin','update','menu',60,'更新菜单\"售后服务\"。旧数据:{\"id\":60,\"parent_id\":56,\"name\":\"MallAfterSales\",\"path\":\"/appstore/mall-after-sales\",\"component\":\"/appstore/admin/mall/mall-after-sales\",\"redirect\":\"\",\"title\":\"售后服务\",\"icon\":\"ri:customer-service-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"处理\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-after-sales\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12c0 5.32 3.36 9.82 8.03 11.49.63.23 1.29.4 1.97.52.68.12 1.34.12 2.03 0 .68-.12 1.34-.29 1.97-.52C20.64 21.82 24 17.32 24 12 24 6.48 19.52 2 14 2zm-2 15h4v2h-4v-2zm4-4H8c0-3.31 2.69-6 6-6s6 2.69 6 6h-4z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:09:06'),
(488,0,'admin','update','menu',61,'更新菜单\"优惠活动\"。旧数据:{\"id\":61,\"parent_id\":56,\"name\":\"MallPromotions\",\"path\":\"/appstore/mall-promotions\",\"component\":\"/appstore/admin/mall/mall-promotions\",\"redirect\":\"\",\"title\":\"优惠活动\",\"icon\":\"ri:gift-line\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-promotions\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-4-4h-2V6h-2v2h-2v2h2v2h2v-2h2V8z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:09:13'),
(489,0,'admin','update','menu',68,'更新菜单\"存储文件\"。旧数据:{\"id\":68,\"parent_id\":54,\"name\":\"StorageFiles\",\"path\":\"/system/storage-files\",\"component\":\"/system/storage-files\",\"redirect\":\"\",\"title\":\"存储文件\",\"icon\":\"ri:hard-drive-3-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"上传\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/storage-files\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T09:31:24.000Z\",\"update_time\":\"2026-07-11T09:31:24.000Z\"}','117.136.111.47','2026-07-12 16:09:23'),
(490,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":54,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-repo-manage\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:27:10.000Z\"}','117.136.111.47','2026-07-12 16:09:29'),
(491,0,'admin','update','menu',16,'更新菜单\"文件上传策略\"。旧数据:{\"id\":16,\"parent_id\":54,\"name\":\"FilePolicyManage\",\"path\":\"filepolicy\",\"component\":\"/operation/filepolicy/index\",\"redirect\":\"\",\"title\":\"文件上传策略\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-policy-manage\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:26:58.000Z\"}','117.136.111.47','2026-07-12 16:09:37'),
(492,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":54,\"name\":\"StorageConfig\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/storage-config\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM6 20V4h5v7h7v9H6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:27:43.000Z\"}','117.136.111.47','2026-07-12 16:09:44'),
(493,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"商品管理\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-12T08:08:43.000Z\"}','117.136.111.47','2026-07-12 16:10:39'),
(494,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"MallAfterSales\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-12T08:10:39.000Z\"}','117.136.111.47','2026-07-12 16:10:51'),
(495,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":54,\"name\":\"对象存储\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T08:09:44.000Z\"}','117.136.111.47','2026-07-12 16:24:10'),
(496,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','117.136.111.47','2026-07-12 16:51:24'),
(497,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"/awsdb\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"上传\\\",\\\"authMark\\\":\\\"upload\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"下载\\\",\\\"authMark\\\":\\\"download\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:29:37.000Z\"}','223.160.214.185','2026-07-12 17:15:51'),
(498,0,'anonymous','update','role_permission',22,'更新角色权限','223.160.214.185','2026-07-12 17:16:41'),
(499,0,'anonymous','update','role_permission',20,'更新角色权限','223.160.214.185','2026-07-12 17:16:45'),
(500,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.111','2026-07-12 18:25:56'),
(501,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_default_group, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 18:48:43'),
(502,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_default_group, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 18:49:07'),
(503,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:08:48'),
(504,0,'anonymous','update','membership',3,'更新会员等级\"钻石会员\"','::ffff:127.0.0.1','2026-07-12 19:13:46'),
(505,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:16:39'),
(506,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:17:09'),
(507,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:17:11'),
(508,0,'35735712','create','user',10001,'用户注册','','2026-07-12 19:18:20'),
(509,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:24:11'),
(510,0,'admin','create','menu',70,'新建菜单\"awdtc\"，路径:','223.160.209.111','2026-07-12 19:26:16'),
(511,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"awdtc\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:16.000Z\"}','223.160.209.111','2026-07-12 19:26:27'),
(512,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:27.000Z\"}','223.160.209.111','2026-07-12 19:26:32'),
(513,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:32.000Z\"}','223.160.209.111','2026-07-12 19:26:36'),
(514,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":3,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"/system/sysconfig/index\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"\",\"sort_order\":12,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M19.14 12.94c.04-.3.06-.61.06-.94 0-.33-.02-.64-.06-.94l2.02-1.58c.18-.14.23-.38.12-.56l-1.89-3.28c-.12-.19-.36-.26-.56-.18l-2.38.96c-.5-.38-1.06-.68-1.66-.88L14.45 3.5c-.04-.2-.2-.34-.4-.34h-3.78c-.2 0-.36.14-.4.34l-.3 2.52c-.6.2-1.16.5-1.66.88l-2.38-.96c-.2-.08-.44-.01-.56.18L3.28 9.52c-.12.19-.06.42.12.56l2.02 1.58c-.04.3-.06.61-.06.94s.02.64.06.94l-2.02 1.58c-.18.14-.23.38-.12.56l1.89 3.28c.12.19.36.26.56.18l2.38-.96c.5.38 1.06.68 1.66.88l.3 2.52c.04.2.2.34.4.34h3.78c.2 0 .36-.14.4-.34l.3-2.52c.6-.2 1.16-.5 1.66-.88l2.38.96c.2.08.44.01.56-.18l1.89-3.28c.12-.19.06-.42-.12-.56l-2.02-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:29:28'),
(515,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":3,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-config\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:24:27.000Z\"}','223.160.209.111','2026-07-12 19:29:42'),
(516,0,'admin','update','menu',34,'更新菜单\"邮件卡片\"。旧数据:{\"id\":34,\"parent_id\":3,\"name\":\"EmailTemplates\",\"path\":\"email-templates\",\"component\":\"/appstore/email-templates\",\"redirect\":\"\",\"title\":\"邮件卡片\",\"icon\":\"\",\"sort_order\":14,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-templates\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:29:55'),
(517,0,'admin','update','menu',35,'更新菜单\"邮件推送\"。旧数据:{\"id\":35,\"parent_id\":3,\"name\":\"EmailPush\",\"path\":\"email-push\",\"component\":\"/appstore/email-push\",\"redirect\":\"\",\"title\":\"邮件推送\",\"icon\":\"\",\"sort_order\":15,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-push\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:30:13'),
(518,0,'admin','update','menu',65,'更新菜单\"支付配置\"。旧数据:{\"id\":65,\"parent_id\":2,\"name\":\"PaymentConfig\",\"path\":\"/operation/payment-config\",\"component\":\"/operation/payment-config/index\",\"redirect\":\"\",\"title\":\"支付配置\",\"icon\":\"ri:bank-card-line\",\"sort_order\":24,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/payment-config\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4H4V6h16v2zm-8 4H7v2h5v-2zm3 0h2v2h-2v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:30:32'),
(519,0,'admin','update','menu',66,'更新菜单\"充值金额配置\"。旧数据:{\"id\":66,\"parent_id\":2,\"name\":\"RechargeAmounts\",\"path\":\"/operation/recharge-amounts\",\"component\":\"/operation/recharge-amounts/index\",\"redirect\":\"\",\"title\":\"充值金额配置\",\"icon\":\"ri:money-cny-circle-line\",\"sort_order\":25,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/recharge-amounts\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:30:42'),
(520,0,'admin','update','menu',63,'更新菜单\"布局主题\"。旧数据:{\"id\":63,\"parent_id\":2,\"name\":\"LayoutThemesManage\",\"path\":\"/operation/layout-themes\",\"component\":\"/operation/themes/index\",\"redirect\":\"\",\"title\":\"布局主题\",\"icon\":\"ri:palette-line\",\"sort_order\":22,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/layout-themes\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-4.5 8c-.83 0-1.5-.67-1.5-1.5S6.67 8 7.5 8 9 8.67 9 9.5 8.33 11 7.5 11zm9 0c-.83 0-1.5-.67-1.5-1.5S15.67 8 16.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:31:19'),
(521,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:36.000Z\"}','223.160.209.111','2026-07-12 19:32:11'),
(522,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"/arccg\",\"component\":\"/sfccg\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:32:11.000Z\"}','223.160.209.111','2026-07-12 19:33:09'),
(523,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(524,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":70,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:41.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(525,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":70,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"/system/sysconfig/index\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"\",\"sort_order\":12,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:28.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(526,0,'admin','update','menu',34,'更新菜单\"邮件卡片\"。旧数据:{\"id\":34,\"parent_id\":70,\"name\":\"EmailTemplates\",\"path\":\"email-templates\",\"component\":\"/appstore/email-templates\",\"redirect\":\"\",\"title\":\"邮件卡片\",\"icon\":\"\",\"sort_order\":14,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:55.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(527,0,'admin','update','menu',35,'更新菜单\"邮件推送\"。旧数据:{\"id\":35,\"parent_id\":70,\"name\":\"EmailPush\",\"path\":\"email-push\",\"component\":\"/appstore/email-push\",\"redirect\":\"\",\"title\":\"邮件推送\",\"icon\":\"\",\"sort_order\":15,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:30:13.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(528,0,'admin','update','menu',63,'更新菜单\"布局主题\"。旧数据:{\"id\":63,\"parent_id\":70,\"name\":\"LayoutThemesManage\",\"path\":\"/operation/layout-themes\",\"component\":\"/operation/themes/index\",\"redirect\":\"\",\"title\":\"布局主题\",\"icon\":\"ri:palette-line\",\"sort_order\":22,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:31:19.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(529,0,'admin','update','menu',65,'更新菜单\"支付配置\"。旧数据:{\"id\":65,\"parent_id\":70,\"name\":\"PaymentConfig\",\"path\":\"/operation/payment-config\",\"component\":\"/operation/payment-config/index\",\"redirect\":\"\",\"title\":\"支付配置\",\"icon\":\"ri:bank-card-line\",\"sort_order\":24,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:30:32.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(530,0,'admin','update','menu',66,'更新菜单\"充值金额配置\"。旧数据:{\"id\":66,\"parent_id\":70,\"name\":\"RechargeAmounts\",\"path\":\"/operation/recharge-amounts\",\"component\":\"/operation/recharge-amounts/index\",\"redirect\":\"\",\"title\":\"充值金额配置\",\"icon\":\"ri:money-cny-circle-line\",\"sort_order\":25,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:30:42.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(531,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:36:24'),
(532,0,'admin','create','menu',71,'新建菜单\"站点配置\"，路径:/appstore/site-config','::ffff:127.0.0.1','2026-07-12 19:36:24'),
(533,0,'admin','delete','menu',71,'删除菜单\"站点配置\"。被删除数据:{\"id\":71,\"parent_id\":70,\"name\":\"SiteConfig\",\"path\":\"/appstore/site-config\",\"component\":\"\",\"redirect\":\"\",\"title\":\"站点配置\",\"icon\":\"ri:global-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#FF4757\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z\",\"category\":\"\",\"create_time\":\"2026-07-12T11:36:24.000Z\",\"update_time\":\"2026-07-12T11:36:24.000Z\"}','223.160.209.111','2026-07-12 19:38:19'),
(534,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:45:16'),
(535,0,'admin','create','menu',72,'新建菜单\"短信配置\"，路径:/appstore/sms-config','::ffff:127.0.0.1','2026-07-12 19:45:16'),
(536,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:45:22'),
(537,19,'alexmorgan','add','sms_config',1,'添加短信配置: yunpian','::ffff:127.0.0.1','2026-07-12 19:45:22'),
(538,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:47:09'),
(539,0,'admin','create','menu',73,'新建菜单\"站点配置\"，路径:/appstore/site-config','::ffff:127.0.0.1','2026-07-12 19:47:09'),
(540,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:53:13'),
(541,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:53:38'),
(542,19,'alexmorgan','add','sms_config',2,'添加短信配置: aliyun','::ffff:127.0.0.1','2026-07-12 19:53:38'),
(543,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:56:06'),
(544,19,'alexmorgan','add','sms_config',3,'添加短信配置: tencent','::ffff:127.0.0.1','2026-07-12 19:56:06'),
(545,19,'alexmorgan','edit','sms_config',2,'更新短信配置: aliyun','223.160.209.111','2026-07-12 20:01:46'),
(546,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:12'),
(547,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:52'),
(548,19,'alexmorgan','add','sms_config',4,'添加短信配置: huawei','::ffff:127.0.0.1','2026-07-12 20:08:52'),
(549,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:57'),
(550,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:26:05'),
(551,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:00'),
(552,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:06'),
(553,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:34'),
(554,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:39'),
(555,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:46'),
(556,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:50'),
(557,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:33:10'),
(558,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','223.160.208.247','2026-07-12 20:35:45'),
(559,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','223.160.208.247','2026-07-12 20:36:06'),
(560,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:37:44'),
(561,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 20:41:29'),
(562,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 20:43:06'),
(563,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:44:39'),
(564,19,'alexmorgan','update','user',10001,'更新用户信息','','2026-07-12 20:44:39'),
(565,19,'alexmorgan','update','user',19,'更新用户信息','','2026-07-12 20:45:27'),
(566,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:59:53'),
(567,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 21:08:50'),
(568,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 21:16:30'),
(569,0,'anonymous','update','app',12,'精品推荐应用ID:12','223.160.209.247','2026-07-12 21:51:59'),
(570,0,'admin','update','menu',6,'更新菜单\"审核中心\"。旧数据:{\"id\":6,\"parent_id\":0,\"name\":\"AppStore\",\"path\":\"/appstore\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"应用商店\",\"icon\":\"ri:apps-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:30:54'),
(571,0,'admin','update','menu',6,'更新菜单\"审核中心\"。旧数据:{\"id\":6,\"parent_id\":0,\"name\":\"AppStore\",\"path\":\"/appstore\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"审核中心\",\"icon\":\"ri:apps-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T15:30:54.000Z\"}','223.160.211.115','2026-07-12 23:31:00'),
(572,0,'admin','update','menu',1,'更新菜单\"仪表盘\"。旧数据:{\"id\":1,\"parent_id\":0,\"name\":\"Dashboard\",\"path\":\"/dashboard\",\"component\":\"/index/index\",\"redirect\":\"/dashboard/console\",\"title\":\"仪表盘\",\"icon\":\"ri:pie-chart-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:31:19'),
(573,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.211.115','2026-07-12 23:37:37'),
(574,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":70,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"ri:settings-3-line\",\"sort_order\":0,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#2ED573\",\"icon_svg\":\"M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94L14.4 2.81c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41L9.25 5.35c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:36:15.000Z\"}','223.160.211.115','2026-07-12 23:39:02'),
(575,0,'anonymous','update','withdraw',4,'审核提现ID:4 拒绝','223.160.211.115','2026-07-12 23:39:30'),
(576,0,'anonymous','update','withdraw',7,'审核提现ID:7 拒绝(666)','223.160.211.115','2026-07-12 23:45:35'),
(577,0,'admin','update','menu',25,'更新菜单\"提现注销审核\"。旧数据:{\"id\":25,\"parent_id\":3,\"name\":\"DeleteReview\",\"path\":\"delete-review\",\"component\":\"/system/user/delete-review\",\"redirect\":\"\",\"title\":\"注销审核\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/delete-review\",\"icon_bg\":\"#70A1FF\",\"icon_svg\":\"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:50:18'),
(578,0,'admin','update','menu',25,'更新菜单\"提现注销审核\"。旧数据:{\"id\":25,\"parent_id\":3,\"name\":\"DeleteReview\",\"path\":\"delete-review\",\"component\":\"/system/user/delete-review\",\"redirect\":\"\",\"title\":\"提现注销审核\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T15:50:18.000Z\"}','223.160.211.115','2026-07-12 23:50:44'),
(579,0,'admin','update','menu',26,'更新菜单\"蓝V认证审核\"。旧数据:{\"id\":26,\"parent_id\":3,\"name\":\"Verification\",\"path\":\"verification\",\"component\":\"/system/verification/index\",\"redirect\":\"\",\"title\":\"蓝V认证审核\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/verification-manage\",\"icon_bg\":\"#FB923C\",\"icon_svg\":\"M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:50:44'),
(580,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 10:22:10'),
(581,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 11:13:35'),
(582,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','39.144.124.108','2026-07-13 11:13:48'),
(583,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','39.144.124.108','2026-07-13 11:13:53'),
(584,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 11:35:41'),
(585,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','39.144.124.108','2026-07-13 11:35:52'),
(586,19,'alexmorgan','approve','post',14,'审核通过帖子《2026最新设计资源合集：UI组件库、插画素材、字体包一次性打包》','','2026-07-13 12:17:06'),
(587,19,'alexmorgan','reject','post',13,'驳回帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》，原因：6666','','2026-07-13 12:17:13'),
(588,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:19:02'),
(589,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:20:45'),
(590,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:08'),
(591,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:25'),
(592,19,'alexmorgan','essence','post',13,'设为精华帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:33'),
(593,19,'alexmorgan','pin','post',13,'版块置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:36'),
(594,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:37'),
(595,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:39'),
(596,19,'alexmorgan','hot','post',13,'设为热帖帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:42'),
(597,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:44'),
(598,19,'alexmorgan','unlock','post',13,'解锁帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:46'),
(599,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:49'),
(600,19,'alexmorgan','unlock','post',13,'解锁帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:53'),
(601,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:55'),
(602,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.208.183','2026-07-13 12:50:55'),
(603,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.183','2026-07-13 12:54:46'),
(604,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.183','2026-07-13 12:59:29'),
(605,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.40','2026-07-13 14:09:14'),
(606,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-13 14:21:29'),
(607,0,'anonymous','update','withdraw',1,'审核提现ID:1 通过','223.160.208.40','2026-07-13 14:24:49'),
(608,0,'anonymous','update','withdraw',1,'审核提现ID:1 通过','223.160.208.40','2026-07-13 14:24:49'),
(609,0,'anonymous','update','withdraw',9,'审核提现ID:9 通过','223.160.208.40','2026-07-13 14:24:58'),
(610,0,'anonymous','update','withdraw',9,'审核提现ID:9 通过','223.160.208.40','2026-07-13 14:24:58'),
(611,0,'anonymous','update','withdraw',9,'审核提现ID:9 拒绝','223.160.208.40','2026-07-13 14:24:58'),
(612,0,'anonymous','update','withdraw',9,'审核提现ID:9 拒绝','223.160.208.40','2026-07-13 14:24:58'),
(613,0,'admin','update','menu',44,'更新菜单\"官方标签\"。旧数据:{\"id\":44,\"parent_id\":6,\"name\":\"OfficialTags\",\"path\":\"official-tags\",\"component\":\"/appstore/official-tags\",\"redirect\":\"\",\"title\":\"官方标签\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/official-tags\",\"icon_bg\":\"#FCA5A5\",\"icon_svg\":\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.6','2026-07-13 15:04:21'),
(614,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.72','2026-07-13 16:39:07'),
(615,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 18:30:36'),
(616,19,'alexmorgan','unpin','post',6,'取消全站置顶帖子《设计师如何提升审美》','','2026-07-13 18:32:35'),
(617,19,'system','delete','post',15,'作者删除帖子《测试编辑帖子6》','','2026-07-13 18:33:17'),
(618,19,'system','delete','post',14,'作者删除帖子《2026最新设计资源合集：UI组件库、插画素材、字体包一次性打包》','','2026-07-13 18:33:30'),
(619,19,'system','delete','post',13,'作者删除帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 18:33:45'),
(620,19,'system','delete','post',3,'管理员删除帖子《React 19 新特性解读》','','2026-07-13 18:33:51'),
(621,19,'system','delete','post',7,'管理员删除帖子《Cloud Native架构实践》','','2026-07-13 18:33:54'),
(622,19,'system','delete','post',9,'管理员删除帖子《像素艺术创作技巧》','','2026-07-13 18:33:57'),
(623,19,'system','delete','post',11,'管理员删除帖子《独立游戏开发日记》','','2026-07-13 18:34:00'),
(624,19,'system','delete','post',6,'管理员删除帖子《设计师如何提升审美》','','2026-07-13 18:34:03'),
(625,19,'system','delete','post',1,'管理员删除帖子《分享我的设计作品集》','','2026-07-13 18:34:06'),
(626,19,'system','delete','post',2,'管理员删除帖子《AI绘画入门指南》','','2026-07-13 18:34:10'),
(627,19,'system','delete','post',5,'管理员删除帖子《Vue3 + TypeScript 实战》','','2026-07-13 18:34:18'),
(628,19,'system','delete','post',4,'管理员删除帖子《我的应用开发历程》','','2026-07-13 18:34:22'),
(629,19,'alexmorgan','approve','post',16,'审核通过帖子《666》','','2026-07-13 18:58:52'),
(630,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 19:02:59'),
(631,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:08:04'),
(632,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:14:08'),
(633,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.209.36','2026-07-13 19:14:37'),
(634,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.209.36','2026-07-13 19:14:59'),
(635,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.209.36','2026-07-13 19:15:11'),
(636,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:15:24'),
(637,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.209.36','2026-07-13 19:15:42'),
(638,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:15:56'),
(639,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:16:34'),
(640,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:16:43'),
(641,19,'alexmorgan','create','experience',8,'新增经验等级\"LV.8\"','223.160.209.36','2026-07-13 19:17:12'),
(642,19,'alexmorgan','create','experience',9,'新增经验等级\"LV.9\"','223.160.209.36','2026-07-13 19:17:49'),
(643,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:19:36'),
(644,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:21:19'),
(645,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:22:24'),
(646,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.209.36','2026-07-13 19:22:46'),
(647,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 19:37:39'),
(648,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:37:53'),
(649,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.208.36','2026-07-13 19:38:22'),
(650,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.208.36','2026-07-13 19:38:34'),
(651,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:38:54'),
(652,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:39:00'),
(653,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.209.36','2026-07-13 19:39:21'),
(654,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:39:29'),
(655,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:39:50'),
(656,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:40:01'),
(657,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.209.36','2026-07-13 19:40:14'),
(658,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.209.36','2026-07-13 19:40:23'),
(659,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:41:18'),
(660,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:03:58'),
(661,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:11'),
(662,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:28'),
(663,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:39'),
(664,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.208.36','2026-07-13 20:19:12'),
(665,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 21:04:48'),
(666,19,'alexmorgan','pin','post',16,'版块置顶帖子《666》','','2026-07-13 21:04:54'),
(667,19,'alexmorgan','unpin','post',16,'取消版块置顶帖子《666》','','2026-07-13 21:04:56'),
(668,19,'alexmorgan','essence','post',16,'设为精华帖子《666》','','2026-07-13 21:04:57'),
(669,19,'alexmorgan','hot','post',16,'设为热帖帖子《666》','','2026-07-13 21:04:58'),
(670,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:13:19'),
(671,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:13:39'),
(672,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:20:01'),
(673,19,'alexmorgan','approve','post',17,'审核通过帖子《8888888888》','','2026-07-13 21:21:18'),
(674,19,'alexmorgan','set_badge','post',16,'设置自定义徽章《666》：8888','','2026-07-13 21:24:09'),
(675,19,'alexmorgan','lock','post',16,'锁定帖子《666》','','2026-07-13 21:24:12'),
(676,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','223.160.209.36','2026-07-13 21:29:31'),
(677,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 21:44:05'),
(678,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 21:44:14'),
(679,19,'alexmorgan','create','title',10,'新增称号\"蓝V官方认证\"','223.160.209.36','2026-07-13 21:52:48'),
(680,19,'alexmorgan','update','title',10,'授予用户19称号ID:10','223.160.209.36','2026-07-13 21:52:57'),
(681,19,'alexmorgan','create','title',11,'新增称号\"官方认证\"','223.160.209.249','2026-07-13 22:16:52'),
(682,19,'alexmorgan','update','title',11,'授予用户19称号ID:11','223.160.209.249','2026-07-13 22:17:04'),
(683,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:25:11'),
(684,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.214.60','2026-07-13 22:39:12'),
(685,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.214.60','2026-07-13 22:39:21'),
(686,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.214.60','2026-07-13 22:40:28'),
(687,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:40:37'),
(688,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:40:45'),
(689,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:40:54'),
(690,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:41:03'),
(691,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:41:11'),
(692,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:41:19'),
(693,19,'alexmorgan','create','experience',10,'新增经验等级\"10\"','223.160.214.60','2026-07-13 22:41:32'),
(694,19,'alexmorgan','create','experience',11,'新增经验等级\"11\"','223.160.214.60','2026-07-13 22:41:54'),
(695,19,'alexmorgan','create','experience',12,'新增经验等级\"12\"','223.160.214.60','2026-07-13 22:42:10'),
(696,19,'alexmorgan','create','experience',13,'新增经验等级\"13\"','223.160.214.60','2026-07-13 22:42:22'),
(697,19,'alexmorgan','create','experience',14,'新增经验等级\"14\"','223.160.214.60','2026-07-13 22:42:33'),
(698,19,'alexmorgan','create','experience',15,'新增经验等级\"15\"','223.160.214.60','2026-07-13 22:42:42'),
(699,19,'alexmorgan','create','experience',16,'新增经验等级\"16\"','223.160.214.60','2026-07-13 22:42:53'),
(700,19,'alexmorgan','create','experience',17,'新增经验等级\"17\"','223.160.214.60','2026-07-13 22:43:06'),
(701,19,'alexmorgan','create','experience',18,'新增经验等级\"18\"','223.160.214.60','2026-07-13 22:43:18'),
(702,19,'alexmorgan','create','experience',19,'新增经验等级\"19\"','223.160.214.60','2026-07-13 22:43:29'),
(703,19,'alexmorgan','create','experience',20,'新增经验等级\"20\"','223.160.214.60','2026-07-13 22:43:47'),
(704,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.214.60','2026-07-13 22:44:26'),
(705,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.214.60','2026-07-13 22:44:31'),
(706,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:44:36'),
(707,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:44:39'),
(708,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:44:43'),
(709,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:44:47'),
(710,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:44:57'),
(711,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:45:03'),
(712,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:45:13'),
(713,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:45:21'),
(714,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:45:38'),
(715,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:45:45'),
(716,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:45:53'),
(717,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:46:02'),
(718,19,'alexmorgan','update','experience',13,'更新经验等级\"13\"','223.160.214.60','2026-07-13 22:46:13'),
(719,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:46:27'),
(720,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:46:55'),
(721,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:46:59'),
(722,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:47:20'),
(723,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:47:26'),
(724,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:47:32'),
(725,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:47:41'),
(726,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:48:00'),
(727,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:48:07'),
(728,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:48:17'),
(729,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:48:25'),
(730,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:48:33'),
(731,19,'alexmorgan','update','experience',13,'更新经验等级\"13\"','223.160.214.60','2026-07-13 22:48:42'),
(732,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:48:55'),
(733,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:49:06'),
(734,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:49:20'),
(735,19,'alexmorgan','update','experience',15,'更新经验等级\"15\"','223.160.214.60','2026-07-13 22:49:26'),
(736,19,'alexmorgan','update','experience',16,'更新经验等级\"16\"','223.160.214.60','2026-07-13 22:49:30'),
(737,19,'alexmorgan','update','experience',17,'更新经验等级\"17\"','223.160.214.60','2026-07-13 22:49:36'),
(738,19,'alexmorgan','update','experience',18,'更新经验等级\"18\"','223.160.214.60','2026-07-13 22:49:43'),
(739,19,'alexmorgan','update','experience',19,'更新经验等级\"19\"','223.160.214.60','2026-07-13 22:49:53'),
(740,19,'alexmorgan','update','experience',20,'更新经验等级\"20\"','223.160.214.60','2026-07-13 22:50:07'),
(741,19,'alexmorgan','update','experience',10,'更新经验等级\"LV.10\"','223.160.214.60','2026-07-13 22:50:39'),
(742,19,'alexmorgan','update','experience',11,'更新经验等级\"LV.11\"','223.160.214.60','2026-07-13 22:50:49'),
(743,19,'alexmorgan','update','experience',20,'更新经验等级\"LV.20\"','223.160.214.60','2026-07-13 22:50:55'),
(744,19,'alexmorgan','update','experience',19,'更新经验等级\"LV.19\"','223.160.214.60','2026-07-13 22:51:01'),
(745,19,'alexmorgan','update','experience',18,'更新经验等级\"LV.18\"','223.160.214.60','2026-07-13 22:51:07'),
(746,19,'alexmorgan','update','experience',17,'更新经验等级\"LV.17\"','223.160.214.60','2026-07-13 22:51:12'),
(747,19,'alexmorgan','update','experience',16,'更新经验等级\"LV.16\"','223.160.214.60','2026-07-13 22:51:18'),
(748,19,'alexmorgan','update','experience',15,'更新经验等级\"LV.15\"','223.160.214.60','2026-07-13 22:51:22'),
(749,19,'alexmorgan','update','experience',14,'更新经验等级\"LV.14\"','223.160.214.60','2026-07-13 22:51:30'),
(750,19,'alexmorgan','update','experience',13,'更新经验等级\"LV.13\"','223.160.214.60','2026-07-13 22:51:36'),
(751,19,'alexmorgan','update','experience',12,'更新经验等级\"LV.12\"','223.160.214.60','2026-07-13 22:51:42'),
(752,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','223.160.213.155','2026-07-13 23:13:56'),
(753,19,'alexmorgan','delete','title',10,'撤销用户19称号ID:10','223.160.213.155','2026-07-13 23:15:03'),
(754,19,'alexmorgan','update','title',10,'授予用户19称号ID:10','223.160.213.155','2026-07-13 23:15:06'),
(755,19,'alexmorgan','update','title',9,'授予用户19称号ID:9','223.160.213.155','2026-07-13 23:15:11'),
(756,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','223.160.213.155','2026-07-13 23:30:00'),
(757,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-13 23:52:32'),
(758,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:57:42'),
(759,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:58:46'),
(760,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:58:55'),
(761,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:01:26'),
(762,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:02:22'),
(763,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:02:51'),
(764,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 09:45:21'),
(765,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','117.136.111.23','2026-07-14 10:07:29'),
(766,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-14 10:35:53'),
(767,19,'system','delete','post',16,'作者删除帖子《666》','','2026-07-14 11:43:44'),
(768,19,'system','delete','post',17,'作者删除帖子《8888888888》','','2026-07-14 12:01:29'),
(769,19,'system','delete','post',10,'管理员删除帖子《面试经历分享》','','2026-07-14 12:01:39'),
(770,19,'system','delete','post',8,'管理员删除帖子《移动开发趋势2026》','','2026-07-14 12:01:54'),
(771,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 12:22:22'),
(772,19,'alexmorgan','approve','post',18,'审核通过帖子《66666》','','2026-07-14 12:23:02'),
(773,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 12:59:34'),
(774,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 13:55:32'),
(775,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 14:00:13'),
(776,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 14:23:57'),
(777,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.63','2026-07-14 15:16:22'),
(778,19,'alexmorgan','update','user',10001,'更新用户信息','','2026-07-14 15:17:21'),
(779,0,'anonymous','login','user',10001,'用户 35735712 登录','39.144.124.34','2026-07-14 15:35:17'),
(780,0,'anonymous','login','user',10001,'用户 35735712 登录','39.144.124.34','2026-07-14 15:35:50'),
(781,19,'alexmorgan','update','avatar_frame',1,'更新头像框\"金色边框\"','117.136.111.67','2026-07-14 21:06:43'),
(782,19,'alexmorgan','update','avatar_frame',1,'授予用户19头像框ID:1','117.136.111.67','2026-07-14 21:06:48'),
(783,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.67','2026-07-15 00:14:52'),
(784,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.67','2026-07-15 00:14:57'),
(785,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.62','2026-07-15 04:07:47'),
(786,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 04:14:36'),
(787,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 04:16:21'),
(788,19,'alexmorgan','approve','post',19,'审核通过帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 04:19:28'),
(789,19,'alexmorgan','approve','post',20,'审核通过帖子《社区卡片与多媒体模块功能测试 - 互动组件篇》','','2026-07-15 04:19:29'),
(790,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:20:48'),
(791,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:33:28'),
(792,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:33:37'),
(793,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.213.200','2026-07-15 04:46:11'),
(794,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.210.82','2026-07-15 05:37:57'),
(795,19,'alexmorgan','approve','post',22,'审核通过帖子《666》','','2026-07-15 05:45:13'),
(796,19,'alexmorgan','pin','post',22,'版块置顶帖子《666》','','2026-07-15 06:11:11'),
(797,19,'alexmorgan','unpin','post',22,'取消版块置顶帖子《666》','','2026-07-15 06:11:13'),
(798,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.210.82','2026-07-15 06:54:47'),
(799,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-15 10:47:14'),
(800,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-15 13:05:02'),
(801,19,'alexmorgan','lock','post',22,'锁定帖子《666》','','2026-07-15 16:03:35'),
(802,19,'alexmorgan','unlock','post',22,'解锁帖子《666》','','2026-07-15 16:03:37'),
(803,19,'alexmorgan','hot','post',22,'设为热帖帖子《666》','','2026-07-15 16:03:38'),
(804,19,'alexmorgan','essence','post',22,'设为精华帖子《666》','','2026-07-15 16:03:40'),
(805,19,'alexmorgan','pin','post',22,'版块置顶帖子《666》','','2026-07-15 16:03:42'),
(806,19,'alexmorgan','pin','post',22,'全站置顶帖子《666》','','2026-07-15 16:03:43'),
(807,19,'alexmorgan','unpin','post',22,'取消全站置顶帖子《666》','','2026-07-15 16:03:45'),
(808,19,'alexmorgan','unpin','post',22,'取消版块置顶帖子《666》','','2026-07-15 16:03:47'),
(809,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.215.186','2026-07-15 16:51:09'),
(810,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.86','2026-07-15 18:39:29'),
(811,19,'alexmorgan','pin','post',19,'版块置顶帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 22:37:01'),
(812,19,'alexmorgan','unpin','post',19,'取消版块置顶帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 22:37:03'),
(813,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 23:43:45'),
(814,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 23:44:33'),
(815,19,'alexmorgan','essence','post',28,'设为精华帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-16 00:12:54'),
(816,19,'alexmorgan','hot','post',28,'设为热帖帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-16 00:13:01'),
(817,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:14:17'),
(818,19,'alexmorgan','create','cardkey',22,'生成1张卡密(2000元余额)','117.136.111.31','2026-07-16 00:15:55'),
(819,10001,'35735712','redeem','cardkey',22,'兑换卡密 CDKEY-MRMRD84EXRNR: 2000元余额、额外10000积分、额外5000经验值','','2026-07-16 00:16:12'),
(820,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:18:39'),
(821,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:19:13'),
(822,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 00:46:23'),
(823,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:44'),
(824,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:10:44'),
(825,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:47'),
(826,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:51'),
(827,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:10:51'),
(828,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:12:14'),
(829,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:12:14'),
(830,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:27:18'),
(831,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:27:18'),
(832,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:27:56'),
(833,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 04:05:38'),
(834,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:46:37'),
(835,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:47:47'),
(836,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:47:54'),
(837,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:48:32'),
(838,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:49:21'),
(839,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:53:54'),
(840,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:53:58'),
(841,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:57:56'),
(842,0,'anonymous','login','user',10001,'用户 35735712 登录','112.17.241.147','2026-07-16 15:21:02'),
(843,0,'anonymous','login','user',19,'用户 alexmorgan 登录','112.17.241.147','2026-07-16 16:34:44'),
(844,19,'alexmorgan','approve','post',29,'审核通过帖子《666》','','2026-07-16 16:41:04'),
(845,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 19:25:18'),
(846,0,'anonymous','login','user',10002,'新用户 github_user_mrnwh1hi 通过 github OAuth注册登录','::ffff:127.0.0.1','2026-07-16 19:26:38'),
(847,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.178','2026-07-16 19:39:24'),
(848,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 20:36:12'),
(849,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 20:36:45'),
(850,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:40:20'),
(851,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:41:11'),
(852,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:41:17'),
(853,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:42:28'),
(854,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:47:42'),
(855,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:48:39'),
(856,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:48:45'),
(857,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:49:57'),
(858,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:49:57'),
(859,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:54:03'),
(860,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:56:04'),
(861,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:57:47'),
(862,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:58:34'),
(863,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 21:38:39'),
(864,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.70','2026-07-16 21:47:52'),
(865,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.70','2026-07-16 21:47:59'),
(866,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.9','2026-07-17 02:01:04'),
(867,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:02:08'),
(868,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:13:12'),
(869,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:13:48'),
(870,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:15:18'),
(871,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:15:23'),
(872,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:15:31'),
(873,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:15:41'),
(874,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:19:28'),
(875,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:19:34'),
(876,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:20:34'),
(877,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:20:41'),
(878,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.237','2026-07-17 02:51:08'),
(879,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.237','2026-07-17 05:41:21'),
(880,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.241','2026-07-17 14:35:49'),
(881,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:03:33'),
(882,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:08'),
(883,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:38'),
(884,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:46'),
(885,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:58'),
(886,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:26'),
(887,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:31'),
(888,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:35'),
(889,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:08'),
(890,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:14'),
(891,10004,'admin','add','logistics_config',1,'添加物流配置','::ffff:127.0.0.1','2026-07-17 15:30:14'),
(892,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:21'),
(893,10004,'admin','delete','logistics_config',0,'删除物流配置','::ffff:127.0.0.1','2026-07-17 15:30:21'),
(894,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:27'),
(895,10004,'admin','add','logistics_config',2,'添加物流配置','::ffff:127.0.0.1','2026-07-17 15:30:27'),
(896,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:50:59'),
(897,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:51:07'),
(898,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:52:12'),
(899,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 15:52:19'),
(900,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:53:36'),
(901,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.160','2026-07-17 16:05:41'),
(902,19,'alexmorgan','update','user',19,'更新用户信息','','2026-07-17 16:30:04'),
(903,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 16:36:30'),
(904,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:28'),
(905,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:32'),
(906,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:38'),
(907,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:44'),
(908,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:50'),
(909,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:12:02'),
(910,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:12:13'),
(911,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:15:42'),
(912,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:15:52'),
(913,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:19:55'),
(914,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:19:55'),
(915,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:00'),
(916,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:01'),
(917,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:06'),
(918,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:11'),
(919,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:28'),
(920,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:37'),
(921,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:23:09'),
(922,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:23:16'),
(923,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:28:35'),
(924,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 17:39:08'),
(925,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:41:04'),
(926,0,'anonymous','login','user',10005,'用户 promo_test1 登录','::ffff:127.0.0.1','2026-07-17 17:41:17'),
(927,0,'anonymous','login','user',10006,'用户 promo_buyer 登录','::ffff:127.0.0.1','2026-07-17 17:42:42'),
(928,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:42:42'),
(929,0,'anonymous','login','user',10007,'用户 promo_test2 登录','::ffff:127.0.0.1','2026-07-17 17:44:52'),
(930,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:49:20'),
(931,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:06'),
(932,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:11'),
(933,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:39'),
(934,0,'anonymous','login','user',10008,'用户 promo_pts 登录','::ffff:127.0.0.1','2026-07-17 18:01:17'),
(935,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:02:02'),
(936,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 18:03:23'),
(937,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:03:37'),
(938,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:03:44'),
(939,0,'anonymous','login','user',10010,'用户 promo_dbg 登录','::ffff:127.0.0.1','2026-07-17 18:05:00'),
(940,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:39:28'),
(941,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:39:50'),
(942,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:42:55'),
(943,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:47:26'),
(944,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:47:59'),
(945,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.214.97','2026-07-17 19:22:54'),
(946,0,'anonymous','update','commission_rule',3,'更新返佣规则\"默认返佣(全局)\"','223.160.214.97','2026-07-17 19:24:41'),
(947,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url','223.160.214.97','2026-07-17 20:04:43'),
(948,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content','223.160.214.97','2026-07-17 20:13:04');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_records`
--

DROP TABLE IF EXISTS `task_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `task_id` int(11) NOT NULL,
  `task_name` varchar(200) DEFAULT '',
  `progress` int(11) DEFAULT 0,
  `target_count` int(11) DEFAULT 1,
  `status` varchar(20) DEFAULT 'pending',
  `completed_at` datetime DEFAULT NULL,
  `period_key` varchar(20) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_records_user` (`user_id`),
  KEY `idx_task_records_period` (`period_key`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_records`
--

LOCK TABLES `task_records` WRITE;
/*!40000 ALTER TABLE `task_records` DISABLE KEYS */;
INSERT INTO `task_records` VALUES
(1,7,'',1,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(2,5,'',4,'',0,1,'pending',NULL,'','2026-07-06 22:39:54'),
(3,3,'',3,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(4,7,'',5,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(5,2,'',3,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(6,5,'',4,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(7,4,'',2,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(8,3,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(9,7,'',2,'',0,1,'pending',NULL,'','2026-07-01 22:39:54'),
(10,12,'',5,'',0,1,'pending',NULL,'','2026-06-30 22:39:54'),
(11,6,'',3,'',0,1,'pending',NULL,'','2026-06-28 22:39:54'),
(12,8,'',5,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(13,9,'',3,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(14,10,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(15,5,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(16,11,'',3,'',0,1,'pending',NULL,'','2026-07-10 22:39:54'),
(17,5,'',4,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(18,8,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(19,2,'',5,'',0,1,'pending',NULL,'','2026-06-27 22:39:54'),
(20,15,'',2,'',0,1,'pending',NULL,'','2026-07-07 22:39:54'),
(22,19,'',5,'完善资料',1,1,'completed','2026-07-13 04:31:51','2026-07-13','2026-07-12 20:31:51'),
(23,19,'alexmorgan',3,'评论互动',1,1,'completed','2026-07-13 05:51:42','2026-07-13','2026-07-12 21:51:42'),
(24,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-14 02:34:40','2026-07-14','2026-07-13 18:34:40'),
(25,19,'',5,'完善资料',1,1,'completed','2026-07-14 03:42:23','2026-07-14','2026-07-13 19:42:23'),
(26,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-15 12:17:41','2026-07-15','2026-07-15 04:17:41'),
(27,19,'Alex Morgan',3,'评论互动',1,1,'completed','2026-07-15 12:26:15','2026-07-15','2026-07-15 04:26:15'),
(28,10001,'user_10001',3,'评论互动',1,1,'completed','2026-07-16 08:17:34','2026-07-16','2026-07-16 00:17:34'),
(29,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-17 00:40:43','2026-07-17','2026-07-16 16:40:43'),
(30,10004,'管理员',3,'评论互动',1,1,'completed','2026-07-17 10:15:18','2026-07-17','2026-07-17 02:15:18');
/*!40000 ALTER TABLE `task_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_follows`
--

DROP TABLE IF EXISTS `topic_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_id` (`topic_id`,`user_id`),
  KEY `idx_topic_follows_topic` (`topic_id`),
  KEY `idx_topic_follows_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_follows`
--

LOCK TABLES `topic_follows` WRITE;
/*!40000 ALTER TABLE `topic_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_addresses`
--

DROP TABLE IF EXISTS `user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `is_default` tinyint(4) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_addresses`
--

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;
INSERT INTO `user_addresses` VALUES
(2,1,'测试地址','13800000000','广东','深圳','南山','科技园',0,'2026-07-16 19:41:50'),
(3,19,'123','1347943258','66','77','88','8888',0,'2026-07-16 21:54:36'),
(4,3,'张三','13800138000','广东省','深圳市','南山区','科技园路1号',0,'2026-07-17 15:03:57'),
(5,19,'Alex Morgan','13800138000','广东省','深圳市','南山区','科技园路1号创新大厦1208',1,'2026-07-17 15:52:31');
/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_appeals`
--

DROP TABLE IF EXISTS `user_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_appeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_appeals`
--

LOCK TABLES `user_appeals` WRITE;
/*!40000 ALTER TABLE `user_appeals` DISABLE KEYS */;
INSERT INTO `user_appeals` VALUES
(1,19,'alexmorgan','我冤枉的，请解封','2026-07-20 14:27:10','approved',0,'','2026-07-13 14:21:20','2026-07-13 14:21:24'),
(2,19,'alexmorgan','666','2026-07-20 14:27:10','rejected',0,'no','2026-07-13 16:21:15','2026-07-16 19:30:07'),
(4,10001,'35735712','test appeal','2027-07-14 23:17:00','approved',0,'','2026-07-14 15:30:56','2026-07-14 15:34:39'),
(5,1,'bobwang','[post#1] test bug fix',NULL,'approved',0,'test approval','2026-07-16 19:29:02','2026-07-16 19:29:02'),
(6,1,'bobwang','我的账号被误封了','2099-12-31 23:59:59','approved',19,'已核实，同意解封','2026-07-16 20:36:51','2026-07-16 20:41:17');
/*!40000 ALTER TABLE `user_appeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_avatar_frames`
--

DROP TABLE IF EXISTS `user_avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `frame_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `obtain_type` varchar(20) DEFAULT 'manual',
  `obtain_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`frame_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_avatar_frames`
--

LOCK TABLES `user_avatar_frames` WRITE;
/*!40000 ALTER TABLE `user_avatar_frames` DISABLE KEYS */;
INSERT INTO `user_avatar_frames` VALUES
(1,8,1,0,'manual','2026-07-10 22:39:54'),
(2,8,3,0,'manual','2026-07-10 22:39:54'),
(3,2,1,0,'manual','2026-07-10 22:39:54'),
(4,9,4,0,'manual','2026-07-10 22:39:54'),
(5,9,2,0,'manual','2026-07-10 22:39:54'),
(8,19,1,1,'membership','2026-07-12 00:11:10'),
(53,1,1,1,'manual','2026-07-17 13:04:14'),
(54,1,2,0,'manual','2026-07-17 13:04:14'),
(55,1,3,0,'manual','2026-07-17 13:04:14');
/*!40000 ALTER TABLE `user_avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocker_id` int(11) NOT NULL,
  `blocked_id` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'active',
  `reviewed` tinyint(1) DEFAULT 0,
  `review_notes` text DEFAULT '',
  `reviewer_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `blocker_id` (`blocker_id`,`blocked_id`),
  KEY `idx_user_blocks_blocker` (`blocker_id`),
  KEY `idx_user_blocks_blocked` (`blocked_id`),
  KEY `idx_user_blocks_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
INSERT INTO `user_blocks` VALUES
(1,2,10,'','active',0,'',0,'2026-07-10 22:39:53'),
(2,3,11,'','active',0,'',0,'2026-07-10 22:39:53'),
(3,4,12,'','active',0,'',0,'2026-07-10 22:39:53'),
(4,5,13,'','active',0,'',0,'2026-07-10 22:39:53'),
(5,6,14,'','active',0,'',0,'2026-07-10 22:39:53'),
(6,19,12,'666','cancelled',0,'',0,'2026-07-11 11:46:43');
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_codes`
--

DROP TABLE IF EXISTS `user_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `label` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 0,
  `used_count` int(11) DEFAULT 0,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `auto_generated` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` varchar(100) DEFAULT '',
  `reward_duration` int(11) DEFAULT 0,
  `reward_target_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_codes`
--

LOCK TABLES `user_codes` WRITE;
/*!40000 ALTER TABLE `user_codes` DISABLE KEYS */;
INSERT INTO `user_codes` VALUES
(1,4,'REF-965vi41','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(2,9,'REF-t0omukq','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(3,14,'REF-rnrw7sk','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(4,15,'REF-bjco7s0','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(8,3,'4DD7C002','默认推广码',0,0,1,0,1,'1','','',0,0,'2026-07-17 17:08:38'),
(9,3,'D7180E11','朋友圈活动',10,1,1,1,0,'1','','',0,0,'2026-07-17 17:08:38'),
(10,19,'DEA1DB95','默认推广码',0,1,3,1,1,'1','','',0,0,'2026-07-17 17:12:40'),
(11,19,'4B8CE830','123',1,0,3,0,0,'1','','',0,0,'2026-07-17 17:15:01'),
(12,3,'E537EE57','测试奖励码',5,0,0,0,0,'3','points,balance','100,5',0,0,'2026-07-17 17:20:01'),
(13,3,'EB571FEE','带定价测试',3,0,0,0,0,'3','points,balance','200,5',0,0,'2026-07-17 17:20:28'),
(14,3,'EDE71968','超限测试1',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(15,3,'758D27BC','超限测试2',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(16,3,'56F88295','超限测试3',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(17,19,'7F86DA39','',1,0,3,0,0,'3','membership','36500',36500,0,'2026-07-17 17:30:58');
/*!40000 ALTER TABLE `user_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'unused',
  `coupon_data` text NOT NULL,
  `expire_time` datetime NOT NULL,
  `use_time` datetime DEFAULT NULL,
  `use_scene` varchar(50) DEFAULT '',
  `use_order_id` int(11) DEFAULT 0,
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `remaining_value` decimal(10,2) DEFAULT NULL,
  `receive_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_coupons_user` (`user_id`),
  KEY `idx_user_coupons_status` (`status`),
  KEY `idx_user_coupons_coupon` (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
INSERT INTO `user_coupons` VALUES
(1,12,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(2,10,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(3,6,3,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(4,6,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(5,2,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(6,9,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(7,2,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(8,12,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(9,11,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(10,4,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(11,10,4,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(12,5,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(13,14,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(14,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(15,10,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(16,9,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(17,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(18,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(19,12,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(20,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(21,19,5,'used','{\"name\":\"限时体验券\",\"type\":\"percentage\",\"value\":8,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 19:49:32','2026-07-16 19:42:28','mall',0,0.80,NULL,'2026-07-11 11:49:32'),
(22,1,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:37:08',NULL,'',0,0.00,NULL,'2026-07-11 20:37:08'),
(23,4,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:38:36',NULL,'',0,0.00,NULL,'2026-07-11 20:38:36'),
(37,19,6,'used','{\"name\":\"黄金会员\",\"type\":\"percent\",\"value\":10,\"minOrder\":1,\"maxDiscount\":10,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2030-07-12 04:42:00','2026-07-16 19:42:21','mall',0,1.00,NULL,'2026-07-11 23:42:22'),
(38,19,1,'used','{\"name\":\"新人专享券\",\"type\":\"fixed\",\"value\":5,\"minOrder\":10,\"maxDiscount\":100,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-11 07:51:45','2026-07-12 08:11:10','membership_buy',0,5.00,NULL,'2026-07-11 23:51:45'),
(39,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 00:11:10',NULL,'',0,0.00,NULL,'2026-07-12 00:11:10'),
(40,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 10:37:22',NULL,'',0,0.00,NULL,'2026-07-12 10:37:22'),
(41,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 10:37:47',NULL,'',0,0.00,NULL,'2026-07-12 10:37:47'),
(42,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:38:02',NULL,'',0,0.00,NULL,'2026-07-17 19:38:02'),
(43,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:43:09',NULL,'',0,0.00,NULL,'2026-07-17 19:43:09'),
(44,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:43:15',NULL,'',0,0.00,NULL,'2026-07-17 19:43:15');
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_delete_requests`
--

DROP TABLE IF EXISTS `user_delete_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_delete_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_delete_requests`
--

LOCK TABLES `user_delete_requests` WRITE;
/*!40000 ALTER TABLE `user_delete_requests` DISABLE KEYS */;
INSERT INTO `user_delete_requests` VALUES
(1,13,'',0,'','rejected','2026-07-09 22:39:54'),
(2,7,'',0,'隐私原因','approved','2026-07-02 22:39:54'),
(3,7,'',0,'账号太多','rejected','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `user_delete_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) NOT NULL,
  `following_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `follower_id` (`follower_id`,`following_id`),
  KEY `idx_user_follows_follower` (`follower_id`),
  KEY `idx_user_follows_following` (`following_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES
(1,7,8,'2026-07-10 22:39:53'),
(2,12,2,'2026-07-10 22:39:53'),
(3,7,14,'2026-07-10 22:39:53'),
(4,4,15,'2026-07-10 22:39:53'),
(5,12,10,'2026-07-10 22:39:53'),
(6,8,9,'2026-07-10 22:39:53'),
(7,10,14,'2026-07-10 22:39:53'),
(8,10,6,'2026-07-10 22:39:53'),
(9,3,7,'2026-07-10 22:39:53'),
(10,2,14,'2026-07-10 22:39:53'),
(11,7,5,'2026-07-10 22:39:53'),
(12,11,8,'2026-07-10 22:39:53'),
(13,15,4,'2026-07-10 22:39:53'),
(14,16,6,'2026-07-10 22:39:53'),
(15,5,15,'2026-07-10 22:39:53'),
(16,5,7,'2026-07-10 22:39:53'),
(17,13,15,'2026-07-10 22:39:53'),
(18,2,11,'2026-07-10 22:39:53'),
(19,9,7,'2026-07-10 22:39:53'),
(20,6,13,'2026-07-10 22:39:53'),
(21,14,5,'2026-07-10 22:39:53'),
(22,3,14,'2026-07-10 22:39:53'),
(23,16,5,'2026-07-10 22:39:53'),
(24,2,3,'2026-07-10 22:39:53'),
(25,7,13,'2026-07-10 22:39:53'),
(26,19,7,'2026-07-11 11:39:21'),
(27,19,12,'2026-07-11 11:46:49'),
(31,10001,19,'2026-07-16 00:16:45'),
(34,10004,19,'2026-07-17 02:20:34');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_gift_claims`
--

DROP TABLE IF EXISTS `user_gift_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_gift_claims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `gift_type` varchar(20) NOT NULL,
  `claim_date` date NOT NULL,
  `claim_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_user_level_type_date` (`user_id`,`level_id`,`gift_type`,`claim_date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_gift_claims`
--

LOCK TABLES `user_gift_claims` WRITE;
/*!40000 ALTER TABLE `user_gift_claims` DISABLE KEYS */;
INSERT INTO `user_gift_claims` VALUES
(6,19,4,'birthday','2026-07-12','2026-07-12 23:26:00'),
(7,19,4,'daily','2026-07-12','2026-07-12 23:27:10');
/*!40000 ALTER TABLE `user_gift_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_memberships`
--

DROP TABLE IF EXISTS `user_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_um_user` (`user_id`),
  KEY `idx_um_expire` (`expire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_memberships`
--

LOCK TABLES `user_memberships` WRITE;
/*!40000 ALTER TABLE `user_memberships` DISABLE KEYS */;
INSERT INTO `user_memberships` VALUES
(1,1,2,'黄金会员','2026-08-11 20:37:08','2026-07-12 10:45:54'),
(2,4,2,'黄金会员','2026-08-11 20:38:36','2026-07-12 10:45:54'),
(3,19,4,'至尊会员','2034-02-08 01:08:18','2026-07-12 10:45:54'),
(6,19,2,'黄金会员','2032-10-26 03:13:05','2026-07-12 11:13:05'),
(7,19,3,'钻石会员','2028-11-05 12:36:22','2026-07-12 20:36:22');
/*!40000 ALTER TABLE `user_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification_settings`
--

DROP TABLE IF EXISTS `user_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notification_settings` (
  `user_id` int(11) NOT NULL,
  `notification_type` varchar(50) NOT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  UNIQUE KEY `uk_user_type` (`user_id`,`notification_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification_settings`
--

LOCK TABLES `user_notification_settings` WRITE;
/*!40000 ALTER TABLE `user_notification_settings` DISABLE KEYS */;
INSERT INTO `user_notification_settings` VALUES
(1,'comment',1,'2026-07-16 19:29:20'),
(19,'comment',1,'2026-07-17 00:22:47'),
(19,'follow',1,'2026-07-17 00:22:47'),
(19,'like',1,'2026-07-17 00:22:47'),
(19,'mention',1,'2026-07-17 00:22:47'),
(19,'message',1,'2026-07-17 00:22:47'),
(19,'system',1,'2026-07-17 00:22:47');
/*!40000 ALTER TABLE `user_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_paid_collections`
--

DROP TABLE IF EXISTS `user_paid_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_paid_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `pay_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`collection_id`),
  KEY `idx_user_paid_collections_collection` (`collection_id`),
  KEY `idx_user_paid_collections_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_paid_collections`
--

LOCK TABLES `user_paid_collections` WRITE;
/*!40000 ALTER TABLE `user_paid_collections` DISABLE KEYS */;
INSERT INTO `user_paid_collections` VALUES
(1,1,1,20.00,'balance','2026-07-16 01:12:14');
/*!40000 ALTER TABLE `user_paid_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_titles`
--

DROP TABLE IF EXISTS `user_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `grant_by` varchar(100) DEFAULT '',
  `grant_time` datetime DEFAULT current_timestamp(),
  `expire_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`title_id`),
  KEY `idx_user_titles_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_titles`
--

LOCK TABLES `user_titles` WRITE;
/*!40000 ALTER TABLE `user_titles` DISABLE KEYS */;
INSERT INTO `user_titles` VALUES
(1,13,3,1,'','2026-07-10 22:39:54',NULL),
(2,7,3,1,'','2026-07-10 22:39:54',NULL),
(3,3,4,1,'','2026-07-10 22:39:54',NULL),
(4,12,1,1,'','2026-07-10 22:39:54',NULL),
(5,6,4,1,'','2026-07-10 22:39:54',NULL),
(6,15,2,1,'','2026-07-10 22:39:54',NULL),
(7,13,4,1,'','2026-07-10 22:39:54',NULL),
(8,7,1,1,'','2026-07-10 22:39:54',NULL),
(11,19,1,1,'membership','2026-07-12 00:11:10',NULL),
(56,19,11,1,'管理员','2026-07-13 22:17:04',NULL),
(57,19,10,1,'管理员','2026-07-13 23:15:06',NULL),
(58,19,9,1,'管理员','2026-07-13 23:15:11',NULL),
(64,3,19,1,'auto','2026-07-16 22:45:04',NULL),
(65,4,19,1,'auto','2026-07-16 22:45:04',NULL),
(66,19,19,1,'auto','2026-07-16 22:45:04',NULL),
(67,19,21,1,'auto','2026-07-16 22:45:04',NULL),
(68,10004,21,1,'auto','2026-07-17 02:13:00',NULL),
(69,1,1,1,'admin','2026-07-17 05:39:33',NULL),
(70,1,4,1,'admin','2026-07-17 05:39:33',NULL),
(71,1,7,1,'admin','2026-07-17 05:39:33',NULL),
(72,1,10,1,'admin','2026-07-17 05:39:33',NULL),
(73,1,12,1,'admin','2026-07-17 05:39:33',NULL),
(74,1,20,1,'auto','2026-07-17 13:51:17',NULL),
(75,1,21,1,'auto','2026-07-17 13:51:17',NULL),
(76,1,22,1,'auto','2026-07-17 13:51:17',NULL),
(77,1,23,1,'auto','2026-07-17 13:51:17',NULL),
(78,19,16,1,'auto','2026-07-17 17:39:00',NULL);
/*!40000 ALTER TABLE `user_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL DEFAULT '123456',
  `password_hash` varchar(200) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `nickname` varchar(100) DEFAULT '',
  `bio` text DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `experience` int(11) DEFAULT 0,
  `gender` varchar(10) DEFAULT '男',
  `avatar` varchar(500) DEFAULT '',
  `bg_url` varchar(500) DEFAULT '',
  `signature` varchar(300) DEFAULT '',
  `qq` varchar(20) DEFAULT '',
  `show_coin` int(11) DEFAULT 1,
  `follow_count` int(11) DEFAULT 0,
  `fans_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `points` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通会员',
  `expire_time` datetime DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_org` varchar(200) DEFAULT '',
  `active_title_id` int(11) DEFAULT 0,
  `active_title_name` varchar(100) DEFAULT '',
  `active_title_id2` int(11) DEFAULT 0,
  `active_title_name2` varchar(100) DEFAULT '',
  `active_title_id3` int(11) DEFAULT 0,
  `active_title_name3` varchar(100) DEFAULT '',
  `last_checkin_date` date DEFAULT NULL,
  `consecutive_checkins` int(11) DEFAULT 0,
  `referrer_id` int(11) DEFAULT 0,
  `referrer_code` varchar(32) DEFAULT '',
  `age` int(11) DEFAULT 0,
  `birthday` date DEFAULT NULL,
  `hide_birthday` tinyint(1) DEFAULT 0,
  `hide_qq` tinyint(1) DEFAULT 0,
  `hide_email` tinyint(1) DEFAULT 0,
  `hide_address` tinyint(1) DEFAULT 0,
  `register_address` varchar(200) DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `active_frame_id` int(11) DEFAULT 0,
  `active_frame_url` varchar(500) DEFAULT '',
  `used_bytes` bigint(20) DEFAULT 0,
  `bonus_data_limit_mb` int(11) DEFAULT 0,
  `bonus_file_limit_mb` int(11) DEFAULT 0,
  `referrer_id_2` int(11) DEFAULT 0,
  `twofa_secret` varchar(100) DEFAULT NULL,
  `twofa_enabled` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10012 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'bobwang','123456','$2b$10$Lt4EC3KVganeBqz8s6wis.mlfSSoc7Ll/YUixuwDmO3bEPxI.jWAK','13800138001','bob@test.com','bob123',NULL,57.00,3300,'1','','','','',1,0,0,'1',1450,2,'黄金会员','2026-08-11 20:37:08',NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,'1998-03-15',0,0,0,0,'',NULL,'[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]','2026-06-09 22:39:49','2026-07-11 21:29:49',1,'',13312,10,10,0,'FFwQm0rhyzJmiLTvLaUgU/FOh0c',1),
(2,'lisa_chen','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','$2b$10$b4DEkmaSpCgSDhXxU5QgKOzxHQs11JMbx8HqtLexLveBMmtdLB7Qa','13800138002','lisa@test.com','lisa123',NULL,25.00,1500,'0','','','','',1,0,0,'1',800,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-09 22:39:49','2026-07-10 22:39:49',0,'',4096,0,0,0,NULL,0),
(3,'tech_guru','123456','$2b$10$8r/5zSf2iGxjGVCZNA8N4.6jerTYYcrIggzbgTkXGn7zyuanlN9rm','13800138003','tech@test.com','tech123',NULL,317.73,8000,'1','','','','',1,0,0,'1',5000,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-05 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(4,'design_master','123456','$2b$10$8r/5zSf2iGxjGVCZNA8N4.6jerTYYcrIggzbgTkXGn7zyuanlN9rm','13800138004','dm@test.com','dm123',NULL,3.00,700,'0','','','','',1,0,0,'1',350,2,'黄金会员','2026-08-11 20:38:36',NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-18 22:39:49','2026-07-10 22:39:49',0,'',0,10,10,0,NULL,0),
(5,'code_ninja','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Code Ninja','13800138005','code@test.com','cn123',NULL,150.00,4500,'1','','','','',1,0,0,'1',2200,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-03 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(6,'pixel_art','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Pixel Art','13800138006','pixel@test.com','pa123',NULL,30.00,900,'0','','','','',1,0,0,'1',450,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-26 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(7,'ui_lover','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','UI Lover','13800138007','ui@test.com','ui123',NULL,500.00,12000,'0','','','','',1,0,1,'1',12000,4,'至尊会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(8,'frontend_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Frontend Dev','13800138008','fd@test.com','fd123',NULL,180.00,6000,'1','','','','',1,0,0,'1',6000,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-12 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(9,'backend_guru','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Backend Guru','13800138009','bg@test.com','bg123',NULL,95.00,3500,'1','','','','',1,0,0,'1',3500,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(10,'data_wizard','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Data Wizard','13800138010','dw@test.com','dw123',NULL,42.00,780,'1','','','','',1,0,0,'1',780,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(11,'mobile_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Mobile Dev','13800138011','md@test.com','md123',NULL,5.00,200,'1','','','','',1,0,0,'1',200,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(12,'cloud_arch','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Cloud Arch','13800138012','ca@test.com','ca123',NULL,350.00,9500,'1','','','','',1,0,1,'1',9500,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-07 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(13,'ai_explorer','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','AI Explorer','13800138013','ai@test.com','ai123',NULL,120.00,3000,'0','','','','',1,0,2,'1',3000,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-16 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(14,'game_dev','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Game Dev','13800138014','gd@test.com','gd123',NULL,66.00,1800,'1','','','','',1,0,0,'1',1800,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(15,'security_pro','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga','Security Pro','13800138015','sp@test.com','sp123',NULL,155.00,4200,'1','','','','',1,0,0,'1',4200,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(16,'deleted1','x','x','','','Deleted1',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(17,'deleted2','x','x','','','Deleted2',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-20 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(18,'deleted3','x','x','','','Deleted3',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-30 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0),
(19,'alexmorgan','123456','$2b$10$XKB4aH6BA68tyobOKSkaEORjvXtPiuNQqYcxfnFE4u8U4O1NsUunm','18670001591','844991059@qq.com','Alex Morgan','',23150.31,49252,'男','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/background/bg.png','','',1,4,5,'1',63520,4,'至尊会员','2034-02-08 01:08:18',NULL,1,'',10,'蓝V官方认证',11,'官方认证',9,'钻石王者','2026-07-12',1,3,'D7180E11',0,NULL,1,1,1,1,'',NULL,'[\"R_SUPER\"]','2026-07-10 22:44:56','2026-07-17 16:30:04',1,'',37606383,570,430140,0,'PISSU5B2JBEXIQZSMRJUQ3LXJZDS4RZE',0),
(10001,'35735712','123456','$2b$10$owIwm3i7VF8hBU462BbVu..NTBUNb1EhfarBwJcIE42QrTLVOkmPu','','844991059@qq.com','','测试',1964.12,5000,'男','','','','',1,2,0,'3',9905,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[]','2026-07-12 19:18:20','2026-07-16 00:16:12',0,'',0,0,0,0,NULL,0),
(10002,'github_user_mrnwh1hi','','$2b$10$WPBwPiyzIj9SiUvw5ermZeU4.9H/poQHWu0nhMZ/fY0WmfSa5Gcua','','','OAuth用户h1jp',NULL,0.00,0,'男','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-16 19:26:38','2026-07-16 19:26:38',0,'',0,0,0,0,NULL,0),
(10003,'test_joiner','123456','$2b$10$ei4Vtfmm08V0V2QxvByg6uFjgsJItGrOnweQobfhOGh/kANNorY4q','','testjoiner@test.com','Test Joiner',NULL,0.00,0,'男','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[]','2026-07-16 20:44:39','2026-07-16 20:44:39',0,'',0,0,0,0,NULL,0),
(10004,'admin','123456','$2b$10$YyvMNoCKGaopknTd5WcCmOszzied3WveFIT7zPUQUIVLMg2Wf2ylG','','','管理员',NULL,0.00,0,'男','','','','',1,3,0,'1',5,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_SUPER\"]','2026-07-17 02:02:05','2026-07-17 02:02:05',0,'',0,0,0,0,NULL,0),
(10009,'promo_pts2','123456','','','','',NULL,10000.00,0,'男','','','','',1,0,0,'1',5000,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:02:02','2026-07-17 18:02:02',0,'',0,0,0,0,NULL,0),
(10010,'promo_dbg','123456','','','','',NULL,2060.98,0,'男','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:05:00','2026-07-17 18:05:00',0,'',0,0,0,0,NULL,0),
(10011,'promo_dual','123456','','','','',NULL,5010.00,0,'男','','','','',1,0,0,'1',4020,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:39:28','2026-07-17 18:39:28',0,'',0,0,0,0,NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_config`
--

DROP TABLE IF EXISTS `verification_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `condition_type` varchar(50) NOT NULL,
  `threshold` int(11) DEFAULT 0,
  `is_active` int(11) DEFAULT 0,
  `logic_type` varchar(20) DEFAULT 'any',
  `logic_count` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_config`
--

LOCK TABLES `verification_config` WRITE;
/*!40000 ALTER TABLE `verification_config` DISABLE KEYS */;
INSERT INTO `verification_config` VALUES
(4,'follower_count',100,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(5,'app_count',1,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(6,'app_developer',0,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(7,'post_count',1,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37');
/*!40000 ALTER TABLE `verification_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_requests`
--

DROP TABLE IF EXISTS `verification_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `real_name` varchar(100) DEFAULT '',
  `id_card` varchar(50) DEFAULT '',
  `organization` varchar(200) DEFAULT '',
  `reason` text DEFAULT NULL,
  `proof_urls` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `selected_condition` varchar(50) DEFAULT '',
  `selected_app_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_verification_requests_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_requests`
--

LOCK TABLES `verification_requests` WRITE;
/*!40000 ALTER TABLE `verification_requests` DISABLE KEYS */;
INSERT INTO `verification_requests` VALUES
(1,2,'','用户1','440137500550','科技有限公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-07-06 22:39:54','',0),
(2,3,'','用户2','440126591708','网络科技公司','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-09 22:39:54','',0),
(3,4,'','用户3','440134963635','设计工作室','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-05 22:39:54','',0),
(4,5,'','用户4','440147897279','科技有限公司','申请蓝V认证',NULL,'rejected',NULL,'',NULL,'2026-07-08 22:39:54','',0),
(5,6,'','用户5','440183856527','网络科技公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-06-21 22:39:54','',0),
(6,19,'alexmorgan','1','','','开发者','[]','approved','','','2026-07-13 21:47:29','2026-07-13 21:47:11','post_count',0);
/*!40000 ALTER TABLE `verification_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_records`
--

DROP TABLE IF EXISTS `withdraw_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(30) DEFAULT 'alipay',
  `account` varchar(200) DEFAULT '',
  `real_name` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `remark` text DEFAULT '',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_withdraw_records_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_records`
--

LOCK TABLES `withdraw_records` WRITE;
/*!40000 ALTER TABLE `withdraw_records` DISABLE KEYS */;
INSERT INTO `withdraw_records` VALUES
(1,5,'user5',12.64,'alipay','','','completed','',19,'alexmorgan','2026-07-13 14:24:49','2026-07-10 22:39:54'),
(2,5,'user5',96.40,'wechat','','','completed','',0,'',NULL,'2026-06-26 22:39:54'),
(3,4,'user4',90.32,'alipay','','','rejected','',0,'',NULL,'2026-06-30 22:39:54'),
(4,7,'user7',87.49,'wechat','','','rejected','',19,'alexmorgan','2026-07-12 23:39:30','2026-06-30 22:39:54'),
(5,8,'user8',15.46,'alipay','','','completed','',0,'',NULL,'2026-06-25 22:39:54'),
(6,9,'user9',32.49,'wechat','','','rejected','',0,'',NULL,'2026-06-28 22:39:54'),
(7,8,'user8',84.19,'alipay','','','rejected','666',19,'alexmorgan','2026-07-12 23:45:35','2026-07-07 22:39:54'),
(8,8,'user8',38.85,'wechat','','','completed','',0,'',NULL,'2026-06-23 22:39:54'),
(9,19,'alexmorgan',500.00,'alipay','123456','1','rejected','',19,'alexmorgan','2026-07-13 14:24:58','2026-07-12 23:39:43'),
(10,10001,'35735712',12.00,'alipay','122','','pending','',0,'',NULL,'2026-07-16 00:20:17');
/*!40000 ALTER TABLE `withdraw_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'art_design_pro'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-17 20:14:30
