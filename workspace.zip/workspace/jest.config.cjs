module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>/server/tests'],
  testMatch: ['**/*.test.cjs'],
  globalSetup: '<rootDir>/server/tests/helpers/global-setup.cjs',
  globalTeardown: '<rootDir>/server/tests/helpers/global-teardown.cjs',
  testTimeout: 30000,
  forceExit: true,
  verbose: true
}
