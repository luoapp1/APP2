<template>
  <div class="ranking-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">合集排行榜</span>
      <span class="nav-spacer" />
    </div>

    <div class="ranking-tabs">
      <button v-for="t in tabs" :key="t.key" class="tab-btn" :class="{ active: activeTab === t.key }" @click="switchTab(t.key)">{{ t.label }}</button>
    </div>

    <div class="page-content">
      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadData" />
      <EmptyState v-else-if="!list.length" text="暂无排行数据" />
      <div v-else class="ranking-list">
        <div v-for="(item, idx) in list" :key="item.id" class="rank-card" @click="$router.push(`/appstore/collection/${item.id}`)">
          <div class="rank-num" :class="{ top3: idx < 3 }">{{ idx + 1 }}</div>
          <div class="rank-cover">
            <img v-if="item.coverUrl" :src="item.coverUrl" loading="lazy" />
            <div v-else class="rank-cover-placeholder">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
            </div>
          </div>
          <div class="rank-body">
            <div class="rank-name">{{ item.name }}</div>
            <div class="rank-desc" v-if="item.description">{{ item.description }}</div>
            <div class="rank-meta">
              <span>{{ item.appCount || 0 }} 款应用</span>
              <span>{{ item.viewCount || 0 }} 浏览</span>
              <span>{{ item.likes || 0 }} 赞</span>
            </div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchCollectionRanking } from '@/api/appstore'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const tabs = [
  { key: 'hot', label: '热门' },
  { key: 'new', label: '最新' },
  { key: 'apps', label: '最多应用' }
]

const activeTab = ref('hot')
const loading = ref(false)
const error = ref('')
const list = ref([])

async function loadData() {
  loading.value = true; error.value = ''
  try { const res = await fetchCollectionRanking({ type: activeTab.value }); list.value = res || [] }
  catch (e) { error.value = e?.response?.data?.msg || e?.message || '加载失败' }
  finally { loading.value = false }
}

function switchTab(key: string) { activeTab.value = key; loadData() }

onMounted(() => loadData())
</script>

<style scoped>
.ranking-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }
.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.nav-spacer { width: 22px; }

.ranking-tabs { display: flex; background: #fff; padding: 8px 16px; gap: 4px; }
.tab-btn { padding: 6px 16px; border-radius: 20px; border: none; background: #f0f2f5; font-size: 13px; color: #666; cursor: pointer; font-weight: 500; }
.tab-btn.active { background: #6366F1; color: #fff; }
.tab-btn:active { opacity: .8; }

.page-content { padding: 16px; }

.ranking-list { display: flex; flex-direction: column; gap: 8px; }
.rank-card { display: flex; align-items: center; gap: 10px; background: #fff; border-radius: 14px; padding: 10px 12px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.rank-card:active { transform: scale(.99); }
.rank-num { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; color: #999; flex-shrink: 0; }
.rank-num.top3 { background: linear-gradient(135deg, #F59E0B, #EF4444); color: #fff; }
.rank-cover { width: 44px; height: 44px; border-radius: 10px; overflow: hidden; flex-shrink: 0; }
.rank-cover img { width: 100%; height: 100%; object-fit: cover; }
.rank-cover-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #F59E0B, #EF4444); display: flex; align-items: center; justify-content: center; }
.rank-body { flex: 1; min-width: 0; }
.rank-name { font-size: 14px; font-weight: 700; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.rank-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.rank-meta { display: flex; gap: 10px; margin-top: 3px; font-size: 10px; color: #aaa; }
</style>
