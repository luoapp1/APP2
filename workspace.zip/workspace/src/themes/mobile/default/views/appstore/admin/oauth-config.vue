<template>
  <div class="oauth-page">
    <div class="oauth-navbar">
      <button class="oauth-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="oauth-title">OAuth 登录配置</span>
      <button class="oauth-save" @click="saveConfig" :disabled="saving">{{ saving ? '保存中...' : '保存' }}</button>
    </div>

    <div class="oauth-content">
      <div v-if="loading" class="oauth-loading"><div class="oauth-spin" /></div>

      <div v-else class="oauth-cards">
        <div v-for="p in providers" :key="p.provider" class="oauth-card">
          <div class="oauth-card-header">
            <div class="oauth-card-icon" :style="{ background: p.bg }">
              <svg v-if="p.provider === 'github'" width="22" height="22" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12z"/></svg>
              <svg v-else-if="p.provider === 'google'" width="20" height="20" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              <svg v-else-if="p.provider === 'wechat'" width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 01.213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 00.167-.054l1.903-1.114a.864.864 0 01.717-.098 10.16 10.16 0 002.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178A1.17 1.17 0 014.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178 1.17 1.17 0 01-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 01.598.082l1.584.926a.272.272 0 00.14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 01-.023-.156.49.49 0 01.201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.952-7.062-6.122zm-3.84 3.192c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982z" fill-rule="evenodd"/></svg>
              <svg v-else-if="p.provider === 'qq'" width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M21.395 15.035a40.36 40.36 0 00-.803-2.264l-1.079-2.695c.001-.032.014-.562.012-.8C19.461 4.892 16.564 1 12 1S4.54 4.893 4.475 9.275c-.002.239.011.769.012.8l-1.078 2.695c-.358.878-.654 1.638-.803 2.264-1.05 4.418.209 5.855.918 6.247.924.514 1.538-.564 1.538-.564.13.735.439 1.267.815 1.267.441 0 .803-.702.834-1.592.731.457 1.666.726 2.598.726.911 0 1.828-.257 2.55-.694.035.863.387 1.56.816 1.56.377 0 .686-.535.815-1.267 0 0 .614 1.078 1.538.564.709-.392 1.968-1.829.918-6.247z"/></svg>
              <span v-else class="oauth-card-icon-text">{{ p.provider[0].toUpperCase() }}</span>
            </div>
            <div>
              <div class="oauth-card-name">{{ p.label }}</div>
              <div class="oauth-card-desc">配置 {{ p.label }} OAuth 登录参数</div>
            </div>
            <label class="oauth-toggle">
              <input type="checkbox" v-model="p.enabled" />
              <span class="oauth-toggle-slider"></span>
            </label>
          </div>

          <div v-if="p.enabled" class="oauth-card-body">
            <div class="oauth-field">
              <label>Client ID</label>
              <input v-model="p.clientId" placeholder="输入 Client ID" class="oauth-input" />
            </div>
            <div class="oauth-field">
              <label>Client Secret</label>
              <input v-model="p.clientSecret" :placeholder="p.hasSecret ? '已设置 (修改时输入新值)' : '输入 Client Secret'" class="oauth-input" type="password" />
            </div>
            <div class="oauth-field">
              <label>回调地址 (Redirect URI)</label>
              <input v-model="p.redirectUri" :placeholder="defaultRedirectUri(p.provider)" class="oauth-input" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const loading = ref(true)
const saving = ref(false)

const providers = reactive([
  { provider: 'github', label: 'GitHub', bg: '#24292F', enabled: false, clientId: '', clientSecret: '', redirectUri: '', hasSecret: false },
  { provider: 'google', label: 'Google', bg: '#fff', enabled: false, clientId: '', clientSecret: '', redirectUri: '', hasSecret: false },
  { provider: 'wechat', label: '微信', bg: '#07C160', enabled: false, clientId: '', clientSecret: '', redirectUri: '', hasSecret: false },
  { provider: 'qq', label: 'QQ', bg: '#12B7F5', enabled: false, clientId: '', clientSecret: '', redirectUri: '', hasSecret: false }
])

function defaultRedirectUri(provider) {
  return 'https://your-domain.com/api/auth/oauth/callback/' + provider
}

onMounted(async () => {
  try {
    const data = await request.get({ url: '/api/admin/oauth-configs' })
    const arr = Array.isArray(data) ? data : (data?.data || [])
    arr.forEach(item => {
      const p = providers.find(x => x.provider === item.provider)
      if (p) {
        p.enabled = item.enabled || false
        p.clientId = item.clientId || ''
        p.redirectUri = item.redirectUri || ''
        p.hasSecret = item.clientSecret === '***'
      }
    })
  } catch (e) {
    console.error('加载OAuth配置失败:', e)
  } finally {
    loading.value = false
  }
})

async function saveConfig() {
  saving.value = true
  try {
    const configs = []
    providers.forEach(p => {
      configs.push({ config_key: 'oauth_' + p.provider + '_enabled', config_value: p.enabled ? '1' : '0', description: p.label + ' 启用状态' })
      if (p.clientId) configs.push({ config_key: 'oauth_' + p.provider + '_client_id', config_value: p.clientId, description: p.label + ' Client ID' })
      if (p.clientSecret && p.clientSecret !== '***') configs.push({ config_key: 'oauth_' + p.provider + '_client_secret', config_value: p.clientSecret, description: p.label + ' Client Secret' })
      if (p.redirectUri) configs.push({ config_key: 'oauth_' + p.provider + '_redirect_uri', config_value: p.redirectUri, description: p.label + ' 回调地址' })
      if (p.clientSecret !== '***') p.hasSecret = !!p.clientSecret
    })
    await request.post({ url: '/api/admin/oauth-configs', data: { configs } })
    alert('保存成功')
  } catch (e) {
    alert(e?.msg || e?.message || '保存失败')
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.oauth-page {
  min-height: 100vh;
  background: #F5F6FA;
}

.oauth-navbar {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.05);
}

.oauth-back {
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  display: flex;
  color: #333;
  border-radius: 8px;
}

.oauth-back:active { background: #f0f0f0; }

.oauth-title {
  flex: 1;
  text-align: center;
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
}

.oauth-save {
  background: linear-gradient(135deg, #FF4757, #FF6B81);
  color: #fff;
  border: none;
  padding: 7px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}

.oauth-save:active { opacity: 0.85; }
.oauth-save:disabled { opacity: 0.5; cursor: not-allowed; }

.oauth-content {
  padding: 16px;
}

.oauth-loading {
  display: flex;
  justify-content: center;
  padding: 48px 0;
}

.oauth-spin {
  width: 22px;
  height: 22px;
  border: 2px solid #e5e7eb;
  border-top-color: #6366F1;
  border-radius: 50%;
  animation: spin .6s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

.oauth-cards {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.oauth-card {
  background: #fff;
  border-radius: 16px;
  overflow: hidden;
}

.oauth-card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
}

.oauth-card-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  overflow: hidden;
}

.oauth-card-icon-text {
  font-size: 18px;
  font-weight: 700;
  color: #fff;
}

.oauth-card-name {
  font-size: 15px;
  font-weight: 600;
  color: #1f2937;
}

.oauth-card-desc {
  font-size: 12px;
  color: #9CA3AF;
  margin-top: 2px;
}

.oauth-toggle {
  margin-left: auto;
  position: relative;
  width: 48px;
  height: 26px;
  flex-shrink: 0;
}

.oauth-toggle input {
  opacity: 0;
  width: 0;
  height: 0;
}

.oauth-toggle-slider {
  position: absolute;
  inset: 0;
  background: #E5E7EB;
  border-radius: 26px;
  cursor: pointer;
  transition: background .2s;
}

.oauth-toggle-slider::before {
  content: '';
  position: absolute;
  width: 22px;
  height: 22px;
  left: 2px;
  top: 2px;
  background: #fff;
  border-radius: 50%;
  transition: transform .2s;
}

.oauth-toggle input:checked + .oauth-toggle-slider {
  background: #6366F1;
}

.oauth-toggle input:checked + .oauth-toggle-slider::before {
  transform: translateX(22px);
}

.oauth-card-body {
  padding: 0 16px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.oauth-field label {
  display: block;
  font-size: 13px;
  color: #6B7280;
  margin-bottom: 6px;
  font-weight: 500;
}

.oauth-input {
  width: 100%;
  padding: 10px 14px;
  border: 1px solid #E5E7EB;
  border-radius: 10px;
  font-size: 14px;
  color: #333;
  background: #F9FAFB;
  outline: none;
  box-sizing: border-box;
}

.oauth-input:focus {
  border-color: #6366F1;
  background: #fff;
  box-shadow: 0 0 0 3px rgba(99,102,241,0.1);
}
</style>
