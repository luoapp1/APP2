<template>
  <div class="search-page">
    <!-- Top Bar -->
    <div class="topbar">
      <button class="tb-back" @click="goBack">&larr;</button>
      <div class="tb-input-wrap">
        <svg class="tb-search-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
        <input
          v-model="keyword"
          class="tb-input"
          placeholder="搜索帖子、应用、用户..."
          @keydown.enter="doSearch"
          @input="onInput"
        />
        <button v-if="keyword" class="tb-clear" @click="keyword=''">&times;</button>
      </div>
      <button class="tb-search-btn" @click="doSearch">搜索</button>
    </div>

    <!-- 搜索过滤面板 -->
    <div class="filter-bar">
      <button class="filter-toggle" @click="showFilters = !showFilters">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" d="M3 6h18M7 12h10M10 18h4"/></svg>
        <span>筛选</span>
        <span v-if="hasFilters" class="filter-dot"></span>
      </button>
      <div class="filter-quicks">
        <button v-for="s in quickSorts" :key="s.value" class="filter-chip" :class="{ active: sort === s.value }" @click="applyQuickSort(s.value)">{{ s.label }}</button>
      </div>
    </div>
    <div v-if="showFilters" class="filter-panel">
      <div class="filter-row">
        <label class="filter-label">板块</label>
        <select v-model="filterSectionId" class="filter-select" @change="doSearch">
          <option value="">全部板块</option>
          <option v-for="s in sections" :key="s.id" :value="s.id">{{ s.name }}</option>
        </select>
      </div>
      <div class="filter-row">
        <label class="filter-label">时间</label>
        <div class="filter-date-chips">
          <button v-for="d in dateRanges" :key="d.value" class="filter-chip" :class="{ active: dateRange === d.value }" @click="setDateRange(d.value)">{{ d.label }}</button>
        </div>
      </div>
      <div class="filter-row">
        <label class="filter-label">排序</label>
        <div class="filter-date-chips">
          <button v-for="s in sortOptions" :key="s.value" class="filter-chip" :class="{ active: sort === s.value }" @click="setSort(s.value)">{{ s.label }}</button>
        </div>
      </div>
    </div>

    <!-- 搜索类型 Tabs -->
    <div class="tabs">
      <div v-for="tab in tabs" :key="tab.key" class="tab-item" :class="{ active: activeTab === tab.key }" @click="switchTab(tab.key)">
        {{ tab.label }}
        <div v-if="activeTab === tab.key" class="tab-line" />
      </div>
    </div>

    <!-- 初始状态 -->
    <div v-if="!searched" class="empty-state">
      <svg class="empty-icon" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
      <p class="empty-text">输入关键词开始搜索</p>
    </div>

    <!-- 搜索结果 -->
    <template v-else>
      <!-- 加载中 -->
      <div v-if="loading" class="loading"><span class="spinner" />搜索中...</div>

      <!-- 帖子结果（与板块列表完全一致） -->
      <div v-else-if="activeTab === 'post'" class="results">
        <div v-if="postResults.length === 0" class="empty-state">
          <svg class="empty-icon" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
          <p class="empty-text">未找到相关帖子</p>
        </div>
        <div v-for="post in postResults" :key="post.id" class="bg-white mx-3 mb-2 rounded-xl px-3 pt-2.5 pb-2.5 cursor-pointer active:bg-[#FAFAFA] transition-colors" @click="goPost(post.id)">
          <!-- Author Row -->
          <div class="flex items-center gap-0.5">
            <div class="post-avatar-wrap">
              <div class="post-avatar">
                <img src="@imgs/user/avatar.webp" class="post-avatar-pic" loading="lazy" />
                <img v-if="post.userAvatar" :src="post.userAvatar" class="post-avatar-pic post-avatar-user" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
            </div>
            <div class="post-author-info">
              <div class="post-author-col">
                <div class="post-author-row">
                  <span class="post-username">{{ post.userName }}</span>
                  <img v-for="(icon, idx) in (post.userAllTitleIcons || '').split('|||').filter(Boolean)" :key="idx" :src="icon" class="post-title-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                </div>
                <div class="post-author-meta">
                  <img v-if="post.userExpLevelIcon && post.userExpLevelIcon.startsWith('http')" :src="post.userExpLevelIcon" class="post-exp-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                  <img v-if="post.userMemberLevelIcon" :src="post.userMemberLevelIcon" class="post-member-name-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                </div>
              </div>
            </div>
          </div>

          <!-- Post Content Area -->
          <div class="post-body">
            <!-- Badges Row -->
            <div class="post-badge-row">
              <span v-if="post.isPinned" class="post-header-badge pin">置顶</span>
              <span v-if="post.isEssence" class="post-header-badge essence">精华</span>
              <span v-if="(post.likeCount || 0) >= 20 || (post.commentCount || 0) >= 30" class="post-header-badge hot">热帖</span>
              <span v-if="post.customBadge" class="post-header-badge custom">{{ post.customBadge }}</span>
              <span v-if="post.isLocked" class="post-header-badge lock">锁定</span>
              <span v-for="(collaborator, ci) in (post.collectionList || [])" :key="'col-'+ci" class="post-header-badge collection">{{ collaborator }}</span>
            </div>

            <!-- Title -->
            <div class="text-[15px] text-[#1A1A1A] font-semibold leading-tight mt-1 line-clamp-2" v-html="highlight(post.title)" />

            <!-- Content Preview -->
            <div class="text-[13px] text-[#777] leading-[1.55] mt-1.5 line-clamp-2" v-html="stripContent(post.content)" />

            <!-- Preview Card -->
            <div v-if="post._previewCard" class="post-preview-card">
              <div v-if="post._previewCard.type === 'paywall'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FFF8E1] border border-[#FFE082] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#F59E0B]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">付费内容</div></div>
                <span class="text-[12px] text-[#D48806] font-semibold">{{ post._previewCard.price || 0 }}{{ post._previewCard.priceType === 'points' ? '积分' : '元' }}购买</span>
              </div>
              <div v-else-if="post._previewCard.type === 'memberUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FEF3C7] border border-[#FCD34D] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">{{ post._previewCard.levelName }}专属</div></div>
                <span class="text-[12px] text-[#D48806]">开通会员</span>
              </div>
              <div v-else-if="post._previewCard.type === 'experienceUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#DBEAFE] border border-[#93C5FD] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#DBEAFE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#3B82F6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#3B82F6] font-semibold">{{ post._previewCard.levelName }}以上</div></div>
              </div>
              <div v-else-if="post._previewCard.type === 'commentUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#D1FAE5] border border-[#A7F3D0] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#10B981]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#10B981] font-semibold">评论后可见</div></div>
                <span class="text-[11px] text-[#888] flex-shrink-0">留下评论即可解锁</span>
              </div>
              <div v-else-if="post._previewCard.type === 'titleUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#EDE9FE] border border-[#C4B5FD] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#8B5CF6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#8B5CF6] font-semibold">{{ post._previewCard.titleName }}</div></div>
                <span class="text-[11px] text-[#888] flex-shrink-0">称号限定内容</span>
              </div>
              <div v-else-if="post._previewCard.type === 'login'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FFF0E0] border border-[#FFCC80] mt-2 mb-1 cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#F59E0B]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">登录后可见</div></div>
              </div>
              <div v-else-if="post._previewCard.type === 'app'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#F0F9FF] to-[#E0F2FE] border border-[#BAE6FD] mt-2 mb-1 cursor-pointer">
                <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] flex items-center justify-center flex-shrink-0 shadow-sm">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#0C4A6E] font-semibold">{{ post._previewCard.name || '应用' }}</div></div>
                <div class="w-6 h-6 rounded-full bg-[#E0F2FE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-3.5 h-3.5 text-[#0EA5E9]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                </div>
              </div>
              <div v-else-if="post._previewCard.type === 'goods'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#FFF7ED] to-[#FFEDD5] border border-[#FED7AA] mt-2 mb-1 cursor-pointer">
                <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#D48806] to-[#F59E0B] flex items-center justify-center flex-shrink-0 overflow-hidden shadow-sm">
                  <img v-if="post._previewCard.image" :src="post._previewCard.image" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                  <svg v-else class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#9A3412] font-semibold">{{ post._previewCard.name || '商品' }}</div></div>
                <div class="w-6 h-6 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                  <svg class="w-3.5 h-3.5 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                </div>
              </div>
              <div v-else-if="post._previewCard.type === 'vote'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#F5F3FF] to-[#EDE9FE] border border-[#DDD6FE] mt-2 mb-1 cursor-pointer">
                <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#A78BFA] flex items-center justify-center flex-shrink-0 shadow-sm">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#4C1D95] font-semibold">{{ post._previewCard.question || '投票' }}</div></div>
                <div class="w-6 h-6 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-3.5 h-3.5 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                </div>
              </div>
              <div v-else-if="post._previewCard.type === 'postRef'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#ECFDF5] to-[#D1FAE5] border border-[#A7F3D0] mt-2 mb-1 cursor-pointer">
                <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#059669] to-[#34D399] flex items-center justify-center flex-shrink-0 shadow-sm">
                  <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                </div>
                <div class="flex-1 min-w-0"><div class="text-[13px] text-[#064E3B] font-semibold">{{ post._previewCard.title || post._previewCard.name || '关联帖子' }}</div></div>
                <div class="w-6 h-6 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                  <svg class="w-3.5 h-3.5 text-[#059669]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                </div>
              </div>
            </div>

            <!-- Images -->
            <div v-if="post.images && post.images.length" class="mt-2.5">
              <div v-if="post.images.length === 1" class="rounded-xl overflow-hidden shadow-sm" style="max-height:200px">
                <img :src="$fixImgUrl(post.images[0])" class="w-full object-cover" style="max-height:200px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div v-else-if="post.images.length === 2" class="grid grid-cols-2 gap-1.5 rounded-xl overflow-hidden">
                <img v-for="(img, idx) in post.images.slice(0,2)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:150px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div v-else class="grid grid-cols-3 gap-1.5 rounded-xl overflow-hidden">
                <img v-for="(img, idx) in post.images.slice(0,3)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:130px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
            </div>
          </div>

          <!-- Tags + Stats -->
          <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-[#F5F5F5]">
            <div v-if="post.tags && post.tags.length" class="flex items-center gap-1.5 flex-wrap">
              <span v-for="tag in post.tags.slice(0,4)" :key="tag" class="text-[10px] px-2 py-[2px] rounded text-[#666] bg-[#F5F5F5] font-medium flex-shrink-0">{{ tag }}</span>
            </div>
            <div class="flex items-center gap-3 text-[12px] text-[#B0B0B0] ml-auto flex-shrink-0">
              <span class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                {{ fmtCount(post.likeCount || 0) }}
              </span>
              <span class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                {{ fmtCount(post.commentCount || 0) }}
              </span>
              <span class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ fmtCount(post.viewCount || 0) }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- 应用结果 -->
      <div v-else-if="activeTab === 'app'" class="results">
        <div v-if="appResults.length === 0" class="empty-state">
          <p class="empty-text">未找到相关应用</p>
        </div>
        <div v-for="item in appResults" :key="item.id" class="post-item" @click="goApp(item.id)">
          <div class="post-left">
            <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="app-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            <div v-else class="app-icon-fb" :style="{ background: item.iconBgColor || '#14B8A6' }">{{ (item.name || '?')[0] }}</div>
          </div>
          <div class="post-info">
            <div class="post-item-title" v-html="highlight(item.name)"></div>
            <div class="post-item-meta">{{ item.category || '工具' }} · {{ item.downloads || 0 }} 下载 · {{ item.sizeMb || 0 }}MB</div>
          </div>
        </div>
      </div>

      <!-- 用户结果 -->
      <div v-else-if="activeTab === 'user'" class="results">
        <div v-if="userResults.length === 0" class="empty-state">
          <p class="empty-text">未找到相关用户</p>
        </div>
        <div v-for="item in userResults" :key="item.id" class="post-item" @click="goUser(item.id)">
          <div class="post-left">
            <img v-if="item.avatar && !item.avatar.startsWith('avatar:')" :src="$fixImgUrl(item.avatar)" class="user-av" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            <div v-else class="user-av-fb" :style="{ background: avatarColor(item.nickname || item.username || '') }">{{ (item.nickname || item.username || '?')[0] }}</div>
          </div>
          <div class="post-info">
            <div class="post-item-title" v-html="highlight(item.nickname || item.username)"></div>
            <div class="post-item-meta">@{{ item.username }}</div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunityPosts, fetchCommunitySections, searchUsers } from '@/api/community'
import { fetchAppList } from '@/api/appstore'

const router = useRouter()
const keyword = ref('')
const activeTab = ref('post')
const loading = ref(false)
const searched = ref(false)
const showFilters = ref(false)
const filterSectionId = ref<string | number>('')
const dateRange = ref('')
const sort = ref('latest')
const sections = ref<any[]>([])

const postResults = ref<any[]>([])
const appResults = ref<any[]>([])
const userResults = ref<any[]>([])

const quickSorts = [
  { label: '最新', value: 'latest' },
  { label: '最热', value: 'hot' },
  { label: '最多评论', value: 'trending' },
  { label: '最多浏览', value: 'views' }
]

const sortOptions = [
  { label: '最新发布', value: 'latest' },
  { label: '最热', value: 'hot' },
  { label: '最多评论', value: 'trending' },
  { label: '最多浏览', value: 'views' },
  { label: '最近回复', value: 'recent_reply' },
  { label: '最多点赞', value: 'most_likes' },
  { label: '最多收藏', value: 'most_favorites' }
]

const dateRanges = [
  { label: '不限', value: '' },
  { label: '今天', value: 'today' },
  { label: '本周', value: 'week' },
  { label: '本月', value: 'month' }
]

const hasFilters = computed(() => {
  return !!filterSectionId.value || !!dateRange.value || sort.value !== 'latest'
})

function applyQuickSort(val: string) {
  sort.value = val
  if (searched.value) doSearch()
}

function setSort(val: string) {
  sort.value = val
  if (searched.value) doSearch()
}

function setDateRange(val: string) {
  dateRange.value = dateRange.value === val ? '' : val
  if (searched.value) doSearch()
}

function getDateParams() {
  const now = new Date()
  if (dateRange.value === 'today') {
    const t = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
    return { startDate: t, endDate: t }
  }
  if (dateRange.value === 'week') {
    const d = new Date(now.getTime() - 7 * 86400000)
    const st = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    const et = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
    return { startDate: st, endDate: et }
  }
  if (dateRange.value === 'month') {
    const d = new Date(now.getTime() - 30 * 86400000)
    const st = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    const et = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
    return { startDate: st, endDate: et }
  }
  return {}
}

onMounted(async () => {
  try {
    const sid = router.currentRoute.value.query.sectionId
    if (sid) filterSectionId.value = String(sid)
    const res: any = await fetchCommunitySections()
    sections.value = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : [])
  } catch {}
})

const tabs = [
  { key: 'post', label: '帖子' },
  { key: 'app', label: '应用' },
  { key: 'user', label: '用户' }
]

const avatarPalette = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#84CC16','#E11D48','#0EA5E9','#7C3AED']
function avatarColor(n: string): string {
  let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h)
  return avatarPalette[Math.abs(h) % avatarPalette.length]
}

function stripContent(text: string): string {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/<[^>]*>/g, '').trim()).filter(Boolean).join(' ').slice(0, 120)
    if (parsed?.type === 'doc') { const parts: string[] = []; function walk(n: any) { if (n.type === 'text') parts.push(n.text || ''); if (n.content) n.content.forEach(walk) }; if (parsed.content) parsed.content.forEach(walk); return parts.join(' ').trim().slice(0, 120) }
  } catch {}
  const stripTags = text.replace(/<[^>]*>/g, ' ').replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim()
  return stripTags.length > 120 ? stripTags.slice(0, 120) + '...' : stripTags
}

function fmtCount(n: number): string {
  if (!n || n === 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1).replace(/\.0$/, '') + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d = new Date(time)
  if (isNaN(d.getTime())) return time.slice(0, 10)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`
  if (diff < 259200000) return `${Math.floor(diff / 86400000)}天前`
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

function highlight(text: string) {
  if (!keyword.value || !text) return escapeHtml(text || '')
  const escaped = escapeHtml(text)
  const escapedKw = escapeHtml(keyword.value)
  const re = new RegExp(`(${escapedKw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
  return escaped.replace(re, '<mark style="background:#fef08a;border-radius:2px;padding:0 1px">$1</mark>')
}

let timer: any = null
function onInput() {
  if (timer) clearTimeout(timer)
  timer = setTimeout(doSearch, 400)
}

function switchTab(key: string) {
  activeTab.value = key
  if (searched.value) doSearch()
}

async function doSearch() {
  const kw = keyword.value.trim()
  if (!kw) { searched.value = false; return }
  loading.value = true; searched.value = true
  try {
    if (activeTab.value === 'post') {
      const params: any = { keyword: kw, pageSize: 50, sort: sort.value }
      if (filterSectionId.value) params.sectionId = filterSectionId.value
      const dateParams = getDateParams()
      if (dateParams.startDate) params.startDate = dateParams.startDate
      if (dateParams.endDate) params.endDate = dateParams.endDate
      const res: any = await fetchCommunityPosts(params)
      postResults.value = Array.isArray(res?.data?.list) ? res.data.list : (Array.isArray(res?.list) ? res.list : [])
    } else if (activeTab.value === 'app') {
      const res: any = await fetchAppList({ keyword: kw, pageSize: 50 })
      appResults.value = Array.isArray(res?.data?.list) ? res.data.list : (Array.isArray(res?.list) ? res.list : (Array.isArray(res) ? res : []))
    } else if (activeTab.value === 'user') {
      const res: any = await searchUsers(kw)
      userResults.value = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : [])
    }
  } catch {} finally { loading.value = false }
}

function goPost(id: number) { router.push(`/community/post/${id}`) }
function goApp(id: number) { router.push(`/appstore/browse/detail/${id}`) }
function goUser(id: number) { router.push(`/u/${id}`) }
function goBack() { router.back() }
</script>

<style scoped>
.search-page { display:flex; flex-direction:column; height:100vh; height:100dvh; background:#fff; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }

/* Top Bar */
.topbar { display:flex; align-items:center; gap:10px; padding:10px 14px; padding-top:calc(10px + env(safe-area-inset-top,0px)); background:#fff; border-bottom:1px solid #f0f0f0; flex-shrink:0; }
.tb-back { width:34px; height:34px; border-radius:10px; border:none; background:#f5f5f5; display:flex; align-items:center; justify-content:center; color:#333; cursor:pointer; font-size:16px; flex-shrink:0; }
.tb-input-wrap { flex:1; display:flex; align-items:center; background:#f5f5f5; border-radius:10px; padding:0 12px; gap:8px; }
.tb-search-icon { width:16px; height:16px; color:#999; flex-shrink:0; }
.tb-input { flex:1; border:none; outline:none; background:transparent; font-size:14px; color:#333; padding:9px 0; }
.tb-input::placeholder { color:#bbb; }
.tb-clear { width:20px; height:20px; border-radius:50%; border:none; background:#ddd; color:#fff; font-size:12px; display:flex; align-items:center; justify-content:center; cursor:pointer; padding:0; flex-shrink:0; }
.tb-search-btn { border:none; background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; padding:8px 16px; border-radius:10px; font-size:13px; font-weight:600; cursor:pointer; flex-shrink:0; }

/* Tabs */
.tabs { display:flex; border-bottom:1px solid #f0f0f0; flex-shrink:0; }
.tab-item { flex:1; text-align:center; padding:12px 0; font-size:14px; font-weight:500; color:#999; cursor:pointer; position:relative; transition:all .15s; }
.tab-item.active { color:#6366f1; font-weight:600; }
.tab-line { position:absolute; bottom:0; left:50%; transform:translateX(-50%); width:24px; height:3px; background:#6366f1; border-radius:2px; }

/* Results */
.results { flex:1; overflow-y:auto; -webkit-overflow-scrolling:touch; }

/* 帖子卡片 - 与板块列表完全一致 */
.post-header-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 3px;
  font-weight: 600;
  margin-right: 5px;
  vertical-align: middle;
}
.post-header-badge.pin { color: #DC2626; background: #FEF2F2; }
.post-header-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-header-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-header-badge.custom { color: #508DFF; background: #F0F5FF; }
.post-header-badge.lock { color: #999; background: #F5F5F5; }
.post-header-badge.collection { color: #7C3AED; background: #F5F3FF; cursor: pointer; }

.post-avatar-wrap {
  position: relative;
  width: 56px;
  height: 56px;
  flex-shrink: 0;
}
.post-avatar {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  z-index: 1;
}
.post-avatar-pic {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}
.post-avatar-user {
  position: absolute;
  inset: 0;
  z-index: 1;
}

.post-author-info { flex: 1; min-width: 0; }
.post-author-col { display: flex; flex-direction: column; gap: 0; }
.post-author-row { display: flex; align-items: center; gap: 0; flex-wrap: wrap; }
.post-username { font-size: 15px; color: #1a1a1a; font-weight: 600; line-height: 1; }
.post-title-icon { width: 26px; height: 26px; object-fit: contain; flex-shrink: 0; vertical-align: middle; }
.post-author-meta {
  display: flex;
  align-items: center;
  gap: 2px;
  margin-top: -6px;
  font-size: 12px;
  flex-wrap: wrap;
}
.post-exp-icon { width: 32px; height: 32px; object-fit: contain; flex-shrink: 0; }
.post-member-name-icon { width: 22px; height: 22px; object-fit: contain; flex-shrink: 0; }

/* 应用和用户结果列表项 */
.post-item { display:flex; gap:12px; padding:14px; border-bottom:1px solid #f5f5f5; cursor:pointer; transition:background .12s; }
.post-item:active { background:#fafafa; }
.post-left { flex-shrink:0; }
.app-icon { width:44px; height:44px; border-radius:12px; object-fit:cover; }
.app-icon-fb { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:17px; font-weight:700; }
.user-av { width:44px; height:44px; border-radius:50%; object-fit:cover; }
.user-av-fb { width:44px; height:44px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-size:17px; font-weight:700; }
.post-info { flex:1; min-width:0; }
.post-item-title { font-size:14px; font-weight:600; color:#222; line-height:1.4; }
.post-item-meta { font-size:11px; color:#999; margin-top:2px; }

/* Empty */
.empty-state { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:60px 20px; color:#ccc; }
.empty-icon { width:48px; height:48px; margin-bottom:12px; }
.empty-text { font-size:14px; color:#bbb; }

/* Loading */
.loading { display:flex; align-items:center; justify-content:center; gap:8px; padding:40px; color:#999; font-size:13px; }
.spinner { width:18px; height:18px; border:2px solid #e5e7eb; border-top-color:#6366f1; border-radius:50%; animation:spin .6s linear infinite; }
@keyframes spin { to { transform:rotate(360deg) } }

.w-full { width: 100%; }
.h-full { height: 100%; }
.object-cover { object-fit: cover; }
.aspect-square { aspect-ratio: 1 / 1; }
.w-\[13px\] { width: 13px; }
.h-\[13px\] { height: 13px; }

/* Filter Panel */
.filter-bar {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 14px; flex-shrink: 0;
  border-bottom: 1px solid #f0f0f0;
}
.filter-toggle {
  display: flex; align-items: center; gap: 4px;
  padding: 5px 10px; border: 1px solid #e5e5e5; border-radius: 8px;
  background: #f9f9f9; color: #666; font-size: 12px;
  cursor: pointer; flex-shrink: 0; position: relative;
}
.filter-toggle:active { background: #f0f0f0; }
.filter-dot {
  position: absolute; top: -2px; right: -2px;
  width: 7px; height: 7px; border-radius: 50%;
  background: #6366f1;
}
.filter-quicks {
  display: flex; gap: 6px; overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.filter-quicks::-webkit-scrollbar { display: none; }
.filter-chip {
  padding: 4px 10px; border: 1px solid #e5e5e5; border-radius: 20px;
  background: #fff; color: #888; font-size: 11px; cursor: pointer;
  white-space: nowrap; flex-shrink: 0; transition: all .15s;
}
.filter-chip.active { background: #EEF2FF; color: #6366f1; border-color: #6366f1; font-weight: 600; }
.filter-chip:active { opacity: .7; }

.filter-panel {
  padding: 10px 14px; background: #fafafa;
  border-bottom: 1px solid #f0f0f0; flex-shrink: 0;
}
.filter-row {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 8px;
}
.filter-row:last-child { margin-bottom: 0; }
.filter-label {
  font-size: 12px; color: #999; width: 36px; flex-shrink: 0;
  text-align: right;
}
.filter-select {
  flex: 1; padding: 6px 10px; border: 1px solid #e5e5e5;
  border-radius: 8px; font-size: 13px; color: #333;
  background: #fff; outline: none; appearance: auto;
  max-width: 200px;
}
.filter-date-chips {
  display: flex; gap: 6px; flex-wrap: wrap;
}
</style>
