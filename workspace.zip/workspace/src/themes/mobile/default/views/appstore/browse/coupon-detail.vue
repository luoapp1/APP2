<template>
  <div class="page">
    <div class="nav">
      <svg class="bk" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" @click="$router.back()"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
      <span class="t">优惠券详情</span>
    </div>
    <div class="w">
      <template v-if="loading"><div class="ld"/></template>
      <p v-else-if="!list.length" class="em">暂无可用优惠券</p>
      <template v-else>
        <div v-for="c in list" :key="c.couponId || c.id" class="cd">
          <span class="tg">{{ tag(c) }}</span>
          <div class="rw">
            <div>
              <b class="nm">{{ c.name }}</b>
              <p class="tm">{{ fmt(c.receiveTime || c.createTime) }}至{{ fmt(c.expireTime) }}</p>
            </div>
            <div class="rr">
              <b class="pr">{{ price(c) }}</b>
              <span class="pl">{{ c.typeLabel }}</span>
            </div>
          </div>
          <div class="bt">
            <span class="tp">{{ tip(c) }}</span>
            <button class="ub" @click="$router.push('/appstore/browse')">使用</button>
          </div>
        </div>
        <p class="en">已显示全部</p>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchMyCoupons } from '@/api/coupon'
import request from '@/utils/http'
defineOptions({ name: 'CouponDetailMobile' })

const list = ref<any[]>([])
const loading = ref(true)
const tagMap: Record<string, string> = { all: '通用优惠券', product: '商品优惠券', membership: '会员优惠券', decoration: '装饰品券', card_pool: '卡池券', content: '内容券', app: '应用券' }
const tag = (c: any) => c.categoryLabel || tagMap[c.scope] || '优惠券'
const fmt = (d: string) => { if (!d) return ''; const dt = new Date(d); const p = (n: number) => String(n).padStart(2, '0'); return `${dt.getFullYear()}-${p(dt.getMonth()+1)}-${p(dt.getDate())} ${p(dt.getHours())}:${p(dt.getMinutes())}` }
const price = (c: any) => { const t = c.type || '', v = +c.value || 0; if (t.endsWith('_fixed') || t === 'fixed') return `￥${v}`; if (t.endsWith('_percent') || t === 'percent') return `${v / 10}折`; return v }
const tip = (c: any) => { const a: string[] = []; if (c.minOrder > 0) a.push(`满${c.minOrder}可用`); if (c.scopeLabel) a.push(`限${c.scopeLabel}场景`); return a.length ? a.join('，') : '限时活动优惠' }

onMounted(async () => {
  loading.value = true
  try {
    const [coupons, opts] = await Promise.all([fetchMyCoupons({ status: 'unused' }), request.get({ url: '/api/coupon/options' })]) as any[]
    list.value = (coupons || []).filter((c: any) => c.status === 'unused')
  } catch { list.value = [] }
  loading.value = false
})
</script>

<style scoped>
.page { max-width: 960px; margin: 0 auto; background: #f9f9f9; min-height: 100vh; }
.nav { display: flex; align-items: center; height: 48px; padding: 0 12px; position: fixed; top: 0; left: 0; right: 0; z-index: 10; background: #fff; }
.bk { width: 20px; height: 20px; color: #111; cursor: pointer; flex-shrink: 0; }
.t { position: absolute; left: 50%; transform: translateX(-50%); font-size: 17px; font-weight: 600; color: #111; }
.w { padding: 58px 14px 10px; }
.ld { width: 18px; height: 18px; border: 2px solid #f03; border-top-color: transparent; border-radius: 50%; animation: sp 0.6s linear infinite; margin: 40px auto; }
@keyframes sp { to { transform: rotate(360deg); } }
.em { text-align: center; padding: 48px 0; font-size: 13px; color: #bbb; }
.cd { background: #fff; border-radius: 12px; padding: 14px 14px 12px; margin-bottom: 12px; position: relative; overflow: hidden; }
.tg { position: absolute; top: 0; left: 0; background: #f3e9d2; color: #947847; font-size: 12px; padding: 3px 14px 3px 10px; border-radius: 0 0 12px 0; }
.rw { display: flex; justify-content: space-between; align-items: flex-start; margin-top: 4px; }
.nm { font-size: 15px; font-weight: 500; color: #111; line-height: 1.3; }
.tm { font-size: 11px; color: #888; margin-top: 4px; }
.rr { text-align: right; flex-shrink: 0; }
.pr { font-size: 28px; color: #ff5038; font-weight: 500; line-height: 1.1; display: block; }
.pl { font-size: 12px; color: #ff5038; }
.bt { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; }
.tp { font-size: 11px; color: #999; flex: 1; }
.ub { background: #f3e2bc; color: #946e39; border: none; border-radius: 99px; padding: 5px 16px; font-size: 12px; cursor: pointer; }
.ub:active { opacity: 0.8; }
.en { text-align: center; padding: 20px 0; font-size: 12px; color: #bbb; }
</style>
