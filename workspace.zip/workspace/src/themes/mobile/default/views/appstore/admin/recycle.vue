<!-- 回收站 - 移动端管理页面 -->
<template>
  <div v-if="!isAdmin" class="min-h-screen flex items-center justify-center bg-[#f5f6f8] p-6">
    <div class="text-center">
      <svg class="mx-auto mb-4" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
        <rect x="3" y="11" width="18" height="11" rx="2" />
        <path d="M7 11V7a5 5 0 0110 0v4" />
      </svg>
      <p class="text-gray-500 text-sm">无权访问此页面</p>
      <button class="mt-4 px-6 py-2 bg-[#FF4757] text-white rounded-lg text-sm" @click="$router.back()">返回</button>
    </div>
  </div>

  <div v-else class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="sticky top-0 z-20 bg-white shadow-sm">
      <div class="flex items-center px-3 py-3">
        <button class="p-1 -ml-1" @click="$router.back()">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6" /></svg>
        </button>
        <h1 class="flex-1 text-center text-base font-bold mr-6">回收站</h1>
        <button v-if="list.length > 0" v-auth="'delete'" class="text-xs px-2 py-1 rounded-lg text-red-500 font-medium active:bg-red-50" @click="handleClearAll">清空</button>
      </div>

      <div class="px-3 pb-3 space-y-2">
        <select v-model="filterTable" class="w-full bg-gray-50 rounded-xl px-3 py-2.5 text-sm border-none outline-none appearance-none text-gray-700" @change="onFilterChange">
          <option value="">全部来源</option>
          <option value="community_posts">社区帖子</option>
          <option value="community_comments">社区评论</option>
          <option value="app_store">应用</option>
          <option value="app_comments">应用评论</option>
        </select>
      </div>
    </div>

    <div class="px-3 py-2 bg-white border-b border-gray-50" v-if="total >= 0">
      <div class="flex items-center justify-between mb-2">
        <span class="text-xs text-gray-400">共 {{ total }} 条，{{ currentPage }}/{{ totalPages }} 页</span>
        <button v-if="filterTable" class="text-xs text-[#FF4757]" @click="clearFilter">清除筛选</button>
      </div>
      <div class="flex items-center gap-2">
        <button :disabled="currentPage <= 1" class="flex-1 py-2 rounded-lg text-xs font-medium border transition-colors" :class="currentPage <= 1 ? 'text-gray-300 border-gray-200 bg-gray-50' : 'text-gray-600 border-gray-200 active:bg-gray-50'" @click="goPage(currentPage - 1)">上一页</button>
        <div class="flex gap-1">
          <button v-for="p in pageNumbers" :key="p" :class="p === currentPage ? 'bg-[#FF4757] text-white border-[#FF4757]' : 'text-gray-600 border-gray-200 active:bg-gray-50'" class="w-8 h-8 flex items-center justify-center rounded-lg text-xs font-medium border transition-colors" @click="goPage(p)">{{ p }}</button>
        </div>
        <button :disabled="currentPage >= totalPages" class="flex-1 py-2 rounded-lg text-xs font-medium border transition-colors" :class="currentPage >= totalPages ? 'text-gray-300 border-gray-200 bg-gray-50' : 'text-gray-600 border-gray-200 active:bg-gray-50'" @click="goPage(currentPage + 1)">下一页</button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto px-3 pb-4">
      <div v-if="loading" class="flex items-center justify-center py-20">
        <svg class="animate-spin" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#FF4757" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" /></svg>
      </div>

      <div v-else-if="list.length === 0" class="flex flex-col items-center justify-center py-20">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="1.5">
          <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
          <path d="M10 11v6M14 11v6" />
        </svg>
        <p class="text-gray-400 text-sm mt-3">回收站为空</p>
      </div>

      <div v-else class="space-y-2">
        <div v-for="item in list" :key="item.id" class="bg-white rounded-xl p-3" @click="showDetail(item)">
          <div class="flex items-start justify-between mb-1.5">
            <span class="text-xs px-2 py-0.5 rounded-full bg-orange-50 text-orange-600 font-medium">{{ tableLabel(item.original_table) }}</span>
            <span class="text-[10px] text-gray-400">{{ formatTime(item.create_time) }}</span>
          </div>
          <div class="flex items-center gap-1 text-xs text-gray-500 mb-1">
            <span>原ID: {{ item.original_id }}</span>
            <span class="text-gray-300">|</span>
            <span>{{ item.deleted_by_name || '未知' }}</span>
          </div>
          <p v-if="item.delete_reason" class="text-xs text-gray-400 line-clamp-1 mb-2">{{ item.delete_reason }}</p>
          <div class="flex justify-end gap-2 mt-2">
            <button v-auth="'restore'" class="text-xs px-3 py-1.5 bg-green-50 text-green-600 rounded-lg font-medium active:bg-green-100" @click.stop="handleRestore(item)">恢复</button>
            <button v-auth="'delete'" class="text-xs px-3 py-1.5 bg-red-50 text-red-500 rounded-lg font-medium active:bg-red-100" @click.stop="handleDelete(item)">彻底删除</button>
          </div>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <Transition name="slide-up">
        <div v-if="detailVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closeDetail">
          <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
            <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
              <button @click="closeDetail">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
              </button>
              <span class="text-base font-bold">回收详情</span>
              <div class="w-6" />
            </div>
            <div v-if="detailItem" class="overflow-y-auto px-4 py-3 space-y-3">
              <div class="bg-gray-50 rounded-2xl p-4 space-y-3">
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">来源表</span>
                  <span class="text-sm font-medium">{{ tableLabel(detailItem.original_table) }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">原记录ID</span>
                  <span class="text-sm text-gray-600">#{{ detailItem.original_id }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">删除者</span>
                  <span class="text-sm text-gray-600">{{ detailItem.deleted_by_name || '未知' }}</span>
                </div>
                <div class="flex justify-between items-center" v-if="detailItem.delete_reason">
                  <span class="text-xs text-gray-400">删除原因</span>
                  <span class="text-sm text-gray-600">{{ detailItem.delete_reason }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">删除时间</span>
                  <span class="text-sm text-gray-600">{{ detailItem.create_time }}</span>
                </div>
              </div>
              <div class="bg-gray-50 rounded-2xl p-4">
                <p class="text-xs text-gray-400 mb-2">原始数据</p>
                <pre class="text-xs text-gray-600 whitespace-pre-wrap break-all font-mono overflow-x-auto max-h-64 overflow-y-auto">{{ formatDataJson(detailItem.data_json) }}</pre>
              </div>
              <div class="flex gap-2">
                <button v-auth="'restore'" class="flex-1 py-3 bg-green-50 text-green-600 rounded-xl text-sm font-medium active:bg-green-100" @click="handleRestoreFromDetail">恢复</button>
                <button v-auth="'delete'" class="flex-1 py-3 bg-red-50 text-red-500 rounded-xl text-sm font-medium active:bg-red-100" @click="handleDeleteFromDetail">彻底删除</button>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'RecycleBinMobile' })

const userStore = useUserStore()
const isAdmin = computed(() => {
  const roles = userStore.info.roles || []
  return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
})

const tableNameMap: Record<string, string> = {
  community_posts: '社区帖子',
  community_comments: '社区评论',
  app_store: '应用',
  app_comments: '应用评论'
}

function tableLabel(table: string) {
  return tableNameMap[table] || table
}

const list = ref<any[]>([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(15)
const total = ref(0)
const filterTable = ref('')

const detailVisible = ref(false)
const detailItem = ref<any>(null)

const totalPages = computed(() => Math.ceil(total.value / pageSize.value) || 1)

const pageNumbers = computed(() => {
  const pages: number[] = []
  const tp = totalPages.value
  const cp = currentPage.value
  let start = Math.max(1, cp - 2)
  let end = Math.min(tp, cp + 2)
  if (end - start < 4) {
    if (start === 1) end = Math.min(tp, start + 4)
    else start = Math.max(1, end - 4)
  }
  for (let i = start; i <= end; i++) pages.push(i)
  return pages
})

function formatTime(time: string) {
  if (!time) return ''
  return time.replace(/^.*?(\d{2}:\d{2}:\d{2}).*$/, '$1')
}

function formatDataJson(json: string) {
  try {
    return JSON.stringify(JSON.parse(json), null, 2)
  } catch {
    return json
  }
}

async function fetchList() {
  loading.value = true
  try {
    const params: any = { page: currentPage.value, pageSize: pageSize.value }
    if (filterTable.value) params.table = filterTable.value
    const res: any = await request.get({ url: '/api/recycle/list', params })
    if (res) {
      list.value = res.list || []
      total.value = res.total || 0
    }
  } finally {
    loading.value = false
  }
}

async function handleRestore(item: any) {
  if (!confirm('确定恢复该记录吗？')) return
  try {
    await request.post({ url: `/api/recycle/restore/${item.id}` })
    alert('恢复成功')
    if (detailVisible.value) closeDetail()
    fetchList()
  } catch (e: any) {
    alert(e?.msg || e?.message || '恢复失败')
  }
}

async function handleDelete(item: any) {
  if (!confirm('确定永久删除？此操作不可恢复！')) return
  try {
    await request.del({ url: `/api/recycle/${item.id}` })
    alert('已永久删除')
    if (detailVisible.value) closeDetail()
    fetchList()
  } catch (e: any) {
    alert(e?.msg || e?.message || '删除失败')
  }
}

async function handleClearAll() {
  if (!confirm('确定清空回收站？所有数据将无法恢复！')) return
  try {
    await request.post({ url: '/api/recycle/clear' })
    alert('回收站已清空')
    fetchList()
  } catch (e: any) {
    alert(e?.msg || e?.message || '清空失败')
  }
}

function handleRestoreFromDetail() {
  if (detailItem.value) handleRestore(detailItem.value)
}

function handleDeleteFromDetail() {
  if (detailItem.value) handleDelete(detailItem.value)
}

function showDetail(item: any) {
  detailItem.value = item
  detailVisible.value = true
}

function closeDetail() {
  detailVisible.value = false
  detailItem.value = null
}

function goPage(p: number) {
  if (p < 1 || p > totalPages.value) return
  currentPage.value = p
  fetchList()
}

function onFilterChange() {
  currentPage.value = 1
  fetchList()
}

function clearFilter() {
  filterTable.value = ''
  currentPage.value = 1
  fetchList()
}

onMounted(() => {
  if (isAdmin.value) fetchList()
})
</script>

<style scoped>
.slide-up-enter-active,
.slide-up-leave-active {
  transition: opacity 0.25s ease;
}
.slide-up-enter-active > div:last-child,
.slide-up-leave-active > div:last-child {
  transition: transform 0.25s ease;
}
.slide-up-enter-from,
.slide-up-leave-to {
  opacity: 0;
}
.slide-up-enter-from > div:last-child,
.slide-up-leave-to > div:last-child {
  transform: translateY(100%);
}

@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.animate-slide-up {
  animation: slide-up 0.25s ease;
}

.line-clamp-1 {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
