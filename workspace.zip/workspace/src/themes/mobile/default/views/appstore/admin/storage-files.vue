<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-2 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">存储文件</span>
    </div>

    <div v-if="toastMsg" class="fixed top-14 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <!-- 存储配置选择器 -->
    <div class="bg-white mx-3 mt-3 rounded-xl p-3 space-y-2">
      <div class="flex items-center gap-2">
        <span class="text-xs text-gray-400 flex-shrink-0">选择存储</span>
        <select v-model="configId" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-700" @change="onConfigChange">
          <option :value="0" disabled>请选择存储配置</option>
          <option v-for="c in configs" :key="c.id" :value="c.id">{{ c.name }} ({{ typeLabel(c.type) }})</option>
        </select>
        <button class="flex-shrink-0 h-9 w-9 rounded-lg bg-[#f5f6f8] flex items-center justify-center active:bg-gray-200" @click="loadConfigs">
          <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
        </button>
      </div>

      <!-- 排序 -->
      <div class="flex items-center gap-1.5" v-if="configId">
        <span class="text-[10px] text-gray-400 flex-shrink-0">排序</span>
        <button
          v-for="s in sorts" :key="s.value"
          class="text-[10px] px-2 py-1 rounded-md transition-colors"
          :class="sortBy===s.value ? 'bg-blue-50 text-blue-600' : 'bg-[#f5f6f8] text-gray-500'"
          @click="toggleSort(s.value)"
        >
          {{ s.label }}
          <span v-if="sortBy===s.value" class="ml-0.5">{{ sortOrder==='asc' ? '↑' : '↓' }}</span>
        </button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="!configId" class="flex flex-col items-center py-20 text-gray-400 gap-2">
        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z"/></svg>
        <span class="text-sm">请选择云存储配置</span>
      </div>

      <div v-else-if="loading" class="flex justify-center py-16">
        <div class="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full" />
      </div>

      <template v-else>
        <!-- 分页 -->
        <div v-if="totalCount>0||files.length>0" class="mx-3 mt-2">
          <div class="flex items-center gap-2 text-[10px] text-gray-400 mb-2">
            <span>{{ currentCfgName }}</span>
            <span>| {{ page }}/{{ Math.max(totalPages,1)||1 }} 页</span>
          </div>
          <div class="bg-white rounded-xl px-3 py-2.5 space-y-2">
            <div class="flex items-center justify-between gap-2">
              <span class="text-[11px] text-gray-400">共 {{ totalCount }} 个文件</span>
              <div class="flex gap-1.5">
                <button :disabled="!hasPrev" class="text-[11px] px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 disabled:opacity-30" @click="prevPage">上一页</button>
                <span class="text-[11px] text-gray-500 self-center font-medium">{{ page }}/{{ Math.max(totalPages,1)||1 }}</span>
                <button :disabled="!hasNext" class="text-[11px] px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 disabled:opacity-30" @click="nextPage">下一页</button>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-gray-400">每页</span>
              <button v-for="ps in [12, 20, 30]" :key="ps" class="text-[10px] w-7 h-6 rounded-md" :class="pageSize===ps?'bg-blue-500 text-white':'bg-gray-100 text-gray-500'" @click="setPageSize(ps)">{{ ps }}</button>
              <span class="text-[10px] text-gray-400">条</span>
            </div>
          </div>
        </div>

        <!-- 文件网格 -->
        <div v-if="files.length > 0" class="mx-3 mt-2 grid grid-cols-2 gap-2">
          <div v-for="f in files" :key="f.key" class="bg-white rounded-xl overflow-hidden shadow-sm relative" @click="openDetail(f)">
            <button v-auth="'delete'" class="absolute top-1.5 right-1.5 z-10 w-6 h-6 rounded-full bg-white/80 flex items-center justify-center active:bg-red-50" @click.stop="confirmDelete(f)">
              <svg class="w-3.5 h-3.5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
            <div class="w-full aspect-square flex items-center justify-center bg-[#fafafa] relative" @click="openDetail(f)">
              <img v-if="isImageFile(f.name)" :src="$fixImgUrl(f.url)" class="w-full h-full object-cover" loading="lazy" />
              <svg v-else-if="isVideoFile(f.name)" class="w-10 h-10 text-green-500" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              <svg v-else-if="isAudioFile(f.name)" class="w-10 h-10 text-orange-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
              <svg v-else class="w-10 h-10 text-gray-300" fill="currentColor" viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4zM8 13h8v2H8v-2zm0 4h8v2H8v-2zm0-8h3v2H8V9z"/></svg>
            </div>
            <div class="px-2 py-2">
              <div class="text-[11px] font-medium text-gray-700 truncate">{{ f.name }}</div>
              <div class="text-[10px] text-gray-400 mt-0.5">{{ formatSize(f.size) }}</div>
            </div>
          </div>
        </div>

        <!-- 空文件 -->
        <div v-if="files.length===0&&!loading" class="flex flex-col items-center py-16 text-gray-400 gap-2">
          <span class="text-sm">此存储暂无文件</span>
        </div>
      </template>
    </div>

    <!-- 详情底部弹窗 -->
    <teleport to="body">
      <div v-if="detailVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="detailVisible=false">
        <div class="bg-white rounded-2xl w-full max-w-lg max-h-[75vh] overflow-y-auto" @click.stop>
          <div class="sticky top-0 bg-white rounded-t-2xl border-b border-gray-100 px-4 py-3 flex items-center justify-between z-10">
            <span class="text-sm font-semibold text-gray-800 truncate pr-4">{{ detailFile?.name }}</span>
            <svg class="w-5 h-5 text-gray-400 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="detailVisible=false"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </div>
          <div v-if="detailFile" class="p-4 space-y-4">
            <div v-if="isImageFile(detailFile.name)" class="rounded-xl overflow-hidden bg-[#fafafa] flex items-center justify-center">
              <img :src="detailFile.url" class="max-w-full max-h-[300px] object-contain"  loading="lazy" />
            </div>
            <div v-else class="rounded-xl bg-[#f5f6f8] flex flex-col items-center py-8 gap-2">
              <svg class="w-12 h-12 text-gray-300" fill="currentColor" viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6z"/></svg>
              <span class="text-xs text-gray-400">非图片文件</span>
            </div>
            <div class="space-y-2">
              <div class="flex justify-between text-xs"><span class="text-gray-400">文件名</span><span class="text-gray-700 font-medium text-right ml-4 break-all">{{ detailFile.name }}</span></div>
              <div class="flex justify-between text-xs"><span class="text-gray-400">大小</span><span class="text-gray-700">{{ formatSize(detailFile.size) }}</span></div>
              <div class="flex justify-between text-xs"><span class="text-gray-400 flex-shrink-0">修改时间</span><span class="text-gray-700 text-right">{{ formatDate(detailFile.mtime) }}</span></div>
              <div class="flex justify-between text-xs"><span class="text-gray-400">ETag</span><span class="text-gray-700 text-right ml-4 break-all text-[10px]">{{ detailFile.etag || '-' }}</span></div>
              <div class="border-t border-gray-100 pt-2">
                <span class="text-xs text-gray-400 block mb-1">Key（文件路径）</span>
                <code class="text-[11px] bg-gray-100 rounded-lg px-2 py-1.5 block break-all text-gray-600">{{ detailFile.key }}</code>
              </div>
              <div class="border-t border-gray-100 pt-2">
                <span class="text-xs text-gray-400 block mb-1">访问链接</span>
                <div class="flex items-center gap-2">
                  <code class="text-[11px] bg-gray-100 rounded-lg px-2 py-1.5 flex-1 break-all text-gray-600">{{ detailFile.url }}</code>
                  <button class="text-[11px] px-3 py-1.5 rounded-lg bg-blue-50 text-blue-500 flex-shrink-0" @click="copyUrl(detailFile.url)">复制</button>
                </div>
              </div>
            </div>
            <a :href="detailFile.url" target="_blank" class="block w-full text-center text-sm py-2.5 rounded-xl bg-blue-500 text-white font-medium active:bg-blue-600">在新窗口打开</a>
            <button v-auth="'delete'" class="block w-full text-center text-sm py-2.5 rounded-xl bg-red-50 text-red-500 font-medium active:bg-red-100 mt-2" @click="confirmDelete(detailFile); detailVisible=false">删除此文件</button>
          </div>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'StorageFilesMobile' })

const TYPE_MAP:Record<string,string>={cos:'腾讯云COS',oss:'阿里云OSS',minio:'MinIO',s3:'AWS S3',qiniu:'七牛云',huawei:'华为云OBS'}
const typeLabel=(t:string)=>TYPE_MAP[t]||t

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const configs=ref<any[]>([])
const configId=ref(0)
const currentCfgName=ref('')
const files=ref<any[]>([])
const loading=ref(false)
const page=ref(1)
const pageSize=ref(12)
const totalCount=ref(0)
const totalPages=ref(1)
const hasNext=ref(false)
const hasPrev=ref(false)
const sortBy=ref('name')
const sortOrder=ref('asc')
const markers=ref<string[]>([''])
const detailVisible=ref(false)
const detailFile=ref<any>(null)

const sorts=[{value:'name',label:'名称'},{value:'size',label:'大小'},{value:'time',label:'时间'}]

const formatSize=(bytes:number)=>{if(!bytes)return'0 B';const units=['B','KB','MB','GB'];let i=0;let v=bytes;while(v>=1024&&i<units.length-1){v/=1024;i++}return v.toFixed(i>0?1:0)+' '+units[i]}
const formatDate=(iso:string)=>{if(!iso)return'-';return new Date(iso).toLocaleString('zh-CN',{hour12:false})}

const isImageFile=(name:string)=>['.jpg','.jpeg','.png','.gif','.webp','.bmp','.svg','.ico'].some(e=>name.toLowerCase().endsWith(e))
const isVideoFile=(name:string)=>['.mp4','.avi','.mov','.wmv','.flv','.mkv','.webm'].some(e=>name.toLowerCase().endsWith(e))
const isAudioFile=(name:string)=>['.mp3','.wav','.ogg','.aac','.flac','.m4a'].some(e=>name.toLowerCase().endsWith(e))

const loadConfigs=async()=>{
  try{
    const res:any=await request.get({url:'/api/storage-config/list'})
    configs.value=(res?.data||res||[]).filter((c:any)=>c.type!=='local')
    if(!configId.value&&configs.value.length>0){
      configId.value=configs.value[0].id
      onConfigChange()
    }
  }catch{}
}

const fetchFiles=async(marker?:string)=>{
  if(!configId.value)return
  loading.value=true
  try{
    const params:any={pageSize:pageSize.value,sortBy:sortBy.value,sortOrder:sortOrder.value}
    const m = marker !== undefined ? marker : (markers.value[page.value-1]||'')
    if(m) params.marker=m
    const res:any=await request.get({url:`/api/storage-config/${configId.value}/browse`,params})
    const d=res?.data||res||{}
    files.value=d.files||[]
    hasNext.value=d.isTruncated||false
    hasPrev.value=page.value>1
    totalCount.value=d.isTruncated?page.value*pageSize.value+1:files.value.length

    if(markers.value.length<=page.value) markers.value[page.value]=d.nextMarker||''
  }catch(e){showToast('加载失败','error')}
  loading.value=false
}

const onConfigChange=()=>{
  const c=configs.value.find((x:any)=>x.id===configId.value)
  currentCfgName.value=c?`${c.name} (${typeLabel(c.type)})`:''
  page.value=1;markers.value=[''];fetchFiles()
}
const toggleSort=(v:string)=>{
  if(sortBy.value===v){sortOrder.value=sortOrder.value==='asc'?'desc':'asc'}else{sortBy.value=v;sortOrder.value='asc'}
  page.value=1;markers.value=[''];fetchFiles()
}
const nextPage=()=>{page.value++;fetchFiles()}
const prevPage=()=>{if(page.value>1){page.value--;fetchFiles()}}
const setPageSize=(ps:number)=>{pageSize.value=ps;page.value=1;markers.value=[''];fetchFiles()}

const openDetail=(f:any)=>{detailFile.value=f;detailVisible.value=true}
const copyUrl=async(u:string)=>{try{await navigator.clipboard.writeText(u);showToast('链接已复制')}catch{showToast('复制失败','error')}}

const confirmDelete=async(f:any)=>{
  if(!confirm(`确定删除文件 ${f.name}？此操作不可恢复。`))return
  try{
    await request.del({url:`/api/storage-config/${configId.value}/file`,params:{key:f.key}})
    showToast('删除成功');fetchFiles()
  }catch{showToast('删除失败','error')}
}

onMounted(()=>loadConfigs())
</script>

<style scoped>
.animate-slide-up{animation:slideUp .25s ease-out}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
</style>
