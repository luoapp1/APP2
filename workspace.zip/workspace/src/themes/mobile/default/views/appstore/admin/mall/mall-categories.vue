<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">分类管理</span>
      <button class="add-btn" v-auth="'add'" @click="showAdd">+ 新增</button>
    </div>
    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>
    <div v-else class="list">
      <div v-for="c in categories" :key="c.id" class="item">
        <span class="cat-name">{{ c.name }}</span>
        <span class="cat-status">{{ c.status === '1' ? '启用' : '禁用' }}</span>
        <div class="cat-actions">
          <button @click="editItem(c)" v-auth="'edit'" class="act-edit">编辑</button>
          <button @click="deleteItem(c)" v-auth="'delete'" class="act-del">删除</button>
        </div>
      </div>
    </div>

    <div v-if="showDialog" class="modal-overlay" @click.self="showDialog = false">
      <div class="modal">
        <div class="modal-title">{{ editId ? '编辑分类' : '新增分类' }}</div>
        <div class="field">
          <label>分类名称</label>
          <input v-model="formName" placeholder="分类名称" class="input" />
        </div>
        <div class="field">
          <label>上级分类</label>
          <select v-model="formParentId" class="input">
            <option :value="0">顶级分类</option>
            <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
          </select>
        </div>
        <div class="field">
          <label>图标URL</label>
          <input v-model="formIcon" placeholder="图标URL" class="input" />
        </div>
        <div class="field">
          <label>排序</label>
          <input v-model.number="formSort" type="number" min="0" class="input" />
        </div>
        <div class="modal-actions">
          <button @click="showDialog = false" class="btn-cancel">取消</button>
          <button @click="save" class="btn-confirm">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const categories = ref<any[]>([])
const loading = ref(true)
const showDialog = ref(false)
const editId = ref(0)
const formName = ref('')
const formParentId = ref(0)
const formIcon = ref('')
const formSort = ref(0)

async function loadList() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    categories.value = res || []
  } catch {} finally { loading.value = false }
}

function showAdd() {
  editId.value = 0; formName.value = ''; formParentId.value = 0; formIcon.value = ''; formSort.value = 0
  showDialog.value = true
}

function editItem(c: any) {
  editId.value = c.id; formName.value = c.name; formParentId.value = c.parentId || 0
  formIcon.value = c.icon || ''; formSort.value = c.sortOrder || 0
  showDialog.value = true
}

async function save() {
  if (!formName.value.trim()) return alert('请输入分类名称')
  try {
    const data = { name: formName.value, parentId: formParentId.value, icon: formIcon.value, sortOrder: formSort.value, status: '1' }
    if (editId.value) {
      await request.put({ url: `/api/mall/categories/${editId.value}`, data })
    } else {
      await request.post({ url: '/api/mall/categories', data })
    }
    showDialog.value = false
    loadList()
  } catch {}
}

async function deleteItem(c: any) {
  if (!confirm(`确定删除分类"${c.name}"？`)) return
  try {
    await request.del({ url: `/api/mall/categories/${c.id}` })
    loadList()
  } catch {}
}

onMounted(loadList)
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.add-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; cursor: pointer; }
.loading { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }
.list { padding: 8px 0; }
.item { display: flex; align-items: center; padding: 12px 14px; background: #fff; margin: 0 10px 8px; border-radius: 12px; gap: 10px; }
.cat-name { font-size: 14px; font-weight: 600; color: #222; flex: 1; }
.cat-status { font-size: 11px; color: #999; }
.cat-actions { display: flex; gap: 8px; }
.act-edit { border: none; background: #E3F2FD; color: #1565C0; padding: 4px 10px; border-radius: 6px; font-size: 11px; cursor: pointer; }
.act-del { border: none; background: #FFEBEE; color: #C62828; padding: 4px 10px; border-radius: 6px; font-size: 11px; cursor: pointer; }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100; }
.modal { background: #fff; width: 100%; max-width: 500px; border-radius: 16px 16px 0 0; padding: 20px; }
.modal-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; }
.modal-actions { display: flex; gap: 10px; margin-top: 16px; }
.btn-cancel { flex: 1; padding: 10px; border: 1px solid #ddd; background: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
.btn-confirm { flex: 1; padding: 10px; border: none; background: #FF6B6B; color: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
</style>
