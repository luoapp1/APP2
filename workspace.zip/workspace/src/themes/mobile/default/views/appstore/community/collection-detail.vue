<template>
  <div class="collection-detail-page">
    <!-- 顶部导航 -->
    <div class="cd-nav">
      <button class="cd-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="cd-nav-title">合集</span>
      <div class="cd-nav-right">
        <button v-if="collection && !collection.isAuthor && userId && !isFavorited" class="cd-nav-fav" @click="showFavPicker = true; loadFavPickerGroups()">收藏</button>
        <button v-if="collection && !collection.isAuthor && userId && isFavorited" class="cd-nav-fav cd-nav-fav-active" @click="unfavoriteCollection">已收藏{{ favGroupName ? ' · ' + favGroupName : '' }}</button>
        <button v-if="collection && collection.isAuthor" class="cd-nav-fav cd-nav-fav-manage" @click="goManage">编辑</button>
        <button class="cd-nav-share" @click="handleCollectionShare">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v13"/></svg>
        </button>
      </div>
    </div>

    <div v-if="loading" class="cd-loading">加载中...</div>
    <div v-else-if="errorMsg" class="cd-empty">
      <div class="cd-empty-icon">&#128533;</div>
      <div class="cd-empty-text">{{ errorMsg }}</div>
      <button class="cd-empty-btn" @click="$router.back()">返回</button>
    </div>
    <div v-else-if="collection" class="cd-body">
      <!-- 封面区域 -->
      <div class="cd-cover-section">
        <div class="cd-cover-img-wrap">
          <img v-if="collection.cover_image" :src="collection.cover_image" class="cd-cover-img" />
          <div v-else class="cd-cover-placeholder">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.6)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
          </div>
        </div>
        <div class="cd-cover-info">
          <h1 class="cd-title">{{ collection.title }}</h1>
          <div class="cd-meta">
            <span>{{ collection.user_name }}</span>
            <span class="cd-meta-sep">·</span>
            <span>{{ collection.post_count }}篇</span>
            <span v-if="collection.subscribe_count > 0">
              <span class="cd-meta-sep">·</span>
              <span>{{ collection.subscribe_count }}人已购</span>
            </span>
            <span v-if="shareCount > 0">
              <span class="cd-meta-sep">·</span>
              <span>{{ shareCount }}次分享</span>
            </span>
            <span v-if="collection.status === 'finished'" class="cd-status-finished">已完结</span>
            <span v-else-if="collection.status === 'serializing'" class="cd-status-serializing">连载中</span>
          </div>
          <div class="cd-price-row">
            <template v-if="collection.is_paid && hasAnyPrice">
              <span v-if="collection.price_balance > 0" class="cd-price-tag cd-price-tag-balance">{{ collection.price_balance }} 余额</span>
              <span v-if="collection.price_points > 0" class="cd-price-tag cd-price-tag-points">{{ collection.price_points }} 积分</span>
            </template>
            <span v-else class="cd-price-tag cd-price-tag-free">免费</span>
          </div>
        </div>
      </div>

      <!-- 简介 -->
      <div v-if="collection.description" class="cd-desc" :class="{ 'cd-desc-expanded': descExpanded, 'cd-desc-long': descLong }">
        <span class="cd-desc-label">简介</span>
        <span class="cd-desc-text">{{ collection.description }}</span>
        <span v-if="descLong" class="cd-desc-toggle" @click="descExpanded = !descExpanded">{{ descExpanded ? '收起' : '展开' }}</span>
      </div>

      <!-- 购买按钮 -->
      <div v-if="collection.is_paid && hasAnyPrice && !collection.isAuthor && !collection.hasPaid" class="cd-actions">
        <button class="cd-btn cd-btn-buy" @click="showBuyModal = true">购买合集</button>
      </div>
      <div v-else-if="collection.is_paid && hasAnyPrice && !collection.isAuthor && collection.hasPaid" class="cd-actions">
        <div class="cd-owned-badge">已购买</div>
      </div>
      <div v-else-if="collection.isAuthor" class="cd-actions">
        <button class="cd-btn cd-btn-manage" @click="goManage">管理合集</button>
      </div>
      <div v-else-if="!collection.isAuthor && !userId && hasAnyPrice" class="cd-actions">
        <button class="cd-btn cd-btn-login" @click="$router.push('/auth/login')">登录后可阅读</button>
      </div>

      <!-- 作者视角：收入汇总 -->
      <div v-if="collection.isAuthor && revenueTotal > 0" class="cd-revenue-card">
        <div class="cd-revenue-header">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
          <span>收入汇总</span>
        </div>
        <div class="cd-revenue-body">
          <div class="cd-revenue-item">
            <span class="cd-revenue-label">余额收入</span>
            <span class="cd-revenue-value">{{ revenueBalance }} 余额</span>
          </div>
          <div class="cd-revenue-item">
            <span class="cd-revenue-label">积分收入</span>
            <span class="cd-revenue-value">{{ revenuePoints }} 积分</span>
          </div>
          <div class="cd-revenue-item">
            <span class="cd-revenue-label">购买人次</span>
            <span class="cd-revenue-value">{{ collection.subscribe_count || 0 }}人</span>
          </div>
        </div>
      </div>

      <!-- 订阅者列表 -->
      <div v-if="collection.subscribers && collection.subscribers.length > 0" class="cd-subscribers">
        <div class="cd-subscribers-header">
          <span>订阅者 ({{ collection.subscribers.length }})</span>
        </div>
        <div class="cd-subscribers-list">
          <div v-for="sub in collection.subscribers.slice(0, 12)" :key="sub.user_id" class="cd-subscriber-item">
            <div class="cd-subscriber-avatar" :style="{ background: avatarColor(sub.user_name) }">{{ sub.user_name?.[0] || '?' }}</div>
            <span class="cd-subscriber-name">{{ sub.user_name }}</span>
          </div>
        </div>
      </div>

      <!-- 收藏分组选择弹窗 -->
      <div v-if="showFavPicker" class="cd-modal-mask" @click.self="showFavPicker = false">
        <div class="cd-modal" style="max-width: 340px;">
          <div class="cd-modal-header">
            <span>选择收藏分组</span>
            <button class="cd-modal-close" @click="showFavPicker = false">&times;</button>
          </div>
          <div class="cd-modal-section" style="max-height: 280px; overflow-y: auto;">
            <div
              v-for="g in favPickerGroups"
              :key="g.id"
              class="cd-fav-group-item"
              :class="{ active: favPickerSelectedId === g.id }"
              @click="favPickerSelectedId = g.id"
            >
              <span>{{ g.name }}</span>
              <span style="font-size: 11px; color: #999;">({{ g.count }})</span>
            </div>
            <div v-if="favPickerGroups.length === 0" style="text-align: center; padding: 16px; color: #999; font-size: 13px;">暂无分组</div>
          </div>
          <div style="display: flex; gap: 8px; margin-top: 12px;">
            <button class="cd-btn" style="flex: 1; background: #f5f6fa; color: #666; border: none;" @click="createFavGroupFromPicker">新建分组</button>
            <button class="cd-btn" style="flex: 1; background: #EC4899; color: #fff; border: none;" @click="confirmFavorite">确认收藏</button>
          </div>
        </div>
      </div>

      <!-- 分组名称输入弹窗 -->
      <div
        v-if="showGroupNameDialog"
        class="cd-modal-mask" style="z-index: 110;"
        @click.self="showGroupNameDialog = false"
      >
        <div style="background: #fff; border-radius: 16px; width: 300px; padding: 24px 20px 20px; box-shadow: 0 12px 40px rgba(0,0,0,.15);">
          <div style="font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 16px;">{{ groupDialogTitle }}</div>
          <input
            ref="groupDialogInput"
            v-model="groupDialogValue"
            placeholder="请输入分组名称"
            style="width: 100%; padding: 10px 14px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 15px; outline: none; box-sizing: border-box;"
            @keyup.enter="confirmGroupNameDialog"
          />
          <div style="display: flex; gap: 10px; margin-top: 18px;">
            <button style="flex: 1; padding: 10px 0; border: none; border-radius: 10px; background: #f3f4f6; color: #666; font-size: 14px; cursor: pointer;" @click="showGroupNameDialog = false">取消</button>
            <button style="flex: 1; padding: 10px 0; border: none; border-radius: 10px; background: #EC4899; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="confirmGroupNameDialog">确定</button>
          </div>
        </div>
      </div>

      <!-- 购买弹窗 -->
      <div v-if="showBuyModal" class="cd-modal-mask" @click.self="showBuyModal = false">
        <div class="cd-modal">
          <div class="cd-modal-header">
            <span class="cd-modal-title">购买合集</span>
            <button class="cd-modal-close" @click="showBuyModal = false">&times;</button>
          </div>
          <div class="cd-modal-desc">{{ collection.title }}</div>
          <div class="cd-modal-section">
            <div class="cd-modal-section-label">选择支付方式</div>
            <div class="cd-buy-options">
              <div v-if="collection.price_balance > 0" class="cd-buy-opt" :class="{ active: buyType === 'balance' }" @click="buyType = 'balance'">
                <span class="cd-buy-opt-label">余额支付</span>
                <span class="cd-buy-opt-price">{{ collection.price_balance }}</span>
              </div>
              <div v-if="collection.price_points > 0" class="cd-buy-opt" :class="{ active: buyType === 'points' }" @click="buyType = 'points'">
                <span class="cd-buy-opt-label">积分支付</span>
                <span class="cd-buy-opt-price">{{ collection.price_points }}</span>
              </div>
            </div>
          </div>
          <button class="cd-btn cd-btn-buy cd-btn-buy-full" @click="handleBuy">确认支付</button>
        </div>
      </div>

      <!-- 阅读进度 -->
      <div v-if="collection && userId && progressPct > 0" class="cd-progress-section">
        <div class="cd-progress-label">阅读进度</div>
        <div class="cd-progress-bar">
          <div class="cd-progress-fill" :style="{ width: progressPct + '%' }"></div>
        </div>
        <div class="cd-progress-text">{{ readPostCount }} / {{ collection.post_count }} 篇 ({{ progressPct }}%)</div>
      </div>

      <!-- 帖子目录 -->
      <div class="cd-toc">
        <div class="cd-toc-header">
          <span class="cd-toc-title">目录 ({{ validPostCount }})</span>
          <span class="cd-toc-progress" v-if="collection.posts && collection.posts.length > 0">{{ validPostCount }}篇</span>
        </div>
        <div class="cd-toc-list">
          <div
            v-for="(post, idx) in collection.posts"
            :key="post.post_id"
            class="cd-toc-item"
            :class="{
              'cd-toc-item-invalid': post.invalid,
              'cd-toc-item-locked': !post.invalid && !collection.isAuthor && !collection.hasPaid && !post.is_preview && collection.is_paid && hasAnyPrice && !isTrial(idx),
              'cd-toc-item-preview': post.is_preview || isTrial(idx)
            }"
            @click="openPost(post)"
          >
            <div class="cd-toc-num">{{ post.sort_order || idx + 1 }}</div>
            <div class="cd-toc-content">
              <div class="cd-toc-post-title">{{ post.invalid ? (post.invalid_reason || '帖子已不可用') : (post.title || '(无标题)') }}</div>
              <div class="cd-toc-post-meta">
                <span>{{ post.view_count || 0 }}阅读</span>
                <span class="cd-toc-meta-sep">|</span>
                <span>{{ post.comment_count || 0 }}评论</span>
                <span class="cd-toc-meta-sep">|</span>
                <span>{{ post.like_count || 0 }}赞</span>
              </div>
            </div>
            <div class="cd-toc-badge" v-if="post.is_preview || isTrial(idx)">试读</div>
            <div class="cd-toc-badge cd-toc-badge-lock" v-else-if="!post.invalid && !collection.isAuthor && !collection.hasPaid && collection.is_paid && hasAnyPrice">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            </div>
            <div class="cd-toc-arrow" v-else>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </div>

          <div v-if="!collection.posts || collection.posts.length === 0" class="cd-toc-empty">
            暂无内容
          </div>
        </div>
      </div>
      </div>

      <!-- 评论 -->
      <div class="cd-comments-section" v-if="collection">
        <div class="cd-comments-header">
          <span class="cd-comments-title">评论 ({{ commentTotal }})</span>
          <span v-if="commentStats" class="cd-comments-stats">均分 {{ commentStats.avgRating?.toFixed(1) || '-' }} / {{ commentStats.totalRatings || 0 }}人评分</span>
        </div>

        <div v-if="userId" class="cd-comment-form">
          <div class="cd-comment-rate">
            <span class="cd-comment-rate-label">评分</span>
            <div class="cd-stars">
              <span v-for="s in 5" :key="s" class="cd-star" :class="{ 'cd-star-active': s <= commentRating }" @click="commentRating = s">&#9733;</span>
            </div>
          </div>
          <textarea v-model="commentContent" class="cd-comment-input" placeholder="写下你的想法..." rows="3"></textarea>
          <button class="cd-comment-submit" :disabled="!commentContent.trim() || submittingComment" @click="submitComment">{{ submittingComment ? '提交中...' : '发表' }}</button>
        </div>
        <div v-else class="cd-comment-login-hint" @click="$router.push('/auth/login')">登录后发表评论</div>

        <div v-if="commentsLoading" class="cd-comments-loading">加载中...</div>
        <div v-else-if="comments.length === 0" class="cd-comments-empty">暂无评论</div>
        <div v-else class="cd-comments-list">
          <div v-for="c in comments" :key="c.id" class="cd-comment-item">
            <div class="cd-comment-avatar" :style="{ background: avatarColor(c.user_name || c.nickname || '') }">
              {{ (c.user_name || c.nickname || '?')[0] }}
            </div>
            <div class="cd-comment-body">
              <div class="cd-comment-top">
                <span class="cd-comment-name">{{ c.user_name || c.nickname }}</span>
                <span class="cd-comment-stars" v-if="c.rating">
                  <span v-for="s in 5" :key="s" :style="{ color: s <= c.rating ? '#f59e0b' : '#d1d5db' }">&#9733;</span>
                </span>
                <span class="cd-comment-time">{{ formatTime(c.create_time) }}</span>
              </div>
              <div class="cd-comment-text">{{ c.content }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCollection, buyCollection } from '@/api/community'
import { useUserStore } from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const collection = ref<any>(null)
const loading = ref(true)
const errorMsg = ref('')
const buyType = ref<'balance' | 'points'>('balance')
const showBuyModal = ref(false)
const isFavorited = ref(false)
const favGroupName = ref('')
const showFavPicker = ref(false)
const favPickerGroups = ref<any[]>([])
const favPickerSelectedId = ref(0)
const showGroupNameDialog = ref(false)
const groupDialogTitle = ref('')
const groupDialogValue = ref('')
const groupDialogInput = ref<HTMLInputElement | null>(null)
let groupDialogCallback: ((v: string) => void) | null = null

const progressPct = ref(0)
const readPostCount = ref(0)
const shareCount = ref(0)

const comments = ref<any[]>([])
const commentTotal = ref(0)
const commentStats = ref<any>(null)
const commentContent = ref('')
const commentRating = ref(5)
const submittingComment = ref(false)
const commentsLoading = ref(false)

const userId = computed(() => Number(userStore.info?.id || 0))

const hasAnyPrice = computed(() => {
  const c = collection.value
  if (!c) return false
  return Number(c.price_balance) > 0 || Number(c.price_points) > 0
})

const revenueBalance = computed(() => {
  const c = collection.value
  if (!c?.subscribers) return 0
  return c.subscribers
    .filter((s: any) => s.pay_type === 'balance')
    .reduce((sum: number, s: any) => sum + (Number(s.amount) || 0), 0)
})

const revenuePoints = computed(() => {
  const c = collection.value
  if (!c?.subscribers) return 0
  return c.subscribers
    .filter((s: any) => s.pay_type === 'points')
    .reduce((sum: number, s: any) => sum + (Number(s.amount) || 0), 0)
})

const revenueTotal = computed(() => revenueBalance.value + revenuePoints.value)

const descExpanded = ref(false)
const descLong = computed(() => (collection.value?.description || '').length > 80)

const validPostCount = computed(() => {
  if (!collection.value?.posts) return 0
  return collection.value.posts.filter((p: any) => !p.invalid).length
})

function isTrial(idx: number) {
  if (!collection.value) return false
  return idx < (collection.value.preview_count || 0)
}

function openPost(post: any) {
  if (post.invalid) return

  if (!collection.value.isAuthor && !collection.value.hasPaid && collection.value.is_paid && hasAnyPrice.value) {
    if (!post.is_preview && !isTrial(collection.value.posts.indexOf(post))) {
      return
    }
  }

  router.push(`/community/post/${post.post_id}`)
}

async function handleBuy() {
  if (!userId.value) {
    router.push('/auth/login')
    return
  }
  try {
    await buyCollection(collection.value.id, buyType.value)
    collection.value.hasPaid = true
    collection.value.subscribe_count = (collection.value.subscribe_count || 0) + 1
    showBuyModal.value = false
  } catch (e: any) {
    alert(e.message || '购买失败')
  }
}

function goManage() {
  router.push(`/community/collection/create?id=${collection.value.id}`)
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

async function loadFavPickerGroups() {
  try {
    const request = (await import('@/utils/http')).default
    const res: any = await request.get({ url: '/api/community/favorite/groups' })
    favPickerGroups.value = res || []
    if (favPickerGroups.value.length > 0) {
      favPickerSelectedId.value = favPickerGroups.value[0].id
    }
  } catch { favPickerGroups.value = [] }
}

async function openGroupNameDialog(title: string, cb: (v: string) => void) {
  groupDialogTitle.value = title
  groupDialogValue.value = ''
  groupDialogCallback = cb
  showGroupNameDialog.value = true
  setTimeout(() => groupDialogInput.value?.focus(), 100)
}

function confirmGroupNameDialog() {
  const val = groupDialogValue.value.trim()
  if (!val) return
  showGroupNameDialog.value = false
  groupDialogCallback?.(val)
}

function createFavGroupFromPicker() {
  openGroupNameDialog('新建收藏分组', async (name) => {
    try {
      const request = (await import('@/utils/http')).default
      const res: any = await request.post({ url: '/api/community/favorite/groups', data: { name } })
      if (res) {
        favPickerGroups.value.push(res)
        favPickerSelectedId.value = res.id
      }
    } catch (e: any) { alert(e.message || '创建失败') }
  })
}

async function confirmFavorite() {
  if (favPickerSelectedId.value <= 0) return alert('请选择分组')
  try {
    const request = (await import('@/utils/http')).default
    await request.post({
      url: `/api/community/collection/${collection.value.id}/favorite`,
      data: { groupId: favPickerSelectedId.value }
    })
    isFavorited.value = true
    const g = favPickerGroups.value.find(x => x.id === favPickerSelectedId.value)
    favGroupName.value = g?.name || ''
    showFavPicker.value = false
  } catch (e: any) { alert(e.message || '收藏失败') }
}

async function unfavoriteCollection() {
  if (!confirm('确定取消收藏？')) return
  try {
    const request = (await import('@/utils/http')).default
    await request.del({ url: `/api/community/collection/${collection.value.id}/favorite` })
    isFavorited.value = false
    favGroupName.value = ''
  } catch (e: any) { alert(e.message || '操作失败') }
}

onMounted(async () => {
  try {
    const id = Number(route.params.id)
    const data: any = await fetchCollection(id)
    if (data && !data.hidden) {
      collection.value = data
      if (Number(data.price_balance) > 0) buyType.value = 'balance'
      else if (Number(data.price_points) > 0) buyType.value = 'points'
    } else if (data && data.hidden) {
      errorMsg.value = '该合集因作者账号异常暂时无法访问'
    } else {
      errorMsg.value = '合集不存在'
    }
    if (userId.value) {
      try {
        const request = (await import('@/utils/http')).default
        const favRes: any = await request.get({ url: `/api/community/collection/${id}/favorite/check` })
        isFavorited.value = !!favRes?.favorited
        favGroupName.value = favRes?.groupName || ''
      } catch {}
      try {
        const request = (await import('@/utils/http')).default
        const progRes: any = await request.get({ url: `/api/community/collection/${id}/progress` })
        if (progRes) {
          progressPct.value = progRes.progress_pct || 0
          readPostCount.value = progRes.read_post_count || 0
        }
      } catch {}
    }
    try {
      const request = (await import('@/utils/http')).default
      const shareRes: any = await request.get({ url: `/api/community/collection/${id}/share-stats` })
      shareCount.value = shareRes?.share_count || 0
    } catch {}
    loadComments(id)
  } catch (e: any) {
    errorMsg.value = '加载失败'
  } finally {
    loading.value = false
  }
})

function formatTime(t: string): string {
  if (!t) return ''
  const d = new Date(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
  return d.toLocaleDateString()
}

async function handleCollectionShare() {
  const cid = Number(route.params.id)
  const url = window.location.href
  try {
    const request = (await import('@/utils/http')).default
    await request.post({ url: `/api/community/collection/${cid}/share` })
    shareCount.value++
  } catch {}
  if (navigator.share) {
    navigator.share({ title: collection.value?.title || '合集', url })
  } else {
    navigator.clipboard.writeText(url).then(() => {}).catch(() => {})
  }
}

async function loadComments(cid: number) {
  commentsLoading.value = true
  try {
    const request = (await import('@/utils/http')).default
    const res: any = await request.get({ url: `/api/community/collection/${cid}/comments` })
    comments.value = res?.list || res || []
    commentTotal.value = res?.total || comments.value.length
  } catch {} finally {
    commentsLoading.value = false
  }
  try {
    const request = (await import('@/utils/http')).default
    const stats: any = await request.get({ url: `/api/community/collection/${cid}/rating` })
    commentStats.value = stats
  } catch {}
}

async function submitComment() {
  const cid = Number(route.params.id)
  if (!commentContent.value.trim()) return
  submittingComment.value = true
  try {
    const request = (await import('@/utils/http')).default
    await request.post({ url: `/api/community/collection/${cid}/comment`, data: { content: commentContent.value, rating: commentRating.value } })
    commentContent.value = ''
    commentRating.value = 5
    await loadComments(cid)
  } catch {} finally {
    submittingComment.value = false
  }
}
</script>

<style scoped>
.collection-detail-page {
  min-height: 100vh;
  background: #f5f6fa;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}
.cd-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
}
.cd-nav-back {
  background: none;
  border: none;
  padding: 4px;
  color: #333;
  cursor: pointer;
  display: flex;
  align-items: center;
}
.cd-nav-title { font-size: 16px; font-weight: 600; color: #1a1a2e; }
.cd-nav-right { width: 30px; }

.cd-loading { text-align: center; padding: 60px 0; color: #999; font-size: 14px; }
.cd-empty {
  display: flex; flex-direction: column; align-items: center; padding: 80px 20px;
}
.cd-empty-icon { font-size: 48px; margin-bottom: 12px; }
.cd-empty-text { font-size: 15px; color: #666; margin-bottom: 20px; }
.cd-empty-btn {
  background: #6366f1; color: #fff; border: none; padding: 10px 32px;
  border-radius: 20px; font-size: 14px; cursor: pointer;
}

.cd-body { padding-bottom: 40px; }

/* ===== COVER SECTION ===== */
.cd-cover-section {
  margin: 12px 16px;
  padding: 20px;
  background: linear-gradient(145deg, #1e1b4b, #312e81);
  border-radius: 16px;
  display: flex;
  gap: 16px;
}
.cd-cover-img-wrap {
  width: 90px; height: 120px;
  border-radius: 10px;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(0,0,0,.25);
}
.cd-cover-img {
  width: 100%; height: 100%; object-fit: cover;
}
.cd-cover-placeholder {
  width: 100%; height: 100%;
  background: linear-gradient(135deg, rgba(99,102,241,.4), rgba(139,92,246,.4));
  display: flex; align-items: center; justify-content: center;
}
.cd-cover-info { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; }
.cd-title {
  font-size: 18px; font-weight: 700; color: #fff;
  margin: 0 0 8px; line-height: 1.35;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.cd-meta {
  display: flex; align-items: center; gap: 4px;
  font-size: 12px; color: rgba(255,255,255,.65); margin-bottom: 10px; flex-wrap: wrap;
}
.cd-meta-sep { opacity: .5; }
.cd-status-finished {
  font-size: 10px; padding: 1px 6px; border-radius: 4px;
  background: rgba(255,255,255,.15); color: #a5b4fc;
}
.cd-status-serializing {
  font-size: 10px; padding: 1px 6px; border-radius: 4px;
  background: rgba(52,211,153,.2); color: #6ee7b7;
}
.cd-price-row { display: flex; gap: 6px; flex-wrap: wrap; }
.cd-price-tag {
  font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 20px;
}
.cd-price-tag-balance { background: rgba(251,191,36,.2); color: #fbbf24; }
.cd-price-tag-points { background: rgba(244,114,182,.2); color: #f472b6; }
.cd-price-tag-free { background: rgba(52,211,153,.2); color: #6ee7b7; }

/* ===== DESCRIPTION ===== */
.cd-desc {
  margin: 0 16px 12px;
  padding: 12px 14px;
  background: #fff;
  border-radius: 12px;
  position: relative;
}
.cd-desc-label {
  font-size: 11px; color: #a78bfa; font-weight: 600;
  margin-right: 8px; vertical-align: middle;
}
.cd-desc-text {
  font-size: 13px; color: #64748b; line-height: 1.55; vertical-align: middle;
}
.cd-desc:not(.cd-desc-expanded) .cd-desc-text {
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.cd-desc-toggle {
  display: block; text-align: right; font-size: 11px; color: #a78bfa;
  cursor: pointer; margin-top: 6px;
}
.cd-desc:not(.cd-desc-long) .cd-desc-toggle { display: none; }

/* ===== ACTIONS / BUY ===== */
.cd-actions { padding: 0 16px 12px; }
.cd-btn {
  width: 100%; padding: 14px; border-radius: 10px; font-size: 16px;
  font-weight: 600; border: none; cursor: pointer;
}
.cd-btn-buy { background: linear-gradient(135deg, #f56c6c, #e74c3c); color: #fff; }
.cd-btn-manage { background: #6366f1; color: #fff; }
.cd-btn-login { background: #6366f1; color: #fff; }

/* ===== BUY MODAL ===== */
.cd-modal-mask {
  position: fixed; inset: 0; background: rgba(0,0,0,.45);
  display: flex; align-items: flex-end; z-index: 1000;
}
.cd-modal {
  width: 100%; background: #fff; border-radius: 20px 20px 0 0;
  padding: 20px 20px 32px; animation: slideUp .25s ease;
}
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.cd-modal-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px;
}
.cd-modal-title { font-size: 17px; font-weight: 700; color: #1e293b; }
.cd-modal-close {
  width: 32px; height: 32px; border-radius: 50%; border: none;
  background: #f1f5f9; font-size: 18px; color: #64748b; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.cd-modal-desc {
  font-size: 13px; color: #94a3b8; margin-bottom: 20px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.cd-modal-section { margin-bottom: 20px; }
.cd-modal-section-label {
  font-size: 14px; font-weight: 600; color: #475569; margin-bottom: 10px;
}
.cd-buy-options { display: flex; gap: 10px; }
.cd-buy-opt {
  flex: 1; padding: 14px; border-radius: 12px; border: 2px solid #f1f5f9;
  text-align: center; cursor: pointer; transition: all .2s; background: #fafbfc;
}
.cd-buy-opt.active { border-color: #6366f1; background: #eef2ff; }
.cd-buy-opt-label { display: block; font-size: 12px; color: #94a3b8; margin-bottom: 2px; }
.cd-buy-opt-price { display: block; font-size: 18px; font-weight: 700; color: #1e293b; }
.cd-buy-opt.active .cd-buy-opt-label { color: #6366f1; }
.cd-buy-opt.active .cd-buy-opt-price { color: #4f46e5; }
.cd-btn-buy-full { margin-top: 0; }
.cd-owned-badge {
  text-align: center; padding: 12px; font-size: 14px; font-weight: 600;
  color: #6366f1; background: #eef2ff; border-radius: 10px;
}

.cd-toc {
  margin: 0 16px;
  background: #fff;
  border-radius: 10px;
  overflow: hidden;
}
.cd-toc-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
  border-bottom: 1px solid #f0f0f0;
}
.cd-toc-title { font-size: 16px; font-weight: 600; color: #1a1a2e; }
.cd-toc-progress { font-size: 13px; color: #909399; }

.cd-toc-item {
  display: flex;
  align-items: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;
  cursor: pointer;
  gap: 12px;
  transition: background .15s;
}
.cd-toc-item:active { background: #f5f7fa; }
.cd-toc-item-invalid { opacity: 0.45; cursor: not-allowed; }
.cd-toc-num {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #f0f2f5;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 600;
  color: #909399;
  flex-shrink: 0;
}
.cd-toc-item-preview .cd-toc-num { background: #e6f7ff; color: #1890ff; }
.cd-toc-content { flex: 1; min-width: 0; }
.cd-toc-post-title {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-bottom: 4px;
}
.cd-toc-post-meta { font-size: 12px; color: #c0c4cc; }
.cd-toc-meta-sep { margin: 0 4px; }
.cd-toc-badge {
  font-size: 11px;
  color: #1890ff;
  background: #e6f7ff;
  padding: 2px 8px;
  border-radius: 10px;
  flex-shrink: 0;
}
.cd-toc-badge-lock {
  background: #fff7e6;
  color: #fa8c16;
  display: flex;
  align-items: center;
  gap: 2px;
}
.cd-toc-arrow { flex-shrink: 0; display: flex; align-items: center; }
.cd-toc-empty { text-align: center; padding: 40px; color: #c0c4cc; font-size: 14px; }

.cd-nav-fav {
  background: none; border: 1px solid #c0c4cc; padding: 4px 12px;
  border-radius: 14px; font-size: 12px; color: #666; cursor: pointer;
}
.cd-nav-fav-active { border-color: #f56c6c; color: #f56c6c; background: #fef0f0; }
.cd-nav-fav-manage { border-color: #6366f1; color: #6366f1; background: #eef2ff; }

.cd-revenue-card {
  margin: 0 16px 12px; padding: 12px 14px;
  background: #fff; border-radius: 12px;
}
.cd-revenue-header {
  display: flex; align-items: center; gap: 6px;
  font-size: 14px; font-weight: 600; color: #1a1a2e; margin-bottom: 10px;
}
.cd-revenue-header svg { color: #f59e0b; }
.cd-revenue-body { display: flex; gap: 12px; }
.cd-revenue-item {
  flex: 1; text-align: center;
  padding: 8px; background: #f9fafb; border-radius: 8px;
}
.cd-revenue-label { display: block; font-size: 11px; color: #999; margin-bottom: 2px; }
.cd-revenue-value { font-size: 14px; font-weight: 600; color: #1a1a2e; }

.cd-subscribers {
  margin: 0 16px 12px; padding: 12px 14px;
  background: #fff; border-radius: 12px;
}
.cd-subscribers-header {
  font-size: 14px; font-weight: 600; color: #1a1a2e; margin-bottom: 10px;
}
.cd-subscribers-list { display: flex; flex-wrap: wrap; gap: 8px; }
.cd-subscriber-item { display: flex; align-items: center; gap: 4px; }
.cd-subscriber-avatar {
  width: 26px; height: 26px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 11px; font-weight: 600;
}
.cd-subscriber-name { font-size: 12px; color: #666; }

.cd-fav-group-item {
  padding: 10px 14px; border-radius: 8px; margin-bottom: 4px;
  cursor: pointer; display: flex; align-items: center; justify-content: space-between;
  background: #f9fafb; transition: all .15s;
}
.cd-fav-group-item.active { background: #fce7f3; border: 1px solid #EC4899; }

/* ===== SHARE BUTTON ===== */
.cd-nav-share {
  background: none; border: none; padding: 4px; cursor: pointer;
  color: #6366f1; display: flex; align-items: center;
  margin-left: 8px;
}

/* ===== PROGRESS SECTION ===== */
.cd-progress-section {
  margin: 0 16px 12px; padding: 14px;
  background: #fff; border-radius: 12px;
}
.cd-progress-label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 8px; }
.cd-progress-bar {
  height: 6px; background: #e2e8f0; border-radius: 3px; overflow: hidden; margin-bottom: 6px;
}
.cd-progress-fill {
  height: 100%; background: linear-gradient(90deg, #6366f1, #a78bfa);
  border-radius: 3px; transition: width .3s ease;
}
.cd-progress-text { font-size: 12px; color: #94a3b8; text-align: right; }

/* ===== COMMENTS SECTION ===== */
.cd-comments-section {
  margin: 12px 16px 100px; background: #fff; border-radius: 12px; padding: 16px;
}
.cd-comments-header {
  display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;
}
.cd-comments-title { font-size: 16px; font-weight: 600; color: #1a1a2e; }
.cd-comments-stats { font-size: 12px; color: #a78bfa; }
.cd-comment-form { margin-bottom: 16px; }
.cd-comment-rate { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.cd-comment-rate-label { font-size: 13px; color: #64748b; }
.cd-stars { display: flex; gap: 2px; }
.cd-star {
  font-size: 20px; color: #d1d5db; cursor: pointer; transition: color .15s;
}
.cd-star-active { color: #f59e0b; }
.cd-comment-input {
  width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 12px;
  font-size: 13px; color: #475569; resize: vertical; outline: none; box-sizing: border-box;
}
.cd-comment-input:focus { border-color: #6366f1; }
.cd-comment-submit {
  margin-top: 8px; padding: 8px 20px; border-radius: 8px; border: none;
  background: #6366f1; color: #fff; font-size: 13px; font-weight: 600; cursor: pointer;
}
.cd-comment-submit:disabled { background: #c7d2fe; cursor: not-allowed; }
.cd-comment-login-hint {
  text-align: center; padding: 16px; font-size: 13px; color: #6366f1; cursor: pointer;
}
.cd-comments-loading { text-align: center; padding: 20px; color: #999; font-size: 13px; }
.cd-comments-empty { text-align: center; padding: 24px; color: #c0c4cc; font-size: 13px; }
.cd-comments-list { display: flex; flex-direction: column; gap: 14px; }
.cd-comment-item { display: flex; gap: 10px; }
.cd-comment-avatar {
  width: 32px; height: 32px; border-radius: 50%; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 13px; font-weight: 600;
}
.cd-comment-body { flex: 1; min-width: 0; }
.cd-comment-top { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-bottom: 4px; }
.cd-comment-name { font-size: 13px; font-weight: 600; color: #334155; }
.cd-comment-stars { font-size: 12px; }
.cd-comment-time { font-size: 11px; color: #94a3b8; margin-left: auto; }
.cd-comment-text { font-size: 13px; color: #475569; line-height: 1.55; word-break: break-word; }
</style>
