<template>
  <div class="scheduled-posts-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">定时帖子</span>
      <div style="width:22px" />
    </div>

    <div class="page-content">
      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadScheduledPosts" />
      <EmptyState v-else-if="!posts.length" text="暂无定时发布的帖子">
        <template #icon>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </template>
      </EmptyState>
      <div v-else class="post-list">
        <div v-for="p in posts" :key="'sp'+p.id" class="pcard">
          <div class="pcard-top">
            <div class="ptitle">{{ p.title || '无标题' }}</div>
            <div class="pstatus" :class="p.status === 'scheduled' ? 'status-scheduled' : 'status-other'">
              {{ statusLabel(p.status) }}
            </div>
          </div>
          <div class="pcontent" v-if="p.summary">{{ p.summary }}</div>
          <div class="pmeta">
            <span class="pmeta-time">{{ formatTime(p.scheduledTime || p.createTime) }}</span>
            <span class="pmeta-section" v-if="p.sectionName">{{ p.sectionName }}</span>
          </div>
          <div class="pcard-actions">
            <button class="paction-btn paction-preview" @click.stop="goPreview(p.id)">预览</button>
            <button class="paction-btn paction-edit" @click.stop="goEdit(p.id)">编辑</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)
const error = ref('')
const posts = ref([])

const statusLabel = (s) => {
  if (s === 'scheduled') return '定时中'
  return s
}

const formatTime = (t) => {
  if (!t) return ''
  const d = new Date(t)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

const loadScheduledPosts = async () => {
  loading.value = true
  error.value = ''
  try {
    const uid = userStore.info?.userId
    if (!uid) { error.value = '请先登录'; loading.value = false; return }
    const res = await request.get({ url: `/api/community/posts?userId=${uid}&status=scheduled&pageSize=50` })
    if (res && res.list) {
      posts.value = res.list.map(p => ({
        ...p,
        summary: getSummary(p.content)
      }))
    } else if (res && Array.isArray(res)) {
      posts.value = res.map(p => ({
        ...p,
        summary: getSummary(p.content)
      }))
    } else {
      posts.value = []
    }
  } catch (e) {
    error.value = '加载失败，请稍后重试'
  }
  loading.value = false
}

const getSummary = (content) => {
  if (!content) return ''
  try {
    const raw = typeof content === 'string' ? content : JSON.stringify(content)
    const trimmed = raw.trim()
    if (!trimmed) return ''

    if (trimmed.startsWith('[')) {
      const blocks = JSON.parse(trimmed)
      for (const b of blocks) {
        if (b.type === 'text' && b.value) {
          const t = String(b.value).replace(/<[^>]*>/g, '').trim()
          if (t) return t.length > 120 ? t.slice(0, 120) + '...' : t
        }
      }
    }

    if (trimmed.startsWith('{"type":"doc"')) {
      const doc = JSON.parse(trimmed)
      const texts = []
      const walk = (node) => {
        if (!node) return
        if (node.text) texts.push(String(node.text))
        if (node.content && Array.isArray(node.content)) {
          node.content.forEach(walk)
        }
      }
      walk(doc)
      const t = texts.join('').replace(/<[^>]*>/g, '').trim()
      if (t) return t.length > 120 ? t.slice(0, 120) + '...' : t
    }

    const t = raw.replace(/<[^>]*>/g, '').trim()
    return t.length > 120 ? t.slice(0, 120) + '...' : t
  } catch {
    const t = String(content).replace(/<[^>]*>/g, '').trim()
    return t.length > 120 ? t.slice(0, 120) + '...' : t
  }
}

const goEdit = (id) => {
  router.push(`/p/edit/${btoa(String(id))}`)
}

const goPreview = (id) => {
  router.push(`/community/post/${id}`)
}

onMounted(() => {
  loadScheduledPosts()
})
</script>

<style scoped>
.scheduled-posts-page { min-height: 100vh; background: #f5f5f5; }
.page-navbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #fff; position: sticky; top: 0; z-index: 10; }
.nav-back { border: none; background: none; padding: 4px; cursor: pointer; display: flex; align-items: center; color: #333; }
.nav-title { font-size: 17px; font-weight: 600; color: #1f2937; }
.page-content { padding: 12px 16px; padding-bottom: 80px; }
.load-wrap { display: flex; justify-content: center; padding: 40px 0; }
.spin { width: 28px; height: 28px; border: 3px solid #e5e7eb; border-top-color: #508DFF; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.err-wrap { text-align: center; padding: 40px 0; }
.err-text { color: #ef4444; margin-bottom: 12px; }
.empty-wrap { text-align: center; padding: 60px 0; color: #9ca3af; }
.empty-text { color: #9ca3af; font-size: 14px; }
.btn { display: inline-block; padding: 8px 20px; border-radius: 8px; font-size: 14px; cursor: pointer; border: none; }
.btn-primary { background: #508DFF; color: #fff; }

.pcard { background: #fff; border-radius: 12px; padding: 14px 16px; margin-bottom: 10px; }
.pcard:active { background: #f9fafb; }
.pcard-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
.ptitle { font-size: 15px; font-weight: 600; color: #1f2937; flex: 1; line-height: 1.4; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.pstatus { font-size: 11px; padding: 2px 8px; border-radius: 4px; white-space: nowrap; flex-shrink: 0; }
.status-scheduled { background: #fef3c7; color: #d97706; }
.status-other { background: #f3f4f6; color: #6b7280; }
.pcontent { font-size: 13px; color: #6b7280; margin-top: 8px; line-height: 1.5; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; }
.pmeta { display: flex; align-items: center; gap: 10px; margin-top: 10px; font-size: 12px; color: #9ca3af; }
.pmeta-section { background: #f3f4f6; padding: 1px 6px; border-radius: 4px; }
.pcard-actions { display: flex; gap: 8px; margin-top: 10px; padding-top: 10px; border-top: 1px solid #f0f0f0; }
.paction-btn { flex: 1; padding: 7px 0; border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer; border: none; }
.paction-preview { background: #eff6ff; color: #3b82f6; }
.paction-edit { background: #f3f4f6; color: #6b7280; }
</style>
