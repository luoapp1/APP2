<template>
  <div class="blocklist-page">
    <div class="blocklist-navbar">
      <button class="blocklist-back" @click="$router.push('/appstore/settings')">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="blocklist-title">黑名单</span>
      <div class="blocklist-placeholder" />
    </div>

    <div class="blocklist-content" v-if="list.length > 0">
      <div v-for="item in list" :key="item.id" class="block-item">
        <img :src="$fixImgUrl(item.blockedAvatar)" class="block-avatar" @error="(e: any) => e.target.src='data:image/svg+xml,<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; viewBox=&quot;0 0 40 40&quot;><rect fill=&quot;%23E0E0E0&quot; width=&quot;40&quot; height=&quot;40&quot; rx=&quot;20&quot;/></svg>'" />
        <div class="block-info" @click="goProfile(item.blockedId)">
          <div class="block-name">{{ item.blockedNickname || item.blockedUsername }}</div>
          <div class="block-time">{{ formatTime(item.createTime) }}</div>
        </div>
        <button class="unblock-btn" @click="unblock(item)">解除</button>
      </div>
    </div>

    <div class="blocklist-empty" v-else-if="!loading">
      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#C0C4CC" stroke-width="1.5" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
      <p>暂无拉黑用户</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const list = ref<any[]>([])
const loading = ref(false)

async function loadList() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/user/blocked' })
    list.value = res.data?.list || res.list || []
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

async function unblock(item: any) {
  try {
    await request.delete({ url: `/api/user/${item.blockedId}/block` })
    list.value = list.value.filter((u: any) => u.blockedId !== item.blockedId)
    ElMessage.success('已解除拉黑')
  } catch (e) {
    ElMessage.error('操作失败')
  }
}

function goProfile(userId: number) {
  router.push(`/u/${userId}`)
}

function formatTime(ts: string): string {
  if (!ts) return ''
  const d = new Date(ts)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 86400000) return '今天'
  if (diff < 172800000) return '昨天'
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

onMounted(loadList)
</script>

<style scoped>
.blocklist-page { min-height: 100vh; background: #F5F6FA; }
.blocklist-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.blocklist-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.blocklist-back:active { background: #f0f0f0; }
.blocklist-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.blocklist-placeholder { width: 22px; }
.blocklist-content { padding: 12px 16px; display: flex; flex-direction: column; gap: 8px; }
.block-item { display: flex; align-items: center; gap: 12px; background: #fff; border-radius: 12px; padding: 14px 16px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.block-avatar { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; flex-shrink: 0; }
.block-info { flex: 1; cursor: pointer; display: flex; flex-direction: column; gap: 2px; }
.block-name { font-size: 15px; font-weight: 500; color: #1a1a1a; }
.block-time { font-size: 12px; color: #999; }
.unblock-btn { padding: 6px 14px; border: 1px solid #f44336; border-radius: 16px; background: transparent; color: #f44336; font-size: 13px; cursor: pointer; }
.unblock-btn:active { background: rgba(244,67,54,.1); }
.blocklist-empty { display: flex; flex-direction: column; align-items: center; padding: 80px 0; gap: 16px; }
.blocklist-empty p { font-size: 14px; color: #999; margin: 0; }
</style>
