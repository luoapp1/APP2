<template>
  <div class="dashboard-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5m7-7l-7 7 7 7"/></svg>
      </button>
      <h2>数据统计</h2>
      <div class="header-spacer"></div>
    </div>

    <div class="content">
      <!-- 概览横幅 -->
      <div class="overview-banner">
        <div class="banner-greeting">数据概览</div>
        <div class="banner-sub">掌握你的创作与收益趋势</div>
      </div>

      <!-- 时间周期选择 -->
      <div class="period-tabs">
        <button
          v-for="p in periods"
          :key="p.value"
          :class="{ active: activePeriod === p.value }"
          @click="switchPeriod(p.value)"
        >
          {{ p.label }}
        </button>
      </div>

      <!-- 统计卡片 -->
      <div class="stats-grid">
        <div class="stat-card card-posts">
          <div class="card-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </div>
          <div class="card-info">
            <span class="card-label">发布帖子</span>
            <span class="card-value">{{ stats.posts ?? '--' }}</span>
            <span class="card-unit">篇</span>
          </div>
        </div>

        <div class="stat-card card-followers">
          <div class="card-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
              <circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </div>
          <div class="card-info">
            <span class="card-label">新增粉丝</span>
            <span class="card-value">{{ stats.followers ?? '--' }}</span>
            <span class="card-unit">人</span>
          </div>
        </div>

        <div class="stat-card card-earnings">
          <div class="card-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="12" y1="1" x2="12" y2="23"/>
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>
          </div>
          <div class="card-info">
            <span class="card-label">收益</span>
            <span class="card-value">{{ formatEarnings(stats.earnings) }}</span>
            <span class="card-unit">元</span>
          </div>
        </div>
      </div>

      <!-- 详细指标 -->
      <div class="metrics-grid" v-if="stats.views != null || stats.likes != null">
        <div class="metric-item">
          <span class="metric-num">{{ stats.views ?? 0 }}</span>
          <span class="metric-label">浏览量</span>
        </div>
        <div class="metric-item">
          <span class="metric-num">{{ stats.likes ?? 0 }}</span>
          <span class="metric-label">获赞</span>
        </div>
        <div class="metric-item">
          <span class="metric-num">{{ stats.comments ?? 0 }}</span>
          <span class="metric-label">评论</span>
        </div>
        <div class="metric-item">
          <span class="metric-num">{{ stats.shares ?? 0 }}</span>
          <span class="metric-label">分享</span>
        </div>
      </div>

      <!-- 趋势图表 -->
      <div class="trend-section" v-if="trends.length > 0">
        <div class="trend-header">
          <span class="trend-title">趋势变化</span>
          <span class="trend-subtitle">最近 {{ activePeriod }} 天</span>
        </div>
        <div class="trend-chart">
          <div class="chart-bars">
            <div
              class="chart-bar-wrapper"
              v-for="(t, idx) in trends"
              :key="idx"
              :style="{ animationDelay: `${idx * 40}ms` }"
            >
              <div
                class="chart-bar"
                :style="{ height: getBarHeight(t.value) }"
              >
                <span class="bar-tooltip">{{ t.value }}</span>
              </div>
              <span class="bar-label">{{ formatDateLabel(t.date) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 趋势列表 -->
      <div class="trend-list-section" v-if="trends.length > 0">
        <div class="trend-list">
          <div class="trend-item" v-for="t in trends" :key="t.date">
            <div class="trend-dot" :style="{ background: getTrendColor(t.value) }"></div>
            <span class="trend-date">{{ t.date }}</span>
            <div class="trend-bar-track">
              <div class="trend-bar-fill" :style="{ width: getTrendPercent(t.value) + '%', background: getTrendColor(t.value) }"></div>
            </div>
            <span class="trend-value">{{ t.value }}</span>
          </div>
        </div>
      </div>

      <div class="empty-state" v-if="!loading && trends.length === 0 && stats.posts == null">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <p>暂无统计数据</p>
        <span>去发布内容，积累你的数据吧</span>
      </div>

      <div class="loading-state" v-if="loading">
        <div class="loading-ring"></div>
        <p>加载中...</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const activePeriod = ref(30)
const periods = [
  { label: '7天', value: 7 },
  { label: '15天', value: 15 },
  { label: '30天', value: 30 },
  { label: '90天', value: 90 }
]
const stats = ref({})
const trends = ref([])
const loading = ref(true)

onMounted(() => fetchData())

async function fetchData() {
  loading.value = true
  try {
    const res = await request.get({ url: `/api/user/dashboard/stats?period=${activePeriod.value}` })
    stats.value = res?.stats || {}
    trends.value = res?.trends || []
  } catch {
    stats.value = {}
    trends.value = []
  }
  loading.value = false
}

function switchPeriod(period) {
  activePeriod.value = period
  fetchData()
}

function formatEarnings(val) {
  if (val == null) return '--'
  const n = Number(val)
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return n.toFixed(2)
}

function formatDateLabel(dateStr) {
  if (!dateStr) return ''
  const parts = dateStr.split('-')
  return parts.length >= 2 ? `${parts[1]}/${parts[2]}` : dateStr
}

function getBarHeight(val) {
  if (!trends.value.length) return '0%'
  const max = Math.max(...trends.value.map(t => t.value || 0), 1)
  const pct = ((val || 0) / max) * 100
  return Math.max(pct, 4) + '%'
}

function getTrendPercent(val) {
  if (!trends.value.length) return 0
  const max = Math.max(...trends.value.map(t => t.value || 0), 1)
  return ((val || 0) / max) * 100
}

function getTrendColor(val) {
  if (!trends.value.length) return '#ddd'
  const max = Math.max(...trends.value.map(t => t.value || 0), 1)
  const ratio = (val || 0) / max
  if (ratio >= 0.8) return '#FF5722'
  if (ratio >= 0.5) return '#FF9800'
  return '#2196F3'
}
</script>

<style scoped>
.dashboard-page {
  min-height: 100vh;
  background: linear-gradient(180deg, #f0f4ff 0%, #f5f5f5 30%);
}

/* 头部导航 */
.header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  background: #fff;
  border-bottom: 1px solid #eee;
  position: sticky;
  top: 0;
  z-index: 10;
}
.header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 700;
  color: #1a1a1a;
  flex: 1;
  text-align: center;
}
.header-spacer { width: 36px; }
.back-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  background: #f5f5f5;
  border: none;
  border-radius: 10px;
  color: #333;
  cursor: pointer;
  transition: all 0.2s;
}
.back-btn:active { background: #e8e8e8; transform: scale(0.95); }

/* 概览横幅 */
.overview-banner {
  background: linear-gradient(135deg, #FF5722 0%, #FF8A65 100%);
  border-radius: 14px;
  padding: 20px;
  margin-bottom: 18px;
  color: #fff;
  box-shadow: 0 4px 15px rgba(255, 87, 34, 0.3);
}
.banner-greeting {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
}
.banner-sub {
  font-size: 13px;
  opacity: 0.85;
}

/* 内容区 */
.content { padding: 12px 16px 60px; }

/* 时间周期 */
.period-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 18px;
  background: #fff;
  border-radius: 10px;
  padding: 4px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}
.period-tabs button {
  flex: 1;
  padding: 10px 0;
  border: none;
  border-radius: 8px;
  background: transparent;
  font-size: 14px;
  font-weight: 500;
  color: #999;
  cursor: pointer;
  transition: all 0.25s;
}
.period-tabs button.active {
  background: #FF5722;
  color: #fff;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(255, 87, 34, 0.3);
}

/* 统计卡片 */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-bottom: 18px;
}
.stat-card {
  background: #fff;
  border-radius: 14px;
  padding: 14px 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.06);
  transition: transform 0.2s;
}
.stat-card:active { transform: scale(0.97); }
.card-icon {
  width: 32px;
  height: 32px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 8px;
}
.card-posts .card-icon { background: linear-gradient(135deg, #e3f2fd, #bbdefb); color: #1565C0; }
.card-followers .card-icon { background: linear-gradient(135deg, #e8f5e9, #c8e6c9); color: #2E7D32; }
.card-earnings .card-icon { background: linear-gradient(135deg, #fff3e0, #ffe0b2); color: #E65100; }
.card-info {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.card-label {
  font-size: 11px;
  color: #999;
  margin-bottom: 2px;
}
.card-value {
  font-size: 20px;
  font-weight: 800;
  color: #1a1a1a;
  line-height: 1.2;
}
.card-unit {
  font-size: 10px;
  color: #bbb;
  margin-top: 1px;
}

/* 详细指标 */
.metrics-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  margin-bottom: 18px;
  background: #fff;
  border-radius: 14px;
  padding: 16px 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.06);
}
.metric-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
}
.metric-item:not(:last-child)::after {
  content: '';
  position: absolute;
  right: 0;
  top: 20%;
  height: 60%;
  width: 1px;
  background: #f0f0f0;
}
.metric-num {
  font-size: 18px;
  font-weight: 700;
  color: #333;
  margin-bottom: 4px;
}
.metric-label {
  font-size: 11px;
  color: #999;
}

/* 趋势图表 */
.trend-section {
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.06);
  overflow: hidden;
  margin-bottom: 16px;
}
.trend-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding: 16px 16px 8px;
}
.trend-title {
  font-size: 16px;
  font-weight: 700;
  color: #1a1a1a;
}
.trend-subtitle {
  font-size: 12px;
  color: #bbb;
}
.trend-chart {
  padding: 0 16px 12px;
}
.chart-bars {
  display: flex;
  align-items: flex-end;
  gap: 4px;
  height: 120px;
}
.chart-bar-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  justify-content: flex-end;
  gap: 4px;
}
.chart-bar {
  width: 100%;
  max-width: 24px;
  background: linear-gradient(180deg, #FF5722 0%, #FF8A65 100%);
  border-radius: 6px 6px 2px 2px;
  min-height: 4px;
  transition: height 0.6s cubic-bezier(0.25, 0.8, 0.25, 1.2);
  position: relative;
  cursor: pointer;
  animation: barRise 0.5s cubic-bezier(0.25, 0.8, 0.25, 1.2) both;
}
.chart-bar:hover,.chart-bar:active { opacity: 0.8; }
.bar-tooltip {
  position: absolute;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 10px;
  color: #FF5722;
  font-weight: 600;
  white-space: nowrap;
  opacity: 0;
  transition: opacity 0.2s;
}
.chart-bar:hover .bar-tooltip,
.chart-bar:active .bar-tooltip { opacity: 1; }
.bar-label {
  font-size: 10px;
  color: #bbb;
  margin-top: 4px;
  white-space: nowrap;
}

@keyframes barRise {
  from { height: 0; opacity: 0; }
  to { opacity: 1; }
}

/* 趋势列表 */
.trend-list-section {
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.06);
  overflow: hidden;
  margin-bottom: 24px;
}
.trend-list { padding: 4px 0; }
.trend-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  transition: background 0.2s;
}
.trend-item:active { background: #fafafa; }
.trend-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.trend-date {
  font-size: 13px;
  color: #666;
  width: 75px;
  flex-shrink: 0;
}
.trend-bar-track {
  flex: 1;
  height: 6px;
  background: #f0f0f0;
  border-radius: 3px;
  overflow: hidden;
}
.trend-bar-fill {
  height: 100%;
  border-radius: 3px;
  transition: width 0.6s ease;
}
.trend-value {
  font-size: 13px;
  color: #333;
  font-weight: 600;
  min-width: 36px;
  text-align: right;
}

/* 空状态 */
.empty-state {
  text-align: center;
  padding: 50px 0;
  color: #bbb;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}
.empty-state p {
  font-size: 15px;
  color: #999;
  margin: 0;
}
.empty-state span {
  font-size: 12px;
  color: #ccc;
}

/* 加载状态 */
.loading-state {
  text-align: center;
  padding: 50px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.loading-ring {
  width: 32px;
  height: 32px;
  border: 3px solid #f0f0f0;
  border-top-color: #FF5722;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
.loading-state p {
  font-size: 14px;
  color: #999;
  margin: 0;
}
</style>
