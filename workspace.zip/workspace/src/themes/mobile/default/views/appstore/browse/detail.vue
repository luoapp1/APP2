<template>
  <div class="app-detail-page min-h-screen relative" style="background: var(--app-page-bg);">
    <!-- 顶部导航 -->
    <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
      <div class="flex items-center gap-3">
        <a href="/#/appstore/browse" class="flex items-center">
          <svg class="w-6 h-6 text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
          </svg>
        </a>
        <span class="text-base font-semibold text-gray-900">{{ app?.name || '加载中...' }}-{{ displayApp?.version || '' }}</span>
      </div>
      <div class="flex items-center gap-4">
        <svg class="w-5 h-5 text-gray-700 cursor-pointer hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="handleAppShare">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v13"/>
        </svg>
        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <div ref="menuRef" class="relative" @click.stop="toggleMenu">
          <svg class="w-5 h-5 text-gray-700 cursor-pointer hover:text-gray-900 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <circle cx="12" cy="6" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="18" r="2"/>
          </svg>
        </div>
      </div>

      <AppActionMenu
        v-model="showMenu"
        :app-id="Number(route.params.id)"
        :app="app"
        :is-owner="isOwner"
        :is-admin="isAdminUser"
        :is-login="isLogin"
        :menu-style="menuStyle"
        :is-app-favorited="isAppFavorited"
        :fav-groups="favGroups"
        :fav-groups-loading="favGroupsLoading"
        @toast="showToast"
        @app-deleted="handleAppDeleted"
        @app-updated="loadDetail"
        @favorite-toggled="onFavoriteToggled"
      />
    </div>

    <!-- 应用不存在提示 -->
    <div v-if="!loading && !app" class="flex flex-col items-center justify-center py-20 text-gray-400">
      <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.5"/><path stroke-linecap="round" stroke-width="1.5" d="M12 8v4m0 4h.01"/></svg>
      <p class="text-base">应用不存在或已下架</p>
      <a href="/#/appstore/browse" class="mt-4 px-6 py-2 bg-blue-500 text-white rounded-full text-sm">返回应用商店</a>
    </div>

    <div v-else class="overflow-y-auto" style="height: calc(100vh - 140px); padding-bottom: 60px;">
      <!-- 应用信息头部 -->
      <div class="relative px-5 pt-5 pb-4">
        <div class="flex items-start gap-4">
          <div class="flex-shrink-0">
            <div class="w-18 h-18 rounded-[22px] flex items-center justify-center shadow-lg ring-4 ring-white" :style="{ background: app?.iconBgColor || iconColor(app?.name || '') }">
              <span v-if="!app?.icon || iconError" class="text-white font-bold text-2xl leading-none">{{ (app?.name || '?')[0] }}</span>
              <img v-else :src="$fixImgUrl(app.icon)" class="w-full h-full object-cover rounded-[22px]" @error="iconError = true"  loading="lazy" />
            </div>
          </div>
          <div class="flex-1 min-w-0 pt-0.5">
            <h1 class="text-lg font-bold text-gray-900 leading-tight">{{ app?.name || '' }}
              <span v-if="app && app.status !== '1'" class="ml-2 inline-block px-2.5 py-0.5 text-[11px] rounded-full bg-orange-100 text-orange-600 font-medium align-middle">已下架</span>
              <span v-if="app?.isPinned" class="ml-1.5 inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-orange-500 text-white align-middle">置顶</span>
              <span v-if="app?.isOfficial" class="ml-1.5 inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-500 text-white align-middle">官方</span>
            </h1>
            <p class="text-xs text-gray-400 mt-0.5">{{ app?.packageName || '' }}</p>
            <div class="flex gap-1.5 mt-1.5 flex-wrap">
              <span v-for="tag in (displayApp?.tags || [])" :key="tag" class="inline-flex items-center gap-0.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium" :class="tagClass(tag)">
                <svg v-if="tag === '星选'" class="w-2.5 h-2.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                {{ tag }}
              </span>
              <span v-for="ot in (displayApp?.officialTags || [])" :key="ot.id" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
              <span v-if="displayApp && getPriceType() === 'free'" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium bg-green-50 text-green-600 border border-green-200">免费</span>
              <span v-else-if="displayApp && getPriceType() !== 'free'" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-600 border border-red-200">
                {{ displayApp.priceType === 'balance' ? '¥' + displayApp.priceAmount : displayApp.priceAmount + '积分' }}
              </span>
              <span v-if="app?.isFeatured" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-600 border border-amber-200">精品推荐</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 数据统计行 -->
      <div class="grid grid-cols-4 gap-2 px-4 pb-4">
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="flex items-center justify-center gap-1">
            <svg class="w-3.5 h-3.5 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <span class="text-sm font-bold text-gray-800">{{ toNum(displayApp?.rating).toFixed(1) }}</span>
          </div>
          <div class="text-[11px] text-gray-400 mt-0.5">评分</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="text-sm font-bold text-gray-800">{{ displayApp?.sizeMb ?? 0 }}MB</div>
          <div class="text-[11px] text-gray-400 mt-0.5">大小</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center" :class="{ 'cursor-pointer': purchased }" @click="purchased && openPurchasers()">
          <div class="text-sm font-bold text-gray-800">{{ formatCount(totalDownloads) }}</div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ purchased ? '已购买' : '下载' }}</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="text-sm font-bold text-gray-800">{{ (app?.coinCount ?? 0).toFixed(0) }}<span class="text-xs text-gray-400 font-normal">积分</span></div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ coinPeopleCount }}人投币</div>
        </div>
      </div>

      <!-- Tab 切换 -->
      <div class="sticky top-0 z-10 border-b border-gray-100" style="background: var(--app-page-bg);">
        <div class="flex px-4">
          <div v-for="tab in tabs" :key="tab" class="relative px-5 py-3 text-sm cursor-pointer transition-colors" :class="activeTab === tab ? 'text-[#00BFA5] font-semibold' : 'text-gray-500'" @click="activeTab = tab">
            {{ tab }}
            <div v-if="activeTab === tab" class="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-full" style="background: #00BFA5"/>
          </div>
        </div>
      </div>

      <!-- Tab: 详情 -->
      <div v-if="activeTab === '详情'" class="px-4 pt-5 pb-20 space-y-4">
        <!-- 截图 -->
        <div v-if="(displayApp?.screenshots || []).length > 0" class="overflow-x-auto scrollbar-hide -mx-1">
          <div class="flex gap-2.5 px-1 pb-1" style="scroll-snap-type: x mandatory;">
            <div
              v-for="(shot, idx) in (displayApp?.screenshots || [])"
              :key="idx"
              class="flex-shrink-0 w-[130px] h-[230px] rounded-[18px] relative overflow-hidden shadow-sm"
              :style="{ background: getShotBg(shot) }"
              style="scroll-snap-align: start;"
            >
              <img
                v-if="getShotImage(shot) && !shotErrors.has(getShotImage(shot))"
                :src="getShotImage(shot)"
                class="w-full h-full object-cover absolute inset-0"
                @error="onShotError($event, getShotImage(shot))"
               loading="lazy" />
              <div v-else class="w-full h-full absolute inset-0 flex flex-col items-center justify-center bg-gray-200">
                <svg class="w-8 h-8 text-gray-400 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <div class="text-xs text-gray-400">{{ getShotText(shot) || '图片加载失败' }}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 应用标签 -->
        <div v-if="displayApp" class="flex gap-1.5 flex-wrap">
          <span v-if="displayApp.isFree" class="inline-block px-2.5 py-1 rounded-full text-[11px] font-medium bg-green-50 text-green-600 border border-green-200">免费应用</span>
          <span v-if="displayApp.hasAds" class="inline-block px-2.5 py-1 rounded-full text-[11px] font-medium bg-orange-50 text-orange-600 border border-orange-200">含广告</span>
          <span v-if="displayApp.hasPaidContent" class="inline-block px-2.5 py-1 rounded-full text-[11px] font-medium bg-purple-50 text-purple-600 border border-purple-200">含付费内容</span>
          <span v-if="displayApp.requiresNetwork" class="inline-block px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-50 text-blue-600 border border-blue-200">需联网</span>
        </div>

        <!-- 上传者信息 -->
        <div v-if="app?.developer || app?.userName || app?.userId" class="py-3 pl-3">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden">
              <img v-if="app?.userAvatar" :src="app.userAvatar" class="w-full h-full object-cover"  loading="lazy" />
              <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover"  loading="lazy" />
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1.5">
                <span class="text-sm font-medium text-gray-900">{{ app?.userName || app?.developer || '未知用户' }}</span>
                <span class="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 font-medium">上传者</span>
              </div>
              <p class="text-[11px] text-gray-400 mt-0.5">该应用由用户上传分享，请自行甄别内容安全性</p>
            </div>
            <svg class="w-4 h-4 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>

        <!-- 关于应用 + 更新内容 -->
        <div class="space-y-4 pl-3">
          <div>
            <h3 class="text-[15px] font-bold text-gray-900 mb-2.5 flex items-center gap-2">
              <span class="w-1 h-4 rounded-full bg-teal-500"></span>
              关于应用
            </h3>
            <p class="text-[13px] text-gray-500 leading-relaxed">{{ displayApp?.description || '暂无介绍' }}</p>
          </div>
          <div class="border-t border-gray-100 pt-4">
            <h3 class="text-[15px] font-bold text-gray-900 mb-2.5 flex items-center gap-2">
              <span class="w-1 h-4 rounded-full bg-teal-500"></span>
              更新内容
            </h3>
            <p class="text-xs text-gray-400 mb-2">版本 {{ displayApp?.version || '' }}</p>
            <p class="text-[13px] text-gray-500 leading-relaxed">{{ displayApp?.updateContent || '暂无更新内容' }}</p>
          </div>
        </div>

        <!-- 免责声明 -->
        <p class="text-[11px] text-gray-300 text-center leading-relaxed px-4">该软件由用户上传，仅用于学习用途。请在下载后24小时内删除，如造成您的权益受损请点击申诉</p>
      </div>

      <CommentSection
        v-if="activeTab === '讨论'"
        :app-id="Number(route.params.id)"
        :comments="comments"
        :rating-stats="ratingStats"
        :is-owner="isOwner"
        :is-admin="isAdminUser"
        @refresh="loadDetail"
      />

      <!-- Tab: 版本 -->
      <div v-if="activeTab === '版本'" class="px-4 pt-4 pb-20">
        <div class="space-y-3">
          <div v-for="ver in versions" :key="ver.id" class="group bg-gray-50/80 rounded-xl p-3.5 cursor-pointer transition-all duration-150 hover:bg-gray-100/90 active:scale-[0.985]" @click="gotoVersion(ver)">
            <div class="flex items-start gap-3">
              <!-- 版本图标 -->
              <div class="flex-shrink-0 w-11 h-11 rounded-2xl flex items-center justify-center shadow-sm overflow-hidden" :style="{ background: iconColor(app?.name || '') }">
                <img v-if="app?.icon" :src="$fixImgUrl(app.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <span v-else class="text-white font-bold text-sm leading-none">{{ (app?.name || '?')[0] }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <!-- 标题行 -->
                <div class="flex items-center gap-2 flex-wrap">
                  <span class="text-sm font-semibold text-gray-800">{{ app?.name }}</span>
                  <span v-if="ver.isCurrent" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold text-white bg-[#00BFA5] shadow-sm shadow-teal-200">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>
                    当前版本
                  </span>
                  <span v-else class="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium text-gray-500 bg-gray-200/80">{{ ver.version }}</span>
                </div>
                <!-- 标签行 -->
                <div class="flex flex-wrap items-center gap-1.5 mt-2" v-if="(ver.tags || []).length > 0 || (ver.officialTags || []).length > 0">
                  <span v-for="tag in (ver.tags || [])" :key="tag" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium" :class="tagClass(tag)">
                    <svg v-if="tag === '星选'" class="w-2.5 h-2.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    {{ tag }}
                  </span>
                  <span v-for="ot in (ver.officialTags || [])" :key="ot.id" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
                </div>
                <!-- 元数据行 -->
                <div class="flex items-center gap-0 mt-2 flex-wrap">
                  <span class="inline-flex items-center gap-1 text-[11px] text-gray-400">
                    <svg class="w-3 h-3 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    {{ toNum(ver.rating).toFixed(1) }}
                  </span>
                  <span class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span class="text-[11px] text-gray-400">{{ ver.sizeMb }} MB</span>
                  <span class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span class="text-[11px] text-gray-400">{{ formatCount(ver.downloads) }} 下载</span>
                  <span v-if="ver.userName" class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span v-if="ver.userName" class="text-[11px] text-gray-400">{{ ver.userName }}</span>
                </div>
              </div>
              <svg class="mt-0.5 flex-shrink-0 transition-transform group-hover:translate-x-0.5" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
            </div>
          </div>
        </div>
        <!-- 无版本 -->
        <div v-if="versions.length === 0" class="text-center py-16 text-gray-400 text-sm">暂无历史版本</div>
        <div class="mt-4 text-center">
          <router-link :to="'/appstore/version-changelog?appId=' + route.params.id" class="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full text-sm font-medium transition-all" style="color: #6366F1; background: #EEF2FF;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
            查看完整版本日志
          </router-link>
        </div>
      </div>
    </div>

    <!-- Toast -->
    <div v-if="toastText" class="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 px-5 py-2.5 rounded-full text-sm text-white" style="background: rgba(0,0,0,0.75);">{{ toastText }}</div>

    <!-- 底部操作栏 -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-between px-5 py-2 z-10" style="height: 60px;">
      <div class="flex flex-col items-center gap-0.5" :class="{ 'cursor-pointer': !isOwner }" @click="!isOwner && (showTipDialog = true)">
        <span class="text-sm font-semibold text-gray-800">{{ (app?.coinCount ?? 0).toFixed(0) }}</span>
        <span class="text-[10px] text-gray-400">{{ coinPeopleCount }}人投币</span>
      </div>
      <button
        v-if="app && app.status !== '1'"
        class="rounded-full px-14 font-semibold text-base text-gray-500 cursor-not-allowed"
        style="background: #e5e7eb; height: 42px;"
        disabled
      >已下架，无法下载</button>
      <button
        v-else-if="getPriceType() !== 'free' && !purchased"
        class="rounded-full px-14 font-semibold text-base text-white" style="background: #00BFA5; height: 42px;"
        @click="openBuy()"
      >{{ purchaseBtnLabel }}</button>
      <button v-else class="rounded-full px-14 font-semibold text-base text-white" style="background: #00BFA5; height: 42px;" @click="doDownload(null)">下载 {{ displayApp?.sizeMb ?? '0' }} MB</button>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer" @click="showTipList = true">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v13"/></svg>
        <span class="text-[10px] text-gray-500">打赏列表</span>
      </div>
    </div>

    <!-- 打赏列表弹窗 -->
    <div v-if="showTipList" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100;" @click.self="showTipList = false">
      <div style="background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 60vh; overflow-y: auto; padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <span style="font-size: 16px; font-weight: 600;">打赏记录</span>
          <span style="font-size: 13px; color: #00BFA5;">余额 {{ formatAmount(tipStats?.totalBalance) }}元 + 积分 {{ formatAmount(tipStats?.totalPoints) }}</span>
        </div>
        <div v-if="tipList.length === 0" style="text-align: center; padding: 40px 0; color: #9ca3af;">暂无打赏</div>
        <div v-for="t in tipList" :key="t.id" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #f3f4f6;">
          <div>
            <div style="font-size: 14px; font-weight: 500;">{{ t.userName }}</div>
            <div style="font-size: 12px; color: #9ca3af;">{{ t.message || '支持一下' }}</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 14px; font-weight: 600;" :style="{ color: t.tipType === 'balance' ? '#00BFA5' : '#f97316' }">{{ formatAmount(t.amount) }}{{ t.tipType === 'balance' ? '元' : '积分' }}</div>
            <div style="font-size: 10px; color: #9ca3af;">{{ t.createTime?.slice(0,10) }}</div>
          </div>
        </div>
        <button style="width: 100%; padding: 12px; margin-top: 12px; border-radius: 8px; border: none; background: #f3f4f6; font-size: 14px; cursor: pointer;" @click="showTipList = false">关闭</button>
      </div>
    </div>

    <TipDialog v-model="showTipDialog" :app-id="Number(route.params.id)" :app-name="app?.name || ''" @tipped="loadDetail" />

      <!-- Tab: 相关 -->
      <div v-if="activeTab === '相关'" class="px-4 pt-4 pb-20">
        <div v-if="relatedLoading" class="text-center py-8 text-gray-400">加载中...</div>
        <div v-else-if="relatedApps.length === 0" class="text-center py-8 text-gray-400">暂无相关应用</div>
        <div v-else class="space-y-3">
          <div v-for="ra in relatedApps" :key="ra.id" class="flex items-center gap-3 bg-white rounded-xl p-3 cursor-pointer" @click="$router.push('/appstore/browse/detail/' + ra.id)">
            <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" :style="{ background: ra.iconBgColor || '#e0e0e0' }">
              <img v-if="ra.icon" :src="$fixImgUrl(ra.icon)" class="w-full h-full object-cover rounded-xl"  loading="lazy" />
              <span v-else class="text-white font-bold">{{ (ra.name || '?')[0] }}</span>
            </div>
            <div class="flex-1 min-w-0">
              <div class="text-sm font-medium text-gray-800 truncate">{{ ra.name }}</div>
              <div class="text-xs text-gray-400 mt-0.5 truncate">{{ ra.description || ra.packageName || '' }}</div>
              <div class="flex items-center gap-2 mt-1">
                <span class="text-xs text-amber-500">{{ (Number(ra.rating) || 0).toFixed(1) }}分</span>
                <span class="text-xs text-gray-400">{{ ra.sizeMb || 0 }}MB</span>
              </div>
            </div>
            <span class="text-xs px-2 py-0.5 rounded-full flex-shrink-0" :class="ra.priceType === 'free' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'">{{ ra.priceType === 'free' ? '免费' : ra.priceAmount + '元' }}</span>
          </div>
        </div>
      </div>
    <BuyDialog v-model="showBuyDialog" :app-id="Number(route.params.id)" :app="buyAppForDialog" @purchased="onPurchased" />
    <!-- 下载弹窗 -->
    <div v-if="showDownloadDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showDownloadDialog = false">
      <div style="background: #fff; border-radius: 16px; width: 340px; padding: 24px 20px 16px;">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 16px;">下载 {{ app?.name }}</div>
        <template v-if="downloadUrl">
          <div style="font-size: 13px; color: #6b7280; margin-bottom: 8px;">下载链接：</div>
          <div style="background: #f3f4f6; border-radius: 8px; padding: 10px; font-size: 12px; color: #374151; word-break: break-all; margin-bottom: 16px; max-height: 80px; overflow-y: auto;">{{ downloadUrl }}</div>
          <div style="display: flex; gap: 10px;">
            <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: 1px solid #e5e7eb; background: #fff; color: #374151; cursor: pointer;" @click="copyDownloadUrl">复制链接</button>
            <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="openDownloadUrl">打开下载</button>
          </div>
        </template>
        <template v-else>
          <div style="text-align: center; padding: 20px 0; color: #9ca3af; font-size: 14px;">暂无下载链接</div>
          <button style="width: 100%; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer; margin-top: 8px;" @click="showDownloadDialog = false">关闭</button>
        </template>
      </div>
    </div>
    <!-- 购买者列表弹窗 -->
    <div v-if="showPurchasersDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100;" @click.self="showPurchasersDialog = false">
      <div style="background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 60vh; overflow-y: auto; padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <span style="font-size: 16px; font-weight: 600;">已购买用户 ({{ purchasersList.length }})</span>
        </div>
        <div v-if="purchasersList.length === 0" style="text-align: center; padding: 40px 0; color: #9ca3af;">暂无购买记录</div>
        <div v-for="p in purchasersList" :key="p.id" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f3f4f6;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; overflow: hidden;">
              <img v-if="p.avatar" :src="$fixImgUrl(p.avatar)" style="width: 100%; height: 100%; object-fit: cover;"  loading="lazy" />
              <img v-else src="@imgs/user/avatar.webp" style="width: 100%; height: 100%; object-fit: cover;"  loading="lazy" />
            </div>
            <div>
              <div style="font-size: 14px; font-weight: 500;">{{ p.userName }}</div>
              <div style="font-size: 12px; color: #9ca3af;">{{ p.levelName || '普通会员' }} · {{ p.createTime }}</div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 13px; font-weight: 600;" :style="{ color: p.priceType === 'points' ? '#8B5CF6' : '#F59E0B' }">
              {{ p.paidPrice }}{{ p.priceType === 'balance' ? '元' : '积分' }}
            </div>
            <div style="font-size: 11px; color: #9ca3af;">{{ p.priceType === 'balance' ? '余额支付' : '积分支付' }}</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchAppDetail, fetchAppList, fetchRecommendApps, fetchAppTips, fetchPurchaseStatus, fetchPurchasers, fetchSaveApp,
} from '@/api/appstore'
import { addBrowseHistory } from '@/api/browse-history'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import { toNum, iconColor } from '@/utils'
import CommentSection from './components/CommentSection.vue'
import TipDialog from './components/TipDialog.vue'
import BuyDialog from './components/BuyDialog.vue'
import AppActionMenu from './components/AppActionMenu.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const app = ref<any>(null)
const loading = ref(true)
const comments = ref<any[]>([])
const versions = ref<any[]>([])
const ratingStats = ref<any>({ average: 0, total: 0, distribution: {} })
const recommendApps = ref<any[]>([])
const relatedApps = ref<any[]>([])
const relatedLoading = ref(false)
const activeTab = ref('详情')
const selectedVersion = ref<any>(null)
const showBuyDialog = ref(false)
const showTipDialog = ref(false)
const purchased = ref(false)
const showDownloadDialog = ref(false)
const downloadUrl = ref('')
const showPurchasersDialog = ref(false)
const purchasersList = ref<any[]>([])
const displayApp = computed(() => {
  if (!app.value) return null
  const sv = selectedVersion.value
  if (!sv) return app.value
  return {
    ...app.value,
    version: sv.version,
    versionCode: sv.versionCode,
    sizeMb: sv.sizeMb,
    downloads: sv.downloads,
    rating: sv.rating,
    downloadUrl: sv.downloadUrl,
    tags: (sv.tags && sv.tags.length > 0) ? sv.tags : app.value.tags,
    officialTags: (sv.officialTags && sv.officialTags.length > 0) ? sv.officialTags : app.value.officialTags,
    hasAds: sv.hasAds !== undefined ? !!sv.hasAds : !!app.value.hasAds,
    requiresNetwork: sv.requiresNetwork !== undefined ? !!sv.requiresNetwork : !!app.value.requiresNetwork,
    hasPaidContent: sv.hasPaidContent !== undefined ? !!sv.hasPaidContent : !!app.value.hasPaidContent,
    isFree: sv.isFree !== undefined ? !!sv.isFree : !!app.value.isFree,
    updateContent: sv.updateContent || '',
    description: sv.description || app.value.description,
    screenshots: (sv.screenshots && sv.screenshots.length > 0) ? sv.screenshots : app.value.screenshots,
  }
})

function gotoVersion(ver: any) {
  router.push({ query: { version: ver.version } })
}

watch(() => route.query.version, (v) => {
  if (v && versions.value.length) {
    const found = versions.value.find((item: any) => item.version === v)
    selectedVersion.value = found || null
    if (found) activeTab.value = '详情'
  } else {
    selectedVersion.value = null
  }
})

function getShotBg(shot: any) {
  if (typeof shot === 'string') return '#333'
  return shot.bgColor || '#222'
}
function getShotImage(shot: any) {
  if (typeof shot === 'string') return shot
  return shot.image || ''
}
function getShotText(shot: any) {
  if (typeof shot === 'string') return ''
  return shot.text || ''
}
function onShotError(_e: Event, url: string) {
  shotErrors.add(url)
}

const showTipList = ref(false)
const tipList = ref<any[]>([])
const tipStats = ref<any>(null)

const coinPeopleCount = computed(() => tipList.value.length)

const coinDisplay = computed(() => {
  const s = tipStats.value
  if (!s || (s.totalBalance === 0 && s.totalPoints === 0)) return String(app.value?.coinCount ?? 0)
  const parts: string[] = []
  if (s.totalBalance > 0) parts.push(`${s.totalBalance}元`)
  if (s.totalPoints > 0) parts.push(`${s.totalPoints}积分`)
  return parts.join('+')
})

const formatAmount = (value: any) => {
  if (value == null) return '0'
  const n = Number(value)
  return Number.isInteger(n) ? String(n) : n.toFixed(2)
}

const tabs = ['详情', '讨论', '版本', '相关']

const balanceStr = computed(() => {
  const b = Number(userStore.info.balance || 0)
  return b.toFixed(2)
})

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return false
  }
  return true
}

const isOwner = computed(() => {
  const uid = userStore.info.userId
  if (!uid) return false
  return app.value.userId === uid || app.value.developer === userStore.info.userName
})

const isAdminUser = computed(() => {
  const roles: string[] = userStore.info.roles || []
  return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
})

const isLogin = computed(() => !!userStore.info.userId)

const isAppFavorited = ref(false)
const favGroups = ref<any[]>([])
const favGroupsLoading = ref(false)

const buyAppForDialog = computed(() => {
  if (!app.value) return null
  return { name: app.value.name, priceAmount: app.value.priceAmount, priceType: app.value.priceType }
})

const showMenu = ref(false)
const menuRef = ref<HTMLElement>()
const menuStyle = ref<Record<string, string>>({})

const toggleMenu = () => {
  if (!showMenu.value && menuRef.value) {
    const rect = menuRef.value.getBoundingClientRect()
    menuStyle.value = {
      position: 'fixed',
      top: rect.bottom + 4 + 'px',
      right: (window.innerWidth - rect.right) + 'px',
    }
  }
  showMenu.value = !showMenu.value
}

const handleAppShare = () => {
  const url = window.location.href
  if (navigator.share) {
    navigator.share({ title: app.value?.name || '应用', url })
  } else {
    navigator.clipboard.writeText(url).then(() => showToast('链接已复制')).catch(() => showToast('复制失败'))
  }
}

function handleAppDeleted() {
  setTimeout(() => { router.push('/appstore/browse') }, 800)
}

function onFavoriteToggled() {
  checkAppFavorite()
}

function onPurchased() {
  loadDetail()
}

const checkAppFavorite = async () => {
  const uid = userStore.info?.userId
  const aid = Number(route.params.id)
  if (!uid || !aid) return
  try {
    const res: any = await request.get({ url: `/api/app-favorite/check?userId=${uid}&appId=${aid}` })
    isAppFavorited.value = res?.favorited || false
  } catch (e: any) { console.error('[detail] checkFavorite failed:', e?.message || e) }
}

const toastText = ref('')
const shotErrors = reactive(new Set<string>())
const iconError = ref(false)
const showToast = (text: string) => {
  toastText.value = text
  setTimeout(() => { toastText.value = '' }, 2000)
}

const getPriceType = () => {
  if (!app.value) return 'free'
  return (app.value as any).priceType || 'free'
}

const calculatedPrice = computed(() => {
  if (!app.value || !hasMembershipDiscount.value) return (app.value as any).priceAmount || 0
  const rate = Number((userStore.info as any).discountRate || (userStore.info as any).pointsDiscountRate || 1)
  const amt = Number((app.value as any).priceAmount || 0)
  return Math.round(amt * rate * 100) / 100
})

const hasMembershipDiscount = computed(() => {
  if (!app.value || !userStore.info) return false
  const pt = (app.value as any).priceType || 'free'
  const ml = Number(userStore.info.levelId || 0)
  if (ml <= 0) return false
  if (pt === 'balance') return Number(userStore.info.discountRate || 1) < 1
  if (pt === 'points') return Number(userStore.info.pointsDiscountRate || 1) < 1
  return false
})

const membershipDiscountLabel = computed(() => {
  const pt = (app.value as any).priceType || 'free'
  if (pt === 'balance') return `会员${Math.round((userStore.info.discountRate || 1) * 100)}折`
  if (pt === 'points') return `积分${Math.round((userStore.info.pointsDiscountRate || 1) * 100)}折`
  return ''
})

const purchaseBtnLabel = computed(() => {
  if (!app.value) return '购买'
  const pt = (app.value as any).priceType || 'free'
  const amt = (app.value as any).priceAmount || 0
  const final = calculatedPrice.value
  const unit = pt === 'balance' ? '元' : '积分'
  if (final !== amt) return `¥${final}${unit} 购买`
  return `¥${amt}${unit} 购买`
})

const openBuy = () => {
  if (!userStore.info?.userId) { showToast('请先登录'); return }
  showBuyDialog.value = true
}

const tagStyles: Record<string, string> = {
  '星选': 'bg-purple-50 text-purple-600 border border-purple-200',
  '官方版': 'bg-blue-50 text-blue-600 border border-blue-200',
  '测试版': 'bg-amber-50 text-amber-600 border border-amber-200',
  '国际版': 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  '灰度版': 'bg-slate-100 text-slate-600 border border-slate-200',
  '汉化版': 'bg-rose-50 text-rose-600 border border-rose-200',
  '破解版': 'bg-red-50 text-red-600 border border-red-200',
  '修改版': 'bg-orange-50 text-orange-600 border border-orange-200',
}
const fallbackTagClass = 'bg-teal-50 text-teal-600 border border-teal-200'
const tagClass = (tag: string) => tagStyles[tag] || fallbackTagClass

const totalDownloads = computed(() => {
  if (selectedVersion.value) return selectedVersion.value.downloads || 0
  const vd = versions.value.reduce((sum: number, v: any) => sum + (v.downloads || 0), 0)
  return vd > 0 ? vd : (app.value?.downloads || 0)
})

const formatCount = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
  return String(n)
}

const doDownload = (ver: any) => {
  let url = ''
  if (ver) {
    url = ver.downloadUrl || ''
  } else {
    url = displayApp.value?.downloadUrl || ''
  }
  downloadUrl.value = url
  showDownloadDialog.value = true
}

const copyDownloadUrl = () => {
  if (downloadUrl.value) {
    navigator.clipboard?.writeText(downloadUrl.value).then(() => {
      showToast('链接已复制')
    }).catch(() => {
      showToast('复制失败，请手动复制')
    })
  }
}

const openDownloadUrl = async () => {
  if (downloadUrl.value) {
    try {
      const res: any = await request.get({ url: '/api/storage/sign-url', params: { url: downloadUrl.value } })
      const signedUrl = res?.data?.url || res?.url || downloadUrl.value
      window.open(signedUrl, '_blank')
    } catch {
      window.open(downloadUrl.value, '_blank')
    }
    showDownloadDialog.value = false
  }
}

const openPurchasers = async () => {
  showPurchasersDialog.value = true
  purchasersList.value = []
  try {
    const res: any = await fetchPurchasers(Number(route.params.id))
    purchasersList.value = res?.list || []
  } catch (e: any) { console.error('[detail] fetchPurchasers failed:', e?.message || e) }
}

onMounted(async () => {
  await loadDetail()
  if (route.query.version) {
    const found = versions.value.find((item: any) => item.version === route.query.version)
    if (found) { selectedVersion.value = found; activeTab.value = '详情' }
  }
  try {
    const recs: any = await fetchRecommendApps()
    recommendApps.value = recs || []
  } catch (e: any) { console.error('[detail] recommend failed:', e?.message || e) }
  try {
    relatedLoading.value = true
    const related: any = await request.get({ url: `/api/app/${route.params.id}/related?limit=10` })
    relatedApps.value = related || []
  } catch (e: any) { console.error('[detail] related failed:', e?.message || e) } finally { relatedLoading.value = false }
  if (userStore.info.userId && app.value) {
    addBrowseHistory({
      userId: userStore.info.userId,
      itemType: 'app',
      itemId: Number(route.params.id),
      itemTitle: app.value.name || '',
      itemCover: app.value.icon || '',
      itemUrl: route.fullPath
    }).catch(() => {})
    checkAppFavorite()
  }
})

async function loadDetail() {
  const id = route.params.id as string
  if (!id) { loading.value = false; return }
  try {
    const res: any = await fetchAppDetail(Number(id), userStore.info.userId)
    app.value = res.app
    if (app.value) {
      app.value.isPinned = app.value.isPinned ?? false
    }
    comments.value = res.comments || []
    versions.value = res.versions || []
    ratingStats.value = res.ratingStats || { average: 0, total: 0, distribution: {} }
    loadPinStatus()
  } catch (e) { console.error(e) }
  loading.value = false
  loadTips()
  checkPurchaseStatus()
}

async function loadPinStatus() {
  try {
    const res: any = await fetchAppList({ page: 1, pageSize: 100, status: '1' })
    const list = res?.data?.list || res?.list || []
    const found = list.find((a: any) => a.id === app.value?.id)
    if (found && app.value) {
      app.value.isPinned = found.isPinned === 1 || found.isPinned === true
    }
  } catch (e: any) { console.error('[detail] pinStatus failed:', e?.message || e) }
}

async function checkPurchaseStatus() {
  const id = route.params.id as string
  if (!id || !userStore.info?.userId) return
  try {
    const res: any = await fetchPurchaseStatus(Number(id), userStore.info.userId)
    purchased.value = res?.purchased === true
  } catch (e: any) { console.error('[detail] purchaseStatus failed:', e?.message || e) }
}

async function loadTips() {
  try {
    const data = await fetchAppTips(Number(route.params.id))
    tipList.value = data.list || []
    tipStats.value = data.stats || null
  } catch (e: any) { console.error('[detail] appTips failed:', e?.message || e) }
}
</script>
