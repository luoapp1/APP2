<template>
  <div class="login-container">
    <LoginLeftView />

    <div class="login-right">
      <AuthTopBar />

      <div class="form-wrapper" v-if="!show2FA">
        <div class="form-card">
          <h3 class="login-title">{{ $t('login.title') }}</h3>
          <p class="login-subtitle">{{ $t('login.subTitle') }}</p>
          <ElForm ref="formRef" :model="formData" :rules="rules" :key="formKey" @keyup.enter="onLogin">
            <ElFormItem prop="username">
              <ElInput class="custom-height" :placeholder="$t('login.placeholder.username')" v-model.trim="formData.username" />
            </ElFormItem>
            <ElFormItem prop="password">
              <ElInput class="custom-height" :placeholder="$t('login.placeholder.password')" v-model.trim="formData.password" type="password" autocomplete="off" show-password />
            </ElFormItem>
            <div class="flex items-center justify-between text-sm mb-4">
              <ElCheckbox v-model="formData.rememberPassword">{{ $t('login.rememberPwd') }}</ElCheckbox>
              <span class="text-[var(--el-color-primary)] cursor-pointer" @click="router.push('/auth/forget-password')">{{ $t('login.forgetPwd') }}</span>
            </div>
            <ElButton class="w-full custom-height" type="primary" @click="onLogin" :loading="loading">{{ $t('login.btnText') }}</ElButton>
            <div class="mt-4 text-sm text-center text-gray-500">
              <span>{{ $t('login.noAccount') }}</span>
              <span class="text-[var(--el-color-primary)] cursor-pointer ml-1" @click="router.push('/auth/register')">{{ $t('login.register') }}</span>
            </div>
          </ElForm>
        </div>
      </div>

      <div class="form-wrapper" v-if="show2FA">
        <div class="form-card">
          <h3 class="login-title">两步验证</h3>
          <p class="login-subtitle">请输入认证应用中的 6 位验证码</p>
          <ElInput v-model="twoFACode" class="custom-height" placeholder="输入6位验证码" maxlength="6" style="text-align:center;font-size:20px;letter-spacing:8px;" @keyup.enter="verify2FA" />
          <ElButton class="w-full custom-height mt-4" type="primary" @click="verify2FA" :loading="twoFALoading" :disabled="twoFACode.length !== 6">验证并登录</ElButton>
          <div class="mt-4 text-sm text-center text-gray-500 cursor-pointer" @click="show2FA = false; twoFACode = ''">返回重新登录</div>
        </div>
      </div>
    </div>

    <ElDialog v-model="banAppealVisible" title="账号已被封禁" width="90%" :close-on-click-modal="false">
      <p class="ban-msg">{{ banMsg }}</p>
      <p class="ban-tip text-sm text-gray-500 mt-2">如需申诉解封，请在下方填写申诉理由：</p>
      <ElInput v-model="appealReason" type="textarea" :rows="4" placeholder="请详细说明申诉理由..." maxlength="500" show-word-limit class="mt-3" />
      <template #footer>
        <ElButton @click="banAppealVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="appealLoading" :disabled="!appealReason.trim()" @click="onAppeal">提交申诉</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useI18n } from 'vue-i18n'
import { fetchLogin, fetchGetUserInfo } from '@/api/auth'
import request from '@/utils/http'
import { HttpError } from '@/utils/http/error'
import { type FormInstance, type FormRules, ElMessage } from 'element-plus'

defineOptions({ name: 'AppStoreLogin' })

const { t, locale } = useI18n()
const formKey = ref(0)
watch(locale, () => { formKey.value++ })

const userStore = useUserStore()
const router = useRouter()
const formRef = ref<FormInstance>()
const loading = ref(false)

const formData = reactive({ username: '', password: '', rememberPassword: true })

const saved = localStorage.getItem('login_remember')
if (saved) {
  try {
    const { username, password } = JSON.parse(saved)
    if (username) formData.username = username
    if (password) {
      formData.password = password
      formData.rememberPassword = true
    }
  } catch {}
}

const banAppealVisible = ref(false)
const banMsg = ref('')
const banUserId = ref(0)
const appealReason = ref('')
const appealLoading = ref(false)
const show2FA = ref(false)
const twoFATempToken = ref('')
const twoFACode = ref('')
const twoFALoading = ref(false)

const rules = computed<FormRules>(() => ({
  username: [{ required: true, message: t('login.placeholder.username'), trigger: 'blur' }],
  password: [{ required: true, message: t('login.placeholder.password'), trigger: 'blur' }]
}))

const onLogin = async () => {
  if (!formRef.value) return
  try {
    const valid = await formRef.value.validate()
    if (!valid) return
    loading.value = true

    const { username, password } = formData

    if (formData.rememberPassword) {
      localStorage.setItem('login_remember', JSON.stringify({ username, password }))
    } else {
      localStorage.removeItem('login_remember')
    }

    const res: any = await fetchLogin({ userName: username, password })

    if (res.need2FA) {
      twoFATempToken.value = res.tempToken
      show2FA.value = true
      return
    }

    if (!res.token) {
      throw new Error('Login failed - no token received')
    }

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    router.replace('/appstore/mine')
  } catch (error) {
    if (error instanceof HttpError) {
      if (error.code === 403 && error.data) {
        const respBody = error.data as any
        const innerData = respBody?.data || respBody
        banUserId.value = innerData.userId || 0
        banMsg.value = error.message || '该账号已被封禁'
        banAppealVisible.value = true
        return
      }
      console.error('[Login] HTTP Error:', error.code)
    } else {
      console.error('[Login] Error:', error)
    }
    } finally {
    loading.value = false
  }
}

const verify2FA = async () => {
  if (!twoFACode.value || twoFACode.value.length !== 6) return
  twoFALoading.value = true
  try {
    const res: any = await request.post({
      url: '/api/auth/login/2fa',
      data: { tempToken: twoFATempToken.value, code: twoFACode.value }
    })
    if (!res.token) throw new Error('No token')

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    router.replace('/appstore/mine')
  } catch (err: any) {
    ElMessage.error(err.message || err.msg || '验证失败')
  } finally {
    twoFALoading.value = false
  }
}

const onAppeal = async () => {
  if (!appealReason.value.trim() || !banUserId.value) return
  appealLoading.value = true
  try {
    await request.post({
      url: '/api/user/appeal',
      data: {
        userId: banUserId.value,
        reason: appealReason.value
      },
      showErrorMessage: false
    })
    ElMessage.success('申诉已提交，请耐心等待管理员审核')
    banAppealVisible.value = false
    appealReason.value = ''
  } catch (err: any) {
    ElMessage.error(err.message || err.msg || '提交失败，请稍后重试')
  } finally {
    appealLoading.value = false
  }
}
</script>

<style>
.login-container{display:flex;width:100%;min-height:100vh}
.login-right{flex:1;display:flex;flex-direction:column;position:relative}
.form-wrapper{flex:1;display:flex;align-items:center;justify-content:center;padding:20px}
.form-card{width:100%;max-width:380px}
.login-title{font-size:24px;font-weight:bold;text-align:center;margin-bottom:4px}
.login-subtitle{font-size:14px;color:#9ca3af;text-align:center;margin-bottom:24px}
</style>
