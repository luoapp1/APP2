<template>
  <div class="notify-page">
    <div class="notify-navbar">
      <button class="notify-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="notify-title">订阅消息提醒</span>
      <div class="notify-placeholder" />
    </div>

    <div class="notify-content">
      <div class="notify-card">
        <div class="toggle-row" v-for="(val, key) in settings" :key="key">
          <div class="toggle-info">
            <span class="toggle-label">{{ labelMap[key] || key }}</span>
            <span class="toggle-desc">{{ descMap[key] || '' }}</span>
          </div>
          <label class="toggle">
            <input type="checkbox" v-model="settings[key]" @change="handleChange(key, settings[key])" />
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const userStore = useUserStore()

const labelMap = {
  comment: '评论通知',
  like: '点赞通知',
  follow: '关注通知',
  system: '系统通知',
  message: '私信通知',
  mention: '@提及通知'
}

const descMap = {
  comment: '有人评论你的内容时通知',
  like: '有人点赞你的内容时通知',
  follow: '有人关注你时通知',
  system: '系统公告和重要消息提醒',
  message: '收到私信时通知',
  mention: '有人@你时通知'
}

const settings = ref({
  comment: true,
  like: true,
  follow: true,
  system: true,
  message: true,
  mention: true
})

onMounted(async () => {
  if (!userStore.isLogin) return
  try {
    const res = await request.get({ url: '/api/user/notification-settings', params: { userId: userStore.info.userId } })
    if (res && Array.isArray(res)) {
      res.forEach((item) => {
        if (settings.value.hasOwnProperty(item.type)) {
          settings.value[item.type] = !!item.enabled
        }
      })
    }
  } catch { /* ignore */ }
})

async function handleChange(type, enabled) {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    await request.put({
      url: '/api/user/notification-settings',
      data: { userId: uid, settings: [{ type, enabled }] }
    })
  } catch { /* ignore */ }
}
</script>

<style scoped>
.notify-page {
  min-height: 100vh;
  background: #F5F6FA;
}

.notify-navbar {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.05);
}

.notify-back {
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  display: flex;
  color: #333;
  border-radius: 8px;
}

.notify-back:active { background: #f0f0f0; }

.notify-title {
  flex: 1;
  text-align: center;
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
}

.notify-placeholder { width: 22px; }

.notify-content {
  padding: 12px 16px;
}

.notify-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
}

.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #F0F0F0;
}

.toggle-row:last-child { border-bottom: none; }

.toggle-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.toggle-label {
  font-size: 15px;
  color: #333;
  font-weight: 400;
}

.toggle-desc {
  font-size: 12px;
  color: #999;
}

.toggle {
  position: relative;
  display: inline-block;
  width: 44px;
  height: 24px;
  flex-shrink: 0;
}

.toggle input {
  opacity: 0;
  width: 0;
  height: 0;
}

.toggle-slider {
  position: absolute;
  cursor: pointer;
  inset: 0;
  background: #E0E0E0;
  border-radius: 12px;
  transition: .2s;
}

.toggle-slider::before {
  content: '';
  position: absolute;
  height: 20px;
  width: 20px;
  left: 2px;
  bottom: 2px;
  background: #fff;
  border-radius: 50%;
  transition: .2s;
  box-shadow: 0 1px 3px rgba(0,0,0,.15);
}

.toggle input:checked + .toggle-slider {
  background: #10B981;
}

.toggle input:checked + .toggle-slider::before {
  transform: translateX(20px);
}
</style>
