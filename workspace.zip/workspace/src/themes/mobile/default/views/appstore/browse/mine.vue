<template>
  <div style="min-height: 100vh; background: var(--app-page-bg); display: flex; flex-direction: column">
    <div style="flex: 1; overflow-y: auto; padding-bottom: 64px">
      <!-- 个人信息区 -->
      <div style="display: flex; align-items: center; padding: 16px">
        <div
          style="
            position: relative;
            width: 72px;
            height: 72px;
            flex-shrink: 0;
          "
        >
          <img
            v-if="activeFrameUrl"
            :src="activeFrameUrl"
            style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
           loading="lazy" />
          <div
            style="
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              width: 52px;
              height: 52px;
              border-radius: 50%;
              background: #f3f4f6;
              display: flex;
              align-items: center;
              justify-content: center;
              overflow: hidden;
              cursor: pointer;
              z-index: 1;
            "
            @click="handleAvatarClick"
          >
            <img
              v-if="isLogin && userInfo.avatar"
              :src="$fixImgUrl(userInfo.avatar)"
              style="width: 100%; height: 100%; object-fit: cover"
             loading="lazy" />
            <img
              v-else
              src="@imgs/user/avatar.webp"
              style="width: 100%; height: 100%; object-fit: cover"
             loading="lazy" />
          </div>
        </div>
        <div style="margin-left: 12px; flex: 1; cursor: pointer" @click="goExperience">
          <div
            style="font-size: 16px; font-weight: 600; color: #1f2937; cursor: pointer"
            @click.stop="handleAvatarClick"
          >{{
            isLogin ? (userInfo.nickname || userInfo.userName || '用户') : '请先登录'
          }}</div>
          <div style="display: flex; align-items: center; gap: 8px; margin-top: 0">
            <img
              v-if="isLogin && expLevelIcon"
              :src="expLevelIcon"
              style="width: 34px; height: 34px; object-fit: contain"
             loading="lazy" />
            <span
              v-else
              style="font-size: 12px; font-weight: 500; padding: 2px 8px; border-radius: 4px"
              :style="{ color: expLevelTextColor, background: expLevelBgColor }"
            >{{ isLogin ? levelName : 'Lv.0' }}</span>
            <div
              style="
                flex: 1;
                height: 6px;
                background: #f3f4f6;
                border-radius: 999px;
                overflow: hidden;
                max-width: 160px;
              "
            >
              <div
                style="height: 100%; border-radius: 999px"
                :style="{ width: expPercent + '%', background: expLevelBgColor }"
              />
            </div>
            <span style="font-size: 12px; font-weight: 500; color: #9ca3af; white-space: nowrap; cursor: pointer" @click="goExperience">{{ expDisplay }}</span>
            <svg
              style="width: 14px; height: 14px; color: #9ca3af; flex-shrink: 0; cursor: pointer"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              @click="goExperience"
            ><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <button
          @click="goSettings"
          style="
            flex-shrink: 0;
            align-self: flex-start;
            margin-top: -4px;
            padding: 6px;
            background: none;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
          "
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
        </button>
      </div>

      <!-- 会员卡片 + 礼包 并排 -->
      <div style="margin: 0 12px 12px; display: flex; gap: 10px; align-items: stretch;">
        <!-- 左侧：会员卡片 -->
        <div style="flex: 1; border-radius: 12px; overflow: hidden; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: #fff; position: relative; display: flex; flex-direction: column;">
          <div style="position: absolute; right: -20px; top: -20px; width: 100px; height: 100px; border-radius: 50%; background: rgba(255,255,255,0.05)"/>
          <div style="position: absolute; right: 30px; top: 10px; width: 50px; height: 50px; border-radius: 50%; background: rgba(255,255,255,0.08)"/>
          <div style="position: relative; z-index: 1; padding: 16px; cursor: pointer;" @click="handleMembershipClick">
            <div style="font-size: 12px; opacity: 0.7; margin-bottom: 4px">会员中心</div>
            <div style="font-size: 16px; font-weight: 700; margin-bottom: 6px">{{ isLogin ? memberLevelName : '普通会员' }}</div>
            <div style="font-size: 11px; opacity: 0.75">{{ isLogin ? (membershipExpireStr || '永久有效') : '点击查看权益' }}</div>
          </div>
          <div v-if="giftBirthday.enabled" style="position: relative; z-index: 1; margin-top: auto; padding: 10px 16px; font-size: 12px; font-weight: 700; color: #b45309; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); text-align: center; cursor: pointer;" @click="handleBirthdayGift">{{ giftBirthday.canClaim ? '生日快乐！领取专属生日礼包' : '生日快乐' }}</div>
        </div>

        <!-- 右侧：定制礼包 -->
        <div v-if="giftDaily.enabled || giftBirthday.enabled" style="flex: 1; border-radius: 12px; overflow: hidden; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,.04);">
          <div style="padding: 10px 14px; display: flex; align-items: center; gap: 6px; border-bottom: 1px solid #f5f5f5;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 12v-1a3 3 0 00-3-3H6a3 3 0 00-3 3v1m17 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m17 0h-4l-2 3H9l-2-3H3"/></svg>
            <span style="font-size: 12px; font-weight: 600; color: #1f2937;">定制礼包</span>
          </div>
          <div
            v-if="giftDaily.enabled"
            style="padding: 10px 14px; cursor: pointer;"
            :style="{ borderBottom: giftBirthday.enabled ? '1px solid #f5f5f5' : 'none' }"
            @click="handleDailyGift"
          >
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
              <div style="width: 22px; height: 22px; border-radius: 7px; background: rgba(59,130,246,.1); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              </div>
              <span style="font-size: 12px; font-weight: 600; color: #1f2937;">定时礼包</span>
              <div style="margin-left: auto; flex-shrink: 0;">
                <span v-if="giftDaily.canClaim" style="padding: 3px 10px; border-radius: 12px; background: #3B82F6; color: #fff; font-size: 10px; font-weight: 600;">领</span>
                <span v-else style="font-size: 10px; color: #bbb;">{{ giftDaily.nextClaimDate || '已领' }}</span>
              </div>
            </div>
            <div style="font-size: 10px; color: #999;">每{{ giftDaily.intervalDays }}天 · {{ giftDaily.desc }}</div>
          </div>
          <div
            v-if="giftBirthday.enabled"
            style="padding: 10px 14px; cursor: pointer;"
            @click="handleBirthdayGift"
          >
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
              <div style="width: 22px; height: 22px; border-radius: 7px; background: rgba(236,72,153,.1); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#EC4899" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
              </div>
              <span style="font-size: 12px; font-weight: 600; color: #1f2937;">生日礼包</span>
              <div style="margin-left: auto; flex-shrink: 0;">
                <span v-if="giftBirthday.canClaim" style="padding: 3px 10px; border-radius: 12px; background: linear-gradient(135deg, #EC4899, #F472B6); color: #fff; font-size: 10px; font-weight: 600;">领</span>
                <span v-else style="font-size: 10px; color: #bbb;">已领</span>
              </div>
            </div>
            <div style="font-size: 10px; color: #999;">{{ giftBirthday.desc }}</div>
          </div>
        </div>
      </div>

      <!-- 我的账户卡片 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; padding: 16px">
        <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 12px"
          >我的账户</div
        >
        <div style="display: grid; grid-template-columns: repeat(4, 1fr)">
          <div
            style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer"
            @click="handleAccountItem('balance')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? balanceStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">余额</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('points')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? pointsStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">积分</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('fans')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{ isLogin ? (userStore.info.fansCount || userStore.info.fans_count || 0) : '--' }}</span>
            <span style="font-size: 10px; color: #9ca3af">粉丝</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('purchases')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{ isLogin ? (userStore.info.purchaseCount || userStore.info.purchase_count || 0) : '--' }}</span>
            <span style="font-size: 10px; color: #9ca3af">付费</span>
          </div>
        </div>
      </div>

      <!-- 功能图标 -->
      <div style="background: #fff; margin: 0 12px; border-radius: 16px; padding: 20px 0 8px 0; overflow: hidden">
        <div
          ref="iconScrollRef"
          style="display: flex; overflow-x: auto; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding: 0 4px"
          @scroll="onIconScroll"
        >
          <div
            v-for="(page, pi) in funcIconPages"
            :key="pi"
            style="flex: 0 0 100%; scroll-snap-align: start; display: grid; grid-template-columns: repeat(4, 1fr); row-gap: 20px; padding: 0 4px"
          >
            <div
              v-for="item in page"
              :key="item.label || ('_empty_'+pi)"
              style="
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 6px;
                cursor: pointer;
              "
              :style="{ visibility: item.label ? 'visible' : 'hidden' }"
              @click="item.label && handleFuncIcon(item)"
            >
              <div
                style="
                  width: 44px;
                  height: 44px;
                  border-radius: 8px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                "
                :style="{ background: item.label ? item.bg : 'transparent' }"
              >
                <svg
                  v-if="item.label && !item.emojiIcon"
                  style="width: 20px; height: 20px; color: #fff"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path :d="item.icon" />
                </svg>
                <span v-if="item.label && item.emojiIcon" style="font-size: 20px; line-height: 1;">{{ item.icon }}</span>
              </div>
              <span style="font-size: 11px; color: #374151">{{ item.label }}</span>
          </div>
        </div>
        <button
          @click="goSettings"
          style="
            flex-shrink: 0;
            padding: 6px;
            background: none;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
          "
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
        </button>
      </div>
        <div
          style="
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            padding: 12px 0;
          "
        >
          <div
            v-for="(_, pi) in funcIconPages"
            :key="pi"
            :style="{
              width: activeIconPage === pi ? '12px' : '6px',
              height: activeIconPage === pi ? '4px' : '6px',
              borderRadius: '999px',
              background: activeIconPage === pi ? '#00bfa5' : '#e5e7eb',
              transition: 'all 0.2s',
            }"
          />
        </div>
        <div
          v-if="bannerConfig.show"
          style="
            margin: 0 4px 12px 4px;
            background: var(--app-page-bg);
            border-radius: 12px;
            display: flex;
            align-items: center;
            padding: 10px 12px;
            gap: 8px;
            cursor: pointer;
          "
          @click="goBannerUrl"
        >
          <svg
            style="width: 16px; height: 16px; color: #6b7280"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fill-rule="evenodd"
              d="M18 3a1 1 0 00-1.447-.894L8.763 6H5a3 3 0 000 6h.28l1.771 5.316A1 1 0 008 18h1a1 1 0 001-1v-4.382l6.553 3.276A1 1 0 0018 15V3z"
              clip-rule="evenodd"
            />
          </svg>
          <span
            style="
              flex: 1;
              font-size: 12px;
              color: #6b7280;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            "
            >{{ bannerConfig.text }}</span
          >
          <svg
            style="width: 14px; height: 14px; color: #9ca3af"
            fill="none"
            stroke="currentColor"
            stroke-width="2.5"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 菜单列表 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; overflow: hidden">
        <div
          v-for="(item, idx) in computedMenuItems"
          :key="item.label"
          style="display: flex; align-items: center; padding: 14px 16px; cursor: pointer"
          :style="{
            borderBottom: idx < computedMenuItems.length - 1 ? '1px solid #f9fafb' : 'none'
          }"
          @click="handleMenuItem(item)"
        >
          <svg
            style="width: 20px; height: 20px; margin-right: 12px; flex-shrink: 0"
            :style="{ color: item.highlight ? '#00BFA5' : '#9ca3af' }"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path :d="item.icon" />
          </svg>
          <span
            style="flex: 1; font-size: 14px"
            :style="{
              color: item.highlight ? '#00BFA5' : '#374151',
              fontWeight: item.highlight ? '600' : '400'
            }"
            >{{ item.label }}</span
          >
          <svg
            style="width: 16px; height: 16px; color: #d1d5db"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>

    <!-- 我的收藏弹窗 -->
    <div
      v-if="showFavoritesDialog"
      style="position: fixed; inset: 0; background: #f5f6fa; z-index: 100; display: flex; flex-direction: column; overflow: hidden;"
    >
      <div style="background: #fff; flex-shrink: 0">
        <div style="display: flex; align-items: center; justify-content: space-between; height: 46px; padding: 0 16px; border-bottom: 1px solid #f0f0f0;">
          <button style="background: none; border: none; padding: 4px; color: #333; cursor: pointer;" @click="showFavoritesDialog = false">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          <span style="font-size: 17px; font-weight: 600; color: #1a1a2e;">我的收藏</span>
          <button style="background: #EC4899; color: #fff; border: none; padding: 6px 14px; border-radius: 16px; font-size: 13px; cursor: pointer;" @click="createFavoriteGroup">新建分组</button>
        </div>
        <!-- 分组横滚 -->
        <div style="padding: 10px 16px; display: flex; gap: 8px; overflow-x: auto; white-space: nowrap;">
          <button
            style="padding: 6px 14px; border-radius: 16px; font-size: 13px; border: none; cursor: pointer; white-space: nowrap; flex-shrink: 0;"
            :style="favActiveGroupId === 0 ? { background: '#EC4899', color: '#fff', fontWeight: '600' } : { background: '#f2f3f6', color: '#666' }"
            @click="switchFavoriteGroup(0)"
          >全部</button>
          <button
            v-for="g in favoriteGroups"
            :key="g.id"
            style="padding: 6px 14px; border-radius: 16px; font-size: 13px; border: none; cursor: pointer; white-space: nowrap; flex-shrink: 0; position: relative;"
            :style="favActiveGroupId === g.id ? { background: '#EC4899', color: '#fff', fontWeight: '600' } : { background: '#f2f3f6', color: '#666' }"
            @click="switchFavoriteGroup(g.id)"
          >
            {{ g.name }}({{ g.count }})
            <span v-if="favActiveGroupId === g.id" style="display: inline-flex; gap: 2px; margin-left: 4px;">
              <svg @click.stop="renameFavoriteGroup(g)" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="opacity: .7;"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              <svg @click.stop="deleteFavoriteGroup(g)" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="opacity: .7;"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </span>
          </button>
        </div>
      </div>

      <div style="flex: 1; overflow-y: auto; padding: 12px 14px;">
        <div v-if="favLoading" style="text-align: center; padding: 60px 0; color: #999;">加载中...</div>
        <template v-else>
          <div v-if="favoriteCollections.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 0;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom: 12px;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
            <div style="font-size: 14px; color: #999;">还没有收藏合集</div>
          </div>
          <div
            v-for="c in favoriteCollections"
            :key="c.fav_id"
            style="background: #fff; border-radius: 14px; margin-bottom: 14px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 12px rgba(0,0,0,.06);"
            @click="openFavItem(c)"
          >
            <div v-if="c.item_type === 'collection' && c.cover_image" style="width: 100%; height: 140px; overflow: hidden;">
              <img :src="c.cover_image" style="width: 100%; height: 100%; object-fit: cover;"  loading="lazy" />
            </div>
            <div style="padding: 14px;">
              <div style="display: flex; align-items: flex-start; justify-content: space-between;">
                <div style="flex: 1; min-width: 0;">
                  <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                    <span style="font-size: 10px; padding: 1px 6px; border-radius: 6px; font-weight: 500;"
                      :style="c.item_type === 'post' ? { background: '#e8f4fd', color: '#1890ff' } : { background: '#fce7f3', color: '#EC4899' }"
                    >{{ c.item_type === 'post' ? '帖子' : '合集' }}</span>
                  </div>
                  <div style="font-size: 16px; font-weight: 700; color: #1a1a2e; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">{{ c.title }}</div>
                  <div v-if="c.description" style="font-size: 13px; color: #999; margin-top: 4px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">{{ c.description }}</div>
                  <div style="display: flex; gap: 12px; margin-top: 8px; font-size: 12px; color: #999;">
                    <span v-if="c.item_type === 'collection'">{{ c.post_count }}篇</span>
                    <span>{{ c.view_count || 0 }}浏览</span>
                  </div>
                </div>
              </div>
              <div style="display: flex; gap: 8px; margin-top: 12px; padding-top: 10px; border-top: 1px solid #f5f5f5;">
                <button style="flex: 1; padding: 6px 0; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; color: #6366f1; font-size: 12px; cursor: pointer;" @click.stop="moveFavItem(c)">移动分组</button>
                <button style="flex: 1; padding: 6px 0; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; color: #f56c6c; font-size: 12px; cursor: pointer;" @click.stop="unfavoriteItem(c)">取消收藏</button>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>

    <!-- 分组操作弹窗 -->
    <div
      v-if="showGroupNameDialog"
      style="position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 110; display: flex; align-items: center; justify-content: center;"
      @click.self="showGroupNameDialog = false"
    >
      <div style="background: #fff; border-radius: 16px; width: 300px; padding: 24px 20px 20px; box-shadow: 0 12px 40px rgba(0,0,0,.15);">
        <div style="font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 16px;">{{ groupDialogTitle }}</div>
        <input
          ref="groupDialogInput"
          v-model="groupDialogValue"
          :placeholder="groupDialogPlaceholder"
          style="width: 100%; padding: 10px 14px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 15px; outline: none; box-sizing: border-box; transition: border-color .15s;"
          @keyup.enter="confirmGroupDialog"
          @focus="$event.target.style.borderColor='#EC4899'"
          @blur="$event.target.style.borderColor='#e5e7eb'"
        />
        <div style="display: flex; gap: 10px; margin-top: 18px;">
          <button style="flex: 1; padding: 10px 0; border: none; border-radius: 10px; background: #f3f4f6; color: #666; font-size: 14px; cursor: pointer;" @click="showGroupNameDialog = false">取消</button>
          <button style="flex: 1; padding: 10px 0; border: none; border-radius: 10px; background: #EC4899; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="confirmGroupDialog">确定</button>
        </div>
      </div>
    </div>

    <!-- 卡密兑换弹窗 -->
    <div
      v-if="showCardKeyDialog"
      style="
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
      "
      @click.self="showCardKeyDialog = false"
    >
      <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 16px"
          >卡密兑换</div
        >
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.cardNo"
            placeholder="请输入卡号"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.password"
            type="text"
            placeholder="请输入卡密密码"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div v-if="cardKeyMsg" style="font-size: 12px; color: #00bfa5; margin-bottom: 8px">{{
          cardKeyMsg
        }}</div>
        <div style="display: flex; gap: 10px">
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #f3f4f6;
              color: #374151;
              cursor: pointer;
            "
            @click="showCardKeyDialog = false"
            >取消</button
          >
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #00bfa5;
              color: #fff;
              cursor: pointer;
            "
            :disabled="cardKeyLoading"
            @click="handleRedeemCardKey"
            >{{ cardKeyLoading ? '兑换中...' : '确认兑换' }}</button
          >
        </div>
      </div>
    </div>

    <!-- 底部5栏Tab -->
    <div
      style="
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 1px solid #f3f4f6;
        display: flex;
        align-items: center;
        justify-content: space-around;
        padding: 4px 0 calc(max(6px, env(safe-area-inset-bottom)));
        z-index: 10;
      "
    >
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/browse')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M4 21V9l8-6 8 6v12h-6v-7h-4v7H4z" />
        </svg>
        <span style="font-size: 10px">首页</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/category')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z" />
        </svg>
        <span style="font-size: 10px">应用</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/updates')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM4.5 9c.83 0 1.5-.67 1.5-1.5S5.33 6 4.5 6 3 6.67 3 7.5 3.67 9 4.5 9zm15 0c.83 0 1.5-.67 1.5-1.5S20.33 6 19.5 6 18 6.67 18 7.5 18.67 9 19.5 9zm-15 6c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5zm15 0c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5z" />
        </svg>
        <span style="font-size: 10px">社区</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/game')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z" />
        </svg>
        <span style="font-size: 10px">发现</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #00bfa5;
        "
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
        </svg>
        <span style="font-size: 10px">我的</span>
      </div>
    </div>

    <div v-if="showSitePopup" style="position:fixed;inset:0;z-index:200;display:flex;align-items:center;justify-content:center" @click.self="showSitePopup = false">
      <div style="position:absolute;inset:0;background:rgba(0,0,0,0.45)" />
      <div style="position:relative;background:#fff;border-radius:14px;width:90%;max-width:360px;max-height:70vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,0.15)">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:16px;border-bottom:1px solid #f0f0f0">
          <span style="font-size:16px;font-weight:600;color:#1a1a2e">{{ sitePopupTitle }}</span>
          <button style="background:none;border:none;padding:4px;color:#999;cursor:pointer" @click="showSitePopup = false">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div style="flex:1;overflow-y:auto;padding:16px;font-size:14px;color:#333;line-height:1.8;white-space:pre-wrap;word-break:break-word" v-html="sanitizeHtml(sitePopupContent)" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, onMounted, watch } from 'vue'
  import { useRouter, useRoute } from 'vue-router'
  import { useUserStore } from '@/store/modules/user'
  import { fetchRedeemCardKey, fetchGetUserInfo } from '@/api/appstore'
  import { fetchPluginInject } from '@/api/operation'
  import { fetchUserAvatarFrames } from '@/api/avatar-frame'
  import request from '@/utils/http'
  import { sanitizeHtml } from '@/utils/ui/sanitize'

  const router = useRouter()
  const route = useRoute()
  const userStore = useUserStore()

  const showCardKeyDialog = ref(false)
  const cardKeyForm = ref({ cardNo: '', password: '' })
  const cardKeyMsg = ref('')
  const cardKeyLoading = ref(false)

  // 我的收藏
  const showFavoritesDialog = ref(false)
  const favoriteGroups = ref<any[]>([])
  const favoriteCollections = ref<any[]>([])
  const favLoading = ref(false)
  const favActiveGroupId = ref(0) // 0 = 全部
  const showGroupNameDialog = ref(false)
  const groupDialogTitle = ref('')
  const groupDialogValue = ref('')
  const groupDialogPlaceholder = ref('')
  const groupDialogCallback = ref<((value: string) => void) | null>(null)
  const groupDialogInput = ref<HTMLInputElement | null>(null)
  const activeFrameUrl = ref('')
  const giftDaily = ref<{ enabled: boolean; canClaim: boolean; nextClaimDate: string; intervalDays: number; desc: string }>({ enabled: false, canClaim: false, nextClaimDate: '', intervalDays: 1, desc: '' })
  const giftBirthday = ref<{ enabled: boolean; canClaim: boolean; desc: string }>({ enabled: false, canClaim: false, desc: '' })
  const giftClaiming = ref(false)

  const isLogin = computed(() => userStore.isLogin)
  const userInfo = computed(() => userStore.info || {})

  const isAdmin = computed(() => {
    const roles: string[] = userStore.info.roles || []
    return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
  })

  const expCurrent = ref(0)
  const expMax = ref(1000)
  const expLevelName = ref('Lv.1')
  const expLevelIcon = ref('')
  const expLevelTextColor = ref('#FFFFFF')
  const expLevelBgColor = ref('#508DFF')
  const siteUrlMap = ref<Record<string, string>>({})
  const showSitePopup = ref(false)
  const sitePopupTitle = ref('')
  const sitePopupContent = ref('')

  const bannerConfig = ref<{ show: boolean; text: string; url: string }>({
    show: true,
    text: '全站规则，快来看看，不然就亏大了',
    url: '/help/rules'
  })

  const loadBannerConfig = async () => {
    try {
      const res: any = await fetchPluginInject()
      const plugins = res?.data || res || []
      const fp = Array.isArray(plugins) ? plugins.find((p: any) => p.name === 'feature-panel') : plugins['feature-panel']
      if (fp?.config?.mineBanner) {
        bannerConfig.value = { ...bannerConfig.value, ...fp.config.mineBanner }
      }
    } catch {}
  }

  const goBannerUrl = () => {
    const url = bannerConfig.value.url
    if (!url) return
    if (url.startsWith('http')) {
      window.open(url, '_blank')
    } else {
      router.push(url)
    }
  }

  onMounted(() => {
    loadBannerConfig()
    loadActiveFrame()
    refreshUserInfo()
    loadGiftStatus()
    loadSiteUrls()
  })

  const loadSiteUrls = async () => {
    try {
      const res: any = await request.get({ url: '/api/sys-config/list' })
      if (Array.isArray(res)) {
        const map: Record<string, string> = {}
        for (const item of res) {
          if (item.config_key && item.config_value) map[item.config_key] = item.config_value
        }
        siteUrlMap.value = map
      }
    } catch {}
  }

  const loadGiftStatus = async () => {
    if (!isLogin.value) return
    try {
      const res: any = await request.get({ url: '/api/membership/gift-status', showErrorMessage: false })
      if (res) {
        giftDaily.value = res.daily || { enabled: false, canClaim: false, nextClaimDate: '', intervalDays: 1, desc: '' }
        giftBirthday.value = res.birthday || { enabled: false, canClaim: false, desc: '' }
      }
    } catch {}
  }

  const handleDailyGift = async () => {
    if (!giftDaily.value.canClaim || giftClaiming.value) return
    giftClaiming.value = true
    try {
      await request.post({ url: '/api/membership/claim-daily-gift', showSuccessMessage: true })
      await loadGiftStatus()
      await refreshUserInfo()
    } catch { /* error message shown by HTTP interceptor */ }
    finally { giftClaiming.value = false }
  }

  const handleBirthdayGift = async () => {
    if (!giftBirthday.value.canClaim || giftClaiming.value) return
    giftClaiming.value = true
    try {
      await request.post({ url: '/api/membership/claim-birthday-gift', showSuccessMessage: true })
      await loadGiftStatus()
      await refreshUserInfo()
    } catch { /* error message shown by HTTP interceptor */ }
    finally { giftClaiming.value = false }
  }

  const refreshUserInfo = async () => {
    try {
      const data = await fetchGetUserInfo()
      userStore.setUserInfo(data)
    } catch {}
  }

  const loadActiveFrame = async () => {
    if (!isLogin.value) return
    try {
      const res: any = await fetchUserAvatarFrames()
      const active = res.frames?.find((f: any) => f.isActive)
      activeFrameUrl.value = active?.image_url || ''
    } catch {}
  }

  const levelName = computed(() => {
    if (!isLogin.value) return 'Lv.0'
    return expLevelName.value || 'Lv.1'
  })

  const memberLevelName = computed(() => {
    if (!isLogin.value) return '普通会员'
    return userStore.info.levelName || '普通会员'
  })

  const expDisplay = computed(() => {
    if (!isLogin.value) return '0/1000'
    return `${expCurrent.value || 0}/${expMax.value}`
  })

  const expPercent = computed(() => {
    if (!isLogin.value || !expMax.value) return 0
    return Math.min(100, Math.round((expCurrent.value / expMax.value) * 100))
  })

  const fetchExpLevels = async () => {
    try {
      const { fetchExpLevelList } = await import('@/api/operation')
      const data: any = await fetchExpLevelList()
      const levels = data?.records || data || []
      if (levels.length > 0) {
        levels.sort((a: any, b: any) => a.level - b.level)
        const exp = userStore.info.experience || 0
        expCurrent.value = exp
        let current = levels[0]
        let next: any = null
        for (const l of levels) {
          const req = l.expRequired || l.exp_required || 0
          if (req <= exp) current = l
          if (req > exp && !next) next = l
        }
        expLevelName.value = current.name || current.expLevelName || 'Lv.1'
        const icon = current.icon || ''
        expLevelIcon.value = (icon && (icon.startsWith('http') || icon.startsWith('/') || icon.startsWith('data:'))) ? icon : ''
        expLevelTextColor.value = current.textColor || current.text_color || '#FFFFFF'
        expLevelBgColor.value = current.bgColor || current.bg_color || '#508DFF'
        if (next) {
          expMax.value = next.expRequired || next.exp_required || 1000
        } else {
          expMax.value = levels[levels.length - 1].expRequired || levels[levels.length - 1].exp_required || 1000
        }
      }
    } catch (_e: unknown) {
      void _e
    }
  }

  fetchExpLevels()

  const formatNum = (val: number): string => {
    if (val >= 10000) {
      const w = Math.floor(val / 100) / 100
      return w % 1 === 0 ? `${w}万` : `${w.toFixed(2)}万`
    }
    return Number.isInteger(val) ? `${val}` : val.toFixed(2)
  }

  const balanceStr = computed(() => {
    if (!isLogin.value) return '--'
    const b = Number(userStore.info.balance || 0)
    return b >= 10000 ? formatNum(b) : b.toFixed(2)
  })

  const pointsStr = computed(() => {
    if (!isLogin.value) return '--'
    const p = Number(userStore.info.points || 0)
    return formatNum(p)
  })

  const membershipExpireStr = computed(() => {
    const t = userStore.info.expireTime
    if (!t) return ''
    try {
      const d = new Date(t)
      if (isNaN(d.getTime())) return ''
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} 到期`
    } catch { return '' }
  })

  const activeIconPage = ref(0)
  const iconScrollRef = ref<HTMLElement | null>(null)

  const onIconScroll = () => {
    const el = iconScrollRef.value
    if (!el) return
    const pageWidth = el.clientWidth
    const scrollLeft = el.scrollLeft
    const page = Math.round(scrollLeft / pageWidth)
    activeIconPage.value = page
  }

  const funcIcons = [
    {
      label: '应用投稿',
      bg: '#3B82F6',
      icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4'
    },
    {
      label: '我的帖子',
      bg: '#7C3AED',
      icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10'
    },
    {
      label: '草稿箱',
      bg: '#6366F1',
      icon: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z M14 2v6h6 M12 18v-6 M9 15h6'
    },
    {
      label: '我的合集',
      bg: '#8B5CF6',
      icon: 'M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z'
    },
    {
      label: '我的收藏',
      bg: '#EC4899',
      icon: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'
    },
    {
      label: '签到',
      bg: '#F59E0B',
      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2zm3-6h.01M9 12l2 2 4-4'
    },
    {
      label: '挂件管理',
      bg: '#22C55E',
      icon: 'M4 4v3a2 2 0 002 2h9a1 1 0 01.987.839l.73 4A2 2 0 0115.73 16H4a2 2 0 01-2-2V6a2 2 0 012-2m0 0l.804-2.413A1 1 0 015.723 3H18a2 2 0 012 2v8m-5 1h5a2 2 0 012 2v1a2 2 0 01-2 2h-1a2 2 0 01-2-2v-1m0-2h.01'
    },
    {
      label: '排行榜',
      bg: '#EC4899',
      icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'
    },
    {
      label: '邀请福利',
      bg: '#10B981',
      icon: 'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z'
    },
    {
      label: '优惠券中心',
      bg: '#f97316',
      icon: 'M20 12v-1.23a1 1 0 00-1.57-.82L15 12m-1.57 2.82A1 1 0 0112 14V9m0-6a9 9 0 100 18 9 9 0 000-18z M4.93 4.93a9.97 9.97 0 000 14.14M5.64 5.64a8.97 8.97 0 000 12.72M15 19a9.05 9.05 0 013-.41'
    },
    {
      label: '数据明细',
      bg: '#F97316',
      icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12'
    },
    {
      label: '数据统计',
      bg: '#FF5722',
      icon: 'M4 4h16v16H4V4z M7 16v-3 M11 16V10 M15 16v-5 M19 16V8 M8 8h3 M8 11h2'
    },
    {
      label: '开发者分析',
      bg: '#00BCD4',
      icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'
    }
  ]

  const funcIconPages = computed(() => {
    const items = [...funcIcons]
    const chunkSize = 8
    const pages: any[][] = []
    for (let i = 0; i < items.length; i += chunkSize) {
      const page = items.slice(i, i + chunkSize)
      while (page.length < chunkSize) page.push({ label: '', icon: '' })
      pages.push(page)
    }
    return pages
  })

  const menuItems = [
    {
      label: '管理中心',
      icon: 'M5.12 14V7a7 7 0 0113.76 0v7m-3.24 0v-7a4.5 4.5 0 00-9 0v7m13-3h1a2 2 0 012 2v4a2 2 0 01-2 2h-14a2 2 0 01-2-2v-4a2 2 0 012-2h1 M12 17v-3 M5 12h14',
      highlight: true,
      adminOnly: true
    },
    {
      label: '后台管理',
      icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '浏览足迹',
      icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
    },
    {
      label: '卡密兑换',
      icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'
    },
    {
      label: '交流群组',
      icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'
    },
    {
      label: '联系我们',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z'
    },
    {
      label: '回收站',
      icon: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16',
      loginOnly: true
    },
    {
      label: '退出登录',
      icon: 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1',
      loginOnly: true
    }
  ]

  const computedMenuItems = computed(() => {
    const items = [...menuItems]
    return items.filter((item) => {
      if (item.adminOnly && !isAdmin.value) return false
      if (item.loginOnly && !isLogin.value) return false
      return true
    })
  })

  const handleAccountItem = (type: string) => {
    if (!isLogin.value) {
      router.push('/appstore/browse/login')
      return
    }
    if (type === 'balance' || type === 'points') {
      router.push('/appstore/assets')
      return
    }
    const uid = userStore.info.userId || 0
    router.push(`/appstore/records?type=${type}&userId=${uid}`)
  }

  const handleFuncIcon = (item: any) => {
    if (item.label === '应用投稿') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/submissions')
    } else if (item.label === '签到') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/checkin')
    } else if (item.label === '邀请福利') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/invite')
    } else if (item.label === '数据明细') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      const uid = userStore.info.userId || 0
      router.push(`/appstore/records?type=overview&userId=${uid}`)
    } else if (item.label === '优惠券中心') {
      router.push('/appstore/coupon')
    } else if (item.label === '排行榜') {
      router.push('/appstore/ranking')
    } else if (item.label === '浏览足迹') {
      router.push('/appstore/footprints')
    } else if (item.label === '头像管理') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/avatar-frame')
    } else if (item.label === '个人空间') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/personal-space')
    } else if (item.label === '我的认证') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/verification')
    } else if (item.label === '我的帖子') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/community/my-collections')
    } else if (item.label === '我的合集') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/my-collections?tab=mine')
    } else if (item.label === '草稿箱') {
      router.push('/appstore/drafts')
    } else if (item.label === '我的收藏') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/community/my-favorites')
    } else if (item.label === '收货地址') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/addresses')
    } else if (item.label === '数据统计') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/dashboard-stats')
    } else if (item.label === '开发者分析') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/developer-analytics')
    } else if (item.label === '挂件管理') {
      router.push('/appstore/avatar-frame')
    }
  }

  const goExperience = () => {
    router.push('/appstore/experience')
  }

  const goSettings = () => {
    router.push('/appstore/settings')
  }

  const handleAvatarClick = () => {
    if (!isLogin.value) {
      router.push('/appstore/browse/login')
    } else {
      router.push('/appstore/profile')
    }
  }

  const handleMembershipClick = () => {
    router.push('/appstore/membership')
  }

  const handleMenuItem = (item: any) => {
    if (item.label === '卡密兑换') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      cardKeyForm.value = { cardNo: '', password: '' }
      cardKeyMsg.value = ''
      showCardKeyDialog.value = true
      return
    }
    if (item.label === '管理中心') {
      router.push('/appstore/admin-center')
    } else if (item.label === '后台管理') {
      router.push('/dashboard/console')
    } else if (item.label === '退出登录') {
      userStore.logOut()
      router.replace('/appstore/mine')
    } else if (item.label === '浏览足迹') {
      router.push('/appstore/footprints')
    } else if (item.label === '联系我们') {
      sitePopupTitle.value = '联系我们'
      sitePopupContent.value = siteUrlMap.value.site_contact_content || ''
      if (sitePopupContent.value) { showSitePopup.value = true; return }
      const url = siteUrlMap.value.site_contact_url
      if (url) { window.open(url, '_blank'); return }
      router.push('/appstore/discover-chat')
    } else if (item.label === '交流群组') {
      sitePopupTitle.value = '交流群组'
      sitePopupContent.value = siteUrlMap.value.site_community_content || ''
      if (sitePopupContent.value) { showSitePopup.value = true; return }
      const url = siteUrlMap.value.site_community_url
      if (url) { window.open(url, '_blank'); return }
      router.push('/appstore/chatrooms')
    } else if (item.label === '回收站') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/recycle')
    }
  }

  const handleRedeemCardKey = async () => {
    if (!cardKeyForm.value.cardNo || !cardKeyForm.value.password) {
      cardKeyMsg.value = '请输入卡号和密码'
      return
    }
    cardKeyLoading.value = true
    cardKeyMsg.value = ''
    try {
      const data = await fetchRedeemCardKey({
        cardNo: cardKeyForm.value.cardNo,
        password: cardKeyForm.value.password,
        userId: userStore.info.userId || 0,
        userName: userStore.info.userName || ''
      })
      cardKeyMsg.value = data.msg || '兑换成功'
      if (data.code === 200) {
        showCardKeyDialog.value = false
      }
    } catch (e: any) {
      cardKeyMsg.value = e?.msg || '兑换失败'
    } finally {
      cardKeyLoading.value = false
    }
  }

  // === 我的收藏 ===
  function openGroupDialog(title: string, placeholder: string, cb: (value: string) => void, initValue = '') {
    groupDialogTitle.value = title
    groupDialogPlaceholder.value = placeholder
    groupDialogValue.value = initValue
    groupDialogCallback.value = cb
    showGroupNameDialog.value = true
    setTimeout(() => groupDialogInput.value?.focus(), 100)
  }

  function confirmGroupDialog() {
    const val = groupDialogValue.value.trim()
    if (!val) return
    showGroupNameDialog.value = false
    groupDialogCallback.value?.(val)
  }

  async function loadFavoriteGroupsData() {
    favLoading.value = true
    try {
      const request = (await import('@/utils/http')).default
      const res: any = await request.get({ url: '/api/community/favorite/groups' })
      favoriteGroups.value = res || []
    } catch { favoriteGroups.value = [] }
    await loadFavoriteCollections()
    favLoading.value = false
  }

  async function loadFavoriteCollections() {
    const request = (await import('@/utils/http')).default
    const groupId = favActiveGroupId.value
    const url = groupId > 0
      ? `/api/community/favorite/items?groupId=${groupId}&pageSize=50`
      : '/api/community/favorite/items?pageSize=50'
    try {
      const res: any = await request.get({ url })
      favoriteCollections.value = res?.list || []
    } catch { favoriteCollections.value = [] }
  }

  function switchFavoriteGroup(gid: number) {
    if (favActiveGroupId.value === gid) return
    favActiveGroupId.value = gid
    loadFavoriteCollections()
  }

  function createFavoriteGroup() {
    openGroupDialog('新建分组', '请输入分组名称', async (name) => {
      try {
        const request = (await import('@/utils/http')).default
        const res: any = await request.post({ url: '/api/community/favorite/groups', data: { name } })
        if (res) favoriteGroups.value.push(res)
      } catch (e: any) { alert(e.message || '创建失败') }
    })
  }

  function renameFavoriteGroup(g: any) {
    openGroupDialog('修改分组名称', '请输入新名称', async (name) => {
      if (name === g.name) return
      try {
        const request = (await import('@/utils/http')).default
        await request.put({ url: `/api/community/favorite/groups/${g.id}`, data: { name } })
        g.name = name
      } catch (e: any) { alert(e.message || '修改失败') }
    }, g.name)
  }

  async function deleteFavoriteGroup(g: any) {
    if (!confirm(`确定删除分组「${g.name}」？分组内的合集将移入默认收藏夹。`)) return
    try {
      const request = (await import('@/utils/http')).default
      await request.del({ url: `/api/community/favorite/groups/${g.id}` })
      favoriteGroups.value = favoriteGroups.value.filter(x => x.id !== g.id)
      if (favActiveGroupId.value === g.id) {
        favActiveGroupId.value = 0
        loadFavoriteCollections()
      }
    } catch (e: any) { alert(e.message || '删除失败') }
  }

  async function unfavoriteCollection(c: any) {
    if (!confirm(`确定从收藏中移除「${c.title}」？`)) return
    try {
      const request = (await import('@/utils/http')).default
      await request.del({ url: `/api/community/collection/${c.id}/favorite` })
      favoriteCollections.value = favoriteCollections.value.filter(x => x.id !== c.id)
      const g = favoriteGroups.value.find(x => x.id === (c.group_id || favActiveGroupId.value))
      if (g && g.count > 0) g.count--
    } catch (e: any) { alert(e.message || '取消收藏失败') }
  }

  function moveFavItem(c: any) {
    const otherGroups = favoriteGroups.value.filter(g => g.id !== (c.group_id || favActiveGroupId.value))
    const listStr = otherGroups.map((g: any) => g.name).join('、')
    openGroupDialog(
      '移动收藏到',
      otherGroups.length ? `现有分组: ${listStr}` : '输入新分组名称',
      async (name) => {
        let targetGroup = favoriteGroups.value.find(g => g.name === name)
        if (!targetGroup) {
          try {
            const request = (await import('@/utils/http')).default
            const res: any = await request.post({ url: '/api/community/favorite/groups', data: { name } })
            if (res) {
              favoriteGroups.value.push(res)
              targetGroup = res
            }
          } catch { return }
        }
        try {
          const request = (await import('@/utils/http')).default
          if (c.item_type === 'post') {
            await request.post({ url: `/api/community/post/${c.id}/favorite`, data: { groupId: targetGroup.id } })
          } else {
            await request.post({ url: '/api/community/favorite/move', data: { collectionIds: [c.id], targetGroupId: targetGroup.id } })
          }
          favoriteCollections.value = favoriteCollections.value.filter(x => x.fav_id !== c.fav_id)
          const oldG = favoriteGroups.value.find(x => x.id === (c.group_id || favActiveGroupId.value))
          if (oldG && oldG.count > 0) oldG.count--
          const newG = favoriteGroups.value.find(x => x.id === targetGroup.id)
          if (newG) newG.count = (newG.count || 0) + 1
        } catch (e: any) { alert(e.message || '移动失败') }
      }
    )
  }

  async function unfavoriteItem(c: any) {
    if (!confirm(`确定移除收藏「${c.title}」？`)) return
    try {
      const request = (await import('@/utils/http')).default
      if (c.item_type === 'post') {
        await request.del({ url: `/api/community/post/${c.id}/favorite` })
      } else {
        await request.del({ url: `/api/community/collection/${c.id}/favorite` })
      }
      favoriteCollections.value = favoriteCollections.value.filter(x => x.fav_id !== c.fav_id)
      const g = favoriteGroups.value.find(x => x.id === (c.group_id || favActiveGroupId.value))
      if (g && g.count > 0) g.count--
    } catch (e: any) { alert(e.message || '取消收藏失败') }
  }

  function openFavItem(c: any) {
    showFavoritesDialog.value = false
    if (c.item_type === 'post') {
      router.push(`/community/post/${c.id}`)
    } else {
      router.push(`/community/collection/${c.id}`)
    }
  }

</script>

<style scoped>
@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
