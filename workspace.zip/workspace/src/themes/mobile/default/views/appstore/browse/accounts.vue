<template>
  <div class="page">
    <div class="top-bar">
      <div class="back-btn" @click="$router.back()">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="20" height="20">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
        </svg>
      </div>
      <div class="top-title">其他账户</div>
    </div>

    <div class="card-container">
      <div class="card-header">
        <span class="card-header-title">我的账户</span>
        <span class="card-header-toggle">收起 <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="12" height="12"><path d="M18 15l-6-6-6 6"/></svg></span>
      </div>

      <div
        v-for="(acc, i) in accounts"
        :key="acc.key"
        class="acct-card"
        :class="acc.cardClass"
        :style="acc.cardBg ? { background: acc.cardBg } : {}"
        @click="goCurrency(acc.key)"
      >
        <div class="acct-body">
          <div class="acct-left">
            <div class="acct-circle"><span class="acct-circle-text" :style="{ color: acc.color }">{{ acc.icon }}</span></div>
            <div>
              <div class="acct-name">{{ acc.name }}</div>
              <div class="acct-type">{{ acc.type }}</div>
            </div>
          </div>
          <div class="acct-right">
            <div class="acct-balance">{{ fmt(acc.balance, acc.dp) }}</div>
          </div>
        </div>
        <div class="acct-footer">
          <span @click.stop="goCurrency(acc.key)">交易记录</span>
          <span @click.stop="toExchange">资产转换</span>
        </div>
      </div>

      <button class="add-btn">添加账户</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreAccounts' })

const router = useRouter()
const userStore = useUserStore()

const settings = ref<any[]>([])
const balanceMap = ref<Record<string, any>>({})
const loaded = ref(false)

const fmt = (v: number, dp: number) => v.toFixed(dp)

const gradients = [
  { cardClass: 'card-style-0', color: '#f59e0b' },
  { cardClass: 'card-style-1', color: '#8b5cf6' },
  { cardClass: 'card-style-2', color: '#2290ee' },
  { cardClass: 'card-style-3', color: '#10b981' },
  { cardClass: 'card-style-4', color: '#ef4444' },
  { cardClass: 'card-style-5', color: '#ec4899' },
  { cardClass: 'card-style-6', color: '#06b6d4' },
  { cardClass: 'card-style-7', color: '#f97316' },
]

function adjustColor(hex: string, amount: number): string {
  const num = parseInt(hex.replace('#', ''), 16)
  const r = Math.max(0, Math.min(255, ((num >> 16) & 255) + amount))
  const g = Math.max(0, Math.min(255, ((num >> 8) & 255) + amount))
  const b = Math.max(0, Math.min(255, (num & 255) + amount))
  return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1)}`
}

const accounts = computed(() => {
  return settings.value
    .filter((s: any) => s.currency_key !== 'balance')
    .map((s: any, i: number) => {
      const g = gradients[i % gradients.length]
      const customColor = s.card_color
      const bg = customColor
        ? `linear-gradient(180deg, ${customColor} 0%, ${adjustColor(customColor, -20)} 100%)`
        : ''
      const color = customColor || g.color
      const cardClass = customColor ? '' : g.cardClass
      const icon = (s.display_icon || s.display_symbol || s.display_name?.charAt(0) || s.currency_key.charAt(0)).substring(0, 2)
      return {
        key: s.currency_key,
        name: s.display_name || s.currency_key,
        icon,
        type: s.currency_type === 'quota' ? '次数' : '虚拟币',
        balance: balanceMap.value[s.currency_key]?.available || 0,
        dp: s.decimal_places || 0,
        cardClass,
        color,
        cardBg: bg,
      }
    })
})

const goCurrency = (key: string) => {
  if (!userStore.isLogin) return
  router.push({ path: '/appstore/currency-detail', query: { key } })
}

const toExchange = () => {
  router.push('/appstore/exchange')
}

const load = async () => {
  if (loaded.value) return
  try {
    const [sRes, bRes] = await Promise.all([
      request.get<any[]>({ url: '/api/currency-settings' }),
      request.get<any>({ url: '/api/user/currency-balance' }),
    ])
    settings.value = Array.isArray(sRes) ? sRes : []
    const currencies = bRes?.currencies || bRes?.data?.currencies || []
    const map: Record<string, any> = {}
    for (const c of currencies) {
      map[c.currency_key] = c
    }
    balanceMap.value = map
    loaded.value = true
  } catch {}
}

onMounted(load)
</script>

<style scoped>
.page { min-height: 100vh; background: #f8f8fa; }

.top-bar {
  display: flex; align-items: center; height: 48px; padding: 0 12px; background: #fff;
  position: fixed; top: 0; left: 0; right: 0; z-index: 10;
}
.back-btn { cursor: pointer; color: #000; flex-shrink: 0; }
.top-title { flex: 1; text-align: center; font-size: 17px; font-weight: 600; }

.card-container {
  margin: 60px 12px 12px; padding: 16px;
  background: #fff; border-radius: 14px;
}

.card-header {
  display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;
}
.card-header-title { font-size: 16px; font-weight: 500; }
.card-header-toggle { font-size: 13px; color: #9ca3af; display: flex; align-items: center; gap: 2px; }

.acct-card {
  border-radius: 10px; color: #fff; overflow: hidden; margin-bottom: 10px;
  cursor: pointer; -webkit-tap-highlight-color: transparent;
}
/* dynamic card backgrounds via inline style */
.card-style-0 { background: linear-gradient(180deg, #ffaa22 0%, #e68c00 100%); }
.card-style-1 { background: linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%); }
.card-style-2 { background: linear-gradient(180deg, #2290ee 0%, #1573c2 100%); }
.card-style-3 { background: linear-gradient(180deg, #10b981 0%, #059669 100%); }
.card-style-4 { background: linear-gradient(180deg, #ef4444 0%, #dc2626 100%); }
.card-style-5 { background: linear-gradient(180deg, #ec4899 0%, #db2777 100%); }
.card-style-6 { background: linear-gradient(180deg, #06b6d4 0%, #0891b2 100%); }
.card-style-7 { background: linear-gradient(180deg, #f97316 0%, #ea580c 100%); }

.acct-body {
  padding: 14px; display: flex; justify-content: space-between; align-items: flex-start;
}

.acct-left { display: flex; align-items: center; gap: 10px; }

.acct-circle {
  width: 40px; height: 40px; border-radius: 50%; background: #fff;
  display: flex; align-items: center; justify-content: center;
}
.acct-circle-text { font-size: 18px; }

.acct-name { font-size: 15px; font-weight: 500; }
.acct-type { opacity: .85; margin-top: 2px; font-size: 12px; }

.acct-balance { font-size: 15px; }

.acct-footer {
  display: flex; align-items: center; padding: 10px 0; background: rgba(0,0,0,.1); font-size: 13px;
}
.acct-footer span { flex: 1; text-align: center; }

.add-btn {
  width: 100%; border: none; border-radius: 10px;
  background: #ff2b59; color: #fff; padding: 12px 0;
  font-size: 15px; cursor: pointer;
}
</style>
