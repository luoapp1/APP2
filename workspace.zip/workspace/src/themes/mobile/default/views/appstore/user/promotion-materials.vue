<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f3f4f6">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">推广素材</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">
      <div v-if="loading" style="text-align:center;padding:40px 0;color:#9ca3af">加载中...</div>

      <template v-else-if="list.length > 0">
        <div v-for="item in list" :key="item.id" style="background:#fff;border-radius:12px;overflow:hidden;margin-bottom:12px">
          <div v-if="item.image_url" style="width:100%;height:200px;overflow:hidden;background:#f3f4f6">
            <img :src="item.image_url" :alt="item.title" style="width:100%;height:100%;object-fit:cover"  loading="lazy" />
          </div>
          <div style="padding:16px">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
              <span style="font-size:16px;font-weight:600;color:#1f2937">{{ item.title }}</span>
              <ElTag size="small" :type="item.type==='poster'?'warning':item.type==='banner'?'primary':'info'">
                {{ typeLabel(item.type) }}
              </ElTag>
            </div>
            <div v-if="item.description" style="font-size:13px;color:#6b7280;line-height:1.5;margin-bottom:12px">
              {{ item.description }}
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between">
              <span style="font-size:12px;color:#bbb">{{ item.create_time }}</span>
              <ElButton size="small" type="primary" plain @click="handleCopy(item)">复制推广链接</ElButton>
            </div>
          </div>
        </div>
      </template>

      <div v-else style="text-align:center;padding:60px 0;color:#9ca3af">
        <div style="font-size:48px;margin-bottom:12px">?</div>
        <div>暂无推广素材，请等待管理员添加</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'
import { fetchDefaultCode } from '@/api/invite'

defineOptions({ name: 'PromotionMaterials' })

const list = ref([])
const loading = ref(true)
const myCode = ref('')

function typeLabel(t) {
  const map = { poster: '海报', banner: '横幅', card: '卡片' }
  return map[t] || t
}

onMounted(async () => {
  try {
    const codeRes: any = await fetchDefaultCode().catch(() => ({}))
    myCode.value = codeRes?.code || ''
    const res = await request.get({ url: '/api/commission/materials' })
    list.value = Array.isArray(res) ? res : (res?.list || res?.data || [])
  } catch { list.value = [] }
  loading.value = false
})

async function handleCopy(item) {
  const shareUrl = `${location.origin}/#/register?ref=${myCode.value}`
  try {
    await navigator.clipboard.writeText(shareUrl)
    ElMessage.success('推广链接已复制')
    request.post({ url: `/api/commission/materials/${item.id}/share` }).catch(() => {})
  } catch {
    const ta = document.createElement('textarea')
    ta.value = shareUrl
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    document.body.removeChild(ta)
    ElMessage.success('推广链接已复制')
  }
}
</script>
