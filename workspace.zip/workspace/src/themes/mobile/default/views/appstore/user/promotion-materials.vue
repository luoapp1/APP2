<template>
  <div class="promotion-materials-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">&lt; 返回</button>
      <h2>推广素材</h2>
    </div>
    <div class="content">
      <div class="material-list" v-if="list.length > 0">
        <div class="material-card" v-for="item in list" :key="item.id">
          <div class="material-image" v-if="item.imageUrl">
            <img :src="item.imageUrl" :alt="item.title" />
          </div>
          <div class="material-body">
            <div class="material-title">{{ item.title }}</div>
            <div class="material-desc" v-if="item.description">{{ item.description }}</div>
            <div class="material-footer">
              <span class="material-time">{{ formatTime(item.createTime) }}</span>
              <button class="copy-btn" @click="handleCopyLink(item)">复制链接</button>
            </div>
          </div>
        </div>
      </div>
      <div class="empty" v-else-if="!loading">暂无推广素材</div>
      <div class="loading" v-if="loading">加载中...</div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref([])
const loading = ref(true)

onMounted(async () => {
  try {
    const res = await request.get({ url: '/api/commission/materials' })
    list.value = res?.list || res || []
  } catch {
    list.value = []
  }
  loading.value = false
})

async function handleCopyLink(item) {
  try {
    await navigator.clipboard.writeText(item.shareUrl || '')
    alert('链接已复制')
  } catch {
    const textarea = document.createElement('textarea')
    textarea.value = item.shareUrl || ''
    document.body.appendChild(textarea)
    textarea.select()
    document.execCommand('copy')
    document.body.removeChild(textarea)
    alert('链接已复制')
  }
}

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
</script>

<style scoped>
.promotion-materials-page { min-height: 100vh; background: #f5f5f5; }
.header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; border-bottom: 1px solid #eee; }
.header h2 { margin: 0; font-size: 18px; }
.back-btn { background: none; border: none; color: #2196F3; font-size: 14px; cursor: pointer; }
.content { padding: 16px; }

.material-list { display: flex; flex-direction: column; gap: 12px; }
.material-card { background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.material-image { width: 100%; height: 160px; overflow: hidden; }
.material-image img { width: 100%; height: 100%; object-fit: cover; }
.material-body { padding: 14px; }
.material-title { font-size: 15px; font-weight: 600; color: #333; margin-bottom: 4px; }
.material-desc { font-size: 13px; color: #999; margin-bottom: 12px; line-height: 1.5; }
.material-footer { display: flex; justify-content: space-between; align-items: center; }
.material-time { font-size: 12px; color: #bbb; }
.copy-btn { padding: 6px 16px; border: 1px solid #FF6B35; border-radius: 16px; background: #fff; color: #FF6B35; font-size: 12px; font-weight: 500; cursor: pointer; }
.empty { text-align: center; padding: 40px 0; color: #999; font-size: 14px; }
.loading { text-align: center; padding: 40px 0; color: #999; font-size: 14px; }
</style>
