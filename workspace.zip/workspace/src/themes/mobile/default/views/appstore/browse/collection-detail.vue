<template>
  <div class="collection-detail-page">
    <LoadingState v-if="loading" />
    <ErrorState v-else-if="error" :error="error" @retry="loadData" />
    <template v-else-if="collection">
      <div class="hero">
        <div class="hero-nav">
          <button class="nav-btn" @click="$router.back()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          <button v-if="!isOwner" class="nav-btn" @click="showReport = true">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
          </button>
        </div>

        <div class="hero-badge">
          <div v-if="collection.coverUrl" class="badge-img-wrap">
            <img :src="collection.coverUrl" class="badge-img" loading="lazy" />
          </div>
          <div v-else class="badge-text">{{ (collection.name || '合')[0] }}</div>
        </div>

        <h1 class="hero-title">{{ collection.name }}</h1>

        <p v-if="collection.description" class="hero-desc">
          <span class="desc-text" :class="{ collapsed: descCollapsed }" ref="descTextRef">{{ collection.description }}</span>
          <button v-if="descOverflow" class="desc-toggle" @click="descCollapsed = !descCollapsed">{{ descCollapsed ? '展开' : '收起' }}</button>
        </p>

        <button v-if="favorited" class="hero-action active" @click="toggleFavorite">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#F59E0B" stroke="#F59E0B" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          已收藏
        </button>
        <button v-else class="hero-action" @click="toggleFavorite">收藏合集</button>

        <div class="hero-footer">
          <span>{{ items.length }} 款应用</span>
          <span class="hf-dot">&middot;</span>
          <span>{{ formatNum(collection.viewCount || 0) }} 浏览</span>
          <span class="hf-dot">&middot;</span>
          <span>{{ formatNum(collection.likes || 0) }} 喜欢</span>
          <template v-if="collection.creator">
            <span class="hf-spacer"></span>
            <div class="hf-author">
              <img v-if="collection.creatorAvatar" :src="collection.creatorAvatar" class="hf-avatar" />
              <div v-else class="hf-avatar-fb">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.6)" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </div>
              <span class="hf-name">{{ collection.creator }}</span>
            </div>
          </template>
        </div>

        <svg class="hero-wave" viewBox="0 0 1440 60" preserveAspectRatio="none">
          <path d="M0,40 C360,15 720,55 1080,30 C1260,18 1380,45 1440,35 L1440,60 L0,60 Z" fill="#fff"/>
        </svg>
      </div>

      <div class="content">
        <div class="content-head">
          <span class="ch-title">应用列表</span>
          <span class="ch-sub">{{ items.length }} 款</span>
          <button v-if="isOwner" class="ch-add" @click="openAddAppDialog">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>添加</span>
          </button>
        </div>

        <EmptyState v-if="!items.length" text="此合集暂无应用" />
        <div v-else class="app-list">
          <div v-for="(item, idx) in items" :key="item.id" class="app-card" @click="goToApp(item)">
            <div class="app-icon-wrap">
              <img v-if="item.icon" :src="item.icon" class="app-icon" loading="lazy" />
              <div v-else class="app-icon-fb" :style="{ background: iconColors[idx % iconColors.length] }">
                {{ (item.name || '?')[0] }}
              </div>
            </div>
            <div class="app-body">
              <div class="app-name">{{ item.name }}</div>
              <div class="app-meta">
                <span v-if="item.downloads !== undefined">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#B0B0B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
                  {{ formatNum(item.downloads) }}
                </span>
                <span v-if="item.sizeMb" class="meta-sep">|</span>
                <span v-if="item.sizeMb">{{ item.sizeMb }}MB</span>
              </div>
            </div>
            <button v-if="isOwner" class="card-rm" @click.stop="removeApp(item)">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
            <button v-else class="card-btn" @click.stop="goToApp(item)">安装</button>
          </div>
        </div>
      </div>
    </template>

    <!-- Dialogs unchanged -->
    <div v-if="showReport" class="dialog-overlay" @click.self="showReport = false">
      <div class="dialog-panel">
        <div class="dialog-header">
          <span class="dialog-title">举报合集</span>
          <button class="dialog-close" @click="showReport = false">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <textarea v-model="reportReason" class="form-textarea" placeholder="请描述举报原因..." rows="4" />
        <div class="dialog-btns">
          <button class="btn-outline" @click="showReport = false">取消</button>
          <button class="btn-fill btn-danger-fill" :disabled="reporting" @click="doReport">{{ reporting ? '提交中...' : '提交举报' }}</button>
        </div>
      </div>
    </div>

    <div v-if="showAddAppDialog" class="dialog-overlay" @click.self="showAddAppDialog = false">
      <div class="dialog-panel">
        <div class="dialog-header">
          <span class="dialog-title">添加应用</span>
          <button class="dialog-close" @click="showAddAppDialog = false">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div class="search-bar">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input ref="searchInput" v-model="searchKeyword" class="search-input" placeholder="搜索应用名称..." @keyup.enter="searchApps" @compositionstart="isComposing = true" @compositionend="isComposing = false" />
          <button class="search-btn" @click="searchApps" :disabled="searching">搜索</button>
        </div>
        <div v-if="searching" class="search-loading">搜索中...</div>
        <div v-if="searchResults.length > 0" class="search-results">
          <div v-for="app in searchResults" :key="app.id" class="search-item" :class="{ selected: selectedAppIds.includes(app.id) }">
            <div class="search-item-left">
              <img v-if="app.icon" :src="app.icon" class="search-item-icon" loading="lazy" />
              <div v-else class="search-item-icon-fb" :style="{ background: app.iconBgColor || '#6366F1' }">{{ (app.name || '?')[0] }}</div>
              <div class="search-item-info">
                <div class="search-item-name">{{ app.name }}</div>
                <div v-if="app.description" class="search-item-desc">{{ app.description }}</div>
              </div>
            </div>
            <span v-if="isAppAlreadyInCollection(app.id)" class="tag-added">已收录</span>
            <button v-else class="select-toggle" :class="{ on: selectedAppIds.includes(app.id) }" @click="toggleSelectApp(app.id)">
              {{ selectedAppIds.includes(app.id) ? '已选' : '选择' }}
            </button>
          </div>
        </div>
        <div v-else-if="searchKeyword && !searching" class="search-empty">未找到匹配应用</div>
        <div class="dialog-btns">
          <button class="btn-outline" @click="showAddAppDialog = false">取消</button>
          <button class="btn-fill" :disabled="selectedAppIds.length === 0 || addingApps" @click="doAddApps">{{ addingApps ? '添加中...' : `添加 (${selectedAppIds.length})` }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCollectionDetail, fetchToggleCollectionFavorite, fetchReportCollection, fetchAddCollectionApps, fetchRemoveCollectionApp } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const loading = ref(true)
const error = ref('')
const collection = ref<any>(null)
const items = ref<any[]>([])
const favorited = ref(false)
const showReport = ref(false)
const reportReason = ref('')
const reporting = ref(false)
const descCollapsed = ref(true)
const descOverflow = ref(false)
const descTextRef = ref<HTMLElement | null>(null)

const showAddAppDialog = ref(false)
const searchKeyword = ref('')
const searchResults = ref<any[]>([])
const selectedAppIds = ref<number[]>([])
const searching = ref(false)
const addingApps = ref(false)
const searchInput = ref<any>(null)
const isComposing = ref(false)

const iconColors = ['#6366F1', '#EC4899', '#10B981', '#F59E0B', '#3B82F6', '#EF4444']

const isOwner = computed(() => {
  if (!collection.value || !userStore.info) return false
  return collection.value.creatorId === userStore.info.userId
})

async function loadData() {
  loading.value = true; error.value = ''
  try {
    const id = Number(route.params.id)
    const res: any = await fetchCollectionDetail(id)
    const d = res || {}
    collection.value = d.collection || null
    items.value = d.items || []
    favorited.value = d.favorited || false
    nextTick(() => {
      const el = descTextRef.value
      if (el) descOverflow.value = el.scrollHeight > 40
    })
  } catch (e: any) {
    error.value = e?.response?.data?.msg || e?.message || '加载失败'
  } finally { loading.value = false }
}

async function toggleFavorite() {
  if (!userStore.isLogin) { alert('请先登录'); return }
  try {
    const res: any = await fetchToggleCollectionFavorite(collection.value.id)
    favorited.value = (res || {}).favorited
  } catch (e: any) { alert(e?.response?.data?.msg || e?.message || '操作失败') }
}

async function doReport() {
  if (!userStore.isLogin) { alert('请先登录'); return }
  reporting.value = true
  try {
    await fetchReportCollection(collection.value.id, reportReason.value)
    alert('举报已提交'); showReport.value = false; reportReason.value = ''
  } catch (e: any) { alert(e?.response?.data?.msg || e?.message || '举报失败') }
  finally { reporting.value = false }
}

async function openAddAppDialog() {
  showAddAppDialog.value = true
  searchKeyword.value = ''
  searchResults.value = []
  selectedAppIds.value = []
  await nextTick()
  searchInput.value?.focus()
}

async function searchApps() {
  if (isComposing.value) return
  const kw = searchKeyword.value.trim()
  if (!kw) return
  searching.value = true
  try {
    const res: any = await request.get({ url: '/api/app/list', params: { keyword: kw, pageSize: 20 } })
    searchResults.value = res?.list || []
  } catch { searchResults.value = [] }
  finally { searching.value = false }
}

function toggleSelectApp(appId: number) {
  const i = selectedAppIds.value.indexOf(appId)
  if (i >= 0) selectedAppIds.value.splice(i, 1)
  else selectedAppIds.value.push(appId)
}

function isAppAlreadyInCollection(appId: number) {
  return items.value.some((i: any) => i.appId === appId)
}

async function doAddApps() {
  addingApps.value = true
  try {
    await fetchAddCollectionApps(collection.value.id, selectedAppIds.value)
    showAddAppDialog.value = false
    await loadData()
  } catch (e: any) { alert(e?.response?.data?.msg || e?.message || '添加失败') }
  finally { addingApps.value = false }
}

async function removeApp(item: any) {
  if (!confirm(`确定从合集中移除「${item.name}」？`)) return
  try {
    await fetchRemoveCollectionApp(collection.value.id, item.appId)
    items.value = items.value.filter((i: any) => i.id !== item.id)
  } catch (e: any) { alert(e?.response?.data?.msg || e?.message || '移除失败') }
}

function goToApp(item: any) {
  if (item.appId) router.push(`/appstore/browse/detail/${item.appId}`)
}

function formatNum(n: number) {
  if (!n && n !== 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(0) + '万'
  return String(n)
}

onMounted(() => {
  document.documentElement.style.background = '#F472B6'
  loadData()
})

onUnmounted(() => {
  document.documentElement.style.background = ''
})
</script>

<style scoped>
.collection-detail-page {
  min-height: 100vh;
  background: #fff;
}

/* ── Hero ── */
.hero {
  background: linear-gradient(155deg, #F472B6 0%, #F97316 50%, #F59E0B 100%);
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 24px 0;
  overflow: visible;
}

.hero::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: radial-gradient(ellipse 140% 80% at 50% 30%, rgba(255,255,255,.1) 0%, transparent 60%);
  pointer-events: none;
}

/* 导航 */
.hero-nav {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 8px;
  padding-bottom: 4px;
}
.nav-btn {
  background: rgba(255,255,255,.18);
  border: none;
  border-radius: 50%;
  width: 30px; height: 30px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
.nav-btn:active { background: rgba(255,255,255,.28); }

/* 徽章 */
.hero-badge {
  width: 44px; height: 44px;
  border-radius: 50%;
  overflow: hidden;
  margin-top: 10px;
  border: 2px solid rgba(255,255,255,.35);
  box-shadow: 0 2px 12px rgba(0,0,0,.08);
}
.badge-img-wrap, .badge-img { width: 100%; height: 100%; }
.badge-img { object-fit: cover; }
.badge-text {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,.2);
  color: #fff; font-size: 18px; font-weight: 700;
}

/* 标题 */
.hero-title {
  font-size: 15px; font-weight: 700;
  color: #fff; margin-top: 8px;
  text-align: center; line-height: 1.3;
}

/* 描述 */
.hero-desc {
  margin-top: 6px;
  text-align: center;
  font-size: 11px;
  color: rgba(255,255,255,.82);
  line-height: 1.5;
  max-width: 280px;
}
.desc-text.collapsed {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.desc-toggle {
  background: none; border: none;
  color: rgba(255,255,255,.95);
  font-size: 11px; cursor: pointer; font-weight: 600;
  padding: 0; margin-left: 2px;
}

/* 按钮 */
.hero-action {
  margin-top: 10px;
  display: inline-flex; align-items: center; gap: 5px;
  padding: 6px 22px;
  border-radius: 16px;
  border: 1.5px solid rgba(255,255,255,.5);
  background: rgba(255,255,255,.12);
  color: #fff;
  font-size: 12px; font-weight: 600;
  cursor: pointer;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  transition: all .15s;
}
.hero-action:active { background: rgba(255,255,255,.25); transform: scale(.96); }
.hero-action.active {
  background: rgba(255,255,255,.28);
  border-color: rgba(255,255,255,.65);
}

/* 底部信息 */
.hero-footer {
  display: flex; align-items: center; justify-content: center;
  flex-wrap: wrap; gap: 5px;
  margin-top: 10px; padding-bottom: 38px;
  font-size: 11px; color: rgba(255,255,255,.7);
}
.hf-dot { color: rgba(255,255,255,.3); }
.hf-spacer { width: 8px; }
.hf-author { display: flex; align-items: center; gap: 4px; }
.hf-avatar { width: 16px; height: 16px; border-radius: 50%; object-fit: cover; border: 1px solid rgba(255,255,255,.3); }
.hf-avatar-fb { width: 16px; height: 16px; border-radius: 50%; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,.2); }
.hf-name { color: rgba(255,255,255,.85); font-weight: 500; }

/* 波浪 */
.hero-wave {
  position: absolute; bottom: -1px; left: 0;
  width: 100%; height: 28px;
}

/* ── 内容 ── */
.content {
  margin-top: -18px;
  padding: 24px 16px 40px;
  position: relative; z-index: 2;
  background: #fff;
}
.content-head {
  display: flex; align-items: center; gap: 6px;
  margin-bottom: 14px;
}
.ch-title { font-size: 15px; font-weight: 700; color: #1A1A2E; }
.ch-sub { font-size: 12px; color: #9CA3AF; font-weight: 500; }
.ch-add {
  margin-left: auto;
  display: flex; align-items: center; gap: 3px;
  padding: 5px 10px; border-radius: 14px;
  border: 1px solid #6366F1;
  background: #fff; color: #6366F1;
  font-size: 11px; font-weight: 600; cursor: pointer;
  transition: all .15s;
}
.ch-add:active { background: #EEF2FF; transform: scale(.97); }

/* 卡片 */
.app-list { display: flex; flex-direction: column; gap: 10px; }
.app-card {
  display: flex; align-items: center; gap: 12px;
  padding: 14px; border-radius: 14px;
  background: #fff;
  cursor: pointer;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
  transition: all .15s;
}
.app-card:active { transform: scale(.985); box-shadow: 0 2px 8px rgba(0,0,0,.06); }

.app-icon-wrap { flex-shrink: 0; }
.app-icon {
  width: 46px; height: 46px; border-radius: 12px;
  object-fit: cover;
  box-shadow: 0 2px 8px rgba(0,0,0,.08);
}
.app-icon-fb {
  width: 46px; height: 46px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 18px; font-weight: 700;
}

.app-body { flex: 1; min-width: 0; }
.app-name {
  font-size: 14px; font-weight: 600; color: #1A1A2E;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.app-meta {
  display: flex; align-items: center; gap: 6px;
  margin-top: 3px; font-size: 11px; color: #B0B0B8;
}
.meta-sep { color: #D1D5DB; }

.card-btn {
  flex-shrink: 0;
  padding: 6px 16px; border-radius: 14px;
  border: none;
  background: linear-gradient(135deg, #6366F1, #8B5CF6);
  color: #fff; font-size: 12px; font-weight: 600;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(99,102,241,.2);
  transition: all .15s;
}
.card-btn:active { opacity: .85; transform: scale(.95); }

.card-rm {
  flex-shrink: 0;
  width: 28px; height: 28px; border-radius: 50%;
  border: 1px solid #FEE2E2; background: #FEF2F2; color: #EF4444;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; padding: 0;
  transition: all .15s;
}
.card-rm:active { background: #FEE2E2; transform: scale(.92); }

/* ── Dialogs ── */
.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 100; display: flex; align-items: center; justify-content: center; padding: 20px; backdrop-filter: blur(4px); }
.dialog-panel { background: #fff; width: 100%; max-width: 340px; border-radius: 18px; padding: 20px; max-height: 75vh; overflow-y: auto; box-shadow: 0 16px 48px rgba(0,0,0,.15); }
.dialog-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.dialog-title { font-size: 16px; font-weight: 700; color: #1A1A2E; }
.dialog-close { background: #F3F4F6; border: none; border-radius: 50%; width: 28px; height: 28px; padding: 0; cursor: pointer; display: flex; align-items: center; justify-content: center; }
.dialog-btns { display: flex; gap: 8px; margin-top: 16px; }
.btn-outline { flex: 1; padding: 10px 0; border-radius: 10px; border: 1.5px solid #E5E7EB; background: #fff; color: #6B7280; font-size: 13px; font-weight: 600; cursor: pointer; text-align: center; }
.btn-fill { flex: 1; padding: 10px 0; border-radius: 10px; border: none; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; text-align: center; }
.btn-fill:disabled { opacity: .4; cursor: not-allowed; }
.btn-danger-fill { background: linear-gradient(135deg, #EF4444, #F87171); }
.form-textarea { width: 100%; padding: 12px; border: 1.5px solid #E5E7EB; border-radius: 12px; font-size: 13px; color: #333; outline: none; resize: vertical; box-sizing: border-box; font-family: inherit; line-height: 1.6; }
.form-textarea:focus { border-color: #6366F1; box-shadow: 0 0 0 3px rgba(99,102,241,.1); }

.search-bar { display: flex; align-items: center; gap: 8px; background: #F3F4F6; border-radius: 12px; padding: 0 12px; margin-bottom: 12px; }
.search-input { flex: 1; border: none; background: transparent; padding: 10px 0; font-size: 13px; color: #333; outline: none; }
.search-input::placeholder { color: #9CA3AF; }
.search-btn { flex-shrink: 0; padding: 5px 14px; border-radius: 16px; border: none; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; font-size: 12px; font-weight: 600; cursor: pointer; }
.search-btn:disabled { opacity: .5; cursor: not-allowed; }
.search-loading { text-align: center; padding: 16px 0; color: #9CA3AF; font-size: 12px; }
.search-results { max-height: 240px; overflow-y: auto; margin-bottom: 8px; }
.search-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 4px; border-radius: 10px; gap: 8px; }
.search-item.selected { background: #EEF2FF; }
.search-item-left { display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0; }
.search-item-icon { width: 38px; height: 38px; border-radius: 10px; object-fit: cover; flex-shrink: 0; }
.search-item-icon-fb { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 16px; font-weight: 700; flex-shrink: 0; }
.search-item-info { min-width: 0; }
.search-item-name { font-size: 13px; font-weight: 600; color: #1A1A2E; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.search-item-desc { font-size: 11px; color: #9CA3AF; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 2px; }
.tag-added { flex-shrink: 0; padding: 3px 10px; border-radius: 16px; background: #D1FAE5; color: #059669; font-size: 11px; font-weight: 600; }
.select-toggle { flex-shrink: 0; padding: 5px 12px; border-radius: 16px; border: 1.5px solid #E5E7EB; background: #fff; color: #6366F1; font-size: 12px; font-weight: 600; cursor: pointer; }
.select-toggle.on { background: #6366F1; color: #fff; border-color: #6366F1; }
.search-empty { text-align: center; padding: 24px 0; color: #9CA3AF; font-size: 13px; }
</style>
