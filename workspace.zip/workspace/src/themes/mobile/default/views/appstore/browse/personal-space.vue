<template>
  <div class="ps-page">
    <div class="ps-header">
      <button class="ps-back" @click="goBack">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="ps-title">{{ currentFolder ? currentFolderName : '个人空间' }}</span>
      <div style="width:28px"></div>
    </div>

    <div class="ps-storage-row">
      <div class="ps-storage-card">
        <div class="ps-storage-icon" style="background:rgba(59,130,246,.12);color:#3B82F6;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>
        </div>
        <div class="ps-storage-info">
          <div class="ps-storage-label">数据配额</div>
          <div class="ps-storage-bar"><div class="ps-storage-fill" :style="{ width: dataStoragePercent + '%' }"></div></div>
          <div class="ps-storage-text">{{ dataUsedStr }}<span v-if="totalDataLimitMb"> / {{ totalStr }}</span></div>
        </div>
      </div>
      <div class="ps-storage-card">
        <div class="ps-storage-icon" style="background:rgba(16,185,129,.12);color:#10B981;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        </div>
        <div class="ps-storage-info">
          <div class="ps-storage-label">文件配额</div>
          <div class="ps-storage-bar"><div class="ps-storage-fill ps-storage-fill-file" :style="{ width: fileStoragePercent + '%' }"></div></div>
          <div class="ps-storage-text">{{ usedStr }}<span v-if="totalFileLimitMb"> / {{ fileTotalStr }}</span></div>
        </div>
      </div>
    </div>

    <div class="ps-list" v-if="!currentFolder">
      <div class="ps-list-header">文件分类</div>
      <div v-if="loading" class="ps-loading">加载中...</div>
      <div v-else-if="folders.length === 0" class="ps-empty">暂无上传文件</div>
      <div v-else v-for="f in folders" :key="f.prefix" class="ps-file-item" @click="enterFolder(f)">
        <div class="ps-file-icon" :class="'ps-icon-' + (f.name || 'other')">
          <svg v-if="f.name === 'img'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          <svg v-else-if="f.name === 'apk'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          <svg v-else-if="f.name === 'video'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
          <svg v-else-if="f.name === 'audio'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          <svg v-else-if="f.name === 'zip'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
          <svg v-else-if="f.name === 'doc'" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          <svg v-else width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        </div>
        <div class="ps-file-info">
          <div class="ps-file-name">{{ folderLabel(f.name) }}</div>
          <div class="ps-file-meta">{{ f.name }}/</div>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </div>
    </div>

    <div class="ps-list" v-else>
      <div class="ps-list-header ps-list-header-row">
        <span>{{ currentFolderName }} ({{ filesTotal }})</span>
        <div class="ps-page-btns">
          <button :disabled="page <= 1" @click="changePage(page - 1)">上一页</button>
          <span class="ps-page-num">{{ page }}/{{ totalPages }}</span>
          <button :disabled="page >= totalPages" @click="changePage(page + 1)">下一页</button>
        </div>
      </div>
      <div class="ps-page-size-bar" v-if="filesTotal > 0">
        <span class="ps-page-size-label">每页条数</span>
        <div class="ps-page-size-opts">
          <button v-for="s in pageSizeOptions" :key="s" :class="{ active: pageSize === s }" @click="setPageSize(s)">{{ s }}</button>
        </div>
      </div>
      <div v-if="filesLoading" class="ps-loading">加载中...</div>
      <template v-else>
        <div class="ps-back-folder" @click="goBack">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
          返回上级目录
        </div>
        <div v-if="files.length === 0" class="ps-empty">暂无文件</div>
        <template v-else>
          <div v-for="f in files" :key="f.key" class="ps-file-item" @click="showDetail(f)">
            <div class="ps-file-icon" :class="fileIconClass(f)">
              <svg v-if="isImage(f)" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
              <svg v-else-if="isVideo(f)" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
              <svg v-else-if="isAudio(f)" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
              <svg v-else-if="isApk(f)" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
              <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
            </div>
            <div class="ps-file-info">
              <div class="ps-file-name">{{ f.name }}</div>
              <div class="ps-file-meta">{{ formatSize(f.size) }} / {{ formatTime(f.time) }}</div>
            </div>
            <button class="ps-file-del" :class="{ 'ps-file-locked': f.dbId }" @click.stop="f.dbId ? null : handleDelete(f)" :title="f.dbId ? '已被引用，不可删除' : '删除文件'">
              <svg v-if="f.dbId" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <svg v-else-if="deleting !== f.key" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              <span v-else class="ps-deleting">...</span>
            </button>
          </div>
        </template>
      </template>
    </div>

    <div v-if="detailVisible" class="ps-detail-overlay" @click.self="detailVisible = false">
      <div class="ps-detail-panel">
        <div class="ps-detail-header">
          <span class="ps-detail-title">文件详情</span>
          <button class="ps-detail-close" @click="detailVisible = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="ps-detail-body" v-if="detail">
          <div class="ps-detail-row"><span class="ps-dk">文件名</span><span class="ps-dv">{{ detail.name }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">大小</span><span class="ps-dv">{{ formatSize(detail.size) }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">类型</span><span class="ps-dv">{{ detail.type || '-' }}</span></div>
          <div class="ps-detail-row" v-if="detail.mime"><span class="ps-dk">MIME</span><span class="ps-dv">{{ detail.mime }}</span></div>
           <div class="ps-detail-row"><span class="ps-dk">分类</span><span class="ps-dv">{{ categoryLabel(detail.category) }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">上传时间</span><span class="ps-dv">{{ formatTime(detail.time) }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">数据记录</span><span class="ps-dv">{{ detail.inDb ? '已引用，不可删除' : '可删除' }}</span></div>
          <div class="ps-detail-row" v-if="detail.appName"><span class="ps-dk">所属应用</span><span class="ps-dv">{{ detail.appName }}</span></div>
          <div class="ps-detail-row" v-if="detail.appPackage"><span class="ps-dk">包名</span><span class="ps-dv">{{ detail.appPackage }}</span></div>
          <div class="ps-detail-row" v-if="detail.refType"><span class="ps-dk">关联类型</span><span class="ps-dv">{{ detail.refTypeLabel || detail.refType }}</span></div>
          <div class="ps-detail-row" v-if="detail.refId"><span class="ps-dk">关联ID</span><span class="ps-dv">{{ detail.refId }}</span></div>
          <div class="ps-detail-row" v-if="detail.description"><span class="ps-dk">描述</span><span class="ps-dv">{{ detail.description }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">路径</span><span class="ps-dv ps-dv-mono">{{ detail.key }}</span></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { ElMessage, ElMessageBox } from 'element-plus'

interface FileEntry {
  name: string; key: string; size: number; url: string; time: string; type: string;
  isFolder?: boolean; prefix?: string; dbId?: string | null;
}

interface DetailInfo {
  key: string; name: string; size: number; type: string; mime: string; category: string;
  time: string; inDb: boolean; appName: string; appPackage: string;
}

const router = useRouter()

const folders = ref<FileEntry[]>([])
const files = ref<FileEntry[]>([])
const allCloudFiles = ref<FileEntry[]>([])
const loading = ref(true)
const filesLoading = ref(false)
const usedBytes = ref(0)
const dataUsedBytes = ref(0)
const totalDataLimitMb = ref(200)
const totalFileLimitMb = ref(200)
const currentFolder = ref('')
const deleting = ref<string | null>(null)
const page = ref(1)
const pageSize = ref(15)
const pageSizeOptions = [10, 15, 20, 30, 50]
const detailVisible = ref(false)
const detail = ref<DetailInfo | null>(null)
const detailLoading = ref(false)

const currentFolderName = computed(() => currentFolder.value.replace(/\/$/, '').split('/').pop() || '')
const usedStr = computed(() => formatSize(usedBytes.value))
const dataUsedStr = computed(() => formatSize(dataUsedBytes.value))
const totalStr = computed(() => formatSize(totalDataLimitMb.value * 1024 * 1024))
const fileTotalStr = computed(() => formatSize(totalFileLimitMb.value * 1024 * 1024))
const dataStoragePercent = computed(() => totalDataLimitMb.value > 0 ? Math.min(100, dataUsedBytes.value / (totalDataLimitMb.value * 1024 * 1024) * 100) : 0)
const fileStoragePercent = computed(() => totalFileLimitMb.value > 0 ? Math.min(100, usedBytes.value / (totalFileLimitMb.value * 1024 * 1024) * 100) : 0)
const totalPages = computed(() => Math.max(1, Math.ceil(allCloudFiles.value.length / pageSize.value)))
const filesTotal = computed(() => allCloudFiles.value.length)

watch([page, pageSize], () => {
  const start = (page.value - 1) * pageSize.value
  files.value = allCloudFiles.value.slice(start, start + pageSize.value)
})

function formatSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B'
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0, v = bytes
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(i > 0 ? 1 : 0) + ' ' + u[i]
}
function formatTime(t: string): string { return t ? t.replace('T', ' ').substring(0, 16) : '' }
function folderLabel(n: string) { return ({ img: '图片', apk: '应用安装包', video: '视频', audio: '音频', zip: '压缩包', doc: '文档', other: '其他' } as any)[n] || n }
function fileIconClass(f: FileEntry): string {
  if (isImage(f)) return 'ps-icon-img'
  if (isVideo(f)) return 'ps-icon-video'
  if (isAudio(f)) return 'ps-icon-audio'
  if (isApk(f)) return 'ps-icon-apk'
  return 'ps-icon-file'
}
const categoryMap: Record<string, string> = {
  avatar: '用户头像', background: '用户背景', app_icon: '应用图标', app_screenshot: '应用截图',
  app_file: '应用文件', app_content: '应用内容图片', post_image: '帖子图片', post_content: '帖子内容图片',
  post_attachment: '帖子附件', comment_image: '评论图片', mall_product: '商城商品图片', mall_detail: '商城详情图片',
  topic_icon: '话题图标', section_icon: '板块图标', avatar_frame: '头像框图片', checkin: '签到图片',
  coupon: '优惠券图片', title: '称号图片', membership: '会员图片', game: '游戏图片',
  chat: '聊天图片', chat_image: '聊天图片', chat_room_avatar: '聊天室头像',
  plugin: '插件文件', general: '通用文件', apk: 'APK安装包', apk_icon: 'APK图标',
  other: '其他文件'
}
function categoryLabel(c: string) { return categoryMap[c] || c || '-' }
function isImage(f: FileEntry) { return f.type && /^(jpg|jpeg|png|gif|webp|bmp|svg|ico)$/i.test(f.type) }
function isVideo(f: FileEntry) { return f.type && /^(mp4|avi|mov|wmv|flv|mkv|webm)$/i.test(f.type) }
function isAudio(f: FileEntry) { return f.type && /^(mp3|wav|ogg|aac|flac|m4a)$/i.test(f.type) }
function isApk(f: FileEntry) { return f.type === 'apk' }

async function loadFolders() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/file-repo/my-files', showErrorMessage: false })
    if (res) {
      folders.value = (res.list || []).filter((f: FileEntry) => f.isFolder)
      usedBytes.value = res.usedBytes || 0
      dataUsedBytes.value = res.dataUsedBytes || 0
      totalDataLimitMb.value = res.totalDataLimitMb || 200
      totalFileLimitMb.value = res.totalFileLimitMb || 200
    }
  } catch {} finally { loading.value = false }
}

async function enterFolder(f: FileEntry) {
  currentFolder.value = f.prefix || ''
  page.value = 1
  filesLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/file-repo/my-files', showErrorMessage: false, params: { prefix: f.prefix } })
    if (res) {
      allCloudFiles.value = (res.list || []).filter((item: FileEntry) => !item.isFolder)
      files.value = allCloudFiles.value.slice(0, pageSize.value)
    }
  } catch {} finally { filesLoading.value = false }
}

function changePage(p: number) {
  if (p < 1 || p > totalPages.value) return
  page.value = p
}

function setPageSize(s: number) {
  pageSize.value = s
  page.value = 1
}

function goBack() {
  if (currentFolder.value) {
    currentFolder.value = ''
    files.value = []
    allCloudFiles.value = []
    page.value = 1
  } else {
    router.replace('/appstore/mine')
  }
}

async function handleDelete(file: FileEntry) {
  if (file.dbId) {
    ElMessage.warning('该文件已被引用，不能直接删除')
    return
  }
  try { await ElMessageBox.confirm(`确定删除「${file.name}」？`, '确认删除', { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }) } catch { return }
  deleting.value = file.key
  try {
    const res: any = await request.post({ url: '/api/file-repo/my-file', data: { key: file.key } })
    if (res) {
      allCloudFiles.value = allCloudFiles.value.filter(f => f.key !== file.key)
      files.value = files.value.filter(f => f.key !== file.key)
      usedBytes.value = Math.max(0, usedBytes.value - (file.size || 0))
      ElMessage.success('删除成功')
    }
  } catch (err: any) { ElMessage.error(err?.message || '删除失败') }
  finally { deleting.value = null }
}

async function showDetail(f: FileEntry) {
  detailVisible.value = true
  detailLoading.value = true
  detail.value = null
  try {
    const res: any = await request.get({ url: '/api/file-repo/file-detail', showErrorMessage: false, params: { key: f.key } })
    if (res) detail.value = res
  } catch {} finally { detailLoading.value = false }
}

onMounted(() => { loadFolders() })
</script>

<style scoped lang="scss">
.ps-page { min-height: 100vh; background: #f0f2f5; }

.ps-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 16px; background: #fff;
  position: sticky; top: 0; z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.06);
}
.ps-back { background: none; border: none; cursor: pointer; padding: 4px; color: #333; display: flex; align-items: center; }
.ps-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }

.ps-storage-row {
  margin: 12px 16px; display: flex; gap: 10px;
}
.ps-storage-card {
  flex: 1; min-width: 0; padding: 14px; background: #fff;
  border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,.04);
  display: flex; gap: 12px; align-items: flex-start;
}
.ps-storage-icon {
  width: 36px; height: 36px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ps-storage-info { flex: 1; min-width: 0; }
.ps-storage-label { font-size: 12px; color: #999; margin-bottom: 6px; font-weight: 500; }
.ps-storage-bar { height: 6px; background: #f0f0f0; border-radius: 3px; overflow: hidden; }
.ps-storage-fill { height: 100%; background: linear-gradient(90deg, #3B82F6, #60A5FA); border-radius: 3px; transition: width .4s ease; }
.ps-storage-fill-file { background: linear-gradient(90deg, #10B981, #34D399); }
.ps-storage-text { font-size: 11px; color: #aaa; margin-top: 5px; }

.ps-list {
  margin: 0 16px 24px; background: #fff; border-radius: 14px;
  box-shadow: 0 2px 8px rgba(0,0,0,.04); overflow: hidden;
}
.ps-list-header {
  padding: 14px 16px; font-size: 15px; font-weight: 600; color: #1a1a2e;
  border-bottom: 1px solid #f0f0f0;
}
.ps-list-header-row { display: flex; align-items: center; justify-content: space-between; }
.ps-page-btns { display: flex; align-items: center; gap: 8px; }
.ps-page-btns button {
  padding: 5px 12px; font-size: 12px; border: 1px solid #e0e0e0;
  border-radius: 8px; background: #fff; color: #555; cursor: pointer;
  transition: all .15s;
  &:hover:not(:disabled) { border-color: #3B82F6; color: #3B82F6; }
  &:disabled { color: #ccc; cursor: not-allowed; }
}
.ps-page-num { font-size: 12px; color: #999; min-width: 40px; text-align: center; }
.ps-page-size-bar {
  display: flex; align-items: center; gap: 10px; padding: 10px 16px;
  border-bottom: 1px solid #f0f0f0;
}
.ps-page-size-label { font-size: 12px; color: #999; }
.ps-page-size-opts { display: flex; gap: 4px; }
.ps-page-size-opts button {
  min-width: 32px; padding: 3px 8px; font-size: 12px;
  border: 1px solid #e0e0e0; border-radius: 6px;
  background: #fff; color: #666; cursor: pointer; transition: all .15s;
  &:hover { border-color: #3B82F6; color: #3B82F6; }
  &.active { background: #3B82F6; color: #fff; border-color: #3B82F6; }
}
.ps-loading, .ps-empty { padding: 48px 16px; text-align: center; color: #bbb; font-size: 14px; }

.ps-file-item {
  display: flex; align-items: center; padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5; cursor: pointer;
  transition: background .15s;
  &:last-child { border-bottom: none; }
  &:active { background: #eff6ff; }
}
.ps-back-folder {
  display: flex; align-items: center; gap: 6px; padding: 12px 16px;
  color: #3B82F6; font-size: 13px; font-weight: 500; cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  &:active { background: #eff6ff; }
}
.ps-icon-img { background: rgba(59,130,246,.1); color: #3B82F6; }
.ps-icon-video { background: rgba(245,158,11,.1); color: #F59E0B; }
.ps-icon-audio { background: rgba(16,185,129,.1); color: #10B981; }
.ps-icon-apk { background: rgba(59,130,246,.1); color: #3B82F6; }
.ps-icon-file { background: rgba(107,114,128,.1); color: #6B7280; }
.ps-icon-zip { background: rgba(139,92,246,.1); color: #8B5CF6; }
.ps-icon-doc { background: rgba(107,114,128,.1); color: #6B7280; }
.ps-icon-other { background: rgba(156,163,175,.1); color: #9CA3AF; }

.ps-file-info { flex: 1; margin-left: 12px; min-width: 0; }
.ps-file-name { font-size: 14px; color: #1a1a2e; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ps-file-meta { font-size: 12px; color: #999; margin-top: 3px; }

.ps-file-del {
  background: none; border: none; cursor: pointer; padding: 8px;
  flex-shrink: 0; opacity: .5; transition: opacity .15s;
  &:hover { opacity: 1; }
  &:disabled { cursor: not-allowed; }
}
.ps-file-locked { cursor: default; opacity: .25; &:hover { opacity: .25; } }
.ps-deleting { color: #EF4444; font-size: 12px; }

.ps-back-folder {
  display: flex; align-items: center; gap: 6px; padding: 12px 16px;
  color: #3B82F6; font-size: 13px; font-weight: 500; cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  &:active { background: #f5f3ff; }
}

.ps-detail-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100;
  display: flex; align-items: flex-end; justify-content: center;
  backdrop-filter: blur(4px);
}
.ps-detail-panel {
  width: 100%; max-width: 500px; background: #fff;
  border-radius: 20px 20px 0 0; padding: 0 0 28px;
  max-height: 72vh; overflow-y: auto;
  animation: slideUp .25s ease;
}
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.ps-detail-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 18px 20px; border-bottom: 1px solid #f0f0f0;
}
.ps-detail-title { font-size: 16px; font-weight: 600; color: #1a1a2e; }
.ps-detail-close { background: none; border: none; cursor: pointer; padding: 6px; border-radius: 8px; &:active { background: #f5f5f5; } }
.ps-detail-body { padding: 16px 20px; }
.ps-detail-row { display: flex; padding: 11px 0; border-bottom: 1px solid #f5f5f5; &:last-child { border: none; } }
.ps-dk { width: 72px; color: #999; font-size: 13px; flex-shrink: 0; }
.ps-dv { flex: 1; color: #333; font-size: 13px; word-break: break-all; }
.ps-dv-mono { font-family: 'SF Mono', monospace; font-size: 11px; color: #3B82F6; }
</style>
