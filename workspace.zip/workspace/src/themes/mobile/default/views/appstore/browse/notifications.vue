<template>
  <div class="page">
    <div class="header">
      <svg class="header-back" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="header-title">通知中心</span>
      <span v-if="unreadTotal" class="header-badge">{{ unreadTotal > 99 ? '99+' : unreadTotal }}</span>
    </div>

    <div v-if="loading && list.length === 0" class="loading-wrap">
      <div class="loading-spin" />
      <span class="loading-text">加载中...</span>
    </div>

    <template v-else>
      <div class="tabs">
        <div
          v-for="tab in tabs"
          :key="tab.key"
          class="tab"
          :class="{ active: activeType === tab.key }"
          @click="switchTab(tab.key)"
        >{{ tab.label }}</div>
      </div>

      <template v-if="list.length > 0">
        <div ref="scrollContainer" class="list" @scroll="onScroll">
          <div
            v-for="item in list"
            :key="item.id"
            class="msg-card"
            :class="{ unread: !item.isRead && item.isRead !== 1 }"
            @click="openDetail(item)"
          >
            <div class="msg-avatar">
              <img :src="item.fromUserAvatar ? $fixImgUrl(item.fromUserAvatar) : defaultAvatar"  loading="lazy" />
            </div>
            <div class="msg-body">
              <div class="msg-name-row">
                <span class="msg-name">{{ displayName(item) }}</span>
                <span class="msg-date">{{ fmtTime(item.create_time || item.createTime) }}</span>
              </div>
              <div class="msg-tags" v-if="roleTag(item) || titleTag(item)">
                <span v-if="roleTag(item)" class="tag-role">{{ roleTag(item) }}</span>
                <span v-if="titleTag(item)" class="tag-title" :style="{ color: item.fromUserTitleColor || '#409EFF', background: (item.fromUserTitleBg || '#ecf5ff') + '80' }">{{ titleTag(item) }}</span>
              </div>
              <div class="msg-content">{{ item.content || item.title || '' }}</div>
            </div>
          </div>

          <div v-if="loadingMore" class="load-more"><div class="loading-spin small" /><span>加载中</span></div>
          <div v-else-if="noMore" class="load-more">没有更多了</div>
        </div>
      </template>

      <div v-else class="empty">
        <svg class="empty-icon" viewBox="0 0 200 160" fill="none">
          <rect x="40" y="30" width="120" height="100" rx="12" fill="#f3f4f6"/>
          <rect x="56" y="50" width="30" height="4" rx="2" fill="#d1d5db"/>
          <rect x="56" y="60" width="50" height="4" rx="2" fill="#e5e7eb"/>
          <rect x="56" y="72" width="88" height="4" rx="2" fill="#e5e7eb"/>
          <rect x="56" y="84" width="70" height="4" rx="2" fill="#e5e7eb"/>
          <rect x="56" y="96" width="40" height="4" rx="2" fill="#e5e7eb"/>
          <circle cx="100" cy="30" r="20" fill="#e5e7eb"/>
          <path d="M94 26h12M100 22v12" stroke="#d1d5db" stroke-width="2.5" stroke-linecap="round"/>
        </svg>
        <span class="empty-text">暂无通知</span>
        <span class="empty-sub">有新的通知会显示在这里</span>
      </div>
    </template>

    <!-- 详情弹窗 -->
    <transition name="sheet" mode="out-in">
      <div v-if="detailVisible" class="sheet-overlay" @click.self="closeDetail">
        <div class="sheet-panel">
          <div class="sheet-handle" />
          <div class="sheet-body">
            <div class="sheet-user">
              <img class="sheet-avatar" :src="detailItem.fromUserAvatar ? $fixImgUrl(detailItem.fromUserAvatar) : defaultAvatar"  loading="lazy" />
              <div>
                <div class="sheet-name">{{ displayName(detailItem) }}</div>
                <div class="sheet-tags" v-if="roleTag(detailItem) || titleTag(detailItem)">
                  <span v-if="roleTag(detailItem)" class="s-role">{{ roleTag(detailItem) }}</span>
                  <span v-if="titleTag(detailItem)" class="s-title" :style="{ color: detailItem.fromUserTitleColor || '#409EFF', background: (detailItem.fromUserTitleBg || '#ecf5ff') }">{{ titleTag(detailItem) }}</span>
                </div>
              </div>
              <span class="s-time">{{ fmtTime(detailItem.create_time || detailItem.createTime) }}</span>
            </div>
            <div class="s-content-title">{{ detailItem.title || '通知详情' }}</div>
            <div class="s-content-text" v-if="detailItem.content">{{ detailItem.content }}</div>
          </div>
          <div class="sheet-actions">
            <button class="sa-btn" @click="closeDetail">关闭</button>
            <button class="sa-btn primary" @click="navToDetail" v-if="detailItem.targetUrl || detailItem.target_url">查看详情</button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'
import request from '@/utils/http'
import defaultAvatarImg from '@imgs/user/avatar.webp'

defineOptions({ name: 'AppStoreNotifications' })

const router = useRouter()
const userStore = useUserStore()
const defaultAvatar = defaultAvatarImg

const tabs = [
  { key: '', label: '全部' },
  { key: 'system', label: '系统' },
  { key: 'comment', label: '评论' },
  { key: 'like', label: '点赞' },
  { key: 'follow', label: '关注' },
  { key: 'mention', label: '@提及' },
]

const activeType = ref('')
const list = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const pageSize = 20
const scrollContainer = ref<HTMLElement | null>(null)
const detailVisible = ref(false)
const detailItem = ref<any>({})

const roleMap: Record<string, string> = { R_SUPER: '超级管理员', R_ADMIN: '管理员', R_MOD: '版主' }

const displayName = (item: any) => item.fromUserName || '用户'
const titleTag = (item: any): string => item.fromUserTitle || ''
const roleTag = (item: any): string => {
  if (!item.fromUserRoles || item.fromUserRoles === '[]') return ''
  try { const roles: string[] = JSON.parse(item.fromUserRoles); const m = roles.map((r: string) => roleMap[r] || r).filter(Boolean); return m[0] || '' } catch { return '' }
}

function fmtTime(t: string) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  const diff = Date.now() - d.getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return '刚刚'
  if (mins < 60) return `${mins}分钟前`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}天前`
  const m = d.getMonth() + 1; const day = d.getDate()
  return `${m}/${day}`
}

const unreadTotal = computed(() => list.value.filter(item => item.isRead !== 1 && !item.isRead).length)

function switchTab(key: string) {
  if (activeType.value === key) return
  activeType.value = key; page.value = 1; list.value = []; noMore.value = false; loadList()
}

async function loadList() {
  if (!userStore.isLogin) {
    useLoginModalStore().open()
    loading.value = false
    return
  }
  if (page.value === 1) loading.value = true; else loadingMore.value = true
  try {
    const params: any = { page: page.value, pageSize, userId: userStore.info.userId }
    if (activeType.value) params.type = activeType.value
    const res = await request.get({ url: '/api/notifications', params })
    const items = res?.list || res || []
    if (page.value === 1) list.value = items; else list.value = list.value.concat(items)
    noMore.value = items.length < pageSize
  } catch { /* ignore */ }
  loading.value = false; loadingMore.value = false
}

onMounted(() => loadList())

function openDetail(item: any) {
  detailItem.value = item; detailVisible.value = true; document.body.style.overflow = 'hidden'
  if (item.isRead !== 1 && !item.isRead) { request.post({ url: `/api/notifications/${item.id}/read` }).catch(() => {}); item.isRead = 1 }
}
function closeDetail() { detailVisible.value = false; document.body.style.overflow = '' }
function navToDetail() { closeDetail(); const url = detailItem.value.targetUrl || detailItem.value.target_url; if (url) router.push(url) }

async function handleMarkAll() {
  try { await request.post({ url: '/api/notifications/read-all', data: { userId: userStore.info.userId } }); list.value.forEach(item => { item.isRead = 1 }) } catch { /* ignore */ }
}

function onScroll() {
  if (!scrollContainer.value || loadingMore.value || noMore.value) return
  if (scrollContainer.value.scrollHeight - scrollContainer.value.scrollTop - scrollContainer.value.clientHeight < 80) { page.value++; loadList() }
}

onUnmounted(() => { document.body.style.overflow = '' })
</script>

<style scoped>
.page { min-height: 100vh; background: var(--app-page-bg); padding-bottom: env(safe-area-inset-bottom, 0px); }

.header {
  display: flex; align-items: center; padding: 14px 16px;
  background: var(--default-bg-color); gap: 10px;
  position: sticky; top: 0; z-index: 10;
}
.header-back { width: 24px; height: 24px; cursor: pointer; color: #333; flex-shrink: 0; }
.header-title { font-size: 18px; font-weight: 700; color: #111; }
.header-badge {
  margin-left: auto; background: #ef4444; color: #fff;
  font-size: 11px; font-weight: 700; min-width: 18px; text-align: center;
  padding: 2px 6px; border-radius: 9px; line-height: 1.4;
}

.loading-wrap { display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 120px 0; }
.loading-spin { width: 28px; height: 28px; border: 2.5px solid #e5e7eb; border-top-color: #6366f1; border-radius: 50%; animation: spin .7s linear infinite; }
.loading-spin.small { width: 14px; height: 14px; border-width: 2px; }
.loading-text { font-size: 13px; color: #9ca3af; }
@keyframes spin { to { transform: rotate(360deg); } }

.tabs {
  display: flex; background: var(--default-bg-color);
  padding: 0; gap: 0; border-bottom: 1px solid #f0f0f0;
  position: sticky; top: 50px; z-index: 9;
}
.tab {
  flex: 1; text-align: center; padding: 10px 4px; font-size: 12px; color: #6b7280; cursor: pointer;
  position: relative; font-weight: 500; transition: color .15s; white-space: nowrap;
}
.tab.active { color: #111; font-weight: 600; }
.tab.active::after {
  content: ''; position: absolute; bottom: -1px; left: 50%;
  transform: translateX(-50%); width: 20px; height: 2px;
  border-radius: 1px; background: #111;
}

.list { padding: 12px 14px 0; display: flex; flex-direction: column; gap: 10px; }

.msg-card {
  display: flex; gap: 12px; align-items: flex-start;
  padding: 14px;
  background: var(--default-bg-color);
  border-radius: 14px;
  cursor: pointer; position: relative;
  transition: transform .15s, box-shadow .15s;
}
.msg-card:active { transform: scale(.985); }
.msg-card.unread { box-shadow: 0 2px 8px rgba(0,0,0,.06), 0 0 0 1px rgba(99,102,241,.12); }

.msg-avatar { width: 46px; height: 46px; flex-shrink: 0; margin-top: 1px; }
.msg-avatar img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; box-shadow: 0 0 0 1px rgba(0,0,0,.04); }

.msg-body { flex: 1; min-width: 0; }
.msg-name-row { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
.msg-name {
  font-size: 15px; font-weight: 600; color: #111;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.msg-date { font-size: 11px; color: #b0b0b0; flex-shrink: 0; font-weight: 400; }
.msg-tags { display: flex; align-items: center; gap: 5px; margin-top: 5px; }
.tag-role {
  display: inline-flex; align-items: center;
  padding: 2px 6px; border-radius: 4px;
  font-size: 10px; font-weight: 600; color: #6C5CE7;
  background: rgba(108,92,231,.08); letter-spacing: .2px;
}
.tag-title {
  display: inline-flex; align-items: center;
  padding: 2px 6px; border-radius: 4px;
  font-size: 10px; font-weight: 600; line-height: 1.4; letter-spacing: .2px;
}
.msg-content {
  font-size: 14px; color: #222; line-height: 1.55; margin-top: 7px;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}

.load-more { text-align: center; padding: 20px; font-size: 12px; color: #9ca3af; display: flex; align-items: center; justify-content: center; gap: 6px; }

.empty { display: flex; flex-direction: column; align-items: center; padding: 80px 0; gap: 12px; }
.empty-icon { width: 120px; height: 96px; }
.empty-text { font-size: 15px; color: #9ca3af; font-weight: 500; }
.empty-sub { font-size: 12px; color: #cbd5e1; }
</style>

<style>
.sheet-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.4); z-index: 1000; display: flex; align-items: flex-end; }
.sheet-panel { width: 100%; max-height: 75vh; background: #fff; border-radius: 16px 16px 0 0; display: flex; flex-direction: column; overflow: hidden; }
.sheet-handle { width: 36px; height: 4px; background: #ddd; border-radius: 2px; margin: 10px auto; flex-shrink: 0; }
.sheet-body { padding: 8px 20px 20px; overflow-y: auto; flex: 1; }
.sheet-user { display: flex; gap: 12px; align-items: center; margin-bottom: 16px; }
.sheet-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
.sheet-name { font-size: 16px; font-weight: 600; color: #111; }
.sheet-tags { display: flex; gap: 4px; margin-top: 2px; }
.s-role { font-size: 10px; padding: 1px 5px; border-radius: 3px; color: #7C3AED; background: rgba(124,58,237,.08); font-weight: 600; }
.s-title { font-size: 10px; padding: 1px 5px; border-radius: 3px; font-weight: 600; }
.s-time { margin-left: auto; font-size: 12px; color: #999; flex-shrink: 0; align-self: flex-start; }
.s-content-title { font-size: 17px; font-weight: 600; color: #111; line-height: 1.5; }
.s-content-text { font-size: 15px; color: #555; line-height: 1.7; margin-top: 10px; }
.sheet-actions { display: flex; gap: 10px; padding: 12px 20px 24px; border-top: 1px solid #eee; }
.sa-btn { flex: 1; padding: 12px; border-radius: 10px; border: 1px solid #e5e5e5; background: #fff; font-size: 15px; font-weight: 500; color: #333; cursor: pointer; }
.sa-btn.primary { background: #333; color: #fff; border-color: #333; }

.sheet-enter-active { transition: opacity .3s; }
.sheet-enter-active .sheet-panel { transition: transform .3s cubic-bezier(.2, .8, .3, 1); }
.sheet-leave-active { transition: opacity .25s; }
.sheet-leave-active .sheet-panel { transition: transform .25s ease-in; }
.sheet-enter-from { opacity: 0; }
.sheet-enter-from .sheet-panel { transform: translateY(100%); }
.sheet-leave-to { opacity: 0; }
.sheet-leave-to .sheet-panel { transform: translateY(100%); }
</style>
