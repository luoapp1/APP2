<template>
  <div class="app-detail-page min-h-screen app-page-bg relative">
    <!-- 顶部导航 -->
    <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
      <div class="flex items-center gap-3">
        <svg class="w-6 h-6 text-gray-800 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
        <span class="text-base font-semibold text-gray-900">{{ app?.name || '加载中...' }}-{{ app?.version || '' }}</span>
      </div>
      <div class="flex items-center gap-4">
        <svg class="w-5 h-5 cursor-pointer" :class="favorited ? 'text-red-500' : 'text-gray-400'" fill="currentColor"
          :stroke="favorited ? 'none' : 'none'" viewBox="0 0 24 24" @click="toggleFav">
          <path v-if="favorited" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          <path v-else fill="none" stroke="currentColor" stroke-width="2" d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
        </svg>
        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="6" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="18" r="2"/>
        </svg>
      </div>
    </div>

    <div class="overflow-y-auto" style="height: calc(100vh - 140px); padding-bottom: 60px;">
      <!-- 应用信息头部 -->
      <div class="flex items-start gap-3 px-4 py-4">
        <div class="flex-shrink-0">
          <div
            class="w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm"
            :style="{ background: app?.iconBgColor || '#00BFA5' }"
          >
            <svg v-if="!app?.icon" width="28" height="28" viewBox="0 0 24 24" fill="rgba(255,255,255,0.9)">
              <path d="M8 5v14l11-7z"/>
            </svg>
            <img v-else :src="$fixImgUrl(app.icon)" class="w-full h-full object-cover rounded-2xl"  loading="lazy" />
          </div>
        </div>
        <div class="flex-1 min-w-0">
          <h1 class="text-lg font-bold text-gray-900">{{ app?.name || '' }}</h1>
          <p class="text-xs text-gray-400 mt-0.5">{{ app?.packageName || '' }}</p>
          <div class="flex gap-1.5 mt-2 flex-wrap">
            <span
              v-for="tag in (app?.tags || [])"
              :key="tag"
              class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
              :class="tag === '星选' ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'"
            >
              <svg v-if="tag === '星选'" class="w-3 h-3 mr-0.5" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              {{ tag }}
            </span>
          </div>
        </div>
      </div>

      <!-- 数据统计行 -->
      <div class="flex items-center divide-x divide-gray-200 px-4 py-3 bg-gray-50/50 mx-4 rounded-xl">
        <div class="flex-1 text-center">
          <div class="text-sm font-semibold text-gray-800">{{ ratingText }}</div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ commentCountText }}</div>
        </div>
        <div class="flex-1 text-center">
          <div class="text-sm font-semibold text-gray-800">{{ app?.sizeMb ?? 0 }} MB</div>
          <div class="text-[11px] text-gray-400 mt-0.5">大小</div>
        </div>
        <div class="flex-1 text-center">
          <div class="text-sm font-semibold text-gray-800">{{ totalDownloads }}</div>
          <div class="text-[11px] text-gray-400 mt-0.5">下载</div>
        </div>
        <div class="flex-1 text-center">
          <div class="flex items-center justify-center gap-0.5">
            <svg class="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-9V6a1 1 0 112 0v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3z" clip-rule="evenodd"/></svg>
            <span class="text-sm font-semibold text-gray-800">{{ app?.coinCount ?? 0 }}$</span>
          </div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ app?.coinPeople ?? 0 }}人投币</div>
        </div>
      </div>

      <!-- Tab 切换 -->
      <div class="flex border-b border-gray-100 mt-4 px-4">
        <div
          v-for="tab in tabs"
          :key="tab"
          class="relative px-5 py-2.5 text-sm cursor-pointer transition-colors"
          :class="activeTab === tab ? 'text-[#00BFA5] font-semibold' : 'text-gray-500'"
          @click="activeTab = tab"
        >
          {{ tab }}
          <div
            v-if="activeTab === tab"
            class="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-full"
            style="background: #00BFA5"
          />
        </div>
      </div>

      <!-- Tab: 详情 -->
      <div v-if="activeTab === '详情'" class="px-4 pt-4">
        <div v-if="(app?.screenshots || []).length > 0" class="mb-5 overflow-x-auto">
          <div class="flex gap-3 pb-1" style="scroll-snap-type: x mandatory;">
            <div
              v-for="(shot, idx) in (app?.screenshots || [])"
              :key="idx"
              class="flex-shrink-0 w-[140px] h-[248px] rounded-2xl flex items-center justify-center relative overflow-hidden"
              :style="{ background: getShotBg(shot) }"
              style="scroll-snap-align: start;"
            >
              <img
                v-if="getShotImage(shot)"
                :src="getShotImage(shot)"
                class="w-full h-full object-cover absolute inset-0"
               loading="lazy" />
              <div v-else class="text-white text-center px-4">
                <div class="text-[15px] font-bold mb-1">{{ getShotText(shot) }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="bg-gray-50 rounded-xl px-3.5 py-3 mb-4">
          <p class="text-xs text-gray-400 leading-relaxed">
            该软件由用户上传，仅用于学习用途，请在下载后24小时内删除，如果造成您的权益受损请点击此处申诉
          </p>
        </div>

        <div class="flex items-start gap-3 mb-4 bg-white rounded-xl p-3 shadow-sm" v-if="bestComment">
          <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold" :style="{ background: bestComment.userAvatar || '#FFB74D' }">{{ (bestComment.userName || '?')[0] }}</div>
          <div class="flex-1 min-w-0">
            <div class="text-sm font-medium text-gray-800">{{ bestComment.userName }}</div>
            <p class="text-sm text-gray-600 mt-1 leading-relaxed" v-html="bestComment.content"></p>
          </div>
        </div>

        <div class="mb-5">
          <h3 class="text-base font-bold text-gray-900 mb-2">关于应用</h3>
          <p class="text-sm text-gray-500 leading-relaxed">{{ app?.description || '' }}</p>
        </div>

        <div class="mb-5">
          <h3 class="text-base font-bold text-gray-900 mb-2">更新内容</h3>
          <p class="text-xs text-gray-400 mb-1">版本{{ app?.version || '' }} 2024年08月07日</p>
          <p class="text-sm text-gray-500">{{ app?.updateContent || '暂无' }}</p>
        </div>

        <div class="mb-5">
          <div class="flex items-center justify-between py-3 border-b border-gray-50 cursor-pointer">
            <span class="text-sm text-gray-400">应用详情</span>
            <div class="flex items-center gap-1.5"><span class="text-sm text-gray-700">详情</span><svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg></div>
          </div>
          <div class="flex items-center justify-between py-3 border-b border-gray-50">
            <span class="text-sm text-gray-400">应用版本</span><span class="text-sm text-gray-700">{{ app?.version || '' }}({{ app?.versionCode || '' }})</span>
          </div>
          <div class="flex items-center justify-between py-3 border-b border-gray-50">
            <span class="text-sm text-gray-400">本地版本</span><span class="text-sm text-gray-400">未安装(0)</span>
          </div>
          <div class="flex items-center justify-between py-3 border-b border-gray-50 cursor-pointer">
            <span class="text-sm text-gray-400">举报</span>
            <div class="flex items-center gap-1.5"><span class="text-sm text-gray-700">去举报</span><svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg></div>
          </div>
        </div>

        <div class="mb-6">
          <h3 class="text-base font-bold text-gray-900 mb-3">随便看看</h3>
          <div class="flex gap-3 overflow-x-auto pb-1">
            <div
              v-for="rec in recommendApps"
              :key="rec.id"
              class="flex-shrink-0 w-[100px] h-[130px] rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer"
              :style="{ background: rec.iconBgColor || '#7C4DFF' }"
              @click="$router.push(`/appstore/detail/${rec.id}`)"
            >
              <div class="w-10 h-10 rounded-xl flex items-center justify-center" :style="{ background: 'rgba(255,255,255,0.2)' }">
                <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              </div>
              <span class="text-xs text-white font-medium">{{ rec.name }}</span>
              <span class="text-[10px] text-white/70">{{ rec.downloads || 0 }}人下载</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab: 讨论 -->
      <div v-if="activeTab === '讨论'" class="px-4 pt-4">
        <div class="flex items-start gap-4 mb-6">
          <div class="text-center">
            <div class="text-[40px] font-bold text-gray-800 leading-none">{{ ratingStats?.average?.toFixed(1) || '0.0' }}</div>
            <div class="text-xs text-gray-400 mt-1">{{ ratingStats?.total || 0 }}人评价</div>
          </div>
          <div class="flex-1 space-y-1.5 pt-1">
            <div v-for="star in 5" :key="star" class="flex items-center gap-2">
              <span class="text-xs text-gray-400 w-4">{{ 6-star }}</span>
              <svg class="w-3 h-3 text-gray-300" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              <div class="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden"><div class="h-full rounded-full" style="background: #00BFA5" :style="{ width: starPercent(6-star) + '%' }" /></div>
            </div>
          </div>
        </div>

        <div class="flex items-center justify-between mb-4">
          <h3 class="text-base font-bold text-gray-900">讨论</h3>
          <div class="flex bg-gray-100 rounded-full p-0.5">
            <span class="px-3 py-1 text-xs rounded-full cursor-pointer" :class="commentFilter === 'current' ? 'bg-white text-[#00BFA5] shadow-sm' : 'text-gray-500'" @click="commentFilter = 'current'">当前</span>
            <span class="px-3 py-1 text-xs rounded-full cursor-pointer" :class="commentFilter === 'all' ? 'bg-white text-[#00BFA5] shadow-sm' : 'text-gray-500'" @click="commentFilter = 'all'">全部</span>
          </div>
        </div>

        <div v-if="comments.length > 0" class="space-y-4 pb-20">
          <div v-for="comment in comments" :key="comment.id" class="flex items-start gap-3">
            <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold" :style="{ background: comment.userAvatar || '#FF5777' }">{{ (comment.userName || '?')[0] }}</div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2"><span class="text-sm font-medium text-gray-800">{{ comment.userName }}</span><span class="text-xs text-gray-400">{{ comment.createTime }}</span></div>
              <p class="text-sm text-gray-600 mt-1 leading-relaxed" v-html="comment.content"></p>
              <div v-if="comment.device || comment.version" class="flex items-center gap-3 mt-1.5">
                <span v-if="comment.device" class="text-[11px] text-gray-400">{{ comment.device }}</span>
                <span v-if="comment.version" class="text-[11px] text-green-500">{{ comment.version }}</span>
              </div>
              <div class="flex items-center gap-4 mt-2">
                <div class="flex items-center gap-1 text-gray-400 cursor-pointer"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg><span class="text-xs">{{ comment.replies || 0 }}</span></div>
                <div class="flex items-center gap-1 text-gray-400 cursor-pointer" @click="toggleLike(comment)"><svg class="w-4 h-4" :class="comment._liked ? 'text-red-400' : ''" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg><span class="text-xs">{{ comment.likes || 0 }}</span></div>
              </div>
            </div>
          </div>
        </div>
        <div v-else class="text-center py-12 text-gray-400 text-sm">暂无讨论，快来发表第一条评论吧~</div>

        <div class="fixed right-5 bottom-24 w-12 h-12 rounded-2xl bg-[#00BFA5] shadow-lg flex items-center justify-center cursor-pointer hover:scale-105 transition-transform z-10" @click="showCommentInput = !showCommentInput">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
        </div>

        <div v-if="showCommentInput" class="fixed inset-x-0 bottom-28 bg-white border-t shadow-lg p-4 z-20">
          <div class="flex items-start gap-3">
            <div class="w-9 h-9 rounded-full flex-shrink-0 bg-gray-200 flex items-center justify-center text-gray-500 text-xs font-bold">我</div>
            <div class="flex-1">
              <textarea v-model="newCommentText" class="w-full border-0 outline-none text-sm resize-none bg-gray-50 rounded-lg p-3" rows="2" placeholder="说点什么..."/>
              <div class="flex justify-end mt-2">
                <el-button size="small" @click="showCommentInput = false">取消</el-button>
                <el-button size="small" type="primary" :style="{ background: '#00BFA5', borderColor: '#00BFA5' }" @click="postComment">发布</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab: 版本 -->
      <div v-if="activeTab === '版本'" class="px-4 pt-4 pb-20">
        <div class="space-y-3">
          <div
            v-for="ver in versions"
            :key="ver.id"
            class="flex items-center gap-3 py-3"
          >
            <!-- 左侧图标 -->
            <div class="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                 :style="{ background: ver.tags?.includes('星选') ? '#7C4DFF' : (app?.iconBgColor || '#00BFA5') }">
              <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <!-- 中间信息 -->
            <div class="flex-1 min-w-0">
              <div class="text-sm font-semibold text-gray-900">{{ app?.name || '神奇影视' }}</div>
              <div class="flex items-center gap-2 mt-0.5">
                <span class="text-xs text-[#00BFA5] font-medium">{{ ver.rating?.toFixed(1) || '0.0' }}</span>
                <span class="text-xs text-gray-400">{{ ver.version }}</span>
              </div>
              <div class="flex items-center gap-2 mt-1">
                <span
                  v-for="tag in (ver.tags || [])"
                  :key="tag"
                  class="text-[10px] px-1.5 py-0.5 rounded-full"
                  :class="tag === '星选' ? 'bg-purple-100 text-purple-600' : 'bg-teal-50 text-teal-600'"
                >{{ tag }}</span>
                <span class="text-[11px] text-gray-400">{{ ver.sizeMb }} MB</span>
                <span v-if="ver.isCurrent" class="text-[11px] text-gray-400">(当前)</span>
                <span class="text-[11px] text-gray-300">·</span>
                <span class="text-[11px] text-gray-400">{{ formatDownloads(ver.downloads) }}下载</span>
              </div>
            </div>
            <!-- 右侧下载按钮 -->
            <button
              class="flex-shrink-0 px-4 py-1.5 rounded-full border text-xs font-medium transition-colors"
              :style="{ borderColor: '#00BFA5', color: '#00BFA5' }"
              @click="doDownload(ver)"
            >下载</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部操作栏 -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-between px-5 py-2 z-10" style="height: 60px;">
      <div class="flex flex-col items-center gap-0.5 cursor-pointer">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.5"/><text x="12" y="16" text-anchor="middle" fill="currentColor" stroke="none" font-size="12" font-weight="bold">$</text></svg>
        <span class="text-[10px] text-gray-500">投币</span>
      </div>
      <el-button type="primary" size="large" class="!rounded-full !px-14 !font-semibold !text-base" :style="{ background: '#00BFA5', borderColor: '#00BFA5', height: '42px' }" @click="doDownload(null)">下载 {{ app?.sizeMb ?? '0' }} MB</el-button>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v13"/></svg>
        <span class="text-[10px] text-gray-500">分享</span>
      </div>
    </div>
    <!-- 购买弹窗 -->
    <div v-if="showPurchaseDialog" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showPurchaseDialog = false">
      <div class="w-full max-w-md bg-white rounded-2xl p-6 max-h-[85vh] overflow-y-auto" @click.stop>
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-bold text-gray-900">购买应用</h3>
          <svg class="w-6 h-6 text-gray-400 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="showPurchaseDialog = false">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </div>
        <div class="bg-gray-50 rounded-xl p-4 mb-4">
          <div class="flex items-center gap-3 mb-3">
            <div class="w-12 h-12 rounded-xl flex items-center justify-center" :style="{ background: app?.iconBgColor || '#00BFA5' }">
              <img v-if="app?.icon" :src="$fixImgUrl(app.icon)" class="w-full h-full object-cover rounded-xl"  loading="lazy" />
              <svg v-else class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div>
              <div class="text-sm font-semibold text-gray-900">{{ app?.name }}</div>
              <div class="text-xs text-gray-400">v{{ app?.version }}</div>
            </div>
          </div>
          <div class="border-t border-gray-200 pt-3 space-y-2">
            <div class="flex justify-between text-sm">
              <span class="text-gray-500">原价</span>
              <span class="text-gray-800">{{ purchasePriceInfo?.priceAmount }} {{ purchasePriceInfo?.unit }}</span>
            </div>
            <div class="flex justify-between text-sm" v-if="purchasePriceInfo?.hasDiscount">
              <span class="text-gray-500">会员折扣 ({{ purchasePriceInfo?.levelName }})</span>
              <span class="text-orange-500">{{ Math.round((purchasePriceInfo?.discountRate || 1) * 100) }}%</span>
            </div>
            <div class="flex justify-between text-sm font-semibold border-t border-gray-200 pt-2">
              <span class="text-gray-700">实付</span>
              <span class="text-red-500 text-base">{{ purchasePriceInfo?.finalPrice }} {{ purchasePriceInfo?.unit }}</span>
            </div>
          </div>
        </div>
        <div class="flex items-center justify-between text-xs text-gray-400 mb-4 px-1">
          <span>当前会员: {{ purchasePriceInfo?.levelName || '普通会员' }}</span>
          <span>我的{{ purchasePriceInfo?.unit === '积分' ? '积分' : '余额' }}: {{ purchasePriceInfo?.myBalance }}</span>
        </div>
        <button
          class="w-full py-3 rounded-xl text-white font-semibold text-base transition-opacity"
          :style="{ background: '#00BFA5' }"
          :disabled="purchaseLoading"
          @click="confirmPurchase"
        >
          {{ purchaseLoading ? '处理中...' : `确认购买 ${purchasePriceInfo?.finalPrice || 0} ${purchasePriceInfo?.unit || ''}` }}
        </button>
        <p class="text-center text-xs text-gray-400 mt-2">购买后可永久下载该应用</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchAppDetail, fetchPostComment, fetchRecommendApps, fetchPurchaseApp, fetchPurchaseStatus } from '@/api/appstore'
import { toggleFavorite, checkFavorite } from '@/api/app-favorite'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const openDownload = async (originalUrl: string) => {
  try {
    const res: any = await request.get({ url: '/api/storage/sign-url', params: { url: originalUrl } })
    const signedUrl = res?.data?.url || res?.url || originalUrl
    window.open(signedUrl, '_blank')
  } catch {
    window.open(originalUrl, '_blank')
  }
}

const route = useRoute()
const userStore = useUserStore()
const userId = computed(() => userStore.getUserInfo.userId || 0)
const currentUser = computed(() => userStore.getUserInfo)
const app = ref<any>(null)
const comments = ref<any[]>([])
const versions = ref<any[]>([])
const ratingStats = ref<any>({ average: 0, total: 0, distribution: {} })
const recommendApps = ref<any[]>([])
const activeTab = ref('详情')
const purchaseStatus = ref<any>(null)
const showPurchaseDialog = ref(false)
const purchaseLoading = ref(false)
const favorited = ref(false)
const favLoading = ref(false)

function getShotBg(shot: any) {
  if (typeof shot === 'string') return '#333'
  return shot.bgColor || '#00BFA5'
}
function getShotImage(shot: any) {
  if (typeof shot === 'string') return shot
  return shot.image || ''
}
function getShotText(shot: any) {
  if (typeof shot === 'string') return ''
  return shot.text || ''
}

const newCommentText = ref('')
const showCommentInput = ref(false)
const commentFilter = ref('current')

const tabs = ['详情', '讨论', '版本']

const ratingText = computed(() => `${(app.value?.rating || 0).toFixed(1)}★`)
const commentCountText = computed(() => `${ratingStats.value?.total || 0}条评论`)

const totalDownloads = computed(() => {
  const vd = versions.value.reduce((sum: number, v: any) => sum + (v.downloads || 0), 0)
  return vd > 0 ? vd : (app.value?.downloads || 0)
})

const bestComment = computed(() => comments.value.find((c: any) => c.rating >= 4) || comments.value[0] || null)

const starPercent = (star: number) => {
  const dist = ratingStats.value?.distribution || {}
  const max = Math.max(...Object.values(dist), 1)
  return Math.round(((dist[star] || 0) / max) * 100)
}

const formatDownloads = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
  return String(n)
}

const getDownloadUrl = (ver: any): string => {
  if (ver) return ver.downloadUrl || ''
  const cur = versions.value.find((v: any) => v.isCurrent)
  return cur?.downloadUrl || app.value?.downloadUrl || ''
}

const doDownload = async (ver: any) => {
  const uid = userId.value
  if (!uid || uid <= 0) {
    ElMessage.warning('请先登录')
    return
  }
  const appData = app.value
  if (!appData) {
    ElMessage.warning('应用数据加载中，请稍后重试')
    return
  }

  // 上传者自己免费下载
  if (appData.userId > 0 && Number(appData.userId) === Number(uid)) {
    const url = getDownloadUrl(ver)
    if (url) {
      openDownload(url)
      ElMessage.success('上传者免费下载')
    } else {
      ElMessage.warning('暂无下载链接')
    }
    return
  }

  // 免费应用直接下载
  const priceType = appData.priceType || 'free'
  const priceAmount = Number(appData.priceAmount || 0)
  if (priceType === 'free' || priceAmount <= 0) {
    try {
      await fetchPurchaseApp(appData.id, uid, 'free')
      const url = getDownloadUrl(ver)
      if (url) {
        openDownload(url)
        ElMessage.success('免费下载')
      } else {
        ElMessage.warning('暂无下载链接')
      }
    } catch {
      ElMessage.error('获取下载权限失败')
    }
    return
  }

  // 检查购买状态
  try {
    const ps = await fetchPurchaseStatus(appData.id, uid)
    purchaseStatus.value = ps
    if ((ps as any)?.purchased) {
      const url = getDownloadUrl(ver)
      if (url) {
        openDownload(url)
        ElMessage.success('已购买，开始下载')
      } else {
        ElMessage.warning('暂无下载链接')
      }
      return
    }
  } catch (e) {
    // 网络错误，也弹窗让用户手动购买
  }

  // 收费应用 — 显示购买弹窗
  showPurchaseDialog.value = true
}

const purchasePriceInfo = computed(() => {
  const appData = app.value
  if (!appData) return null
  const priceType = appData.priceType || 'free'
  const priceAmount = Number(appData.priceAmount || 0)
  const user = currentUser.value
  const discountRate = priceType === 'points' ? (Number(user.pointsDiscountRate) || 1) : (Number(user.discountRate) || 1)
  const finalPrice = Math.round(priceAmount * discountRate * 100) / 100
  const unit = priceType === 'balance' ? '元' : '积分'
  const myBalance = priceType === 'balance' ? Number(user.balance || 0) : Number(user.points || 0)
  return { priceType, priceAmount, discountRate, finalPrice, unit, myBalance,
    levelName: user.levelName || '普通会员',
    hasDiscount: discountRate < 1 }
})

const confirmPurchase = async () => {
  purchaseLoading.value = true
  try {
    const appData = app.value
    const info = purchasePriceInfo.value
    const uid = userId.value
    const res: any = await fetchPurchaseApp(appData.id, uid, info?.priceType)
    showPurchaseDialog.value = false
    ElMessage.success('购买成功，开始下载')
    if (res?.newBalance !== undefined) userStore.setUserInfo({ ...(userStore.getUserInfo as any), balance: res.newBalance })
    if (res?.newPoints !== undefined) userStore.setUserInfo({ ...(userStore.getUserInfo as any), points: res.newPoints })
    const url = getDownloadUrl(null)
    if (url) openDownload(url)
  } catch (e: any) {
    ElMessage.warning(e?.msg || e?.message || '购买失败')
  } finally {
    purchaseLoading.value = false
  }
}

const loadData = async () => {
  const id = route.params.id as string
  if (!id) return
  try {
    const uid = userId.value
    const res = await fetchAppDetail(Number(id), uid || undefined)
    app.value = res.app
    comments.value = res.comments || []
    versions.value = res.versions || []
    ratingStats.value = res.ratingStats || { average: 0, total: 0, distribution: {} }
  } catch (e) { console.error(e) }
}

const loadRecommend = async () => {
  try { const res = await fetchRecommendApps(); recommendApps.value = res || [] } catch {}
}

const toggleLike = (comment: any) => {
  comment._liked = !comment._liked
  comment.likes = (comment._liked ? (comment.likes || 0) + 1 : Math.max(0, (comment.likes || 1) - 1))
}

const postComment = async () => {
  if (!newCommentText.value.trim()) { ElMessage.warning('请输入评论内容'); return }
  const id = route.params.id as string
  try {
    await fetchPostComment(Number(id), { userName: '我', content: newCommentText.value, device: 'web' })
    ElMessage.success('评论成功'); newCommentText.value = ''; showCommentInput.value = false; loadData()
  } catch (e) { ElMessage.error('评论失败') }
}

async function checkFavStatus() {
  if (!userId.value) return
  try {
    const res: any = await checkFavorite(userId.value, Number(route.params.id))
    favorited.value = res?.data?.favorited || false
  } catch {}
}

async function toggleFav() {
  if (!userId.value) { ElMessage.warning('请先登录'); return }
  favLoading.value = true
  try {
    const res: any = await toggleFavorite({ userId: userId.value, appId: Number(route.params.id) })
    favorited.value = res?.data?.favorited || false
    ElMessage.success(favorited.value ? '已收藏' : '已取消收藏')
  } catch (e: any) { ElMessage.error(e.message) }
  finally { favLoading.value = false }
}

onMounted(() => { loadData(); loadRecommend(); checkFavStatus() })
</script>

<style scoped>
@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.animate-slide-up {
  animation: slide-up 0.3s ease-out;
}
</style>
