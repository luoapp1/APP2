<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">审核管理中心</span>
    </div>

    <!-- Tab 切换 -->
    <div class="bg-white px-4 pt-1 pb-3">
      <div class="flex bg-gray-100 rounded-xl p-1">
        <button
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200"
          :class="activeTab === 'post' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = 'post'; fetchData()"
        >帖子审核</button>
        <button
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200"
          :class="activeTab === 'unlock' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = 'unlock'; fetchUnlockData()"
        >解锁申请</button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- ====== 帖子审核 ====== -->
      <template v-if="activeTab === 'post'">

      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-center">
          <div class="text-2xl font-bold text-[#F59E0B]">{{ total }}</div>
          <div class="text-[11px] text-gray-400 mt-1">待审核帖子</div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showDetail(item)">
            <div class="flex items-start gap-3">
              <img :src="$fixImgUrl(item.userAvatar)" class="w-10 h-10 rounded-full object-cover flex-shrink-0 bg-gray-100" @error="($event.target as HTMLImageElement).src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22%3E%3Ccircle cx=%2212%22 cy=%228%22 r=%224%22 fill=%22%23ccc%22/%3E%3Cpath d=%22M4 20c0-4 4-7 8-7s8 3 8 7%22 fill=%22%23ccc%22/%3E%3C/svg%3E'"  loading="lazy" />
              <div class="flex-1 min-w-0">
                <div class="text-sm font-semibold text-gray-800 line-clamp-1 mb-1">{{ item.title }}</div>
                <div class="flex items-center gap-2 text-xs text-gray-400 mb-1">
                  <span>{{ item.userName }}</span>
                  <span>ID:{{ item.id }}</span>
                  <span v-if="item.sectionId" class="px-1 py-0.5 bg-gray-100 rounded text-[10px]">板块{{ item.sectionId }}</span>
                  <span v-if="item.hasResource" class="px-1 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">含资源</span>
                  <span v-if="item.contentPermission === 'pay'" class="px-1 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">付费{{ item.contentPrice }}元</span>
                  <span v-if="item.contentPermission === 'vip'" class="px-1 py-0.5 bg-amber-50 text-amber-600 rounded text-[10px]">VIP</span>
                  <span v-if="item.contentPermission === 'points'" class="px-1 py-0.5 bg-green-50 text-green-600 rounded text-[10px]">{{ item.contentPrice }}积分</span>
                </div>
                <div class="text-xs text-gray-300">{{ item.createTime }}</div>
                <!-- 内容块预览 -->
                <div v-if="parseContentBlocks(item.content).length > 0" class="mt-1.5">
                  <div class="flex flex-wrap gap-1 mb-1">
                    <span v-for="(blk, bi) in parseContentBlocks(item.content)" :key="'b'+bi" class="text-[10px] px-1.5 py-0.5 rounded" :class="blockTypeColor(blk.type)">{{ blockTypeLabel(blk.type) }}</span>
                  </div>
                  <div class="text-xs text-gray-500 line-clamp-2">{{ contentPreview(item.content) }}</div>
                </div>
                <div v-else class="text-xs text-gray-500 line-clamp-2 mt-1" v-html="stripHtml(item.content)" />
              </div>
              <div class="flex gap-1 flex-shrink-0" @click.stop>
                <button class="h-7 px-3 text-xs rounded-lg bg-green-50 text-green-600 active:bg-green-100 font-medium" @click="approveItem(item)">通过</button>
                <button class="h-7 px-3 text-xs rounded-lg bg-red-50 text-red-500 active:bg-red-100 font-medium" @click="showReject(item)">驳回</button>
              </div>
            </div>
          </div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无待审核帖子</span>
        </div>
      </div>
      </template>

      <!-- ====== 解锁申请 ====== -->
      <template v-if="activeTab === 'unlock'">
      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-center">
          <div class="text-2xl font-bold text-[#F59E0B]">{{ unlockTotal }}</div>
          <div class="text-[11px] text-gray-400 mt-1">待审核解锁申请</div>
        </div>
      </div>
      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="unlockLoading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>
        <template v-else-if="unlockList.length > 0">
          <div v-for="item in unlockList" :key="'ul-' + item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.user_name }}</span>
                  <span class="text-[10px] text-gray-400">用户ID:{{ item.user_id }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="unlockStatusClass(item.status)">{{ unlockStatusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-500 mb-1"><span class="text-gray-400">目标帖子：</span>{{ item.title || '帖子ID:' + item.post_id }}</div>
                <div class="text-xs text-gray-500 mb-0.5"><span class="text-gray-400">申请理由：</span>{{ item.reason || '-' }}</div>
                <div class="text-xs text-gray-300">申请时间：{{ item.create_time }}</div>
                <div v-if="item.status === 'rejected' && item.reply" class="text-xs text-red-400 mt-0.5">驳回原因：{{ item.reply }}</div>
              </div>
              <div v-if="item.status === 'pending'" class="flex gap-2 ml-2 flex-shrink-0" @click.stop>
                <button class="text-xs px-2 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="handleUnlockApprove(item.id)">通过</button>
                <button class="text-xs px-2 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="showUnlockReject(item.id)">拒绝</button>
              </div>
              <span v-else class="text-xs text-gray-300">已处理</span>
            </div>
          </div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无解锁申请</span>
        </div>
      </div>
      </template>
    </div>

    <!-- 帖子详情弹窗 -->
    <div v-if="detailVisible" class="fixed inset-0 z-50 flex flex-col bg-white" @click.self="detailVisible=false">
      <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
        <button class="text-gray-400" @click="detailVisible=false">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        </button>
        <span class="text-sm font-bold text-gray-800">帖子详情</span>
        <div class="w-5" />
      </div>

      <div class="flex-1 overflow-y-auto" v-if="detailItem">
        <!-- 作者信息 -->
        <div class="p-4 border-b border-gray-50">
          <div class="flex items-center gap-3">
            <img :src="$fixImgUrl(detailItem.userAvatar)" class="w-11 h-11 rounded-full object-cover bg-gray-100" @error="($event.target as HTMLImageElement).src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22%3E%3Ccircle cx=%2212%22 cy=%228%22 r=%224%22 fill=%22%23ccc%22/%3E%3Cpath d=%22M4 20c0-4 4-7 8-7s8 3 8 7%22 fill=%22%23ccc%22/%3E%3C/svg%3E'"  loading="lazy" />
            <div>
              <div class="text-sm font-semibold text-gray-800">{{ detailItem.userName }}</div>
              <div class="text-xs text-gray-400">用户ID: {{ detailItem.userId }} · 板块ID: {{ detailItem.sectionId || '-' }}</div>
            </div>
          </div>
        </div>

        <!-- 标题 -->
        <div class="px-4 pt-4">
          <h2 class="text-base font-bold text-gray-900 leading-relaxed">{{ detailItem.title }}</h2>
          <div class="flex items-center gap-2 mt-2 text-xs text-gray-400">
            <span>{{ detailItem.createTime }}</span>
            <span v-if="detailItem.hasResource" class="px-1.5 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">{{ detailItem.resourceType || '含资源' }}</span>
          </div>
        </div>

        <!-- 付费内容卡片 -->
        <div v-if="detailItem.contentPermission !== 'public'" class="px-4 pt-3">
          <div class="rounded-xl p-3.5 border-2" :class="detailItem.contentPermission === 'vip' ? 'border-amber-200 bg-amber-50' : 'border-blue-200 bg-blue-50'">
            <div class="flex items-center gap-2 mb-2">
              <svg v-if="detailItem.contentPermission === 'vip'" class="w-5 h-5 text-amber-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              <svg v-else class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <span class="text-sm font-bold" :class="detailItem.contentPermission === 'vip' ? 'text-amber-700' : 'text-blue-700'">
                {{ detailItem.contentPermission === 'vip' ? 'VIP 专属内容' : detailItem.contentPermission === 'pay' ? '付费阅读内容' : detailItem.contentPermission === 'points' ? '积分阅读内容' : '付费内容' }}
              </span>
            </div>
            <div class="space-y-1.5">
              <div class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">内容价格</span>
                <span class="font-semibold" :class="detailItem.contentPermission === 'vip' ? 'text-amber-600' : 'text-blue-600'">
                  <template v-if="detailItem.contentPermission === 'vip'">VIP会员专享</template>
                  <template v-else>{{ detailItem.contentPrice || 0 }} {{ detailItem.contentPriceType === 'money' ? '元' : detailItem.contentPriceType === 'points' ? '积分' : detailItem.contentPriceType }}</template>
                </span>
              </div>
              <div v-if="detailItem.contentPermission === 'pay' || detailItem.contentPermission === 'points'" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">免费预览</span>
                <span class="text-gray-700">{{ detailItem.freeRead ? '前' + detailItem.freeCount + '字免费' : '无免费预览' }}</span>
              </div>
              <div v-if="detailItem.hasResource" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">资源价格</span>
                <span class="font-semibold text-orange-600">{{ detailItem.resourcePrice || 0 }} {{ detailItem.resourcePriceType === 'money' ? '元' : detailItem.resourcePriceType === 'points' ? '积分' : detailItem.resourcePriceType === 'free' ? '免费' : detailItem.resourcePriceType }}</span>
              </div>
              <div v-if="detailItem.extractCode" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">提取码</span>
                <code class="bg-white px-1.5 py-0.5 rounded text-[#FF4757] font-mono text-xs">{{ detailItem.extractCode }}</code>
              </div>
              <div v-if="detailItem.accessPassword" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">访问密码</span>
                <code class="bg-white px-1.5 py-0.5 rounded text-[#FF4757] font-mono text-xs">{{ detailItem.accessPassword }}</code>
                <span v-if="detailItem.accessPasswordTips" class="text-gray-400">（{{ detailItem.accessPasswordTips }}）</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 内容块渲染 -->
        <div class="px-4 py-3">
          <div class="text-xs text-gray-400 mb-2">正文内容</div>
          <template v-if="parseContentBlocks(detailItem.content).length > 0">
            <div v-for="(blk, bi) in parseContentBlocks(detailItem.content)" :key="'db'+bi" class="mb-3">
              <!-- 类型标签 -->
              <div class="flex items-center gap-2 mb-1.5">
                <span class="text-[10px] px-1.5 py-0.5 rounded" :class="blockTypeColor(blk.type)">{{ blockTypeLabel(blk.type) }}</span>
                <span v-if="blk.visibility && blk.visibility !== 'public'" class="text-[10px] px-1.5 py-0.5 rounded bg-yellow-50 text-yellow-600">{{ blk.visibility === 'paid' ? '付费' : blk.visibility === 'login' ? '登录可见' : blk.visibility === 'comment' ? '评论可见' : blk.visibility === 'level' ? '等级可见' : blk.visibility === 'password' ? '密码可见' : blk.visibility }}</span>
              </div>
              <!-- Text -->
              <div v-if="blk.type === 'text' && blk.value" class="text-sm text-gray-700 leading-relaxed" v-html="sanitizeContent(blk.value)" />
              <!-- Image -->
              <div v-else-if="blk.type === 'image' && blk.images && blk.images.length" class="grid gap-2" :class="blk.images.length === 1 ? 'grid-cols-1' : blk.images.length <= 3 ? 'grid-cols-3' : 'grid-cols-2'">
                <img v-for="(img, ii) in blk.images" :key="ii" :src="$fixImgUrl(img)" class="w-full aspect-square rounded-lg object-cover border border-gray-100"  loading="lazy" />
              </div>
              <!-- Attachment -->
              <div v-else-if="blk.type === 'attachment'" class="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100">
                <div class="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                  <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm font-medium text-gray-700">{{ blk.title || blk.fileName || '附件' }}</div>
                  <div class="text-xs text-gray-400">{{ blk.desc || '' }}</div>
                </div>
                <span v-if="blk.coin && blk.coin > 0" class="text-xs font-semibold text-orange-500">{{ blk.coin }}{{ blk.priceType === 'points' ? '积分' : '余额' }}</span>
                <span v-else class="text-xs text-green-500">免费</span>
              </div>
              <!-- Link -->
              <div v-else-if="blk.type === 'link'" class="flex items-center gap-3 p-3 rounded-xl bg-purple-50 border border-purple-100">
                <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <svg class="w-5 h-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm font-medium text-gray-700">{{ blk.title || '链接' }}</div>
                  <div class="text-xs text-gray-400 truncate">{{ blk.url || '' }}</div>
                </div>
              </div>
              <!-- App -->
              <div v-else-if="blk.type === 'app'" class="flex items-center gap-3 p-3 rounded-xl bg-pink-50 border border-pink-100">
                <div class="w-10 h-10 rounded-lg bg-pink-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  <img v-if="blk.appIcon" :src="$fixImgUrl(blk.appIcon)" class="w-full h-full object-cover"  loading="lazy" />
                  <span v-else class="text-sm font-bold text-pink-500">{{ (blk.appName || 'A')[0] }}</span>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm font-medium text-gray-700">{{ blk.appName || '应用' }}</div>
                  <div class="text-xs text-gray-400">{{ blk.desc || '' }}</div>
                </div>
                <span v-if="blk.coinCount && blk.coinCount > 0" class="text-xs font-semibold text-pink-500">{{ blk.coinCount }}余额</span>
                <span v-else class="text-xs text-green-500">免费</span>
              </div>
            </div>
          </template>
          <div v-else class="text-sm text-gray-700 leading-relaxed prose prose-sm max-w-none" v-html="sanitizeContent(detailItem.content) || '<span class=\'text-gray-400\'>无正文内容</span>'" />
        </div>

        <!-- 付费隐藏内容 -->
        <div v-if="detailItem.hiddenContent" class="px-4 pb-3">
          <div class="rounded-xl p-3.5 bg-gray-50 border border-dashed border-gray-300">
            <div class="flex items-center gap-1.5 text-xs text-gray-400 mb-2">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
              <span>付费后可见内容</span>
            </div>
            <div class="text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none" v-html="sanitizeContent(detailItem.hiddenContent)" />
          </div>
        </div>

        <!-- 图片 -->
        <div v-if="detailItem.images && detailItem.images.length > 0" class="px-4 pb-3">
          <div class="text-xs text-gray-400 mb-2">附件图片 ({{ detailItem.images.length }})</div>
          <div class="grid grid-cols-3 gap-2">
            <img v-for="(img, i) in detailItem.images" :key="i" :src="$fixImgUrl(img)" class="w-full aspect-square rounded-lg object-cover border border-gray-100"  loading="lazy" />
          </div>
        </div>
      </div>

      <!-- 操作栏 -->
      <div class="flex gap-3 px-4 py-3 border-t border-gray-100 bg-white flex-shrink-0" v-if="detailItem">
        <button class="flex-1 h-11 rounded-xl bg-green-500 text-white text-sm font-semibold active:opacity-80" @click="approveItem(detailItem)">审核通过</button>
        <button class="flex-1 h-11 rounded-xl bg-red-500 text-white text-sm font-semibold active:opacity-80" @click="showReject(detailItem); detailVisible=false">驳回帖子</button>
      </div>
    </div>

    <!-- 驳回原因弹窗 -->
    <div v-if="rejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="rejectVisible=false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="rejectVisible=false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">驳回帖子</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="doReject">确认驳回</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">驳回原因</label>
          <textarea v-model="rejectReason" rows="3" placeholder="请输入驳回原因（选填）" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>

    <!-- 解锁拒绝原因弹窗 -->
    <div v-if="unlockRejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="unlockRejectVisible=false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="unlockRejectVisible=false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">拒绝解锁</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="doUnlockReject">确认</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">拒绝原因</label>
          <textarea v-model="unlockRejectReason" rows="3" placeholder="请输入拒绝原因（选填）" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import request from '@/utils/http'

defineOptions({ name: 'PostReviewMobile' })

const activeTab = ref<'post' | 'unlock'>('post')

const toastMsg = ref('')
const toastType = ref<'success'|'error'>('success')
let toastTimer: any
const showToast = (m: string, t: 'success'|'error'='success') => {
  toastMsg.value = m; toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const loading = ref(false)
const list = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize)))

const detailVisible = ref(false)
const detailItem = ref<any>(null)

const rejectVisible = ref(false)
const rejectTarget = ref<any>(null)
const rejectReason = ref('')

async function fetchData() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/community/admin/posts/pending', params: { page: page.value, pageSize } })
    list.value = res?.list || []
    total.value = res?.total || 0
  } catch (e: any) {
    showToast('加载失败: ' + (e.message || e), 'error')
  }
  loading.value = false
}

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  fileName?: string
  coin?: number
  coinCount?: number
  priceType?: string
  appId?: number
  appName?: string
  appIcon?: string
  visibility?: string
}

function parseContentBlocks(content: string): ContentBlock[] {
  if (!content) return []
  try {
    const parsed = JSON.parse(content)
    if (Array.isArray(parsed)) return parsed
    if (parsed && typeof parsed === 'object' && parsed.type) return [parsed]
  } catch {}
  return []
}

function contentPreview(content: string): string {
  const blocks = parseContentBlocks(content)
  if (blocks.length === 0) return stripHtml(content)
  return blocks.map(b => {
    if (b.type === 'text') return stripHtml(b.value || '')
    if (b.type === 'image') return `[图片 x${(b.images || []).length || 1}]`
    if (b.type === 'attachment') return `[附件] ${b.title || b.fileName || ''}`
    if (b.type === 'link') return `[链接] ${b.title || b.url || ''}`
    if (b.type === 'app') return `[应用] ${b.appName || ''}`
    return stripHtml(b.value || '')
  }).join(' ').substring(0, 100)
}

/** 获取内容块类型标签文字 */
function blockTypeLabel(type: string): string {
  const m: Record<string, string> = { text: '文本', image: '图片', attachment: '附件', link: '链接', app: '应用' }
  return m[type] || type
}
/** 获取内容块类型标签颜色 */
function blockTypeColor(type: string): string {
  const m: Record<string, string> = { text: 'bg-blue-50 text-blue-500', image: 'bg-green-50 text-green-500', attachment: 'bg-orange-50 text-orange-500', link: 'bg-purple-50 text-purple-500', app: 'bg-pink-50 text-pink-500' }
  return m[type] || 'bg-gray-100 text-gray-500'
}

function stripHtml(html: string): string {
  if (!html) return ''
  return html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').substring(0, 100)
}

function sanitizeContent(html: string): string {
  if (!html) return ''
  return sanitizeHtml(html)
}

function showDetail(item: any) {
  detailItem.value = item
  detailVisible.value = true
}

async function approveItem(item: any) {
  try {
    await request.post({ url: `/api/community/admin/post/${item.id}/approve` })
    showToast('已通过审核', 'success')
    detailVisible.value = false
    fetchData()
  } catch (e: any) {
    showToast('操作失败: ' + (e.message || e), 'error')
  }
}

function showReject(item: any) {
  rejectTarget.value = item
  rejectReason.value = ''
  rejectVisible.value = true
}

async function doReject() {
  if (!rejectTarget.value) return
  try {
    await request.post({
      url: `/api/community/admin/post/${rejectTarget.value.id}/reject`,
      data: { reason: rejectReason.value || '内容不符合规范' }
    })
    showToast('已驳回', 'success')
    rejectVisible.value = false
    rejectTarget.value = null
    fetchData()
  } catch (e: any) {
    showToast('操作失败: ' + (e.message || e), 'error')
  }
}

// --- 解锁申请 ---
const unlockLoading = ref(false)
const unlockList = ref<any[]>([])
const unlockTotal = ref(0)

const unlockStatusMap: Record<string, string> = { pending: '待审核', approved: '已通过', rejected: '已拒绝' }
const unlockStatusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', approved: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }
const unlockStatusText = (s: string) => unlockStatusMap[s] || s
const unlockStatusClass = (s: string) => unlockStatusClassMap[s] || 'bg-gray-100 text-gray-500'

const unlockRejectVisible = ref(false)
const unlockRejectTargetId = ref(0)
const unlockRejectReason = ref('')

async function fetchUnlockData() {
  unlockLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/community/admin/unlock-requests' })
    unlockList.value = res?.list || res?.data?.list || res || []
    unlockTotal.value = unlockList.value.filter((r: any) => r.status === 'pending').length
  } catch (e: any) {
    showToast('加载失败: ' + (e.message || e), 'error')
  }
  unlockLoading.value = false
}

async function handleUnlockApprove(id: number) {
  try {
    await request.post({ url: `/api/community/admin/unlock-request/${id}/handle`, data: { action: 'approve' } })
    showToast('已通过解锁申请', 'success')
    fetchUnlockData()
  } catch (e: any) { showToast('操作失败: ' + (e.message || e), 'error') }
}

function showUnlockReject(id: number) {
  unlockRejectTargetId.value = id; unlockRejectReason.value = ''; unlockRejectVisible.value = true
}

async function doUnlockReject() {
  if (!unlockRejectTargetId.value) return
  try {
    await request.post({
      url: `/api/community/admin/unlock-request/${unlockRejectTargetId.value}/handle`,
      data: { action: 'reject', reply: unlockRejectReason.value || '驳回' }
    })
    showToast('已拒绝解锁申请', 'success')
    unlockRejectVisible.value = false
    fetchUnlockData()
  } catch (e: any) { showToast('操作失败: ' + (e.message || e), 'error') }
}

onMounted(() => { fetchData(); fetchUnlockData() })

watch(activeTab, (tab) => { if (tab === 'unlock') fetchUnlockData() })
</script>
