<template>
  <div class="min-h-screen flex flex-col" style="background:var(--default-bg-color)">
    <div class="flex-1">

      <!-- 顶部搜索区 -->
      <div class="flex items-center gap-3 px-4 py-3">
        <div class="w-[36px] h-[36px] rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
          <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#d1d5db"/><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" fill="white"/></svg>
        </div>
        <div class="flex-1 flex items-center bg-gray-100 rounded-full px-3 py-2 gap-2 cursor-pointer active:opacity-70" @click="router.push('/community/search')">
          <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
          <span class="text-sm text-gray-400">搜索帖子、应用、用户</span>
        </div>
        <svg class="w-5 h-5 text-gray-500 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
        <svg class="w-5 h-5 text-gray-500 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
      </div>

      <!-- 顶部标签 -->
      <div class="sticky top-0 z-10 border-b border-gray-50" style="background:var(--default-bg-color)">
        <div class="flex px-4">
          <div
            v-for="tab in tabs"
            :key="tab"
            class="relative py-3 mr-7 text-sm cursor-pointer transition-colors"
            :class="activeTab === tab ? 'font-semibold' : 'text-gray-500'"
            :style="activeTab === tab ? { color: '#22C1C3' } : {}"
            @click="switchTab(tab)"
          >
            {{ tab }}
            <div v-if="activeTab === tab" class="absolute bottom-0 left-1/2 -translate-x-1/2 w-5 h-0.5 rounded-full" style="background:#22C1C3" />
          </div>
        </div>
      </div>

      <!-- Title -->
      <div v-if="sectionTitle" class="px-4 py-3">
        <div class="text-sm font-semibold text-gray-800">{{ sectionTitle }}</div>
      </div>

      <!-- 板块 -->
      <div v-if="activeTab === '板块'" class="bg-white mx-3 rounded-2xl px-3 pt-3 pb-1">
        <div class="grid grid-cols-2 gap-x-3 gap-y-1">
          <div
            v-for="board in boards"
            :key="board.id"
            class="flex items-center gap-2.5 py-2.5 cursor-pointer active:opacity-70"
            @click="goSection(board.id)"
          >
            <div class="w-[38px] h-[38px] rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: board.iconBgColor || '#14B8A6' }">
              <svg v-if="boardIcon(board.name)" class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="boardIcon(board.name)"/></svg>
              <span v-else class="text-white text-sm font-bold">{{ board.name ? board.name[0] : '?' }}</span>
            </div>
            <div class="min-w-0 flex-1">
              <div class="text-xs text-gray-800 truncate">{{ board.name }}</div>
              <div class="text-[10px] text-gray-400 mt-0.5">热度{{ formatHeat(board.totalViewCount || 0) }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 话题网格 -->
      <div v-else-if="activeTab === '话题'" class="bg-white mx-3 rounded-2xl px-3 pt-3 pb-1">
        <div v-if="topics.length === 0" class="text-center py-8 text-gray-400 text-sm">暂无话题</div>
        <div class="grid grid-cols-2 gap-x-3 gap-y-1">
          <div
            v-for="topic in topics"
            :key="topic.id"
            class="flex items-center gap-2.5 py-2.5 cursor-pointer active:opacity-70"
            @click="goTopic(topic.id)"
          >
            <div class="w-[38px] h-[38px] rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden" style="position:relative" :style="{ background: (colorPool[topic.id % colorPool.length]) }">
              <span class="text-white text-sm font-bold">{{ topic.name ? topic.name[0] : '#' }}</span>
              <img v-if="topic.icon" :src="$fixImgUrl(topic.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
            </div>
            <div class="min-w-0 flex-1">
              <div class="text-xs text-gray-800 truncate">#{{ topic.name }}</div>
              <div class="text-[10px] text-gray-400 mt-0.5">热度 {{ formatHeat(topic.heat || topic.view_count || 0) }}</div>
            </div>
          </div>
        </div>
        <div class="text-center py-3">
          <button class="text-xs text-[#22C1C3] font-medium" @click="goCreateTopic">+ 创建话题</button>
        </div>
      </div>

      <!-- 热门帖子列表 -->
      <div v-else-if="showHot" class="pb-20">
        <div v-if="hotLoading" class="flex justify-center pt-20">
          <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
        </div>
        <div v-else-if="hotPosts.length === 0" class="flex flex-col items-center justify-center py-32 text-gray-300">
          <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
          </svg>
          <span class="text-[13px]">暂无热门帖子</span>
        </div>
        <div v-else>
          <TransitionGroup name="list" tag="div">
            <div v-for="(post, i) in hotPosts" :key="post.id">
              <FeedPostCard
                :post="post"
                :activeFrameUrl="activeFrameUrl"
                :currentUserId="currentUserId"
                @click="openHotPost"
              />
            </div>
          </TransitionGroup>
          <!-- Load more -->
          <div v-if="hotLoadingMore" class="flex justify-center py-6">
            <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
          </div>
          <div v-else-if="!hotNoMore && hotPosts.length > 0" class="text-center py-5 text-[12px] text-[#CCC]">上拉加载更多</div>
          <div v-else-if="hotNoMore && hotPosts.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
        </div>
      </div>

      <!-- 关注帖子列表 -->
      <div v-else-if="showFollowed" class="pb-20">
        <div v-if="followedLoading" class="flex justify-center pt-20">
          <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
        </div>
        <div v-else-if="followedPosts.length === 0" class="flex flex-col items-center justify-center py-32 text-gray-300">
          <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
          </svg>
          <span class="text-[13px]">暂未关注任何人</span>
        </div>
        <div v-else>
          <TransitionGroup name="list" tag="div">
          <div v-for="(post, i) in followedPosts" :key="post.id">
            <FeedPostCard
              :post="post"
              :activeFrameUrl="activeFrameUrl"
              :currentUserId="currentUserId"
              @click="openHotPost"
            />
          </div>
          </TransitionGroup>
          <div v-if="followedLoadingMore" class="flex justify-center py-6">
            <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
          </div>
          <div v-else-if="!followedNoMore && followedPosts.length > 0" class="text-center py-5 text-[12px] text-[#CCC]">上拉加载更多</div>
          <div v-else-if="followedNoMore && followedPosts.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
        </div>
      </div>

      <!-- 发现更多 -->
      <template v-if="activeTab === '板块'">
      <div class="px-4 pt-4 pb-1">
        <div class="text-sm font-semibold text-gray-800">发现更多</div>
      </div>

      <div class="bg-white mx-3 rounded-2xl overflow-hidden mb-4">
        <div
          v-for="(item, idx) in discoverItems"
          :key="item.label"
          class="flex items-center px-4 py-3.5 cursor-pointer active:bg-gray-50"
          :class="{ 'border-b border-gray-50': idx < discoverItems.length - 1 }"
          @click="onDiscoverClick(item)"
        >
          <div class="w-[34px] h-[34px] rounded-lg flex items-center justify-center flex-shrink-0 mr-3" :style="{ background: item.bg }">
            <svg v-if="item.icon" class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="item.icon"/></svg>
          </div>
          <span class="flex-1 text-sm text-gray-700">{{ item.label }}</span>
          <svg class="w-4 h-4 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        </div>
      </div>
      </template>

    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchCommunitySections, fetchTopics, fetchCommunityPosts } from '@/api/community'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import request from '@/utils/http'
import FeedPostCard from '@/components/FeedPostCard.vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const activeTab = ref((route.query.tab as string) || '板块')
const tabs = ['板块', '话题', '热门', '关注']
const boards = ref<any[]>([])
const topics = ref<any[]>([])
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)

// Hot posts state
const hotPosts = ref<any[]>([])
const hotLoading = ref(false)
const hotLoadingMore = ref(false)
const hotNoMore = ref(false)
const hotPage = ref(1)

// Followed posts state
const followedPosts = ref<any[]>([])
const followedLoading = ref(false)
const followedLoadingMore = ref(false)
const followedNoMore = ref(false)
const followedPage = ref(1)

const showTopics = computed(() => activeTab.value === '话题')
const showHot = computed(() => activeTab.value === '热门')
const showFollowed = computed(() => activeTab.value === '关注')

const sectionTitle = computed(() => {
  if (showTopics.value) return '热门话题'
  if (showHot.value) return ''
  if (showFollowed.value) return '关注动态'
  return '全部板块'
})

const colorPool = ['#14B8A6', '#EC4899', '#22C55E', '#10B981', '#F97316', '#3B82F6', '#8B5CF6', '#84CC16', '#EA580C', '#F43F5E', '#06B6D4', '#0891B2']

onMounted(async () => {
  loadActiveFrame()
  checkModeratorStatus()
  try {
    const data: any = await fetchCommunitySections()
    const list = Array.isArray(data) ? data : (data?.list || [])
    boards.value = list.map((s: any, i: number) => ({
      ...s,
      bg: s.iconBgColor || colorPool[i % colorPool.length]
    }))
  } catch {}
  if (activeTab.value === '话题') {
    try {
      const res: any = await fetchTopics()
      topics.value = res?.list || res?.data?.list || res?.data || []
    } catch {}
  }
  if (activeTab.value === '热门') {
    await loadHotPosts(true)
  }
  if (activeTab.value === '关注') {
    await loadFollowedPosts(true)
  }
  window.addEventListener('scroll', onHotScroll, { passive: true })
})

onUnmounted(() => { window.removeEventListener('scroll', onHotScroll) })

function switchTab(tab: string) {
  activeTab.value = tab
  router.replace({ query: { ...route.query, tab } })
}

let _watchAbort: (() => void) | null = null

watch(activeTab, async (tab) => {
  if (_watchAbort) { _watchAbort(); _watchAbort = null }
  let cancelled = false
  _watchAbort = () => { cancelled = true }
  if (tab === '话题' && topics.value.length === 0) {
    try {
      const res: any = await fetchTopics()
      if (cancelled) return
      topics.value = res?.list || res?.data?.list || res?.data || []
    } catch {}
  }
  if (tab === '热门') {
    await loadHotPosts(true)
    if (cancelled) return
  }
  if (tab === '关注') {
    await loadFollowedPosts(true)
    if (cancelled) return
  }
})

function boardIcon(name: string) {
  const icons: Record<string, string> = {
    '综合讨论': 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
    '实用软件': 'M4 6h16M4 12h16M4 18h16',
    '绿色软件': 'M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z',
    '技术交流': 'M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
    '资源分享': 'M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v12',
    '游戏天地': 'M6 11h4m-2-2v4m5-5v6m3-3v6m-7-6h8a2 2 0 012 2v6a2 2 0 01-2 2H7a2 2 0 01-2-2v-6a2 2 0 012-2z'
  }
  return icons[name] || ''
}

function formatHeat(n: number) {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

function goSection(id: number) {
  router.push(`/community/section/${id}`)
}

function goTopic(id: number) {
  router.push(`/community/topic/${id}`)
}

function goCreateTopic() {
  router.push('/community/topic/create')
}

// --- Hot posts ---
async function loadHotPosts(reset = false) {
  if (reset) { hotPage.value = 1; hotNoMore.value = false; hotLoading.value = true }
  else { hotLoadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sort: 'hot', page: hotPage.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          for (const node of doc.content) {
            if (node.type === 'paywall') {
              if (p.hasPurchased) continue
              previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }
              break
            }
            if (node.type === 'memberUnlock') {
              if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue
              previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }
              break
            }
            if (node.type === 'experienceUnlock') {
              const userExp = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0)
              if (userExp >= (node.attrs?.level || 0)) continue
              previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }
              break
            }
            if (node.type === 'commentUnlock') {
              if (p.hasCommented) continue
              previewCard = { type: 'commentUnlock' }
              break
            }
            if (node.type === 'titleUnlock') {
              if (p.viewerTitleIds && p.viewerTitleIds.includes(node.attrs?.titleId)) continue
              previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }
              break
            }
          }
          if (!previewCard && p.contentPermission === 'login') {
            previewCard = { type: 'login' }
          }
          if (previewCard && currentUserId.value && p.userId === currentUserId.value) {
            previewCard = null
          }
          if (!previewCard) {
            for (const node of doc.content) {
              if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
              if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
              if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
              if (node.type === 'paragraph' && node.content) {
                for (const child of node.content) {
                  if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                    const txt = child.text || ''
                    const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                    if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                  }
                }
              }
              if (previewCard) break
            }
          }
        }
      } catch {}
      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        _previewCard: previewCard
      }
    })
    if (reset) { hotPosts.value = parsed } else { hotPosts.value.push(...parsed) }
    if (list.length < 20) hotNoMore.value = true
  } catch {} finally { hotLoading.value = false; hotLoadingMore.value = false }
}

async function loadFollowedPosts(reset = false) {
  if (reset) { followedPage.value = 1; followedNoMore.value = false; followedLoading.value = true }
  else { followedLoadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ followed: '1', sort: 'latest', page: followedPage.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          for (const node of doc.content) {
            if (node.type === 'paywall') {
              if (p.hasPurchased) continue
              previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }
              break
            }
            if (node.type === 'memberUnlock') {
              if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue
              previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }
              break
            }
            if (node.type === 'experienceUnlock') {
              const userExp = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0)
              if (userExp >= (node.attrs?.level || 0)) continue
              previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }
              break
            }
            if (node.type === 'commentUnlock') {
              if (p.hasCommented) continue
              previewCard = { type: 'commentUnlock' }
              break
            }
            if (node.type === 'titleUnlock') {
              if (p.viewerTitleIds && p.viewerTitleIds.includes(node.attrs?.titleId)) continue
              previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }
              break
            }
          }
          if (!previewCard && p.contentPermission === 'login') {
            previewCard = { type: 'login' }
          }
          if (previewCard && currentUserId.value && p.userId === currentUserId.value) {
            previewCard = null
          }
          if (!previewCard) {
            for (const node of doc.content) {
              if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
              if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
              if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
              if (node.type === 'paragraph' && node.content) {
                for (const child of node.content) {
                  if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                    const txt = child.text || ''
                    const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                    if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                  }
                }
              }
              if (previewCard) break
            }
          }
        }
      } catch {}
      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        _previewCard: previewCard
      }
    })
    if (reset) { followedPosts.value = parsed } else { followedPosts.value.push(...parsed) }
    if (list.length < 20) followedNoMore.value = true
  } catch {} finally { followedLoading.value = false; followedLoadingMore.value = false }
}

function openHotPost(postId: number) {
  router.push(`/community/post/${postId}`)
}

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}

function onHotScroll() {
  if (showHot.value) {
    if (hotLoadingMore.value || hotNoMore.value) return
    const { scrollHeight, clientHeight } = document.documentElement
    const top = window.scrollY || document.documentElement.scrollTop
    if (scrollHeight - top - clientHeight < 80) { hotPage.value++; loadHotPosts(false) }
  }
  if (showFollowed.value) {
    if (followedLoadingMore.value || followedNoMore.value) return
    const { scrollHeight, clientHeight } = document.documentElement
    const top = window.scrollY || document.documentElement.scrollTop
    if (scrollHeight - top - clientHeight < 80) { followedPage.value++; loadFollowedPosts(false) }
  }
}

const discoverItems = computed(() => {
  const items = [
    { label: '邀请好友', bg: '#10B981', route: '/community/invite', icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
    { label: '游戏大厅', bg: 'linear-gradient(135deg, #8B5CF6, #EC4899)', route: '/community/game-hall', icon: 'M6 11h4m-2-2v4m5-5v6m3-3v6m-7-6h8a2 2 0 012 2v6a2 2 0 01-2 2H7a2 2 0 01-2-2v-6a2 2 0 012-2z' },
  ]
  if (isModeratorUser.value) {
    items.unshift({ label: '版主中心', bg: '#EF4444', route: '/community/moderator', icon: 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01' })
  }
  return items
})

const isModeratorUser = ref(false)
async function checkModeratorStatus() {
  if (!userStore.isLogin) return
  try {
    const data: any = await request.get({ url: '/api/community/moderator/my-sections' })
    if (data?.length > 0) isModeratorUser.value = true
  } catch {}
}

function onDiscoverClick(item: any) {
  if (item.route) router.push(item.route)
}
</script>
