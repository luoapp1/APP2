<template>
  <div class="page">
    <!-- 搜索 + 投稿按钮 -->
    <div class="search-row">
      <div class="search-pill" @click="$router.push('/community/search')">
        <svg class="search-lens" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
        <span class="search-hint">番茄免费小说 | 233乐园</span>
      </div>
      <div class="update-btn" @click="$router.push('/appstore/submissions')">
        <span>投稿</span>
      </div>
    </div>

    <!-- 频道 Tab -->
    <div class="channel-tabs" ref="channelTabsRef">
      <div
        v-for="tab in channelTabs" :key="tab"
        class="channel-item"
        :class="{ active: activeChannel === tab }"
        @click="activeChannel = tab"
      >{{ tab }}
        <div v-if="activeChannel === tab" class="channel-indicator" />
      </div>
      <div style="flex:1" />
    </div>

    <main class="main" ref="mainRef" @scroll="onScroll">
      <!-- ========== 推荐 Tab: 应用内容 ========== -->
      <template v-if="activeChannel === '推荐'">
      <!-- 精品推荐轮播 -->
       <div v-if="featuredApps.length" class="featured-wrapper">
        <div class="featured-scroll" ref="featuredRef" @scroll="onFeatureScroll">
          <div
            v-for="(app, idx) in featuredApps"
            :key="app.id"
            class="featured-card"
            @click="openDetail(app.id)"
          >
            <div class="featured-bg" />
            <div class="featured-left">
              <span class="banner-badge">精品推荐</span>
              <h2 class="banner-title">{{ app.name }}</h2>
              <p class="banner-sub">{{ app.description || '热门的精品应用' }}</p>
            </div>
            <div class="featured-right">
              <div class="banner-app-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                <img v-if="app.icon" :src="fixImgUrl(app.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
              <button class="banner-install" @click.stop="openDetail(app.id)">安装</button>
            </div>
          </div>
        </div>
        <div class="banner-dots">
          <span v-for="(_, idx) in featuredApps" :key="idx" class="dot" :class="{ active: currentFeature === idx }" />
        </div>
      </div>
      <!-- 默认 Banner（无精品推荐时） -->
      <div v-else class="banner" @click="$router.push('/appstore/category')">
        <div class="banner-bg" />
        <div class="banner-left">
          <span class="banner-badge">发现好应用</span>
          <h2 class="banner-title">探索热门应用</h2>
          <p class="banner-sub">发现更多精彩应用和游戏</p>
        </div>
        <div class="banner-right">
          <div class="banner-app-icon">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          </div>
          <button class="banner-install" @click.stop="$router.push('/appstore/category')">安装</button>
        </div>
      </div>

      <!-- 今日热点 -->
      <section class="section">
        <h3 class="section-title">今日热点</h3>
        <div class="grid-5">
          <div v-for="app in hotApps" :key="app.id" class="grid-card" @click="openDetail(app.id)">
            <div class="grid-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span class="grid-icon-fb">{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="fixImgUrl(app.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="grid-name">{{ app.name }}</div>
            <button class="install-btn" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
      </section>

      <!-- 流行风向 -->
      <section class="section">
        <h3 class="section-title">流行风向</h3>
        <!-- 上半部分：宫格 -->
        <div class="grid-5">
          <div v-for="app in trendingGrid" :key="'g'+app.id" class="grid-card" @click="openDetail(app.id)">
            <div class="grid-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span class="grid-icon-fb">{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="fixImgUrl(app.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="grid-name">{{ app.name }}</div>
            <button class="install-btn" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
        <!-- 下半部分：列表 -->
        <div class="list-section">
          <div v-for="app in trendingList" :key="'l'+app.id" class="list-card" @click="openDetail(app.id)">
            <div class="list-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span>{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="fixImgUrl(app.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="list-body">
              <div class="list-title">{{ app.name }}</div>
              <div class="list-desc">{{ app.description || '热门应用推荐' }}</div>
              <div class="list-tags">
                <span class="list-tag" v-for="t in (app.tags || []).slice(0,3)" :key="t">{{ t }}</span>
              </div>
            </div>
            <button class="install-btn list-install" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
      </section>

      <div style="height:80px" />
      </template>

      <!-- ========== 商城 Tab: 商品列表 ========== -->
      <template v-if="activeChannel === '商城'">
        <!-- 商城头图 -->
        <div class="mall-hero">
          <div class="mall-hero-bg" />
          <div class="mall-hero-text">
            <div class="mall-hero-title">好物商城</div>
            <div class="mall-hero-sub">精选好货 · 优惠直达</div>
          </div>
          <div class="mall-hero-icons">
            <div class="mall-hero-icon">🔥</div>
            <div class="mall-hero-icon">⚡</div>
          </div>
        </div>

        <!-- 秒杀专区入口 -->
        <div class="flash-banner" @click="$router.push('/appstore/mall-flash-sales')">
          <div class="flash-banner-left">
            <div class="flash-banner-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="#FF1744"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
            </div>
            <div class="flash-banner-info">
              <div class="flash-banner-title">限时秒杀</div>
              <div class="flash-banner-sub">超值好货 限时抢购</div>
            </div>
          </div>
          <div class="flash-banner-right">
            <span class="flash-banner-btn">立即抢购</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FF1744" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>

        <!-- 商城搜索栏 -->
        <div class="mall-search-row">
          <div class="mall-search-box" @click="$router.push('/community/search')">
            <svg class="mall-search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
            <span class="mall-search-placeholder">搜索你想要的商品</span>
          </div>
        </div>

        <!-- 价格筛选栏 -->
        <div class="filter-bar">
          <input v-model="filterMinPrice" type="number" placeholder="最低价" class="filter-input" @change="applyFilters" />
          <span class="filter-sep">-</span>
          <input v-model="filterMaxPrice" type="number" placeholder="最高价" class="filter-input" @change="applyFilters" />
          <select v-model="filterSort" @change="applyFilters" class="filter-select">
            <option value="">综合排序</option>
            <option value="newest">最新</option>
            <option value="price_asc">价格从低到高</option>
            <option value="price_desc">价格从高到低</option>
            <option value="sales">销量优先</option>
          </select>
        </div>

        <!-- 一级分类标签 -->
        <div class="mall-cat-scroll">
          <div
            v-for="c in topCategories" :key="c.id"
            class="mall-cat-pill"
            :class="{ on: activeCatId === c.id }"
            @click="switchCat(c.id)"
          >{{ c.name }}</div>
          <div class="mall-cat-pill" style="background:linear-gradient(135deg, #7C5CFC, #A78BFA);color:#fff;font-weight:600" @click="$router.push('/appstore/digital-assets')">数字素材</div>
        </div>

        <!-- 二级分类筛选项 -->
        <div class="mall-sub-scroll" v-if="activeCatId !== 0 && subCategories.length > 1">
          <div
            v-for="s in subCategories" :key="s.id"
            class="mall-sub-item"
            :class="{ on: activeSubId === s.id }"
            @click="activeSubId = s.id; loadMallProducts()"
          >
            <img v-if="s.icon" :src="fixImgUrl(s.icon)" class="mall-sub-icon" @error="($event.target as HTMLImageElement).style.display='none'" />
            <span>{{ s.name }}</span>
          </div>
        </div>

        <!-- 排序栏 -->
        <div class="mall-sort-row">
          <div
            v-for="s in mallSorts" :key="s.key"
            class="mall-sort-item"
            :class="{ on: mallSortKey === s.key }"
            @click="setMallSort(s.key)"
          >{{ s.label }}</div>
          <div style="flex:1" />
          <span class="mall-count">{{ mallProducts.length }}件商品</span>
        </div>

        <!-- 商品列表 -->
        <div v-if="mallLoading" class="flex justify-center py-20">
          <div class="w-6 h-6 border-2 border-[#FF6B6B] border-t-transparent rounded-full animate-spin"/>
        </div>
        <template v-else>
          <div v-if="mallProducts.length === 0" class="mall-empty">
            <svg class="w-14 h-14 text-[#E0E0E0]" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
            </svg>
            <span>暂无商品</span>
          </div>
          <div class="mall-grid">
            <div v-for="p in mallProducts" :key="p.id" class="mall-card" @click="openMallDetail(p.id)">
              <div class="mall-card-img-wrap">
                <div class="mall-card-img mall-card-img-fb">
                  <span class="mall-card-fb-text">{{ p.name }}</span>
                </div>
                <img v-if="p.coverImage" :src="fixImgUrl(p.coverImage)" class="mall-card-img" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
                <div v-if="p.salesCount > 100" class="mall-card-badge hot">热卖</div>
                <div v-else-if="p.originalPrice > p.price" class="mall-card-badge coupon">券</div>
              </div>
              <div class="mall-card-body">
                <div class="mall-card-name">{{ p.name }}</div>
                <div class="mall-card-tags" v-if="(p.tags || []).length">
                  <span v-for="t in (p.tags || []).slice(0,3)" :key="t" class="mall-card-tag">{{ t }}</span>
                </div>
                <div class="mall-card-price-row">
                  <span class="mall-card-price-currency">{{ priceCurrency(p) }}</span>
                  <span class="mall-card-price-num">{{ priceValue(p) }}</span>
                  <span v-if="p.originalPrice > p.price" class="mall-card-original">{{ priceOriginal(p) }}</span>
                </div>
                <div class="mall-card-footer">
                  <span class="mall-card-sold">已售 {{ p.salesCount || 0 }}</span>
                  <span class="mall-card-buy">去购买</span>
                </div>
              </div>
            </div>
          </div>
          <div style="height:20px" />
        </template>
      </template>

      <!-- ========== 广场 Tab: 帖子列表 ========== -->
      <template v-if="activeChannel === '广场'">
        <div v-if="postLoading" class="flex justify-center py-20">
          <div class="w-6 h-6 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
        </div>
        <template v-else>
          <div v-if="postList.length === 0" class="flex flex-col items-center py-20 gap-2">
            <svg class="w-12 h-12 text-[#DDD]" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
            </svg>
            <span class="text-[13px] text-[#BBB]">还没有帖子</span>
          </div>
          <div v-for="(post, i) in postList" :key="post.id">
            <FeedPostCard
              :post="post"
              :activeFrameUrl="activeFrameUrl"
              :currentUserId="currentUserId"
              @click="openPostDetail"
            />
          </div>

          <div v-if="postLoadingMore" class="flex justify-center py-6">
            <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
          </div>
          <div v-else-if="!postNoMore && postList.length > 0" class="text-center py-5 text-[12px] text-[#CCC]">上拉加载更多</div>
          <div v-else-if="postNoMore && postList.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
        </template>
      </template>
    </main>

    <!-- 回到顶部 -->
    <transition name="fade-up">
      <div v-if="showBackTop" class="back-top" @click="scrollToTop">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7"/></svg>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import { fetchAppList, fetchHotToday, fetchTrendingWeek, fetchPostComment, fetchPostTip, fetchCategoryList } from '@/api/appstore'
import { fetchCommunityPosts } from '@/api/community'
import FeedPostCard from '@/components/FeedPostCard.vue'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const keyword = ref('')
const activeChannel = ref('推荐')
const appList = ref<any[]>([])
const total = ref(0)
const loading = ref(true)
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)
const showSearch = ref(false)
const searchInput = ref<HTMLInputElement>()
const mainRef = ref<HTMLElement>()
const showBackTop = ref(false)
const featuredApps = ref<any[]>([])
const currentFeature = ref(0)
const featuredRef = ref<HTMLElement>()

// ---- 广场帖子状态 ----
const postList = ref<any[]>([])
const postPage = ref(1)
const postLoading = ref(false)
const postLoadingMore = ref(false)
const postNoMore = ref(false)
const postTotal = ref(0)

// ---- 商城商品状态 ----
const mallProducts = ref<any[]>([])
const mallLoading = ref(false)
const topCategories = ref<any[]>([])
const subCategories = ref<any[]>([])
const activeCatId = ref(0)
const activeSubId = ref(0)
const mallSortKey = ref('newest')
const mallSorts = [
  { key: 'newest', label: '最新' },
  { key: 'hot', label: '最热' },
  { key: 'sales', label: '销量' },
  { key: 'price', label: '售价' },
]

const filterMinPrice = ref('')
const filterMaxPrice = ref('')
const filterSort = ref('')

const applyFilters = () => {
  loadMallProducts()
}

const openMallDetail = (id: number) => router.push(`/appstore/mall-detail/${id}`)
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const priceCurrency = (p: any) => p.priceType === 'points' ? '' : '¥'
const priceValue = (p: any) => p.price
const priceOriginal = (p: any) => p.priceType === 'points' ? p.originalPrice + '积分' : '¥' + p.originalPrice

const loadCategories = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/categories' })
    const all = res || []
    topCategories.value = [{ id: 0, name: '全部' }, ...all.filter((c: any) => c.parentId === 0)]
    if (topCategories.value.length) activeCatId.value = topCategories.value[0].id
  } catch {}
}

const loadMallProducts = async () => {
  mallLoading.value = true
  try {
    const params: any = { status: 'published', pageSize: 50 }
    if (activeCatId.value) params.categoryId = activeCatId.value
    if (activeSubId.value) params.categoryId = activeSubId.value
    if (filterMinPrice.value) params.minPrice = filterMinPrice.value
    if (filterMaxPrice.value) params.maxPrice = filterMaxPrice.value
    if (filterSort.value) params.sortBy = filterSort.value
    const res: any = await request.get({ url: '/api/mall/products', params })
    mallProducts.value = res?.list || []
    // 按排序
    if (mallSortKey.value === 'sales') mallProducts.value.sort((a:any,b:any)=>(b.salesCount||0)-(a.salesCount||0))
    else if (mallSortKey.value === 'price') mallProducts.value.sort((a:any,b:any)=>(a.price||0)-(b.price||0))
  } catch {} finally { mallLoading.value = false }
}

const switchCat = (cid: number) => {
  activeCatId.value = cid
  activeSubId.value = 0
  if (cid === 0) {
    subCategories.value = []
  } else {
    const all = allSubCats.filter((s: any) => s.parentId === cid)
    subCategories.value = [{ id: 0, name: '全部' }, ...all]
  }
  loadMallProducts()
}

let allSubCats: any[] = []
loadCategories().then(async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    allSubCats = res || []
    subCategories.value = [{ id: 0, name: '全部' }, ...allSubCats.filter((c: any) => c.parentId === activeCatId.value)]
  } catch {}
  loadMallProducts()
})

const setMallSort = (k: string) => { mallSortKey.value = k; loadMallProducts() }

watch(activeChannel, (ch) => {
  if (ch === '商城' && mallProducts.value.length === 0) loadMallProducts()
  else if (ch === '广场' && postList.value.length === 0) loadPosts(true)
})

const onScroll = () => {
  const el = mainRef.value
  if (!el) return
  showBackTop.value = el.scrollTop > 300
  // 广场模式下滚动加载更多
  if (activeChannel.value === '广场' && !postNoMore.value && !postLoadingMore.value) {
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 80) {
      loadPosts(false)
    }
  }
}

const scrollToTop = () => {
  mainRef.value?.scrollTo({ top: 0, behavior: 'smooth' })
}

const channelTabs = ['推荐', '商城', '广场']


const hotApps = ref<any[]>([])
const trendingGrid = ref<any[]>([])
const trendingList = ref<any[]>([])

const colorPool = ['#4F8AF7','#6C5CE7','#00BFA5','#F97316','#EC4899','#EF4444','#8B5CF6','#10B981','#3B82F6','#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const loadApps = async () => {
  loading.value = true
  try {
    const params: Record<string, any> = { page: 1, pageSize: 100, status: '1' }
    if (keyword.value) params.keyword = keyword.value
    const res: any = await fetchAppList(params)
    appList.value = res.list || []
    total.value = res.total || 0
    loadFeatured()
    const hotRes: any = await fetchHotToday(5)
    hotApps.value = hotRes.list || []
    const trendRes: any = await fetchTrendingWeek(9)
    trendingGrid.value = (trendRes.list || []).slice(0, 5)
    trendingList.value = (trendRes.list || []).slice(5, 9)
  } catch {} finally { loading.value = false }
}

const loadFeatured = () => {
  featuredApps.value = appList.value.filter(a => a.isFeatured).slice(0, 3)
  currentFeature.value = 0
  nextTick(() => {
    if (featuredRef.value) featuredRef.value.scrollLeft = 0
  })
}

const onFeatureScroll = () => {
  if (!featuredRef.value) return
  const container = featuredRef.value
  currentFeature.value = Math.round(container.scrollLeft / container.clientWidth)
}

const doSearch = () => { showSearch.value = false; loadApps() }
const openDetail = (id: number) => router.push(`/appstore/browse/detail/${id}`)

// ---- 广场帖子 ----
function stripContent(text: string) {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
    if (parsed?.type === 'doc') { const parts: string[] = []; function walk(n: any) { if (n.type === 'text') parts.push(n.text || ''); if (n.content) n.content.forEach(walk) }; if (parsed.content) parsed.content.forEach(walk); return parts.join(' ').trim() }
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

function openPostDetail(postId: number) {
  router.push(`/community/post/${postId}`)
}

watch(activeChannel, (val) => {
  if (val === '广场' && postList.value.length === 0) {
    loadPosts(true)
  }
})

async function loadPosts(reset = false) {
  if (reset) { postPage.value = 1; postNoMore.value = false; postLoading.value = true }
  else { postLoadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sort: 'hot', page: postPage.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          for (const node of doc.content) {
            if (node.type === 'paywall') {
              if (p.hasPurchased) continue
              previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }
              break
            }
            if (node.type === 'memberUnlock') {
              if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue
              previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }
              break
            }
            if (node.type === 'experienceUnlock') {
              const userExp = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0)
              if (userExp >= (node.attrs?.level || 0)) continue
              previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }
              break
            }
            if (node.type === 'commentUnlock') {
              if (p.hasCommented) continue
              previewCard = { type: 'commentUnlock' }
              break
            }
            if (node.type === 'titleUnlock') {
              if (p.viewerTitleIds && p.viewerTitleIds.includes(node.attrs?.titleId)) continue
              previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }
              break
            }
          }
          if (!previewCard && p.contentPermission === 'login') {
            previewCard = { type: 'login' }
          }
          if (previewCard && currentUserId.value && p.userId === currentUserId.value) {
            previewCard = null
          }
          if (!previewCard) {
            for (const node of doc.content) {
              if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
              if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
              if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
              if (node.type === 'paragraph' && node.content) {
                for (const child of node.content) {
                  if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                    const txt = child.text || ''
                    const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                    if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                  }
                }
              }
              if (previewCard) break
            }
          }
        }
      } catch {}
      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        _previewCard: previewCard
      }
    })
    if (reset) { postList.value = parsed; postTotal.value = res?.data?.total || res?.total || 0 }
    else { postList.value.push(...parsed) }
    if (list.length < 20) postNoMore.value = true
    postPage.value++
  } catch {} finally { postLoading.value = false; postLoadingMore.value = false }
}

onMounted(() => {
  loadApps()
  loadActiveFrame()
})

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}
</script>

<style scoped>
.page {
  min-height: 100vh;
  background: var(--app-page-bg);
  display: flex;
  flex-direction: column;
  padding-bottom: 68px;
}

/* 搜索行 */
.search-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px 14px;
}

.search-pill {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fff;
  border-radius: 24px;
  padding: 11px 16px;
  box-shadow: 0 1px 2px rgba(0,0,0,.04);
  cursor: pointer;
}

.search-lens { width: 18px; height: 18px; color: #9ca3af; flex-shrink: 0; }

.search-hint {
  font-size: 14px;
  color: #9ca3af;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.update-btn {
  position: relative;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 9px 14px;
  border-radius: 22px;
  background: #eaf0fb;
  color: #3D7BEA;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;
}

.update-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 16px;
  height: 16px;
  border-radius: 8px;
  background: #F13A3A;
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 4px;
  line-height: 1;
}

/* 频道 Tab */
.channel-tabs {
  display: flex;
  align-items: center;
  padding: 4px 16px 6px;
  gap: 22px;
  position: sticky;
  top: 0;
  background: var(--app-page-bg);
  z-index: 10;
}

.channel-item {
  position: relative;
  font-size: 16px;
  color: #6b7280;
  cursor: pointer;
  padding-bottom: 8px;
  font-weight: 500;
  transition: color .15s;
}
.channel-item.active { color: #111; font-weight: 700; }

.channel-indicator {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 22px;
  height: 3px;
  border-radius: 2px;
  background: #3D7BEA;
}

/* 主内容 */
.main {
  flex: 1;
  overflow-y: auto;
  padding: 0 16px;
}

/* Banner */
.banner {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  padding: 22px 18px;
  display: flex;
  cursor: pointer;
  margin: 4px 0 14px;
}

.banner-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #1a3a5c 0%, #2d5a87 40%, #c49b7a 100%);
  z-index: 0;
}

.banner-left {
  position: relative;
  z-index: 1;
  flex: 1;
  min-width: 0;
}

.banner-badge {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 5px;
  background: rgba(255,255,255,.25);
  color: #fff;
  font-size: 11px;
  font-weight: 600;
  margin-bottom: 10px;
}

.banner-title {
  font-size: 20px;
  font-weight: 800;
  color: #fff;
  margin: 0 0 6px;
  line-height: 1.3;
}

.banner-sub {
  font-size: 13px;
  color: rgba(255,255,255,.75);
  margin: 0;
}

.banner-right {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: 14px;
}

.banner-app-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  background: rgba(255,255,255,.2);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  overflow: hidden;
}
.banner-app-icon img { width: 100%; height: 100%; object-fit: cover; }
.banner-app-icon svg { width: 26px; height: 26px; }

.banner-install {
  padding: 6px 18px;
  border-radius: 16px;
  background: #fff;
  color: #111;
  font-size: 13px;
  font-weight: 700;
  border: none;
  cursor: pointer;
}

.banner-dots {
  position: absolute;
  bottom: 14px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 6px;
  z-index: 1;
}
.dot {
  width: 6px;
  height: 6px;
  border-radius: 3px;
  background: rgba(255,255,255,.4);
  transition: width .3s ease, background .3s ease;
}
.dot.active { background: #fff; width: 18px; }

/* 精品推荐轮播 */
.featured-wrapper {
  position: relative;
  margin: 4px 0 14px;
  border-radius: 20px;
  overflow: hidden;
}
.featured-scroll {
  display: flex;
  overflow-x: auto;
  scroll-snap-type: x mandatory;
  -webkit-overflow-scrolling: touch;
  border-radius: 20px;
  scroll-behavior: smooth;
}
.featured-scroll::-webkit-scrollbar { display: none; }
.featured-card {
  flex: 0 0 100%;
  scroll-snap-align: start;
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  padding: 22px 18px;
  display: flex;
  cursor: pointer;
  min-width: 100%;
}
.featured-card:not(:last-child)::after {
  content: '';
  position: absolute;
  right: 1px;
  top: 16px;
  bottom: 16px;
  width: 1px;
  background: rgba(0,0,0,.08);
  border-radius: 0.5px;
  z-index: 2;
}
.featured-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #1a3a5c 0%, #2d5a87 40%, #c49b7a 100%);
  z-index: 0;
}
.featured-left {
  position: relative;
  z-index: 1;
  flex: 1;
  min-width: 0;
}
.featured-right {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: 14px;
}
.featured-wrapper .banner-dots {
  position: absolute;
  bottom: 12px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 6px;
  z-index: 2;
}


/* Section */
.section { margin-bottom: 22px; }

.section-title {
  font-size: 19px;
  font-weight: 800;
  color: #111;
  margin: 0 0 12px;
  padding: 0 2px;
}

/* 宫格 */
.grid-5 {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}

.grid-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition: transform .12s;
}
.grid-card:active { transform: scale(.95); }

.grid-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: 0 2px 6px rgba(0,0,0,.06);
  margin-bottom: 6px;
}
.grid-icon img { width: 100%; height: 100%; object-fit: cover; }
.grid-icon span { color: #fff; font-size: 20px; font-weight: 700; }

.grid-name {
  font-size: 12px;
  color: #222;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width: 100%;
  line-height: 1.3;
  margin-bottom: 6px;
}

.install-btn {
  padding: 4px 14px;
  border-radius: 12px;
  background: #eaf0fb;
  color: #3D7BEA;
  font-size: 11px;
  font-weight: 600;
  border: none;
  cursor: pointer;
}

/* 列表 */
.list-section {
  margin-top: 14px;
}

.list-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 0;
  cursor: pointer;
  transition: opacity .12s;
  border-bottom: 1px solid rgba(0,0,0,.03);
}
.list-card:last-child { border-bottom: none; }
.list-card:active { opacity: .7; }

.list-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 2px 6px rgba(0,0,0,.06);
}
.list-icon img { width: 100%; height: 100%; object-fit: cover; }
.list-icon span { color: #fff; font-size: 22px; font-weight: 700; }

.list-body {
  flex: 1;
  min-width: 0;
}
.list-title {
  font-size: 15px;
  font-weight: 700;
  color: #111;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list-desc {
  font-size: 12px;
  color: #9ca3af;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list-tags {
  display: flex;
  gap: 4px;
  margin-top: 4px;
}
.list-tag {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
  background: #f3f4f6;
  color: #6b7280;
}

.list-install {
  flex-shrink: 0;
}

/* 搜索弹窗 */
.search-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.25);
  z-index: 200;
}
.search-panel { background: #fff; padding: 8px 16px 14px; }
.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #f3f4f6;
  border-radius: 24px;
  padding: 10px 16px;
}
.search-field {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-size: 15px;
  color: #111;
}
.search-field::placeholder { color: #9ca3af; }
.search-close {
  flex-shrink: 0;
  border: none;
  background: none;
  font-size: 14px;
  color: #3D7BEA;
  cursor: pointer;
}

/* 回到顶部 */
.back-top {
  position: fixed;
  bottom: 80px;
  right: 16px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #3D7BEA;
  cursor: pointer;
  z-index: 100;
  transition: transform .15s, box-shadow .15s;
}
.back-top:active { transform: scale(.92); box-shadow: 0 2px 8px rgba(0,0,0,.1); }

.fade-up-enter-active,
.fade-up-leave-active { transition: opacity .25s ease, transform .25s ease; }
.fade-up-enter-from,
.fade-up-leave-to { opacity: 0; transform: translateY(12px); }

/* ========== 广场帖子卡片 ========== */
.post-card {
  background: #fff;
  margin: 0 12px 12px;
  border-radius: 12px;
  padding: 16px 16px 14px;
  cursor: pointer;
  transition: background .15s;
}
.post-card:active { background: #FAFAFA; }

.post-author {
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
.post-avatar-wrap {
  position: relative;
  width: 45px;
  height: 45px;
  flex-shrink: 0;
  overflow: visible;
}
.post-avatar-frame {
  position: absolute;
  inset: -6px;
  width: calc(100% + 12px);
  height: calc(100% + 12px);
  object-fit: cover;
  pointer-events: none;
  z-index: 0;
}
.post-avatar {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
  z-index: 1;
}
.post-exp-icon {
  width: 32px;
  height: 32px;
  object-fit: contain;
  flex-shrink: 0;
  vertical-align: middle;
}
.post-member-name-icon {
  width: 22px;
  height: 22px;
  object-fit: contain;
  flex-shrink: 0;
  vertical-align: middle;
}
.post-title-icon {
  width: 26px;
  height: 26px;
  object-fit: contain;
  flex-shrink: 0;
  vertical-align: middle;
}
.post-member-name-icon {
  width: 26px;
  height: 26px;
  object-fit: contain;
  flex-shrink: 0;
  vertical-align: middle;
}
.post-author-info { flex: 1; min-width: 0; }
.post-author-col { display: flex; flex-direction: column; gap: 0; }
.post-author-row {
  display: flex;
  align-items: center;
  gap: 0;
  flex-wrap: wrap;
}
.post-username { font-size: 15px; color: #1a1a1a; font-weight: 600; line-height: 1; }
.post-author-meta {
  display: flex;
  align-items: center;
  gap: 2px;
  margin-top: -6px;
  font-size: 12px;
  flex-wrap: wrap;
}
.post-level-badge { font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 700; line-height: 1.4; }
.post-level-name { color: #508DFF; font-weight: 500; }
.post-meta-dot { color: #DDD; }
.post-device { color: #B0B0B0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.post-meta-time {
  color: #B0B0B0;
  font-size: 11px;
}
.post-meta-views {
  color: #B0B0B0;
  font-size: 11px;
}

.post-title {
  margin-top: 10px;
  font-size: 16px;
  color: #111;
  font-weight: 700;
  line-height: 1.45;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.post-pin-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 3px;
  font-weight: 600;
  color: #DC2626;
  background: #FEF2F2;
  margin-right: 5px;
  vertical-align: middle;
}
.post-pin-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-pin-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-pin-badge.custom { color: #508DFF; background: #F0F5FF; }
.post-pin-badge.lock { color: #999; background: #F5F5F5; }

.post-tags {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 6px;
  flex-wrap: wrap;
}
.post-tag {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 4px;
  color: #666;
  background: #F5F5F5;
  font-weight: 500;
  flex-shrink: 0;
}

.post-body {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}
.post-body-text {
  flex: 1;
  min-width: 0;
}
.post-body-thumb {
  width: 100px;
  height: 75px;
  flex-shrink: 0;
  border-radius: 8px;
  overflow: hidden;
  position: relative;
  background: #F5F5F5;
}
.post-thumb-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.post-thumb-count {
  position: absolute;
  right: 4px;
  bottom: 4px;
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 4px;
  background: rgba(0,0,0,.5);
  color: #fff;
  line-height: 1.5;
}

.post-content {
  font-size: 13px;
  color: #999;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.post-resource {
  margin-top: 6px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 10px;
  background: #FFF7ED;
  border: 1px solid #FED7AA;
  border-radius: 8px;
  font-size: 11px;
}
.post-resource-title { color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
.post-resource-price { color: #EA580C; font-weight: 600; flex-shrink: 0; margin-left: 8px; }

.post-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid #F5F5F5;
}
.post-footer-cat {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  color: #999;
  background: #F8F8F8;
  padding: 3px 8px;
  border-radius: 4px;
}
.post-footer-stats {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-left: auto;
  flex-shrink: 0;
}
.post-stat-item {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-size: 12px;
  color: #B0B0B0;
}

.post-divider { display: none; }

/* ========== 商城 ========== */
/* 商城头图 */
.mall-hero {
  position: relative; margin: 8px 12px 0; height: 100px;
  border-radius: 16px; overflow: hidden; display: flex;
  align-items: center; justify-content: space-between; padding: 0 20px;
}
.mall-hero-bg {
  position: absolute; inset: 0;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 50%, #FFB347 100%);
}
.mall-hero-text { position: relative; z-index: 1; }
.mall-hero-title { font-size: 22px; font-weight: 800; color: #fff; line-height: 1.2; }
.mall-hero-sub { font-size: 12px; color: rgba(255,255,255,.85); margin-top: 2px; }
.mall-hero-icons { position: relative; z-index: 1; display: flex; gap: 12px; }
.mall-hero-icon { font-size: 28px; filter: drop-shadow(0 2px 4px rgba(0,0,0,.15)); }

.flash-banner {
  margin: 0 12px 8px; display: flex; align-items: center; justify-content: space-between;
  background: linear-gradient(135deg, #FFF5F5, #FFEBEE); border: 1px solid #FFCDD2;
  border-radius: 12px; padding: 12px 14px; cursor: pointer;
}
.flash-banner-left { display: flex; align-items: center; gap: 10px }
.flash-banner-icon { width: 40px; height: 40px; background: rgba(255,23,68,.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0 }
.flash-banner-info { display: flex; flex-direction: column; gap: 2px }
.flash-banner-title { font-size: 15px; font-weight: 700; color: #FF1744 }
.flash-banner-sub { font-size: 11px; color: #FF5252 }
.flash-banner-right { display: flex; align-items: center; gap: 4px }
.flash-banner-btn { font-size: 12px; font-weight: 600; color: #FF1744 }

.mall-search-row { padding: 10px 12px 0; }
.mall-search-box {
  display: flex; align-items: center; gap: 8px;
  height: 40px; padding: 0 16px; background: #F5F5F5;
  border-radius: 20px; cursor: pointer;
}
.mall-search-icon { width: 18px; height: 18px; color: #999; flex-shrink: 0; }
.mall-search-placeholder { font-size: 14px; color: #BBB; }

.mall-cat-scroll {
  display: flex; gap: 8px; padding: 12px 12px 6px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.mall-cat-scroll::-webkit-scrollbar { display: none; }
.mall-cat-pill {
  flex-shrink: 0; padding: 6px 16px; font-size: 13px;
  color: #666; background: #F5F5F5; border-radius: 20px; cursor: pointer;
  transition: all .15s; white-space: nowrap;
}
.mall-cat-pill.on { color: #fff; background: linear-gradient(135deg, #FF6B6B, #FF8E53); font-weight: 600; }

.mall-sub-scroll {
  display: flex; gap: 8px; padding: 0 12px 10px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.mall-sub-scroll::-webkit-scrollbar { display: none; }
.mall-sub-item {
  flex-shrink: 0; display: flex; align-items: center; gap: 4px;
  padding: 5px 12px; font-size: 12px; color: #888;
  background: #F5F5F5; border-radius: 14px; cursor: pointer;
  transition: all .15s; white-space: nowrap;
}
.mall-sub-item.on { color: #FF6B6B; background: #FFF0F0; font-weight: 500; }
.mall-sub-icon { width: 18px; height: 18px; border-radius: 4px; object-fit: cover; }

.mall-sort-row {
  display: flex; align-items: center; gap: 6px; padding: 6px 12px 10px;
  border-bottom: 1px solid #f2f2f2;
}
.mall-sort-item {
  padding: 4px 12px; font-size: 12px; color: #999;
  border-radius: 12px; cursor: pointer; transition: all .15s;
}
.mall-sort-item.on { color: #FF6B6B; background: #FFF0F0; font-weight: 600; }
.mall-count { font-size: 11px; color: #BBB; flex-shrink: 0; }

.mall-empty { display: flex; flex-direction: column; align-items: center; padding: 60px 0; gap: 10px; }
.mall-empty span { font-size: 14px; color: #BBB; }

/* 商品网格 */
.mall-grid {
  display: grid; grid-template-columns: repeat(2, 1fr);
  gap: 8px; padding: 8px 10px;
}
.mall-card {
  background: #fff; border-radius: 10px; overflow: hidden;
  box-shadow: 0 0 0 1px rgba(0,0,0,.04), 0 2px 6px rgba(0,0,0,.05);
  cursor: pointer; transition: transform .15s, box-shadow .15s;
}
.mall-card:active { transform: scale(.97); box-shadow: 0 4px 14px rgba(0,0,0,.1); }
.mall-card-img-wrap { position: relative; width: 100%; padding-top: 80%; overflow: hidden; background: #f8f8f8; }
.mall-card-img {
  position: absolute; inset: 0; width: 100%; height: 100%;
  object-fit: cover; transition: transform .25s;
}
.mall-card:active .mall-card-img { transform: scale(1.03); }
.mall-card-img-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(180deg, #FF8A80 0%, #FF5252 50%, #D32F2F 100%);
}
.mall-card-fb-text {
  color: rgba(255,255,255,.55); font-size: 22px; font-weight: 900;
  max-width: 80%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.mall-card-badge {
  position: absolute; top: 0; left: 0;
  font-size: 10px; padding: 3px 8px; border-radius: 0 0 8px 0;
  background: linear-gradient(135deg, #FF4757, #FF6B6B);
  color: #fff; font-weight: 600; letter-spacing: .5px;
}
.mall-card-badge.hot { background: linear-gradient(135deg, #FF4757, #FF6B6B); }
.mall-card-badge.coupon { background: linear-gradient(135deg, #FF9500, #FF6B3D); }
.mall-card-body { padding: 6px 9px 8px; display: flex; flex-direction: column; gap: 3px; }
.mall-card-name {
  font-size: 13px; font-weight: 600; color: #222; line-height: 1.4;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
  overflow: hidden;
}
.mall-card-tags { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 1px; }
.mall-card-tag {
  font-size: 9px; padding: 2px 6px; border-radius: 3px;
  background: #FFF0E6; color: #FF7D37; white-space: nowrap; font-weight: 500;
}
.mall-card-tag:nth-child(2) { background: #F0EBFF; color: #7C5CFC; }
.mall-card-tag:nth-child(3) { background: #E8FAF0; color: #00B578; }
.mall-card-price-row { display: flex; align-items: baseline; gap: 3px; flex-wrap: wrap; }
.mall-card-price-currency { font-size: 12px; font-weight: 700; color: #FF4757; }
.mall-card-price-num { font-size: 18px; font-weight: 800; color: #FF4757; line-height: 1; }
.mall-card-original { font-size: 10px; color: #CCC; text-decoration: line-through; margin-left: 2px; }
.mall-card-footer { display: flex; align-items: center; justify-content: space-between; }
.mall-card-sold { font-size: 10px; color: #BBB; }
.mall-card-buy {
  font-size: 10px; color: #fff; background: linear-gradient(135deg, #FF6B6B, #FF8E53);
  padding: 3px 10px; border-radius: 10px; font-weight: 600;
}

/* 价格筛选栏 */
.filter-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
}
.filter-input {
  width: 80px;
  height: 32px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 0 8px;
  font-size: 12px;
  color: #333;
  outline: none;
  background: #fff;
}
.filter-input::placeholder {
  color: #bbb;
}
.filter-sep {
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
.filter-select {
  flex: 1;
  height: 32px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 0 8px;
  font-size: 12px;
  color: #333;
  outline: none;
  background: #fff;
  appearance: auto;
}
</style>
