<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">货币体系配置</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-20">
        <div class="animate-spin w-6 h-6 border-2 border-[#FF4757] border-t-transparent rounded-full" />
      </div>

      <template v-else>
        <!-- 货币列表 -->
        <div v-for="item in currencies" :key="item.id" class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div class="px-4 py-3 flex items-center justify-between border-b border-gray-50" @click="toggleExpand(item.id)">
            <div class="flex items-center gap-3">
              <div v-if="item.display_icon && item.display_icon.startsWith('/')" class="w-9 h-9 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                <img :src="item.display_icon" class="w-full h-full object-cover" />
              </div>
              <div v-else class="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0" :style="{ background: item.card_color || colorFor(item.sort_order) }">
                {{ item.display_icon || item.display_name.charAt(0) }}
              </div>
              <div>
                <div class="text-sm font-semibold text-gray-800">{{ item.display_name }}</div>
                <div class="text-xs text-gray-400">{{ item.currency_key }}</div>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span v-if="isSystemCurrency(item.currency_key)" class="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-600">系统</span>
              <span class="text-xs px-2 py-0.5 rounded-full" :class="item.is_visible ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.is_visible ? '显示' : '隐藏' }}</span>
              <svg class="w-4 h-4 text-gray-400 transition-transform" :class="{ 'rotate-90': expandedId === item.id }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
          </div>

          <!-- 编辑区域 -->
          <div v-if="expandedId === item.id" class="px-4 py-4 space-y-3">
            <div v-if="!isSystemCurrency(item.currency_key)">
              <div class="text-xs text-gray-500 mb-1">Key (创建后不可改)</div>
              <input disabled :value="item.currency_key" class="w-full h-9 px-3 text-sm bg-gray-100 text-gray-400 rounded-lg border-none outline-none" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">显示名称</div>
              <input v-model="editForm.display_name" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">图标</div>
              <div class="flex items-center gap-3">
                <div v-if="iconPreview" class="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                  <img :src="iconPreview" class="w-full h-full object-cover" @error="iconPreview = ''" />
                </div>
                <div v-else class="w-10 h-10 rounded-lg flex items-center justify-center text-lg bg-[#f5f6f8] flex-shrink-0">
                  {{ editForm.display_icon || '�' }}
                </div>
                <div class="flex-1 flex gap-2 items-center">
                  <input v-model="editForm.display_icon" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="图标URL或emoji" />
                  <label class="flex-shrink-0 h-9 px-3 bg-gray-100 rounded-lg text-xs text-gray-500 flex items-center cursor-pointer active:bg-gray-200">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    上传
                    <input type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
                  </label>
                </div>
              </div>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">符号</div>
              <input v-model="editForm.display_symbol" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="如 ¥" />
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500">交易货币</span>
              <button class="w-11 h-6 rounded-full relative transition-colors" :class="editForm.currency_type === 'currency' ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="toggleCurrencyType">
                <span class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform" :class="editForm.currency_type === 'currency' ? 'translate-x-5' : 'translate-x-0.5'" />
              </button>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <div class="text-xs text-gray-500 mb-1">卡片颜色</div>
                <div class="flex items-center gap-2">
                  <input type="color" v-model="editForm.card_color" class="w-9 h-9 p-0 border-0 rounded cursor-pointer bg-transparent" />
                  <input v-model="editForm.card_color" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none font-mono" placeholder="#8b5cf6" />
                </div>
              </div>
              <div>
                <div class="text-xs text-gray-500 mb-1">账号前缀(4位)</div>
                <input v-model="editForm.account_prefix" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none font-mono" placeholder="8801" maxlength="4" />
              </div>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">小数位数</div>
              <input v-model.number="editForm.decimal_places" type="number" min="0" max="4" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">排序</div>
              <input v-model.number="editForm.sort_order" type="number" min="0" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500">可见</span>
              <button class="w-11 h-6 rounded-full relative transition-colors" :class="editForm.is_visible ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="editForm.is_visible = editForm.is_visible ? 0 : 1">
                <span class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform" :class="editForm.is_visible ? 'translate-x-5' : 'translate-x-0.5'" />
              </button>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500">允许兑换</span>
              <button class="w-11 h-6 rounded-full relative transition-colors" :class="editForm.is_exchangeable ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="editForm.is_exchangeable = editForm.is_exchangeable ? 0 : 1">
                <span class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform" :class="editForm.is_exchangeable ? 'translate-x-5' : 'translate-x-0.5'" />
              </button>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">描述</div>
              <textarea v-model="editForm.description" rows="2" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
            </div>
            <div class="flex gap-3 pt-2">
              <button class="flex-1 py-2.5 rounded-lg bg-gray-100 text-gray-600 text-sm" @click="expandedId = null">取消</button>
              <button class="flex-1 py-2.5 rounded-lg bg-[#FF4757] text-white text-sm font-medium active:opacity-80" :disabled="saving" @click="saveCurrency(item.currency_key)">{{ saving ? '保存中...' : '保存' }}</button>
              <button v-if="!isSystemCurrency(item.currency_key)" class="py-2.5 px-4 rounded-lg bg-red-100 text-red-500 text-sm font-medium active:opacity-80" :disabled="deleting === item.id" @click.stop="confirmDelete(item)">{{ deleting === item.id ? '删除中...' : '删除' }}</button>
            </div>
          </div>
        </div>

        <!-- 新增货币按钮 -->
        <div class="bg-white mx-3 mt-4 rounded-xl overflow-hidden">
          <div v-if="!showCreate" class="px-4 py-4 flex items-center justify-center gap-2 text-[#FF4757] text-sm font-medium cursor-pointer active:opacity-70" @click="openCreate">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            新增货币类型
          </div>
          <div v-else class="px-4 py-4 space-y-3">
            <div class="text-sm font-bold text-gray-800">新建货币</div>
            <div>
              <div class="text-xs text-gray-500 mb-1">Key <span class="text-red-400">*</span></div>
              <input v-model="createForm.currency_key" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="仅字母/数字/下划线" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">显示名称 <span class="text-red-400">*</span></div>
              <input v-model="createForm.display_name" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="如 钻石" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">图标</div>
              <div class="flex items-center gap-3">
                <div v-if="createIconPreview" class="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                  <img :src="createIconPreview" class="w-full h-full object-cover" @error="createIconPreview = ''" />
                </div>
                <div v-else class="w-10 h-10 rounded-lg flex items-center justify-center text-lg bg-[#f5f6f8] flex-shrink-0">
                  {{ createForm.display_icon || '�' }}
                </div>
                <div class="flex-1 flex gap-2 items-center">
                  <input v-model="createForm.display_icon" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="图标URL或emoji" />
                  <label class="flex-shrink-0 h-9 px-3 bg-gray-100 rounded-lg text-xs text-gray-500 flex items-center cursor-pointer active:bg-gray-200">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    上传
                    <input type="file" accept="image/*" class="hidden" @change="handleCreateIconUpload" />
                  </label>
                </div>
              </div>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">符号</div>
              <input v-model="createForm.display_symbol" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="如 ♦" />
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500">交易货币</span>
              <button class="w-11 h-6 rounded-full relative transition-colors" :class="createForm.currency_type === 'currency' ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="createForm.currency_type = createForm.currency_type === 'quota' ? 'currency' : 'quota'">
                <span class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform" :class="createForm.currency_type === 'currency' ? 'translate-x-5' : 'translate-x-0.5'" />
              </button>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">小数位数</div>
              <input v-model.number="createForm.decimal_places" type="number" min="0" max="4" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">排序</div>
              <input v-model.number="createForm.sort_order" type="number" min="0" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500">隐藏</span>
              <button class="w-11 h-6 rounded-full relative transition-colors" :class="!createForm.is_hidden ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="createForm.is_hidden = createForm.is_hidden ? 0 : 1">
                <span class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform" :class="!createForm.is_hidden ? 'translate-x-5' : 'translate-x-0.5'" />
              </button>
            </div>
            <div>
              <div class="text-xs text-gray-500 mb-1">描述</div>
              <input v-model="createForm.description" class="w-full h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex gap-3">
              <button class="flex-1 py-2.5 rounded-lg bg-gray-100 text-gray-600 text-sm" @click="showCreate = false">取消</button>
              <button class="flex-1 py-2.5 rounded-lg bg-[#FF4757] text-white text-sm font-medium active:opacity-80" :disabled="creating" @click="doCreate">{{ creating ? '创建中...' : '创建' }}</button>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'CurrencyManageMobile' })

const SYSTEM_CURRENCIES = ['balance', 'points', 'experience', 'makeup_count', 'rename_count']

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => {
  toastMsg.value = m; toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const loading = ref(false)
const currencies = ref<any[]>([])
const expandedId = ref<number | null>(null)
const saving = ref(false)
const deleting = ref<number | null>(null)

const editForm = reactive({
  display_name: '',
  display_icon: '',
  display_symbol: '',
  decimal_places: 0,
  sort_order: 0,
  is_visible: 1,
  is_exchangeable: 0,
  currency_type: 'currency',
  description: '',
  card_color: '',
  account_prefix: ''
})

const showCreate = ref(false)
const creating = ref(false)
const createForm = reactive({
  currency_key: '',
  display_name: '',
  display_icon: '',
  display_symbol: '',
  decimal_places: 0,
  sort_order: 99,
  is_hidden: 0,
  currency_type: 'currency',
  description: ''
})

const COLORS = ['#FF4757', '#FFA502', '#2ED573', '#1E90FF', '#5352ED', '#EC4899', '#F97316', '#14B8A6']

const iconPreview = ref('')
const iconUploading = ref(false)

const createIconPreview = ref('')

const handleIconUpload = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  iconUploading.value = true
  try {
    const fd = new FormData()
    fd.append('file', file)
    const res: any = await request.post({ url: '/api/upload/file', data: fd, headers: {} })
    const url = res?.url || res?.data?.url || res?.data || ''
    if (url) {
      editForm.display_icon = url
      iconPreview.value = url
      if (iconPreview.value.startsWith('/')) {
        iconPreview.value = import.meta.env.VITE_API_PREFIX
          ? (import.meta.env.VITE_API_PREFIX as string) + iconPreview.value
          : iconPreview.value
      }
    }
  } catch (e: any) { showToast('上传失败: ' + (e.message || ''), 'error') }
  iconUploading.value = false
  input.value = ''
}

const handleCreateIconUpload = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  try {
    const fd = new FormData()
    fd.append('file', file)
    const res: any = await request.post({ url: '/api/upload/file', data: fd, headers: {} })
    const url = res?.url || res?.data?.url || res?.data || ''
    if (url) {
      createForm.display_icon = url
      createIconPreview.value = url
      if (createIconPreview.value.startsWith('/')) {
        createIconPreview.value = import.meta.env.VITE_API_PREFIX
          ? (import.meta.env.VITE_API_PREFIX as string) + createIconPreview.value
          : createIconPreview.value
      }
    }
  } catch (e: any) { showToast('上传失败: ' + (e.message || ''), 'error') }
  input.value = ''
}

const toggleCurrencyType = () => {
  editForm.currency_type = editForm.currency_type === 'quota' ? 'currency' : 'quota'
}

const isSystemCurrency = (key: string) => SYSTEM_CURRENCIES.includes(key)
const colorFor = (order: number) => COLORS[(order - 1) % COLORS.length]

const fetchCurrencies = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/admin/currency-settings' })
    currencies.value = res || []
  } catch { showToast('加载失败', 'error') }
  loading.value = false
}

const toggleExpand = (id: number) => {
  if (expandedId.value === id) { expandedId.value = null; return }
  const item = currencies.value.find(c => c.id === id)
  if (item) {
    expandedId.value = id
    editForm.display_name = item.display_name
    editForm.display_icon = item.display_icon
    editForm.display_symbol = item.display_symbol
    editForm.decimal_places = item.decimal_places
    editForm.sort_order = item.sort_order
    editForm.is_visible = item.is_visible
    editForm.is_exchangeable = item.is_exchangeable
    editForm.description = item.description || ''
    editForm.card_color = item.card_color || ''
    editForm.account_prefix = item.account_prefix || ''
    editForm.currency_type = item.currency_type || 'currency'
  }
}

const saveCurrency = async (key: string) => {
  saving.value = true
  try {
    await request.put({
      url: `/api/admin/currency-settings/${key}`,
      data: { ...editForm }
    })
    showToast('保存成功')
    expandedId.value = null
    fetchCurrencies()
  } catch { showToast('保存失败', 'error') }
  saving.value = false
}

const confirmDelete = (item: any) => {
  if (!confirm(`确定删除货币 "${item.display_name}" (${item.currency_key})？`)) return
  deleteCurrency(item)
}

const deleteCurrency = async (item: any) => {
  deleting.value = item.id
  try {
    await request.delete({ url: `/api/admin/currency-settings/${item.currency_key}` })
    showToast('删除成功')
    expandedId.value = null
    fetchCurrencies()
  } catch { showToast('删除失败', 'error') }
  deleting.value = null
}

const openCreate = () => {
  showCreate.value = true
  createForm.currency_key = ''
  createForm.display_name = ''
  createForm.display_icon = ''
  createForm.display_symbol = ''
  createForm.decimal_places = 0
  createForm.sort_order = 99
  createForm.is_hidden = 0
  createForm.description = ''
}

const doCreate = async () => {
  if (!createForm.currency_key || !createForm.display_name) { showToast('请填写 Key 和显示名称', 'error'); return }
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(createForm.currency_key)) { showToast('Key 仅允许字母/数字/下划线，不能以数字开头', 'error'); return }
  creating.value = true
  try {
    await request.post({
      url: '/api/admin/currency-settings',
      data: {
        currency_key: createForm.currency_key,
        display_name: createForm.display_name,
        display_icon: createForm.display_icon,
        display_symbol: createForm.display_symbol,
        decimal_places: createForm.decimal_places,
        sort_order: createForm.sort_order,
        is_visible: createForm.is_hidden ? 0 : 1,
        currency_type: createForm.currency_type,
        description: createForm.description,
        card_color: '',
        account_prefix: ''
      }
    })
    showToast('创建成功')
    showCreate.value = false
    fetchCurrencies()
  } catch { showToast('创建失败', 'error') }
  creating.value = false
}

onMounted(fetchCurrencies)
</script>
