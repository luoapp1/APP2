<template>
  <div class="page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="title">物流追踪</span>
    </div>
    <main class="main">
      <div v-if="loading" class="loading">加载中...</div>
      <template v-else-if="logistics">
        <div class="info-card">
          <div class="info-row">
            <span class="info-label">快递公司</span>
            <span class="info-value">{{ logistics.carrier || '-' }}</span>
          </div>
          <div class="info-row">
            <span class="info-label">快递单号</span>
            <span class="info-value mono">{{ logistics.trackingNumber || '-' }}</span>
          </div>
          <div class="info-row">
            <span class="info-label">物流状态</span>
            <span class="info-value status">{{ logistics.status || '-' }}</span>
          </div>
        </div>
        <div class="timeline" v-if="logistics.traces && logistics.traces.length > 0">
          <div v-for="(trace, idx) in logistics.traces" :key="idx" class="tl-item" :class="{ active: idx === 0 }">
            <div class="tl-dot-wrap">
              <div class="tl-dot" :class="{ on: idx === 0 }" />
              <div v-if="idx < logistics.traces.length - 1" class="tl-line" />
            </div>
            <div class="tl-body">
              <div class="tl-status" :class="{ current: idx === 0 }">{{ trace.status }}</div>
              <div class="tl-desc" v-if="trace.description">{{ trace.description }}</div>
              <div class="tl-time">{{ trace.time }}</div>
            </div>
          </div>
        </div>
        <div v-else class="empty">暂无物流轨迹信息</div>
      </template>
      <div v-else class="empty">未找到物流信息</div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '@/utils/http'

const route = useRoute()
const logistics = ref(null)
const loading = ref(true)

onMounted(async () => {
  const orderId = route.query.orderId
  if (!orderId) {
    loading.value = false
    return
  }
  try {
    const res = await request.get({ url: `/api/mall/orders/${orderId}/tracking` })
    logistics.value = res
  } catch (e) { console.error(e) }
  loading.value = false
})
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6fa }
.header { background: #fff; display: flex; align-items: center; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; position: sticky; top: 0; z-index: 10 }
.back-btn { background: none; border: none; padding: 4px; color: #333; cursor: pointer }
.title { font-size: 17px; font-weight: 600; color: #1a1a2e; margin-left: 8px }
.main { padding: 16px }
.loading { text-align: center; padding: 60px 0; color: #999 }
.empty { text-align: center; padding: 80px 0; color: #999; font-size: 14px }
.info-card { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 16px }
.info-row { display: flex; align-items: center; padding: 8px 0; font-size: 14px }
.info-row + .info-row { border-top: 1px solid #f5f5f5 }
.info-label { color: #999; width: 72px; flex-shrink: 0 }
.info-value { color: #333; flex: 1 }
.info-value.mono { font-family: monospace; font-size: 13px }
.info-value.status { color: #508DFF; font-weight: 500 }
.timeline { padding-left: 8px }
.tl-item { display: flex; gap: 14px }
.tl-dot-wrap { display: flex; flex-direction: column; align-items: center; flex-shrink: 0; width: 16px }
.tl-dot { width: 10px; height: 10px; border-radius: 50%; background: #ddd; flex-shrink: 0 }
.tl-dot.on { background: #508DFF; box-shadow: 0 0 0 3px rgba(80,141,255,.2) }
.tl-line { width: 2px; flex: 1; min-height: 24px; background: #eee; margin: 4px 0 }
.tl-body { flex: 1; padding-bottom: 20px }
.tl-status { font-size: 14px; color: #999; font-weight: 500 }
.tl-status.current { color: #333 }
.tl-desc { font-size: 13px; color: #666; margin-top: 4px }
.tl-time { font-size: 12px; color: #bbb; margin-top: 4px }
</style>
