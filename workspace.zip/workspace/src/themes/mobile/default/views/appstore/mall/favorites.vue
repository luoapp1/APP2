<template>
  <div style="min-height:100vh;background:#f5f6fa;display:flex;flex-direction:column">
    <div style="background:#fff;display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f0f0f0">
      <button style="background:none;border:none;padding:4px;color:#333;cursor:pointer" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span style="font-size:17px;font-weight:600;color:#1a1a2e;margin-left:8px">商城收藏</span>
    </div>
    <div style="flex:1;overflow-y:auto;padding:12px">
      <div v-if="loading" style="text-align:center;padding:60px 0;color:#999">加载中...</div>
      <div v-else-if="list.length===0" style="text-align:center;padding:80px 0;color:#999">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
        <div style="font-size:14px">暂无收藏商品</div>
      </div>
      <div v-for="item in list" :key="item.id" class="list-item" @click="goDetail(item)">
        <img v-if="item.coverImage" :src="item.coverImage" class="cover"  loading="lazy" />
        <div v-else class="cover placeholder" />
        <div class="info">
          <div class="name">{{ item.name }}</div>
          <div class="price">{{ item.price }} {{ item.priceType === 'points' ? '积分' : item.priceType === 'balance' ? '余额' : '元' }}</div>
          <div class="sold">已售 {{ item.salesCount || 0 }}</div>
        </div>
        <button class="unfav-btn" @click.stop="handleUnfav(item)">取消</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const list = ref([])
const loading = ref(true)

onMounted(() => fetchList())

async function fetchList() {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/mall/favorites' })
    list.value = res?.list || []
  } catch { ElMessage.error('加载收藏列表失败') }
  loading.value = false
}

async function handleUnfav(item) {
  try {
    await ElMessageBox.confirm('确定要取消收藏该商品吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await request.post({ url: `/api/mall/favorites/${item.productId}`, data: {} })
    list.value = list.value.filter(f => f.productId !== item.productId)
    ElMessage.success('已取消收藏')
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error(e?.msg || '操作失败')
    }
  }
}

function goDetail(item) {
  router.push(`/appstore/mall-detail/${item.productId}`)
}
</script>

<style scoped>
.list-item { display:flex;align-items:center;gap:12px;background:#fff;border-radius:12px;padding:12px;margin-bottom:10px }
.cover { width:72px;height:72px;border-radius:8px;object-fit:cover;flex-shrink:0 }
.placeholder { background:linear-gradient(135deg,#f0f0f0,#e0e0e0) }
.info { flex:1;min-width:0 }
.name { font-size:14px;font-weight:600;color:#1a1a2e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap }
.price { font-size:14px;font-weight:700;color:#f56c6c;margin-top:4px }
.sold { font-size:11px;color:#999;margin-top:2px }
.unfav-btn { background:#fef0f0;color:#f56c6c;border:none;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer }
</style>
