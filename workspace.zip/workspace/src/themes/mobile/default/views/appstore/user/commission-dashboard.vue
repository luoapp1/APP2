<template>
  <div class="commission-dashboard-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">&lt; 返回</button>
      <h2>推广返佣</h2>
    </div>
    <div class="content">
      <div class="stats-row">
        <div class="stat-card">
          <div class="stat-label">累计收益</div>
          <div class="stat-value primary">{{ formatMoney(data.totalEarnings) }}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">今日收益</div>
          <div class="stat-value accent">{{ formatMoney(data.todayEarnings) }}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">推广人数</div>
          <div class="stat-value">{{ data.referralCount ?? '--' }}</div>
        </div>
      </div>

      <div class="level-breakdown">
        <div class="level-item">
          <div class="level-label">一级佣金</div>
          <div class="level-amount">{{ formatMoney(data.level1Earnings) }}</div>
        </div>
        <div class="level-divider"></div>
        <div class="level-item">
          <div class="level-label">二级佣金</div>
          <div class="level-amount">{{ formatMoney(data.level2Earnings) }}</div>
        </div>
      </div>

      <div class="section">
        <div class="section-header">
          <span class="section-title">近期佣金订单</span>
          <span class="section-action" @click="$router.push('/appstore/commission-orders')">查看全部</span>
        </div>
        <div class="order-list" v-if="data.recentOrders && data.recentOrders.length > 0">
          <div class="order-item" v-for="item in data.recentOrders" :key="item.id">
            <div class="order-info">
              <div class="order-id">订单 #{{ item.id }}</div>
              <div class="order-meta">
                <span class="order-tag" :class="'level-' + item.level">{{ item.level === 1 ? '一级' : '二级' }}</span>
                <span class="order-time">{{ formatTime(item.createTime) }}</span>
              </div>
            </div>
            <div class="order-right">
              <div class="order-amount">{{ formatMoney(item.amount) }}</div>
              <div class="order-commission">+{{ formatMoney(item.commission) }}</div>
            </div>
          </div>
        </div>
        <div class="empty" v-else>暂无佣金订单</div>
      </div>

      <button class="promotion-btn" @click="$router.push('/appstore/promotion-materials')">推广素材</button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const data = reactive({
  totalEarnings: 0,
  todayEarnings: 0,
  referralCount: 0,
  level1Earnings: 0,
  level2Earnings: 0,
  recentOrders: []
})
const loading = ref(true)

onMounted(async () => {
  try {
    const res = await request.get({ url: '/api/commission/stats/dashboard' })
    const d = res || {}
    data.totalEarnings = d.totalEarnings || 0
    data.todayEarnings = d.todayEarnings || 0
    data.referralCount = d.referralCount || 0
    data.level1Earnings = d.level1Earnings || 0
    data.level2Earnings = d.level2Earnings || 0
    data.recentOrders = d.recentOrders || []
  } catch {
    data.recentOrders = []
  }
  loading.value = false
})

function formatMoney(val) {
  if (val == null) return '--'
  const n = Number(val)
  return n >= 10000 ? `${(n / 10000).toFixed(2)}万` : n.toFixed(2)
}

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
</script>

<style scoped>
.commission-dashboard-page { min-height: 100vh; background: #f5f5f5; }
.header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; border-bottom: 1px solid #eee; }
.header h2 { margin: 0; font-size: 18px; }
.back-btn { background: none; border: none; color: #2196F3; font-size: 14px; cursor: pointer; }
.content { padding: 16px; }

.stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 16px; }
.stat-card { background: #fff; border-radius: 10px; padding: 14px 10px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.stat-label { font-size: 12px; color: #999; margin-bottom: 6px; }
.stat-value { font-size: 20px; font-weight: 700; color: #333; }
.stat-value.primary { color: #FF6B35; }
.stat-value.accent { color: #4CAF50; }

.level-breakdown { background: #fff; border-radius: 10px; padding: 16px; display: flex; align-items: center; justify-content: space-around; box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 16px; }
.level-item { text-align: center; }
.level-label { font-size: 12px; color: #999; margin-bottom: 6px; }
.level-amount { font-size: 20px; font-weight: 700; color: #FF6B35; }
.level-divider { width: 1px; height: 32px; background: #eee; }

.section { background: #fff; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 16px; }
.section-header { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid #f0f0f0; }
.section-title { font-size: 14px; font-weight: 600; color: #333; }
.section-action { font-size: 12px; color: #2196F3; cursor: pointer; }

.order-list { padding: 0; }
.order-item { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid #f8f8f8; }
.order-item:last-child { border-bottom: none; }
.order-info { flex: 1; min-width: 0; }
.order-id { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 4px; }
.order-meta { display: flex; align-items: center; gap: 8px; }
.order-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; font-weight: 500; }
.order-tag.level-1 { background: #fff3e0; color: #FF6B35; }
.order-tag.level-2 { background: #e8f5e9; color: #4CAF50; }
.order-time { font-size: 11px; color: #bbb; }
.order-right { text-align: right; flex-shrink: 0; }
.order-amount { font-size: 13px; color: #666; margin-bottom: 2px; }
.order-commission { font-size: 14px; font-weight: 600; color: #FF6B35; }

.promotion-btn { width: 100%; padding: 14px 0; border: none; border-radius: 10px; background: linear-gradient(135deg, #FF6B35, #FF8F5E); color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.empty { text-align: center; padding: 32px 0; color: #999; font-size: 13px; }
</style>
