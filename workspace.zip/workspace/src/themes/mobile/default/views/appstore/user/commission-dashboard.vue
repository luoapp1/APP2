<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f3f4f6">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">佣金明细</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">

      <!-- 累计收益大卡片 -->
      <div style="background:linear-gradient(135deg,#FF6B35,#FF8F5E);border-radius:14px;padding:20px;margin-bottom:12px;color:#fff;text-align:center">
        <div style="font-size:13px;opacity:0.85;margin-bottom:6px">累计收益</div>
        <div style="font-size:36px;font-weight:800;letter-spacing:1px">¥{{ formatMoney(data.totalEarnings) }}</div>
        <div style="display:flex;justify-content:center;gap:24px;margin-top:14px">
          <div>
            <div style="font-size:20px;font-weight:700">¥{{ formatMoney(data.totalEarnings) }}</div>
            <div style="font-size:11px;opacity:0.75">累计余额</div>
          </div>
          <div style="width:1px;background:rgba(255,255,255,0.3)" />
          <div>
            <div style="font-size:20px;font-weight:700">{{ Math.floor(data.totalPointsEarnings) }}</div>
            <div style="font-size:11px;opacity:0.75">累计积分</div>
          </div>
          <div style="width:1px;background:rgba(255,255,255,0.3)" />
          <div>
            <div style="font-size:20px;font-weight:700">{{ data.referralCount ?? '--' }}</div>
            <div style="font-size:11px;opacity:0.75">推广人数</div>
          </div>
        </div>
      </div>

      <!-- 两级佣金 -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div style="background:#fff;border-radius:12px;padding:16px;text-align:center">
          <div style="font-size:12px;color:#9ca3af;margin-bottom:6px">一级佣金</div>
          <div style="font-size:22px;font-weight:700;color:#FF6B35">¥{{ formatMoney(data.level1Earnings) }}</div>
        </div>
        <div style="background:#fff;border-radius:12px;padding:16px;text-align:center">
          <div style="font-size:12px;color:#9ca3af;margin-bottom:6px">二级佣金</div>
          <div style="font-size:22px;font-weight:700;color:#4CAF50">¥{{ formatMoney(data.level2Earnings) }}</div>
        </div>
      </div>

      <!-- 近期订单 -->
      <div style="background:#fff;border-radius:12px;padding:16px;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <div style="font-size:15px;font-weight:600;color:#1f2937">近期佣金订单</div>
          <span style="font-size:12px;color:#2196F3;cursor:pointer" @click="$router.push('/appstore/commission-orders')">查看全部</span>
        </div>
        <div v-if="data.recentOrders && data.recentOrders.length > 0">
          <div v-for="item in data.recentOrders" :key="item.id"
            style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #f3f4f6">
            <div>
              <div style="font-size:14px;font-weight:500;color:#1f2937">订单 #{{ item.id }}</div>
              <div style="display:flex;align-items:center;gap:6px;margin-top:3px">
                <span :style="{fontSize:'10px',padding:'2px 6px',borderRadius:'4px',fontWeight:500,color:item.level===1?'#FF6B35':'#4CAF50',background:item.level===1?'#fff3e0':'#e8f5e9'}">
                  {{ item.level === 1 ? '一级' : '二级' }}
                </span>
                <span style="font-size:11px;color:#bbb">{{ formatTime(item.createTime) }}</span>
              </div>
            </div>
            <div style="text-align:right">
              <div style="font-size:13px;color:#9ca3af">消费 ¥{{ formatMoney(item.amount) }}</div>
              <div v-if="(item.commission||0) > 0" style="font-size:14px;font-weight:700;color:#FF6B35">+¥{{ formatMoney(item.commission) }}</div>
              <div v-if="(item.pointsCommission||0) > 0" style="font-size:14px;font-weight:700;color:#4CAF50">+{{ item.pointsCommission }}积分</div>
            </div>
          </div>
        </div>
        <div v-else style="text-align:center;padding:30px 0;color:#9ca3af;font-size:13px">暂无佣金订单</div>
      </div>

      <!-- 分享入口 -->
      <div style="background:#fff;border-radius:12px;padding:16px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;margin-bottom:12px"
        @click="$router.push('/appstore/promotion-materials')">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:8px;background:#fef3c7;display:flex;align-items:center;justify-content:center">
            <svg style="width:18px;height:18px;color:#d97706" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" />
            </svg>
          </div>
          <div style="font-size:14px;font-weight:500;color:#1f2937">推广素材</div>
        </div>
        <svg style="width:16px;height:16px;color:#9ca3af" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
        </svg>
      </div>

      <!-- 分享弹窗 -->
      <div v-if="showShareModal" style="position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.5);display:flex;align-items:flex-end;justify-content:center" @click.self="showShareModal = false">
        <div style="width:100%;max-width:480px;background:#fff;border-radius:16px 16px 0 0;padding-bottom:32px">
          <div style="display:flex;align-items:center;justify-content:center;padding:14px 16px;border-bottom:1px solid #f0f0f0;position:relative">
            <span style="font-size:16px;font-weight:700;color:#1f2937">分享推广链接</span>
            <svg @click="showShareModal = false" style="position:absolute;right:16px;width:20px;height:20px;color:#9ca3af;cursor:pointer" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
          <div style="padding:20px 16px;display:flex;flex-direction:column;gap:14px">
            <div style="background:#f5f5f5;border-radius:8px;padding:14px;word-break:break-all">
              <div style="font-size:13px;color:#1f2937;line-height:1.5">{{ referralLink }}</div>
            </div>
            <button style="width:100%;padding:12px 0;border:none;border-radius:24px;background:#2196F3;color:#fff;font-size:15px;font-weight:600;cursor:pointer" @click="copyLink">{{ copied ? '已复制' : '复制链接' }}</button>
            <div style="font-size:12px;color:#9ca3af;text-align:center;line-height:1.5">将链接分享给朋友，朋友注册后消费你即可获得佣金</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

defineOptions({ name: 'CommissionDashboard' })

const data = reactive({
  totalEarnings: 0,
  totalPointsEarnings: 0,
  todayEarnings: 0,
  referralCount: 0,
  level1Earnings: 0,
  level2Earnings: 0,
  recentOrders: [] as any[]
})
const loading = ref(true)

const showShareModal = ref(false)
const referralLink = ref('')
const copied = ref(false)

const openShareLink = async () => {
  showShareModal.value = true
  try {
    const res: any = await request.post({ url: '/api/user-codes/default' })
    if (res?.code) {
      referralLink.value = `${location.origin}/#/register?ref=${res.code}`
    }
  } catch {
    ElMessage.error('获取推广链接失败')
  }
}

const copyLink = () => {
  navigator.clipboard.writeText(referralLink.value).then(() => {
    copied.value = true
    setTimeout(() => { copied.value = false }, 2000)
  }).catch(() => {
    ElMessage.error('复制失败，请手动复制')
  })
}

onMounted(async () => {
  try {
    const res = await request.get({ url: '/api/commission/stats/dashboard' })
    const d = res || {}
    data.totalEarnings = d.totalEarnings || 0
    data.totalPointsEarnings = d.totalPointsEarnings || 0
    data.todayEarnings = d.todayEarnings || 0
    data.referralCount = d.referralCount || 0
    data.level1Earnings = d.level1Earnings || 0
    data.level2Earnings = d.level2Earnings || 0
    data.recentOrders = (d.recentOrders || []).map((r: any) => ({
      id: r.orderId || r.id,
      amount: r.orderAmount || r.amount || 0,
      commission: r.commission || 0,
      pointsCommission: r.pointsCommission || 0,
      level: r.level || 1,
      createTime: r.createTime
    }))
  } catch {
    data.recentOrders = []
  }
  loading.value = false
})

function formatMoney(val: any) {
  if (val == null) return '0.00'
  const n = Number(val)
  return n >= 10000 ? `${(n / 10000).toFixed(2)}万` : n.toFixed(2)
}

function formatTime(t: any) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
</script>
