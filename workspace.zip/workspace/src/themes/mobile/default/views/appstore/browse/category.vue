<template>
  <div class="page">
    <!-- 顶部搜索 + 更新 -->
    <div class="top-bar">
      <div class="search-pill" @click="showSearch = true">
        <svg class="search-lens" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
        <span class="search-hint">番茄免费小说 | 233乐园</span>
      </div>
      <div class="update-btn">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/></svg>
        <span>更新</span>
      </div>
    </div>

    <!-- 顶部 Tab -->
    <div class="main-tabs" ref="tabsRef">
      <div
        v-for="t in topTabs" :key="t"
        class="main-tab"
        :class="{ active: activeTopTab === t }"
        @click="activeTopTab = t"
      >{{ t }}
        <div v-if="activeTopTab === t" class="tab-indicator" />
      </div>
    </div>

    <!-- 主体：左侧边栏 + 右侧内容 -->
    <div class="body">
      <!-- 分类模式：侧边栏 -->
      <template v-if="activeTopTab === '分类'">
        <aside class="sidebar">
          <div
            v-for="cat in categories" :key="cat"
            class="sidebar-item"
            :class="{ active: activeCategory === cat }"
            @click="selectCategory(cat)"
          >{{ cat }}</div>
        </aside>
        <div class="content" ref="contentRef" @scroll="onScroll">
          <div class="filter-bar">
            <div class="filter-dropdown" ref="dropdownRef" @click="toggleDropdown">
              <span>{{ priceFilter }}</span>
              <svg width="10" height="6" viewBox="0 0 10 6" fill="#9ca3af"><path d="M0 0l5 6 5-6z"/></svg>
            </div>
          </div>
          <div v-if="loading" class="loading">加载中...</div>
          <div v-else class="app-list">
            <div
              v-for="app in appList" :key="app.id"
              class="app-card" @click="openDetail(app.id)"
            >
              <div class="app-icon" :style="{ background: app.iconBgColor || iconColor(app.name) }">
                <img v-if="app.icon" :src="$fixImgUrl(app.icon)"  loading="lazy" />
                <span v-else>{{ (app.name || '?')[0] }}</span>
              </div>
              <div class="app-info">
                <div class="app-name">{{ app.name }}</div>
                <div class="app-desc">{{ app.description || '热门应用推荐' }}</div>
                <div class="app-meta">
                  <svg class="meta-star" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                  <span>{{ toNum(app.rating).toFixed(1) }}</span>
                  <span class="meta-sep">&middot;</span>
                  <span>{{ app.sizeMb }}MB</span>
                  <span class="meta-sep">&middot;</span>
                  <span>{{ fmtCount(app.downloads) }}下载</span>
                </div>
              </div>
              <button class="install-btn" @click.stop="openDetail(app.id)">下载</button>
            </div>
            <div v-if="appList.length === 0" class="empty">暂无应用</div>
          </div>
        </div>
      </template>

      <!-- 排行榜模式 -->
      <div v-else class="rank-content" ref="contentRef" @scroll="onScroll">
        <div v-if="loading" class="loading">加载中...</div>
        <div v-else class="rank-list">
          <div
            v-for="(app, idx) in rankApps" :key="app.id"
            class="rank-row" @click="openDetail(app.id)"
          >
            <div class="rank-num" :class="{ gold: idx === 0, silver: idx === 1, bronze: idx === 2 }">
              <template v-if="idx === 0"><svg width="18" height="18" viewBox="0 0 24 24" fill="#F59E0B"><circle cx="12" cy="12" r="10"/><text x="12" y="16" text-anchor="middle" fill="#fff" font-size="12" font-weight="700">{{ idx + 1 }}</text></svg></template>
              <template v-else-if="idx === 1"><svg width="18" height="18" viewBox="0 0 24 24" fill="#94A3B8"><circle cx="12" cy="12" r="10"/><text x="12" y="16" text-anchor="middle" fill="#fff" font-size="12" font-weight="700">{{ idx + 1 }}</text></svg></template>
              <template v-else-if="idx === 2"><svg width="18" height="18" viewBox="0 0 24 24" fill="#D97706"><circle cx="12" cy="12" r="10"/><text x="12" y="16" text-anchor="middle" fill="#fff" font-size="12" font-weight="700">{{ idx + 1 }}</text></svg></template>
              <template v-else><span>{{ idx + 1 }}</span></template>
            </div>
            <div class="app-icon" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <img v-if="app.icon" :src="$fixImgUrl(app.icon)"  loading="lazy" />
              <span v-else>{{ (app.name || '?')[0] }}</span>
            </div>
            <div class="app-info">
              <div class="app-name">
                {{ app.name }}
                <span v-if="app.isPinned" class="rank-badge rank-badge-pin">置顶</span>
                <span v-if="app.isFeatured" class="rank-badge rank-badge-feat">推荐</span>
                <span v-if="app.isOfficial" class="rank-badge rank-badge-official">官方</span>
              </div>
              <div class="app-meta">
                <svg class="meta-star" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                <span>{{ toNum(app.rating).toFixed(1) }}</span>
                <span class="meta-sep">&middot;</span>
                <span>{{ app.sizeMb }}MB</span>
                <span class="meta-sep">&middot;</span>
                <span>{{ fmtCount(app.downloads) }}下载</span>
              </div>
            </div>
            <button class="install-btn" @click.stop="openDetail(app.id)">下载</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 回到顶部 -->
    <transition name="fade-up">
      <div v-if="showBackTop" class="back-top" @click="scrollToTop">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7"/></svg>
      </div>
    </transition>

    <!-- 价格筛选下拉 -->
    <teleport to="body">
      <div v-if="showPriceDropdown" class="dropdown-overlay" @click="showPriceDropdown = false"></div>
      <div v-if="showPriceDropdown" class="dropdown-menu" :style="dropdownStyle">
        <div
          v-for="opt in priceOptions" :key="opt"
          class="dropdown-item"
          :class="{ active: priceFilter === opt }"
          @click="selectPrice(opt)"
        >{{ opt }}</div>
      </div>
    </teleport>
    <teleport to="body">
      <div v-if="showSearch" class="search-overlay" @click.self="showSearch = false">
        <div class="search-panel">
          <div class="search-bar">
            <svg class="search-lens" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
            <input v-model="keyword" class="search-field" placeholder="搜索应用" @keyup.enter="doSearch" />
            <button class="search-cancel" @click="showSearch = false">取消</button>
          </div>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { fetchAppList, fetchCategoryList } from '@/api/appstore'

const keyword = ref('')
const router = useRouter()
const activeTopTab = ref('分类')
const activeCategory = ref('小编推荐')
const appList = ref<any[]>([])
const total = ref(0)
const loading = ref(true)
const categories = ref<string[]>(['小编推荐'])
const showSearch = ref(false)
const showPriceDropdown = ref(false)
const dropdownRef = ref<HTMLElement>()
const dropdownStyle = ref<Record<string, string>>({})
const priceFilter = ref('全部')
const priceOptions = ['全部', '免费', '付费']
const contentRef = ref<HTMLElement>()
const showBackTop = ref(false)
const allApps = ref<any[]>([])

const filteredApps = () => {
  if (priceFilter.value === '免费') return allApps.value.filter((a: any) => a.isFree || a.priceType === 'free' || !a.priceType)
  if (priceFilter.value === '付费') return allApps.value.filter((a: any) => !a.isFree && a.priceType && a.priceType !== 'free')
  return allApps.value
}

const onScroll = () => {
  showBackTop.value = (contentRef.value?.scrollTop || 0) > 300
}

const scrollToTop = () => {
  contentRef.value?.scrollTo({ top: 0, behavior: 'smooth' })
}

const toggleDropdown = () => {
  if (!showPriceDropdown.value && dropdownRef.value) {
    const rect = dropdownRef.value.getBoundingClientRect()
    dropdownStyle.value = {
      position: 'fixed',
      top: rect.bottom + 6 + 'px',
      left: rect.left + 'px',
    }
  }
  showPriceDropdown.value = !showPriceDropdown.value
}

const selectPrice = (opt: string) => {
  priceFilter.value = opt
  showPriceDropdown.value = false
  appList.value = filteredApps()
}

const topTabs = ['分类', '排行榜']

const toNum = (v: any) => Number(v) || 0
const fmtCount = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + '亿'
  if (n >= 1000) return (n / 1000).toFixed(1) + '万'
  return String(n)
}

const colorPool = ['#4F8AF7','#6C5CE7','#00BFA5','#F97316','#EC4899','#EF4444','#8B5CF6','#10B981','#3B82F6','#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const loadApps = async () => {
  loading.value = true
  try {
    const params: Record<string, unknown> = { page: 1, pageSize: 50, status: '1' }
    if (activeCategory.value !== '小编推荐') params.category = activeCategory.value
    if (keyword.value) params.keyword = keyword.value
    const res: any = await fetchAppList(params)
    allApps.value = res.list || []
    appList.value = filteredApps()
    total.value = res.total || 0
  } catch {} finally { loading.value = false }
}

const rankApps = computed(() => {
  return [...allApps.value].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1
    if (!a.isPinned && b.isPinned) return 1
    if (a.isFeatured && !b.isFeatured) return -1
    if (!a.isFeatured && b.isFeatured) return 1
    if (a.isOfficial && !b.isOfficial) return -1
    if (!a.isOfficial && b.isOfficial) return 1
    return (b.downloads || 0) - (a.downloads || 0)
  })
})

watch(activeTopTab, (tab) => {
  if (tab === '排行榜') loadApps()
})

const selectCategory = (cat: string) => { activeCategory.value = cat; loadApps() }
const doSearch = () => { showSearch.value = false; loadApps() }
const openDetail = (id: number) => router.push(`/appstore/browse/detail/${id}`)

onMounted(async () => {
  try {
    const data: any = await fetchCategoryList()
    if (Array.isArray(data) && data.length > 0) {
      categories.value = ['小编推荐', ...data.map((c: any) => c.name)]
    }
  } catch {}
  loadApps()
})
</script>

<style scoped>
.page {
  min-height: 100vh;
  background: var(--app-page-bg);
  display: flex;
  flex-direction: column;
  padding-bottom: 68px;
}

/* 顶部栏 */
.top-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px 14px;
}

.search-pill {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fff;
  border-radius: 24px;
  padding: 11px 16px;
  box-shadow: 0 1px 2px rgba(0,0,0,.04);
  cursor: pointer;
}
.search-lens { width: 18px; height: 18px; color: #9ca3af; flex-shrink: 0; }
.search-hint { font-size: 14px; color: #9ca3af; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.update-btn {
  position: relative;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 9px 14px;
  border-radius: 22px;
  background: #eaf0fb;
  color: #3D7BEA;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;
}

/* 主 Tab */
.main-tabs {
  display: flex;
  align-items: center;
  padding: 4px 16px 6px;
  gap: 24px;
  position: sticky;
  top: 0;
  background: var(--app-page-bg);
  z-index: 10;
}

.main-tab {
  position: relative;
  font-size: 15px;
  color: #6b7280;
  cursor: pointer;
  padding-bottom: 8px;
  font-weight: 500;
}
.main-tab.active { color: #111; font-weight: 700; }

.tab-indicator {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 24px;
  height: 3px;
  border-radius: 2px;
  background: #3D7BEA;
}

/* 主体 */
.body {
  flex: 1;
  display: flex;
  overflow: hidden;
  margin-top: 2px;
}

/* 侧边栏 */
.sidebar {
  width: 82px;
  flex-shrink: 0;
  overflow-y: auto;
  padding: 6px 0 40px;
  background: var(--app-page-bg);
}

.sidebar-item {
  margin: 2px 8px;
  padding: 10px 0;
  text-align: center;
  font-size: 13px;
  color: #9ca3af;
  cursor: pointer;
  font-weight: 500;
  border-radius: 10px;
  transition: all .2s ease;
  white-space: nowrap;
}
.sidebar-item.active {
  background: #fff;
  color: #3D7BEA;
  font-weight: 600;
  box-shadow: 0 1px 3px rgba(0,0,0,.04);
}

/* 内容区 */
.content {
  flex: 1;
  overflow-y: auto;
  padding: 0 12px 40px;
  background: var(--app-page-bg);
}

/* 过滤栏 */
.filter-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 4px 6px;
  position: sticky;
  top: 0;
  background: var(--app-page-bg);
  z-index: 5;
}

.filter-dropdown {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #374151;
  font-weight: 600;
  cursor: pointer;
  position: relative;
}

.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  margin-top: 6px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
  overflow: hidden;
  z-index: 20;
  min-width: 100px;
}
.dropdown-item {
  padding: 10px 16px;
  font-size: 13px;
  font-weight: 500;
  color: #374151;
  cursor: pointer;
  white-space: nowrap;
}
.dropdown-item:hover { background: #f3f4f6; }
.dropdown-item.active { color: #3D7BEA; background: #eef4ff; }

.dropdown-overlay {
  position: fixed;
  inset: 0;
  z-index: 19;
}

/* 加载 */
.loading {
  text-align: center;
  padding: 60px 0;
  color: #9ca3af;
  font-size: 14px;
}

/* 应用列表 */
.app-list { padding-top: 2px; }

.app-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  margin-bottom: 3px;
  border-radius: 16px;
  background: #f8fafc;
  cursor: pointer;
  transition: all .2s ease;
  box-shadow: 0 1px 3px rgba(0,0,0,.04);
}
.app-card:active { transform: scale(.98); box-shadow: 0 2px 8px rgba(0,0,0,.08); }

.app-icon {
  width: 48px;
  height: 48px;
  border-radius: 13px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 4px 10px rgba(0,0,0,.1);
}
.app-icon img { width: 100%; height: 100%; object-fit: cover; }
.app-icon span { color: #fff; font-size: 17px; font-weight: 700; }

.app-info {
  flex: 1;
  min-width: 0;
}
.app-name {
  font-size: 15px;
  font-weight: 600;
  color: #1f2937;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.app-desc {
  font-size: 12px;
  color: #a0aec0;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.app-meta {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 4px;
  font-size: 11px;
  color: #a0aec0;
}
.meta-star { width: 11px; height: 11px; color: #f59e0b; flex-shrink: 0; }
.meta-sep { color: #d1d5db; }

.install-btn {
  flex-shrink: 0;
  padding: 7px 18px;
  border-radius: 18px;
  background: linear-gradient(135deg, #3D7BEA, #5B8DF5);
  color: #fff;
  font-size: 12px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all .2s ease;
  box-shadow: 0 2px 6px rgba(61,123,234,.25);
}
.install-btn:active { transform: scale(.95); opacity: .9; }

.empty {
  text-align: center;
  padding: 60px 0;
  color: #9ca3af;
  font-size: 14px;
}

/* 搜索弹窗 */
.search-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.25);
  z-index: 200;
}
.search-panel { background: #fff; padding: 8px 16px 14px; }
.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #f3f4f6;
  border-radius: 24px;
  padding: 10px 16px;
}
.search-field { flex: 1; border: none; outline: none; background: transparent; font-size: 15px; color: #111; }
.search-field::placeholder { color: #9ca3af; }
.search-cancel { flex-shrink: 0; border: none; background: none; font-size: 14px; color: #3D7BEA; cursor: pointer; }

.back-top {
  position: fixed;
  right: 16px;
  bottom: 88px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 2px 12px rgba(0,0,0,.12);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #3D7BEA;
  cursor: pointer;
  z-index: 50;
  transition: transform .2s, opacity .2s;
}
.back-top:active { transform: scale(.92); }

.fade-up-enter-active, .fade-up-leave-active { transition: opacity .25s, transform .25s; }
.fade-up-enter-from, .fade-up-leave-to { opacity: 0; transform: translateY(12px); }

/* 排行榜 */
.rank-content {
  flex: 1;
  overflow-y: auto;
  padding: 0 12px 40px;
  background: var(--app-page-bg);
}
.rank-list { padding-top: 4px; }
.rank-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background .2s ease;
}
.rank-row:active { background: var(--app-page-bg); }
.rank-row:last-child { border-bottom: none; }

.rank-num {
  width: 28px;
  flex-shrink: 0;
  text-align: center;
  font-size: 15px;
  font-weight: 700;
  color: #9ca3af;
}
.rank-num.gold, .rank-num.silver, .rank-num.bronze {
  display: flex;
  align-items: center;
  justify-content: center;
}

.rank-badge {
  display: inline-block;
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 3px;
  font-weight: 600;
  margin-left: 3px;
  vertical-align: middle;
}
.rank-badge-pin { background: #FEF3C7; color: #D97706; }
.rank-badge-feat { background: #FEF3C7; color: #B45309; }
.rank-badge-official { background: #DBEAFE; color: #2563EB; }
</style>
