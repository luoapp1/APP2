<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">物流配置</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-4 h-4 text-[#FF5722]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect x="1" y="3" width="15" height="13" rx="2" stroke-width="1.8"/>
            <polyline points="16 8 20 8 23 11 23 16 16 16" stroke-width="1.8"/>
          </svg>
          {{ configId ? '编辑物流配置' : '配置物流服务' }}
        </div>

        <div class="space-y-3">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">物流服务商</label>
            <select v-model="form.provider" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="kdniao">快递鸟 (KDNiao) - 推荐</option>
              <option value="kuaidi100">快递100 (百递云)</option>
              <option value="cainiao">菜鸟开放平台</option>
            </select>
          </div>

          <template v-if="form.provider === 'kdniao'">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">商户ID (EBusinessID)</label>
              <input v-model="form.e_business_id" placeholder="快递鸟商户ID" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">API Key</label>
              <input v-model="form.api_key_encrypted" type="password" :placeholder="configId ? '留空则不修改' : '快递鸟API密钥'" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="bg-blue-50 rounded-lg p-3 text-xs text-blue-700 leading-relaxed">
              <div class="font-bold mb-1">快递鸟接入说明</div>
              <div>1. 前往 <span class="underline">https://www.kdniao.com</span> 注册并完成企业认证</div>
              <div>2. 在「我的API」中获取 EBusinessID 和 API Key</div>
              <div>3. 配置回调地址：<code class="bg-blue-100 px-1 rounded">{{ callbackUrl }}</code></div>
              <div>4. 发货后系统将自动订阅物流轨迹，状态变更会通过回调实时推送</div>
            </div>
          </template>

          <template v-if="form.provider === 'kuaidi100'">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">授权Key</label>
              <input v-model="form.e_business_id" type="password" :placeholder="configId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">Customer</label>
              <input v-model="form.api_key_encrypted" type="password" :placeholder="configId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="bg-blue-50 rounded-lg p-3 text-xs text-blue-700 leading-relaxed">
              <div class="font-bold mb-1">快递100接入说明</div>
              <div>1. 前往 <span class="underline">https://api.kuaidi100.com</span> 注册企业账号</div>
              <div>2. 在控制台获取授权Key和Customer参数</div>
              <div>3. 配置回调地址到快递100控制台</div>
            </div>
          </template>

          <template v-if="form.provider === 'cainiao'">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">App Key</label>
              <input v-model="form.e_business_id" type="password" :placeholder="configId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">App Secret</label>
              <input v-model="form.api_key_encrypted" type="password" :placeholder="configId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="bg-yellow-50 rounded-lg p-3 text-xs text-yellow-700 leading-relaxed">
              <div class="font-bold mb-1">菜鸟接入说明</div>
              <div>菜鸟主要面向淘系/天猫商家，非阿里系平台接入有限制</div>
              <div>如果商城不在阿里生态中，建议使用快递鸟</div>
            </div>
          </template>

          <template v-if="form.provider">
            <div class="flex items-center justify-between py-1">
              <span class="text-sm text-gray-600">启用物流追踪</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.enabled?'bg-[#FF5722]':'bg-gray-200'" @click="form.enabled=!form.enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.enabled?'translate-x-4.5':'left-0.5'" /></button>
            </div>
          </template>
        </div>

        <div class="flex gap-2 mt-4">
          <button class="flex-1 h-10 bg-[#FF5722] text-white text-sm rounded-lg font-medium active:opacity-80" :disabled="saving" @click="doSave">{{ saving?'保存中...':'保存配置' }}</button>
          <button v-if="configId" class="flex-1 h-10 bg-red-500 text-white text-sm rounded-lg font-medium active:opacity-80" :disabled="saving" @click="doDelete">删除配置</button>
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4" v-if="configId">
        <div class="text-sm font-bold text-gray-800 mb-4">当前配置</div>
        <div class="flex items-center justify-between py-2">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-lg flex items-center justify-center text-white text-xs font-bold bg-[#FF5722]">{{ currentProvider[0] || '未' }}</div>
            <div>
              <div class="text-sm font-medium text-gray-800">{{ currentProvider }}</div>
              <div class="text-[10px] text-gray-400">商户ID: {{ currentBusinessId }}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full" :class="config.enabled?'bg-green-400':'bg-gray-300'" />
            <span class="text-xs" :class="config.enabled?'text-green-600':'text-gray-400'">{{ config.enabled ? '已启用' : '未启用' }}</span>
          </div>
        </div>
        <div class="mt-3 p-3 bg-gray-50 rounded-lg">
          <div class="text-xs text-gray-500 mb-1">Webhook 回调地址</div>
          <code class="text-xs text-gray-700 break-all">{{ callbackUrl }}</code>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'LogisticsConfig' })

const config = ref<any>({})
const configId = ref<string | number>('')
const saving = ref(false)
const toastMsg = ref('')
const toastType = ref('info')
let toastTimer: number | null = null

const form = reactive({
  provider: 'kdniao',
  e_business_id: '',
  api_key_encrypted: '',
  enabled: true
})

const providerLabels: Record<string, string> = {
  kdniao: '快递鸟 (KDNiao)',
  kuaidi100: '快递100',
  cainiao: '菜鸟开放平台'
}

const currentProvider = computed(() => providerLabels[config.value.provider] || config.value.provider || '未配置')
const currentBusinessId = computed(() => {
  const id = config.value.e_business_id || ''
  if (id.length > 8) return id.substring(0, 4) + '****' + id.slice(-4)
  return id || '未设置'
})

const callbackUrl = computed(() => {
  const origin = typeof window !== 'undefined' ? window.location.origin : ''
  return `${origin}/api/webhook/logistics/track`
})

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg; toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = window.setTimeout(() => { toastMsg.value = '' }, 2500)
}

async function loadConfig() {
  try {
    const res: any = await request.get({ url: '/api/admin/logistics-config' })
    const data = res?.data || res
    if (data && data.id) {
      config.value = data
      configId.value = data.id
      form.provider = data.provider || 'kdniao'
      form.e_business_id = data.e_business_id || ''
      form.api_key_encrypted = data.api_key_encrypted || ''
      form.enabled = data.enabled !== false
    }
  } catch {}
}

async function doSave() {
  if (!form.provider) return showToast('请选择物流服务商', 'error')
  saving.value = true
  try {
    await request.put({ url: '/api/admin/logistics-config', data: { ...form } })
    showToast('保存成功')
    await loadConfig()
  } catch { showToast('保存失败', 'error') }
  finally { saving.value = false }
}

async function doDelete() {
  if (!confirm('确定删除物流配置？删除后物流追踪功能将不可用。')) return
  saving.value = true
  try {
    await request.del({ url: '/api/admin/logistics-config' })
    showToast('已删除')
    config.value = {}
    configId.value = ''
    form.e_business_id = ''
    form.api_key_encrypted = ''
  } catch { showToast('删除失败', 'error') }
  finally { saving.value = false }
}

onMounted(() => loadConfig())
</script>
