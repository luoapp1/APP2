<template>
  <div class="analytics-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">开发者分析</span>
      <div style="width:22px" />
    </div>

    <div class="page-content">
      <div v-if="loading" class="load-wrap"><div class="spin" /></div>
      <div v-else-if="error" class="err-wrap">
        <p class="err-text">{{ error }}</p>
        <button class="btn btn-primary" @click="loadData">重试</button>
      </div>
      <template v-else>
        <div class="section-title">数据概览</div>
        <div class="stats-row">
          <div class="stat-card">
            <div class="stat-val">{{ fmtNum(data.totalApps) }}</div>
            <div class="stat-lbl">应用总数</div>
          </div>
          <div class="stat-card stat-accent">
            <div class="stat-val">{{ fmtNum(data.totalDownloads) }}</div>
            <div class="stat-lbl">总下载量</div>
          </div>
          <div class="stat-card stat-revenue">
            <div class="stat-val">{{ fmtRevenue(data.totalRevenue) }}</div>
            <div class="stat-lbl">总收益</div>
          </div>
        </div>

        <div class="section-title">近期趋势</div>
        <div class="chart-wrap">
          <div v-if="!recentStats.length" class="chart-empty">暂无趋势数据</div>
          <div v-else class="bar-chart">
            <div v-for="item in recentStats" :key="item.date" class="bar-row">
              <span class="bar-date">{{ item.date?.slice(5) }}</span>
              <div class="bar-tracks">
                <div class="bar-track-wrap">
                  <div class="bar-track-bar bar-dl" :style="{ width: barWidth(item, 'downloads') + '%' }" />
                </div>
                <div class="bar-track-wrap">
                  <div class="bar-track-bar bar-rv" :style="{ width: barWidth(item, 'revenue') + '%' }" />
                </div>
              </div>
              <span class="bar-val">{{ item.downloads || 0 }}</span>
            </div>
          </div>
          <div class="chart-legend">
            <span class="legend-item"><span class="legend-dot ld-dl" />下载</span>
            <span class="legend-item"><span class="legend-dot ld-rv" />收益</span>
          </div>
        </div>

        <div class="section-title">热门应用</div>
        <div v-if="!topApps.length" class="empty-sm">暂无应用数据</div>
        <div v-else class="top-list">
          <div v-for="(app, idx) in topApps" :key="app.id" class="top-item">
            <span class="top-rank" :class="{ 'top-1': idx === 0, 'top-2': idx === 1, 'top-3': idx === 2 }">{{ idx + 1 }}</span>
            <img v-if="app.iconUrl" :src="app.iconUrl" class="top-icon" />
            <div v-else class="top-icon top-icon-placeholder">{{ (app.name || '?')[0] }}</div>
            <span class="top-name">{{ app.name }}</span>
            <span class="top-count">{{ fmtNum(app.downloadCount) }} 下载</span>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import request from '@/utils/http'

const loading = ref(false)
const error = ref('')
const data = reactive({ totalApps: 0, totalDownloads: 0, totalRevenue: 0 })
const recentStats = ref([])
const topApps = ref([])

function fmtNum(n) {
  if (n == null) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

function fmtRevenue(n) {
  if (n == null) return '0'
  const v = Number(n)
  return v >= 10000 ? (v / 10000).toFixed(2) + 'w' : v.toFixed(2)
}

function barWidth(item, key) {
  const maxVal = recentStats.value.reduce((m, t) => Math.max(m, (t[key] || 0)), 0)
  if (!maxVal) return 0
  return Math.round(((item[key] || 0) / maxVal) * 100)
}

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    const res = await request.get({ url: '/api/appstore/developer/analytics' })
    const d = res?.data || res || {}
    data.totalApps = d.totalApps ?? 0
    data.totalDownloads = d.totalDownloads ?? 0
    data.totalRevenue = d.totalRevenue ?? 0
    recentStats.value = d.recentStats || []
    topApps.value = d.topApps || []
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.analytics-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

.page-content { padding: 16px; }

.load-wrap { display: flex; justify-content: center; padding: 48px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #00BCD4; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.err-wrap { text-align: center; padding: 48px 16px; }
.err-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }

.section-title { font-size: 15px; font-weight: 700; color: #1a1a1a; margin-bottom: 12px; margin-top: 20px; }
.section-title:first-child { margin-top: 0; }

.stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 4px; }
.stat-card { background: #fff; border-radius: 12px; padding: 16px 12px; text-align: center; }
.stat-val { font-size: 22px; font-weight: 800; color: #1a1a1a; line-height: 1.2; }
.stat-lbl { font-size: 12px; color: #999; margin-top: 4px; }
.stat-accent .stat-val { color: #00BCD4; }
.stat-revenue .stat-val { color: #00BFA5; }

.chart-wrap { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 4px; }
.chart-empty { text-align: center; padding: 32px 0; color: #bbb; font-size: 13px; }
.bar-chart { display: flex; flex-direction: column; gap: 6px; }
.bar-row { display: flex; align-items: center; gap: 8px; }
.bar-date { font-size: 11px; color: #aaa; width: 46px; flex-shrink: 0; text-align: right; }
.bar-tracks { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.bar-track-wrap { height: 7px; background: #f0f2f5; border-radius: 3px; overflow: hidden; }
.bar-track-bar { height: 100%; border-radius: 3px; min-width: 1px; transition: width .3s; }
.bar-dl { background: linear-gradient(90deg, #00BCD4, #4DD0E1); }
.bar-rv { background: linear-gradient(90deg, #00BFA5, #4DB6AC); }
.bar-val { font-size: 11px; color: #666; width: 36px; flex-shrink: 0; font-weight: 600; text-align: right; }
.chart-legend { display: flex; justify-content: center; gap: 20px; margin-top: 10px; }
.legend-item { display: flex; align-items: center; gap: 4px; font-size: 11px; color: #888; }
.legend-dot { width: 8px; height: 8px; border-radius: 2px; }
.ld-dl { background: #00BCD4; }
.ld-rv { background: #00BFA5; }

.empty-sm { text-align: center; padding: 32px 16px; color: #bbb; font-size: 13px; }

.top-list { background: #fff; border-radius: 12px; overflow: hidden; margin-bottom: 4px; }
.top-item { display: flex; align-items: center; gap: 10px; padding: 12px 14px; border-bottom: 1px solid #f5f5f5; }
.top-item:last-child { border-bottom: none; }
.top-rank { width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; background: #f0f2f5; color: #999; flex-shrink: 0; }
.top-rank.top-1 { background: linear-gradient(135deg, #FFD700, #FFA000); color: #fff; }
.top-rank.top-2 { background: linear-gradient(135deg, #C0C0C0, #9E9E9E); color: #fff; }
.top-rank.top-3 { background: linear-gradient(135deg, #CD7F32, #A0522D); color: #fff; }
.top-icon { width: 36px; height: 36px; border-radius: 10px; object-fit: cover; flex-shrink: 0; }
.top-icon-placeholder { background: linear-gradient(135deg, #00BCD4, #4DD0E1); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; }
.top-name { flex: 1; font-size: 14px; font-weight: 600; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.top-count { font-size: 12px; color: #999; flex-shrink: 0; }

.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; }
.btn-primary { background: #00BCD4; color: #fff; border-color: #00BCD4; }
.btn-primary:active { background: #0097A7; }
</style>
