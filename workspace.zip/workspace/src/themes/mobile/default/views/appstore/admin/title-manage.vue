<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">称号管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex gap-2">
        <button v-auth="'add'" class="flex-1 h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openEditDialog(null)">新增称号</button>
        <button class="h-10 px-4 bg-white border border-gray-200 text-gray-600 text-xs rounded-lg active:bg-gray-50 flex items-center gap-1" @click="scanVisible = true">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          扫描
        </button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between" @click="openEditDialog(item)">
              <div class="flex items-center gap-3 flex-1 min-w-0">
                <div class="w-10 h-10 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0" :style="{ background: item.bg_color || item.bgColor || '#ecf5ff' }">
                  <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="w-full h-full object-cover" />
                  <span v-else class="text-xs font-bold" :style="{ color: item.color || '#409EFF' }">{{ (item.name || '?')[0] }}</span>
                </div>
                <div class="min-w-0">
                  <div class="flex items-center gap-2 mb-0.5">
                    <span class="text-sm font-semibold text-gray-800">{{ item.name }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                  </div>
                  <div class="text-xs text-gray-400">{{ conditionText(item.condition_type || item.conditionType, item.condition_value || item.conditionValue) }}</div>
                  <div class="text-[10px] text-gray-400 mt-0.5">排序: {{ item.sort_order || item.sortOrder }}</div>
                </div>
              </div>
              <div class="flex gap-1 flex-shrink-0 ml-2">
                <button class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click.stop="openGrantDialog(item)">授予</button>
                <button class="text-xs px-2 py-1 rounded bg-purple-50 text-purple-500 active:bg-purple-100" @click.stop="openUsersDialog(item)">用户</button>
                <button v-auth="'delete'" class="text-xs px-1.5 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteItem(item)">删</button>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="delVisible" class="fixed inset-0 z-[60] flex items-center justify-center p-4" @click.self.stop="delVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-400">确定要删除「{{ delTarget?.name }}」吗？此操作不可恢复。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="delVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">确定删除</button>
        </div>
      </div>
    </div>

    <!-- 撤销确认弹窗 -->
    <div v-if="revokeVisible" class="fixed inset-0 z-[60] flex items-center justify-center p-4" @click.self.stop="revokeVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认撤销</div>
          <div class="text-xs text-gray-400">确定要撤销「{{ revokeTarget?.nickname || revokeTarget?.username }}」的「{{ usersTarget?.name }}」称号吗？</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="revokeVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doRevoke">确定撤销</button>
        </div>
      </div>
    </div>
  </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无称号</span></div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="editVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="editVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="editVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑称号' : '新增称号' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveTitle">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">称号名称</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>

          <!-- 图标上传 -->
          <div>
            <label class="text-xs text-gray-500 mb-1 block">图标</label>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-xl bg-[#f5f6f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-gray-100">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover" />
                <svg v-else class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">
                {{ uploadingIcon ? '上传中...' : (form.icon ? '重新上传' : '上传图标') }}
              </button>
              <button v-if="form.icon" class="h-9 px-3 text-xs text-gray-400 active:text-red-400" @click="form.icon=''">移除</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
          </div>

          <!-- 颜色 + 预览 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">样式设置</div>
            <div class="flex gap-3">
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">文字颜色</label><input v-model="form.color" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">背景颜色</label><input v-model="form.bgColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-gray-400">预览:</span>
              <span class="inline-block text-xs px-2.5 py-1.5 rounded-full font-medium shadow-sm" :style="{ background: form.bgColor || '#ecf5ff', color: form.color || '#409EFF' }">{{ form.name || '称号预览' }}</span>
            </div>
          </div>

          <div><label class="text-xs text-gray-500 mb-1 block">描述</label><textarea v-model="form.description" rows="2" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>

          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">获取方式</label><select v-model="form.conditionType" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option v-for="opt in conditionOptions" :key="opt.value" :value="opt.value">{{ opt.label }}</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sortOrder" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div v-if="form.conditionType !== 'manual'">
            <template v-if="form.conditionType === 'has_role'">
              <label class="text-xs text-gray-500 mb-1 block">角色代码</label>
              <input v-model="form.conditionValue" placeholder="例如: R_ADMIN" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
              <p class="text-[10px] text-gray-400 mt-1">当前可用: R_SUPER, R_ADMIN, R_MODERATOR, R_REVIEWER</p>
            </template>
            <template v-else>
              <label class="text-xs text-gray-500 mb-1 block">条件阈值（数值）</label>
              <input v-model.number="form.conditionValue" type="number" min="1" placeholder="例如: 50" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </template>
          </div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 授予弹窗 -->
    <div v-if="grantVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="grantVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg animate-slide-up overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="grantVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">授予称号: {{ grantTarget?.name }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="doGrant">确认</button>
        </div>
        <div class="p-4"><label class="text-xs text-gray-500 mb-1 block">用户ID</label><input v-model.number="grantUserId" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
      </div>
    </div>

    <!-- 用户列表弹窗 -->
    <div v-if="usersVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="usersVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="usersVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ usersTarget?.name }} 拥有者</span>
          <span></span>
        </div>
        <div class="flex-1 overflow-y-auto">
          <div v-if="usersList.length>0">
            <div v-for="u in usersList" :key="u.id" class="px-4 py-3.5 border-b border-gray-50 flex items-center justify-between">
              <div class="flex-1">
                <span class="text-sm text-gray-800">{{ u.nickname || u.username || '-' }}</span>
                <span class="text-xs text-gray-400 ml-2">ID:{{ u.id }} | {{ u.grantTime || u.grant_time }}</span>
              </div>
              <button class="text-xs text-red-400 active:text-red-600" @click="revokeTitle(u)">撤销</button>
            </div>
          </div>
          <div v-else class="py-12 text-center text-sm text-gray-400">暂无用户拥有此称号</div>
        </div>
      </div>
    </div>

    <!-- 扫描设置弹窗 -->
    <div v-if="scanVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="scanVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="scanVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">自动扫描设置</span>
          <span></span>
        </div>
        <div class="p-4 space-y-4">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">扫描间隔（分钟）</label>
            <div class="flex items-center gap-2">
              <input v-model.number="scanInterval" type="number" min="1" max="1440" class="flex-1 h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="60" />
              <button class="h-10 px-5 text-sm font-medium bg-[#FF4757] text-white rounded-lg active:opacity-80" @click="saveScanConfig">保存</button>
            </div>
            <p class="text-[10px] text-gray-400 mt-1">范围 1-1440 分钟，默认 60 分钟</p>
          </div>
          <div>
            <button class="w-full h-11 text-sm font-medium bg-blue-50 text-blue-500 rounded-xl active:bg-blue-100" :disabled="scanning" @click="doManualScan">
              {{ scanning ? '扫描中...' : '立即扫描全部用户' }}
            </button>
          </div>
          <div v-if="lastScan" class="text-[11px] text-gray-400 text-center">上次扫描: {{ lastScan }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'TitleManageMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const conditionMap: Record<string,string> = {
  manual: '手动授予',
  post_count: '发布帖子数',
  like_received: '获得点赞数',
  comment_count: '发表评论数',
  checkin_days: '签到天数',
  coin_received: '累计余额收入',
  likes_given: '主动点赞数',
  follower_count: '粉丝数',
  following_count: '关注人数',
  collection_count: '创建合集数',
  favorite_count: '收藏帖子数',
  vote_participated: '参与投票次数',
  task_completed: '完成任务数',
  topic_followed: '关注话题数',
  draft_count: '草稿数量',
  mall_orders: '商城下单次数',
  chat_messages: '聊天发言数',
  content_purchased: '付费购买次数',
  app_count: '安装应用数',
  app_comments: '应用评论数',
  post_shared: '帖子转发数',
  experience_total: '累计经验值',
  points_earned: '累计积分收入',
  points_spent: '累计积分支出',
  membership_count: '购买会员次数',
  recharge_total: '累计充值金额',
  invite_success: '成功邀请人数',
  balance_spent: '累计余额支出',
  report_count: '举报次数',
  withdraw_total: '累计提现金额',
  game_played: '游戏总场次',
  game_won: '游戏胜场数',
  mall_review_count: '商城评价次数',
  coupon_used_count: '使用优惠券次数',
  message_sent: '发送私信数',
  rating_count: '评分次数',
  trust_level: '社区信任等级',
  app_favorite_count: '收藏应用数',
  collection_favorite_count: '收藏合集数',
  mall_favorite_count: '收藏商品数',
  verified: '通过实名认证',
  has_role: '拥有角色(输入角色代码)'
}
const conditionOptions = Object.entries(conditionMap).map(([value, label]) => ({ value, label }))
const conditionText=(t:string, cv?:string)=>{
  const label = conditionMap[t] || t
  if (t === 'has_role') return label + ': ' + (cv || '')
  if (cv != null && cv !== '' && t !== 'manual') return label + '>=' + cv
  return label
}

const loading=ref(false);const data=ref<any[]>([])
const fetchData=async()=>{loading.value=true;try{const res:any=await request.get({url:'/api/title/all'});const list=res?.records||res?.data?.records||res?.data||res||[];data.value=list}catch{}loading.value=false}

// Icon upload
const iconInput=ref<HTMLInputElement>();const uploadingIcon=ref(false)
const triggerIconUpload=()=>iconInput.value?.click()
const handleIconUpload=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploadingIcon.value=true;try{const fd=new FormData();fd.append('file',file);const res:any=await request.post({url:'/api/upload/file',data:fd,headers:{}});form.icon=res?.url||res?.data?.url||res?.data||'';showToast('上传成功')}catch(e:any){showToast('上传失败: '+(e.message||''),'error')}uploadingIcon.value=false;input.value=''}

// Edit
const editVisible=ref(false);const editId=ref<number|null>(null)
const form=reactive({name:'',icon:'',color:'#409EFF',bgColor:'#ecf5ff',description:'',conditionType:'manual',conditionValue:'',sortOrder:0,status:'1'})

const openEditDialog=(item:any|null)=>{editId.value=item?.id||null;if(item){form.name=item.name||'';form.icon=item.icon||'';form.color=item.color||'#409EFF';form.bgColor=item.bg_color||item.bgColor||'#ecf5ff';form.description=item.description||'';form.conditionType=item.condition_type||item.conditionType||'manual';form.conditionValue=item.condition_value||item.conditionValue||'';form.sortOrder=item.sort_order||item.sortOrder||0;form.status=item.status||'1'}else{Object.assign(form,{name:'',icon:'',color:'#409EFF',bgColor:'#ecf5ff',description:'',conditionType:'manual',conditionValue:'',sortOrder:0,status:'1'})}editVisible.value=true}

const saveTitle=async()=>{try{await request.post({url:'/api/title/save',data:{id:editId.value||undefined,...form}});showToast('保存成功');editVisible.value=false;fetchData()}catch(e:any){showToast('保存失败: '+(e.message||''),'error')}}
const deleteItem=(item:any)=>{delTarget.value=item;delVisible.value=true}
const delVisible=ref(false);const delTarget=ref<any>(null)
const doDelete=async()=>{if(!delTarget.value)return;try{await request.del({url:`/api/title/${delTarget.value.id}`});showToast('删除成功');delVisible.value=false;fetchData()}catch{showToast('删除失败','error')}}

// Grant
const grantVisible=ref(false);const grantTarget=ref<any>(null);const grantUserId=ref<number>(0)
const openGrantDialog=(item:any)=>{grantTarget.value=item;grantUserId.value=0;grantVisible.value=true}
const doGrant=async()=>{if(!grantUserId.value){showToast('请输入用户ID','error');return};try{await request.post({url:`/api/user/${grantUserId.value}/grant-title`,data:{titleId:grantTarget.value.id}});showToast('授予成功');grantVisible.value=false;fetchData()}catch(e:any){showToast('授予失败: '+(e.message||''),'error')}}

// Users
const usersVisible=ref(false);const usersTarget=ref<any>(null);const usersList=ref<any[]>([])
const openUsersDialog=async(item:any)=>{usersTarget.value=item;usersVisible.value=true;try{const res:any=await request.get({url:`/api/title/${item.id}/users`});usersList.value=res?.records||res?.data?.records||res?.data||res||[]}catch{usersList.value=[]}}
const revokeTitle=(u:any)=>{revokeTarget.value=u;revokeVisible.value=true}
const revokeVisible=ref(false);const revokeTarget=ref<any>(null)
const doRevoke=async()=>{if(!revokeTarget.value||!usersTarget.value)return;try{await request.del({url:`/api/user/${revokeTarget.value.id}/revoke-title/${usersTarget.value.id}`});showToast('已撤销');revokeVisible.value=false;usersList.value=usersList.value.filter(x=>x.id!==revokeTarget.value.id)}catch{showToast('撤销失败','error')}}

// Scan config
const scanVisible = ref(false)
const scanInterval = ref(60)
const lastScan = ref('')
const scanning = ref(false)
const fetchScanConfig = async () => {
  try {
    const res: any = await request.get({ url: '/api/admin/titles/scan-config' })
    scanInterval.value = res?.interval || 60
    lastScan.value = res?.lastScan || ''
  } catch {}
}
const saveScanConfig = async () => {
  const val = Math.max(1, Math.min(1440, scanInterval.value || 60))
  try {
    await request.put({ url: '/api/admin/titles/scan-config', data: { interval: val } })
    scanInterval.value = val
    scanVisible.value = false
    showToast('保存成功')
  } catch (e: any) { showToast('保存失败: ' + (e.message || ''), 'error') }
}
const doManualScan = async () => {
  scanning.value = true
  try {
    const res: any = await request.post({ url: '/api/admin/titles/check', data: {} })
    const unlocked = res?.unlocked || []
    showToast(unlocked.length > 0 ? `扫描完成，新解锁 ${unlocked.length} 个称号` : '扫描完成，无新解锁称号')
    fetchScanConfig()
  } catch (e: any) { showToast('扫描失败: ' + (e.message || ''), 'error') }
  scanning.value = false
}

onMounted(() => { fetchData(); fetchScanConfig() })
</script>
