<template>
  <!-- ===== COMMENT COMPOSE DIALOG ===== -->
  <Teleport to="body">
    <div v-if="showCommentDialog" class="comment-dialog-overlay" @click.self="showCommentDialog = false">
      <div class="comment-dialog">
        <div class="comment-dialog-header">
          <span class="comment-dialog-title">发表评论</span>
          <button class="comment-dialog-close" @click="showCommentDialog = false">&times;</button>
        </div>
        <div class="comment-dialog-body">
          <textarea v-model="newCommentText" placeholder="说说你的看法..." class="comment-dialog-textarea" rows="4"></textarea>
          <div class="comment-dialog-toolbar">
            <label class="comment-dialog-img-btn">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.6" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
              <input type="file" accept="image/*" multiple hidden @change="onCommentImagesSelected"/>
            </label>
          </div>
          <div v-if="commentImages.length > 0" class="comment-dialog-imgs">
            <div v-for="(img, idx) in commentImages" :key="idx" class="comment-dialog-img-item">
              <img :src="$fixImgUrl(img)" class="comment-dialog-img-thumb" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
              <button class="comment-dialog-img-remove" @click="commentImages.splice(idx,1); commentFiles.splice(idx,1)">&times;</button>
            </div>
          </div>
        </div>
        <div class="comment-dialog-footer">
          <button class="comment-dialog-cancel" @click="showCommentDialog = false">取消</button>
          <button class="comment-dialog-send" :disabled="!newCommentText.trim() && commentImages.length===0" @click="submitComment">发送</button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- ===== COMMENTS ===== -->
  <div class="comments-section">
    <div class="comments-header">
      <span class="comments-title">共 {{ commentsTotal }} 回复</span>
      <div class="comments-sort">
        <button v-for="s in ['默认','最新','热门','楼主']" :key="s" class="sort-btn" :class="{active: sortBy===s}" @click="changeSortBy(s)">{{ s }}</button>
      </div>
    </div>

    <div v-if="commentsLoading" class="comments-loading"><span class="spin"/></div>
    <div v-else-if="sortedComments.length===0" class="comments-empty">
      <div class="empty-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
      <p>还没有评论</p>
      <span>来说两句吧</span>
    </div>

    <div v-else class="comments-list">
      <div v-for="c in sortedComments" :key="c.id" class="comment-card" :class="{ pinned: c.isPinned, hot: c.likeCount >= 10 && !c.isPinned }">
        <div class="comment-card-inner">
        <div class="comment-avatar-wrap">
          <img v-if="c.userAvatarFrame" :src="c.userAvatarFrame" class="comment-avatar-frame" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
          <div class="comment-avatar-img">
            <img src="@imgs/user/avatar.webp" class="comment-avatar-pic"  loading="lazy" />
            <img v-if="c.userAvatar" :src="$fixImgUrl(c.userAvatar)" class="comment-avatar-pic comment-avatar-user" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
          </div>
        </div>
        <div class="comment-main">
          <div class="comment-meta">
            <span class="comment-username">{{ c.userName }}</span>
            <img v-if="c.userExpLevelIcon && c.userExpLevelIcon.startsWith('http')" :src="c.userExpLevelIcon" class="comment-level-icon" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
            <img v-for="(icon, idx) in ((c as any).userAllTitleIcons || '').split('|||').filter(Boolean)" :key="idx" :src="icon" class="comment-title-icon" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
            <img v-if="c.userMemberLevelIcon" :src="c.userMemberLevelIcon" class="comment-member-icon" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
            <span v-if="c.userId === post?.userId" class="comment-author-badge">作者</span>
            <span v-if="c.isPinned" class="comment-pinned-badge">置顶</span>
            <span v-if="c.likeCount >= 10 && !c.isPinned" class="comment-hot-badge">热</span>
            <span class="comment-meta-spacer"></span>
            <span class="comment-floor">{{ commentFloorMap[c.id] }}楼</span>
            <div class="comment-menu-wrap">
              <button class="comment-menu-btn" @click.stop="toggleCommentMenu(c.id)">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
              </button>
              <div v-if="commentMenuId===c.id" class="comment-dropdown">
                <div v-if="canPinComment(c)" class="comment-menu-item" @click.stop="handlePinComment(c);commentMenuId=null">{{ c.isPinned ? '取消置顶' : '置顶' }}</div>
                <div v-if="canDeleteComment(c)" class="comment-menu-item" @click.stop="handleDeleteComment(c);commentMenuId=null">删除</div>
                <div v-if="getUserId()" class="comment-menu-item" @click.stop="handleReportComment(c);commentMenuId=null">举报</div>
              </div>
            </div>
          </div>
          <div class="comment-title-row">
            <template v-if="((c as any).userAllTitleNames || '').split('|||')[0]">
              <span class="comment-tag comment-tag-t1">{{ ((c as any).userAllTitleNames || '').split('|||')[0] }}</span>
              <span v-if="((c as any).userAllTitleNames || '').split('|||')[1]" class="comment-tag comment-tag-t2">{{ ((c as any).userAllTitleNames || '').split('|||')[1] }}</span>
            </template>
            <span v-else class="comment-tag comment-tag-member">{{ (c as any).userMemberLevelName || '普通用户' }}</span>
          </div>
          <div class="comment-content" v-html="sanitizeContent(c.content)"></div>
          <div v-if="c.images && c.images.length" class="comment-imgs">
            <img v-for="(img, idx) in c.images" :key="idx" :src="$fixImgUrl(img)" class="comment-img" loading="lazy" @click.stop="$emit('preview-image', c.images!, idx)" @error="($event.target as HTMLImageElement).style.display='none'"/>
          </div>
          <div class="comment-footer">
            <span class="comment-time">{{ fmtTime(c.createTime) }}</span>
            <button class="comment-act" @click="toggleReplyInput(c)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>
              <span>{{ c.replyCount || 0 }}</span>
            </button>
            <button class="comment-act" :class="{liked: c._isLiked}" @click="handleCommentLike(c)">
              <svg width="14" height="14" viewBox="0 0 24 24" :fill="c._isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>
              <span>{{ c.likeCount || 0 }}</span>
            </button>
          </div>

          <div v-if="replyingTo===c.id" class="reply-input-area">
            <div class="reply-input-row">
              <input v-model="replyText" :placeholder="'回复 '+c.userName+'...'" class="reply-input" @keyup.enter="submitReply(c)"/>
              <label class="reply-img-btn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                <input type="file" accept="image/*" multiple hidden @change="onReplyImagesSelected"/>
              </label>
              <button class="reply-cancel" @click="replyingTo=null;replyText='';replyImages=[]">取消</button>
              <button class="reply-send" :disabled="!replyText.trim() && replyImages.length===0" @click="submitReply(c)">发送</button>
            </div>
            <div v-if="replyImages.length > 0" class="comment-img-previews">
              <div v-for="(img, idx) in replyImages" :key="idx" class="comment-img-preview">
                <img :src="$fixImgUrl(img)" class="comment-img-thumb" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                <button class="comment-img-remove" @click="replyImages.splice(idx,1); replyFiles.splice(idx,1)">&times;</button>
              </div>
            </div>
          </div>

          <div v-if="c.replies&&c.replies.length" class="replies-wrap">
            <div v-for="r in c.replies" :key="r.id" class="reply-item">
              <div class="reply-meta">
                <span class="reply-username">{{ r.userName }}</span>
                <span class="reply-colon">：</span>
                <span class="reply-content" v-html="sanitizeContent(r.content)"></span>
              </div>
              <div v-if="r.images && r.images.length" class="comment-imgs" style="margin-top:4px">
                <img v-for="(img, idx) in r.images" :key="idx" :src="$fixImgUrl(img)" class="comment-img" loading="lazy" @click.stop="$emit('preview-image', r.images!, idx)" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div class="reply-footer">
                <span class="comment-time">{{ fmtTime(r.createTime) }}</span>
                <button v-if="canDeleteReply(r)" class="reply-del" @click="handleDeleteReply(c, r)">删除</button>
                <button v-if="getUserId()" class="reply-del" @click="handleReportComment(r)">举报</button>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
      <div v-if="hasMoreComments" class="load-more-wrap" @click="loadMoreComments">
        <span v-if="loadingMore" class="load-more-spin"></span>
        <span v-else>加载更多评论 ({{ commentsTotal - comments.length }})</span>
      </div>
    </div>
  </div>

  <!-- 底部操作栏 -->
  <div class="comment-bottom-bar" v-if="!(post as any)?.isLocked || userIsAdmin()">
    <button class="comment-bottom-donate" @click="$emit('donate')">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
      <span>打赏</span>
    </button>
    <div class="comment-bottom-trigger" @click="openCommentDialog">
      <span class="comment-bottom-placeholder">{{ (post as any)?.tags?.length ? '#' + (post as any).tags[0] : '' }} 说点什么...</span>
      <svg class="comment-bottom-emoji" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
    </div>
    <div class="comment-bottom-actions">
      <button class="comment-bottom-act" @click="openCommentDialog">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
        <span>{{ post?.commentCount || 0 }}</span>
      </button>
      <button class="comment-bottom-act" :class="{active: post?.isLiked}" @click="$emit('like')">
        <svg width="18" height="18" viewBox="0 0 24 24" :fill="post?.isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3m7-2V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>
        <span :class="{active: post?.isLiked}">{{ post?.likeCount || 0 }}</span>
      </button>
      <button class="comment-bottom-act" :class="{active: postIsFavInGroup}" @click="$emit('fav')">
        <svg width="18" height="18" viewBox="0 0 24 24" :fill="postIsFavInGroup ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        <span :class="{active: postIsFavInGroup}">{{ postIsFavInGroup ? '已收藏' : '收藏' }}</span>
      </button>
      <button class="comment-bottom-act">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        <span>{{ post?.viewCount || 0 }}</span>
      </button>
    </div>
  </div>
  <div v-else-if="!post" class="empty-wrap"><span>帖子不存在或已被删除</span></div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onBeforeUnmount, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { fetchComments, postComment, deleteComment, likeComment, pinComment, reportComment } from '@/api/community'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import request from '@/utils/http'
import { compressFromPolicy } from '@/utils/uploadCompress'
import type { CommunityPost, CommunityComment } from '@/api/community'

const props = defineProps<{
  postId: number
  post: CommunityPost | null
  postIsFavInGroup: boolean
}>()

const emit = defineEmits<{
  'preview-image': [images: string[], idx: number]
  'donate': []
  'like': []
  'fav': []
  'commented': []
  'report-comment': [commentId: number]
}>()

const userStore = useUserStore()

const comments = ref<(CommunityComment & { _isLiked?: boolean; _originalLiked?: boolean })[]>([])
const commentsLoading = ref(false)
const commentsPage = ref(1)
const commentsTotal = ref(0)
const commentsPageSize = 20
const hasMoreComments = computed(() => comments.value.length < commentsTotal.value)
const loadingMore = ref(false)
const replyingTo = ref<number | null>(null)
const replyText = ref('')
const newCommentText = ref('')
const commentImages = ref<string[]>([])
const commentFiles = ref<File[]>([])
const showCommentDialog = ref(false)
const replyImages = ref<string[]>([])
const replyFiles = ref<File[]>([])
const uploadingImage = ref(false)
const sortBy = ref('默认')
const commentMenuId = ref<number | null>(null)

function openCommentDialog() { showCommentDialog.value = true }

function toggleCommentMenu(id: number) {
  commentMenuId.value = commentMenuId.value === id ? null : id
}

let closeCommentMenuHandler: ((e: MouseEvent) => void) | null = null
watch(commentMenuId, (val) => {
  if (val != null) {
    closeCommentMenuHandler = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (!target.closest('.comment-menu-wrap')) commentMenuId.value = null
    }
    setTimeout(() => document.addEventListener('click', closeCommentMenuHandler!), 0)
  } else if (closeCommentMenuHandler) {
    document.removeEventListener('click', closeCommentMenuHandler)
    closeCommentMenuHandler = null
  }
})

onBeforeUnmount(() => {
  if (closeCommentMenuHandler) {
    document.removeEventListener('click', closeCommentMenuHandler)
  }
})

const sortedComments = computed(() => {
  if (sortBy.value === '楼主') {
    return comments.value.filter(c => c.userId === props.post?.userId)
  }
  return comments.value
})

const commentFloorMap = computed(() => {
  const sorted = [...comments.value].sort((a, b) => new Date(a.createTime).getTime() - new Date(b.createTime).getTime())
  const map: Record<number, number> = {}
  sorted.forEach((c, i) => { map[c.id] = i + 1 })
  return map
})

function changeSortBy(s: string) {
  if (sortBy.value === s) return
  sortBy.value = s
  loadComments(true)
}

function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }

function canDeleteComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid) return false
  return c.userId === uid || props.post?.userId === uid || userIsAdmin()
}
function canPinComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid || c.parentId) return false
  return props.post?.userId === uid || userIsAdmin()
}
function canDeleteReply(r: CommunityComment) {
  const uid = getUserId()
  if (!uid) return false
  return r.userId === uid || props.post?.userId === uid || userIsAdmin()
}

function fmtTime(t: string) {
  if (!t) return ''
  const s = t.replace(' ', 'T')
  const d0 = s.match(/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/) ? new Date(s) : new Date(s + 'Z')
  if (isNaN(d0.getTime())) return t.slice(0, 10)
  const d = Date.now() - d0.getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}

function sanitizeContent(html: string): string {
  if (!html) return ''
  return sanitizeHtml(html)
}

function parseCommentImages(list: any[]) {
  for (const c of list) {
    try { c.images = typeof c.images === 'string' ? JSON.parse(c.images) : (c.images || []) } catch { c.images = [] }
    if (c.replies) {
      for (const r of c.replies) {
        try { r.images = typeof r.images === 'string' ? JSON.parse(r.images) : (r.images || []) } catch { r.images = [] }
      }
    }
  }
}

async function loadComments(reset = true) {
  if (!props.postId) return
  if (reset) {
    commentsPage.value = 1
    commentsLoading.value = true
  } else {
    loadingMore.value = true
  }
  try {
    const params: Record<string, unknown> = { page: commentsPage.value, pageSize: commentsPageSize }
    if (sortBy.value === '热门') params.sortBy = 'hot'
    const r: any = await fetchComments(props.postId, params)
    const list = r.data?.list || r.list || r.data || []
    const total = r.data?.total ?? r.total ?? 0
    commentsTotal.value = total
    parseCommentImages(list)
    const mapped = (list as CommunityComment[]).map(c => ({ ...c, _isLiked: !!(c as any).isLiked, _originalLiked: !!(c as any).isLiked }))
    comments.value = reset ? mapped : [...comments.value, ...mapped]
  } catch {} finally {
    commentsLoading.value = false
    loadingMore.value = false
  }
}

async function loadMoreComments() {
  if (!hasMoreComments.value || loadingMore.value) return
  commentsPage.value++
  await loadComments(false)
}

function toggleReplyInput(c: CommunityComment & { _isLiked?: boolean }) { replyingTo.value = replyingTo.value === c.id ? null : c.id; replyText.value = '' }

function onCommentImagesSelected(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files) return
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    commentFiles.value.push(file)
    const reader = new FileReader()
    reader.onload = () => { commentImages.value.push(reader.result as string) }
    reader.readAsDataURL(file)
  }
}

function onReplyImagesSelected(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files) return
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    replyFiles.value.push(file)
    const reader = new FileReader()
    reader.onload = () => { replyImages.value.push(reader.result as string) }
    reader.readAsDataURL(file)
  }
}

async function uploadImage(file: File): Promise<string> {
  const { file: compressedFile } = await compressFromPolicy(file)
  const formData = new FormData()
  formData.append('file', compressedFile, compressedFile.name)
  const r: any = await request.post({ url: '/api/upload/file', data: formData })
  const data = r?.data || r
  return data?.url || ''
}

async function submitReply(pc: CommunityComment & { _isLiked?: boolean }) {
  const t = replyText.value.trim()
  if (!t && replyImages.value.length === 0) return
  if (!props.postId) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再回复'); return }
  try {
    let uploadedUrls: string[] = []
    if (replyImages.value.length > 0) {
      uploadingImage.value = true
      for (const file of replyFiles.value) {
        const url = await uploadImage(file)
        if (url) uploadedUrls.push(url)
      }
      uploadingImage.value = false
    }
    const r: any = await postComment(props.postId, { userId: u, content: t || '', parent_id: pc.id, images: uploadedUrls })
    const nr: any = r.data || r
    if (!pc.replies) pc.replies = []
    pc.replies.push({ id: nr.id || Date.now(), postId: props.postId, parentId: pc.id, userId: u, userName: (userStore.info as any)?.username || '我', userAvatar: '', content: t, images: uploadedUrls, likeCount: 0, replyCount: 0, createTime: new Date().toISOString() })
    pc.replyCount = (pc.replyCount || 0) + 1; replyingTo.value = null; replyText.value = ''; replyImages.value = []; replyFiles.value = []
  } catch {}
}

async function submitComment() {
  const t = newCommentText.value.trim()
  if (!t && commentImages.value.length === 0) return
  if (!props.postId) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再评论'); return }
  try {
    let uploadedUrls: string[] = []
    if (commentImages.value.length > 0) {
      uploadingImage.value = true
      for (const file of commentFiles.value) {
        const url = await uploadImage(file)
        if (url) uploadedUrls.push(url)
      }
      uploadingImage.value = false
    }
    const r: any = await postComment(props.postId, { userId: u, content: t || '', parent_id: 0, images: uploadedUrls })
    if (props.post) props.post.commentCount = (props.post.commentCount || 0) + 1
    newCommentText.value = ''; commentImages.value = []; commentFiles.value = []
    showCommentDialog.value = false
    const fileInput = document.querySelector('.comment-dialog-img-btn input[type=file]') as HTMLInputElement
    if (fileInput) fileInput.value = ''
    emit('commented')
    await loadComments()
  } catch {}
}

async function handleCommentLike(c: CommunityComment & { _isLiked?: boolean }) {
  const u = getUserId(); if (!u) { ElMessage.warning('请先登录'); return }
  try {
    const r: any = await likeComment(c.id)
    const d = r.data || r
    c._isLiked = d.isLiked
    c.likeCount = d.likeCount
  } catch {}
}

async function handleDeleteComment(c: CommunityComment) {
  const u = getUserId(); if (!u) return
  try {
    await ElMessageBox.confirm('确定删除这条评论吗？', '确认删除', { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' })
    await deleteComment(c.id, u); comments.value = comments.value.filter(x => x.id !== c.id); if (props.post) props.post.commentCount = Math.max(0, (props.post.commentCount || 1) - 1 - (c.replyCount||0))
  } catch {}
}

function handleReportComment(c: CommunityComment & { _isLiked?: boolean }) {
  emit('report-comment', c.id)
}

async function handlePinComment(c: CommunityComment) {
  try {
    const action = c.isPinned ? '取消置顶' : '置顶'
    await ElMessageBox.confirm(`确定${action}这条评论吗？`, '确认操作', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'info' })
    const r: any = await pinComment(c.id)
    const d = r.data || r
    c.isPinned = d.isPinned ? 1 : 0
    comments.value.sort((a, b) => (b.isPinned || 0) - (a.isPinned || 0))
    ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶')
  } catch {}
}

async function handleDeleteReply(parent: CommunityComment, reply: CommunityComment) {
  const u = getUserId(); if (!u) return
  try {
    await ElMessageBox.confirm('确定删除这条回复吗？', '确认删除', { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' })
    await deleteComment(reply.id, u)
    if (parent.replies) {
      parent.replies = parent.replies.filter(x => x.id !== reply.id)
      parent.replyCount = Math.max(0, (parent.replyCount || 1) - 1)
    }
    if (props.post) props.post.commentCount = Math.max(0, (props.post.commentCount || 1) - 1)
  } catch {}
}

watch(() => props.postId, () => {
  if (props.postId) {
    loadComments()
  }
})

const hasUserCommented = computed(() => {
  const uid = getUserId()
  if (!uid) return false
  return comments.value.some(c => c.userId === uid) ||
    comments.value.some(c => (c.replies || []).some((r: any) => r.userId === uid))
})

defineExpose({ openCommentDialog, loadComments, hasUserCommented })

onMounted(() => {
  if (props.postId) {
    loadComments()
  }
})
</script>

<style scoped>
.comments-section { padding-bottom: 80px; }
.comments-header { display: flex; align-items: center; justify-content: space-between; padding: 12px 8px; }
.comments-title { font-size: 15px; font-weight: 600; color: #333; }
.comments-sort { display: flex; gap: 0; background: #f0f0f0; border-radius: 8px; overflow: hidden; }
.sort-btn { font-size: 11px; color: #666; background: transparent; border: none; padding: 2px 8px; cursor: pointer; transition: all .15s; }
.sort-btn.active { color: #fff; font-weight: 600; background: #508DFF; }
.comments-loading { display: flex; justify-content: center; padding: 40px 0; }
.comments-empty { padding: 56px 16px; text-align: center; display: flex; flex-direction: column; align-items: center; }
.empty-icon { margin-bottom: 12px; }
.comments-empty p { margin: 0 0 4px; font-size: 15px; color: #999; }
.comments-empty span { font-size: 13px; color: #bbb; }
.comments-list { padding: 0; }
.comment-card { padding: 2px 0; position: relative; }
.comment-card:not(:last-child)::after {
  content: '';
  position: absolute; bottom: 0; left: 46px; right: 16px;
  height: 0.5px; background: #eee;
}
.comment-card.hot { background: linear-gradient(135deg, #fff5f5, transparent); border-radius: 0; }
.comment-card-inner { display: flex; gap: 10px; padding: 8px 0; }
.comment-avatar-wrap { position: relative; width: 48px; height: 48px; flex-shrink: 0; }
.comment-avatar-frame { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0; }
.comment-avatar-img { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 34px; height: 34px; border-radius: 50%; overflow: hidden; z-index: 1; }
.comment-avatar-pic { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
.comment-avatar-user { position: absolute; inset: 0; z-index: 1; }
.comment-main { flex: 1; min-width: 0; }
.comment-meta { display: flex; align-items: center; gap: 0; margin-bottom: 1px; flex-wrap: wrap; }
.comment-level-icon { width: 40px; height: 28px; object-fit: contain; flex-shrink: 0; margin-left: 3px; }
.comment-title-icon { width: 22px; height: 22px; object-fit: contain; flex-shrink: 0; }
.comment-member-icon { width: 22px; height: 22px; object-fit: contain; flex-shrink: 0; }
.comment-meta-spacer { flex: 1; }
.comment-menu-wrap { position: relative; flex-shrink: 0; }
.comment-menu-btn {
  background: none; border: none; cursor: pointer;
  padding: 2px 4px; border-radius: 4px; color: #bbb;
  display: flex; align-items: center;
  transition: background .12s;
}
.comment-menu-btn:active { background: #f0f0f0; }
.comment-dropdown {
  position: absolute; right: 0; top: 100%;
  background: #fff; border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,.12);
  min-width: 110px; padding: 6px 0; z-index: 999;
  overflow: hidden;
  animation: cmIn .15s ease;
}
@keyframes cmIn { from { opacity: 0; transform: translateY(-4px) scale(.92); } to { opacity: 1; transform: translateY(0) scale(1); } }
.comment-menu-item {
  padding: 10px 18px; font-size: 14px; color: #333;
  cursor: pointer; white-space: nowrap;
  transition: background .1s;
}
.comment-menu-item:active { background: #f2f3f5; }
.comment-menu-item:nth-child(2) { color: #e44; }
.comment-username { font-size: 13px; font-weight: 600; color: #00BFA5; }
.comment-author-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #E8F5E9; color: #43A047; font-weight: 600; line-height: 14px; margin-right: 4px; }
.comment-pinned-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #FFF3E0; color: #E65100; font-weight: 600; line-height: 14px; margin-left: 4px; }
.comment-hot-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #FFEDED; color: #E53E3E; font-weight: 600; line-height: 14px; margin-right: 4px; }
.comment-floor { font-size: 10px; color: #aaa; flex-shrink: 0; }
.comment-title-row { display: flex; gap: 4px; margin: 2px 0; }
.comment-tag { font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; }
.comment-tag-t1 { color: #7c3aed; background: #ede9fe; }
.comment-tag-t2 { color: #db2777; background: #fce7f3; }
.comment-tag-member { color: #6b7280; background: #f3f4f6; }
.comment-content { font-size: 15px; color: #222; line-height: 1.6; word-break: break-word; }
.comment-imgs { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.comment-img { width: 72px; height: 72px; border-radius: 6px; object-fit: cover; cursor: pointer; }
.comment-footer { display: flex; align-items: center; gap: 16px; margin-top: 8px; }
.comment-time { font-size: 12px; color: #bbb; }
.comment-act { display: inline-flex; align-items: center; gap: 3px; font-size: 12px; color: #aaa; background: none; border: none; cursor: pointer; padding: 0; }
.comment-act svg { flex-shrink: 0; }
.comment-act.liked { color: #ef4444; }

.reply-input-area { margin-top: 10px; }
.reply-input-row { display: flex; align-items: center; gap: 8px; }
.reply-input { flex: 1; background: #F2F3F5; border: none; border-radius: 16px; padding: 8px 12px; font-size: 13px; color: #333; outline: none; }
.reply-input::placeholder { color: #bbb; }
.reply-img-btn { display: flex; align-items: center; cursor: pointer; padding: 4px; flex-shrink: 0; }
.reply-cancel { font-size: 12px; color: #aaa; background: none; border: none; cursor: pointer; white-space: nowrap; }
.reply-send { font-size: 12px; background: #333; color: #fff; border: none; border-radius: 14px; padding: 5px 14px; cursor: pointer; }
.reply-send:disabled { opacity: .3; }

.replies-wrap { margin-top: 8px; background: #F5F6F8; border-radius: 10px; padding: 10px 12px; }
.reply-item { padding: 5px 0; line-height: 1.6; }
.reply-item + .reply-item { border-top: 1px solid #ececec; }
.reply-username { font-size: 13px; font-weight: 600; color: #00BFA5; }
.reply-meta { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.reply-colon { color: #aaa; }
.reply-content { font-size: 14px; color: #333; }
.reply-footer { display: flex; align-items: center; gap: 12px; margin-top: 4px; }
.reply-del { font-size: 11px; color: #bbb; background: none; border: none; cursor: pointer; padding: 0; }

.comment-img-previews { display: flex; gap: 8px; flex-wrap: wrap; padding: 8px 0 0; }
.comment-img-preview { position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden; }
.comment-img-thumb { width: 100%; height: 100%; object-fit: cover; }
.comment-img-remove {
  position: absolute; top: 2px; right: 2px;
  width: 18px; height: 18px; border-radius: 50%;
  background: rgba(0,0,0,.5); color: #fff; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
  border: none; cursor: pointer; line-height: 1;
}

.comment-dialog-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,.45);
  z-index: 2000;
  display: flex; align-items: flex-end; justify-content: center;
}
.comment-dialog {
  width: 100%; max-width: 480px;
  background: #fff;
  border-radius: 16px 16px 0 0;
  overflow: hidden;
  animation: cdSlideUp .25s ease;
}
@keyframes cdSlideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.comment-dialog-header {
  display: flex; align-items: center; justify-content: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f0f0f0;
  position: relative;
}
.comment-dialog-title { font-size: 16px; font-weight: 600; color: #111; }
.comment-dialog-close {
  position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
  width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;
  font-size: 22px; color: #999; background: none; border: none; cursor: pointer;
}
.comment-dialog-body { padding: 16px; }
.comment-dialog-textarea {
  width: 100%; border: none; outline: none; resize: none;
  font-size: 15px; line-height: 1.6; color: #222;
  background: #f7f7f7; border-radius: 10px; padding: 12px;
  box-sizing: border-box;
}
.comment-dialog-toolbar {
  display: flex; align-items: center; padding: 8px 0 0;
}
.comment-dialog-img-btn {
  display: flex; align-items: center; justify-content: center;
  width: 34px; height: 34px; border-radius: 8px;
  background: #f5f5f5; cursor: pointer;
}
.comment-dialog-imgs {
  display: flex; gap: 8px; flex-wrap: wrap; padding: 8px 0 0;
}
.comment-dialog-img-item {
  position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden;
}
.comment-dialog-img-thumb {
  width: 100%; height: 100%; object-fit: cover;
}
.comment-dialog-img-remove {
  position: absolute; top: 2px; right: 2px;
  width: 18px; height: 18px; border-radius: 50%;
  background: rgba(0,0,0,.5); color: #fff; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
  border: none; cursor: pointer; line-height: 1;
}
.comment-dialog-footer {
  display: flex; gap: 12px; padding: 12px 16px 20px;
  border-top: 1px solid #f0f0f0;
}
.comment-dialog-cancel {
  flex: 1; height: 42px; border-radius: 21px;
  background: #f0f0f0; color: #666; font-size: 15px;
  border: none; cursor: pointer;
}
.comment-dialog-send {
  flex: 1; height: 42px; border-radius: 21px;
  background: linear-gradient(135deg, #508DFF, #3b6fcf); color: #fff; font-size: 15px; font-weight: 600;
  border: none; cursor: pointer;
}
.comment-dialog-send:disabled { opacity: .4; cursor: not-allowed; }

.comment-bottom-bar {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: #fff; z-index: 100;
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px calc(8px + env(safe-area-inset-bottom));
  box-shadow: 0 -2px 8px rgba(0,0,0,.06);
  border-top: 1px solid #f0f0f0;
}
.comment-bottom-donate {
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  background: none; border: none; cursor: pointer;
  padding: 4px 6px; border-radius: 8px;
  color: #F59E0B; font-size: 11px; font-weight: 600;
  flex-shrink: 0;
  transition: background .12s;
}
.comment-bottom-donate:hover { background: #fef3c7; }
.comment-bottom-trigger {
  flex: 1;
  display: flex; align-items: center; justify-content: space-between;
  background: #f5f5f5;
  border-radius: 20px;
  padding: 8px 12px;
  cursor: pointer;
  transition: background .12s;
}
.comment-bottom-trigger:hover { background: #eee; }
.comment-bottom-placeholder { font-size: 13px; color: #bbb; }
.comment-bottom-emoji { flex-shrink: 0; }
.comment-bottom-actions { display: flex; align-items: center; gap: 2px; flex-shrink: 0; }
.comment-bottom-act {
  display: inline-flex; flex-direction: column; align-items: center; gap: 1px;
  background: none; border: none; cursor: pointer;
  padding: 4px 5px; border-radius: 6px;
  color: #999; font-size: 11px;
  transition: color .12s, background .12s;
}
.comment-bottom-act:hover { color: #508DFF; background: #f0f4ff; }
.comment-bottom-act.active { color: #508DFF; }
.comment-bottom-act span { text-align: center; }
.comment-bottom-act span.active { color: #508DFF; font-weight: 600; }

.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #22C3D0; border-radius: 50%; animation: sp .6s linear infinite; }
@keyframes sp { to { transform: rotate(360deg); } }
.empty-wrap { display: flex; justify-content: center; align-items: center; color: #aaa; font-size: 13px; padding: 40px 0; }

.load-more-wrap { display: flex; align-items: center; justify-content: center; padding: 16px 0 20px; color: #508DFF; font-size: 14px; cursor: pointer; user-select: none; }
.load-more-wrap:active { opacity: .7; }
.load-more-spin { width: 20px; height: 20px; border: 2px solid #e0e0e0; border-top-color: #508DFF; border-radius: 50%; animation: load-more-rotate .6s linear infinite; }
@keyframes load-more-rotate { to { transform: rotate(360deg); } }
</style>
