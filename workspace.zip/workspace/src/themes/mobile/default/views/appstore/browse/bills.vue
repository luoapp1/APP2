<template>
  <div class="page">
    <div class="top-bar">
      <div class="back-btn" @click="$router.back()">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
        </svg>
      </div>
      <span class="top-title">{{ pageTitle }}</span>
    </div>

    <div class="search-bar">
      <div class="search-input">
        <svg fill="none" stroke="#9ca3af" stroke-width="2" viewBox="0 0 24 24" width="14" height="14">
          <circle cx="11" cy="11" r="8"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/>
        </svg>
        <input v-model="searchText" placeholder="搜索账单信息或金额" class="search-field" @input="onSearch" />
      </div>
    </div>

    <div class="tabs-row">
      <div v-for="tab in tabs" :key="tab.key" class="tab-item" :class="{ 'tab-active': activeTab === tab.key }" @click="switchTab(tab.key)">{{ tab.label }}</div>
      <div class="tab-filter" @click="showFilter = true">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="14" height="14">
          <path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/>
        </svg>
        筛选
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <div class="list-area" v-if="filteredList.length > 0">
      <div class="detail-list">
      <div v-for="item in filteredList" :key="item.id" class="order-item">
        <div class="order-left">
          <div class="order-desc">{{ item.description || txTypeLabel(item.tx_type) }}</div>
          <div class="order-meta">
            <span class="order-type-tag" :style="{ background: txBadgeBg(item.tx_type), color: txBadgeColor(item.tx_type) }">{{ txTypeLabel(item.tx_type) }}</span>
            <span class="order-time">{{ (item.create_time || '').slice(0, 16) }}</span>
          </div>
        </div>
        <div class="order-right">
          <div class="order-amount" :style="{ color: txAmountColor(item.tx_type) }">{{ txAmountFormat(item) }}</div>
        </div>
      </div>
      </div>
    </div>

    <div v-else-if="!loading" class="empty-state">
      <svg fill="none" stroke="#d1d5db" stroke-width="1.5" viewBox="0 0 24 24" width="64" height="64">
        <path stroke-linecap="round" stroke-linejoin="round" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
      </svg>
      <div class="empty-text">暂无交易记录</div>
    </div>

    <div v-if="loading" class="loading">加载中...</div>

    <teleport to="body">
      <div v-if="showFilter" class="filter-mask" @click="showFilter = false"></div>
      <div v-if="showFilter" class="filter-popup">
        <div class="fp-header">
          <span class="fp-title">快速筛选</span>
          <span class="fp-close" @click="showFilter = false">&times;</span>
        </div>
        <div class="fp-section">
          <div class="fp-label">交易类型</div>
          <div class="fp-grid">
            <div v-for="t in filterTypes" :key="t.key" class="fp-chip" :class="{ 'fp-chip-on': filterType === t.key }" @click="filterType = filterType === t.key ? '' : t.key">{{ t.label }}</div>
          </div>
        </div>
        <div class="fp-section">
          <div class="fp-label">金额范围</div>
          <div class="fp-range">
            <input v-model="filterMin" type="number" placeholder="最低金额" class="fp-range-input" />
            <span>—</span>
            <input v-model="filterMax" type="number" placeholder="最高金额" class="fp-range-input" />
          </div>
        </div>
        <div class="fp-btns">
          <div class="fp-reset" @click="resetFilter">重置</div>
          <div class="fp-confirm" @click="applyFilter">确认</div>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreBills' })

const route = useRoute()

const pageTitle = ref('账单')
const searchText = ref('')
const loading = ref(true)

const tabs = [
  { key: '', label: '全部' },
  { key: 'earn', label: '收入' },
  { key: 'spend', label: '支出' },
  { key: 'refund', label: '退款' },
]
const activeTab = ref('')

const showFilter = ref(false)
const filterType = ref('')
const filterMin = ref('')
const filterMax = ref('')
const filterTypes = [
  { key: 'earn', label: '收入' }, { key: 'spend', label: '支出' },
  { key: 'refund', label: '退款' }, { key: 'admin_adjust', label: '提现' },
]

const resetFilter = () => { filterType.value = ''; filterMin.value = ''; filterMax.value = '' }
const applyFilter = () => { showFilter.value = false }

const switchTab = (key: string) => { activeTab.value = key }

const list = ref<any[]>([])

const filteredList = computed(() => {
  let data = list.value
  if (activeTab.value) data = data.filter(item => item.tx_type === activeTab.value)
  if (searchText.value) {
    const kw = searchText.value.toLowerCase()
    data = data.filter(item =>
      txTypeLabel(item.tx_type).includes(kw) ||
      String(item.amount || '').includes(kw) ||
      (item.description || '').includes(kw)
    )
  }
  if (filterType.value) data = data.filter(item => item.tx_type === filterType.value)
  const minN = Number(filterMin.value) || 0
  const maxN = Number(filterMax.value) || Infinity
  data = data.filter(item => Math.abs(Number(item.amount)) >= minN && Math.abs(Number(item.amount)) <= maxN)
  return data
})

const onSearch = () => {}

const txTypeMap: Record<string, string> = {
  earn: '收入', spend: '支出', refund: '退款',
  freeze: '冻结', unfreeze: '解冻', exchange: '兑换', admin_adjust: '调整'
}

const txTypeLabel = (t: string) => txTypeMap[t] || t

const txBadgeBg = (t: string) => {
  const m: Record<string, string> = {
    earn: '#d1fae5', spend: '#fee2e2', refund: '#dbeafe',
    freeze: '#fef3c7', unfreeze: '#d1fae5', exchange: '#ede9fe', admin_adjust: '#e0e7ff',
  }
  return m[t] || '#f3f4f6'
}

const txBadgeColor = (t: string) => {
  const m: Record<string, string> = {
    earn: '#059669', spend: '#dc2626', refund: '#2563eb',
    freeze: '#d97706', unfreeze: '#059669', exchange: '#7c3aed', admin_adjust: '#4f46e5',
  }
  return m[t] || '#6b7280'
}

const txBadgeText = (t: string) => {
  return t === 'earn' || t === 'refund' || t === 'unfreeze' ? '+' : '-'
}

const txAmountColor = (t: string) => {
  return t === 'earn' || t === 'refund' || t === 'unfreeze' ? '#10b981' : '#ef4444'
}

const txAmountFormat = (item: any) => {
  const sign = item.tx_type === 'earn' || item.tx_type === 'refund' || item.tx_type === 'unfreeze' ? '+' : '-'
  const amt = Number(item.amount || 0)
  const d = (item.dp !== undefined) ? item.dp : 0
  return sign + amt.toFixed(d)
}

function fmtTime(raw: string) {
  if (!raw) return ''
  const s = raw.trim()
  const matched = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(s)
  if (!matched) return s
  const d = new Date(s.replace(' ', 'T') + 'Z')
  if (isNaN(d.getTime())) return s
  return d.toLocaleString('zh-CN', { hour12: false })
}


onMounted(async () => {
  const key = route.query.key as string
  if (!key) { loading.value = false; return }

  try {
    const [txRes, sRes] = await Promise.allSettled([
      request.get({ url: '/api/user/currency-transactions', params: { currency_key: key, pageSize: 100 }, showErrorMessage: false }),
      request.get<any[]>({ url: '/api/currency-settings', showErrorMessage: false }),
    ])
    if (sRes.status === 'fulfilled') {
      const arr = Array.isArray(sRes.value) ? sRes.value : []
      const setting = arr.find((s: any) => s.currency_key === key)
      pageTitle.value = (setting?.display_name || key) + '账单'
    } else {
      pageTitle.value = key + '账单'
    }
    if (txRes.status === 'fulfilled') {
      const data = txRes.value?.data || txRes.value || {}
      list.value = data.list || data.records || []
    }
  } catch {
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.page { min-height: 100vh; background: #fff; }
.top-bar { display: flex; align-items: center; padding: 12px 14px; }
.back-btn { cursor: pointer; color: #000; }
.top-title { flex: 1; text-align: center; font-size: 16px; font-weight: 500; margin-right: 16px; }

.search-bar { padding: 0 14px 12px; }
.search-input { display: flex; align-items: center; gap: 8px; background: #f5f5f7; border-radius: 20px; padding: 8px 16px; }
.search-field { flex: 1; border: none; outline: none; background: transparent; font-size: 13px; color: #333; }
.search-field::placeholder { color: #9ca3af; }

.tabs-row { display: flex; align-items: center; gap: 6px; padding: 6px 14px; overflow-x: auto; }
.tab-item { padding: 6px 14px; border-radius: 16px; font-size: 13px; background: #f5f5f7; color: #6b7280; white-space: nowrap; cursor: pointer; }
.tab-active { background: #fee2e2; color: #e62852; }
.tab-filter { display: flex; align-items: center; gap: 4px; margin-left: auto; font-size: 13px; color: #6b7280; padding: 6px 10px; cursor: pointer; white-space: nowrap; }

.list-area { padding: 0 14px; }

.detail-list {
  background: #fff;
  border-radius: 12px;
  padding: 0 16px;
}

.order-item {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 14px 0;
  border-bottom: 1px solid #f3f4f6;
}
.order-item:last-child { border-bottom: none; }
.order-left { flex: 1; min-width: 0; }
.order-desc { font-size: 14px; font-weight: 500; color: #1f2937; margin-bottom: 6px; }
.order-meta { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.order-type-tag { font-size: 11px; padding: 2px 6px; border-radius: 4px; }
.order-time { font-size: 11px; color: #9ca3af; }
.order-right { text-align: right; flex-shrink: 0; margin-left: 12px; }
.order-amount { font-size: 15px; font-weight: 600; }

.empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding-top: 120px; }
.empty-text { font-size: 16px; color: #9ca3af; margin-top: 16px; }
.loading { text-align: center; padding: 60px 0; color: #9ca3af; font-size: 14px; }

.filter-mask { position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 90; }
.filter-popup { position: fixed; bottom: 0; left: 0; right: 0; background: #fff; border-radius: 16px 16px 0 0; z-index: 100; padding: 20px 14px; max-height: 70vh; overflow-y: auto; }
.fp-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.fp-title { font-size: 16px; font-weight: 600; }
.fp-close { font-size: 22px; color: #9ca3af; cursor: pointer; }
.fp-section { margin-bottom: 16px; }
.fp-label { font-size: 13px; font-weight: 500; margin-bottom: 10px; }
.fp-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.fp-chip { background: #f5f5f7; padding: 8px 0; text-align: center; border-radius: 10px; font-size: 13px; cursor: pointer; }
.fp-chip-on { background: #fee2e2; color: #e62852; }
.fp-range { display: flex; align-items: center; gap: 8px; }
.fp-range-input { flex: 1; background: #f5f5f7; border: none; outline: none; border-radius: 10px; padding: 10px 12px; font-size: 13px; }
.fp-btns { display: flex; }
.fp-reset { flex: 1; text-align: center; padding: 14px 0; font-size: 15px; background: #f5f5f7; border-radius: 12px 0 0 12px; cursor: pointer; }
.fp-confirm { flex: 1; text-align: center; padding: 14px 0; font-size: 15px; background: #e62852; color: #fff; border-radius: 0 12px 12px 0; cursor: pointer; }
</style>
