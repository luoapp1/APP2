<template>
  <div class="assets-page" :style="{ background: `var(--default-bg-color, #fafbfc)` }">
    <!-- 顶部标题栏 -->
    <div class="assets-header">
      <svg class="assets-back" @click="$router.back()" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
      </svg>
      <span class="assets-title">我的资产</span>
      <div style="width:24px" />
    </div>

    <div class="assets-body">
      <!-- 余额卡片 -->
      <div class="asset-card">
        <div class="asset-card-header">
          <div>
            <div class="asset-label">余额</div>
            <div class="asset-amount">￥{{ formatNum(balance) }}</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="asset-btn" @click="showTransferDialog('balance')">充值</button>
            <button class="asset-btn asset-btn-outline" @click="showWithdrawDialog">提现</button>
          </div>
        </div>
        <div class="asset-pending" v-if="pendingOutBalance > 0">待转出 ￥{{ formatNum(pendingOutBalance) }}</div>
        <div class="asset-pending" v-if="pendingInBalance > 0">待转入 ￥{{ formatNum(pendingInBalance) }}</div>
        <div class="asset-pending" v-if="pendingOutBalance === 0 && pendingInBalance === 0">待转入 ￥0</div>
      </div>

      <!-- 积分卡片 -->
      <div class="asset-card">
        <div class="asset-card-header">
          <div>
            <div class="asset-label">积分</div>
            <div class="asset-amount" style="color:#3b82f6">{{ formatInt(points) }}</div>
          </div>
          <button class="asset-btn" @click="showTransferDialog('points')">转账购买积分</button>
        </div>
        <div class="asset-pending" v-if="pendingOutPoints > 0">待转出 {{ formatInt(pendingOutPoints) }}积分</div>
        <div class="asset-pending" v-if="pendingInPoints > 0">待转入 {{ formatInt(pendingInPoints) }}积分</div>
        <div class="asset-pending" v-if="pendingOutPoints === 0 && pendingInPoints === 0">待转入 0积分</div>
      </div>

      <!-- 积分任务卡片 -->
      <div class="asset-card">
        <div class="asset-section-title">积分任务</div>

        <div class="daily-progress">
          <div class="daily-progress-text">
            <span>今日累计 <strong style="color:#3b82f6">+{{ todayEarned }}</strong></span>
            <span class="daily-cap">每日可免费获取{{ dailyCap }}积分，超过后将不再获取</span>
          </div>
          <div class="progress-bar-wrap">
            <div class="progress-bar-fill" :style="{ width: progressPercent + '%' }" />
          </div>
        </div>

        <div class="task-list" v-if="dailyTasks.length">
          <div v-for="task in dailyTasks" :key="task.id" class="task-item">
            <div class="task-icon" :style="{ background: task.completed ? '#dcfce7' : '#f0f0f0' }">
              <svg v-if="task.completed" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="3">
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
              </svg>
              <span v-else style="font-size:14px">{{ task.icon || '📋' }}</span>
            </div>
            <div class="task-info">
              <div class="task-name">{{ task.name }}</div>
              <div class="task-reward">+{{ task.points_reward || 0 }}积分</div>
            </div>
            <div class="task-progress" :class="{ completed: task.completed }">
              {{ task.progress }}/{{ task.target_count }}
            </div>
          </div>
        </div>
        <div v-else class="task-empty">暂无积分任务</div>
      </div>

      <!-- 积分/余额详情 -->
      <div class="asset-card">
        <div class="asset-section-title">资产明细</div>
        <div class="detail-tabs">
          <div class="detail-tab" :class="{ active: activeDetailTab === 'points' }" @click="activeDetailTab = 'points'">积分详细</div>
          <div class="detail-tab" :class="{ active: activeDetailTab === 'balance' }" @click="activeDetailTab = 'balance'">余额详细</div>
          <div class="detail-tab" :class="{ active: activeDetailTab === 'orders' }" @click="activeDetailTab = 'orders'">订单记录</div>
        </div>
        <template v-if="activeDetailTab === 'points'">
          <div v-if="pointsRecords.length" class="detail-list">
            <div v-for="r in pointsRecords" :key="'p-'+r.id" class="detail-item">
              <div class="detail-left">
                <div class="detail-name">{{ sourceLabel(r.source) || r.task_name || '积分变动' }}</div>
                <div class="detail-description" v-if="r.description">{{ r.description }}</div>
                <div class="detail-time">{{ (r.createTime || r.create_time || '').slice(0,16) }}</div>
              </div>
              <div class="detail-right" :style="{ color: r.type === 'expense' ? '#ef4444' : '#16a34a' }">
                {{ r.type === 'expense' ? '-' : '+' }}{{ r.points || r.amount || 0 }}
              </div>
            </div>
          </div>
          <div v-else class="task-empty">暂无积分变动记录</div>
        </template>
        <template v-else-if="activeDetailTab === 'balance'">
          <div v-if="balanceRecords.length" class="detail-list">
            <div v-for="r in balanceRecords" :key="'b-'+r.id" class="detail-item">
              <div class="detail-left">
                <div class="detail-name">{{ sourceLabel(r.source) || '余额变动' }}</div>
                <div class="detail-description" v-if="r.description">{{ r.description }}</div>
                <div class="detail-time">{{ (r.create_time || '').slice(0,16) }}</div>
              </div>
              <div class="detail-right" :style="{ color: r.type === 'expense' ? '#ef4444' : '#16a34a' }">
                {{ r.type === 'expense' ? '-' : '+' }}{{ r.amount || 0 }}
              </div>
            </div>
          </div>
          <div v-else class="task-empty">暂无余额变动记录</div>
        </template>
        <template v-else>
          <div v-if="ordersLoading" class="task-empty">加载中...</div>
          <div v-else-if="orders.length" class="detail-list">
            <div v-for="o in orders" :key="'o-'+o.id" class="order-item">
              <div class="order-left">
                <div class="order-desc">{{ o.order_desc || o.order_type || '订单' }}</div>
                <div class="order-meta">
                  <span class="order-type-tag" :style="{ background: o.pay_type === 'points' ? '#eff6ff' : '#fef3c7', color: o.pay_type === 'points' ? '#3b82f6' : '#b45309' }">{{ o.pay_type === 'points' ? '积分' : '余额' }}</span>
                  <span class="order-status-tag" :style="orderStatusStyle(o.status)">{{ orderStatusText(o.status) }}</span>
                  <span class="order-time">{{ (o.create_time || '').slice(0,16) }}</span>
                </div>
                <div v-if="o.refund_reason" class="order-reason">
                  <span v-if="o.status === 'refunding'" style="color:#b45309">退款原因: {{ o.refund_reason }}</span>
                  <span v-else-if="o.status === 'shipped' && o.refund_reason.includes('[卖家拒绝')" style="color:#ef4444">{{ o.refund_reason }}</span>
                  <span v-else style="color:#64748b">原因: {{ o.refund_reason }}</span>
                </div>
              </div>
              <div class="order-right">
                <div class="order-amount" :style="{ color: o.buyer_id === userId ? '#ef4444' : '#16a34a' }">
                  {{ o.buyer_id === userId ? '-' : '+' }}{{ o.pay_type === 'points' ? o.paid_amount + '积分' : '￥' + o.paid_amount }}
                </div>
                <div class="order-actions">
                  <span v-if="o.admin_review === 'pending'" class="order-admin-tip">等待管理员审核</span>
                  <template v-else>
                  <button v-if="o.status === 'shipped' && o.buyer_id === userId" class="order-btn confirm-btn" @click="confirmOrder(o)">确认收货</button>
                  <button v-if="o.status === 'shipped' && o.buyer_id === userId" class="order-btn refund-btn" @click="showRefundDialog(o)">退款</button>
                  <button v-if="o.status === 'refunding' && o.seller_id === userId" class="order-btn confirm-btn" @click="respondRefund(o, 'agree')">同意退款</button>
                  <button v-if="o.status === 'refunding' && o.seller_id === userId" class="order-btn refund-btn" @click="respondRefund(o, 'reject')">拒绝</button>
                  <button v-if="o.status === 'refunding' && o.buyer_id === userId" class="order-btn refund-btn" @click="reportRefund(o)">上报管理员</button>
                  </template>
                </div>
              </div>
            </div>
          </div>
          <div v-else class="task-empty">暂无订单记录</div>
        </template>
      </div>
    </div>

    <!-- 充值弹窗 -->
    <Teleport to="body">
      <div v-if="dialogVisible" class="dialog-mask" @click.self="dialogVisible = false">
        <div class="dialog-card recharge-dialog">
          <div class="dialog-header">
            <span>余额充值</span>
            <svg @click="dialogVisible = false" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="cursor:pointer">
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          <div class="dialog-body" v-if="dialogType === 'balance'">
            <div class="recharge-section">
              <div class="recharge-section-title">请选择充值金额</div>
              <div class="recharge-amount-grid">
                <div
                  v-for="a in rechargeAmounts"
                  :key="a.amount"
                  class="recharge-amount-item"
                  :class="{ active: selectedAmount === a.amount }"
                  @click="selectRechargeAmount(a)"
                >
                  <div class="recharge-amount-value">￥{{ a.amount }}</div>
                  <div class="recharge-amount-label" v-if="a.label">{{ a.label }}</div>
                  <div class="recharge-amount-discount" v-if="a.discount && selectedAmount === a.amount">{{ a.discount }}</div>
                </div>
              </div>
              <div class="recharge-custom">
                <div class="recharge-custom-label">自定义充值金额</div>
                <input v-model="customAmount" type="number" step="0.01" placeholder="最低 ¥0.1，最高 ¥99999" class="form-input" @focus="selectedAmount = null" />
              </div>
            </div>
            <div class="recharge-notice">
              <div>充值金额仅用于本站消费，无法提现</div>
              <div>充值后无法退款</div>
              <div>如有疑问，请与客服联系</div>
            </div>
            <div class="recharge-section">
              <div class="recharge-section-title">请选择支付方式</div>
              <div class="recharge-pay-methods">
                <label v-if="payMethods.alipay" class="recharge-pay-item" :class="{ active: payMethod === 'alipay' }" @click="payMethod = 'alipay'">
                  <span class="pay-icon" style="background:#1677ff">支</span>
                  <span>支付宝</span>
                </label>
                <label v-if="payMethods.wechat" class="recharge-pay-item" :class="{ active: payMethod === 'wechat' }" @click="payMethod = 'wechat'">
                  <span class="pay-icon" style="background:#07c160">微</span>
                  <span>微信</span>
                </label>
                <label v-if="payMethods.epay" class="recharge-pay-item" :class="{ active: payMethod === 'epay' }" @click="payMethod = 'epay'">
                  <span class="pay-icon" style="background:#ff6b35">付</span>
                  <span>在线支付</span>
                </label>
                <div v-if="!payMethods.alipay && !payMethods.wechat && !payMethods.epay" style="color:#9ca3af;font-size:13px;text-align:center;width:100%;padding:12px 0">暂无可用支付方式</div>
              </div>
            </div>
            <button class="recharge-submit-btn" :disabled="submitting || !canPay" @click="doRecharge">{{ submitting ? '处理中...' : '立即支付' }}</button>
          </div>
          <template v-else>
            <div class="dialog-body">
              <div class="form-group">
                <label>购买金额 (￥)</label>
                <input v-model="purchaseAmount" type="number" step="0.01" placeholder="输入金额" class="form-input" />
                <div class="form-hint">可兑换 {{ Math.floor(Number(purchaseAmount || 0) * purchaseRate) }} 积分 (汇率: 1元={{ purchaseRate }}积分)</div>
              </div>
              <button class="dialog-submit-btn" :disabled="submitting" @click="doPurchasePoints">{{ submitting ? '处理中...' : '确认购买' }}</button>
            </div>
          </template>
        </div>
      </div>
    </Teleport>

    <!-- 提现弹窗 -->
    <Teleport to="body">
      <div v-if="withdrawDialogVisible" class="dialog-mask" @click.self="withdrawDialogVisible = false">
        <div class="dialog-card">
          <div class="dialog-header">
            <span>余额提现</span>
            <svg @click="withdrawDialogVisible = false" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="cursor:pointer">
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          <div class="dialog-body">
            <div class="form-group">
              <label>可提现余额: ￥{{ formatNum(balance) }}</label>
            </div>
            <div class="form-group">
              <label>提现金额 (￥)</label>
              <input v-model="withdrawForm.amount" type="number" step="0.01" placeholder="输入金额" class="form-input" />
            </div>
            <div class="form-group">
              <label>提现方式</label>
              <div style="display:flex;gap:8px">
                <label v-for="m in ['alipay','wechat','bank']" :key="m" style="display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer">
                  <input type="radio" v-model="withdrawForm.method" :value="m" />
                  {{ {alipay:'支付宝',wechat:'微信',bank:'银行卡'}[m] }}
                </label>
              </div>
            </div>
            <div class="form-group">
              <label>收款账号</label>
              <input v-model="withdrawForm.account" placeholder="输入账号" class="form-input" />
            </div>
            <div class="form-group">
              <label>真实姓名</label>
              <input v-model="withdrawForm.realName" placeholder="可选" class="form-input" />
            </div>
            <button class="dialog-submit-btn" :disabled="withdrawSubmitting" @click="doWithdraw">{{ withdrawSubmitting ? '处理中...' : '确认提现' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useLoginModalStore } from '@/store/modules/loginModal'

const ALLOWED_PAY_DOMAINS = [
  window.location.hostname,
  'alipay.com',
  'api.mch.weixin.qq.com',
  'pay.weixin.qq.com',
]

function safeRedirect(url: string) {
  if (!url) {
    ElMessage.error('支付链接异常')
    return
  }
  try {
    const u = new URL(url)
    if (ALLOWED_PAY_DOMAINS.some(d => u.hostname === d || u.hostname.endsWith('.' + d))) {
      window.location.href = u.href
    } else {
      ElMessage.error('支付链接异常，请联系管理员')
    }
  } catch {
    ElMessage.error('支付链接格式错误')
  }
}

defineOptions({ name: 'AppStoreAssets' })

const sourceLabelMap: Record<string, string> = {
  purchase: '积分购买',
  transfer_points: '积分转账',
  transfer: '转账手续费',
  transfer_balance: '余额转账',
  '每日签到': '每日签到',
  '内容购买': '内容购买',
  '应用购买': '应用购买',
  '应用打赏': '应用打赏',
  '打赏收入': '打赏收入',
  '邀请奖励': '邀请奖励',
  '会员购买': '会员购买',
  '帖子打赏': '帖子打赏',
  '附件购买': '附件购买',
  order_settle: '订单结算',
  admin_refund: '管理员退款',
  '每日发帖': '每日发帖',
  '每日评论': '每日评论',
  '点赞奖励': '点赞奖励',
  '浏览帖子': '浏览帖子',
}

function sourceLabel(src: string) {
  return sourceLabelMap[src] || src || ''
}

const router = useRouter()
const userStore = useUserStore()

const balance = ref(0)
const points = ref(0)
const pendingBalance = ref(0)
const dailyTasks = ref<any[]>([])
const todayEarned = ref(0)
const dailyCap = ref(100)
const pointsRecords = ref<any[]>([])
const balanceRecords = ref<any[]>([])
const activeDetailTab = ref('points')
const dialogVisible = ref(false)
const dialogType = ref('balance')
const submitting = ref(false)
const purchaseRate = ref(1)
const orders = ref<any[]>([])
const ordersLoading = ref(false)
const pendingOutBalance = ref(0)
const pendingInBalance = ref(0)
const pendingOutPoints = ref(0)
const pendingInPoints = ref(0)

const transferForm = reactive({ toUserId: '', amount: '', remark: '' })
const purchaseAmount = ref('')
const withdrawDialogVisible = ref(false)
const withdrawSubmitting = ref(false)
const withdrawForm = reactive({ amount: '', method: 'alipay', account: '', realName: '' })
const rechargeAmounts = ref<any[]>([])
const selectedAmount = ref<number | null>(null)
const customAmount = ref('')
const payMethod = ref('epay')
const payMethods = reactive({ alipay: false, wechat: false, epay: false })

const canPay = computed(() => {
  const amount = selectedAmount.value || Number(customAmount.value || 0)
  return amount > 0
})

const progressPercent = computed(() => {
  if (!dailyCap.value) return 0
  return Math.min((todayEarned.value / dailyCap.value) * 100, 100)
})

const formatNum = (val: number) => {
  if (val >= 10000) {
    const w = Math.floor(val / 100) / 100
    return w % 1 === 0 ? `${w}万` : `${w.toFixed(2)}万`
  }
  return Number.isInteger(val) ? val.toString() : val.toFixed(2)
}

const formatInt = (val: number) => {
  if (val >= 10000) {
    const w = Math.floor(val / 100) / 100
    return w % 1 === 0 ? `${w}万` : `${w.toFixed(2)}万`
  }
  return val.toString()
}

const showTransferDialog = (type: string) => {
  if (!userStore.isLogin) {
    useLoginModalStore().open()
    return
  }
  dialogType.value = type
  if (type === 'balance') {
    selectedAmount.value = null
    customAmount.value = ''
    payMethod.value = payMethods.epay ? 'epay' : (payMethods.alipay ? 'alipay' : 'wechat')
  } else {
    transferForm.toUserId = ''
    transferForm.amount = ''
    transferForm.remark = ''
    purchaseAmount.value = ''
  }
  dialogVisible.value = true
}

const selectRechargeAmount = (a: any) => {
  selectedAmount.value = a.amount
  customAmount.value = ''
}

const doRecharge = async () => {
  const amount = selectedAmount.value || Number(customAmount.value || 0)
  if (amount <= 0) {
    ElMessage.warning('请输入有效金额')
    return
  }
  submitting.value = true
  try {
    const res: any = await request.post({ url: '/api/recharge/create', data: { amount, payMethod: payMethod.value } })
    if (res?.payUrl) {
      dialogVisible.value = false
      safeRedirect(res.payUrl)
    } else {
      ElMessage.error('创建支付订单失败')
    }
  } catch (e: any) {
    ElMessage.error(e.message || '充值失败')
  }
  submitting.value = false
}

const doBalanceTransfer = async () => {
  if (!transferForm.toUserId || !transferForm.amount || Number(transferForm.amount) <= 0) {
    ElMessage.warning('请填写完整信息')
    return
  }
  submitting.value = true
  try {
    await request.post({ url: '/api/transfer/balance', data: transferForm })
    ElMessage.success('转账成功')
    dialogVisible.value = false
    fetchAssets()
    fetchBalanceRecords()
    fetchPointsRecords()
    fetchOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '转账失败')
  }
  submitting.value = false
}

const doPurchasePoints = async () => {
  if (!purchaseAmount.value || Number(purchaseAmount.value) <= 0) {
    ElMessage.warning('请输入有效金额')
    return
  }
  submitting.value = true
  try {
    await request.post({ url: '/api/transfer/points/purchase', data: { amount: Number(purchaseAmount.value) } })
    ElMessage.success('购买成功')
    dialogVisible.value = false
    fetchAssets()
    fetchBalanceRecords()
    fetchPointsRecords()
  } catch (e: any) {
    ElMessage.error(e.message || '购买失败')
  }
  submitting.value = false
}

const showWithdrawDialog = () => {
  withdrawForm.amount = ''
  withdrawForm.method = 'alipay'
  withdrawForm.account = ''
  withdrawForm.realName = ''
  withdrawDialogVisible.value = true
}

const doWithdraw = async () => {
  if (!withdrawForm.amount || Number(withdrawForm.amount) <= 0) {
    ElMessage.warning('请输入有效金额')
    return
  }
  if (!withdrawForm.account) {
    ElMessage.warning('请输入收款账号')
    return
  }
  if (Number(withdrawForm.amount) > balance.value) {
    ElMessage.warning('提现金额不能超过余额')
    return
  }
  withdrawSubmitting.value = true
  try {
    await request.post({ url: '/api/commission/withdraw/apply', data: withdrawForm })
    ElMessage.success('提现申请已提交，等待审核')
    withdrawDialogVisible.value = false
    fetchAssets()
    fetchBalanceRecords()
  } catch (e: any) {
    ElMessage.error(e.message || '提现失败')
  }
  withdrawSubmitting.value = false
}

const fetchAssets = async () => {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const profile: any = await request.get({ url: '/api/user/profile', params: { userId: uid } })
    if (profile) {
      balance.value = Number(profile.balance || 0)
      points.value = Number(profile.points || 0)
    }
  } catch {}
}

const fetchTasks = async () => {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const data: any = await request.get({ url: '/api/custom-task/my', params: { userId: uid } })
    const tasks = data?.data || data || []
    const dailies = tasks.filter((t: any) => t.task_type === 'daily' && t.direction === 'earn')
    dailyTasks.value = dailies
    dailyCap.value = dailies.reduce((sum: number, t: any) => sum + (t.points_reward || 0), 0)
    todayEarned.value = dailies.filter((t: any) => t.completed).reduce((sum: number, t: any) => sum + (t.points_reward || 0), 0)
  } catch {}
}

const fetchPointsRecords = async () => {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const today = new Date().toISOString().slice(0, 10)
    const data: any = await request.get({ url: '/api/operation/points-record/list', params: { userId: uid, startDate: today, endDate: today, size: 50 } })
    pointsRecords.value = data?.records || data?.data?.records || data || []
  } catch {}
}

const fetchBalanceRecords = async () => {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const data: any = await request.get({ url: '/api/user/balance-records', params: { userId: uid, page: 1, pageSize: 50 } })
    balanceRecords.value = data?.data?.list || data?.list || []
  } catch {}
}

const fetchConfig = async () => {
  try {
    const data: any = await request.get({ url: '/api/transfer/config' })
    purchaseRate.value = parseInt(data?.points_purchase_rate || data?.data?.points_purchase_rate) || 1
  } catch {}
}

const userId = computed(() => userStore.info?.userId || 0)

const fetchPendingStats = async () => {
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const data: any = await request.get({ url: '/api/settlement/pending-stats', params: { userId: uid } })
    if (data) {
      pendingOutBalance.value = Number(data.pendingOutBalance || 0)
      pendingInBalance.value = Number(data.pendingInBalance || 0)
      pendingOutPoints.value = Number(data.pendingOutPoints || 0)
      pendingInPoints.value = Number(data.pendingInPoints || 0)
    }
  } catch {}
}

const fetchOrders = async () => {
  ordersLoading.value = true
  try {
    const uid = userStore.info.userId
    if (!uid) return
    const data: any = await request.get({ url: '/api/settlement/orders', params: { userId: uid } })
    orders.value = data?.list || data?.data?.list || []
  } catch {}
  ordersLoading.value = false
}

const confirmOrder = async (order: any) => {
  const deadline = order.confirm_deadline ? new Date(order.confirm_deadline.replace(' ', 'T')) : null
  const now = new Date()
  const remainMs = deadline ? deadline.getTime() - now.getTime() : 0
  const remainDays = remainMs > 0 ? Math.ceil(remainMs / 86400000) : 0
  const msg = remainDays > 0 ? `确认收货后资金将转给卖家，距离自动确认还有 ${remainDays} 天，确定现在确认吗？` : '确认收货后资金将转给卖家，确定确认吗？'
  try {
    await ElMessageBox.confirm(msg, '确认收货', { confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning' })
  } catch { return }
  try {
    await request.post({ url: '/api/settlement/confirm', data: { orderId: order.id, userId: userStore.info.userId } })
    ElMessage.success('确认收货成功')
    fetchAssets()
    fetchPendingStats()
    fetchOrders()
    fetchBalanceRecords()
    fetchPointsRecords()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

const showRefundDialog = (order: any) => {
  ElMessageBox.prompt('请输入退款原因', '申请退款', { confirmButtonText: '提交', cancelButtonText: '取消' }).then(({ value }) => {
    requestRefund(order, value)
  }).catch(() => {})
}

const requestRefund = async (order: any, reason: string) => {
  try {
    await request.post({ url: '/api/settlement/request-refund', data: { orderId: order.id, userId: userStore.info.userId, reason } })
    ElMessage.success('退款申请已提交')
    fetchOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

const respondRefund = async (order: any, action: string) => {
  let reason = ''
  if (action === 'reject') {
    try {
      const { value } = await ElMessageBox.prompt('请输入拒绝退款的原因', '拒绝退款', { confirmButtonText: '确认拒绝', cancelButtonText: '取消' })
      reason = value || ''
    } catch { return }
    try {
      await ElMessageBox.confirm(`确定拒绝该退款申请吗？${reason ? '拒绝原因: ' + reason : ''}`, '再次确认', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    } catch { return }
  } else {
    try {
      await ElMessageBox.confirm('确定同意该退款申请吗？资金将退回买家。', '同意退款', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    } catch { return }
  }
  try {
    await request.post({ url: '/api/settlement/respond-refund', data: { orderId: order.id, userId: userStore.info.userId, action, reason } })
    ElMessage.success(action === 'agree' ? '已同意退款' : '已拒绝退款')
    fetchAssets()
    fetchPendingStats()
    fetchOrders()
    fetchBalanceRecords()
    fetchPointsRecords()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

const reportRefund = async (order: any) => {
  let reason = ''
  try {
    const result = await ElMessageBox.prompt('请输入上报管理员的原因', '上报管理员', { confirmButtonText: '确认上报', cancelButtonText: '取消' })
    reason = result.value || ''
    if (!reason) return
    await ElMessageBox.confirm(`确定上报管理员吗？上报原因: ${reason}`, '再次确认', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
  } catch { return }
  try {
    await request.post({ url: '/api/settlement/report-to-admin', data: { orderId: order.id, userId: userStore.info.userId, reason } })
    ElMessage.success('已上报管理员审核')
    fetchOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

const orderStatusStyle = (status: string) => {
  const map: Record<string, string> = {
    shipped: 'background:#eff6ff;color:#3b82f6',
    completed: 'background:#f0fdf4;color:#16a34a',
    refunding: 'background:#fef3c7;color:#b45309',
    refunded: 'background:#faf5ff;color:#9333ea',
    cancelled: 'background:#f1f5f9;color:#64748b'
  }
  return map[status] || ''
}

const orderStatusText = (status: string) => {
  const map: Record<string, string> = {
    shipped: '待确认',
    completed: '已完成',
    refunding: '退款中',
    refunded: '已退款',
    cancelled: '已取消'
  }
  return map[status] || status
}

const fetchRechargeAmounts = async () => {
  try {
    const data: any = await request.get({ url: '/api/recharge/amounts' })
    rechargeAmounts.value = data || []
  } catch {}
}

const fetchPayMethods = async () => {
  try {
    const cfg: any = await request.get({ url: '/api/admin/payment-config' })
    payMethods.alipay = cfg?.payment_alipay_enabled === true || cfg?.payment_alipay_enabled === 'true'
    payMethods.wechat = cfg?.payment_wechat_enabled === true || cfg?.payment_wechat_enabled === 'true'
    payMethods.epay = cfg?.payment_epay_enabled === true || cfg?.payment_epay_enabled === 'true'
  } catch {}
}

onMounted(() => {
  if (!userStore.isLogin) {
    useLoginModalStore().open()
    return
  }
  fetchAssets()
  fetchTasks()
  fetchPointsRecords()
  fetchBalanceRecords()
  fetchConfig()
  fetchPendingStats()
  fetchOrders()
  fetchRechargeAmounts()
  fetchPayMethods()

  if (router.currentRoute.value.query.recharge === 'success') {
    ElMessage.success('充值成功! 余额已到账')
    fetchAssets()
    fetchBalanceRecords()
  }
})
</script>

<style scoped>
.assets-page { min-height: 100vh; padding-bottom: 80px; }
.assets-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 16px; position: sticky; top: 0; z-index: 10;
  background: var(--default-bg-color, #fafbfc);
}
.assets-back { width: 24px; height: 24px; cursor: pointer; color: #374151; }
.assets-title { font-size: 17px; font-weight: 600; color: #1f2937; }
.assets-body { padding: 0 12px; display: flex; flex-direction: column; gap: 12px; }

.asset-card {
  background: #fff; border-radius: 16px; padding: 16px;
}
.asset-card-header { display: flex; align-items: center; justify-content: space-between; }
.asset-label { font-size: 13px; color: #9ca3af; margin-bottom: 4px; }
.asset-amount { font-size: 28px; font-weight: 700; color: #1f2937; }
.asset-pending { margin-top: 10px; font-size: 13px; color: #9ca3af; }
.asset-btn {
  background: #3b82f6; color: #fff; border: none; border-radius: 8px;
  padding: 8px 16px; font-size: 13px; font-weight: 500; cursor: pointer;
}
.asset-btn-outline {
  background: #fff; color: #3b82f6; border: 1px solid #3b82f6;
}
.asset-section-title {
  font-size: 15px; font-weight: 600; color: #1f2937; margin-bottom: 12px;
  display: flex; align-items: center; gap: 6px;
}

.daily-progress { margin-bottom: 12px; }
.daily-progress-text { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
.daily-progress-text strong { font-size: 16px; }
.daily-cap { font-size: 11px; color: #9ca3af; }
.progress-bar-wrap {
  height: 6px; background: #e5e7eb; border-radius: 999px; overflow: hidden;
}
.progress-bar-fill {
  height: 100%; background: linear-gradient(90deg, #3b82f6, #60a5fa); border-radius: 999px; transition: width .3s;
}

.task-list { display: flex; flex-direction: column; gap: 10px; }
.task-item { display: flex; align-items: center; gap: 10px; }
.task-icon {
  width: 36px; height: 36px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
}
.task-info { flex: 1; min-width: 0; }
.task-name { font-size: 13px; font-weight: 500; color: #374151; }
.task-reward { font-size: 11px; color: #f59e0b; margin-top: 2px; }
.task-progress { font-size: 12px; color: #9ca3af; font-weight: 500; white-space: nowrap; }
.task-progress.completed { color: #16a34a; }
.task-empty { font-size: 13px; color: #9ca3af; text-align: center; padding: 20px 0; }

.detail-tabs {
  display: flex; background: #f3f4f6; border-radius: 8px; padding: 2px; margin-bottom: 12px;
}
.detail-tab {
  flex: 1; text-align: center; padding: 8px 0; font-size: 13px; font-weight: 500; color: #9ca3af;
  border-radius: 6px; cursor: pointer; transition: all .2s;
}
.detail-tab.active { background: #fff; color: #3b82f6; box-shadow: 0 1px 2px rgba(0,0,0,.06); }

.detail-description { font-size: 11px; color: #9ca3af; margin-top: 2px; }

.detail-list { display: flex; flex-direction: column; gap: 10px; }
.detail-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #f3f4f6; }
.detail-item:last-child { border-bottom: none; }
.detail-name { font-size: 13px; color: #374151; }
.detail-time { font-size: 11px; color: #9ca3af; margin-top: 2px; }
.detail-right { font-size: 14px; font-weight: 600; }

.dialog-mask {
  position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 1000;
  display: flex; align-items: flex-end; justify-content: center;
}
.dialog-card {
  width: 100%; max-width: 420px; background: #fff; border-radius: 20px 20px 0 0;
  padding: 20px 16px 32px;
}
.dialog-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; font-size: 16px; font-weight: 600; color: #1f2937; }
.dialog-body { display: flex; flex-direction: column; gap: 14px; }
.form-group { display: flex; flex-direction: column; gap: 4px; }
.form-group label { font-size: 13px; font-weight: 500; color: #374151; }
.form-input {
  border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 12px; font-size: 14px;
  outline: none; background: #f9fafb;
}
.form-input:focus { border-color: #3b82f6; }
.form-hint { font-size: 11px; color: #9ca3af; margin-top: 4px; }
.dialog-submit-btn {
  background: #3b82f6; color: #fff; border: none; border-radius: 10px;
  padding: 12px; font-size: 15px; font-weight: 500; cursor: pointer; margin-top: 4px;
}
.dialog-submit-btn:disabled { opacity: .6; cursor: not-allowed; }

.order-item { display: flex; justify-content: space-between; align-items: flex-start; padding: 14px 0; border-bottom: 1px solid #f3f4f6; }
.order-item:last-child { border-bottom: none; }
.order-left { flex: 1; min-width: 0; }
.order-desc { font-size: 14px; font-weight: 500; color: #1f2937; margin-bottom: 6px; }
.order-meta { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.order-reason { margin-top: 6px; font-size: 12px; line-height: 1.5; }
.order-type-tag, .order-status-tag { font-size: 11px; padding: 2px 6px; border-radius: 4px; }
.order-time { font-size: 11px; color: #9ca3af; }
.order-right { text-align: right; flex-shrink: 0; margin-left: 12px; }
.order-amount { font-size: 15px; font-weight: 600; margin-bottom: 4px; }
.order-actions { display: flex; gap: 4px; justify-content: flex-end; margin-top: 4px; }
.order-admin-tip { font-size: 12px; color: #9333ea; background: #faf5ff; padding: 4px 10px; border-radius: 4px; }
.order-btn { font-size: 11px; padding: 3px 8px; border-radius: 4px; border: none; cursor: pointer; }
.confirm-btn { background: #dbeafe; color: #1d4ed8; }
.refund-btn { background: #fee2e2; color: #b91c1c; }

/* 充值弹窗样式 */
.recharge-section { margin-bottom: 16px; }
.recharge-section-title { font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 10px; }
.recharge-amount-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.recharge-amount-item {
  border: 1.5px solid #e5e7eb; border-radius: 10px; padding: 10px 6px;
  text-align: center; cursor: pointer; transition: .2s; position: relative;
}
.recharge-amount-item.active { border-color: #3b82f6; background: #eff6ff; }
.recharge-amount-value { font-size: 16px; font-weight: 700; color: #1f2937; }
.recharge-amount-label { font-size: 11px; color: #f59e0b; margin-top: 2px; }
.recharge-amount-discount { font-size: 11px; color: #16a34a; margin-top: 2px; }
.recharge-custom { margin-top: 12px; }
.recharge-custom-label { font-size: 13px; color: #6b7280; margin-bottom: 6px; }
.recharge-notice {
  background: #f9fafb; border-radius: 8px; padding: 10px 12px;
  font-size: 12px; color: #9ca3af; line-height: 1.7; margin-bottom: 16px;
}
.recharge-pay-methods { display: flex; gap: 10px; }
.recharge-pay-item {
  flex: 1; display: flex; align-items: center; gap: 6px;
  padding: 10px 12px; border: 1.5px solid #e5e7eb; border-radius: 10px;
  cursor: pointer; font-size: 13px; color: #374151; transition: .2s;
}
.recharge-pay-item.active { border-color: #3b82f6; background: #eff6ff; }
.pay-icon {
  width: 24px; height: 24px; border-radius: 50%; color: #fff;
  font-size: 12px; display: flex; align-items: center; justify-content: center;
}
.recharge-submit-btn {
  width: 100%; background: #3b82f6; color: #fff; border: none;
  border-radius: 10px; padding: 14px; font-size: 16px; font-weight: 600;
  cursor: pointer; margin-top: 12px;
}
.recharge-submit-btn:disabled { opacity: .6; cursor: not-allowed; }
</style>
