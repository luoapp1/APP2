<template>
  <div class="assets-page">
    <div class="assets-header">
      <svg class="assets-back" @click="$router.back()" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="assets-title">总资产</span>
    </div>

    <div class="assets-card">
      <div class="card-header">
        <div class="card-header-row">
          <span class="card-header-text">我的资产(元)</span>
          <svg class="eye-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" @click="toggleVisible">
            <path v-if="showBalance" stroke-linecap="round" stroke-linejoin="round" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <path v-if="showBalance" d="M12 9a3 3 0 100 6 3 3 0 000-6z"/>
            <path v-if="!showBalance" d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/>
            <line v-if="!showBalance" x1="1" y1="1" x2="23" y2="23"/>
          </svg>
        </div>
        <div class="card-balance">{{ showBalance ? totalStr : '****' }}</div>
      </div>

      <div class="card-list">
        <!-- 余额 -->
        <div class="card-item" @click="goBalance">
          <div class="item-icon" style="background:#e8f0fe">
            <svg class="item-svg" fill="none" stroke="#3b82f6" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="8" stroke-width="1.5"/>
              <text x="12" y="16" text-anchor="middle" fill="#3b82f6" font-size="12" font-weight="700">¥</text>
            </svg>
          </div>
          <div class="item-body">
            <div class="item-head">
              <span class="item-title">我的余额</span>
              <span class="item-badge">保障中</span>
            </div>
            <div class="item-desc">随取随用，即时到账</div>
          </div>
          <div class="item-tail">
            <span class="item-amount">{{ showBalance ? formatAmount(balance, 'balance') : '****' }}</span>
            <svg class="item-arrow" fill="none" stroke="#9ca3af" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>

        <!-- 其他账户 -->
        <div class="card-item" @click="goAccounts">
          <div class="item-icon" style="background:#fef3c7">
            <svg class="item-svg" fill="none" stroke="#f59e0b" viewBox="0 0 24 24">
              <rect x="4" y="5" width="16" height="14" rx="2" stroke-width="1.5"/>
              <circle cx="12" cy="12" r="3" stroke-width="1.5"/>
              <path d="M12 2v3m0 14v3M2 12h3m14 0h3" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="item-body">
            <div class="item-title">其他账户</div>
            <div class="item-desc">各币种资产，随时可兑换</div>
          </div>
          <div class="item-tail">
            <span class="item-sub-text" v-if="visibleSettings.length > 0 && showBalance">{{ visibleSettings.length }}个币种 · {{ formatAmount(balance, 'balance') }}</span>
            <span class="item-sub-text" v-else>****</span>
            <svg class="item-arrow" fill="none" stroke="#9ca3af" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>

        <!-- 优惠券 -->
        <div class="card-item" @click="$router.push('/appstore/coupon-detail')">
          <div class="item-icon" style="background:#d1fae5">
            <svg class="item-svg" fill="none" stroke="#10b981" viewBox="0 0 24 24">
              <path d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" stroke-width="1.5"/>
            </svg>
          </div>
          <div class="item-body">
            <div class="item-title">优惠券</div>
            <div class="item-desc">活动发放权益，随时可使用</div>
          </div>
          <div class="item-tail">
            <span class="item-sub-text" v-if="couponCount > 0">{{ couponCount }}张</span>
            <svg class="item-arrow" fill="none" stroke="#9ca3af" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>

        <!-- 交易记录 -->
        <div class="card-item" @click="$router.push('/appstore/records')">
          <div class="item-icon" style="background:#ede9fe">
            <svg class="item-svg" fill="none" stroke="#8b5cf6" viewBox="0 0 24 24">
              <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9h6m-6-4h6" stroke-width="1.5"/>
            </svg>
          </div>
          <div class="item-body">
            <div class="item-title">交易记录</div>
            <div class="item-desc">查看全部收支明细账单</div>
          </div>
          <div class="item-tail">
            <span class="item-link">立即查看</span>
            <svg class="item-arrow" fill="none" stroke="#9ca3af" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'
import { useRouter } from 'vue-router'
import { useCurrency } from '@/composables/useCurrency'

defineOptions({ name: 'AppStoreAssets' })

const userStore = useUserStore()
const router = useRouter()
const { balance, formatAmount, visibleSettings, load: loadCurrency } = useCurrency()

const couponCount = ref(0)
const showBalance = ref(true)

const toggleVisible = () => { showBalance.value = !showBalance.value }

const totalStr = computed(() => {
  return formatAmount(balance.value, 'balance')
})

const goBalance = () => {
  if (!userStore.isLogin) { useLoginModalStore().open(); return }
  router.push('/appstore/balance')
}

const goAccounts = () => {
  if (!userStore.isLogin) { useLoginModalStore().open(); return }
  router.push('/appstore/accounts')
}

const fetchData = async () => {
  if (!userStore.isLogin) return
  await loadCurrency()
  try {
    const coupRes = await request.get({ url: '/api/coupon/my', params: { status: 'unused', size: 1 } }).catch(() => null)
    if (coupRes) {
      const list = coupRes?.data?.list || coupRes?.list || []
      couponCount.value = Array.isArray(list) ? list.length : 0
    }
  } catch {}
}

onMounted(fetchData)
</script>

<style scoped>
.assets-page { min-height: 100vh; background: linear-gradient(180deg, #d6e4ff 0%, #fce4f0 100%); }
.assets-header {
  display: flex; align-items: center; justify-content: center; position: relative;
  padding: 10px 16px 12px;
}
.assets-back { position: absolute; left: 16px; width: 20px; height: 20px; cursor: pointer; color: #374151; }
.assets-title { font-size: 18px; font-weight: 500; color: #1f2937; }

.assets-card { background: #fff; border-radius: 12px; margin: 0 20px 28px; overflow: hidden; }

.card-header { padding: 42px 0 48px; text-align: center; border-bottom: 1px solid #f3f4f6; }
.card-header-row { display: flex; align-items: center; justify-content: center; gap: 4px; margin-bottom: 12px; }
.card-header-text { font-size: 13px; color: #6b7280; }
.eye-icon { width: 14px; height: 14px; color: #9ca3af; cursor: pointer; }
.card-balance { font-size: 36px; font-weight: 700; color: #1f2937; line-height: 1; }

.card-list { padding: 2px 16px 8px; }
.card-item {
  display: flex; align-items: center; padding: 10px 0; cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.card-item + .card-item { border-top: 1px solid #f5f5f5; }

.item-icon {
  width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center;
  justify-content: center; margin-right: 10px; flex-shrink: 0;
}
.item-svg { width: 15px; height: 15px; }

.item-body { flex: 1; min-width: 0; }
.item-head { display: flex; align-items: center; }
.item-title { font-size: 14px; color: #1f2937; }
.item-badge {
  margin-left: 4px; font-size: 10px; color: #3b82f6;
  border: 1px solid #93c5fd; border-radius: 4px; padding: 0 4px;
}
.item-desc { font-size: 11px; color: #6b7280; margin-top: 1px; }

.item-tail { display: flex; align-items: center; flex-shrink: 0; margin-left: 8px; }
.item-amount { font-size: 16px; color: #1f2937; }
.item-sub-text { font-size: 11px; color: #9ca3af; }
.item-link { font-size: 14px; color: #374151; }
.item-arrow { width: 12px; height: 12px; margin-left: 4px; }
</style>
