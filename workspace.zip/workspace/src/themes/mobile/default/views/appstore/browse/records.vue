<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">{{ pageTitle }}</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">
      <div v-if="loading" style="text-align:center;padding:40px;color:#9ca3af">加载中...</div>

      <!-- 余额 -->
      <template v-else-if="type === 'balance'">
        <div v-if="list.length === 0" style="text-align:center;padding:60px 20px;color:#9ca3af">
          <div style="font-size:48px;margin-bottom:8px">💰</div>
          <div>暂无余额流水</div>
        </div>
        <div
          v-for="item in list" :key="item.id"
          style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center"
        >
          <div style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0"
            :style="{ background: item.type === 'earn' ? '#ecfdf5' : '#fef2f2' }"
          >
            <span style="font-size:18px">{{ item.type === 'earn' ? '+' : '-' }}</span>
          </div>
          <div style="flex:1;margin-left:10px">
            <div style="font-size:14px;color:#1f2937">{{ item.source || item.description || '余额变动' }}</div>
            <div style="font-size:11px;color:#9ca3af;margin-top:2px">{{ fmtTime(item.create_time || item.createTime || '') }}</div>
          </div>
          <div style="font-size:15px;font-weight:600" :style="{ color: item.type === 'earn' ? '#10b981' : '#ef4444' }">
            {{ item.type === 'earn' ? '+' : '-' }}{{ typeof item.amount === 'number' ? item.amount.toFixed(2) : item.amount }}
          </div>
        </div>
      </template>

      <!-- 积分 -->
      <template v-else-if="type === 'points'">
        <div v-if="list.length === 0" style="text-align:center;padding:60px 20px;color:#9ca3af">
          <div style="font-size:48px;margin-bottom:8px">⭐</div>
          <div>暂无积分流水</div>
        </div>
        <div
          v-for="item in list" :key="item.id"
          style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center"
        >
          <div style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0"
            :style="{ background: (item.type === 'earn' || item.type === 'adjust') ? '#ecfdf5' : '#fef2f2' }"
          >
            <span style="font-size:18px">{{ (item.type === 'earn' || item.type === 'adjust') ? '+' : '-' }}</span>
          </div>
          <div style="flex:1;margin-left:10px">
            <div style="font-size:14px;color:#1f2937">{{ sourceLabel(item.source) || item.description || '积分变动' }}</div>
            <div style="font-size:11px;color:#9ca3af;margin-top:2px">{{ fmtTime(item.create_time || item.createTime || '') }}</div>
          </div>
          <div style="font-size:15px;font-weight:600" :style="{ color: item.type === 'earn' || item.type === 'adjust' ? '#10b981' : '#ef4444' }">
            {{ (item.type === 'earn' || item.type === 'adjust') ? '+' : '-' }}{{ item.points || item.amount || 0 }}
          </div>
        </div>
      </template>

      <!-- 粉丝 -->
      <template v-else-if="type === 'fans'">
        <div v-if="list.length === 0" style="text-align:center;padding:60px 20px;color:#9ca3af">
          <div style="font-size:48px;margin-bottom:8px">👥</div>
          <div>暂无粉丝</div>
        </div>
        <div
          v-for="item in list" :key="item.id"
          style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center;cursor:pointer"
          @click="$router.push('/appstore/profile/' + item.id)"
        >
          <div style="width:42px;height:42px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;overflow:hidden">
            <img v-if="item.avatar && !item.avatar.startsWith('avatar:')" :src="$fixImgUrl(item.avatar)" style="width:100%;height:100%;object-fit:cover"  loading="lazy" />
            <img v-else src="@imgs/user/avatar.webp" style="width:100%;height:100%;object-fit:cover"  loading="lazy" />
          </div>
          <div style="flex:1;margin-left:10px">
            <div style="display:flex;align-items:center;gap:4px">
              <span style="font-size:14px;font-weight:600;color:#1f2937">{{ item.nickname || item.username }}</span>
              <span v-if="item.is_verified" style="background:#3b82f6;color:#fff;font-size:9px;padding:1px 4px;border-radius:4px">V</span>
            </div>
            <div style="font-size:11px;color:#9ca3af;margin-top:2px">{{ item.signature || '这个人很懒，什么都没写' }}</div>
          </div>
          <button
            style="font-size:11px;padding:4px 10px;border-radius:4px;border:1px solid #e5e7eb;background:#fff;color:#6b7280;cursor:pointer;white-space:nowrap;flex-shrink:0"
            @click.stop="handleRemoveFan(item)"
          >取消关注</button>
        </div>
      </template>

      <!-- 付费 -->
      <template v-else-if="type === 'purchases'">
        <div v-if="list.length === 0" style="text-align:center;padding:60px 20px;color:#9ca3af">
          <div style="font-size:48px;margin-bottom:8px">💳</div>
          <div>暂无付费记录</div>
        </div>
        <div v-else class="detail-list">
          <div v-for="item in list" :key="item._source + '-' + item.id" class="order-item" :class="{ clickable: item._source === 'mall' }" @click="item._source === 'mall' ? showOrderDetail(item) : null">
            <div class="order-left">
              <div class="order-desc">{{ item._source === 'mall' ? (item.items?.[0]?.productName || '商城订单') : (item.order_desc || item.order_type || '订单') }}</div>
              <div class="order-meta">
                <template v-if="item._source === 'settlement'">
                  <span class="order-type-tag" :style="{ background: item.pay_type === 'points' ? '#eff6ff' : '#fef3c7', color: item.pay_type === 'points' ? '#3b82f6' : '#b45309' }">{{ item.pay_type === 'points' ? '积分' : '余额' }}</span>
                  <span class="order-status-tag" :style="orderStatusStyle(item.status)">{{ orderStatusLabel(item.status) }}</span>
                </template>
                <template v-else>
                  <span class="order-status-tag" :style="mallOrderStatusStyle(item.status)">{{ mallOrderStatusLabel(item.status) }}</span>
                </template>
                <span class="order-time">{{ (item.create_time || '').slice(0, 16) }}</span>
              </div>
              <!-- 操作按钮 -->
              <div v-if="item._source === 'settlement'" class="order-actions">
                <template v-if="item.status === 'shipped'">
                  <button class="order-btn confirm-btn" @click.stop="confirmOrder(item)">确认收货</button>
                  <button class="order-btn refund-btn" @click.stop="showRefundDialog(item)">退款</button>
                </template>
                <template v-else-if="item.status === 'refunding'">
                  <div v-if="item.seller_id === userId" class="order-refund-actions">
                    <button class="order-btn" style="background:#ecfdf5;color:#059669" @click.stop="respondRefund(item, 'agree')">同意退款</button>
                    <button class="order-btn" style="background:#fef2f2;color:#dc2626" @click.stop="respondRefund(item, 'reject')">拒绝退款</button>
          <div v-if="orderDetail.receiverName || orderDetail.receiverAddress" class="order-detail-divider" />
          <div v-if="orderDetail.receiverName || orderDetail.receiverAddress" class="order-detail-section-title">收货信息</div>
          <div v-if="orderDetail.receiverName || orderDetail.receiverAddress" class="order-detail-row">
            <span class="order-detail-label">收货人</span>
            <span class="order-detail-val">{{ orderDetail.receiverName }} {{ orderDetail.receiverPhone || '' }}</span>
          </div>
          <div v-if="orderDetail.receiverAddress" class="order-detail-row">
            <span class="order-detail-label">收货地址</span>
            <span class="order-detail-val">{{ orderDetail.receiverAddress }}</span>
          </div>

          <div v-if="orderDetail.logisticsCompany || orderDetail.logisticsNo" class="order-detail-divider" />
          <div v-if="orderDetail.logisticsCompany || orderDetail.logisticsNo" class="order-detail-section-title">物流信息</div>
          <div v-if="orderDetail.logisticsCompany" class="order-detail-row">
            <span class="order-detail-label">快递公司</span>
            <span class="order-detail-val">{{ orderDetail.logisticsCompany }}</span>
          </div>
          <div v-if="orderDetail.logisticsNo" class="order-detail-row">
            <span class="order-detail-label">快递单号</span>
            <span class="order-detail-val" style="font-family:monospace">{{ orderDetail.logisticsNo }}</span>
          </div>
          <div v-if="orderDetail.logisticsCompany || orderDetail.logisticsNo" style="text-align:center;margin-top:12px">
            <button class="tracking-btn" @click="showLogisticsTracking(orderDetail)">查看物流轨迹</button>
          </div>

          <!-- 物流轨迹弹窗 -->
          <div class="order-detail-overlay" v-if="showTrackingDialog" @click.self="showTrackingDialog = false">
            <div class="order-detail-sheet" style="max-height:70vh;overflow-y:auto">
              <div class="order-detail-header">
                <span class="order-detail-title">物流轨迹</span>
                <svg class="order-detail-close" @click="showTrackingDialog = false" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </div>
              <div v-if="trackingLoading" style="text-align:center;padding:20px;color:#9ca3af">加载中...</div>
              <div v-else-if="trackingData" style="padding:16px">
                <div style="margin-bottom:16px;font-size:14px;color:#666">
                  {{ trackingData.company }} {{ trackingData.trackingNo }}
                </div>
                <div v-if="trackingData.traces && trackingData.traces.length > 0">
                  <div v-for="(t, idx) in trackingData.traces" :key="t" class="tracking-trace-item" :class="{ active: idx === 0 }">
                    <div class="tracking-trace-dot" :class="{ active: idx === 0 }" />
                    <div v-if="idx < trackingData.traces.length - 1" class="tracking-trace-line" :class="{ active: idx === 0 }" />
                    <div class="tracking-trace-content">
                      <div class="tracking-trace-desc">{{ t.desc }}</div>
                      <div class="tracking-trace-time">{{ (t.time || '').slice(0, 16).replace('T', ' ') }}</div>
                    </div>
                  </div>
                </div>
                <div v-else style="text-align:center;padding:40px;color:#9ca3af">暂无物流轨迹数据</div>
              </div>
              <div v-else style="text-align:center;padding:40px;color:#9ca3af">暂无物流信息</div>
            </div>
          </div>
        </div>
                  <button class="order-btn" style="background:#fef3c7;color:#b45309" @click.stop="reportRefund(item)">上报管理员</button>
                </template>
              </div>
            </div>
            <div class="order-right">
              <div class="order-amount" :style="{ color: '#ef4444' }">
                <template v-if="item._source === 'settlement'">
                  {{ item.pay_type === 'points' ? '-' + (item.paid_amount || 0) + '积分' : '-¥' + (Number(item.paid_amount) || 0).toFixed(2) }}
                </template>
                <template v-else>
                  -¥{{ (Number(item.total_amount) || 0).toFixed(2) }}
                </template>
              </div>
              <div class="order-no" style="font-size:10px;color:#bbb">{{ item.order_no }}</div>
            </div>
          </div>
        </div>
      </template>

      <!-- overview: 带 tab 切换的数据明细 -->
      <template v-else-if="type === 'overview'">
        <div style="display:flex;background:#fff;border-radius:12px;overflow:hidden;margin-bottom:12px">
          <div
            v-for="tab in tabs" :key="tab.key"
            @click="switchTab(tab.key)"
            style="flex:1;text-align:center;padding:12px 0;font-size:14px;cursor:pointer;position:relative;transition:all .2s"
            :style="{
              color: activeTab === tab.key ? tab.color : '#9ca3af',
              fontWeight: activeTab === tab.key ? '600' : '400',
              borderBottom: activeTab === tab.key ? '2px solid ' + tab.color : '2px solid transparent'
            }"
          >
            <span style="margin-right:4px">{{ tab.icon }}</span>{{ tab.label }}
          </div>
        </div>

        <div v-if="tabLoading" style="text-align:center;padding:40px;color:#9ca3af">加载中...</div>

        <template v-else>
          <div v-if="tabData.length === 0" style="text-align:center;padding:60px 20px;color:#9ca3af">
            <div style="font-size:40px;margin-bottom:8px">{{ activeTabConfig.emptyIcon }}</div>
            <div style="font-size:14px">{{ activeTabConfig.emptyText }}</div>
          </div>

          <div
            v-for="item in tabData" :key="item.id"
            style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center;transition:transform .15s"
          >
            <div
              style="width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:16px"
              :style="{ background: activeTabConfig.badgeBg(item) }"
            >
              <span :style="{ color: activeTabConfig.badgeColor(item) }">{{ activeTabConfig.badgeText(item) }}</span>
            </div>
            <div style="flex:1;margin-left:12px">
              <div style="font-size:14px;color:#1f2937;font-weight:500">{{ activeTabConfig.getTitle(item) }}</div>
              <div style="font-size:11px;color:#9ca3af;margin-top:3px">{{ activeTabConfig.getTime(item) }}</div>
            </div>
            <div style="font-size:16px;font-weight:700" :style="{ color: activeTabConfig.amountColor(item) }">
              {{ activeTabConfig.getAmount(item) }}
            </div>
          </div>
        </template>
      </template>

    </div>

    <!-- 商城订单详情弹窗 -->
    <div class="order-detail-overlay" v-if="showOrderDetailDialog" @click.self="showOrderDetailDialog = false">
      <div class="order-detail-sheet">
        <div class="order-detail-header">
          <span class="order-detail-title">订单详情</span>
          <svg class="order-detail-close" @click="showOrderDetailDialog = false" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </div>
        <div v-if="orderDetailLoading" style="text-align:center;padding:20px;color:#9ca3af">加载中...</div>
        <div v-else-if="orderDetail" class="order-detail-body">
          <div class="order-detail-row">
            <span class="order-detail-label">订单编号</span>
            <span class="order-detail-val">{{ orderDetail.order_no }}</span>
          </div>
          <div class="order-detail-row">
            <span class="order-detail-label">订单状态</span>
            <span class="order-detail-val" :style="{ color: mallOrderStatusColor(orderDetail.status) }">{{ mallOrderStatusLabel(orderDetail.status) }}</span>
          </div>
          <div class="order-detail-row">
            <span class="order-detail-label">支付金额</span>
            <span class="order-detail-val" style="color:#FF4757;font-weight:700">¥{{ Number(orderDetail.total_amount || 0).toFixed(2) }}</span>
          </div>
          <div class="order-detail-row">
            <span class="order-detail-label">支付方式</span>
            <span class="order-detail-val">{{ orderDetail.payment_method === 'points' ? '积分支付' : '余额支付' }}</span>
          </div>
          <div class="order-detail-row">
            <span class="order-detail-label">下单时间</span>
            <span class="order-detail-val">{{ (orderDetail.create_time || '').slice(0, 16) }}</span>
          </div>
          <div class="order-detail-divider" />

          <div class="order-detail-section-title">商品信息</div>
          <div v-for="it in (orderDetail.items || [])" :key="it.id" class="order-detail-goods">
            <img v-if="it.image" :src="$fixImgUrl(it.image)" class="order-goods-img"  loading="lazy" />
            <div v-else class="order-goods-img order-goods-fb">{{ (it.productName || '?')[0] }}</div>
            <div class="order-goods-info">
              <div class="order-goods-name">{{ it.productName }}</div>
              <div v-if="it.optionName" class="order-goods-opt">{{ it.optionName }}</div>
              <div class="order-goods-price">¥{{ Number(it.price || 0).toFixed(2) }} x {{ it.quantity }}</div>
            </div>
          </div>

          <div v-if="orderDetail.userCustomFields && Object.keys(orderDetail.userCustomFields).length > 0" class="order-detail-divider" />
          <div v-if="orderDetail.userCustomFields && Object.keys(orderDetail.userCustomFields).length > 0" class="order-detail-section-title">填写信息</div>
          <div v-if="orderDetail.userCustomFields && Object.keys(orderDetail.userCustomFields).length > 0" class="order-detail-custom-fields">
            <div v-for="(val, key) in orderDetail.userCustomFields" :key="key" class="order-custom-field-row">
              <span class="order-custom-field-key">{{ key }}</span>
              <span class="order-custom-field-val">{{ val }}</span>
            </div>
          </div>

          <div v-if="orderDetail.virtualContent || (orderDetail.items || []).some((i: any) => i.virtualContent)" class="order-detail-divider" />
          <div v-if="orderDetail.virtualContent || (orderDetail.items || []).some((i: any) => i.virtualContent)" class="order-detail-section-title">发货内容（卡密/虚拟商品）</div>
          <div v-for="it in (orderDetail.items || [])" :key="'vc-'+it.id">
            <div v-if="it.virtualContent" class="order-detail-virtual">
              <div class="order-virtual-label">{{ it.productName }}：</div>
              <div class="order-virtual-content" style="white-space:pre-wrap;word-break:break-all;background:#f5f5f5;padding:12px;border-radius:8px;font-size:13px;color:#333;line-height:1.6">{{ it.virtualContent }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'
import { fetchBalanceRecords, fetchPointsRecords, fetchFollowers, fetchContentPurchases, fetchOrders, fetchExperienceRecords, fetchMembershipRecords, removeFollower, fetchMallOrders, fetchMallOrderDetail, fetchMallOrderTracking } from '@/api/mine'

function fmtTime(raw: string) {
  if (!raw) return ''
  const s = raw.trim()
  const matched = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(s)
  if (!matched) return s
  const d = new Date(s.replace(' ', 'T') + 'Z')
  if (isNaN(d.getTime())) return s
  return d.toLocaleString('zh-CN', { hour12: false })
}

const sourceLabelMap: Record<string, string> = {
  purchase: '积分购买',
  transfer_points: '积分转账',
  transfer: '转账手续费',
  transfer_balance: '余额转账',
  '每日签到': '每日签到',
  '内容购买': '内容购买',
  '应用购买': '应用购买',
  '应用打赏': '应用打赏',
  '打赏收入': '打赏收入',
  '邀请奖励': '邀请奖励',
  '会员购买': '会员购买',
  '帖子打赏': '帖子打赏',
  '附件购买': '附件购买',
  order_settle: '订单结算',
  admin_refund: '管理员退款',
  '每日发帖': '每日发帖',
  '每日评论': '每日评论',
  '点赞奖励': '点赞奖励',
  '浏览帖子': '浏览帖子',
}

function sourceLabel(src: string) {
  return sourceLabelMap[src] || src || ''
}

const orderStatusMap: Record<string, { label: string; bg: string; color: string }> = {
  shipped: { label: '已发货', bg: '#dbeafe', color: '#2563eb' },
  completed: { label: '已完成', bg: '#d1fae5', color: '#059669' },
  refunded: { label: '已退款', bg: '#fee2e2', color: '#dc2626' },
  cancelled: { label: '已取消', bg: '#f3f4f6', color: '#6b7280' },
  refunding: { label: '退款中', bg: '#fef3c7', color: '#f59e0b' },
  review_pending: { label: '待确认', bg: '#ede9fe', color: '#7c3aed' },
  refund_rejected: { label: '退款拒绝', bg: '#fee2e2', color: '#dc2626' },
}

const refundStatuses = ['refunded', 'refunding', 'review_pending']

function orderStatusStyle(status: string) {
  const map: Record<string, string> = {
    shipped: 'background:#eff6ff;color:#3b82f6',
    completed: 'background:#f0fdf4;color:#16a34a',
    refunding: 'background:#fef3c7;color:#b45309',
    refunded: 'background:#faf5ff;color:#9333ea',
    cancelled: 'background:#f1f5f9;color:#64748b'
  }
  return map[status] || ''
}

function orderStatusLabel(status: string) {
  const map: Record<string, string> = {
    shipped: '待确认',
    completed: '已完成',
    refunding: '退款中',
    refunded: '已退款',
    cancelled: '已取消'
  }
  return map[status] || status
}

function orderAmountColor(item: any) {
  return refundStatuses.includes(item.status) ? '#10b981' : '#ef4444'
}

function orderAmountText(item: any) {
  const amt = typeof item.paid_amount === 'number' ? item.paid_amount.toFixed(2) : (item.paid_amount || '0')
  if (item.pay_type === 'points') {
    return refundStatuses.includes(item.status) ? '+' + amt + '积分' : '-' + amt + '积分'
  }
  return refundStatuses.includes(item.status) ? '+￥' + amt : '-￥' + amt
}

function getOrderDesc(item: any) {
  return item.order_desc || item.order_type || '订单'
}

function getOrderCounterparty(item: any) {
  if (orderStatusLabel(item.status) === '已退款' || orderStatusLabel(item.status) === '退款中') return ''
  if (item.buyer_id === userId.value) {
    return '发送给 ' + (item.seller_name || item.seller_name_full || '用户')
  }
  if (item.seller_id === userId.value) {
    return '来自 ' + (item.buyer_name || item.buyer_name_full || '用户')
  }
  return ''
}

async function confirmOrder(order: any) {
  const deadline = order.confirm_deadline ? new Date(order.confirm_deadline.replace(' ', 'T')) : null
  const now = new Date()
  const remainMs = deadline ? deadline.getTime() - now.getTime() : 0
  const remainDays = remainMs > 0 ? Math.ceil(remainMs / 86400000) : 0
  const msg = remainDays > 0
    ? `确认收货后资金将转给卖家，距离自动确认还有 ${remainDays} 天，确定现在确认吗？`
    : '确认收货后资金将转给卖家，确定确认吗？'
  try {
    await ElMessageBox.confirm(msg, '确认收货', { confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning' })
  } catch { return }
  try {
    await request.post({ url: '/api/settlement/confirm', data: { orderId: order.id, userId: userId.value } })
    ElMessage.success('确认收货成功')
    reloadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

function showRefundDialog(order: any) {
  ElMessageBox.prompt('请输入退款原因', '申请退款', { confirmButtonText: '提交', cancelButtonText: '取消' })
    .then(({ value }) => requestRefund(order, value))
    .catch(() => {})
}

async function requestRefund(order: any, reason: string) {
  try {
    await request.post({ url: '/api/settlement/request-refund', data: { orderId: order.id, userId: userId.value, reason } })
    ElMessage.success('退款申请已提交')
    reloadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

async function respondRefund(order: any, action: string) {
  let reason = ''
  if (action === 'reject') {
    try {
      const { value } = await ElMessageBox.prompt('请输入拒绝退款的原因', '拒绝退款', { confirmButtonText: '确认拒绝', cancelButtonText: '取消' })
      reason = value || ''
    } catch { return }
    try {
      await ElMessageBox.confirm(`确定拒绝该退款申请吗？${reason ? '拒绝原因: ' + reason : ''}`, '再次确认', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    } catch { return }
  } else {
    try {
      await ElMessageBox.confirm('确定同意该退款申请吗？资金将退回买家。', '同意退款', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    } catch { return }
  }
  try {
    await request.post({ url: '/api/settlement/respond-refund', data: { orderId: order.id, userId: userId.value, action, reason } })
    ElMessage.success(action === 'agree' ? '已同意退款' : '已拒绝退款')
    reloadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

async function reportRefund(order: any) {
  let reason = ''
  try {
    const result = await ElMessageBox.prompt('请输入上报管理员的原因', '上报管理员', { confirmButtonText: '确认上报', cancelButtonText: '取消' })
    reason = result.value || ''
    if (!reason) return
    await ElMessageBox.confirm(`确定上报管理员吗？上报原因: ${reason}`, '再次确认', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
  } catch { return }
  try {
    await request.post({ url: '/api/settlement/report-to-admin', data: { orderId: order.id, userId: userId.value, reason } })
    ElMessage.success('已上报管理员审核')
    reloadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

const orderDetail = ref<any>(null)
const showOrderDetailDialog = ref(false)
const orderDetailLoading = ref(false)

function mallOrderStatusStyle(status: string) {
  const map: Record<string, string> = {
    pending: 'background:#fef3c7;color:#b45309',
    paid: 'background:#dbeafe;color:#2563eb',
    shipped: 'background:#d1fae5;color:#059669',
    completed: 'background:#d1fae5;color:#059669',
    cancelled: 'background:#f3f4f6;color:#6b7280',
    refunded: 'background:#fee2e2;color:#dc2626'
  }
  return map[status] || 'background:#f3f4f6;color:#6b7280'
}

function mallOrderStatusLabel(status: string) {
  const map: Record<string, string> = {
    pending: '待支付', paid: '已支付', shipped: '已发货',
    completed: '已完成', cancelled: '已取消', refunded: '已退款'
  }
  return map[status] || status
}

function mallOrderStatusColor(status: string) {
  const map: Record<string, string> = {
    pending: '#b45309', paid: '#2563eb', shipped: '#059669',
    completed: '#059669', cancelled: '#6b7280', refunded: '#dc2626'
  }
  return map[status] || '#6b7280'
}

async function showOrderDetail(item: any) {
  showOrderDetailDialog.value = true
  orderDetailLoading.value = true
  orderDetail.value = null
  try {
    const res: any = await fetchMallOrderDetail(item.id)
    orderDetail.value = res
  } catch {} finally {
    orderDetailLoading.value = false
  }
}

const showTrackingDialog = ref(false)
const trackingLoading = ref(false)
const trackingData = ref<any>(null)

async function showLogisticsTracking(order: any) {
  showTrackingDialog.value = true
  trackingLoading.value = true
  trackingData.value = null
  try {
    const res: any = await fetchMallOrderTracking(order.id || orderDetail.value?.id)
    trackingData.value = res?.logistics || res
  } catch (e: any) {
    ElMessage.error(e.message || '获取物流信息失败')
  } finally {
    trackingLoading.value = false
  }
}

async function reloadOrders() {
  try {
    const [oldRes, mallRes] = await Promise.all([
      fetchOrders().catch(() => ({ list: [] })),
      fetchMallOrders().catch(() => ({ list: [] }))
    ]) as any[]
    const oldOrders = ((oldRes?.list || oldRes?.data?.list || []) as any[]).map((o: any) => ({
      ...o, _source: 'settlement', create_time: o.create_time || o.createTime,
      total_amount: o.paid_amount || 0, order_no: o.order_no || o.orderNo || ''
    }))
    const mallOrders = ((mallRes?.list || mallRes?.data?.list || []) as any[]).map((o: any) => ({
      ...o, _source: 'mall', create_time: o.create_time || o.createTime,
      total_amount: o.total_amount || o.paid_amount || 0, order_no: o.order_no || o.orderNo || ''
    }))
    list.value = [...oldOrders, ...mallOrders].sort((a, b) =>
      (b.create_time || '').localeCompare(a.create_time || '')
    )
  } catch {}
}

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const type = computed(() => (route.query.type as string) || 'balance')
const userId = computed(() => userStore.info.userId || 0)

const pageTitle = computed(() => {
  const map: Record<string, string> = { balance: '余额明细', points: '积分明细', fans: '粉丝', purchases: '付费记录', overview: '数据明细' }
  return map[type.value] || '明细'
})

const list = ref<any[]>([])
const loading = ref(true)

const activeTab = ref<'points' | 'exp' | 'balance' | 'membership'>('points')
const tabLoading = ref(false)
const balanceList = ref<any[]>([])
const pointsList = ref<any[]>([])
const expList = ref<any[]>([])
const memList = ref<any[]>([])

const tabs = [
  { key: 'points' as const, label: '积分', icon: '⭐', color: '#f59e0b' },
  { key: 'exp' as const, label: '经验', icon: '⚡', color: '#3b82f6' },
  { key: 'balance' as const, label: '余额', icon: '💰', color: '#10b981' },
  { key: 'membership' as const, label: '会员', icon: '👑', color: '#8b5cf6' },
]

const activeTabConfig = computed(() => {
  const configs = {
    points: {
      emptyIcon: '⭐',
      emptyText: '暂无积分流水',
      getTitle: (item: any) => sourceLabel(item.source) || item.description || '积分变动',
      getTime: (item: any) => fmtTime(item.create_time || item.createTime || ''),
      getAmount: (item: any) => {
        const sign = (item.type === 'earn' || item.type === 'adjust') ? '+' : '-'
        return sign + (item.points || item.amount || 0)
      },
      amountColor: (item: any) => (item.type === 'earn' || item.type === 'adjust') ? '#f59e0b' : '#ef4444',
      badgeBg: (item: any) => (item.type === 'earn' || item.type === 'adjust') ? '#fef3c7' : '#fee2e2',
      badgeColor: (item: any) => (item.type === 'earn' || item.type === 'adjust') ? '#f59e0b' : '#ef4444',
      badgeText: (item: any) => (item.type === 'earn' || item.type === 'adjust') ? '+' : '-',
    },
    exp: {
      emptyIcon: '⚡',
      emptyText: '暂无经验记录',
      getTitle: (item: any) => item.source || '经验变动',
      getTime: (item: any) => fmtTime(item.create_time || item.createTime || ''),
      getAmount: (item: any) => '+' + (item.amount || 0),
      amountColor: () => '#3b82f6',
      badgeBg: () => '#dbeafe',
      badgeColor: () => '#3b82f6',
      badgeText: () => '+',
    },
    balance: {
      emptyIcon: '💰',
      emptyText: '暂无余额流水',
      getTitle: (item: any) => item.source || item.description || '余额变动',
      getTime: (item: any) => fmtTime(item.create_time || item.createTime || ''),
      getAmount: (item: any) => {
        const sign = item.type === 'earn' ? '+' : '-'
        return sign + (typeof item.amount === 'number' ? item.amount.toFixed(2) : item.amount)
      },
      amountColor: (item: any) => item.type === 'earn' ? '#10b981' : '#ef4444',
      badgeBg: (item: any) => item.type === 'earn' ? '#d1fae5' : '#fee2e2',
      badgeColor: (item: any) => item.type === 'earn' ? '#10b981' : '#ef4444',
      badgeText: (item: any) => item.type === 'earn' ? '+' : '-',
    },
    membership: {
      emptyIcon: '👑',
      emptyText: '暂无会员记录',
      getTitle: (item: any) => {
        if (item.purchase_type === 'cardkey') return '卡密兑换 - ' + (item.level_name || '会员')
        const typeMap: Record<string, string> = { buy: '购买', renew: '续费', upgrade: '升级' }
        return (typeMap[item.purchase_type] || '会员') + ' - ' + (item.product_name || item.level_name || '会员')
      },
      getTime: (item: any) => fmtTime(item.create_time || item.createTime || ''),
      getAmount: (item: any) => {
        if (item.purchase_type === 'cardkey') return '+' + (item.duration_days || 0) + '天'
        const p = '-' + (typeof item.amount === 'number' ? item.amount.toFixed(2) : item.amount)
        if (item.duration_days) return p + ' (+' + item.duration_days + '天)'
        return p
      },
      amountColor: (item: any) => item.purchase_type === 'cardkey' ? '#10b981' : '#ef4444',
      badgeBg: (item: any) => item.purchase_type === 'cardkey' ? '#d1fae5' : '#ede9fe',
      badgeColor: (item: any) => item.purchase_type === 'cardkey' ? '#10b981' : '#8b5cf6',
      badgeText: (item: any) => {
        if (item.purchase_type === 'cardkey') return '卡'
        const iconMap: Record<string, string> = { buy: '购', renew: '续', upgrade: '升' }
        return iconMap[item.purchase_type] || '会'
      },
    },
  }
  return configs[activeTab.value]
})

const tabData = computed(() => {
  if (activeTab.value === 'points') return pointsList.value
  if (activeTab.value === 'exp') return expList.value
  if (activeTab.value === 'membership') return memList.value
  return balanceList.value
})

async function loadPoints() {
  const data: any = await fetchPointsRecords({ userId: userId.value, page: 1, pageSize: 100 })
  pointsList.value = data?.records || data?.list || []
}

async function loadExp() {
  const data: any = await fetchExperienceRecords({ userId: userId.value, page: 1, pageSize: 100 })
  expList.value = data?.list || []
}

async function loadBalance() {
  const data: any = await fetchBalanceRecords({ userId: userId.value, page: 1, pageSize: 100 })
  balanceList.value = data?.list || []
}

async function loadMembership() {
  const data: any = await fetchMembershipRecords({ userId: userId.value, page: 1, pageSize: 100 })
  memList.value = data?.list || []
}

async function switchTab(tab: 'points' | 'exp' | 'balance' | 'membership') {
  if (activeTab.value === tab) return
  activeTab.value = tab
  tabLoading.value = true
  try {
    if (tab === 'points' && pointsList.value.length === 0) await loadPoints()
    if (tab === 'exp' && expList.value.length === 0) await loadExp()
    if (tab === 'balance' && balanceList.value.length === 0) await loadBalance()
    if (tab === 'membership' && memList.value.length === 0) await loadMembership()
  } catch {} finally {
    tabLoading.value = false
  }
}

onMounted(async () => {
  if (!userId.value) return
  try {
    switch (type.value) {
      case 'balance': {
        const data: any = await fetchBalanceRecords({ userId: userId.value, page: 1, pageSize: 100 })
        list.value = data?.list || []
        break
      }
      case 'points': {
        const data: any = await fetchPointsRecords({ userId: userId.value, page: 1, pageSize: 100 })
        list.value = data?.records || data?.list || []
        break
      }
      case 'fans': {
        const data: any = await fetchFollowers(userId.value)
        list.value = data?.list || []
        break
      }
      case 'purchases': {
        // 合并旧结算订单 + 商场订单
        const [oldRes, mallRes] = await Promise.all([
          fetchOrders().catch(() => ({ list: [] })),
          fetchMallOrders().catch(() => ({ list: [] }))
        ]) as any[]
        const oldOrders = ((oldRes?.list || oldRes?.data?.list || []) as any[]).map((o: any) => ({
          ...o, _source: 'settlement', create_time: o.create_time || o.createTime,
          total_amount: o.paid_amount || 0, order_no: o.order_no || o.orderNo || ''
        }))
        const mallOrders = ((mallRes?.list || mallRes?.data?.list || []) as any[]).map((o: any) => ({
          ...o, _source: 'mall', create_time: o.create_time || o.createTime || o.payment_time,
          total_amount: o.total_amount || o.totalAmount || 0, order_no: o.order_no || o.orderNo || ''
        }))
        list.value = [...oldOrders, ...mallOrders].sort((a, b) => {
          const ta = a.create_time || ''
          const tb = b.create_time || ''
          return tb.localeCompare(ta)
        })
        break
      }
      case 'overview': {
        await loadPoints()
        break
      }
    }
  } catch {} finally {
    loading.value = false
  }
})
</script>

<style scoped>
.detail-list {
  background: #fff;
  border-radius: 12px;
  padding: 0 16px;
}
.order-item {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 14px 0;
  border-bottom: 1px solid #f3f4f6;
}
.order-item:last-child {
  border-bottom: none;
}
.order-left {
  flex: 1;
  min-width: 0;
}
.order-desc {
  font-size: 14px;
  font-weight: 500;
  color: #1f2937;
  margin-bottom: 6px;
}
.order-counterparty {
  font-size: 12px;
  color: #8b5cf6;
  margin-bottom: 6px;
}
.order-meta {
  display: flex;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}
.order-reason {
  margin-top: 6px;
  font-size: 12px;
  line-height: 1.5;
}
.order-type-tag,
.order-status-tag {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
}
.order-time {
  font-size: 11px;
  color: #9ca3af;
}
.order-right {
  text-align: right;
  flex-shrink: 0;
  margin-left: 12px;
}
.order-amount {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 4px;
}
.order-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}
.order-refund-actions {
  display: flex;
  gap: 6px;
  margin-bottom: 6px;
}
.order-admin-tip {
  font-size: 11px;
  color: #f59e0b;
}
.order-btn {
  border: none;
  border-radius: 4px;
  padding: 4px 10px;
  font-size: 11px;
  cursor: pointer;
  white-space: nowrap;
}
.order-btn.confirm-btn {
  background: #ecfdf5;
  color: #059669;
}
.order-btn.refund-btn {
  background: #fef2f2;
  color: #dc2626;
}

/* 订单详情弹窗 */
.order-detail-overlay {
  position: fixed; inset: 0; z-index: 1000;
  background: rgba(0,0,0,.5);
  display: flex; align-items: flex-end;
}
.order-detail-sheet {
  width: 100%; max-height: 75vh; overflow-y: auto;
  background: #fff; border-radius: 20px 20px 0 0;
  padding: 20px 16px 32px; animation: slideUp .3s ease;
}
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.order-detail-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 16px;
}
.order-detail-title { font-size: 18px; font-weight: 700; color: #111; }
.order-detail-close { width: 24px; height: 24px; color: #999; cursor: pointer; }
.order-detail-body { }
.order-detail-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 0;
}
.order-detail-label { font-size: 14px; color: #999; flex-shrink: 0; }
.order-detail-val { font-size: 14px; color: #333; font-weight: 500; text-align: right; max-width: 60%; overflow: hidden; text-overflow: ellipsis; }
.order-detail-divider { height: 1px; background: #f0f0f0; margin: 12px 0; }
.order-detail-section-title { font-size: 15px; font-weight: 700; color: #111; margin-bottom: 10px; }
.order-detail-goods {
  display: flex; gap: 10px; align-items: center;
  padding: 8px 0; border-bottom: 1px solid #f5f5f5;
}
.order-goods-img { width: 48px; height: 48px; border-radius: 8px; object-fit: cover; flex-shrink: 0; }
.order-goods-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #FF6B6B, #FF4757);
  color: #fff; font-size: 18px; font-weight: 700;
}
.order-goods-info { flex: 1; min-width: 0; }
.order-goods-name { font-size: 14px; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.order-goods-opt { font-size: 12px; color: #999; margin-top: 2px; }
.order-goods-price { font-size: 13px; color: #FF4757; font-weight: 600; margin-top: 2px; }
.order-detail-virtual { margin-bottom: 8px; }
.order-virtual-label { font-size: 13px; color: #666; }
.order-no { font-size: 10px; color: #bbb; margin-top: 2px; }
.order-item.clickable { cursor: pointer; }
.order-item.clickable:active { background: #f9fafb; }
.order-detail-custom-fields {
  background: #fafafa; border-radius: 10px; padding: 10px 14px;
}
.order-custom-field-row {
  display: flex; justify-content: space-between; align-items: flex-start;
  padding: 6px 0; gap: 12px;
}
.order-custom-field-row + .order-custom-field-row { border-top: 1px solid #f0f0f0; }
.order-custom-field-key { font-size: 13px; color: #888; flex-shrink: 0; }
.order-custom-field-val { font-size: 13px; color: #333; font-weight: 500; text-align: right; word-break: break-all; }

.tracking-btn {
  padding: 10px 32px;
  background: linear-gradient(135deg, #FF5722, #FF8A50);
  color: #fff;
  border: none;
  border-radius: 24px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}
.tracking-btn:active { transform: scale(0.96); opacity: 0.9; }

.tracking-trace-item {
  position: relative;
  padding-left: 28px;
  padding-bottom: 20px;
}
.tracking-trace-item:last-child { padding-bottom: 0; }
.tracking-trace-dot {
  position: absolute;
  left: 0;
  top: 4px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #d1d5db;
  border: 2px solid #fff;
  box-shadow: 0 0 0 1px #d1d5db;
}
.tracking-trace-dot.active {
  background: #FF5722;
  box-shadow: 0 0 0 1px #FF5722, 0 0 0 4px rgba(255,87,34,0.15);
}
.tracking-trace-line {
  position: absolute;
  left: 5px;
  top: 18px;
  width: 2px;
  height: calc(100% + 4px);
  background: #e5e7eb;
}
.tracking-trace-line.active { background: linear-gradient(to bottom, #FF5722, #e5e7eb); }
.tracking-trace-content {
  padding-bottom: 4px;
}
.tracking-trace-desc {
  font-size: 14px;
  color: #6b7280;
  line-height: 1.5;
}
.tracking-trace-item.active .tracking-trace-desc {
  color: #1f2937;
  font-weight: 500;
}
.tracking-trace-time {
  font-size: 12px;
  color: #9ca3af;
  margin-top: 4px;
}
</style>
