<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">结算规则</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0" @click="openDialog(item)">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.levelName || item.level_name || getLevelName(item.level_id || item.levelId) || '-' }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.enabled === '1' || item.enabled === true ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.enabled === '1' || item.enabled === true ? '启用' : '禁用' }}</span>
                </div>
                <div class="text-xs text-gray-400">确认天数: {{ item.confirmDays || item.confirm_days || '-' }}天</div>
                <div class="text-xs text-gray-400 mt-0.5">
                  <template v-if="item.transfer_config && Object.keys(item.transfer_config).length">
                    <span v-for="(cfg, key) in item.transfer_config" :key="key" class="mr-2">转出{{ currencyLabel(key) }}: {{ cfg.singleMin || '-' }}~{{ cfg.singleMax || '-' }}</span>
                  </template>
                  <span v-else>
                    <span v-if="item.balanceTransferEnabled || item.balance_transfer_enabled">转出余额: {{ item.singleMinBalance || '-' }}~{{ item.singleMaxBalance || '-' }}</span>
                    <span v-if="item.pointsTransferEnabled || item.points_transfer_enabled" class="ml-2">转出积分: {{ item.singleMinPoints || '-' }}~{{ item.singleMaxPoints || '-' }}</span>
                  </span>
                </div>
                <div class="text-xs text-gray-400 mt-0.5">
                  <template v-if="item.transfer_config && Object.keys(item.transfer_config).length">
                    手续费: <span v-for="(cfg, key) in item.transfer_config" :key="key" class="mr-2">{{ currencyLabel(key) }}{{ cfg.fee || 0 }}%</span>
                  </template>
                  <span v-else>手续费: 余额{{ item.balanceTransferFee || item.balance_transfer_fee || 0 }}% / 积分{{ item.pointsTransferFee || item.points_transfer_fee || 0 }}%</span>
                </div>
              </div>
              <div class="flex gap-1 flex-shrink-0 ml-2">
                <button v-auth="'edit'" class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click.stop="openDialog(item)">编辑</button>
                <button v-auth="'delete'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ list.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无结算规则</span></div>
      </div>

      <button v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>
    </div>

    <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="confirmVisible = false">
      <div class="absolute inset-0 bg-black/50"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[80vw] overflow-hidden">
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-500">确定要删除「{{ confirmTarget?.levelName || '' }}」的结算规则吗？此操作不可撤销。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doConfirmDelete">删除</button>
        </div>
      </div>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="dialogVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="dialogVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[90vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑规则' : '新增规则' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">用户等级</label>
            <select v-model.number="form.levelId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" @change="onLevelChange">
              <option :value="0">所有用户</option>
              <option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
            </select>
          </div>
          <div>
            <label class="text-xs text-gray-500 mb-1 block">等级名</label>
            <input v-model="form.levelName" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">确认天数</label><input v-model.number="form.confirmDays" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>

          <!-- 动态转账规则 -->
          <div v-for="c in availableCurrencies" :key="c.currency_key" class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <span class="text-xs text-gray-500 font-medium">{{ c.display_name }}规则</span>
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">{{ c.display_name }}转出</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.transfer_config[c.currency_key]?.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleTransferCurrency(c.currency_key)">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.transfer_config[c.currency_key]?.enabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <div v-if="form.transfer_config[c.currency_key]?.enabled" class="space-y-2">
              <div class="grid grid-cols-3 gap-3">
                <div><label class="text-[10px] text-gray-400 mb-1 block">最低</label><input v-model.number="form.transfer_config[c.currency_key].singleMin" type="number" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">最高</label><input v-model.number="form.transfer_config[c.currency_key].singleMax" type="number" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">手续费%</label><input v-model.number="form.transfer_config[c.currency_key].fee" type="number" step="0.1" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              </div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">每日转出上限 (0=不限)</label><input v-model.number="form.transfer_config[c.currency_key].dailyLimit" type="number" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div class="pt-2 border-t border-gray-200">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[10px] text-gray-400">转出次数限制</span>
                  <button type="button" class="text-[10px] text-blue-500 active:text-blue-700" @click="addTimeLimit(c.currency_key)">+ 添加</button>
                </div>
                <div v-for="(tl, idx) in form.transfer_config[c.currency_key].timeLimits" :key="idx" class="flex items-center gap-2 mb-2">
                  <span class="text-[10px] text-gray-400 whitespace-nowrap">{{ tl.days || 0 }}天内</span>
                  <span class="text-[10px] text-gray-400">最多</span>
                  <input v-model.number="tl.maxTimes" type="number" min="0" class="flex-1 h-9 px-2 text-sm bg-white rounded-lg border-none outline-none" placeholder="次数" />
                  <span class="text-[10px] text-gray-400">次</span>
                  <input v-model.number="tl.days" type="number" min="1" class="w-16 h-9 px-2 text-sm bg-white rounded-lg border-none outline-none" placeholder="天" />
                  <button type="button" class="w-6 h-6 rounded-full bg-red-50 text-red-400 text-xs flex items-center justify-center flex-shrink-0" @click="removeTimeLimit(c.currency_key, idx)">x</button>
                </div>
                <div v-if="!form.transfer_config[c.currency_key].timeLimits?.length" class="text-[10px] text-gray-300">0=不限</div>
              </div>
            </div>
          </div>

          <!-- 动态兑换汇率 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <span class="text-xs text-gray-500 font-medium">兑换汇率</span>
            <div v-for="src in availableCurrencies" :key="'ex-'+src.currency_key" class="bg-white rounded-lg p-3 space-y-2">
              <div class="flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full flex-shrink-0" :style="{ background: src.card_color || '#666' }"></span>
                <span class="text-xs font-semibold text-gray-700">{{ src.display_name }} 兑换</span>
              </div>
              <div v-for="tar in getExchangeTargets(src)" :key="'r-'+src.currency_key+'-'+tar.currency_key" class="flex items-center gap-1.5 pl-3">
                <span class="text-xs text-gray-500 whitespace-nowrap">1 {{ src.display_symbol || src.currency_key }}</span>
                <span class="text-[10px] text-gray-300">=</span>
                <input
                  v-model.number="form.exchange_config[`${src.currency_key}_to_${tar.currency_key}`]"
                  type="number"
                  step="0.01"
                  min="0"
                  class="w-20 h-7 px-2 text-xs bg-[#f5f6f8] rounded-md border-none outline-none text-center"
                  :placeholder="'?'"
                />
                <span class="text-xs text-gray-500 whitespace-nowrap">{{ tar.display_name || tar.currency_key }}</span>
              </div>
            </div>
          </div>

          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button v-auth="'toggle'" class="w-10 h-6 rounded-full transition-colors relative" :class="form.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.enabled = !form.enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.enabled ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'SettlementMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false); const list = ref<any[]>([])
const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/settlement/config' })
    list.value = res?.list || res?.records || res?.data?.records || res?.data?.list || []
  } catch { }
  loading.value = false
}

const dialogVisible = ref(false); const editId = ref<number | null>(null)
const confirmVisible = ref(false); const confirmTarget = ref<any>(null)

const formDefault = () => ({
  levelId: 0, levelName: '', confirmDays: 7, enabled: true,
  transfer_config: {} as Record<string, any>,
  exchange_config: {} as Record<string, number>,
  // 旧字段向后兼容
  balanceTransferEnabled: true, pointsTransferEnabled: true,
  singleMinBalance: 0, singleMaxBalance: 0, singleMinPoints: 0, singleMaxPoints: 0,
  dailyLimitBalanceAmount: 0, dailyLimitPointsAmount: 0,
  balanceTransferFee: 0, pointsTransferFee: 0,
  balanceToPointsRate: 1, pointsToBalanceRate: 1
})
const form = reactive(formDefault())

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) {
    form.levelId = item.levelId || item.level_id || 0
    form.levelName = item.levelName || item.level_name || ''
    form.confirmDays = item.confirmDays || item.confirm_days || 7
    form.enabled = item.enabled === '1' || item.enabled === true

    // 旧字段
    form.balanceTransferEnabled = item.balanceTransferEnabled === '1' || item.balance_transfer_enabled === true || item.balanceTransferEnabled === true
    form.pointsTransferEnabled = item.pointsTransferEnabled === '1' || item.points_transfer_enabled === true || item.pointsTransferEnabled === true
    form.singleMinBalance = item.singleMinBalance || item.single_min_balance || 0
    form.singleMaxBalance = item.singleMaxBalance || item.single_max_balance || 0
    form.singleMinPoints = item.singleMinPoints || item.single_min_points || 0
    form.singleMaxPoints = item.singleMaxPoints || item.single_max_points || 0
    form.balanceTransferFee = item.balanceTransferFee || item.balance_transfer_fee || 0
    form.pointsTransferFee = item.pointsTransferFee || item.points_transfer_fee || 0
    form.dailyLimitBalanceAmount = item.dailyLimitBalanceAmount || item.daily_limit_balance_amount || 0
    form.dailyLimitPointsAmount = item.dailyLimitPointsAmount || item.daily_limit_points_amount || 0
    form.balanceToPointsRate = item.balanceToPointsRate || item.balance_to_points_rate || 1
    form.pointsToBalanceRate = item.pointsToBalanceRate || item.points_to_balance_rate || 1

    // 动态字段
    form.transfer_config = item.transfer_config ? { ...item.transfer_config } : {}
    form.exchange_config = item.exchange_config ? { ...item.exchange_config } : {}
  } else {
    Object.assign(form, formDefault())
    initTransferConfig()
  }
  dialogVisible.value = true
}

const toggleTransferCurrency = (currencyKey: string) => {
  if (!form.transfer_config[currencyKey]) {
    form.transfer_config[currencyKey] = { enabled: true, singleMin: 0, singleMax: 0, fee: 0, dailyLimit: 0, timeLimits: [] }
  } else {
    form.transfer_config[currencyKey].enabled = !form.transfer_config[currencyKey].enabled
  }
}

const saveItem = async () => {
  try {
    const data: any = { ...form }
    // 清理 transfer_config 中未启用的
    const cleanTc: Record<string, any> = {}
    for (const [k, v] of Object.entries(data.transfer_config || {})) {
      if (v?.enabled) {
        // 清理 timeLimits 中无效项
        const validTL = (v.timeLimits || []).filter((tl: any) => tl.days > 0 && tl.maxTimes > 0)
        cleanTc[k] = { ...v, timeLimits: validTL }
      }
    }
    data.transfer_config = cleanTc
    // 清理 exchange_config 中为 0 的
    const cleanEc: Record<string, number> = {}
    for (const [k, v] of Object.entries(data.exchange_config || {})) {
      if (Number(v) > 0) cleanEc[k] = Number(v)
    }
    data.exchange_config = cleanEc

    if (editId.value) {
      await request.put({ url: `/api/settlement/config/${editId.value}`, data })
    } else {
      await request.post({ url: '/api/settlement/config', data })
    }
    showToast('保存成功'); dialogVisible.value = false; fetchData()
  } catch (e: any) { showToast(e?.msg || '保存失败', 'error') }
}

const deleteItem = (item: any) => {
  confirmTarget.value = { id: item.id, levelName: item.levelName || item.level_name || '#' + item.id }
  confirmVisible.value = true
}

const doConfirmDelete = async () => {
  if (!confirmTarget.value) return
  confirmVisible.value = false
  try {
    await request.del({ url: `/api/settlement/config/${confirmTarget.value.id}` })
    showToast('删除成功'); fetchData()
  } catch (e: any) { showToast(e?.message || '删除失败', 'error') }
}

// 动态币种
const availableCurrencies = ref<any[]>([])
const currencyLabels = ref<Record<string, string>>({})
const currencyLabel = (key: string) => currencyLabels.value[key] || key
const loadCurrencies = async () => {
  try {
    const res: any = await request.get({ url: '/api/currency-settings' })
    const list = res?.data || res || []
    availableCurrencies.value = list.filter((c: any) => c.currency_type !== 'quota')
    const map: Record<string, string> = {}
    for (const c of list) map[c.currency_key] = c.display_name
    currencyLabels.value = map
  } catch {}
}

const getExchangeTargets = (fromCurrency: any) => {
  return availableCurrencies.value.filter((c: any) => c.currency_key !== fromCurrency.currency_key)
}

const addTimeLimit = (currencyKey: string) => {
  if (!form.transfer_config[currencyKey].timeLimits) {
    form.transfer_config[currencyKey].timeLimits = []
  }
  form.transfer_config[currencyKey].timeLimits.push({ days: 1, maxTimes: 0 })
}

const removeTimeLimit = (currencyKey: string, idx: number) => {
  form.transfer_config[currencyKey].timeLimits.splice(idx, 1)
}

const initTransferConfig = () => {
  for (const c of availableCurrencies.value) {
    if (!form.transfer_config[c.currency_key]) {
      form.transfer_config[c.currency_key] = { enabled: false, singleMin: 0, singleMax: 0, fee: 0, dailyLimit: 0, timeLimits: [] }
    }
  }
}

// 会员等级
const levelList = ref<any[]>([])
const levelNameMap = ref<Record<number, string>>({})
const getLevelName = (levelId: number) => levelNameMap.value[levelId] || ''
const loadLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    levelList.value = res?.records || res?.data?.records || []
    const map: Record<number, string> = {}
    for (const lv of levelList.value) map[lv.id] = lv.name
    levelNameMap.value = map
  } catch {}
}

const onLevelChange = () => {
  const lv = levelList.value.find((l: any) => l.id === form.levelId)
  if (lv) form.levelName = lv.name
  else if (form.levelId === 0) form.levelName = '所有用户'
}

onMounted(async () => {
  await Promise.all([loadCurrencies(), loadLevels()])
  initTransferConfig()
  fetchData()
})
</script>