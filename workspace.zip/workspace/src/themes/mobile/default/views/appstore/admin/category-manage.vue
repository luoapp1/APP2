<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">应用分类</span>
    </div>

    <!-- Tab 切换 -->
    <div class="bg-white px-4 pt-1 pb-3">
      <div class="flex bg-gray-100 rounded-xl p-1">
        <button class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200" :class="activeTab === 'categories' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'" @click="activeTab = 'categories'">分类管理</button>
        <button class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200" :class="activeTab === 'offtags' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'" @click="activeTab = 'offtags'; fetchTagData()">官方标签</button>
      </div>
    </div>

    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <!-- ====== 分类管理 ====== -->
    <div v-if="activeTab === 'categories'" class="flex-1 overflow-y-auto pb-20">
      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#EC4899] border-t-transparent rounded-full" /></div>

      <template v-else-if="list.length > 0">
        <div v-for="item in list" :key="item.id" class="bg-white mx-3 mt-3 rounded-xl px-4 py-3">
          <div class="flex items-center justify-between">
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-2">
                <span class="text-sm font-semibold text-gray-800">{{ item.name }}</span>
                <span class="text-[11px] px-1.5 py-0.5 rounded-full" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
              </div>
              <div class="text-[11px] text-gray-400 mt-1">
                排序 {{ item.sortOrder ?? 0 }}
                <template v-if="item.icon"> · 图标 {{ item.icon }}</template>
              </div>
            </div>
            <div class="flex items-center gap-1 flex-shrink-0">
              <button v-auth="'edit'" class="text-xs px-2.5 py-1 rounded-full bg-[#EC4899]/10 text-[#EC4899] active:bg-[#EC4899]/20" @click="openDialog(item)">编辑</button>
              <button v-auth="'delete'" class="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 active:bg-gray-200" @click="deleteItem(item)">删除</button>
            </div>
          </div>
        </div>
        <div class="text-center text-xs text-gray-400 py-3">共 {{ list.length }} 条</div>
      </template>
      <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无分类</span></div>
    </div>

    <!-- ====== 官方标签 ====== -->
    <div v-if="activeTab === 'offtags'" class="flex-1 overflow-y-auto pb-20">
      <div v-if="tagLoading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#EC4899] border-t-transparent rounded-full" /></div>

      <template v-else-if="tagList.length > 0">
        <div v-for="item in tagList" :key="'t'+item.id" class="bg-white mx-3 mt-3 rounded-xl px-4 py-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3 min-w-0 flex-1">
              <span class="px-3 py-1 rounded-full text-xs font-medium flex-shrink-0" :style="{ background: item.bgColor || '#dbeafe', color: item.color || '#2563eb' }">{{ item.name }}</span>
              <div class="min-w-0">
                <div class="flex items-center gap-2">
                  <span class="text-[11px] text-gray-400">排序 {{ item.sortOrder ?? 0 }}</span>
                  <span class="text-[11px] px-1.5 py-0.5 rounded-full" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                </div>
                <div class="flex items-center gap-2 mt-1">
                  <span class="w-3.5 h-3.5 rounded-sm border border-gray-200 flex-shrink-0" :style="{ background: item.color }" />
                  <span class="text-[10px] text-gray-300">{{ item.color }}</span>
                  <span class="w-3.5 h-3.5 rounded-sm border border-gray-200 flex-shrink-0" :style="{ background: item.bgColor }" />
                  <span class="text-[10px] text-gray-300">{{ item.bgColor }}</span>
                </div>
              </div>
            </div>
            <div class="flex items-center gap-1 flex-shrink-0">
              <button v-auth="'edit'" class="text-xs px-2.5 py-1 rounded-full bg-[#EC4899]/10 text-[#EC4899] active:bg-[#EC4899]/20" @click="openTagDialog(item)">编辑</button>
              <button v-auth="'delete'" class="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 active:bg-gray-200" @click="deleteTagItem(item)">删除</button>
            </div>
          </div>
        </div>
        <div class="text-center text-xs text-gray-400 py-3">共 {{ tagList.length }} 条</div>
      </template>
      <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无标签</span></div>
    </div>

    <button v-if="activeTab === 'categories'" v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 bg-[#EC4899] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>

    <button v-if="activeTab === 'offtags'" v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 bg-[#EC4899] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openTagDialog(null)">+</button>

    <!-- 分类编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑分类' : '新增分类' }}</span>
          <button v-auth="editId ? 'edit' : 'add'" class="text-sm font-semibold text-[#EC4899]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">分类名称 *</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="请输入分类名称" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">图标 URL</label><input v-model="form.icon" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="图标URL（可选）" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sortOrder" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#EC4899]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 官方标签编辑弹窗 -->
    <div v-if="tagDialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="tagDialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="tagDialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ tagEditId ? '编辑标签' : '新增标签' }}</span>
          <button v-auth="tagEditId ? 'edit' : 'add'" class="text-sm font-semibold text-[#EC4899]" @click="saveTagItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">标签名称 *</label><input v-model="tagForm.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="如: 无广告" maxlength="10" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">文字颜色</label>
              <div class="flex items-center gap-2 bg-[#f5f6f8] rounded-lg px-3 h-10">
                <input v-model="tagForm.color" type="color" class="w-7 h-7 rounded border-none cursor-pointer bg-transparent p-0" />
                <span class="text-xs text-gray-400">{{ tagForm.color }}</span>
              </div>
            </div>
            <div><label class="text-xs text-gray-500 mb-1 block">背景颜色</label>
              <div class="flex items-center gap-2 bg-[#f5f6f8] rounded-lg px-3 h-10">
                <input v-model="tagForm.bgColor" type="color" class="w-7 h-7 rounded border-none cursor-pointer bg-transparent p-0" />
                <span class="text-xs text-gray-400">{{ tagForm.bgColor }}</span>
              </div>
            </div>
          </div>
          <div class="bg-[#f5f6f8] rounded-xl p-3 flex items-center justify-center">
            <span class="px-4 py-1.5 rounded-full text-sm font-medium" :style="{ background: tagForm.bgColor, color: tagForm.color }">{{ tagForm.name || '预览效果' }}</span>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="tagForm.sortOrder" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="tagForm.status === '1' ? 'bg-[#EC4899]' : 'bg-gray-200'" @click="tagForm.status = tagForm.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="tagForm.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 确认删除弹窗 -->
    <div v-if="showConfirm" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showConfirm = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="text-center pt-6 pb-2 px-4">
          <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-red-50 flex items-center justify-center">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">{{ confirmText }}</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="showConfirm = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-medium border-l border-gray-100 active:bg-red-50" @click="doConfirmed">删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { fetchCategoryList, fetchSaveCategory, fetchDeleteCategory, fetchOfficialTags, fetchSaveOfficialTag, fetchDeleteOfficialTag } from '@/api/appstore'

defineOptions({ name: 'CategoryManageMobile' })

const activeTab = ref<'categories' | 'offtags'>('categories')

const showConfirm = ref(false)
const confirmText = ref('')
let pendingAction: (() => void) | null = null
const doConfirmed = () => { showConfirm.value = false; if (pendingAction) pendingAction() }
const askConfirm = (text: string, action: () => void) => { confirmText.value = text; pendingAction = action; showConfirm.value = true }

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

// --- 分类管理 ---
const loading = ref(false)
const list = ref<any[]>([])

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await fetchCategoryList()
    list.value = res?.records || res || []
  } catch (e) { console.error('fetchData error:', e) }
  loading.value = false
}

const dialogVisible = ref(false)
const editId = ref<number | null>(null)
const formDefault = () => ({ name: '', icon: '', sortOrder: 0, status: '1' })
const form = reactive(formDefault())

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) { form.name = item.name || ''; form.icon = item.icon || ''; form.sortOrder = item.sortOrder ?? 0; form.status = item.status || '1' }
  else { Object.assign(form, formDefault()) }
  dialogVisible.value = true
}

const saveItem = async () => {
  if (!form.name.trim()) { showToast('请输入分类名称', 'error'); return }
  try {
    const data: any = { name: form.name.trim(), icon: form.icon, sortOrder: form.sortOrder, status: form.status }
    if (editId.value) data.id = editId.value
    await fetchSaveCategory(data)
    showToast('保存成功')
    dialogVisible.value = false
    fetchData()
  } catch (e) { showToast('保存失败', 'error') }
}

const deleteItem = (item: any) => {
  askConfirm(`确认删除分类「${item.name}」？`, async () => {
    try {
      await fetchDeleteCategory(item.id)
      showToast('删除成功')
      fetchData()
    } catch (e) { showToast('删除失败', 'error') }
  })
}

// --- 官方标签 ---
const tagLoading = ref(false)
const tagList = ref<any[]>([])

const fetchTagData = async () => {
  tagLoading.value = true
  try {
    const res: any = await fetchOfficialTags()
    tagList.value = res || []
  } catch (e) { console.error('fetchTagData error:', e) }
  tagLoading.value = false
}

const tagDialogVisible = ref(false)
const tagEditId = ref<number | null>(null)
const tagFormDefault = () => ({ name: '', color: '#2563eb', bgColor: '#dbeafe', sortOrder: 0, status: '1' })
const tagForm = reactive(tagFormDefault())

const openTagDialog = (item: any | null) => {
  tagEditId.value = item?.id || null
  if (item) { tagForm.name = item.name || ''; tagForm.color = item.color || '#2563eb'; tagForm.bgColor = item.bgColor || '#dbeafe'; tagForm.sortOrder = item.sortOrder ?? 0; tagForm.status = item.status || '1' }
  else { Object.assign(tagForm, tagFormDefault()) }
  tagDialogVisible.value = true
}

const saveTagItem = async () => {
  if (!tagForm.name.trim()) { showToast('请输入标签名称', 'error'); return }
  try {
    const data: any = { name: tagForm.name.trim(), color: tagForm.color, bgColor: tagForm.bgColor, sortOrder: tagForm.sortOrder, status: tagForm.status }
    if (tagEditId.value) data.id = tagEditId.value
    await fetchSaveOfficialTag(data)
    showToast('保存成功')
    tagDialogVisible.value = false
    fetchTagData()
  } catch (e) { showToast('保存失败', 'error') }
}

const deleteTagItem = (item: any) => {
  askConfirm(`确认删除标签「${item.name}」？`, async () => {
    try {
      await fetchDeleteOfficialTag(item.id)
      showToast('删除成功')
      fetchTagData()
    } catch (e) { showToast('删除失败', 'error') }
  })
}

onMounted(() => fetchData())
</script>
