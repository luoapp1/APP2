<template>
  <div class="editor-root">
    <div class="topbar">
      <button class="tb-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="tb-title">{{ isEditMode ? '编辑帖子' : '发布帖子' }}</span>
      <button class="tb-publish" :disabled="submitting || !form.title.trim()" @click="handlePublish">
        {{ submitting ? '发布中...' : '发布' }}
      </button>
    </div>

    <div class="toast-bar" v-if="toastMsg">{{ toastMsg }}</div>

    <div class="autosave-indicator" v-if="autoSaveStatus">{{ autoSaveStatus }}</div>

    <div class="editor-main">
      <div class="cover-section" v-if="coverImage">
        <div class="cover-preview">
          <img :src="coverImage" alt="封面图"  loading="lazy" />
          <button class="cover-remove" @click="coverImage = ''">&times;</button>
        </div>
      </div>

      <div class="title-section">
        <textarea v-model="form.title" rows="1" maxlength="100" placeholder="添加标题" class="title-input"></textarea>
      </div>

      <div class="meta-bar">
        <div class="tp-tags">
          <span v-for="tid in selectedTopicIds" :key="tid" class="tp-tag" @click="removeTopic(tid)">#{{ selectedTopicNames[tid] || tid }} &times;</span>
          <button v-if="selectedTopicIds.length < 5" class="tp-add-btn" @click="topicPickerMode = 'header'; showTopicPicker = true">{{ selectedTopicIds.length === 0 ? '选择话题' : '+' }}</button>
          <span class="tp-sep" v-if="selectedTopicIds.length > 0 && selectedTags.length > 0">|</span>
          <span v-for="t in selectedTags" :key="t" class="tp-tag tp-tag-green" @click="toggleTagItem(t)">{{ t }} &times;</span>
          <button v-if="selectedTags.length < 5 && officialTags.length > 0" class="tp-add-btn" @click="showTagPicker = true">{{ selectedTags.length === 0 ? '选择标签' : '+' }}</button>
          <button class="tp-add-btn tp-cover-btn" @click="coverInput?.click()">{{ coverImage ? '更换封面' : '添加封面' }}</button>
          <input ref="coverInput" type="file" accept="image/*" hidden @change="onCoverUpload" />
        </div>
      </div>

      <div class="edit-toolbar">
        <button @click="editorRef?.toggleToolbar()" class="et-btn et-btn-fmt" title="文字格式">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>
        </button>
        <button @click="showPicker('vote')" class="et-btn" title="投票">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 14l2 2 4-4"/></svg>
        </button>
        <button @click="showPicker('goods')" class="et-btn" title="商品">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
        </button>
        <button @click="showPicker('audio')" class="et-btn" title="音频">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
        </button>
        <button @click="showPicker('file')" class="et-btn" title="附件">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
        </button>
        <button @click="showPicker('notice')" class="et-btn" title="公告">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        </button>
        <button @click="showPicker('updateLog')" class="et-btn" title="更新日志">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
        </button>
        <button @click="showPicker('password')" class="et-btn" title="密码解锁">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
        </button>
        <button @click="showPicker('gallery')" class="et-btn" title="图集">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
        </button>
        <button @click="showPicker('video')" class="et-btn" title="视频">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
        </button>
        <button @click="showPicker('original')" class="et-btn" title="原创声明">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M14.3 16.3L12 12l-2.3-4.3"/><path d="M9.7 7.7L12 12l2.3 4.3"/></svg>
        </button>
        <button @click="showPicker('sourceQuote')" class="et-btn" title="转载引用">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
        </button>
        <button @click="showPicker('followUnlock')" class="et-btn" title="关注解锁">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
        </button>
        <button @click="showPicker('commentUnlock')" class="et-btn" title="评论解锁">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/><line x1="9" y1="10" x2="15" y2="10"/></svg>
        </button>
        <button @click="showPicker('template')" class="et-btn" title="内容模板">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
        </button>
        <button @click="showPicker('postRef')" class="et-btn" title="引用帖子">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
        </button>
        <button @click="showPicker('levelPrivilege')" class="et-btn" title="等级权益卡片">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>
        </button>
      </div>

      <input ref="imgInput" type="file" accept="image/*" multiple hidden @change="onImageUpload" />

      <div class="editor-area">
        <TipTapEditor ref="editorRef" v-model="editorContent" placeholder="分享你的想法..." @hashtag-click="onHashtagClick" />
      </div>
    </div>

    <div class="bottom-bar">
      <button @click="addImage" class="bb-btn" title="图片">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M2 16l5-4 3 2 2-3 5 5"/></svg>
      </button>
      <button @click="showPaywallModal = true" class="bb-btn" title="付费分割">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
      </button>
      <button @click="showMemberUnlockModal = true" class="bb-btn" title="会员可见">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#D48806" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
      </button>
      <button @click="showExpUnlockModal = true" class="bb-btn" title="经验等级可见">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#508DFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      </button>
      <button @click="showTitleUnlockModal = true; loadMyTitles()" class="bb-btn" title="称号解锁">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777z"/><circle cx="12" cy="12" r="3"/><path d="M22 12A10 10 0 1112 2"/></svg>
      </button>
      <button @click="showAppSelector = true; loadAppList()" class="bb-btn" title="插入应用">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="3"/></svg>
      </button>
      <div class="bb-divider"></div>
      <button @click="topicPickerMode = 'insert'; showTopicPicker = true" class="bb-btn" title="插入话题" style="font-size:22px;font-weight:700;color:#508DFF;line-height:1;">#</button>
      <div class="bb-spacer"></div>
      <div class="bb-schedule-wrap">
        <div class="scheduled-chip" v-if="form.scheduledTime" @click="form.scheduledTime = ''">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          {{ formatScheduledLabel(form.scheduledTime) }}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </div>
        <button @click="showScheduledPicker = true" class="bb-btn bb-btn-schedule" :class="{ 'is-set': !!form.scheduledTime }" title="定时发布">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </button>
      </div>
      <div class="bb-schedule-wrap">
        <div class="scheduled-chip hide-chip" v-if="form.autoHideAt" @click="form.autoHideAt = ''">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M1 1l22 22"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M8.59 15.41a4 4 0 0 0 5.66 0"/><path d="M14.83 9.17a4 4 0 0 0-5.66 0"/></svg>
          {{ formatScheduledLabel(form.autoHideAt) }}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </div>
        <button @click="showAutoHidePicker = true" class="bb-btn bb-btn-schedule" :class="{ 'is-set': !!form.autoHideAt }" title="定时隐藏">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M1 1l22 22"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M8.59 15.41a4 4 0 0 0 5.66 0"/><path d="M14.83 9.17a4 4 0 0 0-5.66 0"/></svg>
        </button>
      </div>
      <select v-model="form.contentPermission" class="bb-select">
        <option value="public">公开</option>
        <option value="login">登录可见</option>
        <option value="comment">评论可见</option>
      </select>
    </div>

    <!-- Scheduled Picker Modal -->
    <div class="modal-overlay" v-if="showScheduledPicker" @click.self="showScheduledPicker = false">
      <div class="modal-sheet">
        <div class="ms-title">设置定时发布时间</div>
        <input type="datetime-local" v-model="scheduledTimeInput" class="ms-input" />
        <div class="ms-actions">
          <button @click="showScheduledPicker = false" class="ms-cancel">取消</button>
          <button @click="confirmScheduled" class="ms-confirm" :disabled="!scheduledTimeInput">确认</button>
        </div>
      </div>
    </div>

    <!-- Auto Hide Picker Modal -->
    <div class="modal-overlay" v-if="showAutoHidePicker" @click.self="showAutoHidePicker = false">
      <div class="modal-sheet">
        <div class="ms-title">设置定时隐藏时间</div>
        <input type="datetime-local" v-model="autoHideTimeInput" class="ms-input" />
        <div class="ms-actions">
          <button @click="showAutoHidePicker = false" class="ms-cancel">取消</button>
          <button @click="confirmAutoHide" class="ms-confirm" :disabled="!autoHideTimeInput">确认</button>
        </div>
      </div>
    </div>

    <!-- Modal Overlay -->
    <div class="modal-overlay" v-if="activePicker" @click.self="activePicker = null">
      <div class="modal-sheet">
        <!-- VoteCard -->
        <template v-if="activePicker === 'vote'">
          <div class="ms-title">添加投票</div>
          <input v-model="voteForm.question" placeholder="投票问题" class="ms-input" />
          <div v-for="(opt, i) in voteForm.options" :key="i" class="ms-opt-row">
            <input v-model="voteForm.options[i]" :placeholder="`选项 ${i + 1}`" class="ms-input" />
            <button @click="voteForm.options.splice(i, 1)" class="ms-del">×</button>
          </div>
          <button @click="voteForm.options.push('')" class="ms-add">+ 添加选项</button>
          <input v-model.number="voteForm.maxSelect" type="number" min="1" placeholder="最多可选几项" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertVote" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- GoodsCard -->
        <template v-if="activePicker === 'goods'">
          <div class="ms-title">选择商品</div>
          <input v-model="goodsSearch" placeholder="搜索商品..." class="ms-input" @input="filterGoods" />
          <div style="max-height:300px;overflow-y:auto;">
            <div v-for="a in filteredGoodsList" :key="a.id" class="app-item" @click="selectGoods(a)">
              <div class="app-item-icon" style="background:#f5f5f5">
                <img v-if="a.coverImage || a.image" :src="$fixImgUrl(a.coverImage || a.image)" class="app-item-img"  loading="lazy" />
                <span v-else>{{ (a.name || '商')[0] }}</span>
              </div>
              <div style="flex:1">
                <div style="font-size:14px;font-weight:500">{{ a.name }}</div>
                <div style="font-size:12px;color:#e74c3c;font-weight:600">￥{{ a.price || 0 }}</div>
              </div>
            </div>
            <div v-if="filteredGoodsList.length === 0" style="text-align:center;padding:20px;color:#bbb;">暂无商品</div>
          </div>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
          </div>
        </template>

        <!-- AudioBlock -->
        <template v-if="activePicker === 'audio'">
          <div class="ms-title">添加音频</div>
          <input v-model="audioForm.src" placeholder="音频链接" class="ms-input" />
          <input v-model="audioForm.title" placeholder="音频标题" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertAudio" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- FileAttachment -->
        <template v-if="activePicker === 'file'">
          <div class="ms-title">添加附件</div>
          <input v-model="fileForm.name" placeholder="文件名" class="ms-input" />
          <input v-model="fileForm.size" placeholder="文件大小" class="ms-input" />
          <input v-model="fileForm.url" placeholder="文件链接" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertFile" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- NoticeBanner -->
        <template v-if="activePicker === 'notice'">
          <div class="ms-title">添加公告</div>
          <select v-model="noticeForm.type" class="ms-input">
            <option value="info">信息</option>
            <option value="warning">警告</option>
            <option value="success">成功</option>
            <option value="error">错误</option>
          </select>
          <textarea v-model="noticeForm.content" placeholder="公告内容" class="ms-input" rows="3"></textarea>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertNotice" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- UpdateLog -->
        <template v-if="activePicker === 'updateLog'">
          <div class="ms-title">添加更新日志</div>
          <input v-model="updateLogForm.version" placeholder="版本号" class="ms-input" />
          <input v-model="updateLogForm.date" placeholder="日期" class="ms-input" />
          <textarea v-model="updateLogForm.changes" placeholder="更新内容（每行一条）" class="ms-input" rows="4"></textarea>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertUpdateLog" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- PasswordUnlock -->
        <template v-if="activePicker === 'password'">
          <div class="ms-title">添加密码解锁块</div>
          <input v-model="passwordForm.password" placeholder="解锁密码" class="ms-input" />
          <input v-model="passwordForm.hint" placeholder="密码提示" class="ms-input" />
          <textarea v-model="passwordForm.content" placeholder="锁定内容" class="ms-input" rows="3"></textarea>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertPassword" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- GalleryBlock -->
        <template v-if="activePicker === 'gallery'">
          <div class="ms-title">添加轮播图集</div>
          <div v-for="(img, i) in galleryForm.images" :key="i" class="ms-opt-row">
            <input v-model="galleryForm.images[i]" :placeholder="`图片链接 ${i + 1}`" class="ms-input" />
            <button @click="galleryForm.images.splice(i, 1)" class="ms-del">×</button>
          </div>
          <button @click="galleryForm.images.push('')" class="ms-add">+ 添加图片</button>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertGallery" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- VideoEmbed -->
        <template v-if="activePicker === 'video'">
          <div class="ms-title">添加视频</div>
          <input v-model="videoForm.url" placeholder="粘贴视频分享链接，自动识别" class="ms-input" @input="onVideoUrlInput" />
          <div v-if="videoForm.type" style="font-size:11px;color:#508DFF;margin:4px 0 8px;">
            已识别：{{ videoPlatformLabel(videoForm.type) }} 
            <span v-if="videoForm.id" style="color:#999">({{ videoForm.id }})</span>
          </div>
          <div v-else style="font-size:11px;color:#999;margin:4px 0 8px;">
            支持：YouTube、B站、腾讯视频、抖音、快手
          </div>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertVideo" class="ms-confirm" :disabled="!videoForm.id">插入</button>
          </div>
        </template>

        <!-- OriginalStatement -->
        <template v-if="activePicker === 'original'">
          <div class="ms-title">原创声明</div>
          <input v-model="originalForm.author" placeholder="作者名" class="ms-input" />
          <select v-model="originalForm.license" class="ms-input">
            <option value="CC BY 4.0">CC BY 4.0</option>
            <option value="CC BY-SA 4.0">CC BY-SA 4.0</option>
            <option value="CC BY-NC 4.0">CC BY-NC 4.0</option>
            <option value="CC BY-ND 4.0">CC BY-ND 4.0</option>
            <option value="All Rights Reserved">保留所有权利</option>
          </select>
          <input v-model="originalForm.reprintRule" placeholder="转载规则（如：转载需注明出处）" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertOriginal" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- SourceQuote -->
        <template v-if="activePicker === 'sourceQuote'">
          <div class="ms-title">转载来源引用</div>
          <input v-model="sourceQuoteForm.url" placeholder="原文链接" class="ms-input" />
          <input v-model="sourceQuoteForm.author" placeholder="原作者" class="ms-input" />
          <input v-model="sourceQuoteForm.platform" placeholder="来源平台（如：知乎、公众号）" class="ms-input" />
          <textarea v-model="sourceQuoteForm.quoteText" placeholder="转载声明或引用原文（选填）" class="ms-input" rows="3"></textarea>
          <input v-model="sourceQuoteForm.note" placeholder="备注说明（选填）" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertSourceQuote" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- FollowUnlock -->
        <template v-if="activePicker === 'followUnlock'">
          <div class="ms-title">关注解锁</div>
          <textarea v-model="followUnlockForm.hint" placeholder="解锁后的内容（用户关注后可见）" class="ms-input" rows="3"></textarea>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertFollowUnlock" class="ms-confirm">插入</button>
          </div>
        </template>

        <!-- CommentUnlock -->
        <template v-if="activePicker === 'commentUnlock'">
          <div class="ms-title">评论解锁</div>
          <input v-model.number="commentUnlockForm.minCommentCount" type="number" min="1" placeholder="最少评论数" class="ms-input" />
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertCommentUnlock" class="ms-confirm">插入</button>
          </div>
        </template>

        <template v-if="activePicker === 'template'">
          <div class="ms-title">选择内容模板</div>
          <div v-for="tpl in contentTemplates" :key="tpl.name" class="tpl-item" @click="applyTemplate(tpl)">
            <div class="tpl-icon">{{ tpl.icon }}</div>
            <div>
              <div class="tpl-name">{{ tpl.name }}</div>
              <div class="tpl-desc">{{ tpl.desc }}</div>
            </div>
          </div>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
          </div>
        </template>

        <template v-if="activePicker === 'levelPrivilege'">
          <div class="ms-title">等级权益卡片</div>
          <div style="margin-bottom:10px;">
            <div style="font-size:13px;color:#666;margin-bottom:4px;">选择等级</div>
            <select v-model="levelForm.level" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:8px;font-size:14px;">
              <option v-for="l in levelOptions" :key="l.level" :value="l.level">Lv.{{ l.level }} {{ l.name }}</option>
            </select>
          </div>
          <div style="margin-bottom:10px;">
            <div style="font-size:13px;color:#666;margin-bottom:4px;">权益列表（每行一条）</div>
            <textarea v-model="levelForm.privilegesText" rows="5" placeholder="无限制下载资源&#10;私信不受限制&#10;创建付费内容&#10;专属身份标识&#10;优先客服支持" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:8px;font-size:13px;resize:vertical;"></textarea>
          </div>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
            <button @click="insertLevelCard" class="ms-confirm">插入</button>
          </div>
        </template>
        <template v-if="activePicker === 'postRef'">
          <div class="ms-title">引用帖子</div>
          <input v-model="postRefSearch" placeholder="搜索帖子标题..." class="ms-input" @input="searchPosts" />
          <div style="max-height:300px;overflow-y:auto;">
            <div v-for="p in postRefList" :key="p.id" class="tpl-item" @click="insertPostRefCard(p)">
              <div class="tpl-icon" style="font-size:16px;background:#e8f0fe;color:#3b82f6;">
                {{ (p.title || '?')[0] }}
              </div>
              <div style="flex:1;min-width:0;">
                <div style="font-size:14px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{{ p.title }}</div>
                <div style="font-size:12px;color:#999;">{{ p.authorName || p.author }} · {{ p.sectionName || '' }}</div>
              </div>
            </div>
            <div v-if="postRefList.length === 0 && postRefSearch" style="text-align:center;padding:20px;color:#bbb;">无匹配帖子</div>
          </div>
          <div class="ms-actions">
            <button @click="activePicker = null" class="ms-cancel">取消</button>
          </div>
        </template>
      </div>
    </div>

    <div class="modal-overlay" v-if="showPaywallModal" @click.self="showPaywallModal = false">
      <div class="modal-sheet">
        <div class="ms-title">付费内容设置</div>
        <input v-model.number="paywallPrice" type="number" min="0" placeholder="价格" class="ms-input" />
        <select v-model="paywallPriceType" class="ms-input">
          <option value="balance">余额 (元)</option>
          <option value="points">积分</option>
        </select>
        <div class="ms-actions">
          <button @click="showPaywallModal = false" class="ms-cancel">取消</button>
          <button @click="insertPaywall" class="ms-confirm">插入</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showMemberUnlockModal" @click.self="showMemberUnlockModal = false">
      <div class="modal-sheet">
        <div class="ms-title">会员等级可见设置</div>
        <div class="ms-sub">以下内容仅指定等级会员可见</div>
        <select v-model="memberUnlockLevel" class="ms-input">
          <option v-for="l in memberLevels" :key="'m'+l.id" :value="l.id">{{ l.name }}</option>
        </select>
        <div class="ms-actions">
          <button @click="showMemberUnlockModal = false" class="ms-cancel">取消</button>
          <button @click="insertMemberUnlock" class="ms-confirm">插入</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showExpUnlockModal" @click.self="showExpUnlockModal = false">
      <div class="modal-sheet">
        <div class="ms-title">经验等级可见设置</div>
        <div class="ms-sub">以下内容仅指定经验等级及以上可见</div>
        <select v-model="expUnlockLevel" class="ms-input">
          <option v-for="l in expLevels" :key="l.level" :value="l.level">{{ l.name }}</option>
        </select>
        <div class="ms-actions">
          <button @click="showExpUnlockModal = false" class="ms-cancel">取消</button>
          <button @click="insertExpUnlock" class="ms-confirm">插入</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showTitleUnlockModal" @click.self="showTitleUnlockModal = false">
      <div class="modal-sheet">
        <div class="ms-title">称号解锁设置</div>
        <div class="ms-sub">以下内容仅拥有指定称号的用户可见 (仅显示您拥有的称号)</div>
        <select v-if="myTitles.length > 0" v-model="titleUnlockId" class="ms-input">
          <option v-for="t in myTitles" :key="t.id" :value="t.id">{{ t.name }}</option>
        </select>
        <div v-else class="ms-empty">您还没有获得任何称号</div>
        <div class="ms-actions">
          <button @click="showTitleUnlockModal = false" class="ms-cancel">取消</button>
          <button v-if="myTitles.length > 0" @click="insertTitleUnlock" class="ms-confirm">插入</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showTopicPicker" @click.self="showTopicPicker = false">
      <div class="modal-sheet">
        <div class="ms-title">选择话题</div>
        <input v-model="topicSearchQuery" placeholder="搜索话题..." class="ms-input" />
        <div style="max-height:300px;overflow-y:auto;">
          <div v-for="t in filteredTopics" :key="t.id" class="tp-item" :class="{ 'tp-item-on': topicPickerMode === 'header' && selectedTopicIds.includes(t.id) }" @click="topicPickerMode === 'header' ? toggleTopic(t) : insertTopicHash(t)">
            <span class="tp-item-icon">{{ t.icon || '#' }}</span>
            <span class="tp-item-name">{{ t.name }}</span>
            <span v-if="t.postCount" class="tp-item-count">{{ t.postCount }} 帖</span>
            <svg v-if="topicPickerMode === 'header' && selectedTopicIds.includes(t.id)" width="16" height="16" viewBox="0 0 24 24" fill="#508DFF"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </div>
          <div v-if="filteredTopics.length === 0" style="text-align:center;padding:20px;color:#bbb;">暂无话题</div>
        </div>
        <div class="ms-actions">
          <button @click="showTopicPicker = false" class="ms-confirm" style="flex:2">完成</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showTagPicker" @click.self="showTagPicker = false">
      <div class="modal-sheet">
        <div class="ms-title">选择标签</div>
        <div class="ms-opt-row">
          <input v-model="customTagInput" placeholder="自定义标签（回车添加）" class="ms-input" @keydown.enter="addCustomTag" />
          <button @click="addCustomTag" class="ms-add" style="width:auto;padding:10px 16px;margin-bottom:10px;white-space:nowrap;">添加</button>
        </div>
        <div style="max-height:260px;overflow-y:auto;">
          <div v-for="t in allTagOptions" :key="t" class="tp-item" :class="{ 'tp-item-on': selectedTags.includes(t) }" @click="toggleTagItem(t)">
            <span class="tp-item-icon" style="color:#508DFF">#</span>
            <span class="tp-item-name">{{ t }}</span>
            <svg v-if="selectedTags.includes(t)" width="16" height="16" viewBox="0 0 24 24" fill="#508DFF"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </div>
        </div>
        <div class="ms-actions">
          <button @click="showTagPicker = false" class="ms-confirm" style="flex:2">完成</button>
        </div>
      </div>
    </div>

    <div class="modal-overlay" v-if="showAppSelector" @click.self="showAppSelector = false">
      <div class="modal-sheet">
        <div class="ms-title">插入应用</div>
        <input v-model="appSearchQuery" placeholder="搜索应用..." class="ms-input" @input="filterApps" />
        <div style="max-height:300px;overflow-y:auto;">
          <div v-for="a in filteredAppList" :key="a.id" class="app-item" @click="selectAppInline(a)">
            <div class="app-item-icon" :style="{ background: a.iconBgColor || '#508DFF' }">
              <img v-if="a.icon" :src="$fixImgUrl(a.icon)" class="app-item-img"  loading="lazy" />
              <span v-else>{{ (a.name || 'A')[0] }}</span>
            </div>
            <div>
              <div style="font-size:14px;font-weight:500">{{ a.name }}</div>
              <div style="font-size:11px;color:#999">{{ a.description || a.category || '' }}</div>
            </div>
          </div>
          <div v-if="filteredAppList.length === 0" style="text-align:center;padding:20px;color:#bbb;">暂无应用</div>
        </div>
        <div class="ms-actions">
          <button @click="showAppSelector = false" class="ms-cancel">取消</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import TipTapEditor from '@/components/editor/TipTapEditor.vue'
import { uploadCommunityImage, fetchTopics, fetchCommunityPost, createCommunityPost, updateCommunityPost, fetchMembershipLevels, fetchExperienceLevels } from '@/api/community'
import { fetchMyTitles } from '@/api/social'
import request from '@/utils/http'
import { fetchAppList, fetchOfficialTags } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import { parseVideoUrl } from '@/components/editor/extensions/video-embed'
import { hashPassword } from '@/components/editor/extensions/password-unlock'
import { blocksToTiptap } from '@/utils/tiptap'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const editorRef = ref<any>(null)
const editorContent = ref<any>({ type: 'doc', content: [{ type: 'paragraph' }] })
const imgInput = ref<HTMLInputElement>()
const coverInput = ref<HTMLInputElement>()
const coverImage = ref('')
const submitting = ref(false)
const fetching = ref(true)
const toastMsg = ref('')
const activePicker = ref<string | null>(null)
const showPaywallModal = ref(false)
const paywallPrice = ref(0)
const paywallPriceType = ref('balance')
const showMemberUnlockModal = ref(false)
const memberUnlockLevel = ref(1)
const showExpUnlockModal = ref(false)
const expUnlockLevel = ref(2)
const memberLevels = ref<Array<{ id: number; level: number; name: string }>>([])
const expLevels = ref<Array<{ level: number; name: string }>>([])
const showTitleUnlockModal = ref(false)
const titleUnlockId = ref(0)
const myTitles = ref<Array<{ id: number; name: string }>>([])

async function loadMemberLevels() {
  try {
    const res = await fetchMembershipLevels()
    const arr = Array.isArray(res) ? res : (res?.data || res?.list || [])
    memberLevels.value = arr.map((l: any) => ({ id: l.id, level: l.level || l.tier, name: l.name }))
  } catch {}
}

async function loadExpLevels() {
  try {
    const res = await fetchExperienceLevels()
    const records = res?.records || res?.data?.records || res?.data || res?.list || []
    expLevels.value = (Array.isArray(records) ? records : []).map((l: any) => ({ level: l.level, name: l.name }))
  } catch {}
}
const showAppSelector = ref(false)
const showTopicPicker = ref(false)
const topicPickerMode = ref<'header' | 'insert'>('header')
const showTagPicker = ref(false)
const showScheduledPicker = ref(false)
const scheduledTimeInput = ref('')
const showAutoHidePicker = ref(false)
const autoHideTimeInput = ref('')
const postRefSearch = ref('')
const postRefList = ref<any[]>([])
const availableTopics = ref<any[]>([])
const selectedTopicIds = ref<number[]>([])
const selectedTopicNames = ref<Record<number, string>>({})
const topicSearchQuery = ref('')
const officialTags = ref<string[]>([])
const selectedTags = ref<string[]>([])
const customTagInput = ref('')
const customTags = ref<string[]>([])

const editPostId = computed(() => {
  const id = route.params.id
  if (!id) return 0
  try { return Number(atob(id as string)) } catch { return 0 }
})
const isEditMode = computed(() => editPostId.value > 0)

function getUserId(): number { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }

const allTagOptions = computed(() => {
  const set = new Set([...officialTags.value, ...customTags.value])
  return [...set]
})
const appList = ref<any[]>([])
const appSearchQuery = ref('')
const filteredAppList = ref<any[]>([])
const goodsSearch = ref('')
const goodsList = ref<any[]>([])
const filteredGoodsList = ref<any[]>([])

const form = reactive({
  sectionId: Number(route.params.sectionId) || 0, title: '', tags: [] as string[],
  contentPermission: 'public', contentPrice: 0, contentPriceType: 'balance',
  accessPassword: '', accessPasswordTips: '', scheduledTime: '', autoHideAt: ''
})

const filteredTopics = computed(() => {
  if (!topicSearchQuery.value) return availableTopics.value.slice(0, 30)
  const q = topicSearchQuery.value.toLowerCase()
  return availableTopics.value.filter((t: any) => t.name.toLowerCase().includes(q)).slice(0, 30)
})

const voteForm = reactive({ question: '', options: ['', ''], maxSelect: 1 })
const audioForm = reactive({ src: '', title: '' })
const fileForm = reactive({ name: '', size: '', url: '' })
const noticeForm = reactive({ type: 'info', content: '' })
const updateLogForm = reactive({ version: '', date: '', changes: '' })
const passwordForm = reactive({ password: '', hint: '', content: '' })
const galleryForm = reactive({ images: ['', ''] })
const videoForm = reactive({ url: '', type: '', id: '', title: '' })
const originalForm = reactive({ author: '', license: 'CC BY 4.0', reprintRule: '' })
const sourceQuoteForm = reactive({ url: '', author: '', platform: '', note: '', quoteText: '' })
const followUnlockForm = reactive({ hint: '' })
const commentUnlockForm = reactive({ minCommentCount: 1 })
const levelForm = reactive({ level: 1, privilegesText: '无限制下载资源\n私信不受限制\n创建付费内容\n专属身份标识' })
const levelOptions = [
  { level: 1, name: '普通会员' }, { level: 2, name: '青铜会员' },
  { level: 3, name: '白银会员' }, { level: 4, name: '黄金会员' },
  { level: 5, name: '铂金会员' }, { level: 6, name: '钻石会员' }
]

const contentTemplates = [
  { name: '评测', icon: '⭐', desc: '产品/应用评测模板', content: [
    { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: '评测标题' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '【一句话总结】这里写你的整体评价。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 外观与设计' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '描述产品的外观、材质、颜色等。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 功能体验' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '逐一介绍核心功能和使用感受。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 优缺点' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '- 优点：...\n- 缺点：...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 总结评分' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '综合评分：⭐（满分5星）/ 推荐指数：X/10' }] }
  ]},
  { name: '教程', icon: '📖', desc: '操作教程/指南模板', content: [
    { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: '教程标题' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '【简介】本文教你如何...，适合人群：XX。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 准备工作' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '- 需要准备的工具/软件：...\n- 环境要求：...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 步骤一：' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '详细描述第一步操作...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 步骤二：' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '详细描述第二步操作...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 常见问题' }] },
    { type: 'paragraph', content: [{ type: 'text', text: 'Q: 问题一？\nA: 解答一。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 总结' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '回顾关键步骤和注意事项。' }] }
  ]},
  { name: '开箱', icon: '📦', desc: '开箱体验模板', content: [
    { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: '开箱：产品名称' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '【购买信息】入手渠道：XX / 价格：XX 元' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 包装与外观' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '描述包装盒、开箱第一印象。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 配件一览' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '列出所有配件和附件。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 上手体验' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '第一次使用的感受和印象。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 初步评价' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '是否值得购买？适合谁？' }] }
  ]},
  { name: '公告', icon: '📢', desc: '公告/通知模板', content: [
    { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: '公告标题' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '发布人：XX  时间：XXXX年XX月XX日' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '【正文】' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '各位用户/成员：' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '特此通知以下事项：' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '- 事项一：...\n- 事项二：...\n- 事项三：...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '如有疑问，请联系XX。' }] }
  ]},
  { name: '游戏攻略', icon: '🎮', desc: '游戏攻略/心得模板', content: [
    { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: '游戏名称 - 攻略标题' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '【适用平台】PC / 手机 / 主机丨【难度】简单/中等/困难' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 前言' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '介绍攻略的背景和目标。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 核心技巧' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '- 技巧一：...\n- 技巧二：...' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 推荐配置/阵容' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '详细的配置说明。' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '## 总结' }] },
    { type: 'paragraph', content: [{ type: 'text', text: '一句话总结核心要点。' }] }
  ]}
]

async function loadTopics() {
  try { const resp: any = await fetchTopics(); availableTopics.value = resp?.list || resp || [] } catch {}
}

async function loadPost() {
  try {
    await loadTopics()
    const res = await fetchCommunityPost(editPostId.value, getUserId())
    const p = res.data || res
    if (!p) { fetching.value = false; return }
    const uid = getUserId()
    if (!uid || (p.userId && p.userId !== uid && !userIsAdmin())) { router.replace(`/community/post/${editPostId.value}`); return }
    form.title = p.title || ''
    form.contentPermission = p.contentPermission || 'public'
    form.contentPrice = p.contentPrice || 0
    form.contentPriceType = p.contentPriceType || 'balance'
    form.accessPassword = p.accessPassword || ''
    form.accessPasswordTips = p.accessPasswordTips || ''
    form.sectionId = p.sectionId || 0
    form.scheduledTime = p.scheduledTime || ''
    form.autoHideAt = p.autoHideAt || ''
    coverImage.value = p.coverImage || p.coverUrl || ''
    if (p.topicIds && p.topicIds.length > 0) {
      selectedTopicIds.value = p.topicIds
      p.topicIds.forEach((tid: number) => { const t = availableTopics.value.find((t2: any) => t2.id === tid); if (t) selectedTopicNames.value[tid] = t.name })
    } else if (p.topicId) {
      selectedTopicIds.value = [p.topicId]; if (p.topicName) selectedTopicNames.value[p.topicId] = p.topicName
    }
    if (p.officialTags && p.officialTags.length > 0) {
      selectedTags.value = [...p.officialTags]
    }
    if (p.tags && p.tags.length > 0) {
      const parsed = typeof p.tags === 'string' ? JSON.parse(p.tags) : p.tags
      if (Array.isArray(parsed) && parsed.length > 0) {
        const seen = new Set(selectedTags.value)
        parsed.forEach((t: string) => { if (!seen.has(t)) { seen.add(t); selectedTags.value.push(t) } })
      }
    }
    if (p.content) {
      try {
        const parsed = JSON.parse(p.content)
        if (Array.isArray(parsed)) editorContent.value = blocksToTiptap(parsed)
        else if (parsed.type === 'doc') editorContent.value = parsed
        else editorContent.value = { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: p.content }] }] }
      } catch {
        editorContent.value = { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: p.content }] }] }
      }
    }
    if (!editorContent.value.content || editorContent.value.content.length === 0) editorContent.value = { type: 'doc', content: [{ type: 'paragraph' }] }
  } catch (e) { /* ignore */ }
  finally { fetching.value = false }
}
function toggleTopic(topic: any) {
  const idx = selectedTopicIds.value.indexOf(topic.id)
  if (idx > -1) { selectedTopicIds.value.splice(idx, 1); delete selectedTopicNames.value[topic.id] }
  else { selectedTopicIds.value.push(topic.id); selectedTopicNames.value[topic.id] = topic.name }
}

function insertTopicHash(topic: any) {
  editorRef.value?.editor?.chain().focus().insertContent({ type: 'text', text: '#' + topic.name, marks: [{ type: 'hashtag' }] }).insertContent({ type: 'text', text: ' ' }).run()
  showTopicPicker.value = false
}
function removeTopic(topicId: number) {
  const idx = selectedTopicIds.value.indexOf(topicId)
  if (idx > -1) selectedTopicIds.value.splice(idx, 1)
  delete selectedTopicNames.value[topicId]
}

async function loadOfficialTags() {
  try {
    const res: any = await fetchOfficialTags()
    const list = res?.list || res?.data || res || []
    officialTags.value = list.map((t: any) => t.name || t)
  } catch {}
}
function toggleTagItem(tag: string) {
  const idx = selectedTags.value.indexOf(tag)
  if (idx > -1) selectedTags.value.splice(idx, 1)
  else if (selectedTags.value.length < 5) selectedTags.value.push(tag)
}

function addCustomTag() {
  const t = customTagInput.value.trim()
  if (!t) return
  if (!customTags.value.includes(t)) customTags.value.push(t)
  if (!selectedTags.value.includes(t)) selectedTags.value.push(t)
  customTagInput.value = ''
}
onMounted(() => { loadOfficialTags(); loadMemberLevels(); loadExpLevels(); if (isEditMode.value) loadPost(); else { loadTopics(); fetching.value = false } })

const autoSaveTimer = ref<ReturnType<typeof setTimeout>>()
const autoSaveStatus = ref('')

function debouncedAutoSave() {
  if (autoSaveTimer.value) clearTimeout(autoSaveTimer.value)
  autoSaveTimer.value = setTimeout(async () => {
    if (isEditMode.value) return
    try {
      const content = editorRef.value?.getJSON()
      await request.post({ url: '/api/community/draft', data: {
        sectionId: form.sectionId, title: form.title, content: content ? JSON.stringify(content) : '',
        tags: selectedTags.value, images: galleryForm.images.filter(i => i.trim()), coverImage: coverImage.value
      }})
      autoSaveStatus.value = `已自动保存 ${new Date().toLocaleTimeString()}`
      setTimeout(() => { if (autoSaveStatus.value.includes('已自动保存')) autoSaveStatus.value = '' }, 3000)
    } catch {}
  }, 5000)
}

watch(() => [form.title, form.sectionId, selectedTags.value, uploadedImages.value, coverImage.value], () => {
  if (!isEditMode.value && (form.title.trim() || uploadedImages.value.length)) debouncedAutoSave()
}, { deep: true })

onUnmounted(() => { if (autoSaveTimer.value) clearTimeout(autoSaveTimer.value) })

function showPicker(type: string) { activePicker.value = type; if (type === 'goods') loadGoodsList(); if (type === 'postRef') { postRefSearch.value = ''; searchPosts() } }

function addImage() { imgInput.value?.click() }

function searchPosts() {
  request.get({ url: '/api/community/posts', params: { keyword: postRefSearch.value || '', pageSize: 20 } })
    .then((res: any) => {
      const data = Array.isArray(res) ? res : (res.list || res.data || [])
      postRefList.value = data
    })
    .catch(() => { postRefList.value = [] })
}

function insertPostRefCard(p: any) {
  editorRef.value?.insertPostRef({
    postId: p.id,
    title: p.title || '',
    author: p.authorName || p.author || '',
    sectionName: p.sectionName || '',
    summary: (p.summary || p.content || '').replace(/<[^>]+>/g, '').substring(0, 100)
  })
  activePicker.value = null
}

function insertLevelCard() {
  const selected = levelOptions.find(l => l.level === levelForm.level)
  if (!selected) return
  const privileges = levelForm.privilegesText.split('\n').filter(line => line.trim())
  if (privileges.length === 0) { toastMsg.value = '请至少填写一条权益'; setTimeout(() => toastMsg.value = '', 2000); return }
  editorRef.value?.insertLevelPrivilege({
    level: selected.level,
    levelName: selected.name,
    privileges,
    currentUserLevel: 0
  })
  activePicker.value = null
}

async function onCoverUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  try {
    const res: any = await uploadCommunityImage(files[0])
    const url = res?.url || res?.data?.url || res
    if (url) coverImage.value = url
  } catch { toastMsg.value = '封面上传失败'; setTimeout(() => toastMsg.value = '', 2000) }
  (e.target as HTMLInputElement).value = ''
}

function insertPaywall() {
  if (!paywallPrice.value || paywallPrice.value <= 0) { toastMsg.value = '请输入付费价格'; setTimeout(() => toastMsg.value = '', 2000); return }
  editorRef.value?.insertPaywall(paywallPrice.value, paywallPriceType.value)
  showPaywallModal.value = false; paywallPrice.value = 0
}

function insertMemberUnlock() {
  const levelId = memberUnlockLevel.value
  const name = memberLevels.value.find(l => l.id === levelId)?.name || `会员`
  editorRef.value?.insertMemberUnlock(levelId, name)
  showMemberUnlockModal.value = false; memberUnlockLevel.value = 1
}

function insertExpUnlock() {
  const level = expUnlockLevel.value
  const name = `Lv.${level}`
  editorRef.value?.insertExperienceUnlock(level, name)
  showExpUnlockModal.value = false; expUnlockLevel.value = 2
}

async function loadMyTitles() {
  try {
    const res: any = await fetchMyTitles()
    myTitles.value = (res.data || res || []).map((t: any) => ({ id: t.id, name: t.name }))
    if (myTitles.value.length > 0) titleUnlockId.value = myTitles.value[0].id
  } catch { myTitles.value = [] }
}

function insertTitleUnlock() {
  const title = myTitles.value.find(t => t.id === titleUnlockId.value)
  if (!title) return
  editorRef.value?.insertTitleUnlock(title.id, title.name)
  showTitleUnlockModal.value = false
}

async function loadAppList() {
  try {
    const res: any = await fetchAppList({ page: 1, pageSize: 200 })
    const list = Array.isArray(res) ? res : (res.list || res.data || [])
    appList.value = list; filteredAppList.value = list
  } catch {}
}
function filterApps() {
  const q = appSearchQuery.value.toLowerCase()
  filteredAppList.value = appList.value.filter((a: any) => a.name?.toLowerCase().includes(q) || a.category?.toLowerCase().includes(q))
}
function selectAppInline(app: any) {
  editorRef.value?.editor?.chain().focus().insertContent({
    type: 'paragraph', content: [{ type: 'text', text: ` [应用:${app.name}|${app.appId || app.id}|${app.description || app.category || ''}] `, marks: [{ type: 'bold' }] }]
  }).run()
  showAppSelector.value = false; appSearchQuery.value = ''
}

async function onImageUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  const urls: string[] = []
  for (const f of Array.from(files)) {
    try {
      const res: any = await uploadCommunityImage(f)
      const url = res?.url || res?.data?.url || res
      if (url) { urls.push(url) }
    } catch { toastMsg.value = '图片上传失败'; setTimeout(() => toastMsg.value = '', 2000) }
  }
  if (urls.length > 0) {
    const html = urls.map(u => `<img src="${u}"  loading="lazy" />`).join('')
    editorRef.value?.editor?.chain().focus().insertContent(html).run()
  }
  (e.target as HTMLInputElement).value = ''
}

function insertVote() {
  if (!voteForm.question.trim()) return
  editorRef.value?.insertVoteCard({
    question: voteForm.question,
    options: JSON.stringify(voteForm.options.filter((o: string) => o.trim())),
    maxSelect: voteForm.maxSelect
  })
  voteForm.question = ''; voteForm.options = ['', '']; voteForm.maxSelect = 1
  activePicker.value = null
}

async function loadGoodsList() {
  try {
    const res: any = await request.get({ url: '/api/mall/products', params: { status: 'published', pageSize: 200 } })
    const list = Array.isArray(res) ? res : (res.list || res.data || [])
    goodsList.value = list; filteredGoodsList.value = list
  } catch {}
}
function filterGoods() {
  const q = goodsSearch.value.toLowerCase()
  filteredGoodsList.value = goodsList.value.filter((a: any) => a.name?.toLowerCase().includes(q))
}
function selectGoods(product: any) {
  editorRef.value?.insertGoodsCard({
    name: product.name || '',
    price: Number(product.price) || 0,
    image: product.coverImage || product.image || '',
    link: `/appstore/mall-detail/${product.id}`
  })
  activePicker.value = null
  goodsSearch.value = ''
}

function insertAudio() {
  editorRef.value?.insertAudioBlock({ ...audioForm })
  audioForm.src = ''; audioForm.title = ''
  activePicker.value = null
}

function insertFile() {
  editorRef.value?.insertFileAttachment({ ...fileForm })
  fileForm.name = ''; fileForm.size = ''; fileForm.url = ''
  activePicker.value = null
}

function insertNotice() {
  editorRef.value?.insertNoticeBanner({ ...noticeForm })
  noticeForm.type = 'info'; noticeForm.content = ''
  activePicker.value = null
}

function insertUpdateLog() {
  editorRef.value?.insertUpdateLog({ ...updateLogForm, changes: updateLogForm.changes.split('\n').filter(Boolean) })
  updateLogForm.version = ''; updateLogForm.date = ''; updateLogForm.changes = ''
  activePicker.value = null
}

async function insertPassword() {
  editorRef.value?.insertPasswordUnlock({ passwordHash: passwordForm.password ? await hashPassword(passwordForm.password) : '', hint: passwordForm.hint, content: passwordForm.content })
  passwordForm.password = ''; passwordForm.hint = ''; passwordForm.content = ''
  activePicker.value = null
}

function insertGallery() {
  const imgs = galleryForm.images.filter((i: string) => i.trim())
  editorRef.value?.insertGalleryBlock({ images: JSON.stringify(imgs) })
  galleryForm.images = ['', '']
  activePicker.value = null
}

function insertVideo() {
  if (!videoForm.id.trim()) return
  editorRef.value?.insertVideoEmbed({ type: videoForm.type, id: videoForm.id.trim() })
  videoForm.url = ''; videoForm.type = ''; videoForm.id = ''
  activePicker.value = null
}

function onVideoUrlInput() {
  const result = parseVideoUrl(videoForm.url)
  if (result) {
    videoForm.type = result.type
    videoForm.id = result.id
  } else {
    videoForm.type = ''
    videoForm.id = ''
  }
}

function videoPlatformLabel(type: string) {
  const map: Record<string, string> = { youtube: 'YouTube', bilibili: 'B站', tencent: '腾讯视频', douyin: '抖音', kuaishou: '快手' }
  return map[type] || type
}

function applyTemplate(tpl: any) {
  const ed = editorRef.value?.editor
  if (!ed) return
  const currentContent = ed.getJSON()
  const hasContent = currentContent.content && currentContent.content.length > 0
  if (hasContent) {
    if (!confirm('当前内容将被模板覆盖，确定继续？')) return
  }
  ed.commands.setContent({
    type: 'doc',
    content: tpl.content
  })
  activePicker.value = null
}

function insertOriginal() {
  editorRef.value?.insertOriginalStatement({ ...originalForm })
  originalForm.author = ''; originalForm.license = 'CC BY 4.0'; originalForm.reprintRule = ''
  activePicker.value = null
}

function insertSourceQuote() {
  editorRef.value?.insertSourceQuote({ ...sourceQuoteForm })
  sourceQuoteForm.url = ''; sourceQuoteForm.author = ''; sourceQuoteForm.platform = ''; sourceQuoteForm.note = ''; sourceQuoteForm.quoteText = ''
  activePicker.value = null
}

function insertFollowUnlock() {
  editorRef.value?.insertFollowUnlock({ hint: followUnlockForm.hint })
  followUnlockForm.hint = ''
  activePicker.value = null
}

function insertCommentUnlock() {
  editorRef.value?.insertCommentUnlock({ minCommentCount: commentUnlockForm.minCommentCount })
  commentUnlockForm.minCommentCount = 1
  activePicker.value = null
}

async function handlePublish() {
  if (!form.title.trim()) { toastMsg.value = '请输入标题'; setTimeout(() => toastMsg.value = '', 2000); return }
  submitting.value = true
  try {
    const content = JSON.stringify(editorContent.value)
    const payload: any = {
      title: form.title, content, sectionId: form.sectionId,
      device: 'mobile', tags: JSON.stringify(selectedTags.value),
      topicIds: selectedTopicIds.value, userId: getUserId(),
      contentPermission: form.contentPermission, contentPrice: form.contentPrice,
      contentPriceType: form.contentPriceType, accessPassword: form.accessPassword,
      accessPasswordTips: form.accessPasswordTips, coverImage: coverImage.value
    }
    if (selectedTopicIds.value.length > 0) {
      payload.topicId = selectedTopicIds.value[0]
    }
    if (form.scheduledTime) {
      payload.scheduledTime = form.scheduledTime
    }
    if (form.autoHideAt) {
      payload.autoHideAt = form.autoHideAt
    }
    if (isEditMode.value) await updateCommunityPost(editPostId.value, payload)
    else await createCommunityPost(payload)
    toastMsg.value = isEditMode.value ? '更新成功' : '发布成功'
    setTimeout(() => router.back(), 800)
  } catch (e: any) {
    toastMsg.value = e.message || (isEditMode.value ? '更新失败' : '发布失败')
    setTimeout(() => toastMsg.value = '', 2000)
  }
  finally { submitting.value = false }
}

function onHashtagClick(tag: string) {
  const topic = availableTopics.value.find((t: any) => t.name === tag)
  if (topic) {
    router.push(`/community/topic/${topic.id}`)
  }
}

function confirmScheduled() {
  form.scheduledTime = scheduledTimeInput.value
  scheduledTimeInput.value = ''
  showScheduledPicker.value = false
}

function confirmAutoHide() {
  form.autoHideAt = autoHideTimeInput.value
  autoHideTimeInput.value = ''
  showAutoHidePicker.value = false
}

function formatScheduledLabel(dt: string): string {
  if (!dt) return ''
  const d = new Date(dt)
  return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`
}
</script>

<style scoped>
.editor-root { display:flex; flex-direction:column; height:100vh; height:100dvh; background:#fff; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
.topbar { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; padding-top:calc(10px + env(safe-area-inset-top,0px)); background:#fff; border-bottom:1px solid #f0f0f0; flex-shrink:0; z-index:10; }
.tb-back { background:none; border:none; padding:4px; cursor:pointer; color:#333; border-radius:8px; transition:background .15s; }
.tb-back:active { background:#f0f0f5; }
.tb-title { font-size:17px; font-weight:600; color:#1a1a1a; }
.tb-publish { background:linear-gradient(135deg,#508DFF,#3b6fd4); color:#fff; border:none; padding:7px 20px; border-radius:20px; font-size:14px; font-weight:600; cursor:pointer; transition:opacity .15s,transform .1s; }
.tb-publish:active { transform:scale(.96); }
.tb-publish:disabled { background:#d1d5db; cursor:not-allowed; transform:none; }
.editor-main { flex:1; overflow-y:auto; display:flex; flex-direction:column; }
.title-section { padding:14px 16px 0; }
.title-input { width:100%; font-size:20px; font-weight:700; border:none; outline:none; resize:none; line-height:1.5; color:#1a1a1a; }
.title-input::placeholder { color:#c7c7cc; }
.edit-toolbar { display:flex; flex-wrap:wrap; gap:6px; padding:6px 12px; border-bottom:1px solid #f5f5f5; }
.et-btn { background:#f7f7fa; border:none; border-radius:8px; padding:8px 10px; cursor:pointer; display:flex; align-items:center; justify-content:center; color:#666; flex-shrink:0; transition:background .15s,color .15s; }
.et-btn:active { background:#e8e8f0; color:#508DFF; }
.et-select { padding:7px 8px; border:1px solid #e8e8ed; border-radius:8px; font-size:13px; background:#fff; outline:none; }
.editor-area { flex:1; display:flex; flex-direction:column; min-height:200px; padding:0 12px 56px; }
.bottom-bar { position:fixed; bottom:0; left:0; right:0; display:flex; align-items:center; gap:2px; padding:6px 10px; padding-bottom:calc(6px + env(safe-area-inset-bottom,0px)); background:rgba(255,255,255,.96); backdrop-filter:blur(10px); border-top:1px solid rgba(0,0,0,.06); box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:100; }
.bb-btn { background:none; border:none; padding:8px; cursor:pointer; color:#8e8e93; display:flex; align-items:center; justify-content:center; border-radius:8px; transition:all .15s; }
.bb-btn:active { background:#f2f2f7; color:#508DFF; transform:scale(.94); }
.bb-divider { width:1px; height:22px; background:rgba(0,0,0,.06); margin:0 8px; }
.bb-select { padding:6px 28px 6px 10px; border:1px solid rgba(0,0,0,.08); border-radius:8px; font-size:12px; background:#f9f9fb url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23999' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat right 8px center; color:#555; outline:none; margin-left:auto; appearance:none; }
.meta-bar { padding:0 16px 8px; }
.tp-tags { display:flex; flex-wrap:wrap; gap:6px; align-items:center; }
.tp-tag { display:inline-flex; align-items:center; gap:2px; padding:5px 12px; background:#edf2ff; color:#508DFF; border-radius:14px; font-size:12px; font-weight:500; cursor:pointer; transition:background .15s; }
.tp-tag-green { background:#ecfdf5; color:#059669; }
.tp-tag:active { background:#dbe4ff; }
.tp-tag-green:active { background:#d1fae5; }
.tp-sep { color:#ddd; font-size:12px; margin:0 2px; }
.tp-add-btn { background:none; border:1px dashed #508DFF; color:#508DFF; border-radius:14px; padding:4px 12px; font-size:12px; cursor:pointer; }
.tp-add-btn:active { background:#edf2ff; }
.tp-item { display:flex; align-items:center; gap:8px; padding:10px 12px; cursor:pointer; border-radius:6px; }
.tp-item:active { background:#f0f0f0; }
.tp-item-on { background:#edf2ff; }
.tp-item-icon { width:20px; text-align:center; font-size:14px; }
.tp-item-name { flex:1; font-size:14px; font-weight:500; }
.tp-item-count { font-size:11px; color:#adb5bd; }
.bb-btn-active { display:none; }
.bb-spacer { flex:1; }
.bb-schedule-wrap { position:relative; display:flex; align-items:center; }
.scheduled-chip { position:absolute; bottom:calc(100% + 10px); right:-4px; display:flex; align-items:center; gap:4px; padding:6px 10px; background:#fff; border:1px solid #e8e8ed; border-radius:10px; font-size:12px; color:#D48806; white-space:nowrap; box-shadow:0 4px 12px rgba(0,0,0,.1); cursor:pointer; z-index:10; animation:chipIn .2s ease; }
.scheduled-chip::after { content:''; position:absolute; bottom:-5px; right:14px; width:10px; height:10px; background:#fff; border-right:1px solid #e8e8ed; border-bottom:1px solid #e8e8ed; transform:rotate(45deg); }
@keyframes chipIn { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
.bb-btn-schedule { position:relative; }
.bb-btn-schedule.is-set { color:#D48806; background:rgba(212,136,6,.08); }
.bb-btn-schedule.is-set::after { content:''; position:absolute; top:6px; right:6px; width:6px; height:6px; background:#D48806; border-radius:50%; }
.app-item { display:flex; align-items:center; gap:10px; padding:10px 0; border-bottom:1px solid #f5f5f5; cursor:pointer; }
.app-item-icon { width:36px; height:36px; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:14px; font-weight:600; overflow:hidden; flex-shrink:0; }
.app-item-img { width:100%; height:100%; object-fit:cover; }
.toast-bar { position:fixed; top:56px; left:16px; right:16px; z-index:200; padding:10px 16px; border-radius:8px; font-size:13px; text-align:center; background:#fef2f2; color:#dc2626; border:1px solid #fecaca; }
.autosave-indicator { position:fixed; top:56px; left:16px; right:16px; z-index:199; padding:8px 16px; border-radius:8px; font-size:12px; text-align:center; background:#ecfdf5; color:#059669; border:1px solid #a7f3d0; }
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.4); z-index:500; display:flex; align-items:flex-end; }
.modal-sheet { background:#fff; width:100%; max-height:70vh; overflow-y:auto; border-radius:16px 16px 0 0; padding:20px 16px 30px; }
.ms-title { font-size:17px; font-weight:700; margin-bottom:16px; text-align:center; }
.ms-sub { font-size:12px; color:#999; margin-bottom:12px; text-align:center; }
.ms-empty { font-size:13px; color:#999; text-align:center; padding:20px 0; }
.ms-input { width:100%; padding:10px 12px; border:1px solid #e0e0e0; border-radius:8px; font-size:14px; margin-bottom:10px; outline:none; box-sizing:border-box; }
.ms-input:focus { border-color:#508DFF; }
.ms-opt-row { display:flex; gap:6px; align-items:center; }
.ms-opt-row .ms-input { flex:1; }
.ms-del { background:none; border:none; color:#ef4444; font-size:20px; cursor:pointer; padding:4px 8px; }
.ms-add { background:none; border:1px dashed #508DFF; color:#508DFF; border-radius:6px; padding:8px; width:100%; font-size:13px; cursor:pointer; margin-bottom:10px; }
.ms-actions { display:flex; gap:10px; margin-top:16px; }
.ms-cancel { flex:1; padding:12px; background:#f5f5f5; border:none; border-radius:8px; font-size:15px; cursor:pointer; }
.tpl-item { display:flex; align-items:center; gap:12px; padding:12px; border:1px solid #eee; border-radius:8px; cursor:pointer; margin-bottom:8px; }
.tpl-item:active { background:#f0f4ff; border-color:#508DFF; }
.tpl-icon { width:40px; height:40px; background:#f5f5f5; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0; }
.tpl-name { font-size:14px; font-weight:600; color:#333; }
.tpl-desc { font-size:12px; color:#999; margin-top:2px; }
.ms-confirm { flex:1; padding:12px; background:#508DFF; color:#fff; border:none; border-radius:8px; font-size:15px; cursor:pointer; }
</style>
