<template>
  <div class="page">
    <main class="main" v-if="product" ref="mainRef">
      <div class="nav-bar" :class="{ scrolled }">
        <button class="nav-btn" @click="$router.back()">
          <svg viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <span class="nav-title" v-show="scrolled">{{ product.name }}</span>
        <button class="nav-btn fav-btn" @click="toggleFavorite">
          <svg viewBox="0 0 24 24" fill="none"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" :fill="favorited ? '#FF4757' : 'none'" :stroke="favorited ? '#FF4757' : 'currentColor'" stroke-width="1.8"/></svg>
        </button>
      </div>

      <div class="hero-wrap">
        <div class="hero">
          <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="hero-img"  loading="lazy" />
          <div v-else class="hero-fb">
            <svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="2"/><path d="M16 24l5 5 11-10" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
        </div>
        <div class="hero-dots" v-if="product.images && product.images.length > 1">
          <span v-for="(img, i) in product.images" :key="img" class="dot" :class="{ on: activeImg === i }" @click="activeImg = i" />
        </div>
      </div>

      <div class="price-card">
        <div class="price-main">
          <span class="price-unit">R币</span>
          <span class="price-val">{{ displayPrice }}</span>
          <span v-if="product.originalPrice > product.price" class="price-old">R币{{ product.originalPrice }}</span>
        </div>
        <div class="price-sub">
          <span class="subsidy-chip">
            <svg viewBox="0 0 14 14" fill="none"><path d="M7 1l1.8 3.6 4 .6-2.9 2.8.7 4L7 10.2l-3.6 1.9.7-4L1.2 5.2l4-.6L7 1z" fill="#FF5722"/></svg>
            官方补贴
          </span>
          <span class="sold-info">已售{{ product.salesCount || 0 }}</span>
        </div>
        <div class="countdown-bar" v-if="countdownHasEnd && !countdownExpired">
          <svg viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="#FF5722" stroke-width="1.2"/><path d="M7 4v3l1.5 1.5" stroke="#FF5722" stroke-width="1" stroke-linecap="round"/></svg>
          <span>限时优惠 {{ countdownStr }}</span>
        </div>
      </div>

      <div class="info-card">
        <div class="tag-row" v-if="productTags.length">
          <span v-for="(t, i) in productTags" :key="t" class="tag">{{ t }}</span>
        </div>
        <h1 class="title">{{ product.name }}<span v-if="product.subtitle" class="subtitle"> / {{ product.subtitle }}</span></h1>
        <div class="service-tags" v-if="productServices.length">
          <span v-for="(s, i) in productServices" :key="s" class="service-tag">{{ s }}</span>
        </div>
      </div>

      <div class="action-grid">
        <div class="action-card" v-if="afterSalesText" @click="goAfterSales">
          <div class="ac-icon ac-icon-warm">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 22s8-4.5 8-11.5V5l-8-3-8 3v5.5C4 17.5 12 22 12 22z" stroke="currentColor" stroke-width="2"/></svg>
          </div>
          <div class="ac-text">
            <div class="ac-title">售后服务</div>
            <div class="ac-desc">{{ afterSalesText }}</div>
          </div>
          <svg class="ac-arrow" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2"/></svg>
        </div>
        <div class="action-card" v-if="groupedSpecs.length > 0" @click="showPaySheet = true">
          <div class="ac-icon ac-icon-accent">
            <svg viewBox="0 0 24 24" fill="none"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" stroke="currentColor" stroke-width="2"/></svg>
          </div>
          <div class="ac-text">
            <div class="ac-title">已选规格</div>
            <div class="ac-desc">{{ currentOptionName }}</div>
          </div>
          <svg class="ac-arrow" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2"/></svg>
        </div>
        <div class="action-card" v-if="purchaseLimitText">
          <div class="ac-icon ac-icon-cool">
            <svg viewBox="0 0 24 24" fill="none"><rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" stroke-width="2"/><path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" stroke-width="2"/></svg>
          </div>
          <div class="ac-text">
            <div class="ac-title">购买限制</div>
            <div class="ac-desc">{{ purchaseLimitText }}</div>
          </div>
        </div>
      </div>

      <div class="section-card" v-if="productParams.length">
        <div class="section-head">
          <div class="section-indicator" />
          <span class="section-label">商品参数</span>
        </div>
        <div class="param-list">
          <div v-for="(p, i) in productParams" :key="i" class="param-item">
            <span class="param-key">{{ p.name }}</span>
            <span class="param-val">{{ p.value }}</span>
          </div>
        </div>
      </div>

      <div class="section-card review-wrapper">
        <div class="section-head">
          <div class="section-indicator accent" />
          <span class="section-label">商品评价</span>
          <span class="section-more" @click="$router.push('/appstore/mall-reviews/' + product.id)">全部 {{ reviewTotal }} &gt;</span>
        </div>

        <div class="review-stat" v-if="reviews.length > 0" @click="$router.push('/appstore/mall-reviews/' + product.id)">
          <div class="review-score">{{ avgRating }}</div>
          <div class="review-stars">
            <svg v-for="s in 5" :key="s" class="star" :class="{ on: s <= (parseFloat(avgRating) || 0) }" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
          </div>
          <div class="review-label">{{ ratingLabel }}</div>
        </div>

        <div class="review-list" v-if="reviews.length > 0">
          <div v-for="r in reviews" :key="r.id" class="review-item">
            <div class="review-user" :style="{ background: avatarColor(r.userName || '?') }">{{ (r.userName || '?')[0] }}</div>
            <div class="review-body">
              <div class="review-name-row">
                <span class="review-name">{{ r.userName || '匿名用户' }}</span>
                <div class="review-stars-sm">
                  <svg v-for="s in 5" :key="s" class="star-sm" :class="{ on: s <= (r.rating || 0) }" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
                </div>
              </div>
              <div class="review-content" v-if="r.content">{{ r.content }}</div>
              <div class="review-imgs" v-if="r.images && r.images.length">
                <img v-for="(img, idx) in r.images.slice(0, 3)" :key="idx" :src="img" class="review-img"  loading="lazy" />
              </div>
              <div class="review-footer">
                <span class="review-time">{{ relativeTime(r.createTime) }}</span>
                <span class="review-like" @click="toggleLike(r)">
                  <svg viewBox="0 0 16 16" fill="none" :class="{ liked: reviewLikes[String(r.id)] }"><path d="M4.5 14H2.67A1.33 1.33 0 011.33 12.67V8a1.33 1.33 0 011.34-1.33h2m5.66-2V2.67A2 2 0 008.33.67L5.67 6.67v7.33h7.52a1.33 1.33 0 001.33-1.13l.92-6A1.33 1.33 0 0014.12 5.3H9.5z" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                  {{ r.likeCount || 0 }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div class="review-empty" v-else>暂无评价，快来第一个评价吧</div>

        <div class="review-write" v-if="reviewWritePerm.canReview" @click="showReviewEditor = true">
          <svg viewBox="0 0 20 20" fill="none"><path d="M13.33 3.33a1.41 1.41 0 012 2L8 12.67 5.33 13.33 6 10.67 13.33 3.33z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          写评价
        </div>
      </div>

      <div class="section-card" v-if="product.description">
        <div class="section-head">
          <div class="section-indicator alt" />
          <span class="section-label">商品详情</span>
        </div>
        <div class="detail-content" v-html="sanitizeHtml(product.description)" />
      </div>

      <div class="bottom-spacer" />
    </main>

    <div v-else-if="loading" class="loading"><div class="spinner" /></div>
    <div v-else class="empty">商品不存在或已下架</div>

    <footer class="footer" v-if="product">
      <div class="footer-icons">
        <button class="fi-btn" @click="goShop">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>店铺</span>
        </button>
        <button class="fi-btn" @click="openChat">
          <svg viewBox="0 0 24 24" fill="none"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>客服</span>
        </button>
        <button class="fi-btn" @click="gotoCart">
          <svg viewBox="0 0 24 24" fill="none"><circle cx="9" cy="21" r="1" fill="currentColor"/><circle cx="20" cy="21" r="1" fill="currentColor"/><path d="M1 1h4l2.4 12.2a2 2 0 002 1.8h9.7a2 2 0 002-1.8l1.5-8H6" stroke="currentColor" stroke-width="1.8" fill="none"/></svg>
          <span>购物车</span>
        </button>
      </div>
      <button class="footer-cart" :disabled="countdownExpired" @click="addToCart">{{ countdownExpired ? '已截止' : '加入购物车' }}</button>
      <button class="footer-buy" :disabled="countdownExpired" @click="buyNow">{{ countdownExpired ? '已截止' : '立即购买' }}</button>
    </footer>

    <!-- 购买弹窗 -->
    <div class="sheet-overlay" v-if="showPaySheet" @click.self="hidePaySheet">
      <div class="buy-sheet">
        <div class="sheet-tips">
          <div v-for="(tip, ti) in sheetTips" :key="ti" class="tip-item">
            <svg class="tip-icon" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#4CAF50" stroke-width="2"/><path d="M7 12l3 3 7-7" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <span>{{ tip }}</span>
          </div>
          <svg class="tip-close" @click="hidePaySheet" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#999" stroke-width="2" stroke-linecap="round"/></svg>
        </div>

        <div class="sheet-divider" />

        <div class="sheet-product">
          <div class="sheet-product-img-wrap">
            <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="sheet-product-img"  loading="lazy" />
            <div v-else class="sheet-product-img sheet-product-fb">{{ product.name[0] }}</div>
          </div>
          <div class="sheet-product-info">
            <div class="sheet-product-name">{{ product.name }}</div>
            <div class="sheet-product-price">R币 <b>{{ displayPrice }}</b></div>
            <div class="sheet-tag-row" v-if="productTags.length">
              <span v-for="(t, i) in productTags" :key="t" class="sheet-tag">{{ t }}</span>
            </div>
          </div>
        </div>

        <div class="sheet-section" v-if="groupedSpecs.length > 0">
          <div class="sheet-section-title">规格</div>
          <div class="sheet-spec-tabs">
            <span v-for="(spec, si) in groupedSpecs" :key="si" class="sheet-spec-tab" :class="{ active: selectedSpecIndex === si }" @click="selectedSpecIndex = si; selectedOptIndex = 0">{{ spec.name }}</span>
          </div>
        </div>

        <div v-if="currentPackages.length" class="sheet-section">
          <div class="sheet-section-title">套餐</div>
          <div class="sheet-opt-grid">
            <div v-for="(opt, oi) in currentPackages" :key="oi" class="sheet-opt-item" :class="{ active: selectedOptIndex === oi }" @click="selectedOptIndex = oi">
              <div class="sheet-opt-item-name">{{ opt.name || ('套餐' + (oi + 1)) }}</div>
              <div class="sheet-opt-item-price">R币{{ opt.price || 0 }}</div>
            </div>
          </div>
        </div>

        <div class="sheet-section">
          <div class="sheet-section-title">数量</div>
          <div class="qty-stepper">
            <button class="qty-btn" @click="qty > 1 && qty--" :class="{ disabled: qty <= 1 }">-</button>
            <span class="qty-val">{{ qty }}</span>
            <button class="qty-btn" @click="qty++" :class="{ disabled: qty >= maxStock }">+</button>
          </div>
        </div>

        <div class="sheet-section" v-if="product.customFields && product.customFields.length > 0">
          <div class="sheet-section-title">填写信息</div>
          <div class="custom-fields">
            <div v-for="(field, fi) in product.customFields" :key="fi" class="custom-field-item">
              <div class="custom-field-label">{{ field.name || field.label || ('字段' + (fi + 1)) }}<span v-if="field.required !== false" class="custom-field-required">*</span></div>
              <input v-if="(field.type || 'text') === 'text'" v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]" class="custom-field-input" :placeholder="field.placeholder || '请输入'" />
              <textarea v-else-if="(field.type || 'text') === 'textarea'" v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]" class="custom-field-textarea" :placeholder="field.placeholder || '请输入'" rows="3" />
              <select v-else-if="(field.type || 'text') === 'select'" v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]" class="custom-field-select"><option value="">请选择</option><option v-for="(opt, oi2) in (field.options || [])" :key="oi2" :value="typeof opt === 'string' ? opt : opt.value">{{ typeof opt === 'string' ? opt : (opt.label || opt.value) }}</option></select>
              <input v-else v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]" class="custom-field-input" :placeholder="field.placeholder || '请输入'" />
            </div>
          </div>
        </div>

        <div class="sheet-btns">
          <button class="sheet-btn-submit" @click="confirmPayFromSheet" :disabled="paying">提交订单</button>
        </div>
      </div>
    </div>

    <!-- 确认订单弹窗保持不变 -->
    <div class="confirm-overlay" v-if="showConfirmSheet" @click.self="showConfirmSheet = false">
      <div class="confirm-sheet">
        <div class="confirm-header">
          <span class="confirm-title">确认订单</span>
          <svg class="confirm-close" @click="showConfirmSheet = false" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#999" stroke-width="2" stroke-linecap="round"/></svg>
        </div>
        <div class="confirm-body">
          <div class="confirm-section">
            <div class="confirm-section-title">商品信息</div>
            <div class="confirm-product">
              <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="confirm-product-img"  loading="lazy" />
              <div v-else class="confirm-product-img confirm-product-fb">{{ product.name[0] }}</div>
              <div class="confirm-product-info">
                <div class="confirm-product-name">{{ product.name }}</div>
                <div v-if="confirmOptionName" class="confirm-product-opt">{{ confirmOptionName }}</div>
                <div class="confirm-product-price">R币{{ confirmPrice }} x {{ confirmQty }}</div>
              </div>
            </div>
          </div>
          <div class="confirm-section" v-if="confirmCustomFields && Object.keys(confirmCustomFields).length > 0">
            <div class="confirm-section-title">填写信息</div>
            <div class="confirm-field-list"><div v-for="(val, key) in confirmCustomFields" :key="key" class="confirm-field-row"><span class="confirm-field-key">{{ key }}</span><span class="confirm-field-val">{{ val }}</span></div></div>
          </div>
          <div class="confirm-section" v-if="product.productType === 'physical'">
            <div class="confirm-section-title">收货地址</div>
            <div v-if="loadingAddresses" style="text-align:center;padding:16px;color:#9ca3af">加载地址中...</div>
            <div v-else-if="addresses.length === 0" style="text-align:center;padding:16px">
              <div style="color:#9ca3af;font-size:13px;margin-bottom:8px">暂无收货地址</div>
              <button class="add-addr-btn" @click="router.push('/appstore/addresses')">添加地址</button>
            </div>
            <select v-else v-model="selectedAddressIndex" class="confirm-coupon-select">
              <option v-for="(addr, ai) in addresses" :key="ai" :value="ai">{{ addr.name }} {{ addr.phone }} {{ addr.province }}{{ addr.city }}{{ addr.district }}{{ addr.detail }}</option>
            </select>
            <div v-if="addresses.length > 0" style="text-align:right;margin-top:6px">
              <button class="add-addr-btn" @click="router.push('/appstore/addresses')">管理地址</button>
            </div>
          </div>
          <div class="confirm-section">
            <div class="confirm-section-title">优惠券</div>
            <select v-model="selectedCouponIndex" class="confirm-coupon-select"><option :value="-1">不使用优惠券</option><option v-for="(c, ci) in filteredCoupons" :key="c.id" :value="ci">{{ c.name }} (-{{ Number(c.value || 0).toFixed(2) }})</option></select>
          </div>
          <div class="confirm-section">
            <div class="confirm-section-title">支付方式</div>
            <div class="confirm-pay-methods"><div v-for="pm in confirmAvailablePayMethods" :key="pm.value" class="confirm-pay-item" :class="{ active: confirmPayMethod === pm.value }" @click="confirmPayMethod = pm.value">{{ pm.label }}</div></div>
          </div>
          <div class="confirm-section">
            <div class="confirm-price-breakdown">
              <div class="confirm-price-row"><span class="confirm-price-label">商品总价</span><span class="confirm-price-val">{{ confirmPayUnit }}{{ confirmSubtotal.toFixed(2) }}</span></div>
              <div class="confirm-price-row" v-if="confirmCoupon"><span class="confirm-price-label">优惠券抵扣</span><span class="confirm-price-val discount">-{{ confirmPayUnit }}{{ Number(confirmCoupon.value || 0).toFixed(2) }}</span></div>
              <div class="confirm-price-divider" />
              <div class="confirm-price-row total"><span class="confirm-price-label">合计</span><span class="confirm-price-val total-val">{{ confirmPayUnit }}{{ confirmFinalAmount.toFixed(2) }}</span></div>
            </div>
          </div>
        </div>
        <div class="confirm-footer">
          <button class="confirm-btn-submit" @click="doPayOrder" :disabled="paying">{{ paying ? '支付中...' : ('立即支付 ' + confirmPayUnit + confirmFinalAmount.toFixed(2)) }}</button>
        </div>
      </div>
    </div>

    <!-- 写评价弹窗保持不变 -->
    <div class="review-overlay" v-if="showReviewEditor" @click.self="showReviewEditor = false">
      <div class="review-editor">
        <div class="review-editor-header"><span class="review-editor-title">写评价</span><svg class="review-editor-close" @click="showReviewEditor = false" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></div>
        <div class="review-editor-body">
          <div class="review-editor-stars"><span class="review-editor-label">评分</span><div class="review-editor-stars-row"><svg v-for="s in 5" :key="s" class="review-star-lg" :class="{ on: s <= reviewForm.rating }" @click="reviewForm.rating = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg></div><span class="review-star-text">{{ reviewForm.rating >= 5 ? '超赞' : reviewForm.rating >= 4 ? '很棒' : reviewForm.rating >= 3 ? '不错' : reviewForm.rating >= 2 ? '一般' : '很差' }}</span></div>
          <div class="review-dim-stars"><div class="review-dim-row" v-for="dim in reviewDims" :key="dim.key"><span class="review-dim-label">{{ dim.label }}</span><div class="review-dim-stars-row"><svg v-for="s in 5" :key="s" class="review-dim-star" :class="{ on: s <= dim.model.value }" @click="dim.model.value = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg></div></div></div>
          <div class="review-editor-field"><textarea v-model="reviewForm.content" class="review-editor-textarea" placeholder="分享你的使用感受吧..." maxlength="500" rows="4" /><span class="review-editor-count">{{ reviewForm.content.length }}/500</span></div>
          <div class="review-editor-field"><span class="review-editor-label">图片 ({{ reviewForm.images.length }}/3)</span><div class="review-editor-imgs"><div v-for="(img, idx) in reviewForm.images" :key="img" class="review-editor-img-wrap"><img :src="img" class="review-editor-img"  loading="lazy" /><div class="review-editor-img-del" @click="reviewForm.images.splice(idx, 1)"><svg viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg></div></div><div v-if="reviewForm.images.length < 3" class="review-editor-add" @click="triggerReviewUpload"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg><input ref="reviewImgInput" type="file" accept="image/*" style="display:none" @change="onReviewImgPicked" /></div></div></div>
        </div>
        <div class="review-editor-footer"><button class="review-editor-submit" @click="submitReview" :disabled="reviewSubmitting || reviewForm.rating === 0">{{ reviewSubmitting ? '提交中...' : '提交评价' }}</button></div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, toRef } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { sanitizeHtml } from '@/utils/ui/sanitize'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const product = ref<any>(null)
const loading = ref(true)
const favorited = ref(false)
const favLoading = ref(false)
const reviews = ref<any[]>([])
const reviewTotal = ref(0)
const reviewWritePerm = ref({ canReview: false, hasPurchased: false, hasReviewed: false, orderId: 0 })
const reviewLikes = reactive<Record<string, boolean>>({})
const showReviewEditor = ref(false)
const reviewSubmitting = ref(false)
const reviewImgInput = ref<HTMLInputElement | null>(null)
const reviewForm = reactive({ rating: 0, content: '', images: [] as string[], dimProduct: 5, dimService: 5, dimLogistics: 5 })
const reviewDims = [
  { key: 'dimProduct', label: '商品', model: toRef(reviewForm, 'dimProduct') },
  { key: 'dimService', label: '服务', model: toRef(reviewForm, 'dimService') },
  { key: 'dimLogistics', label: '物流', model: toRef(reviewForm, 'dimLogistics') }
]
const showPaySheet = ref(false)
const paying = ref(false)
const selectedSpecIndex = ref(0)
const selectedOptIndex = ref(0)
const qty = ref(1)
const payMethod = ref('balance')
const userCustomFieldValues = ref<Record<string, string>>({})
const confirmPayMethod = ref('balance')
const confirmCoupons = ref<any[]>([])
const selectedCouponIndex = ref(-1)
const showConfirmSheet = ref(false)
const countdownExpired = ref(false)
const countdownHasEnd = ref(false)
const countdownDays = ref(0)
const countdownHours = ref(0)
const countdownMinutes = ref(0)
const countdownSeconds = ref(0)
const scrolled = ref(false)
const mainRef = ref<HTMLElement | null>(null)
const activeImg = ref(0)
const sheetTips = ['支持7天无理由', '官方正品保证', '极速退款']

const countdownStr = computed(() => {
  if (countdownExpired.value) return '已截止'
  if (!countdownHasEnd.value) return '活动进行中'
  return `${countdownDays.value}天${String(countdownHours.value).padStart(2, '0')}小时${String(countdownMinutes.value).padStart(2, '0')}分${String(countdownSeconds.value).padStart(2, '0')}秒`
})

function updateCountdown() {
  if (!product.value?.saleEndTime) { countdownHasEnd.value = false; countdownExpired.value = false; return }
  countdownHasEnd.value = true
  const end = new Date(product.value.saleEndTime).getTime()
  const diff = end - Date.now()
  if (diff <= 0) { countdownExpired.value = true; return }
  countdownExpired.value = false
  countdownDays.value = Math.floor(diff / 86400000)
  countdownHours.value = Math.floor((diff % 86400000) / 3600000)
  countdownMinutes.value = Math.floor((diff % 3600000) / 60000)
  countdownSeconds.value = Math.floor((diff % 60000) / 1000)
}

function onScroll() {
  const el = mainRef.value
  if (el) scrolled.value = el.scrollTop > 160
}

onMounted(async () => {
  updateCountdown()
  const timer = setInterval(() => { if (countdownHasEnd.value && !countdownExpired.value) updateCountdown() }, 1000)
  onUnmountedDirect(() => clearInterval(timer))
  await loadProduct()
  updateCountdown()
  await loadReviews()
  await loadCoupons()
})

onUnmountedDirect(() => {})

function onUnmountedDirect(fn: () => void) {
  if (typeof onUnmounted === 'function') { try { onUnmounted(fn) } catch {} }
}

const loadProduct = async () => {
  try {
    const id = route.params.id as string
    product.value = await request.get({ url: `/api/mall/products/${id}` })
    await checkFavStatus()
  } finally { loading.value = false }
}

const checkFavStatus = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/favorites', showErrorMessage: false })
    favorited.value = (res || []).some((f: any) => f.productId === Number(product.value?.id))
  } catch {}
}

const toggleFavorite = async () => {
  if (favLoading.value) return
  favLoading.value = true
  try {
    await request.post({ url: `/api/mall/favorites/${product.value.id}`, data: {} })
    favorited.value = !favorited.value
  } catch {}
  favLoading.value = false
}

const goAfterSales = () => { router.push(`/appstore/mall-after-sales?productId=${product.value.id}`) }

const groupedSpecs = computed(() => {
  const opts = product.value?.options || []
  const map = new Map<string, any[]>()
  opts.forEach((o: any) => { const key = o.specName || ''; if (!map.has(key)) map.set(key, []); map.get(key)!.push(o) })
  return Array.from(map.entries()).map(([name, packages]) => ({ name: name || '默认规格', packages }))
})

const currentPackages = computed(() => { const spec = groupedSpecs.value[selectedSpecIndex.value]; return spec?.packages || [] })
const selectedOption = computed(() => currentPackages.value[selectedOptIndex.value] || null)

const maxStock = computed(() => {
  const optStock = selectedOption.value?.stock
  const prodStock = product.value?.stock
  const optValid = optStock && optStock > 0
  const prodValid = prodStock && prodStock > 0
  if (optValid && prodValid) return Math.min(optStock, prodStock)
  if (optValid) return optStock
  if (prodValid) return prodStock
  return Infinity
})

const displayPrice = computed(() => { const opt = selectedOption.value; return opt ? (opt.price || 0) : (product.value?.price || 0) })

const currentOptionName = computed(() => {
  const opt = selectedOption.value; if (opt) return opt.name || ('套餐' + (selectedOptIndex.value + 1))
  const spec = groupedSpecs.value[selectedSpecIndex.value]; if (spec?.packages?.[0]) return spec.packages[0].name || '套餐1'
  return '默认'
})

const selectedOptionName = computed(() => { const opt = selectedOption.value; return opt ? (opt.name || ('套餐' + (selectedOptIndex.value + 1))) : '' })
const productTags = computed(() => { const tags = product.value?.tags || []; return Array.isArray(tags) ? tags : [] })
const productServices = computed(() => { const services = product.value?.services || []; return Array.isArray(services) ? services : [] })

const afterSalesText = computed(() => {
  const cfg = product.value?.afterSalesConfig; if (!cfg) return ''
  const parts: string[] = []
  if (cfg.enableRefund) parts.push('支持退款')
  if (cfg.enableReturn) parts.push('支持退货')
  if (cfg.enablePrice) parts.push('支持保价')
  if (cfg.validDays && (cfg.enableRefund || cfg.enableReturn)) parts.push(`有效期${cfg.validDays}天`)
  return parts.join(' · ') || '不支持退款'
})

const purchaseLimitText = computed(() => {
  const limits = product.value?.purchaseLimitConfig || []; if (!limits.length) return ''
  return limits.map((l: any) => {
    if (l.type === 'global') return `每用户限购${l.limit}件`
    if (l.type === 'membership') return `会员限购${l.limit}件`
    if (l.type === 'verified') return `认证用户限购${l.limit}件`
    return `限购${l.limit}件`
  }).join('、')
})

const productParams = computed(() => { const params = product.value?.productParams || []; return Array.isArray(params) ? params : [] })

const avgRating = computed(() => {
  if (!reviews.value.length) return '0.0'
  const sum = reviews.value.reduce((s: number, r: any) => s + (r.rating || 0), 0)
  return (sum / reviews.value.length).toFixed(1)
})

const ratingLabel = computed(() => {
  const r = parseFloat(avgRating.value)
  if (r >= 4.5) return '很棒'; if (r >= 3) return '不错'; return '一般'
})

const loadReviews = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/reviews', params: { productId: product.value.id, pageSize: 3 } })
    reviews.value = res?.list || []; reviewTotal.value = res?.total || res?.list?.length || 0
    for (const r of reviews.value) reviewLikes[String(r.id)] = !!r.liked
  } catch {}
  loadReviewPerm()
}

const loadReviewPerm = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/reviews/check', params: { productId: product.value.id } })
    reviewWritePerm.value = res || { canReview: false, hasPurchased: false, hasReviewed: false, orderId: 0 }
  } catch {}
}

const colorPool = ['#FF6B6B', '#FFA726', '#66BB6A', '#42A5F5', '#AB47BC', '#EF5350', '#26C6DA', '#7E57C2', '#EC407A', '#5C6BC0']
const avatarColor = (name: string) => colorPool[(name || '?').charCodeAt(0) % colorPool.length]

const relativeTime = (t: string) => {
  if (!t) return ''
  const diff = Date.now() - new Date(t).getTime(); const minutes = Math.floor(diff / 60000); const hours = Math.floor(diff / 3600000); const days = Math.floor(diff / 86400000); const months = Math.floor(days / 30)
  if (months > 0) return `${months}个月前`; if (days > 0) return `${days}天前`; if (hours > 0) return `${hours}小时前`; if (minutes > 0) return `${minutes}分钟前`; return '刚刚'
}

const toggleLike = async (review: any) => {
  const key = String(review.id); const liked = !!reviewLikes[key]; const action = liked ? 'unlike' : 'like'
  try {
    const res: any = await request.put({ url: `/api/mall/reviews/${review.id}/like`, data: { action } })
    review.likeCount = res?.likeCount ?? review.likeCount; reviewLikes[key] = res?.liked ?? !liked
  } catch {}
}

const triggerReviewUpload = () => { reviewImgInput.value?.click() }

const onReviewImgPicked = async (e: Event) => {
  const input = e.target as HTMLInputElement; const file = input?.files?.[0]; if (!file) return
  const fd = new FormData(); fd.append('file', file)
  try {
    const res: any = await request.post({ url: '/api/upload/file', data: fd })
    const url = res?.url || res?.data?.url || res?.data || ''; if (url) reviewForm.images.push(url)
  } catch {} finally { input.value = '' }
}

const submitReview = async () => {
  if (!reviewForm.rating || reviewSubmitting.value) return
  reviewSubmitting.value = true
  try {
    await request.post({ url: '/api/mall/reviews', data: { productId: product.value.id, rating: reviewForm.rating, content: reviewForm.content, images: reviewForm.images, orderId: reviewWritePerm.value.orderId, dimProductRating: reviewForm.dimProduct, dimServiceRating: reviewForm.dimService, dimLogisticsRating: reviewForm.dimLogistics } })
    showReviewEditor.value = false; reviewForm.rating = 0; reviewForm.content = ''; reviewForm.images = []; loadReviews()
  } catch {} finally { reviewSubmitting.value = false }
}

const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const openChat = () => { const uid = product.value?.createdBy; uid ? router.push(`/chat/${uid}`) : ElMessage.warning('暂无卖家信息') }
const goShop = () => { const uid = product.value?.createdBy; uid ? router.push(`/appstore/profile/${uid}`) : ElMessage.warning('暂无店铺信息') }

const confirmOptionName = computed(() => { const opt = selectedOption.value; return opt?.specName ? (opt.specName + ' / ' + opt.name) : (opt?.name || '') })

const confirmPrice = computed(() => {
  const opt = selectedOption.value; if (!opt) return product.value?.price || 0
  if (confirmPayMethod.value === 'points' && opt.pointsPrice) return opt.pointsPrice
  if (confirmPayMethod.value === 'points' && product.value?.pointsPrice) return product.value.pointsPrice
  return opt.price || 0
})

const confirmQty = computed(() => qty.value)
const confirmCustomFields = computed(() => userCustomFieldValues.value || {})

const confirmAvailablePayMethods = computed(() => {
  const pms = product.value?.paymentMethods || ['balance']
  const labels: Record<string, string> = { balance: '余额支付', points: '积分支付', alipay: '支付宝', wechat: '微信支付', epay: '易支付' }
  return pms.filter((v: string) => labels[v]).map((v: string) => ({ value: v, label: labels[v] }))
})

const confirmSubtotal = computed(() => confirmPrice.value * confirmQty.value)

const confirmCoupon = computed(() => { const idx = selectedCouponIndex.value; return (idx >= 0 && idx < filteredCoupons.value.length) ? filteredCoupons.value[idx] : null })
const confirmDiscount = computed(() => confirmCoupon.value ? Number(confirmCoupon.value.value || 0) : 0)
const confirmFinalAmount = computed(() => Math.max(0, confirmSubtotal.value - confirmDiscount.value))
const confirmPayUnit = computed(() => confirmPayMethod.value === 'points' ? '积分' : 'R币')

const selectedAddressIndex = computed({
  get: () => { if (!selectedAddress.value) return 0; return addresses.value.findIndex((a: any) => a.id === selectedAddress.value.id) },
  set: (idx: number) => { selectedAddress.value = addresses.value[idx] || null }
})

const filteredCoupons = computed(() => {
  const subtotal = confirmSubtotal.value
  return confirmCoupons.value.filter((c: any) => {
    const type = (c.type || '').toLowerCase(); const scope = (c.scope || '').toLowerCase(); const minOrder = Number(c.minOrder || 0); const isPointsType = type.includes('points')
    if (confirmPayMethod.value === 'points') { if (!isPointsType) return false } else { if (isPointsType) return false }
    if (scope && scope !== 'all' && scope !== 'mall' && !isPointsType) return false
    if (minOrder > subtotal) return false; return true
  })
})

const loadCoupons = async () => {
  try { const res: any = await request.get({ url: '/api/coupon/my', params: { status: 'unused' } }); confirmCoupons.value = res || []; selectedCouponIndex.value = -1 } catch { confirmCoupons.value = []; selectedCouponIndex.value = -1 }
}

const gotoCart = () => { router.push('/appstore/mall-cart') }

const addToCart = async () => {
  if (!userStore.getUserInfo.userId) { ElMessage.warning('请先登录'); return }
  const opt = selectedOption.value; const optionId = opt?.id || 0
  try { await request.post({ url: '/api/mall/cart', data: { productId: product.value.id, optionId, quantity: 1 } }); ElMessage.success('已加入购物车') } catch (e: any) { ElMessage.error(e?.message || '加入购物车失败') }
}

const buyNow = () => {
  if (!userStore.getUserInfo.userId) { ElMessage.warning('请先登录'); return }
  if (!product.value.options || product.value.options.length === 0) { ElMessage.warning('该商品暂无套餐可选'); return }
  if (groupedSpecs.value.length > 0 && selectedOptIndex.value < 0) { selectedSpecIndex.value = 0; selectedOptIndex.value = 0 }
  qty.value = 1; userCustomFieldValues.value = {}; confirmPayMethod.value = (product.value.paymentMethods || ['balance'])[0] || 'balance'; loadCoupons(); showPaySheet.value = true
}

const addresses = ref<any[]>([])
const selectedAddress = ref<any>(null)
const loadingAddresses = ref(false)

const loadAddresses = async () => {
  loadingAddresses.value = true
  try {
    const res: any = await request.get({ url: '/api/user/addresses' })
    addresses.value = res?.list || res?.data?.list || (Array.isArray(res) ? res : [])
    if (!selectedAddress.value && addresses.value.length > 0) {
      const def = addresses.value.find((a: any) => a.isDefault) || addresses.value[0]
      selectedAddress.value = def
    }
  } catch {} finally { loadingAddresses.value = false }
}

const confirmPayFromSheet = () => {
  const opt = selectedOption.value; if (!opt) { ElMessage.warning('请选择套餐'); return }
  if (qty.value > maxStock.value) { ElMessage.warning('库存不足，请减少数量'); return }
  const pms = product.value.paymentMethods || ['balance']; if (!pms.length) { ElMessage.warning('该商品未配置支付方式，无法支付'); return }
  const customFields = product.value.customFields || []
  for (const field of customFields) {
    if (field.required !== false) { const key = field.name || field.label || ''; if (!userCustomFieldValues.value[key]) { ElMessage.warning('请填写' + key); return } }
  }
  showPaySheet.value = false; showConfirmSheet.value = true
  if (product.value.productType === 'physical') loadAddresses()
}

const doPayOrder = async () => {
  const opt = selectedOption.value; if (!opt) return
  if (!['balance', 'points'].includes(confirmPayMethod.value)) { ElMessage.warning('当前仅支持余额支付和积分支付，请切换支付方式'); return }
  paying.value = true
  try {
    const payData: any = { productId: product.value.id, optionId: opt.id || 0, quantity: qty.value, paymentMethod: confirmPayMethod.value, userCustomFields: { ...userCustomFieldValues.value }, userCouponId: confirmCoupon.value?.id || undefined }
    if (selectedAddress.value) payData.addressId = selectedAddress.value.id
    const payRes: any = await request.post({ url: '/api/mall/orders', data: payData })
    ElMessage.success(payRes?.productType?.startsWith('virtual') ? '购买成功！' : '支付成功！')
    showConfirmSheet.value = false
    if (payRes?.productType?.startsWith('virtual') && payRes?.deliveryInfo) { ElMessageBox.confirm(payRes.deliveryInfo, '发货内容', { confirmButtonText: '查看数字资产', cancelButtonText: '稍后查看', type: 'success' }).then(() => { router.push('/appstore/digital-assets') }).catch(() => {}) }
    try { const userInfo: any = await request.get({ url: '/api/user/info' }); if (userInfo) userStore.setUserInfo(userInfo) } catch {}
    product.value.salesCount = (product.value.salesCount || 0) + qty.value; qty.value = 1
  } catch (e: any) { ElMessage.error(e?.message || '支付失败，请重试') }
  finally { paying.value = false }
}

const hidePaySheet = () => { if (!paying.value) showPaySheet.value = false }
</script>

<style scoped>
.page { height: 100vh; display: flex; flex-direction: column; background: #F5F6FA; }
.main { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; }
.loading { display: flex; justify-content: center; align-items: center; height: 60vh; }
.spinner { width: 28px; height: 28px; border: 2px solid #e0e0e0; border-top-color: #FF5722; border-radius: 50%; animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.empty { text-align: center; padding: 80px 0; font-size: 14px; color: #bbb; }

.nav-bar {
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  display: flex; align-items: center; padding: 8px 12px; height: 48px;
  transition: background .3s;
}
.nav-bar.scrolled { background: rgba(255,255,255,.92); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); box-shadow: 0 1px 0 rgba(0,0,0,.06); }
.nav-bar.scrolled .nav-btn { background: #F0F1F5; }
.nav-bar.scrolled .nav-btn svg { color: #333; }
.nav-btn {
  width: 34px; height: 34px; border-radius: 50%; border: none; cursor: pointer;
  background: rgba(0,0,0,.25); display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; backdrop-filter: blur(8px);
}
.nav-btn svg { width: 18px; height: 18px; color: #fff; }
.nav-btn:active { opacity: .8; }
.nav-title { flex: 1; font-size: 15px; font-weight: 700; color: #1a1a2e; text-align: center; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin: 0 12px; }
.fav-btn { margin-left: auto; }

.hero-wrap { position: relative; }
.hero {
  width: 100%; height: 320px; background: linear-gradient(170deg, #1a1a2e 0%, #252540 50%, #2a2a48 100%);
  overflow: hidden; display: flex; align-items: center; justify-content: center;
}
.hero-img { width: 100%; height: 100%; object-fit: cover; }
.hero-fb {
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  color: rgba(255,255,255,.25); width: 72px; height: 72px;
}
.hero-fb svg { width: 100%; height: 100%; }
.hero-dots { position: absolute; bottom: 14px; left: 50%; transform: translateX(-50%); display: flex; gap: 6px; }
.dot { width: 6px; height: 6px; border-radius: 3px; background: rgba(255,255,255,.35); cursor: pointer; transition: all .3s; }
.dot.on { width: 18px; background: #fff; }

.price-card {
  margin: -20px 16px 0; position: relative; z-index: 2;
  background: #fff; border-radius: 20px; padding: 20px;
  box-shadow: 0 8px 30px rgba(0,0,0,.08);
}
.price-main { display: flex; align-items: baseline; gap: 6px; margin-bottom: 10px; }
.price-unit { font-size: 14px; color: #FF5722; font-weight: 600; }
.price-val { font-size: 36px; font-weight: 900; color: #1a1a2e; line-height: 1; }
.price-old { font-size: 13px; color: #bbb; text-decoration: line-through; margin-left: 4px; }
.price-sub { display: flex; align-items: center; justify-content: space-between; }
.subsidy-chip {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;
  color: #FF5722; background: linear-gradient(135deg, #FFF3EE, #FFE4D6);
}
.subsidy-chip svg { width: 12px; height: 12px; }
.sold-info { font-size: 12px; color: #999; }
.countdown-bar {
  display: flex; align-items: center; gap: 6px; margin-top: 12px;
  padding: 8px 12px; border-radius: 10px; font-size: 12px; font-weight: 600;
  color: #FF5722; background: linear-gradient(135deg, #FFF3EE, #FFE8E0);
}
.countdown-bar svg { width: 14px; height: 14px; flex-shrink: 0; }

.info-card { padding: 16px 16px 0; }
.tag-row { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
.tag {
  padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700;
  color: #fff; background: linear-gradient(135deg, #FF5722, #FF8A65);
}
.title { font-size: 18px; font-weight: 800; color: #1a1a2e; line-height: 1.4; margin: 0; }
.subtitle { font-size: 13px; color: #999; font-weight: 400; }
.service-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 10px; }
.service-tag { padding: 3px 10px; border-radius: 10px; font-size: 11px; color: #8B8FA3; background: #F0F1F5; }

.action-grid { padding: 14px 16px; display: flex; flex-direction: column; gap: 8px; }
.action-card {
  display: flex; align-items: center; gap: 12px;
  background: #fff; border-radius: 14px; padding: 14px 16px;
  box-shadow: 0 2px 8px rgba(0,0,0,.03); cursor: pointer;
  transition: transform .15s;
}
.action-card:active { transform: scale(.98); }
.ac-icon {
  width: 40px; height: 40px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ac-icon svg { width: 20px; height: 20px; }
.ac-icon-warm { background: #FFF3EE; color: #FF5722; }
.ac-icon-accent { background: #EEF2FF; color: #4F6EF7; }
.ac-icon-cool { background: #F0FAF0; color: #22C55E; }
.ac-text { flex: 1; min-width: 0; }
.ac-title { font-size: 14px; font-weight: 700; color: #1a1a2e; }
.ac-desc { font-size: 12px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ac-arrow { width: 16px; height: 16px; color: #ccc; flex-shrink: 0; }

.section-card { background: #fff; margin: 0 16px 12px; border-radius: 16px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,.03); }
.section-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.section-indicator { width: 3px; height: 16px; border-radius: 2px; background: #FF5722; }
.section-indicator.accent { background: #F59E0B; }
.section-indicator.alt { background: #4F6EF7; }
.section-label { font-size: 15px; font-weight: 700; color: #1a1a2e; flex: 1; }
.section-more { font-size: 12px; color: #999; cursor: pointer; }

.param-list { display: flex; flex-direction: column; }
.param-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #F5F6FA; }
.param-item:last-child { border-bottom: none; }
.param-key { font-size: 13px; color: #999; }
.param-val { font-size: 13px; color: #333; font-weight: 500; }

.review-stat { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: #F5F6FA; border-radius: 12px; margin-bottom: 14px; cursor: pointer; }
.review-score { font-size: 28px; font-weight: 900; color: #FF5722; line-height: 1; }
.review-stars { display: flex; gap: 2px; }
.star { width: 16px; height: 16px; color: #e0e0e0; }
.star.on { color: #F59E0B; }
.review-label { font-size: 12px; color: #999; margin-left: auto; }

.review-list { display: flex; flex-direction: column; }
.review-item { display: flex; gap: 10px; padding: 12px 0; border-top: 1px solid #F5F6FA; }
.review-item:first-child { border-top: none; }
.review-user {
  width: 34px; height: 34px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 13px; font-weight: 700; flex-shrink: 0;
}
.review-body { flex: 1; min-width: 0; }
.review-name-row { display: flex; align-items: center; gap: 8px; }
.review-name { font-size: 13px; color: #333; font-weight: 600; }
.review-stars-sm { display: flex; gap: 1px; }
.star-sm { width: 12px; height: 12px; color: #e8e8e8; }
.star-sm.on { color: #F59E0B; }
.review-content { font-size: 13px; color: #444; line-height: 1.6; margin-top: 6px; }
.review-imgs { display: flex; gap: 6px; margin-top: 8px; }
.review-img { width: 64px; height: 64px; border-radius: 8px; object-fit: cover; }
.review-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 8px; }
.review-time { font-size: 11px; color: #bbb; }
.review-like {
  display: flex; align-items: center; gap: 3px; font-size: 11px; color: #bbb; cursor: pointer;
  padding: 2px 6px; border-radius: 10px; transition: all .15s;
}
.review-like svg { width: 14px; height: 14px; }
.review-like svg.liked { color: #FF5722; }
.review-like:active { background: #FFF3EE; }

.review-empty { text-align: center; padding: 20px 0; font-size: 13px; color: #bbb; }
.review-write {
  display: flex; align-items: center; gap: 6px; justify-content: center;
  margin-top: 12px; padding: 10px; border: 1px dashed #FF5722;
  border-radius: 12px; font-size: 13px; color: #FF5722; font-weight: 600; cursor: pointer;
  transition: all .15s;
}
.review-write:active { background: #FFF3EE; }
.review-write svg { width: 16px; height: 16px; }

.detail-content { font-size: 14px; color: #555; line-height: 1.8; }
.detail-content :deep(img) { max-width: 100%; border-radius: 10px; margin: 10px 0; }

.bottom-spacer { height: 80px; }

.footer {
  position: fixed; bottom: 0; left: 0; right: 0; z-index: 99;
  display: flex; align-items: center; gap: 8px; height: 56px;
  padding: 0 14px; background: rgba(255,255,255,.94);
  backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid rgba(0,0,0,.06); box-shadow: 0 -2px 10px rgba(0,0,0,.04);
}
.footer-icons { display: flex; gap: 2px; }
.fi-btn {
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  padding: 2px 8px; background: none; border: none; cursor: pointer;
}
.fi-btn svg { width: 22px; height: 22px; color: #8B8FA3; }
.fi-btn span { font-size: 10px; color: #8B8FA3; }
.fi-btn:active { opacity: .7; }

.footer-cart {
  flex: 1; height: 40px; border: none; border-radius: 20px;
  font-size: 14px; font-weight: 700; cursor: pointer; transition: all .15s;
  background: #1a1a2e; color: #fff;
}
.footer-cart:active:not(:disabled) { opacity: .85; }
.footer-buy {
  flex: 1; height: 40px; border: none; border-radius: 20px;
  font-size: 14px; font-weight: 700; cursor: pointer; transition: all .15s;
  background: linear-gradient(135deg, #FF5722, #FF7043); color: #fff;
  box-shadow: 0 4px 14px rgba(255,87,34,.3);
}
.footer-buy:active:not(:disabled) { transform: scale(.97); }
.footer-cart:disabled, .footer-buy:disabled { background: #ddd; color: #999; box-shadow: none; cursor: not-allowed; }

.sheet-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; animation: fadeIn .2s ease; }
@keyframes fadeIn { from { opacity: 0; } }
.buy-sheet { width: 100%; background: #fff; border-radius: 20px 20px 0 0; padding: 0 16px 28px; animation: slideUp .3s ease; max-height: 85vh; overflow-y: auto; }
@keyframes slideUp { from { transform: translateY(100%); } }
.sheet-tips { display: flex; flex-wrap: wrap; gap: 8px; padding: 16px 0; position: relative; }
.tip-item { display: flex; align-items: center; gap: 4px; font-size: 12px; color: #4CAF50; }
.tip-icon { width: 16px; height: 16px; }
.tip-close { position: absolute; right: 0; top: 14px; width: 24px; height: 24px; cursor: pointer; }
.sheet-divider { height: 1px; background: #f0f0f0; margin-bottom: 14px; }
.sheet-product { display: flex; gap: 12px; align-items: flex-start; margin-bottom: 16px; }
.sheet-product-img-wrap { position: relative; width: 96px; height: 96px; border-radius: 12px; overflow: hidden; flex-shrink: 0; }
.sheet-product-img { width: 100%; height: 100%; object-fit: cover; }
.sheet-product-fb { display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #FF5722, #FF8A65); color: #fff; font-size: 28px; font-weight: 800; }
.sheet-product-info { flex: 1; min-width: 0; }
.sheet-product-name { font-size: 15px; font-weight: 700; color: #111; line-height: 1.4; }
.sheet-product-price { font-size: 13px; color: #FF5722; margin-top: 6px; }
.sheet-product-price b { font-size: 22px; font-weight: 900; }
.sheet-tag-row { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.sheet-tag { font-size: 10px; color: #FF5722; padding: 1px 6px; border: 1px solid #FFCDD2; border-radius: 6px; background: #FFF5F5; }
.sheet-section { margin-top: 16px; }
.sheet-section-title { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 10px; }
.sheet-spec-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.sheet-spec-tab { padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; color: #666; background: #f5f5f5; cursor: pointer; transition: all .2s; }
.sheet-spec-tab.active { background: #1a1a2e; color: #fff; }
.sheet-opt-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.sheet-opt-item { padding: 8px 16px; border-radius: 8px; border: 1.5px solid #e0e0e0; font-size: 13px; color: #666; cursor: pointer; transition: all .2s; background: #fff; display: flex; flex-direction: column; gap: 2px; }
.sheet-opt-item.active { border-color: #FF5722; background: #FFF3EE; color: #FF5722; font-weight: 600; }
.sheet-opt-item-name { font-size: 13px; font-weight: 600; }
.sheet-opt-item-price { font-size: 11px; color: #FF5722; }
.qty-stepper { display: inline-flex; align-items: center; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
.qty-btn { width: 40px; height: 36px; border: none; background: #f9f9f9; font-size: 18px; color: #333; cursor: pointer; display: flex; align-items: center; justify-content: center; }
.qty-btn.disabled { color: #ccc; cursor: not-allowed; }
.qty-val { width: 48px; text-align: center; font-size: 15px; font-weight: 600; color: #333; }
.sheet-btns { margin-top: 20px; }
.sheet-btn-submit { width: 100%; height: 48px; border: none; border-radius: 24px; background: linear-gradient(135deg, #FF5722, #FF7043); color: #fff; font-size: 16px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 14px rgba(255,87,34,.3); }
.sheet-btn-submit:active { opacity: .85; }

.custom-fields { display: flex; flex-direction: column; gap: 12px; }
.custom-field-item { display: flex; flex-direction: column; gap: 4px; }
.custom-field-label { font-size: 13px; font-weight: 600; color: #555; display: flex; align-items: center; gap: 4px; }
.custom-field-required { color: #FF4757; font-size: 14px; }
.custom-field-input { height: 40px; padding: 0 12px; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 14px; color: #333; outline: none; transition: border-color .2s; background: #fafafa; }
.custom-field-input:focus { border-color: #FF5722; background: #fff; }
.custom-field-textarea { padding: 10px 12px; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 14px; color: #333; outline: none; resize: none; background: #fafafa; transition: border-color .2s; }
.custom-field-textarea:focus { border-color: #FF5722; background: #fff; }
.custom-field-select { height: 40px; padding: 0 12px; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 14px; color: #333; outline: none; background: #fafafa; }

.confirm-overlay { position: fixed; inset: 0; z-index: 1001; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; animation: fadeIn .2s ease; }
.confirm-sheet { width: 100%; background: #fff; border-radius: 20px 20px 0 0; max-height: 85vh; display: flex; flex-direction: column; animation: slideUp .3s ease; }
.confirm-header { display: flex; align-items: center; justify-content: space-between; padding: 18px 20px 14px; border-bottom: 1px solid #f0f0f0; }
.confirm-title { font-size: 18px; font-weight: 700; color: #111; }
.confirm-close { width: 24px; height: 24px; cursor: pointer; }
.confirm-body { flex: 1; overflow-y: auto; padding: 0 20px; }
.confirm-section { padding: 16px 0; border-bottom: 1px solid #f5f5f5; }
.confirm-section:last-child { border-bottom: none; }
.confirm-section-title { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 12px; }
.confirm-product { display: flex; gap: 12px; align-items: center; }
.confirm-product-img { width: 64px; height: 64px; border-radius: 10px; object-fit: cover; flex-shrink: 0; }
.confirm-product-fb { display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #FF5722, #FF8A65); color: #fff; font-size: 24px; font-weight: 800; }
.confirm-product-info { flex: 1; min-width: 0; }
.confirm-product-name { font-size: 14px; font-weight: 600; color: #333; }
.confirm-product-opt { font-size: 12px; color: #999; margin-top: 2px; }
.confirm-product-price { font-size: 16px; font-weight: 700; color: #FF4757; margin-top: 4px; }
.confirm-field-list { background: #fafafa; border-radius: 10px; padding: 12px 14px; }
.confirm-field-row { display: flex; justify-content: space-between; padding: 6px 0; gap: 12px; }
.confirm-field-row + .confirm-field-row { border-top: 1px solid #f0f0f0; }
.confirm-field-key { font-size: 13px; color: #666; }
.confirm-field-val { font-size: 13px; color: #333; font-weight: 500; }
.confirm-coupon-select { width: 100%; height: 44px; padding: 0 12px; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 14px; color: #333; outline: none; appearance: none; background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M6 9l6 6 6-6' stroke='%23999' stroke-width='2' stroke-linecap='round'/%3E%3C/svg%3E") no-repeat right 12px center; }
.confirm-pay-methods { display: flex; flex-wrap: wrap; gap: 8px; }
.confirm-pay-item { padding: 8px 20px; border-radius: 8px; border: 1.5px solid #e0e0e0; font-size: 13px; color: #666; cursor: pointer; transition: all .2s; background: #fff; }
.confirm-pay-item.active { border-color: #FF5722; background: #FFF3EE; color: #FF5722; font-weight: 600; }
.confirm-price-breakdown { background: #fafafa; border-radius: 10px; padding: 14px; }
.confirm-price-row { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; }
.confirm-price-label { font-size: 13px; color: #777; }
.confirm-price-val { font-size: 13px; color: #333; font-weight: 500; }
.confirm-price-val.discount { color: #10b981; }
.confirm-price-divider { height: 1px; background: #e8e8e8; margin: 8px 0; }
.confirm-price-row.total .confirm-price-label { font-size: 15px; font-weight: 700; color: #111; }
.confirm-price-row.total .confirm-price-val.total-val { font-size: 18px; font-weight: 800; color: #FF4757; }
.confirm-footer { padding: 12px 20px 28px; }
.confirm-btn-submit { width: 100%; height: 48px; border: none; border-radius: 24px; background: linear-gradient(135deg, #FF5722, #FF7043); color: #fff; font-size: 16px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 14px rgba(255,87,34,.3); }
.confirm-btn-submit:disabled { opacity: .5; cursor: not-allowed; }

.review-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; justify-content: center; }
.review-editor { width: 100%; max-width: 480px; background: #fff; border-radius: 16px 16px 0 0; max-height: 85vh; overflow-y: auto; display: flex; flex-direction: column; }
.review-editor-header { display: flex; align-items: center; justify-content: center; padding: 14px 16px; border-bottom: 1px solid #f0f0f0; position: relative; }
.review-editor-title { font-size: 16px; font-weight: 700; color: #222; }
.review-editor-close { position: absolute; right: 16px; width: 20px; height: 20px; color: #999; cursor: pointer; }
.review-editor-body { padding: 16px; display: flex; flex-direction: column; gap: 18px; }
.review-editor-stars { display: flex; align-items: center; gap: 10px; }
.review-editor-label { font-size: 13px; color: #666; flex-shrink: 0; }
.review-editor-stars-row { display: flex; gap: 5px; }
.review-star-lg { width: 30px; height: 30px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-star-lg.on { color: #F59E0B; }
.review-star-lg:active { transform: scale(1.2); }
.review-star-text { font-size: 13px; color: #F59E0B; font-weight: 500; }
.review-dim-stars { margin-top: 8px; }
.review-dim-row { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
.review-dim-label { font-size: 12px; color: #999; width: 28px; flex-shrink: 0; }
.review-dim-stars-row { display: flex; gap: 3px; }
.review-dim-star { width: 20px; height: 20px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-dim-star.on { color: #F59E0B; }
.review-dim-star:active { transform: scale(1.1); }
.review-editor-field { position: relative; }
.review-editor-textarea { width: 100%; border: 1px solid #eee; border-radius: 8px; padding: 10px 12px 28px; font-size: 13px; color: #333; outline: none; resize: none; line-height: 1.5; box-sizing: border-box; font-family: inherit; }
.review-editor-textarea:focus { border-color: #FF5722; }
.review-editor-count { position: absolute; right: 10px; bottom: 8px; font-size: 11px; color: #ccc; }
.review-editor-imgs { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px; }
.review-editor-img-wrap { width: 68px; height: 68px; border-radius: 6px; overflow: hidden; position: relative; }
.review-editor-img { width: 100%; height: 100%; object-fit: cover; }
.review-editor-img-del { position: absolute; top: 0; right: 0; width: 20px; height: 20px; background: rgba(0,0,0,.5); border-radius: 0 6px 0 6px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.review-editor-img-del svg { width: 12px; height: 12px; }
.review-editor-add { width: 68px; height: 68px; border: 1px dashed #ddd; border-radius: 6px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: #ccc; transition: all .15s; }
.review-editor-add:active { border-color: #FF5722; color: #FF5722; }
.review-editor-add svg { width: 24px; height: 24px; }
.review-editor-footer { padding: 0 16px 24px; }
.review-editor-submit { width: 100%; height: 44px; border: none; border-radius: 22px; background: linear-gradient(135deg, #FF5722, #FF8A65); color: #fff; font-size: 15px; font-weight: 700; cursor: pointer; transition: opacity .15s; }

.add-addr-btn { padding: 6px 16px; border: 1.5px solid #FF5722; border-radius: 16px; background: #fff; color: #FF5722; font-size: 13px; cursor: pointer; transition: all .15s; }
.add-addr-btn:active { background: #FFF3EE; }
.review-editor-submit:disabled { opacity: .5; cursor: not-allowed; }
</style>
