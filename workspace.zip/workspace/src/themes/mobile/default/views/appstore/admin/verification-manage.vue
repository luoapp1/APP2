<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">蓝V认证审核</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>
      <!-- 操作栏 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex gap-2">
        <div class="flex-1 flex gap-1 bg-[#f5f6f8] rounded-lg p-0.5">
          <button v-for="opt in statusOptions" :key="opt.value" class="flex-1 h-8 text-xs rounded-md font-medium transition-colors" :class="filterStatus === opt.value ? 'bg-white text-[#FF4757] shadow-sm' : 'text-gray-500'" @click="filterStatus = opt.value; handleStatusChange()">{{ opt.label }}</button>
        </div>
        <button class="h-8 px-3 bg-[#FF4757] text-white text-xs rounded-lg font-medium active:opacity-80 flex-shrink-0" @click="openConfig">认证条件配置</button>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showDetail(item)">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.user_name }}</span>
                  <span v-if="item.nickname" class="text-xs text-gray-400">{{ item.nickname }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="statusTagClass(item.status)">{{ statusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>机构: {{ item.organization || '-' }}</div>
                  <div>申请称号: {{ item.reason ? (item.reason.length > 20 ? item.reason.slice(0, 20) + '...' : item.reason) : '-' }}</div>
                  <div>条件: {{ conditionLabel(item.selected_condition) }}{{ item.selected_app_name ? ' - ' + item.selected_app_name : '' }}</div>
                  <div>申请时间: {{ item.create_time }}</div>
                </div>
              </div>
              <svg class="w-4 h-4 text-gray-300 flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
              </svg>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="pagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current - 1)">上一页</button>
            <span class="text-xs text-gray-400">{{ pagination.current }}/{{ totalPages }}</span>
            <button :disabled="pagination.current >= totalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current + 1)">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ pagination.total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
          <span class="text-sm">暂无认证申请</span>
        </div>
      </div>
    </div>

    <!-- 审核详情弹窗 -->
    <div v-if="detailVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="detailVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="detailVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">审核详情</span>
          <div v-if="currentReq.status === 'pending'" class="flex gap-2">
            <button v-auth="'reject'" class="text-xs px-3 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="doReview('reject')">拒绝</button>
            <button v-auth="'approve'" class="text-xs px-3 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="doReview('approve')">通过</button>
          </div>
          <button v-else-if="currentReq.status === 'approved'" class="text-xs px-3 py-1 rounded bg-orange-50 text-orange-600 active:bg-orange-100" @click="cancelVerify">取消认证</button>
        </div>

        <div class="flex-1 overflow-y-auto p-4" v-if="currentReq">
          <div class="space-y-3">
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">申请人</span>
              <span class="text-gray-800 font-medium">{{ currentReq.user_name }} ({{ currentReq.nickname || '-' }})</span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">真实姓名</span>
              <span class="text-gray-800">{{ currentReq.real_name || '-' }}</span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">身份证号</span>
              <span class="text-gray-800">{{ currentReq.id_card || '-' }}</span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">所属机构</span>
              <span class="text-gray-800">{{ currentReq.organization || '-' }}</span>
            </div>
            <div v-if="currentReq.selected_condition" class="flex justify-between text-sm">
              <span class="text-gray-400">认证条件</span>
              <span class="text-gray-800">{{ conditionLabel(currentReq.selected_condition) }}<span v-if="currentReq.selected_app_name"> - {{ currentReq.selected_app_name }}</span></span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">申请称号</span>
              <span class="text-gray-800">{{ currentReq.reason || '-' }}</span>
            </div>
            <div class="flex justify-between text-sm">
              <span class="text-gray-400">申请时间</span>
              <span class="text-gray-800">{{ currentReq.create_time }}</span>
            </div>
            <div v-if="currentReq.review_comment" class="flex justify-between text-sm">
              <span class="text-gray-400">审核意见</span>
              <span class="text-gray-800">{{ currentReq.review_comment }}</span>
            </div>
          </div>

          <div v-if="currentReq.status === 'pending'" class="mt-4">
            <label class="text-xs text-gray-500 mb-1 block">审核意见(可选)</label>
            <textarea v-model="reviewComment" rows="2" placeholder="可选" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
          </div>
        </div>
      </div>
    </div>

    <!-- 认证条件配置弹窗 -->
    <div v-if="configVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="configVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="configVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">认证条件配置</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveConfig">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">申请逻辑</label>
            <select v-model="configForm.logic_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none">
              <option value="any">满足任意一项即可</option>
              <option value="specific_count">满足指定数量</option>
            </select>
          </div>
          <div v-if="configForm.logic_type === 'specific_count'" class="flex items-center gap-2">
            <span class="text-xs text-gray-500">从</span>
            <input v-model.number="configForm.logic_count" type="number" min="1" class="w-16 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-center" />
            <span class="text-xs text-gray-500">项中满足</span>
            <input v-model.number="configForm.min_meet" type="number" min="1" class="w-16 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-center" />
            <span class="text-xs text-gray-500">项即通过</span>
          </div>

          <div class="text-xs text-gray-400 font-medium mt-3">认证条件</div>
          <div v-for="cond in conditionDefs" :key="cond.type" class="flex items-center justify-between py-2 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center gap-2">
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="cond.is_active ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cond.is_active = !cond.is_active">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cond.is_active ? 'translate-x-4.5 left-0.5' : 'left-0.5'" style="transition: transform 0.2s" />
              </button>
              <span class="text-sm text-gray-700">{{ cond.label }}</span>
            </div>
            <template v-if="cond.is_active && cond.type !== 'app_developer'">
              <div class="flex items-center gap-1">
                <span class="text-xs text-gray-400">阈值:</span>
                <input v-model.number="cond.threshold" type="number" min="1" class="w-20 h-8 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none text-center" />
                <span class="text-xs text-gray-400">{{ cond.unit }}</span>
              </div>
            </template>
            <span v-else-if="cond.is_active && cond.type === 'app_developer'" class="text-xs text-gray-400">需已审核通过的应用</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'VerificationMobile' })

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

const loading = ref(false)
const data = ref<any[]>([])
const pagination = reactive({ current: 1, size: 20, total: 0 })
const totalPages = computed(() => Math.max(1, Math.ceil(pagination.total / pagination.size)))
const filterStatus = ref('pending')

const statusOptions = [
  { label: '待审核', value: 'pending' },
  { label: '已通过', value: 'approved' },
  { label: '已拒绝', value: 'rejected' }
]

const statusMap: Record<string, string> = { pending: '待审核', approved: '已通过', rejected: '已拒绝' }
const statusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', approved: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }
const statusText = (s: string) => statusMap[s] || s
const statusTagClass = (s: string) => statusClassMap[s] || 'bg-gray-100 text-gray-500'

const conditionDefs = reactive([
  { type: 'follower_count', label: '粉丝数量', unit: '人', threshold: 100, is_active: false },
  { type: 'app_count', label: '上传应用数量', unit: '个', threshold: 3, is_active: false },
  { type: 'app_developer', label: '应用开发者', unit: '', threshold: 0, is_active: false },
  { type: 'post_count', label: '发帖数量', unit: '条', threshold: 10, is_active: false }
])

const conditionLabel = (type: string) => {
  const def = conditionDefs.find(c => c.type === type)
  return def ? def.label : type || '-'
}

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/verification/list', params: { status: filterStatus.value, page: pagination.current, pageSize: pagination.size } })
    data.value = res?.records || res?.data?.records || res?.list || []
    pagination.total = res?.total || res?.data?.total || data.value.length
  } catch {}
  loading.value = false
}

const handleStatusChange = () => { pagination.current = 1; fetchData() }
const goPage = (p: number) => { pagination.current = p; fetchData() }

// Detail modal
const detailVisible = ref(false)
const currentReq = ref<any>(null)
const reviewComment = ref('')

const showDetail = (row: any) => {
  currentReq.value = row
  reviewComment.value = ''
  detailVisible.value = true
}

const doReview = async (action: string) => {
  if (!currentReq.value) return
  try {
    await request.post({ url: `/api/verification/${currentReq.value.id}/review`, data: { action, comment: reviewComment.value } })
    showToast(action === 'approve' ? '已通过认证' : '已拒绝认证')
    detailVisible.value = false
    fetchData()
  } catch { showToast('操作失败', 'error') }
}

const cancelVerify = async () => {
  if (!currentReq.value) return
  if (!confirm('确定取消该用户的蓝V认证？')) return
  try {
    await request.post({ url: '/api/verification/cancel', data: { userId: currentReq.value.user_id } })
    showToast('认证已取消')
    detailVisible.value = false
    fetchData()
  } catch { showToast('操作失败', 'error') }
}

// Config modal
const configVisible = ref(false)
const configForm = reactive({ logic_type: 'any', logic_count: 1, min_meet: 1 })

const openConfig = async () => {
  configVisible.value = true
  try {
    const data: any = await request.get({ url: '/api/verification/config' })
    if (data && data.conditions) {
      configForm.logic_type = data.logic_type || 'any'
      configForm.logic_count = data.logic_count || 1
      configForm.min_meet = data.logic_count || 1
      data.conditions.forEach((c: any) => {
        const def = conditionDefs.find(d => d.type === c.condition_type)
        if (def) {
          def.is_active = !!c.is_active
          def.threshold = c.threshold || 0
        }
      })
    }
  } catch { showToast('加载配置失败，请确认已登录管理员账号', 'error') }
}

const saveConfig = async () => {
  const activeCount = conditionDefs.filter(c => c.is_active).length
  if (activeCount === 0) { showToast('请至少启用一项认证条件', 'error'); return }
  try {
    await request.post({ url: '/api/verification/config', data: {
      conditions: conditionDefs.map(c => ({ condition_type: c.type, threshold: c.threshold, is_active: c.is_active })),
      logic_type: configForm.logic_type,
      logic_count: configForm.logic_type === 'specific_count' ? configForm.min_meet : activeCount
    }})
    showToast('配置已保存')
    configVisible.value = false
  } catch { showToast('保存失败', 'error') }
}

onMounted(() => fetchData())
</script>
