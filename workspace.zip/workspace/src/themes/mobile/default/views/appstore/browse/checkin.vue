<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="flex:1;overflow-y:auto;padding-bottom:20px">
      <div style="display:flex;align-items:center;padding:12px 16px;background:var(--default-bg-color);position:sticky;top:0;z-index:5">
        <div style="cursor:pointer;padding:4px" @click="$router.back()">
          <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
          </svg>
        </div>
        <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">每日签到</div>
        <div style="width:30px" />
      </div>

      <div
        style="background:linear-gradient(135deg,#0ea5e9,#06b6d4,#14b8a6,#10b981);margin:12px;border-radius:20px;padding:20px;color:#fff;position:relative;overflow:hidden"
      >
        <div style="position:absolute;top:-20px;right:-20px;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.1)" />
        <div style="position:absolute;bottom:-30px;left:-30px;width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.08)" />
        <div style="position:relative;display:flex;align-items:center;justify-content:space-between">
          <div>
            <div style="font-size:13px;opacity:.85">已连续签到</div>
            <div style="font-size:40px;font-weight:700;line-height:1.2">{{ consecutiveDays }}</div>
            <div style="font-size:13px;opacity:.85">天</div>
          </div>
          <div style="text-align:right">
            <div style="font-size:13px;opacity:.85">本月签到</div>
            <div style="font-size:28px;font-weight:700;line-height:1.2">{{ monthCheckinCount }}</div>
            <div style="font-size:13px;opacity:.85">天</div>
          </div>
        </div>
      </div>

      <div style="background:#fff;margin:0 12px;border-radius:16px;padding:16px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:15px;font-weight:600;color:#1f2937">{{ currentYear }}年{{ currentMonth }}月</div>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="cursor:pointer;padding:2px" @click="prevMonth">
              <svg style="width:18px;height:18px;color:#9ca3af" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </div>
            <div style="cursor:pointer;padding:2px" @click="nextMonth">
              <svg style="width:18px;height:18px;color:#9ca3af" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(7,1fr);text-align:center;margin-bottom:8px">
          <div v-for="d in weekDays" :key="d" style="font-size:11px;color:#9ca3af;padding:6px 0">{{ d }}</div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(7,1fr);text-align:center;row-gap:4px">
          <div v-for="(day, idx) in calendarDays" :key="idx" style="display:flex;justify-content:center">
            <div
              v-if="day.day"
              style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px"
              :style="{ ...getDayStyle(day), ...(day.isPast && !day.checked ? { cursor: 'pointer' } : {}) }"
              @click="day.isPast && !day.checked && openMakeupDialog(`${currentYear}-${String(currentMonth).padStart(2,'0')}-${String(day.day).padStart(2,'0')}`)"
            >
              <svg v-if="day.checked" style="width:18px;height:18px;color:#fff" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
              </svg>
              <span v-else-if="day.isPast" style="cursor:pointer">{{ day.day }}</span>
              <span v-else style="color:#374151">{{ day.day }}</span>
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:center;gap:20px;margin-top:12px">
          <div style="display:flex;align-items:center;gap:4px">
            <div style="width:12px;height:12px;border-radius:50%;background:#10b981" />
            <span style="font-size:11px;color:#9ca3af">已签到</span>
          </div>
          <div style="display:flex;align-items:center;gap:4px">
            <div style="width:12px;height:12px;border-radius:50%;background:#f3f4f6" />
            <span style="font-size:11px;color:#9ca3af">未签到</span>
          </div>
          <div style="display:flex;align-items:center;gap:4px">
            <div style="font-size:16px;color:#ef4444;line-height:1">✕</div>
            <span style="font-size:11px;color:#9ca3af">已过期</span>
          </div>
        </div>
      </div>

      <div v-if="!checkedToday && isCurrentMonth" style="background:#fff;margin:12px;border-radius:16px;padding:16px;text-align:center">
        <div style="font-size:14px;color:#6b7280;margin-bottom:12px">
          <template v-if="nextRewardText">{{ nextRewardText }}</template>
          <template v-else>今天还没签到哦</template>
        </div>
        <div style="display:flex;align-items:center;justify-content:center;gap:12px">
          <div
            style="display:inline-block;background:linear-gradient(135deg,#0ea5e9,#10b981);color:#fff;font-size:15px;font-weight:600;padding:10px 48px;border-radius:24px;cursor:pointer;box-shadow:0 4px 15px rgba(14,165,233,.3)"
            :style="checkingIn ? { opacity: 0.7, pointerEvents: 'none' } : {}"
            @click="handleCheckin"
          >{{ checkingIn ? '签到中...' : '立即签到' }}</div>
          <div
            style="display:inline-block;color:#f59e0b;font-size:13px;font-weight:600;padding:8px 20px;border-radius:24px;cursor:pointer;border:1.5px solid #f59e0b"
            @click="openMakeupDialog()"
          >补签</div>
        </div>
      </div>

      <div v-else-if="checkedToday" style="background:#fff;margin:12px;border-radius:16px;padding:16px;text-align:center">
        <div style="display:flex;align-items:center;justify-content:center;gap:6px">
          <svg style="width:20px;height:20px;color:#10b981" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span style="font-size:14px;color:#10b981;font-weight:600">今日已签到</span>
        </div>
        <div style="font-size:12px;color:#9ca3af;margin-top:4px" v-if="todayReward">
          获得积分 +{{ todayReward.pointsEarned || 0 }}，经验 +{{ todayReward.experienceEarned || 0 }}
        </div>
        <div v-if="makeupInfoText" style="font-size:11px;color:#f59e0b;margin-top:8px">{{ makeupInfoText }}</div>
      </div>

      <div style="background:#fff;margin:12px;border-radius:16px;padding:16px">
        <div style="font-size:15px;font-weight:600;color:#1f2937;margin-bottom:12px">签到排行榜（本月）</div>
        <div v-if="rankingLoading" style="text-align:center;padding:20px;color:#9ca3af">加载中...</div>
        <div v-else-if="ranking.length === 0" style="text-align:center;padding:20px;color:#9ca3af">暂无数据</div>
        <div v-else>
          <div
            v-for="item in ranking"
            :key="item.userId"
            style="display:flex;align-items:center;padding:10px 0"
            :style="{ borderBottom: '1px solid #f9fafb' }"
          >
            <div style="width:28px;text-align:center;font-weight:700;font-size:14px;flex-shrink:0"
              :style="{ color: item.rank === 1 ? '#f59e0b' : item.rank === 2 ? '#94a3b8' : item.rank === 3 ? '#d97706' : '#9ca3af' }"
            >
              <span v-if="item.rank === 1">🥇</span>
              <span v-else-if="item.rank === 2">🥈</span>
              <span v-else-if="item.rank === 3">🥉</span>
              <span v-else>{{ item.rank }}</span>
            </div>
            <div style="
              width:36px;height:36px;border-radius:50%;flex-shrink:0;margin-left:10px;
              display:flex;align-items:center;justify-content:center;overflow:hidden
            ">
              <img v-if="item.avatar && (item.avatar.startsWith('http') || item.avatar.startsWith('/'))"
                :src="$fixImgUrl(item.avatar)" style="width:100%;height:100%;object-fit:cover"
               loading="lazy" />
              <img v-else src="@imgs/user/avatar.webp" style="width:100%;height:100%;object-fit:cover"  loading="lazy" />
            </div>
            <div style="flex:1;margin-left:10px">
              <div style="font-size:13px;font-weight:600;color:#1f2937">{{ item.nickname || item.username }}</div>
              <div style="font-size:10px;color:#9ca3af">{{ item.levelName }}</div>
            </div>
            <div style="text-align:right">
              <div style="font-size:13px;color:#6b7280">本月签到 <span style="font-weight:600;color:#00bfa5">{{ item.totalCheckins }}</span> 天</div>
              <div style="font-size:10px;color:#9ca3af">连续 {{ item.consecutiveCheckins }} 天</div>
            </div>
          </div>
        </div>
      </div>

      <div
        v-if="showMakeupDialog"
        style="position:fixed;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;z-index:100"
        @click.self="showMakeupDialog = false"
      >
        <div style="background:#fff;border-radius:16px;width:340px;padding:24px 20px 16px">
          <div style="font-size:16px;font-weight:600;color:#1f2937;margin-bottom:4px">补签</div>
          <div v-if="makeupTargetDate" style="font-size:12px;color:#f59e0b;margin-bottom:8px">补签日期：{{ makeupTargetDate }}</div>
          <div style="font-size:11px;color:#9ca3af;margin-bottom:12px">
            <span>免费补签：<b style="color:#f59e0b">{{ makeupAvailable.freeMakeups + makeupAvailable.membershipMakeups + makeupAvailable.giftFreeMakeups }}</b> 次</span>
          </div>
          <div style="display:flex;gap:0;margin-bottom:16px;background:#f3f4f6;border-radius:10px;padding:3px">
            <div
              v-for="tab in makeupTabs" :key="tab.key"
              style="flex:1;text-align:center;padding:8px 0;font-size:13px;border-radius:8px;cursor:pointer;transition:all .2s"
              :style="makeupTab === tab.key ? { background: '#fff', color: '#f59e0b', fontWeight: 600, boxShadow: '0 1px 3px rgba(0,0,0,.1)' } : { color: '#6b7280' }"
              @click="makeupTab = tab.key"
            >{{ tab.label }}</div>
          </div>
          <template v-if="makeupMsg" :key="makeupMsg">
            <div :style="{ fontSize: '12px', marginBottom: '12px', color: makeupMsgColor, textAlign: 'center' }">{{ makeupMsg }}</div>
          </template>
          <!-- 免费补签 -->
          <template v-if="makeupTab === 'free'">
            <div style="font-size:12px;color:#9ca3af;margin-bottom:12px">
              使用免费补签次数，当前可用：<b style="color:#f59e0b">{{ makeupAvailable.freeMakeups + makeupAvailable.membershipMakeups + makeupAvailable.giftFreeMakeups }}</b> 次
            </div>
            <div style="display:flex;gap:10px">
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f3f4f6;color:#374151;cursor:pointer" @click="showMakeupDialog = false">取消</button>
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f59e0b;color:#fff;cursor:pointer" :disabled="makingUp" @click="handleMakeupFree">{{ makingUp ? '补签中...' : '免费补签' }}</button>
            </div>
          </template>
          <!-- 积分补签 -->
          <template v-if="makeupTab === 'points'">
            <div style="font-size:12px;color:#9ca3af;margin-bottom:12px">
              <span v-if="makeupConfig.pointsCost > 0">消耗 <b style="color:#f59e0b">{{ makeupConfig.pointsCost }}</b> 积分进行补签签到</span>
              <span v-else style="color:#ef4444">当前签到组未启用积分补签</span>
            </div>
            <div style="display:flex;gap:10px">
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f3f4f6;color:#374151;cursor:pointer" @click="showMakeupDialog = false">取消</button>
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f59e0b;color:#fff;cursor:pointer" :disabled="makingUp || makeupConfig.pointsCost <= 0" @click="handleMakeupPoints">{{ makingUp ? '补签中...' : '积分补签' }}</button>
            </div>
          </template>
          <!-- 余额补签 -->
          <template v-if="makeupTab === 'balance'">
            <div style="font-size:12px;color:#9ca3af;margin-bottom:12px">
              <span v-if="makeupConfig.balanceCost > 0">消耗 <b style="color:#f59e0b">¥{{ makeupConfig.balanceCost }}</b> 余额进行补签签到</span>
              <span v-else style="color:#ef4444">当前签到组未启用余额补签</span>
            </div>
            <div style="display:flex;gap:10px">
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f3f4f6;color:#374151;cursor:pointer" @click="showMakeupDialog = false">取消</button>
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f59e0b;color:#fff;cursor:pointer" :disabled="makingUp || makeupConfig.balanceCost <= 0" @click="handleMakeupBalance">{{ makingUp ? '补签中...' : '余额补签' }}</button>
            </div>
          </template>
          <!-- 卡密补签 -->
          <template v-if="makeupTab === 'card'">
            <div style="margin-bottom:12px">
              <input v-model="makeupForm.cardNo" placeholder="请输入补签卡号" style="width:100%;padding:10px 12px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box" />
            </div>
            <div style="margin-bottom:12px">
              <input v-model="makeupForm.password" placeholder="请输入补签卡密码" style="width:100%;padding:10px 12px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box" />
            </div>
            <div style="display:flex;gap:10px">
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f3f4f6;color:#374151;cursor:pointer" @click="showMakeupDialog = false">取消</button>
              <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#f59e0b;color:#fff;cursor:pointer" :disabled="makingUp" @click="handleMakeupCard">{{ makingUp ? '补签中...' : '确认补签' }}</button>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { doCheckin, doMakeupCheckin, doMakeupCheckinByPoints, doMakeupCheckinByBalance, doMakeupCheckinFree, fetchMakeupsAvailable, fetchCheckinHistory, fetchCheckinRanking, fetchCheckinStatus } from '@/api/checkin'
import { ElMessage } from 'element-plus'
import { useLoginModalStore } from '@/store/modules/loginModal'

const router = useRouter()
const userStore = useUserStore()

const isLogin = computed(() => userStore.isLogin)

const weekDays = ['日', '一', '二', '三', '四', '五', '六']

const currentDate = ref(new Date())
const currentYear = computed(() => currentDate.value.getFullYear())
const currentMonth = computed(() => currentDate.value.getMonth() + 1)
const isCurrentMonth = computed(() => {
  const now = new Date()
  return currentYear.value === now.getFullYear() && currentMonth.value === now.getMonth() + 1
})

const checkedDays = ref<Set<string>>(new Set())
const checkedToday = ref(false)
const consecutiveDays = ref(0)
const checkingIn = ref(false)
const todayReward = ref<any>(null)
const monthCheckinCount = ref(0)

const ranking = ref<any[]>([])
const rankingLoading = ref(false)
const nextRewardText = ref('')

const showMakeupDialog = ref(false)
const makeupTargetDate = ref('')
const makeupForm = ref({ cardNo: '', password: '' })
const makeupMsg = ref('')
const makeupMsgColor = ref('#00bfa5')
const makeupTab = ref('')
const makeupConfig = ref({ pointsCost: 0, balanceCost: 0, freeCount: 0 })
const makeupAvailable = ref({ cardCount: 0, membershipMakeups: 0, freeMakeups: 0, giftFreeMakeups: 0 })
const makingUp = ref(false)

const makeupInfoText = computed(() => {
  const parts: string[] = []
  if (makeupAvailable.value.freeMakeups > 0) parts.push(`里程碑补签 ${makeupAvailable.value.freeMakeups} 次`)
  if (makeupAvailable.value.membershipMakeups > 0) parts.push(`会员补签 ${makeupAvailable.value.membershipMakeups} 次`)
  if (makeupAvailable.value.giftFreeMakeups > 0) parts.push(`礼包补签 ${makeupAvailable.value.giftFreeMakeups} 次`)
  if (makeupAvailable.value.cardCount > 0) parts.push(`补签卡 ${makeupAvailable.value.cardCount} 张`)
  return parts.join(' ｜ ')
})
const makeupTabs = computed(() => {
  const tabs: { key: string; label: string }[] = []
  const freeTotal = makeupAvailable.value.freeMakeups + makeupAvailable.value.membershipMakeups + makeupAvailable.value.giftFreeMakeups
  if (freeTotal > 0) {
    tabs.push({ key: 'free', label: `免费补签(${freeTotal})` })
  }
  if (makeupConfig.value.pointsCost > 0) tabs.push({ key: 'points', label: '积分补签' })
  if (makeupConfig.value.balanceCost > 0) tabs.push({ key: 'balance', label: '余额补签' })
  tabs.push({ key: 'card', label: '卡密补签' })
  return tabs
})

const prevMonth = () => {
  const d = new Date(currentDate.value)
  d.setMonth(d.getMonth() - 1)
  currentDate.value = d
  loadMonthHistory()
  loadRanking()
}

const nextMonth = () => {
  const d = new Date(currentDate.value)
  d.setMonth(d.getMonth() + 1)
  if (d > new Date()) return
  currentDate.value = d
  loadMonthHistory()
  loadRanking()
}

const calendarDays = computed(() => {
  const year = currentYear.value
  const month = currentMonth.value
  const firstDay = new Date(year, month - 1, 1)
  const lastDay = new Date(year, month, 0)
  const startDow = firstDay.getDay()
  const totalDays = lastDay.getDate()
  const today = new Date()
  const todayStr = today.toISOString().substring(0, 10)

  const days: { day: number; checked: boolean; isPast: boolean; isToday: boolean }[] = []

  for (let i = 0; i < startDow; i++) {
    days.push({ day: 0, checked: false, isPast: false, isToday: false })
  }

  for (let d = 1; d <= totalDays; d++) {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`
    const isChecked = checkedDays.value.has(dateStr)
    const isToday = dateStr === todayStr
    const isPast = dateStr < todayStr
    days.push({ day: d, checked: isChecked, isPast, isToday })
  }

  return days
})

const getDayStyle = (day: { checked: boolean; isPast: boolean; isToday: boolean; day: number }) => {
  if (day.day === 0) return {}
  if (day.checked) {
    return { background: '#10b981', color: '#fff', fontWeight: '600' }
  }
  if (day.isToday) {
    return { background: '#dbeafe', color: '#2563eb', fontWeight: '700', border: '2px solid #3b82f6' }
  }
  if (day.isPast) {
    return { color: '#ef4444', textDecoration: 'line-through' }
  }
  return { color: '#374151' }
}

const loadMonthHistory = async () => {
  if (!isLogin.value) return
  try {
    const year = currentYear.value
    const month = currentMonth.value
    const monthStart = `${year}-${String(month).padStart(2, '0')}-01`
    const monthEnd = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`
    const data: any = await fetchCheckinHistory({ page: 1, pageSize: 200 })
    const list = data?.list || []
    const set = new Set<string>()
    let monthCount = 0
    for (const r of list) {
      const d = typeof r.checkin_date === 'string' ? r.checkin_date.substring(0, 10) : String(r.checkin_date)
      if (d >= monthStart && d <= monthEnd) {
        set.add(d)
        monthCount++
      }
    }
    checkedDays.value = set
    monthCheckinCount.value = data?.total || monthCount
  } catch {}
}

const loadStatus = async () => {
  if (!isLogin.value) return
  try {
    const data: any = await fetchCheckinStatus()
    checkedToday.value = data?.checkedToday || false
    consecutiveDays.value = data?.consecutive || 0
    if (data?.todayRecord) {
      todayReward.value = {
        pointsEarned: data.todayRecord.points_earned || 0,
        experienceEarned: data.todayRecord.experience_earned || 0
      }
    }
    if (data?.nextReward) {
      const nr = data.nextReward
      const parts = []
      if (nr.points) parts.push(`${nr.points}积分`)
      if (nr.experience) parts.push(`${nr.experience}经验`)
      if (nr.balance) parts.push(`${nr.balance}余额`)
      if (parts.length) {
        nextRewardText.value = `明天签到可得：${parts.join(' + ')}`
      }
    }
    if (data?.makeupConfig) {
      makeupConfig.value = {
        pointsCost: Number(data.makeupConfig.pointsCost) || 0,
        balanceCost: Number(data.makeupConfig.balanceCost) || 0,
        freeCount: Number(data.makeupConfig.freeCount) || 0
      }
    }
  } catch {}
}

const loadRanking = async () => {
  rankingLoading.value = true
  try {
    const month = `${currentYear.value}-${String(currentMonth.value).padStart(2, '0')}`
    const data: any = await fetchCheckinRanking({ month })
    ranking.value = data?.ranking || []
  } catch {} finally {
    rankingLoading.value = false
  }
}

const loadMakeupsAvailable = async () => {
  if (!isLogin.value) return
  try {
    const data: any = await fetchMakeupsAvailable()
    makeupAvailable.value = {
      cardCount: Number(data?.cardCount) || 0,
      membershipMakeups: Number(data?.membershipMakeups) || 0,
      freeMakeups: Number(data?.freeMakeups) || 0,
      giftFreeMakeups: Number(data?.giftFreeMakeups) || 0
    }
  } catch {}
}

const handleCheckin = async () => {
  if (!isLogin.value) {
    useLoginModalStore().open()
    return
  }
  checkingIn.value = true
  try {
    const data: any = await doCheckin()
    checkedToday.value = true
    consecutiveDays.value = data?.consecutive || consecutiveDays.value + 1
    todayReward.value = {
      pointsEarned: data?.pointsEarned || 0,
      experienceEarned: data?.experienceEarned || 0
    }
    monthCheckinCount.value++
    ElMessage.success(data?.message || '签到成功')
    setTimeout(() => {
      loadMonthHistory()
      loadRanking()
    }, 500)
  } catch (e: any) {
    ElMessage.error(e?.message || '签到失败')
  } finally {
    checkingIn.value = false
  }
}

const handleMakeupCard = async () => {
  if (!makeupForm.value.cardNo || !makeupForm.value.password) {
    makeupMsg.value = '请输入补签卡号和密码'
    makeupMsgColor.value = '#ef4444'
    return
  }
  makingUp.value = true
  makeupMsg.value = ''
  try {
    const data: any = await doMakeupCheckin({
      cardNo: makeupForm.value.cardNo,
      password: makeupForm.value.password,
      date: makeupTargetDate.value || undefined
    })
    consecutiveDays.value = data?.consecutive || consecutiveDays.value
    makeupMsg.value = data?.message || '补签成功'
    makeupMsgColor.value = '#00bfa5'
    ElMessage.success(data?.message || '补签成功')
    showMakeupDialog.value = false
    loadMonthHistory()
    loadStatus()
    loadRanking()
    loadMakeupsAvailable()
  } catch (e: any) {
    makeupMsg.value = e?.message || '补签失败，请检查卡密'
    makeupMsgColor.value = '#ef4444'
    ElMessage.error(e?.message || '补签失败')
  } finally {
    makingUp.value = false
  }
}

const handleMakeupFree = async () => {
  makingUp.value = true
  makeupMsg.value = ''
  try {
    const data: any = await doMakeupCheckinFree(makeupTargetDate.value || undefined)
    const isTodayMakeup = !makeupTargetDate.value || makeupTargetDate.value === new Date().toISOString().substring(0, 10)
    if (isTodayMakeup) checkedToday.value = true
    consecutiveDays.value = data?.consecutive || consecutiveDays.value
    if (isTodayMakeup) {
      todayReward.value = {
        pointsEarned: data?.pointsEarned || 0,
        experienceEarned: data?.experienceEarned || 0
      }
      monthCheckinCount.value++
    }
    makeupMsg.value = data?.message || '免费补签成功'
    makeupMsgColor.value = '#00bfa5'
    ElMessage.success(data?.message || '免费补签成功')
    showMakeupDialog.value = false
    loadMonthHistory()
    loadStatus()
    loadRanking()
    loadMakeupsAvailable()
  } catch (e: any) {
    makeupMsg.value = e?.message || '免费补签失败'
    makeupMsgColor.value = '#ef4444'
    ElMessage.error(e?.message || '免费补签失败')
  } finally {
    makingUp.value = false
  }
}

const handleMakeupPoints = async () => {
  makingUp.value = true
  makeupMsg.value = ''
  try {
    const data: any = await doMakeupCheckinByPoints(makeupTargetDate.value || undefined)
    const isTodayMakeup = !makeupTargetDate.value || makeupTargetDate.value === new Date().toISOString().substring(0, 10)
    if (isTodayMakeup) checkedToday.value = true
    consecutiveDays.value = data?.consecutive || consecutiveDays.value
    if (isTodayMakeup) {
      todayReward.value = {
        pointsEarned: data?.pointsEarned || 0,
        experienceEarned: data?.experienceEarned || 0
      }
      monthCheckinCount.value++
    }
    makeupMsg.value = data?.message || '积分补签成功'
    makeupMsgColor.value = '#00bfa5'
    ElMessage.success(data?.message || '积分补签成功')
    showMakeupDialog.value = false
    loadMonthHistory()
    loadStatus()
    loadRanking()
    loadMakeupsAvailable()
  } catch (e: any) {
    makeupMsg.value = e?.message || '积分补签失败'
    makeupMsgColor.value = '#ef4444'
    ElMessage.error(e?.message || '积分补签失败')
  } finally {
    makingUp.value = false
  }
}

const handleMakeupBalance = async () => {
  makingUp.value = true
  makeupMsg.value = ''
  try {
    const data: any = await doMakeupCheckinByBalance(makeupTargetDate.value || undefined)
    const isTodayMakeup = !makeupTargetDate.value || makeupTargetDate.value === new Date().toISOString().substring(0, 10)
    if (isTodayMakeup) checkedToday.value = true
    consecutiveDays.value = data?.consecutive || consecutiveDays.value
    if (isTodayMakeup) {
      todayReward.value = {
        pointsEarned: data?.pointsEarned || 0,
        experienceEarned: data?.experienceEarned || 0
      }
      monthCheckinCount.value++
    }
    makeupMsg.value = data?.message || '余额补签成功'
    makeupMsgColor.value = '#00bfa5'
    ElMessage.success(data?.message || '余额补签成功')
    showMakeupDialog.value = false
    loadMonthHistory()
    loadStatus()
    loadRanking()
    loadMakeupsAvailable()
  } catch (e: any) {
    makeupMsg.value = e?.message || '余额补签失败'
    makeupMsgColor.value = '#ef4444'
    ElMessage.error(e?.message || '余额补签失败')
  } finally {
    makingUp.value = false
  }
}

const openMakeupDialog = (dateStr?: string) => {
  makeupTargetDate.value = dateStr || ''
  showMakeupDialog.value = true
}

watch(showMakeupDialog, (val) => {
  if (val) {
    makeupMsg.value = ''
    makeupForm.value = { cardNo: '', password: '' }
    if (makeupTabs.value.length > 0) {
      makeupTab.value = makeupTabs.value[0].key
    }
  }
})

onMounted(() => {
  if (!isLogin.value) return
  loadStatus()
  loadMonthHistory()
  loadRanking()
  loadMakeupsAvailable()
})

</script>

