<template>
  <div class="sm-page">
    <div class="sm-navbar">
      <button class="sm-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="sm-nav-title">标签管理</span>
      <div style="width:22px" />
    </div>

    <div class="sm-content">
      <div class="sm-search-bar">
        <svg class="sm-search-icon-s" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <input v-model="keyword" placeholder="搜索标签..." class="sm-search-input-s" @input="onSearch" />
        <button v-if="keyword" class="sm-search-clear-s" @click="keyword='';loadTags()">&times;</button>
      </div>

      <div class="sm-toolbar">
        <button class="sm-btn sm-btn-primary" @click="openCreateDialog">新增标签</button>
        <button class="sm-btn sm-btn-ghost" @click="doSyncTags">同步标签</button>
        <button class="sm-btn sm-btn-ghost" @click="showMergeDialog = true">合并标签</button>
      </div>

      <div class="sm-sort-row">
        <span class="sm-sort-label">排序:</span>
        <button class="sm-sort-btn" :class="{ on: sortBy === 'post_count' }" @click="sortBy='post_count';loadTags()">帖子数</button>
        <button class="sm-sort-btn" :class="{ on: sortBy === 'name' }" @click="sortBy='name';loadTags()">名称</button>
      </div>

      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadTags" />
      <div v-else-if="!tags.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
        </div>
        <p class="sm-empty-title">暂无标签</p>
        <p class="sm-empty-desc">点击"新增标签"创建第一个标签</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="t in tags" :key="t.id" class="sm-card" :class="{ off: t.status === 'hidden' }">
          <div class="sm-card-body">
            <div class="sm-card-left">
              <span class="sm-card-icon-letter" :style="{ background: tagColor(t.name) }">{{ t.name?.charAt(0) || '#' }}</span>
              <div class="sm-card-info">
                <div class="sm-card-title">
                  {{ t.name }}
                  <span v-if="t.is_official || t.isOfficial" class="sm-tag sm-tag-essence">官方</span>
                  <span :class="t.status === 'hidden' ? 'sm-tag sm-tag-off' : 'sm-tag sm-tag-ok'">{{ t.status === 'hidden' ? '已隐藏' : '显示中' }}</span>
                </div>
                <div class="sm-card-meta">
                  <span class="sm-meta-item">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    {{ t.post_count || t.postCount || 0 }} 帖
                  </span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ fmtTime(t.create_time || t.createTime) }}</span>
                </div>
              </div>
            </div>
            <div class="sm-card-acts">
              <button class="sm-acts-btn" @click="openEditDialog(t)">编辑</button>
              <button class="sm-acts-btn sm-acts-toggle" @click="toggleTagStatus(t)">{{ t.status === 'hidden' ? '显示' : '隐藏' }}</button>
              <button class="sm-acts-btn sm-acts-del" @click="confirmDelete(t)">删除</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <div v-if="showFormDialog" class="sm-overlay" @click.self="showFormDialog = false">
        <div class="sm-dialog" @click.stop>
          <div class="sm-dialog-head">
            <h3>{{ editingTag ? '编辑标签' : '新增标签' }}</h3>
            <button class="sm-dialog-close" @click="showFormDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>标签名称 *</label>
              <input v-model="form.name" placeholder="请输入标签名称" maxlength="30" />
            </div>
            <div class="sm-field">
              <label>官方标签</label>
              <div class="sm-visibility-toggle">
                <button class="sm-vis-opt" :class="{ on: form.is_official }" @click="form.is_official = true">是</button>
                <button class="sm-vis-opt" :class="{ on: !form.is_official }" @click="form.is_official = false">否</button>
              </div>
            </div>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showFormDialog = false">取消</button>
            <button class="sm-btn sm-btn-primary" @click="saveTag" :disabled="!form.name || submitting">{{ submitting ? '保存中...' : '保存' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <Teleport to="body">
      <div v-if="showMergeDialog" class="sm-overlay" @click.self="showMergeDialog = false">
        <div class="sm-dialog sm-dialog-section" @click.stop>
          <div class="sm-dialog-head">
            <h3>合并标签</h3>
            <button class="sm-dialog-close" @click="showMergeDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>源标签 (将被合并)</label>
              <select v-model="mergeSourceId" class="sm-select">
                <option :value="null" disabled>请选择源标签</option>
                <option v-for="t in allTags" :key="'s'+t.id" :value="t.id" :disabled="t.id === mergeTargetId">{{ t.name }} ({{ t.post_count || t.postCount || 0 }}帖)</option>
              </select>
            </div>
            <div class="sm-field">
              <label>目标标签 (合并到)</label>
              <select v-model="mergeTargetId" class="sm-select">
                <option :value="null" disabled>请选择目标标签</option>
                <option v-for="t in allTags" :key="'t'+t.id" :value="t.id" :disabled="t.id === mergeSourceId">{{ t.name }} ({{ t.post_count || t.postCount || 0 }}帖)</option>
              </select>
            </div>
            <p class="sm-merge-hint">合并后源标签将被删除，其下所有帖子将转移到目标标签</p>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showMergeDialog = false">取消</button>
            <button class="sm-btn sm-btn-primary" @click="doMerge" :disabled="!mergeSourceId || !mergeTargetId || mergeSourceId === mergeTargetId || submitting">{{ submitting ? '合并中...' : '确认合并' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <Teleport to="body">
      <div v-if="showConfirmDialog" class="sm-overlay" @click.self="showConfirmDialog = false">
        <div class="sm-dialog sm-dialog-confirm" @click.stop>
          <div class="sm-dialog-head">
            <h3>确认删除</h3>
            <button class="sm-dialog-close" @click="showConfirmDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <p class="sm-confirm-text">确定删除标签「{{ confirmTarget?.name }}」？此操作不可撤销。</p>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showConfirmDialog = false">取消</button>
            <button class="sm-btn sm-btn-danger" @click="doDelete">确认删除</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'

const tags = ref([])
const allTags = ref([])
const loading = ref(false)
const error = ref('')
const keyword = ref('')
const sortBy = ref('post_count')
const submitting = ref(false)

const showFormDialog = ref(false)
const editingTag = ref(null)
const form = ref({ name: '', is_official: false })

const showMergeDialog = ref(false)
const mergeSourceId = ref(null)
const mergeTargetId = ref(null)

const showConfirmDialog = ref(false)
const confirmTarget = ref(null)

const tagColors = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#E11D48','#7C3AED']

function tagColor(name) {
  let h = 0
  for (let i = 0; i < (name || '').length; i++) h = name.charCodeAt(i) + ((h << 5) - h)
  return tagColors[Math.abs(h) % tagColors.length]
}

function fmtTime(t) {
  if (!t) return ''
  const dt = new Date(t)
  if (isNaN(dt.getTime())) return t.slice(0, 10)
  const d = Date.now() - dt.getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}

let searchTimer = null
function onSearch() {
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = setTimeout(() => loadTags(), 300)
}

async function loadTags() {
  loading.value = true
  error.value = ''
  try {
    const params = { sort: sortBy.value }
    if (keyword.value) params.keyword = keyword.value
    const res = await request.get({ url: '/api/community/tags', params })
    const data = res?.data || res || {}
    const list = data.records || data.list || data || []
    tags.value = list
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '加载标签失败'
  } finally {
    loading.value = false
  }
}

async function loadAllTags() {
  try {
    const res = await request.get({ url: '/api/community/tags', params: { sort: 'name' } })
    const data = res?.data || res || {}
    allTags.value = data.records || data.list || data || []
  } catch (e) { /* ignore */ }
}

async function doSyncTags() {
  submitting.value = true
  try {
    await request.post({ url: '/api/community/tags/sync' })
    await loadTags()
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '同步失败'
  } finally {
    submitting.value = false
  }
}

function openCreateDialog() {
  editingTag.value = null
  form.value = { name: '', is_official: false }
  showFormDialog.value = true
}

function openEditDialog(tag) {
  editingTag.value = tag
  form.value = {
    name: tag.name || '',
    is_official: !!(tag.is_official || tag.isOfficial)
  }
  showFormDialog.value = true
}

async function saveTag() {
  submitting.value = true
  try {
    const data = { name: form.value.name, is_official: form.value.is_official }
    if (editingTag.value) data.id = editingTag.value.id
    await request.post({ url: '/api/community/tags', data })
    showFormDialog.value = false
    await loadTags()
    await loadAllTags()
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '保存失败'
  } finally {
    submitting.value = false
  }
}

async function toggleTagStatus(tag) {
  try {
    const newStatus = tag.status === 'hidden' ? 'active' : 'hidden'
    await request.post({ url: '/api/community/tags', data: { id: tag.id, status: newStatus } })
    tag.status = newStatus
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '操作失败'
  }
}

function confirmDelete(tag) {
  confirmTarget.value = tag
  showConfirmDialog.value = true
}

async function doDelete() {
  if (!confirmTarget.value) return
  submitting.value = true
  try {
    await request.post({ url: '/api/community/tags', data: { id: confirmTarget.value.id, _delete: true } })
    showConfirmDialog.value = false
    confirmTarget.value = null
    await loadTags()
    await loadAllTags()
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '删除失败'
  } finally {
    submitting.value = false
  }
}

async function doMerge() {
  if (!mergeSourceId.value || !mergeTargetId.value) return
  submitting.value = true
  try {
    await request.post({ url: '/api/community/tags/merge', data: {
      source_id: mergeSourceId.value,
      target_id: mergeTargetId.value
    }})
    showMergeDialog.value = false
    mergeSourceId.value = null
    mergeTargetId.value = null
    await loadTags()
    await loadAllTags()
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '合并失败'
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  loadTags()
  loadAllTags()
})
</script>

<style scoped>
.sm-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.sm-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.sm-nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; transition: background .15s; }
.sm-nav-back:active { background: #f0f0f0; }
.sm-nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

.sm-content { padding: 16px; }

.sm-search-bar { display: flex; align-items: center; background: #f5f6f8; border: 1px solid #e5e7eb; border-radius: 10px; padding: 0 12px; margin-bottom: 14px; transition: border .15s; }
.sm-search-bar:focus-within { border-color: #6366F1; background: #fff; }
.sm-search-icon-s { flex-shrink: 0; margin-right: 8px; }
.sm-search-input-s { flex: 1; padding: 11px 0; border: none; background: transparent; font-size: 14px; color: #333; outline: none; }
.sm-search-clear-s { background: #d0d4da; border: none; width: 20px; height: 20px; border-radius: 50%; color: #fff; font-size: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }

.sm-toolbar { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; }

.sm-sort-row { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }
.sm-sort-label { font-size: 13px; color: #888; font-weight: 500; }
.sm-sort-btn { padding: 5px 14px; border-radius: 16px; border: 1px solid #e5e7eb; background: #fff; font-size: 12px; color: #888; cursor: pointer; font-weight: 500; transition: all .12s; }
.sm-sort-btn.on { background: #EEF2FF; color: #6366F1; border-color: #C7D2FE; }

.sm-loading { display: flex; justify-content: center; padding: 48px 0; }
.sm-spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.sm-error { text-align: center; padding: 48px 16px; }
.sm-error-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }

.sm-empty { text-align: center; padding: 72px 16px 64px; }
.sm-empty-icon { width: 72px; height: 72px; border-radius: 50%; background: #f2f3f5; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: #c0c4cc; }
.sm-empty-title { margin: 0; font-size: 15px; color: #a0a4ac; font-weight: 600; }
.sm-empty-desc { margin: 6px 0 0; font-size: 12px; color: #c8ccd4; }

.sm-btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; transition: all .12s; white-space: nowrap; font-weight: 500; }
.sm-btn:active { background: #f5f5f5; }
.sm-btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.sm-btn-primary:active { background: #4F46E5; }
.sm-btn-ghost { border-color: transparent; color: #6366F1; background: transparent; }
.sm-btn-ghost:active { background: #EEF2FF; }
.sm-btn-danger { background: #EF4444; color: #fff; border-color: #EF4444; }
.sm-btn-danger:active { background: #DC2626; }
.sm-btn:disabled { opacity: .5; cursor: not-allowed; }

.sm-list { display: flex; flex-direction: column; gap: 10px; }
.sm-card { background: #fff; border-radius: 12px; overflow: hidden; transition: box-shadow .15s; }
.sm-card:active { box-shadow: 0 2px 8px rgba(0,0,0,.06); }
.sm-card.off { opacity: .45; }
.sm-card-body { padding: 14px 16px; }
.sm-card-left { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
.sm-card-icon-letter { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; flex-shrink: 0; }
.sm-card-info { flex: 1; min-width: 0; }
.sm-card-title { font-size: 15px; font-weight: 700; color: #1a1a1a; display: flex; align-items: center; gap: 8px; line-height: 1.4; }
.sm-card-meta { font-size: 12px; color: #999; margin-top: 4px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.sm-meta-item { display: inline-flex; align-items: center; gap: 3px; }
.sm-meta-dot { width: 3px; height: 3px; border-radius: 50%; background: #d0d4da; flex-shrink: 0; }

.sm-tag { display: inline-block; font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 600; }
.sm-tag-off { background: #FEE2E2; color: #DC2626; }
.sm-tag-ok { background: #D1FAE5; color: #059669; }
.sm-tag-essence { background: #FEF3C7; color: #D97706; }

.sm-card-acts { display: flex; gap: 8px; flex-wrap: wrap; }
.sm-acts-btn { padding: 6px 14px; border-radius: 6px; border: 1px solid #e5e7eb; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all .12s; font-weight: 500; }
.sm-acts-btn:active { background: #f5f5f5; }
.sm-acts-toggle { color: #F59E0B; border-color: #FDE68A; }
.sm-acts-toggle:active { background: #FFFBEB; }
.sm-acts-del { color: #EF4444; border-color: #FECACA; }
.sm-acts-del:active { background: #FEF2F2; }

.sm-overlay { position: fixed; inset: 0; z-index: 999; background: rgba(0,0,0,.4); display: flex; align-items: flex-end; justify-content: center; }
.sm-dialog { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-width: 480px; max-height: 85vh; display: flex; flex-direction: column; }
.sm-dialog-section .sm-dialog-body { max-height: 60vh; }
.sm-dialog-head { display: flex; align-items: center; justify-content: space-between; padding: 18px 16px 14px; flex-shrink: 0; }
.sm-dialog-head h3 { margin: 0; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.sm-dialog-close { background: #f5f5f5; border: none; width: 28px; height: 28px; border-radius: 50%; font-size: 18px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; }
.sm-dialog-body { padding: 0 16px 16px; overflow-y: auto; flex: 1; }
.sm-dialog-btns { display: flex; gap: 10px; padding: 12px 16px 20px; justify-content: flex-end; flex-shrink: 0; border-top: 1px solid #f5f5f5; }

.sm-field { margin-bottom: 14px; }
.sm-field label { display: block; font-size: 13px; color: #666; margin-bottom: 5px; font-weight: 600; }
.sm-field input { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; color: #333; background: #f9fafb; outline: none; box-sizing: border-box; transition: border .15s; }
.sm-field input:focus { border-color: #6366F1; background: #fff; }
.sm-select { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; color: #333; background: #f9fafb; outline: none; box-sizing: border-box; transition: border .15s; appearance: auto; }
.sm-select:focus { border-color: #6366F1; }

.sm-visibility-toggle { display: flex; gap: 8px; }
.sm-vis-opt { flex: 1; height: 38px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #888; cursor: pointer; font-weight: 500; transition: all .12s; }
.sm-vis-opt.on { background: #6366F1; color: #fff; border-color: #6366F1; }

.sm-merge-hint { font-size: 12px; color: #F59E0B; margin-top: 4px; }
.sm-confirm-text { font-size: 14px; color: #555; line-height: 1.6; }
</style>
