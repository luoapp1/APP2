<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">{{ isEdit ? '编辑商品' : '新增商品' }}</span>
      <button class="save-btn" @click="save">保存</button>
    </div>

    <div v-if="pageLoading" class="loading"><span class="spinner" />加载中...</div>

    <div v-else class="form">
      <!-- 表单错误提示 -->
      <div v-if="showErrorBanner && formErrors.length" class="form-error-banner" @click="scrollToFirstError">
        <div class="error-banner-title">以下必填项未完成：</div>
        <div class="error-banner-list">
          <span v-for="(err, i) in formErrors" :key="i" class="error-banner-item" @click.stop="scrollToError(err)">
            {{ err.field }}{{ i < formErrors.length - 1 ? '、' : '' }}
          </span>
        </div>
        <div class="error-banner-tip">点击错误项自动滚动到对应位置</div>
      </div>

      <!-- 分组面板：基础信息 -->
      <div class="collapsible-panel">
        <div class="panel-header" @click="togglePanel('basic')">
          <span>基础信息</span>
          <span class="panel-arrow" :class="{ rotated: !collapsed.basic }">&#9660;</span>
        </div>
        <div class="panel-body" v-show="!collapsed.basic">
      <!-- 基本信息 -->
      <div class="section">
        <div class="section-title">基本信息</div>
        <div class="field">
          <label>商品名称 <span class="req">*</span></label>
          <input v-model="form.name" placeholder="请输入商品名称" class="input" data-field="name" />
        </div>
        <div class="field" v-if="isEdit">
          <label>创建账号</label>
          <input :value="form.createdByName || '-'" disabled class="input" style="background:#f5f5f5;color:#999;cursor:not-allowed" />
        </div>
        <div class="field">
          <label>副标题</label>
          <input v-model="form.subtitle" placeholder="请输入副标题" class="input" />
        </div>
        <div class="field">
          <label>商品类型 <span class="req">*</span></label>
          <select v-model="form.productType" class="input">
            <option value="virtual_auto">自动虚拟商品（卡密/邀请码等自动发货）</option>
            <option value="virtual_manual">手动发货虚拟商品</option>
            <option value="physical">实物商品</option>
          </select>
        </div>
        <div class="field">
          <label>价格类型 <span class="req">*</span></label>
          <div class="checkbox-group" data-field="paymentMethods">
            <label v-for="pm in paymentMethodOptions" :key="pm.value" class="check-label">
              <input type="checkbox" :value="pm.value" v-model="form.paymentMethods" /> {{ pm.label }}
            </label>
          </div>
          <div v-if="!form.paymentMethods.length" class="field-hint-warn">请至少选择一种支付方式，否则商品将无法被购买</div>
        </div>
        <div class="field-row">
          <div class="field">
            <label>余额售价</label>
            <input v-model.number="form.price" type="number" min="0" step="0.01" class="input" />
          </div>
          <div class="field">
            <label>原价</label>
            <input v-model.number="form.originalPrice" type="number" min="0" step="0.01" class="input" />
          </div>
          <div class="field">
            <label>库存</label>
            <input v-model.number="form.stock" type="number" min="0" class="input" />
          </div>
        </div>
        <div class="field" v-if="form.productType === 'physical'">
          <label>运费（元）</label>
          <input v-model.number="form.freight" type="number" min="0" step="0.01" class="input" placeholder="0表示免运费" />
        </div>
        <div class="field">
          <label>分类</label>
          <select v-model="form.categoryId" class="input">
            <option :value="0">未分类</option>
            <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
          </select>
        </div>
        <div class="field">
          <label>销售开始时间 <span class="hint-text">（设置后商品将在指定时间上线，留空则立即可售）</span></label>
          <input type="datetime-local" v-model="form.saleStartTime" class="input" />
        </div>
        <div class="field">
          <label>销售截止时间 <span class="hint-text">（设置后到期自动下架，留空则不限时）</span></label>
          <input type="datetime-local" v-model="form.saleEndTime" class="input" />
        </div>
      </div>

      <!-- 封面图 -->
      <div class="section">
        <div class="section-title">封面图</div>
        <div class="field">
          <div class="field-row">
            <input v-model="coverImageInput" placeholder="输入封面图URL" class="input" @blur="setCoverImage" />
            <label class="upload-btn">
              <input type="file" accept="image/*" style="display:none" @change="(e) => handleCoverUpload(e)" />
              上传
            </label>
          </div>
          <div v-if="coverUploading" class="upload-progress">上传中...</div>
          <div v-if="form.coverImage" class="cover-preview">
            <img :src="fixImgUrl(form.coverImage)"  loading="lazy" />
            <button @click="form.coverImage = ''" class="remove-img">&times;</button>
          </div>
        </div>
      </div>

      <!-- 商品图片 -->
      <div class="section">
        <div class="section-title">商品图片</div>
        <div v-if="(form.images || []).length" class="img-list">
          <div v-for="(img, i) in form.images" :key="img" class="img-item">
            <img :src="fixImgUrl(img.url || img)"  loading="lazy" />
            <button @click="form.images.splice(i, 1)" class="remove-img">&times;</button>
          </div>
        </div>
        <div class="field-row">
          <input v-model="newImageUrl" placeholder="输入图片URL" class="input" />
          <button @click="addImage" class="btn-sm">添加</button>
          <label class="upload-btn btn-sm">
            <input type="file" accept="image/*" style="display:none" @change="(e) => handleImageUpload(e)" />
            上传图片
          </label>
        </div>
        <div v-if="imgUploading" class="upload-progress">上传中...</div>
      </div>

      <!-- 商品描述 -->
      <div class="section">
        <div class="section-title">商品描述</div>
        <textarea v-model="form.description" class="input textarea" placeholder="请输入商品描述（支持HTML）" rows="6" />
      </div>

      <!-- 状态 -->
      <div class="section">
        <div class="section-title">发布状态</div>
        <div class="field">
          <select v-model="form.status" class="input">
            <option value="draft">草稿</option>
            <option value="published">上架</option>
            <option value="offline">下架</option>
          </select>
        </div>
      </div>
        </div><!-- /.panel-body -->
      </div><!-- /.collapsible-panel -->

      <!-- 分组面板：套餐定价 -->
      <div class="collapsible-panel">
        <div class="panel-header" @click="togglePanel('pricing')">
          <span>套餐定价</span>
          <span class="panel-arrow" :class="{ rotated: !collapsed.pricing }">&#9660;</span>
        </div>
        <div class="panel-body" v-show="!collapsed.pricing">
      <!-- 商品规格与套餐管理 -->
      <div class="section">
        <div class="section-title">商品规格与套餐</div>

        <!-- 多规格开关 -->
        <div class="field" style="margin-bottom:12px">
          <label class="check-label" style="font-weight:600">
            <input type="checkbox" v-model="form.useSpecs" @change="onUseSpecsChange" /> 启用多规格
          </label>
          <div class="hint" style="margin-top:4px;font-size:11px;color:#999">
            开启后可添加多个规格，每个规格下包含不同套餐（如"颜色"规格下有"红色""蓝色"套餐）
          </div>
        </div>

        <!-- 平铺套餐模式（无规格） -->
        <template v-if="!form.useSpecs">
          <template v-if="(form.flatPackages || []).length">
            <div class="spec-list">
              <div class="spec-card">
              <div class="spec-header">
                <div class="spec-label">套餐列表</div>
                <div class="spec-header-right">
                  <button @click="batchGenerateFlat" class="btn-spec-action" style="background:#eee;color:#666;margin-right:6px">批量生成</button>
                  <button @click="addFlatPackage" class="btn-spec-action">+ 套餐</button>
                </div>
              </div>
              <div class="pkg-list">
                <div v-for="(pkg, pi) in form.flatPackages" :key="pi" class="pkg-card" :class="{ 'dragging': dragIdx === pi }" draggable="true" @dragstart="onDragStartFlat(pi, $event)" @dragover="onDragOverFlat($event)" @drop="onDropFlat(pi)">
                  <div class="pkg-header">
                    <span class="drag-handle" title="拖拽排序">&#x2630;</span>
                    <span class="pkg-index">套餐 {{ pi + 1 }}</span>
                    <span v-if="pkg.cardConfig?.enabled" class="pkg-badge auto">自动发货</span>
                    <button @click="copyFlatPackage(pi)" class="btn-sm" style="color:#666;margin-right:4px">复制</button>
                    <button @click="form.flatPackages.splice(pi, 1)" class="btn-sm del">删除</button>
                  </div>
                  <div class="field">
                    <label>套餐名称 <span class="req">*</span></label>
                    <input v-model="pkg.name" placeholder="如：10000点券" class="input" :data-field="'pkg-' + pi + '-name'" />
                  </div>
                  <div class="package-price-row">
                    <div class="field" style="flex:1"><label>售价</label><input v-model.number="pkg.price" type="number" min="0" step="0.01" placeholder="0.00" class="input" /></div>
                    <div class="field" style="flex:1"><label>原价</label><input v-model.number="pkg.originalPrice" type="number" min="0" step="0.01" placeholder="划线价" class="input" /></div>
                    <div class="field" style="flex:1"><label>积分售价</label><input v-model.number="pkg.pointsPrice" type="number" min="0" placeholder="0" class="input" /></div>
                  </div>
                  <div class="field"><label>库存</label>
                    <div style="display:flex;align-items:center;gap:6px">
                      <input v-model.number="pkg.stock" type="number" min="0" placeholder="0表示不限库存" class="input" :class="{ 'stock-low': pkg.stock > 0 && pkg.stock <= form.stockWarning }" style="flex:1" />
                      <span v-if="pkg.stock > 0 && pkg.stock <= form.stockWarning" class="stock-warn-tag">库存紧张</span>
                    </div>
                  </div>
                  <div class="field"><label>限购次数</label>
                    <input v-model.number="pkg.purchaseLimit" type="number" min="0" placeholder="0表示不限购" class="input" style="width:120px" />
                  </div>
                  <div class="field">
                    <label>套餐图片</label>
                    <div style="display:flex;align-items:center;gap:8px">
                      <img v-if="pkg.image" :src="fixImgUrl(pkg.image)" style="width:48px;height:48px;object-fit:cover;border-radius:6px" />
                      <span v-if="!pkg.image" style="color:#ccc;font-size:12px">可选</span>
                      <label class="upload-btn btn-sm" style="margin:0">
                        <input type="file" accept="image/*" style="display:none" @change="(e: any) => uploadPackageImage(e, pkg)" />
                        {{ pkg.image ? '更换' : '上传' }}
                      </label>
                    </div>
                  </div>

                  <!-- 自动发货配置 -->
                  <div v-if="form.productType === 'virtual_auto'" class="package-delivery">
                    <div class="delivery-toggle" :class="{ active: expandedCardConfigKey === ('fp-' + pi), configured: pkg.cardConfig?.enabled }" @click="toggleCardConfig('fp-' + pi)">
                      <div class="delivery-toggle-left">
                        <svg class="delivery-icon" viewBox="0 0 24 24" fill="none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg>
                        <span>自动发货</span>
                        <span v-if="pkg.cardConfig?.enabled" class="delivery-status configured">已启用</span>
                        <span v-else class="delivery-status">未启用</span>
                      </div>
                      <span class="toggle-arrow" :class="{ expanded: expandedCardConfigKey === ('fp-' + pi) }">&#9660;</span>
                    </div>
                    <div v-if="expandedCardConfigKey === ('fp-' + pi)" class="delivery-body">
                      <div class="field" style="margin-top:0"><label class="check-label"><input type="checkbox" v-model="pkg.cardConfig.enabled" /> 启用自动发货</label></div>
                      <template v-if="pkg.cardConfig.enabled">
                        <div class="field"><label>发货类型 <span class="req">*</span></label>
                          <select v-model="pkg.cardConfig.type" class="input">
                            <option value="card_key">卡密</option><option value="auto_recharge">自动充值</option><option value="invite_code">邀请码</option><option value="custom">自定义卡密</option><option value="card_pool">选择卡池</option><option value="text">文本内容</option><option value="decoration">装饰品</option>
                          </select>
                        </div>
                        <template v-if="pkg.cardConfig.type === 'card_key'">
                          <div class="field"><label>卡密子类型 <span class="req">*</span></label><select v-model="pkg.cardConfig.cardType" class="input"><option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option><option value="free">通用卡</option></select></div>
                          <template v-if="pkg.cardConfig.cardType === 'membership'"><div class="field"><label>会员等级</label><select v-model="pkg.cardConfig.targetId" class="input"><option :value="0">请选择会员等级</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div></template>
                          <div class="field-row"><div class="field"><label>{{ pkg.cardConfig.cardType === 'membership' ? '有效天数' : '发放数量' }}</label><input v-model.number="pkg.cardConfig.value" type="number" min="0" class="input" /></div><div class="field" v-if="pkg.cardConfig.cardType === 'membership'"><label>时间单位</label><select v-model="pkg.cardConfig.durationUnit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div></div>
                          <div class="field-row" v-if="pkg.cardConfig.cardType === 'membership'"><div class="field"><label>额外积分</label><input v-model.number="pkg.cardConfig.extraPoints" type="number" min="0" class="input" /></div><div class="field"><label>额外余额</label><input v-model.number="pkg.cardConfig.extraBalance" type="number" min="0" step="0.01" class="input" /></div><div class="field"><label>额外经验</label><input v-model.number="pkg.cardConfig.extraExperience" type="number" min="0" class="input" /></div></div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'auto_recharge'">
                          <div class="field"><label>充值类型 <span class="req">*</span></label><select v-model="pkg.cardConfig.cardType" class="input"><option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option></select></div>
                          <template v-if="pkg.cardConfig.cardType === 'membership'"><div class="field"><label>会员等级</label><select v-model="pkg.cardConfig.targetId" class="input"><option :value="0">请选择会员等级</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div></template>
                          <div class="field-row"><div class="field"><label>{{ pkg.cardConfig.cardType === 'membership' ? '有效天数' : '充值数量' }}</label><input v-model.number="pkg.cardConfig.value" type="number" min="0" class="input" /></div><div class="field" v-if="pkg.cardConfig.cardType === 'membership'"><label>时间单位</label><select v-model="pkg.cardConfig.durationUnit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div></div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'invite_code'">
                          <div class="field"><label>奖励类型</label><select v-model="pkg.cardConfig.rewardType" class="input"><option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option></select></div>
                          <template v-if="pkg.cardConfig.rewardType === 'membership'"><div class="field"><label>目标会员等级</label><select v-model="pkg.cardConfig.targetId" class="input"><option :value="0">请选择会员等级</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div></template>
                          <div class="field-row"><div class="field"><label>{{ pkg.cardConfig.rewardType === 'membership' ? '奖励时长' : '奖励数量' }}</label><input v-model.number="pkg.cardConfig.rewardValue" type="number" min="0" class="input" /></div><div class="field" v-if="pkg.cardConfig.rewardType === 'membership'"><label>时间单位</label><select v-model="pkg.cardConfig.rewardDurationUnit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div></div>
                          <div class="field-row"><div class="field"><label>生成数量</label><input v-model.number="pkg.cardConfig.inviteCodeCount" type="number" min="1" class="input" placeholder="每次发放数量" /></div><div class="field"><label>最大使用次数</label><input v-model.number="pkg.cardConfig.maxUses" type="number" min="1" class="input" placeholder="每个邀请码可用次数" /></div></div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'custom'">
                          <div class="field"><label>卡号密码（一行一个，格式：卡号:密码）</label><textarea v-model="pkg.cardConfig.customCardsText" class="input textarea" placeholder="AA001:pass123&#10;AA002:pass456" rows="5" @blur="syncCustomCardsForPkg(pkg)" /><div class="hint">共 {{ getCustomCardCountForPkg(pkg) }} 张卡，库存自动同步</div></div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'card_pool'">
                          <div class="field"><label>选择卡池 <span class="req">*</span></label>
                            <label class="checkbox-label" style="margin-bottom:6px"><input type="checkbox" v-model="pkg.cardConfig._multiPool" @change="onMultiPoolChange(pkg)" /> 多卡池轮换</label>
                            <select v-if="!pkg.cardConfig._multiPool" v-model="pkg.cardConfig.poolId" class="input">
                              <option :value="0">请选择卡池</option>
                              <option v-for="pool in cardPools" :key="pool.id" :value="pool.id">{{ pool.name }} ({{ pool.total_count }}张)</option>
                            </select>
                            <div v-else>
                              <div v-for="pool in cardPools" :key="pool.id" class="checkbox-label" style="margin-bottom:2px">
                                <label><input type="checkbox" :value="pool.id" v-model="pkg.cardConfig.poolIds" /> {{ pool.name }} ({{ pool.total_count }}张)</label>
                              </div>
                              <div class="field" style="margin-top:4px"><label>发放模式</label>
                                <select v-model="pkg.cardConfig.poolMode" class="input"><option value="random">随机</option><option value="sequential">顺序</option></select>
                              </div>
                            </div>
                          </div>
                          <div class="field" style="margin-top:4px">
                            <button class="btn-sm" @click="router.push('/appstore/card-pool')" style="color:#FF6B6B;text-decoration:underline">管理卡池</button>
                          </div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'text'">
                          <div class="field"><label>文本内容 <span class="req">*</span></label><textarea v-model="pkg.cardConfig.textContent" class="input textarea" placeholder="输入购买后显示给用户的文本内容（网盘链接、激活码说明等）" rows="4" /></div>
                        </template>
                        <template v-if="pkg.cardConfig.type === 'decoration'">
                          <div class="field"><label>装饰品类型 <span class="req">*</span></label>
                            <select v-model="pkg.cardConfig.decorationSubtype" class="input" @change="loadPkgDecorations(pkg)">
                              <option value="">请选择</option>
                              <option value="avatar_frame">头像框</option>
                              <option value="title">称号</option>
                              <option value="avatar_effect">头像特效</option>
                              <option value="comment_background">评论背景墙</option>
                              <option value="nickname_effect">昵称特效</option>
                              <option value="home_bg">主页背景图</option>
                            </select>
                          </div>
                          <div class="field" v-if="(pkg.cardConfig._decorations || []).length">
                            <label>选择装饰品</label>
                            <div class="decoration-grid">
                              <div v-for="d in pkg.cardConfig._decorations" :key="d.id" class="decoration-card" :class="{ active: pkg.cardConfig.decorationId === d.id }" @click="pkg.cardConfig.decorationId = d.id">
                                <img v-if="d.image_url" :src="$fixImgUrl(d.image_url)" class="decoration-thumb" />
                                <span class="decoration-name">{{ d.name }}</span>
                              </div>
                            </div>
                            <div class="field mt-2">
                              <label>有效期天数（0=永久）</label>
                              <input v-model.number="pkg.cardConfig.decorationDurationDays" type="number" min="0" class="input" placeholder="0" />
                            </div>
                          </div>
                        </template>
                      </template>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </template>
          <div v-if="!(form.flatPackages || []).length" class="pkg-empty">暂无套餐，请点击"+ 套餐"添加</div>
          <button @click="addFlatPackage" class="btn-add-package">+ 套餐</button>
        </template>
        <template v-else>
              <div v-for="(spec, si) in form.specs" :key="si" class="spec-card">
                <div class="spec-header">
                  <div class="spec-label">规格 {{ si + 1 }}</div>
                  <div class="spec-header-right">
                    <input v-model="spec.name" placeholder="规格名称（如：颜色、尺寸）" class="input" style="width:120px;height:28px;font-size:12px" />
                    <button @click="addPackage(si)" class="btn-spec-action">+ 套餐</button>
                    <button @click="form.specs.splice(si, 1)" class="btn-sm del">删除</button>
                  </div>
                </div>
                <div class="pkg-list">
                  <div v-for="(pkg, pi) in spec.packages" :key="pi" class="pkg-card">
                    <div class="pkg-header">
                      <span class="pkg-index">套餐 {{ pi + 1 }}</span>
                      <button @click="spec.packages.splice(pi, 1)" class="btn-sm del">删除</button>
                    </div>
                    <div class="field"><label>套餐名称 <span class="req">*</span></label><input v-model="pkg.name" class="input" /></div>
                    <div class="package-price-row">
                      <div class="field" style="flex:1"><label>售价</label><input v-model.number="pkg.price" type="number" min="0" step="0.01" class="input" /></div>
                      <div class="field" style="flex:1"><label>积分售价</label><input v-model.number="pkg.pointsPrice" type="number" min="0" class="input" /></div>
                    </div>
                    <div class="field"><label>限购次数</label><input v-model.number="pkg.purchaseLimit" type="number" min="0" placeholder="0表示不限购" class="input" style="width:120px" /></div>
                  </div>
                  <div v-if="!(spec.packages || []).length" class="pkg-empty">暂无套餐，请点击"+ 套餐"添加</div>
                </div>
              </div>
              <button @click="addSpec" class="btn-add-package">+ 添加规格</button>
            </template>
          </div>
            </div><!-- /.panel-body -->
          </div><!-- /.collapsible-panel -->

      <!-- 分组面板：高级配置 -->
      <div class="collapsible-panel">
        <div class="panel-header" @click="togglePanel('advanced')">
          <span>高级配置</span>
          <span class="panel-arrow" :class="{ rotated: !collapsed.advanced }">&#9660;</span>
        </div>
        <div class="panel-body" v-show="!collapsed.advanced">
      <!-- 商品参数 -->
      <div class="section">
        <div class="section-title">商品参数</div>
        <div v-if="(form.productParams || []).length" class="param-list">
          <div v-for="(p, i) in form.productParams" :key="i" class="field-row" style="margin-bottom:6px">
            <input v-model="p.name" placeholder="参数名" class="input" style="flex:1" />
            <input v-model="p.value" placeholder="参数值" class="input" style="flex:2" />
            <button @click="form.productParams.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
        <button @click="form.productParams = form.productParams || []; form.productParams.push({ name: '', value: '' })" class="btn-sm">+ 添加参数</button>
      </div>

      <!-- 服务保障 -->
      <div class="section">
        <div class="section-title">服务保障</div>
        <div class="checkbox-group">
          <label v-for="svc in defaultServices" :key="svc" class="check-label">
            <input type="checkbox" :value="svc" v-model="form.services" /> {{ svc }}
          </label>
        </div>
        <div class="field-row" style="margin-top:6px">
          <input v-model="newService" placeholder="自定义服务" class="input" />
          <button @click="addService" class="btn-sm">添加</button>
        </div>
      </div>

      <!-- 标签 -->
      <div class="section">
        <div class="section-title">商品标签</div>
        <div v-if="(form.tags || []).length" class="tag-list">
          <span v-for="(t, i) in form.tags" :key="t" class="tag">
            {{ t }} <button @click="form.tags.splice(i, 1)" class="tag-close">&times;</button>
          </span>
        </div>
        <div class="field-row">
          <input v-model="newTag" placeholder="输入标签" class="input" @keydown.enter="addTag" />
          <button @click="addTag" class="btn-sm">添加</button>
        </div>
      </div>

      <!-- 限购配置 -->
      <div class="section">
        <div class="section-title">限购配置</div>
        <div class="field">
          <label>不限购</label>
          <label class="check-label" style="margin-left: 10px;">
            <input type="checkbox" v-model="noLimit" /> 不限购
          </label>
        </div>
        <div v-if="!noLimit" class="field-row">
          <input v-model.number="globalLimit" type="number" min="1" placeholder="每用户限购数量" class="input" />
          <button @click="addLimit" class="btn-sm">添加</button>
        </div>
        <div v-if="form.purchaseLimitConfig.length" class="opt-list">
          <div v-for="(lc, i) in form.purchaseLimitConfig" :key="i" class="limit-row">
            <span v-if="lc.type === 'global'">全局: {{ lc.limit }}件</span>
            <span v-else-if="lc.type === 'membership'">会员等级{{ lc.levelId }}: {{ lc.limit }}件</span>
            <span v-else-if="lc.type === 'verified'">认证用户: {{ lc.limit }}件</span>
            <button @click="form.purchaseLimitConfig.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 推广返佣 -->
      <div class="section">
        <div class="section-title">推广返佣</div>
        <div class="field-row">
          <select v-model="commissionType" class="input" style="flex:1">
            <option value="">不启用</option>
            <option value="percent">按比例</option>
            <option value="fixed">固定金额</option>
          </select>
          <input v-if="commissionType" v-model.number="commissionValue" type="number" min="0" step="0.01" :placeholder="commissionType === 'percent' ? '百分比%' : '固定金额'" class="input" style="flex:1" />
          <button v-if="commissionType" @click="addCommission" class="btn-sm">添加</button>
        </div>
        <div v-if="form.commissionConfig.length" class="opt-list">
          <div v-for="(cm, i) in form.commissionConfig" :key="i" class="limit-row">
            {{ cm.type === 'percent' ? cm.value + '%' : '¥' + cm.value }}
            <button @click="form.commissionConfig.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 自定义用户必留信息 -->
      <div class="section">
        <div class="section-title">用户必留信息</div>
        <div class="field-row" style="margin-bottom:6px">
          <input v-model="newFieldName" placeholder="字段名（如：手机号）" class="input" style="flex:1" />
          <button @click="addCustomField" class="btn-sm">添加</button>
        </div>
        <div v-if="form.customFields.length" class="opt-list">
          <div v-for="(f, i) in form.customFields" :key="i" class="limit-row">
            <label class="check-label">
              <input type="checkbox" v-model="f.required" /> {{ f.name }}{{ f.required ? '（必填）' : '' }}
            </label>
            <button @click="form.customFields.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 售后服务 -->
      <div class="section">
        <div class="section-title">售后服务</div>
        <div class="checkbox-group">
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enableRefund" /> 支持退款
          </label>
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enableReturn" /> 支持退货
          </label>
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enablePrice" /> 支持保价
          </label>
        </div>
        <div v-if="form.afterSalesConfig.enableRefund || form.afterSalesConfig.enableReturn" class="field" style="margin-top:8px">
          <label>售后有效期（天）</label>
          <input v-model.number="form.afterSalesConfig.validDays" type="number" min="1" class="input" placeholder="7" />
        </div>
      </div>
      <!-- 套装组合 -->
      <div class="section">
        <div class="section-title">套装组合配置</div>
        <p class="hint" style="margin-bottom:8px">购买本商品时，同时赠送以下装饰品/卡密</p>
        <div v-if="(form.bundleConfig || []).length" class="opt-list">
          <div v-for="(item, i) in form.bundleConfig" :key="i" class="limit-row" style="padding:6px 8px">
            <select v-model="item.type" class="input" style="width:100px;margin-right:4px">
              <option value="decoration">装饰品</option>
              <option value="card_pool">卡池卡密</option>
            </select>
            <template v-if="item.type === 'decoration'">
              <select v-model="item.decorationId" class="input" style="flex:1;margin-right:4px">
                <option :value="0">选择装饰品</option>
                <option v-for="d in decorations" :key="d.id" :value="d.id">{{ d.name }}</option>
              </select>
              <div style="display:flex;align-items:center;gap:2px;font-size:12px;white-space:nowrap;margin-right:4px">
                <input v-model.number="item.durationDays" type="number" min="0" class="input" style="width:50px" /> 天
              </div>
            </template>
            <template v-else>
              <select v-model="item.poolId" class="input" style="flex:1;margin-right:4px">
                <option :value="0">选择卡池</option>
                <option v-for="pool in cardPools" :key="pool.id" :value="pool.id">{{ pool.name }}</option>
              </select>
            </template>
            <button @click="form.bundleConfig.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
        <button @click="addBundleItem" class="btn-sm">+ 添加套装项</button>
      </div>
        </div><!-- /.panel-body -->
      </div><!-- /.collapsible-panel -->

      <div style="height: 60px" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const isEdit = ref(false)
const pageLoading = ref(false)

const categories = ref<any[]>([])
const membershipLevels = ref<any[]>([])
const newImageUrl = ref('')
const newTag = ref('')
const newService = ref('')
const newFieldName = ref('')
const coverImageInput = ref('')
const noLimit = ref(false)
const cardPools = ref<any[]>([])
const decorations = ref<any[]>([])

const defaultServices = ['7天无理由退货', '正品保证', '极速发货', '售后无忧', '免费包邮']

const paymentMethodOptions = [
  { label: '余额支付', value: 'balance' },
  { label: '积分支付', value: 'points' },
  { label: '支付宝', value: 'alipay' },
  { label: '微信支付', value: 'wechat' },
  { label: '易支付', value: 'epay' }
]

function defaultCardConfig() {
  return {
    enabled: false,
    type: 'card_key',
    cardType: 'membership',
    targetId: 0,
    targetName: '',
    value: 30,
    durationUnit: 'day',
    extraPoints: 0,
    extraBalance: 0,
    extraExperience: 0,
    rewardType: 'membership',
    rewardValue: 30,
    rewardDurationUnit: 'day',
    inviteCodeCount: 1,
    maxUses: 1,
    customCards: [],
    customCardsText: '',
    textContent: '',
    poolId: 0,
    decorationSubtype: '',
    decorationId: 0,
    decorationDurationDays: 0,
    _decorations: []
  }
}

const form = reactive<any>({
  name: '', subtitle: '', description: '', coverImage: '', coverVideo: '',
  priceType: 'balance', price: 0, originalPrice: 0, stock: 0,
  productType: 'virtual_auto', productSubtype: '',
  categoryId: 0, status: 'draft', freight: 0, isRecommended: false, sortOrder: 0,
  specs: [], flatPackages: [], useSpecs: false,
  images: [], services: [],
  purchaseLimitConfig: [], commissionConfig: [], customFields: [],
  stockWarning: 10,
  afterSalesConfig: { enableRefund: false, enableReturn: false, enablePrice: false, validDays: 7 },
  tags: [], productParams: [], paymentMethods: ['balance'],
  saleEndTime: '', saleStartTime: '',
  createdByName: ''
})

const globalLimit = ref(1)
const commissionType = ref('')
const commissionValue = ref(0)
const expandedCardConfigKey = ref<string | null>(null)
const collapsed = reactive({ basic: false, pricing: false, advanced: true })
const formErrors = ref<{ field: string; selector: string }[]>([])
const showErrorBanner = ref(false)
const coverUploading = ref(false)
const imgUploading = ref(false)

function syncCustomCardsForPkg(pkg: any) {
  if (!pkg.cardConfig) return
  const text = pkg.cardConfig.customCardsText || ''
  const lines = text.split('\n').filter((l: string) => l.trim())
  const cards = lines.map((line: string) => {
    const parts = line.split(':')
    return { number: (parts[0] || '').trim(), password: (parts[1] || '').trim() }
  }).filter((c: any) => c.number)
  pkg.cardConfig.customCards = cards
  pkg.stock = cards.length
}

function getCustomCardCountForPkg(pkg: any) {
  if (!pkg || !pkg.cardConfig) return 0
  return (pkg.cardConfig.customCards || []).length
}

function onMultiPoolChange(pkg: any) {
  if (!pkg.cardConfig) return
  if (!pkg.cardConfig._multiPool) {
    pkg.cardConfig.poolIds = []
    pkg.cardConfig.poolMode = 'random'
  } else {
    if (!pkg.cardConfig.poolIds) pkg.cardConfig.poolIds = []
    if (!pkg.cardConfig.poolMode) pkg.cardConfig.poolMode = 'random'
  }
}

async function loadPkgDecorations(pkg: any) {
  const subtype = pkg.cardConfig?.decorationSubtype
  if (!subtype) {
    pkg.cardConfig._decorations = []
    pkg.cardConfig.decorationId = 0
    return
  }
  try {
    let apiUrl: string
    let res: any
    if (subtype === 'avatar_frame') {
      res = await request.get({ url: '/api/avatar-frame/all' })
    } else if (subtype === 'title') {
      res = await request.get({ url: '/api/title/all' })
    } else {
      res = await request.get({ url: '/api/decoration/all', params: { type: subtype } })
    }
    if (Array.isArray(res) && res.length > 0) {
      const list = res.map((item: any) => ({
        id: item.id,
        name: item.name || '',
        image_url: item.image_url || item.thumbnail_url || item.icon || ''
      }))
      pkg.cardConfig._decorations = list
    } else {
      pkg.cardConfig._decorations = []
    }
  } catch {
    pkg.cardConfig._decorations = []
  }
}

async function uploadPackageImage(e: Event, pkg: any) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  try {
    const url = await uploadFile(file)
    pkg.image = url
  } catch (err: any) { alert('上传失败: ' + (err.message || '未知错误')) }
}

function toggleCardConfig(key: string) {
  expandedCardConfigKey.value = expandedCardConfigKey.value === key ? null : key
}

function togglePanel(name: keyof typeof collapsed) {
  collapsed[name] = !collapsed[name]
}

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData()
  fd.append('file', file)
  const headers: Record<string, string> = {}
  const token = userStore.accessToken
  if (token) headers['Authorization'] = token
  const res = await fetch('/api/upload/background', { method: 'POST', body: fd, headers })
  const json = await res.json()
  if (json.code !== 200) throw new Error(json.msg || 'Upload failed')
  return json.data.url
}

async function handleCoverUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  coverUploading.value = true
  try {
    const url = await uploadFile(file)
    form.coverImage = url
    coverImageInput.value = url
  } catch (err: any) { alert('上传失败: ' + (err.message || '未知错误')) }
  finally { coverUploading.value = false }
}

async function handleImageUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  imgUploading.value = true
  try {
    const url = await uploadFile(file)
    form.images = form.images || []
    form.images.push({ url, sortOrder: form.images.length })
  } catch (err: any) { alert('上传失败: ' + (err.message || '未知错误')) }
  finally { imgUploading.value = false }
}

function setCoverImage() {
  form.coverImage = fixImgUrl(coverImageInput.value.trim())
}
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
function addImage() {
  const url = newImageUrl.value.trim()
  if (url) { form.images = form.images || []; form.images.push({ url, sortOrder: form.images.length }); newImageUrl.value = '' }
}
function addTag() {
  const t = newTag.value.trim()
  if (t) { form.tags = form.tags || []; form.tags.push(t); newTag.value = '' }
}
function addService() {
  const s = newService.value.trim()
  if (s) { form.services = form.services || []; form.services.push(s); newService.value = '' }
}
function addCustomField() {
  const n = newFieldName.value.trim()
  if (n) { form.customFields = form.customFields || []; form.customFields.push({ name: n, required: true }); newFieldName.value = '' }
}
function addBundleItem() {
  form.bundleConfig = form.bundleConfig || []
  form.bundleConfig.push({ type: 'decoration', decorationId: 0, durationDays: 0, poolId: 0 })
}
function addLimit() {
  form.purchaseLimitConfig = form.purchaseLimitConfig || []
  form.purchaseLimitConfig.push({ type: 'global', limit: globalLimit.value })
}
function addCommission() {
  form.commissionConfig = form.commissionConfig || []
  form.commissionConfig.push({ type: commissionType.value, value: commissionValue.value })
  commissionType.value = ''; commissionValue.value = 0
}

function newFlatPkg() {
  const cc = defaultCardConfig()
  return { name: '', price: 0, originalPrice: 0, pointsPrice: 0, stock: 0, purchaseLimit: 0, image: '', cardConfig: { ...cc, enabled: false }, _key: Date.now() }
}

function addFlatPackage() {
  form.flatPackages = form.flatPackages || []
  form.flatPackages.push(newFlatPkg())
}

function addSpec() {
  form.specs = form.specs || []
  form.specs.push({ name: '', packages: [] })
}

function addPackage(si: number) {
  const spec = form.specs[si]
  if (!spec) return
  spec.packages = spec.packages || []
  spec.packages.push(newFlatPkg())
}

function copyFlatPackage(pi: number) {
  const pkg = form.flatPackages[pi]
  if (!pkg) return
  form.flatPackages.push(JSON.parse(JSON.stringify(pkg)))
}

function copyPackage(si: number, pi: number) {
  const pkg = form.specs[si]?.packages[pi]
  if (!pkg) return
  form.specs[si].packages.push(JSON.parse(JSON.stringify(pkg)))
}

function batchGenerateFlat() {
  form.flatPackages = form.flatPackages || []
  const countStr = prompt('请输入要生成的套餐数量')
  const count = parseInt(countStr || '')
  if (!count || count < 1) return
  for (let i = 0; i < count; i++) {
    form.flatPackages.push(newFlatPkg())
  }
}

function onDragStartFlat(pi: number, e: DragEvent) {
  dragIdx.value = pi
  if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move'
}

function onDragOverFlat(e: DragEvent) {
  e.preventDefault()
}

function onDropFlat(pi: number) {
  if (dragIdx.value < 0 || dragIdx.value === pi) return
  const arr = form.flatPackages
  const item = arr.splice(dragIdx.value, 1)[0]
  arr.splice(pi, 0, item)
  dragIdx.value = -1
}

function onUseSpecsChange() {
  if (form.useSpecs) {
    if (form.flatPackages?.length) {
      form.specs = form.specs || []
      form.specs.push({ name: '默认规格', packages: form.flatPackages.map((p: any) => JSON.parse(JSON.stringify(p))) })
      form.flatPackages = []
    }
  } else {
    if (form.specs?.[0]?.packages?.length) {
      form.flatPackages = form.specs[0].packages.map((p: any) => JSON.parse(JSON.stringify(p)))
      form.specs = []
    }
  }
}

async function loadProduct(id: number) {
  pageLoading.value = true
  try {
    const res: any = await request.get({ url: `/api/mall/products/${id}` })
    const d = res
    if (d) {
      form.name = d.name || ''
      form.subtitle = d.subtitle || ''
      form.description = d.description || ''
      form.coverImage = d.coverImage || ''
      form.coverVideo = d.coverVideo || ''
      form.priceType = d.priceType || 'balance'
      form.price = d.price || 0
      form.originalPrice = d.originalPrice || 0
      form.stock = d.stock || 0
      form.productType = d.productType || 'virtual_auto'
      form.categoryId = d.categoryId || 0
      form.status = d.status || 'draft'
      form.freight = d.freight || 0
      form.isRecommended = d.isRecommended || false
      form.sortOrder = d.sortOrder || 0

      // 将 options 按 specName 还原为 specs 结构
      const rawOptions = (d.options || []).map((o: any) => {
        const cfg = o.cardConfig ? { ...defaultCardConfig(), ...o.cardConfig } : defaultCardConfig()
        if (cfg.customCards && cfg.customCards.length) {
          cfg.customCardsText = cfg.customCards.join('\n')
        }
        return { ...o, pointsPrice: o.pointsPrice || 0, originalPrice: o.originalPrice || 0, image: o.image || '', cardConfig: cfg }
      })

      // 按 specName 分组
      const specMap = new Map<string, any[]>()
      rawOptions.forEach((o: any) => {
        const key = o.specName || ''
        if (!specMap.has(key)) specMap.set(key, [])
        specMap.get(key)!.push(o)
      })

      // 判断是否多规格：如果只有一个规格且 specName 为空或只有默认规格，切到平铺模式
      if (d.useSpecs === false || (specMap.size <= 1 && d.useSpecs === undefined)) {
        form.useSpecs = false
        form.flatPackages = rawOptions
        form.specs = []
      } else {
        form.useSpecs = true
        form.flatPackages = []
        form.specs = Array.from(specMap.entries()).map(([name, pkgs]) => ({
          name: name || '默认规格',
          packages: pkgs
        }))
      }

      form.images = d.images || []
      form.services = d.services || []
      form.tags = d.tags || []
      form.productParams = d.productParams || []
      form.purchaseLimitConfig = d.purchaseLimitConfig || []
      form.commissionConfig = d.commissionConfig || []
      form.customFields = d.customFields || []
      form.paymentMethods = d.paymentMethods || ['balance']
      form.saleStartTime = d.saleStartTime ? d.saleStartTime.replace(' ', 'T').slice(0, 16) : ''
      form.saleEndTime = d.saleEndTime ? d.saleEndTime.replace(' ', 'T').slice(0, 16) : ''
      form.productSubtype = d.productSubtype || ''
      form.createdByName = d.createdByName || ''
      Object.assign(form.afterSalesConfig, d.afterSalesConfig || { enableRefund: false, enableReturn: false, enablePrice: false, validDays: 7 })
      form.id = d.id
      coverImageInput.value = form.coverImage || ''
    }
  } catch (e: any) { console.error('加载商品失败:', e) } finally { pageLoading.value = false }
}

async function save() {
  showErrorBanner.value = false
  formErrors.value = []
  const errs: { field: string; selector: string }[] = []

  if (!form.name) errs.push({ field: '商品名称', selector: '[data-field="name"]' })
  if (!(form.paymentMethods || []).length) errs.push({ field: '支付方式', selector: '[data-field="paymentMethods"]' })

  // 校验套餐名称
  if (form.useSpecs && form.specs?.length) {
    form.specs.forEach((spec, si) => {
      spec.packages?.forEach((pkg, pi) => {
        if (!pkg.name) errs.push({ field: `规格「${spec.name || '未命名'}」套餐 ${pi + 1} 名称`, selector: `[data-field="spec-${si}-pkg-${pi}-name"]` })
      })
    })
  } else {
    form.flatPackages?.forEach((pkg, pi) => {
      if (!pkg.name) errs.push({ field: `套餐 ${pi + 1} 名称`, selector: `[data-field="pkg-${pi}-name"]` })
    })
  }

  // 校验自动发货类型
  if (form.productType === 'virtual_auto') {
    const checkPkg = (pkg: any, label: string) => {
      if (pkg.cardConfig?.enabled && !pkg.cardConfig.type) {
        errs.push({ field: `${label}发货类型`, selector: '[data-field="delivery-type"]' })
      }
    }
    if (form.useSpecs) {
      form.specs?.forEach(s => s.packages?.forEach((p, pi) => checkPkg(p, `规格「${s.name}」套餐 ${pi + 1} `)))
    } else {
      form.flatPackages?.forEach((p, pi) => checkPkg(p, `套餐 ${pi + 1} `))
    }
  }

  if (errs.length) {
    formErrors.value = errs
    showErrorBanner.value = true
    scrollToFirstError()
    return
  }

  try {
    const payload: any = JSON.parse(JSON.stringify(form))
    if (!isEdit.value) delete payload.id

    // 将 specs/flatPackages 结构扁平化为 options
    payload.options = []
    if (payload.useSpecs && payload.specs && payload.specs.length) {
      payload.specs.forEach((spec: any) => {
        if (spec.packages && spec.packages.length) {
          spec.packages.forEach((pkg: any, pi: number) => {
            if (pkg.cardConfig) {
              delete pkg.cardConfig.customCardsText
              delete pkg.cardConfig._decorations
              delete pkg.cardConfig._multiPool
            }
            payload.options.push({
              ...pkg,
              specName: spec.name || '',
              sortOrder: pi,
              originalPrice: pkg.originalPrice || 0
            })
          })
        }
      })
    } else if (payload.flatPackages && payload.flatPackages.length) {
      payload.flatPackages.forEach((pkg: any, pi: number) => {
        if (pkg.cardConfig) {
          delete pkg.cardConfig.customCardsText
          delete pkg.cardConfig._decorations
          delete pkg.cardConfig._multiPool
        }
        payload.options.push({
          ...pkg,
          specName: '',
          sortOrder: pi,
          originalPrice: pkg.originalPrice || 0
        })
      })
    }
    delete payload.specs
    delete payload.flatPackages
    delete payload.useSpecs

    const url = isEdit.value ? `/api/mall/products/${payload.id}` : '/api/mall/products'
    const method = isEdit.value ? request.put : request.post
    await method({ url, data: payload })
    ElMessage.success(isEdit.value ? '更新成功' : '创建成功')
    router.back()
  } catch (e: any) {
    ElMessage.error('保存失败: ' + (e.message || '未知错误'))
  }
}

function scrollToFirstError() {
  if (!formErrors.value.length) return
  const el = document.querySelector(formErrors.value[0].selector)
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
  else showErrorBanner.value = true
}

function scrollToError(err: { field: string; selector: string }) {
  const el = document.querySelector(err.selector)
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
}

// 当切换到虚拟自动发货时，自动展开第一个套餐的发货配置
watch(() => form.productType, (val) => {
  if (val === 'virtual_auto') {
    if (!form.useSpecs && form.flatPackages?.length) {
      expandedCardConfigKey.value = 'fp-0'
    } else if (form.useSpecs && form.specs?.[0]?.packages?.length) {
      expandedCardConfigKey.value = '0-0'
    }
  }
})

async function loadCategories() {
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    categories.value = res || []
  } catch {}
}

async function loadCardPools() {
  try {
    const res: any = await request.get({ url: '/api/admin/card-pools', data: { pageSize: 200 } })
    cardPools.value = (res.list || []).filter((p: any) => p.status === 'active')
  } catch {}
}

async function loadDecorations() {
  try {
    const res: any = await request.get({ url: '/api/decoration/all', params: { type: 'avatar_frame' } })
    decorations.value = res || []
  } catch {}
}

async function loadMembershipLevels() {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = res || []
  } catch {}
}

onMounted(async () => {
  await loadCategories()
  await loadMembershipLevels()
  await loadCardPools()
  await loadDecorations()
  const id = route.query.id
  if (id) { isEdit.value = true; await loadProduct(Number(id)) }
})
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; position: sticky; top: 0; z-index: 10; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.save-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 16px; border-radius: 8px; font-size: 13px; cursor: pointer; }

.form-error-banner {
  margin: 10px; padding: 12px 14px; background: #FFF2F2; border: 1px solid #FF6B6B;
  border-radius: 10px; color: #CC3333; font-size: 12px; cursor: pointer;
}
.error-banner-title { font-weight: 700; margin-bottom: 4px; }
.error-banner-list { line-height: 1.8; }
.error-banner-item { cursor: pointer; text-decoration: underline; }
.error-banner-item:hover { color: #FF6B6B; }
.error-banner-tip { margin-top: 4px; color: #999; font-size: 11px; }

.loading { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }

.form { padding: 0 0 20px; }
.collapsible-panel { margin: 10px 10px 0; border-radius: 12px; overflow: hidden; background: #fff; }
.panel-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px; background: #fff; cursor: pointer;
  border-bottom: 1px solid #f5f5f5; user-select: none;
  font-size: 14px; font-weight: 700; color: #333;
}
.panel-header:active { background: #fafafa; }
.panel-arrow { font-size: 10px; color: #999; transition: transform .2s; }
.panel-arrow.rotated { transform: rotate(180deg); }
.panel-body { padding: 0; }
.panel-body .section { margin: 4px 0 0; border-radius: 0; }
.panel-body .section:last-child { border-radius: 0 0 12px 12px; }
.section { background: #fff; margin: 10px 10px 0; border-radius: 12px; padding: 14px; }
.decoration-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.decoration-card {
  border: 2px solid #e8e8e8; border-radius: 10px; padding: 8px;
  text-align: center; cursor: pointer; transition: border-color .2s;
}
.decoration-card.active { border-color: #FF6B6B; }
.decoration-card:active { background: #fafafa; }
.decoration-card-img {
  width: 100%; padding-bottom: 100%; position: relative; background: #fafafa;
  border-radius: 6px; overflow: hidden; display: flex; align-items: center; justify-content: center;
}
.decoration-card-img img {
  position: absolute; top: 0; left: 0; width: 100%; height: 100%;
  object-fit: cover;
}
.decoration-card-name { margin-top: 6px; font-size: 11px; color: #666; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.decoration-card.active .decoration-card-name { color: #FF6B6B; font-weight: 600; }
.section-title { font-size: 14px; font-weight: 700; color: #333; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; gap: 8px; }
.section-tip { font-size: 11px; color: #999; font-weight: 400; }
.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.req { color: #FF4757; }
.hint-text { font-size: 10px; color: #aaa; font-weight: 400; }
.field-hint-warn { font-size: 11px; color: #FF6B6B; margin-top: 4px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; background: #fff; }
.textarea { resize: vertical; min-height: 60px; }
.field-row { display: flex; gap: 8px; align-items: center; }
.field-row .field { flex: 1; margin-bottom: 0; }
.btn-sm { border: 1px solid #ddd; background: #fff; padding: 6px 14px; border-radius: 8px; font-size: 12px; cursor: pointer; color: #666; flex-shrink: 0; }
.btn-sm.del { color: #FF4757; border-color: #FF4757; }

.cover-preview { position: relative; width: 100px; height: 100px; margin-top: 8px; border-radius: 8px; overflow: hidden; }
.cover-preview img { width: 100%; height: 100%; object-fit: cover; }
.remove-img { position: absolute; top: 2px; right: 2px; width: 20px; height: 20px; border-radius: 50%; border: none; background: rgba(0,0,0,.6); color: #fff; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; }

.img-list { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
.img-item { position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden; }
.img-item img { width: 100%; height: 100%; object-fit: cover; }

/* ====== 规格与套餐管理 ====== */
.spec-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 12px; }
.spec-card {
  background: #fff; border-radius: 12px; padding: 14px;
  border: 1.5px solid #FF6B6B33; border-left: 4px solid #FF6B6B;
}
.spec-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 10px;
}
.spec-label {
  font-size: 14px; font-weight: 800; color: #FF6B6B;
}
.spec-header-right { display: flex; gap: 6px; align-items: center; }
.btn-spec-action {
  font-size: 11px; padding: 4px 10px; border-radius: 6px;
  border: 1px solid #FF6B6B; background: #FFF5F5;
  color: #FF6B6B; cursor: pointer; font-weight: 600;
}

.pkg-list { display: flex; flex-direction: column; gap: 8px; margin-top: 10px; padding-top: 10px; border-top: 1px dashed #FFE0E0; }
.pkg-card {
  background: #f9fafb; border-radius: 10px; padding: 10px;
  border: 1px solid #eee; transition: opacity .2s;
}
.pkg-card.dragging { opacity: .5; border-style: dashed; }
.pkg-card:active:not(.dragging) { cursor: grab; }
.drag-handle {
  cursor: grab; color: #ccc; font-size: 14px; padding: 2px 4px;
  user-select: none; line-height: 1;
}
.drag-handle:hover { color: #666; }
.pkg-header {
  display: flex; align-items: center; gap: 8px; margin-bottom: 8px;
}
.pkg-index { font-size: 12px; font-weight: 700; color: #666; margin-right: auto; }
.pkg-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; }
.pkg-badge.auto { background: #E8F5E9; color: #4CAF50; }
.pkg-empty {
  text-align: center; padding: 16px 0; font-size: 13px;
  color: #ccc; background: #fafafa; border-radius: 8px;
  margin-top: 10px;
}

.package-delivery { margin-top: 8px; padding-top: 8px; border-top: 1px dashed #e0e0e0; }
.input.stock-low { border-color: #FF6B6B; color: #FF6B6B; }
.stock-warn-tag { font-size: 10px; background: #FFF2F2; color: #FF6B6B; padding: 2px 8px; border-radius: 4px; white-space: nowrap; }
.package-price-row { display: flex; gap: 8px; }
.delivery-toggle {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 12px; border-radius: 8px; cursor: pointer;
  background: #fff; border: 1px solid #e8e8e8;
  transition: all .2s; user-select: none;
}
.delivery-toggle:hover { border-color: #FF6B6B; }
.delivery-toggle.active { border-color: #FF6B6B; }
.delivery-toggle-left { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555; }
.delivery-icon { width: 18px; height: 18px; color: #999; }
.delivery-toggle.active .delivery-icon { color: #FF6B6B; }
.delivery-status {
  font-size: 11px; padding: 2px 8px; border-radius: 10px;
  background: #f0f0f0; color: #999;
}
.delivery-status.configured {
  background: #E8F5E9; color: #4CAF50;
}
.toggle-arrow { font-size: 11px; color: #999; transition: transform .2s; }
.toggle-arrow.expanded { transform: rotate(180deg); color: #FF6B6B; }
.delivery-body {
  margin-top: 8px; padding: 12px; background: #fff;
  border-radius: 8px; border: 1px solid #FFE0E0;
}

.btn-add-package {
  width: 100%; border: 2px dashed #ddd; background: #fff;
  padding: 12px; border-radius: 10px; font-size: 14px;
  cursor: pointer; color: #FF6B6B; font-weight: 600;
  transition: all .2s;
}
.btn-add-package:hover { border-color: #FF6B6B; background: #FFF5F5; }
.hint { font-size: 11px; color: #999; margin-top: 4px; }
.upload-btn { display: inline-block; padding: 6px 14px; border: 1px solid #ddd; border-radius: 8px; font-size: 12px; cursor: pointer; color: #666; background: #fff; white-space: nowrap; }
.upload-progress { font-size: 11px; color: #999; padding: 4px 0; }
.param-list { margin-bottom: 8px; }
.limit-row { display: flex; align-items: center; justify-content: space-between; padding: 6px 8px; background: #f9fafb; border-radius: 6px; margin-bottom: 4px; font-size: 12px; color: #666; }

.checkbox-group { display: flex; flex-wrap: wrap; gap: 12px; }
.check-label { display: flex; align-items: center; gap: 4px; font-size: 12px; color: #555; cursor: pointer; }

.tag-list { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.tag { padding: 4px 10px; background: #EEF2FF; color: #6366F1; border-radius: 20px; font-size: 11px; display: flex; align-items: center; gap: 4px; }
.tag-close { border: none; background: none; color: #6366F1; cursor: pointer; font-size: 14px; padding: 0; line-height: 1; }
</style>
