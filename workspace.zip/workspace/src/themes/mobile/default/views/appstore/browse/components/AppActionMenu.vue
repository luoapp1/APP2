<template>
  <!-- ========== 操作菜单浮层 ========== -->
  <teleport to="body">
    <div v-if="modelValue" class="menu-overlay" @click="closeMenu"></div>
    <div v-if="modelValue" class="menu-dropdown" :style="menuStyle">
      <div v-if="isLogin" class="menu-item" @click="openReport">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 5h-9.5l-1-1H5a2 2 0 00-2 2zm9-13.5V9"/></svg>
        <span>举报</span>
      </div>
      <div v-if="isLogin" class="menu-item" @click="toggleAppFavorite">
        <svg class="w-4 h-4" :fill="isAppFavorited ? '#EC4899' : 'none'" :stroke="isAppFavorited ? '#EC4899' : 'currentColor'" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
        <span :style="{ color: isAppFavorited ? '#EC4899' : '' }">{{ isAppFavorited ? '已收藏' : '收藏' }}</span>
      </div>
      <div v-if="isOwner || isAdmin" class="menu-item" @click="handleEdit">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        <span>编辑</span>
      </div>
      <div v-if="isOwner || isAdmin" class="menu-item menu-item-danger" @click="handleDelete">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        <span>删除</span>
      </div>
      <div v-if="isAdmin" class="menu-item" @click="handlePinApp">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>
        <span>{{ app?.isPinned ? '取消置顶' : '置顶' }}</span>
      </div>
      <div v-if="isAdmin" class="menu-item" @click="handleOfficialTag">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/></svg>
        <span>{{ app?.isOfficial ? '取消官方认证' : '官方认证' }}</span>
      </div>
      <div v-if="isAdmin" class="menu-item" @click="handleFeaturedApp">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
        <span>{{ app?.isFeatured ? '取消精品推荐' : '精品推荐' }}</span>
      </div>
    </div>
  </teleport>

  <!-- ========== 收藏分组选择弹窗 ========== -->
  <teleport to="body">
    <div v-if="showFavGroupDialog" class="fav-group-overlay" @click.self="showFavGroupDialog = false">
      <div class="fav-group-dialog">
        <div class="fav-group-title">选择收藏分组</div>
        <div class="fav-group-list">
          <div v-if="favGroupsLoading" style="text-align:center;padding:20px;color:#999">加载中...</div>
          <div
            v-for="g in favGroups"
            :key="g.id"
            class="fav-group-row"
            @click="selectFavGroup(g)"
          >
            <svg class="w-5 h-5" style="color:#EC4899" fill="currentColor" viewBox="0 0 24 24"><path d="M21 20a2 2 0 01-2 2H5a2 2 0 01-2-2V9c0-1.1.9-2 2-2h5l2-2h7a2 2 0 012 2v13z"/></svg>
            <span style="flex:1;font-size:14px;font-weight:500;color:#1a1a2e">{{ g.name }}</span>
            <span style="font-size:12px;color:#999">{{ g.app_count || 0 }}项</span>
          </div>
        </div>
        <div style="display:flex;gap:10px;margin-top:16px">
          <button style="flex:1;padding:10px 0;border:none;border-radius:10px;font-size:14px;background:#f3f4f6;color:#666;cursor:pointer" @click="showFavGroupDialog = false">取消</button>
        </div>
      </div>
    </div>
  </teleport>

  <!-- ========== 举报应用弹窗 ========== -->
  <teleport to="body">
    <div v-if="showAppReport" class="modal-overlay" @click.self="showAppReport = false">
      <div class="modal-card">
        <div class="modal-title">举报应用</div>
        <div class="modal-body">{{ app?.name }}</div>
        <textarea v-model="appReportReason" maxlength="500" placeholder="请描述举报原因..." class="modal-textarea" />
        <div class="modal-btns">
          <button class="modal-btn-cancel" @click="showAppReport = false">取消</button>
          <button class="modal-btn-confirm" @click="doAppReport">提交举报</button>
        </div>
      </div>
    </div>
  </teleport>

  <!-- ========== 删除确认弹窗 ========== -->
  <teleport to="body">
    <div v-if="showAppDeleteConfirm" class="modal-overlay" @click.self="showAppDeleteConfirm = false">
      <div class="modal-card">
        <div class="modal-title">确认删除</div>
        <div class="modal-body">确定要删除应用 "{{ app?.name }}" 吗？此操作不可撤销。</div>
        <div class="modal-btns">
          <button class="modal-btn-cancel" @click="showAppDeleteConfirm = false">取消</button>
          <button class="modal-btn-confirm modal-btn-danger" @click="doAppDelete">确认删除</button>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import {
  fetchDeleteApp,
  fetchPinApp,
  fetchToggleOfficial,
  fetchToggleFeatured,
  fetchReportComment,
} from '@/api/appstore'
import { fetchSendMessage } from '@/api/message'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()

const props = withDefaults(defineProps<{
  appId: number
  app: any
  isOwner: boolean
  isAdmin: boolean
  isLogin: boolean
  modelValue: boolean
  menuStyle: Record<string, string>
}>(), {
  appId: 0,
  app: undefined,
  isOwner: false,
  isAdmin: false,
  isLogin: false,
  modelValue: false,
  menuStyle: () => ({}),
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: boolean): void
  (e: 'app-deleted'): void
  (e: 'app-updated'): void
  (e: 'favorite-toggled'): void
  (e: 'toast', text: string): void
}>()

const showMenu = ref(false)
const showAppReport = ref(false)
const appReportReason = ref('')
const showAppDeleteConfirm = ref(false)
const isAppFavorited = ref(false)
const showFavGroupDialog = ref(false)
const favGroups = ref<any[]>([])
const favGroupsLoading = ref(false)

const closeMenu = () => {
  emit('update:modelValue', false)
}

watch(() => props.modelValue, (val) => {
  if (val) {
    checkAppFavorite()
  }
})

const checkAppFavorite = async () => {
  const uid = userStore.info?.userId
  if (!uid || !props.appId) return
  try {
    const res: any = await request.get({ url: `/api/app-favorite/check?userId=${uid}&appId=${props.appId}` })
    isAppFavorited.value = res?.favorited || false
  } catch (e: any) {
    console.error('[AppActionMenu] checkFavorite failed:', e?.message || e)
  }
}

const handleEdit = () => {
  emit('update:modelValue', false)
  router.push(`/appstore/submissions/edit?id=${props.appId}`)
}

const handleDelete = () => {
  emit('update:modelValue', false)
  showAppDeleteConfirm.value = true
}

const doAppDelete = async () => {
  try {
    await fetchDeleteApp(props.appId)
    showAppDeleteConfirm.value = false
    emit('toast', '已删除')
    setTimeout(() => {
      emit('app-deleted')
    }, 800)
  } catch {
    emit('toast', '删除失败')
  }
}

const openReport = () => {
  emit('update:modelValue', false)
  showAppReport.value = true
  appReportReason.value = ''
}

const doAppReport = async () => {
  if (!appReportReason.value.trim()) return
  try {
    await fetchReportComment(props.appId, 0, userStore.info.userId || 0, appReportReason.value)
    showAppReport.value = false
    emit('toast', '举报已提交')
  } catch {
    emit('toast', '举报失败')
  }
}

const loadFavGroups = async () => {
  favGroupsLoading.value = true
  try {
    const uid = userStore.info?.userId
    const res: any = await request.get({ url: `/api/app-favorite/groups?userId=${uid}` })
    favGroups.value = res || []
  } catch {
    favGroups.value = []
  }
  favGroupsLoading.value = false
}

const toggleAppFavorite = async () => {
  emit('update:modelValue', false)
  if (isAppFavorited.value) {
    const uid = userStore.info?.userId
    if (!uid || !props.appId) return
    try {
      await request.post({ url: '/api/app-favorite/toggle', data: { userId: uid, appId: props.appId } })
      isAppFavorited.value = false
      emit('toast', '已取消收藏')
      emit('favorite-toggled')
    } catch {
      emit('toast', '操作失败')
    }
  } else {
    showFavGroupDialog.value = true
    loadFavGroups()
  }
}

const selectFavGroup = async (g: any) => {
  showFavGroupDialog.value = false
  const uid = userStore.info?.userId
  if (!uid || !props.appId) return
  try {
    await request.post({ url: '/api/app-favorite/toggle', data: { userId: uid, appId: props.appId, groupId: g.id } })
    isAppFavorited.value = true
    emit('toast', '已收藏到「' + g.name + '」')
    emit('favorite-toggled')
  } catch {
    emit('toast', '操作失败')
  }
}

const handlePinApp = async () => {
  emit('update:modelValue', false)
  try {
    const newPinned = !props.app.isPinned
    await fetchPinApp(props.appId, newPinned)
    props.app.isPinned = newPinned
    emit('toast', newPinned ? '已置顶' : '已取消置顶')
    emit('app-updated')
    notifyUploader(`您的应用"${props.app.name}"已被管理员${newPinned ? '置顶' : '取消置顶'}`)
  } catch {
    emit('toast', '操作失败')
  }
}

const handleOfficialTag = async () => {
  emit('update:modelValue', false)
  const isOfficial = !props.app.isOfficial
  try {
    await fetchToggleOfficial(props.appId, isOfficial)
    props.app.isOfficial = isOfficial
    emit('toast', isOfficial ? '已设为官方认证' : '已取消官方认证')
    emit('app-updated')
    notifyUploader(`您的应用"${props.app.name}"已被管理员${isOfficial ? '设为官方认证' : '取消官方认证'}`)
  } catch {
    emit('toast', '操作失败，请重试')
  }
}

const handleFeaturedApp = async () => {
  emit('update:modelValue', false)
  const isFeatured = !props.app.isFeatured
  try {
    await fetchToggleFeatured(props.appId, isFeatured)
    props.app.isFeatured = isFeatured
    emit('toast', isFeatured ? '已设为精品推荐' : '已取消精品推荐')
    emit('app-updated')
    notifyUploader(`您的应用"${props.app.name}"已被管理员${isFeatured ? '设为精品推荐' : '取消精品推荐'}`)
  } catch {
    emit('toast', '操作失败，请重试')
  }
}

const notifyUploader = async (content: string) => {
  const uploaderId = props.app?.userId
  if (!uploaderId || uploaderId === userStore.info.userId) return
  try {
    await fetchSendMessage(
      userStore.info.userId || 0,
      userStore.info.userName || '系统',
      userStore.info.avatar || '',
      uploaderId,
      content
    )
  } catch {
    /* silently ignore notification failure */
  }
}
</script>

<style scoped>
.menu-overlay {
  position: fixed;
  inset: 0;
  z-index: 150;
}

.menu-dropdown {
  position: fixed;
  z-index: 151;
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 8px 32px rgba(0,0,0,.12), 0 2px 8px rgba(0,0,0,.06);
  overflow: hidden;
  min-width: 180px;
  padding: 6px 0;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 11px 16px;
  font-size: 14px;
  color: #374151;
  cursor: pointer;
  white-space: nowrap;
  transition: background .15s;
}
.menu-item:hover { background: #f8fafc; }
.menu-item:active { background: #f1f5f9; }
.menu-item-danger { color: #ef4444; }

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
}

.modal-card {
  background: #fff;
  border-radius: 16px;
  width: 320px;
  padding: 24px 20px 20px;
}

.modal-title {
  font-size: 17px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 8px;
}

.modal-body {
  font-size: 14px;
  color: #6b7280;
  margin-bottom: 14px;
}

.modal-textarea {
  width: 100%;
  height: 100px;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 10px 12px;
  font-size: 13px;
  outline: none;
  resize: none;
  margin-bottom: 14px;
  color: #374151;
}
.modal-textarea:focus { border-color: #3D7BEA; }

.modal-btns {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.modal-btn-cancel {
  padding: 8px 18px;
  border-radius: 8px;
  border: none;
  background: #f3f4f6;
  color: #374151;
  font-size: 14px;
  cursor: pointer;
}

.modal-btn-confirm {
  padding: 8px 18px;
  border-radius: 8px;
  border: none;
  background: #3D7BEA;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
}

.modal-btn-danger {
  background: #ef4444;
}

.fav-group-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.4); z-index: 200;
  display: flex; align-items: center; justify-content: center;
}
.fav-group-dialog {
  background: #fff; border-radius: 16px; padding: 20px;
  width: 300px; max-height: 420px; overflow-y: auto;
  box-shadow: 0 8px 32px rgba(0,0,0,.15);
}
.fav-group-title { font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 14px; }
.fav-group-list { max-height: 280px; overflow-y: auto; }
.fav-group-row {
  display: flex; align-items: center; gap: 12px; padding: 12px 10px;
  border-radius: 10px; cursor: pointer; transition: background .15s;
}
.fav-group-row:active { background: #fdf2f8; }
</style>
