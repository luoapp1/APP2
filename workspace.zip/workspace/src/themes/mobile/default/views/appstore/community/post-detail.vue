<template>
  <div class="post-detail-page">
    <!-- ==================== TOP NAVBAR (WHITE) ==================== -->
    <div class="navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <div class="nav-author">
        <div class="nav-avatar-wrap">
          <img v-if="(post as any)?.userAvatarFrame" :src="(post as any).userAvatarFrame" class="nav-avatar-frame" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
          <div class="nav-avatar">
            <img src="@imgs/user/avatar.webp" class="nav-avatar-pic"  loading="lazy" />
            <img v-if="(post as any)?.userAvatar" :src="$fixImgUrl((post as any).userAvatar)" class="nav-avatar-pic nav-avatar-user" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
          </div>
        </div>
        <div class="nav-author-info">
          <div class="nav-name-row">
            <span class="nav-name">{{ post?.userName || '--' }}</span>
            <img v-if="(post as any)?.userExpLevelIcon" :src="(post as any).userExpLevelIcon" class="nav-level-icon"  loading="lazy" />
            <img v-for="(icon, idx) in ((post as any)?.userAllTitleIcons || [])" :key="'ti'+idx" :src="icon" class="nav-title-icon" @error="($event.target as HTMLImageElement).style.display='none'"  loading="lazy" />
            <img v-if="(post as any)?.userMemberLevelIcon" :src="(post as any).userMemberLevelIcon" class="nav-member-icon"  loading="lazy" />
          </div>
          <div class="nav-meta-row">
            <span class="nav-time">{{ fmtTime(post?.createTime || '') }}</span>
            <span v-if="(post as any)?.authorIsModerator" class="nav-mod-tag">版主</span>
            <span v-if="(post as any)?.userAllTitleNames?.[0]" class="nav-tag nav-tag-title">{{ (post as any).userAllTitleNames[0] }}</span>
            <span v-if="(post as any)?.userAllTitleNames?.[1]" class="nav-tag nav-tag-title2">{{ (post as any).userAllTitleNames[1] }}</span>
          </div>
        </div>
      </div>
      <div class="nav-actions">
        <button v-if="getUserId() && post?.userId !== getUserId()" class="nav-follow-btn" :class="{ 'is-following': following }" @click.stop="handleFollowAuthor">{{ following ? '已关注' : '+ 关注' }}</button>
        <svg class="nav-dots" width="20" height="20" viewBox="0 0 24 24" fill="#333" @click.stop="showMenu = !showMenu"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </div>
      </div>

    <!-- ==================== DROPDOWN MENU ==================== -->
    <PostMenu v-model:visible="showMenu" :post="post" @report="handleMenuReport" />

    <!-- ==================== LOADING / EMPTY ==================== -->
    <div v-if="post" class="content-scroll">

      <!-- ===== POST INFO AREA ===== -->
      <div class="post-info-area">

      <!-- ===== COVER IMAGE ===== -->
      <div v-if="(post as any).coverUrl" class="post-cover">
        <img :src="$fixImgUrl((post as any).coverUrl)" alt="封面" class="post-cover-img" loading="lazy" />
      </div>

      <!-- ===== TITLE ===== -->
      <h1 class="post-title">
        <span class="title-badge title-badge-pin" v-if="post.isPinned">顶</span>
        <span class="title-badge title-badge-essence" v-if="post.isEssence">精</span>
        <span class="title-badge title-badge-hot" v-if="post.isHot">热</span>
        <span class="title-badge title-badge-lock" v-if="(post as any).isLocked">锁</span>
        <span class="title-badge title-badge-custom" v-if="(post as any).customBadge">{{ (post as any).customBadge }}</span>
        <span>{{ post.title }}</span>
      </h1>

      <div v-if="post.status === 'pending'" class="status-bar status-pending">审核中，仅自己可见</div>
      <div v-else-if="post.status === 'rejected'" class="status-bar status-rejected">审核未通过{{ post.rejectReason ? '：' + post.rejectReason : '' }}</div>
      <div v-if="(post as any).isLocked" class="status-bar status-locked">该帖已被管理员锁定，禁止编辑和评论</div>
      <div v-if="(post as any).isDeleted" class="status-bar status-deleted">此帖子已移入回收站，仅作者可见</div>
      <div v-if="post.status === 'scheduled'" class="status-bar status-scheduled">
        将于 {{ formatScheduledBanner((post as any).scheduledTime) }} 自动发布，仅自己可见
      </div>
      <div v-if="(post as any).isHidden" class="status-bar status-hidden">
        该帖已自动隐藏，仅作者和管理员可见
        <span v-if="(post as any).autoHideAt">（自动隐藏时间：{{ formatScheduledBanner((post as any).autoHideAt) }}）</span>
      </div>
      <div v-if="(post as any).autoHideAt && !(post as any).isHidden && post.status !== 'scheduled'" class="status-bar status-auto-hide">
        将于 {{ formatScheduledBanner((post as any).autoHideAt) }} 自动隐藏
      </div>

      <!-- ===== COLLECTION BANNER ===== -->
      <div v-if="postCollection" class="collection-banner" @click="$router.push('/community/collection/' + postCollection.collection.id)">
        <button v-if="postCollection.prevPost" class="cb-nav-btn" @click.stop="$router.push('/community/post/' + postCollection.prevPost.id)">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <div class="cb-center">
          <span class="cb-tag">合集</span>
          <span class="cb-title">{{ postCollection.collection.title }}</span>
          <span class="cb-progress">{{ postCollection.postIndex }}/{{ postCollection.totalPosts }}</span>
        </div>
        <button v-if="postCollection.nextPost" class="cb-nav-btn" @click.stop="$router.push('/community/post/' + postCollection.nextPost.id)">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
        </button>
      </div>

      <!-- ===== SOFTWARE INFO LIST (【】 format) ===== -->
      <div v-if="post.hasResource || post.content" class="info-list">
        <div class="info-row" v-if="post.title">
          <span class="info-label">【标题】</span><span class="info-value">{{ post.title }}</span>
        </div>
      </div>

      <!-- ===== CONTENT BLOCKS WITH PER-BLOCK VISIBILITY ===== -->
      <PostContentBlocks
        :post="post"
        :content-blocks="contentBlocks"
        :user-has-commented="userHasCommented"
        :following="following"
        :block-passed-set="blockPassedSet"
        :block-purchased-set="blockPurchasedSet"
        :content-purchased="contentPurchased"
        :purchased-attach-urls="purchasedAttachUrls"
        @preview-image="previewBlockImage"
        @open-comment-dialog="openCommentSection"
        @follow-author="handleFollowAuthor"
        @pay="openPayDialog"
        @verify-password="handleBlockPassword"
        @attach-click="handleAttachmentClick"
      />

      <!-- ===== DOWNLOAD SECTION ===== -->
      <div v-if="post.hasResource" class="download-block">
        <div class="download-heading">下载地址</div>
        <div class="download-card">
          <div class="download-icon-box">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
          </div>
          <div class="download-info">
            <div class="download-desc">评论999最高爆100金币</div>
            <div class="download-hint">需要支付 {{ post.resourcePrice || 1 }}余额</div>
          </div>
          <div class="download-btn-wrap">
            <span class="download-price-tag">$ {{ post.resourcePrice || 1 }}</span>
            <button class="download-btn">{{ post.resourcePrice || 1 }}余额</button>
          </div>
        </div>
        <div v-if="post.extractCode" class="extract-row">
          <span>提取码：</span><span class="extract-val">{{ post.extractCode }}</span>
        </div>
      </div>

      <!-- ===== TAGS ===== -->
      <div class="tags-row">
        <span class="tag-pill" v-for="tag in tagsList" :key="tag" @click="navigateToTag(tag)">
          <span class="tag-dot" :style="{background: tagDotColor(tag)}"/>
          {{ tag }}
        </span>
      </div>


      <!-- ===== DONATE DISPLAY ===== -->
      <div v-if="coinLogs.length > 0" class="reward-display" @click="toggleCoinLogs">
        <div class="reward-avatars">
          <div v-for="(donor, idx) in donorAvatars.slice(0,6)" :key="donor.userId"
            class="reward-avatar" style="position:relative"
            :style="{ marginLeft: idx > 0 ? '-8px' : '0', zIndex: 6 - idx }">
            <img src="@imgs/user/avatar.webp" class="reward-avatar-pic" loading="lazy" />
            <img v-if="donor.avatar" :src="$fixImgUrl(donor.avatar)" class="reward-avatar-pic" style="position:absolute;inset:0;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
          </div>
          <div v-if="donorAvatars.length > 6" class="reward-avatar reward-avatar-more" style="margin-left:-8px;z-index:0">+{{ donorAvatars.length - 6 }}</div>
        </div>
        <div class="reward-summary">
          <span class="reward-label">{{ coinLogs.length }}次打赏，共{{ getRewardSummary() }}</span>
        </div>
      </div>

    <!-- ==================== COIN LOGS MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showCoinLogs" class="donate-overlay" @click.self="showCoinLogs = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏记录</span>
            <button class="dm-close" @click="showCoinLogs = false">&times;</button>
          </div>
          <div class="coin-logs-body">
            <div v-if="coinLogs.length===0" class="coin-logs-empty">暂无打赏记录</div>
            <div v-else class="donate-item" v-for="log in coinLogs" :key="log.id">
              <div class="donate-avatar" style="position:relative">
                <img src="@imgs/user/avatar.webp" class="donate-avatar-pic" loading="lazy" />
                <img v-if="log.fromUserAvatar || log.userAvatar" :src="$fixImgUrl(log.fromUserAvatar || log.userAvatar)" class="donate-avatar-pic" style="position:absolute;inset:0;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
              <div class="donate-info">
                <span class="donate-name">{{ log.fromUserName }}</span>
                <span class="donate-time">{{ fmtTime(log.createTime) }}</span>
              </div>
              <div class="donate-amount">
                <span class="donate-val">{{ log.amount }}</span>
                <span class="donate-unit">{{ log.coinType === 'points' ? '积分' : '余额' }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- 附件信息弹窗 -->
    <Teleport to="body">
      <div v-if="attachInfoDialog.show" class="attach-overlay" @click.self="attachInfoDialog.show = false">
        <div class="attach-modal">
          <div class="attach-modal-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22C3D0" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
          </div>
          <h3 class="attach-modal-title">{{ attachInfoDialog.title || '附件信息' }}</h3>
          <p v-if="attachInfoDialog.desc" class="attach-modal-desc">{{ attachInfoDialog.desc }}</p>
          <div class="attach-modal-fields">
            <div v-if="attachInfoDialog.url" class="attach-field">
              <span class="attach-field-label">下载链接</span>
              <span class="attach-field-value attach-field-url">{{ attachInfoDialog.url }}</span>
            </div>
            <div v-if="attachInfoDialog.extractCode" class="attach-field">
              <span class="attach-field-label">提取码</span>
              <span class="attach-field-value attach-field-code">{{ attachInfoDialog.extractCode }}</span>
            </div>
          </div>
          <div class="attach-modal-actions">
            <button class="attach-btn attach-btn-copy" @click="navigator.clipboard?.writeText(attachInfoDialog.url);ElMessage.success('链接已复制')">复制链接</button>
            <button class="attach-btn attach-btn-close" @click="attachInfoDialog.show = false">关闭</button>
          </div>
        </div>
      </div>
    </Teleport>

      </div><!-- /post-info-area -->

      <!-- ===== COMMENTS SECTION ===== -->
      <CommentSection
        ref="commentSectionRef"
        :post-id="postId"
        :post="post"
        :post-is-fav-in-group="postIsFavInGroup"
        @preview-image="previewCommentImage"
        @donate="showDonateModal = true"
        @like="handleLike"
        @fav="handleFavorite"
        @commented="onCommentSubmitted"
        @report-comment="handleCommentReport"
      />
  </div>

    <!-- ==================== DONATE MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showDonateModal" class="donate-overlay" @click.self="showDonateModal = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏作者</span>
            <button class="dm-close" @click="showDonateModal = false">&times;</button>
          </div>
          <div class="dm-body">
            <!-- Balance + Points -->
            <div class="dm-balance-row">
              <div class="dm-bal-item">
                <span class="dm-bal-label">余额</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.balance || 0 }}</span>
              </div>
              <div class="dm-bal-item">
                <span class="dm-bal-label">积分</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.points || 0 }}</span>
              </div>
            </div>
            <!-- Payment type -->
            <div class="dm-type-row">
              <span class="dm-type-label">支付方式</span>
              <div class="dm-type-tabs">
                <button class="dm-type-tab" :class="{active: donateType === 'coin'}" @click="donateType = 'coin'">余额</button>
                <button class="dm-type-tab" :class="{active: donateType === 'points'}" @click="donateType = 'points'">积分</button>
              </div>
            </div>
            <!-- Amount selector -->
            <div class="dm-amount-row">
              <span class="dm-type-label">打赏数量</span>
              <div class="dm-amount-opts">
                <button v-for="n in donateType==='coin' ? [1,5,10,50] : [10,50,100,500]" :key="n" class="dm-amt-btn" :class="{active: donateAmount===n}" @click="donateAmount=n">{{ n }}</button>
              </div>
            </div>
            <!-- Custom amount -->
            <div class="dm-custom-row">
              <input v-model.number="donateAmount" type="number" min="1" class="dm-custom-input" placeholder="自定义数量"/>
            </div>
          </div>
          <div class="dm-footer">
            <button class="dm-cancel" @click="showDonateModal = false">取消</button>
            <button class="dm-confirm" :disabled="donating || donateAmount < 1" @click="doDonate">{{ donating ? '打赏中...' : '确认打赏 ' + donateAmount + (donateType==='points'?'积分':'余额') }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== REPORT DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showReportDialog" class="donate-overlay" @click.self="showReportDialog = false">
        <div class="report-dialog">
          <div class="report-header">
            <span>举报{{ reportTarget === 'comment' ? '评论' : '帖子' }}</span>
            <button class="report-close" @click="showReportDialog = false">&times;</button>
          </div>
          <div class="report-body">
            <p class="report-label">请选择举报原因</p>
            <div class="report-types">
              <label v-for="r in reportTypes" :key="r" class="report-type-item" :class="{ active: reportReason === r }">
                <input type="radio" :value="r" v-model="reportReason" />
                <span>{{ r }}</span>
              </label>
            </div>
            <div class="report-detail-row">
              <textarea v-model="reportDetail" class="report-textarea" placeholder="补充详细描述(选填)" maxlength="200"></textarea>
            </div>
          </div>
          <div class="report-footer">
            <button class="report-cancel" @click="showReportDialog = false">取消</button>
            <button class="report-confirm" :disabled="reporting || !reportReason" @click="doReport">{{ reporting ? '提交中...' : '提交举报' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== IMAGE PREVIEW ==================== -->
    <Teleport to="body">
      <div v-if="previewVisible" class="img-over" @click="closePreview">
        <span class="img-over-close" @click="closePreview">&times;</span>
        <span class="img-over-idx">{{ previewIndex+1 }}/{{ previewImages.length }}</span>
        <img v-if="previewImages[previewIndex]" :src="previewImages[previewIndex]" class="img-over-src" @error="($event.target as HTMLImageElement).style.display='none'" loading="lazy" />
        <button class="img-over-prev" @click.stop="prevImage">&lsaquo;</button>
        <button class="img-over-next" @click.stop="nextImage">&rsaquo;</button>
      </div>
    </Teleport>

    <!-- ==================== PAYMENT CONFIRM DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showPayConfirm" class="modal-overlay" @click.self="showPayConfirm = false">
        <div class="confirm-modal">
          <div class="confirm-title">确认支付</div>
          <div class="confirm-detail">
            <div class="confirm-row"><span>内容</span><span class="strong">{{ post?.title || '' }}</span></div>
            <div class="confirm-row"><span>支付方式</span><span class="strong">{{ payBlockPrice.type === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <template v-if="selectedCouponInfo">
              <div class="confirm-row"><span>优惠券</span><span class="accent">{{ selectedCouponInfo.name }} ({{ isPointsCoupon ? '' : '¥' }}{{ payBlockPrice.price }} - {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }})</span></div>
            </template>
            <div class="confirm-row"><span>支付金额</span><span class="accent">{{ payBlockPrice.type === 'points' ? finalPayPrice + '积分' : '¥' + finalPayPrice }}</span></div>
          </div>
          <div class="pay-coupon-section">
            <ElSelect
              v-model="selectedCouponId"
              placeholder="不使用优惠券"
              clearable
              style="width:100%"
              popper-class="coupon-select-popper"
              @change="onPayCouponSelect"
            >
              <ElOption :value="0" label="不使用优惠券" />
              <ElOption
                v-for="c in usableCoupons"
                :key="c.userCouponId"
                :value="c.userCouponId"
                :label="couponLabel(c)"
              >
                <div class="coupon-dd-item">
                  <span class="coupon-dd-left">{{ couponLabel(c) }}</span>
                  <span class="coupon-dd-right">{{ c.expireTime ? '到期 '+fmtDate(c.expireTime) : '' }}</span>
                </div>
              </ElOption>
            </ElSelect>
          </div>
          <div class="confirm-actions">
            <button class="confirm-btn cancel" @click="showPayConfirm = false">取消</button>
            <button class="confirm-btn primary" :disabled="payLoading" @click="handleConfirmPay">
              {{ payLoading ? '支付中...' : '确认支付' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== PAYMENT RESULT DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showPayResult" class="modal-overlay" @click.self="showPayResult = false">
        <div class="result-modal">
          <div v-if="payResultSuccess" class="result-icon success">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </div>
          <div v-else class="result-icon fail">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M6 18L18 6M6 6l12 12"/></svg>
          </div>
          <div class="result-title">{{ payResultSuccess ? '购买成功' : '购买失败' }}</div>
          <div class="result-msg">{{ payResultMsg }}</div>
          <div v-if="payResultSuccess" class="result-detail">
            <div class="result-row"><span>内容</span><span class="strong">{{ post?.title || '' }}</span></div>
            <div class="result-row"><span>支付方式</span><span class="strong">{{ payBlockPrice.type === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <div class="result-row"><span>金额</span><span class="accent">{{ payBlockPrice.type === 'points' ? payBlockPrice.price + '积分' : '¥' + payBlockPrice.price }}</span></div>
          </div>
          <button class="result-btn primary" @click="showPayResult = false">我知道了</button>
        </div>
      </div>
    </Teleport>

    <!-- ==================== GROUP NAME DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showPostGroupNameDialog" class="fav-picker-overlay" style="z-index: 210;" @click.self="showPostGroupNameDialog = false">
        <div class="fav-picker-card">
          <div class="fav-picker-header">
            <span>新建收藏分组</span>
            <button @click="showPostGroupNameDialog = false">&times;</button>
          </div>
          <input
            ref="postGroupDialogInput"
            v-model="postGroupNameValue"
            placeholder="请输入分组名称"
            style="width: 100%; padding: 10px 14px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 15px; outline: none; box-sizing: border-box; margin: 8px 0;"
            @keyup.enter="confirmPostGroupName"
          />
          <div class="fav-picker-actions">
            <button class="fav-picker-btn outline" @click="showPostGroupNameDialog = false">取消</button>
            <button class="fav-picker-btn primary" @click="confirmPostGroupName">确定</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== FAVORITE GROUP PICKER ==================== -->
    <Teleport to="body">
      <div v-if="showPostFavPicker" class="fav-picker-overlay" @click.self="showPostFavPicker = false">
        <div class="fav-picker-card">
          <div class="fav-picker-header">
            <span>选择收藏分组</span>
            <button @click="showPostFavPicker = false">&times;</button>
          </div>
          <div class="fav-picker-body">
            <div
              v-for="g in postFavGroups"
              :key="g.id"
              class="fav-picker-item"
              :class="{ active: postFavSelectedId === g.id }"
              @click="postFavSelectedId = g.id"
            >
              <span>{{ g.name }}</span>
              <span style="font-size: 11px; color: #999;">({{ g.count }})</span>
            </div>
            <div v-if="postFavGroups.length === 0" style="text-align: center; padding: 16px; color: #999; font-size: 13px;">暂无分组</div>
          </div>
          <div class="fav-picker-actions">
            <button class="fav-picker-btn outline" @click="createGroupFromPicker">新建分组</button>
            <button class="fav-picker-btn primary" @click="confirmPostFavorite">确认收藏</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/store/modules/user'
import { useMenuStore } from '@/store/modules/menu'
import { fetchCommunityPost, likePost, sendCoin, fetchCoinLogs, reportPost, reportComment, fetchTopics, fetchPostCollection } from '@/api/community'
import { fetchUsableCoupons } from '@/api/coupon'
import { addBrowseHistory } from '@/api/browse-history'
import { fetchMyTitles } from '@/api/social'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import request from '@/utils/http'
import type { CommunityPost } from '@/api/community'
import PostMenu from './components/PostMenu.vue'
import CommentSection from './components/CommentSection.vue'
import PostContentBlocks, { type ContentBlock } from './components/PostContentBlocks.vue'
import { useLoginModalStore } from '@/store/modules/loginModal'

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  extractCode?: string
  priceType?: string
  coin?: number
  coinCount?: number
  appId?: number
  appName?: string
  appIcon?: string
  fileName?: string
  visibility?: string
  visibilityPrice?: number
  visibilityPriceType?: string
  visibilityLevel?: number
  visibilityLevelName?: string
  visibilityPasswordTips?: string
  _filtered?: boolean
}

const commentSectionRef = ref<InstanceType<typeof CommentSection> | null>(null)
const userHasCommented = computed(() => commentSectionRef.value?.hasUserCommented ?? false)

function openCommentSection() { commentSectionRef.value?.openCommentDialog() }

function onCommentSubmitted() {
  // CommentSection handles its own reload after submit
}

function handleCommentReport(commentId: number) {
  reportTarget.value = 'comment'
  reportTargetId.value = commentId
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
}

function handleMenuReport(postId: number) {
  reportTarget.value = 'post'
  reportTargetId.value = postId
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
}

function handleBlockPassword(idx: number) {
  verifyBlockPassword(idx)
}

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()
const { menuList } = storeToRefs(menuStore)
const postId = computed(() => Number(route.params.id) || 0)

const post = ref<CommunityPost | null>(null)
const postCollection = ref<any>(null)
const showPostFavPicker = ref(false)
const postFavGroups = ref<any[]>([])
const postFavSelectedId = ref(0)
const postFavGroupName = ref('')
const postIsFavInGroup = ref(false)
const showPostGroupNameDialog = ref(false)
const postGroupNameValue = ref('')
const postGroupDialogInput = ref<HTMLInputElement | null>(null)
let postGroupNameCallback: ((v: string) => void) | null = null
const parsedContentBlocks = ref<ContentBlock[]>([])
const topicMap = ref<Record<string, number>>({})
const loading = ref(true)
const parsing = ref(false)
const previewVisible = ref(false)
const previewIndex = ref(0)
const previewImages = ref<string[]>([])
const showDonateModal = ref(false)
const donateAmount = ref(1)
const donateType = ref('coin')
const donating = ref(false)
const pwdInput = ref('')
const contentPurchased = ref(false)
const blockPassedSet = ref(new Set<number>())
const blockPurchasedSet = ref(new Set<number>())
const membershipLevels = ref<{ id: number; name: string; level: number; discount_rate: number; points_discount_rate: number }[]>([])

function levelName(lv: number): string {
  const found = membershipLevels.value.find(l => l.level === lv)
  return found?.name || `${lv}级会员`
}

async function loadMembershipLevels() {
  try {
    const r: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = (r?.records || []).filter((l: any) => l.status === '1')
  } catch {}
}

async function loadUserTitles() {
  try {
    const res: any = await fetchMyTitles()
    const list = res.data || res || []
    userTitles.value = list.map((t: any) => t.name)
  } catch {}
}

async function loadPostCollection() {
  try {
    const data: any = await fetchPostCollection(postId.value)
    if (data) {
      postCollection.value = data
    }
  } catch {}
}

function blockVisibility(idx: number): string {
  const block = contentBlocks.value[idx]
  return block?.visibility || (post.value?.contentPermission as string) || 'public'
}

function effectiveBlockVisibility(idx: number): string {
  const vis = blockVisibility(idx)
  if (!getUserId() && (vis === 'paid' || vis === 'comment' || vis === 'follow' || vis === 'level' || vis === 'level1' || vis === 'level2' || vis === 'member' || vis === 'exp')) {
    return 'login'
  }
  return vis
}

async function openPayDialog(idx: number) {
  const priceData = blockBarrierPrice(idx)
  if (!priceData || priceData.price <= 0) return
  currentPayBlockIdx.value = idx
  selectedCouponId.value = 0
  await loadUsableCoupons(priceData.price, priceData.type)
  showPayConfirm.value = true
}

function onPayCouponSelect(val: number) {
  if (!val) {
    selectedCouponId.value = 0
  } else {
    const c = usableCoupons.value.find((c: any) => c.userCouponId === val)
    selectedCouponId.value = val
  }
}

async function handleConfirmPay() {
  const idx = currentPayBlockIdx.value
  const priceData = payBlockPrice.value
  if (!priceData || idx < 0) return
  payLoading.value = true
  try {
    await request.post({
      url: `/api/content/purchase/post/${postId.value}`,
      data: { price: priceData.price, priceType: priceData.type, blockIndex: idx, couponId: selectedCouponId.value || 0 }
    })
    blockPurchasedSet.value.add(idx)
    payResultSuccess.value = true
    payResultMsg.value = '购买成功，内容已解锁'
    showPayConfirm.value = false
    showPayResult.value = true
    selectedCouponId.value = 0
    await loadPost()
  } catch (e: any) {
    payResultSuccess.value = false
    payResultMsg.value = e?.msg || e?.message || '支付失败，请重试'
    showPayConfirm.value = false
    showPayResult.value = true
  } finally {
    payLoading.value = false
  }
}

async function verifyBlockPassword(idx: number) {
  const block = contentBlocks.value[idx]
  const pwd = block?.visibilityPassword || post.value?.accessPassword
  if (!pwdInput.value || !pwdInput.value.trim()) {
    ElMessage.warning('请输入密码')
    return
  }
  if (pwd && pwdInput.value === pwd) {
    blockPassedSet.value.add(idx)
    pwdInput.value = ''
    await loadPost()
    return
  }
  try {
    const res = await request.post({
      url: `/api/content/verify-password/post/${postId.value}`,
      data: { password: pwdInput.value },
      showErrorMessage: false
    })
    const data = res as any
    if (data.valid || data.code === 200 || data.msg === 'ok') {
      blockPassedSet.value.add(idx)
      pwdInput.value = ''
      await loadPost()
    } else {
      ElMessage.error('密码错误')
    }
  } catch (e: any) { ElMessage.error(e?.msg || e?.message || '验证失败') }
}

const showReportDialog = ref(false)
const reportTarget = ref<'post' | 'comment'>('post')
const reportTargetId = ref(0)
const reportReason = ref('')
const reportDetail = ref('')
const reporting = ref(false)
const reportTypes = ['色情低俗', '政治敏感', '垃圾广告', '辱骂攻击', '侵权内容', '其他违规']
const coinLogs = ref<any[]>([])
const showCoinLogs = ref(false)
const lastDonateTime = ref(0)

function fmtDate(d: string) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    if (isNaN(dt.getTime())) return d.slice(0, 10)
    return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`
  } catch { return '' }
}

const donorAvatars = computed(() => {
  const seen = new Set<number>()
  const donors: { userId: number; name: string; avatar: string }[] = []
  for (const log of coinLogs.value) {
    const uid = log.fromUserId || log.userId
    if (uid && !seen.has(uid)) {
      seen.add(uid)
      donors.push({ userId: uid, name: log.fromUserName || log.userName || '', avatar: log.fromUserAvatar || log.userAvatar || '' })
    }
  }
  return donors
})

function getRewardSummary() {
  const parts: string[] = []
  if (coinLogPointsTotal.value) parts.push(`${coinLogPointsTotal.value}积分`)
  if (coinLogCoinTotal.value) parts.push(`${coinLogCoinTotal.value}余额`)
  return parts.length ? parts.join(' ') : '0积分余额'
}
const purchasedAttachUrls = ref<string[]>([])
const attachInfoDialog = ref({ show: false, title: '', desc: '', url: '', extractCode: '' })
const showMenu = ref(false)
const following = ref(false)
const userTitles = ref<string[]>([])
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref<number>(0)
const selectedCouponInfo = computed(() => usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value) || null)

const showPayConfirm = ref(false)
const showPayResult = ref(false)
const payResultSuccess = ref(false)
const payResultMsg = ref('')
const payLoading = ref(false)
const currentPayBlockIdx = ref(-1)

const payBlockPrice = computed(() => {
  if (currentPayBlockIdx.value < 0) return { price: 0, type: 'balance' as string }
  return blockBarrierPrice(currentPayBlockIdx.value) || { price: 0, type: 'balance' as string }
})

const isPointsCoupon = computed(() => {
  const c = selectedCouponInfo.value
  return c && (c.type === 'fixed_points' || c.type === 'points_percent')
})

const couponDiscount = computed(() => {
  const c = selectedCouponInfo.value
  if (!c) return 0
  const base = payBlockPrice.value.price
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    let disc = Math.floor(base * c.value / 100 * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPayPrice = computed(() => {
  const priceData = payBlockPrice.value
  const userLevelId = (userStore.info as any)?.levelId || 0
  let discountRate = 1.0
  if (userLevelId && membershipLevels.value.length) {
    const ml = membershipLevels.value.find((l: any) => l.id === userLevelId)
    if (ml) discountRate = priceData.type === 'points' ? (ml.points_discount_rate || 1) : (ml.discount_rate || 1)
  }
  const memberPrice = Math.round(priceData.price * discountRate * 100) / 100
  const cd = couponDiscount.value
  return Math.max(0, memberPrice - cd)
})

function couponLabel(c: any) {
  const isPoints = c.type === 'fixed_points' || c.type === 'points_percent'
  const isFixed = c.type === 'fixed' || c.type === 'fixed_points'
  const prefix = isFixed ? `${isPoints ? '' : '¥'}${c.value}${isPoints ? '积分' : ''}` : `${c.value}折`
  const suffix = c.isMultiUse && c.remainingValue !== null ? `(剩${isPoints ? '' : '¥'}${c.remainingValue}${isPoints ? '积分' : ''})` : ''
  return `${prefix} ${c.name}${suffix}`
}

const contentBlocks = computed<ContentBlock[]>(() => parsedContentBlocks.value)

function fmtTime(t: string) {
  if (!t) return ''
  const s = t.replace(' ', 'T')
  const d0 = s.match(/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/) ? new Date(s) : new Date(s + 'Z')
  if (isNaN(d0.getTime())) return t.slice(0, 10)
  const d = Date.now() - d0.getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}
function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }

/**
 * Check if current user has the given button-level permission
 * for CommunityPostManage menu via authList
 */
function tagDotColor(t: string) { return t === '玩机广场' ? '#4BCB73' : t === '资源分享' ? '#999' : '#22C3D0' }
function navigateToTag(tag: string) {
  const tId = topicMap.value[tag]
  if (tId) router.push(`/community/topic/${tId}`)
}

function formatScheduledBanner(dt: string): string {
  if (!dt) return ''
  const d = new Date(dt)
  return `${d.getFullYear()}/${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getDate().toString().padStart(2, '0')} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`
}

async function loadPost() {
  if (!postId.value) return
  loading.value = true
  try {
    try { const topics: any = await fetchTopics(); if (topics?.list) { const map: Record<string, number> = {}; topics.list.forEach((t: any) => { if (t.name) map[t.name] = t.id }); topicMap.value = map } } catch {}
    const r: any = await fetchCommunityPost(postId.value, getUserId())
    post.value = r.data || r
    if (post.value?.content) {
      try {
        let parsed: any
        if (typeof post.value.content === 'string') {
          parsed = JSON.parse(post.value.content)
        } else if (typeof post.value.content === 'object') {
          parsed = JSON.parse(JSON.stringify(post.value.content))
        }
        if (parsed) {
          if (Array.isArray(parsed)) {
            parsedContentBlocks.value = parsed as ContentBlock[]
          } else if (parsed?.type === 'doc') {
            parsedContentBlocks.value = flattenTiptapToBlocks(parsed)
          }
        }
      } catch (e: any) {
        parsedContentBlocks.value = []
      }
    } else {
      parsedContentBlocks.value = []
    }
    const hasPaywallBlock = parsedContentBlocks.value.some((b: any) => b.visibility === 'paid')
    if ((post.value?.contentPermission === 'paid' || post.value?.contentPermission === 'mixed' || hasPaywallBlock) && getUserId()) {
      try {
        const pur: any = await request.get({ url: `/api/content/purchased/post/${postId.value}` })
        // fullPurchase 或 content_permission='paid' 且有购买记录 → 全帖可见
        contentPurchased.value = (pur?.fullPurchase) || (post.value?.contentPermission === 'paid' && pur?.purchased) || false
        if (pur?.boughtBlocks?.length) {
          blockPurchasedSet.value = new Set(pur.boughtBlocks)
        }
      } catch {}
    }
    checkFollowStatus()
    if (getUserId() && post.value) {
      addBrowseHistory({
        userId: getUserId(),
        itemType: 'post',
        itemId: postId.value,
        itemTitle: post.value.title || '',
        itemCover: post.value.cover || '',
        itemUrl: route.fullPath
      }).catch(() => {})
    }
  } catch (e: any) { console.error(e) } finally { loading.value = false }
}

async function loadUsableCoupons(price: number, priceType: string) {
  if (!getUserId()) return
  try {
    const res: any = await fetchUsableCoupons({ scene: 'content_buy', orderAmount: price, payType: priceType })
    usableCoupons.value = res?.data || res || []
  } catch { usableCoupons.value = [] }
}
async function handleLike() {
  const u = getUserId(); if (!u || !post.value) return
  try { await likePost(post.value.id, u); post.value.isLiked = !post.value.isLiked; post.value.likeCount = (post.value.likeCount || 0) + (post.value.isLiked ? 1 : -1) } catch {}
}
async function handleFavorite() {
  const u = getUserId(); if (!u || !post.value) return
  if (postIsFavInGroup.value) {
    if (!confirm('确定取消收藏？')) return
    try {
      const request = (await import('@/utils/http')).default
      await request.del({ url: `/api/community/post/${post.value.id}/favorite` })
      postIsFavInGroup.value = false
      postFavGroupName.value = ''
    } catch { return }
  } else {
    await loadPostFavGroups()
    showPostFavPicker.value = true
  }
}
const toggleFav = handleFavorite

async function loadPostFavGroups() {
  try {
    const request = (await import('@/utils/http')).default
    const res: any = await request.get({ url: '/api/community/favorite/groups' })
    postFavGroups.value = res || []
    if (postFavGroups.value.length > 0) postFavSelectedId.value = postFavGroups.value[0].id
  } catch { postFavGroups.value = [] }
}

function openPostGroupNameDialog(cb: (v: string) => void) {
  postGroupNameValue.value = ''
  postGroupNameCallback = cb
  showPostGroupNameDialog.value = true
  setTimeout(() => postGroupDialogInput.value?.focus(), 100)
}

function confirmPostGroupName() {
  const val = postGroupNameValue.value.trim()
  if (!val) return
  showPostGroupNameDialog.value = false
  postGroupNameCallback?.(val)
}

async function createGroupFromPicker() {
  openPostGroupNameDialog(async (name) => {
    try {
      const request = (await import('@/utils/http')).default
      const res: any = await request.post({ url: '/api/community/favorite/groups', data: { name } })
      if (res) {
        postFavGroups.value.push(res)
        postFavSelectedId.value = res.id
      }
    } catch (e: any) { alert(e.message || '创建失败') }
  })
}

async function confirmPostFavorite() {
  if (postFavSelectedId.value <= 0) return alert('请选择分组')
  try {
    const request = (await import('@/utils/http')).default
    await request.post({
      url: `/api/community/post/${post.value!.id}/favorite`,
      data: { groupId: postFavSelectedId.value }
    })
    postIsFavInGroup.value = true
    const g = postFavGroups.value.find(x => x.id === postFavSelectedId.value)
    postFavGroupName.value = g?.name || ''
    showPostFavPicker.value = false
  } catch (e: any) { alert(e.message || '收藏失败') }
}

async function checkPostFavStatus() {
  if (!post.value) return
  try {
    const request = (await import('@/utils/http')).default
    const res: any = await request.get({ url: `/api/community/post/${post.value.id}/favorite/check` })
    postIsFavInGroup.value = !!res?.favorited
    postFavGroupName.value = res?.groupName || ''
  } catch {}
}
async function doDonate() {
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再打赏'); return }
  if (!post.value || donateAmount.value < 1) return
  const elapsed = Date.now() - lastDonateTime.value
  if (elapsed < 30000) {
    const remain = Math.ceil((30000 - elapsed) / 1000)
    ElMessage.warning(`请等待 ${remain} 秒后再打赏`)
    return
  }
  donating.value = true
  try {
    await sendCoin(post.value.id, { userId: u, amount: donateAmount.value, coinType: donateType.value })
    post.value.coinCount = (post.value.coinCount || 0) + donateAmount.value
    lastDonateTime.value = Date.now()
    showDonateModal.value = false
    await loadCoinLogs()
    ElMessage.success('打赏成功')
  } catch {} finally { donating.value = false }
}

function isAttachPurchased(url?: string) {
  return !!(url && purchasedAttachUrls.value.includes(url))
}

function handleAttachmentClick(block: ContentBlock) {
  if (!block.url) return
  // 已购买 → 弹窗显示信息
  if (isAttachPurchased(block.url)) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const isFree = block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0
  if (isFree) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再下载'); return }
  const unitLabel = block.priceType === 'points' ? '积分' : '余额'
  ElMessageBox.confirm(
    `该附件需要支付 ${block.coin || 0}${unitLabel}，确认购买？`,
    '购买附件',
    { confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning' }
  ).then(async () => {
    try {
      const res = await fetch('/api/community/attach/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken },
        body: JSON.stringify({ postId: post.value?.id, attachUrl: block.url, coinType: block.priceType, amount: block.coin })
      })
      const data = await res.json()
      if (data.code === 200) {
        purchasedAttachUrls.value.push(block.url!)
        ElMessage.success(data.msg)
        attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url!, extractCode: block.extractCode || '' }
      } else {
        ElMessage.error(data.msg || '购买失败')
      }
    } catch {
      ElMessage.error('购买失败')
    }
  }).catch(() => {})
}

async function loadPurchasedAttachments() {
  if (!postId.value) return
  const u = getUserId()
  if (!u) return
  try {
    const res = await fetch(`/api/community/attach/purchased?postId=${postId.value}`, {
      headers: { 'Authorization': userStore.accessToken }
    })
    const data = await res.json()
    if (data.code === 200) {
      purchasedAttachUrls.value = data.data?.urls || []
    }
  } catch {}
}

async function loadCoinLogs() {
  if (!postId.value) return
  try {
    const r: any = await fetchCoinLogs(postId.value)
    coinLogs.value = r.data?.list || r.list || r.data || []
  } catch {}
}
async function toggleCoinLogs() {
  showCoinLogs.value = true
  await loadCoinLogs()
}
function previewCommentImage(images: string[], idx: number) {
  previewImages.value = images
  previewIndex.value = idx
  previewVisible.value = true
}
async function handleFollowAuthor() {
  if (!post.value) return
  const targetId = (post.value as any).userId
  if (!targetId) return
  try {
    if (following.value) {
      await request.del({ url: `/api/user/${targetId}/follow` })
      following.value = false
    } else {
      await request.post({ url: `/api/user/${targetId}/follow` })
      following.value = true
    }
  } catch {}
}
async function checkFollowStatus() {
  if (!post.value) return
  const targetId = (post.value as any).userId
  if (!targetId || !getUserId() || targetId === getUserId()) return
  try {
    const res: any = await request.get({ url: `/api/user/${targetId}/follow-status` })
    following.value = !!res?.isFollowing
  } catch {}
}

async function doReport() {
  if (!reportReason.value) return
  reporting.value = true
  try {
    if (reportTarget.value === 'post') {
      await reportPost(reportTargetId.value, reportReason.value, reportDetail.value)
    } else {
      await reportComment(reportTargetId.value, reportReason.value, reportDetail.value)
    }
    ElMessage.success('举报成功，管理员将尽快处理')
    showReportDialog.value = false
  } catch { ElMessage.error('举报失败') }
  reporting.value = false
}

function previewBlockImage(images: string[], i: number) {
  previewImages.value = images
  previewIndex.value = i
  previewVisible.value = true
}

function closePreview() { previewVisible.value = false }
function prevImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value - 1 + previewImages.value.length) % previewImages.value.length }
function nextImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value + 1) % previewImages.value.length }

onMounted(() => {
  loadPost()
  loadComments()
  loadCoinLogs()
  loadPurchasedAttachments()
  loadMembershipLevels()
  loadUserTitles()
  loadPostCollection()

  window.__submitVote = async function(postId: number, optionIndex: number, el: HTMLElement) {
    try {
      await request.post({ url: '/api/community/vote/submit', data: { postId, optionIndex }, showErrorMessage: false })
      const actionEl = el.querySelector('.vote-opt-action') as HTMLElement
      const numEl = el.querySelector('.vote-opt-num') as HTMLElement
      const checkEl = el.querySelector('.vote-opt-check') as HTMLElement
      if (actionEl) { actionEl.textContent = '已投票'; actionEl.style.color = '#38a169' }
      if (numEl) { numEl.style.background = '#38a169'; numEl.style.color = '#fff' }
      if (checkEl) checkEl.style.display = 'block'
      el.style.borderColor = '#86efac'
      el.style.background = '#f0fdf4'
      el.classList.add('vote-option-active')
      const card = el.closest('.vote-card') as HTMLElement
      if (card) {
        const pid = Number(card.dataset.votePostId) || 0
        loadVoteResults(pid, card)
        disableExtraOptions(card, Number(card.dataset.voteMax) || 1)
      }
      ElMessage.success('投票成功')
    } catch (e: any) {
      const code = e?.code || e?.response?.status
      if (code === 401) {
        ElMessageBox.confirm('登录后即可参与投票', '提示', { confirmButtonText: '去登录', cancelButtonText: '取消', type: 'info' }).then(() => {
          useLoginModalStore().open()
        }).catch(() => {})
      } else {
        ElMessage.error(e?.msg || e?.message || '投票失败，请稍后再试')
      }
    }
  }

  setTimeout(() => { initVoteCards() }, 500)
})

onBeforeUnmount(() => { delete (window as any).__submitVote })

watch(postId, () => {
  if (postId.value) {
    loadPost()
    loadComments()
    loadCoinLogs()
    loadPurchasedAttachments()
  loadPostCollection()
  if (getUserId()) checkPostFavStatus()
  }
})

function escapeHtml(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

async function loadVoteResults(postId: number, card: HTMLElement) {
  try {
    const res: any = await request.get({ url: '/api/community/vote/result/' + postId, params: {} })
    if (!res) return
    const d = res.data || res
    const total = d.total || 0
    if (!total || !d.options) return
    const maxCount = Math.max(1, ...d.options.map((o: any) => o.count))
    const colors = ['#508DFF', '#00C9A7', '#FF6B6B', '#FFA94D', '#845EF7', '#339AF0', '#F06595', '#20C997', '#FF922B', '#5C7CFA']
    const container = card.querySelector('.vote-result-container') as HTMLElement
    const optsContainer = card.querySelector('.vote-options-container') as HTMLElement
    const footer = card.querySelector('.vote-footer') as HTMLElement
    if (!container) return
    container.innerHTML = d.options.map((o: any, i: number) => {
      const pct = (o.count / d.total) * 100
      const c = colors[i % colors.length]
      const isTop = o.count === maxCount && o.count > 0
      return `<div style="margin:6px 0;font-size:11px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2px">
          <div style="display:flex;align-items:center;gap:6px">
            <span style="width:18px;height:18px;border-radius:50%;background:${c};color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600;flex-shrink:0">${i + 1}</span>
            <span style="color:#333">${escapeHtml(o.text)}</span>
            ${isTop ? '<span style="font-size:9px;background:#fef3c7;color:#b45309;padding:1px 4px;border-radius:3px;font-weight:600">领先</span>' : ''}
          </div>
          <span style="font-weight:600;font-size:12px;color:${c}">${o.count}票</span>
        </div>
        <div style="height:6px;background:#f0f2f5;border-radius:3px;overflow:hidden">
          <div style="height:100%;width:${Math.max(pct, 2)}%;background:${c};border-radius:3px;transition:width 0.5s"></div>
        </div>
        <div style="text-align:right;font-size:10px;color:#999;margin-top:1px">${Math.round(pct)}%</div>
      </div>`
    }).join('') + `<div style="text-align:center;margin-top:6px;padding-top:6px;border-top:1px solid #f0f2f5;font-size:11px;color:#999">${d.total}人已参与</div>`
    container.style.display = 'block'
    if (optsContainer) optsContainer.style.display = 'none'
    if (footer) footer.style.display = 'none'
  } catch {}
}

function disableExtraOptions(card: HTMLElement, max: number) {
  const voted = card.querySelectorAll('.vote-option-active').length
  if (voted >= max) {
    card.querySelectorAll('.vote-option').forEach((opt: any) => {
      if (!opt.classList.contains('vote-option-active')) {
        opt.style.pointerEvents = 'none'
        opt.style.opacity = '0.5'
      }
    })
  }
}

async function initVoteCards() {
  const cards = document.querySelectorAll('.vote-card') as NodeListOf<HTMLElement>
  for (const card of cards) {
    const pid = Number(card.dataset.votePostId) || 0
    if (!pid) continue
    try {
      const res: any = await request.get({ url: '/api/community/vote/my/' + pid, params: {} })
      const data = Array.isArray(res) ? res : (res?.data || res)
      if (data && data.length > 0) {
        loadVoteResults(pid, card)
        data.forEach((idx: number) => {
          const opt = card.querySelector(`.vote-option[data-idx="${idx}"]`) as HTMLElement
          if (opt) {
            const actionEl = opt.querySelector('.vote-opt-action') as HTMLElement
            const numEl = opt.querySelector('.vote-opt-num') as HTMLElement
            const checkEl = opt.querySelector('.vote-opt-check') as HTMLElement
            if (actionEl) { actionEl.textContent = '已投票'; actionEl.style.color = '#38a169' }
            if (numEl) { numEl.style.background = '#38a169'; numEl.style.color = '#fff' }
            if (checkEl) checkEl.style.display = 'block'
            opt.style.borderColor = '#86efac'
            opt.style.background = '#f0fdf4'
            opt.classList.add('vote-option-active')
          }
        })
        disableExtraOptions(card, Number(card.dataset.voteMax) || 1)
      }
    } catch {}
  }
}
</script>

<style scoped>

/* ===== COLLECTION BANNER ===== */
.collection-banner {
  display: flex;
  align-items: center;
  margin: 0 16px 12px;
  padding: 8px 10px;
  background: linear-gradient(135deg, #f5f3ff, #ede9fe);
  border-radius: 10px;
  border: 1px solid #e9d5ff;
  cursor: pointer;
  gap: 6px;
}
.collection-banner:active { background: linear-gradient(135deg, #ede9fe, #e4dbfe); }
.cb-center {
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
}
.cb-tag {
  display: inline-block;
  font-size: 10px;
  color: #7c3aed;
  background: rgba(124,58,237,.12);
  padding: 1px 6px;
  border-radius: 6px;
  font-weight: 600;
  flex-shrink: 0;
}
.cb-title {
  font-size: 13px;
  font-weight: 500;
  color: #334155;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cb-progress {
  font-size: 11px;
  color: #a78bfa;
  flex-shrink: 0;
  margin-left: auto;
}
.cb-nav-btn {
  width: 28px; height: 28px;
  border-radius: 50%;
  background: rgba(255,255,255,.7);
  border: 1px solid #e9d5ff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #7c3aed;
  flex-shrink: 0;
  padding: 0;
}
.cb-nav-btn:active { background: rgba(237,233,254,.9); }

/* ============ PAGE ============ */
.post-detail-page { display: flex; flex-direction: column; height: 100vh; height: 100dvh; background: #fff; font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans SC', sans-serif; overscroll-behavior: none; -webkit-overflow-scrolling: touch; }
.content-scroll { flex: 1; overflow-y: auto; padding: 0 12px; overscroll-behavior-y: contain; }

/* ============ NAVBAR - WHITE, CLEAN ============ */
.navbar { display: flex; align-items: center; padding: 10px 12px; gap: 8px; background: #fff; flex-shrink: 0; }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; flex-shrink: 0; }
.nav-author { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.nav-avatar-wrap { position: relative; width: 56px; height: 56px; flex-shrink: 0; }
.nav-avatar-frame { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0; }
.nav-avatar { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; border-radius: 50%; overflow: hidden; z-index: 1; }
.nav-avatar-pic { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
.nav-avatar-user { position: absolute; inset: 0; z-index: 1; }
.nav-author-info { display: flex; flex-direction: column; gap: 2px; }
.nav-name-row { display: flex; align-items: center; gap: 0; }
.nav-name { font-size: 15px; font-weight: 600; color: #111; }
.nav-level-icon { width: 40px; height: 28px; object-fit: contain; flex-shrink: 0; }
.nav-title-icon { width: 28px; height: 28px; object-fit: contain; flex-shrink: 0; }
.nav-member-icon { width: 28px; height: 28px; object-fit: contain; flex-shrink: 0; }
.nav-meta-row { display: flex; align-items: center; gap: 6px; }
.nav-time { font-size: 12px; color: #888; }
.nav-mod-tag { font-size: 10px; color: #059669; background: #d1fae5; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; }
.nav-tag { font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; }
.nav-tag-title { color: #7c3aed; background: #ede9fe; }
.nav-tag-title2 { color: #db2777; background: #fce7f3; }
.nav-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.nav-dots { cursor: pointer; }
.nav-follow-btn {
  font-size: 13px; font-weight: 500; padding: 4px 12px; border-radius: 16px;
  border: 1px solid #4BCB73; color: #4BCB73; background: #fff;
  cursor: pointer; white-space: nowrap; line-height: 18px;
}
.nav-follow-btn.is-following {
  color: #999; border-color: #ddd; background: #f5f5f5;
}

/* ============ TITLE ============ */
.post-cover { margin-bottom: 12px; border-radius: 8px; overflow: hidden; }
.post-cover-img { width: 100%; max-height: 240px; object-fit: cover; display: block; }
.post-title { font-size: 20px; font-weight: 700; color: #111; line-height: 1.35; margin: 14px 0 12px; display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
.title-badge { display: inline-block; font-size: 11px; font-weight: 500; padding: 2px 8px; border-radius: 4px; line-height: 18px; white-space: nowrap; flex-shrink: 0; }
.title-badge-pin { background: #FEF3C7; color: #B45309; }
.title-badge-essence { background: #EDE9FE; color: #6D28D9; }
.title-badge-hot { background: #FEE2E2; color: #DC2626; }
.title-badge-lock { background: #F3F4F6; color: #6B7280; }
.title-badge-custom { background: #FCE4EC; color: #C62828; }
.status-bar { margin: 8px 0 0; padding: 8px 14px; border-radius: 8px; font-size: 13px; }
.status-pending { background: #FEF3C7; color: #92400E; }
.status-rejected { background: #FEE2E2; color: #991B1B; }
.status-locked { background: #F3F4F6; color: #6B7280; }
.status-deleted { background: #FFF3E0; color: #E65100; }
.status-scheduled { background: #E0E7FF; color: #3730A3; }
.status-auto-hide { background: #F3E8FF; color: #6B21A8; }
.status-hidden { background: #F3F4F6; color: #6B7280; }

/* ============ INFO LIST (【】style) ============ */
.info-list { margin-bottom: 14px; }
.info-row { font-size: 15px; line-height: 1.9; }
.info-label { font-weight: 700; color: #111; }
.info-value { color: #222; }
.info-link { color: #22C3D0; text-decoration: underline; }

/* ============ BODY TEXT ============ */
.post-body { font-size: 15px; color: #222; line-height: 1.75; margin-bottom: 16px; word-break: break-word; padding-left: 8px; }
.post-body :deep(h2) { font-size: 20px; font-weight: 700; line-height: 1.4; margin: .5em 0 .3em; }
.post-body :deep(h3) { font-size: 17px; font-weight: 600; line-height: 1.45; margin: .4em 0 .2em; }
.post-body :deep(strong) { font-weight: 700; }
.post-body :deep(em) { font-style: italic; }
.post-body :deep(u) { text-decoration: underline; }
.post-body :deep(s) { text-decoration: line-through; }
.post-body :deep(blockquote) { border-left: 3px solid #5c7cfa; padding: 6px 0 6px 12px; margin: 8px 0; color: #495057; background: #f8f9fa; border-radius: 0 6px 6px 0; }
.post-body :deep(pre.ql-syntax) { background: #f1f3f5; border-radius: 8px; padding: 10px 12px; font-size: 13px; overflow-x: auto; font-family: 'SF Mono', Monaco, monospace; white-space: pre; }
.post-body :deep(ol), .post-body :deep(ul) { padding-left: 20px; margin: 4px 0; }
.post-body :deep(ol) { list-style-type: decimal; }
.post-body :deep(ul) { list-style-type: disc; }
.post-body :deep(li) { margin: 2px 0; }
.post-body :deep(hr) { border: none; border-top: 1px solid #e9ecef; margin: 10px 0; }
.post-body :deep(p) { margin: 0 0 4px; }
.post-body :deep(.ql-size-12px) { font-size: 12px; }
.post-body :deep(.ql-size-14px) { font-size: 14px; }
.post-body :deep(.ql-size-16px) { font-size: 16px; }
.post-body :deep(.ql-size-18px) { font-size: 18px; }
.post-body :deep(.ql-size-20px) { font-size: 20px; }
.post-body :deep(.ql-size-24px) { font-size: 24px; }
.post-body :deep(.ql-size-28px) { font-size: 28px; }
.post-body :deep(.ql-size-32px) { font-size: 32px; }
.post-body :deep([style*="color"]) { /* inline styles pass through */ }
.post-body :deep(a[href*="/community/topic"]) { color: #6366f1; font-weight: 700; text-decoration: none; cursor: pointer; border-radius: 4px; padding: 0 2px; transition: background .15s; }
.post-body :deep(a[href*="/community/topic"]:hover) { background: #edf2ff; }

/* ============ IMAGES ============ */
.images-grid { display: grid; gap: 4px; margin-bottom: 14px; }
.images-grid.img-1 { grid-template-columns: 1fr; }
.images-grid.img-2 { grid-template-columns: 1fr 1fr; }
.images-grid.img-3 { grid-template-columns: 1fr 1fr 1fr; }
.image-item { border-radius: 8px; overflow: hidden; aspect-ratio: 1; cursor: pointer; }
.image-item img { width: 100%; height: 100%; object-fit: cover; display: block; }

/* ============ DOWNLOAD SECTION ============ */
.download-block { margin-bottom: 16px; }
.download-heading { font-size: 16px; font-weight: 600; color: #111; margin-bottom: 8px; }
.download-card { background: #f5f5f5; border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 10px; position: relative; }
.download-icon-box { width: 50px; height: 50px; background: #22C3D0; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.download-icon-box svg { width: 22px; height: 22px; }
.download-info { flex: 1; min-width: 0; }
.download-desc { font-size: 13px; color: #333; font-weight: 500; }
.download-hint { font-size: 11px; color: #999; margin-top: 3px; }
.download-btn-wrap { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.download-price-tag { font-size: 14px; font-weight: 700; color: #22C3D0; background: #fff; padding: 3px 10px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.download-btn { background: #fff; border: none; padding: 5px 14px; border-radius: 12px; font-size: 13px; color: #333; font-weight: 500; cursor: pointer; box-shadow: 0 1px 2px rgba(0,0,0,.05); }
.extract-row { margin-top: 8px; font-size: 12px; color: #888; }
.extract-val { font-weight: 600; color: #333; }

/* ============ TAGS ============ */
.tags-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
.tag-pill { display: flex; align-items: center; gap: 5px; background: #f3f3f3; border-radius: 14px; padding: 5px 12px; font-size: 13px; color: #444; }
.tag-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }

/* ============ REWARD ROW ============ */
.reward-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; margin-bottom: 4px; }
.reward-info { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #666; cursor: pointer; }
.reward-info:hover { color: #333; }
.reward-info em { font-style: normal; font-weight: 600; color: #F59E0B; }
.reward-donate-btn { background: #22C3D0; color: #fff; border: none; border-radius: 14px; padding: 5px 16px; font-size: 13px; font-weight: 500; cursor: pointer; }

/* ============ SPINNER ============ */
.loading-wrap { display: flex; justify-content: center; padding: 40px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #22C3D0; border-radius: 50%; animation: sp .6s linear infinite; }
@keyframes sp { to { transform: rotate(360deg); } }
.empty-wrap { flex: 1; display: flex; justify-content: center; align-items: center; color: #aaa; font-size: 13px; }

/* ============ IMAGE PREVIEW ============ */
.img-over { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,.95); display: flex; align-items: center; justify-content: center; }
.img-over-close { position: absolute; top: 16px; right: 16px; color: #fff; font-size: 32px; cursor: pointer; z-index: 10; line-height: 1; }
.img-over-idx { position: absolute; top: 20px; left: 16px; color: #fff; font-size: 14px; z-index: 10; }
.img-over-src { max-width: 90vw; max-height: 80vh; object-fit: contain; }
.img-over-prev, .img-over-next { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,.12); border: none; color: #fff; font-size: 36px; padding: 8px 12px; cursor: pointer; border-radius: 8px; z-index: 10; line-height: 1; }
.img-over-prev { left: 8px; }
.img-over-next { right: 8px; }

/* ============ BOTTOM SPACER ============ */
.bottom-spacer { height: 80px; }

/* ============ DONATION HISTORY ============ */
.coin-logs-body { max-height: 50vh; overflow-y: auto; padding: 0 18px 12px; }
.coin-logs-empty { text-align: center; color: #bbb; font-size: 13px; padding: 30px 0; }
.donate-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f3f3f3; }
.donate-item:last-child { border-bottom: none; }
.donate-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.donate-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.donate-info { flex: 1; display: flex; flex-direction: column; gap: 1px; }
.donate-name { font-size: 12px; font-weight: 600; color: #333; }
.donate-time { font-size: 10px; color: #bbb; }
.donate-amount { display: flex; align-items: baseline; gap: 2px; flex-shrink: 0; }
.donate-val { font-size: 15px; font-weight: 700; color: #F59E0B; }
.donate-unit { font-size: 10px; color: #999; }

/* ============ DONATE MODAL ============ */
.donate-overlay { position: fixed; inset: 0; z-index: 300; background: rgba(0,0,0,.45); display: flex; align-items: flex-end; justify-content: center; }
.donate-modal { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
@keyframes dmUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.dm-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
.dm-title { font-size: 17px; font-weight: 700; color: #222; }
.dm-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.dm-balance-row { display: flex; gap: 12px; margin-bottom: 16px; }
.dm-bal-item { flex: 1; background: #f7f8fa; border-radius: 10px; padding: 10px 14px; display: flex; flex-direction: column; gap: 4px; }
.dm-bal-label { font-size: 11px; color: #999; }
.dm-bal-val { font-size: 16px; font-weight: 700; color: #F59E0B; }
.dm-type-row, .dm-amount-row { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.dm-type-label { font-size: 13px; color: #666; flex-shrink: 0; width: 60px; }
.dm-type-tabs { display: flex; background: #f3f4f6; border-radius: 8px; padding: 2px; }
.dm-type-tab { padding: 6px 18px; font-size: 13px; border: none; background: none; color: #888; cursor: pointer; border-radius: 6px; transition: all .2s; }
.dm-type-tab.active { background: #22C3D0; color: #fff; }
.dm-amount-opts { display: flex; gap: 8px; }
.dm-amt-btn { width: 54px; height: 34px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; font-size: 14px; font-weight: 600; color: #333; cursor: pointer; }
.dm-amt-btn.active { border-color: #22C3D0; background: #e0f7f9; color: #22C3D0; }
.dm-custom-row { margin-bottom: 18px; }
.dm-custom-input { width: 100%; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 15px; color: #333; outline: none; box-sizing: border-box; }
.dm-custom-input:focus { border-color: #22C3D0; }
.dm-footer { display: flex; gap: 10px; }
.dm-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.dm-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #22C3D0; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.dm-confirm:disabled { background: #b0e0e6; cursor: not-allowed; }

/* ============ REPORT DIALOG ============ */
.report-dialog { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
.report-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; font-size: 17px; font-weight: 700; color: #222; }
.report-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.report-body { margin-bottom: 18px; }
.report-label { font-size: 13px; color: #666; margin-bottom: 10px; }
.report-types { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
.report-type-item { display: flex; align-items: center; gap: 5px; padding: 8px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 13px; color: #444; cursor: pointer; transition: all .2s; }
.report-type-item:hover { border-color: #F59E0B; background: #fff8ed; }
.report-type-item.active { border-color: #F59E0B; background: #fff3e0; color: #F59E0B; font-weight: 600; }
.report-type-item input[type="radio"] { display: none; }
.report-detail-row { margin-top: 8px; }
.report-textarea { width: 100%; height: 80px; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; color: #333; resize: none; outline: none; box-sizing: border-box; font-family: inherit; }
.report-textarea:focus { border-color: #F59E0B; }
.report-footer { display: flex; gap: 10px; }
.report-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.report-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #EF4444; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.report-confirm:disabled { background: #fca5a5; cursor: not-allowed; }

/* ============ ATTACH INFO MODAL ============ */
.attach-overlay { position: fixed; inset: 0; z-index: 310; background: rgba(0,0,0,.4); display: flex; align-items: center; justify-content: center; padding: 24px; }
.attach-modal { width: 100%; max-width: 360px; background: #fff; border-radius: 20px; padding: 28px 24px 20px; animation: amPop .2s ease; box-shadow: 0 12px 40px rgba(0,0,0,.12); }
@keyframes amPop { from { transform: scale(.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.attach-modal-icon { width: 56px; height: 56px; border-radius: 16px; background: #e0f7f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 14px; }
.attach-modal-title { font-size: 17px; font-weight: 700; color: #1a1a1a; text-align: center; margin: 0 0 6px; }
.attach-modal-desc { font-size: 13px; color: #888; text-align: center; margin: 0 0 18px; line-height: 1.5; }
.attach-modal-fields { background: #f7f8fa; border-radius: 12px; padding: 14px; margin-bottom: 20px; display: flex; flex-direction: column; gap: 12px; }
.attach-field { display: flex; flex-direction: column; gap: 4px; }
.attach-field-label { font-size: 11px; color: #999; font-weight: 500; text-transform: uppercase; letter-spacing: .5px; }
.attach-field-value { font-size: 14px; color: #333; font-weight: 500; }
.attach-field-url { word-break: break-all; line-height: 1.5; font-size: 13px; color: #555; }
.attach-field-code { font-size: 18px; font-weight: 700; color: #22C3D0; letter-spacing: 2px; }
.attach-modal-actions { display: flex; gap: 10px; }
.attach-btn { flex: 1; height: 44px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all .15s; }
.attach-btn-copy { background: #22C3D0; color: #fff; }
.attach-btn-copy:active { background: #1a9fa8; }
.attach-btn-close { background: #f3f4f6; color: #555; }
.attach-btn-close:active { background: #e5e7eb; }

/* Post action bar */
.post-action-bar { position: fixed; bottom: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; gap: 10px; padding: 8px 14px calc(8px + env(safe-area-inset-bottom, 0px)); border-top: 1px solid #eee; background: #fff; }
.action-input { flex: 1; display: flex; align-items: center; justify-content: space-between; height: 36px; padding: 0 12px; border-radius: 18px; background: #f5f5f5; cursor: pointer; }
.action-input-text { font-size: 14px; color: #bbb; }
.action-input-emoji { flex-shrink: 0; }
.action-icons { display: flex; align-items: center; gap: 4px; }
.action-icon-btn { display: flex; flex-direction: column; align-items: center; gap: 1px; padding: 2px 8px; border: none; background: none; cursor: pointer; min-width: 38px; }
.action-icon-btn svg { color: #999; transition: color .15s; }
.action-icon-count { font-size: 10px; color: #999; line-height: 1; }
.action-icon-count.active { color: #ef4444; }
.action-icon-btn.active svg { color: #ef4444; }

/* keep old action-btn style for compatibility */
.action-btn { display: flex; align-items: center; gap: 4px; padding: 6px 12px; border: none; background: none; cursor: pointer; color: #999; font-size: 14px; transition: all .15s; border-radius: 8px; }
.action-btn:hover { background: #f5f5f5; }
.action-btn.active { color: #ef4444; }
.action-btn.active svg { color: #ef4444; }

/* ============ REWARD DISPLAY ============ */
.reward-display {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  margin: 16px 0;
  padding: 4px 0;
  cursor: pointer;
  user-select: none;
}
.reward-avatars { display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.reward-avatar {
  width: 32px; height: 32px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 13px; font-weight: 700;
  border: 2px solid #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,.1);
  overflow: hidden;
  flex-shrink: 0;
  position: relative;
}
.reward-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.reward-avatar-more {
  background: #f0f0f0 !important;
  color: #999 !important;
  font-size: 10px;
  font-weight: 600;
}
.reward-summary { text-align: center; }
.reward-label { font-size: 12px; color: #999; }

/* ============ PERMISSION BARRIER ============ */
.perm-barrier {
  margin: 14px auto;
  border-radius: 12px;
  overflow: hidden;
  background: #f7f8fa;
  box-shadow: 0 2px 4px rgba(0,0,0,.02), 0 4px 10px rgba(0,0,0,.02);
  max-width: 320px;
}
.pb-deco {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 22px 0 0;
}
.pb-deco-bg {
  display: none;
}
.pb-deco-icon {
  width: 38px; height: 38px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.pb-deco-icon svg {
  width: 20px; height: 20px;
}
.pb-body {
  padding: 10px 20px 20px;
  text-align: center;
}
.pb-title {
  font-size: 15px; font-weight: 700;
  color: rgba(0,0,0,.5);
  line-height: 1.3;
  margin-bottom: 0;
}
.pb-sub {
  margin-top: 6px;
  margin-bottom: 0;
}
.pb-price-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 16px; font-weight: 700;
  color: rgba(0,0,0,.5);
}
.pb-hint {
  font-size: 13px; font-weight: 400;
  color: rgba(0,0,0,.5);
  line-height: 19px;
  margin: 0;
}
.pb-pwd-input {
  width: 100%;
  max-width: 200px;
  height: 36px;
  border: 1px solid rgba(0,0,0,.12);
  border-radius: 8px;
  padding: 0 12px;
  font-size: 13px;
  text-align: center;
  outline: none;
  background: #f9fafb;
  color: rgba(0,0,0,.85);
  transition: border-color .2s;
  box-sizing: border-box;
}
.pb-pwd-input::placeholder { color: rgba(0,0,0,.3); }
.pb-pwd-input:focus { border-color: rgba(0,102,255,.5); }
.pb-actions {
  display: flex;
  gap: 8px;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 14px;
}
.pb-btn {
  height: 36px;
  padding: 0 26px;
  border: none;
  border-radius: 18px;
  font-size: 13px; font-weight: 600;
  cursor: pointer;
  transition: all .15s cubic-bezier(.4,0,.2,1);
  white-space: nowrap;
}
.pb-btn:active { opacity: .85; }
.pb-btn-primary {
  background: linear-gradient(94.87deg, #06f .34%, #0085ff 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(0,102,255,.25), 0 1px 2px 0 rgba(0,102,255,.4);
}
.pb-btn-secondary {
  background: #f3f4f6;
  color: rgba(0,0,0,.85);
  box-shadow: none;
}
.pb-btn-secondary:active { background: #e5e7eb; }
.pb-btn-premium {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

/* Paid barrier - exact doubao.com proportions, gold color */
.perm-barrier-paid {
  margin: 14px auto;
  border-radius: 14px;
}
.perm-barrier-paid .pb-deco { padding-top: 24px; }
.perm-barrier-paid .pb-deco-icon { width: 38px; height: 38px; background: rgba(245,158,11,.08); color: #f59e0b; }
.perm-barrier-paid .pb-deco-icon svg { width: 20px; height: 20px; }
.perm-barrier-paid .pb-body { padding: 10px 20px 20px; }
.perm-barrier-paid .pb-title { font-size: 15px; }
.perm-barrier-paid .pb-sub { margin-top: 6px; }
.perm-barrier-paid .pb-price-tag { font-size: 13px; font-weight: 400; color: rgba(0,0,0,.5); gap: 2px; }
.perm-barrier-paid .pb-sold {
  margin: 4px 0 0;
  font-size: 12px; font-weight: 400;
  color: rgba(0,0,0,.35);
  text-align: center;
}
.perm-barrier-paid .pb-actions { margin-top: 14px; }
.perm-barrier-paid .pb-btn {
  height: 36px; padding: 0 26px;
  border-radius: 18px; font-size: 13px;
}
.perm-barrier-paid .pb-btn-primary {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

.perm-barrier-login .pb-deco-icon { background: rgba(0,102,255,.08); color: #06f; }

.perm-barrier-comment .pb-deco-icon { background: rgba(16,185,129,.08); color: #10b981; }
.perm-barrier-follow .pb-deco-icon { background: rgba(5,150,105,.08); color: #059669; }

.perm-barrier-level .pb-deco-icon,
.perm-barrier-level1 .pb-deco-icon,
.perm-barrier-level2 .pb-deco-icon { background: rgba(139,92,246,.08); color: #8b5cf6; }

.perm-barrier-password .pb-deco-icon { background: rgba(236,72,153,.08); color: #ec4899; }

.perm-barrier-title .pb-deco-icon { background: rgba(124,58,237,.08); color: #7c3aed; }
.perm-barrier-title .pb-btn-primary { background: linear-gradient(135deg, #7c3aed, #a78bfa); }

/* ===== COMMENT DIALOG ===== */
.comment-dialog-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,.45);
  z-index: 2000;
  display: flex; align-items: flex-end; justify-content: center;
}
.comment-dialog {
  width: 100%; max-width: 480px;
  background: #fff;
  border-radius: 16px 16px 0 0;
  overflow: hidden;
  animation: cdSlideUp .25s ease;
}
@keyframes cdSlideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.comment-dialog-header {
  display: flex; align-items: center; justify-content: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f0f0f0;
  position: relative;
}
.comment-dialog-title { font-size: 16px; font-weight: 600; color: #111; }
.comment-dialog-close {
  position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
  width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;
  font-size: 22px; color: #999; background: none; border: none; cursor: pointer;
}
.comment-dialog-body { padding: 16px; }
.comment-dialog-textarea {
  width: 100%; border: none; outline: none; resize: none;
  font-size: 15px; line-height: 1.6; color: #222;
  background: #f7f7f7; border-radius: 10px; padding: 12px;
  box-sizing: border-box;
}
.comment-dialog-toolbar {
  display: flex; align-items: center; padding: 8px 0 0;
}
.comment-dialog-img-btn {
  display: flex; align-items: center; justify-content: center;
  width: 34px; height: 34px; border-radius: 8px;
  background: #f5f5f5; cursor: pointer;
}
.comment-dialog-imgs {
  display: flex; gap: 8px; flex-wrap: wrap; padding: 8px 0 0;
}
.comment-dialog-img-item {
  position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden;
}
.comment-dialog-img-thumb {
  width: 100%; height: 100%; object-fit: cover;
}
.comment-dialog-img-remove {
  position: absolute; top: 2px; right: 2px;
  width: 18px; height: 18px; border-radius: 50%;
  background: rgba(0,0,0,.5); color: #fff; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
  border: none; cursor: pointer; line-height: 1;
}
.comment-dialog-footer {
  display: flex; gap: 12px; padding: 12px 16px 20px;
  border-top: 1px solid #f0f0f0;
}
.comment-dialog-cancel {
  flex: 1; height: 42px; border-radius: 21px;
  background: #f0f0f0; color: #666; font-size: 15px;
  border: none; cursor: pointer;
}
.comment-dialog-send {
  flex: 1; height: 42px; border-radius: 21px;
  background: linear-gradient(135deg, #508DFF, #3b6fcf); color: #fff; font-size: 15px; font-weight: 600;
  border: none; cursor: pointer;
}
.comment-dialog-send:disabled { opacity: .4; cursor: not-allowed; }

/* ============ PAYMENT DIALOGS ============ */
.modal-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.5);
  display: flex; align-items: center; justify-content: center;
  z-index: 200;
}
.confirm-modal {
  background: #fff; border-radius: 24px; width: 320px;
  padding: 32px 24px 24px; text-align: center;
}
.confirm-title {
  font-size: 18px; font-weight: 700; color: #1a1a2e; margin-bottom: 20px;
}
.confirm-detail {
  background: #f5f6fa; border-radius: 12px; padding: 16px; margin-bottom: 16px;
}
.confirm-row {
  display: flex; justify-content: space-between; align-items: center;
  font-size: 14px; color: #6b7280; padding: 6px 0;
}
.confirm-row + .confirm-row { border-top: 1px solid rgba(0,0,0,.05); }
.confirm-row .strong { color: #1a1a2e; font-weight: 600; }
.confirm-row .accent { color: #ff6b35; font-weight: 600; font-size: 12px; word-break: break-all; }
.pay-coupon-section {
  margin-bottom: 20px;
  text-align: left;
}
.confirm-actions { display: flex; gap: 12px; }
.confirm-btn {
  flex: 1; padding: 12px 0; border-radius: 12px; font-size: 15px;
  font-weight: 600; border: none; cursor: pointer; transition: all .2s;
}
.confirm-btn.cancel { background: #f0f0f5; color: #6b7280; }
.confirm-btn.cancel:hover { background: #e5e5eb; }
.confirm-btn.primary {
  background: linear-gradient(135deg, #ff6b35, #ff3c00); color: #fff;
}
.confirm-btn.primary:hover { opacity: .9; }
.confirm-btn.primary:disabled { opacity: .5; cursor: not-allowed; }

.result-modal {
  background: #fff; border-radius: 24px; width: 300px;
  padding: 32px 24px 24px; text-align: center;
}
.result-icon {
  width: 64px; height: 64px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px;
}
.result-icon svg { width: 32px; height: 32px; color: #fff; }
.result-icon.success {
  background: linear-gradient(135deg, #22c55e, #16a34a);
  box-shadow: 0 8px 24px rgba(34,197,94,.3);
}
.result-icon.fail {
  background: linear-gradient(135deg, #ef4444, #dc2626);
  box-shadow: 0 8px 24px rgba(239,68,68,.3);
}
.result-title { font-size: 18px; font-weight: 700; color: #1f2937; margin-bottom: 6px; }
.result-msg { font-size: 13px; color: #6b7280; margin-bottom: 4px; }
.result-detail {
  background: #f9fafb; border-radius: 14px; padding: 12px; margin: 16px 0;
}
.result-row {
  display: flex; justify-content: space-between; font-size: 12px;
  color: #6b7280; margin-bottom: 6px;
}
.result-row:last-child { margin-bottom: 0; }
.result-row .strong { color: #374151; font-weight: 600; }
.result-row .accent { color: #ef4444; font-weight: 600; }
.result-btn {
  width: 100%; padding: 12px; border-radius: 12px; border: none;
  font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 8px;
  background: #f3f4f6; color: #374151;
}
.result-btn.primary {
  background: linear-gradient(135deg, #f59e0b, #ea580c); color: #fff;
}

.coupon-dd-item {
  display: flex; justify-content: space-between; width: 100%;
}
.coupon-dd-left { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.coupon-dd-right { font-size: 11px; color: #999; margin-left: 8px; white-space: nowrap; }
.load-more-wrap { display: flex; align-items: center; justify-content: center; padding: 16px 0 20px; color: #508DFF; font-size: 14px; cursor: pointer; user-select: none; }
.load-more-wrap:active { opacity: .7; }
.load-more-spin { width: 20px; height: 20px; border: 2px solid #e0e0e0; border-top-color: #508DFF; border-radius: 50%; animation: load-more-rotate .6s linear infinite; }
@keyframes load-more-rotate { to { transform: rotate(360deg); } }

.fav-picker-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 200; display: flex; align-items: center; justify-content: center; }
.fav-picker-card { background: #fff; border-radius: 16px; width: 300px; padding: 20px; box-shadow: 0 12px 40px rgba(0,0,0,.15); }
.fav-picker-header { display: flex; align-items: center; justify-content: space-between; font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 14px; }
.fav-picker-header button { background: none; border: none; font-size: 22px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.fav-picker-body { max-height: 260px; overflow-y: auto; margin-bottom: 14px; }
.fav-picker-item { padding: 10px 14px; border-radius: 8px; margin-bottom: 4px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; background: #f9fafb; transition: all .15s; }
.fav-picker-item.active { background: #fce7f3; border: 1px solid #EC4899; }
.fav-picker-actions { display: flex; gap: 8px; }
.fav-picker-btn { flex: 1; padding: 10px 0; border: none; border-radius: 10px; font-size: 14px; cursor: pointer; }
.fav-picker-btn.outline { background: #f3f4f6; color: #666; }
.fav-picker-btn.primary { background: #EC4899; color: #fff; font-weight: 600; }
</style>
