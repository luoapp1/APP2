<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">基础配置</span>
      <button v-auth="'edit'" class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-xs font-medium active:opacity-85 shadow-sm shadow-red-200 flex-shrink-0" @click="saveConfig">{{ saving ? '保存中...' : '保存' }}</button>
    </div>

    <div class="flex-1 overflow-y-auto pb-20 p-4 space-y-4">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>

      <template v-else>
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">主题设置</div>
          <div class="text-[10px] text-gray-400">日间模式及夜间模式显示效果，默认为自动根据时间切换</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">显示模式</label>
            <select v-model="cfg.theme_mode" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="auto">自动切换（根据时间）</option>
              <option value="light">日间模式</option>
              <option value="dark">夜间模式</option>
            </select>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">前端显示切换按钮</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.show_theme_switch ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.show_theme_switch = !cfg.show_theme_switch">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.show_theme_switch ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div class="flex items-center justify-between">
            <div>
              <span class="text-sm text-gray-600">自动刷新页面内容</span>
              <div class="text-[10px] text-gray-400 mt-0.5">关闭后进入页面不会自动请求数据，需手动刷新</div>
            </div>
            <button class="w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ml-2" :class="cfg.auto_refresh ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.auto_refresh = !cfg.auto_refresh">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.auto_refresh ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">系统通知</div>
          <div class="text-[10px] text-gray-400">指定用作系统通知发送者的用户账号，未配置时显示"管理员"</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">通知操作者</label>
            <div class="flex gap-2" v-if="!cfg.system_operator_id">
              <input
                v-model="operatorSearch"
                class="flex-1 h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none"
                placeholder="输入用户名或昵称"
                @keyup.enter="addOperator"
              />
              <button class="px-4 h-10 bg-[#6366F1] text-white text-xs rounded-xl font-medium active:opacity-85 flex-shrink-0" @click="addOperator">添加</button>
            </div>
            <div v-if="resultMsg" class="text-[11px]" :class="resultError ? 'text-red-400' : 'text-green-500'">{{ resultMsg }}</div>
            <div v-if="cfg.system_operator_id" class="flex items-center gap-2 mt-2 bg-[#f5f6f8] rounded-lg px-3 py-2">
              <span class="w-7 h-7 rounded-full bg-[#6366F1] text-white text-xs flex items-center justify-center font-medium">{{ (operatorLabel || '?').charAt(0) }}</span>
              <span class="text-sm text-gray-700">{{ operatorLabel }}</span>
              <button class="ml-auto text-[11px] text-red-400" @click="cfg.system_operator_id = ''; operatorLabel = ''">移除</button>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">聊天室创建权限</div>
          <div class="flex items-center justify-between">
            <div>
              <span class="text-sm text-gray-600">启用条件限制</span>
              <div class="text-[10px] text-gray-400 mt-0.5">关闭时不限制，所有用户均可创建聊天室</div>
            </div>
            <button class="w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ml-2" :class="cfg.chat_room_create_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.chat_room_create_enabled = !cfg.chat_room_create_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.chat_room_create_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <template v-if="cfg.chat_room_create_enabled">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最低经验等级</label>
                <input v-model.number="cfg.chat_room_min_exp_level" type="number" min="0" max="999" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="0=不限制" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最低会员等级</label>
                <input v-model.number="cfg.chat_room_min_mem_level" type="number" min="0" max="999" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="0=不限制" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最低发帖数</label>
                <input v-model.number="cfg.chat_room_min_posts" type="number" min="0" max="99999" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="0=不限制" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最低积分</label>
                <input v-model.number="cfg.chat_room_min_points" type="number" min="0" max="999999" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="0=不限制" />
              </div>
            </div>
          </template>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">网站信息</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站名称</label>
            <input v-model="cfg.site_name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="对外全称，用于浏览器标题、邮件、分享卡片" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站副标题</label>
            <input v-model="cfg.site_subtitle" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="补充描述，用于首页SEO、底部说明" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站域名</label>
            <input v-model="cfg.site_domain" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">后台入口地址</label>
            <input v-model="cfg.admin_path" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="如 /admin123" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站图标 favicon</label>
            <input v-model="cfg.site_favicon" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="32×32px ICO格式URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">PC端LOGO</label>
            <input v-model="cfg.logo_pc" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="透明PNG格式URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">移动端LOGO</label>
            <input v-model="cfg.logo_mobile" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="适配手机端尺寸URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">底部版权信息</label>
            <input v-model="cfg.copyright" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="©2026 某某网站 版权所有" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">ICP备案号</label>
            <input v-model="cfg.icp" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="粤ICP备xxxx号" />
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">页面链接</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">帮助与反馈链接</label>
            <input v-model="cfg.help_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com/help" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">用户协议链接</label>
            <input v-model="cfg.agreement_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com/agreement" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">隐私政策链接</label>
            <input v-model="cfg.privacy_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com/privacy" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">安全条款链接</label>
            <input v-model="cfg.security_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com/security" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">关于页链接</label>
            <input v-model="cfg.about_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com/about" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">交流群组内容</label>
            <textarea v-model="cfg.community_content" class="w-full h-24 px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="支持HTML，如QQ群号、微信群二维码图片链接等" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">联系我们内容</label>
            <textarea v-model="cfg.contact_content" class="w-full h-24 px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="支持HTML，如客服微信、邮箱、电话等" />
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">登录安全</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">后台登录验证码</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.login_captcha ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.login_captcha = !cfg.login_captcha">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.login_captcha ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">连续错误次数</label>
              <input v-model.number="cfg.login_max_errors" type="number" min="1" max="100" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
              <div class="text-[10px] text-gray-400 mt-0.5">达到后临时封禁</div>
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">封号时长(分钟)</label>
              <input v-model.number="cfg.login_lock_minutes" type="number" min="1" max="1440" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">IP安全限制</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">API请求签名验证</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.api_sign_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.api_sign_enabled = !cfg.api_sign_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.api_sign_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">接口请求频率限制 (次/分钟)</label>
            <input v-model.number="cfg.api_rate_limit" type="number" min="0" max="1000" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">IP黑名单 (每行一个)</label>
            <textarea v-model="cfg.ip_blacklist" class="w-full h-20 px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="172.16.0.1" />
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">用户注册</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">开启用户注册</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.register_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.register_enabled = !cfg.register_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.register_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
           <div v-if="cfg.register_enabled">
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">注册验证方式</label>
            <select v-model="cfg.register_verify_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="none">无需验证</option>
              <option value="email">邮箱验证</option>
              <option value="mobile">手机验证</option>
            </select>
          </div>
          <div v-if="cfg.register_enabled && cfg.register_verify_type === 'email'">
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">验证邮件模板</label>
            <select v-model="cfg.register_email_config_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="">-- 默认模板 --</option>
              <option v-for="t in emailTemplates" :key="t.id" :value="String(t.id)">{{ t.name }} ({{ t.subject }})</option>
            </select>
            <div class="text-[10px] text-gray-400 mt-1">选择用于发送注册验证码的邮箱服务配置</div>
          </div>
          <div v-if="cfg.register_enabled && cfg.register_verify_type === 'mobile'" class="bg-[#fdf2f4] rounded-xl p-4 border border-[#FF4757]/20">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-sm font-bold text-gray-800 flex items-center gap-2">
                  <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                  短信发送通道
                </div>
                <div class="text-[10px] text-gray-400 mt-0.5">关闭后验证码仅存库，不调用第三方短信服务</div>
              </div>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.sms_channel_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.sms_channel_enabled = !cfg.sms_channel_enabled">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.sms_channel_enabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">密码规则</label>
            <select v-model="cfg.password_rule" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="any">无限制</option>
              <option value="alphanumeric">字母+数字</option>
              <option value="strong">字母+数字+特殊字符</option>
            </select>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">新用户默认分组</label>
            <select v-model="cfg.register_default_group" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="">-- 不分组 --</option>
              <option v-for="r in roles" :key="r.roleId ?? r.id" :value="String(r.roleId ?? r.id)">{{ r.roleName ?? r.name }}</option>
            </select>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">新用户默认会员等级</label>
            <select v-model="cfg.register_default_level" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="">-- 不设置 --</option>
              <option v-for="lv in memberLevels" :key="lv.id" :value="String(lv.id)">{{ lv.name }} (Lv.{{ lv.level }})</option>
            </select>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">用户ID起始编号</label>
            <input v-model.number="cfg.register_start_id" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="如 10001，新用户从该ID递增" />
            <div class="text-[10px] text-gray-400 mt-1">留空或0则使用系统自动编号。设置后下一个注册用户的ID将从此数字开始递增</div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">用户名最小长度</label>
              <input v-model.number="cfg.register_username_min" type="number" min="1" max="50" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">密码最小长度</label>
              <input v-model.number="cfg.register_password_min" type="number" min="1" max="50" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
            </div>
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="flex items-center justify-between">
            <div>
              <div class="text-sm font-bold text-gray-800">网站维护模式</div>
              <div class="text-[10px] text-gray-400 mt-0.5">开启后访客将看到维护页面</div>
            </div>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.maintenance_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.maintenance_enabled = !cfg.maintenance_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.maintenance_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div v-if="cfg.maintenance_enabled">
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">维护提示文案</label>
            <textarea v-model="cfg.maintenance_msg" class="w-full h-20 px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="系统维护中，请稍后再试..." />
          </div>
        </div>


      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { SystemThemeEnum } from '@/enums/appEnum'
import { useSettingStore } from '@/store/modules/setting'
import { useTheme as useAppTheme, injectFallbackDark as sharedInjectFallbackDark } from '@/hooks/core/useTheme'
import request from '@/utils/http'
import { fetchSaveSysConfig } from '@/api/system-manage'

defineOptions({ name: 'SiteConfigMobile' })

const SITE_NAME_KEY = 'art_site_name'
const FALLBACK_DARK_ID = 'art-fallback-dark'

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false)
const saving = ref(false)
const roles = ref<any[]>([])
const memberLevels = ref<any[]>([])
const emailConfigs = ref<any[]>([])
  const emailTemplates = ref<any[]>([])
const settingStore = useSettingStore()

const cfg = reactive<any>({
  theme_mode: 'auto',
  show_theme_switch: true,
  auto_refresh: true,
  site_name: '',
  site_subtitle: '',
  site_domain: '',
  admin_path: '/admin',
  site_favicon: '',
  logo_pc: '',
  logo_mobile: '',
  copyright: '',
  icp: '',
  login_captcha: true,
  login_max_errors: 5,
  login_lock_minutes: 15,
  ip_blacklist: '',
  api_sign_enabled: true,
  api_rate_limit: 60,
  register_enabled: true,
  register_verify_type: 'none',
  register_email_config_id: '',
  register_default_group: '',
  register_default_level: '',
  register_start_id: 0,
  register_username_min: 3,
  register_password_min: 6,
  sms_channel_enabled: true,
  password_rule: 'alphanumeric',
  maintenance_enabled: false,
  maintenance_msg: '',
  help_url: '',
  agreement_url: '',
  privacy_url: '',
  security_url: '',
  about_url: '',
  contact_url: '',
  community_url: '',
  community_content: '',
  contact_content: '',
  system_operator_id: '',
  chat_room_create_enabled: false,
  chat_room_min_exp_level: 0,
  chat_room_min_mem_level: 0,
  chat_room_min_posts: 0,
  chat_room_min_points: 0
})

function injectFallbackDark() {
  sharedInjectFallbackDark()
}

function removeFallbackDark() {
  const el = document.getElementById(FALLBACK_DARK_ID)
  if (el) el.remove()
}

function hasActiveThemeVars(): boolean {
  const darkStyle = document.getElementById('theme-dark-vars')
  if (!darkStyle || !darkStyle.textContent) return false
  return darkStyle.textContent.replace('.dark {', '').replace('}', '').trim().length > 0
}

function applyFavicon(url: string) {
  let link = document.querySelector('link[rel="icon"]') as HTMLLinkElement | null
  if (!link) {
    link = document.createElement('link')
    link.rel = 'icon'
    document.head.appendChild(link)
  }
  link.href = url || ''
}

function applySiteName(name: string) {
  if (name) {
    localStorage.setItem(SITE_NAME_KEY, name)
    document.title = name
  } else {
    localStorage.removeItem(SITE_NAME_KEY)
  }
}

const { switchThemeStyles } = useAppTheme()

const operatorSearch = ref('')
const operatorLabel = ref('')
const resultMsg = ref('')
const resultError = ref(false)
let operatorTimer: any = null

async function addOperator() {
  const q = operatorSearch.value.trim()
  if (!q) { resultMsg.value = '请输入用户名或昵称'; resultError.value = true; return }
  try {
    const res: any = await request.get({ url: '/api/community/user/search', params: { keyword: q } })
    const list = res?.data?.data || res?.data || res
    const found = Array.isArray(list) ? list[0] : null
    if (found) {
      cfg.system_operator_id = String(found.id)
      operatorLabel.value = found.nickname || found.username || ''
      operatorSearch.value = ''
      resultMsg.value = '添加成功'
      resultError.value = false
    } else {
      resultMsg.value = '未找到该用户'
      resultError.value = true
    }
  } catch {
    resultMsg.value = '查询失败'
    resultError.value = true
  }
}

document.addEventListener('click', () => {})

const themeModeMap: Record<string, SystemThemeEnum> = {
  light: SystemThemeEnum.LIGHT,
  dark: SystemThemeEnum.DARK,
  auto: SystemThemeEnum.AUTO
}

function applyTheme(mode: string) {
  const enumVal = themeModeMap[mode]
  if (enumVal === undefined) return
  switchThemeStyles(enumVal)
  localStorage.setItem('art_site_theme', mode)
  if (enumVal === SystemThemeEnum.DARK || enumVal === SystemThemeEnum.AUTO) injectFallbackDark()
  if (enumVal === SystemThemeEnum.LIGHT) removeFallbackDark()
}

const loadConfig = async () => {
  loading.value = true
  try {
    const [configRes, roleRes]: any[] = await Promise.all([
      request.get({ url: '/api/sys-config/list' }),
      request.get({ url: '/api/role/list' })
    ])

    if (roleRes && roleRes.records) roles.value = roleRes.records

    try {
      const lvRes = await request.get({ url: '/api/membership/levels' })
      if (lvRes && Array.isArray(lvRes)) memberLevels.value = lvRes
      else if (lvRes && lvRes.data && Array.isArray(lvRes.data)) memberLevels.value = lvRes.data
    } catch { memberLevels.value = [] }

    try {
      const emailRes = await request.get({ url: '/api/email/templates' })
      if (emailRes && Array.isArray(emailRes)) emailTemplates.value = emailRes.filter((c: any) => c.status === '1' || c.status === 1)
      else if (emailRes && emailRes.data && Array.isArray(emailRes.data)) emailTemplates.value = emailRes.data.filter((c: any) => c.status === '1' || c.status === 1)
    } catch { emailTemplates.value = [] }

    if (configRes && Array.isArray(configRes)) {
      const map: Record<string, string> = {}
      for (const item of configRes) {
        if (item.config_key && item.config_value !== undefined) {
          map[item.config_key] = String(item.config_value)
        }
      }

      if (map.site_theme_mode) { cfg.theme_mode = map.site_theme_mode; applyTheme(map.site_theme_mode) }
      else cfg.theme_mode = settingStore.systemThemeMode
      if (map.site_show_theme_switch) cfg.show_theme_switch = map.site_show_theme_switch === 'true'
      if (map.site_auto_refresh !== undefined) { cfg.auto_refresh = map.site_auto_refresh === 'true'; localStorage.setItem('art_site_auto_refresh', cfg.auto_refresh ? '1' : '0') }
      if (map.site_name) { cfg.site_name = map.site_name; applySiteName(map.site_name) }
      if (map.site_favicon) { cfg.site_favicon = map.site_favicon; applyFavicon(map.site_favicon) }
      if (map.site_subtitle) cfg.site_subtitle = map.site_subtitle
      if (map.site_domain) cfg.site_domain = map.site_domain
      if (map.site_admin_path) cfg.admin_path = map.site_admin_path
      if (map.site_logo_pc) cfg.logo_pc = map.site_logo_pc
      if (map.site_logo_mobile) cfg.logo_mobile = map.site_logo_mobile
      if (map.site_copyright) cfg.copyright = map.site_copyright
      if (map.site_icp) cfg.icp = map.site_icp
      if (map.login_captcha_enabled) cfg.login_captcha = map.login_captcha_enabled === 'true'
      if (map.login_max_errors) cfg.login_max_errors = parseInt(map.login_max_errors) || 5
      if (map.login_lock_minutes) cfg.login_lock_minutes = parseInt(map.login_lock_minutes) || 15
      if (map.ip_blacklist) cfg.ip_blacklist = map.ip_blacklist
      if (map.api_sign_enabled) cfg.api_sign_enabled = map.api_sign_enabled === 'true'
      if (map.api_rate_limit) cfg.api_rate_limit = parseInt(map.api_rate_limit) || 60
      if (map.register_enabled) cfg.register_enabled = map.register_enabled === 'true'
      if (map.register_verify_type) cfg.register_verify_type = map.register_verify_type
      if (map.register_email_config_id) cfg.register_email_config_id = map.register_email_config_id
      if (map.register_default_group) cfg.register_default_group = map.register_default_group
      if (map.register_default_level) cfg.register_default_level = map.register_default_level
      if (map.register_start_id) cfg.register_start_id = parseInt(map.register_start_id) || 0
      if (map.register_username_min) cfg.register_username_min = parseInt(map.register_username_min) || 3
      if (map.register_password_min) cfg.register_password_min = parseInt(map.register_password_min) || 6
      if (map.password_rule) cfg.password_rule = map.password_rule
      if (map.sms_channel_enabled) cfg.sms_channel_enabled = map.sms_channel_enabled === 'true'
      if (map.site_maintenance_enabled) cfg.maintenance_enabled = map.site_maintenance_enabled === 'true'
      if (map.site_maintenance_msg) cfg.maintenance_msg = map.site_maintenance_msg
      if (map.site_help_url) cfg.help_url = map.site_help_url
      if (map.site_agreement_url) cfg.agreement_url = map.site_agreement_url
      if (map.site_privacy_url) cfg.privacy_url = map.site_privacy_url
      if (map.site_security_url) cfg.security_url = map.site_security_url
      if (map.site_about_url) cfg.about_url = map.site_about_url
      if (map.site_community_url) cfg.community_url = map.site_community_url
      if (map.site_contact_url) cfg.contact_url = map.site_contact_url
      if (map.site_community_content) cfg.community_content = map.site_community_content
      if (map.site_contact_content) cfg.contact_content = map.site_contact_content
      if (map.system_operator_id) {
        cfg.system_operator_id = map.system_operator_id
        operatorLabel.value = '用户 #' + map.system_operator_id
      }
      if (map.chat_room_create_condition) {
        try {
          const cc = JSON.parse(map.chat_room_create_condition)
          cfg.chat_room_create_enabled = !!cc.enabled
          cfg.chat_room_min_exp_level = Number(cc.min_experience_level) || 0
          cfg.chat_room_min_mem_level = Number(cc.min_membership_level) || 0
          cfg.chat_room_min_posts = Number(cc.min_post_count) || 0
          cfg.chat_room_min_points = Number(cc.min_points) || 0
        } catch {}
      }
    }
  } catch {}
  loading.value = false
}

const saveConfig = async () => {
  saving.value = true
  try {
    const configs = [
      { config_key: 'site_theme_mode', config_value: cfg.theme_mode, description: '主题显示模式' },
      { config_key: 'site_show_theme_switch', config_value: String(cfg.show_theme_switch), description: '前端显示主题切换按钮' },
      { config_key: 'site_auto_refresh', config_value: String(cfg.auto_refresh), description: '自动刷新页面内容' },
      { config_key: 'site_name', config_value: cfg.site_name, description: '网站名称' },
      { config_key: 'site_subtitle', config_value: cfg.site_subtitle, description: '网站副标题' },
      { config_key: 'site_domain', config_value: cfg.site_domain, description: '网站域名' },
      { config_key: 'site_admin_path', config_value: cfg.admin_path, description: '后台入口地址' },
      { config_key: 'site_favicon', config_value: cfg.site_favicon, description: '网站favicon' },
      { config_key: 'site_logo_pc', config_value: cfg.logo_pc, description: 'PC端LOGO' },
      { config_key: 'site_logo_mobile', config_value: cfg.logo_mobile, description: '移动端LOGO' },
      { config_key: 'site_copyright', config_value: cfg.copyright, description: '底部版权信息' },
      { config_key: 'site_icp', config_value: cfg.icp, description: 'ICP备案号' },
      { config_key: 'login_captcha_enabled', config_value: String(cfg.login_captcha), description: '后台登录验证码' },
      { config_key: 'login_max_errors', config_value: String(cfg.login_max_errors), description: '连续登录错误次数' },
      { config_key: 'login_lock_minutes', config_value: String(cfg.login_lock_minutes), description: '封号时长(分钟)' },
      { config_key: 'ip_blacklist', config_value: cfg.ip_blacklist, description: 'IP黑名单' },
      { config_key: 'api_sign_enabled', config_value: String(cfg.api_sign_enabled), description: 'API请求签名验证' },
      { config_key: 'api_rate_limit', config_value: String(cfg.api_rate_limit), description: '接口请求频率限制' },
      { config_key: 'register_enabled', config_value: String(cfg.register_enabled), description: '开启用户注册' },
      { config_key: 'register_verify_type', config_value: cfg.register_verify_type, description: '注册验证方式' },
      { config_key: 'register_email_config_id', config_value: String(cfg.register_email_config_id || ''), description: '注册验证邮件模板ID' },
      { config_key: 'register_default_group', config_value: cfg.register_default_group, description: '新用户默认分组' },
      { config_key: 'register_default_level', config_value: String(cfg.register_default_level || ''), description: '新用户默认会员等级' },
      { config_key: 'register_start_id', config_value: String(cfg.register_start_id || 0), description: '用户ID起始编号' },
      { config_key: 'register_username_min', config_value: String(cfg.register_username_min || 3), description: '用户名最小长度' },
      { config_key: 'register_password_min', config_value: String(cfg.register_password_min || 6), description: '密码最小长度' },
      { config_key: 'password_rule', config_value: cfg.password_rule, description: '密码规则' },
      { config_key: 'sms_channel_enabled', config_value: String(cfg.sms_channel_enabled), description: '短信发送通道开关' },
      { config_key: 'site_maintenance_enabled', config_value: String(cfg.maintenance_enabled), description: '网站维护开关' },
      { config_key: 'site_maintenance_msg', config_value: cfg.maintenance_msg, description: '维护提示文案' },
      { config_key: 'site_help_url', config_value: cfg.help_url, description: '帮助与反馈链接' },
      { config_key: 'site_agreement_url', config_value: cfg.agreement_url, description: '用户协议链接' },
      { config_key: 'site_privacy_url', config_value: cfg.privacy_url, description: '隐私政策链接' },
      { config_key: 'site_security_url', config_value: cfg.security_url, description: '安全条款链接' },
      { config_key: 'site_about_url', config_value: cfg.about_url, description: '关于页链接' },
      { config_key: 'site_community_url', config_value: cfg.community_url, description: '交流群组链接' },
      { config_key: 'site_contact_url', config_value: cfg.contact_url, description: '联系我们链接' },
      { config_key: 'site_community_content', config_value: cfg.community_content, description: '交流群组弹窗内容' },
      { config_key: 'site_contact_content', config_value: cfg.contact_content, description: '联系我们弹窗内容' },
      { config_key: 'system_operator_id', config_value: cfg.system_operator_id, description: '系统通知操作者' },
      { config_key: 'chat_room_create_condition', config_value: JSON.stringify({
        enabled: cfg.chat_room_create_enabled,
        min_experience_level: cfg.chat_room_min_exp_level,
        min_membership_level: cfg.chat_room_min_mem_level,
        min_post_count: cfg.chat_room_min_posts,
        min_points: cfg.chat_room_min_points
      }), description: '聊天室创建权限' }
    ]
    await fetchSaveSysConfig(configs)

    applyTheme(cfg.theme_mode)
    applySiteName(cfg.site_name)
    applyFavicon(cfg.site_favicon)
    localStorage.setItem('art_site_auto_refresh', cfg.auto_refresh ? '1' : '0')

    showToast('配置保存成功')
  } catch (e: any) {
    showToast('保存失败: ' + (e?.msg || e?.message || ''), 'error')
  } finally {
    saving.value = false
  }
}

onMounted(() => loadConfig())
</script>
