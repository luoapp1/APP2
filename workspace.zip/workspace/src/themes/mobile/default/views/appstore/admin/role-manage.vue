<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <!-- 顶部标题栏 -->
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">角色管理</span>
    </div>

    <!-- 操作栏 -->
    <div class="bg-white mx-3 mt-3 rounded-xl p-3">
      <div class="flex gap-2 mb-3">
        <input
          v-model="searchKey"
          type="text"
          placeholder="搜索角色名称"
          class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"
          @keyup.enter="handleSearch"
        />
        <button class="h-9 px-4 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80 flex-shrink-0" @click="handleSearch">
          搜索
        </button>
        <button v-auth="'add'" class="h-9 w-9 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80 flex items-center justify-center flex-shrink-0" @click="openAddDialog">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        </button>
      </div>

      <div class="flex items-center justify-between">
        <div class="flex items-center gap-1.5">
          <span class="text-xs text-gray-400">排序:</span>
          <select
            v-model="sortField"
            class="text-xs px-2 py-1 bg-[#f5f6f8] rounded border-none outline-none text-gray-600"
            @change="handleSearch"
          >
            <option value="id">ID</option>
            <option value="createTime">创建时间</option>
          </select>
          <button class="text-xs px-2 py-1 rounded bg-[#f5f6f8] text-gray-500 active:opacity-70" @click="toggleSortOrder">{{ sortOrder === 'desc' ? '降序' : '升序' }}</button>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="text-xs text-gray-400">每页:</span>
          <select
            v-model="pageSize"
            class="text-xs px-2 py-1 bg-[#f5f6f8] rounded border-none outline-none text-gray-600"
            @change="handlePageSizeChange"
          >
            <option :value="10">10</option>
            <option :value="15">15</option>
            <option :value="20">20</option>
            <option :value="50">50</option>
          </select>
        </div>
      </div>
    </div>

    <!-- 加载中 -->
    <div v-if="loading" class="flex-1 flex items-center justify-center">
      <div class="animate-spin w-6 h-6 border-2 border-[#FF4757] border-t-transparent rounded-full" />
    </div>

    <!-- 角色列表 -->
    <div v-else class="flex-1 overflow-y-auto px-3 pb-3">
      <div v-if="list.length === 0" class="flex flex-col items-center justify-center py-20 text-gray-400">
        <svg class="w-16 h-16 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
        </svg>
        <span class="text-sm">暂无角色数据</span>
      </div>

      <div
        v-for="role in list"
        :key="role.roleId"
        class="bg-white mt-3 rounded-xl p-4"
      >
        <div class="flex items-start justify-between">
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <span class="text-sm font-semibold text-gray-800">{{ role.roleName }}</span>
              <span
                class="text-[10px] px-1.5 py-0.5 rounded-full font-medium"
                :class="role.enabled ? 'bg-[#ecfdf5] text-[#059669]' : 'bg-[#fef2f2] text-[#dc2626]'"
              >{{ role.enabled ? '启用' : '禁用' }}</span>
            </div>
            <div class="text-xs text-gray-400 mt-1">{{ role.roleCode }}</div>
            <div v-if="role.description" class="text-xs text-gray-500 mt-1 line-clamp-2">{{ role.description }}</div>
            <div class="text-[10px] text-gray-300 mt-2">ID: {{ role.roleId }} / 创建: {{ formatTime(role.createTime) }}</div>
          </div>
        </div>
        <div class="flex items-center justify-between mt-3 pt-3 border-t border-gray-50">
          <button class="text-xs text-gray-400 flex items-center gap-1" @click="toggleCardActions(role.roleId)">
            <span>{{ expandedCards.has(role.roleId) ? '收起' : '操作' }}</span>
            <svg class="w-3 h-3 transition-transform" :class="{ 'rotate-180': expandedCards.has(role.roleId) }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </button>
        </div>
        <div v-show="expandedCards.has(role.roleId)" class="flex gap-2 mt-2">
          <button v-auth="'edit'" class="flex-1 py-2 text-xs font-medium rounded-lg bg-[#eff6ff] text-[#3b82f6] active:opacity-70" @click="openEditDialog(role)">编辑</button>
          <button v-auth="'edit'" class="flex-1 py-2 text-xs font-medium rounded-lg bg-[#f5f3ff] text-[#7c3aed] active:opacity-70" @click="openPermissionDialog(role)">权限</button>
          <button v-auth="'delete'" class="flex-1 py-2 text-xs font-medium rounded-lg bg-[#fef2f2] text-[#dc2626] active:opacity-70" @click="confirmDelete(role)">删除</button>
        </div>
      </div>

      <!-- 分页栏 -->
      <div v-if="totalPages > 1" class="flex items-center justify-center gap-3 mt-4 pb-2">
        <button
          :disabled="currentPage <= 1"
          class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70"
          @click="goPage(currentPage - 1)"
        >上一页</button>

        <div class="flex items-center gap-1">
          <button
            v-for="p in pageNumbers"
            :key="p"
            class="w-7 h-7 text-xs rounded-lg"
            :class="p === currentPage ? 'bg-[#FF4757] text-white' : 'bg-white text-gray-500 shadow-sm'"
            @click="goPage(p)"
          >{{ p }}</button>
        </div>

        <button
          :disabled="currentPage >= totalPages"
          class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70"
          @click="goPage(currentPage + 1)"
        >下一页</button>
      </div>

      <div class="text-center text-xs text-gray-400 pb-4">
        共 {{ total }} 条 / {{ totalPages }} 页
      </div>
    </div>

    <!-- 新增/编辑弹窗 -->
    <div v-if="showForm" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closeForm">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-50">
          <button class="text-gray-400 text-sm" @click="closeForm">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">{{ formMode === 'add' ? '新增角色' : '编辑角色' }}</span>
          <button v-auth="formMode === 'add' ? 'add' : 'edit'" class="text-sm font-semibold text-[#FF4757]" @click="submitForm">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          <div>
            <div class="text-[11px] text-gray-400 mb-1">角色名称</div>
            <input v-model="formData.roleName" class="w-full text-sm text-gray-800 bg-[#f5f6f8] rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] transition-all" placeholder="请输入角色名称" />
          </div>
          <div>
            <div class="text-[11px] text-gray-400 mb-1">角色编码</div>
            <input v-model="formData.roleCode" class="w-full text-sm text-gray-800 bg-[#f5f6f8] rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] transition-all" placeholder="请输入角色编码" />
          </div>
          <div>
            <div class="text-[11px] text-gray-400 mb-1">角色描述</div>
            <textarea v-model="formData.description" rows="3" class="w-full text-sm text-gray-800 bg-[#f5f6f8] rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] transition-all resize-none" placeholder="请输入角色描述"></textarea>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-700">启用状态</span>
            <button
              class="relative w-11 h-6 rounded-full transition-colors duration-200"
              :class="formData.enabled ? 'bg-[#FF4757]' : 'bg-gray-300'"
              @click="formData.enabled = !formData.enabled"
            >
              <span class="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200" :class="formData.enabled ? 'translate-x-5' : ''" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 权限管理弹窗 -->
    <div v-if="showPermission" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closePermission">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-50">
          <button class="text-gray-400 text-sm" @click="closePermission">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">权限管理 - {{ permRole?.roleName }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="savePermission">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto px-4 py-4">
          <div v-if="permMenuLoading" class="flex items-center justify-center py-16">
            <div class="animate-spin w-6 h-6 border-2 border-[#FF4757] border-t-transparent rounded-full" />
          </div>
          <template v-else>
            <div class="flex items-center justify-between mb-4">
              <div class="text-xs text-gray-400">已选 {{ checkedMenuIds.length }} 项</div>
              <button class="text-xs px-3 py-1 rounded-full bg-[#f5f6f8] text-gray-500 active:opacity-70" @click="toggleSelectAll">{{ selectAll ? '取消全选' : '全选' }}</button>
            </div>
            <div class="space-y-1">
              <div
                v-for="item in flatVisibleItems"
                :key="item.id"
                class="flex items-center gap-2.5 py-2.5 px-3 rounded-lg active:bg-gray-50 transition-colors"
                :class="{ 'bg-[#fff5f5]': checkedMenuIds.includes(item.id) }">
                <template v-if="item.hasChildren">
                  <svg class="w-3.5 h-3.5 text-gray-400 transition-transform flex-shrink-0 cursor-pointer"
                    :class="{ 'rotate-90': item._expanded }"
                    @click="toggleTreeNode(item._path)"
                    fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                  <button class="w-4.5 h-4.5 rounded border-1.5 flex-shrink-0 flex items-center justify-center transition-colors ml-1"
                    :class="getNodeCheckState(item) === 'all' ? 'bg-[#FF4757] border-[#FF4757]' : getNodeCheckState(item) === 'part' ? 'bg-[#FF4757]/60 border-[#FF4757]/60' : 'border-[#d1d5db] bg-white shadow-sm'"
                    @click.stop="toggleNodeCascade(item)">
                    <svg v-if="getNodeCheckState(item) !== 'none'" class="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path v-if="getNodeCheckState(item) === 'all'" stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/>
                      <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M20 12H4"/>
                    </svg>
                  </button>
                </template>
                <template v-else>
                  <button class="w-4.5 h-4.5 rounded border-1.5 flex-shrink-0 flex items-center justify-center transition-colors"
                    :class="checkedMenuIds.includes(item.id) ? 'bg-[#FF4757] border-[#FF4757]' : 'border-[#d1d5db] bg-white shadow-sm'"
                    @click="toggleMenuCheck(item.id)">
                    <svg v-if="checkedMenuIds.includes(item.id)" class="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
                  </button>
                </template>
                <div class="flex-1 min-w-0 cursor-pointer" :class="{ 'pl-4': item.depth > 0, 'pl-8': item.depth > 1, 'pl-12': item.depth > 2 }" @click="item.hasChildren ? toggleTreeNode(item._path) : toggleMenuCheck(item.id)">
                  <span class="text-xs" :class="item.isAuth ? 'text-[#FF4757] font-medium' : 'text-gray-600'">{{ item.label }}</span>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="showDeleteConfirm" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40" @click.self="showDeleteConfirm = false">
      <div class="bg-white rounded-2xl shadow-xl w-[300px] p-6">
        <div class="text-center mb-4">
          <svg class="w-12 h-12 mx-auto text-[#dc2626] mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/>
          </svg>
          <p class="text-sm font-semibold text-gray-800">确认删除角色？</p>
          <p class="text-xs text-gray-400 mt-1">确定要删除 "{{ deleteTarget?.roleName }}" 吗？此操作不可恢复。</p>
        </div>
        <div class="flex gap-3">
          <button class="flex-1 py-2.5 text-sm font-medium rounded-xl bg-[#f5f6f8] text-gray-600 active:opacity-70" @click="showDeleteConfirm = false">取消</button>
          <button class="flex-1 py-2.5 text-sm font-medium rounded-xl bg-[#dc2626] text-white active:opacity-80" @click="doDelete">删除</button>
        </div>
      </div>
    </div>

    <!-- Toast 消息 -->
    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-[60] px-5 py-2.5 rounded-full text-sm font-medium shadow-lg" :class="toastType === 'success' ? 'bg-[#ecfdf5] text-[#059669]' : 'bg-[#fef2f2] text-[#dc2626]'">{{ toastMsg }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

interface RoleItem {
  roleId: number
  roleName: string
  roleCode: string
  description: string
  enabled: boolean | number
  createTime: string
}

interface FlatMenuItem {
  id: number
  label: string
  depth: number
  isAuth?: boolean
}

interface MenuRawItem {
  id: number
  parentId: number
  title: string
  name: string
  authList?: { authMark: string; title: string }[] | null
}

const menuNameMap: Record<string, string> = {
  'Dashboard': '仪表盘', 'Console': '控制台',
  'Operation': '运营管理', 'CardKey': '卡密管理', 'Membership': '会员管理',
  'Coupon': '优惠券管理', 'Points': '积分管理', 'ExperienceLevel': '经验等级',
  'Plugins': '插件管理', 'ContentPurchases': '内容购买',
  'MembershipProducts': '会员商品', 'MembershipPurchases': '会员购买',
  'CommunityPostManage': '帖子管理', 'CommunityCommentManage': '评论管理',
  'CommunityReportManage': '举报管理',
  'System': '系统管理', 'User': '用户管理', 'Role': '角色管理',
  'UserCenter': '个人中心', 'Menus': '菜单管理', 'SystemLog': '系统日志',
  'SysConfig': '系统配置', 'DeleteReview': '注销审核', 'RecycleBin': '回收站',
  'Themes': '主题管理', 'FileRepository': '文件仓库', 'FilePolicyManage': '文件策略',
  'Result': '结果页', 'Success': '成功', 'Fail': '失败',
  'Exception': '异常页', 'Exception403': '403', 'Exception404': '404', 'Exception500': '500',
  'AppStore': '应用商店', 'AppStoreList': '应用列表', 'AppStoreDetail': '应用详情',
  'AppCategory': '分类管理', 'AppReports': '举报管理',
  'MySubmissions': '我的投稿', 'SubmissionReview': '投稿审核',
  'SubmissionReviewMobile': '投稿审核(移动端)', 'OfficialTags': '官方标签',
  'SectionManage': '版块管理', 'TitleManage': '称号管理',
  'Verification': '认证管理', 'InviteManage': '邀请码管理',
  'EmailConfig': '邮件配置', 'CustomTask': '自定义任务',
  'CommissionManage': '分佣管理', 'Settlement': '结算管理',
  'CheckinManage': '签到管理',
}

const getMenuLabel = (name: string, title: string): string => {
  return menuNameMap[name] || name
}

const searchKey = ref('')
const expandedCards = ref<Set<number>>(new Set())

const toggleCardActions = (id: number) => {
  if (expandedCards.value.has(id)) {
    expandedCards.value.delete(id)
  } else {
    expandedCards.value.add(id)
  }
  expandedCards.value = new Set(expandedCards.value)
}
const sortField = ref('id')
const sortOrder = ref<'desc' | 'asc'>('desc')
const pageSize = ref(10)
const currentPage = ref(1)
const total = ref(0)
const loading = ref(false)
const list = ref<RoleItem[]>([])

const totalPages = computed(() => Math.ceil(total.value / pageSize.value) || 1)

const pageNumbers = computed(() => {
  const pages: number[] = []
  const t = totalPages.value
  const c = currentPage.value
  let start = Math.max(1, c - 2)
  let end = Math.min(t, c + 2)
  if (end - start < 4) {
    if (start === 1) end = Math.min(t, start + 4)
    else start = Math.max(1, end - 4)
  }
  for (let i = start; i <= end; i++) pages.push(i)
  return pages
})

const formatTime = (s: string) => {
  if (!s) return '-'
  return s.replace('T', ' ').slice(0, 16)
}

const toggleSortOrder = () => {
  sortOrder.value = sortOrder.value === 'desc' ? 'asc' : 'desc'
  handleSearch()
}

const handlePageSizeChange = () => {
  currentPage.value = 1
  fetchList()
}

const goPage = (p: number) => {
  if (p < 1 || p > totalPages.value) return
  currentPage.value = p
  fetchList()
}

const handleSearch = () => {
  currentPage.value = 1
  fetchList()
}

const fetchList = async () => {
  loading.value = true
  try {
    const res: any = await request.get({
      url: '/api/role/list',
      params: { current: currentPage.value, size: pageSize.value }
    })
    let records = res?.records || res?.data?.records || []
    if (searchKey.value.trim()) {
      const kw = searchKey.value.trim().toLowerCase()
      records = records.filter((r: RoleItem) => r.roleName.toLowerCase().includes(kw) || r.roleCode.toLowerCase().includes(kw) || (r.description || '').toLowerCase().includes(kw))
    }
    if (sortField.value === 'createTime') {
      records.sort((a: RoleItem, b: RoleItem) => {
        const va = a.createTime || ''
        const vb = b.createTime || ''
        return sortOrder.value === 'desc' ? vb.localeCompare(va) : va.localeCompare(vb)
      })
    } else {
      if (sortOrder.value === 'desc') records.sort((a: RoleItem, b: RoleItem) => b.roleId - a.roleId)
      else records.sort((a: RoleItem, b: RoleItem) => a.roleId - b.roleId)
    }
    total.value = records.length
    const start = (currentPage.value - 1) * pageSize.value
    list.value = records.slice(start, start + pageSize.value)
  } catch {
    list.value = []
    total.value = 0
  }
  loading.value = false
}

// 新增/编辑表单
const showForm = ref(false)
const formMode = ref<'add' | 'edit'>('add')
const formData = ref({ roleId: 0, roleName: '', roleCode: '', description: '', enabled: true })
const editTargetId = ref<number>(0)

const openAddDialog = () => {
  formMode.value = 'add'
  editTargetId.value = 0
  formData.value = { roleId: 0, roleName: '', roleCode: '', description: '', enabled: true }
  showForm.value = true
}

const openEditDialog = (role: RoleItem) => {
  formMode.value = 'edit'
  editTargetId.value = role.roleId
  formData.value = {
    roleId: role.roleId,
    roleName: role.roleName,
    roleCode: role.roleCode,
    description: role.description || '',
    enabled: !!role.enabled
  }
  showForm.value = true
}

const closeForm = () => {
  showForm.value = false
}

const submitForm = async () => {
  if (!formData.value.roleName.trim()) {
    showToast('请输入角色名称', 'error')
    return
  }
  if (!formData.value.roleCode.trim()) {
    showToast('请输入角色编码', 'error')
    return
  }
  try {
    await request.post({
      url: '/api/role/save',
      data: {
        roleId: formMode.value === 'edit' ? formData.value.roleId : undefined,
        roleName: formData.value.roleName,
        roleCode: formData.value.roleCode,
        description: formData.value.description,
        enabled: formData.value.enabled
      }
    })
    showToast(formMode.value === 'add' ? '新增成功' : '修改成功', 'success')
    closeForm()
    fetchList()
  } catch {
    showToast('保存失败', 'error')
  }
}

// 删除
const showDeleteConfirm = ref(false)
const deleteTarget = ref<RoleItem | null>(null)

const confirmDelete = (role: RoleItem) => {
  deleteTarget.value = role
  showDeleteConfirm.value = true
}

const doDelete = async () => {
  if (!deleteTarget.value) return
  try {
    await request.del({ url: `/api/role/${deleteTarget.value.roleId}` })
    showToast('删除成功', 'success')
    showDeleteConfirm.value = false
    if (list.value.length === 1 && currentPage.value > 1) currentPage.value--
    fetchList()
  } catch {
    showToast('删除失败', 'error')
  }
}

// 权限管理
const showPermission = ref(false)
const permRole = ref<RoleItem | null>(null)
const checkedMenuIds = ref<(number | string)[]>([])
const permMenuLoading = ref(false)

const buildMenuTree = (flatList: MenuRawItem[], parentId: number = 0): any[] => {
  return flatList
    .filter(m => m.parentId === parentId)
    .sort((a, b) => a.id - b.id)
    .map(m => ({
      ...m,
      children: buildMenuTree(flatList, m.id)
    }))
}

interface TreeNode {
  id: number | string
  label: string
  depth: number
  isAuth?: boolean
  hasChildren: boolean
  _expanded: boolean
  _path: string
}

const expandedPaths = ref<Set<string>>(new Set())

const hasCheckedDescendant = (node: any): boolean => {
  if (checkedMenuIds.value.includes(node.id)) return true
  if (node.authList?.length) {
    for (const auth of node.authList) {
      if (checkedMenuIds.value.includes(`auth_${node.id}_${auth.authMark}`)) return true
    }
  }
  if (node.children?.length) {
    for (const child of node.children) {
      if (hasCheckedDescendant(child)) return true
    }
  }
  return false
}

const flatVisibleItems = computed<TreeNode[]>(() => {
  const result: TreeNode[] = []
  const walk = (nodes: any[], depth: number = 0, parentPath: string = '') => {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i]
      const path = parentPath ? `${parentPath}.${i}` : `${i}`
      const children = node.children?.length || 0
      const authCount = node.authList?.length || 0
      const hasKids = children > 0 || authCount > 0
      const isExpanded = expandedPaths.value.has(path) || hasCheckedDescendant(node)

      result.push({
        id: node.id,
        label: getMenuLabel(node.name || '', node.title || ''),
        depth,
        isAuth: false,
        hasChildren: hasKids,
        _expanded: isExpanded,
        _path: path
      })

      if (isExpanded && hasKids) {
        if (node.authList?.length) {
          for (const auth of node.authList) {
            const aid = `auth_${node.id}_${auth.authMark}`
            result.push({
              id: aid,
              label: auth.title,
              depth: depth + 1,
              isAuth: true,
              hasChildren: false,
              _expanded: false,
              _path: ''
            })
          }
        }
        if (children > 0) {
          walk(node.children, depth + 1, path)
        }
      }
    }
  }
  walk(menuTreeData.value)
  return result
})

const menuTreeData = ref<any[]>([])

const toggleTreeNode = (path: string) => {
  if (expandedPaths.value.has(path)) {
    expandedPaths.value.delete(path)
  } else {
    expandedPaths.value.add(path)
  }
  expandedPaths.value = new Set(expandedPaths.value)
}

const getNodeDescendantIds = (node: any): (number | string)[] => {
  const ids: (number | string)[] = [node.id]
  if (node.authList?.length) {
    for (const auth of node.authList) {
      ids.push(`auth_${node.id}_${auth.authMark}`)
    }
  }
  if (node.children?.length) {
    for (const child of node.children) {
      ids.push(...getNodeDescendantIds(child))
    }
  }
  return ids
}

const findTreeNode = (nodes: any[], id: number): any => {
  for (const node of nodes) {
    if (node.id === id) return node
    if (node.children?.length) {
      const found = findTreeNode(node.children, id)
      if (found) return found
    }
  }
  return null
}

const getNodeCheckState = (item: TreeNode): 'all' | 'part' | 'none' => {
  if (!item.hasChildren) return checkedMenuIds.value.includes(item.id) ? 'all' : 'none'
  const node = findTreeNode(menuTreeData.value, item.id as number)
  if (!node) return 'none'
  const allIds = getNodeDescendantIds(node)
  const checked = allIds.filter(id => checkedMenuIds.value.includes(id))
  if (checked.length === 0) return 'none'
  if (checked.length === allIds.length) return 'all'
  return 'part'
}

const toggleNodeCascade = (item: TreeNode) => {
  const node = findTreeNode(menuTreeData.value, item.id as number)
  if (!node) return
  const allIds = getNodeDescendantIds(node)
  const state = getNodeCheckState(item)
  if (state === 'all') {
    checkedMenuIds.value = checkedMenuIds.value.filter(id => !allIds.includes(id))
  } else {
    const toAdd = allIds.filter(id => !checkedMenuIds.value.includes(id))
    checkedMenuIds.value = [...checkedMenuIds.value, ...toAdd]
  }
}

const selectAll = computed(() => {
  const ids = new Set<number | string>()
  const collect = (nodes: any[]) => {
    for (const node of nodes) {
      ids.add(node.id)
      if (node.authList?.length) {
        for (const auth of node.authList) {
          ids.add(`auth_${node.id}_${auth.authMark}`)
        }
      }
      if (node.children?.length) collect(node.children)
    }
  }
  collect(menuTreeData.value)
  if (ids.size === 0) return false
  return checkedMenuIds.value.length >= ids.size
})

const fetchMenuList = async (): Promise<MenuRawItem[]> => {
  try {
    const res: any = await request.get({ url: '/api/menu/list' })
    return Array.isArray(res) ? res : (Array.isArray(res?.records) ? res.records : [])
  } catch {
    return []
  }
}

const openPermissionDialog = async (role: RoleItem) => {
  permRole.value = role
  checkedMenuIds.value = []
  permMenuLoading.value = true
  expandedPaths.value = new Set()
  showPermission.value = true

  try {
    const [menuData, permRes]: [MenuRawItem[], any] = await Promise.all([
      fetchMenuList(),
      request.get({ url: `/api/role/${role.roleId}/permissions` })
    ])
    menuTreeData.value = buildMenuTree(menuData)
    const permData = permRes?.data || permRes || []
    if (Array.isArray(permData)) {
      checkedMenuIds.value = permData.map((p: any) => {
        if (typeof p === 'number') return p
        if (p.authMark === null || p.authMark === undefined) return p.menuId
        return `auth_${p.menuId}_${p.authMark}`
      })
    }
  } catch {
    checkedMenuIds.value = []
  }
  permMenuLoading.value = false
}

const closePermission = () => {
  showPermission.value = false
}

const toggleMenuCheck = (id: number | string) => {
  const idx = checkedMenuIds.value.indexOf(id as any)
  if (idx >= 0) {
    checkedMenuIds.value.splice(idx, 1)
  } else {
    checkedMenuIds.value.push(id as any)
  }
}

const toggleSelectAll = () => {
  if (selectAll.value) {
    checkedMenuIds.value = []
  } else {
    const ids: (number | string)[] = []
    const collect = (nodes: any[]) => {
      for (const node of nodes) {
        ids.push(node.id)
        if (node.authList?.length) {
          for (const auth of node.authList) {
            ids.push(`auth_${node.id}_${auth.authMark}`)
          }
        }
        if (node.children?.length) collect(node.children)
      }
    }
    collect(menuTreeData.value)
    checkedMenuIds.value = ids as any
  }
}

const savePermission = async () => {
  if (!permRole.value) return
  try {
    const permissions = checkedMenuIds.value.map((k: any) => {
      if (typeof k === 'number') return { menuId: k, authMark: null }
      const match = String(k).match(/^auth_(\d+)_(.+)$/)
      if (match) return { menuId: Number(match[1]), authMark: match[2] }
      return null
    }).filter(Boolean)
    await request.post({
      url: `/api/role/${permRole.value.roleId}/permissions`,
      data: { permissions }
    })
    showToast('权限保存成功', 'success')
    closePermission()
  } catch {
    showToast('权限保存失败', 'error')
  }
}

// Toast
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null

const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

onMounted(() => {
  fetchList()
})
</script>
