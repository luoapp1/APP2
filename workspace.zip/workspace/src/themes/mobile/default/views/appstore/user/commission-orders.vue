<template>
  <div class="commission-orders-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">&lt; 返回</button>
      <h2>佣金明细</h2>
    </div>
    <div class="content">
      <div class="order-list" v-if="list.length > 0">
        <div class="order-item" v-for="item in list" :key="item.id">
          <div class="order-left">
            <div class="order-id">订单 #{{ item.id }}</div>
            <div class="order-meta">
              <span class="order-tag" :class="'level-' + item.level">{{ item.level === 1 ? '一级' : item.level === 2 ? '二级' : '--' }}</span>
              <span class="order-status" :class="'status-' + item.status">{{ statusLabel(item.status) }}</span>
              <span class="order-time">{{ formatTime(item.createTime) }}</span>
            </div>
          </div>
          <div class="order-right">
            <div class="order-amount">{{ formatMoney(item.orderAmount) }}</div>
            <div class="order-commission">+{{ formatMoney(item.commission) }}</div>
          </div>
        </div>
      </div>
      <div class="empty" v-if="!loading && list.length === 0">暂无佣金明细</div>
      <div class="loading" v-if="loading">加载中...</div>
      <div class="load-more" v-if="!loading && list.length < total">
        <button class="load-more-btn" :disabled="loadingMore" @click="loadMore">
          {{ loadingMore ? '加载中...' : '加载更多' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const loading = ref(true)
const loadingMore = ref(false)

onMounted(() => {
  fetchData()
})

async function fetchData() {
  try {
    const res = await request.get({ url: `/api/commission/records?page=${page.value}&pageSize=${pageSize}` })
    list.value = res?.list || res || []
    total.value = res?.total || 0
  } catch {
    list.value = []
  }
  loading.value = false
}

async function loadMore() {
  if (loadingMore.value) return
  loadingMore.value = true
  page.value++
  try {
    const res = await request.get({ url: `/api/commission/records?page=${page.value}&pageSize=${pageSize}` })
    const newList = res?.list || res || []
    list.value = [...list.value, ...newList]
    total.value = res?.total || total.value
  } catch {
    page.value--
  }
  loadingMore.value = false
}

function statusLabel(status) {
  const map = {
    pending: '待结算',
    settled: '已结算',
    cancelled: '已取消'
  }
  return map[status] || status || '--'
}

function formatMoney(val) {
  if (val == null) return '--'
  const n = Number(val)
  return n >= 10000 ? `${(n / 10000).toFixed(2)}万` : n.toFixed(2)
}

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
</script>

<style scoped>
.commission-orders-page { min-height: 100vh; background: #f5f5f5; }
.header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; border-bottom: 1px solid #eee; }
.header h2 { margin: 0; font-size: 18px; }
.back-btn { background: none; border: none; color: #2196F3; font-size: 14px; cursor: pointer; }
.content { padding: 16px; }

.order-list { background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.order-item { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid #f8f8f8; }
.order-item:last-child { border-bottom: none; }
.order-left { flex: 1; min-width: 0; }
.order-id { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 4px; }
.order-meta { display: flex; align-items: center; gap: 8px; }
.order-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; font-weight: 500; }
.order-tag.level-1 { background: #fff3e0; color: #FF6B35; }
.order-tag.level-2 { background: #e8f5e9; color: #4CAF50; }
.order-status { font-size: 11px; padding: 1px 6px; border-radius: 4px; }
.order-status.status-pending { background: #fff8e1; color: #f9a825; }
.order-status.status-settled { background: #e8f5e9; color: #4CAF50; }
.order-status.status-cancelled { background: #fce4ec; color: #e53935; }
.order-time { font-size: 11px; color: #bbb; }
.order-right { text-align: right; flex-shrink: 0; margin-left: 12px; }
.order-amount { font-size: 13px; color: #666; margin-bottom: 2px; }
.order-commission { font-size: 14px; font-weight: 600; color: #FF6B35; }

.load-more { text-align: center; padding: 16px 0; }
.load-more-btn { padding: 10px 32px; border: 1px solid #ddd; border-radius: 20px; background: #fff; color: #666; font-size: 13px; cursor: pointer; }
.load-more-btn:disabled { opacity: 0.5; cursor: default; }
.empty { text-align: center; padding: 40px 0; color: #999; font-size: 14px; }
.loading { text-align: center; padding: 40px 0; color: #999; font-size: 14px; }
</style>
