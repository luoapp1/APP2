<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f3f4f6">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">佣金明细</div>
      <div v-if="filterCode" style="font-size:11px;color:#f59e0b;font-family:monospace;padding:2px 8px;background:#fffbeb;border-radius:4px;margin-left:4px">{{ filterCode }}</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">

      <div v-if="loading" style="text-align:center;padding:40px 0;color:#9ca3af;font-size:13px">加载中...</div>

      <div v-else-if="list.length === 0" style="text-align:center;padding:60px 0;color:#9ca3af">
        <div style="font-size:48px;margin-bottom:12px;opacity:0.4">&#128230;</div>
        <div style="font-size:14px">暂无佣金明细</div>
        <div style="font-size:12px;color:#d1d5db;margin-top:4px">邀请好友下单后这里就会有记录了</div>
      </div>

      <div v-else>
        <div v-for="item in list" :key="item.id"
          style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:10px;box-shadow:0 1px 3px rgba(0,0,0,0.04)">

          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <div style="display:flex;align-items:center;gap:8px">
              <span :style="{fontSize:'11px',padding:'2px 8px',borderRadius:'4px',fontWeight:600,color:item.level===1?'#FF6B35':'#4CAF50',background:item.level===1?'#fff3e0':'#e8f5e9'}">
                {{ item.level === 1 ? '一级返佣' : item.level === 2 ? '二级返佣' : '返佣' }}
              </span>
              <span :style="{fontSize:'11px',padding:'2px 8px',borderRadius:'4px',fontWeight:500,color:statusStyle(item.status).color,background:statusStyle(item.status).bg}">
                {{ statusLabel(item.status) }}
              </span>
            </div>
            <div style="text-align:right">
              <div v-if="(item.commission||0) > 0" style="font-size:16px;font-weight:800;color:#FF6B35">+¥{{ formatMoney(item.commission) }}</div>
              <div v-if="(item.pointsCommission||0) > 0" style="font-size:16px;font-weight:800;color:#4CAF50">+{{ item.pointsCommission }}积分</div>
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 16px">
            <div style="font-size:12px;color:#9ca3af">订单编号</div>
            <div style="font-size:12px;color:#9ca3af;text-align:right">订单金额</div>
            <div style="font-size:13px;color:#374151;font-weight:500">#{{ item.orderId || item.id }}</div>
            <div style="font-size:13px;color:#374151;font-weight:500;text-align:right">¥{{ formatMoney(item.orderAmount) }}</div>

            <div style="font-size:12px;color:#9ca3af">订单类型</div>
            <div style="font-size:12px;color:#9ca3af;text-align:right">返佣比例</div>
            <div style="font-size:13px;color:#374151">{{ orderTypeLabel(item.orderType) }}</div>
            <div style="font-size:13px;color:#374151;text-align:right">{{ formatRate(item.rate) }}%</div>

            <div v-if="item.referrerName" style="font-size:12px;color:#9ca3af">推荐人</div>
            <div v-if="item.referrerName" style="font-size:12px;color:#9ca3af;text-align:right">时间</div>
            <div v-if="item.referrerName" style="font-size:13px;color:#374151">{{ item.referrerName }}</div>
            <div v-if="item.referrerName" style="font-size:13px;color:#374151;text-align:right">{{ formatTime(item.createTime) }}</div>

            <div v-if="!item.referrerName" style="font-size:12px;color:#9ca3af">时间</div>
            <div v-if="!item.referrerName" />
            <div v-if="!item.referrerName" style="font-size:13px;color:#374151">{{ formatTime(item.createTime) }}</div>
          </div>
        </div>

        <div v-if="!loading && list.length < total" style="text-align:center;padding:16px 0">
          <button :disabled="loadingMore" @click="loadMore"
            style="padding:10px 40px;border:1px solid #e5e7eb;border-radius:20px;background:#fff;color:#6b7280;font-size:13px;cursor:pointer">
            {{ loadingMore ? '加载中...' : '加载更多' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '@/utils/http'

defineOptions({ name: 'CommissionOrders' })

const route = useRoute()
const filterCode = ref(route.query.code as string || '')

const list = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const loading = ref(true)
const loadingMore = ref(false)
const commission = ref(0)

onMounted(() => fetchData())

function buildUrl(p: number) {
  let url = `/api/commission/records?page=${p}&pageSize=${pageSize}`
  if (filterCode.value) { url += `&code=${encodeURIComponent(filterCode.value)}` }
  return url
}

async function fetchData() {
  try {
    const res: any = await request.get({ url: buildUrl(page.value) })
    const data = res?.list || res || []
    list.value = data.map((r: any) => ({
      id: r.id,
      orderId: r.order_id || r.id,
      orderType: r.order_type || '',
      orderAmount: Number(r.order_amount) || 0,
      commission: Number(r.amount) || 0,
      pointsCommission: Number(r.points_amount) || 0,
      rate: Number(r.rate) || 0,
      level: r.level || 1,
      referrerName: r.referrer_name || '',
      status: r.status || 'pending',
      createTime: r.create_time
    }))
    total.value = res?.total || 0
    commission.value = Number(res?.commission || 0)
  } catch {
    list.value = []
  }
  loading.value = false
}

async function loadMore() {
  if (loadingMore.value) return
  loadingMore.value = true
  page.value++
  try {
    const res: any = await request.get({ url: buildUrl(page.value) })
    const data = res?.list || res || []
    const newList = data.map((r: any) => ({
      id: r.id,
      orderId: r.order_id || r.id,
      orderType: r.order_type || '',
      orderAmount: Number(r.order_amount) || 0,
      commission: Number(r.amount) || 0,
      pointsCommission: Number(r.points_amount) || 0,
      rate: Number(r.rate) || 0,
      level: r.level || 1,
      referrerName: r.referrer_name || '',
      status: r.status || 'pending',
      createTime: r.create_time
    }))
    list.value = [...list.value, ...newList]
    total.value = res?.total || total.value
  } catch {
    page.value--
  }
  loadingMore.value = false
}

function statusLabel(status: string) {
  const map: Record<string, string> = { pending: '待结算', completed: '已结算', settled: '已结算', cancelled: '已取消' }
  return map[status] || status || '--'
}

function statusStyle(status: string) {
  const map: Record<string, { color: string; bg: string }> = {
    completed: { color: '#4CAF50', bg: '#e8f5e9' },
    settled: { color: '#4CAF50', bg: '#e8f5e9' },
    pending: { color: '#f59e0b', bg: '#fffbeb' },
    cancelled: { color: '#ef4444', bg: '#fef2f2' }
  }
  return map[status] || { color: '#9ca3af', bg: '#f3f4f6' }
}

function orderTypeLabel(type: string) {
  const map: Record<string, string> = { app: '应用消费', content: '内容消费', membership: '会员购买', mall: '商城订单' }
  return map[type] || type || '--'
}

function formatRate(val: number) {
  return val != null ? Number(val).toFixed(0) : '0'
}

function formatMoney(val: any) {
  if (val == null) return '0.00'
  const n = Number(val)
  return n >= 10000 ? `${(n / 10000).toFixed(2)}万` : n.toFixed(2)
}

function formatTime(t: any) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
</script>
