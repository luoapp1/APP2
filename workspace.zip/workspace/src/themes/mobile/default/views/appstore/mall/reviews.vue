<template>
  <div class="page">
    <header class="nav-bar">
      <div class="nav-back" @click="$router.back()">
        <svg viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="#666" stroke-width="2" stroke-linecap="round"/></svg>
      </div>
      <span class="nav-title">商品评价 · {{ reviewData.total }}</span>
      <button class="nav-write-btn" v-if="canWriteReview" @click="showEditor = true">写评价</button>
      <div class="nav-placeholder" v-else />
    </header>

    <!-- 综合评分统计区域（左右分栏） -->
    <div class="rating-overview" v-if="!loading">
      <div class="rating-score-left">
        <div class="rating-score-num">{{ avgRating }}</div>
        <div class="rating-score-count">{{ reviewData.total || 0 }}份评分</div>
      </div>
      <div class="rating-distribution">
        <div v-for="star in 5" :key="star" class="dist-row">
          <div class="dist-stars">
            <svg v-for="s in (6-star)" :key="s" class="dist-star-icon" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          </div>
          <div class="dist-bar">
            <div class="dist-bar-inner" :style="{ width: starPercent(6-star) + '%' }" />
          </div>
        </div>
      </div>
    </div>

    <!-- 筛选&排序标签栏 -->
    <div class="filter-bar">
      <div class="filter-tags">
        <span
          v-for="tab in categoryTabs"
          :key="tab.value"
          class="filter-tag"
          :class="{ active: activeCategory === tab.value }"
          @click="activeCategory = tab.value"
        >{{ tab.label }}{{ tab.count }}</span>
      </div>
      <div class="sort-toggle">
        <span class="sort-btn" :class="{ active: sortBy === 'latest' }" @click="sortBy = 'latest'">最新</span>
        <span class="sort-btn" :class="{ active: sortBy === 'hot' }" @click="sortBy = 'hot'">最热</span>
      </div>
    </div>

    <!-- 评价列表 -->
    <main class="review-list" v-if="!loading && filteredReviews.length > 0">
      <div v-for="review in filteredReviews" :key="review.id" class="review-card">
        <div class="review-user-row">
          <div class="review-avatar-wrap">
            <img v-if="review.userAvatar && !isBuiltinAvatar(review.userAvatar)" :src="$fixImgUrl(review.userAvatar)" class="review-avatar-img"  loading="lazy" />
            <div v-else class="review-avatar-placeholder" :style="{ background: avatarColor(review.userName || '?') }">
              <span>{{ (review.userName || '?')[0] }}</span>
            </div>
            <div class="avatar-crown" v-if="review.userExpLevel >= 3">
              <svg viewBox="0 0 16 16" fill="none"><path d="M3 13l1.5-7L8 9l3.5-3L13 13H3z" fill="#FFB800" stroke="#E6A100" stroke-width="0.5"/><circle cx="4.5" cy="5" r="1.2" fill="#FFB800"/><circle cx="11.5" cy="5" r="1.2" fill="#FFB800"/><circle cx="8" cy="3" r="1.2" fill="#FFB800"/></svg>
            </div>
          </div>
          <div class="review-user-info">
            <div class="review-user-name-row">
              <span class="review-user-name">{{ review.userName || '匿名用户' }}</span>
              <svg v-if="review.userVerified" class="verified-icon" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" fill="#1E90FF"/><path d="M5 8l2 2 4-4" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              <span class="user-badge badge-level">Lv.{{ review.userExpLevel }}</span>
              <span class="user-badge badge-member" v-if="review.userMemberLevel">{{ review.userMemberLevel }}</span>
              <span class="user-badge badge-title" v-if="review.userTitleName">{{ review.userTitleName }}</span>
            </div>

            <div class="review-tag-row">
              <span class="review-feel-tag" :class="feelClass(review.rating)">{{ feelLabel(review.rating) }}</span>
              <div class="review-stars">
                <svg v-for="s in 5" :key="s" class="review-star-sm" :class="{ on: s <= (review.rating || 0) }" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
              </div>
              <span class="review-sku-tag" v-if="review.optionName">【{{ review.optionName }}】</span>
            </div>
          </div>
          <div class="review-like-btn" @click="toggleLike(review)">
            <svg viewBox="0 0 24 24" fill="none" :class="{ liked: isLiked(review) }"><path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3m7-2V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <span>{{ review.likeCount || 0 }}</span>
          </div>
        </div>

        <div class="review-content" v-if="review.content">{{ review.content }}</div>

        <div class="review-images" v-if="review.images && review.images.length > 0">
          <img v-for="(img, idx) in review.images" :key="idx" :src="$fixImgUrl(img)" class="review-image" @click="previewImage(review.images, idx)"  loading="lazy" />
        </div>

        <div class="review-reply" v-if="review.reply">
          <div class="review-reply-label">商家回复：</div>
          <div class="review-reply-content">{{ review.reply }}</div>
          <div class="review-reply-time" v-if="review.replyTime">{{ formatTime(review.replyTime) }}</div>
        </div>

        <div class="review-footer">
          <span class="review-time">{{ relativeTime(review.createTime) }}</span>
          <span class="review-location" v-if="review.location">{{ review.location }}</span>
        </div>
      </div>
    </main>

    <div class="empty-state" v-else-if="!loading">
      <svg class="empty-icon" viewBox="0 0 80 80" fill="none">
        <circle cx="40" cy="40" r="36" stroke="#e0e0e0" stroke-width="2" stroke-dasharray="6 4"/>
        <path d="M28 38h24M28 46h16" stroke="#ccc" stroke-width="2" stroke-linecap="round"/>
      </svg>
      <div class="empty-text">{{ activeCategory !== 'all' ? '暂无该类评价' : '暂无评价' }}</div>
    </div>

    <div class="loading" v-if="loading">
      <div class="spinner" />
    </div>

    <!-- 写评价弹出层 -->
    <div class="review-overlay" v-if="showEditor" @click.self="showEditor = false">
      <div class="review-editor">
        <div class="review-editor-header">
          <span class="review-editor-title">写评价</span>
          <svg class="review-editor-close" @click="showEditor = false" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        </div>
        <div class="review-editor-body">
          <div class="review-editor-stars">
            <span class="review-editor-label">评分</span>
            <div class="review-editor-stars-row">
              <svg v-for="s in 5" :key="s" class="review-star-lg" :class="{ on: s <= reviewForm.rating }" @click="reviewForm.rating = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
            </div>
            <span class="review-star-text">{{ reviewForm.rating >= 5 ? '超赞' : reviewForm.rating >= 4 ? '很棒' : reviewForm.rating >= 3 ? '不错' : reviewForm.rating >= 2 ? '一般' : '很差' }}</span>
          </div>
          <div class="review-dim-stars">
            <div class="review-dim-row" v-for="dim in reviewDims" :key="dim.key">
              <span class="review-dim-label">{{ dim.label }}</span>
              <div class="review-dim-stars-row">
                <svg v-for="s in 5" :key="s" class="review-dim-star" :class="{ on: s <= dim.model.value }" @click="dim.model.value = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
              </div>
            </div>
          </div>
          <div class="review-editor-field">
            <textarea v-model="reviewForm.content" class="review-editor-textarea" placeholder="分享你的使用感受吧..." maxlength="500" rows="4" />
            <span class="review-editor-count">{{ reviewForm.content.length }}/500</span>
          </div>
          <div class="review-editor-field">
            <span class="review-editor-label">图片 ({{ reviewForm.images.length }}/3)</span>
            <div class="review-editor-imgs">
              <div v-for="(img, idx) in reviewForm.images" :key="idx" class="review-editor-img-wrap">
                <img :src="img" class="review-editor-img"  loading="lazy" />
                <div class="review-editor-img-del" @click="reviewForm.images.splice(idx, 1)">
                  <svg viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>
                </div>
              </div>
              <div v-if="reviewForm.images.length < 3" class="review-editor-add" @click="triggerUpload">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg>
                <input ref="uploadInput" type="file" accept="image/*" style="display:none" @change="onImgPicked" />
              </div>
            </div>
          </div>
        </div>
        <div class="review-editor-footer">
          <button class="review-editor-submit" @click="submitReview" :disabled="reviewSubmitting || reviewForm.rating === 0">
            {{ reviewSubmitting ? '提交中...' : '提交评价' }}
          </button>
        </div>
      </div>
    </div>

    <footer class="bottom-bar">
      <div class="bottom-bar-left">
        <div class="bottom-icon-btn" @click="$router.push('/')">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>店铺</span>
        </div>
        <div class="bottom-icon-btn" @click="onService">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 18v-6a9 9 0 0118 0v6" stroke="currentColor" stroke-width="1.8"/><path d="M21 19a2 2 0 01-2 2h-1a2 2 0 01-2-2v-3a2 2 0 012-2h3v5zM3 19a2 2 0 002 2h1a2 2 0 002-2v-3a2 2 0 00-2-2H3v5z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>客服</span>
        </div>
      </div>
      <div class="bottom-bar-right">
        <button class="bottom-btn buy-now" @click="buyNow">立即购买</button>
      </div>
    </footer>
  </div>
</template>

<script lang="ts">
import { reactive } from 'vue'

export const reviewLikes = reactive<Record<string, boolean>>({})
</script>

<script setup lang="ts">
import { ref, computed, onMounted, reactive } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()
const productId = computed(() => Number(route.params.id) || Number(route.query.productId) || 0)
const loading = ref(true)
const reviewData = ref<{ list: any[]; total: number }>({ list: [], total: 0 })
const activeCategory = ref<string>('all')
const sortBy = ref<string>('latest')

const showEditor = ref(false)
const reviewSubmitting = ref(false)
const uploadInput = ref<HTMLInputElement | null>(null)
const reviewForm = reactive({ rating: 0, content: '', images: [] as string[], dimProduct: 5, dimService: 5, dimLogistics: 5 })
const reviewDims = [
  { key: 'dimProduct', label: '商品', model: computed({ get: () => reviewForm.dimProduct, set: (v: number) => reviewForm.dimProduct = v }) },
  { key: 'dimService', label: '服务', model: computed({ get: () => reviewForm.dimService, set: (v: number) => reviewForm.dimService = v }) },
  { key: 'dimLogistics', label: '物流', model: computed({ get: () => reviewForm.dimLogistics, set: (v: number) => reviewForm.dimLogistics = v }) }
]

const canWriteReview = ref(false)
const reviewOrderId = ref(0)

const isLiked = (review: any) => !!reviewLikes[String(review.id)]

const categoryTabs = computed(() => {
  const list = reviewData.value.list
  return [
    { label: '全部', value: 'all', count: list.length },
    { label: '有图', value: 'hasImage', count: countByFilter('hasImage') },
    { label: '好评', value: 'good', count: countByFilter('good') },
    { label: '中/差评', value: 'bad', count: countByFilter('bad') }
  ]
})

const countByFilter = (filter: string) => {
  const list = reviewData.value.list
  if (filter === 'hasImage') return list.filter((r: any) => (r.images || []).length > 0).length
  if (filter === 'good') return list.filter((r: any) => (r.rating || 0) >= 4).length
  if (filter === 'bad') return list.filter((r: any) => (r.rating || 0) <= 2).length
  return list.length
}

const filteredReviews = computed(() => {
  let list = [...reviewData.value.list]

  if (activeCategory.value === 'good') list = list.filter((r: any) => (r.rating || 0) >= 4)
  else if (activeCategory.value === 'bad') list = list.filter((r: any) => (r.rating || 0) <= 2)
  else if (activeCategory.value === 'hasImage') list = list.filter((r: any) => (r.images || []).length > 0)

  if (sortBy.value === 'hot') list.sort((a: any, b: any) => {
    const aLike = a.likeCount || 0
    const bLike = b.likeCount || 0
    return bLike - aLike
  })

  return list
})

const avgRating = computed(() => {
  const list = reviewData.value.list
  if (!list.length) return '0.0'
  return (list.reduce((s: number, r: any) => s + (r.rating || 0), 0) / list.length).toFixed(1)
})

const ratingDistribution = computed(() => {
  const dist: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
  reviewData.value.list.forEach((r: any) => {
    const star = Math.round(r.rating || 0)
    if (star >= 1 && star <= 5) dist[star]++
  })
  return dist
})

const starPercent = (star: number) => {
  const max = Math.max(...Object.values(ratingDistribution.value) as number[], 1)
  return Math.round(((ratingDistribution.value[star] || 0) / max) * 100)
}

const feelLabel = (rating: number) => {
  if (rating >= 5) return '很棒'
  if (rating >= 4) return '不错'
  if (rating >= 3) return '一般'
  return '较差'
}

const feelClass = (rating: number) => {
  if (rating >= 4) return 'feel-good'
  if (rating >= 3) return 'feel-neutral'
  return 'feel-bad'
}

const isBuiltinAvatar = (url: string) => !url || url.startsWith('avatar:')
const colorPool = ['#FF6B6B', '#FFA726', '#66BB6A', '#42A5F5', '#AB47BC', '#EF5350', '#26C6DA', '#7E57C2', '#EC407A', '#5C6BC0']
const avatarColor = (name: string) => colorPool[(name || '?').charCodeAt(0) % colorPool.length]

const toggleLike = async (review: any) => {
  const key = String(review.id)
  const liked = !!reviewLikes[key]
  const action = liked ? 'unlike' : 'like'
  try {
    const res: any = await request.put({ url: `/api/mall/reviews/${review.id}/like`, data: { action } })
    review.likeCount = res?.likeCount ?? review.likeCount
    reviewLikes[key] = res?.liked ?? !liked
  } catch { ElMessage.error('操作失败，请重试') }
}

const formatTime = (t: string) => {
  if (!t) return ''
  return t.slice(0, 10).replace(/-/g, '.') + ' ' + t.slice(11, 16)
}

const relativeTime = (t: string) => {
  if (!t) return ''
  const dt = new Date(t)
  if (isNaN(dt.getTime())) return t.slice(0, 10)
  const diff = Date.now() - dt.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)
  const months = Math.floor(days / 30)
  if (months > 0) return `${months}个月前`
  if (days > 0) return `${days}天前`
  if (hours > 0) return `${hours}小时前`
  if (minutes > 0) return `${minutes}分钟前`
  return '刚刚'
}

const previewImage = (images: string[], idx: number) => window.open(images[idx], '_blank')
const buyNow = () => router.push(`/appstore/mall-detail/${productId.value}`)
const onService = () => ElMessage.info('客服功能开发中')

const triggerUpload = () => { uploadInput.value?.click() }

const onImgPicked = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input?.files?.[0]
  if (!file) return
  const fd = new FormData()
  fd.append('file', file)
  try {
    const res: any = await request.post({ url: '/api/upload/file', data: fd })
    const url = res?.url || res?.data?.url || res?.data || ''
    if (url) reviewForm.images.push(url)
  } catch { ElMessage.error('图片上传失败，请重试') }
  input.value = ''
}

const submitReview = async () => {
  if (!reviewForm.rating || reviewSubmitting.value) return
  reviewSubmitting.value = true
  try {
    await request.post({
      url: '/api/mall/reviews',
      data: {
        productId: productId.value,
        rating: reviewForm.rating,
        content: reviewForm.content,
        images: reviewForm.images,
        orderId: reviewOrderId.value,
        dimProductRating: reviewForm.dimProduct,
        dimServiceRating: reviewForm.dimService,
        dimLogisticsRating: reviewForm.dimLogistics
      }
    })
    showEditor.value = false
    reviewForm.rating = 0
    reviewForm.content = ''
    reviewForm.images = []
    reviewForm.dimProduct = 5
    reviewForm.dimService = 5
    reviewForm.dimLogistics = 5
    await loadData()
  } catch { ElMessage.error('提交评价失败，请重试') } finally { reviewSubmitting.value = false }
}

const loadData = async () => {
  if (!productId.value) return
  const res: any = await request.get({ url: '/api/mall/reviews', params: { productId: productId.value, pageSize: 200 } })
  reviewData.value = { list: res?.list || [], total: res?.total || 0 }
  for (const r of reviewData.value.list) {
    reviewLikes[String(r.id)] = !!r.liked
  }
}

const checkReviewPerm = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/reviews/check', params: { productId: productId.value } })
    canWriteReview.value = res?.canReview || false
    reviewOrderId.value = res?.orderId || 0
  } catch { ElMessage.error('获取评价权限失败') }
}

onMounted(async () => {
  if (!productId.value) { loading.value = false; return }
  try {
    await loadData()
    await checkReviewPerm()
  } catch { ElMessage.error('加载评价数据失败') } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.page { min-height: 100vh; background: #fff; display: flex; flex-direction: column; padding-bottom: 62px; }

.nav-bar { position: sticky; top: 0; z-index: 100; display: flex; align-items: center; justify-content: space-between; height: 44px; padding: 0 12px; background: #fff; }
.nav-back { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.nav-back svg { width: 22px; height: 22px; }
.nav-title { font-size: 17px; font-weight: 600; color: #222; flex: 1; text-align: center; }
.nav-placeholder { width: 36px; }
.nav-write-btn { font-size: 13px; color: #FF69B4; background: #FFF0F5; border: none; border-radius: 14px; padding: 4px 14px; cursor: pointer; font-weight: 500; }

.rating-overview { display: flex; align-items: center; gap: 16px; padding: 12px 16px; background: #f0f2f5; border-radius: 12px; margin: 10px 12px; }
.rating-score-left { text-align: center; flex-shrink: 0; min-width: 56px; }
.rating-score-num { font-size: 32px; font-weight: 600; color: #1f2937; line-height: 1; letter-spacing: -1px; }
.rating-score-count { font-size: 11px; color: #9ca3af; margin-top: 2px; }

.rating-distribution { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.dist-row { display: flex; align-items: center; gap: 6px; }
.dist-stars { display: flex; align-items: center; gap: 1px; flex-shrink: 0; }
.dist-star-icon { width: 10px; height: 10px; color: #c4b5fd; }
.dist-bar { flex: 1; height: 4px; background: #d1d5db; border-radius: 2px; overflow: hidden; }
.dist-bar-inner { height: 100%; border-radius: 2px; background: #3D7BEA; transition: width .4s ease; }

.filter-bar { position: sticky; top: 44px; z-index: 99; display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; background: #fff; border-bottom: 1px solid #f5f5f5; }
.filter-tags { display: flex; gap: 6px; flex: 1; }
.filter-tag { font-size: 12px; color: #666; background: #f7f7f7; padding: 4px 12px; border-radius: 12px; cursor: pointer; white-space: nowrap; }
.filter-tag.active { color: #07C160; background: #E8F8EF; font-weight: 500; }

.sort-toggle { display: flex; gap: 0; flex-shrink: 0; margin-left: 8px; }
.sort-btn { font-size: 12px; color: #999; padding: 4px 10px; border-radius: 12px; cursor: pointer; white-space: nowrap; border: 1px solid #e0e0e0; }
.sort-btn:first-child { border-radius: 12px 0 0 12px; border-right: none; }
.sort-btn:last-child { border-radius: 0 12px 12px 0; }
.sort-btn.active { color: #fff; background: #07C160; border-color: #07C160; }

.review-list { flex: 1; }
.review-card { padding: 10px 16px; border-bottom: 6px solid #f5f5f5; }

.review-user-row { display: flex; align-items: flex-start; gap: 10px; }
.review-avatar-wrap { position: relative; flex-shrink: 0; }
.review-avatar-img { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; background: #f0f0f0; }
.review-avatar-placeholder { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 15px; font-weight: 600; }
.avatar-crown { position: absolute; bottom: -4px; left: 50%; transform: translateX(-50%); }
.avatar-crown svg { width: 16px; height: 10px; }

.review-user-info { flex: 1; min-width: 0; }
.review-user-name-row { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.review-user-name { font-size: 14px; color: #333; font-weight: 500; }
.verified-icon { width: 14px; height: 14px; flex-shrink: 0; }
.user-badge { font-size: 10px; padding: 1px 5px; border-radius: 3px; line-height: 1.5; white-space: nowrap; }
.badge-level { color: #FF69B4; background: #FFF0F5; }
.badge-member { color: #FFB800; background: #FFF8E1; }
.badge-title { color: #8B5CF6; background: #F3F0FF; }

.review-like-btn { display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; flex-shrink: 0; padding: 2px 4px; }
.review-like-btn svg { width: 18px; height: 18px; color: #ccc; }
.review-like-btn svg.liked { color: #FF69B4; }
.review-like-btn span { font-size: 10px; color: #999; }

.review-tag-row { display: flex; align-items: center; gap: 4px; margin-top: 0; }
.review-feel-tag { font-size: 11px; padding: 1px 8px; border-radius: 8px; flex-shrink: 0; }
.review-feel-tag.feel-good { color: #FF69B4; background: #FFF0F5; }
.review-feel-tag.feel-neutral { color: #FFB800; background: #FFF8E1; }
.review-feel-tag.feel-bad { color: #999; background: #f5f5f5; }
.review-stars { display: flex; gap: 1px; }
.review-star-sm { width: 13px; height: 13px; color: #e8e8e8; }
.review-star-sm.on { color: #FF69B4; }
.review-sku-tag { font-size: 11px; color: #999; }

.review-content { margin-top: 4px; margin-left: 46px; font-size: 14px; color: #333; line-height: 1.6; word-break: break-word; }

.review-images { display: flex; gap: 6px; margin-top: 4px; margin-left: 46px; flex-wrap: wrap; }
.review-image { width: 80px; height: 80px; border-radius: 4px; object-fit: cover; cursor: pointer; background: #f5f5f5; }

.review-reply { margin-top: 4px; margin-left: 46px; padding: 8px 10px; background: #fafafa; border-radius: 6px; }
.review-reply-label { font-size: 11px; color: #FF69B4; margin-bottom: 3px; }
.review-reply-content { font-size: 13px; color: #666; line-height: 1.5; }
.review-reply-time { font-size: 10px; color: #bbb; margin-top: 3px; }

.review-footer { display: flex; align-items: center; gap: 8px; margin-top: 4px; margin-left: 46px; }
.review-time { font-size: 12px; color: #bbb; }
.review-location { font-size: 12px; color: #bbb; padding-left: 6px; border-left: 1px solid #eee; }

.empty-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 0; }
.empty-icon { width: 60px; height: 60px; margin-bottom: 12px; }
.empty-text { font-size: 14px; color: #bbb; }

.loading { flex: 1; display: flex; align-items: center; justify-content: center; padding: 80px 0; }
.spinner { width: 28px; height: 28px; border: 2px solid #e8e8e8; border-top-color: #FF69B4; border-radius: 50%; animation: spin 0.7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ===== 写评价弹出层 ===== */
.review-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,.55); display: flex; align-items: flex-end; animation: fadeIn .2s ease; }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.review-editor { width: 100%; background: #fff; border-radius: 20px 20px 0 0; padding: 0 16px 32px; animation: slideUp .3s ease; max-height: 85vh; overflow-y: auto; }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.review-editor-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; }
.review-editor-title { font-size: 18px; font-weight: 600; }
.review-editor-close { width: 24px; height: 24px; cursor: pointer; color: #999; }
.review-editor-body { padding-bottom: 12px; }
.review-editor-stars { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
.review-editor-label { font-size: 13px; color: #666; flex-shrink: 0; }
.review-editor-stars-row { display: flex; gap: 5px; }
.review-star-lg { width: 30px; height: 30px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-star-lg.on { color: #FF9500; }
.review-star-lg:active { transform: scale(1.2); }
.review-star-text { font-size: 13px; color: #FF9500; font-weight: 500; }

.review-dim-stars { margin-bottom: 12px; }
.review-dim-row { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
.review-dim-label { font-size: 12px; color: #999; width: 28px; flex-shrink: 0; }
.review-dim-stars-row { display: flex; gap: 3px; }
.review-dim-star { width: 20px; height: 20px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-dim-star.on { color: #FF9500; }
.review-dim-star:active { transform: scale(1.1); }

.review-editor-field { position: relative; margin-bottom: 12px; }
.review-editor-textarea { width: 100%; border: 1px solid #eee; border-radius: 8px; padding: 10px 12px 28px; font-size: 14px; font-family: inherit; resize: none; outline: none; color: #333; }
.review-editor-textarea:focus { border-color: #FF69B4; }
.review-editor-count { position: absolute; bottom: 6px; right: 10px; font-size: 11px; color: #bbb; }
.review-editor-imgs { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
.review-editor-img-wrap { position: relative; width: 70px; height: 70px; border-radius: 6px; overflow: hidden; }
.review-editor-img { width: 100%; height: 100%; object-fit: cover; }
.review-editor-img-del { position: absolute; top: -2px; right: -2px; width: 18px; height: 18px; background: rgba(0,0,0,.5); border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.review-editor-img-del svg { width: 12px; height: 12px; }
.review-editor-add { width: 70px; height: 70px; border: 1px dashed #ddd; border-radius: 6px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.review-editor-add svg { width: 24px; height: 24px; color: #bbb; }
.review-editor-footer { padding: 0 0 24px; }
.review-editor-submit { width: 100%; height: 44px; border-radius: 22px; background: linear-gradient(135deg, #FF69B4, #FF1493); color: #fff; border: none; font-size: 16px; font-weight: 600; cursor: pointer; }
.review-editor-submit:disabled { opacity: 0.5; cursor: not-allowed; }
.review-editor-submit:active { opacity: 0.85; }

.bottom-bar { position: fixed; bottom: 0; left: 0; right: 0; display: flex; align-items: center; height: 56px; padding: 0 8px; background: #fff; border-top: 1px solid #f0f0f0; z-index: 200; }
.bottom-bar-left { display: flex; gap: 0; }
.bottom-icon-btn { display: flex; flex-direction: column; align-items: center; gap: 1px; padding: 2px 6px; cursor: pointer; }
.bottom-icon-btn svg { width: 20px; height: 20px; color: #777; }
.bottom-icon-btn span { font-size: 10px; color: #aaa; }
.bottom-bar-right { display: flex; gap: 6px; margin-left: auto; padding-right: 4px; }
.bottom-btn { height: 36px; padding: 0 16px; border-radius: 18px; font-size: 13px; font-weight: 600; border: none; cursor: pointer; white-space: nowrap; }
.bottom-btn.buy-now { background: linear-gradient(135deg, #FF69B4, #FF1493); color: #fff; }
.bottom-btn:active { opacity: 0.85; }
</style>
