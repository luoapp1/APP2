<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">版主申请审核</span>
    </div>

    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div class="bg-white mx-3 mt-3 rounded-xl px-4 py-3">
        <div class="flex items-center justify-between mb-3">
          <span class="text-sm font-medium text-gray-600">板块筛选</span>
          <button class="sm-btn sm-btn-ghost text-xs" @click="fetchData">刷新</button>
        </div>
        <select v-model="filterSectionId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" @change="fetchData">
          <option value="">全部板块</option>
          <option v-for="s in sections" :key="s.id" :value="s.id">{{ s.name }}</option>
        </select>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div class="flex border-b border-gray-100">
          <button
            v-for="tab in tabs"
            :key="tab.value"
            class="flex-1 h-10 text-sm font-medium transition-colors"
            :class="activeTab === tab.value ? 'text-[#6366F1] border-b-2 border-[#6366F1]' : 'text-gray-400'"
            @click="activeTab = tab.value; fetchData()"
          >{{ tab.label }}</button>
        </div>

        <div v-if="loading" class="flex justify-center py-12">
          <div class="w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full animate-spin" />
        </div>

        <template v-else-if="filteredList.length > 0">
          <div v-for="item in filteredList" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start gap-3">
              <img :src="$fixImgUrl(item.user_avatar) || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Ccircle cx=%2250%22 cy=%2250%22 r=%2250%22 fill=%22%23e5e7eb%22/%3E%3C/svg%3E'" class="w-10 h-10 rounded-full flex-shrink-0"  loading="lazy" />
              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-2 mb-0.5">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.user_name || '-' }}</span>
                  <span class="text-[11px] px-1.5 py-0.5 rounded text-[#6366F1] bg-[#EEF2FF]">{{ item.desired_role || '-' }}</span>
                </div>
                <div class="text-xs text-gray-400 mb-1">{{ item.section_name || '-' }} · {{ (item.create_time || '').slice(0, 16) }}</div>
                <div class="text-sm text-gray-600 leading-relaxed mb-2">{{ item.reason || '无申请理由' }}</div>
                <div class="flex items-center gap-2" v-if="item.status === 'pending'">
                  <button class="sm-btn flex-1 h-8 text-xs rounded-lg font-medium" style="background:#D1FAE5;color:#059669" @click="approveApplication(item)">通过</button>
                  <button class="sm-btn flex-1 h-8 text-xs rounded-lg font-medium" style="background:#FEE2E2;color:#DC2626" @click="openRejectDialog(item)">拒绝</button>
                </div>
                <div v-else class="flex items-center gap-1">
                  <span class="text-[11px] px-1.5 py-0.5 rounded" :class="item.status === 'approved' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'">
                    {{ item.status === 'approved' ? '已通过' : '已拒绝' }}
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ filteredList.length }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <span class="text-sm">暂无申请</span>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <div v-if="rejectVisible" class="fixed inset-0 z-50 flex items-end justify-center" @click.self="rejectVisible = false">
        <div class="absolute inset-0 bg-black/40" @click="rejectVisible = false" />
        <div class="bg-white rounded-t-2xl w-full max-w-lg relative z-10 animate-slide-up" @click.stop>
          <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <button class="text-gray-400" @click="rejectVisible = false">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
            <span class="text-sm font-bold text-gray-800">拒绝申请</span>
            <button class="text-sm font-semibold text-[#EF4444]" @click="doReject">确认</button>
          </div>
          <div class="p-4">
            <label class="text-xs text-gray-500 mb-1 block">拒绝理由（选填）</label>
            <textarea v-model="rejectReason" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" placeholder="请输入拒绝理由..." />
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'ModeratorApplicationsMobile' })

const toastMsg = ref('')
const toastType = ref('success')
let toastTimer = null
const showToast = (m, t = 'success') => {
  toastMsg.value = m
  toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const loading = ref(false)
const applications = ref([])
const sections = ref([])
const filterSectionId = ref('')
const activeTab = ref('pending')
const tabs = [
  { label: '待审核', value: 'pending' },
  { label: '已通过', value: 'approved' },
  { label: '已拒绝', value: 'rejected' }
]

const filteredList = computed(() => {
  return applications.value.filter(item => item.status === activeTab.value)
})

const fetchData = async () => {
  loading.value = true
  try {
    const params = {}
    if (filterSectionId.value) params.section_id = filterSectionId.value
    const res = await request.get({ url: '/api/community/applications', params })
    applications.value = res?.records || res?.data?.records || res?.data || res || []
  } catch (e) {
    console.error('fetchData error:', e)
  }
  loading.value = false
}

const fetchSections = async () => {
  try {
    const res = await request.get({ url: '/api/community/sections' })
    sections.value = res?.records || res?.data?.records || res?.data || res || []
  } catch (e) {
    console.error('fetchSections error:', e)
  }
}

const approveApplication = async (item) => {
  try {
    await request.post({ url: `/api/community/application/${item.id}/approve` })
    showToast('已通过')
    fetchData()
  } catch (e) {
    showToast('操作失败', 'error')
  }
}

const rejectVisible = ref(false)
const rejectTarget = ref(null)
const rejectReason = ref('')

const openRejectDialog = (item) => {
  rejectTarget.value = item
  rejectReason.value = ''
  rejectVisible.value = true
}

const doReject = async () => {
  if (!rejectTarget.value) return
  try {
    await request.post({ url: `/api/community/application/${rejectTarget.value.id}/reject`, data: { reason: rejectReason.value } })
    showToast('已拒绝')
    rejectVisible.value = false
    fetchData()
  } catch (e) {
    showToast('操作失败', 'error')
  }
}

onMounted(() => {
  fetchSections()
  fetchData()
})
</script>

<style scoped>
.animate-slide-up {
  animation: slide-up 0.25s ease-out;
}
@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
</style>
