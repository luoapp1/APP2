<template>
  <template v-if="contentBlocks.length">
    <div v-if="globalLoginBarrier" class="perm-barrier perm-barrier-login">
      <div class="pb-deco">
        <div class="pb-deco-bg"></div>
        <div class="pb-deco-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        </div>
      </div>
      <div class="pb-body">
        <div class="pb-title">请登录后查看</div>
        <div class="pb-sub">
          <p class="pb-hint">登录后即可查看此内容</p>
        </div>
        <div class="pb-actions">
          <button class="pb-btn pb-btn-primary" @click="loginModalStore.open()">立即登录</button>
          <button class="pb-btn pb-btn-secondary" @click="$router.push('/auth/register')">注册账号</button>
        </div>
      </div>
    </div>
    <template v-if="!globalLoginBarrier">
    <template v-for="(block, idx) in contentBlocks" :key="idx">
       <div v-if="!globalLoginBarrier && blockBarrier(idx) && isFirstOfVisibilityGroup(idx)" class="perm-barrier" :class="'perm-barrier-' + effectiveBlockVisibility(idx)">
        <div class="pb-deco">
          <div class="pb-deco-bg"></div>
          <div class="pb-deco-icon">
            <svg v-if="effectiveBlockVisibility(idx)==='paid'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><ellipse cx="12" cy="5" rx="10" ry="3"/><path d="M2 12c0 1.66 4.48 3 10 3s10-1.34 10-3"/><path d="M2 5v14c0 1.66 4.48 3 10 3s10-1.34 10-3V5"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='login'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='comment'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 15c6.67-4 13.33-4 20 0"/><circle cx="12" cy="7" r="4"/><path d="M9 12l2 2 4-4"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='member'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#D48806" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='exp'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#508DFF" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <svg v-else-if="effectiveBlockVisibility(idx)==='title'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
            <svg v-else width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1.2"/></svg>
          </div>
        </div>
        <div class="pb-body">
          <div class="pb-title">{{ blockBarrierText(idx) }}</div>
          <div class="pb-sub" v-if="effectiveBlockVisibility(idx)==='paid'">
            <span class="pb-price-tag">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/><text x="12" y="17" text-anchor="middle" fill="#fff" font-size="12" font-weight="bold">￥</text></svg>
              {{ blockBarrierPrice(idx)?.price || 0 }} {{ blockBarrierPrice(idx)?.type==='points'?'积分':'余额' }}
            </span>
            <p class="pb-sold" v-if="post?.soldCount != null">已售 {{ post.soldCount }}</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='password'">
            <input
              v-model="pwdInput"
              type="password"
              placeholder="请输入访问密码"
              class="pb-pwd-input"
              @keyup.enter="$emit('verify-password', idx)"
            />
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'">
            <p class="pb-hint">{{ levelBarrierDesc(idx) }}</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='login'">
            <p class="pb-hint">登录后即可查看此内容</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='comment'">
            <p class="pb-hint">发表评论后即可解锁</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='follow'">
            <p class="pb-hint">关注作者后即可查看</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='member'">
            <p class="pb-hint" style="color:#D48806">{{ contentBlocks[idx]?.visibilityMemberLevelName }}会员及以上可查看此内容</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='exp'">
            <p class="pb-hint" style="color:#508DFF">经验等级 {{ contentBlocks[idx]?.visibilityExpLevelName }} 及以上可查看此内容</p>
          </div>
          <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='title'">
            <p class="pb-hint" style="color:#7c3aed">需要拥有称号「{{ contentBlocks[idx]?.visibilityTitleName }}」才可查看此内容</p>
          </div>
          <div class="pb-actions">
            <template v-if="effectiveBlockVisibility(idx)==='paid'">
              <button class="pb-btn pb-btn-primary" @click="$emit('pay', idx)">立即购买</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='password'">
              <button class="pb-btn pb-btn-primary" @click="$emit('verify-password', idx)">验证密码</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='login'">
              <button class="pb-btn pb-btn-primary" @click="loginModalStore.open()">立即登录</button>
              <button class="pb-btn pb-btn-secondary" @click="$router.push('/auth/register')">注册账号</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='comment'">
              <button class="pb-btn pb-btn-primary" @click="$emit('open-comment-dialog')">发表评论</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'">
              <button class="pb-btn pb-btn-premium" @click="$router.push('/membership')">开通会员</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='follow'">
              <button class="pb-btn pb-btn-primary" @click="$emit('follow-author')">关注作者</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='member'">
              <button class="pb-btn pb-btn-premium" @click="$router.push('/membership')">开通会员</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='exp'">
              <button class="pb-btn pb-btn-primary" @click="$router.push('/checkin')">提升经验</button>
            </template>
            <template v-else-if="effectiveBlockVisibility(idx)==='title'">
              <button class="pb-btn pb-btn-secondary">暂无此称号</button>
            </template>
          </div>
        </div>
      </div>
      <template v-else-if="!blockBarrier(idx)">
        <div v-if="block.type === 'text' && block.value" class="post-body" v-html="sanitizeContent(block.value)" @click="handlePostBodyClick"></div>
        <div v-else-if="block.type === 'image' && block.images && block.images.length" class="images-grid" :class="gridClassFor(block.images.length)">
          <div v-for="(img, i) in block.images" :key="img" class="image-item" @click="$emit('preview-image', block.images!, i)">
            <img :src="$fixImgUrl(img)" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
          </div>
        </div>
        <div v-else-if="block.type === 'attachment'" class="block-attachment-card" @click="$emit('attach-click', block)">
          <div class="bac-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
          </div>
          <div class="bac-info">
            <div class="bac-title">{{ block.title || '附件' }}</div>
            <div class="bac-desc">{{ block.desc || '' }}</div>
          </div>
          <div class="bac-price">
            <span v-if="isAttachPurchased(block.url)" class="bac-purchased">已购买</span>
            <span v-else-if="block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0" class="bac-free">免费</span>
            <span v-else class="bac-coin">{{ block.coin || 0 }}{{ block.priceType === 'points' ? '积分' : '余额' }}</span>
          </div>
        </div>
        <div v-else-if="block.type === 'link'" class="block-link-card" @click="block.url && window.open(block.url, '_blank')">
          <div class="blc-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
          </div>
          <div class="blc-info">
            <div class="blc-title">{{ block.title || '链接' }}</div>
            <div class="blc-url">{{ block.url || '' }}</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
        </div>
        <div v-else-if="block.type === 'app'" class="block-app-card" @click="block.appId && $router.push('/appstore/browse/detail/' + block.appId)">
          <div class="bac-app-icon" :style="{ background: block.appIcon ? undefined : avatarColor(block.appName || 'a') }">
            <img v-if="block.appIcon" :src="$fixImgUrl(block.appIcon)" class="bac-app-img" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            <span v-else class="bac-app-letter">{{ (block.appName || 'A')[0] }}</span>
          </div>
          <div class="bac-app-info">
            <div class="bac-app-name">{{ block.appName || '应用' }}</div>
            <div class="bac-app-desc">{{ block.desc || '' }}</div>
          </div>
          <div class="bac-app-price">
            <span v-if="!block.coinCount || block.coinCount === 0" class="bac-free">免费</span>
            <span v-else class="bac-coin">{{ block.coinCount }}余额</span>
          </div>
        </div>
      </template>
    </template>
    </template>
  </template>
  <div v-else-if="post?.content && !contentBlocks.length" class="post-body" ref="postBodyRef" @click="handlePostBodyClick">
    <template v-for="(line, li) in fallbackContentLines" :key="li">
      <p>{{ line }}</p>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import type { CommunityPost } from '@/api/community'
import { useLoginModalStore } from '@/store/modules/loginModal'

const loginModalStore = useLoginModalStore()
export interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  extractCode?: string
  priceType?: string
  coin?: number
  coinCount?: number
  appId?: number
  appName?: string
  appIcon?: string
  fileName?: string
  visibility?: string
  visibilityPrice?: number
  visibilityPriceType?: string
  visibilityLevel?: number
  visibilityLevelName?: string
  visibilityPasswordTips?: string
  visibilityMemberLevelId?: number
  visibilityMemberLevelName?: string
  visibilityExpLevel?: number
  visibilityExpLevelName?: string
  visibilityTitleName?: string
  visibilityPassword?: string
  _filtered?: boolean
}

const props = defineProps<{
  post: CommunityPost | null
  contentBlocks: ContentBlock[]
  userHasCommented: boolean
  following: boolean
}>()

defineEmits<{
  'preview-image': [images: string[], idx: number]
  'open-comment-dialog': []
  'follow-author': []
  'pay': [idx: number]
  'verify-password': [idx: number]
  'attach-click': [block: ContentBlock]
}>()

const router = useRouter()
const userStore = useUserStore()
const pwdInput = ref('')

function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }

const globalLoginBarrier = computed(() => {
  if (getUserId()) return false
  if (!props.contentBlocks.length) return false
  return props.contentBlocks.some(b => {
    const vis = b?.visibility || (props.post?.contentPermission as string) || 'public'
    return vis === 'paid' || vis === 'comment' || vis === 'follow' || vis === 'level' || vis === 'level1' || vis === 'level2'
  })
})

function blockVisibility(idx: number): string {
  const block = props.contentBlocks[idx]
  return block?.visibility || (props.post?.contentPermission as string) || 'public'
}

function effectiveBlockVisibility(idx: number): string {
  const vis = blockVisibility(idx)
  if (!getUserId() && (vis === 'paid' || vis === 'comment' || vis === 'follow' || vis === 'level' || vis === 'level1' || vis === 'level2' || vis === 'member' || vis === 'exp')) {
    return 'login'
  }
  return vis
}

function blockBarrier(idx: number): boolean {
  if (!props.post) return false
  const vis = blockVisibility(idx)
  if (!vis || vis === 'public') return false
  const isAuthor = (props.post as any).userId === getUserId()
  if (isAuthor) return false

  if (vis === 'login' && getUserId()) return false
  if (vis === 'comment' && props.userHasCommented) return false
  if (vis === 'follow' && props.following) return false

  const userLevelId = (userStore.info as any)?.levelId || 0
  const userExpLevel = (userStore.info as any)?.expLevel || 0
  const block = props.contentBlocks[idx]
  if (vis === 'level' && block?.visibilityLevel !== undefined && userLevelId >= (block.visibilityLevel || 0)) return false
  if (vis === 'level' && block?.visibilityLevel === undefined && userLevelId >= 1) return false
  if (vis === 'member' && userLevelId >= ((block as any)?.visibilityMemberLevelId || 1)) return false
  if (vis === 'exp' && userExpLevel >= ((block as any)?.visibilityExpLevel || 1)) return false
  if (vis === 'title' && (userStore.info as any)?.titles?.some?.((t: string) => t === block?.visibilityTitleName)) return false

  if (vis === 'level1' && userLevelId >= 1) return false
  if (vis === 'level2' && userLevelId >= 2) return false

  if (!getUserId() && (vis === 'paid' || vis === 'comment' || vis === 'follow' || vis === 'level' || vis === 'level1' || vis === 'level2' || vis === 'member' || vis === 'exp' || vis === 'title')) return true

  return true
}

function isFirstOfVisibilityGroup(idx: number): boolean {
  if (idx === 0) return true
  const prevVis = effectiveBlockVisibility(idx - 1)
  const curVis = effectiveBlockVisibility(idx)
  return prevVis !== curVis
}

function blockBarrierText(idx: number): string {
  const vis = effectiveBlockVisibility(idx)
  const block = props.contentBlocks[idx]
  const map: Record<string, string> = {
    paid: '此内容需要付费后查看',
    password: '此内容需要密码访问' + (block?.visibilityPasswordTips ? ' (提示: ' + block.visibilityPasswordTips + ')' : (props.post?.accessPasswordTips ? ' (提示: ' + props.post.accessPasswordTips + ')' : '')),
    login: '请登录后查看',
    comment: '评论后即可查看内容',
    follow: '关注作者后即可查看内容',
    member: block?.visibilityMemberLevelName ? `${block.visibilityMemberLevelName}会员及以上可查看` : '会员及以上可查看',
    exp: block?.visibilityExpLevelName ? `经验等级 ${block.visibilityExpLevelName} 及以上可查看` : '指定经验等级及以上可查看'
  }
  return map[vis] || '内容受限'
}

function blockBarrierPrice(idx: number): { price: number; type: string } | null {
  const vis = effectiveBlockVisibility(idx)
  const block = props.contentBlocks[idx]
  if (vis === 'paid') {
    return {
      price: block?.visibilityPrice || props.post?.contentPrice || 0,
      type: block?.visibilityPriceType || (props.post?.contentPriceType as string) || 'balance'
    }
  }
  return null
}

function levelBarrierDesc(idx: number): string {
  const vis = effectiveBlockVisibility(idx)
  const block = props.contentBlocks[idx]
  const lv = block?.visibilityLevel ?? 1
  return `开通${lv}级会员即可查看此内容`
}

function isAttachPurchased(url?: string) {
  return false
}

function sanitizeContent(html: string): string {
  if (!html) return ''
  return sanitizeHtml(html)
}

function handlePostBodyClick(e: MouseEvent) {
  const el = (e.target as HTMLElement).closest('a') as HTMLAnchorElement | null
  if (el) {
    const href = el.getAttribute('href') || ''
    const match = href.match(/\/community\/topic\/(\d+)/)
    if (match) {
      e.preventDefault()
      router.push(href)
    }
  }
}

function gridClassFor(n: number) {
  if (n === 1) return 'img-1'
  if (n <= 3) return 'img-3'
  if (n === 4) return 'img-2'
  return 'img-3'
}

const pal = ['#6366F1','#EC4899','#F59E0B','#10B981','#3B82F6','#8B5CF6','#EF4444','#14B8A6','#F97316','#84CC16']
function avatarColor(n: string) { let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h); return pal[Math.abs(h) % pal.length] }

const fallbackContentLines = computed(() => {
  const raw = props.post?.content
  if (!raw) return []
  try {
    const doc = JSON.parse(raw)
    if (doc?.type === 'doc' && doc.content) {
      return doc.content
        .map((n: any) => {
          if (n.type === 'voteCard') return '[投票] ' + (n.attrs?.question || '')
          if (n.type === 'paywall' || n.type === 'memberUnlock' || n.type === 'experienceUnlock') return ''
          return extractTextFromTiptapNode(n)
        })
        .filter(Boolean)
    }
    if (Array.isArray(doc)) {
      return doc.map((b: any) => b.value || '').filter(Boolean)
    }
  } catch {}
  return [raw.substring(0, 500)]
})

function extractTextFromTiptapNode(node: any): string {
  if (!node) return ''
  if (node.type === 'text' && node.text) return node.text
  if (node.type === 'hardBreak') return '\n'
  if (node.content && Array.isArray(node.content)) return node.content.map(extractTextFromTiptapNode).join('')
  return ''
}
</script>

<style scoped>
.post-body { font-size: 15px; color: #222; line-height: 1.75; margin-bottom: 16px; word-break: break-word; padding-left: 8px; }
.post-body :deep(h2) { font-size: 20px; font-weight: 700; line-height: 1.4; margin: .5em 0 .3em; }
.post-body :deep(h3) { font-size: 17px; font-weight: 600; line-height: 1.45; margin: .4em 0 .2em; }
.post-body :deep(strong) { font-weight: 700; }
.post-body :deep(em) { font-style: italic; }
.post-body :deep(u) { text-decoration: underline; }
.post-body :deep(s) { text-decoration: line-through; }
.post-body :deep(blockquote) { border-left: 3px solid #5c7cfa; padding: 6px 0 6px 12px; margin: 8px 0; color: #495057; background: #f8f9fa; border-radius: 0 6px 6px 0; }
.post-body :deep(pre.ql-syntax) { background: #f1f3f5; border-radius: 8px; padding: 10px 12px; font-size: 13px; overflow-x: auto; font-family: 'SF Mono', Monaco, monospace; white-space: pre; }
.post-body :deep(ol), .post-body :deep(ul) { padding-left: 20px; margin: 4px 0; }
.post-body :deep(ol) { list-style-type: decimal; }
.post-body :deep(ul) { list-style-type: disc; }
.post-body :deep(li) { margin: 2px 0; }
.post-body :deep(hr) { border: none; border-top: 1px solid #e9ecef; margin: 10px 0; }
.post-body :deep(p) { margin: 0 0 4px; }
.post-body :deep(.ql-size-12px) { font-size: 12px; }
.post-body :deep(.ql-size-14px) { font-size: 14px; }
.post-body :deep(.ql-size-16px) { font-size: 16px; }
.post-body :deep(.ql-size-18px) { font-size: 18px; }
.post-body :deep(.ql-size-20px) { font-size: 20px; }
.post-body :deep(.ql-size-24px) { font-size: 24px; }
.post-body :deep(.ql-size-28px) { font-size: 28px; }
.post-body :deep(.ql-size-32px) { font-size: 32px; }
.post-body :deep(a[href*="/community/topic"]) { color: #6366f1; font-weight: 700; text-decoration: none; cursor: pointer; border-radius: 4px; padding: 0 2px; transition: background .15s; }
.post-body :deep(a[href*="/community/topic"]:hover) { background: #edf2ff; }

.images-grid { display: grid; gap: 4px; margin-bottom: 14px; }
.images-grid.img-1 { grid-template-columns: 1fr; }
.images-grid.img-2 { grid-template-columns: 1fr 1fr; }
.images-grid.img-3 { grid-template-columns: 1fr 1fr 1fr; }
.image-item { border-radius: 8px; overflow: hidden; aspect-ratio: 1; cursor: pointer; }
.image-item img { width: 100%; height: 100%; object-fit: cover; display: block; }

.block-attachment-card { display: flex; align-items: center; gap: 10px; background: #f7f8fa; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-attachment-card:hover { background: #eef0f4; }
.bac-icon { width: 42px; height: 42px; border-radius: 10px; background: #E8F5E9; color: #43A047; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.bac-info { flex: 1; min-width: 0; }
.bac-title { font-size: 14px; font-weight: 500; color: #333; }
.bac-desc { font-size: 11px; color: #999; margin-top: 2px; }
.bac-price { flex-shrink: 0; }
.bac-free { font-size: 12px; background: #E8F5E9; color: #43A047; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-coin { font-size: 12px; background: #FFF3E0; color: #E65100; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-purchased { font-size: 12px; background: #E3F2FD; color: #1976D2; padding: 3px 10px; border-radius: 10px; font-weight: 500; }

.block-link-card { display: flex; align-items: center; gap: 10px; background: #E8EAF6; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; }
.blc-icon { width: 42px; height: 42px; border-radius: 10px; background: rgba(63,81,181,.15); color: #3F51B5; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.blc-info { flex: 1; min-width: 0; }
.blc-title { font-size: 14px; font-weight: 500; color: #333; }
.blc-url { font-size: 11px; color: #999; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.block-app-card { display: flex; align-items: center; gap: 10px; background: #FFF8E1; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-app-card:hover { background: #FFECB3; }
.bac-app-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.bac-app-img { width: 100%; height: 100%; object-fit: cover; }
.bac-app-letter { text-transform: uppercase; }
.bac-app-info { flex: 1; min-width: 0; }
.bac-app-name { font-size: 14px; font-weight: 600; color: #333; }
.bac-app-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.bac-app-price { flex-shrink: 0; }

.perm-barrier {
  margin: 14px auto;
  border-radius: 12px;
  overflow: hidden;
  background: #f7f8fa;
  box-shadow: 0 2px 4px rgba(0,0,0,.02), 0 4px 10px rgba(0,0,0,.02);
  max-width: 320px;
}
.pb-deco {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 22px 0 0;
}
.pb-deco-bg { display: none; }
.pb-deco-icon {
  width: 38px; height: 38px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.pb-deco-icon svg { width: 20px; height: 20px; }
.pb-body {
  padding: 10px 20px 20px;
  text-align: center;
}
.pb-title {
  font-size: 15px; font-weight: 700;
  color: rgba(0,0,0,.5);
  line-height: 1.3;
  margin-bottom: 0;
}
.pb-sub { margin-top: 6px; margin-bottom: 0; }
.pb-price-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 16px; font-weight: 700;
  color: rgba(0,0,0,.5);
}
.pb-hint {
  font-size: 13px; font-weight: 400;
  color: rgba(0,0,0,.5);
  line-height: 19px;
  margin: 0;
}
.pb-pwd-input {
  width: 100%;
  max-width: 200px;
  height: 36px;
  border: 1px solid rgba(0,0,0,.12);
  border-radius: 8px;
  padding: 0 12px;
  font-size: 13px;
  text-align: center;
  outline: none;
  background: #f9fafb;
  color: rgba(0,0,0,.85);
  transition: border-color .2s;
  box-sizing: border-box;
}
.pb-pwd-input::placeholder { color: rgba(0,0,0,.3); }
.pb-pwd-input:focus { border-color: rgba(0,102,255,.5); }
.pb-actions {
  display: flex;
  gap: 8px;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 14px;
}
.pb-btn {
  height: 36px;
  padding: 0 26px;
  border: none;
  border-radius: 18px;
  font-size: 13px; font-weight: 600;
  cursor: pointer;
  transition: all .15s cubic-bezier(.4,0,.2,1);
  white-space: nowrap;
}
.pb-btn:active { opacity: .85; }
.pb-btn-primary {
  background: linear-gradient(94.87deg, #06f .34%, #0085ff 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(0,102,255,.25), 0 1px 2px 0 rgba(0,102,255,.4);
}
.pb-btn-secondary {
  background: #f3f4f6;
  color: rgba(0,0,0,.85);
  box-shadow: none;
}
.pb-btn-secondary:active { background: #e5e7eb; }
.pb-btn-premium {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

.perm-barrier-paid { margin: 14px auto; border-radius: 14px; }
.perm-barrier-paid .pb-deco { padding-top: 24px; }
.perm-barrier-paid .pb-deco-icon { width: 38px; height: 38px; background: rgba(245,158,11,.08); color: #f59e0b; }
.perm-barrier-paid .pb-deco-icon svg { width: 20px; height: 20px; }
.perm-barrier-paid .pb-body { padding: 10px 20px 20px; }
.perm-barrier-paid .pb-title { font-size: 15px; }
.perm-barrier-paid .pb-sub { margin-top: 6px; }
.perm-barrier-paid .pb-price-tag { font-size: 13px; font-weight: 400; color: rgba(0,0,0,.5); gap: 2px; }
.perm-barrier-paid .pb-sold {
  margin: 4px 0 0;
  font-size: 12px; font-weight: 400;
  color: rgba(0,0,0,.35);
  text-align: center;
}
.perm-barrier-paid .pb-actions { margin-top: 14px; }
.perm-barrier-paid .pb-btn { height: 36px; padding: 0 26px; border-radius: 18px; font-size: 13px; }
.perm-barrier-paid .pb-btn-primary {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

.perm-barrier-login .pb-deco-icon { background: rgba(0,102,255,.08); color: #06f; }
.perm-barrier-comment .pb-deco-icon { background: rgba(16,185,129,.08); color: #10b981; }
.perm-barrier-follow .pb-deco-icon { background: rgba(5,150,105,.08); color: #059669; }
.perm-barrier-level .pb-deco-icon,
.perm-barrier-level1 .pb-deco-icon,
.perm-barrier-level2 .pb-deco-icon { background: rgba(139,92,246,.08); color: #8b5cf6; }
.perm-barrier-password .pb-deco-icon { background: rgba(236,72,153,.08); color: #ec4899; }
.perm-barrier-title .pb-deco-icon { background: rgba(124,58,237,.08); color: #7c3aed; }
.perm-barrier-title .pb-btn-primary { background: linear-gradient(135deg, #7c3aed, #a78bfa); }
</style>
