<template>
  <div class="votes-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">&lt; 返回</button>
      <h2>投票</h2>
      <button class="create-btn" @click="showCreate = true">+ 创建</button>
    </div>
    <div class="vote-list">
      <div class="vote-card" v-for="v in votes" :key="v.id" @click="goVote(v.id)">
        <div class="vote-title">{{ v.title }}</div>
        <div class="vote-meta">
          {{ v.optionCount }}个选项 · {{ v.totalVotes }}票 · {{ v.isActive ? '进行中' : '已结束' }}
          <span v-if="v.deadline" class="deadline-badge" :class="{ 'deadline-expired': isExpired(v.deadline) }">
            {{ deadlineLabel(v.deadline, v.isActive) }}
          </span>
        </div>
        <div class="vote-options">
          <div class="vote-option" v-for="o in (v.options || []).slice(0,3)" :key="o.id">
            <span>{{ o.text }}</span>
            <span class="vote-bar" :style="{ width: v.totalVotes ? (o.count/v.totalVotes*100)+'%' : '0%' }"></span>
          </div>
        </div>
        <div class="vote-deadline" v-if="v.deadline">截止: {{ formatDate(v.deadline) }}</div>
      </div>
      <div class="empty" v-if="votes.length===0">暂无投票</div>
    </div>
    <div class="overlay" v-if="showCreate" @click.self="showCreate=false">
      <div class="create-form">
        <h3>创建投票</h3>
        <input v-model="newTitle" placeholder="投票标题" class="cf-input" />
        <div class="cf-options">
          <div v-for="(opt,i) in newOptions" :key="opt" class="cf-opt-row">
            <input v-model="newOptions[i]" :placeholder="'选项'+(i+1)" class="cf-input" />
            <button v-if="newOptions.length>2" @click="newOptions.splice(i,1)">x</button>
          </div>
        </div>
        <button @click="newOptions.push('')" class="cf-add-btn">+ 添加选项</button>
        <div class="cf-deadline-label">截止时间</div>
        <input v-model="newDeadline" type="datetime-local" class="cf-input" />
        <div class="cf-btns">
          <button @click="submitVote" class="cf-submit">创建</button>
          <button @click="showCreate=false" class="cf-cancel">取消</button>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
const router = useRouter()
const votes = ref([])
const showCreate = ref(false)
const newTitle = ref('')
const newOptions = ref(['', ''])
const newDeadline = ref('')
onMounted(() => loadVotes())
const loadVotes = async () => {
  try { const res = await request.get({ url: '/api/votes' }); votes.value = res?.list || res || [] } catch {}
}
const goVote = (id) => router.push(`/community/vote/${id}`)
const submitVote = async () => {
  try {
    const body = { title: newTitle.value, options: newOptions.value.filter(o => o.trim()) }
    if (newDeadline.value) body.deadline = new Date(newDeadline.value).toISOString()
    await request.post({ url: '/api/votes', data: body })
    showCreate.value = false
    loadVotes()
  } catch (e) { alert(e?.msg || '创建失败') }
}
const formatDate = (d) => new Date(d).toLocaleDateString('zh-CN')
const isExpired = (d) => new Date(d) < new Date()
const deadlineLabel = (d, isActive) => {
  if (!d) return ''
  const now = new Date()
  const deadline = new Date(d)
  const diff = deadline.getTime() - now.getTime()
  if (diff <= 0) return isActive ? '已截止' : ''
  const days = Math.floor(diff / 86400000)
  const hours = Math.floor((diff % 86400000) / 3600000)
  if (days > 0) return `剩余 ${days}天 ${hours}小时`
  const mins = Math.floor((diff % 3600000) / 60000)
  if (hours > 0) return `剩余 ${hours}小时 ${mins}分钟`
  return `剩余 ${mins}分钟`
}
</script>
<style scoped>
.votes-page { min-height:100vh;background:#f5f5f5 }
.header { display:flex;align-items:center;gap:12px;padding:12px 16px;background:#fff }
.header h2 { margin:0;font-size:18px;flex:1 }
.back-btn { background:none;border:none;color:#2196F3;font-size:14px;cursor:pointer }
.create-btn { background:#2196F3;color:#fff;border:none;padding:6px 14px;border-radius:6px;font-size:13px }
.vote-list { padding:12px }
.vote-card { background:#fff;border-radius:12px;padding:14px;margin-bottom:10px;cursor:pointer }
.vote-title { font-size:14px;font-weight:600;color:#333;margin-bottom:6px }
.vote-meta { font-size:12px;color:#999;margin-bottom:8px }
.vote-options { margin:8px 0 }
.vote-option { display:flex;align-items:center;gap:8px;margin:4px 0;font-size:12px;color:#666 }
.vote-bar { height:6px;background:#E3F2FD;border-radius:3px;min-width:2px }
.vote-deadline { font-size:11px;color:#f44336;margin-top:4px }
.deadline-badge {
  display: inline-block;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
  background: #e8f5e9;
  color: #2e7d32;
  margin-left: 6px;
  vertical-align: middle;
}
.deadline-badge.deadline-expired {
  background: #ffebee;
  color: #c62828;
}
.cf-deadline-label {
  font-size: 13px;
  color: #666;
  margin-top: 6px;
  margin-bottom: 2px;
}
.overlay { position:fixed;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:flex-end;z-index:100 }
.create-form { background:#fff;width:100%;border-radius:16px 16px 0 0;padding:20px }
.cf-input { width:100%;padding:8px 12px;border:1px solid #ddd;border-radius:8px;margin:6px 0;font-size:14px }
.cf-options { margin:8px 0 }
.cf-opt-row { display:flex;align-items:center;gap:4px }
.cf-opt-row button { background:#f44336;color:#fff;border:none;border-radius:4px;padding:2px 8px;cursor:pointer }
.cf-add-btn { background:#f0f0f0;border:none;padding:6px 12px;border-radius:6px;font-size:13px;cursor:pointer;margin:4px 0 }
.cf-btns { display:flex;gap:8px;margin-top:12px }
.cf-submit { flex:1;background:#2196F3;color:#fff;border:none;padding:10px;border-radius:8px;font-size:14px }
.cf-cancel { flex:1;background:#f0f0f0;border:none;padding:10px;border-radius:8px;font-size:14px }
.empty { text-align:center;padding:60px 0;color:#999 }
</style>
