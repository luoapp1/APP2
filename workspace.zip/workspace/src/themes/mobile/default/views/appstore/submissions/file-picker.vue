<template>
  <div class="up-page">
    <div class="up-header">
      <div class="up-back" @click="goBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <div class="up-title">上传安装包</div>
    </div>

    <div class="up-body">
      <label class="up-dropzone" @click="triggerFileInput">
        <svg class="up-drop-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#3DDC84" stroke-width="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        <span class="up-drop-title">点击选择 .apk 文件</span>
        <span class="up-drop-sub">支持最大 200MB</span>
      </label>
      <input ref="fileInput" type="file" accept=".apk,application/vnd.android.package-archive" class="up-file-input" @change="onFileChange" />

      <div v-if="parsing" class="up-parsing">
        <div class="up-spinner" />
        <span>解析中...</span>
      </div>

      <div v-if="parseError" class="up-err">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span>{{ parseError }}</span>
      </div>

      <div v-if="quotaError" class="up-quota-warn">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span>{{ quotaError }}</span>
      </div>

      <div v-if="apkInfo" class="up-card">
        <div class="up-card-icon" :style="{ background: iconBg }">
          <img v-if="showIconImg" :src="apkInfo.iconBase64" class="up-card-icon-img"  loading="lazy" />
          <span v-else class="up-card-icon-letter">{{ firstLetter }}</span>
        </div>
        <div class="up-card-body">
          <div class="up-card-name">{{ appName }}</div>
          <div class="up-card-pkg">{{ apkInfo.packageName }}</div>
          <div class="up-card-meta">
            <span v-if="apkInfo.version">v{{ apkInfo.version }}</span>
            <span>{{ apkInfo.sizeMb }} MB</span>
          </div>
        </div>
        <div class="up-reselect" @click="triggerFileInput">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
        </div>
      </div>
    </div>

    <div class="up-bottom">
      <button class="up-btn" :disabled="!apkInfo || parsing || uploading" @click="confirmUpload">
        {{ uploading ? '上传中...' : (apkInfo ? '下一步' : '请选择 .apk 文件') }}
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import JSZip from 'jszip'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'
import { colorPool } from '@/utils/ui'

const router = useRouter()

interface ApkInfo {
  fileName: string
  packageName: string
  version: string
  versionCode: string
  sizeMb: string
  iconBase64: string
  downloadUrl: string
}

const apkInfo = ref<ApkInfo | null>(null)
const parsing = ref(false)
const parseError = ref('')
const quotaError = ref('')
const uploading = ref(false)
const fileInput = ref<HTMLInputElement | null>(null)
const selectedFile = ref<File | null>(null)
const quotaLoading = ref(false)
const storageQuota = ref<{ totalFileLimitMb: number, usedBytes: number } | null>(null)

const appName = computed(() => {
  const f = selectedFile.value
  if (!f) return '未知应用'
  return f.name.replace(/\.apk$/i, '').replace(/[_-]v?\d[\d.]*/i, '').replace(/[_-]/g, ' ')
})

const firstLetter = computed(() => appName.value.charAt(0).toUpperCase())

const iconBg = computed(() => {
  const name = appName.value
  const hash = name.split('').reduce((s: number, c: string) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
})

const showIconImg = computed(() => !!(apkInfo.value && apkInfo.value.iconBase64))

async function loadQuota() {
  try {
    quotaLoading.value = true
    const res: any = await request.get({ url: '/api/upload/storage-quota', showErrorMessage: false })
    if (res) {
      storageQuota.value = { totalFileLimitMb: res.totalFileLimitMb, usedBytes: res.usedBytes }
    }
  } catch { storageQuota.value = null } finally { quotaLoading.value = false }
}

loadQuota()

function goBack() {
  if (window.history.length > 1) router.back()
  else router.push('/appstore/submissions')
}

function triggerFileInput() {
  parseError.value = ''
  quotaError.value = ''
  fileInput.value?.click()
}

function guessPackageName(files: string[], fileName: string): string {
  const manifest = files.find(f => /AndroidManifest\.xml$/i.test(f))
  if (!manifest) return fileName.replace(/\.apk$/i, '')
  const parts = manifest.replace(/\/AndroidManifest\.xml$/i, '')
    .split('/')
    .filter(p => p && !p.startsWith('res') && !p.startsWith('META-INF') && p !== 'original')
  if (parts.length >= 3) {
    if (parts[0] === 'unknown' || parts[0] === 'sources') return parts.slice(-2).join('.')
    return parts.slice(0, 3).join('.')
  }
  if (parts.length === 2) return parts.join('.')
  return fileName.replace(/\.apk$/i, '')
}

async function extractVersion(zip: JSZip, files: string[]): Promise<{ versionName: string; versionCode: string }> {
  try {
    const mf = files.find(f => /AndroidManifest\.xml$/i.test(f))
    if (!mf) return { versionName: '', versionCode: '' }
    const xmlFile = zip.file(mf.replace(/^\//, ''))
    if (!xmlFile) return { versionName: '', versionCode: '' }
    const raw = await xmlFile.async('uint8array')
    const text = new TextDecoder('utf-8', { fatal: false }).decode(raw)
    const vnMatch = text.match(/versionName[=&"']{1,3}([^"&']+)/i)
    const vcMatch = text.match(/versionCode[=&"']{1,3}(\d+)/i)
    return { versionName: vnMatch?.[1] || '', versionCode: vcMatch?.[1] || '' }
  } catch {
    return { versionName: '', versionCode: '' }
  }
}

async function extractIcon(zip: JSZip): Promise<string> {
  const iconPatterns = ['ic_launcher', 'ic_launcher_round', 'icon', 'logo']
  const candidates: { path: string; width: number; height: number }[] = []
  const iconDirRegex = /^res\/(mipmap|drawable)-/i

  for (const [name] of Object.entries(zip.files)) {
    if (!name.endsWith('.png') && !name.endsWith('.webp')) continue
    if (!iconDirRegex.test(name)) continue
    const baseName = name.split('/').pop()?.replace(/\.(png|webp)$/i, '').toLowerCase() || ''
    const match = iconPatterns.some(pat => baseName.includes(pat))
    if (!match) continue
    const dimMatch = name.match(/(\d+)x(\d+)/)
    let w = dimMatch ? parseInt(dimMatch[1]) : 0
    let h = dimMatch ? parseInt(dimMatch[2]) : 0
    if (!w) {
      const densityMatch = name.match(/mipmap-([a-z]+)/i)
      if (densityMatch) {
        const densities: Record<string, number> = { 'xxxhdpi': 192, 'xxhdpi': 144, 'xhdpi': 96, 'hdpi': 72, 'mdpi': 48, 'ldpi': 36 }
        const sz = densities[densityMatch[1].toLowerCase()] || 48
        w = sz; h = sz
      }
    }
    candidates.push({ path: name, width: w, height: h })
  }

  let best = candidates[0]
  for (const c of candidates) {
    const bestPixels = (best?.width || 0) * (best?.height || 0)
    const cPixels = c.width * c.height
    if (cPixels > bestPixels) best = c
  }

  if (!best) return ''

  try {
    const iconFile = zip.file(best.path)
    if (!iconFile) return ''
    const data = await iconFile.async('uint8array')
    const ext = best.path.endsWith('.png') ? 'png' : 'webp'
    const mime = ext === 'png' ? 'image/png' : 'image/webp'
    let binary = ''
    for (let i = 0; i < data.length; i++) {
      binary += String.fromCharCode(data[i])
    }
    return `data:${mime};base64,${btoa(binary)}`
  } catch {
    return ''
  }
}

function checkFileQuota(fileSize: number): string | null {
  if (!storageQuota.value || !storageQuota.value.totalFileLimitMb) return null
  const limitBytes = storageQuota.value.totalFileLimitMb * 1024 * 1024
  const afterUpload = (storageQuota.value.usedBytes || 0) + fileSize
  if (afterUpload > limitBytes) {
    const usedMb = ((storageQuota.value.usedBytes || 0) / (1024 * 1024)).toFixed(1)
    return `存储空间不足，已用 ${usedMb}MB/${storageQuota.value.totalFileLimitMb}MB`
  }
  return null
}

async function onFileChange() {
  const files = fileInput.value?.files
  if (!files || files.length === 0) return

  const file = files[0]
  selectedFile.value = file
  parsing.value = true
  parseError.value = ''
  quotaError.value = ''
  apkInfo.value = null

  const quotaMsg = checkFileQuota(file.size)
  if (quotaMsg) {
    quotaError.value = quotaMsg
  }

  try {
    const buffer = await file.arrayBuffer()
    const zip = await JSZip.loadAsync(buffer)
    const allFiles = Object.keys(zip.files)
    const pkg = guessPackageName(allFiles, file.name)
    const ver = await extractVersion(zip, allFiles)
    const iconBase64 = await extractIcon(zip)

    apkInfo.value = {
      fileName: file.name,
      packageName: pkg,
      version: ver.versionName,
      versionCode: ver.versionCode,
      sizeMb: (file.size / (1024 * 1024)).toFixed(1),
      iconBase64,
      downloadUrl: ''
    }
  } catch (err: any) {
    parseError.value = err?.message || '文件解析失败'
    ElMessage.error('解析失败: ' + (err?.message || '无效的 APK 文件'))
  } finally {
    parsing.value = false
    if (fileInput.value) fileInput.value.value = ''
  }
}

async function confirmUpload() {
  if (!apkInfo.value || !selectedFile.value) return
  uploading.value = true

  try {
    const fd = new FormData()
    fd.append('file', selectedFile.value)
    const res: any = await request.post({ url: '/api/upload/apk', data: fd, timeout: 300000, showErrorMessage: false })
    const url = res?.downloadUrl || ''
    const icon = res?.icon || apkInfo.value.iconBase64

    router.push({
      path: '/appstore/submissions/edit',
      query: {
        fileName: apkInfo.value.fileName,
        packageName: apkInfo.value.packageName,
        sizeMb: apkInfo.value.sizeMb,
        version: apkInfo.value.version,
        versionCode: apkInfo.value.versionCode,
        icon: icon,
        downloadUrl: url,
        name: ''
      }
    })
  } catch (err: any) {
    ElMessage.error('上传失败: ' + (err?.message || '请重试'))
  } finally {
    uploading.value = false
  }
}
</script>

<style lang="scss" scoped>
.up-page { min-height: 100vh; background: #f5f6fa; display: flex; flex-direction: column; padding-bottom: 80px; }
.up-header { display: flex; align-items: center; padding: 48px 16px 14px; background: #fff; gap: 12px; }
.up-back { cursor: pointer; flex-shrink: 0; }
.up-title { font-size: 17px; font-weight: 600; color: #1a1a1a; }
.up-body { flex: 1; padding: 20px 16px; display: flex; flex-direction: column; }
.up-dropzone { display: flex; flex-direction: column; align-items: center; justify-content: center; background: #fff; border-radius: 16px; border: 2px dashed #e0e0e0; cursor: pointer; gap: 12px; padding: 60px 20px; margin-bottom: 12px; }
.up-dropzone:hover { border-color: #3DDC84; }
.up-file-input { display: none; }
.up-drop-icon { opacity: .6; }
.up-drop-title { font-size: 16px; font-weight: 600; color: #333; }
.up-drop-sub { font-size: 13px; color: #999; }
.up-card { background: #fff; border-radius: 16px; padding: 20px; display: flex; align-items: center; gap: 14px; position: relative; }
.up-card-icon { width: 56px; height: 56px; border-radius: 14px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; overflow: hidden; }
.up-card-icon-letter { color: #fff; font-size: 28px; font-weight: 700; }
.up-card-icon-img { width: 100%; height: 100%; object-fit: cover; }
.up-card-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 4px; }
.up-card-name { font-size: 16px; font-weight: 700; color: #111; }
.up-card-pkg { font-size: 12px; color: #999; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.up-card-meta { display: flex; gap: 10px; font-size: 12px; color: #666; }
.up-reselect { position: absolute; top: 12px; right: 12px; width: 32px; height: 32px; border-radius: 50%; background: #f5f5f5; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.up-reselect:hover { background: #eee; }
.up-parsing { display: flex; align-items: center; justify-content: center; gap: 10px; padding: 24px; color: #999; font-size: 14px; }
.up-spinner { width: 18px; height: 18px; border: 2px solid #e0e0e0; border-top-color: #3DDC84; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.up-err { background: #fff; border-radius: 12px; padding: 16px 20px; display: flex; align-items: center; gap: 10px; color: #EF4444; font-size: 14px; }
.up-quota-warn { background: #fff; border-radius: 12px; padding: 16px 20px; display: flex; align-items: center; gap: 10px; color: #F59E0B; font-size: 13px; margin-bottom: 12px; }
.up-bottom { padding: 16px; background: #fff; border-top: 1px solid #f0f0f0; }
.up-btn { width: 100%; padding: 14px; border: none; border-radius: 12px; background: #3DDC84; color: #fff; font-size: 16px; font-weight: 600; cursor: pointer; }
.up-btn:disabled { background: #e0e0e0; color: #bbb; cursor: not-allowed; }
</style>
