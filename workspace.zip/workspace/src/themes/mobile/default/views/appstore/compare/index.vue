<template>
  <div class="app-compare-page art-full-height p-4">
    <div class="flex items-center gap-3 mb-6">
      <el-button link @click="$router.push('/appstore/list')">
        <i class="ri-arrow-left-line mr-1" /> 返回列表
      </el-button>
      <h3 class="text-base font-bold">应用对比</h3>
    </div>

    <div v-if="compareList.length === 0" class="text-center py-20">
      <el-empty description="请从应用列表中选择最多3个应用进行对比">
        <el-button type="primary" @click="$router.push('/appstore/list')">去选择应用</el-button>
      </el-empty>
    </div>

    <div v-else v-loading="loading">
      <div class="overflow-x-auto">
        <table class="compare-table w-full border-collapse">
          <thead>
            <tr>
              <th class="w-[120px] text-left p-3 bg-gray-50">对比项</th>
              <th v-for="app in compareList" :key="app.id" class="p-3 text-center bg-gray-50 min-w-[200px]">
                <div class="flex flex-col items-center gap-2">
                  <div
                    class="flex items-center justify-center rounded-xl text-white font-bold"
                    :style="{ width: '48px', height: '48px', background: app.iconBgColor || '#00BFA5' }"
                  >
                    <img v-if="app.icon" :src="$fixImgUrl(app.icon)" class="w-full h-full object-cover rounded-xl"  loading="lazy" />
                    <i v-else class="ri-apps-2-line text-xl" />
                  </div>
                  <span class="font-bold text-sm">{{ app.name }}</span>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-3 font-medium bg-gray-50">评分</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <el-rate v-model="app.rating" disabled size="small" />
                <span class="text-xs text-gray-500 ml-1">{{ app.rating }}</span>
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">下载量</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ formatNumber(app.downloads || 0) }}
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">大小</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ app.sizeMb }} MB
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">版本</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ app.version }}
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">收费</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <span v-if="app.priceType === 'free' || !app.priceType" class="text-green-500">免费</span>
                <span v-else>{{ app.priceType === 'balance' ? '¥' : '' }}{{ app.priceAmount }}{{ app.priceType === 'points' ? '积分' : '' }}</span>
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">分类</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ app.category }}
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">开发者</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ app.developer || '-' }}
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">投币数</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                {{ app.coinCount || 0 }} ({{ app.coinPeople || 0 }}人)
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">标签</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <el-tag v-for="tag in (app.tags || [])" :key="tag" size="small" class="mr-1">{{ tag }}</el-tag>
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">广告</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <el-tag :type="app.hasAds ? 'warning' : 'success'" size="small">{{ app.hasAds ? '含广告' : '无广告' }}</el-tag>
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">付费内容</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <el-tag :type="app.hasPaidContent ? 'warning' : 'success'" size="small">{{ app.hasPaidContent ? '有' : '无' }}</el-tag>
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">描述</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center text-sm text-gray-600">
                {{ app.description || '-' }}
              </td>
            </tr>
            <tr>
              <td class="p-3 font-medium bg-gray-50">操作</td>
              <td v-for="app in compareList" :key="app.id" class="p-3 text-center">
                <el-button size="small" type="primary" @click="$router.push(`/appstore/detail/${app.id}`)">查看详情</el-button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const loading = ref(false)
const compareList = ref<any[]>([])

function formatNumber(n: number) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return String(n)
}

onMounted(async () => {
  const ids = route.query.ids as string
  if (!ids) return

  const idList = ids.split(',').filter(Boolean).slice(0, 3)
  if (idList.length === 0) return

  loading.value = true
  try {
    const results = await Promise.all(
      idList.map(id =>
        fetch(`/api/app/${id}/detail`).then(r => r.json())
      )
    )
    compareList.value = results
      .filter(r => r.code === 200)
      .map(r => r.data.app)
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
})
</script>
