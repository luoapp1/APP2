<template>
  <div class="mf-page">
    <div class="mf-nav">
      <button class="mf-nav-back" @click="viewMode === 'groups' ? $router.back() : backToGroups()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="mf-nav-title">{{ activeTab === 'mall' && viewMode === 'groups' ? '商城收藏' : (viewMode === 'groups' ? '我的收藏' : groupTitle) }}</span>
      <button v-if="viewMode === 'groups' && activeTab !== 'mall'" class="mf-nav-add" @click="openCreateGroup">新建分组</button>
      <div v-else style="width: 52px;"></div>
    </div>

    <!-- Tab 切换 -->
    <div v-if="viewMode === 'groups'" class="mf-tabs">
      <button class="mf-tab" :class="{ active: activeTab === 'posts' }" @click="activeTab = 'posts'">帖子</button>
      <button class="mf-tab" :class="{ active: activeTab === 'apps' }" @click="activeTab = 'apps'">应用</button>
      <button class="mf-tab" :class="{ active: activeTab === 'mall' }" @click="activeTab = 'mall'">商城</button>
    </div>

    <!-- ==================== 分组列表 / 商城商品 ==================== -->
    <div v-if="viewMode === 'groups'" class="mf-groups">
      <!-- 商城 Tab：直接展示商品列表 -->
      <template v-if="activeTab === 'mall'">
        <div v-if="loading" class="mf-empty">加载中...</div>
        <div v-else-if="items.length === 0" class="mf-empty" style="padding: 80px 0;">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="display:block;margin:0 auto 12px auto;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          <div style="font-size: 14px; color: #999;">暂无收藏商品</div>
        </div>
        <div v-else class="mf-items" style="padding-top: 8px;">
          <div
            v-for="c in items"
            :key="c.id"
            class="bg-white mx-3 mb-2 rounded-xl px-3 py-3 cursor-pointer active:bg-[#FAFAFA] transition-colors flex items-center gap-3"
            @click="openItem(c)"
          >
            <div class="w-[56px] h-[56px] rounded-xl flex-shrink-0 overflow-hidden bg-[#f5f5f5] flex items-center justify-center">
              <img v-if="c.coverImage" :src="c.coverImage" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
              <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
            </div>
            <div class="flex-1 min-w-0">
              <div class="text-[14px] font-semibold text-[#111] truncate">{{ c.name }}</div>
              <div class="flex items-center gap-2 mt-1">
                <span class="text-[15px] font-bold text-[#FF5722]">
                  <template v-if="c.priceType === 'free' || c.price === 0">免费</template>
                  <template v-else>{{ c.priceType === 'points' ? c.price + '积分' : '￥' + c.price }}</template>
                </span>
              </div>
              <div class="text-[11px] text-[#999] mt-0.5">已售 {{ c.salesCount || 0 }}</div>
            </div>
            <button @click.stop="removeItem(c)" class="text-[11px] px-3 py-1 border border-[#E5E7EB] rounded-md text-[#F56C6C] bg-white flex-shrink-0">取消</button>
          </div>
        </div>
      </template>
      <!-- 帖子/应用 Tab：展示分组 -->
      <template v-else>
      <div v-if="loading" class="mf-empty">加载中...</div>
      <template v-else>
        <div v-if="groups.length === 0" class="mf-empty">还没有收藏分组</div>
        <div class="mf-group-list">
          <div
            v-for="g in groups"
            :key="g.id"
            class="mf-folder-row"
            @click="enterGroup(g)"
          >
            <div class="mf-folder-icon">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="#EC4899" stroke="#EC4899" stroke-width="1" stroke-linejoin="round">
                <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
              </svg>
            </div>
            <div class="mf-folder-info">
              <div class="mf-folder-name">{{ g.name }}</div>
              <div class="mf-folder-meta">
                <span>{{ g.count || 0 }}项</span>
                <span v-if="Number(g.follower_count)"> &middot; {{ g.follower_count }}关注</span>
                <span style="color: #1890ff;" v-if="Number(g.is_public)"> &middot; 公开</span>
                <span style="color: #999;" v-else> &middot; 私密</span>
              </div>
            </div>
            <div class="mf-folder-actions">
              <button
                class="mf-visibility-btn"
                :class="{ public: Number(g.is_public) }"
                @click.stop="toggleVisibility(g)"
                :title="Number(g.is_public) ? '点击设为私密' : '点击设为公开'"
              >
                <svg v-if="Number(g.is_public)" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10"/><path d="M12 2a15.3 15.3 0 00-4 10 15.3 15.3 0 004 10"/></svg>
                <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              </button>
              <button class="mf-folder-edit-btn" @click.stop="openRenameGroup(g)" title="改名">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </div>
        </div>
      </template>
      </template>
    </div>

    <!-- ==================== 分组内列表 ==================== -->
    <div v-else class="mf-items">
      <!-- 顶部统计条 -->
      <div class="mf-items-header" v-if="activeGroup">
        <span class="mf-items-count">共 {{ items.length }} 项收藏</span>
        <span class="mf-items-visibility" v-if="Number(activeGroup.is_public)">公开</span>
        <span class="mf-items-visibility priv" v-else>私密</span>
      </div>

      <div v-if="itemsLoading" class="mf-empty">加载中...</div>
      <template v-else>
        <div v-if="items.length === 0" class="mf-empty" style="padding: 80px 0;">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="display:block;margin:0 auto 12px auto;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          <div style="font-size: 14px; color: #999;">该分组下暂无收藏</div>
        </div>

        <!-- ==================== 帖子/合集列表 ==================== -->
        <template v-if="activeTab === 'posts'">
        <TransitionGroup name="list" tag="div">
        <div
          v-for="c in items"
          :key="c.fav_id"
          class="bg-white mx-3 mb-2 rounded-xl px-3 pt-2.5 pb-2.5 cursor-pointer active:bg-[#FAFAFA] transition-colors"
          @click="openItem(c)"
        >

          <!-- Author Row -->
          <div class="flex items-center gap-2">
            <div class="w-[28px] h-[28px] rounded-full overflow-hidden flex-shrink-0 bg-[#F0F0F0] flex items-center justify-center">
              <img v-if="c.user_avatar" :src="c.user_avatar" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
              <svg v-else width="14" height="14" viewBox="0 0 24 24" fill="#bbb"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v1.2c0 .7.5 1.2 1.2 1.2h16.8c.7 0 1.2-.5 1.2-1.2v-1.2c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1">
                <span class="text-[13px] text-[#111] font-semibold truncate">{{ c.user_name || '匿名用户' }}</span>
                <span class="text-[10px] px-[6px] py-[1px] rounded font-medium flex-shrink-0" :class="c.item_type === 'post' ? 'bg-[#E8F4FD] text-[#1890FF]' : 'bg-[#FCE7F3] text-[#EC4899]'">
                  {{ c.item_type === 'post' ? '帖子' : '合集' }}
                </span>
              </div>
            </div>
          </div>

          <!-- Title -->
          <div class="mt-2 text-[16px] text-[#111] font-bold leading-[1.45] line-clamp-2">
            {{ c.title }}
          </div>

          <!-- Content / Cover Image for collections -->
          <div v-if="c.item_type === 'collection'" class="mt-2 bg-gradient-to-br from-[#fdf2f8] to-white rounded-xl p-3 flex items-center gap-3">
            <div class="w-[60px] h-[60px] rounded-lg overflow-hidden flex-shrink-0 bg-[#f0f0f5] flex items-center justify-center">
              <img v-if="c.cover_image" :src="c.cover_image" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
              <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            </div>
            <div class="flex-1 min-w-0">
              <div class="text-[12px] text-[#666] line-clamp-2">{{ c.description || '暂无描述' }}</div>
              <div class="text-[11px] text-[#999] mt-1">{{ c.post_count || 0 }}篇内容</div>
            </div>
          </div>

          <!-- Content Preview for posts -->
          <div v-else class="mt-2">
            <!-- Lock card: 付费解锁 -->
            <div v-if="c._previewCard?.type === 'paywall' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#FFF7ED] via-white to-white rounded-2xl p-4 shadow-md border border-[#FED7AA] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                付费阅读
              </div>
              <div v-if="(c.soldCount || 0) > 0" class="absolute top-2.5 right-3 bg-[#22C55E] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">已售 {{ c.soldCount }}</div>
              <div class="flex items-center gap-2 mt-2 mb-4">
                <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#F97316]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                </div>
                <span class="text-[13px] text-[#555] font-medium">该帖子部分内容已隐藏</span>
              </div>
              <div class="text-center mb-4">
                <div class="inline-flex items-baseline gap-0.5">
                  <span v-if="c._previewCard.priceType !== 'points'" class="text-[18px] font-bold text-[#F97316] self-start mt-1">￥</span>
                  <span class="text-[40px] font-black text-[#F97316] leading-none tracking-tight">{{ c._previewCard.price || 0 }}</span>
                  <span v-if="c._previewCard.priceType === 'points'" class="text-[13px] font-bold text-[#F97316] self-end mb-1">积分</span>
                </div>
                <div class="text-[11px] text-[#999] mt-0.5">付费后可查看完整内容</div>
              </div>
              <div @click.stop="openItem(c)" class="bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-orange-200/50">立即购买</div>
            </div>

            <!-- Lock card: 会员专属 -->
            <div v-else-if="c._previewCard?.type === 'memberUnlock' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#FFFDF5] via-white to-white rounded-2xl p-4 shadow-md border border-[#FDE68A] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#D48806] to-[#F59E0B] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 15c6.67-4 13.33-4 20 0"/><circle cx="12" cy="7" r="4"/></svg>
                会员专属
              </div>
              <div class="flex items-center gap-2 mt-2 mb-4">
                <div class="w-8 h-8 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                </div>
                <span class="text-[13px] text-[#555] font-medium">该帖子内容仅 {{ c._previewCard.levelName }} 会员可见</span>
              </div>
              <div class="bg-[#FEFCE8] rounded-xl px-3.5 py-2.5 mb-3 flex items-center gap-2">
                <svg class="w-4 h-4 text-[#D48806] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                <span class="text-[11px] text-[#92400E]">开通会员享受专属内容与更多权益</span>
              </div>
              <div @click.stop="$router.push('/membership')" class="bg-gradient-to-r from-[#D48806] to-[#F59E0B] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-amber-200/50">开通会员</div>
            </div>

            <!-- Lock card: 经验等级 -->
            <div v-else-if="c._previewCard?.type === 'experienceUnlock' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#F0F7FF] via-white to-white rounded-2xl p-4 shadow-md border border-[#BFDBFE] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                等级限制
              </div>
              <div class="flex items-center gap-2 mt-2 mb-4">
                <div class="w-8 h-8 rounded-full bg-[#DBEAFE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#3B82F6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <span class="text-[13px] text-[#555] font-medium">需经验等级 {{ c._previewCard.levelName }} 及以上</span>
              </div>
              <div class="bg-[#EFF6FF] rounded-xl px-3.5 py-2.5 mb-3 flex items-center gap-2">
                <svg class="w-4 h-4 text-[#3B82F6] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                <span class="text-[11px] text-[#1E40AF]">每日签到和发帖可获得经验值</span>
              </div>
              <div @click.stop="$router.push('/checkin')" class="bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-blue-200/50">提升经验</div>
            </div>

            <!-- Lock card: 登录可见 -->
            <div v-else-if="c._previewCard?.type === 'login' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#F4F7FF] via-white to-[#FAFBFF] rounded-2xl p-5 shadow-md border border-[#C7D2FE] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#6366F1] to-[#818CF8] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="7" r="4"/><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/></svg>
                登录可见
              </div>
              <div class="flex flex-col items-center text-center mt-1 mb-4">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center mb-3 shadow-lg shadow-indigo-200/40">
                  <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                </div>
                <span class="text-[14px] text-[#374151] font-semibold">该帖子内容已隐藏</span>
                <span class="text-[12px] text-[#9CA3AF] mt-1">登录后即可查看完整内容</span>
              </div>
              <div @click.stop="$router.push('/auth/login')" class="bg-gradient-to-r from-[#6366F1] to-[#818CF8] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-indigo-300/40">立即登录</div>
            </div>

            <!-- Lock card: 评论解锁 -->
            <div v-else-if="c._previewCard?.type === 'commentUnlock' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#F0FDF4] via-white to-white rounded-2xl p-4 shadow-md border border-[#A7F3D0] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#22C55E] to-[#4ADE80] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                评论解锁
              </div>
              <div class="flex items-center gap-2 mt-2 mb-3">
                <div class="w-8 h-8 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#22C55E]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                </div>
                <span class="text-[13px] text-[#555] font-medium">该帖子内容已隐藏，请评论后查看</span>
              </div>
              <div class="flex items-center gap-3 mb-4"><span class="flex-1 h-px bg-[#D1FAE5]"></span><span class="text-[11px] text-[#888] flex-shrink-0">留下评论即可解锁</span><span class="flex-1 h-px bg-[#D1FAE5]"></span></div>
              <div @click.stop="openItem(c)" class="bg-gradient-to-r from-[#22C55E] to-[#4ADE80] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-green-200/50 flex items-center justify-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                去评论
              </div>
            </div>

            <!-- Lock card: 称号解锁 -->
            <div v-else-if="c._previewCard?.type === 'titleUnlock' && !c.hasPurchased" class="relative bg-gradient-to-br from-[#F5F3FF] via-white to-white rounded-2xl p-4 shadow-md border border-[#DDD6FE] overflow-hidden">
              <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777z"/><circle cx="12" cy="12" r="3"/><path d="M22 12A10 10 0 1112 2"/></svg>
                称号解锁
              </div>
              <div class="flex items-center gap-2 mt-2 mb-3">
                <div class="w-8 h-8 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                  <svg class="w-4 h-4 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                </div>
                <span class="text-[13px] text-[#555] font-medium">需拥有称号「{{ c._previewCard.titleName }}」才可查看</span>
              </div>
              <div class="flex items-center gap-3 mb-4"><span class="flex-1 h-px bg-[#DDD6FE]"></span><span class="text-[11px] text-[#888] flex-shrink-0">称号限定内容</span><span class="flex-1 h-px bg-[#DDD6FE]"></span></div>
              <div @click.stop="openItem(c)" class="bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-violet-200/50 flex items-center justify-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777z"/></svg>
                查看详情
              </div>
            </div>

            <!-- Content cards: always show regardless of purchase -->
            <!-- App card -->
            <div v-else-if="c._previewCard?.type === 'app'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#F0F9FF] to-[#FAFEFF] rounded-xl p-3.5 border border-[#BAE6FD] shadow-sm">
              <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] flex items-center justify-center flex-shrink-0 shadow-sm">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4" stroke-linecap="round"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-[13px] font-semibold text-[#0C4A6E] truncate">{{ c._previewCard.name || '应用' }}</div>
                <div class="text-[11px] text-[#38BDF8] mt-0.5">点击查看详情</div>
              </div>
              <div class="w-6 h-6 rounded-full bg-[#E0F2FE] flex items-center justify-center flex-shrink-0">
                <svg class="w-3.5 h-3.5 text-[#0EA5E9]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
            </div>
            <!-- Goods card -->
            <div v-else-if="c._previewCard?.type === 'goods'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#FFFBE6] to-[#FFFEF5] rounded-xl p-3.5 border border-[#FDE68A] shadow-sm">
              <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#D48806] to-[#F59E0B] flex items-center justify-center flex-shrink-0 overflow-hidden shadow-sm">
                <img v-if="c._previewCard.image" :src="c._previewCard.image" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                <svg v-else class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-[13px] font-semibold text-[#92400E] truncate">{{ c._previewCard.name || '商品' }}</div>
                <div class="text-[12px] text-[#D48806] font-bold mt-0.5">{{ c._previewCard.price ? (typeof c._previewCard.price === 'number' ? '￥' + c._previewCard.price : c._previewCard.price) : '' }}</div>
              </div>
              <div class="w-6 h-6 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                <svg class="w-3.5 h-3.5 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
            </div>
            <!-- Vote card -->
            <div v-else-if="c._previewCard?.type === 'vote'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#F5F3FF] to-[#FDFBFF] rounded-xl p-3.5 border border-[#DDD6FE] shadow-sm">
              <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#A78BFA] flex items-center justify-center flex-shrink-0 shadow-sm">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-[13px] font-semibold text-[#5B21B6] truncate">{{ c._previewCard.question || '投票' }}</div>
                <div class="text-[11px] text-[#A78BFA] mt-0.5">点击参与投票</div>
              </div>
              <div class="w-6 h-6 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                <svg class="w-3.5 h-3.5 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
            </div>
            <!-- PostRef card -->
            <div v-else-if="c._previewCard?.type === 'postRef'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#ECFDF5] to-[#F6FFFA] rounded-xl p-3.5 border border-[#A7F3D0] shadow-sm">
              <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#059669] to-[#34D399] flex items-center justify-center flex-shrink-0 shadow-sm">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-[13px] font-semibold text-[#064E3B] truncate">{{ c._previewCard.title || '引用帖子' }}</div>
                <div class="text-[11px] text-[#34D399] mt-0.5">{{ c._previewCard.sectionName || '查看原帖' }}</div>
              </div>
              <div class="w-6 h-6 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                <svg class="w-3.5 h-3.5 text-[#059669]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </div>
            </div>

            <!-- Normal text content -->
            <div v-else-if="c.content && !['app','goods','vote','postRef'].includes(c._previewCard?.type)" class="text-[13px] text-[#555] leading-[1.55] line-clamp-2" v-html="stripContentRich(c.content)"></div>

            <!-- Post Images -->
            <div v-if="parsedImages(c).length === 1 && (!c._previewCard || c._previewCard?.type === 'app' || c._previewCard?.type === 'goods' || c._previewCard?.type === 'vote' || c._previewCard?.type === 'postRef' || c.hasPurchased)" class="mt-2 rounded-xl overflow-hidden" style="max-height:180px">
              <img :src="parsedImages(c)[0]" class="w-full object-cover" style="max-height:180px" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div v-else-if="parsedImages(c).length === 2 && (!c._previewCard || c._previewCard?.type === 'app' || c._previewCard?.type === 'goods' || c._previewCard?.type === 'vote' || c._previewCard?.type === 'postRef' || c.hasPurchased)" class="mt-2 grid grid-cols-2 gap-1.5 rounded-xl overflow-hidden">
              <img v-for="(img, idx) in parsedImages(c)" :key="img" :src="img" class="w-full object-cover aspect-square" style="max-height:140px" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div v-else-if="parsedImages(c).length >= 3 && (!c._previewCard || c._previewCard?.type === 'app' || c._previewCard?.type === 'goods' || c._previewCard?.type === 'vote' || c._previewCard?.type === 'postRef' || c.hasPurchased)" class="mt-2 grid grid-cols-3 gap-1.5 rounded-xl overflow-hidden">
              <img v-for="(img, idx) in parsedImages(c).slice(0,3)" :key="img" :src="img" class="w-full object-cover aspect-square" style="max-height:120px" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
          </div>

          <!-- Stats bar -->
          <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-[#F5F5F5]">
            <span v-if="c.section_name" class="text-[11px] text-[#999]">{{ c.section_name }}</span>
            <span v-else class="text-[11px] text-[#999]"></span>
            <div class="flex items-center gap-3 text-[12px] text-[#B0B0B0]">
              <span v-if="c.item_type === 'post'" class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                {{ fmtCount(c.like_count || 0) }}
              </span>
              <span v-else class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                {{ c.post_count || 0 }}篇
              </span>
              <span class="inline-flex items-center gap-0.5">
                <svg v-if="c.item_type === 'post'" class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                <svg v-else class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
                {{ fmtCount(c.item_type === 'post' ? (c.comment_count || 0) : (c.subscribe_count || 0)) }}
              </span>
              <span class="inline-flex items-center gap-0.5">
                <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ fmtCount(c.view_count || 0) }}
              </span>
              <span class="text-[11px] text-[#B0B0B0] ml-1">{{ formatTime(c.fav_time) }}</span>
            </div>
            <!-- Action buttons -->
            <div class="flex gap-2 mt-2" style="justify-content: flex-end;">
              <button @click.stop="openMoveDialog(c)" class="text-[11px] px-3 py-1 border border-[#E5E7EB] rounded-md text-[#6366F1] bg-white">移动</button>
              <button @click.stop="removeItem(c)" class="text-[11px] px-3 py-1 border border-[#E5E7EB] rounded-md text-[#F56C6C] bg-white">取消收藏</button>
            </div>
          </div>
        </div>
      </TransitionGroup>
      </template>

        <!-- ==================== 应用列表 ==================== -->
        <template v-else-if="activeTab === 'apps'">
        <div
          v-for="c in items"
          :key="c.id"
          class="bg-white mx-3 mb-2 rounded-xl px-3 py-3 cursor-pointer active:bg-[#FAFAFA] transition-colors flex items-center gap-3"
          @click="openItem(c)"
        >
          <div class="w-[48px] h-[48px] rounded-xl flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: c.icon_bg_color || '#EC4899' }">
            <img v-if="c.icon" :src="c.icon" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            <svg v-else width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4" stroke-linecap="round"/></svg>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[14px] font-semibold text-[#111] truncate">{{ c.app_name }}</div>
            <div class="flex items-center gap-2 mt-0.5">
              <span class="text-[11px] text-[#999]">{{ c.category || '工具' }}</span>
              <span class="text-[11px] text-[#bbb]">v{{ c.version || '1.0' }}</span>
              <span v-if="c.size_mb" class="text-[11px] text-[#bbb]">{{ c.size_mb }}MB</span>
            </div>
            <div class="flex items-center gap-3 mt-1.5 text-[11px] text-[#999]">
              <span>{{ fmtCount(c.downloads || 0) }}下载</span>
              <span v-if="c.rating">★ {{ c.rating }}</span>
            </div>
          </div>
          <!-- Action buttons -->
          <div class="flex flex-col gap-1.5 flex-shrink-0">
            <button @click.stop="openMoveDialog(c)" class="text-[10px] px-2.5 py-1 border border-[#E5E7EB] rounded-md text-[#6366F1] bg-white">移动</button>
            <button @click.stop="removeItem(c)" class="text-[10px] px-2.5 py-1 border border-[#E5E7EB] rounded-md text-[#F56C6C] bg-white">取消</button>
          </div>
        </div>
        </template>

        <!-- ==================== 商城商品列表 ==================== -->
        <template v-else-if="activeTab === 'mall'">
        <div
          v-for="c in items"
          :key="c.id"
          class="bg-white mx-3 mb-2 rounded-xl px-3 py-3 cursor-pointer active:bg-[#FAFAFA] transition-colors flex items-center gap-3"
          @click="openItem(c)"
        >
          <div class="w-[56px] h-[56px] rounded-xl flex-shrink-0 overflow-hidden bg-[#f5f5f5] flex items-center justify-center">
            <img v-if="c.coverImage" :src="c.coverImage" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
            <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[14px] font-semibold text-[#111] truncate">{{ c.name }}</div>
            <div class="flex items-center gap-2 mt-1">
              <span class="text-[15px] font-bold text-[#FF5722]">
                <template v-if="c.priceType === 'free' || c.price === 0">免费</template>
                <template v-else>{{ c.priceType === 'points' ? c.price + '积分' : '￥' + c.price }}</template>
              </span>
              <span v-if="c.priceType !== 'free' && c.price > 0 && c.originalPrice && c.originalPrice > c.price" class="text-[11px] text-[#bbb] line-through">￥{{ c.originalPrice }}</span>
            </div>
            <div class="text-[11px] text-[#999] mt-0.5">已售 {{ c.salesCount || 0 }}</div>
          </div>
          <button @click.stop="removeItem(c)" class="text-[11px] px-3 py-1 border border-[#E5E7EB] rounded-md text-[#F56C6C] bg-white flex-shrink-0">取消</button>
        </div>
        </template>
      </template>
    </div>

    <!-- ==================== 移动到分组弹窗（列表） ==================== -->
    <div v-if="showMoveDialog" class="mf-dialog-mask" @click.self="showMoveDialog = false">
      <div class="mf-dialog" style="min-width:280px">
        <div class="mf-dialog-title">移动到分组</div>
        <div class="mf-move-list">
          <div
            v-for="g in moveTargetGroups"
            :key="g.id"
            class="mf-move-row"
            @click="selectMoveTarget(g)"
          >
            <svg class="w-5 h-5" style="color:#EC4899" fill="currentColor" viewBox="0 0 24 24"><path d="M21 20a2 2 0 01-2 2H5a2 2 0 01-2-2V9c0-1.1.9-2 2-2h5l2-2h7a2 2 0 012 2v13zM8 15l3-3m0 0l3 3m-3-3v8"/></svg>
            <span class="mf-move-name">{{ g.name }}</span>
            <span class="mf-move-count">{{ g.count || 0 }}项</span>
          </div>
          <div v-if="moveTargetGroups.length === 0" class="mf-move-empty">暂无其他分组</div>
        </div>
        <div class="mf-dialog-btns">
          <button class="mf-dialog-btn cancel" @click="showMoveDialog = false">取消</button>
        </div>
      </div>
    </div>

    <!-- ==================== 通用弹窗 ==================== -->
    <div v-if="showDialog" class="mf-dialog-mask" @click.self="showDialog = false">
      <div class="mf-dialog">
        <div class="mf-dialog-title">{{ dialogTitle }}</div>
        <input
          ref="dialogInput"
          v-model="dialogValue"
          placeholder="请输入分组名称"
          class="mf-dialog-input"
          @keyup.enter="confirmDialog"
        />
        <div v-if="dialogShowSwitch" class="mf-dialog-switch" @click="dialogIsPublic = !dialogIsPublic">
          <span class="mf-dialog-switch-label">{{ dialogIsPublic ? '公开' : '私密' }}</span>
          <div class="mf-dialog-switch-track" :class="{ on: dialogIsPublic }">
            <div class="mf-dialog-switch-thumb"></div>
          </div>
        </div>
        <div class="mf-dialog-btns">
          <button class="mf-dialog-btn cancel" @click="showDialog = false">取消</button>
          <button class="mf-dialog-btn confirm" @click="confirmDialog">确定</button>
        </div>
      </div>
        </div>
      </div>
      </template>

<script setup lang="ts">
import { ref, onMounted, nextTick, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { stripContentRich } from '@/utils'

const router = useRouter()
const userStore = useUserStore()
const currentUserId = computed(() => userStore.info?.userId || 0)

const viewMode = ref<'groups' | 'items'>('groups')
const activeTab = ref<'posts' | 'apps' | 'mall'>('posts')
const groupTitle = ref('')
const activeGroupId = ref(0)
const groups = ref<any[]>([])
const items = ref<any[]>([])
const loading = ref(true)
const itemsLoading = ref(false)

const activeGroup = computed(() => groups.value.find(g => g.id === activeGroupId.value) || null)

const showDialog = ref(false)
const dialogTitle = ref('')
const dialogValue = ref('')
const dialogInput = ref<HTMLInputElement | null>(null)
const dialogShowSwitch = ref(false)
const dialogIsPublic = ref(false)
let dialogCallback: ((v: string) => void) | null = null

const showMoveDialog = ref(false)
const movingItem = ref<any>(null)

const moveTargetGroups = computed(() => groups.value.filter(g => g.id !== activeGroupId.value))

watch(activeTab, () => {
  if (viewMode.value === 'groups') {
    if (activeTab.value === 'mall') loadMallItems()
    else loadGroups()
  }
})

watch(showDialog, (v) => { if (!v) dialogShowSwitch.value = false })

async function loadGroups() {
  loading.value = true
  try {
    const request = (await import('@/utils/http')).default
    const uid = userStore.info?.userId
    let res
    if (activeTab.value === 'apps') {
      res = await request.get({ url: `/api/app-favorite/groups?userId=${uid}` })
    } else {
      res = await request.get({ url: '/api/community/favorite/groups' })
    }
    groups.value = res || []
  } catch { groups.value = [] }
  loading.value = false
}

async function loadMallItems() {
  loading.value = true
  groups.value = []
  try {
    const request = (await import('@/utils/http')).default
    const res: any = await request.get({ url: '/api/mall/favorites' })
    items.value = (res || []).map((f: any) => ({
      ...f,
      id: f.id,
      fav_id: f.id,
      item_type: 'mall'
    }))
  } catch { items.value = [] }
  loading.value = false
}

async function loadItems(groupId: number) {
  itemsLoading.value = true
  try {
    const request = (await import('@/utils/http')).default
    const url = `/api/community/favorite/items?groupId=${groupId}&pageSize=50`
    const res: any = await request.get({ url })
    const raw = res?.list || []
    for (const item of raw) {
      if (item.item_type === 'post' && item.content) {
        let previewCard = null
        try {
          const safe = String(item.content).replace(/\\\\\"/g, '\\"')
          const doc = JSON.parse(safe)
          if (doc?.type === 'doc' && doc.content) {
            for (const node of doc.content) {
              if (node.type === 'paywall') { if (item.hasPurchased) continue; previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }; break }
              if (node.type === 'memberUnlock') { if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue; previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }; break }
              if (node.type === 'experienceUnlock') { const uExp2 = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0); if (uExp2 >= (node.attrs?.level || 0)) continue; previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }; break }
              if (node.type === 'commentUnlock') { if (item.hasCommented) continue; previewCard = { type: 'commentUnlock' }; break }
              if (node.type === 'titleUnlock') { if (item.viewerTitleIds && item.viewerTitleIds.includes(node.attrs?.titleId)) continue; previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }; break }
            }
            if (!previewCard && item.contentPermission === 'login') {
              previewCard = { type: 'login' }
            }
            // Author can see their own paywalled content — nullify lock card
            if (previewCard && currentUserId.value && item.user_id === currentUserId.value) {
              previewCard = null
            }
            // Content cards (app/goods/vote/postRef) are always shown
            if (!previewCard) {
              for (const node of doc.content) {
                if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
                if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
                if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
                if (node.type === 'paragraph' && node.content) {
                  for (const child of node.content) {
                    if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                      const txt = child.text || ''
                      const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                      if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                    }
                  }
                }
                if (previewCard) break
              }
            }
          }
        } catch {}
        item._previewCard = previewCard
      }
    }
    items.value = raw
  } catch { items.value = [] }
  itemsLoading.value = false
}

async function loadAppItems(groupId: number) {
  itemsLoading.value = true
  try {
    const request = (await import('@/utils/http')).default
    const uid = userStore.info?.userId
    const res: any = await request.get({ url: `/api/app-favorite/list?groupId=${groupId}&userId=${uid}` })
    items.value = res || []
  } catch { items.value = [] }
  itemsLoading.value = false
}

function enterGroup(g: any) {
  activeGroupId.value = g.id
  groupTitle.value = g.name
  viewMode.value = 'items'
  if (activeTab.value === 'apps') {
    loadAppItems(g.id)
  } else {
    loadItems(g.id)
  }
}

function backToGroups() {
  viewMode.value = 'groups'
  loadGroups()
}

function openDialog(title: string, cb: (v: string) => void, initVal = '') {
  dialogTitle.value = title
  dialogValue.value = initVal
  dialogCallback = cb
  showDialog.value = true
  nextTick(() => dialogInput.value?.focus())
}

function confirmDialog() {
  const val = dialogValue.value.trim()
  if (!val) return
  showDialog.value = false
  dialogCallback?.(val)
}

function openCreateGroup() {
  openDialog('新建分组', async (name) => {
    try {
      const request = (await import('@/utils/http')).default
      const uid = userStore.info?.userId
      let res
      if (activeTab.value === 'apps') {
        res = await request.post({ url: '/api/app-favorite/groups', data: { userId: uid, name } })
      } else {
        res = await request.post({ url: '/api/community/favorite/groups', data: { name } })
      }
      if (res) groups.value.push(res)
    } catch (e: any) { alert(e.message || '创建失败') }
  })
}

function openRenameGroup(g: any) {
  dialogShowSwitch.value = true
  dialogIsPublic.value = !!Number(g.is_public)
  openDialog('修改分组', async (name) => {
    const changed = name !== g.name || dialogIsPublic.value !== !!Number(g.is_public)
    if (!changed) return
    try {
      const request = (await import('@/utils/http')).default
      const uid = userStore.info?.userId
      if (activeTab.value === 'apps') {
        await request.put({ url: `/api/app-favorite/groups/${g.id}`, data: { userId: uid, name } })
        if (dialogIsPublic.value !== !!Number(g.is_public)) {
          await request.put({ url: `/api/app-favorite/groups/${g.id}/visibility`, data: { userId: uid, is_public: dialogIsPublic.value ? 1 : 0 } })
        }
      } else {
        await request.put({ url: `/api/community/favorite/groups/${g.id}`, data: { name } })
        if (dialogIsPublic.value !== !!Number(g.is_public)) {
          await request.put({ url: `/api/community/favorite/groups/${g.id}/visibility`, data: { is_public: dialogIsPublic.value ? 1 : 0 } })
        }
      }
      g.name = name
      g.is_public = dialogIsPublic.value ? 1 : 0
    } catch (e: any) { alert(e.message || '修改失败') }
  }, g.name)
}

async function toggleVisibility(g: any) {
  const newVal = g.is_public ? 0 : 1
  try {
    const request = (await import('@/utils/http')).default
    const uid = userStore.info?.userId
    let res
    if (activeTab.value === 'apps') {
      res = await request.put({ url: `/api/app-favorite/groups/${g.id}/visibility`, data: { userId: uid, is_public: newVal } })
    } else {
      res = await request.put({ url: `/api/community/favorite/groups/${g.id}/visibility`, data: { is_public: newVal } })
    }
    if (res) g.is_public = newVal
  } catch (e: any) {
    alert(e.message || '操作失败')
  }
}

function openMoveDialog(c: any) {
  movingItem.value = c
  showMoveDialog.value = true
}

async function selectMoveTarget(g: any) {
  showMoveDialog.value = false
  const c = movingItem.value
  if (!c) return
  try {
    const request = (await import('@/utils/http')).default
    if (activeTab.value === 'apps') {
      await request.post({ url: '/api/app-favorite/move', data: { userId: userStore.info?.userId, appId: c.app_id, targetGroupId: g.id } })
    } else if (c.item_type === 'post') {
      await request.post({ url: `/api/community/post/${c.id}/favorite`, data: { groupId: g.id } })
    } else {
      await request.post({ url: '/api/community/favorite/move', data: { collectionIds: [c.id], targetGroupId: g.id } })
    }
    if (activeTab.value === 'apps') {
      items.value = items.value.filter(x => x.id !== c.id)
    } else {
      items.value = items.value.filter(x => x.fav_id !== c.fav_id)
    }
    const grp = groups.value.find(x => x.id === activeGroupId.value)
    if (grp && grp.count > 0) grp.count--
  } catch (e: any) { alert(e.message || '移动失败') }
  movingItem.value = null
}

async function removeItem(c: any) {
  if (!confirm('确定移除收藏？')) return
  try {
    const request = (await import('@/utils/http')).default
    if (activeTab.value === 'mall') {
      await request.post({ url: `/api/mall/favorites/${c.productId}`, data: {} })
      items.value = items.value.filter(x => x.id !== c.id)
      return
    }
    if (activeTab.value === 'apps') {
      await request.post({ url: '/api/app-favorite/toggle', data: { userId: userStore.info?.userId, appId: c.app_id } })
    } else if (c.item_type === 'post') {
      await request.del({ url: `/api/community/post/${c.id}/favorite` })
    } else {
      await request.del({ url: `/api/community/collection/${c.id}/favorite` })
    }
    if (activeTab.value === 'apps') {
      items.value = items.value.filter(x => x.id !== c.id)
    } else {
      items.value = items.value.filter(x => x.fav_id !== c.fav_id)
    }
    const g = groups.value.find(x => x.id === activeGroupId.value)
    if (g) {
      if (activeTab.value === 'apps') { if (g.app_total > 0) g.app_total-- }
      else { if (g.post_total > 0) g.post_total-- }
    }
  } catch (e: any) { alert(e.message || '操作失败') }
}

function openItem(c: any) {
  if (activeTab.value === 'apps') {
    router.push(`/a/${c.app_id}`)
  } else if (activeTab.value === 'mall') {
    router.push(`/appstore/mall-detail/${c.productId}`)
  } else if (c.item_type === 'post') {
    router.push(`/community/post/${c.id}`)
  } else {
    router.push(`/community/collection/${c.id}`)
  }
}

function formatTime(t: string) {
  if (!t) return ''
  const d = new Date(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return '刚刚'
  if (mins < 60) return mins + '分钟前'
  const hours = Math.floor(mins / 60)
  if (hours < 24) return hours + '小时前'
  const days = Math.floor(hours / 24)
  if (days < 30) return days + '天前'
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return y + '-' + m + '-' + dd
}

function fmtCount(n: number) {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n || 0)
}

function parsedImages(c: any): string[] {
  if (c.item_type !== 'post') return []
  try {
    const arr = typeof c.images === 'string' ? JSON.parse(c.images) : c.images
    return Array.isArray(arr) ? arr : []
  } catch { return [] }
}

onMounted(() => { if (userStore.isLogin) { if (activeTab.value === 'mall') loadMallItems(); else loadGroups() } else loading.value = false })
</script>

<style scoped>
.mf-page {
  position: fixed; inset: 0; background: #f5f6fa; z-index: 50;
  display: flex; flex-direction: column; overflow: hidden;
}
.mf-nav {
  background: #fff; flex-shrink: 0; display: flex; align-items: center;
  justify-content: space-between; height: 46px; padding: 0 16px;
  border-bottom: 1px solid #f0f0f0;
}
.mf-nav-back { background: none; border: none; padding: 4px; color: #333; cursor: pointer; display: flex; }
.mf-nav-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
.mf-nav-add {
  background: #EC4899; color: #fff; border: none; padding: 6px 14px;
  border-radius: 16px; font-size: 13px; cursor: pointer;
}

/* ---- Tab 切换 ---- */
.mf-tabs {
  display: flex; background: #fff; padding: 0 16px;
  border-bottom: 1px solid #f0f0f0; flex-shrink: 0;
}
.mf-tab {
  flex: 1; padding: 10px 0; border: none; background: none;
  font-size: 14px; color: #999; cursor: pointer; text-align: center;
  position: relative; transition: color .15s;
}
.mf-tab.active { color: #EC4899; font-weight: 600; }
.mf-tab.active::after {
  content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 24px; height: 3px; border-radius: 2px; background: #EC4899;
}

/* ---- 分组 ---- */
.mf-groups { flex: 1; overflow-y: auto; }
.mf-group-list { padding: 8px 14px; }
.mf-folder-row {
  display: flex; align-items: center; gap: 12px;
  background: #fff; border-radius: 14px; padding: 14px;
  margin-bottom: 10px; cursor: pointer;
  box-shadow: 0 2px 10px rgba(0,0,0,.04); transition: all .15s;
}
.mf-folder-row:active { background: #fdf2f8; transform: scale(.985); }
.mf-folder-icon {
  width: 44px; height: 44px; border-radius: 12px;
  background: #fdf2f8; display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.mf-folder-info { flex: 1; min-width: 0; }
.mf-folder-name {
  font-size: 15px; font-weight: 600; color: #1a1a2e;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.mf-folder-meta { font-size: 12px; color: #999; margin-top: 3px; }
.mf-folder-actions {
  display: flex; align-items: center; gap: 6px; flex-shrink: 0;
}
.mf-visibility-btn {
  background: none; border: none; padding: 6px; color: #999;
  border-radius: 8px; cursor: pointer; display: flex;
}
.mf-visibility-btn.public { color: #1890ff; }
.mf-folder-edit-btn {
  background: none; border: none; padding: 6px; color: #bbb;
  cursor: pointer; display: flex;
}

/* ---- 列表顶部 ---- */
.mf-items { flex: 1; overflow-y: auto; }
.mf-items-header {
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 16px 8px;
}
.mf-items-count { font-size: 13px; color: #999; }
.mf-items-visibility {
  font-size: 11px; padding: 2px 10px; border-radius: 10px;
  background: #e8f4fd; color: #1890ff;
}
.mf-items-visibility.priv { background: #f3f4f6; color: #999; }

/* ---- 空状态 & 弹窗 ---- */
.mf-empty {
  text-align: center; padding: 60px 0; color: #999; font-size: 14px;
}
.mf-dialog-mask {
  position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100;
  display: flex; align-items: center; justify-content: center;
}
.mf-dialog {
  background: #fff; border-radius: 16px; width: 300px; padding: 24px 20px 20px;
  box-shadow: 0 12px 40px rgba(0,0,0,.15);
}
.mf-dialog-title { font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 14px; }
.mf-dialog-input {
  width: 100%; padding: 10px 14px; border: 2px solid #e5e7eb; border-radius: 10px;
  font-size: 15px; outline: none; box-sizing: border-box;
  transition: border-color .15s;
}
.mf-dialog-input:focus { border-color: #EC4899; }
.mf-dialog-btns { display: flex; gap: 10px; margin-top: 16px; }
.mf-dialog-btn {
  flex: 1; padding: 10px 0; border: none; border-radius: 10px;
  font-size: 14px; cursor: pointer;
}
.mf-dialog-btn.cancel { background: #f3f4f6; color: #666; }
.mf-dialog-btn.confirm { background: #EC4899; color: #fff; font-weight: 600; }
.mf-dialog-switch {
  display: flex; align-items: center; justify-content: space-between;
  margin-top: 14px; padding: 10px 14px; background: #f8f9fc;
  border-radius: 10px; cursor: pointer;
}
.mf-dialog-switch-label { font-size: 14px; color: #333; font-weight: 500; }
.mf-dialog-switch-track {
  width: 46px; height: 26px; border-radius: 13px; background: #d1d5db;
  position: relative; transition: background .2s;
}
.mf-dialog-switch-track.on { background: #EC4899; }
.mf-dialog-switch-thumb {
  position: absolute; top: 3px; left: 3px; width: 20px; height: 20px;
  border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.15);
  transition: left .2s;
}
.mf-dialog-switch-track.on .mf-dialog-switch-thumb { left: 23px; }

/* ---- 移动分组列表 ---- */
.mf-move-list { max-height: 280px; overflow-y: auto; margin: -4px -4px 0; }
.mf-move-row {
  display: flex; align-items: center; gap: 12px; padding: 12px 14px;
  border-radius: 10px; cursor: pointer; transition: background .15s;
}
.mf-move-row:active { background: #fdf2f8; }
.mf-move-name { flex: 1; font-size: 14px; font-weight: 500; color: #1a1a2e; }
.mf-move-count { font-size: 12px; color: #999; }
.mf-move-empty { text-align: center; padding: 24px 0; color: #999; font-size: 13px; }
</style>

<style>
.ct-hash { color: #6366F1; background: #EEF2FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-img { color: #9CA3AF; font-size: 11px; }
</style>
