<template>
  <div class="page">
    <header class="topbar">
      <svg class="back-btn" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
      <span class="title">控制台</span>
      <button class="refresh-btn" @click="reload"><svg class="refresh-icon" :class="{ spin: l }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg></button>
    </header>

    <div v-if="e" class="err-box"><div class="err-card"><svg class="err-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><p class="err-msg">{{ e }}</p><button class="err-retry" @click="reload">点击重试</button></div></div>

    <div v-if="l" class="loading-box"><span class="spinner"/></div>

    <div v-if="d" class="content">
      <section class="overview">
        <div class="sec-header"><span class="sec-label">核心概览</span><span class="sec-time" v-if="t">{{ t }}</span></div>
        <div class="ov-grid">
          <div v-for="(o,i) in ov" :key="o.k" class="ov-card" :style="{ borderTopColor: o.c, animationDelay: i * 40 + 'ms' }">
            <span class="ov-label">{{ o.l }}</span>
            <span class="ov-value" :style="{ color: o.c }">{{ o.v }}</span>
            <span class="ov-sub" v-if="o.s">{{ o.s }}</span>
          </div>
        </div>
      </section>

      <div class="mt-4 space-y-3">
        <div v-for="(s,i) in sx" :key="s.t" class="sec-card" :style="{ animationDelay: i * 50 + 'ms' }">
          <div class="sec-head" @click="xg[s.t] = !xg[s.t]">
            <div class="sec-icon-box" :style="{ background: s.c + '16' }">
              <svg class="sec-icon" :style="{ color: s.c }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" :d="s.icon"/></svg>
            </div>
            <span class="sec-title">{{ s.title }}</span>
            <span class="sec-count">{{ s.i.length }}</span>
            <svg class="sec-arrow" :class="{ open: xg[s.t] }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </div>
          <div v-if="xg[s.t]" class="sec-body">
            <div v-for="it in s.i" :key="it.k" class="sec-row"><span class="sec-row-label">{{ it.l }}</span><span class="sec-row-val" :style="{ color: it.c || '#374151' }">{{ it.v }}</span></div>
          </div>
        </div>
      </div>
      <div class="spacer"/>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { fetchConsoleStats } from '@/api/system-manage'

const l = ref(true)
const e = ref('')
const d = ref<any>(null)
const t = ref('')
const xg = reactive<Record<string, boolean>>({})

function n(v: any): string {
  if (v == null) return '-'
  const num = Number(v)
  return Number.isNaN(num) ? String(v) : num.toLocaleString()
}

function siz(v: any): string {
  if (v == null) return '-'
  const num = Number(v)
  if (Number.isNaN(num)) return String(v)
  if (num < 1024) return num + ' B'
  if (num < 1048576) return (num / 1024).toFixed(1) + ' KB'
  if (num < 1073741824) return (num / 1048576).toFixed(1) + ' MB'
  return (num / 1073741824).toFixed(1) + ' GB'
}

function load() {
  l.value = true; e.value = ''
  fetchConsoleStats()
    .then((res: any) => {
      d.value = res
      t.value = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      l.value = false
    })
    .catch((err: any) => { e.value = err.message || '加载失败'; l.value = false })
}

function reload() { d.value = null; load() }

const ov = computed(() => {
  if (!d.value) return []
  const a = d.value
  const cards: any[] = []
  if (a.user) { cards.push({ k: 'ut', l: '用户总数', v: n(a.user.total), c: '#4F46E5' }); cards.push({ k: 'un', l: '今日新增', v: n(a.user.todayNew), c: '#059669' }); cards.push({ k: 'uo', l: '当前在线', v: n(a.user.online), c: '#2563EB' }) }
  if (a.order) { cards.push({ k: 'ot', l: '今日订单额', v: '\xA5' + n(a.order.todayAmount), c: '#D97706' }); cards.push({ k: 'oo', l: '总订单', v: n(a.order.total), c: '#4B5563' }) }
  if (a.points) { cards.push({ k: 'pt', l: '积分流通', v: n(a.points.total), c: '#7C3AED' }); cards.push({ k: 'pr', l: '积分流水', v: n(a.points.records), c: '#9CA3AF' }) }
  if (a.fileRepo) cards.push({ k: 'fs', l: '文件存储', v: siz(a.fileRepo.size), c: '#0891B2', s: n(a.fileRepo.total) + ' 个文件' })
  return cards
})

const sx = computed(() => {
  if (!d.value) return []
  const a = d.value
  return [
    { t: 'user', title: '用户与会员', c: '#4F46E5', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z', i: [{ k: 'ut', l: '总用户', v: n(a.user.total) }, { k: 'un', l: '今日新增', v: n(a.user.todayNew), c: '#059669' }, { k: 'uo', l: '当前在线', v: n(a.user.online), c: '#2563EB' }, { k: 'ud', l: '已注销', v: n(a.user.deleted) }, { k: 'ml', l: '会员等级', v: n(a.membership.levels) }, { k: 'mp', l: '会员商品', v: n(a.membership.products) }, { k: 'mbu', l: '购买次数', v: n(a.membership.purchases) }] },
    { t: 'card', title: '卡密与优惠券', c: '#D97706', icon: 'M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z', i: [{ k: 'ct', l: '卡密总数', v: n(a.cardKey.total) }, { k: 'ca', l: '可用卡密', v: n(a.cardKey.available), c: '#059669' }, { k: 'cu', l: '已用卡密', v: n(a.cardKey.used) }, { k: 'cot', l: '优惠券种类', v: n(a.coupon.total) }, { k: 'coi', l: '已发放', v: n(a.coupon.issued) }, { k: 'cou', l: '已核销', v: n(a.coupon.used), c: '#059669' }] },
    { t: 'points', title: '积分与经验', c: '#7C3AED', icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6', i: [{ k: 'pt', l: '系统总积分', v: n(a.points.total) }, { k: 'pr', l: '积分流水', v: n(a.points.records) }, { k: 'el', l: '经验等级', v: n(a.experience.levels) }, { k: 'er', l: '经验流水', v: n(a.experience.records) }] },
    { t: 'plugin', title: '插件与称号', c: '#059669', icon: 'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4', i: [{ k: 'plt', l: '插件总数', v: n(a.plugin.total) }, { k: 'pla', l: '已启用', v: n(a.plugin.active), c: '#059669' }, { k: 'tc', l: '自定义称号', v: n(a.title.custom) }, { k: 'ta', l: '已分配', v: n(a.title.assigned) }] },
    { t: 'comm', title: '推广与返佣', c: '#DC2626', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z', i: [{ k: 'ccr', l: '返佣记录', v: n(a.commission.records) }, { k: 'cca', l: '返佣总额', v: '\xA5' + n(a.commission.amount) }, { k: 'ccu', l: '返佣规则', v: n(a.commission.rules) }, { k: 'ccl', l: '推广链接', v: n(a.commission.links) }] },
    { t: 'order', title: '订单与购买', c: '#2563EB', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z', i: [{ k: 'ot', l: '总订单', v: n(a.order.total) }, { k: 'ota', l: '今日订单额', v: '\xA5' + n(a.order.todayAmount), c: '#059669' }, { k: 'cp', l: '内容购买', v: n(a.contentPurchase.total) }] },
    { t: 'appstore', title: '应用商店', c: '#7C3AED', icon: 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z', i: [{ k: 'at', l: '应用总数', v: n(a.appStore.total) }, { k: 'aa', l: '已审核', v: n(a.appStore.approved), c: '#059669' }, { k: 'ap', l: '待审核', v: n(a.appStore.pending), c: '#D97706' }, { k: 'ac', l: '分类', v: n(a.appStore.categories) }, { k: 'atg', l: '标签', v: n(a.appStore.tags) }, { k: 'av', l: '版本', v: n(a.appStore.versions) }, { k: 'aco', l: '评论', v: n(a.appStore.comments) }, { k: 'apu', l: '购买', v: n(a.appStore.purchases) }, { k: 'afa', l: '收藏', v: n(a.appStore.favorites) }] },
    { t: 'community', title: '社区', c: '#059669', icon: 'M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z', i: [{ k: 'cpt', l: '帖子', v: n(a.community.posts) }, { k: 'ccm', l: '评论', v: n(a.community.comments) }, { k: 'cto', l: '话题', v: n(a.community.topics) }, { k: 'csc', l: '板块', v: n(a.community.sections) }, { k: 'clk', l: '点赞', v: n(a.community.likes) }, { k: 'crp', l: '举报', v: n(a.community.reports), c: '#DC2626' }] },
    { t: 'mall', title: '商城', c: '#D97706', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', i: [{ k: 'mprd', l: '商品', v: n(a.mall.products) }, { k: 'mo', l: '订单', v: n(a.mall.orders) }, { k: 'mta', l: '今日销售额', v: '\xA5' + n(a.mall.todayAmount) }, { k: 'mc', l: '分类', v: n(a.mall.categories) }, { k: 'mrv', l: '评价', v: n(a.mall.reviews) }, { k: 'mpm', l: '促销', v: n(a.mall.promotions) }] },
    { t: 'chat', title: '聊天', c: '#0891B2', icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z', i: [{ k: 'chr', l: '聊天室', v: n(a.chat.rooms) }, { k: 'chm', l: '消息', v: n(a.chat.messages) }, { k: 'chb', l: '成员', v: n(a.chat.members) }, { k: 'chg', l: '礼物', v: n(a.chat.gifts) }] },
    { t: 'recharge', title: '充值提现', c: '#DC2626', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z', i: [{ k: 'rco', l: '充值订单', v: n(a.recharge.orders) }, { k: 'rct', l: '充值总额', v: '\xA5' + n(a.recharge.totalAmount) }, { k: 'rcd', l: '今日充值', v: '\xA5' + n(a.recharge.todayAmount) }, { k: 'wt', l: '提现申请', v: n(a.withdraw.total) }, { k: 'wp', l: '待处理', v: n(a.withdraw.pending), c: '#D97706' }, { k: 'wd', l: '已完成提现', v: '\xA5' + n(a.withdraw.completedAmount) }] },
    { t: 'social', title: '社交与签到', c: '#2563EB', icon: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z', i: [{ k: 'sf', l: '关注关系', v: n(a.social.follows) }, { k: 'sb', l: '拉黑', v: n(a.social.blocks) }, { k: 'sm', l: '私信', v: n(a.social.messages) }, { k: 'cr', l: '签到记录', v: n(a.checkin.records) }, { k: 'ctd', l: '今日签到', v: n(a.checkin.today), c: '#059669' }, { k: 'cg', l: '签到分组', v: n(a.checkin.groups) }] },
    { t: 'other', title: '其他配置', c: '#6B7280', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z', i: [{ k: 'af', l: '头像框', v: n(a.avatarFrame.total) }, { k: 'afa', l: '已分配', v: n(a.avatarFrame.assigned) }, { k: 'sl', l: '在线会话', v: n(a.session.active), c: '#059669' }, { k: 'nt', l: '系统通知', v: n(a.notification.total) }, { k: 'sw', l: '敏感词', v: n(a.sensitiveWord.total) }, { k: 'flc', l: '文件数量', v: n(a.fileRepo.total) }, { k: 'fls', l: '存储占用', v: siz(a.fileRepo.size) }, { k: 'rz', l: '角色', v: n(a.role.total) }, { k: 'mn', l: '菜单', v: n(a.menu.total) }, { k: 'sysl', l: '系统日志', v: n(a.systemLog.total) }, { k: 'syslt', l: '今日日志', v: n(a.systemLog.today), c: '#2563EB' }] },
  ]
})

onMounted(() => load())
</script>

<style scoped>
.page { min-height: 100vh; background: #F5F6F8; }
.topbar { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: rgba(255,255,255,0.75); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); position: sticky; top: 0; z-index: 20; border-bottom: 1px solid rgba(255,255,255,0.6); box-shadow: 0 1px 8px rgba(0,0,0,0.03); }
.back-btn { width: 20px; height: 20px; color: #6B7280; flex-shrink: 0; cursor: pointer; }
.title { font-size: 17px; font-weight: 700; color: #111827; flex: 1; text-align: center; margin-right: 20px; }
.refresh-btn { width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 8px; color: #9CA3AF; background: none; border: none; cursor: pointer; }
.refresh-btn:active { background: #F3F4F6; }
.refresh-icon { width: 16px; height: 16px; }
.spin { animation: spin 0.8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.err-box { padding: 16px 14px; }
.err-card { background: #FEF2F2; border: 1px solid #FECACA; border-radius: 16px; padding: 28px 16px; text-align: center; }
.err-icon { width: 36px; height: 36px; color: #F87171; margin: 0 auto 10px; }
.err-msg { font-size: 14px; color: #DC2626; margin-bottom: 14px; line-height: 1.5; }
.err-retry { font-size: 13px; padding: 7px 22px; background: #DC2626; color: #fff; border: none; border-radius: 20px; cursor: pointer; }
.err-retry:active { background: #B91C1C; }

.loading-box { display: flex; justify-content: center; padding: 80px 0; }
.spinner { width: 32px; height: 32px; border: 3px solid #E5E7EB; border-top-color: #4F46E5; border-radius: 50%; animation: spin 0.7s linear infinite; }

.content { padding: 0 14px 24px; animation: fadeUp 0.35s ease-out; }
@keyframes fadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

.overview { margin-top: 16px; }
.sec-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
.sec-label { font-size: 13px; font-weight: 600; color: #9CA3AF; letter-spacing: 0.5px; }
.sec-time { font-size: 11px; color: #D1D5DB; }

.ov-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.ov-card { background: #fff; border-radius: 14px; padding: 14px 14px 12px; border-top: 3px solid #E5E7EB; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: transform 0.2s, box-shadow 0.2s; animation: cardIn 0.35s ease-out both; }
.ov-card:active { transform: scale(0.98); box-shadow: 0 4px 16px rgba(0,0,0,0.1); }
.ov-label { display: block; font-size: 12px; color: #9CA3AF; margin-bottom: 4px; }
.ov-value { display: block; font-size: 22px; font-weight: 700; line-height: 1.2; }
.ov-sub { display: block; font-size: 11px; color: #D1D5DB; margin-top: 2px; }

.sec-card { background: #fff; border-radius: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow: hidden; animation: cardIn 0.35s ease-out both; }
@keyframes cardIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

.sec-head { display: flex; align-items: center; gap: 10px; padding: 14px 14px; cursor: pointer; user-select: none; }
.sec-head:active { background: #F9FAFB; }
.sec-icon-box { width: 32px; height: 32px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.sec-icon { width: 18px; height: 18px; }
.sec-title { font-size: 15px; font-weight: 600; color: #1F2937; flex: 1; }
.sec-count { font-size: 11px; font-weight: 500; color: #D1D5DB; background: #F3F4F6; padding: 2px 8px; border-radius: 10px; }
.sec-arrow { width: 16px; height: 16px; color: #D1D5DB; flex-shrink: 0; transition: transform 0.25s ease; }
.sec-arrow.open { transform: rotate(90deg); }

.sec-body { padding: 0 14px 14px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 0 20px; }
.sec-row { display: flex; align-items: center; justify-content: space-between; padding: 7px 0; border-bottom: 1px solid #F9FAFB; }
.sec-row:last-child { border-bottom: none; }
.sec-row-label { font-size: 12px; color: #6B7280; white-space: nowrap; }
.sec-row-val { font-size: 13px; font-weight: 600; flex-shrink: 0; }

.spacer { height: 40px; }
</style>
