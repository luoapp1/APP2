<template>
  <div class="page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="title">售后服务</span>
    </div>
    <main class="main" ref="mainRef">
      <div v-if="loading" class="loading">加载中...</div>
      <template v-else>
        <div v-if="list.length === 0 && !showForm" class="empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
          <div>暂无售后记录</div>
        </div>
        <div v-for="item in list" :key="item.id" class="card">
          <div class="card-row">
            <span class="card-label">订单号</span>
            <span class="card-value">{{ item.orderId }}</span>
          </div>
          <div class="card-row">
            <span class="card-label">商品</span>
            <span class="card-value">{{ item.productName }}</span>
          </div>
          <div class="card-row">
            <span class="card-label">原因</span>
            <span class="card-value">{{ item.reason }}</span>
          </div>
          <div class="card-row">
            <span class="card-label">状态</span>
            <span class="status-badge" :class="statusClass(item.status)">{{ statusText(item.status) }}</span>
          </div>
          <div class="card-row">
            <span class="card-label">申请时间</span>
            <span class="card-value">{{ item.createTime }}</span>
          </div>
        </div>
        <div v-if="total > list.length" class="load-more" @click="loadMore">加载更多</div>
      </template>
    </main>
    <div class="fab" @click="showForm = !showForm">
      <svg v-if="!showForm" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
      <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
    </div>
    <div class="form-overlay" v-if="showForm" @click.self="showForm = false">
      <div class="form-panel">
        <div class="form-header">新建售后申请</div>
        <div class="form-body">
          <div class="form-field">
            <label class="form-label">订单号</label>
            <input v-model="form.orderId" class="form-input" placeholder="请输入订单号" />
          </div>
          <input type="hidden" v-model="form.productId" />
          <div class="form-field">
            <label class="form-label">售后原因</label>
            <div class="reason-options">
              <label v-for="r in reasonOptions" :key="r" class="reason-option" :class="{ checked: form.reason === r }">
                <input type="radio" :value="r" v-model="form.reason" class="reason-radio" />
                <span>{{ r }}</span>
              </label>
            </div>
            <textarea v-if="form.reason === '其他原因'" v-model="form.reasonDetail" class="form-textarea" placeholder="请补充具体原因..." rows="2" />
          </div>
          <div class="form-field">
            <label class="form-label">详细描述</label>
            <textarea v-model="form.description" class="form-textarea" placeholder="请详细描述问题..." rows="3" />
          </div>
          <div class="form-field">
            <label class="form-label">上传图片（最多3张）</label>
            <input ref="imgInput" type="file" accept="image/*" class="img-input-hidden" @change="onImgPicked" />
            <div class="image-upload-area">
              <div v-for="(img, idx) in form.images" :key="idx" class="image-thumb">
                <img :src="img" class="thumb-img" />
                <span class="thumb-remove" @click="removeImage(idx)">x</span>
              </div>
              <div v-if="form.images.length < 3" class="image-add" @click="triggerImgUpload">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
              </div>
            </div>
          </div>
        </div>
        <div class="form-footer">
          <button class="form-btn cancel" @click="showForm = false">取消</button>
          <button class="form-btn submit" :disabled="submitting" @click="handleSubmit">{{ submitting ? '提交中...' : '提交申请' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const route = useRoute()

const list = ref([])
const total = ref(0)
const page = ref(1)
const loading = ref(true)
const showForm = ref(false)
const submitting = ref(false)
const imgInput = ref(null)

const reasonOptions = ['质量问题', '商品与描述不符', '不想要了', '卖家发错货', '商品破损', '其他原因']

const form = ref({
  orderId: '',
  productId: '',
  reason: '',
  reasonDetail: '',
  description: '',
  images: []
})

onMounted(() => {
  const pid = route.query.productId
  if (pid) form.value.productId = String(pid)
  fetchList()
})

async function fetchList() {
  try {
    const res = await request.get({ url: `/api/mall/after-sales?page=${page.value}&pageSize=20` })
    list.value = res?.list || []
    total.value = res?.total || 0
  } catch (e) { console.error(e) }
  loading.value = false
}

async function loadMore() {
  page.value++
  try {
    const res = await request.get({ url: `/api/mall/after-sales?page=${page.value}&pageSize=20` })
    list.value = list.value.concat(res?.list || [])
    total.value = res?.total || 0
  } catch (e) { console.error(e) }
}

function triggerImgUpload() {
  imgInput.value?.click()
}

function removeImage(idx) {
  form.value.images.splice(idx, 1)
}

async function onImgPicked(e) {
  const input = e.target
  const file = input?.files?.[0]
  if (!file) return
  const fd = new FormData()
  fd.append('file', file)
  try {
    const res = await request.post({ url: '/api/upload/file', data: fd })
    const url = res?.url || res?.data?.url || res?.data || ''
    if (url) form.value.images.push(url)
  } catch (e) { ElMessage.error('图片上传失败') }
  input.value = ''
}

async function handleSubmit() {
  if (!form.value.orderId || !form.value.productId) {
    ElMessage.warning('请填写订单号和商品ID')
    return
  }
  if (!form.value.reason) {
    ElMessage.warning('请选择售后原因')
    return
  }
  submitting.value = true
  try {
    const reasonText = form.value.reason === '其他原因'
      ? `其他原因：${form.value.reasonDetail || ''}`
      : form.value.reason
    await request.post({
      url: '/api/mall/after-sales',
      data: {
        orderId: form.value.orderId,
        productId: form.value.productId,
        reason: reasonText,
        description: form.value.description,
        images: form.value.images
      }
    })
    ElMessage.success('提交成功')
    showForm.value = false
    form.value = { orderId: '', productId: '', reason: '', reasonDetail: '', description: '', images: [] }
    page.value = 1
    await fetchList()
  } catch (e) { ElMessage.error(e?.msg || '提交失败') }
  submitting.value = false
}

function statusClass(status) {
  const map = { pending: 's-pending', approved: 's-approved', rejected: 's-rejected', refunded: 's-refunded' }
  return map[status] || ''
}

function statusText(status) {
  const map = { pending: '待处理', approved: '已通过', rejected: '已拒绝', refunded: '已退款' }
  return map[status] || status
}
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6fa; position: relative; padding-bottom: 60px }
.header { background: #fff; display: flex; align-items: center; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; position: sticky; top: 0; z-index: 10 }
.back-btn { background: none; border: none; padding: 4px; color: #333; cursor: pointer }
.title { font-size: 17px; font-weight: 600; color: #1a1a2e; margin-left: 8px }
.main { padding: 12px }
.loading { text-align: center; padding: 60px 0; color: #999 }
.empty { text-align: center; padding: 80px 0; color: #999 }
.card { background: #fff; border-radius: 12px; padding: 14px; margin-bottom: 10px }
.card-row { display: flex; align-items: center; margin-bottom: 8px; font-size: 13px }
.card-row:last-child { margin-bottom: 0 }
.card-label { color: #999; width: 64px; flex-shrink: 0 }
.card-value { color: #333; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
.status-badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 500 }
.s-pending { background: #FFF3E0; color: #FF9800 }
.s-approved { background: #E8F5E9; color: #4CAF50 }
.s-rejected { background: #FFEBEE; color: #F44336 }
.s-refunded { background: #E3F2FD; color: #2196F3 }
.load-more { text-align: center; padding: 16px; color: #508DFF; font-size: 13px; cursor: pointer }
.fab { position: fixed; right: 20px; bottom: 80px; width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #508DFF, #6C63FF); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(80,141,255,.4); cursor: pointer; z-index: 20 }
.form-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.4); display: flex; align-items: flex-end; z-index: 30 }
.form-panel { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 80vh; overflow-y: auto; padding: 20px 16px }
.form-header { font-size: 16px; font-weight: 600; color: #1a1a2e; margin-bottom: 16px; text-align: center }
.form-body { display: flex; flex-direction: column; gap: 14px }
.form-field { display: flex; flex-direction: column; gap: 6px }
.form-label { font-size: 13px; color: #666; font-weight: 500 }
.form-input { padding: 10px 12px; border: 1px solid #e5e5e5; border-radius: 8px; font-size: 14px; outline: none; color: #333 }
.form-input:focus { border-color: #508DFF }
.form-textarea { padding: 10px 12px; border: 1px solid #e5e5e5; border-radius: 8px; font-size: 14px; outline: none; color: #333; resize: vertical; font-family: inherit }
.form-textarea:focus { border-color: #508DFF }
.form-footer { display: flex; gap: 12px; margin-top: 20px }
.form-btn { flex: 1; padding: 12px; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; border: none }
.form-btn.cancel { background: #f5f6fa; color: #666 }
.form-btn.submit { background: linear-gradient(135deg, #508DFF, #6C63FF); color: #fff }
.form-btn.submit:disabled { opacity: .6 }
.reason-options { display: flex; flex-wrap: wrap; gap: 8px }
.reason-option { display: flex; align-items: center; gap: 6px; padding: 8px 12px; border: 1px solid #e5e5e5; border-radius: 8px; font-size: 13px; color: #333; cursor: pointer }
.reason-option.checked { border-color: #508DFF; background: #EDF2FF; color: #508DFF; font-weight: 500 }
.reason-radio { display: none }
.img-input-hidden { display: none }
.image-upload-area { display: flex; flex-wrap: wrap; gap: 8px }
.image-thumb { position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden }
.thumb-img { width: 100%; height: 100%; object-fit: cover }
.thumb-remove { position: absolute; top: -4px; right: -4px; width: 20px; height: 20px; border-radius: 50%; background: #FF4757; color: #fff; font-size: 12px; display: flex; align-items: center; justify-content: center; cursor: pointer; line-height: 1 }
.image-add { width: 72px; height: 72px; border: 1px dashed #d9d9d9; border-radius: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer }
</style>
