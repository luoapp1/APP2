<template>
  <div class="bundles-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">系列包管理</span>
      <button class="nav-action" @click="openCreate">新建</button>
    </div>

    <div class="page-content">
      <div v-if="loading" class="load-wrap"><div class="spin" /></div>
      <div v-else-if="error" class="err-wrap">
        <p class="err-text">{{ error }}</p>
        <button class="btn btn-primary" @click="loadData">重试</button>
      </div>
      <div v-else-if="!list.length" class="empty-wrap">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
        <p class="empty-text">暂无系列包</p>
        <button class="btn btn-primary" @click="openCreate">创建系列包</button>
      </div>
      <div v-else class="bundles-grid">
        <div v-for="item in list" :key="item.id" class="bundle-card" @click="openEdit(item)">
          <div class="bundle-cover">
            <img v-if="item.coverImage" :src="item.coverImage" class="bundle-cover-img" />
            <div v-else class="bundle-cover-placeholder">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
            </div>
          </div>
          <div class="bundle-info">
            <div class="bundle-name">{{ item.name }}</div>
            <div v-if="item.description" class="bundle-desc">{{ item.description }}</div>
            <div class="bundle-meta">
              <span>{{ item.appCount || 0 }} 款应用</span>
              <span v-if="item.originalPrice" class="bundle-original">{{ item.originalPrice }}</span>
              <span class="bundle-price">{{ item.price }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="showDialog" class="dialog-overlay" @click.self="cancelDialog">
      <div class="dialog-panel">
        <div class="dialog-title">{{ isCreate ? '新建系列包' : '编辑系列包' }}</div>
        <div class="dialog-form">
          <div class="form-item">
            <label class="form-label">名称</label>
            <input v-model="form.name" class="form-input" placeholder="系列包名称" />
          </div>
          <div class="form-item">
            <label class="form-label">描述</label>
            <textarea v-model="form.description" class="form-input form-textarea" placeholder="系列包描述" rows="2" />
          </div>
          <div class="form-item">
            <label class="form-label">封面图URL</label>
            <input v-model="form.coverImage" class="form-input" placeholder="封面图片链接" />
          </div>
          <div class="form-row">
            <div class="form-item form-item-half">
              <label class="form-label">价格</label>
              <input v-model="form.price" class="form-input" placeholder="0" type="number" />
            </div>
            <div class="form-item form-item-half">
              <label class="form-label">原价</label>
              <input v-model="form.originalPrice" class="form-input" placeholder="0" type="number" />
            </div>
          </div>
        </div>
        <div class="dialog-actions">
          <button v-if="!isCreate" class="btn btn-danger" @click="doDelete">删除</button>
          <div class="dialog-actions-right">
            <button class="btn" @click="cancelDialog">取消</button>
            <button class="btn btn-primary" :disabled="saving" @click="doSave">{{ saving ? '保存中...' : '保存' }}</button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="showDeleteConfirm" class="dialog-overlay" @click.self="showDeleteConfirm = false">
      <div class="dialog-panel dialog-small">
        <div class="dialog-title">确认删除</div>
        <p class="dialog-msg">确定要删除该系列包吗？此操作不可恢复。</p>
        <div class="dialog-actions">
          <button class="btn" @click="showDeleteConfirm = false">取消</button>
          <button class="btn btn-danger" :disabled="saving" @click="confirmDelete">{{ saving ? '删除中...' : '确认删除' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const loading = ref(false)
const error = ref('')
const list = ref([])
const showDialog = ref(false)
const showDeleteConfirm = ref(false)
const isCreate = ref(true)
const saving = ref(false)
const editingId = ref(null)

const form = reactive({
  name: '',
  description: '',
  coverImage: '',
  price: '',
  originalPrice: ''
})

function resetForm() {
  form.name = ''
  form.description = ''
  form.coverImage = ''
  form.price = ''
  form.originalPrice = ''
  editingId.value = null
}

function openCreate() {
  isCreate.value = true
  resetForm()
  showDialog.value = true
}

function openEdit(item) {
  isCreate.value = false
  editingId.value = item.id
  form.name = item.name || ''
  form.description = item.description || ''
  form.coverImage = item.coverImage || ''
  form.price = item.price ?? ''
  form.originalPrice = item.originalPrice ?? ''
  showDialog.value = true
}

function cancelDialog() {
  showDialog.value = false
  resetForm()
}

function doDelete() {
  showDialog.value = false
  showDeleteConfirm.value = true
}

async function confirmDelete() {
  saving.value = true
  try {
    await request.request({ url: '/api/appstore/bundles', method: 'DELETE', data: { id: editingId.value } })
    showDeleteConfirm.value = false
    resetForm()
    await loadData()
  } catch (e) {
    const msg = e?.response?.data?.msg || e?.message || '删除失败'
    alert(msg)
  } finally {
    saving.value = false
  }
}

async function doSave() {
  if (!form.name.trim()) { alert('请输入名称'); return }
  saving.value = true
  try {
    const method = isCreate.value ? 'POST' : 'PUT'
    const body = {
      name: form.name,
      description: form.description,
      coverImage: form.coverImage,
      price: Number(form.price) || 0,
      originalPrice: Number(form.originalPrice) || 0
    }
    if (!isCreate.value) body.id = editingId.value
    await request.request({ url: '/api/appstore/bundles', method, data: body })
    showDialog.value = false
    resetForm()
    await loadData()
  } catch (e) {
    const msg = e?.response?.data?.msg || e?.message || '保存失败'
    alert(msg)
  } finally {
    saving.value = false
  }
}

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    const res = await request.get({ url: '/api/appstore/bundles' })
    const d = res?.data || res || {}
    list.value = d.list || []
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.bundles-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.nav-action { background: #6366F1; color: #fff; border: none; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
.nav-action:active { background: #4F46E5; }

.page-content { padding: 16px; }

.load-wrap { display: flex; justify-content: center; padding: 48px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.err-wrap { text-align: center; padding: 48px 16px; }
.err-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }
.empty-wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 60px 0; }
.empty-text { font-size: 14px; color: #999; margin-bottom: 12px; }

.bundles-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.bundle-card { background: #fff; border-radius: 14px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.04); transition: transform .15s; }
.bundle-card:active { transform: scale(.98); }
.bundle-cover { width: 100%; height: 130px; overflow: hidden; }
.bundle-cover-img { width: 100%; height: 100%; object-fit: cover; }
.bundle-cover-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #6366F1, #8B5CF6); display: flex; align-items: center; justify-content: center; }
.bundle-info { padding: 12px; }
.bundle-name { font-size: 14px; font-weight: 700; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bundle-desc { font-size: 11px; color: #999; margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bundle-meta { display: flex; align-items: center; gap: 8px; margin-top: 8px; font-size: 11px; }
.bundle-meta > span:first-child { color: #888; }
.bundle-original { color: #bbb; text-decoration: line-through; }
.bundle-price { color: #EF4444; font-weight: 700; font-size: 13px; }

.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; display: flex; align-items: flex-end; justify-content: center; }
.dialog-panel { background: #fff; width: 100%; max-width: 420px; border-radius: 20px 20px 0 0; padding: 20px 16px max(20px, env(safe-area-inset-bottom)); max-height: 80vh; overflow-y: auto; }
.dialog-small { border-radius: 20px; margin: 0 16px 200px; }
.dialog-title { font-size: 17px; font-weight: 700; color: #1a1a1a; margin-bottom: 16px; text-align: center; }
.dialog-msg { font-size: 14px; color: #666; text-align: center; margin-bottom: 20px; }
.dialog-form { display: flex; flex-direction: column; gap: 12px; }
.form-item { display: flex; flex-direction: column; gap: 4px; }
.form-item-half { flex: 1; }
.form-row { display: flex; gap: 10px; }
.form-label { font-size: 12px; font-weight: 600; color: #555; }
.form-input { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box; transition: border-color .15s; }
.form-input:focus { border-color: #6366F1; }
.form-textarea { resize: vertical; }
.dialog-actions { display: flex; align-items: center; gap: 10px; margin-top: 16px; }
.dialog-actions-right { display: flex; gap: 10px; margin-left: auto; }

.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; white-space: nowrap; font-weight: 500; }
.btn:active { background: #f5f5f5; }
.btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.btn-primary:active { background: #4F46E5; }
.btn-danger { background: #EF4444; color: #fff; border-color: #EF4444; }
.btn-danger:active { background: #DC2626; }
.btn:disabled { opacity: .5; cursor: not-allowed; }
</style>
