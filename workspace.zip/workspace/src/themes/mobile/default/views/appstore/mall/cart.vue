<template>
  <div class="cart-page">
    <div class="cart-header">
      <button class="back-btn" @click="$router.back()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="header-title">购物车</span>
      <button class="manage-btn" @click="toggleManage">{{ manageMode ? '完成' : '管理' }}</button>
    </div>

    <div class="cart-body" ref="bodyRef" :style="{ paddingBottom: list.length ? '80px' : '0' }">
      <div v-if="loading" class="loading-state">
        <div class="loading-ring"></div>
        <p>加载中...</p>
      </div>

      <div v-else-if="list.length === 0" class="empty-state">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#d0d5dd" stroke-width="1.2">
          <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
          <line x1="3" y1="6" x2="21" y2="6"/>
          <path d="M16 10a4 4 0 01-8 0"/>
        </svg>
        <p>购物车是空的</p>
        <span>快去挑选心仪的商品吧</span>
        <button class="go-shop-btn" @click="$router.push('/appstore/mall')">去逛逛</button>
      </div>

      <template v-else>
        <div v-for="item in list" :key="item.id" class="cart-item">
          <div class="item-check" @click="toggleSelect(item)">
            <div class="check-circle" :class="{ checked: selectedIds.has(item.id) }">
              <svg v-if="selectedIds.has(item.id)" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
            </div>
          </div>
          <img
            :src="item.coverImage || item.optionImage"
            class="item-img"
            @click="$router.push(`/appstore/mall-detail/${item.productId}`)"
           loading="lazy" />
          <div class="item-info">
            <div class="item-name" @click="$router.push(`/appstore/mall-detail/${item.productId}`)">{{ item.productName }}</div>
            <div class="item-option" v-if="item.optionName">{{ item.optionName }}</div>
            <div class="item-price-row">
              <span class="item-price">¥{{ (item.optionPrice || item.price || 0).toFixed(2) }}</span>
              <div class="qty-control">
                <button class="qty-btn" :disabled="qtyLoading[item.id]" @click="changeQty(item, -1)">-</button>
                <span class="qty-num">{{ item.quantity }}</span>
                <button class="qty-btn" :disabled="qtyLoading[item.id]" @click="changeQty(item, 1)">+</button>
              </div>
            </div>
            <div class="item-bottom">
              <span class="item-subtotal">小计：¥{{ ((item.optionPrice || item.price || 0) * item.quantity).toFixed(2) }}</span>
              <button class="item-del" @click="handleDelete(item)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/></svg>
                删除
              </button>
            </div>
          </div>
        </div>
      </template>
    </div>

    <div class="cart-footer" v-if="list.length && !manageMode">
      <div class="footer-left" @click="toggleAll">
        <div class="check-circle" :class="{ checked: isAllSelected }">
          <svg v-if="isAllSelected" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
        </div>
        <span class="select-all-text">全选</span>
      </div>
      <div class="footer-right">
        <div class="total-info">
          <span class="total-label">合计：</span>
          <span class="total-price">¥{{ totalPrice.toFixed(2) }}</span>
        </div>
        <button
          class="checkout-btn"
          :disabled="selectedIds.size === 0 || checkoutLoading"
          @click="handleCheckout"
        >
          {{ checkoutLoading ? '结算中...' : `结算(${selectedIds.size})` }}
        </button>
      </div>
    </div>

    <div class="cart-footer manage-footer" v-if="list.length && manageMode">
      <button class="delete-selected-btn" :disabled="selectedIds.size === 0" @click="handleDeleteSelected">
        删除选中({{ selectedIds.size }})
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessageBox } from 'element-plus'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const router = useRouter()
const userStore = useUserStore()
const list = ref([])
const loading = ref(true)
const selectedIds = reactive(new Set())
const qtyLoading = reactive({})
const checkoutLoading = ref(false)
const manageMode = ref(false)

const isAllSelected = computed(() => {
  return list.value.length > 0 && list.value.every(item => selectedIds.has(item.id))
})

const totalPrice = computed(() => {
  return list.value
    .filter(item => selectedIds.has(item.id))
    .reduce((sum, item) => sum + (item.optionPrice || item.price || 0) * item.quantity, 0)
})

onMounted(() => fetchList())

async function fetchList() {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/mall/cart' })
    list.value = res?.list || res || []
  } catch (e) {
    console.error(e)
  }
  loading.value = false
}

function toggleSelect(item) {
  if (selectedIds.has(item.id)) {
    selectedIds.delete(item.id)
  } else {
    selectedIds.add(item.id)
  }
}

function toggleAll() {
  if (isAllSelected.value) {
    selectedIds.clear()
  } else {
    list.value.forEach(item => selectedIds.add(item.id))
  }
}

function toggleManage() {
  manageMode.value = !manageMode.value
}

async function changeQty(item, delta) {
  const newQty = item.quantity + delta
  if (newQty < 1) return
  qtyLoading[item.id] = true
  try {
    await request.put({ url: `/api/mall/cart/${item.id}`, data: { quantity: newQty } })
    item.quantity = newQty
  } catch (e) {
    console.error(e)
  }
  qtyLoading[item.id] = false
}

async function handleDelete(item) {
  try {
    await ElMessageBox.confirm(
      `确定删除「${item.productName}」吗？`,
      '确认删除',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
    )
  } catch {
    return
  }
  try {
    await request.del({ url: `/api/mall/cart/${item.id}` })
    selectedIds.delete(item.id)
    list.value = list.value.filter(f => f.id !== item.id)
  } catch (e) {
    alert(e?.msg || '删除失败')
  }
}

async function handleDeleteSelected() {
  if (selectedIds.size === 0) return
  try {
    await ElMessageBox.confirm(
      `确定删除选中的 ${selectedIds.size} 件商品吗？`,
      '确认删除',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
    )
  } catch {
    return
  }
  const cartIds = [...selectedIds]
  try {
    await request.post({ url: '/api/mall/cart/clear', data: { cartIds } })
    list.value = list.value.filter(f => !selectedIds.has(f.id))
    selectedIds.clear()
  } catch (e) {
    alert(e?.msg || '清空失败')
  }
}

function checkLogin() {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return false
  }
  return true
}

async function handleCheckout() {
  if (selectedIds.size === 0) return
  if (!checkLogin()) return
  checkoutLoading.value = true
  try {
    const cartIds = [...selectedIds]
    const res = await request.post({ url: '/api/mall/cart/checkout', data: { cartIds } })
    checkoutLoading.value = false

    const orderId = res?.orderId || res?.id || ''
    const amount = res?.amount || res?.totalAmount || totalPrice.value
    await ElMessageBox.alert(
      `订单已生成！订单ID：${orderId}<br/>支付金额：¥${Number(amount).toFixed(2)}`,
      '下单成功',
      {
        confirmButtonText: '确定',
        dangerouslyUseHTMLString: true,
        type: 'success'
      }
    )
    selectedIds.clear()
    fetchList()
  } catch (e) {
    checkoutLoading.value = false
    alert(e?.msg || '结算失败')
  }
}
</script>

<style scoped>
.cart-page {
  min-height: 100vh;
  background: #f5f6fa;
  display: flex;
  flex-direction: column;
}

.cart-header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #fff;
  gap: 12px;
  position: sticky;
  top: 0;
  z-index: 10;
}
.header-title {
  flex: 1;
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
}
.back-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  background: #f5f5f5;
  border: none;
  border-radius: 10px;
  color: #333;
  cursor: pointer;
}
.manage-btn {
  background: none;
  border: none;
  font-size: 14px;
  color: #FF5722;
  cursor: pointer;
  padding: 6px 8px;
}

.cart-body {
  flex: 1;
  padding: 12px;
  overflow-y: auto;
}

/* 商品卡片 */
.cart-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  background: #fff;
  border-radius: 14px;
  padding: 12px;
  margin-bottom: 10px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
.item-check {
  display: flex;
  align-items: center;
  padding-top: 24px;
  cursor: pointer;
}
.check-circle {
  width: 20px;
  height: 20px;
  border: 2px solid #ddd;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all .2s;
}
.check-circle.checked {
  background: #FF5722;
  border-color: #FF5722;
}
.item-img {
  width: 80px;
  height: 80px;
  border-radius: 10px;
  object-fit: cover;
  flex-shrink: 0;
  cursor: pointer;
}
.item-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.item-name {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a2e;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
}
.item-option {
  font-size: 12px;
  color: #999;
  background: #f5f5f5;
  padding: 2px 8px;
  border-radius: 4px;
  display: inline-block;
  align-self: flex-start;
}
.item-price-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.item-price {
  font-size: 15px;
  font-weight: 700;
  color: #f56c6c;
}
.qty-control {
  display: flex;
  align-items: center;
  gap: 0;
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  overflow: hidden;
}
.qty-btn {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f9f9f9;
  border: none;
  font-size: 16px;
  color: #333;
  cursor: pointer;
  transition: background .15s;
}
.qty-btn:active:not(:disabled) { background: #eee; }
.qty-btn:disabled { color: #ccc; cursor: not-allowed; }
.qty-num {
  width: 32px;
  text-align: center;
  font-size: 14px;
  font-weight: 600;
  color: #333;
}
.item-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.item-subtotal {
  font-size: 12px;
  color: #999;
}
.item-del {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #fef2f2;
  color: #EF4444;
  border: none;
  border-radius: 8px;
  padding: 5px 10px;
  font-size: 12px;
  cursor: pointer;
  transition: all .15s;
}
.item-del:active { background: #fee2e2; }

/* 底部结算栏 */
.cart-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  box-shadow: 0 -1px 6px rgba(0,0,0,0.06);
  z-index: 10;
}
.cart-footer.manage-footer {
  justify-content: center;
}
.footer-left {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}
.select-all-text {
  font-size: 14px;
  color: #333;
}
.footer-right {
  display: flex;
  align-items: center;
  gap: 12px;
}
.total-info {
  display: flex;
  align-items: baseline;
}
.total-label {
  font-size: 13px;
  color: #666;
}
.total-price {
  font-size: 18px;
  font-weight: 700;
  color: #f56c6c;
}
.checkout-btn {
  background: linear-gradient(135deg, #FF5722, #FF8A65);
  color: #fff;
  border: none;
  border-radius: 20px;
  padding: 10px 22px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 2px 10px rgba(255,87,34,0.25);
  transition: all .2s;
  white-space: nowrap;
}
.checkout-btn:active:not(:disabled) { transform: scale(0.98); opacity: 0.9; }
.checkout-btn:disabled { background: #ccc; box-shadow: none; cursor: not-allowed; }
.delete-selected-btn {
  width: 100%;
  background: #EF4444;
  color: #fff;
  border: none;
  border-radius: 12px;
  padding: 12px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all .2s;
}
.delete-selected-btn:active:not(:disabled) { opacity: 0.9; }
.delete-selected-btn:disabled { background: #ccc; cursor: not-allowed; }

/* 空/加载状态 */
.empty-state {
  text-align: center;
  padding: 80px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.empty-state p {
  font-size: 15px;
  color: #999;
  margin: 0;
  margin-top: 4px;
}
.empty-state span {
  font-size: 12px;
  color: #ccc;
}
.go-shop-btn {
  margin-top: 8px;
  background: linear-gradient(135deg, #FF5722, #FF8A65);
  color: #fff;
  border: none;
  border-radius: 20px;
  padding: 10px 28px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 2px 10px rgba(255,87,34,0.25);
}
.loading-state {
  text-align: center;
  padding: 80px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.loading-state p {
  font-size: 14px;
  color: #999;
  margin: 0;
}
.loading-ring {
  width: 30px;
  height: 30px;
  border: 3px solid #f0f0f0;
  border-top-color: #FF5722;
  border-radius: 50%;
  animation: spin .8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
