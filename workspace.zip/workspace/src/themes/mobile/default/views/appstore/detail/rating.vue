<template>
  <div class="rating-detail-page art-full-height p-4">
    <div class="flex items-center gap-3 mb-6">
      <el-button link @click="$router.back()">
        <i class="ri-arrow-left-line mr-1" /> 返回
      </el-button>
      <h3 class="text-base font-bold">{{ appName }} - 评分详情</h3>
    </div>

    <el-row :gutter="16" v-loading="loading">
      <el-col :xs="24" :sm="12">
        <el-card class="mb-4">
          <template #header>
            <div class="flex items-center justify-between">
              <span class="font-bold">评分分布</span>
              <span class="text-sm text-gray-500">共 {{ ratingStats.total }} 条评价</span>
            </div>
          </template>
          <div class="space-y-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl font-bold text-orange-500">{{ ratingStats.average }}</span>
              <el-rate v-model="ratingStats.average" disabled show-score text-color="#ff9900" />
            </div>
            <div v-for="star in 5" :key="star" class="flex items-center gap-3">
              <span class="w-8 text-sm text-gray-600">{{ 6 - star }}星</span>
              <el-progress
                :percentage="getStarPercent(6 - star)"
                :color="starColors[6 - star]"
                :stroke-width="12"
                class="flex-1"
              />
              <span class="w-8 text-xs text-gray-400 text-right">{{ getStarCount(6 - star) }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12">
        <div ref="chartRef" class="w-full h-[300px]"></div>
      </el-col>
    </el-row>

    <el-card class="mt-4">
      <template #header>
        <span class="font-bold">最新评价</span>
      </template>
      <div v-if="reviews.length === 0">
        <el-empty description="暂无评价" />
      </div>
      <div v-else class="space-y-3">
        <div v-for="item in reviews" :key="item.id" class="border-b border-gray-100 pb-3 last:border-none">
          <div class="flex items-center gap-3 mb-1">
            <el-avatar :size="32">{{ item.userName?.charAt(0) || '匿' }}</el-avatar>
            <div class="flex-1">
              <div class="flex items-center gap-2">
                <span class="text-sm font-medium">{{ item.userName || '匿名用户' }}</span>
                <el-rate v-model="item.rating" disabled size="small" />
              </div>
              <span class="text-xs text-gray-400">{{ item.createTime }}</span>
            </div>
          </div>
          <p class="text-sm text-gray-700 ml-11">{{ item.content }}</p>
        </div>
      </div>
      <div class="flex justify-center mt-4">
        <el-pagination
          v-model:current-page="reviewPage"
          :page-size="reviewPageSize"
          :total="reviewTotal"
          layout="prev, pager, next"
          @current-change="loadReviews"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import * as echarts from 'echarts'

const route = useRoute()
const appId = route.params.id as string
const appName = ref('')
const loading = ref(false)
const chartRef = ref<HTMLElement>()

const starColors: Record<number, string> = {
  5: '#f56c6c',
  4: '#e6a23c',
  3: '#f7ba2a',
  2: '#67c23a',
  1: '#909399'
}

const ratingStats = reactive({
  total: 0,
  average: 0,
  distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
})

const reviews = ref<any[]>([])
const reviewPage = ref(1)
const reviewPageSize = ref(10)
const reviewTotal = ref(0)

function getStarCount(star: number) {
  return ratingStats.distribution[star as keyof typeof ratingStats.distribution] || 0
}

function getStarPercent(star: number) {
  if (ratingStats.total === 0) return 0
  return Math.round((getStarCount(star) / ratingStats.total) * 100)
}

function renderChart() {
  if (!chartRef.value) return
  const chart = echarts.init(chartRef.value)
  chart.setOption({
    tooltip: { trigger: 'item' },
    series: [{
      name: '评分分布',
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}: {c}条\n({d}%)' },
      data: [5, 4, 3, 2, 1].map(s => ({
        value: getStarCount(s),
        name: `${s}星`,
        itemStyle: { color: starColors[s] }
      })).filter(d => d.value > 0)
    }]
  })
}

async function loadData() {
  loading.value = true
  try {
    const res = await fetch(`/api/appstore/${appId}/ratings?page=${reviewPage.value}&pageSize=${reviewPageSize.value}`)
    const json = await res.json()
    if (json.code === 200) {
      const data = json.data
      if (data.appName) appName.value = data.appName
      Object.assign(ratingStats, data.ratingStats)
      reviews.value = data.reviews || []
      reviewTotal.value = data.total || 0
      await nextTick()
      renderChart()
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

async function loadReviews() {
  loadData()
}

onMounted(() => {
  loadData()
})
</script>
