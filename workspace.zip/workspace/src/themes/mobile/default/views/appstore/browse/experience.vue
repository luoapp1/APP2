<template>
  <div style="min-height: 100vh; background: var(--app-page-bg);">
    <div style="background: #fff; padding: 12px 16px; display: flex; align-items: center; gap: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">我的经验</span>
    </div>

    <div style="padding: 16px;" v-if="isLogin">
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 16px; padding: 24px; color: #fff; margin-bottom: 16px;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
          <img v-if="currentLevel.icon" :src="$fixImgUrl(currentLevel.icon)" style="width: 40px; height: 40px; object-fit: contain;"  loading="lazy" />
          <div>
            <div style="font-size: 22px; font-weight: 700;">{{ currentLevel.name || 'Lv.1' }}</div>
            <div style="font-size: 13px; opacity: 0.85;">{{ userExp }}/{{ nextExp }}</div>
          </div>
        </div>
        <div style="background: rgba(255,255,255,0.2); border-radius: 999px; height: 8px; overflow: hidden; margin-bottom: 8px;">
          <div :style="{ width: expPercent + '%', height: '100%', background: '#fff', borderRadius: '999px', transition: 'width .3s' }" />
        </div>
        <div style="font-size: 13px; opacity: 0.9;">升级还需{{ expRemain }}经验</div>
      </div>

      <div style="background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 16px; display: flex; align-items: center; gap: 12px;">
        <div style="width: 44px; height: 44px; border-radius: 12px; background: #f0f5ff; display: flex; align-items: center; justify-content: center;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"/></svg>
        </div>
        <div>
          <div style="font-size: 12px; color: #999;">我的经验值</div>
          <div style="font-size: 20px; font-weight: 700; color: #333;">{{ userExp }}</div>
        </div>
        <div style="margin-left: auto; text-align: center;">
          <div style="font-size: 12px; color: #999;">今日</div>
          <div style="font-size: 18px; font-weight: 700; color: #409EFF;">+{{ todayExp }}</div>
        </div>
      </div>

      <div style="background: linear-gradient(135deg, #f5f3ff 0%, #fdf2f8 50%, #f0f5ff 100%); border-radius: 20px; padding: 20px 16px 16px; margin-bottom: 16px; position: relative; overflow: hidden;">
        <div style="position: absolute; top: -40px; left: -20px; width: 120px; height: 120px; border-radius: 50%; background: rgba(167,139,250,0.08); pointer-events: none;" />
        <div style="position: absolute; top: -30px; right: -30px; width: 100px; height: 100px; border-radius: 50%; background: rgba(249,168,212,0.08); pointer-events: none;" />
        <div style="position: absolute; bottom: -50px; left: 40%; width: 160px; height: 80px; border-radius: 50%; background: rgba(167,139,250,0.06); pointer-events: none;" />

        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; position: relative; z-index: 1;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 36px; height: 36px; border-radius: 10px; background: linear-gradient(135deg, #8b5cf6, #a78bfa); display: flex; align-items: center; justify-content: center;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <div>
              <div style="font-size: 15px; font-weight: 600; color: #1f2937; line-height: 1.3;">成长体系</div>
              <div style="font-size: 11px; color: #9ca3af;">我的经验值: {{ userExp }}</div>
            </div>
          </div>
          <div style="font-size: 12px; color: #a78bfa; display: flex; align-items: center; gap: 2px; flex-shrink: 0;">
            今日 +{{ todayExp }} <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>

        <div style="overflow-x: auto; padding-bottom: 4px; position: relative; z-index: 1; -webkit-overflow-scrolling: touch;">
          <div style="display: flex; align-items: flex-end; gap: 0; min-width: max-content; padding: 0 8px;">
            <div v-for="(lv, idx) in levels" :key="lv.level" style="flex-shrink: 0; width: 80px; display: flex; flex-direction: column; align-items: center; position: relative;">
              <div :style="{ fontSize: '10px', color: lv.level <= currentLevel.level ? '#6d28d9' : '#c4b5fd', fontWeight: lv.level === currentLevel.level ? 700 : 500, marginBottom: '6px', transition: 'color .3s' }">
                {{ lv.expRequired || lv.exp_required || 0 }}
              </div>
              <div style="position: relative; width: 100%; display: flex; flex-direction: column; align-items: center;">
                <div :style="{ width: '2px', height: '16px', borderRadius: '1px', background: lv.level <= currentLevel.level ? '#8b5cf6' : '#e5e7eb', transition: 'background .3s' }" />
                <div style="width: 10px; height: 10px; border-radius: 50%; border: 2px solid #fff; margin-top: -5px; box-shadow: 0 1px 2px rgba(0,0,0,0.1);" :style="{ background: lv.level <= currentLevel.level ? '#8b5cf6' : '#d1d5db' }" />
                <div v-if="idx < levels.length - 1" :style="{ position: 'absolute', top: '28px', left: '50%', width: '80px', height: '2px', background: lv.level < currentLevel.level ? '#8b5cf6' : '#e5e7eb', transition: 'background .3s' }" />
              </div>
              <div :style="{
                marginTop: '8px',
                opacity: lv.level <= currentLevel.level ? 1 : 0.35,
                transform: lv.level === currentLevel.level ? 'scale(1.2)' : 'scale(1)',
                transition: 'all .3s'
              }">
                <img v-if="lv.icon" :src="$fixImgUrl(lv.icon)" style="width: 36px; height: 36px; object-fit: contain;"  loading="lazy" />
                <span v-else style="font-size: 20px; color: #8b5cf6; font-weight: 700;">◆</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style="background: #fff; border-radius: 12px; padding: 16px;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
          <div style="font-size: 15px; font-weight: 600; color: #333;">积分任务</div>
          <div style="font-size: 12px; color: #999;">今日累计 <span style="color: #409EFF; font-weight: 600;">+{{ todayPoints }}</span></div>
        </div>
        <div style="font-size: 11px; color: #bbb; margin-bottom: 12px;">每日可免费获取{{ dailyMaxPoints }}积分，超过后将不再获取</div>
        <div v-for="(task, idx) in pointTasks" :key="idx" style="display: flex; align-items: center; gap: 12px; padding: 12px 0; border-top: 1px solid #f5f5f5;">
          <div style="width: 36px; height: 36px; border-radius: 10px; background: #f0f5ff; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0;">{{ task.emoji }}</div>
          <div style="flex: 1;">
            <div style="font-size: 13px; font-weight: 500; color: #333;">{{ task.name }}</div>
            <div style="display: flex; align-items: center; gap: 6px; margin-top: 4px;">
              <div style="flex: 1; height: 4px; background: #f3f4f6; border-radius: 999px; overflow: hidden;">
                <div :style="{ width: (task.done / task.max * 100) + '%', height: '100%', background: task.done >= task.max ? '#10b981' : '#409EFF', borderRadius: '999px', transition: 'width .3s' }" />
              </div>
              <span style="font-size: 11px; color: #999; flex-shrink: 0;">{{ task.done }}/{{ task.max }}</span>
            </div>
          </div>
          <div style="text-align: right; flex-shrink: 0;">
            <div style="font-size: 13px; font-weight: 700; color: #f59e0b;">+{{ task.points_reward }}积分</div>
            <div style="font-size: 11px; font-weight: 600; color: #409EFF;">+{{ task.exp_reward }}经验</div>
          </div>
        </div>
      </div>
    </div>

    <div v-else style="text-align: center; padding: 80px 16px; color: #999;">
      <p>请先登录后查看经验详情</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchExpLevelList } from '@/api/operation'
import { fetchMyTasks } from '@/api/task'

defineOptions({ name: 'AppStoreExperience' })

const router = useRouter()
const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)

watch(isLogin, (val) => {
  if (!val) router.replace('/appstore/browse/login')
}, { immediate: true })
const levels = ref<any[]>([])
const currentLevel = ref<any>({})
const todayExp = ref(0)
const nextExp = ref(0)

const todayPoints = ref(0)
const dailyMaxPoints = ref(0)
const pointTasks = ref<any[]>([])

const userExp = computed(() => userStore.info?.experience || 0)
const expRemain = computed(() => Math.max(0, nextExp.value - userExp.value))
const expPercent = computed(() => {
  if (!nextExp.value) return 0
  const prevExp = currentLevel.value.expRequired || currentLevel.value.exp_required || 0
  const range = nextExp.value - prevExp
  if (range <= 0) return 100
  return Math.min(100, Math.round(((userExp.value - prevExp) / range) * 100))
})

function actionEmoji(type: string) {
  const m: Record<string, string> = {
    like: '👍', comment: '💬', post: '📋', checkin: '🎯',
    share: '📤', follow: '👥', favorite: '⭐', download: '📥',
    register: '🎉', profile: '👤', view_post: '👀', purchase: '🛒',
    upload: '📎', invite: '🤝',
  }
  return m[type] || '📌'
}

function levelBadgeBg(level: number, currentLevel: number) {
  if (level > currentLevel) return '#d1d5db'
  const colors = [
    'linear-gradient(135deg, #a78bfa, #8b5cf6)',
    'linear-gradient(135deg, #f472b6, #ec4899)',
    'linear-gradient(135deg, #fbbf24, #f59e0b)',
    'linear-gradient(135deg, #fb923c, #f97316)',
    'linear-gradient(135deg, #60a5fa, #3b82f6)',
    'linear-gradient(135deg, #a78bfa, #7c3aed)',
    'linear-gradient(135deg, #34d399, #10b981)',
    'linear-gradient(135deg, #f87171, #ef4444)',
  ]
  return colors[(level - 1) % colors.length]
}

async function loadTasks() {
  try {
    const uid = userStore.info?.userId
    if (!uid) return
    const tasks: any = await fetchMyTasks(uid)
    const list = tasks?.data || tasks || []
    pointTasks.value = list
      .filter((t: any) => t.task_type === 'daily')
      .map((t: any) => ({
        ...t,
        emoji: actionEmoji(t.action_type),
        done: t.progress || 0,
        max: t.target_count || 1,
      }))
    let total = 0
    let earned = 0
    let earnedExp = 0
    pointTasks.value.forEach((t: any) => {
      total += (t.points_reward || 0)
      if (t.done >= t.max) {
        earned += (t.points_reward || 0)
        earnedExp += (t.exp_reward || 0)
      }
    })
    dailyMaxPoints.value = total
    todayPoints.value = earned
    todayExp.value = earnedExp
  } catch (_e) { void _e }
}

async function loadData() {
  try {
    const data: any = await fetchExpLevelList()
    const list = data?.records || data || []
    if (list.length > 0) {
      const sorted = [...list].sort((a: any, b: any) => (a.level || 0) - (b.level || 0)).map((lv: any) => {
        if (lv.icon && !(lv.icon.startsWith('http') || lv.icon.startsWith('/') || lv.icon.startsWith('data:'))) {
          return { ...lv, icon: '' }
        }
        return lv
      })
      levels.value = sorted
      const exp = userExp.value
      let cur = sorted[0]
      let nxt: any = null
      for (const l of sorted) {
        const req = l.expRequired || l.exp_required || 0
        if (req <= exp) cur = l
        if (req > exp && !nxt) nxt = l
      }
      currentLevel.value = cur
      nextExp.value = nxt ? (nxt.expRequired || nxt.exp_required || 0) : (cur.expRequired || cur.exp_required || 0) + 1000
    }
  } catch (_e) { void _e }
}

onMounted(() => {
  if (isLogin.value) {
    loadData()
    loadTasks()
  }
})
</script>
