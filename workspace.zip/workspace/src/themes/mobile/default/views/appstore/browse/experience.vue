<template>
  <div :style="compareMode ? 'position:fixed;inset:0;z-index:100;display:flex;flex-direction:column;background:var(--app-page-bg);' : 'min-height:100vh;background:var(--app-page-bg);'">
    <div style="background:#fff;padding:12px 16px;display:flex;align-items:center;gap:12px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
      <div @click="compareMode ? compareMode = false : $router.back()" style="cursor:pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size:17px;font-weight:600;color:#222;">{{ compareMode ? '权益对比' : '我的经验' }}</span>
      <button v-if="!compareMode" style="margin-left:auto;font-size:12px;color:#667eea;background:#f0f3ff;border:none;border-radius:999px;padding:5px 14px;font-weight:500;" @click="openCompare">权益对比</button>
    </div>

    <!-- 普通模式 -->
    <div v-if="!compareMode" style="padding:16px;" v-show="isLogin">
      <div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);border-radius:16px;padding:24px;color:#fff;margin-bottom:16px;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
          <img v-if="currentLevel.icon" :src="$fixImgUrl(currentLevel.icon)" style="width:40px;height:40px;object-fit:contain;" loading="lazy" />
          <div>
            <div style="font-size:22px;font-weight:700;">{{ currentLevel.name || 'Lv.1' }}</div>
            <div style="font-size:13px;opacity:0.85;">{{ userExp }}/{{ nextExp }}</div>
          </div>
        </div>
        <div style="background:rgba(255,255,255,0.2);border-radius:999px;height:8px;overflow:hidden;margin-bottom:8px;">
          <div :style="{ width: expPercent + '%', height: '100%', background: '#fff', borderRadius: '999px', transition: 'width .3s' }"></div>
        </div>
        <div style="font-size:13px;opacity:0.9;">升级还需{{ expRemain }}经验</div>
      </div>

      <div style="background:#fff;border-radius:12px;padding:16px;margin-bottom:16px;display:flex;align-items:center;gap:12px;">
        <div style="width:44px;height:44px;border-radius:12px;background:#f0f5ff;display:flex;align-items:center;justify-content:center;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"/></svg>
        </div>
        <div>
          <div style="font-size:12px;color:#999;">我的经验值</div>
          <div style="font-size:20px;font-weight:700;color:#333;">{{ userExp }}</div>
        </div>
        <div style="margin-left:auto;text-align:center;">
          <div style="font-size:12px;color:#999;">今日</div>
          <div style="font-size:18px;font-weight:700;color:#409EFF;">+{{ todayExp }}</div>
        </div>
      </div>

      <div style="background:linear-gradient(135deg,#f5f3ff 0%,#fdf2f8 50%,#f0f5ff 100%);border-radius:20px;padding:20px 16px 16px;margin-bottom:16px;position:relative;overflow:hidden;">
        <div style="position:absolute;top:-40px;left:-20px;width:120px;height:120px;border-radius:50%;background:rgba(167,139,250,0.08);pointer-events:none;"></div>
        <div style="position:absolute;top:-30px;right:-30px;width:100px;height:100px;border-radius:50%;background:rgba(249,168,212,0.08);pointer-events:none;"></div>
        <div style="position:absolute;bottom:-50px;left:40%;width:160px;height:80px;border-radius:50%;background:rgba(167,139,250,0.06);pointer-events:none;"></div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;position:relative;z-index:1;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#8b5cf6,#a78bfa);display:flex;align-items:center;justify-content:center;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <div>
              <div style="font-size:15px;font-weight:600;color:#1f2937;line-height:1.3;">成长体系</div>
              <div style="font-size:11px;color:#9ca3af;">我的经验值: {{ userExp }}</div>
            </div>
          </div>
          <div style="font-size:12px;color:#a78bfa;display:flex;align-items:center;gap:2px;flex-shrink:0;">今日 +{{ todayExp }} <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M9 18l6-6-6-6"/></svg></div>
        </div>
        <div style="overflow-x:auto;padding-bottom:4px;position:relative;z-index:1;-webkit-overflow-scrolling:touch;">
          <div style="display:flex;align-items:flex-end;gap:0;min-width:max-content;padding:0 8px;">
            <div v-for="(lv, idx) in levels" :key="lv.level" style="flex-shrink:0;width:80px;display:flex;flex-direction:column;align-items:center;position:relative;">
              <div :style="{ fontSize:'10px', color:lv.level<=currentLevel.level?'#6d28d9':'#c4b5fd', fontWeight:lv.level===currentLevel.level?700:500, marginBottom:'6px', transition:'color .3s' }">{{ lv.expRequired || lv.exp_required || 0 }}</div>
              <div style="position:relative;width:100%;display:flex;flex-direction:column;align-items:center;">
                <div :style="{ width:'2px',height:'16px',borderRadius:'1px',background:lv.level<=currentLevel.level?'#8b5cf6':'#e5e7eb',transition:'background .3s' }"></div>
                <div style="width:10px;height:10px;border-radius:50%;border:2px solid #fff;margin-top:-5px;box-shadow:0 1px 2px rgba(0,0,0,0.1);" :style="{ background: lv.level<=currentLevel.level?'#8b5cf6':'#d1d5db' }"></div>
                <div v-if="idx<levels.length-1" :style="{ position:'absolute',top:'28px',left:'50%',width:'80px',height:'2px',background:lv.level<currentLevel.level?'#8b5cf6':'#e5e7eb',transition:'background .3s' }"></div>
              </div>
              <div :style="{ marginTop:'8px',opacity:lv.level<=currentLevel.level?1:0.35,transform:lv.level===currentLevel.level?'scale(1.2)':'scale(1)',transition:'all .3s' }">
                <div v-if="lv.icon" style="height:38px;display:flex;align-items:center;justify-content:center;">
                  <img :src="$fixImgUrl(lv.icon)" style="width:36px;height:36px;object-fit:contain;" loading="lazy" />
                </div>
                <span v-else style="font-size:20px;color:#8b5cf6;font-weight:700;">&#9670;</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style="background:#fff;border-radius:12px;padding:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="font-size:15px;font-weight:600;color:#333;">积分任务</div>
          <div style="font-size:12px;color:#999;">今日累计 <span style="color:#409EFF;font-weight:600;">+{{ todayPoints }}</span></div>
        </div>
        <div style="font-size:11px;color:#bbb;margin-bottom:12px;">每日可免费获取{{ dailyMaxPoints }}积分，超过后将不再获取</div>
        <div v-for="(task, idx) in pointTasks" :key="idx" style="display:flex;align-items:center;gap:12px;padding:12px 0;border-top:1px solid #f5f5f5;">
          <div style="width:36px;height:36px;border-radius:10px;background:#f0f5ff;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">{{ task.emoji }}</div>
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:500;color:#333;">{{ task.name }}</div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
              <div style="flex:1;height:4px;background:#f3f4f6;border-radius:999px;overflow:hidden;">
                <div :style="{ width:(task.done/task.max*100)+'%',height:'100%',background:task.done>=task.max?'#10b981':'#409EFF',borderRadius:'999px',transition:'width .3s' }"></div>
              </div>
              <span style="font-size:11px;color:#999;flex-shrink:0;">{{ task.done }}/{{ task.max }}</span>
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-size:13px;font-weight:700;color:#f59e0b;">+{{ task.points_reward }}积分</div>
            <div style="font-size:11px;font-weight:600;color:#409EFF;">+{{ task.exp_reward }}经验</div>
          </div>
        </div>
      </div>

      <div v-if="penaltyTasks.length>0" style="background:#fff;border-radius:12px;padding:16px;margin-top:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:6px;">
            <span style="font-size:15px;font-weight:600;color:#333;">违规扣分规则</span>
            <span style="font-size:10px;color:#fff;background:#FF4757;border-radius:4px;padding:1px 6px;">{{ penaltyTasks.length }}项</span>
          </div>
        </div>
        <div style="font-size:11px;color:#bbb;margin-bottom:12px;">以下行为会扣除经验值，请遵守社区规范</div>
        <div v-for="(task, idx) in penaltyTasks" :key="idx" style="display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid #fef0f0;">
          <div style="width:32px;height:32px;border-radius:8px;background:#fff5f5;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">⚠️</div>
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:500;color:#333;">{{ task.name }}</div>
            <div style="font-size:11px;color:#999;margin-top:2px;">{{ task.description || '' }}</div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <template v-if="task._penaltyDetail">
              <div v-for="(d,i) in task._penaltyDetail" :key="i" style="font-size:11px;color:#FF4757;font-weight:600;">{{ d }}</div>
            </template>
            <div v-else style="font-size:13px;font-weight:700;color:#FF4757;">-{{ task.exp_reward || 0 }}经验</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 权益对比 -->
    <div v-if="compareMode" style="flex:1;display:flex;flex-direction:column;overflow:hidden;min-height:0;">
      <div v-if="compLoading" style="text-align:center;padding:48px 16px;color:#999;">加载中...</div>
      <div v-else-if="compLevels.length>0" style="flex:1;display:flex;flex-direction:column;overflow:hidden;">
          <div style="display:flex;flex-shrink:0;background:#fff;border-bottom:1px solid #e8e8e8;overflow:hidden;">
            <div style="width:110px;flex-shrink:0;padding:10px 12px;font-size:11px;color:#999;border-right:1px solid #f0f0f0;box-sizing:border-box;">权益项</div>
            <div ref="topScrollRef" style="flex:1;overflow:hidden;">
              <div :style="{ transform: 'translateX(-'+topScrollX+'px)' }" style="display:flex;min-width:max-content;">
                <div v-for="lv in compLevels" :key="lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;text-align:center;position:relative;box-sizing:border-box;" :style="{ background: lv.level===compOwnLevel ? '#ede9fe' : '#fff' }">
                  <div v-if="lv.level===compOwnLevel" style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#8b5cf6,#a78bfa);"></div>
                  <div style="height:22px;display:flex;align-items:center;justify-content:center;">
                    <img v-if="lv.icon" :src="$fixImgUrl(lv.icon)" style="width:20px;height:20px;object-fit:contain;" />
                  </div>
                  <div style="font-size:11px;font-weight:700;color:#6d28d9;margin-top:1px;">Lv.{{ lv.level }}</div>
                  <div style="font-size:8px;color:#bbb;">{{ formatExp(lv.expRequired||0) }}</div>
                </div>
            </div>
          </div>
          </div>
          <div ref="mainScrollRef" @scroll="onDataScroll" style="flex:1;overflow:auto;">
            <div style="display:flex;background:#f3f0ff;min-width:max-content;">
              <div style="width:110px;flex-shrink:0;position:sticky;left:0;z-index:1;background:#f3f0ff;padding:6px 12px;font-size:11px;font-weight:700;color:#7c3aed;box-sizing:border-box;">礼包</div>
              <div v-for="lv in compLevels" :key="'gh-'+lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;background:#fdfcff;box-sizing:border-box;"></div>
            </div>
            <div style="display:flex;min-width:max-content;">
              <div style="width:110px;flex-shrink:0;position:sticky;left:0;z-index:1;background:#fff;padding:8px 12px;font-size:11px;color:#555;box-sizing:border-box;border-bottom:1px solid #f5f5f5;">首次等级礼包</div>
              <div v-for="lv in compLevels" :key="'fg-'+lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;text-align:center;box-sizing:border-box;border-bottom:1px solid #f5f5f5;" :style="{ background: lv.level===compOwnLevel ? '#faf8ff' : '#fff' }">
                <span v-if="hasFirstGift(lv)" @click.stop="showGiftPopup(lv)" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:#ecfdf5;cursor:pointer;" title="点击查看详情">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                </span>
                <span v-else style="color:#ddd;font-size:12px;">-</span>
              </div>
            </div>
            <div style="display:flex;min-width:max-content;">
              <div style="width:110px;flex-shrink:0;position:sticky;left:0;z-index:1;background:#fff;padding:8px 12px;font-size:11px;color:#555;box-sizing:border-box;border-bottom:1px solid #f5f5f5;">定时礼包</div>
              <div v-for="lv in compLevels" :key="'dg-'+lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;text-align:center;box-sizing:border-box;border-bottom:1px solid #f5f5f5;" :style="{ background: lv.level===compOwnLevel ? '#faf8ff' : '#fff' }">
                <span v-if="hasDailyGift(lv)" @click.stop="showGiftPopup(lv)" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:#ecfdf5;cursor:pointer;" title="点击查看详情">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                </span>
                <span v-else style="color:#ddd;font-size:12px;">-</span>
              </div>
            </div>
            <template v-for="(group, mod) in compGrouped" :key="mod">
              <div style="display:flex;background:#f3f0ff;min-width:max-content;">
                <div style="width:110px;flex-shrink:0;position:sticky;left:0;z-index:1;background:#f3f0ff;padding:6px 12px;font-size:11px;font-weight:700;color:#7c3aed;box-sizing:border-box;">{{ modLabel(mod) }}</div>
                <div v-for="lv in compLevels" :key="lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;background:#fdfcff;box-sizing:border-box;"></div>
              </div>
              <div v-for="p in group" :key="p.permissionKey" style="display:flex;min-width:max-content;">
                <div style="width:110px;flex-shrink:0;position:sticky;left:0;z-index:1;background:#fff;padding:6px 12px;font-size:11px;color:#555;box-sizing:border-box;border-bottom:1px solid #f5f5f5;">{{ p.permissionName }}</div>
                <div v-for="lv in compLevels" :key="lv.level" style="width:72px;flex-shrink:0;padding:6px 2px;text-align:center;box-sizing:border-box;border-bottom:1px solid #f5f5f5;" :style="{ background: lv.level===compOwnLevel ? '#faf8ff' : '#fff' }">
                  <template v-if="p.permissionKey==='G1'||p.permissionKey==='G2'">
                    <span v-if="p.levelValues[lv.level]&&p.levelValues[lv.level]!=='false'&&p.levelValues[lv.level]!==''" style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:#ecfdf5;">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </span>
                    <span v-else style="color:#ddd;font-size:12px;">-</span>
                  </template>
                  <template v-else-if="isBoolPerm(p.permissionKey)">
                    <span v-if="p.levelValues[lv.level]==='true'" style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:#ecfdf5;">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </span>
                    <span v-else style="color:#ddd;font-size:12px;">-</span>
                  </template>
                  <template v-else>
                    <span style="font-size:11px;font-weight:600;" :style="{ color:(p.levelValues[lv.level]||'')===''?'#ddd':'#6d28d9' }">{{ (p.levelValues[lv.level]||'')===''?'-':p.levelValues[lv.level] }}</span>
                  </template>
                </div>
              </div>
            </template>
          </div>
      </div>
      <div v-else style="text-align:center;padding:48px 16px;color:#999;">暂无数据</div>

      <!-- 礼包详情弹窗 -->
      <teleport to="body">
        <div v-if="giftPopupLevel" style="position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;" @click.self="giftPopupLevel=null">
          <div style="position:absolute;inset:0;background:rgba(0,0,0,0.45);"></div>
          <div style="position:relative;background:#fff;border-radius:16px;width:calc(100vw - 48px);max-width:360px;padding:24px 20px 20px;box-shadow:0 8px 32px rgba(0,0,0,0.12);">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
              <img v-if="giftPopupLevel.icon" :src="$fixImgUrl(giftPopupLevel.icon)" style="width:32px;height:32px;object-fit:contain;" />
              <div>
                <div style="font-size:17px;font-weight:700;color:#1f2937;">{{ giftPopupLevel.name || 'Lv.'+giftPopupLevel.level }} 礼包详情</div>
                <div style="font-size:12px;color:#9ca3af;">经验要求: {{ formatExp(giftPopupLevel.expRequired) }}</div>
              </div>
              <button @click="giftPopupLevel=null" style="margin-left:auto;border:none;background:none;font-size:20px;color:#bbb;cursor:pointer;padding:4px 8px;line-height:1;">&times;</button>
            </div>
            <div v-if="hasFirstGift(giftPopupLevel)" style="background:linear-gradient(135deg,#f0fdf4,#ecfdf5);border-radius:12px;padding:14px;margin-bottom:12px;">
              <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-9 9-4-4"/></svg>
                <span style="font-size:14px;font-weight:600;color:#065f46;">首次到达礼包</span>
              </div>
              <div style="font-size:13px;color:#374151;display:flex;flex-wrap:wrap;gap:4px 12px;">
                <template v-for="(val, key) in giftPopupCurrencies" :key="'fg-'+key">
                  <span v-if="Number(val)>0" :style="{ color: '#374151' }">{{ val }} {{ getCurrencyLabel(key) }}</span>
                </template>
                <span v-if="!giftPopupCurrencies || Object.keys(giftPopupCurrencies).every(k=>Number(giftPopupCurrencies[k])<=0)" style="color:#9ca3af;">该等级暂无首次礼包</span>
              </div>
            </div>
            <div v-else style="background:#f9fafb;border-radius:12px;padding:14px;margin-bottom:12px;text-align:center;color:#9ca3af;font-size:13px;">该等级暂无首次礼包</div>
            <div v-if="hasDailyGift(giftPopupLevel)" style="background:linear-gradient(135deg,#faf5ff,#f3e8ff);border-radius:12px;padding:14px;">
              <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"/></svg>
                <span style="font-size:14px;font-weight:600;color:#5b21b6;">定时礼包 (每{{ giftPopupLevel.dailyGiftIntervalDays }}天)</span>
              </div>
              <div style="font-size:13px;color:#374151;display:flex;flex-wrap:wrap;gap:4px 12px;">
                <template v-for="(val, key) in giftPopupDailyCurrencies" :key="'dg-'+key">
                  <span v-if="Number(val)>0" :style="{ color: '#374151' }">{{ val }} {{ getCurrencyLabel(key) }}</span>
                </template>
                <span v-if="!giftPopupDailyCurrencies || Object.keys(giftPopupDailyCurrencies).every(k=>Number(giftPopupDailyCurrencies[k])<=0)" style="color:#9ca3af;">该等级暂无定时礼包</span>
              </div>
            </div>
            <div v-else style="background:#f9fafb;border-radius:12px;padding:14px;text-align:center;color:#9ca3af;font-size:13px;">该等级暂无定时礼包</div>
          </div>
        </div>
      </teleport>
    </div>

    <div v-if="!isLogin&&!compareMode" style="text-align:center;padding:80px 16px;color:#999;"><p>请先登录后查看经验详情</p></div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

defineOptions({ name: 'AppStoreExperience' })

const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)

const levels = ref<any[]>([])
const currentLevel = ref<any>({})
const todayExp = ref(0)
const nextExp = ref(0)
const pointTasks = ref<any[]>([])
const penaltyTasks = ref<any[]>([])

const actionEmoji: Record<string, string> = {
  checkin: '📅', post: '📝', comment: '💬', like: '❤️', share: '📤',
  download: '📥', register: '🎉', follow: '👥', favorite: '⭐', purchase: '🛒',
  upload: '🎨', invite: '✉️', profile: '👤', view_post: '👀'
}
const todayPoints = ref(0)
const dailyMaxPoints = ref(1000)

const userExp = computed(() => userStore.info?.experience || 0)
const expRemain = computed(() => Math.max(0, nextExp.value - userExp.value))
const expPercent = computed(() => {
  if (!nextExp.value) return 0
  const prevExp = currentLevel.value.expRequired || 0
  const range = nextExp.value - prevExp
  if (range <= 0) return 100
  return Math.min(100, Math.round(((userExp.value - prevExp) / range) * 100))
})

const compareMode = ref(false)
const compLoading = ref(false)
const compLevels = ref<any[]>([])
const compPermissions = ref<any[]>([])
const compOwnLevel = ref(0)
const giftPopupLevel = ref<any>(null)
const giftPopupCurrencies = computed(() => {
  if (!giftPopupLevel.value) return {}
  const lv = giftPopupLevel.value
  if (lv.giftCurrencies) {
    const gc = typeof lv.giftCurrencies === 'string' ? JSON.parse(lv.giftCurrencies) : lv.giftCurrencies
    if (gc && Object.keys(gc).some(k => Number(gc[k]) > 0)) return gc
  }
  return {}
})
const giftPopupDailyCurrencies = computed(() => {
  if (!giftPopupLevel.value) return {}
  const lv = giftPopupLevel.value
  if (lv.dailyGiftCurrencies) {
    const dgc = typeof lv.dailyGiftCurrencies === 'string' ? JSON.parse(lv.dailyGiftCurrencies) : lv.dailyGiftCurrencies
    if (dgc && Object.keys(dgc).some(k => Number(dgc[k]) > 0)) return dgc
  }
  return {}
})

function showGiftPopup(lv: any) { giftPopupLevel.value = lv }

const MOD_LABELS: Record<string, string> = {
  community: '社区', appstore: '应用', social: '社交',
  avatar: '形象', function: '功能', invite: '邀请', monetize: '变现', mall: '商城'
}
const BOOLEAN_PERMS = new Set(['A1','A2','A5','A9','A10','B1','B3','B5','C1','C2','C5','C14','C15','C17','D4','D10','D13','E1','H3'])

function isBoolPerm(key: string) { return BOOLEAN_PERMS.has(key) }
function modLabel(mod: string) { return MOD_LABELS[mod] || mod }
function hasFirstGift(lv: any) {
  if (lv.giftCurrencies) {
    const gc = typeof lv.giftCurrencies === 'string' ? JSON.parse(lv.giftCurrencies) : lv.giftCurrencies
    if (gc && Object.keys(gc).some(k => Number(gc[k]) > 0)) return true
  }
  return (Number(lv.firstGiftPoints)||0) > 0 || (Number(lv.firstGiftBalance)||0) > 0 || (Number(lv.firstGiftExperience)||0) > 0 || (Number(lv.firstGiftMakeupCount)||0) > 0
}
function hasDailyGift(lv: any) { return lv.dailyGiftEnabled === 1 }
function dailyGiftLabel(lv: any) {
  const parts: string[] = []
  if (lv.dailyGiftCurrencies) {
    const dgc = typeof lv.dailyGiftCurrencies === 'string' ? JSON.parse(lv.dailyGiftCurrencies) : lv.dailyGiftCurrencies
    if (dgc) {
      for (const [key, val] of Object.entries(dgc)) {
        if (Number(val) > 0) parts.push(val + getCurrencyLabel(key))
      }
    }
  }
  if (parts.length === 0) {
    const pts = Number(lv.dailyGiftPoints) || 0
    const bal = Number(lv.dailyGiftBalance) || 0
    const exp = Number(lv.dailyGiftExperience) || 0
    if (pts) parts.push(pts + '积分')
    if (bal) parts.push('¥' + bal)
    if (exp) parts.push(exp + '经验')
  }
  return parts.join('/') || (String(lv.dailyGiftIntervalDays || 1) + '天')
}

function getCurrencyLabel(key: string) {
  const found = currencyLabels.value[key]
  if (found) return found
  const map: Record<string, string> = { balance: '元', points: '积分', experience: '经验', makeup_count: '补签', rename_count: '改名' }
  return map[key] || key
}

const currencyLabels = ref<Record<string, string>>({})
async function loadCurrencyLabels() {
  try {
    const res: any = await request.get({ url: '/api/currency-settings' })
    const list = res?.data || res || []
    const map: Record<string, string> = {}
    for (const c of list) { map[c.currency_key] = c.display_name || c.currency_key }
    currencyLabels.value = map
  } catch {}
}
function formatExp(val: number | string) {
  const n = Number(val) || 0
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

const compGrouped = computed(() => {
  const groups: Record<string, any[]> = {}
  for (const p of compPermissions.value) {
    const m = p.module || 'community'
    if (!groups[m]) groups[m] = []
    groups[m].push(p)
  }
  return groups
})

const topScrollRef = ref<HTMLElement>()
const mainScrollRef = ref<HTMLElement>()
const topScrollX = ref(0)
let scrollSyncing = false

function onDataScroll() {
  if (scrollSyncing) return
  scrollSyncing = true
  topScrollX.value = mainScrollRef.value?.scrollLeft || 0
  nextTick(() => { scrollSyncing = false })
}

async function openCompare() {
  compareMode.value = true
  compLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/operation/experience-level/permissions-compare' })
    const rawData = res?.data || res || {}
    const rawLevels = rawData.levels || []
    const userLevel = rawData.userLevel || rawData.user_level || 0
    compOwnLevel.value = userLevel
    const sorted = [...rawLevels].sort((a: any, b: any) => {
      if (a.level === userLevel) return -1
      if (b.level === userLevel) return 1
      return b.level - a.level
    })
    compLevels.value = sorted
    compPermissions.value = rawData.permissions || []
  } catch (_e) { void _e }
  compLoading.value = false
}

async function loadData() {
  try {
    const data: any = await request.get({ url: '/api/operation/experience-level/list' })
    const list = data?.records || data?.data?.records || data || []
    if (list.length > 0) {
      const sorted = [...list].sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
      levels.value = sorted
      const exp = userExp.value
      let cur = sorted[0]
      let nxt: any = null
      for (const l of sorted) {
        const req = l.expRequired || l.exp_required || 0
        if (req <= exp) cur = l
        if (req > exp && !nxt) nxt = l
      }
      currentLevel.value = cur
      nextExp.value = nxt ? (nxt.expRequired || nxt.exp_required || 0) : (cur.expRequired || cur.exp_required || 0) + 1000
    }
  } catch (_e) { void _e }

  try {
    const ptRes: any = await request.get({ url: '/api/operation/points-record/list' })
    const records = ptRes?.records || ptRes?.data?.records || ptRes?.data || []
    let todayTotal = 0
    const today = new Date().toISOString().slice(0, 10)
    for (const r of records) {
      if (r.created_at && String(r.created_at).slice(0, 10) === today) {
        todayTotal += Number(r.points || 0)
      }
    }
    todayPoints.value = todayTotal

    let myList: any[] = []
    try {
      const myRes: any = await request.get({ url: '/api/custom-task/my' })
      myList = Array.isArray(myRes) ? myRes : (myRes?.records || myRes?.data?.records || myRes?.data || [])
    } catch { /* fall through to defaults */ }

    const earnList = myList.filter((t: any) => t.direction === 'earn')
    if (earnList.length > 0) {
      pointTasks.value = earnList.map((t: any) => ({
        name: t.name,
        emoji: actionEmoji[t.action_type] || '🎯',
        done: t.progress || 0,
        max: t.target_count || 1,
        points_reward: t.points_reward || 0,
        exp_reward: t.exp_reward || 0
      }))
    } else {
      pointTasks.value = [
        { name: '每日签到', emoji: '📅', done: todayTotal > 0 ? 1 : 0, max: 1, points_reward: 10, exp_reward: 5 },
        { name: '点赞作品', emoji: '❤️', done: 0, max: 5, points_reward: 2, exp_reward: 1 },
        { name: '发表评论', emoji: '💬', done: 0, max: 3, points_reward: 5, exp_reward: 3 },
        { name: '上传作品', emoji: '🎨', done: 0, max: 1, points_reward: 20, exp_reward: 10 },
        { name: '分享作品', emoji: '📤', done: 0, max: 2, points_reward: 5, exp_reward: 2 }
      ]
    }
    dailyMaxPoints.value = pointTasks.value.reduce((s, t) => s + t.points_reward * t.max, 0)

    const penList = myList.filter((t: any) => t.direction === 'spend')
    penaltyTasks.value = penList.map((t: any) => {
      const detail: string[] = []
      let cfg: any = {}
      try { cfg = typeof t.penalty_config === 'string' ? JSON.parse(t.penalty_config) : (t.penalty_config || {}) } catch {}
      if (t.exp_reward > 0 && !cfg.duration_bands) {
        detail.push(`-${t.exp_reward}经验/次`)
      }
      if (cfg.duration_bands && cfg.duration_bands.length > 0) {
        detail.push(`${cfg.duration_bands.length}个天数档位`)
      }
      if (cfg.additional_actions && cfg.additional_actions.length > 0) {
        detail.push(`累计违规触发${cfg.additional_actions.length}项附加惩罚`)
      }
      return { ...t, _penaltyDetail: detail }
    })
  } catch (_e) { void _e }

  try {
    const teRes: any = await request.get({ url: '/api/operation/experience-level/list' })
    const teList = teRes?.records || teRes?.data?.records || []
    let todayExpVal = 0
    const today2 = new Date().toISOString().slice(0, 10)
    for (const r of teList) {
      if (r.updatedAt && String(r.updatedAt).slice(0, 10) === today2) {
        todayExpVal += Number(r.expGain || r.exp_gain || 0)
      }
    }
    todayExp.value = todayExpVal || 0
  } catch (_e) { void _e }
}

onMounted(() => {
  loadCurrencyLabels()
  if (isLogin.value) loadData()
})
</script>

<style scoped>
.compare-scroll::-webkit-scrollbar { height: 0; width: 0; }
</style>
