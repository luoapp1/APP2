<template>
  <div class="mall-page">
    <!-- 顶部渐变区 -->
    <div class="mall-header">
      <div class="header-decor header-decor--big" />
      <div class="header-decor header-decor--small" />

      <!-- 导航栏 -->
      <div class="header-nav">
        <button class="nav-btn" @click="$router.back()">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span class="nav-title">商城</span>
        <button class="nav-btn" @click="$router.push('/appstore/buyed')">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
        </button>
      </div>

      <!-- 双卡片 -->
      <div class="header-cards">
        <div class="hc-card hc-card--points" @click="$router.push('/appstore/mine')">
          <div class="hc-left">
            <div class="hc-value">{{ isLogin ? pointsStr : '--' }}</div>
            <div class="hc-label">我的积分 <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg></div>
          </div>
          <div class="hc-icon hc-icon--gold">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          </div>
        </div>
        <div class="hc-card hc-card--orders" @click="$router.push('/appstore/buyed')">
          <div class="hc-left">
            <div class="hc-value hc-value--small">我购买的</div>
            <div class="hc-label">查看订单 <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg></div>
          </div>
          <div class="hc-icon hc-icon--amber">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          </div>
        </div>
      </div>
    </div>

    <!-- 分类 Tab -->
    <div class="section-tabs" ref="catScrollRef">
      <span
        v-for="cat in categories"
        :key="cat.id"
        class="tab-item"
        :class="{ 'tab-item--active': activeCategory === cat.id }"
        @click="activeCategory = cat.id"
      >{{ cat.name }}</span>
    </div>

    <!-- 筛选 + 排序 -->
    <div class="section-filters">
      <div class="filter-tags">
        <span
          v-for="tag in filterTags"
          :key="tag.value"
          class="filter-chip"
          :class="{ 'filter-chip--active': activeTag === tag.value }"
          @click="activeTag = tag.value"
        >{{ tag.label }}</span>
      </div>
      <div class="sort-btn" @click="toggleSort">
        <span>{{ sortNewest ? '最新' : '热销' }}</span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
      </div>
    </div>

    <!-- 主体 -->
    <div class="section-body" @scroll="onScroll" ref="listScrollRef">
      <!-- 骨架屏 -->
      <div v-if="loading && products.length === 0" class="product-grid">
        <div v-for="i in 4" :key="i" class="skeleton-card">
          <div class="skeleton-img" />
          <div class="skeleton-info">
            <div class="skeleton-line skeleton-line--w70" />
            <div class="skeleton-row">
              <div class="skeleton-line skeleton-line--w45" />
              <div class="skeleton-line skeleton-line--w25" />
            </div>
          </div>
        </div>
      </div>

      <!-- 空态 -->
      <div v-else-if="!loading && products.length === 0" class="empty-state">
        <div class="empty-icon">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
        </div>
        <div class="empty-title">暂无商品</div>
        <div class="empty-desc">换个分类试试吧</div>
      </div>

      <!-- 商品列表 -->
      <div v-else class="product-grid" :style="decorCategoryType ? { gap: '10px', gridTemplateColumns: decorCategoryType === 'comment_background' || decorCategoryType === 'nickname_effect' ? 'repeat(2, 1fr)' : 'repeat(3, 1fr)', padding: '0 16px 16px' } : { gap: '10px', gridTemplateColumns: 'repeat(2, 1fr)', padding: '0 16px 16px' }">
        <!-- ===== 装饰类型：头像框 ===== -->
        <template v-if="decorCategoryType === 'frames'">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="position: relative; width: 56px; height: 56px; margin-bottom: 8px;">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0;" loading="lazy" />
              <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 40px; height: 40px; border-radius: 50%; overflow: hidden; z-index: 1;">
                <img :src="userAvatar" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              </div>
            </div>
            <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 2px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
            <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
            <span style="font-size: 10px; color: #9ca3af; margin-top: 1px;">{{ ownedStatusText(item) }}</span>
          </div>
        </template>

        <!-- ===== 装饰类型：称号 ===== -->
        <template v-else-if="decorCategoryType === 'titles'">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; background: #f3f4f6;">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <span v-else style="font-size: 22px; font-weight: 800; color: #d1d5db;">{{ (item.name || '?')[0] }}</span>
            </div>
            <span v-if="item.category" style="font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 500; margin-bottom: 4px; line-height: 14px;" :style="{ color: catColor(item.category), background: catBg(item.category) }">{{ catLabel(item.category) }}</span>
            <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 2px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
            <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
            <span style="font-size: 10px; color: #9ca3af; margin-top: 1px;">{{ ownedStatusText(item) }}</span>
          </div>
        </template>

        <!-- ===== 装饰类型：评论背景 ===== -->
        <template v-else-if="decorCategoryType === 'comment_background'">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; overflow: hidden; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="width: 100%; height: 50px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <span v-else style="font-size: 16px; color: #d1d5db;">无预览图</span>
            </div>
            <div style="padding: 8px 8px 6px;">
              <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
              <div style="display: flex; align-items: center; justify-content: space-between;">
                <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
                <span style="font-size: 9px; color: #9ca3af;">{{ ownedStatusText(item) }}</span>
              </div>
            </div>
            <span v-if="item.originalPrice && item.originalPrice > item.price" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">-{{ Math.round((1 - item.price / item.originalPrice) * 100) }}%</span>
          </div>
        </template>

        <!-- ===== 装饰类型：昵称特效 ===== -->
        <template v-else-if="decorCategoryType === 'nickname_effect'">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; overflow: hidden; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="width: 100%; height: 64px; background: #fafbfc; display: flex; align-items: center; gap: 8px; padding: 0 10px; position: relative; overflow: hidden; border-left: 3px solid #e8ecf1;">
              <img :src="userAvatar" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex-shrink: 0;" loading="lazy" />
              <div style="flex: 1; min-width: 0;">
                <span :style="{ fontSize: '13px', fontWeight: '600', color: '#00BFA5', ...nicknameEffectStyle(item.decorationConfig || {}) }" :class="nicknameEffectAnim(item.decorationConfig || {})">{{ (item.name || '昵称').slice(0, 6) }}</span>
                <div style="font-size: 9px; color: #bbb; margin-top: 1px;">点击查看效果</div>
              </div>
            </div>
            <div style="padding: 8px 8px 6px;">
              <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
              <div style="display: flex; align-items: center; justify-content: space-between;">
                <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
                <span style="font-size: 9px; color: #9ca3af;">{{ ownedStatusText(item) }}</span>
              </div>
            </div>
            <span v-if="item.originalPrice && item.originalPrice > item.price" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">-{{ Math.round((1 - item.price / item.originalPrice) * 100) }}%</span>
          </div>
        </template>

        <!-- ===== 装饰类型：主页背景 ===== -->
        <template v-else-if="decorCategoryType === 'home_bg'">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; overflow: hidden; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="width: 100%; height: 190px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <span v-else style="font-size: 14px; color: #d1d5db;">无预览图</span>
            </div>
            <div style="padding: 8px 8px 6px;">
              <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
              <div style="display: flex; align-items: center; justify-content: space-between;">
                <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
                <span style="font-size: 9px; color: #9ca3af;">{{ ownedStatusText(item) }}</span>
              </div>
            </div>
            <span v-if="item.originalPrice && item.originalPrice > item.price" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">-{{ Math.round((1 - item.price / item.originalPrice) * 100) }}%</span>
          </div>
        </template>

        <!-- ===== 装饰类型：头像特效 / 默认 ===== -->
        <template v-else-if="decorCategoryType">
          <div v-for="item in ownedFilteredProducts" :key="item.id" @click="openBuy(item)" style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; box-shadow: 0 2px 8px rgba(0,0,0,.06);">
            <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; background: #f3f4f6;">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <span v-else style="font-size: 22px; font-weight: 800; color: #d1d5db;">{{ (item.name || '?')[0] }}</span>
            </div>
            <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 2px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
            <span style="font-size: 11px; color: #FF4757;">{{ getPriceDisplay(item) }}</span>
            <span style="font-size: 10px; color: #9ca3af; margin-top: 1px;">{{ ownedStatusText(item) }}</span>
          </div>
        </template>

        <!-- ===== 非装饰类型：长方形卡片 1行2个 ===== -->
        <template v-else>
          <div
            v-for="(item, idx) in products"
            :key="item.id"
            class="product-card"
            @click="openBuy(item)"
          >
            <div class="card-cover" :style="{ background: placeholderColors[idx % placeholderColors.length] }">
              <img v-if="item.coverImage" :src="$fixImgUrl(item.coverImage)" class="card-img" loading="lazy" />
              <span v-else class="card-cover-placeholder">&#x1F3A8;</span>
              <span :class="getPriceTagClass(item)">
                {{ getPriceDisplay(item) }}
              </span>
              <span v-if="item.originalPrice && item.originalPrice > item.price" class="card-discount">
                -{{ Math.round((1 - item.price / item.originalPrice) * 100) }}%
              </span>
              <span v-if="item.ownedStatus" class="card-owned-badge" :style="{ top: (item.originalPrice && item.originalPrice > item.price) ? '28px' : '8px' }" :class="{
                'card-owned-badge--perm': item.ownedStatus.status === 'permanent',
                'card-owned-badge--temp': item.ownedStatus.status === 'temporary',
                'card-owned-badge--none': item.ownedStatus.status === 'not_owned'
              }">
                {{ item.ownedStatus.status === 'permanent' ? '已拥有' : item.ownedStatus.status === 'temporary' ? item.ownedStatus.remainingDays + '天' : (item.ownedStatus.status === 'not_owned' ? '未拥有' : '') }}
              </span>
            </div>
            <div class="card-body">
              <div class="card-name">{{ item.name }}<template v-if="item.durationLabel">（{{ item.durationLabel }}）</template></div>
              <div class="card-meta">
                <span v-if="item.originalPrice && item.originalPrice > item.price" class="card-original">¥{{ item.originalPrice }}</span>
                <span class="card-sales">已售 {{ item.salesCount || 0 }}</span>
              </div>
            </div>
          </div>
        </template>

        <!-- 加载更多 -->
        <div v-if="loading && products.length > 0" class="load-more-spinner"><div class="spinner" /></div>
        <!-- 到底 -->
        <div v-if="finished && products.length > 0" class="load-more-end">
          <div class="end-line" /><span>已经到底了</span><div class="end-line" />
        </div>
      </div>
    </div>

    <!-- 赚积分悬浮 -->
    <div class="fab-earn" @click="handleEarnPoints">
      <div class="fab-pulse" />
      <div class="fab-btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        <span>赚积分</span>
      </div>
    </div>

    <MallBuyPopup
      :visible="showBuy"
      :product-id="buyProductId"
      @close="showBuy = false"
      @paid="onPaid"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue'
import request from '@/utils/http'
import MallBuyPopup from './MallBuyPopup.vue'
import { useUserStore } from '@/store/modules/user'
import { nicknameEffectStyle, nicknameEffectAnim } from '@/utils/nickname-effect'

const defaultAvatarImg = new URL('@imgs/user/avatar.webp', import.meta.url).href

const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)
const userAvatar = computed(() => userStore.info?.avatar || defaultAvatarImg)

const formatNum = (val: number): string => {
  if (val >= 10000) return (val / 10000).toFixed(1).replace('.0', '') + '万'
  return Number.isInteger(val) ? String(val) : val.toFixed(0)
}

const pointsStr = computed(() => {
  if (!isLogin.value) return '--'
  return formatNum(Number(userStore.info.points || 0))
})

// 分类名 -> 装饰类型映射
const DECOR_CATEGORY_MAP: Record<string, string> = {
  '头像框': 'frames',
  '称号': 'titles',
  '头像特效': 'avatar_effect',
  '评论背景': 'comment_background',
  '评论背景墙': 'comment_background',
  '昵称特效': 'nickname_effect',
  '主页背景': 'home_bg',
  '主页背景图': 'home_bg',
}

function formatDurationLabel(expireTime: string | null): string {
  if (!expireTime) return '永久'
  const days = Math.ceil((new Date(expireTime + ' UTC').getTime() - Date.now()) / 86400000)
  if (days <= 0) return '已过期'
  if (days >= 365) return Math.floor(days / 365) + '年'
  if (days >= 60) return Math.floor(days / 30) + '个月'
  return days + '天'
}

function getItemDurationLabel(item: any): string {
  if (item.expireTime !== void 0) return formatDurationLabel(item.expireTime)
  return '永久'
}

function ownedStatusText(item: any): string {
  if (item.isEquipped) return '已装备'
  if (item.expireTime) return getItemDurationLabel(item)
  return '已拥有'
}

function getPriceDisplay(item: any): string {
  if (item.priceType === 'points') {
    return (item.minPointsPrice || item.price) + ' 积分'
  }
  if (item.priceType === 'balance' && item.price === 0 && item.minPointsPrice > 0) {
    return item.minPointsPrice + ' 积分'
  }
  return '¥' + item.price
}

function getPriceTagClass(item: any): string {
  if (item.priceType === 'points' || (item.priceType === 'balance' && item.price === 0 && item.minPointsPrice > 0)) {
    return 'card-price-tag card-price-tag--points'
  }
  return 'card-price-tag card-price-tag--money'
}

const categoryLabelMap: Record<string, string> = { '成就': '成就', '活动': '活动', '消费': '消费', '社交': '社交', '管理员': '管理员' }
const categoryColorMap: Record<string, string> = { '成就': '#FF9800', '活动': '#E91E63', '消费': '#4CAF50', '社交': '#2196F3', '管理员': '#9C27B0' }
const categoryBgMap: Record<string, string> = { '成就': '#FFF3E0', '活动': '#FCE4EC', '消费': '#E8F5E9', '社交': '#E3F2FD', '管理员': '#F3E5F5' }
function catLabel(v: string) { return categoryLabelMap[v] || v }
function catColor(v: string) { return categoryColorMap[v] || '#999' }
function catBg(v: string) { return categoryBgMap[v] || '#f3f4f6' }

const decorCategoryType = computed(() => {
  const cat = categories.value.find((c: any) => c.id === activeCategory.value)
  return cat ? (DECOR_CATEGORY_MAP[cat.name] || '') : ''
})

const ownedFilteredProducts = computed(() => {
  if (!decorCategoryType.value) return products.value
  return products.value.filter((p: any) => p.ownedStatus?.status === 'permanent' || p.ownedStatus?.status === 'temporary')
})

const placeholderColors = [
  '#f5f5f5',
  '#f5f5f5',
  '#f5f5f5',
  '#f5f5f5',
  '#f5f5f5',
  '#f5f5f5',
]

const categories = ref<any[]>([])
const activeCategory = ref(0)

const filterTags = [
  { label: '全部', value: '' },
  { label: '积分兑换', value: 'points' },
  { label: '余额购买', value: 'balance' },
]
const activeTag = ref('')
const sortNewest = ref(true)
const products = ref<any[]>([])
const page = ref(1)
const loading = ref(false)
const finished = ref(false)
const listScrollRef = ref<HTMLElement | null>(null)
const catScrollRef = ref<HTMLElement | null>(null)
const showBuy = ref(false)
const buyProductId = ref(0)

const openBuy = (item: any) => {
  buyProductId.value = item.id
  showBuy.value = true
}

const onPaid = () => {
  request.get({ url: '/api/user/info' }).then((res: any) => {
    if (res) userStore.info = res
  }).catch(() => {})
  page.value = 1
  products.value = []
  finished.value = false
  loadProducts()
}

const toggleSort = () => {
  sortNewest.value = !sortNewest.value
  page.value = 1
  products.value = []
  finished.value = false
  loadProducts()
}

const loadCategories = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    const cats = Array.isArray(res) ? res : []
    categories.value = cats
    if (cats.length > 0) activeCategory.value = cats[0].id
  } catch {}
}

const loadProducts = async () => {
  if (loading.value || finished.value) return
  loading.value = true
  try {
    const params: any = { status: 'published', page: page.value, pageSize: 20, sortBy: sortNewest.value ? 'newest' : 'sales' }
    if (activeCategory.value) params.categoryId = activeCategory.value
    if (activeTag.value === 'points') params.priceType = 'points'
    else if (activeTag.value === 'balance') params.priceType = 'balance'
    const res: any = await request.get({ url: '/api/mall/products', params })
    const list = res?.list || res || []
    products.value = page.value === 1 ? list : [...products.value, ...list]
    if (list.length < 20) finished.value = true
    else page.value++
  } catch {} finally { loading.value = false }
}

const onScroll = () => {
  const el = listScrollRef.value
  if (!el || loading.value || finished.value) return
  if (el.scrollHeight - el.scrollTop - el.clientHeight < 100) loadProducts()
}

const handleEarnPoints = () => {
  window.location.hash = '#/appstore/mine'
}

watch(activeCategory, () => { page.value = 1; products.value = []; finished.value = false; loadProducts() })
watch(activeTag, () => { page.value = 1; products.value = []; finished.value = false; loadProducts() })

onMounted(() => {
  loadCategories()
})
</script>

<style scoped>
/* ======== base ======== */
.mall-page {
  min-height: 100vh;
  background: #fff;
  display: flex;
  flex-direction: column;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

/* ======== header ======== */
.mall-header {
  position: relative;
  overflow: hidden;
  padding: 12px 16px 24px;
  background: linear-gradient(180deg, #d4f5e2 0%, #e8f8ee 60%, #f5f6f8 100%);
}
.header-decor {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.header-decor--big {
  right: -40px;
  top: -60px;
  width: 180px;
  height: 180px;
  background: rgba(34,167,93,.06);
}
.header-decor--small {
  left: 20px;
  bottom: 10px;
  width: 80px;
  height: 80px;
  background: rgba(34,167,93,.04);
}

/* nav */
.header-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
  position: relative;
  z-index: 1;
}
.nav-btn {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: none;
  background: rgba(255,255,255,.7);
  backdrop-filter: blur(6px);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #374151;
}
.nav-title {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
}

/* cards */
.header-cards {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  position: relative;
  z-index: 1;
}
.hc-card {
  border-radius: 18px;
  padding: 16px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  transition: transform .15s;
}
.hc-card:active {
  transform: scale(.96);
}
.hc-card--points {
  background: linear-gradient(135deg, #fff 0%, #fffbeb 100%);
  box-shadow: 0 4px 18px rgba(245,158,11,.10);
}
.hc-card--orders {
  background: linear-gradient(135deg, #fff 0%, #fef3c7 100%);
  box-shadow: 0 4px 18px rgba(252,211,77,.12);
}
.hc-value {
  font-size: 26px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.1;
}
.hc-value--small {
  font-size: 15px;
  font-weight: 600;
}
.hc-label {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 2px;
}
.hc-icon {
  width: 40px;
  height: 40px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.hc-icon--gold {
  background: linear-gradient(135deg, #fbbf24, #f59e0b);
}
.hc-icon--amber {
  background: linear-gradient(135deg, #fcd34d, #fbbf24);
}

/* ======== tabs ======== */
.section-tabs {
  display: flex;
  overflow-x: auto;
  scrollbar-width: none;
  gap: 2px;
  margin: 10px 12px 0;
  padding: 4px;
  background: #fff;
  border-radius: 14px;
}
.tab-item {
  flex-shrink: 0;
  padding: 8px 16px;
  font-size: 13px;
  white-space: nowrap;
  cursor: pointer;
  border-radius: 12px;
  color: #666;
  transition: all .2s;
}
.tab-item--active {
  background: #22a75d;
  color: #fff;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(34,167,93,.2);
}

/* ======== filters ======== */
.section-filters {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  gap: 8px;
}
.filter-tags {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  scrollbar-width: none;
  flex: 1;
}
.filter-chip {
  flex-shrink: 0;
  padding: 5px 14px;
  border-radius: 16px;
  font-size: 12px;
  white-space: nowrap;
  cursor: pointer;
  background: #fff;
  color: #666;
  border: 1px solid #e5e7eb;
  transition: all .15s;
}
.filter-chip--active {
  background: #1a1a2e;
  color: #fff;
  font-weight: 500;
  border-color: #1a1a2e;
}
.sort-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 16px;
  padding: 5px 10px;
  font-size: 12px;
  color: #666;
  cursor: pointer;
}

/* ======== product grid ======== */
.section-body {
  flex: 1;
  overflow-y: auto;
  padding: 0 12px 12px;
}
.product-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}

/* skeleton */
.skeleton-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
}
.skeleton-img {
  height: 120px;
  background: linear-gradient(110deg, #f0f0f0 30%, #f8f8f8 50%, #f0f0f0 70%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}
.skeleton-info {
  padding: 10px 12px;
}
.skeleton-line {
  height: 14px;
  background: #f0f0f0;
  border-radius: 4px;
  margin-bottom: 8px;
}
.skeleton-line--w70 { width: 70%; }
.skeleton-line--w45 { width: 45%; }
.skeleton-line--w25 { width: 25%; }
.skeleton-row {
  display: flex;
  justify-content: space-between;
}

/* empty */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 0;
}
.empty-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: #f0fdf4;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
}
.empty-title {
  font-size: 15px;
  color: #bbb;
  margin-bottom: 4px;
}
.empty-desc {
  font-size: 12px;
  color: #d0d0d0;
}

/* product card */
.product-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0,0,0,.04);
  transition: transform .15s;
}


.card-discount {
  position: absolute;
  top: 4px;
  right: 4px;
  background: #FF6B6B;
  color: #fff;
  padding: 1px 6px;
  border-radius: 6px;
  font-size: 9px;
  font-weight: 700;
}
.product-card:active {
  transform: scale(.97);
}
.card-cover {
  position: relative;
  width: 100%;
  height: 120px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-img {
  max-width: 80%;
  max-height: 80%;
  object-fit: contain;
}
.card-cover-placeholder {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 48px;
  opacity: .5;
}
.card-price-tag {
  position: absolute;
  bottom: 4px;
  left: 4px;
  padding: 2px 6px;
  border-radius: 8px;
  font-size: 10px;
  font-weight: 600;
  color: #fff;
  backdrop-filter: blur(4px);
}
.card-price-tag--points {
  background: rgba(34,167,93,.9);
}
.card-price-tag--money {
  background: rgba(255,107,107,.9);
}
.card-discount {
  position: absolute;
  top: 8px;
  right: 8px;
  background: #FF6B6B;
  color: #fff;
  padding: 2px 8px;
  border-radius: 8px;
  font-size: 10px;
  font-weight: 700;
  line-height: 16px;
}
.card-owned-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  padding: 1px 6px;
  border-radius: 6px;
  font-size: 10px;
  font-weight: 600;
  line-height: 16px;
  color: #fff;
}
.card-owned-badge--perm { background: rgba(34,167,93,.85); }
.card-owned-badge--temp { background: rgba(253,176,57,.85); }
.card-owned-badge--none { background: rgba(153,153,153,.7); }
.card-body {
  padding: 8px 8px 10px;
}
.card-name {
  font-size: 12px;
  font-weight: 600;
  color: #1a1a2e;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-bottom: 2px;
}
.card-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.card-original {
  font-size: 10px;
  color: #bbb;
  text-decoration: line-through;
}
.card-sales {
  font-size: 9px;
  color: #bbb;
}

/* load-more */
.load-more-spinner {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  padding: 16px 0;
}
.spinner {
  width: 24px;
  height: 24px;
  border: 2px solid #e5e7eb;
  border-top-color: #22a75d;
  border-radius: 50%;
  animation: spin .6s linear infinite;
}
.load-more-end {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 20px 0 32px;
  color: #ccc;
  font-size: 12px;
}
.end-line {
  width: 40px;
  height: 1px;
  background: #eee;
}

/* ======== fab ======== */
.fab-earn {
  position: fixed;
  bottom: 100px;
  right: 16px;
  z-index: 10;
  cursor: pointer;
}
.fab-pulse {
  position: absolute;
  inset: -6px;
  border-radius: 24px;
  background: rgba(255,155,104,.2);
  animation: pulse 2s infinite;
}
.fab-btn {
  position: relative;
  width: 60px;
  height: 60px;
  border-radius: 20px;
  background: linear-gradient(145deg, #ffd399, #ff9b68);
  box-shadow: 0 6px 20px rgba(255,155,104,.4);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: 9px;
  color: #fff;
  font-weight: 700;
  transition: transform .15s;
}
.fab-btn:active {
  transform: scale(.9);
}

/* ======== keyframes ======== */
@keyframes shimmer {
  0%  { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
@keyframes pulse {
  0%, 100% { opacity: 1;    transform: scale(1); }
  50%      { opacity: .6;   transform: scale(1.08); }
}
</style>
