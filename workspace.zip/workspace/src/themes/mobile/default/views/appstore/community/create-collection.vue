<template>
  <div class="create-collection-page">
    <div v-if="toastText" class="cc-toast" :class="{ 'cc-toast-err': toastErr }">{{ toastText }}</div>
    <div class="cc-nav">
      <button class="cc-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="cc-nav-title">{{ isEdit ? '编辑合集' : '新建合集' }}</span>
      <button class="cc-nav-save" :disabled="saving || !form.title.trim()" @click="handleSave">
        {{ saving ? '保存中...' : '保存' }}
      </button>
    </div>

    <div class="cc-body" v-if="!loading">
      <!-- 基本信息 -->
      <div class="cc-section">
        <div class="cc-section-title">基本信息</div>
        <div class="cc-field">
          <label class="cc-label">合集标题 <span class="cc-required">*</span></label>
          <input v-model="form.title" class="cc-input" placeholder="输入合集标题" maxlength="100" />
        </div>
        <div class="cc-field">
          <label class="cc-label">简介</label>
          <textarea v-model="form.description" class="cc-textarea" placeholder="介绍合集的简要内容" rows="4" maxlength="500"></textarea>
        </div>
        <div class="cc-field">
          <label class="cc-label">封面图</label>
          <div class="cc-cover-row">
            <div class="cc-cover-preview" v-if="form.coverImage">
              <img :src="form.coverImage"  loading="lazy" />
              <button class="cc-cover-remove" @click="form.coverImage = ''">&times;</button>
            </div>
            <button class="cc-upload-btn" @click="triggerUpload" v-if="!form.coverImage">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#909399" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
              <span>上传封面</span>
            </button>
            <input ref="coverInput" type="file" accept="image/*" style="display:none" @change="handleCoverUpload" />
          </div>
        </div>
      </div>

      <!-- 收费设置 -->
      <div class="cc-section">
        <div class="cc-section-title">收费设置</div>
        <div class="cc-field cc-field-switch">
          <label class="cc-label">收费合集</label>
          <div class="cc-switch" :class="{ active: form.isPaid }" @click="form.isPaid = !form.isPaid">
            <div class="cc-switch-dot"></div>
          </div>
        </div>
        <div v-if="form.isPaid">
          <div class="cc-field">
            <label class="cc-label">余额价格（元）</label>
            <input v-model.number="form.priceBalance" type="number" class="cc-input" placeholder="留空则不支持余额支付" min="0" step="0.01" />
          </div>
          <div class="cc-field">
            <label class="cc-label">积分价格</label>
            <input v-model.number="form.pricePoints" type="number" class="cc-input" placeholder="留空则不支持积分支付" min="0" />
          </div>
        </div>
      </div>

      <!-- 试读设置 -->
      <div class="cc-section">
        <div class="cc-section-title">试读设置</div>
        <div class="cc-field">
          <label class="cc-label">免费试读篇数</label>
          <div class="cc-preview-count">
            <button class="cc-count-btn" @click="form.previewCount = Math.max(0, (form.previewCount || 0) - 1)">-</button>
            <span class="cc-count-val">{{ form.previewCount || 0 }}</span>
            <button class="cc-count-btn" @click="form.previewCount = Math.min(20, (form.previewCount || 0) + 1)">+</button>
          </div>
        </div>
      </div>

      <!-- 帖子管理（仅编辑模式） -->
      <div class="cc-section" v-if="isEdit">
        <div class="cc-section-title">帖子管理</div>
        <div class="cc-field">
          <label class="cc-label">排序模式</label>
          <div class="cc-sort-tabs">
            <button class="cc-sort-tab" :class="{ active: form.sortMode === 'manual' }" @click="form.sortMode = 'manual'">手动排序</button>
            <button class="cc-sort-tab" :class="{ active: form.sortMode === 'chronological' }" @click="form.sortMode = 'chronological'">按时间排序</button>
          </div>
        </div>

        <!-- 已添加帖子 -->
        <div class="cc-post-list" v-if="collectionPosts.length > 0">
          <VueDraggable
            v-if="form.sortMode === 'manual'"
            v-model="collectionPosts"
            item-key="post_id"
            handle=".cc-post-drag"
            :animation="200"
            @end="onSortEnd"
          >
            <div
              v-for="(p, idx) in collectionPosts"
              :key="p.post_id"
              class="cc-post-item"
            >
              <span class="cc-post-index">{{ idx + 1 }}</span>
              <div class="cc-post-drag" :class="{ 'cc-post-drag-active': form.sortMode === 'manual' }">&#9776;</div>
              <div class="cc-post-info">
                <div class="cc-post-title">{{ p.title || '(无标题)' }}</div>
                <div class="cc-post-tags">
                  <span v-if="p.is_preview" class="cc-post-tag cc-post-tag-preview">试读</span>
                  <span class="cc-post-tag" :class="p.invalid ? 'cc-post-tag-invalid' : ''">
                    {{ p.invalid ? '已失效' : '' }}
                  </span>
                </div>
              </div>
              <div class="cc-post-actions">
                <button v-if="!p.invalid" class="cc-post-btn" @click="togglePreview(p)">{{ p.is_preview ? '取消试读' : '设试读' }}</button>
                <button class="cc-post-btn cc-post-btn-del" @click="removePost(p)">移除</button>
              </div>
            </div>
          </VueDraggable>
          <template v-else>
            <div
              v-for="(p, idx) in collectionPosts"
              :key="p.post_id"
              class="cc-post-item"
            >
              <span class="cc-post-index">{{ idx + 1 }}</span>
              <div class="cc-post-drag">&#9776;</div>
              <div class="cc-post-info">
                <div class="cc-post-title">{{ p.title || '(无标题)' }}</div>
                <div class="cc-post-tags">
                  <span v-if="p.is_preview" class="cc-post-tag cc-post-tag-preview">试读</span>
                  <span class="cc-post-tag" :class="p.invalid ? 'cc-post-tag-invalid' : ''">
                    {{ p.invalid ? '已失效' : '' }}
                  </span>
                </div>
              </div>
              <div class="cc-post-actions">
                <button v-if="!p.invalid" class="cc-post-btn" @click="togglePreview(p)">{{ p.is_preview ? '取消试读' : '设试读' }}</button>
                <button class="cc-post-btn cc-post-btn-del" @click="removePost(p)">移除</button>
              </div>
            </div>
          </template>
        </div>
        <div v-else class="cc-post-empty">暂未添加帖子</div>

        <button class="cc-add-post-btn" @click="showPostSelector = true">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          添加帖子
        </button>
      </div>

      <!-- 状态设置（仅编辑模式） -->
      <div class="cc-section" v-if="isEdit">
        <div class="cc-section-title">状态</div>
        <div class="cc-field">
          <div class="cc-status-row">
            <button
              v-for="s in statusOptions"
              :key="s.value"
              class="cc-status-btn"
              :class="{ active: form.status === s.value, disabled: s.disabled }"
              :disabled="s.disabled"
              @click="form.status = s.value"
            >{{ s.label }}</button>
          </div>
        </div>
        <div class="cc-status-tip" v-if="form.status === 'finished'">
          已完结后不能再增删帖子或调整排序，仅可修改封面和简介
        </div>
      </div>
    </div>

    <div v-else class="cc-loading">加载中...</div>

    <!-- 帖子选择器弹窗 -->
    <div class="cc-overlay" v-if="showPostSelector" @click.self="showPostSelector = false">
      <div class="cc-dialog">
        <div class="cc-dialog-header">
          <span>选择帖子</span>
          <button class="cc-dialog-close" @click="showPostSelector = false">&times;</button>
        </div>
        <div class="cc-dialog-search">
          <input v-model="postSearch" class="cc-search-input" placeholder="搜索你的帖子..." />
        </div>
        <div class="cc-dialog-body">
          <div class="cc-dialog-loading" v-if="searchingPosts">搜索中...</div>
          <div
            v-for="p in filteredPosts"
            :key="p.id"
            class="cc-dialog-item"
            :class="{ selected: selectedPostIds.includes(p.id) }"
            @click="toggleSelectPost(p.id)"
          >
            <div class="cc-dialog-check">
              <svg v-if="selectedPostIds.includes(p.id)" width="20" height="20" viewBox="0 0 24 24" fill="#6366f1" stroke="#6366f1" stroke-width="2"><circle cx="12" cy="12" r="10" fill="#6366f1"/><path d="M7 12l3 3 7-7" stroke="#fff" stroke-width="2" fill="none"/></svg>
              <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
            </div>
            <div class="cc-dialog-info">
              <div class="cc-dialog-title">{{ p.title || '(无标题)' }}</div>
              <div class="cc-dialog-meta">{{ p.createTime?.slice(0, 10) }} | {{ p.viewCount || 0 }}阅读</div>
            </div>
          </div>
          <div v-if="!searchingPosts && filteredPosts.length === 0" class="cc-dialog-empty">暂无帖子</div>
        </div>
        <div class="cc-dialog-footer">
          <span class="cc-dialog-count">已选 {{ selectedPostIds.length }} 篇</span>
          <button class="cc-dialog-confirm" :disabled="selectedPostIds.length === 0" @click="confirmAddPosts">确定添加</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { VueDraggable } from 'vue-draggable-plus'
import {
  createCollection, updateCollection, fetchCollection,
  addPostsToCollection, removePostsFromCollection, setPostPreview,
  sortCollectionPosts, uploadCommunityImage
} from '@/api/community'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()

const toastText = ref('')
const toastErr = ref(false)
const toastTimer = ref<ReturnType<typeof setTimeout>>()

function showToast(text: string, isError = false) {
  toastText.value = text
  toastErr.value = isError
  clearTimeout(toastTimer.value)
  toastTimer.value = setTimeout(() => { toastText.value = '' }, 2000)
}

const isEdit = computed(() => !!route.query.id)

const form = ref({
  title: '',
  description: '',
  coverImage: '',
  isPaid: false,
  priceBalance: 0,
  pricePoints: 0,
  previewCount: 0,
  sortMode: 'manual',
  status: 'draft' as string,
})

const saving = ref(false)
const loading = ref(false)
const showPostSelector = ref(false)
const postSearch = ref('')
const myPosts = ref<any[]>([])
const selectedPostIds = ref<number[]>([])
const searchingPosts = ref(false)
const collectionPosts = ref<any[]>([])

const coverInput = ref<HTMLInputElement>()

const statusOptions = computed(() => {
  const base = [
    { label: '草稿', value: 'draft' },
    { label: '连载中', value: 'serializing' },
    { label: '已完结', value: 'finished' },
  ]
  // 如果初始状态是 finished，不允许切回其他状态
  if (form.value.status === 'finished') {
    return base.map(s => ({
      ...s,
      disabled: s.value !== 'finished'
    }))
  }
  return base.map(s => ({ ...s, disabled: false }))
})

const filteredPosts = computed(() => {
  if (!postSearch.value) return myPosts.value
  const q = postSearch.value.toLowerCase()
  return myPosts.value.filter(p => (p.title || '').toLowerCase().includes(q))
})

watch(showPostSelector, async (val) => {
  if (val) {
    searchingPosts.value = true
    selectedPostIds.value = []
    try {
      const data: any = await request.get({ url: '/api/community/posts', params: { pageSize: 200, myPosts: true } })
      if (!showPostSelector.value) return
      const posts = data?.list || data || []
      const existingIds = new Set(collectionPosts.value.map(p => p.post_id))
      myPosts.value = posts.filter((p: any) => !existingIds.has(p.id))
    } catch { myPosts.value = [] }
    searchingPosts.value = false
  }
})

function triggerUpload() { coverInput.value?.click() }

async function handleCoverUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  try {
    const data: any = await uploadCommunityImage(file)
    if (data?.url) {
      form.value.coverImage = data.url
    } else {
      showToast('上传失败', true)
    }
  } catch { showToast('上传失败', true) }
}

async function handleSave() {
  if (!form.value.title.trim()) return
  saving.value = true
  try {
    if (isEdit.value) {
      const id = Number(route.query.id)
      await updateCollection(id, {
        title: form.value.title,
        description: form.value.description,
        coverImage: form.value.coverImage,
        isPaid: form.value.isPaid,
        priceBalance: form.value.priceBalance,
        pricePoints: form.value.pricePoints,
        previewCount: form.value.previewCount,
        sortMode: form.value.sortMode,
        status: form.value.status,
      })
      router.back()
    } else {
      const data: any = await createCollection({
        title: form.value.title,
        description: form.value.description,
        coverImage: form.value.coverImage,
        isPaid: form.value.isPaid,
        priceBalance: form.value.priceBalance,
        pricePoints: form.value.pricePoints,
        previewCount: form.value.previewCount,
        sortMode: form.value.sortMode,
      })
      if (data?.id) {
        router.replace(`/community/collection/create?id=${data.id}`)
      } else {
        showToast('创建失败', true)
      }
    }
  } catch (e: any) {
    showToast(e.message || '保存失败', true)
  }
  saving.value = false
}

function toggleSelectPost(pid: number) {
  const idx = selectedPostIds.value.indexOf(pid)
  if (idx >= 0) selectedPostIds.value.splice(idx, 1)
  else selectedPostIds.value.push(pid)
}

async function confirmAddPosts() {
  if (selectedPostIds.value.length === 0) return
  try {
    const id = Number(route.query.id)
    await addPostsToCollection(id, selectedPostIds.value)
    showPostSelector.value = false
    await loadCollection()
  } catch (e: any) {
    showToast(e.message || '添加失败', true)
  }
}

async function removePost(post: any) {
  if (!confirm(`确定将「${post.title || '无标题'}」从合集中移除？`)) return
  try {
    const id = Number(route.query.id)
    await removePostsFromCollection(id, [post.post_id])
    await loadCollection()
  } catch (e: any) {
    showToast(e.message || '移除失败', true)
  }
}

async function togglePreview(post: any) {
  try {
    const id = Number(route.query.id)
    await setPostPreview(id, post.post_id, !post.is_preview)
    await loadCollection()
  } catch (e: any) {
    showToast(e.message || '设置失败', true)
  }
}

async function onSortEnd() {
  try {
    const id = Number(route.query.id)
    const sortedIds = collectionPosts.value.map(p => p.post_id)
    await sortCollectionPosts(id, sortedIds)
  } catch (e: any) {
    showToast(e.message || '排序保存失败', true)
  }
}

async function loadCollection() {
  try {
    const id = Number(route.query.id)
    const data: any = await fetchCollection(id)
    if (data) {
      form.value.title = data.title || ''
      form.value.description = data.description || ''
      form.value.coverImage = data.cover_image || ''
      form.value.isPaid = !!data.is_paid
      form.value.priceBalance = Number(data.price_balance) || 0
      form.value.pricePoints = Number(data.price_points) || 0
      form.value.previewCount = data.preview_count || 0
      form.value.sortMode = data.sort_mode || 'manual'
      form.value.status = data.status || 'draft'
      collectionPosts.value = data.posts || []
    }
  } catch {}
}

onMounted(async () => {
  if (isEdit.value) {
    loading.value = true
    await loadCollection()
    loading.value = false
  }
})
</script>

<style scoped>
/* Toast */
.cc-toast {
  position: fixed;
  top: 60px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999;
  padding: 10px 22px;
  border-radius: 22px;
  font-size: 14px;
  font-weight: 500;
  color: #fff;
  background: rgba(0,0,0,.75);
  backdrop-filter: blur(8px);
  animation: cc-toast-in .25s ease;
  pointer-events: none;
}
.cc-toast-err {
  background: rgba(239,68,68,.88);
}
@keyframes cc-toast-in {
  from { opacity: 0; transform: translateX(-50%) translateY(-8px); }
  to { opacity: 1; transform: translateX(-50%) translateY(0); }
}
.create-collection-page {
  min-height: 100vh;
  background: #f5f6fa;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}
.cc-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
  border-bottom: 1px solid #eee;
}
.cc-nav-back { background: none; border: none; padding: 4px; color: #333; cursor: pointer; display: flex; align-items: center; }
.cc-nav-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
.cc-nav-save {
  background: #6366f1;
  color: #fff;
  border: none;
  padding: 6px 16px;
  border-radius: 16px;
  font-size: 14px;
  cursor: pointer;
}
.cc-nav-save:disabled { opacity: .5; cursor: not-allowed; }
.cc-body { padding: 16px; padding-bottom: 60px; }
.cc-loading { text-align: center; padding: 60px 0; color: #999; }

.cc-section {
  background: #fff;
  border-radius: 10px;
  padding: 16px;
  margin-bottom: 14px;
}
.cc-section-title {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 14px;
  padding-bottom: 10px;
  border-bottom: 1px solid #f0f0f0;
}

.cc-field { margin-bottom: 14px; }
.cc-field:last-child { margin-bottom: 0; }
.cc-label { display: block; font-size: 14px; color: #606266; margin-bottom: 6px; }
.cc-required { color: #f56c6c; }
.cc-input {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  font-size: 14px;
  background: #fafafa;
  box-sizing: border-box;
}
.cc-input:focus { border-color: #6366f1; background: #fff; outline: none; }
.cc-textarea {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  font-size: 14px;
  resize: vertical;
  background: #fafafa;
  box-sizing: border-box;
  font-family: inherit;
}
.cc-textarea:focus { border-color: #6366f1; background: #fff; outline: none; }

.cc-cover-row { display: flex; align-items: center; }
.cc-cover-preview { position: relative; width: 80px; height: 107px; border-radius: 6px; overflow: hidden; }
.cc-cover-preview img { width: 100%; height: 100%; object-fit: cover; }
.cc-cover-remove {
  position: absolute; top: 4px; right: 4px;
  width: 20px; height: 20px; border-radius: 50%;
  background: rgba(0,0,0,.5); color: #fff; border: none;
  font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.cc-upload-btn {
  width: 80px; height: 107px; border-radius: 6px;
  border: 1px dashed #d9d9d9; background: #fafafa;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 6px; cursor: pointer; font-size: 12px; color: #909399;
}

.cc-field-switch { display: flex; justify-content: space-between; align-items: center; }
.cc-switch {
  width: 48px; height: 26px; border-radius: 13px;
  background: #dcdfe6; position: relative; cursor: pointer; transition: background .2s;
}
.cc-switch.active { background: #6366f1; }
.cc-switch-dot {
  width: 22px; height: 22px; border-radius: 50%; background: #fff;
  position: absolute; top: 2px; left: 2px; transition: left .2s;
  box-shadow: 0 1px 3px rgba(0,0,0,.15);
}
.cc-switch.active .cc-switch-dot { left: 24px; }

.cc-preview-count { display: flex; align-items: center; gap: 12px; }
.cc-count-btn {
  width: 32px; height: 32px; border-radius: 50%;
  border: 1px solid #dcdfe6; background: #fff; font-size: 16px;
  cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.cc-count-val { font-size: 18px; font-weight: 600; min-width: 24px; text-align: center; }

.cc-sort-tabs { display: flex; gap: 8px; }
.cc-sort-tab {
  flex: 1; padding: 8px; border-radius: 8px; border: 1px solid #e4e7ed;
  background: #fff; font-size: 13px; cursor: pointer;
}
.cc-sort-tab.active { border-color: #6366f1; background: #eef0ff; color: #6366f1; font-weight: 500; }

.cc-post-list { margin-top: 10px; }
.cc-post-item {
  display: flex; align-items: center; padding: 10px 0;
  border-bottom: 1px solid #f5f5f5; gap: 10px;
}
.cc-post-index {
  width: 22px; height: 22px; border-radius: 50%;
  background: #e8edf5; color: #6366f1; font-size: 12px; font-weight: 600;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.cc-post-drag { font-size: 16px; color: #c0c4cc; cursor: grab; flex-shrink: 0; }
.cc-post-info { flex: 1; min-width: 0; }
.cc-post-title { font-size: 14px; color: #303133; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cc-post-tags { display: flex; gap: 4px; margin-top: 4px; }
.cc-post-tag { font-size: 11px; padding: 1px 6px; border-radius: 4px; background: #f0f2f5; color: #909399; }
.cc-post-tag-preview { background: #e6f7ff; color: #1890ff; }
.cc-post-tag-invalid { color: #f56c6c; }
.cc-post-actions { display: flex; gap: 6px; flex-shrink: 0; }
.cc-post-btn {
  background: #f0f2f5; border: none; padding: 4px 10px; border-radius: 12px;
  font-size: 12px; cursor: pointer; color: #606266;
}
.cc-post-btn-del { color: #f56c6c; }
.cc-post-empty { text-align: center; padding: 16px; color: #c0c4cc; font-size: 13px; }
.cc-add-post-btn {
  width: 100%; padding: 12px; border: 1px dashed #d9d9d9; border-radius: 8px;
  background: #fafafa; color: #6366f1; font-size: 14px; cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 6px; margin-top: 10px;
}

.cc-status-row { display: flex; gap: 8px; }
.cc-status-btn {
  flex: 1; padding: 10px; border-radius: 8px; border: 1px solid #e4e7ed;
  background: #fff; font-size: 13px; cursor: pointer;
}
.cc-status-btn.active { border-color: #6366f1; background: #eef0ff; color: #6366f1; }
.cc-status-btn.disabled { opacity: .4; cursor: not-allowed; }
.cc-status-tip {
  margin-top: 10px; padding: 10px; background: #fff7e6; border-radius: 8px;
  font-size: 13px; color: #e6a23c; line-height: 1.5;
}

/* 帖子选择器弹窗 */
.cc-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 100;
  display: flex; align-items: flex-end; justify-content: center;
}
.cc-dialog {
  background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 70vh;
  display: flex; flex-direction: column;
}
.cc-dialog-header {
  display: flex; justify-content: space-between; align-items: center;
  padding: 16px; border-bottom: 1px solid #f0f0f0; font-size: 16px; font-weight: 600;
}
.cc-dialog-close { background: none; border: none; font-size: 24px; color: #909399; cursor: pointer; }
.cc-dialog-search { padding: 12px 16px; }
.cc-search-input {
  width: 100%; padding: 10px 12px; border: 1px solid #e4e7ed; border-radius: 8px;
  font-size: 14px; background: #f5f6fa; box-sizing: border-box;
}
.cc-dialog-body { flex: 1; overflow-y: auto; padding: 0 16px; max-height: 40vh; }
.cc-dialog-loading { text-align: center; padding: 20px; color: #999; }
.cc-dialog-item {
  display: flex; align-items: center; padding: 12px 0; border-bottom: 1px solid #f5f5f5;
  cursor: pointer; gap: 12px;
}
.cc-dialog-check { flex-shrink: 0; display: flex; align-items: center; }
.cc-dialog-info { flex: 1; min-width: 0; }
.cc-dialog-title { font-size: 14px; color: #303133; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cc-dialog-meta { font-size: 12px; color: #c0c4cc; margin-top: 2px; }
.cc-dialog-empty { text-align: center; padding: 30px; color: #c0c4cc; }
.cc-dialog-footer {
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 16px; border-top: 1px solid #f0f0f0;
}
.cc-dialog-count { font-size: 14px; color: #6366f1; }
.cc-dialog-confirm {
  background: #6366f1; color: #fff; border: none;
  padding: 10px 24px; border-radius: 18px; font-size: 14px; cursor: pointer;
}
.cc-dialog-confirm:disabled { opacity: .5; cursor: not-allowed; }
</style>
