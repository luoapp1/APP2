<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">短信配置</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- 服务商选择 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
          {{ editId ? '编辑短信配置' : '新增短信配置' }}
        </div>
        <div class="space-y-3">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">配置名称</label>
            <input v-model="form.name" placeholder="如：阿里云注册验证" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>
          <div>
            <label class="text-xs text-gray-500 mb-1 block">短信服务商</label>
            <select v-model="form.provider" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" @change="onProviderChange">
              <option value="">-- 请选择 --</option>
              <option value="aliyun">阿里云短信</option>
              <option value="tencent">腾讯云短信</option>
              <option value="huawei">华为云短信</option>
              <option value="yunpian">云片 (YunPian)</option>
              <option value="chuanglan">创蓝云智</option>
              <option value="cloopen">容联七陌 (容联云)</option>
              <option value="yimei">亿美软通</option>
            </select>
          </div>

          <!-- 阿里云 -->
          <template v-if="form.provider === 'aliyun'">
            <div><label class="text-xs text-gray-500 mb-1 block">AccessKey ID</label><input v-model="form.accessKeyId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">AccessKey Secret</label><input v-model="form.accessKeySecret" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 腾讯云 -->
          <template v-if="form.provider === 'tencent'">
            <div><label class="text-xs text-gray-500 mb-1 block">SecretId</label><input v-model="form.secretId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">SecretKey</label><input v-model="form.secretKey" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">SDK App ID</label><input v-model="form.appId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 华为云 -->
          <template v-if="form.provider === 'huawei'">
            <div><label class="text-xs text-gray-500 mb-1 block">App Key</label><input v-model="form.appKey" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">App Secret</label><input v-model="form.appSecret" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">短信通道号</label><input v-model="form.sender" placeholder="国内签名通道号" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 云片 -->
          <template v-if="form.provider === 'yunpian'">
            <div><label class="text-xs text-gray-500 mb-1 block">API Key</label><input v-model="form.apiKey" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 创蓝 -->
          <template v-if="form.provider === 'chuanglan'">
            <div><label class="text-xs text-gray-500 mb-1 block">账号</label><input v-model="form.account" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">密码</label><input v-model="form.password" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 容联云 -->
          <template v-if="form.provider === 'cloopen'">
            <div><label class="text-xs text-gray-500 mb-1 block">Account SID</label><input v-model="form.accountSid" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">Auth Token</label><input v-model="form.authToken" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">App ID</label><input v-model="form.appId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <!-- 亿美 -->
          <template v-if="form.provider === 'yimei'">
            <div><label class="text-xs text-gray-500 mb-1 block">CDkey</label><input v-model="form.cdKey" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">密码</label><input v-model="form.password" type="password" :placeholder="editId ? '留空则不修改' : ''" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <template v-if="form.provider">
            <div><label class="text-xs text-gray-500 mb-1 block">短信签名</label><input v-model="form.signName" placeholder="如：ArtDesign" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">模板代码</label><input v-model="form.templateCode" placeholder="如：SMS_123456789" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </template>

          <div class="flex items-center justify-between py-1">
            <span class="text-sm text-gray-600">设为默认</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.isDefault?'bg-[#FF4757]':'bg-gray-200'" @click="form.isDefault=!form.isDefault"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.isDefault?'translate-x-4.5':'left-0.5'" /></button>
          </div>
          <div class="flex items-center justify-between py-1">
            <span class="text-sm text-gray-600">启用</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.enabled?'bg-[#FF4757]':'bg-gray-200'" @click="form.enabled=!form.enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.enabled?'translate-x-4.5':'left-0.5'" /></button>
          </div>
        </div>

        <div class="flex gap-2 mt-4">
          <button class="flex-1 h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" :disabled="saving" @click="doSave">{{ saving?'保存中...':'保存配置' }}</button>
          <button v-if="editId" class="flex-1 h-10 bg-red-500 text-white text-sm rounded-lg font-medium active:opacity-80" :disabled="saving" @click="doDelete">删除</button>
        </div>
      </div>

      <!-- 已有配置列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-4">已配置的服务商</div>
        <div v-if="list.length === 0" class="text-center py-6 text-gray-400 text-sm">暂无配置，请添加</div>
        <div v-for="item in list" :key="item.id" class="flex items-center justify-between py-3 border-b last:border-none border-gray-100" @click="editItem(item)">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-lg flex items-center justify-center text-white text-xs font-bold" :style="{ background: providerColor(item.provider) }">{{ providerLabel(item.provider).charAt(0) }}</div>
            <div>
              <div class="text-sm font-medium text-gray-800">{{ item.name || providerLabel(item.provider) }}</div>
              <div class="text-[10px] text-gray-400">{{ item.sign_name || '未设签名' }} {{ item.template_code ? '| '+item.template_code : '' }}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span v-if="item.is_default" class="text-[10px] bg-[#FF4757]/10 text-[#FF4757] px-2 py-0.5 rounded-full">默认</span>
            <span class="w-2 h-2 rounded-full" :class="item.enabled?'bg-green-400':'bg-gray-300'" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { useRoute, useRouter } from 'vue-router'

defineOptions({ name: 'SmsConfig' })

const route = useRoute()
const router = useRouter()

const list = ref<any[]>([])
const editId = ref<string | number>('')
const saving = ref(false)
const toastMsg = ref('')
const toastType = ref('info')
let toastTimer: number | null = null

const form = reactive<any>({
  name: '', provider: '', accessKeyId: '', accessKeySecret: '',
  secretId: '', secretKey: '', appId: '', appKey: '', appSecret: '',
  sender: '', apiKey: '', account: '', password: '',
  accountSid: '', authToken: '', cdKey: '',
  signName: '', templateCode: '', isDefault: false, enabled: true
})

const providerLabels: Record<string, string> = {
  aliyun: '阿里云短信', tencent: '腾讯云短信', huawei: '华为云短信',
  yunpian: '云片', chuanglan: '创蓝云智', cloopen: '容联七陌', yimei: '亿美软通'
}

const providerColors: Record<string, string> = {
  aliyun: '#FF6A00', tencent: '#0052D9', huawei: '#CF0A2C',
  yunpian: '#FF4757', chuanglan: '#2196F3', cloopen: '#00BF6F', yimei: '#9C27B0'
}

function providerLabel(p: string) { return providerLabels[p] || p }
function providerColor(p: string) { return providerColors[p] || '#666' }

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg; toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = window.setTimeout(() => { toastMsg.value = '' }, 2500)
}

function onProviderChange() {
  form.accessKeyId = ''; form.accessKeySecret = ''; form.secretId = ''; form.secretKey = ''
  form.appId = ''; form.appKey = ''; form.appSecret = ''; form.sender = ''
  form.apiKey = ''; form.account = ''; form.password = ''
  form.accountSid = ''; form.authToken = ''; form.cdKey = ''
}

async function loadList() {
  try {
    const res: any = await request.get({ url: '/api/sms/configs' })
    if (Array.isArray(res)) list.value = res
    else if (res && Array.isArray(res.data)) list.value = res.data
  } catch {}
}

function buildConfigJson() {
  const p = form.provider
  const cfg: any = {}
  if (p === 'aliyun') { cfg.accessKeyId = form.accessKeyId; if (form.accessKeySecret) cfg.accessKeySecret = form.accessKeySecret }
  if (p === 'tencent') { cfg.secretId = form.secretId; if (form.secretKey) cfg.secretKey = form.secretKey; cfg.appId = form.appId }
  if (p === 'huawei') { cfg.appKey = form.appKey; if (form.appSecret) cfg.appSecret = form.appSecret; cfg.sender = form.sender }
  if (p === 'yunpian') { if (form.apiKey) cfg.apiKey = form.apiKey }
  if (p === 'chuanglan') { cfg.account = form.account; if (form.password) cfg.password = form.password }
  if (p === 'cloopen') { cfg.accountSid = form.accountSid; if (form.authToken) cfg.authToken = form.authToken; cfg.appId = form.appId }
  if (p === 'yimei') { cfg.cdKey = form.cdKey; if (form.password) cfg.password = form.password }
  return JSON.stringify(cfg)
}

async function doSave() {
  if (!form.provider) return showToast('请选择短信服务商', 'error')
  saving.value = true
  try {
    const data: any = {
      provider: form.provider,
      name: form.name || providerLabel(form.provider),
      config_json: buildConfigJson(),
      sign_name: form.signName,
      template_code: form.templateCode,
      is_default: form.isDefault,
      enabled: form.enabled
    }
    if (editId.value) {
      await request.put({ url: `/api/sms/config/${editId.value}`, data })
      showToast('更新成功')
    } else {
      await request.post({ url: '/api/sms/config', data })
      showToast('添加成功')
    }
    resetForm()
    await loadList()
  } catch { } finally { saving.value = false }
}

async function doDelete() {
  if (!confirm('确定删除此配置？')) return
  saving.value = true
  try {
    await request.del({ url: `/api/sms/config/${editId.value}` })
    showToast('删除成功')
    resetForm()
    await loadList()
  } catch { } finally { saving.value = false }
}

function editItem(item: any) {
  editId.value = item.id
  form.provider = item.provider
  form.name = item.name || ''
  form.signName = item.sign_name || ''
  form.templateCode = item.template_code || ''
  form.isDefault = !!item.is_default
  form.enabled = !!item.enabled
  try {
    const cfg = typeof item.config_json === 'string' ? JSON.parse(item.config_json) : (item.config_json || {})
    form.accessKeyId = cfg.accessKeyId || ''; form.accessKeySecret = ''
    form.secretId = cfg.secretId || ''; form.secretKey = ''
    form.appId = cfg.appId || ''; form.appKey = cfg.appKey || ''; form.appSecret = ''
    form.sender = cfg.sender || ''; form.apiKey = ''
    form.account = cfg.account || ''; form.password = ''
    form.accountSid = cfg.accountSid || ''; form.authToken = ''
    form.cdKey = cfg.cdKey || ''
  } catch {}
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function resetForm() {
  editId.value = ''
  Object.assign(form, {
    name: '', provider: '', accessKeyId: '', accessKeySecret: '',
    secretId: '', secretKey: '', appId: '', appKey: '', appSecret: '',
    sender: '', apiKey: '', account: '', password: '',
    accountSid: '', authToken: '', cdKey: '',
    signName: '', templateCode: '', isDefault: false, enabled: true
  })
}

onMounted(() => loadList())
</script>
