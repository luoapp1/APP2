<template>
  <div class="recharge-page">
    <div class="nav-bar">
      <svg class="nav-back" fill="none" stroke="currentColor" viewBox="0 0 24 24" width="22" height="22" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <div class="nav-title">充值</div>
      <div class="nav-orders" @click="$router.push('/appstore/bills')">订单</div>
    </div>

    <div class="balance-card">
      <div class="balance-icon">¥</div>
      <div class="balance-info">
        <div class="balance-label">我的余额</div>
        <div class="balance-value">{{ formatAmount(balance, 'balance') }}</div>
      </div>
      <div class="balance-action" @click="$router.push('/appstore/balance')">
        明细
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </div>
    </div>

    <div class="section-title">
      <span>选择充值金额</span>
    </div>

    <div class="package-grid">
      <div
        v-for="(pkg, idx) in packages" :key="idx"
        class="package-item"
        :class="{ selected: selectedIdx === idx, 'is-first': pkg.firstOnly }"
        @click="selectPackage(idx)"
      >
        <div v-if="pkg.tag" class="package-badge">{{ pkg.tag }}</div>
        <div class="package-amount">
          <span class="package-symbol">¥</span>{{ pkg.price }}
        </div>
        <div v-if="pkg.giftText" class="package-bonus">{{ pkg.giftText }}</div>
        <div v-if="pkg.memberName" class="package-bonus member">{{ pkg.memberName }}{{ pkg.memberDays }}天</div>
        <div class="package-select" :class="{ on: selectedIdx === idx }">
          <svg v-if="selectedIdx === idx" fill="currentColor" viewBox="0 0 24 24" width="16" height="16"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          <svg v-else fill="currentColor" viewBox="0 0 24 24" width="16" height="16"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/></svg>
        </div>
      </div>
    </div>

    <div class="section-title">
      <span>选择支付方式</span>
    </div>

    <div class="payment-card">
      <div
        v-for="pm in payMethods" :key="pm.key"
        class="payment-item"
        :class="{ selected: payMethod === pm.key, disabled: !pm.available }"
        @click="selectPayment(pm)"
      >
        <div class="payment-left">
          <div class="payment-icon" :style="{ background: pm.bg }">
            <svg v-if="pm.key === 'wechat'" fill="currentColor" viewBox="0 0 24 24" width="18" height="18"><path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 0 1 .213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 0 0 .167-.054l1.903-1.114a.864.864 0 0 1 .717-.098 10.16 10.16 0 0 0 2.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178A1.17 1.17 0 0 1 4.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178 1.17 1.17 0 0 1-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 0 1 .598.082l1.584.926a.272.272 0 0 0 .14.045c.133 0 .241-.108.241-.245 0-.06-.024-.12-.04-.178l-.325-1.233a.492.492 0 0 1 .178-.555C23.028 18.48 24 16.82 24 14.98c0-3.21-2.931-5.952-7.062-6.122zm-2.18 2.769c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.97-.982z"/></svg>
            <span v-else-if="pm.key === 'alipay'" style="font-weight:700;font-size:16px">支</span>
            <svg v-else fill="currentColor" viewBox="0 0 24 24" width="18" height="18"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-5-5 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z"/></svg>
          </div>
          <span class="payment-name">{{ pm.name }}</span>
          <span v-if="pm.hint" class="payment-hint">{{ pm.hint }}</span>
        </div>
        <div class="payment-right">
          <span v-if="pm.recommend" class="payment-rec">推荐</span>
          <svg v-if="payMethod === pm.key" fill="#ff4757" viewBox="0 0 24 24" width="20" height="20"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
        </div>
      </div>
    </div>

    <div v-if="selectedPackage" class="gift-preview">
      <div class="gift-preview-title">充值赠送</div>
      <div class="gift-preview-list">
        <span class="gift-dot base">本金 ¥{{ selectedPackage.price }}</span>
        <span v-if="selectedPackage.giftBalance" class="gift-dot balance">赠余额 {{ selectedPackage.giftBalance }}</span>
        <span v-if="selectedPackage.giftPoints" class="gift-dot points">赠积分 {{ selectedPackage.giftPoints }}</span>
        <span v-if="selectedPackage.giftExp" class="gift-dot exp">赠经验 {{ selectedPackage.giftExp }}</span>
        <span v-for="(cn, ci) in selectedPackage.couponNames" :key="'c'+ci" class="gift-dot coupon">{{ cn }}</span>
        <span v-if="selectedPackage.titleName" class="gift-dot title">赠称号: {{ selectedPackage.titleName }}</span>
        <span v-if="selectedPackage.frameName" class="gift-dot frame">赠头像框</span>
        <span v-if="selectedPackage.memberName" class="gift-dot member">会员 {{ selectedPackage.memberName }}{{ selectedPackage.memberDays }}天</span>
      </div>
    </div>

    <div class="desc-card">
      <div class="desc-title">充值说明</div>
      <p>1. 充值金额将计入账户余额，不支持退款</p>
      <p>2. 充值未完成时请勿切换账号或卸载应用</p>
      <p>3. 如有疑问请联系客服</p>
    </div>

    <div class="bottom-bar">
      <button class="recharge-btn" :disabled="!selectedPackage || recharging" @click="doRecharge">
        <template v-if="recharging">
          <span class="btn-spinner"></span> 处理中...
        </template>
        <template v-else>
          立即充值 ¥{{ selectedPackage ? selectedPackage.price : '--' }}
        </template>
      </button>
      <div class="agreement-text">充值即表示同意《用户服务协议》</div>
    </div>

    <div v-if="toastMsg" class="toast" :class="{ error: toastType === 'error' }">{{ toastMsg }}</div>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { useCurrency } from '@/composables/useCurrency'
import { onMounted } from 'vue'

defineOptions({ name: 'AppRecharge' })

const { balance, formatAmount, load: loadCurrency } = useCurrency()
const recharging = ref(false)
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any

function showToast(msg: string, type: 'success' | 'error' = 'success') {
  toastMsg.value = msg; toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2500)
}

const packages = ref<any[]>([])
const selectedIdx = ref(0)
const payMethods = ref<{ key: string; name: string; bg: string; recommend: boolean; available: boolean }[]>([])
const payMethod = ref('epay')

const selectedPackage = computed(() => packages.value[selectedIdx.value] || null)

function selectPackage(idx: number) {
  selectedIdx.value = idx
}

function selectPayment(pm: any) {
  if (!pm.available) {
    showToast(pm.hint || '暂不可用', 'error')
    return
  }
  payMethod.value = pm.key
}

async function loadPaymentMethods() {
  try {
    const d: any = await request.get({ url: '/api/recharge/payment-methods' })
    if (Array.isArray(d)) {
      const methodMeta: Record<string, any> = {
        epay: { bg: '#3b82f6', recommend: true },
        wechat: { bg: '#07c160', recommend: false },
        alipay: { bg: '#1677ff', recommend: false },
      }
      const mapped = d.map((m: any) => ({ ...m, ...(methodMeta[m.key] || { bg: '#666', recommend: false }) }))
      payMethods.value = mapped
      const available = mapped.filter((m: any) => m.available)
      if (available.length > 0) payMethod.value = available[0].key
    }
  } catch {}
}

async function loadPackages() {
  try {
    const d: any = await request.get({ url: '/api/recharge/amounts' })
    const rows = d || []
    const loaded = rows.map((r: any) => {
      const giftBalance = Number(r.gift_balance) || 0
      const giftPoints = Number(r.gift_points) || 0
      const giftExp = Number(r.gift_experience) || 0
      let couponItems: any[] = []
      if (r.gift_coupon_ids) {
        try { couponItems = typeof r.gift_coupon_ids === 'string' ? JSON.parse(r.gift_coupon_ids) : r.gift_coupon_ids } catch {}
      }
      return {
        price: Number(r.amount) || 0,
        tag: r.label || '',
        giftBalance,
        giftPoints,
        giftExp,
        giftText: giftBalance > 0 ? `送${giftBalance}余额` : (giftPoints ? `送${giftPoints}积分` : ''),
        firstOnly: r.first_only === 1,
        titleId: Number(r.gift_title_id) || 0,
        titleName: '',
        frameId: Number(r.gift_avatar_frame_id) || 0,
        frameName: '',
        memberLevelId: Number(r.gift_member_level_id) || 0,
        memberName: '',
        memberDays: Number(r.gift_member_days) || 0,
        couponNames: [] as string[],
        couponItems
      }
    })
    packages.value = loaded
    if (loaded.length > 0) selectedIdx.value = 0
  } catch {}
}

async function doRecharge() {
  const pkg = selectedPackage.value
  if (!pkg || recharging.value) return

  recharging.value = true
  try {
    const pm = payMethod.value
    const res: any = await request.post({
      url: '/api/recharge/create',
      data: { amount: pkg.price, payMethod: pm },
      showErrorMessage: false,
    } as any)
    const payUrl = res?.payUrl || res?.pay_url

    if (payUrl) {
      window.location.href = payUrl
    } else {
      showToast('支付渠道暂未配置，请联系管理员', 'error')
    }
  } catch (e: any) {
    showToast(e?.message || '创建订单失败', 'error')
  }
  recharging.value = false
}

onMounted(async () => {
  loadCurrency()
  loadPaymentMethods()
  loadPackages()
})
</script>

<style scoped>
.recharge-page {
  background: linear-gradient(180deg, #f0f4ff 0%, #fafbff 30%, #ffffff 100%);
  min-height: 100vh;
  padding-bottom: 120px;
}

.nav-bar {
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  background: rgba(255,255,255,0.8);
  backdrop-filter: blur(12px);
  position: sticky;
  top: 0;
  z-index: 20;
}
.nav-back {
  color: #333;
  cursor: pointer;
  flex-shrink: 0;
}
.nav-title {
  font-size: 17px;
  font-weight: 600;
  color: #1a1a2e;
}
.nav-orders {
  font-size: 14px;
  color: #3b82f6;
  cursor: pointer;
}

.balance-card {
  margin: 12px 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  padding: 18px 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  color: #fff;
  box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
}
.balance-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: rgba(255,255,255,0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  font-weight: 700;
  flex-shrink: 0;
}
.balance-info {
  flex: 1;
}
.balance-label {
  font-size: 12px;
  opacity: 0.8;
  margin-bottom: 2px;
}
.balance-value {
  font-size: 28px;
  font-weight: 700;
}
.balance-unit {
  font-size: 14px;
  font-weight: 500;
  opacity: 0.85;
}
.balance-action {
  font-size: 13px;
  opacity: 0.8;
  display: flex;
  align-items: center;
  gap: 2px;
  cursor: pointer;
  flex-shrink: 0;
}

.section-title {
  padding: 16px 20px 10px;
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
}

.package-grid {
  padding: 0 16px;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}

.package-item {
  background: #fff;
  border: 2px solid #e8ecf1;
  border-radius: 14px;
  padding: 14px 6px 10px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}
.package-item.selected {
  border-color: #ff4757;
  background: #fff5f7;
  box-shadow: 0 2px 12px rgba(255, 71, 87, 0.15);
  transform: translateY(-2px);
}
.package-item:active {
  transform: scale(0.97);
}
.package-badge {
  position: absolute;
  top: -10px;
  left: 50%;
  transform: translateX(-50%);
  background: linear-gradient(135deg, #ff6b6b, #ff4757);
  color: #fff;
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 999px;
  white-space: nowrap;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(255, 71, 87, 0.3);
}
.package-amount {
  font-size: 22px;
  font-weight: 800;
  color: #1a1a2e;
  margin: 4px 0 2px;
}
.package-symbol {
  font-size: 13px;
  font-weight: 600;
  color: #ff4757;
}
.package-bonus {
  font-size: 11px;
  color: #b56b00;
  background: #fff3dc;
  border-radius: 6px;
  padding: 1px 6px;
  display: inline-block;
  margin-top: 4px;
  font-weight: 500;
}
.package-bonus.member {
  background: #e0f2fe;
  color: #0284c7;
}
.package-select {
  margin-top: 6px;
  color: #d1d5db;
  display: flex;
  justify-content: center;
}
.package-select.on {
  color: #ff4757;
}

.payment-card {
  margin: 0 16px;
  background: #fff;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}

.payment-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  cursor: pointer;
  transition: background 0.15s;
  border-bottom: 1px solid #f3f4f6;
}
.payment-item:last-child {
  border-bottom: none;
}
.payment-item:active {
  background: #fafbfc;
}
.payment-item.disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
.payment-left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.payment-icon {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.payment-name {
  font-size: 15px;
  font-weight: 500;
  color: #1f2937;
}
.payment-hint {
  font-size: 11px;
  color: #c0c4cc;
  background: #f5f6f8;
  padding: 1px 6px;
  border-radius: 4px;
}
.payment-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.payment-rec {
  font-size: 11px;
  color: #ff4757;
  background: #fff5f7;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: 600;
}

.gift-preview {
  margin: 12px 16px;
  background: #fafbfc;
  border-radius: 12px;
  padding: 12px 14px;
  border: 1px solid #f0f0f0;
}
.gift-preview-title {
  font-size: 12px;
  font-weight: 600;
  color: #9ca3af;
  margin-bottom: 8px;
}
.gift-preview-list {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}
.gift-dot {
  font-size: 11px;
  padding: 3px 8px;
  border-radius: 999px;
  font-weight: 500;
}
.gift-dot.base { background: #e8f4fd; color: #3b82f6; }
.gift-dot.balance { background: #ecfdf5; color: #059669; }
.gift-dot.points { background: #fef3c7; color: #d97706; }
.gift-dot.exp { background: #ede9fe; color: #7c3aed; }
.gift-dot.coupon { background: #fce7f3; color: #db2777; }
.gift-dot.title { background: #e0f2fe; color: #0284c7; }
.gift-dot.frame { background: #fef9c3; color: #ca8a04; }
.gift-dot.member { background: #dcfce7; color: #16a34a; }

.desc-card {
  margin: 0 20px 16px;
  padding: 0 4px;
  font-size: 12px;
  color: #9ca3af;
  line-height: 1.8;
}
.desc-title {
  font-size: 13px;
  font-weight: 600;
  color: #6b7280;
  margin-bottom: 4px;
}

.bottom-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(180deg, rgba(255,255,255,0) 0%, #fff 20%);
  padding: 20px 16px 28px;
}
.recharge-btn {
  width: 100%;
  height: 48px;
  border-radius: 24px;
  background: linear-gradient(135deg, #ff6b6b 0%, #ff4757 100%);
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  border: none;
  cursor: pointer;
  box-shadow: 0 4px 16px rgba(255, 71, 87, 0.35);
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
.recharge-btn:disabled {
  background: #d1d5db;
  box-shadow: none;
  cursor: not-allowed;
}
.recharge-btn:not(:disabled):active {
  transform: scale(0.98);
  box-shadow: 0 2px 8px rgba(255, 71, 87, 0.3);
}
.btn-spinner {
  width: 18px;
  height: 18px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
.agreement-text {
  text-align: center;
  margin-top: 12px;
  font-size: 12px;
  color: #9ca3af;
}

.toast {
  position: fixed;
  top: 60px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 100;
  background: #1f2937;
  color: #fff;
  font-size: 13px;
  padding: 10px 24px;
  border-radius: 24px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  animation: toastIn 0.25s ease-out;
}
.toast.error {
  background: #ef4444;
}
@keyframes toastIn {
  from { opacity: 0; transform: translateX(-50%) translateY(-8px); }
  to { opacity: 1; transform: translateX(-50%) translateY(0); }
}
</style>
