<template>
  <div class="changelog-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">版本日志</span>
      <div style="width:22px" />
    </div>

    <div class="page-content">
      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadData" />
      <EmptyState v-else-if="!list.length" text="暂无版本记录">
        <template #icon>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        </template>
      </EmptyState>
      <div v-else class="timeline">
        <div v-for="(item, idx) in list" :key="item.version" class="tl-item">
          <div class="tl-line">
            <div class="tl-dot" :class="{ 'tl-dot-latest': idx === 0 }" />
            <div v-if="idx < list.length - 1" class="tl-connector" />
          </div>
          <div class="tl-card">
            <div class="tl-header">
              <span class="tl-version">v{{ item.version }}</span>
              <span v-if="idx === 0" class="tl-badge">最新</span>
              <span class="tl-date">{{ formatDate(item.releaseDate) }}</span>
            </div>
            <div v-if="item.changes && item.changes.length" class="tl-changes">
              <div v-for="(c, ci) in item.changes" :key="ci" class="tl-change">{{ c }}</div>
            </div>
            <div v-if="item.downloadUrl" class="tl-footer">
              <a :href="item.downloadUrl" class="btn btn-sm btn-primary" target="_blank">下载此版本</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const route = useRoute()
const loading = ref(false)
const error = ref('')
const list = ref([])

const appId = route.query.appId

function formatDate(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    if (isNaN(dt.getTime())) return String(d).slice(0, 10)
    return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`
  } catch { return String(d).slice(0, 10) }
}

async function loadData() {
  if (!appId) {
    error.value = '缺少应用ID'
    return
  }
  loading.value = true
  error.value = ''
  try {
    const res = await request.get({ url: `/api/app/${appId}/changelog` })
    const d = res?.data || res || {}
    list.value = d.list || []
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.changelog-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

.page-content { padding: 16px; }

.load-wrap { display: flex; justify-content: center; padding: 48px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.err-wrap { text-align: center; padding: 48px 16px; }
.err-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }
.empty-wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 60px 0; }
.empty-text { font-size: 14px; color: #999; }

.timeline { padding-left: 12px; }
.tl-item { display: flex; gap: 12px; }
.tl-line { display: flex; flex-direction: column; align-items: center; width: 20px; flex-shrink: 0; }
.tl-dot { width: 12px; height: 12px; border-radius: 50%; background: #e5e7eb; border: 2px solid #d1d5db; flex-shrink: 0; }
.tl-dot-latest { background: #6366F1; border-color: #6366F1; box-shadow: 0 0 0 4px rgba(99,102,241,.15); }
.tl-connector { width: 2px; flex: 1; min-height: 16px; background: #e5e7eb; }
.tl-card { flex: 1; min-width: 0; background: #fff; border-radius: 12px; padding: 14px; margin-bottom: 12px; }
.tl-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.tl-version { font-size: 15px; font-weight: 700; color: #1a1a1a; }
.tl-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; background: #EEF2FF; color: #6366F1; font-weight: 600; }
.tl-date { font-size: 12px; color: #bbb; margin-left: auto; }
.tl-changes { display: flex; flex-direction: column; gap: 4px; }
.tl-change { font-size: 13px; color: #555; line-height: 1.5; padding-left: 12px; position: relative; }
.tl-change::before { content: ''; position: absolute; left: 0; top: 8px; width: 4px; height: 4px; border-radius: 50%; background: #00BFA5; }
.tl-footer { margin-top: 10px; padding-top: 10px; border-top: 1px solid #f5f5f5; }
.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; text-decoration: none; }
.btn-sm { padding: 6px 12px; font-size: 12px; }
.btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.btn-primary:active { background: #4F46E5; }
</style>
