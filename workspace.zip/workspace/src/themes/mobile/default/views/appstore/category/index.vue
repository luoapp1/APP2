<template>
  <div class="category-page">
    <div class="page-tabs">
      <button v-for="t in tabs" :key="t.key" class="tab-btn" :class="{ active: activeTab === t.key }" @click="switchTab(t.key)">{{ t.label }}</button>
    </div>

    <!-- 分类 -->
    <template v-if="activeTab === 'category'">
      <ElCard class="art-table-card">
        <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
          <template #left>
            <ElButton type="primary" @click="showDialog('add')" v-ripple>添加分类</ElButton>
          </template>
        </ArtTableHeader>
        <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination" @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
        <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增分类' : '编辑分类'" width="30%" align-center>
          <ElForm ref="formRef" :model="formData" :rules="rules" label-width="80px">
            <ElFormItem label="分类名称" prop="name"><ElInput v-model="formData.name" placeholder="请输入分类名称" /></ElFormItem>
            <ElFormItem label="图标"><ElInput v-model="formData.icon" placeholder="图标URL（可选）" /></ElFormItem>
            <ElFormItem label="排序"><ElInputNumber v-model="formData.sortOrder" :min="0" :max="999" style="width:100%" /></ElFormItem>
            <ElFormItem label="状态"><ElSwitch v-model="formData.status" active-value="1" inactive-value="0" /></ElFormItem>
          </ElForm>
          <template #footer>
            <ElButton @click="dialogVisible = false">取消</ElButton>
            <ElButton type="primary" @click="handleSubmit">保存</ElButton>
          </template>
        </ElDialog>
      </ElCard>
    </template>

    <!-- 应用集 -->
    <template v-if="activeTab === 'collections'">
      <div v-if="colLoading" class="loading-state">加载中...</div>
      <div v-else-if="!colList.length" class="empty-state">暂无应用集</div>
      <div v-else class="collections-grid">
        <div v-for="c in colList" :key="c.id" class="col-card" @click="goCollection(c.id)">
          <div class="col-cover">
            <img v-if="c.coverUrl" :src="c.coverUrl" loading="lazy" />
            <div v-else class="col-cover-fb" :style="{ background: coverColors[c.id % coverColors.length] }">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.5" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
            </div>
          </div>
          <div class="col-body">
            <div class="col-name">{{ c.name }}</div>
            <div class="col-author" v-if="c.creatorName">{{ c.creatorName }}</div>
            <div class="col-meta">
              <span class="col-meta-item">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
                {{ c.appCount ?? c.postCount ?? 0 }}款
              </span>
              <span class="col-meta-item" v-if="c.likes !== undefined">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
                {{ formatNum(c.likes) }}
              </span>
            </div>
            <div class="col-desc" v-if="c.description">{{ c.description }}</div>
          </div>
        </div>
      </div>
    </template>

    <!-- 排行榜 -->
    <template v-if="activeTab === 'ranking'">
      <div class="ranking-tabs">
        <button v-for="r in rankTabs" :key="r.key" class="rank-tab" :class="{ active: rankType === r.key }" @click="switchRankTab(r.key)">{{ r.label }}</button>
      </div>
      <div v-if="rankLoading" class="loading-state">加载中...</div>
      <div v-else-if="!rankList.length" class="empty-state">暂无排行数据</div>
      <div v-else class="rank-list">
        <div v-for="(item, idx) in rankList" :key="item.id" class="rank-row" @click="goCollection(item.id)">
          <div class="rank-num" :class="'rank-' + (idx + 1)">
            <template v-if="idx === 0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#FFD700"><circle cx="12" cy="12" r="10" fill="#FFD700"/><text x="12" y="17" text-anchor="middle" font-size="12" font-weight="700" fill="#B8860B">1</text></svg>
            </template>
            <template v-else-if="idx === 1">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#C0C0C0"><circle cx="12" cy="12" r="10" fill="#C0C0C0"/><text x="12" y="17" text-anchor="middle" font-size="12" font-weight="700" fill="#666">2</text></svg>
            </template>
            <template v-else-if="idx === 2">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#CD7F32"><circle cx="12" cy="12" r="10" fill="#CD7F32"/><text x="12" y="17" text-anchor="middle" font-size="12" font-weight="700" fill="#8B4513">3</text></svg>
            </template>
            <template v-else>{{ idx + 1 }}</template>
          </div>
          <div class="rank-cover">
            <img v-if="item.coverUrl" :src="item.coverUrl" loading="lazy" />
            <div v-else class="rank-cover-fb" :style="{ background: coverColors[item.id % coverColors.length] }" />
          </div>
          <div class="rank-body">
            <div class="rank-name">{{ item.name }}</div>
            <div class="rank-meta">
              <span v-if="item.appCount !== undefined">{{ item.appCount }}款应用</span>
              <span v-if="item.likes !== undefined">{{ formatNum(item.likes) }}赞</span>
              <span v-if="item.viewCount !== undefined">{{ formatNum(item.viewCount) }}浏览</span>
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
import { useTable } from '@/hooks/core/useTable'
import { fetchCategoryList, fetchSaveCategory, fetchDeleteCategory, fetchCollections, fetchCollectionRanking } from '@/api/appstore'
import { ElTag, ElButton, ElMessageBox, ElMessage, ElInput, ElInputNumber, ElSwitch, ElDialog, ElForm, ElFormItem } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { DialogType } from '@/types'

defineOptions({ name: 'CategoryManage' })

type CategoryRecord = {
  id: number
  name: string
  icon: string
  sortOrder: number
  status: string
  createTime: string
}

const router = useRouter()
const activeTab = ref('category')
const tabs = [
  { key: 'category', label: '分类' },
  { key: 'collections', label: '应用集' },
  { key: 'ranking', label: '排行榜' }
]

const coverColors = [
  'linear-gradient(135deg, #6366F1, #8B5CF6)',
  'linear-gradient(135deg, #EC4899, #F472B6)',
  'linear-gradient(135deg, #10B981, #34D399)',
  'linear-gradient(135deg, #F59E0B, #FBBF24)',
  'linear-gradient(135deg, #3B82F6, #60A5FA)',
  'linear-gradient(135deg, #EF4444, #F87171)'
]

// ─── 分类管理 ───
const dialogVisible = ref(false)
const dialogType = ref<DialogType>('add')
const currentRow = ref<Partial<CategoryRecord>>({})
const formRef = ref<FormInstance>()
const formData = reactive({ name: '', icon: '', sortOrder: 0, status: '1' as string })
const rules: FormRules = { name: [{ required: true, message: '请输入分类名称', trigger: 'blur' }] }
const STATUS_CONFIG: Record<string, { type: 'success' | 'info'; text: string }> = { '1': { type: 'success', text: '启用' }, '0': { type: 'info', text: '禁用' } }

const { columns, columnChecks, data, loading, pagination, getData, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: fetchCategoryList,
    apiParams: {},
    columnsFactory: () => [
      { type: 'index', width: 60, label: '序号' },
      { prop: 'name', label: '分类名称', width: 150 },
      { prop: 'icon', label: '图标', width: 120, formatter: (row: CategoryRecord) => row.icon || '-' },
      { prop: 'sortOrder', label: '排序', width: 80, align: 'center' },
      { prop: 'status', label: '状态', width: 80, formatter: (row: CategoryRecord) => { const c = STATUS_CONFIG[row.status] || { type: 'info' as const, text: '未知' }; return h(ElTag, { type: c.type, size: 'small' }, () => c.text) } },
      { prop: 'createTime', label: '创建时间', width: 180 },
      { prop: 'operation', label: '操作', width: 140, fixed: 'right', formatter: (row: CategoryRecord) => h('div', { style: { display: 'flex', gap: '8px' } }, [h(ArtButtonTable, { type: 'edit', onClick: () => showDialog('edit', row) }), h(ArtButtonTable, { type: 'delete', onClick: () => deleteCategory(row) })]) }
    ]
  }
})

getData()

const showDialog = (type: DialogType, row?: CategoryRecord) => {
  dialogType.value = type
  if (type === 'edit' && row) {
    currentRow.value = row
    Object.assign(formData, { name: row.name, icon: row.icon || '', sortOrder: row.sortOrder || 0, status: row.status || '1' })
  } else {
    currentRow.value = {}
    Object.assign(formData, { name: '', icon: '', sortOrder: 0, status: '1' })
  }
  nextTick(() => { dialogVisible.value = true; formRef.value?.clearValidate() })
}

const handleSubmit = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    const params: Record<string, unknown> = { name: formData.name, icon: formData.icon, sortOrder: formData.sortOrder, status: formData.status }
    if (dialogType.value === 'edit' && currentRow.value.id) params.id = currentRow.value.id
    await fetchSaveCategory(params)
    ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
    dialogVisible.value = false
    refreshData()
  })
}

const deleteCategory = (row: CategoryRecord) => {
  ElMessageBox.confirm(`确定要删除分类「${row.name}」吗？`, '删除分类', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
    await fetchDeleteCategory(row.id)
    ElMessage.success('删除成功')
    refreshData()
  }).catch(() => {})
}

// ─── 应用集 ───
const colLoading = ref(false)
const colList = ref<any[]>([])

async function loadCollections() {
  colLoading.value = true
  try {
    const res: any = await fetchCollections()
    colList.value = res || []
  } catch { colList.value = [] }
  finally { colLoading.value = false }
}

// ─── 排行榜 ───
const rankType = ref('hot')
const rankTabs = [
  { key: 'hot', label: '热门' },
  { key: 'new', label: '最新' },
  { key: 'apps', label: '最多应用' }
]
const rankLoading = ref(false)
const rankList = ref<any[]>([])

async function loadRanking() {
  rankLoading.value = true
  try {
    const res: any = await fetchCollectionRanking({ type: rankType.value, pageSize: 50 })
    rankList.value = res || []
  } catch { rankList.value = [] }
  finally { rankLoading.value = false }
}

// ─── 公共 ───
function switchTab(key: string) {
  activeTab.value = key
  if (key === 'collections' && !colList.value.length) loadCollections()
  if (key === 'ranking' && !rankList.value.length) loadRanking()
}

function switchRankTab(key: string) {
  rankType.value = key
  loadRanking()
}

function goCollection(id: number) {
  router.push(`/appstore/collection/${id}`)
}

function formatNum(n: number) {
  if (!n && n !== 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(0) + '万'
  return String(n)
}

onMounted(() => loadCollections())
</script>

<style scoped>
.category-page { min-height: 100vh; background: #fff; }

/* ── Tabs ── */
.page-tabs {
  display: flex; gap: 4px; padding: 12px 16px;
  background: #fff; position: sticky; top: 0; z-index: 10;
  border-bottom: 1px solid #F0F0F5;
}
.tab-btn {
  flex: 1; padding: 8px 0; border-radius: 10px;
  border: none; background: #F3F4F6; color: #6B7280;
  font-size: 14px; font-weight: 600; cursor: pointer;
  transition: all .2s;
}
.tab-btn.active {
  background: linear-gradient(135deg, #6366F1, #8B5CF6);
  color: #fff; box-shadow: 0 2px 8px rgba(99,102,241,.3);
}
.tab-btn:active { transform: scale(.97); }

/* ── 应用集 Grid ── */
.collections-grid {
  display: grid; grid-template-columns: repeat(2, 1fr);
  gap: 12px; padding: 16px;
}
.col-card {
  border-radius: 14px; overflow: hidden; background: #fff;
  box-shadow: 0 2px 12px rgba(0,0,0,.06);
  cursor: pointer; transition: transform .2s, box-shadow .2s;
}
.col-card:active { transform: scale(.96); box-shadow: 0 1px 6px rgba(0,0,0,.08); }
.col-cover {
  width: 100%; height: 100px; overflow: hidden;
}
.col-cover img {
  width: 100%; height: 100%; object-fit: cover;
}
.col-cover-fb {
  width: 100%; height: 100%; display: flex;
  align-items: center; justify-content: center;
}
.col-body { padding: 10px 12px 14px; }
.col-name {
  font-size: 14px; font-weight: 700; color: #1A1A2E;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.col-author {
  font-size: 11px; color: #9CA3AF; margin-top: 2px;
}
.col-meta {
  display: flex; gap: 8px; margin-top: 6px;
  font-size: 11px; color: #9CA3AF;
}
.col-meta-item {
  display: flex; align-items: center; gap: 3px;
}
.col-desc {
  font-size: 11px; color: #B0B0B8; margin-top: 6px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

/* ── 排行榜 ── */
.ranking-tabs {
  display: flex; gap: 4px; padding: 12px 16px;
}
.rank-tab {
  padding: 6px 16px; border-radius: 16px;
  border: none; background: #F3F4F6; color: #6B7280;
  font-size: 12px; font-weight: 600; cursor: pointer;
  transition: all .2s;
}
.rank-tab.active { background: #6366F1; color: #fff; }
.rank-tab:active { transform: scale(.97); }

.rank-list { padding: 0 16px 32px; display: flex; flex-direction: column; gap: 8px; }
.rank-row {
  display: flex; align-items: center; gap: 12px;
  padding: 12px; border-radius: 12px;
  background: #FAFBFC; cursor: pointer;
  transition: background .2s;
}
.rank-row:active { background: #F0F1F6; }
.rank-num {
  width: 28px; text-align: center; font-size: 14px; font-weight: 700;
  color: #9CA3AF; flex-shrink: 0;
}
.rank-num.rank-1, .rank-num.rank-2, .rank-num.rank-3 { font-size: 0; }
.rank-cover {
  width: 44px; height: 44px; border-radius: 10px; overflow: hidden;
  flex-shrink: 0; background: #E5E7EB;
}
.rank-cover img { width: 100%; height: 100%; object-fit: cover; }
.rank-cover-fb { width: 100%; height: 100%; }
.rank-body { flex: 1; min-width: 0; }
.rank-name {
  font-size: 14px; font-weight: 600; color: #1A1A2E;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.rank-meta {
  display: flex; gap: 8px; margin-top: 4px;
  font-size: 11px; color: #9CA3AF;
}

/* ── 状态 ── */
.loading-state { text-align: center; padding: 60px 0; color: #9CA3AF; font-size: 14px; }
.empty-state { text-align: center; padding: 60px 0; color: #B0B0B8; font-size: 14px; }
</style>
