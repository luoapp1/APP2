<template>
  <Teleport to="body">
    <div v-if="visible" class="menu-overlay" @click="$emit('update:visible', false)">
      <div class="menu-panel" @click.stop>
        <div class="menu-item" @click="handleShare">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/></svg>
          <span>分享</span>
        </div>
        <div v-if="(post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin())" class="menu-item" @click="goEditPost(); $emit('update:visible', false)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          <span>编辑</span>
        </div>
        <div v-if="(post as any)?.isLocked" class="menu-item menu-item-locked" @click="$emit('update:visible', false)">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          <span>{{ userIsAdmin() ? '已锁定(管理员可管理)' : '已锁定' }}</span>
        </div>
        <template v-if="hasCommunityPermission('pin') || hasCommunityPermission('essence') || hasCommunityPermission('boost') || hasCommunityPermission('lock')">
          <div class="menu-divider" />
          <div v-if="hasCommunityPermission('pin')" class="menu-item" @click="handlePinPin(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 7h6l-4 5 2 8-7-4-7 4 2-8-4-5h6z"/></svg>
            <span>{{ post?.isPinned ? '取消置顶' : '置顶' }}</span>
          </div>
          <div v-if="hasCommunityPermission('pin')" class="menu-item" @click="handleGlobalPin(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            <span>{{ (post as any)?.isGlobalPinned ? '取消全站置顶' : '全站置顶' }}</span>
          </div>
          <div v-if="hasCommunityPermission('essence')" class="menu-item" @click="handleEssence(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26"/></svg>
            <span>{{ post?.isEssence ? '取消加精' : '加精' }}</span>
          </div>
          <div v-if="hasCommunityPermission('boost')" class="menu-item" @click="handleHot(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"/></svg>
            <span>{{ post?.isHot ? '取消热帖' : '热帖' }}</span>
          </div>
          <div v-if="hasCommunityPermission('boost')" class="menu-item" @click="handleCustomBadge(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 12h8M12 8v8"/></svg>
            <span>{{ (post as any)?.customBadge ? '修改自定义' : '自定义' }}</span>
          </div>
          <div v-if="hasCommunityPermission('lock')" class="menu-item" @click="handleLock(); $emit('update:visible', false)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            <span>{{ (post as any)?.isLocked ? '解锁' : '锁定' }}</span>
          </div>
        </template>
        <template v-if="(post as any)?.isDeleted ? post?.userId === getUserId() : ((post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin()))">
          <div class="menu-divider" />
          <template v-if="(post as any)?.isDeleted">
            <div class="menu-item menu-item-restore" @click="handleRestorePost(); $emit('update:visible', false)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
              <span>恢复帖子</span>
            </div>
            <div class="menu-item menu-item-danger" @click="handlePermanentDeletePost(); $emit('update:visible', false)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
              <span>永久删除</span>
            </div>
          </template>
          <template v-else>
            <div class="menu-item menu-item-danger" @click="handleDeletePost(); $emit('update:visible', false)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              <span>删除</span>
            </div>
          </template>
        </template>
         <div v-if="getUserId()" class="menu-item" @click="$emit('report', (post as any)?.id || 0); $emit('update:visible', false)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></svg>
          <span>举报</span>
        </div>
        <div v-if="(post as any)?.isLocked && post?.userId === getUserId() && !userIsAdmin()" class="menu-item" @click="handleRequestUnlock(); $emit('update:visible', false)">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
          <span>申请解锁</span>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useMenuStore } from '@/store/modules/menu'
import { storeToRefs } from 'pinia'
import { pinPost, essencePost, hotPost, lockPost, globalPinPost, setCustomBadge, requestUnlock } from '@/api/community'
import type { CommunityPost } from '@/api/community'

const props = defineProps<{
  post: CommunityPost | null
  visible: boolean
}>()

const emit = defineEmits<{
  'update:visible': [v: boolean]
  'report': [id: number]
  'close': []
}>()

const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()
const { menuList } = storeToRefs(menuStore)

function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }

function hasCommunityPermission(authMark: string): boolean {
  const findAuthList = (nodes: any[]): any[] | null => {
    for (const n of nodes) {
      if (n.name === 'CommunityPostManage' && n.meta?.authList?.length) return n.meta.authList
      if (n.children?.length) {
        const result = findAuthList(n.children)
        if (result) return result
      }
    }
    return null
  }
  const authList = findAuthList(menuList.value as any[])
  if (!authList) return userIsAdmin()
  return authList.some((a: any) => a.authMark === authMark)
}

async function handleShare() {
  const url = window.location.href
  try {
    await navigator.clipboard.writeText(url)
    ElMessage.success('链接已复制')
  } catch {
    ElMessage.info(url)
  }
  emit('update:visible', false)
}

function goEditPost() {
  if (!props.post) return
  router.push(`/community/post/edit/${btoa(String(props.post.id))}`)
}

async function handlePinPin() {
  if (!props.post) return
  try { const r: any = await pinPost(props.post.id, getUserId()); const d = r.data || r; props.post.isPinned = d.isPinned; ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶') } catch {}
}

async function handleGlobalPin() {
  if (!props.post) return
  try { const r: any = await globalPinPost(props.post.id, getUserId()); const d = r.data || r; (props.post as any).isGlobalPinned = d.isGlobalPinned; ElMessage.success(d.isGlobalPinned ? '已全站置顶' : '已取消全站置顶') } catch {}
}

async function handleEssence() {
  if (!props.post) return
  try { const r: any = await essencePost(props.post.id, getUserId()); const d = r.data || r; props.post.isEssence = d.isEssence; ElMessage.success(d.isEssence ? '已加精' : '已取消加精') } catch {}
}

async function handleHot() {
  if (!props.post) return
  try { const r: any = await hotPost(props.post.id, getUserId()); const d = r.data || r; props.post.isHot = d.isHot; ElMessage.success(d.isHot ? '已设为热帖' : '已取消热帖') } catch {}
}

async function handleCustomBadge() {
  if (!props.post) return
  try {
    const { value } = await ElMessageBox.prompt('请输入自定义徽章文字（留空则清除）', '自定义徽章', {
      confirmButtonText: '确定', cancelButtonText: '取消',
      inputValue: (props.post as any).customBadge || '',
      inputPlaceholder: '最多10个字',
      inputValidator: (v: string) => v.length <= 10 || '最多10个字'
    })
    const badge = value ? value.trim() : ''
    const r: any = await setCustomBadge(props.post.id, badge)
    const d = r.data || r;
    (props.post as any).customBadge = d.customBadge
    ElMessage.success(d.customBadge ? '自定义徽章已设置' : '自定义徽章已清除')
  } catch {}
}

async function handleLock() {
  if (!props.post) return
  try { const r: any = await lockPost(props.post.id, getUserId()); const d = r.data || r; (props.post as any).isLocked = d.isLocked; ElMessage.success(d.isLocked ? '已锁定' : '已解锁') } catch {}
}

async function handleDeletePost() {
  if (!props.post) return
  try {
    await ElMessageBox.confirm('确定要删除该帖子吗？删除后帖子将移入回收站，可恢复。', '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    const u = getUserId()
    const res = await fetch(`/api/community/post/${props.post.id}`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken }, body: JSON.stringify({ userId: u }) })
    const data = await res.json()
    if (data.code === 200) { ElMessage.success('已移入回收站'); router.replace('/community') }
    else { ElMessage.error(data.msg || '删除失败') }
  } catch {}
}

async function handleRestorePost() {
  if (!props.post) return
  try {
    await ElMessageBox.confirm('确定要恢复该帖子吗？', '确认恢复', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'info' })
    const u = getUserId()
    const res = await fetch(`/api/community/post/${props.post.id}/restore`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken }, body: JSON.stringify({ userId: u }) })
    const data = await res.json()
    if (data.code === 200) { ElMessage.success('帖子已恢复'); router.go(0) }
    else { ElMessage.error(data.msg || '恢复失败') }
  } catch {}
}

async function handlePermanentDeletePost() {
  if (!props.post) return
  try {
    await ElMessageBox.confirm('永久删除后将无法恢复，确定要永久删除吗？', '永久删除', { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' })
    const u = getUserId()
    const res = await fetch(`/api/community/post/${props.post.id}/permanent`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken }, body: JSON.stringify({ userId: u }) })
    const data = await res.json()
    if (data.code === 200) { ElMessage.success('已永久删除'); router.replace('/community') }
    else { ElMessage.error(data.msg || '删除失败') }
  } catch {}
}

async function handleRequestUnlock() {
  if (!props.post) return
  try {
    await requestUnlock(props.post.id)
    ElMessage.success('解锁申请已提交，等待管理员审核')
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || '申请失败，请稍后再试')
  }
}
</script>

<style scoped>
.menu-overlay {
  position: fixed; inset: 0; z-index: 9999;
  background: transparent;
}
.menu-panel {
  position: absolute;
  top: 50px; right: 12px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,.12), 0 1px 4px rgba(0,0,0,.06);
  min-width: 160px;
  padding: 8px 0;
  overflow: hidden;
  animation: menuIn .18s cubic-bezier(.25,.8,.25,1);
}
@keyframes menuIn {
  from { opacity: 0; transform: translateY(-6px) scale(.95); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}
.menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  font-size: 14px;
  color: #333;
  cursor: pointer;
  transition: background .12s;
  user-select: none;
}
.menu-item:active { background: #f2f3f5; }
.menu-item svg {
  width: 18px; height: 18px;
  flex-shrink: 0;
  color: #888;
}
.menu-item span {
  white-space: nowrap;
}
.menu-item-danger { color: #e44; }
.menu-item-danger svg { color: #e44; }
.menu-item-danger:active { background: #fef0f0; }
.menu-item-restore { color: #22c55e; }
.menu-item-restore svg { color: #22c55e; }
.menu-item-restore:active { background: #f0fdf4; }
.menu-item-locked { color: #9CA3AF; pointer-events: none; }
.menu-item-locked svg { color: #9CA3AF; }
.menu-divider {
  height: 1px;
  background: #eee;
  margin: 4px 12px;
}
</style>
