<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <!-- 顶部标题栏 -->
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">用户管理</span>
    </div>

    <!-- 统计卡片 -->
    <div class="bg-white mx-3 mt-3 rounded-xl p-4">
      <div class="flex items-start justify-between mb-2">
        <div>
          <div class="text-xs text-gray-400 mb-1">用户总数</div>
          <div class="text-2xl font-bold text-[#FF4757]">{{ total }}</div>
        </div>
        <div class="text-right">
          <div class="text-xs text-gray-400 mb-1">数据总量</div>
          <div class="text-2xl font-bold text-[#1E90FF]">{{ formatBytes(totalUsedBytes) }}</div>
        </div>
      </div>
      <div class="flex items-center justify-between border-t border-gray-50 pt-2">
        <div class="flex items-center gap-1 text-xs text-gray-400">
          <span class="inline-block w-2 h-2 rounded-full bg-[#059669]"></span>正常 {{ totalStats.active }}
        </div>
        <div class="flex items-center gap-1 text-xs text-gray-400">
          <span class="inline-block w-2 h-2 rounded-full bg-[#d97706]"></span>异常 {{ totalStats.warning }}
        </div>
        <div class="flex items-center gap-1 text-xs text-gray-400">
          <span class="inline-block w-2 h-2 rounded-full bg-[#dc2626]"></span>注销 {{ totalStats.deleted }}
        </div>
      </div>
    </div>

    <!-- 操作栏 -->
    <div class="bg-white mx-3 mt-3 rounded-xl p-3">
      <!-- 搜索 -->
      <div class="flex gap-2 mb-3">
        <input
          v-model="searchKey"
          type="text"
          placeholder="搜索用户名/手机号"
          class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"
          @keyup.enter="handleSearch"
        />
        <button class="h-9 px-4 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="handleSearch">
          搜索
        </button>
      </div>

      <!-- 排序和每页数 -->
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-1.5">
          <span class="text-xs text-gray-400">排序:</span>
          <select
            v-model="sortField"
            class="text-xs px-2 py-1 bg-[#f5f6f8] rounded border-none outline-none text-gray-600"
            @change="handleSearch"
          >
            <option value="id">ID</option>
            <option value="createTime">注册时间</option>
          </select>
          <button
            class="text-xs px-2 py-1 rounded bg-[#f5f6f8] text-gray-500 active:opacity-70"
            @click="toggleSortOrder"
          >{{ sortOrder === 'desc' ? '降序' : '升序' }}</button>
        </div>

        <div class="flex items-center gap-1.5">
          <span class="text-xs text-gray-400">每页:</span>
          <select
            v-model="pageSize"
            class="text-xs px-2 py-1 bg-[#f5f6f8] rounded border-none outline-none text-gray-600"
            @change="handlePageSizeChange"
          >
            <option :value="10">10</option>
            <option :value="15">15</option>
            <option :value="20">20</option>
            <option :value="50">50</option>
          </select>
        </div>
      </div>
    </div>

    <!-- 无权限提示 -->
    <div v-if="!isAdmin" class="flex-1 flex flex-col items-center justify-center px-6">
      <svg class="w-20 h-20 text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
      </svg>
      <span class="text-base font-semibold text-gray-500 mb-2">无权访问</span>
      <span class="text-sm text-gray-400 text-center">您没有管理员权限，无法查看用户管理</span>
      <button class="mt-5 px-6 py-2 bg-[#FF4757] text-white text-sm rounded-lg active:opacity-80" @click="$router.back()">返回上一页</button>
    </div>

    <!-- 加载中 -->
    <div v-else-if="loading" class="flex-1 flex items-center justify-center">
      <div class="animate-spin w-6 h-6 border-2 border-[#FF4757] border-t-transparent rounded-full" />
    </div>

    <!-- 用户列表 -->
    <div v-else class="flex-1 overflow-y-auto px-3 pb-3">
      <div v-if="list.length === 0" class="flex flex-col items-center justify-center py-20 text-gray-400">
        <svg class="w-16 h-16 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
        </svg>
        <span class="text-sm">暂无用户数据</span>
      </div>

      <!-- 用户卡片 -->
      <div
        v-for="(user, idx) in list"
        :key="user.id"
        class="bg-white mt-3 rounded-xl p-3 active:bg-gray-50 cursor-pointer transition-colors"
        @click="openUserDetail(user)"
      >
        <div class="flex items-center gap-3">
          <!-- 头像 -->
          <div class="relative flex-shrink-0">
            <img
              :src="$fixImgUrl(user.avatar || defaultAvatar)"
              class="w-11 h-11 rounded-full object-cover"
              @error="(e) => { e.target.src = defaultAvatar }"
            />
            <span
              class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white"
              :class="statusDot(user.status)"
            ></span>
          </div>

          <!-- 主体信息 -->
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <span class="text-sm font-semibold text-gray-800 truncate max-w-[120px]">{{ user.userName }}</span>
                <span
                  class="text-[10px] px-1.5 py-0.5 rounded-full font-medium flex-shrink-0"
                  :class="statusBadge(user.status)"
                >{{ statusText(user.status) }}</span>
              </div>
              <span class="text-xs text-gray-400">#{{ user.id }}</span>
            </div>

            <div class="flex items-center gap-3 mt-1.5 text-xs text-gray-500">
              <span v-if="user.userPhone" class="flex items-center gap-1">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                {{ user.userPhone }}
              </span>
            </div>

            <div class="flex items-center gap-2 mt-1.5">
              <span class="text-[10px] px-1.5 py-0.5 rounded bg-[#eff6ff] text-[#2563eb]">{{ user.levelName || '普通会员' }}</span>
              <span v-if="user.expireTime" class="text-[10px] text-gray-400">{{ formatExpire(user.expireTime) }}</span>
            </div>
          </div>

          <!-- 箭头 -->
          <svg class="w-4 h-4 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
          </svg>
        </div>
      </div>

      <!-- 分页栏 -->
      <div class="flex items-center justify-center gap-3 mt-4 pb-2">
        <button
          :disabled="currentPage <= 1"
          class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70"
          @click="goPage(currentPage - 1)"
        >上一页</button>

        <div class="flex items-center gap-1">
          <button
            v-for="p in pageNumbers"
            :key="p"
            class="w-7 h-7 text-xs rounded-lg"
            :class="p === currentPage ? 'bg-[#FF4757] text-white' : 'bg-white text-gray-500 shadow-sm'"
            @click="goPage(p)"
          >{{ p }}</button>
        </div>

        <button
          :disabled="currentPage >= totalPages"
          class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70"
          @click="goPage(currentPage + 1)"
        >下一页</button>
      </div>

      <!-- 分页信息 -->
      <div class="text-center text-xs text-gray-400 pb-4">
        共 {{ total }} 条 / {{ totalPages }} 页
      </div>
    </div>

    <!-- 用户详情/编辑弹窗 -->
    <div v-if="showDetail" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showDetail = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <!-- 弹窗头部 -->
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0">
          <button class="text-gray-400 text-sm" @click="showDetail = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">{{ isEditing ? '编辑用户' : '用户详情' }}</span>
          <button v-if="!isEditing" v-auth="'edit'" class="text-sm font-semibold text-[#FF4757]" @click="startEdit">编辑</button>
          <button v-else v-auth="'edit'" class="text-sm font-semibold text-[#FF4757]" @click="saveEdit">保存</button>
        </div>

        <!-- 滚动内容 -->
        <div class="flex-1 overflow-y-auto">
          <!-- 头像区域 -->
          <div class="flex flex-col items-center py-6 bg-gradient-to-b from-red-50 to-white">
            <div class="relative mb-3">
              <img
                :src="$fixImgUrl(detailUser.avatar || defaultAvatar)"
                class="w-20 h-20 rounded-full object-cover ring-4 ring-white shadow-lg"
                @error="(e) => { e.target.src = defaultAvatar }"
              />
              <span
                class="absolute bottom-0 right-0 w-5 h-5 rounded-full border-[3px] border-white shadow-sm"
                :class="statusDot(detailUser.status)"
              ></span>
            </div>
            <span class="text-lg font-bold text-gray-800">{{ detailUser.userName }}</span>
            <div class="flex items-center gap-2 mt-1">
              <span class="text-xs text-gray-400">ID: {{ detailUser.id }}</span>
              <span class="text-[10px] px-2 py-0.5 rounded-full font-medium" :class="statusBadge(detailUser.status)">{{ statusText(detailUser.status) }}</span>
              <span v-if="communityProfile.trustLevelName" class="text-[10px] px-2 py-0.5 rounded-full font-medium bg-purple-100 text-purple-600">{{ communityProfile.trustLevelName }}</span>
            </div>
            <!-- 统计 -->
            <div class="flex gap-6 mt-3">
              <div class="text-center">
                <div class="text-base font-bold text-gray-800">{{ detailUser.postCount || 0 }}</div>
                <div class="text-[10px] text-gray-400">动态</div>
              </div>
              <div class="text-center">
                <div class="text-base font-bold text-gray-800">{{ detailUser.followCount || 0 }}</div>
                <div class="text-[10px] text-gray-400">关注</div>
              </div>
              <div class="text-center">
                <div class="text-base font-bold text-gray-800">{{ detailUser.fansCount || 0 }}</div>
                <div class="text-[10px] text-gray-400">粉丝</div>
              </div>
            </div>
          </div>

          <!-- 货币资产 -->
          <div class="px-4 mb-4">
            <div class="bg-gray-50 rounded-xl p-4">
              <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold text-gray-400 uppercase tracking-wide">货币资产</span>
                <button
                  v-if="!currencyEditing"
                  class="text-[10px] px-3 py-1 rounded-lg bg-[#FF4757] text-white font-medium active:opacity-80"
                  @click="startCurrencyEdit"
                >编辑</button>
                <div v-else class="flex gap-2">
                  <button
                    class="text-[10px] px-3 py-1 rounded-lg bg-gray-200 text-gray-600 font-medium active:opacity-80"
                    @click="cancelCurrencyEdit"
                  >取消</button>
                  <button
                    class="text-[10px] px-3 py-1 rounded-lg bg-[#FF4757] text-white font-medium active:opacity-80"
                    :disabled="currencySaving"
                    @click="saveCurrencyEdit"
                  >{{ currencySaving ? '保存中...' : '保存' }}</button>
                </div>
              </div>
              <div v-if="userCurrencies.length === 0 && !currencyLoading" class="text-xs text-gray-400 py-2">暂无货币数据</div>
              <div v-for="c in userCurrencies" :key="c.currency_key" class="flex items-center gap-2 py-2 border-b border-gray-100 last:border-0">
                <span class="text-sm font-medium text-gray-700 w-16 flex-shrink-0">{{ c.display_name }}</span>
                <template v-if="!currencyEditing">
                  <span class="text-xs text-gray-500">{{ c.total }}{{ c.display_symbol }}</span>
                </template>
                <template v-else>
                  <input
                    v-model.number="c.editTarget"
                    type="number"
                    step="0.01"
                    class="flex-1 h-8 px-2 text-xs bg-white rounded-lg border border-gray-200 outline-none focus:border-[#FF4757] min-w-0"
                  />
                  <span class="text-[10px] text-gray-400 flex-shrink-0">{{ c.display_symbol }}</span>
                </template>
              </div>
            </div>
          </div>

          <!-- 会员购买记录 -->
          <div class="px-4 mb-4">
            <div class="bg-gray-50 rounded-xl p-4">
              <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-semibold text-gray-400 uppercase tracking-wide">已购会员 ({{ groupedPurchases.length }}种)</span>
              </div>
              <div v-if="groupedPurchases.length === 0" class="text-xs text-gray-400 py-2">暂无购买记录</div>
              <div v-for="gp in groupedPurchases" :key="gp.levelName" class="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <span class="text-sm font-medium text-gray-800">{{ gp.levelName }}</span>
                <span class="text-xs text-gray-500">{{ gp.expireTime ? '到期: ' + formatExpire(gp.expireTime) : '永久' }}</span>
              </div>
            </div>
          </div>

          <!-- 角色标签 -->
          <div v-if="detailUser.userRoles && detailUser.userRoles.length" class="px-4 mb-4">
            <div class="flex gap-1 flex-wrap">
              <span v-for="r in detailUser.userRoles" :key="r" class="text-[10px] px-2 py-0.5 rounded-full bg-[#fef0f0] text-[#FF4757] font-medium">{{ r }}</span>
            </div>
          </div>

          <!-- 社区角色（只读） -->
          <div v-if="!isEditing && communityProfile && communityProfile.trustLevelName" class="px-4 mb-4">
            <div class="bg-purple-50 rounded-xl p-4">
              <div class="flex items-center gap-2 mb-3">
                <svg class="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                <span class="text-xs font-semibold text-purple-500">社区信息</span>
              </div>
              <div class="space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">信任等级</span>
                  <span class="text-xs font-bold text-purple-600">{{ communityProfile.trustLevelName }}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">帖子数</span>
                  <span class="text-xs text-gray-800">{{ communityProfile.postCount }}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">评论数</span>
                  <span class="text-xs text-gray-800">{{ communityProfile.commentCount }}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">被举报</span>
                  <span class="text-xs" :class="communityProfile.reportCount > 0 ? 'text-red-500' : 'text-gray-800'">{{ communityProfile.reportCount }}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-xs text-gray-500">封禁状态</span>
                  <span class="text-xs font-medium" :class="communityProfile.banStatus.banned ? 'text-red-500' : 'text-green-500'">{{ communityProfile.banStatus.banned ? '已封禁' : '正常' }}</span>
                </div>
                <div v-if="communityProfile.moderatorSections && communityProfile.moderatorSections.length" class="pt-2 border-t border-purple-200">
                  <span class="text-xs text-gray-500 block mb-1">管理板块</span>
                  <span v-for="ms in communityProfile.moderatorSections" :key="ms.sectionId" class="inline-block text-[10px] px-2 py-0.5 rounded-full bg-purple-200 text-purple-700 mr-1 mb-1">{{ ms.sectionName }} - {{ ms.role }}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 社区角色管理（编辑模式） -->
          <div v-if="isEditing" class="bg-purple-50 rounded-2xl p-4 mb-4">
            <div class="flex items-center gap-2 mb-3">
              <svg class="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
              <span class="text-xs font-semibold text-purple-500">社区角色管理</span>
            </div>
            <!-- 信任等级显示 -->
            <div class="flex items-center justify-between mb-3 bg-white rounded-xl p-2.5">
              <span class="text-xs text-gray-500">信任等级</span>
              <span class="text-xs font-bold text-purple-600">{{ communityProfile.trustLevelName || '新手' }} ({{ communityProfile.postCount || 0 }}帖 / {{ communityProfile.commentCount || 0 }}评)</span>
            </div>
            <!-- 版主管理 -->
            <div class="mb-3">
              <div class="text-[10px] text-gray-400 mb-1.5">板块管理权限</div>
              <div v-if="communityProfile.moderatorSections && communityProfile.moderatorSections.length" class="space-y-1 mb-2">
                <div v-for="ms in communityProfile.moderatorSections" :key="ms.sectionId" class="flex items-center justify-between bg-white rounded-lg px-2.5 py-1.5">
                  <span class="text-xs text-gray-800">{{ ms.sectionName }} - <span class="text-[#FF4757]">{{ ms.role }}</span></span>
                  <button class="text-[10px] text-red-400 px-1.5 py-0.5 rounded active:bg-red-50" @click="removeModerator(ms.sectionId)">移除</button>
                </div>
              </div>
              <div v-else class="text-xs text-gray-400 py-1">暂无板块管理权限</div>
              <div class="flex gap-1 mt-2">
                <select v-model="addModSectionId" class="flex-1 text-xs bg-white rounded-lg px-2 py-1.5 border border-gray-100 outline-none">
                  <option :value="0">选择板块</option>
                  <option v-for="s in sections" :key="s.id" :value="s.id">{{ s.name }}</option>
                </select>
                <button class="text-[10px] px-3 py-1.5 bg-purple-500 text-white rounded-lg font-medium active:opacity-80 disabled:opacity-30" :disabled="addModSectionId <= 0" @click="addModerator">授权</button>
              </div>
            </div>
            <!-- 封禁状态 -->
            <div class="flex items-center justify-between bg-white rounded-xl p-2.5">
              <span class="text-xs text-gray-500">封禁状态</span>
              <span v-if="communityProfile.banStatus.banned" class="text-xs font-medium text-red-500">已封禁</span>
              <span v-else class="text-xs font-medium text-green-500">正常</span>
            </div>
          </div>

          <!-- 详情/编辑区域 -->
          <div class="px-4 pb-6">
            <template v-if="!isEditing">
              <!-- 只读详情 -->
              <div class="space-y-0">
                <div class="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">基本信息</div>
                <div v-for="item in detailFields" :key="item.key" class="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
                  <span class="text-sm text-gray-500">{{ item.label }}</span>
                  <span class="text-sm text-gray-800 font-medium text-right max-w-[60%] truncate">{{ item.value }}</span>
                </div>
              </div>
            </template>

            <template v-if="isEditing">
              <div class="space-y-4">
                <!-- 基础信息卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">基础信息</span>
                  </div>
                  <div class="space-y-3">
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">用户名</div>
                      <div class="relative">
                        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                        <input v-model="editForm.username" class="w-full text-sm text-gray-800 bg-white rounded-xl pl-9 pr-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all" />
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">手机号</div>
                      <div class="relative">
                        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                        <input v-model="editForm.phone" class="w-full text-sm text-gray-800 bg-white rounded-xl pl-9 pr-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all" />
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">邮箱</div>
                      <div class="relative">
                        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                        <input v-model="editForm.email" class="w-full text-sm text-gray-800 bg-white rounded-xl pl-9 pr-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all" />
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">性别</div>
                      <div class="flex gap-2">
                        <button
                          v-for="g in ['男', '女']" :key="g"
                          class="flex-1 py-2 text-sm rounded-xl font-medium transition-all"
                          :class="editForm.gender === g ? 'bg-[#FF4757] text-white shadow-sm shadow-red-200' : 'bg-white text-gray-400 border border-gray-100'"
                          @click="editForm.gender = g"
                        >{{ g }}</button>
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">昵称</div>
                      <div class="relative">
                        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                        <input v-model="editForm.nickname" class="w-full text-sm text-gray-800 bg-white rounded-xl pl-9 pr-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all" />
                      </div>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">个人介绍</div>
                      <textarea v-model="editForm.bio" rows="2" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all resize-none" placeholder="介绍一下..." />
                    </div>
                  </div>
                </div>

                <!-- 资产信息卡片 -->
                <!-- 补充信息卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#6366F1]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">补充信息</span>
                  </div>
                  <div class="space-y-3">
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">生日</div>
                      <input v-model="editForm.birthday" type="date" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">交友QQ</div>
                      <input v-model="editForm.qq" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">认证称号</div>
                      <input v-model="editForm.signature" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">注册地址</div>
                      <input v-model="editForm.register_address" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">背景图片URL</div>
                      <input v-model="editForm.bg_url" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                  </div>
                </div>

                <!-- 存储配额卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#00BFA5]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2 1 3 3 3h10c2 0 3-1 3-3V7M4 7c0-2 1-3 3-3h10c2 0 3 1 3 3M4 7h16M9 3v18"/></svg>
                    <span class="text-xs font-semibold text-gray-500">存储配额</span>
                  </div>
                  <div class="grid grid-cols-3 gap-3">
                    <div>
                      <div class="text-[10px] text-gray-400 mb-1">已用存储</div>
                      <input v-model.number="editForm.used_bytes" type="number" class="w-full text-sm font-semibold text-[#00BFA5] text-center bg-white rounded-xl py-2.5 outline-none border border-gray-100 focus:border-[#00BFA5] focus:ring-1 focus:ring-teal-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[10px] text-gray-400 mb-1">数据配额(MB)</div>
                      <input v-model.number="editForm.bonus_data_limit_mb" type="number" class="w-full text-sm font-semibold text-[#6366F1] text-center bg-white rounded-xl py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                    </div>
                    <div>
                      <div class="text-[10px] text-gray-400 mb-1">文件配额</div>
                      <input v-model.number="editForm.bonus_file_limit_mb" type="number" class="w-full text-sm font-semibold text-[#FF8C42] text-center bg-white rounded-xl py-2.5 outline-none border border-gray-100 focus:border-[#FF8C42] focus:ring-1 focus:ring-orange-100 transition-all" />
                    </div>
                  </div>
                </div>

                <!-- 会员购买记录 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                      <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>
                      <span class="text-xs font-semibold text-gray-500">添加会员购买记录</span>
                    </div>
                    <button class="text-[10px] px-3 py-1.5 bg-[#FF4757] text-white rounded-lg font-medium" @click="addMemberPurchase">+ 添加</button>
                  </div>
                  <div v-for="(mp, i) in editForm.memberPurchases" :key="i" class="bg-white rounded-xl p-3 mb-2">
                    <div class="flex items-center gap-2 mb-2">
                      <select v-model="mp.levelId" class="flex-1 text-xs bg-[#f5f6f8] rounded-lg px-2 py-1.5 border-none outline-none">
                        <option :value="0">选择等级</option>
                        <option v-for="lv in mLvs" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
                      </select>
                      <button class="text-xs text-red-400 px-2 py-1" @click="editForm.memberPurchases.splice(i, 1)">删除</button>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                      <div>
                        <div class="text-[9px] text-gray-400 mb-0.5">有效期(天)</div>
                        <input v-model.number="mp.durationDays" type="number" class="w-full text-xs bg-[#f5f6f8] rounded-lg px-2 py-1.5 outline-none" placeholder="如 365" />
                      </div>
                      <div>
                        <div class="text-[9px] text-gray-400 mb-0.5">金额</div>
                        <input v-model.number="mp.amount" type="number" step="0.01" class="w-full text-xs bg-[#f5f6f8] rounded-lg px-2 py-1.5 outline-none" placeholder="0" />
                      </div>
                    </div>
                  </div>
                </div>

                <!-- 会员信息卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">会员信息</span>
                  </div>
                  <div class="space-y-3">
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">会员等级</div>
                      <select v-model.number="editForm.level_id" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all appearance-none">
                        <option :value="0">普通会员</option>
                        <option v-for="lv in mLvs" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
                      </select>
                    </div>
                    <div>
                      <div class="text-[11px] text-gray-400 mb-1">会员到期时间</div>
                      <input v-model="editForm.expireTime" type="datetime-local" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#FF4757] focus:ring-1 focus:ring-red-100 transition-all" />
                    </div>
                  </div>
                </div>

                <!-- 角色设置卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#FF8C42]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">角色设置</span>
                  </div>
                  <div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
                    <button
                      v-for="r in roleOpts" :key="r.code"
                      class="flex-shrink-0 px-4 py-2.5 text-xs rounded-xl font-medium whitespace-nowrap transition-all"
                      :class="editForm.roles.includes(r.code) ? r.activeClass : 'bg-white text-gray-400 border border-gray-100'"
                      @click="toggleRole(r.code)"
                    >{{ r.label }}</button>
                  </div>
                </div>

                <!-- 状态卡片 -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#6366F1]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">用户状态</span>
                  </div>
                  <div class="flex gap-2 mb-3">
                    <button
                      v-for="s in statusOptions" :key="s.value"
                      class="flex-1 py-2.5 text-xs rounded-xl font-medium transition-all"
                      :class="editForm.status === s.value ? s.activeClass : 'bg-white text-gray-400 border border-gray-100'"
                      @click="editForm.status = s.value"
                    >
                      <div class="flex items-center justify-center gap-1.5">
                        <span class="w-1.5 h-1.5 rounded-full" :class="s.dot"></span>
                        {{ s.label }}
                      </div>
                    </button>
                  </div>
                  <div>
                    <div class="text-[11px] text-gray-400 mb-1">封禁截止时间（留空=未封禁）</div>
                    <input v-model="editForm.ban_until" type="datetime-local" class="w-full text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#6366F1] focus:ring-1 focus:ring-indigo-100 transition-all" />
                  </div>
                </div>

                <!-- 头像URL -->
                <div class="bg-gray-50 rounded-2xl p-4">
                  <div class="flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4 text-[#00BFA5]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <span class="text-xs font-semibold text-gray-500">头像设置</span>
                  </div>
                  <div class="flex items-center gap-3">
                    <img
                      :src="$fixImgUrl(editForm.avatar || detailUser.avatar || defaultAvatar)"
                      class="w-12 h-12 rounded-xl object-cover border border-gray-200"
                      @error="(e) => { e.target.src = defaultAvatar }"
                    />
                    <input v-model="editForm.avatar" class="flex-1 text-sm text-gray-800 bg-white rounded-xl px-3 py-2.5 outline-none border border-gray-100 focus:border-[#00BFA5] focus:ring-1 focus:ring-teal-100 transition-all" placeholder="请输入头像URL" />
                  </div>
                </div>

                <!-- 保存按钮 -->
                <button v-auth="'edit'" class="w-full py-3 bg-[#FF4757] text-white text-sm font-semibold rounded-2xl shadow-lg shadow-red-200 active:scale-[0.98] transition-all" @click="saveEdit">
                  保存修改
                </button>
                <button class="w-full py-3 text-sm text-gray-400" @click="isEditing = false">
                  取消编辑
                </button>
                <div class="h-4"></div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const userStore = useUserStore()

const isAdmin = computed(() => {
  const roles = userStore.info.roles || []
  return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
})

const defaultAvatar = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDQiIGhlaWdodD0iNDQiIHZpZXdCb3g9IjAgMCA0NCA0NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDQiIGhlaWdodD0iNDQiIHJ4PSIyMiIgZmlsbD0iI0UyRThGMSIvPjxwYXRoIGQ9Ik0yMiAyMmE1IDUgMCAxIDAgMC0xMCA1IDUgMCAwIDAgMCAxMFoiIGZpbGw9IiM5NEEzQjgiLz48cGF0aCBkPSJNMjIgMjRjLTQuNDE4IDAtOCAyLjIzOS04IDV2Mi41aDE2VjI5YzAtMi43NjEtMy41ODItNS04LTVaIiBmaWxsPSIjOTRBM0I4Ii8+PC9zdmc+'

interface UserItem {
  id: number; userName: string; userPhone: string; userEmail: string
  userGender: string; avatar: string; status: string
  level: number; levelName: string; expireTime: string
  userRoles: string[]; nickname: string; bio: string
  createTime: string; updateTime: string
  signature: string; qq: string; bgUrl: string
  age: number; birthday: string; registerAddress: string; banUntil: string
  followCount: number; fansCount: number; postCount: number
  usedBytes: number; bonusDataLimitMb: number; bonusFileLimitMb: number
}

const list = ref<UserItem[]>([])
const loading = ref(false)
const searchKey = ref('')
const currentPage = ref(1)
const total = ref(0)
const totalUsedBytes = ref(0)
const pageSize = ref(15)
const sortField = ref('id')
const sortOrder = ref<'desc' | 'asc'>('desc')
const totalStats = ref({ active: 0, warning: 0, deleted: 0 })

const totalPages = computed(() => Math.ceil(total.value / pageSize.value) || 1)

const pageNumbers = computed(() => {
  const pages: number[] = []
  const t = totalPages.value
  const c = currentPage.value
  let start = Math.max(1, c - 2)
  let end = Math.min(t, c + 2)
  if (end - start < 4) {
    if (start === 1) end = Math.min(t, start + 4)
    else start = Math.max(1, end - 4)
  }
  for (let i = start; i <= end; i++) pages.push(i)
  return pages
})

const statusDot = (s: string) => ({
  '1': 'bg-[#059669]', '2': 'bg-[#6b7280]', '3': 'bg-[#d97706]', '4': 'bg-[#dc2626]'
}[s] || 'bg-[#6b7280]')

const statusBadge = (s: string) => ({
  '1': 'bg-[#ecfdf5] text-[#059669]', '2': 'bg-[#f3f4f6] text-[#6b7280]',
  '3': 'bg-[#fffbeb] text-[#d97706]', '4': 'bg-[#fef2f2] text-[#dc2626]'
}[s] || 'bg-[#f3f4f6] text-[#6b7280]')

const statusText = (s: string) =>
  ({ '1': '正常', '2': '离线', '3': '异常', '4': '注销' }[s] || '未知')

const formatExpire = (s: string) => {
  if (!s) return ''
  return s.replace('T', ' ').slice(0, 16)
}

const formatBytes = (bytes: number) => {
  if (!bytes || bytes <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0
  let val = bytes
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++ }
  return val.toFixed(i > 0 ? 2 : 0) + ' ' + units[i]
}

const calcAge = (birthday: string) => {
  if (!birthday) return '?'
  const b = new Date(birthday)
  const now = new Date()
  let age = now.getFullYear() - b.getFullYear()
  const m = now.getMonth() - b.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--
  return age
}

const statusOptions = [
  { value: '1', label: '正常', dot: 'bg-[#059669]', activeClass: 'bg-[#ecfdf5] text-[#059669] ring-1 ring-emerald-200' },
  { value: '2', label: '离线', dot: 'bg-[#6b7280]', activeClass: 'bg-[#f3f4f6] text-[#6b7280] ring-1 ring-gray-200' },
  { value: '3', label: '异常', dot: 'bg-[#d97706]', activeClass: 'bg-[#fffbeb] text-[#d97706] ring-1 ring-amber-200' },
  { value: '4', label: '注销', dot: 'bg-[#dc2626]', activeClass: 'bg-[#fef2f2] text-[#dc2626] ring-1 ring-red-200' },
]

const roleOpts = ref<{ code: string; label: string; activeClass: string }[]>([])
const fetchRoles = async () => {
  try {
    const res: any = await request.get({ url: '/api/role/list' })
    if (res && res.records) {
      const palette = ['bg-[#fef0f0] text-[#FF4757] ring-1 ring-red-200', 'bg-[#eff6ff] text-[#3b82f6] ring-1 ring-blue-200', 'bg-[#ecfdf5] text-[#059669] ring-1 ring-emerald-200', 'bg-[#fffbeb] text-[#d97706] ring-1 ring-amber-200', 'bg-[#f5f3ff] text-[#7c3aed] ring-1 ring-violet-200', 'bg-[#fdf2f8] text-[#db2777] ring-1 ring-pink-200']
      roleOpts.value = res.records.map((r: any, i: number) => ({
        code: r.roleCode,
        label: r.roleName,
        activeClass: palette[i % palette.length]
      }))
    }
  } catch { /* ignore */ }
}
const toggleRole = (code: string) => {
  const arr = editForm.value.roles as string[]
  const idx = arr.indexOf(code)
  if (idx >= 0) {
    arr.splice(idx, 1)
  } else {
    arr.push(code)
  }
}

const communityProfile = ref<any>({ trustLevelName: '', moderatorSections: [], banStatus: { banned: false, bans: [] }, postCount: 0, commentCount: 0, reportCount: 0 })
const sections = ref<{ id: number; name: string }[]>([])
const addModSectionId = ref(0)

const fetchCommunityProfile = async (userId: number) => {
  try {
    const res: any = await request.get({ url: `/api/community/user/${userId}/community-profile` })
    if (res) communityProfile.value = res
  } catch { communityProfile.value = { trustLevelName: '', moderatorSections: [], banStatus: { banned: false, bans: [] }, postCount: 0, commentCount: 0, reportCount: 0 } }
}

const fetchSections = async () => {
  try {
    const res: any = await request.get({ url: '/api/community/sections', params: { all: 'true' } })
    if (res && res.data) sections.value = res.data.map((s: any) => ({ id: s.id, name: s.name }))
  } catch {}
}

const addModerator = async () => {
  if (addModSectionId.value <= 0 || !detailUser.value.id) return
  try {
    await request.post({
      url: `/api/community/section/${addModSectionId.value}/moderator`,
      data: { userId: detailUser.value.id, userName: detailUser.value.userName, role: '版主' }
    })
    addModSectionId.value = 0
    fetchCommunityProfile(detailUser.value.id)
  } catch {}
}

const removeModerator = async (sectionId: number) => {
  try {
    await request.del({ url: `/api/community/section/${sectionId}/moderator/${detailUser.value.id}` })
    fetchCommunityProfile(detailUser.value.id)
  } catch {}
}

const toggleSortOrder = () => {
  sortOrder.value = sortOrder.value === 'desc' ? 'asc' : 'desc'
  handleSearch()
}

const handlePageSizeChange = () => {
  currentPage.value = 1
  fetchUsers()
}

const goPage = (p: number) => {
  if (p < 1 || p > totalPages.value) return
  currentPage.value = p
  fetchUsers()
}

const fetchUsers = async () => {
  loading.value = true
  try {
    const params: Record<string, any> = {
      current: currentPage.value,
      size: pageSize.value,
      sortField: sortField.value,
      sortOrder: sortOrder.value
    }
    if (searchKey.value.trim()) {
      const kw = searchKey.value.trim()
      if (/^\d+$/.test(kw)) {
        params.userPhone = kw
      } else {
        params.userName = kw
      }
    }
    const res: any = await request.get({ url: '/api/user/list', params })
    if (res) {
      list.value = res.records || []
      total.value = res.total || 0
      totalUsedBytes.value = res.totalUsedBytes || 0
      currentPage.value = res.current || 1
      calcStats(list.value)
    }
  } catch {
    // ignore
  }
  loading.value = false
}

const calcStats = (users: UserItem[]) => {
  totalStats.value = {
    active: users.filter(u => u.status === '1').length,
    warning: users.filter(u => u.status === '3').length,
    deleted: users.filter(u => u.status === '4').length
  }
}

const handleSearch = () => {
  currentPage.value = 1
  fetchUsers()
}

// 详情弹窗
const showDetail = ref(false)
const isEditing = ref(false)
const detailUser = ref<UserItem>({} as UserItem)
const editForm = ref<Record<string, any>>({})
const memberPurchases = ref<any[]>([])
const userCurrencies = ref<any[]>([])
const currencyLoading = ref(false)
const currencyEditing = ref(false)
const currencySaving = ref(false)

const fetchUserCurrencies = async (userId: number) => {
  currencyLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/user/currency-balance', params: { userId } })
    const currencies = res?.currencies || []
    userCurrencies.value = currencies.map(c => ({
      ...c,
      editTarget: c.total
    }))
  } catch {
    userCurrencies.value = []
  }
  currencyLoading.value = false
}

const startCurrencyEdit = () => {
  userCurrencies.value.forEach(c => { c.editTarget = c.total })
  currencyEditing.value = true
}

const cancelCurrencyEdit = () => {
  currencyEditing.value = false
}

const saveCurrencyEdit = async () => {
  currencySaving.value = true
  const changed = userCurrencies.value.filter(c => c.editTarget !== c.total)
  for (const c of changed) {
    const diff = c.editTarget - c.total
    if (diff === 0) continue
    try {
      await request.post({
        url: '/api/admin/currency/adjust',
        data: {
          user_id: detailUser.value.id,
          currency_key: c.currency_key,
          amount: diff,
          description: '管理员调整'
        }
      })
    } catch (e: any) {
      alert(e?.data?.msg || `调整 ${c.display_name} 失败`)
    }
  }
  currencySaving.value = false
  currencyEditing.value = false
  fetchUserCurrencies(detailUser.value.id)
}

const groupedPurchases = computed(() => {
  const map: Record<string, any> = {}
  for (const mp of memberPurchases.value) {
    const key = mp.levelName || '普通会员'
    if (!map[key] || new Date(mp.expireTime || '9999').getTime() > new Date(map[key].expireTime || '9999').getTime()) {
      map[key] = mp
    }
  }
  return Object.values(map).sort((a, b) =>
    new Date(b.expireTime || '9999').getTime() - new Date(a.expireTime || '9999').getTime()
  )
})

const detailFields = computed(() => [
  { key: 'userPhone', label: '手机号', value: detailUser.value.userPhone || '-' },
  { key: 'userEmail', label: '邮箱', value: detailUser.value.userEmail || '-' },
  { key: 'userGender', label: '性别', value: detailUser.value.userGender || '-' },
  { key: 'nickname', label: '昵称', value: detailUser.value.nickname || '-' },
  { key: 'bio', label: '个人介绍', value: detailUser.value.bio || '-' },
  { key: 'birthday', label: '生日', value: detailUser.value.birthday ? (detailUser.value.birthday.slice(0, 10) + ' (' + calcAge(detailUser.value.birthday) + '岁)') : '未设置' },
  { key: 'qq', label: '交友QQ', value: detailUser.value.qq || '-' },
  { key: 'signature', label: '认证称号', value: detailUser.value.signature || '-' },
  { key: 'registerAddress', label: '注册地址', value: detailUser.value.registerAddress || '-' },
  { key: 'bgUrl', label: '背景图片', value: detailUser.value.bgUrl ? '已设置' : '未设置' },
  { key: 'usedBytes', label: '已用存储', value: formatBytes(detailUser.value.usedBytes || 0) },
  { key: 'bonusDataLimitMb', label: '数据配额(MB)', value: String(detailUser.value.bonusDataLimitMb || 0) },
  { key: 'bonusFileLimitMb', label: '文件配额', value: String(detailUser.value.bonusFileLimitMb || 0) },
  { key: 'userRoles', label: '角色', value: detailUser.value.userRoles?.length ? detailUser.value.userRoles.join(', ') : '-' },
  { key: 'status', label: '状态', value: statusText(detailUser.value.status) },
  { key: 'banUntil', label: '封禁截止', value: detailUser.value.banUntil ? formatExpire(detailUser.value.banUntil) : '无' },
  { key: 'postCount', label: '动态', value: String(detailUser.value.postCount || 0) },
  { key: 'followCount', label: '关注', value: String(detailUser.value.followCount || 0) },
  { key: 'fansCount', label: '粉丝', value: String(detailUser.value.fansCount || 0) },
  { key: 'createTime', label: '注册时间', value: detailUser.value.createTime ? formatExpire(detailUser.value.createTime) : '-' },
])

const fetchMemberPurchases = async (userId: number) => {
  try {
    const res: any = await request.get({ url: `/api/user/membership-purchases/${userId}` })
    memberPurchases.value = Array.isArray(res) ? res : (res?.data || [])
  } catch { memberPurchases.value = [] }
}

const openUserDetail = (user: UserItem) => {
  detailUser.value = { ...user }
  isEditing.value = false
  memberPurchases.value = []
  fetchMemberPurchases(user.id)
  fetchCommunityProfile(user.id)
  fetchUserCurrencies(user.id)
  showDetail.value = true
}

const mLvs = ref<{ id: number; name: string; level: number }[]>([])
const fetchMembershipLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    if (res && res.records) mLvs.value = res.records
  } catch {
    // ignore
  }
}

const startEdit = async () => {
  const u = detailUser.value
  let roles: string[] = []
  try { roles = Array.isArray(u.userRoles) ? u.userRoles : (typeof u.userRoles === 'string' ? JSON.parse(u.userRoles) : []) } catch { roles = [] }
  editForm.value = {
    username: u.userName || '',
    phone: u.userPhone || '',
    email: u.userEmail || '',
    gender: u.userGender || '男',
    nickname: u.nickname || '',
    bio: u.bio || '',
    status: u.status || '1',
    avatar: u.avatar || '',
    birthday: u.birthday ? u.birthday.slice(0, 10) : '',
    qq: u.qq || '',
    signature: u.signature || '',
    bg_url: u.bgUrl || '',
    register_address: u.registerAddress || '',
    ban_until: u.banUntil || '',
    level_id: u.level || 0,
    expireTime: u.expireTime || '',
    roles: roles,
    used_bytes: u.usedBytes || 0,
    bonus_data_limit_mb: u.bonusDataLimitMb || 0,
    bonus_file_limit_mb: u.bonusFileLimitMb || 0
  }
  editForm.value.memberPurchases = []
  if (mLvs.value.length === 0) await fetchMembershipLevels()
  if (roleOpts.value.length === 0) await fetchRoles()
  isEditing.value = true
}

const addMemberPurchase = () => {
  if (!Array.isArray(editForm.value.memberPurchases)) editForm.value.memberPurchases = []
  editForm.value.memberPurchases.push({ levelId: 0, durationDays: 365, amount: 0 })
}

const saveEdit = async () => {
  try {
    const body: Record<string, any> = {
      id: detailUser.value.id,
      username: editForm.value.username,
      phone: editForm.value.phone,
      email: editForm.value.email,
      gender: editForm.value.gender,
      nickname: editForm.value.nickname,
      bio: editForm.value.bio,
      status: editForm.value.status,
      avatar: editForm.value.avatar,
      birthday: editForm.value.birthday || null,
      qq: editForm.value.qq,
      signature: editForm.value.signature,
      bg_url: editForm.value.bg_url,
      register_address: editForm.value.register_address,
      ban_until: editForm.value.ban_until,
      level_id: editForm.value.level_id,
      expireTime: editForm.value.expireTime,
      role: editForm.value.roles,
      used_bytes: editForm.value.used_bytes,
      bonus_data_limit_mb: editForm.value.bonus_data_limit_mb,
      bonus_file_limit_mb: editForm.value.bonus_file_limit_mb,
      member_purchases: editForm.value.memberPurchases || []
    }
    await request.post({ url: '/api/user/update', data: body })
    showDetail.value = false
    fetchUsers()
  } catch {
    // ignore
  }
}

onMounted(() => {
  if (!isAdmin.value) return
  fetchUsers()
  fetchMembershipLevels()
  fetchRoles()
  fetchSections()
})
</script>

<style scoped>
.animate-slide-up {
  animation: slide-up 0.25s ease-out;
}
@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
</style>
