<template>
  <div class="topic-posts-page mx-auto max-w-[430px] shadow-lg relative h-screen flex flex-col overflow-hidden" style="background:#fff">
    <div v-if="loading" class="flex justify-center pt-40">
      <div class="w-5 h-5 border-2 border-[#22C1C3] border-t-transparent rounded-full animate-spin"/>
    </div>

    <template v-else>
      <div class="h-[34px] bg-white flex-shrink-0"/>
      <div class="nav-bar bg-white flex-shrink-0">
        <div class="flex items-center justify-between h-[40px] px-4">
          <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
          <span class="text-[17px] text-[#111] font-bold">#{{ topicName }}</span>
          <div class="w-[32px] h-[32px]"/>
        </div>
      </div>

      <div class="bg-white px-5 py-3.5 flex-shrink-0">
        <div class="flex items-start gap-3">
          <div class="w-[64px] h-[64px] rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden" :style="{ background: topic?.icon ? 'transparent' : '#3B82F6' }">
            <img v-if="topic?.icon" :src="$fixImgUrl(topic.icon)" class="w-full h-full object-cover" loading="lazy" />
            <span v-else class="text-white text-xl font-bold">{{ topicName ? topicName[0] : '#' }}</span>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[18px] text-[#111] font-bold mb-0.5">#{{ topicName }}</div>
            <div class="flex items-center text-[12px] text-[#666] mb-1">
              <span>{{ formatCount(viewCount) }} 热度</span>
              <span class="mx-1 text-[#ddd]">|</span>
              <span>{{ total }} 讨论</span>
              <span class="mx-1 text-[#ddd]">|</span>
              <span>{{ formatCount(followerCount) }} 关注</span>
            </div>
            <div v-if="followerCount > 0" class="flex -space-x-1.5 cursor-pointer" @click="showFollowers = true">
              <div v-for="(f, i) in followerAvatars.slice(0, 5)" :key="i" class="w-[22px] h-[22px] rounded-full border-2 border-white overflow-hidden flex-shrink-0">
                <img :src="f" class="w-full h-full object-cover" loading="lazy" />
              </div>
              <div v-if="followerCount > 5" class="w-[22px] h-[22px] rounded-full border-2 border-white bg-[#22C1C3] flex items-center justify-center flex-shrink-0 text-[9px] text-white font-bold">
                +{{ followerCount - 5 }}
              </div>
            </div>
          </div>
          <button
            class="flex-shrink-0 px-4 py-1.5 rounded-full text-[12px] font-medium transition-colors mt-1"
            :class="isFollowing ? 'border border-[#E5E7EB] text-[#999] bg-[#F5F5F5]' : 'border border-[#22C1C3] text-[#22C1C3] bg-white'"
            @click="toggleFollow"
          >
            {{ isFollowing ? '已关注' : '+ 关注' }}
          </button>
        </div>
        <div v-if="topic?.description" class="mt-2.5 text-[12px] text-[#666]">{{ topic.description }}</div>
      </div>

      <div class="bg-white px-5 flex-shrink-0">
        <div class="border-b border-[#F0F0F0]"/>
      </div>

      <div class="tab-bar bg-white px-4 pt-3 pb-1.5 flex-shrink-0">
        <div class="bg-[#F2F2F2] rounded-[10px] p-[3px] inline-flex">
          <div v-for="tab in sortTabs" :key="tab.key"
            class="px-3 py-[5px] text-[12px] rounded-[8px] cursor-pointer transition-all duration-200"
            :class="activeSort === tab.key ? 'bg-white text-[#1A1A1A] font-semibold shadow-sm' : 'text-[#999]'"
            @click="switchSort(tab.key)">
            {{ tab.label }}
          </div>
        </div>
      </div>

      <div class="flex-1 min-h-0">
        <div v-if="posts.length === 0 && !loading" class="flex flex-col items-center justify-center py-32 text-gray-300">
          <span class="text-[13px]">还没有帖子，快来发布第一个</span>
        </div>

        <VirtualScroller v-else :items="posts" :estimated-height="200" :load-more-threshold="200" @load-more="onLoadMore">
          <template #default="{ item }">
            <div class="bg-white px-6 pt-3 cursor-pointer active:bg-[#FAFAFA] transition-colors"
              @click="openPostDetail(item.id)">

            <div class="flex items-start gap-2.5">
              <div class="w-[38px] h-[38px] rounded-full flex items-center justify-center flex-shrink-0 font-bold overflow-hidden">
                <img v-if="item.userAvatar" :src="item.userAvatar" class="w-full h-full object-cover" loading="lazy"/>
                <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span class="text-[14px] text-[#222] font-semibold">{{ item.userName }}</span>
                  <span v-if="item.userLevelName" class="text-[9px] px-1.5 py-0.5 rounded font-bold flex-shrink-0 leading-none" style="color:#FFFFFF;background:#508DFF">{{ item.userLevelName }}</span>
                  <span v-if="item.isEssence" class="text-[10px] px-1.5 py-0.5 rounded font-bold text-[#EA580C] bg-[#FFF7ED] flex-shrink-0 leading-none">精</span>
                  <span v-if="item.isHot" class="text-[10px] px-1.5 py-0.5 rounded font-bold text-[#DC2626] bg-[#FEF2F2] flex-shrink-0 leading-none">热</span>
                </div>
                <div class="flex items-center gap-1 mt-0.5 text-[12px]">
                  <span class="font-medium" style="color:#508DFF">{{ item.userLevelName || '普通用户' }}</span>
                  <span class="text-[#DDD]">·</span>
                  <span class="text-[#B0B0B0] truncate">{{ fmtRelativeTime(item.createTime) }}</span>
                </div>
              </div>
            </div>

            <div class="mt-2.5 text-[16px] text-[#111] font-bold leading-[1.45] line-clamp-2">{{ item.title }}</div>
            <div v-if="item.contentFiltered" class="mt-1 text-[12px] text-[#999]">
              部分内容付费 - 需购买后查看
              <span v-if="item.contentPrice" class="ml-1" style="color:#D48806">{{ item.contentPriceType === 'points' ? item.contentPrice + '积分' : '￥' + item.contentPrice }}</span>
            </div>
            <div v-else-if="item.content" class="mt-1 text-[13px] text-[#AAA] leading-[1.6] line-clamp-2" v-html="stripContent(item.content)"></div>

            <div v-if="item.images && item.images.length" class="mt-2.5">
              <div v-if="item.images.length === 1" class="rounded-lg overflow-hidden" style="max-height:180px">
                <img :src="$fixImgUrl(item.images[0])" class="w-full object-cover" style="max-height:180px" loading="lazy" alt=""/>
              </div>
              <div v-else-if="item.images.length === 2" class="grid grid-cols-2 gap-1 rounded-lg overflow-hidden">
                <img v-for="(img, idx) in item.images.slice(0,2)" :key="img" :src="img" class="w-full object-cover aspect-square" style="max-height:140px" loading="lazy" alt=""/>
              </div>
              <div v-else class="grid grid-cols-3 gap-1 rounded-lg overflow-hidden">
                <img v-for="(img, idx) in item.images.slice(0,3)" :key="img" :src="img" class="w-full object-cover aspect-square" style="max-height:110px" loading="lazy" alt=""/>
              </div>
            </div>

            <div class="flex items-center justify-between mt-2.5">
              <div v-if="item.tags && item.tags.length" class="flex items-center gap-1.5 flex-1 min-w-0 overflow-hidden">
                <span v-for="tag in item.tags.slice(0,3)" :key="tag"
                  class="text-[10px] px-2 py-0.5 rounded-full text-[#508DFF] bg-[#EEF2FF] font-medium flex-shrink-0">{{ tag }}</span>
              </div>
              <div class="flex items-center gap-3.5 text-[12px] text-[#B8B8B8] ml-auto flex-shrink-0">
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                  {{ fmtCount(item.viewCount) }}
                </span>
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                  {{ fmtCount(item.commentCount) }}
                </span>
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                  {{ fmtCount(item.likeCount) }}
                </span>
                <span v-if="item.images && item.images.length" class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path stroke-linecap="round" d="M21 15l-5-5L5 21"/></svg>
                  {{ item.images.length }}
                </span>
              </div>
            </div>
            <div class="bg-white px-6 py-3 pb-5">
              <div class="border-b border-[#F0F0F0]"/>
            </div>
            </div>
          </template>

          <template #footer>
            <div v-if="loadingMore" class="flex justify-center py-6">
              <div class="w-5 h-5 border-2 border-[#22C1C3] border-t-transparent rounded-full animate-spin"/>
            </div>
            <div v-else-if="noMore && posts.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
          </template>
        </VirtualScroller>
      </div>
    </template>

    <!-- 关注者列表弹窗 -->
    <div v-if="showFollowers" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showFollowers = false">
      <div class="bg-white w-full max-w-[430px] rounded-2xl max-h-[85vh] overflow-y-auto" @click.stop>
        <div class="flex items-center justify-between px-5 py-3.5 border-b border-[#F0F0F0]">
          <span class="text-[16px] font-semibold text-[#111]">{{ followerCount }} 人关注</span>
          <svg class="w-5 h-5 text-[#999] cursor-pointer" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" @click="showFollowers = false">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </div>
        <div>
          <div v-if="followersLoading" class="flex justify-center py-12">
            <div class="w-5 h-5 border-2 border-[#22C1C3] border-t-transparent rounded-full animate-spin"/>
          </div>
          <div v-else>
            <div v-for="f in followerList" :key="f.user_id" class="flex items-center gap-3 px-5 py-3 border-b border-[#F8F8F8]">
              <div class="w-[40px] h-[40px] rounded-full flex items-center justify-center flex-shrink-0 font-bold overflow-hidden">
                <img v-if="f.avatar" :src="$fixImgUrl(f.avatar)" class="w-full h-full object-cover" loading="lazy"/>
                <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-[14px] text-[#222] font-medium truncate">{{ f.nickname || f.username }}</div>
                <div class="text-[11px] text-[#BBB] mt-0.5">{{ f.create_time?.slice(0, 10) }} 关注</div>
              </div>
            </div>
            <div v-if="followerList.length === 0 && !followersLoading" class="text-center py-12 text-[#BBB] text-[13px]">暂无关注者</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchTopicDetail, fetchTopicPosts, followTopic, unfollowTopic, checkTopicFollow, fetchTopicFollowers } from '@/api/community'
import { stripContent, fmtCount } from '@/utils'
import VirtualScroller from '@/components/core/VirtualScroller.vue'

const route = useRoute()
const router = useRouter()
const topicId = computed(() => Number(route.params.id) || 0)
const topicName = ref('')
const topic = ref<any>(null)
const posts = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const total = ref(0)
const activeSort = ref('latest')
const isFollowing = ref(false)
const followerCount = ref(0)
const viewCount = ref(0)
const followerAvatars = ref<string[]>([])
const followerList = ref<any[]>([])
const showFollowers = ref(false)
const followersLoading = ref(false)

const sortTabs = [
  { key: 'latest', label: '最新' },
  { key: 'hot', label: '热门' }
]

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']

function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

function formatCount(n: number): string {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  return String(n)
}

async function toggleFollow() {
  try {
    if (isFollowing.value) {
      const res: any = await unfollowTopic(topicId.value)
      const data = res?.data || res
      isFollowing.value = false
      if (data?.follower_count !== undefined) followerCount.value = data.follower_count
      else followerCount.value = Math.max(0, followerCount.value - 1)
    } else {
      const res: any = await followTopic(topicId.value)
      const data = res?.data || res
      isFollowing.value = true
      if (data?.follower_count !== undefined) followerCount.value = data.follower_count
      else followerCount.value += 1
    }
    followerList.value = []
    if (followerCount.value > 0) {
      const flRes: any = await fetchTopicFollowers(topicId.value, { page: 1, pageSize: 5 })
      const flData = flRes?.data || flRes
      followerAvatars.value = (flData?.list || []).map((f: any) => f.avatar || '').filter(Boolean)
    } else {
      followerAvatars.value = []
    }
  } catch {}
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

async function loadTopic() {
  if (!topicId.value) return
  try {
    const res: any = await fetchTopicDetail(topicId.value)
    const data = res?.data || res
    topic.value = data
    topicName.value = data?.name || ''
    viewCount.value = data?.heat || data?.view_count || data?.viewCount || 0
    followerCount.value = data?.follower_count || 0
    try {
      const fRes: any = await checkTopicFollow(topicId.value)
      const fData = fRes?.data || fRes
      isFollowing.value = fData?.following || false
      if (fData?.follower_count !== undefined) followerCount.value = fData.follower_count
    } catch {}
    if (followerCount.value > 0) {
      try {
        const flRes: any = await fetchTopicFollowers(topicId.value, { page: 1, pageSize: 5 })
        const flData = flRes?.data || flRes
        const list = flData?.list || []
        followerAvatars.value = list.map((f: any) => f.avatar || '').filter(Boolean)
      } catch {}
    }
  } catch {}
}

async function loadPosts(reset = false) {
  if (reset) { page.value = 1; noMore.value = false; loading.value = true }
  else { loadingMore.value = true }
  try {
    const res: any = await fetchTopicPosts(topicId.value, { page: page.value, pageSize: 20, sort: activeSort.value })
    const list = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => ({
      ...p,
      images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || [])
    }))
    if (reset) {
      posts.value = parsed
      total.value = res?.data?.total || res?.total || 0
    }
    else { posts.value.push(...parsed) }
    if (list.length < 20) noMore.value = true
  } catch {} finally { loading.value = false; loadingMore.value = false }
}

async function loadFullFollowers() {
  if (!showFollowers.value || followerList.value.length > 0) return
  followersLoading.value = true
  try {
    const flRes: any = await fetchTopicFollowers(topicId.value, { page: 1, pageSize: 50 })
    const flData = flRes?.data || flRes
    followerList.value = flData?.list || []
  } catch {} finally { followersLoading.value = false }
}

function switchSort(key: string) {
  if (activeSort.value !== key) { activeSort.value = key; loadPosts(true) }
}

function openPostDetail(postId: number) {
  router.push(`/community/post/${postId}`)
}

function onLoadMore() {
  if (loadingMore.value || noMore.value) return
  page.value++
  loadPosts(false)
}

onMounted(async () => {
  await loadTopic()
  loadPosts(true)
})

watch(showFollowers, (val) => {
  if (val) loadFullFollowers()
})
</script>

<style scoped>
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.animate-slide-up { animation: slideUp 0.25s ease-out; }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
</style>
