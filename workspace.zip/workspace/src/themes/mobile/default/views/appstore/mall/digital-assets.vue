<template>
  <div class="min-h-screen flex flex-col" style="background:var(--default-bg-color)">
    <div class="px-4 py-3 flex items-center gap-3">
      <div class="cursor-pointer active:opacity-70" @click="$router.back()">
        <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
      </div>
      <div class="text-base font-bold text-gray-800">数字素材</div>
    </div>

    <div class="px-3 pb-4">
      <div class="flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2">
        <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
        <input
          v-model="keyword"
          type="text"
          placeholder="搜索数字素材"
          class="flex-1 bg-transparent border-none outline-none text-sm text-gray-800 placeholder-gray-400"
          @keyup.enter="search"
        />
        <span v-if="keyword" class="text-gray-400 text-sm cursor-pointer" @click="keyword='';search()">x</span>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto">
      <div v-if="loading" class="flex justify-center py-20">
        <div class="w-6 h-6 border-2 border-[#FF6B6B] border-t-transparent rounded-full animate-spin" />
      </div>

      <div v-else-if="products.length === 0" class="flex flex-col items-center py-20 gap-3">
        <svg class="w-16 h-16 text-gray-200" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
        </svg>
        <span class="text-sm text-gray-400">暂无数字素材</span>
      </div>

      <div v-else class="grid grid-cols-2 gap-2 px-2 pb-6">
        <div
          v-for="p in products"
          :key="p.id"
          class="bg-white rounded-xl overflow-hidden shadow-sm cursor-pointer active:scale-[0.97] transition-transform"
          @click="goDetail(p.id)"
        >
          <div class="relative w-full" style="padding-top:80%">
            <div class="absolute inset-0 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
              <span class="text-gray-300 text-xl font-black">{{ p.name }}</span>
            </div>
            <img v-if="p.coverImage" :src="fixImg(p.coverImage)" class="absolute inset-0 w-full h-full object-cover z-10" @error="(e) => e.target.style.display='none'" />
            <div class="absolute top-2 left-2 z-20 flex gap-1">
              <span v-if="p.fileType" class="text-[9px] px-1.5 py-0.5 rounded-full bg-black/40 text-white font-medium">{{ p.fileType }}</span>
              <span v-if="p.salesCount > 100" class="text-[9px] px-1.5 py-0.5 rounded-full bg-gradient-to-r from-red-400 to-pink-400 text-white font-medium">热销</span>
            </div>
          </div>
          <div class="p-2">
            <div class="text-xs font-semibold text-gray-800 line-clamp-2">{{ p.name }}</div>
            <div class="flex items-center gap-1.5 mt-1.5 flex-wrap" v-if="(p.tags || []).length">
              <span v-for="t in (p.tags || []).slice(0,3)" :key="t" class="text-[9px] px-1.5 py-0.5 rounded bg-orange-50 text-orange-500">{{ t }}</span>
            </div>
            <div class="flex items-center justify-between mt-2">
              <div class="flex items-baseline gap-0.5">
                <span class="text-[10px] font-bold text-red-500">{{ p.priceType === 'points' ? '' : '¥' }}</span>
                <span class="text-sm font-extrabold text-red-500">{{ p.price }}</span>
                <span v-if="p.originalPrice > p.price" class="text-[9px] text-gray-300 line-through ml-1">{{ p.priceType === 'points' ? p.originalPrice + '积分' : '¥' + p.originalPrice }}</span>
              </div>
              <span class="text-[9px] text-gray-400">已售 {{ p.salesCount || 0 }}</span>
            </div>
          </div>
        </div>
      </div>

      <div v-if="!loading && products.length >= pageSize && !noMore" class="flex justify-center pb-6">
        <div class="px-5 py-2 bg-gray-100 rounded-full text-xs text-gray-500 cursor-pointer active:bg-gray-200" @click="loadMore">加载更多</div>
      </div>
      <div v-else-if="noMore && products.length > 0" class="text-center pb-6 text-[12px] text-gray-300">- 全部加载完成 -</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const products = ref<any[]>([])
const loading = ref(false)
const page = ref(1)
const pageSize = 20
const noMore = ref(false)
const keyword = ref('')

const fixImg = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''

const loadProducts = async (reset = false) => {
  if (reset) {
    page.value = 1
    products.value = []
    noMore.value = false
  }
  if (noMore.value && !reset) return
  loading.value = true
  try {
    const params: any = { productSubtype: 'digital', status: 'published', pageSize, page: page.value }
    if (keyword.value.trim()) params.keyword = keyword.value.trim()
    const res: any = await request.get({ url: '/api/mall/products', params })
    const data = res?.list || res || []
    if (reset) {
      products.value = data
    } else {
      products.value = [...products.value, ...data]
    }
    if (data.length < pageSize) noMore.value = true
    page.value++
  } catch {
    ElMessage.error('加载失败，请检查网络后重试')
  } finally {
    loading.value = false
  }
}

const search = () => loadProducts(true)
const loadMore = () => loadProducts()

const goDetail = (id: number) => router.push(`/appstore/mall-detail/${id}`)

onMounted(() => loadProducts(true))
</script>
