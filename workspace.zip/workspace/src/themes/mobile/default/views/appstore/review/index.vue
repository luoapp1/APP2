<template>
  <div class="review-page">
    <div class="flex justify-between items-center mb-4">
      <div class="flex gap-3">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索应用/包名/上传者"
          clearable
          class="!w-[260px]"
          @keyup.enter="fetchData"
        />
        <el-select
          v-model="filterStatus"
          placeholder="审核状态"
          clearable
          class="!w-[140px]"
          @change="fetchData"
        >
          <el-option label="审核中" value="pending" />
          <el-option label="已通过" value="approved" />
          <el-option label="未通过" value="rejected" />
          <el-option label="已下架" value="removed" />
          <el-option label="草稿" value="draft" />
        </el-select>
        <el-button type="primary" @click="fetchData">搜索</el-button>
      </div>
      <div class="text-sm text-gray-500">
        共 {{ total }} 条记录
      </div>
    </div>

    <!-- 审核列表表格 -->
    <el-table
      :data="tableData"
      border
      stripe
      v-loading="loading"
      max-height="calc(100vh - 280px)"
    >
      <el-table-column prop="id" label="ID" width="70" align="center" />
      <el-table-column label="应用图标" width="80" align="center">
        <template #default="{ row }">
          <div class="flex justify-center">
            <div
              class="flex items-center justify-center rounded-xl text-white font-bold text-xs"
              :style="{ width: '42px', height: '42px', background: row.iconBgColor || '#00BFA5' }"
            >
              <img
                v-if="row.icon"
                :src="$fixImgUrl(row.icon)"
                class="w-full h-full object-cover rounded-xl"
               loading="lazy" />
              <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="应用名称" min-width="120" show-overflow-tooltip />
      <el-table-column prop="userName" label="上传者" width="100" />
      <el-table-column prop="packageName" label="包名" min-width="160" show-overflow-tooltip />
      <el-table-column prop="category" label="分类" width="80" />
      <el-table-column prop="version" label="版本" width="80" />
      <el-table-column prop="sizeMb" label="大小" width="80" align="center">
        <template #default="{ row }">{{ row.sizeMb || 0 }} MB</template>
      </el-table-column>
      <el-table-column label="状态" width="90" align="center">
        <template #default="{ row }">
          <el-tag :type="getStatusType(row.submissionStatus)" size="small">
            {{ getStatusLabel(row.submissionStatus) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="审核信息" min-width="160">
        <template #default="{ row }">
          <div v-if="row.reviewBy" class="text-xs">
            <div>审核人: {{ row.reviewBy }}</div>
            <div v-if="row.reviewTime" class="text-gray-400">时间: {{ row.reviewTime }}</div>
            <div v-if="row.reviewComment" class="text-orange-500 truncate max-w-[160px]">
              {{ row.reviewComment }}
            </div>
          </div>
          <span v-else class="text-xs text-gray-400">-</span>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="提交时间" width="170" show-overflow-tooltip />
      <el-table-column label="操作" width="280" align="center" fixed="right">
        <template #default="{ row }">
          <div class="flex gap-2 justify-center">
            <el-button
              v-if="row.submissionStatus === 'pending'"
              type="success"
              size="small"
              @click="handleApprove(row)"
            >通过</el-button>
            <el-button
              v-if="row.submissionStatus === 'pending'"
              type="danger"
              size="small"
              @click="handleReject(row)"
            >驳回</el-button>
            <el-button
              v-if="row.submissionStatus === 'approved'"
              type="warning"
              size="small"
              @click="handleRemove(row)"
            >下架</el-button>
            <el-button
              size="small"
              @click="handleViewDetail(row)"
            >详情</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div v-if="total > pageSize" class="flex justify-center py-5">
      <el-pagination
        v-model:current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="fetchData"
      />
    </div>

    <!-- 驳回原因对话框 -->
    <el-dialog v-model="showRejectDialog" title="驳回投稿" width="420px">
      <el-input
        v-model="rejectComment"
        type="textarea"
        :rows="3"
        placeholder="请输入驳回原因（可选）"
      />
      <template #footer>
        <el-button @click="showRejectDialog = false">取消</el-button>
        <el-button type="danger" @click="confirmReject">确认驳回</el-button>
      </template>
    </el-dialog>

    <!-- 详情对话框 -->
    <el-dialog v-model="showDetailDialog" title="投稿详情" width="600px">
      <el-descriptions v-if="detailItem" :column="2" border size="small">
        <el-descriptions-item label="应用名称">{{ detailItem.name }}</el-descriptions-item>
        <el-descriptions-item label="包名">{{ detailItem.packageName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="分类">{{ detailItem.category || '-' }}</el-descriptions-item>
        <el-descriptions-item label="版本">{{ detailItem.version }}</el-descriptions-item>
        <el-descriptions-item label="大小">{{ detailItem.sizeMb || 0 }} MB</el-descriptions-item>
        <el-descriptions-item label="上传者">{{ detailItem.userName }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(detailItem.submissionStatus)" size="small">
            {{ getStatusLabel(detailItem.submissionStatus) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="图标">
          <div
            v-if="detailItem.icon"
            class="w-10 h-10 rounded-lg bg-cover"
            :style="{ backgroundImage: `url(${detailItem.icon})` }"
          />
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item label="下载地址" :span="2">
          <span class="text-xs">{{ detailItem.downloadUrl || '-' }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="描述" :span="2">
          {{ detailItem.description || '-' }}
        </el-descriptions-item>
        <el-descriptions-item v-if="detailItem.reviewBy" label="审核人">{{ detailItem.reviewBy }}</el-descriptions-item>
        <el-descriptions-item v-if="detailItem.reviewTime" label="审核时间">{{ detailItem.reviewTime }}</el-descriptions-item>
        <el-descriptions-item v-if="detailItem.reviewComment" label="审核备注" :span="2">
          {{ detailItem.reviewComment }}
        </el-descriptions-item>
        <el-descriptions-item label="提交时间">{{ detailItem.createTime }}</el-descriptions-item>
        <el-descriptions-item label="更新时间">{{ detailItem.updateTime }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <el-button @click="showDetailDialog = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import { fetchReviewList, fetchUpdateSubmissionStatus } from '@/api/submission'

const userStore = useUserStore()
const userName = computed(() => userStore.getUserInfo.userName || userStore.getUserInfo.nickname || '')
const roles = computed(() => userStore.getUserInfo.roles || [])

const loading = ref(false)
const searchKeyword = ref('')
const filterStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const tableData = ref<any[]>([])

const showRejectDialog = ref(false)
const rejectComment = ref('')
const rejectItem = ref<any>(null)

const showDetailDialog = ref(false)
const detailItem = ref<any>(null)

function getStatusType(status: string) {
  const map: Record<string, string> = {
    approved: 'success',
    pending: 'warning',
    rejected: 'danger',
    removed: 'info',
    draft: ''
  }
  return map[status] || 'info'
}

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    approved: '已分享',
    pending: '审核中',
    rejected: '未通过',
    removed: '下架',
    draft: '草稿'
  }
  return map[status] || status
}

async function fetchData() {
  loading.value = true
  try {
    const data = await fetchReviewList({
      keyword: searchKeyword.value,
      submissionStatus: filterStatus.value,
      page: page.value,
      pageSize: pageSize.value
    })
    if (data) {
      tableData.value = data.list || []
      total.value = data.total || 0
    }
  } catch {} finally {
    loading.value = false
  }
}

function handleApprove(item: any) {
  ElMessageBox.confirm(`确定通过「${item.name}」的投稿吗？`, '审核通过', {
    confirmButtonText: '确定通过',
    cancelButtonText: '取消',
    type: 'success'
  }).then(async () => {
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'approved',
      reviewBy: userName.value,
      reviewComment: '',
      role: roles.value[0] || ''
    })
    ElMessage.success('已通过审核')
    fetchData()
  }).catch(() => {})
}

function handleReject(item: any) {
  rejectItem.value = item
  rejectComment.value = ''
  showRejectDialog.value = true
}

async function confirmReject() {
  if (!rejectItem.value) return
  try {
    await fetchUpdateSubmissionStatus(rejectItem.value.id, {
      submissionStatus: 'rejected',
      reviewBy: userName.value,
      reviewComment: rejectComment.value,
      role: roles.value[0] || ''
    })
    ElMessage.success('已驳回')
    showRejectDialog.value = false
    fetchData()
  } catch {
    ElMessage.error('操作失败')
  }
}

function handleRemove(item: any) {
  ElMessageBox.confirm(`确定下架「${item.name}」吗？`, '下架确认', {
    confirmButtonText: '确定下架',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'removed',
      reviewBy: userName.value,
      reviewComment: '',
      role: roles.value[0] || ''
    })
    ElMessage.success('已下架')
    fetchData()
  }).catch(() => {})
}

function handleViewDetail(item: any) {
  detailItem.value = item
  showDetailDialog.value = true
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="scss" scoped>
.review-page {
  padding: 0;
}
</style>
