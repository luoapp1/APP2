<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" @click="$router.back()" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">邮件卡片</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg text-white text-sm shadow-lg" :class="toastType==='success'?'bg-[#4ECDC4]':'bg-[#FF4757]'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div v-if="templates.length === 0 && !loading" class="text-center py-8 text-gray-400 text-sm">暂无邮件模板，点击下方按钮添加</div>
        <div v-for="tpl in templates" :key="tpl.id" class="flex items-center gap-3 py-3 border-b border-gray-100 last:border-0">
          <div class="w-10 h-10 rounded-lg flex items-center justify-center text-white text-sm font-bold flex-shrink-0" :style="{ background: tpl.code === 'all' ? 'linear-gradient(135deg,#FF4757,#FF6B81)' : tpl.code === 'register_verify' ? 'linear-gradient(135deg,#4ECDC4,#44B7B0)' : tpl.code === 'password_reset' ? 'linear-gradient(135deg,#FFA502,#FFB830)' : tpl.code === 'account_ban' ? 'linear-gradient(135deg,#F44336,#EF5350)' : tpl.code === 'order_notify' ? 'linear-gradient(135deg,#2196F3,#42A5F5)' : tpl.code === 'post_notify' ? 'linear-gradient(135deg,#9C27B0,#AB47BC)' : 'linear-gradient(135deg,#607D8B,#78909C)' }">{{ tpl.name.slice(0, 2) }}</div>
          <div class="flex-1 min-w-0">
            <div class="text-sm font-medium text-gray-800 truncate">{{ tpl.name }}</div>
            <div class="text-xs text-gray-400 mt-0.5">{{ tpl.description || codeLabel(tpl.code) }}</div>
          </div>
          <div class="flex gap-1 flex-shrink-0">
            <button v-auth="'edit'" @click="editTemplate(tpl)" class="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button v-auth="'delete'" @click="deleteTemplate(tpl)" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </div>
      </div>

      <div class="px-3 mt-4">
        <button v-auth="'add'" @click="showAddDialog = true" class="w-full py-3 rounded-xl bg-[#FF4757] text-white font-medium text-sm flex items-center justify-center gap-2 active:opacity-80">
          <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          添加邮件卡片
        </button>
      </div>

      <div v-if="showAddDialog || showEditDialog" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closeDialog">
        <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col" @click.stop>
          <div class="px-5 py-4 flex items-center justify-between border-b border-gray-100 flex-shrink-0">
            <span class="text-base font-bold text-gray-800">{{ editingId ? '编辑邮件卡片' : '添加邮件卡片' }}</span>
            <button @click="closeDialog" class="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center">
              <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <div class="flex-1 overflow-y-auto px-5 py-4 space-y-3">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">模板名称</label>
              <input v-model="form.name" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：注册验证模板" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">模板代码</label>
              <select v-model="form.code" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none bg-white">
                <option value="" disabled>请选择模板代码</option>
                <optgroup label="通用系统模板">
                  <option value="all">通用模板（兜底用）</option>
                  <option value="register_verify">注册验证码</option>
                  <option value="password_reset">密码重置</option>
                </optgroup>
                <optgroup label="通知管理员">
                  <option value="new_submission">链接提交通知</option>
                  <option value="new_order">新订单通知</option>
                  <option value="withdraw_request">提现申请通知</option>
                  <option value="submission_review">投稿待审核通知</option>
                  <option value="post_review">帖子待审核通知</option>
                  <option value="identity_verify">身份认证申请通知</option>
                  <option value="account_appeal">帐号申诉通知</option>
                  <option value="report_notify">举报通知</option>
                  <option value="moderator_apply">版主申请通知</option>
                </optgroup>
                <optgroup label="通知版主">
                  <option value="post_review_moderator">帖子待审核通知（版主）</option>
                </optgroup>
                <optgroup label="通知用户">
                  <option value="order_paid_user">支付成功通知</option>
                  <option value="withdraw_result">提现处理结果</option>
                  <option value="order_paid_referrer">佣金到账通知</option>
                  <option value="revenue_split">创作分成通知</option>
                  <option value="comment_approved">评论审核通过</option>
                  <option value="comment_reply">评论被回复</option>
                  <option value="content_approved">内容审核通过</option>
                  <option value="phone_changed">手机号修改通知</option>
                  <option value="identity_result">身份认证结果</option>
                  <option value="account_ban_user">帐号禁封/解封</option>
                  <option value="report_result">举报处理结果</option>
                  <option value="moderator_apply_result">版主申请结果</option>
                  <option value="moderator_removed">版主被移出</option>
                  <option value="answer_accepted">回答被采纳</option>
                  <option value="private_message">私信通知</option>
                </optgroup>
                <optgroup label="自定义">
                  <option value="__custom__">自定义代码...</option>
                </optgroup>
              </select>
              <input v-if="form.code === '__custom__'" v-model="customCode" class="w-full mt-2 px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="请输入自定义模板代码" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">邮件主题</label>
              <input v-model="form.subject" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：注册验证码 - Art Design Pro" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">描述</label>
              <input v-model="form.description" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="模板用途说明" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">排序</label>
              <input v-model.number="form.sort_order" type="number" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="数字越小越靠前" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">启用状态</label>
              <button v-auth="'toggle'" :class="form.status === '1' ? 'bg-[#4ECDC4]' : 'bg-gray-200'" class="relative w-12 h-6 rounded-full transition-colors" @click="form.status = form.status === '1' ? '0' : '1'">
                <span :class="form.status === '1' ? 'translate-x-6' : 'translate-x-0.5'" class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform"></span>
              </button>
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">HTML 内容 (在线编辑)</label>
              <div class="text-xs mb-2 bg-amber-50 px-3 py-2 rounded-lg space-y-1.5">
                <div class="text-amber-700 font-medium mb-1">可用变量说明：</div>
                <div class="flex gap-2"><span class="text-amber-600 font-mono bg-amber-100 px-1.5 rounded">&#123;&#123;code&#125;&#125;</span><span class="text-gray-500">验证码数字（6位随机数）</span></div>
                <div class="flex gap-2"><span class="text-amber-600 font-mono bg-amber-100 px-1.5 rounded">&#123;&#123;subject&#125;&#125;</span><span class="text-gray-500">邮件主题标题</span></div>
                <div class="flex gap-2"><span class="text-amber-600 font-mono bg-amber-100 px-1.5 rounded">&#123;&#123;content&#125;&#125;</span><span class="text-gray-500">邮件正文主要内容</span></div>
                <div class="flex gap-2"><span class="text-amber-600 font-mono bg-amber-100 px-1.5 rounded">&#123;&#123;message&#125;&#125;</span><span class="text-gray-500">附加提示信息</span></div>
                <div class="flex gap-2"><span class="text-amber-600 font-mono bg-amber-100 px-1.5 rounded">&#123;&#123;username&#125;&#125;</span><span class="text-gray-500">收件人用户名</span></div>
              </div>
              <textarea v-model="form.html_content" class="w-full px-3 py-2.5 text-xs border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none font-mono" rows="12" placeholder="请输入 HTML 邮件模板代码..."></textarea>
            </div>
          </div>
          <div class="px-5 py-4 border-t border-gray-100 flex gap-3 flex-shrink-0">
            <button @click="closeDialog" class="flex-1 py-3 rounded-xl border border-gray-200 text-gray-600 text-sm font-medium">取消</button>
            <button @click="saveTemplate" class="flex-1 py-3 rounded-xl bg-[#FF4757] text-white text-sm font-medium active:opacity-80" :disabled="saving">{{ saving ? '保存中...' : '保存' }}</button>
          </div>
        </div>
      </div>

      <div v-if="showDeleteConfirm" class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center" @click.self="showDeleteConfirm = false">
        <div class="bg-white w-[280px] rounded-2xl p-5" @click.stop>
          <div class="text-center text-sm font-bold text-gray-800 mb-2">确认删除</div>
          <div class="text-center text-xs text-gray-500 mb-4">确定要删除模板 "{{ deleteTarget?.name }}" 吗？</div>
          <div class="flex gap-3">
            <button @click="showDeleteConfirm = false" class="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 text-sm">取消</button>
            <button @click="confirmDelete" class="flex-1 py-2.5 rounded-xl bg-[#FF4757] text-white text-sm">删除</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'EmailTemplatesMobile' })

const CODE_LABELS: Record<string, string> = {
  'all': '通用模板（兜底用）',
  'register_verify': '注册验证码',
  'password_reset': '密码重置',
  'new_submission': '链接提交通知',
  'new_order': '新订单通知',
  'withdraw_request': '提现申请通知',
  'submission_review': '投稿待审核通知',
  'post_review': '帖子待审核通知',
  'identity_verify': '身份认证申请通知',
  'account_appeal': '帐号申诉通知',
  'report_notify': '举报通知',
  'moderator_apply': '版主申请通知',
  'post_review_moderator': '帖子待审核通知（版主）',
  'order_paid_user': '支付成功通知',
  'withdraw_result': '提现处理结果',
  'order_paid_referrer': '佣金到账通知',
  'revenue_split': '创作分成通知',
  'comment_approved': '评论审核通过',
  'comment_reply': '评论被回复',
  'content_approved': '内容审核通过',
  'phone_changed': '手机号修改通知',
  'identity_result': '身份认证结果',
  'account_ban_user': '帐号禁封/解封',
  'report_result': '举报处理结果',
  'moderator_apply_result': '版主申请结果',
  'moderator_removed': '版主被移出',
  'answer_accepted': '回答被采纳',
  'private_message': '私信通知'
}

const codeLabel = (code: string) => CODE_LABELS[code] || code
const templates = ref<any[]>([])
const loading = ref(true)
const saving = ref(false)
const showAddDialog = ref(false)
const showEditDialog = ref(false)
const showDeleteConfirm = ref(false)
const editingId = ref<number | null>(null)
const deleteTarget = ref<any>(null)
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
const customCode = ref('')
let toastTimer: any = null

const form = reactive({
  name: '',
  code: '',
  subject: '',
  html_content: '',
  description: '',
  sort_order: 0,
  status: '1'
})

const showToast = (m: string, t: 'success' | 'error' = 'success') => {
  toastMsg.value = m
  toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

const loadTemplates = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/email-templates' })
    templates.value = Array.isArray(res) ? res : (res?.data || [])
  } catch (e: any) { showToast('加载失败: ' + (e.message || ''), 'error') }
  loading.value = false
}

const resetForm = () => {
  form.name = ''
  form.code = ''
  form.subject = ''
  form.html_content = ''
  form.description = ''
  form.sort_order = 0
  form.status = '1'
  customCode.value = ''
}

const KNOWN_CODES = [
  'all','register_verify','password_reset','new_submission','new_order','withdraw_request',
  'submission_review','post_review','identity_verify','account_appeal','report_notify',
  'moderator_apply','post_review_moderator','order_paid_user','withdraw_result',
  'order_paid_referrer','revenue_split','comment_approved','comment_reply','content_approved',
  'phone_changed','identity_result','account_ban_user','report_result',
  'moderator_apply_result','moderator_removed','answer_accepted','private_message'
]

const editTemplate = (tpl: any) => {
  editingId.value = tpl.id
  form.name = tpl.name
  form.subject = tpl.subject || ''
  form.html_content = tpl.html_content || ''
  form.description = tpl.description || ''
  form.sort_order = tpl.sort_order || 0
  form.status = tpl.status || '1'
  const code = tpl.code || ''
  if (code && !KNOWN_CODES.includes(code)) {
    customCode.value = code
    form.code = '__custom__'
  } else {
    customCode.value = ''
    form.code = code
  }
  showEditDialog.value = true
}

const closeDialog = () => {
  showAddDialog.value = false
  showEditDialog.value = false
  editingId.value = null
  resetForm()
}

const saveTemplate = async () => {
  if (!form.name || !form.code) { showToast('名称和代码不能为空', 'error'); return }
  const code = form.code === '__custom__' ? customCode.value : form.code
  if (!code) { showToast('代码不能为空', 'error'); return }
  saving.value = true
  try {
    const data = { ...form, code }
    if (editingId.value) {
      await request.put({ url: `/api/email-templates/${editingId.value}`, data })
      showToast('更新成功')
    } else {
      await request.post({ url: '/api/email-templates', data })
      showToast('创建成功')
    }
    closeDialog()
    await loadTemplates()
  } catch (e: any) { showToast('操作失败: ' + (e.message || ''), 'error') }
  saving.value = false
}

const deleteTemplate = (tpl: any) => {
  deleteTarget.value = tpl
  showDeleteConfirm.value = true
}

const confirmDelete = async () => {
  if (!deleteTarget.value) return
  try {
    await request.del({ url: `/api/email-templates/${deleteTarget.value.id}` })
    showToast('删除成功')
    showDeleteConfirm.value = false
    deleteTarget.value = null
    await loadTemplates()
  } catch (e: any) { showToast('删除失败: ' + (e.message || ''), 'error') }
}

onMounted(() => loadTemplates())
</script>
