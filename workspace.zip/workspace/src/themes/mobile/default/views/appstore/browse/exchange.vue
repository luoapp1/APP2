<template>
  <div class="page">
    <div class="top-bar">
      <div class="back-btn" @click="$router.back()">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="20" height="20">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
        </svg>
      </div>
      <div class="top-title">资产转换</div>
    </div>

    <!-- 当前余额卡片 -->
    <div v-if="loading" class="flex justify-center py-20">
      <div class="w-6 h-6 border-2 border-[#ffaa33] border-t-transparent rounded-full animate-spin"></div>
    </div>

    <div v-else-if="loginRequired" class="empty-state">
      <div class="text-gray-400 text-center py-20">
        <div class="text-lg mb-3">请先登录</div>
        <div class="text-sm text-[#ffaa33] cursor-pointer" @click="$router.push('/login')">点击前往登录</div>
      </div>
    </div>

    <div v-else-if="exchanges.length === 0" class="empty-state">
      <div class="text-gray-400 text-center py-20">暂无可用的资产兑换配置</div>
    </div>

    <template v-else>
    <div class="points-card" v-if="currentExchange">
      <div class="points-label">可用{{ currentExchange.fromDisplayName }}</div>
      <div class="points-num">{{ fmtBalance(currentBalance) }}</div>
      <div class="flex justify-between items-center">
        <span class="rate-text">{{ currentExchange.rateDesc }}</span>
        <span class="points-btn" @click="$router.push('/appstore/bills')">账单</span>
      </div>
    </div>

    <!-- 下拉选择框 -->
    <div class="select-wrap" v-if="exchanges.length > 0">
      <div class="select-box" @click="selectOpen = true">
        <span class="select-text">{{ currentExchange?.tabName || '选择兑换类型' }}</span>
        <svg class="select-arrow" :class="{ open: selectOpen }" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <!-- 底部弹窗选择面板 -->
    <div v-if="selectOpen" class="select-overlay" @click="selectOpen = false">
      <div class="select-popup">
        <div class="select-header">
          <span class="select-cancel" @click="selectOpen = false">取消</span>
          选择兑换类型
        </div>
        <div
          v-for="(ex, i) in exchanges"
          :key="ex.typeKey"
          class="option-item"
          :class="{ active: i === currentIndex }"
          @click="switchExchange(i)"
        >{{ ex.tabName }}</div>
      </div>
    </div>

    <!-- 兑换套餐 -->
    <div class="card" v-if="currentExchange">
      <div class="card-header">
        <div class="card-title">选择兑换档位</div>
      </div>
      <div class="grid-3">
        <div
          v-for="(pkg, i) in packages"
          :key="i"
          class="item"
          :class="{ active: i === selectedIndex }"
          @click="selectPackage(i)"
        >
          <div class="item-gain">{{ fmtToAmount(pkg.toAmount) }}</div>
          <div class="item-desc">{{ currentExchange.toDisplayName }}</div>
          <div class="item-cost">消耗{{ fmtFromAmount(pkg.fromAmount) }}{{ currentExchange.fromDisplayName }}</div>
        </div>
      </div>
    </div>

    <!-- 兑换说明 -->
    <div class="desc-text" v-if="currentExchange">
      <div class="font-medium text-black mb-1">兑换规则：</div>
      <p>1. 兑换为单向转换，完成不可退回；</p>
      <p>2. 兑换后资产实时到账，可在其他账户页面查看；</p>
      <p>3. 如有任何疑问请联系客服。</p>
    </div>

    <!-- 底部固定栏 -->
    <div class="bottom-bar" v-if="currentExchange && currentPackage">
      <div class="bottom-info">
        <div class="info-text">
          预计获得：<span class="highlight-red">{{ fmtToAmount(currentPackage.toAmount) }}</span> {{ currentExchange.toDisplayName }}
        </div>
        <div class="text-sm text-gray-400">消耗 {{ fmtFromAmount(currentPackage.fromAmount) }} {{ currentExchange.fromDisplayName }}</div>
      </div>
      <div class="exchange-btn" @click="showConfirm">立即兑换</div>
    </div>

    <!-- 确认兑换弹窗 -->
    <div v-if="confirmVisible" class="popup-mask" @click.self="confirmVisible = false">
      <div class="popup-box">
        <div class="popup-title">确认兑换</div>
        <div class="popup-content">
          是否消耗{{ fmtFromAmount(currentPackage?.fromAmount) }}{{ currentExchange?.fromDisplayName }}兑换{{ fmtToAmount(currentPackage?.toAmount) }}{{ currentExchange?.toDisplayName }}？
        </div>
        <div class="popup-row">
          <div class="popup-cancel" @click="confirmVisible = false">取消</div>
          <div class="popup-confirm" :class="{ disabled: submitting }" @click="doExchange">{{ submitting ? '兑换中...' : '确认兑换' }}</div>
        </div>
      </div>
    </div>

    </template>

    <!-- Toast -->
    <div v-if="toastMsg" class="toast" :class="toastType">{{ toastMsg }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreExchange' })

const exchanges = ref<any[]>([])
const balances = ref<Record<string, number>>({})
const currentIndex = ref(0)
const selectedIndex = ref(1)
const selectOpen = ref(false)
const confirmVisible = ref(false)
const submitting = ref(false)
const loading = ref(true)
const loginRequired = ref(false)
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any

const showToast = (m: string, t: 'success' | 'error' = 'success') => {
  toastMsg.value = m; toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const currentExchange = computed(() => exchanges.value[currentIndex.value] || null)

const currentBalance = computed(() => {
  if (!currentExchange.value) return 0
  return balances.value[currentExchange.value.fromCurrency] || 0
})

const fmtBalance = (v: number) => {
  const ex = currentExchange.value
  if (ex) return trimTrailingZeros(Number(v).toFixed(ex.fromDecimalPlaces))
  return String(v)
}

const fmtFromAmount = (v: number) => {
  const ex = currentExchange.value
  if (ex) return trimTrailingZeros(Number(v).toFixed(ex.fromDecimalPlaces))
  return String(v)
}

const fmtToAmount = (v: number) => {
  const ex = currentExchange.value
  if (ex) return trimTrailingZeros(Number(v).toFixed(ex.toDecimalPlaces))
  return String(v)
}

function trimTrailingZeros(s: string) {
  return s.replace(/\.0+$/, '').replace(/(\.\d+?)0+$/, '$1')
}

const packages = computed(() => {
  const ex = currentExchange.value
  if (!ex) return []
  const rate = ex.rate
  const mults = [1, 5, 10, 25, 50, 100]
  return mults.map(mul => {
    const fromAmount = mul
    const toAmount = Math.floor(mul * rate)
    return { fromAmount, toAmount }
  })
})

const currentPackage = computed(() => packages.value[selectedIndex.value] || null)

const switchExchange = (i: number) => {
  currentIndex.value = i
  selectedIndex.value = 1
  selectOpen.value = false
}

const selectPackage = (i: number) => {
  selectedIndex.value = i
}

const showConfirm = () => {
  if (!currentPackage.value) return showToast('请选择兑换档位', 'error')
  const bal = currentBalance.value
  if (currentPackage.value.fromAmount > bal) return showToast(`${currentExchange.value?.fromDisplayName}不足`, 'error')
  confirmVisible.value = true
}

const doExchange = async () => {
  if (submitting.value) return
  submitting.value = true
  try {
    const ex = currentExchange.value
    const pkg = currentPackage.value
    if (!ex || !pkg) return

    await request.post({
      url: '/api/exchange/apply',
      data: {
        fromCurrency: ex.fromCurrency,
        toCurrency: ex.toCurrency,
        fromAmount: pkg.fromAmount,
      },
      showErrorMessage: false,
    })
    showToast('兑换成功', 'success')
    confirmVisible.value = false
    loadConfig()
  } catch (e: any) {
    showToast(e?.msg || '兑换失败', 'error')
  }
  submitting.value = false
}

const loadConfig = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/exchange/config' })
    if (res) {
      exchanges.value = res.exchanges || []
      balances.value = res.balances || {}
    } else {
      loginRequired.value = true
    }
  } catch {
    loginRequired.value = true
  }
  loading.value = false
}

onMounted(loadConfig)
</script>

<style scoped>
.page { min-height: 100vh; background: linear-gradient(180deg, #f9efe2 0%, #ffffff 52%); padding-bottom: 120px; }
.top-bar {
  display: flex; align-items: center; padding: 16px 14px;
}
.back-btn { cursor: pointer; color: #000; }
.top-title { flex: 1; text-align: center; font-size: 16px; font-weight: 600; margin-right: 20px; }

.points-card {
  margin: 8px 14px 16px; border-radius: 16px;
  background: linear-gradient(135deg, #ffc864, #ffaa33);
  padding: 18px 20px; color: #fff;
}
.points-label { font-size: 14px; opacity: .9; }
.points-num { font-size: 40px; font-weight: 800; margin: 4px 0; }
.rate-text { font-size: 13px; opacity: .85; }
.points-btn { font-size: 13px; background: rgba(255,255,255,.25); padding: 4px 10px; border-radius: 99px; cursor: pointer; }

.select-wrap { margin: 0 14px 16px; }
.select-box {
  width: 100%; background: #fff; border-radius: 12px; padding: 14px 16px;
  display: flex; justify-content: space-between; align-items: center;
  font-size: 15px; cursor: pointer;
}
.select-text { color: #222; }
.select-arrow { color: #999; transition: transform .24s; }
.select-arrow.open { transform: rotate(180deg); }

.select-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 98;
  display: flex; align-items: flex-end; justify-content: center;
}
.select-popup {
  width: 100%; max-width: 375px; background: #fff; border-radius: 16px 16px 0 0;
  padding-bottom: 30px; z-index: 99;
}
.select-header { padding: 16px; text-align: center; font-weight: 600; border-bottom: 1px solid #eee; position: relative; }
.select-cancel { position: absolute; left: 16px; color: #666; cursor: pointer; }
.option-item { padding: 16px; text-align: center; font-size: 15px; border-bottom: 1px solid #f3f3f3; cursor: pointer; }
.option-item.active { color: #ff4d4f; font-weight: 600; }

.card { margin: 0 14px 16px; background: #fff; border-radius: 16px; padding: 16px; }
.card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
.card-title { font-size: 15px; font-weight: 600; }
.grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.item {
  border: 1px solid #e5e5e5; border-radius: 10px; padding: 12px 6px;
  text-align: center; cursor: pointer; transition: .2s;
}
.item.active { border-color: #ff4d4f; background: #fff5f5; }
.item-gain { font-size: 22px; font-weight: 800; color: #111; }
.item-desc { font-size: 12px; color: #666; margin: 2px 0; }
.item-cost { font-size: 13px; color: #ff5233; }

.desc-text { margin: 0 14px; font-size: 12px; color: #666; line-height: 1.7; }

.bottom-bar {
  position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 100%; max-width: 375px; background: #fff;
  padding: 14px 14px 22px; border-radius: 16px 16px 0 0;
  box-shadow: 0 -2px 12px rgba(0,0,0,.06);
}
.bottom-info { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 14px; }
.highlight-red { color: #ff4d4f; font-weight: 700; }
.exchange-btn {
  width: 100%; height: 46px; line-height: 46px; background: #ff4d4f; color: #fff;
  border-radius: 99px; text-align: center; font-size: 16px; font-weight: 600; cursor: pointer;
}

.popup-mask {
  position: fixed; inset: 0; background: rgba(0,0,0,.5);
  display: flex; align-items: center; justify-content: center; z-index: 100;
}
.popup-box { width: 300px; background: #fff; border-radius: 16px; overflow: hidden; }
.popup-title { padding: 20px 16px 10px; text-align: center; font-size: 16px; font-weight: 600; }
.popup-content { padding: 8px 20px 20px; text-align: center; color: #555; font-size: 14px; }
.popup-row { display: flex; border-top: 1px solid #eee; }
.popup-cancel { width: 50%; text-align: center; padding: 14px; font-size: 15px; cursor: pointer; color: #666; border-right: 1px solid #eee; }
.popup-confirm { width: 50%; text-align: center; padding: 14px; font-size: 15px; cursor: pointer; color: #ff4d4f; font-weight: 600; }
.popup-confirm.disabled { opacity: .5; pointer-events: none; }

.toast {
  position: fixed; top: 60px; left: 50%; transform: translateX(-50%); z-index: 200;
  padding: 10px 24px; border-radius: 8px; font-size: 14px; color: #fff; white-space: nowrap;
}
.toast.success { background: #10b981; }
.toast.error { background: #ef4444; }

.empty-state { text-align: center; color: #9ca3af; font-size: 14px; padding: 80px 0; }

@keyframes spin { to { transform: rotate(360deg); } }
.animate-spin { animation: spin 1s linear infinite; }

.flex { display: flex; }
.justify-between { justify-content: space-between; }
.items-center { align-items: center; }
.font-medium { font-weight: 500; }
.text-black { color: #000; }
.mb-1 { margin-bottom: 4px; }
.text-sm { font-size: 12px; }
.text-gray-400 { color: #9ca3af; }
</style>
