<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">解锁申请管理</span>
    </div>

    <div class="bg-white px-4 pt-1 pb-3">
      <div class="flex bg-gray-100 rounded-xl p-1">
        <button
          v-for="tab in statusTabs"
          :key="tab.key"
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200"
          :class="activeTab === tab.key ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = tab.key"
        >{{ tab.label }}<span v-if="tab.key === 'pending' && pendingCount > 0" class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-[#6366F1] text-white">{{ pendingCount }}</span></button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="loading" class="flex justify-center pt-40">
        <div class="animate-spin w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full" />
      </div>

      <template v-else>
        <div v-if="filteredList.length === 0" class="flex flex-col items-center pt-20 text-gray-400">
          <span class="text-sm">暂无{{ statusLabel(activeTab) }}的解锁申请</span>
        </div>

        <div v-for="item in filteredList" :key="item.id" class="bg-white mx-3 mt-3 rounded-xl p-4">
          <div class="flex items-center gap-3 mb-3">
            <img
              :src="item.user_avatar || item.userAvatar"
              class="w-10 h-10 rounded-full object-cover flex-shrink-0 bg-gray-100"
              @error="e => e.target.src = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22%3E%3Ccircle cx=%2212%22 cy=%228%22 r=%224%22 fill=%22%23ccc%22/%3E%3Cpath d=%22M4 20c0-4 4-7 8-7s8 3 8 7%22 fill=%22%23ccc%22/%3E%3C/svg%3E'"
            />
            <div class="flex-1 min-w-0">
              <div class="text-sm font-semibold text-gray-800">{{ item.user_name || item.userName }}</div>
              <div class="text-[11px] text-gray-400">{{ item.create_time || item.createTime }}</div>
            </div>
            <span class="px-2 py-1 rounded text-[10px] font-medium" :style="statusBadgeStyle(item.status)">{{ statusLabel(item.status) }}</span>
          </div>

          <div class="text-sm text-gray-700 mb-1 font-medium line-clamp-1">
            帖子：{{ item.post_title || item.postTitle }}
          </div>

          <div class="text-xs text-gray-500 mb-3 bg-gray-50 rounded-lg p-2.5 leading-relaxed">
            {{ item.reason || '无理由说明' }}
          </div>

          <div v-if="item.status === 'pending'" class="flex gap-3">
            <button class="flex-1 h-9 rounded-lg text-sm font-medium text-white active:opacity-80" style="background:#00BFA5" @click="handleApprove(item)">
              <svg class="w-4 h-4 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
              通过
            </button>
            <button class="flex-1 h-9 rounded-lg text-sm font-medium text-white active:opacity-80" style="background:#EF4444" @click="showReject(item)">
              <svg class="w-4 h-4 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
              拒绝
            </button>
          </div>
        </div>
      </template>
    </div>

    <Teleport to="body">
      <div v-if="rejectVisible" class="fixed inset-0 z-[60]" @click.self="closeReject">
        <div class="absolute inset-0 bg-black/50" />
        <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl p-5 pb-8 max-h-[80vh] overflow-y-auto">
          <div class="text-base font-semibold text-gray-800 mb-4">拒绝解锁申请</div>

          <div class="mb-4">
            <div class="text-xs text-gray-500 mb-1.5">拒绝理由</div>
            <textarea
              v-model="rejectReason"
              class="w-full h-24 px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none resize-none focus:border-[#EF4444]"
              placeholder="请输入拒绝理由（可选）"
              maxlength="200"
            />
          </div>

          <div v-if="rejectMsg" class="text-xs text-[#EF4444] text-center mb-3">{{ rejectMsg }}</div>

          <div class="flex gap-3 mt-6">
            <button class="flex-1 h-11 rounded-lg text-sm font-medium bg-gray-100 text-gray-600 active:bg-gray-200" @click="closeReject">取消</button>
            <button class="flex-1 h-11 rounded-lg text-sm font-medium text-white active:opacity-80" style="background:#EF4444" :disabled="rejectSaving" @click="doReject">{{ rejectSaving ? '处理中...' : '确认拒绝' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

const loading = ref(true)
const list = ref([])
const activeTab = ref('pending')

const statusTabs = [
  { key: 'pending', label: '待处理' },
  { key: 'approved', label: '已通过' },
  { key: 'rejected', label: '已拒绝' }
]

const statusLabelMap = { pending: '待处理', approved: '已通过', rejected: '已拒绝' }

function statusLabel(s) { return statusLabelMap[s] || s }

function statusBadgeStyle(s) {
  const colors = {
    pending: { bg: '#FEF3C7', color: '#D97706' },
    approved: { bg: '#D1FAE5', color: '#059669' },
    rejected: { bg: '#FEE2E2', color: '#DC2626' }
  }
  const c = colors[s] || { bg: '#F3F4F6', color: '#6B7280' }
  return { background: c.bg, color: c.color }
}

const filteredList = computed(() => list.value.filter(item => item.status === activeTab.value))
const pendingCount = computed(() => list.value.filter(item => item.status === 'pending').length)

const rejectVisible = ref(false)
const rejectTargetId = ref(0)
const rejectReason = ref('')
const rejectMsg = ref('')
const rejectSaving = ref(false)

async function loadData() {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/community/admin/unlock-requests' })
    list.value = Array.isArray(res) ? res : (res?.list || res?.data?.list || [])
  } catch (e) {
    list.value = []
  } finally {
    loading.value = false
  }
}

async function handleApprove(item) {
  try {
    await request.post({
      url: `/api/community/admin/unlock-request/${item.id}/handle`,
      data: { action: 'approve' }
    })
    loadData()
  } catch (e) {
    /* ignore */
  }
}

function showReject(item) {
  rejectTargetId.value = item.id
  rejectReason.value = ''
  rejectMsg.value = ''
  rejectVisible.value = true
}

function closeReject() {
  rejectVisible.value = false
  rejectTargetId.value = 0
}

async function doReject() {
  rejectSaving.value = true
  rejectMsg.value = ''
  try {
    await request.post({
      url: `/api/community/admin/unlock-request/${rejectTargetId.value}/handle`,
      data: { action: 'reject', reply: rejectReason.value || undefined }
    })
    closeReject()
    loadData()
  } catch (e) {
    rejectMsg.value = e?.message || '操作失败'
  } finally {
    rejectSaving.value = false
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.line-clamp-1 {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
textarea::placeholder { color: #c0c4cc; }
</style>
