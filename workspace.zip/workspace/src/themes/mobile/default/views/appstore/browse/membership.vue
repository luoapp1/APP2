<template>
  <div class="vip-page">
    <!-- 顶部标题栏 -->
    <div class="vip-topbar">
      <svg class="vip-topbar-back" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" @click="$router.back()"><path d="M15 19l-7-7 7-7"/></svg>
      <h1 class="vip-topbar-title">我的会员</h1>
      <div class="vip-topbar-right">
        <svg class="vip-topbar-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
        <span class="vip-topbar-order">订单</span>
      </div>
    </div>

    <!-- 用户头部区域 -->
    <div class="vip-hero">
      <div class="vip-hero-user">
        <div class="vip-hero-avatar">
          <img v-if="avatarUrl" :src="avatarUrl"  loading="lazy" />
          <svg v-else viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v1.2c0 .66.54 1.2 1.2 1.2h16.8c.66 0 1.2-.54 1.2-1.2v-1.2c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
        </div>
        <div class="vip-hero-info">
          <div class="vip-hero-name">{{ userDisplayName }}</div>
          <div class="vip-hero-sub" @click="showMembershipModal = true">
            <template v-if="isLogin && currentLevelName">{{ currentLevelName }}</template>
            <template v-else>您还不是会员</template>
            <svg class="vip-hero-sub-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>
        <button v-if="isLogin && myMemberships.length > 1" class="vip-hero-btn" @click="showMembershipModal = true">我的会员</button>
      </div>
      <div v-if="isLogin && myMemberships.length" class="vip-hero-expire">到期 {{ formatExpire(myMemberships[0].expire_time) }}</div>

      <!-- 等级Tab栏 -->
      <div class="vip-hero-tabs">
        <div
          v-for="lvl in availableLevels" :key="lvl.id"
          class="vip-hero-tab"
          :class="{ active: selectedLevel === lvl.id }"
          @click="selectLevel(lvl)"
        >
          <span class="vip-hero-tab-name">{{ lvl.name }}</span>
          <span class="vip-hero-tab-desc">{{ fmtTabDesc(lvl) }}</span>
        </div>
        <div class="vip-hero-tab-placeholder" />
      </div>
    </div>

    <!-- 套餐卡片横向滚动 -->
    <div class="vip-package-scroll" v-if="levelPlans.length > 0">
      <div
        v-for="p in levelPlans" :key="p.id"
        class="vip-pkg-card"
        :class="{ active: selectedPlan === p.id }"
        @click="selectedPlan = p.id"
      >
        <span v-if="p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())" class="vip-pkg-tag">限时特惠</span>
        <div class="vip-pkg-top" :class="{ promo: p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()) }">
          <div class="vip-pkg-dur">{{ durationLabel(p.duration_days) }}</div>
          <div class="vip-pkg-price">
            <span class="vip-pkg-sym">¥</span>
            <span class="vip-pkg-val">{{ planPrice(p) }}</span>
            <span v-if="planOriginalPrice(p) > Number(planPrice(p))" class="vip-pkg-old">¥{{ planOriginalPrice(p) }}</span>
          </div>
        </div>
        <div class="vip-pkg-bot" :class="{ promo: p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()) }">
          {{ planOriginalPrice(p) > Number(planPrice(p)) ? '立省 ¥' + (planOriginalPrice(p) - Number(planPrice(p))) : (capacityLabel || selectedLevelName + '会员') }}
        </div>
      </div>
    </div>

    <!-- 优惠券 / 促销信息 -->
    <div class="vip-promo-banner">
      <div class="vip-promo-left">
        <svg class="vip-promo-icon" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M20 12v6a2 2 0 01-2 2H6a2 2 0 01-2-2v-6m16-4V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2m16 0H4m16 0a2 2 0 012 2v2a2 2 0 01-2 2H4a2 2 0 01-2-2v-2a2 2 0 012-2"/></svg>
        <span class="vip-promo-text">选择套餐后查看可用优惠</span>
      </div>
      <svg class="vip-promo-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12"><path d="M9 18l6-6-6-6"/></svg>
    </div>

    <!-- 买一得多 (礼包展示) -->
    <div class="vip-gift-section">
      <div class="vip-gift-header">
        <span class="vip-gift-title">买一得多</span>
        <span class="vip-gift-sub">开通后自动发放以下礼包</span>
      </div>
      <div class="vip-gift-grid">
        <div class="vip-gift-item" v-for="row in giftShowRows" :key="row.label" v-show="row.visible">
          <div class="vip-gift-icon" :style="{ background: row.bg }">
            <svg v-if="row.label === '首次开通赠送'" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M5 4h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V6c0-1.1.9-2 2-2zm0 6h14M5 16h8m-8-2h8"/></svg>
            <svg v-else-if="row.label === '定时专属礼包'" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/></svg>
            <svg v-else-if="row.label === '生日礼包'" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 2l3 4.5L20 5l-2 7 2 8-5-3-3 3-3-3-5 3 2-8-2-7 5-.5L12 2z"/></svg>
          </div>
          <span class="vip-gift-name">{{ row.label }}</span>
          <span class="vip-gift-val">{{ row.desc }}</span>
        </div>
      </div>
    </div>

    <!-- 支付方式 -->
    <div class="vip-pay-section">
      <div
        v-for="pm in selectablePayMethods" :key="pm.currency_key"
        class="vip-pay-item"
        :class="{ active: confirmPayMethod === pm.currency_key }"
        @click="confirmPayMethod = pm.currency_key"
      >
        <div class="vip-pay-icon" :class="'vip-pay-' + pm.currency_key" :style="{ background: pmIconBg(pm.currency_key) }">{{ pmIconText(pm.currency_key) }}</div>
        <span class="vip-pay-label">{{ pm.display_name || '余额' }}支付</span>
        <svg v-if="confirmPayMethod === pm.currency_key" class="vip-pay-check" viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><circle cx="12" cy="12" r="10" :fill="pmIconBg(pm.currency_key)"/><path d="M9 12l2 2 4-4" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <svg v-else class="vip-pay-uncheck" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><circle cx="12" cy="12" r="10"/></svg>
      </div>
    </div>

    <!-- 权益对比 -->
    <div class="vip-priv-section" v-if="compareLevels.length >= 2">
      <h2 class="vip-priv-title">{{ compareLevels[compareLevels.length-1]?.name || '最高' }}会员尊享权​​益</h2>

      <div v-for="group in privilegeGroups" :key="group.name" class="vip-priv-group">
        <h3 class="vip-priv-group-title">{{ group.name }}</h3>
        <div class="vip-priv-table-wrap">
          <table class="vip-priv-table">
            <thead>
              <tr>
                <th class="vip-priv-col-label">特权</th>
                <th v-for="cl in compareLevels" :key="'hd-'+cl.id" class="vip-priv-col-lvl" :class="{ 'hd-highlight': cl.id === highlightLevelId }">{{ cl.name }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(row, idx) in group.rows" :key="row.label" :class="{ 'row-alt': idx % 2 === 1 }">
                <td class="vip-priv-col-label" :class="{ clickable: clickableRowLabels.has(row.label) }" @click="clickableRowLabels.has(row.label) && (openPrivDetail(row.label), showCommissionDetail = true)">{{ row.label }}</td>
                <td v-for="cell in row.cells" :key="cell.levelId" class="vip-priv-col-lvl" :class="{ highlight: cell.levelId === highlightLevelId, clickable: clickableRowLabels.has(row.label) }" @click="clickableRowLabels.has(row.label) && (openPrivDetail(row.label), showCommissionDetail = true)">
                  <template v-if="cell.type === 'check'">
                    <svg v-if="cell.value" class="vip-priv-chk" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    <span v-else class="vip-priv-no">-</span>
                  </template>
                  <span v-else class="vip-priv-txt">{{ cell.value }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="vip-bottom-safe" />

    <!-- 底部购买栏 -->
    <footer class="vip-bottom-bar">
      <div class="vip-bb-left">
        <span class="vip-bb-price" v-if="selectedPlanInfo">¥{{ totalPrice }}</span>
        <span class="vip-bb-discount" v-if="selectedPlanInfo && planOriginalPrice(selectedPlanInfo) > Number(planPrice(selectedPlanInfo))">已优惠 ¥{{ planOriginalPrice(selectedPlanInfo) - Number(planPrice(selectedPlanInfo)) }}</span>
      </div>
      <button
        class="vip-bb-btn"
        :class="{ disabled: !selectedPlan || buyLoading > 0 }"
        :disabled="!selectedPlan || buyLoading > 0"
        @click="showConfirm"
      >
        <span v-if="buyLoading > 0" class="vip-btn-spinner" /> 立即购买
      </button>
    </footer>

    <!-- 我的会员弹窗 (保持不变) -->
    <div v-if="showMembershipModal" class="vip-modal-overlay" @click.self="showMembershipModal = false">
      <div class="vip-modal">
        <div class="vip-modal-head">
          <h3>我的会员</h3>
          <button class="vip-modal-close" @click="showMembershipModal = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="vip-modal-body">
          <div v-for="m in myMemberships" :key="m.id" class="vip-m-item" :class="{ 'is-top': m.id === myMemberships[0].id }">
            <span class="vip-m-dot" :style="{ background: m.bg_color || '#5b6abf' }" />
            <div class="vip-m-info">
              <span class="vip-m-name">{{ m.level_name }}</span>
              <span class="vip-m-meta">到期 {{ formatExpire(m.expire_time) }}</span>
            </div>
            <span v-if="m.id === myMemberships[0].id" class="vip-m-top-badge">当前</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 确认支付弹窗 (保持不变) -->
    <div class="vip-overlay" v-if="showConfirmModal" @click.self="showConfirmModal = false">
      <div class="vip-sheet">
        <div class="vip-sheet-bar" />
        <div class="vip-sheet-head">
          <span class="vip-sheet-title">确认支付</span>
          <svg class="vip-sheet-close" @click="showConfirmModal = false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </div>
        <div class="vip-sheet-body">
          <div class="vip-sheet-prod">
            <div class="vip-sheet-prod-icon">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
            </div>
            <div class="vip-sheet-prod-info">
              <div class="vip-sheet-prod-name">{{ selectedPlanInfo?.name || selectedPlanInfo?.levelName || selectedLevelName }}</div>
              <div class="vip-sheet-prod-sub">{{ selectedPlanInfo ? durationLabel(selectedPlanInfo.duration_days) : '' }}</div>
            </div>
            <div class="vip-sheet-prod-price">&#165;{{ totalPrice }}</div>
          </div>
          <div class="vip-sheet-row">
            <span class="vip-sr-label">支付方式</span>
            <div class="vip-sr-pays">
              <div v-for="pm in selectablePayMethods" :key="pm.currency_key" class="vip-sr-pay" :class="{ active: confirmPayMethod === pm.currency_key }" @click="confirmPayMethod = pm.currency_key">{{ pm.display_short || pm.display_name || '余额' }}</div>
            </div>
          </div>
          <div class="vip-sheet-row" v-if="isLogin && effectiveCoupons.length > 0">
            <span class="vip-sr-label">优惠券</span>
            <div class="vip-cp-trigger" @click="showCouponPicker = !showCouponPicker">
              <span v-if="selectedCouponId" class="vip-cp-selected">{{ selectedCouponInfo?.name }} ({{ selectedCouponInfo?.type === 'fixed' ? '¥' + selectedCouponInfo?.value : selectedCouponInfo?.type === 'fixed_points' ? selectedCouponInfo?.value + '积分' : (selectedCouponInfo?.value / 10) + '折' }})</span>
              <span v-else class="vip-cp-placeholder">不使用优惠券</span>
              <svg class="vip-cp-arrow" :class="{ open: showCouponPicker }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><path d="M6 9l6 6 6-6"/></svg>
            </div>
          </div>
          <div class="vip-cp-dropdown" v-if="showCouponPicker">
            <div class="vip-cp-opt" :class="{ active: selectedCouponId === 0 }" @click="selectCoupon(null)">不使用优惠券</div>
            <div v-for="c in effectiveCoupons" :key="c.userCouponId" class="vip-cp-opt" :class="{ active: selectedCouponId === c.userCouponId }" @click="selectCoupon(c)">
              <span>{{ c.name }}</span>
              <span v-if="c.type === 'fixed' || c.type === 'fixed_points'" class="vip-cp-val">{{ c.type === 'fixed_points' ? c.value + '积分' : '¥' + c.value }}</span>
              <span v-else class="vip-cp-val">{{ c.value / 10 }}折</span>
            </div>
          </div>
          <div class="vip-sheet-total">
            <div class="vip-st-row"><span>应付金额</span><span class="vip-st-red">&#165;{{ finalPrice }}</span></div>
            <div v-if="couponDiscount > 0" class="vip-st-row sub"><span>已优惠</span><span class="vip-cp-saved">-&#165;{{ couponDiscount }}</span></div>
            <div v-if="selectedPlanInfo" class="vip-st-row sub"><span>有效期至</span><span>{{ expirePreview }}</span></div>
          </div>
        </div>
        <button class="vip-sheet-pay-btn" :disabled="buyLoading > 0" @click="handleConfirmPay">{{ buyLoading > 0 ? '支付中...' : '立即支付' }}</button>
      </div>
    </div>

    <!-- 支付结果弹窗 (保持不变) -->
    <div v-if="showResultModal" class="vip-overlay center" @click.self="showResultModal = false">
      <div class="vip-toast">
        <div class="vip-toast-icon" :class="resultSuccess ? 'ok' : 'fail'">
          <svg v-if="resultSuccess" viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="28" height="28"><path d="M6 18L18 6M6 6l12 12"/></svg>
        </div>
        <div class="vip-toast-title">{{ resultSuccess ? '支付成功' : '支付失败' }}</div>
        <div class="vip-toast-msg">{{ resultMsg }}</div>
        <button class="vip-toast-btn" @click="showResultModal = false">我知道了</button>
      </div>
    </div>

    <!-- 推广返佣详情弹窗 -->
    <div v-if="showCommissionDetail" class="vip-modal-overlay" @click.self="showCommissionDetail = false">
      <div class="vip-modal">
        <div class="vip-modal-head">
          <h3>{{ privDetailLabel }}</h3>
          <button class="vip-modal-close" @click="showCommissionDetail = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="vip-modal-body">
          <div v-for="item in privDetailItems" :key="item.name" class="vip-m-item">
            <span class="vip-m-dot" :style="{ background: item.dotColor }" />
            <div class="vip-m-info">
              <span class="vip-m-name">{{ item.name }}</span>
              <span class="vip-m-meta">{{ item.desc }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'
import request from '@/utils/http'

const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const compressEnabledLevelIds = ref(new Set<number>())
const recycleRetentionDaysMap = ref(new Map<number, number>())
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const showConfirmModal = ref(false)
const showResultModal = ref(false)
const resultSuccess = ref(false)
const resultMsg = ref('')
const confirmPayMethod = ref('balance')

const currencySettings = ref<{ currency_key: string; display_name: string; decimal_places: number }[]>([])

const selectablePayMethods = computed(() => {
  if (!selectedPlanInfo.value) return []
  const cks = currencySettings.value
  const raw = selectedPlanInfo.value.payment_methods || selectedPlanInfo.value.paymentMethods
  let allowed: string[]
  if (typeof raw === 'string') { try { allowed = JSON.parse(raw) } catch { allowed = [] } }
  else if (Array.isArray(raw)) { allowed = raw }
  else { allowed = [] }
  // If no payment_methods configured, fall back to all currencies with price > 0
  if (allowed.length === 0) {
    const planCurrencies = typeof selectedPlanInfo.value.currencies === 'string'
      ? JSON.parse(selectedPlanInfo.value.currencies || '{}')
      : (selectedPlanInfo.value.currencies || {})
    allowed = cks.filter(c => (Number(planCurrencies[c.currency_key]) > 0 || Number(planCurrencies[c.currency_key + '_original']) > 0))
      .map(c => c.currency_key)
  }
  if (allowed.length === 0 && !selectedPlanInfo.value.paymentMethods && !selectedPlanInfo.value.payment_methods) {
    // Backward compat: always show balance and points if no currencies JSON
    allowed = ['balance', 'points']
  }
  return cks.filter(c => allowed.includes(c.currency_key)).map(c => ({
    ...c,
    display_short: c.currency_key === 'balance' ? '余额' : c.currency_key === 'points' ? '积分' : c.display_name
  }))
})
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)
const showCouponPicker = ref(false)
const showCommissionDetail = ref(false)
const privDetailLabel = ref('')
const privDetailItems = ref<{ name: string; desc: string; dotColor: string }[]>([])

const clickableRowLabels = new Set(['专属称号', '专属头像框', '生日礼包', '定时专属礼包', '首次开通赠送', '年度礼品', '推广返佣'])

function openPrivDetail(label: string) {
  privDetailLabel.value = label
  const items: { name: string; desc: string; dotColor: string }[] = []
  for (const lvl of compareLevels.value) {
    const dot = lvl.bg_color || '#5b6abf'
    let desc = ''
    if (label === '专属称号') {
      desc = lvl.titleName || lvl.title_id || (lvl.titleId ? `ID:${lvl.titleId}` : '暂未开放')
    } else if (label === '专属头像框') {
      desc = lvl.frameName || lvl.frame_id || (lvl.frameId ? `ID:${lvl.frameId}` : '暂未开放')
    } else if (label === '年度礼品') {
      const bs = (lvl.benefits || '').split(/[,，、]/).filter((s: string) => s.trim())
      const gift = bs.find((b: string) => b.includes('年度礼品'))
      desc = gift || '暂未开放'
    } else if (label === '推广返佣') {
      const r = Number(lvl.commissionRate || 0)
      const pr = Number(lvl.commissionPointsRate || 0)
      const parts: string[] = []
      if (r > 0) parts.push(`余额返佣 ${r}%`)
      if (pr > 0) parts.push(`积分返佣 ${pr}%`)
      desc = parts.length > 0 ? parts.join('，') : '暂未开启'
    } else {
      // gift rows
      desc = getGiftDetail(lvl.id, label) || '暂未配置'
    }
    items.push({ name: lvl.name, desc, dotColor: dot })
  }
  privDetailItems.value = items
}

function openCommissionDetail() {
  privDetailLabel.value = '推广返佣详情'
  const items = compareLevels.value.map((lvl: any) => {
    const r = Number(lvl.commissionRate || 0)
    const pr = Number(lvl.commissionPointsRate || 0)
    const parts: string[] = []
    if (r > 0) parts.push(`余额返佣 ${r}%`)
    if (pr > 0) parts.push(`积分返佣 ${pr}%`)
    return {
      name: lvl.name,
      desc: parts.length > 0 ? parts.join('，') : '暂未开启',
      dotColor: lvl.bg_color || '#5b6abf',
    }
  })
  privDetailItems.value = items
}

const isLogin = computed(() => userStore.isLogin)

const avatarUrl = computed(() => {
  const av = userStore.info.avatar
  if (!av) return ''
  if (av.startsWith('http')) return av
  return av
})

const userDisplayName = computed(() => {
  return userStore.info.nickname || userStore.info.userName || userStore.info.phone || '未登录'
})

const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '')

const myMemberships = ref<any[]>([])
const showMembershipModal = ref(false)
const fetchMyMemberships = async () => {
  try {
    const res: any = await request.get({ url: '/api/membership/my-memberships', showErrorMessage: false })
    myMemberships.value = res || []
  } catch {}
}
const currentMembershipLabel = computed(() => {
  if (!myMemberships.value.length) return ''
  return myMemberships.value.map(m => `${m.level_name}(${formatExpire(m.expire_time)})`).join(' | ')
})

function formatExpire(t: string) {
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return '永久'
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
  } catch { return '' }
}

const expireTimeDisplay = computed(() => {
  const t = userStore.info.expireTime
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return ''
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  } catch { return '' }
})

const availableLevels = computed(() => {
  return allLevels.value
    .filter((l: any) => l.status === '1')
    .filter((l: any) => products.value.some((p: any) => p.level_id === l.id))
    .sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const selectedLevelName = computed(() => allLevels.value.find((l: any) => l.id === selectedLevel.value)?.name || '')

const levelMinPrice = (lvl: any) => {
  const plans = products.value.filter((p: any) => p.level_id === lvl.id && Number(p.price) > 0)
  if (plans.length === 0) return lvl.price || 0
  return Math.min(...plans.map((p: any) => Number(p.price) || Infinity))
}

const levelPlans = computed(() => {
  if (!selectedLevel.value) return []
  return products.value.filter((p: any) => p.level_id === selectedLevel.value)
})

const selectedPlanInfo = computed(() => {
  if (!selectedPlan.value) return null
  return products.value.find((p: any) => p.id === selectedPlan.value) || null
})

function pmIconBg(key: string) {
  const m: Record<string, string> = { balance: '#508DFF', points: '#F59E0B' }
  return m[key] || '#6B7280'
}
function pmIconText(key: string) {
  const m: Record<string, string> = { balance: '余', points: '积' }
  return m[key] || key.charAt(0).toUpperCase()
}

const planCurrenciesObj = computed(() => {
  const p = selectedPlanInfo.value
  if (!p) return {}
  return typeof p.currencies === 'string' ? JSON.parse(p.currencies || '{}') : (p.currencies || {})
})

const totalPrice = computed(() => {
  if (!selectedPlanInfo.value) return '0'
  const p = selectedPlanInfo.value
  const curKey = confirmPayMethod.value
  const co = planCurrenciesObj.value
  const curPrice = Number(co[curKey] || 0)
  const curOriginal = Number(co[curKey + '_original'] || 0)
  if (curPrice > 0 || curOriginal > 0) {
    const isPromo = p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())
    return isPromo ? String(curPrice || curOriginal) : String(curOriginal || curPrice)
  }
  if (curKey === 'points') return String(p.points_price || p.price || 0)
  if (curKey === 'balance') return String(displayPrice(p))
  return '0'
})

const couponDiscount = computed(() => {
  if (!selectedCouponInfo.value) return 0
  const c = selectedCouponInfo.value
  const base = Number(totalPrice.value)
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    const pct = Math.max(0, (10 - c.value) / 10)
    let disc = Math.floor(base * pct * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPrice = computed(() => String(Math.max(0, Number(totalPrice.value) - couponDiscount.value)))

const expirePreview = computed(() => {
  if (!selectedPlanInfo.value) return '--'
  const days = selectedPlanInfo.value.duration_days
  if (days === 0) return '永久有效'
  const d = new Date(Date.now() + days * 86400000)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
})

function displayPrice(p: any) {
  if (p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())) return Number(p.price) || 0
  return Number(p.original_price) || Number(p.price) || 0
}
function planPrice(p: any) { return displayPrice(p).toFixed(0) }
function planOriginalPrice(p: any) {
  if (!(p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()))) return 0
  return Number(p.original_price) || 0
}
function durationLabel(days: number) {
  if (days === 0) return '永久'
  if (days >= 365 && days % 365 === 0) return `${days / 365}年`
  if (days >= 30 && days % 30 === 0) return `${days / 30}个月`
  return `${days}天`
}

const capacityLabel = computed(() => {
  const lv = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  if (!lv) return ''
  const dl = Number(lv.dataLimitMb || 0)
  if (dl <= 0) return ''
  if (dl >= 1048576) return `${(dl / 1048576).toFixed(0)}TB大容量`
  if (dl >= 1024) return `${(dl / 1024).toFixed(0)}GB大容量`
  return `${dl}MB`
})

function selectLevel(lvl: any) {
  selectedLevel.value = lvl.id
  const plans = products.value.filter((p: any) => p.level_id === lvl.id)
  if (plans.length > 0) selectedPlan.value = plans[0].id
  else selectedPlan.value = 0
}

function fmtTabDesc(lvl: any): string {
  const dl = Number(lvl.dataLimitMb || 0)
  if (dl >= 1024) return `${(dl/1024).toFixed(0)}G空间`
  if (dl > 0) return `${dl}MB空间`
  return '会员专享'
}

const compareLevels = computed(() => {
  return allLevels.value.filter((l: any) => l.status === '1').sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const highlightLevelId = computed(() => {
  const uid = currentLevelId.value
  if (uid) return uid
  const levels = compareLevels.value
  if (levels.length === 0) return 0
  const maxLvl = levels.reduce((max: any, l: any) => (l.level || 0) > (max.level || 0) ? l : max, levels[0])
  return maxLvl.id
})

const giftRowLabels = new Set(['生日礼包', '定时专属礼包', '首次开通赠送'])
const expandedGiftRows = ref(new Set<string>())

function isGiftRow(label: string) { return giftRowLabels.has(label) }
function toggleGiftRow(label: string) {
  const s = new Set(expandedGiftRows.value)
  if (s.has(label)) s.delete(label); else s.add(label)
  expandedGiftRows.value = s
}

const giftDetailMap: Record<string, [string, string]> = {
  '生日礼包': ['birthday_gift', 'birthdayGift'],
  '定时专属礼包': ['daily_gift', 'dailyGift'],
  '首次开通赠送': ['gift', 'gift'],
}

function giftValFromLevel(lvl: any, snakePrefix: string, camelPrefix: string) {
  const v = (key: string) => Number(lvl[key] || 0)
  return {
    pts: v(`${snakePrefix}_points`) || v(camelPrefix + 'Points'),
    bal: v(`${snakePrefix}_balance`) || v(camelPrefix + 'Balance'),
    exp: v(`${snakePrefix}_experience`) || v(camelPrefix + 'Experience'),
  }
}

function getGiftDetail(levelId: number, label: string): string {
  const key = giftDetailMap[label]
  if (!key) return ''
  const lvl = compareLevels.value.find((l: any) => l.id === levelId)
  if (!lvl) return ''
  const g = giftValFromLevel(lvl, key[0], key[1])
  const parts: string[] = []
  if (g.pts > 0) parts.push(`+${g.pts}积分`)
  if (g.bal > 0) parts.push(`+¥${g.bal}`)
  if (g.exp > 0) parts.push(`+${g.exp}经验`)
  return parts.length > 0 ? parts.join(' ') : ''
}

interface CompareCell {
  levelId: number
  type: 'check' | 'text'
  value: string | boolean
}

interface CompareRow {
  label: string
  cells: CompareCell[]
}

const allLevelCompareRows = computed((): CompareRow[] => {
  const levels = compareLevels.value
  if (levels.length < 2) return []

  const checkBy = (lvl: any, cond: boolean): CompareCell => ({
    levelId: lvl.id,
    type: 'check' as const,
    value: cond
  })

  const textBy = (lvl: any, text: string): CompareCell => ({
    levelId: lvl.id,
    type: 'text' as const,
    value: text
  })

  const fmtSize = (mb: number): string => {
    if (mb <= 0) return '不限'
    if (mb >= 1048576) return `${(mb / 1048576).toFixed(0)}TB`
    if (mb >= 1024) return `${(mb / 1024).toFixed(0)}GB`
    return `${mb}MB`
  }

  const hasGiftVal = (lvl: any, snakePrefix: string, camelPrefix: string): { pts: number; bal: number; exp: number } => {
    return giftValFromLevel(lvl, snakePrefix, camelPrefix)
  }

  const giftDetail = (lvl: any, snakePrefix: string, camelPrefix: string): string => {
    const g = hasGiftVal(lvl, snakePrefix, camelPrefix)
    const parts: string[] = []
    if (g.pts > 0) parts.push(`+${g.pts}积分`)
    if (g.bal > 0) parts.push(`+¥${g.bal}`)
    if (g.exp > 0) parts.push(`+${g.exp}经验`)
    return parts.length > 0 ? parts.join(' ') : ''
  }

  const hasGift = (lvl: any, snakePrefix: string, camelPrefix: string): boolean => {
    const g = hasGiftVal(lvl, snakePrefix, camelPrefix)
    return g.pts > 0 || g.bal > 0 || g.exp > 0
      || !!(lvl[`${snakePrefix}_coupon_ids`] || lvl[camelPrefix + 'CouponIds'])
  }

  const benefitMap = new Map<number, string[]>()
  for (const lv of levels) {
    benefitMap.set(lv.id, (lv.benefits || '').split(/[,，、]/).filter((s: string) => s.trim()).map((s: string) => s.trim()))
  }

  const hasBenefit = (lvl: any, keyword: string): boolean => {
    const bs = benefitMap.get(lvl.id) || []
    return bs.some((b: string) => b.includes(keyword) || keyword.includes(b))
  }

  type RowDef = { label: string; cell: (lvl: any) => CompareCell }

  const rowDefs: RowDef[] = [
    {
      label: '基础权益',
      cell: (lvl) => checkBy(lvl, (benefitMap.get(lvl.id) || []).length > 0)
    },
    {
      label: '商品折扣',
      cell: (lvl) => {
        const dr = Number(lvl.discountRate || lvl.discount_rate || 1)
        return textBy(lvl, dr < 1 ? `${(dr * 10).toFixed(0)}折` : '原价')
      }
    },
    {
      label: '积分倍数',
      cell: (lvl) => textBy(lvl, `${lvl.pointsMultiplier || lvl.points_multiplier || 1}倍`)
    },
    {
      label: '数据空间',
      cell: (lvl) => textBy(lvl, fmtSize(Number(lvl.dataLimitMb || lvl.data_limit_mb || 0)))
    },
    {
      label: '文件空间',
      cell: (lvl) => textBy(lvl, fmtSize(Number(lvl.fileLimitMb || lvl.file_limit_mb || 0)))
    },
    {
      label: '推广返佣',
      cell: (lvl) => {
        const hasRule = !!lvl.commissionRuleName
        if (!hasRule) return checkBy(lvl, false)
        const r = Number(lvl.commissionRate || 0)
        const pr = Number(lvl.commissionPointsRate || 0)
        return checkBy(lvl, r > 0 || pr > 0)
      }
    },
    {
      label: '图片压缩',
      cell: (lvl) => textBy(lvl, compressEnabledLevelIds.value.has(lvl.id) ? '是' : '否')
    },
    {
      label: '回收站保留',
      cell: (lvl) => {
        const days = recycleRetentionDaysMap.value.get(lvl.id) || 0
        return textBy(lvl, days > 0 ? `${days}天` : '不支持')
      }
    },
    {
      label: '专属称号',
      cell: (lvl) => checkBy(lvl, !!(lvl.titleId || lvl.title_id || lvl.titleName))
    },
    {
      label: '生日礼包',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'birthday_gift', 'birthdayGift'))
    },
    {
      label: '年度礼品',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '年度礼品'))
    },
    {
      label: '优先发货',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '优先发货'))
    },
    {
      label: '自动签到',
      cell: (lvl) => checkBy(lvl, !!(lvl.autoCheckin || lvl.auto_checkin))
    },
    {
      label: '专属客服',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '专属客服'))
    },
    {
      label: '专属头像框',
      cell: (lvl) => checkBy(lvl, !!(lvl.frameId || lvl.frame_id || lvl.frameName))
    },
    {
      label: '首次开通赠送',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'gift', 'gift'))
    },
    {
      label: '定时专属礼包',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'daily_gift', 'dailyGift') || !!(lvl.dailyGiftEnabled || lvl.daily_gift_enabled))
    },
  ]

  return rowDefs.map(def => ({
    label: def.label,
    cells: levels.map(l => def.cell(l))
  }))
})

const privilegeGroups = computed(() => {
  const rows = allLevelCompareRows.value
  const groups: { name: string; labels: string[] }[] = [
    { name: '基础特权', labels: ['商品折扣', '积分倍数', '数据空间', '文件空间', '回收站保留', '图片压缩'] },
    { name: '专属特权', labels: ['专属称号', '生日礼包', '定时专属礼包', '首次开通赠送', '年度礼品', '推广返佣', '优先发货', '自动签到', '专属客服', '专属头像框'] },
  ]
  return groups.map(g => ({
    name: g.name,
    rows: g.labels.map(l => rows.find(r => r.label === l)).filter(Boolean) as CompareRow[]
  })).filter(g => g.rows.length > 0)
})

const giftShowRows = computed(() => {
  if (!selectedPlanInfo.value) return []
  const lvl = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  if (!lvl) return []
  const rows: { label: string; visible: boolean; desc: string; bg: string }[] = []
  for (const label of ['首次开通赠送', '定时专属礼包', '生日礼包']) {
    const key = giftDetailMap[label]
    if (!key) continue
    const g = giftValFromLevel(lvl, key[0], key[1])
    const parts: string[] = []
    if (g.pts > 0) parts.push(`+${g.pts}积分`)
    if (g.bal > 0) parts.push(`+¥${g.bal}`)
    if (g.exp > 0) parts.push(`+${g.exp}经验`)
    const hasCoupons = !!(lvl[`${key[0]}_coupon_ids`] || lvl[key[1] + 'CouponIds'])
    rows.push({
      label,
      visible: parts.length > 0 || hasCoupons || (label === '定时专属礼包' && (lvl.dailyGiftEnabled || lvl.daily_gift_enabled)),
      desc: parts.join(' ') || '有礼',
      bg: label === '首次开通赠送' ? '#fef3c7' : label === '定时专属礼包' ? '#dbeafe' : '#fce7f3',
    })
  }
  return rows
})

async function loadCoupons() {
  if (!isLogin.value || !selectedPlanInfo.value) { usableCoupons.value = []; return }
  try {
    const res: any = await fetchUsableCoupons({ scene: 'membership', targetId: selectedLevel.value || 0, orderAmount: Number(totalPrice.value), payType: confirmPayMethod.value })
    usableCoupons.value = Array.isArray(res) ? res : []
    if (!usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value)) { selectedCouponId.value = 0; selectedCouponInfo.value = null }
  } catch { usableCoupons.value = [] }
}

function selectCoupon(c: any) {
  selectedCouponId.value = c ? c.userCouponId : 0
  selectedCouponInfo.value = c || null
  showCouponPicker.value = false
}

const effectiveCoupons = computed(() => {
  const base = Number(totalPrice.value)
  return usableCoupons.value.filter((c: any) => {
    if (c.type === 'fixed' || c.type === 'fixed_points') return c.value > 0 && c.value < base
    if (c.type === 'percent' || c.type === 'points_percent') return c.value < 10
    return false
  })
})

watch([selectedPlan, confirmPayMethod], () => { selectedCouponId.value = 0; selectedCouponInfo.value = null; loadCoupons() })

async function loadProducts() {
  try {
    const [prodRes, levelRes, policyRes, curRes] = await Promise.all([
      fetchMembershipProducts() as any,
      fetchGetMembershipLevelList({} as any) as any,
      request.get({ url: '/api/file-policy/list', showErrorMessage: false }).catch(() => []) as any,
      request.get({ url: '/api/currency-settings' }).catch(() => []) as any
    ])
    if (Array.isArray(curRes) && curRes.length > 0) currencySettings.value = curRes.filter((c: any) => c.currency_type !== 'quota')
    const raw = (prodRes?.data || prodRes) || []
    const levelsData = (levelRes?.data?.records || levelRes?.records || levelRes?.data || levelRes) || []
    const levels = Array.isArray(levelsData) ? levelsData : []
    allLevels.value = levels

    const policies = Array.isArray(policyRes)
      ? policyRes
      : (policyRes?.data || policyRes?.records || [])
    const policyCompressMap = new Map<number, boolean>()
    for (const p of policies) {
      if (p.status === '1') {
        policyCompressMap.set(p.id, !!(p.image_compress_enabled))
      }
    }
    const cSet = new Set<number>()
    for (const lv of levels) {
      const ids = String(lv.filePolicyIds || lv.file_policy_ids || '')
      const list = ids.split(',').map((s: string) => parseInt(s.trim())).filter((n: number) => !isNaN(n))
      const hasCompress = list.some((pid: number) => policyCompressMap.get(pid) === true)
      if (hasCompress) cSet.add(lv.id)
    }
    compressEnabledLevelIds.value = cSet

    const rMap = new Map<number, number>()
    for (const lv of levels) {
      const days = Number(lv.recycleRetentionDays || 0)
      if (days > 0) rMap.set(lv.id, days)
    }
    recycleRetentionDaysMap.value = rMap

    const enriched = (Array.isArray(raw) ? raw : []).map((p: any) => {
      const level = levels.find((l: any) => l.id === p.level_id)
      return { ...p, levelName: level?.name || '' }
    })
    products.value = enriched
    const avail = availableLevels.value
    if (avail.length > 0) selectLevel(avail[0])
  } catch { /* ignore */ }
}

async function showConfirm() {
  if (!selectedPlan.value) return
  if (!isLogin.value) { resultSuccess.value = false; resultMsg.value = '请先登录'; showResultModal.value = true; return }
  confirmPayMethod.value = 'balance'
  selectedCouponId.value = 0
  selectedCouponInfo.value = null
  showConfirmModal.value = true
  loadCoupons()
}

async function handleConfirmPay() {
  showConfirmModal.value = false
  buyLoading.value = selectedPlan.value
  try {
    const res: any = await fetchBuyMembership(selectedPlan.value, confirmPayMethod.value, selectedCouponId.value || undefined)
    await fetchMyMemberships()
    if (myMemberships.value.length) {
      const top = myMemberships.value[0]
      userStore.info.levelId = top.level_id
      userStore.info.levelName = top.level_name
      userStore.info.expireTime = top.expire_time
    }
    resultSuccess.value = true
    resultMsg.value = '恭喜您成功开通会员，立即享受专属权益'
    showResultModal.value = true
  } catch (e: any) {
    resultSuccess.value = false
    resultMsg.value = e?.message || e?.msg || e?.data?.msg || '支付失败，请重试'
    showResultModal.value = true
  } finally { buyLoading.value = 0 }
}

onMounted(() => { loadProducts(); fetchMyMemberships() })

watch(selectablePayMethods, (methods) => {
  if (methods.length > 0 && !methods.some(m => m.currency_key === confirmPayMethod.value)) {
    confirmPayMethod.value = methods[0].currency_key
  }
}, { immediate: true })
</script>

<style lang="scss" scoped>
$bg: #f7f8fa;
$text: #1a1a2e;
$text2: #505568;
$text3: #949aad;

.vip-page {
  min-height: 100vh;
  background: $bg;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif;
  -webkit-font-smoothing: antialiased;
}

// ── Topbar ──
.vip-topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 16px;
  position: sticky; top: 0; z-index: 50;
  background: #fff;
  svg { color: $text2; }
}
.vip-topbar-back { width: 22px; height: 22px; cursor: pointer; }
.vip-topbar-title { font-size: 17px; font-weight: 600; color: $text; }
.vip-topbar-right { display: flex; align-items: center; gap: 4px; font-size: 13px; color: $text2; cursor: pointer; }
.vip-topbar-icon { width: 20px; height: 20px; color: $text2; }
.vip-topbar-order { font-size: 13px; }

// ── Hero ──
.vip-hero {
  background: linear-gradient(160deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
  color: #fff;
  padding: 24px 16px 0;
  position: relative;
  overflow: hidden;
  &::after {
    content: '';
    position: absolute; top: -40px; right: -30px;
    width: 160px; height: 160px; border-radius: 50%;
    background: radial-gradient(circle, rgba(255,255,255,.04) 0%, transparent 70%);
    pointer-events: none;
  }
}
.vip-hero-user {
  display: flex; align-items: center; gap: 12px;
}
.vip-hero-avatar {
  width: 44px; height: 44px; border-radius: 50%;
  background: rgba(255,255,255,.15);
  display: flex; align-items: center; justify-content: center;
  overflow: hidden; flex-shrink: 0;
  img { width: 100%; height: 100%; object-fit: cover; }
  svg { color: rgba(255,255,255,.7); }
}
.vip-hero-name { font-size: 17px; font-weight: 500; }
.vip-hero-info { flex: 1; min-width: 0; cursor: pointer; }
.vip-hero-sub {
  font-size: 13px; opacity: .7; margin-top: 2px;
  display: flex; align-items: center; gap: 2px;
}
.vip-hero-sub-arrow { width: 12px; height: 12px; opacity: .5; }
.vip-hero-btn {
  flex-shrink: 0;
  padding: 6px 14px; border-radius: 14px;
  border: none; background: rgba(255,255,255,.2);
  color: #fff; font-size: 12px; font-weight: 600;
  cursor: pointer; white-space: nowrap;
  &:active { background: rgba(255,255,255,.35); }
}
.vip-hero-expire {
  font-size: 11px; opacity: .5; margin-top: 8px;
  padding-left: 56px;
}

// ── Hero Tab ──
.vip-hero-tabs {
  display: flex; gap: 0; margin-top: 20px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
  &::-webkit-scrollbar { display: none; }
}
.vip-hero-tab {
  flex: 0 0 auto; min-width: 72px;
  padding: 12px 14px 10px; text-align: center;
  cursor: pointer; border-radius: 12px 12px 0 0;
  transition: background .25s;
  &.active {
    background: $bg;
    box-shadow: 0 -2px 8px rgba(0,0,0,.04);
  }
}
.vip-hero-tab-name {
  display: block; font-size: 15px; font-weight: 600;
  color: rgba(255,255,255,.65);
  transition: color .25s;
  .vip-hero-tab.active & { color: $text; font-weight: 700; }
}
.vip-hero-tab-desc {
  display: block; font-size: 10px; color: rgba(255,255,255,.35);
  margin-top: 2px; transition: color .25s;
  .vip-hero-tab.active & { color: $text2; }
}
.vip-hero-tab-placeholder { flex: 1; min-width: 0; }

// ── Package Cards ──
.vip-package-scroll {
  display: flex; gap: 12px; padding: 16px 12px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
  background: $bg;
  &::-webkit-scrollbar { display: none; }
}
.vip-pkg-card {
  flex: 0 0 auto; min-width: 148px;
  border-radius: 14px; overflow: hidden;
  background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,.05);
  cursor: pointer; transition: all .25s cubic-bezier(.4,0,.2,1);
  border: 2px solid transparent;
  position: relative;
  &.active {
    border-color: #3b6df0;
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(59,109,240,.15);
  }
  &.active::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, #3b6df0, #818cf8);
  }
}
.vip-pkg-tag {
  position: absolute; top: 0; left: 12px;
  font-size: 10px; padding: 2px 8px; border-radius: 0 0 6px 6px;
  background: linear-gradient(135deg, #ef4444, #f97316);
  color: #fff; z-index: 2; font-weight: 600; letter-spacing: .5px;
}
.vip-pkg-top {
  padding: 18px 14px 12px; text-align: center;
  &.promo { background: #fffbf0; }
}
.vip-pkg-dur { font-size: 15px; font-weight: 700; color: $text; }
.vip-pkg-price { margin-top: 8px; display: flex; align-items: baseline; justify-content: center; gap: 4px; }
.vip-pkg-sym { font-size: 13px; color: #ff9838; }
.vip-pkg-val { font-size: 26px; font-weight: 800; color: #ff9838; line-height: 1; }
.vip-pkg-old { font-size: 11px; color: $text3; text-decoration: line-through; margin-left: 2px; }
.vip-pkg-bot {
  padding: 8px 12px; text-align: center; font-size: 11px; color: $text2;
  background: #fafbfc;
  &.promo { background: linear-gradient(135deg, #ff9838, #f97316); color: #fff; font-weight: 700; font-size: 12px; letter-spacing: .3px; }
}

// ── Promo Banner ──
.vip-promo-banner {
  margin: 0 12px; padding: 10px 14px;
  background: #fffbf0; border-radius: 12px;
  display: flex; align-items: center; justify-content: space-between;
  border: 1px solid #fef3c7;
}
.vip-promo-left { display: flex; align-items: center; gap: 8px; }
.vip-promo-icon { color: #f59e0b; flex-shrink: 0; }
.vip-promo-text { font-size: 12px; color: #92400e; font-weight: 500; }
.vip-promo-arrow { color: #d97706; flex-shrink: 0; }

// ── Gift Section ──
.vip-gift-section {
  margin: 16px 12px; padding: 18px 16px;
  background: #fff; border-radius: 14px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.vip-gift-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.vip-gift-title { font-size: 16px; font-weight: 700; color: $text; }
.vip-gift-sub { font-size: 12px; color: $text3; }
.vip-gift-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.vip-gift-item { display: flex; flex-direction: column; align-items: center; text-align: center; }
.vip-gift-icon {
  width: 40px; height: 40px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 8px;
  svg { flex-shrink: 0; color: #b45309; }
}
.vip-gift-name { font-size: 12px; color: $text; font-weight: 500; }
.vip-gift-val { font-size: 11px; color: #ff9838; margin-top: 2px; }

// ── Pay Section ──
.vip-pay-section {
  margin: 12px; padding: 4px 0;
  background: #fff; border-radius: 14px; overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.vip-pay-item {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 16px;
  border-bottom: 1px solid #f2f4f8;
  cursor: pointer; transition: background .2s;
  &:active, &.active { background: #f8f9ff; }
  &:last-of-type { border-bottom: none; }
}
.vip-pay-icon {
  width: 32px; height: 32px; border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 700; color: #fff; flex-shrink: 0;
}
.vip-pay-balance { background: #508DFF; }
.vip-pay-points { background: #F59E0B; }
.vip-pay-label { flex: 1; font-size: 14px; color: $text; font-weight: 500; }
.vip-pay-check, .vip-pay-uncheck { flex-shrink: 0; }
.vip-pay-uncheck { color: #d1d5db; }

// ── Privileges ──
.vip-priv-section {
  margin: 20px 12px 0;
}
.vip-priv-title {
  font-size: 18px; font-weight: 700; color: $text; margin-bottom: 14px;
}
.vip-priv-group {
  background: #fff; border-radius: 14px;
  padding: 16px; margin-bottom: 12px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.vip-priv-group-title {
  font-size: 15px; font-weight: 600; color: $text; margin-bottom: 12px;
  padding-left: 10px; border-left: 3px solid #3b6df0;
}
.vip-priv-table-wrap {
  border-radius: 10px; overflow: hidden;
  border: 1px solid #f2f4f8;
}
.vip-priv-table {
  width: 100%; border-collapse: collapse;
  font-size: 13px;
  table-layout: fixed;
}
.vip-priv-table thead tr {
  background: #fafbfd;
}
.vip-priv-table th {
  font-weight: 700; color: $text; font-size: 13px;
  padding: 12px 8px; background: #fafbfd;
}
.vip-priv-table .vip-priv-col-label {
  font-weight: 600; color: $text2; width: 30%;
  padding: 12px; text-align: center; vertical-align: middle;
}
.vip-priv-col-lvl {
  text-align: center; vertical-align: middle;
  padding: 12px 8px;
  span, svg { display: inline-block; vertical-align: middle; }
}
.vip-priv-table th.hd-highlight {
  background: #fff8e6; color: #c8974b;
}
.vip-priv-table td {
  border-top: 1px solid #f2f4f8;
  padding: 12px 8px;
}
.vip-priv-table td.vip-priv-col-label {
  color: $text2; font-weight: 500; padding: 12px; text-align: center; vertical-align: middle;
}
.vip-priv-table td.highlight {
  background: #fffbeb;
}
.vip-priv-table tr.row-alt td {
  background: #fafbfd;
}
.vip-priv-table tr.row-alt td.highlight {
  background: #fffdf5;
}
.vip-priv-table td.clickable, .vip-priv-table .vip-priv-col-label.clickable {
  cursor: pointer; color: #3b6df0; text-decoration: underline;
  &:active { opacity: .7; }
}

.vip-priv-chk { color: #22c55e; width: 16px; height: 16px; vertical-align: middle; }
.vip-priv-no { color: #e5e7eb; font-size: 16px; vertical-align: middle; }
.vip-priv-txt { color: $text; font-weight: 600; font-size: 12px; white-space: nowrap; vertical-align: middle; }

// ── Bottom Bar ──
.vip-bottom-safe { height: 90px; }
.vip-bottom-bar {
  position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 100%; max-width: 480px;
  background: rgba(255,255,255,.95);
  backdrop-filter: blur(20px);
  border-top: 1px solid #f2f4f8;
  display: flex; align-items: center; padding: 10px 16px;
  z-index: 40; gap: 12px;
}
.vip-bb-left { flex: 1; }
.vip-bb-price { font-size: 26px; font-weight: 800; color: #ff9838; line-height: 1; }
.vip-bb-discount { display: block; font-size: 11px; color: $text3; margin-top: 2px; }
.vip-bb-btn {
  padding: 12px 36px; border-radius: 24px;
  border: none; font-size: 16px; font-weight: 700; color: #fff;
  background: linear-gradient(135deg, #3b6df0, #5b8af7);
  cursor: pointer; white-space: nowrap; letter-spacing: .5px;
  box-shadow: 0 4px 14px rgba(59,109,240,.35);
  transition: all .2s;
  &:active { transform: scale(.97); box-shadow: 0 2px 8px rgba(59,109,240,.3); }
  &.disabled { opacity: .5; pointer-events: none; box-shadow: none; }
}
.vip-btn-spinner {
  display: inline-block; width: 14px; height: 14px;
  border: 2px solid rgba(255,255,255,.3);
  border-top-color: #fff; border-radius: 50%;
  animation: spin .6s linear infinite;
  margin-right: 6px;
  vertical-align: middle;
}
@keyframes spin { to { transform: rotate(360deg); } }

// ── Modals (kept from original) ──
.vip-modal-overlay {
  position: fixed; inset: 0; z-index: 1000;
  display: flex; align-items: center; justify-content: center;
  background: rgba(0,0,0,.5); backdrop-filter: blur(4px);
  padding: 24px;
}
.vip-modal {
  width: 100%; max-width: 340px; max-height: 65vh;
  background: #fff; border-radius: 18px;
  display: flex; flex-direction: column; overflow: hidden;
  box-shadow: 0 20px 60px rgba(0,0,0,.15);
}
.vip-modal-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 20px 12px; flex-shrink: 0;
  h3 { margin: 0; font-size: 18px; font-weight: 700; color: $text; }
}
.vip-modal-close {
  width: 30px; height: 30px; border-radius: 50%;
  background: #f2f4f8; border: none;
  display: flex; align-items: center; justify-content: center;
  color: #999; cursor: pointer; transition: background .2s;
  &:active { background: #e5e7eb; }
}
.vip-modal-body { padding: 0 20px 20px; overflow-y: auto; }
.vip-m-item {
  display: flex; align-items: center; gap: 12px; padding: 14px 0;
  & + & { border-top: 1px solid #f2f4f8; }
}
.vip-m-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.vip-m-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.vip-m-name { font-size: 15px; font-weight: 600; color: $text; }
.vip-m-meta { font-size: 12px; color: $text3; }
.vip-m-top-badge {
  font-size: 10px; padding: 3px 8px; border-radius: 8px;
  background: #eef3ff; color: #3b6df0; font-weight: 600; flex-shrink: 0;
}

// ── Sheet / Toast (kept from original) ──
.vip-overlay {
  position: fixed; inset: 0; z-index: 900;
  background: rgba(0,0,0,.4);
  display: flex; align-items: flex-end; justify-content: center;
  &.center { align-items: center; }
}
.vip-sheet {
  width: 100%; max-width: 480px;
  background: #fff; border-radius: 20px 20px 0 0;
  display: flex; flex-direction: column; max-height: 80vh;
}
.vip-sheet-bar {
  width: 36px; height: 4px; border-radius: 2px;
  background: #d9dde3; margin: 10px auto 0;
}
.vip-sheet-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 20px; flex-shrink: 0;
}
.vip-sheet-title { font-size: 17px; font-weight: 700; color: $text; }
.vip-sheet-close { cursor: pointer; color: $text3; }
.vip-sheet-body { padding: 0 20px 20px; overflow-y: auto; }
.vip-sheet-prod {
  display: flex; align-items: center; gap: 12px;
  padding: 14px; background: #f7f8fa; border-radius: 14px; margin-bottom: 16px;
}
.vip-sheet-prod-icon {
  width: 40px; height: 40px; border-radius: 12px;
  background: linear-gradient(135deg, #fde68a, #fcd34d);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  svg { color: #92400e; }
}
.vip-sheet-prod-info { flex: 1; min-width: 0; }
.vip-sheet-prod-name { font-size: 15px; font-weight: 600; color: $text; }
.vip-sheet-prod-sub { font-size: 12px; color: $text3; }
.vip-sheet-prod-price { font-size: 18px; font-weight: 800; color: #ff9838; flex-shrink: 0; }
.vip-sheet-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 0; border-top: 1px solid #f2f4f8;
}
.vip-sr-label { font-size: 14px; color: $text2; }
.vip-sr-pays { display: flex; gap: 8px; }
.vip-sr-pay {
  font-size: 12px; padding: 6px 14px; border-radius: 18px;
  background: #f2f4f8; color: $text2; cursor: pointer;
  &.active { background: #3b6df0; color: #fff; }
}
.vip-cp-trigger {
  display: flex; align-items: center; gap: 6px; cursor: pointer;
  font-size: 13px;
}
.vip-cp-selected { color: #ff9838; }
.vip-cp-placeholder { color: $text3; }
.vip-cp-arrow {
  transition: transform .2s;
  &.open { transform: rotate(180deg); }
}
.vip-cp-dropdown {
  max-height: 180px; overflow-y: auto;
  border: 1px solid #f2f4f8; border-radius: 12px;
}
.vip-cp-opt {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 14px; cursor: pointer; font-size: 13px; color: $text;
  & + & { border-top: 1px solid #f2f4f8; }
  &.active { background: #eef3ff; color: #3b6df0; }
}
.vip-cp-val { font-size: 12px; color: #ff9838; font-weight: 600; }
.vip-sheet-total {
  padding: 14px 0 0; border-top: 1px solid #f2f4f8;
  display: flex; flex-direction: column; gap: 6px;
}
.vip-st-row {
  display: flex; align-items: center; justify-content: space-between;
  font-size: 14px; color: $text2;
  &.sub { font-size: 12px; color: $text3; }
}
.vip-st-red { font-size: 20px; font-weight: 800; color: #ff9838; }
.vip-cp-saved { color: #22c55e; font-weight: 600; }
.vip-sheet-pay-btn {
  margin: 16px 20px 24px; padding: 14px;
  border-radius: 14px; border: none; font-size: 16px; font-weight: 700; color: #fff;
  background: linear-gradient(135deg, #ffb050, #ff9030);
  cursor: pointer;
  &:active { transform: scale(.97); }
  &:disabled { opacity: .5; }
}

.vip-toast {
  width: 280px; padding: 30px 24px;
  background: #fff; border-radius: 18px;
  display: flex; flex-direction: column; align-items: center; text-align: center;
  box-shadow: 0 20px 60px rgba(0,0,0,.18);
}
.vip-toast-icon {
  width: 56px; height: 56px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center; margin-bottom: 16px;
  &.ok { background: #ecfdf5; color: #22c55e; }
  &.fail { background: #fef2f2; color: #ef4444; }
}
.vip-toast-title { font-size: 17px; font-weight: 700; color: $text; margin-bottom: 6px; }
.vip-toast-msg { font-size: 13px; color: $text2; margin-bottom: 20px; }
.vip-toast-btn {
  width: 100%; padding: 12px; border-radius: 12px;
  border: none; font-size: 15px; font-weight: 600;
  background: #3b6df0; color: #fff; cursor: pointer;
  transition: background .2s;
  &:active { background: #2b5cd6; }
}
</style>
