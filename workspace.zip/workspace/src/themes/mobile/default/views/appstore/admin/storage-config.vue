<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" @click="$router.back()" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">对象存储</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg text-white text-sm shadow-lg" :class="toastType==='success'?'bg-[#4ECDC4]':'bg-[#FF4757]'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div v-if="list.length === 0 && !loading" class="text-center py-8 text-gray-400 text-sm">暂无存储配置，点击下方按钮添加</div>
        <div v-for="item in list" :key="item.id" class="flex items-center gap-3 py-3 border-b border-gray-100 last:border-0">
          <div class="w-10 h-10 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0" :style="{ background: typeColor(item.type) }">
            {{ typeLabel(item.type).slice(0, 1) }}
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <span class="text-sm font-medium text-gray-800 truncate">{{ item.name }}</span>
              <span v-if="item.is_default" class="text-[10px] bg-[#4ECDC4] text-white px-1.5 py-0.5 rounded">默认</span>
            </div>
            <div class="text-xs text-gray-400 mt-0.5">{{ typeLabel(item.type) }} · {{ item.bucket || item.local_dir || '-' }}</div>
            <div v-if="item.applicable_roles || item.applicable_levels" class="text-[10px] text-[#FF4757] mt-0.5">
              <span v-if="item.applicable_roles">{{ audienceRolesLabel(item.applicable_roles) }}</span>
              <span v-if="item.applicable_levels">{{ audienceLevelsLabel(item.applicable_levels) }}</span>
            </div>
          </div>
          <div class="flex gap-1 flex-shrink-0">
            <button @click="testConnection(item)" class="w-8 h-8 rounded-lg bg-green-50 text-green-500 flex items-center justify-center text-xs" :title="'测试连接'">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            </button>
            <button v-auth="'edit'" @click="editItem(item)" class="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button v-auth="'delete'" @click="deleteItem(item)" class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </div>
      </div>

      <div class="px-3 mt-4">
        <button v-auth="'add'" @click="openAdd" class="w-full py-3 rounded-xl bg-[#FF4757] text-white font-medium text-sm flex items-center justify-center gap-2 active:opacity-80">
          <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          添加存储配置
        </button>
      </div>

      <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closeDialog">
        <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col" @click.stop>
          <div class="px-5 py-4 flex items-center justify-between border-b border-gray-100 flex-shrink-0">
            <span class="text-base font-bold text-gray-800">{{ editingId ? '编辑存储配置' : '添加存储配置' }}</span>
            <button @click="closeDialog" class="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center">
              <svg class="w-4 h-4 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <div class="flex-1 overflow-y-auto px-5 py-4 space-y-3">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">配置名称 <span class="text-red-500">*</span></label>
              <input v-model="form.name" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：腾讯云COS生产环境" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">存储类型 <span class="text-red-500">*</span></label>
              <select v-model="form.type" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none bg-white">
                <option v-for="t in types" :key="t.value" :value="t.value">{{ t.label }}</option>
              </select>
            </div>
            <div v-if="form.type === 'local'">
              <label class="text-xs text-gray-500 mb-1 block">本地目录</label>
              <input v-model="form.local_dir" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：uploads" />
            </div>
            <template v-if="form.type !== 'local'">
              <div>
                <label class="text-xs text-gray-500 mb-1 block">Endpoint / 服务端点</label>
                <input v-model="form.endpoint" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" :placeholder="form.type==='cos'?'https://cos.ap-guangzhou.myqcloud.com':form.type==='oss'?'https://oss-cn-hangzhou.aliyuncs.com':'https://play.min.io'" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">Region / 地区</label>
                <input v-model="form.region" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：ap-guangzhou" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">Bucket / 存储桶</label>
                <input v-model="form.bucket" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：my-bucket-1234567890" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">Access Key / SecretId</label>
                <input v-model="form.access_key" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="请输入 Access Key" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">Secret Key / SecretKey</label>
                <input v-model="form.secret_key" type="password" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="请输入 Secret Key" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">远程目录</label>
                <input v-model="form.remote_dir" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：uploads/images" />
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">文件有效期(秒) <span class="text-gray-300">0=不限制</span></label>
                <div class="flex items-center gap-2">
                  <input v-model.number="form.expiry_seconds" type="number" min="0" step="60" class="flex-1 px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：3600 (1小时)" />
                  <select v-model="form.expiry_seconds" class="w-24 px-2 py-2.5 text-sm border border-gray-200 rounded-lg bg-white" @change="(e: any) => form.expiry_seconds = Number(e.target.value)">
                    <option :value="0">不限制</option>
                    <option :value="300">5分钟</option>
                    <option :value="600">10分钟</option>
                    <option :value="1800">30分钟</option>
                    <option :value="3600">1小时</option>
                    <option :value="7200">2小时</option>
                    <option :value="21600">6小时</option>
                    <option :value="43200">12小时</option>
                    <option :value="86400">24小时</option>
                  </select>
                </div>
                <div class="text-[10px] text-gray-400 mt-1 leading-tight">非图片文件(APK、文档等)下载时自动生成带有效期的签名URL，过期后需重新获取。0表示直接返回原始URL不签名。</div>
              </div>
              <div>
                <label class="text-xs text-gray-500 mb-1 block">自定义域名 / CDN 地址</label>
                <input v-model="form.base_url" class="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:border-[#FF4757] focus:outline-none" placeholder="例如：https://cdn.example.com" />
              </div>
            </template>
            <div class="flex items-center gap-2 py-1">
              <label class="text-xs text-gray-500">设为默认存储</label>
              <input type="checkbox" v-model="form.is_default" class="w-4 h-4 accent-[#FF4757]" />
            </div>

            <div class="border-t border-gray-100 pt-3">
              <label class="text-xs text-gray-500 mb-2 block">适用后台</label>
              <div class="flex flex-wrap gap-2">
                <label class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs cursor-pointer select-none"
                  :class="form.for_backend ? 'border-[#FF4757] bg-red-50 text-[#FF4757]' : 'border-gray-200 text-gray-600'">
                  <input type="checkbox" v-model="form.for_backend" @change="onBackendToggle" class="sr-only" />
                  适用后台
                </label>
              </div>
            </div>

            <div class="border-t border-gray-100 pt-3" v-if="!form.for_backend">
              <label class="text-xs text-gray-500 mb-2 block">适用角色 <span class="text-gray-300">(多选)</span></label>
              <div class="flex flex-wrap gap-2">
                <label class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs cursor-pointer select-none"
                  :class="form.applicable_roles.includes('all') ? 'border-[#FF4757] bg-red-50 text-[#FF4757]' : 'border-gray-200 text-gray-600'">
                  <input type="checkbox" value="all" v-model="form.applicable_roles" @change="onAllRolesToggle" class="sr-only" />
                  所有角色
                </label>
                <label v-for="r in audienceRoles" :key="r.value" class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs cursor-pointer select-none"
                  :class="form.applicable_roles.includes(r.value) ? 'border-[#FF4757] bg-red-50 text-[#FF4757]' : 'border-gray-200 text-gray-600'">
                  <input type="checkbox" :value="r.value" v-model="form.applicable_roles" @change="onSpecificRoleToggle" class="sr-only" />
                  {{ r.label }}
                </label>
              </div>
            </div>

            <div class="border-t border-gray-100 pt-3" v-if="!form.for_backend">
              <label class="text-xs text-gray-500 mb-2 block">适用会员 <span class="text-gray-300">(多选)</span></label>
              <div class="flex flex-wrap gap-2">
                <label class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs cursor-pointer select-none"
                  :class="form.applicable_levels.includes('all') ? 'border-[#FF4757] bg-red-50 text-[#FF4757]' : 'border-gray-200 text-gray-600'">
                  <input type="checkbox" value="all" v-model="form.applicable_levels" @change="onAllLevelsToggle" class="sr-only" />
                  所有会员
                </label>
                <label v-for="l in audienceLevels" :key="l.value" class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs cursor-pointer select-none"
                  :class="form.applicable_levels.includes(l.value) ? 'border-[#FF4757] bg-red-50 text-[#FF4757]' : 'border-gray-200 text-gray-600'">
                  <input type="checkbox" :value="l.value" v-model="form.applicable_levels" @change="onSpecificLevelToggle" class="sr-only" />
                  {{ l.label }}
                </label>
              </div>
            </div>

            <div class="flex items-center gap-2 py-1" v-if="editingId">
              <label class="text-xs text-gray-500">启用</label>
              <input type="checkbox" v-model="form.status" :true-value="'1'" :false-value="'0'" class="w-4 h-4 accent-[#FF4757]" />
            </div>
          </div>
          <div class="px-5 py-4 border-t border-gray-100 flex gap-3 flex-shrink-0">
            <button v-if="editingId" @click="setDefault" class="flex-1 py-2.5 rounded-xl border border-[#4ECDC4] text-[#4ECDC4] font-medium text-sm">设为默认</button>
            <button v-auth="'edit'" @click="save" class="flex-1 py-2.5 rounded-xl bg-[#FF4757] text-white font-medium text-sm">{{ editingId ? '保存' : '创建' }}</button>
          </div>
        </div>
      </div>

      <!-- 删除确认弹窗 -->
      <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="confirmVisible = false">
        <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
          <div class="p-5 text-center">
            <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
              <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
            <div class="text-xs text-gray-400">确定要删除「{{ confirmTarget?.name }}」吗？此操作不可恢复。</div>
          </div>
          <div class="flex border-t border-gray-100">
            <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
            <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">确定删除</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const types = ref<{ value: string; label: string }[]>([])
const audienceRoles = ref<{ value: string; label: string }[]>([])
const audienceLevels = ref<{ value: string; label: string }[]>([])
const loading = ref(false)
const dialogVisible = ref(false)
const editingId = ref<number | null>(null)
const toastMsg = ref('')
const toastType = ref('success')

const defaultForm = () => ({
  name: '', type: 'cos', endpoint: '', region: '', bucket: '',
  access_key: '', secret_key: '', local_dir: '', remote_dir: '', expiry_seconds: 0, base_url: '',
  is_default: false, status: '1',
  for_backend: false,
  applicable_roles: [] as string[],
  applicable_levels: [] as string[]
})
const form = ref(defaultForm())

function typeLabel(type: string) {
  const map: Record<string, string> = { local: '本地存储', cos: '腾讯云COS', oss: '阿里云OSS', minio: 'MinIO', s3: 'AWS S3', qiniu: '七牛云Kodo', huawei: '华为云OBS' }
  return map[type] || type
}

function typeColor(type: string) {
  const map: Record<string, string> = { local: '#607D8B', cos: '#1E88E5', oss: '#FF6F00', minio: '#C62828', s3: '#F90', qiniu: '#00B96B', huawei: '#CF0A2C' }
  return map[type] || '#607D8B'
}

function audienceRolesLabel(val: string) {
  if (!val) return ''
  const codes = val.split(',')
  return '角色: ' + codes.map(c => {
    if (c === 'all') return '所有角色'
    const found = audienceRoles.value.find((r: any) => r.value === c)
    return found ? found.label : c
  }).join('、')
}

function audienceLevelsLabel(val: string) {
  if (!val) return ''
  const codes = val.split(',')
  return ' · 会员: ' + codes.map(c => {
    if (c === 'all') return '所有会员'
    const found = audienceLevels.value.find((l: any) => l.value === c)
    return found ? found.label : c
  }).join('、')
}

function onBackendToggle() {
  if (form.value.for_backend) {
    form.value.applicable_roles = []
    form.value.applicable_levels = []
  }
}

function onAllRolesToggle() {
  if (form.value.applicable_roles.includes('all')) {
    form.value.applicable_roles = ['all']
  }
}

function onAllLevelsToggle() {
  if (form.value.applicable_levels.includes('all')) {
    form.value.applicable_levels = ['all']
  }
}

function onSpecificRoleToggle() {
  form.value.applicable_roles = form.value.applicable_roles.filter(r => r !== 'all')
}

function onSpecificLevelToggle() {
  form.value.applicable_levels = form.value.applicable_levels.filter(l => l !== 'all')
}

function showToast(msg: string, type: string) {
  toastMsg.value = msg; toastType.value = type
  setTimeout(() => toastMsg.value = '', 2000)
}

async function fetchAudiences() {
  try {
    const data = await request.get<{ roles: any[]; levels: any[] }>({ url: '/api/storage-config/audiences' })
    audienceRoles.value = data?.roles || []
    audienceLevels.value = data?.levels || []
  } catch {}
}

async function fetchTypes() {
  try {
    const data = await request.get<any[]>({ url: '/api/storage-config/types' })
    types.value = data || []
  } catch {}
}

async function fetchList() {
  loading.value = true
  try {
    const data = await request.get<any[]>({ url: '/api/storage-config/list' })
    list.value = data || []
  } catch (e: any) { showToast('加载失败: ' + (e.message || e), 'error') }
  finally { loading.value = false }
}

function openAdd() {
  editingId.value = null
  form.value = defaultForm()
  dialogVisible.value = true
}

function editItem(item: any) {
  editingId.value = item.id
  const levelStr = item.applicable_levels || ''
  const isBackend = levelStr === 'backend'
  form.value = {
    name: item.name, type: item.type, endpoint: item.endpoint || '', region: item.region || '',
    bucket: item.bucket || '', access_key: item.access_key || '', secret_key: item.secret_key || '',
    local_dir: item.local_dir || '', remote_dir: item.remote_dir || '', expiry_seconds: Number(item.expiry_seconds) || 0, base_url: item.base_url || '',
    is_default: !!item.is_default, status: item.status || '1',
    for_backend: isBackend,
    applicable_roles: item.applicable_roles ? item.applicable_roles.split(',').filter(Boolean) : [],
    applicable_levels: isBackend ? [] : levelStr.split(',').filter(Boolean)
  }
  dialogVisible.value = true
}

function closeDialog() {
  dialogVisible.value = false
}

async function save() {
  if (!form.value.name || !form.value.type) { showToast('名称和类型不能为空', 'error'); return }
  try {
    const payload: any = {
      ...form.value,
      applicable_roles: form.value.applicable_roles.join(','),
      applicable_levels: form.value.for_backend ? 'backend' : form.value.applicable_levels.join(',')
    }
    delete payload.for_backend
    if (editingId.value) {
      await request.put({ url: `/api/storage-config/${editingId.value}`, data: payload })
      showToast('更新成功', 'success')
    } else {
      await request.post({ url: '/api/storage-config', data: payload })
      showToast('创建成功', 'success')
    }
    closeDialog()
    fetchList()
  } catch (e: any) { showToast('操作失败: ' + (e.message || e), 'error') }
}

async function testConnection(item: any) {
  try {
    showToast('正在测试连接...', 'success')
    const res = await request.post<any>({ url: '/api/storage-config/test', data: { id: item.id } })
    showToast((res as any)?.message || '连接成功', (res as any)?.code === 200 ? 'success' : 'error')
  } catch (e: any) { showToast('测试失败: ' + (e.message || e), 'error') }
}

async function setDefault() {
  if (!editingId.value) return
  try {
    await request.put({ url: `/api/storage-config/${editingId.value}/default` })
    showToast('已设为默认', 'success')
    closeDialog()
    fetchList()
  } catch (e: any) { showToast('操作失败: ' + (e.message || e), 'error') }
}

const confirmVisible = ref(false)
const confirmTarget = ref<any>(null)

async function deleteItem(item: any) {
  confirmTarget.value = item
  confirmVisible.value = true
}

async function doDelete() {
  if (!confirmTarget.value) return
  try {
    await request.del({ url: `/api/storage-config/${confirmTarget.value.id}` })
    showToast('删除成功', 'success')
    confirmVisible.value = false
    fetchList()
  } catch (e: any) { showToast('删除失败: ' + (e.message || e), 'error') }
}

onMounted(() => { fetchTypes(); fetchAudiences(); fetchList() })
</script>
