<template>
  <el-dialog
    v-model="visible"
    :title="isEdit ? '编辑应用' : '添加应用'"
    width="640px"
    destroy-on-close
    @closed="handleClosed"
  >
    <el-form ref="formRef" :model="form" label-width="100px" :rules="rules">
      <el-form-item label="上传账号" prop="userId">
        <el-select v-model="form.userId" filterable placeholder="请选择上传账号" class="!w-full">
          <el-option v-for="u in userOptions" :key="u.id" :label="u.userName + ' (ID:' + u.id + ')'" :value="u.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="应用名称" prop="name">
        <el-input v-model="form.name" placeholder="如：神奇影视" />
      </el-form-item>
      <el-form-item label="包名" prop="packageName">
        <el-input v-model="form.packageName" placeholder="如：com.example.app" />
      </el-form-item>
      <el-form-item label="版本号" prop="version">
        <el-input v-model="form.version" placeholder="如：1.3.0" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="版本代码" prop="versionCode">
        <el-input v-model="form.versionCode" placeholder="如：130" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="应用大小(MB)" prop="sizeMb">
        <el-input-number v-model="form.sizeMb" :min="0" :precision="1" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="图标颜色" prop="iconBgColor">
        <el-color-picker v-model="form.iconBgColor" />
      </el-form-item>
      <el-form-item label="评分" prop="rating">
        <el-input-number v-model="form.rating" :min="0" :max="5" :precision="1" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="投币数" prop="coinCount">
        <el-input-number v-model="form.coinCount" :min="0" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="投币人数" prop="coinPeople">
        <el-input-number v-model="form.coinPeople" :min="0" class="!w-[200px]" />
      </el-form-item>
      <el-form-item label="标签">
          <el-select v-model="form.tags" multiple allow-create filterable placeholder="输入标签后回车" class="!w-full">
            <el-option label="星选" value="星选" />
            <el-option label="官方版" value="官方版" />
            <el-option label="视频播放" value="视频播放" />
            <el-option label="64Bit" value="64Bit" />
          </el-select>
        </el-form-item>
        <el-form-item label="官方标签">
          <el-select v-model="form.officialTags" multiple placeholder="选择官方标签" value-key="id" class="!w-full">
            <el-option v-for="ot in officialTagList" :key="ot.id" :label="ot.name" :value="{ id: ot.id, name: ot.name, color: ot.color, bgColor: ot.bgColor }">
              <span class="inline-block px-2 py-0.5 rounded-full text-xs font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="应用标志">
          <div class="flex flex-wrap gap-x-6 gap-y-2">
            <div class="flex items-center gap-2">
              <el-switch v-model="form.hasAds" size="small" />
              <span class="text-sm text-gray-600">是否有广告</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="form.requiresNetwork" size="small" />
              <span class="text-sm text-gray-600">是否需要联网</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="form.hasPaidContent" size="small" />
              <span class="text-sm text-gray-600">是否包含付费内容</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="form.isFree" size="small" />
              <span class="text-sm text-gray-600">是否免费应用</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item label="收费方式">
          <el-radio-group v-model="form.price_type">
            <el-radio value="free">免费</el-radio>
            <el-radio value="balance">余额</el-radio>
            <el-radio value="points">积分</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="价格" v-if="form.price_type === 'balance' || form.price_type === 'points'">
          <el-input-number v-model="form.price_amount" :min="0" :precision="2" class="!w-[200px]" />
          <span class="ml-2 text-sm text-gray-400">{{ form.price_type === 'balance' ? '元' : '积分' }}</span>
        </el-form-item>
      <el-form-item label="下载链接" prop="downloadUrl">
        <el-input v-model="form.downloadUrl" placeholder="如：https://example.com/app.apk" />
      </el-form-item>
      <el-form-item label="应用介绍" prop="description">
        <el-input v-model="form.description" type="textarea" :rows="3" placeholder="应用介绍文字" />
      </el-form-item>
      <el-form-item label="更新内容" prop="updateContent">
        <el-input v-model="form.updateContent" type="textarea" :rows="2" placeholder="更新内容" />
      </el-form-item>
      <el-form-item label="截图配置">
        <div class="w-full">
          <div v-for="(item, idx) in form.screenshots" :key="item" class="flex gap-2 mb-2 items-center">
            <el-color-picker v-model="item.bgColor" size="small" />
            <el-input v-model="item.text" placeholder="截图宣传语" class="!w-[200px]" size="small" />
            <el-button link type="danger" size="small" @click="removeScreenshot(idx)">删除</el-button>
          </div>
          <el-button size="small" @click="addScreenshot">+ 添加截图</el-button>
        </div>
      </el-form-item>
      <el-form-item label="应用分类">
        <el-select v-model="form.selectedCategoryIds" multiple placeholder="请选择分类" class="!w-full">
          <el-option v-for="c in categoryOptions" :key="c.id" :label="c.name" :value="c.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <el-switch v-model="form.status" active-value="1" inactive-value="0" />
        <span class="ml-2 text-gray-400 text-xs">{{ form.status === '1' ? '上架' : '下架' }}</span>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="handleSubmit" :loading="submitting">确定</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { fetchCategoryList, fetchOfficialTags } from '@/api/appstore'
import request from '@/utils/http'

const props = defineProps<{
  visible: boolean
  editData?: any
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  submit: [data: any]
}>()

const visible = ref(false)
watch(() => props.visible, (v) => { visible.value = v })
watch(visible, (v) => { emit('update:visible', v) })

const formRef = ref()
const submitting = ref(false)
const isEdit = ref(false)
const categoryOptions = ref<Array<{ id: number; name: string }>>([])
const userOptions = ref<Array<{ id: number; userName: string }>>([])
const officialTagList = ref<any[]>([])

const form = reactive({
  id: 0,
  userId: 0,
  name: '',
  packageName: '',
  version: '1.0.0',
  versionCode: '100',
  icon: '',
  iconBgColor: '#00BFA5',
  sizeMb: 0,
  rating: 0,
  description: '',
  updateContent: '',
  screenshots: [] as Array<{ image: string; text: string; bgColor: string }>,
  tags: [] as string[],
  officialTags: [] as any[],
  hasAds: false,
  requiresNetwork: true,
  hasPaidContent: false,
  isFree: true,
  price_type: 'free',
  price_amount: 0,
  downloadUrl: '',
  coinCount: 0,
  coinPeople: 0,
  developer: '',
  category: '工具',
  selectedCategoryIds: [] as number[],
  status: '1'
})

const rules = {
  userId: [{ required: true, message: '请选择上传账号', trigger: 'change' }],
  name: [{ required: true, message: '请输入应用名称', trigger: 'blur' }],
  packageName: [{ required: true, message: '请输入包名', trigger: 'blur' }]
}

watch(() => props.visible, (v) => {
  if (v && props.editData) {
    isEdit.value = true
    const d = props.editData
    form.id = d.id || 0
    form.userId = d.userId || d.user_id || 0
    form.name = d.name || ''
    form.packageName = d.packageName || ''
    form.version = d.version || '1.0.0'
    form.versionCode = d.versionCode || '100'
    form.icon = d.icon || ''
    form.iconBgColor = d.iconBgColor || '#00BFA5'
    form.sizeMb = d.sizeMb || 0
    form.rating = d.rating || 0
    form.description = d.description || ''
    form.updateContent = d.updateContent || ''
    form.screenshots = d.screenshots && d.screenshots.length > 0 ? [...d.screenshots] : []
    form.tags = d.tags ? [...d.tags] : []
    form.officialTags = d.officialTags ? (Array.isArray(d.officialTags) ? [...d.officialTags] : []) : []
    form.hasAds = !!d.hasAds
    form.requiresNetwork = d.requiresNetwork !== undefined ? !!d.requiresNetwork : true
    form.hasPaidContent = !!d.hasPaidContent
    form.isFree = d.isFree !== undefined ? !!d.isFree : true
    form.price_type = d.priceType || 'free'
    form.price_amount = Number(d.priceAmount) || 0
    form.downloadUrl = d.downloadUrl || ''
    form.coinCount = d.coinCount || 0
    form.coinPeople = d.coinPeople || 0
    form.developer = d.developer || ''
    form.category = d.category || '工具'
    form.selectedCategoryIds = d.categories ? d.categories.split(',').map(Number).filter(Boolean) : (d.categoryId ? [Number(d.categoryId)] : [])
    form.status = d.status || '1'
  } else if (v) {
    isEdit.value = false
    form.id = 0
    form.userId = 0
    form.name = ''
    form.packageName = ''
    form.version = '1.0.0'
    form.versionCode = '100'
    form.icon = ''
    form.iconBgColor = '#00BFA5'
    form.sizeMb = 0
    form.rating = 0
    form.description = ''
    form.updateContent = ''
    form.screenshots = []
    form.tags = []
    form.officialTags = []
    form.hasAds = false
    form.requiresNetwork = true
    form.hasPaidContent = false
    form.isFree = true
    form.price_type = 'free'
    form.price_amount = 0
    form.downloadUrl = ''
    form.coinCount = 0
    form.coinPeople = 0
    form.developer = ''
    form.category = '工具'
    form.selectedCategoryIds = []
    form.status = '1'
  }
})

const addScreenshot = () => {
  form.screenshots.push({ image: '', text: '', bgColor: '#00BFA5' })
}

const removeScreenshot = (idx: number) => {
  form.screenshots.splice(idx, 1)
}

const handleClosed = () => {
  formRef.value?.resetFields()
  isEdit.value = false
}

const handleSubmit = async () => {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
    submitting.value = true
    emit('submit', {
      id: form.id || undefined,
      userId: form.userId,
      name: form.name,
      packageName: form.packageName,
      version: form.version,
      versionCode: form.versionCode,
      icon: form.icon,
      iconBgColor: form.iconBgColor,
      sizeMb: form.sizeMb,
      rating: form.rating,
      description: form.description,
      updateContent: form.updateContent,
      screenshots: form.screenshots,
      tags: form.tags,
      officialTags: form.officialTags,
      hasAds: form.hasAds,
      requiresNetwork: form.requiresNetwork,
      hasPaidContent: form.hasPaidContent,
      isFree: form.isFree,
      price_type: form.price_type,
      price_amount: form.price_amount,
      downloadUrl: form.downloadUrl,
      coinCount: form.coinCount,
      coinPeople: form.coinPeople,
      developer: form.developer,
      category: form.category,
      categoryId: form.selectedCategoryIds.length > 0 ? form.selectedCategoryIds[0] : 0,
      categories: form.selectedCategoryIds.join(','),
      status: form.status
    })
  } catch {
    ElMessage.warning('请填写必填项（上传账号、应用名称、包名）')
  } finally {
    submitting.value = false
  }
}

const loadUsers = async () => {
  try {
    const data: any = await request.get({ url: '/api/user/list', params: { size: 999 } })
    userOptions.value = (data?.records || []).map((u: any) => ({ id: u.id, userName: u.userName || u.username }))
  } catch {}
}

const loadOfficialTags = async () => {
  try {
    const data: any = await fetchOfficialTags()
    officialTagList.value = (data || []).filter((t: any) => t.status === '1')
  } catch {}
}

onMounted(async () => {
  try {
    const data: any = await fetchCategoryList()
    categoryOptions.value = data || []
  } catch {}
  loadUsers()
  loadOfficialTags()
})
</script>
