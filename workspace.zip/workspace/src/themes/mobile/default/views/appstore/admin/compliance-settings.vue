<template>
  <div class="min-h-screen flex flex-col bg-[#f0f2f5]">
    <!-- 顶部导航 -->
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-500 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-semibold text-gray-800 flex-1 text-center mr-5 tracking-wide">合规设置</span>
    </div>

    <!-- Toast -->
    <transition name="toast">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2.5 rounded-xl shadow-lg backdrop-blur-sm" :class="toastType === 'error' ? 'bg-red-500/90 text-white' : 'bg-gray-800/90 text-white'">{{ toastMsg }}</div>
    </transition>

    <!-- Tab 栏 -->
    <div class="bg-white border-b border-gray-100 sticky top-[52px] z-10">
      <div class="flex px-1">
        <button
          v-for="tab in tabs"
          :key="tab.key"
          class="relative flex-1 py-3.5 text-sm font-medium transition-colors"
          :class="activeTab === tab.key ? 'text-[#FF4757]' : 'text-gray-400 hover:text-gray-600'"
          @click="activeTab = tab.key"
        >
          <span class="inline-flex items-center gap-1.5">
            <svg v-if="tab.icon" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="tab.icon"/></svg>
            {{ tab.label }}
          </span>
          <div v-if="activeTab === tab.key" class="absolute bottom-0 left-1/4 right-1/4 h-0.5 rounded-full bg-[#FF4757]" />
        </button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-24">
      <div v-if="loading" class="flex flex-col items-center justify-center py-20 gap-3">
        <div class="w-8 h-8 border-2 border-[#FF4757] border-t-transparent rounded-full animate-spin" />
        <span class="text-xs text-gray-400">加载中...</span>
      </div>

      <template v-else>
        <!-- Cookie 同意设置 -->
        <div v-if="activeTab === 'cookie'" class="p-4 space-y-4 animate-fade-in">
          <div class="bg-white rounded-3xl overflow-hidden shadow-sm">
            <div class="bg-gradient-to-r from-[#FF4757] to-[#FF6B81] px-5 py-4">
              <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                  <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                </div>
                <div>
                  <div class="text-white text-sm font-semibold">Cookie 同意弹窗</div>
                  <div class="text-white/70 text-xs">用户首次访问时显示的 Cookie 声明</div>
                </div>
              </div>
            </div>

            <div class="p-5 space-y-4">
              <div class="flex items-center justify-between py-1.5">
                <span class="text-sm text-gray-700">启用弹窗</span>
                <button
                  class="w-11 h-6 rounded-full transition-all duration-300 relative"
                  :class="cookie.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'"
                  @click="cookie.enabled = !cookie.enabled"
                >
                  <span class="w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-all duration-300" :class="cookie.enabled ? 'left-5' : 'left-0.5'" />
                </button>
              </div>

              <div class="h-px bg-gray-50" />

              <div class="space-y-3.5">
                <div class="field-group">
                  <label class="field-label">弹窗标题</label>
                  <input v-model="cookie.title" class="field-input" placeholder="Cookie 声明" />
                </div>
                <div class="field-group">
                  <label class="field-label">弹窗内容</label>
                  <textarea v-model="cookie.content" rows="3" class="field-input resize-none" placeholder="本站使用 Cookie 来改善您的浏览体验、分析网站流量并提供个性化内容..." />
                </div>
                <div class="grid grid-cols-2 gap-3">
                  <div class="field-group">
                    <label class="field-label">同意按钮文字</label>
                    <input v-model="cookie.agreeText" class="field-input" placeholder="同意全部" />
                  </div>
                  <div class="field-group">
                    <label class="field-label">拒绝按钮文字</label>
                    <input v-model="cookie.declineText" class="field-input" placeholder="仅必要" />
                  </div>
                </div>
              </div>

              <button class="btn-primary w-full mt-2" @click="saveCookie" :disabled="savingCookie">
                <svg v-if="!savingCookie" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <div v-else class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>{{ savingCookie ? '保存中...' : '保存 Cookie 设置' }}</span>
              </button>
            </div>
          </div>

          <!-- 预览卡片 -->
          <div v-if="cookie.enabled" class="bg-white rounded-3xl overflow-hidden shadow-sm">
            <div class="px-5 py-3 border-b border-gray-50 flex items-center gap-2">
              <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
              <span class="text-xs font-medium text-gray-400 uppercase tracking-wider">预览</span>
            </div>
            <div class="p-5">
              <div class="rounded-xl bg-[#f8f9fb] p-4 border border-gray-100">
                <div class="text-sm font-semibold text-gray-800 mb-2">{{ cookie.title || 'Cookie 声明' }}</div>
                <div class="text-xs text-gray-500 leading-relaxed mb-4">{{ cookie.content || '本站使用 Cookie 来改善您的浏览体验...' }}</div>
                <div class="flex gap-2">
                  <span class="flex-1 text-center py-2 rounded-full bg-[#FF4757] text-white text-xs font-medium">{{ cookie.agreeText || '同意全部' }}</span>
                  <span class="flex-1 text-center py-2 rounded-full bg-gray-100 text-gray-500 text-xs font-medium">{{ cookie.declineText || '仅必要' }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 隐私政策 / 用户协议 -->
        <div v-if="activeTab === 'privacy' || activeTab === 'agreement'" class="animate-fade-in">
          <PolicyManager :type="activeTab" :title="activeTab === 'privacy' ? '隐私政策' : '用户协议'" />
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const tabs = [
  { key: 'cookie', label: 'Cookie 同意', icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z' },
  { key: 'privacy', label: '隐私政策', icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
  { key: 'agreement', label: '用户协议', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' }
]
const activeTab = ref('cookie')
const loading = ref(true)
const toastMsg = ref('')
const toastType = ref('success')
const savingCookie = ref(false)

const cookie = reactive({
  enabled: true,
  title: '',
  content: '',
  agreeText: '',
  declineText: ''
})

let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2500)
}

const loadCookieConfig = async () => {
  try {
    const d: any = await request.get({ url: '/api/cookie-consent/config' })
    if (d) {
      cookie.enabled = d.enabled
      cookie.title = d.title
      cookie.content = d.content
      cookie.agreeText = d.agreeText
      cookie.declineText = d.declineText
    }
  } catch {}
}

const saveCookie = async () => {
  savingCookie.value = true
  try {
    const configs = [
      { config_key: 'cookie_consent_enabled', config_value: cookie.enabled ? 'true' : 'false', description: 'Cookie 同意弹窗开关' },
      { config_key: 'cookie_consent_title', config_value: cookie.title, description: 'Cookie 弹窗标题' },
      { config_key: 'cookie_consent_content', config_value: cookie.content, description: 'Cookie 弹窗内容' },
      { config_key: 'cookie_consent_agree_text', config_value: cookie.agreeText, description: '同意按钮文字' },
      { config_key: 'cookie_consent_decline_text', config_value: cookie.declineText, description: '拒绝按钮文字' }
    ]
    await request.post({ url: '/api/sys-config/save', data: { configs } })
    showToast('Cookie 设置已保存')
  } catch (e: any) {
    showToast(e?.message || '保存失败', 'error')
  } finally {
    savingCookie.value = false
  }
}

onMounted(async () => {
  await Promise.all([loadCookieConfig()])
  loading.value = false
})
</script>

<script lang="ts">
import { ref, onMounted, watch, defineComponent, h } from 'vue'
import request from '@/utils/http'

const PolicyManager = defineComponent({
  name: 'PolicyManager',
  props: { type: { type: String, required: true }, title: { type: String, default: '' } },
  setup(props: { type: string; title: string }) {
    const policies = ref<any[]>([])
    const loading = ref(true)
    const editingId = ref<number | null>(null)
    const editTitle = ref('')
    const editContent = ref('')
    const saving = ref(false)
    const showConfirmModal = ref(false)
    const confirmModalAction = ref<null | (() => Promise<void> | void)>(null)
    const confirmModalTitle = ref('')
    const confirmModalMessage = ref('')
    const confirmModalLoading = ref(false)

    const loadPolicies = async () => {
      try {
        const res: any = await request.get({ url: '/api/admin/policies', params: { type: props.type } })
        policies.value = res?.list || []
      } catch {} finally { loading.value = false }
    }

    const startNew = () => {
      editingId.value = 0
      editTitle.value = ''
      editContent.value = ''
    }

    const startEdit = (p: any) => {
      editingId.value = p.id
      editTitle.value = p.title
      editContent.value = p.content
    }

    const cancelEdit = () => {
      editingId.value = null
      editTitle.value = ''
      editContent.value = ''
    }

    const savePolicy = async () => {
      if (!editTitle.value.trim()) { alert('请输入标题'); return }
      saving.value = true
      try {
        if (editingId.value === 0) {
          await request.post({ url: '/api/admin/policies', data: { type: props.type, title: editTitle.value, content: editContent.value } })
        } else {
          await request.put({ url: `/api/admin/policies/${editingId.value}`, data: { title: editTitle.value, content: editContent.value } })
        }
        cancelEdit()
        await loadPolicies()
      } catch (e: any) {
        alert(e?.message || '保存失败')
      } finally { saving.value = false }
    }

    const openConfirm = (title: string, message: string, action: () => Promise<void> | void) => {
      confirmModalTitle.value = title
      confirmModalMessage.value = message
      confirmModalAction.value = action
      showConfirmModal.value = true
      confirmModalLoading.value = false
    }

    const closeConfirm = () => {
      showConfirmModal.value = false
      confirmModalAction.value = null
    }

    const executeConfirm = async () => {
      confirmModalLoading.value = true
      try {
        if (confirmModalAction.value) await confirmModalAction.value()
        closeConfirm()
      } catch (e: any) {
        alert(e?.message || '操作失败')
      } finally {
        confirmModalLoading.value = false
      }
    }

    const publishPolicy = (id: number) => {
      openConfirm('发布版本', '发布后将通知所有用户重新确认，确定发布？', async () => {
        await request.post({ url: `/api/admin/policies/${id}/publish` })
        await loadPolicies()
      })
    }

    const deletePolicy = (id: number) => {
      openConfirm('删除版本', '确定删除该版本？删除后不可恢复。', async () => {
        await request.del({ url: `/api/admin/policies/${id}` })
        await loadPolicies()
      })
    }

    onMounted(loadPolicies)
    watch(() => props.type, () => {
      loading.value = true
      loadPolicies()
    })

    const iconMap: Record<string, string> = {
      privacy: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
      agreement: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4'
    }

    const gradientMap: Record<string, string> = {
      privacy: 'from-blue-500 to-cyan-500',
      agreement: 'from-violet-500 to-purple-500'
    }

    return () => {
      if (loading.value) return h('div', { class: 'flex flex-col items-center justify-center py-20 gap-3' }, [
        h('div', { class: 'w-8 h-8 border-2 border-[#FF4757] border-t-transparent rounded-full animate-spin' }),
        h('span', { class: 'text-xs text-gray-400' }, '加载中...')
      ])

      return h('div', { class: 'p-4 space-y-4' }, [
        // 头部卡片
        h('div', { class: `bg-gradient-to-r ${gradientMap[props.type]} rounded-3xl p-5 shadow-sm` }, [
          h('div', { class: 'flex items-center justify-between' }, [
            h('div', { class: 'flex items-center gap-3' }, [
              h('div', { class: 'w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm' }, [
                h('svg', { class: 'w-5 h-5 text-white', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                  h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: iconMap[props.type] })
                ])
              ]),
              h('div', {}, [
                h('div', { class: 'text-white font-semibold text-sm' }, props.title),
                h('div', { class: 'text-white/70 text-xs' }, `${policies.value.length} 个版本`)
              ])
            ]),
            h('button', {
              class: 'flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-white text-sm font-semibold shadow-lg active:scale-95 transition-transform',
              style: { color: props.type === 'privacy' ? '#3b82f6' : '#7c3aed' },
              onClick: startNew
            }, [
              h('svg', { class: 'w-4 h-4', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2.5', d: 'M12 4v16m8-8H4' })
              ]),
              '+ 新建'
            ])
          ])
        ]),

        // 编辑表单
        editingId.value !== null ? h('div', { class: 'bg-white rounded-3xl p-5 space-y-4 shadow-sm animate-slide-up' }, [
          h('div', { class: 'flex items-center gap-2 text-sm font-semibold text-gray-800 pb-1' }, [
            h('div', { class: 'w-1.5 h-4 rounded-full bg-[#FF4757]' }),
            editingId.value === 0 ? `新建${props.title}` : '编辑版本'
          ]),
          h('input', {
            class: 'w-full h-11 px-4 text-sm bg-[#f5f6f8] rounded-2xl border-none outline-none focus:ring-2 focus:ring-[#FF4757]/20 transition-all',
            value: editTitle.value,
            onInput: (e: any) => editTitle.value = e.target.value,
            placeholder: '版本标题，如：v2.0 更新'
          }),
          h('textarea', {
            class: 'w-full min-h-[260px] px-4 py-3 text-sm bg-[#f5f6f8] rounded-2xl border-none outline-none focus:ring-2 focus:ring-[#FF4757]/20 transition-all resize-y',
            value: editContent.value,
            onInput: (e: any) => editContent.value = e.target.value,
            placeholder: '正文内容（支持 HTML 标签）',
            rows: 10
          }),
          h('div', { class: 'flex gap-3' }, [
            h('button', {
              class: 'flex-1 h-11 rounded-full bg-gray-100 text-gray-600 text-sm font-medium active:bg-gray-200 transition-colors',
              onClick: cancelEdit
            }, '取消'),
            h('button', {
              class: 'flex-1 h-11 rounded-full bg-[#FF4757] text-white text-sm font-medium active:bg-[#e5394b] transition-colors flex items-center justify-center gap-1.5',
              onClick: savePolicy
            }, [
              saving.value
                ? h('div', { class: 'w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin' })
                : h('svg', { class: 'w-4 h-4', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                    h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M5 13l4 4L19 7' })
                  ]),
              saving.value ? '保存中...' : '保存'
            ])
          ])
        ]) : null,

        // 版本列表
        ...policies.value.map((p: any) => {
          const isPublished = p.status === 'published'
          const isArchived = p.status === 'archived'
          const hasPublished = policies.value.some((x: any) => x.status === 'published')
          return h('div', {
            key: p.id,
            class: `bg-white rounded-2xl overflow-hidden shadow-sm transition-all ${isPublished ? 'ring-1 ring-green-200' : ''}`
          }, [
            h('div', { class: 'p-4' }, [
              h('div', { class: 'flex items-start gap-3' }, [
                // Status icon
                h('div', {
                  class: `w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${isPublished ? 'bg-green-50' : isArchived ? 'bg-gray-50' : 'bg-orange-50'}`
                }, [
                  isPublished
                    ? h('svg', { class: 'w-4.5 h-4.5 text-green-500', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                        h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M5 13l4 4L19 7' })
                      ])
                    : isArchived
                      ? h('svg', { class: 'w-4.5 h-4.5 text-gray-400', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                          h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8' })
                        ])
                      : h('svg', { class: 'w-4.5 h-4.5 text-orange-500', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                          h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z' })
                        ])
                ]),
                h('div', { class: 'flex-1 min-w-0' }, [
                  h('div', { class: 'flex items-center gap-2 mb-1' }, [
                    h('span', { class: 'text-sm font-semibold text-gray-800 truncate' }, p.title || `版本 ${p.version}`),
                    h('span', {
                      class: `text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${isPublished ? 'bg-green-100 text-green-700' : isArchived ? 'bg-gray-100 text-gray-500' : 'bg-orange-100 text-orange-600'}`
                    }, isPublished ? '已发布' : isArchived ? '已归档' : '草稿')
                  ]),
                  h('div', { class: 'text-[11px] text-gray-400 flex items-center gap-2' }, [
                    h('span', null, `v${p.version}`),
                    h('span', { class: 'w-0.5 h-0.5 rounded-full bg-gray-300' }),
                    h('span', null, p.published_at
                      ? `发布于 ${new Date(p.published_at).toLocaleDateString('zh-CN')}`
                      : `创建于 ${new Date(p.create_time).toLocaleDateString('zh-CN')}`)
                  ])
                ])
              ]),
              // Actions
              h('div', { class: 'flex gap-2 pt-3 mt-2 border-t border-gray-50' }, [
                !isPublished && !isArchived ? h('button', {
                  class: 'text-xs text-blue-500 font-medium px-3 py-1.5 rounded-full bg-blue-50 active:bg-blue-100 transition-colors',
                  onClick: () => startEdit(p)
                }, '编辑') : null,
                p.status === 'draft' && !hasPublished ? h('button', {
                  class: 'text-xs text-green-600 font-medium px-3 py-1.5 rounded-full bg-green-50 active:bg-green-100 transition-colors',
                  onClick: () => publishPolicy(p.id)
                }, '发布') : null,
                isPublished ? h('span', { class: 'text-xs text-green-500 font-medium px-3 py-1.5 rounded-full bg-green-50 flex items-center gap-1' }, [
                  h('svg', { class: 'w-3 h-3', fill: 'currentColor', viewBox: '0 0 20 20' }, [
                    h('path', { 'fill-rule': 'evenodd', d: 'M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z', 'clip-rule': 'evenodd' })
                  ]),
                  `当前 v${p.version}`
                ]) : null,
                !isPublished ? h('button', {
                  class: 'text-xs text-red-400 font-medium px-3 py-1.5 rounded-full bg-red-50 active:bg-red-100 transition-colors',
                  onClick: () => deletePolicy(p.id)
                }, '删除') : null
              ].filter(Boolean))
            ])
          ])
        }),

        // 空状态
        policies.value.length === 0 && editingId.value === null ? h('div', { class: 'flex flex-col items-center py-16' }, [
          h('div', { class: 'w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4' }, [
            h('svg', { class: 'w-9 h-9 text-gray-300', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
              h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '1.5', d: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' })
            ])
          ]),
          h('div', { class: 'text-sm text-gray-500 font-medium mb-1' }, `暂无${props.title}版本`),
          h('div', { class: 'text-xs text-gray-400 mb-5' }, '创建第一个版本开始使用'),
          h('button', {
            class: 'px-6 py-2.5 rounded-full bg-[#FF4757] text-white text-sm font-semibold active:scale-95 transition-transform shadow-lg shadow-[#FF4757]/25 flex items-center gap-1.5',
            onClick: startNew
          }, [
            h('svg', { class: 'w-4 h-4', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
              h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2.5', d: 'M12 4v16m8-8H4' })
            ]),
            `新建${props.title}`
          ])
        ]) : null,

        // 确认弹窗
        showConfirmModal.value ? h('div', { class: 'cps-modal-overlay', onClick: closeConfirm }, [
          h('div', { class: 'cps-modal-card', onClick: (e: Event) => e.stopPropagation() }, [
            h('div', { class: 'cps-modal-icon' }, [
              h('svg', { class: 'w-7 h-7 text-[#FF4757]', fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [
                h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z' })
              ])
            ]),
            h('div', { class: 'cps-modal-title' }, confirmModalTitle.value),
            h('div', { class: 'cps-modal-message' }, confirmModalMessage.value),
            h('div', { class: 'cps-modal-actions' }, [
              h('button', { class: 'cps-modal-btn-cancel', onClick: closeConfirm }, '取消'),
              h('button', { class: 'cps-modal-btn-danger', onClick: executeConfirm }, [
                confirmModalLoading.value
                  ? h('div', { class: 'w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin' })
                  : null,
                confirmModalLoading.value ? '处理中...' : '确认删除'
              ])
            ])
          ])
        ]) : null,
      ])
    }
  }
})
</script>

<style scoped>
.toast-enter-active, .toast-leave-active { transition: all 0.25s ease; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translate(-50%, -8px); }

.animate-fade-in { animation: fadeIn 0.3s ease-out; }
.animate-slide-up { animation: slideUp 0.3s ease-out; }

@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }

.field-group { display: flex; flex-direction: column; gap: 0.375rem; }
.field-label {
  font-size: 11px;
  font-weight: 600;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.field-input {
  width: 100%;
  height: 42px;
  padding: 0 14px;
  font-size: 14px;
  background: #f5f6f8;
  border-radius: 12px;
  border: none;
  outline: none;
  transition: all 0.2s;
}
.field-input:focus { background: #fff; box-shadow: 0 0 0 2px rgba(255,71,87,0.15); }
textarea.field-input { height: auto; padding: 10px 14px; }

.btn-primary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 44px;
  border-radius: 999px;
  background: linear-gradient(135deg, #FF4757, #FF6B81);
  color: white;
  font-size: 14px;
  font-weight: 600;
  border: none;
  outline: none;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 15px rgba(255,71,87,0.3);
}
.btn-primary:active { transform: scale(0.97); opacity: 0.9; }
.btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
</style>

<style>
.cps-modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.45);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  animation: cpsModalFadeIn 0.2s ease-out;
  padding: 2rem;
}
.cps-modal-card {
  background: #fff;
  border-radius: 1.5rem;
  padding: 1.75rem 1.5rem 1.25rem;
  width: 100%;
  max-width: 320px;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0,0,0,0.15);
  animation: cpsModalSlideUp 0.25s ease-out;
}
.cps-modal-icon {
  width: 56px; height: 56px; border-radius: 50%;
  background: #fff1f0;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 1rem;
}
.cps-modal-title {
  font-size: 1rem; font-weight: 700; color: #1f2937; margin-bottom: 0.375rem;
}
.cps-modal-message {
  font-size: 0.8125rem; color: #6b7280; line-height: 1.5; margin-bottom: 1.25rem;
}
.cps-modal-actions { display: flex; gap: 0.75rem; }
.cps-modal-btn-cancel {
  flex: 1; height: 42px; border-radius: 999px;
  background: #f3f4f6; color: #6b7280;
  font-size: 0.875rem; font-weight: 600;
  border: none; cursor: pointer; transition: background 0.15s;
}
.cps-modal-btn-cancel:active { background: #e5e7eb; }
.cps-modal-btn-danger {
  flex: 1; height: 42px; border-radius: 999px;
  background: linear-gradient(135deg, #FF4757, #FF6B81);
  color: #fff; font-size: 0.875rem; font-weight: 600;
  border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 0.375rem;
  transition: all 0.15s;
  box-shadow: 0 4px 12px rgba(255,71,87,0.3);
}
.cps-modal-btn-danger:active { transform: scale(0.97); opacity: 0.9; }
@keyframes cpsModalFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes cpsModalSlideUp { from { opacity: 0; transform: translateY(24px) scale(0.96); } to { opacity: 1; transform: translateY(0) scale(1); } }
</style>
