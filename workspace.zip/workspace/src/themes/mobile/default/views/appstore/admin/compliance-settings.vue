<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">合规设置</span>
    </div>

    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div class="flex bg-white border-b border-gray-100 sticky top-[52px] z-10">
        <button v-for="tab in tabs" :key="tab.key" class="flex-1 py-3 text-sm font-medium border-b-2 transition-colors" :class="activeTab === tab.key ? 'text-[#FF4757] border-[#FF4757]' : 'text-gray-500 border-transparent'" @click="activeTab = tab.key">{{ tab.label }}</button>
      </div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>

      <template v-else>
        <!-- Cookie 同意设置 -->
        <div v-if="activeTab === 'cookie'" class="p-4 space-y-4">
          <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
            <div class="text-sm font-bold text-gray-800">Cookie 同意弹窗</div>
            <div class="flex items-center justify-between">
              <span class="text-sm text-gray-600">启用 Cookie 同意弹窗</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="cookie.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cookie.enabled = !cookie.enabled">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cookie.enabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">弹窗标题</label>
              <input v-model="cookie.title" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="Cookie 声明" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">弹窗内容</label>
              <textarea v-model="cookie.content" rows="3" class="w-full px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="本站使用 Cookie 来改善您的浏览体验..." />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">同意按钮文字</label>
              <input v-model="cookie.agreeText" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="同意全部" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">拒绝/仅必要按钮文字</label>
              <input v-model="cookie.declineText" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="仅必要" />
            </div>
            <button class="w-full h-10 rounded-full bg-[#FF4757] text-white text-sm font-medium active:opacity-85" @click="saveCookie">{{ savingCookie ? '保存中...' : '保存 Cookie 设置' }}</button>
          </div>
        </div>

        <!-- 隐私政策 -->
        <div v-if="activeTab === 'privacy'" class="p-4 space-y-4">
          <PolicyManager type="privacy" title="隐私政策" />
        </div>

        <!-- 用户协议 -->
        <div v-if="activeTab === 'agreement'" class="p-4 space-y-4">
          <PolicyManager type="agreement" title="用户协议" />
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, defineComponent, h } from 'vue'
import request from '@/utils/http'

const tabs = [
  { key: 'cookie', label: 'Cookie 同意' },
  { key: 'privacy', label: '隐私政策' },
  { key: 'agreement', label: '用户协议' }
]
const activeTab = ref('cookie')
const loading = ref(true)
const toastMsg = ref('')
const toastType = ref('success')
const savingCookie = ref(false)

const cookie = reactive({
  enabled: true,
  title: '',
  content: '',
  agreeText: '',
  declineText: ''
})

let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2500)
}

const loadCookieConfig = async () => {
  try {
    const res = await request.get({ url: '/api/cookie-consent/config' })
    const d = res?.data
    if (d) {
      cookie.enabled = d.enabled
      cookie.title = d.title
      cookie.content = d.content
      cookie.agreeText = d.agreeText
      cookie.declineText = d.declineText
    }
  } catch {}
}

const saveCookie = async () => {
  savingCookie.value = true
  try {
    const configs = [
      { config_key: 'cookie_consent_enabled', config_value: cookie.enabled ? 'true' : 'false', description: 'Cookie 同意弹窗开关' },
      { config_key: 'cookie_consent_title', config_value: cookie.title, description: 'Cookie 弹窗标题' },
      { config_key: 'cookie_consent_content', config_value: cookie.content, description: 'Cookie 弹窗内容' },
      { config_key: 'cookie_consent_agree_text', config_value: cookie.agreeText, description: '同意按钮文字' },
      { config_key: 'cookie_consent_decline_text', config_value: cookie.declineText, description: '拒绝按钮文字' }
    ]
    await request.post({ url: '/api/sys-config/save', data: { configs } })
    showToast('Cookie 设置已保存')
  } catch (e: any) {
    showToast(e?.message || '保存失败', 'error')
  } finally {
    savingCookie.value = false
  }
}

onMounted(async () => {
  await Promise.all([loadCookieConfig()])
  loading.value = false
})
</script>

<script lang="ts">
const PolicyManager = defineComponent({
  name: 'PolicyManager',
  props: { type: { type: String, required: true }, title: { type: String, default: '' } },
  setup(props: { type: string; title: string }) {
    const policies = ref<any[]>([])
    const loading = ref(true)
    const editingId = ref<number | null>(null)
    const editTitle = ref('')
    const editContent = ref('')
    const saving = ref(false)

    const loadPolicies = async () => {
      try {
        const res = await request.get({ url: '/api/admin/policies', params: { type: props.type } })
        policies.value = res?.data || []
      } catch {} finally { loading.value = false }
    }

    const startNew = () => {
      editingId.value = 0
      editTitle.value = ''
      editContent.value = ''
    }

    const startEdit = (p: any) => {
      editingId.value = p.id
      editTitle.value = p.title
      editContent.value = p.content
    }

    const cancelEdit = () => {
      editingId.value = null
      editTitle.value = ''
      editContent.value = ''
    }

    const savePolicy = async () => {
      saving.value = true
      try {
        if (editingId.value === 0) {
          await request.post({ url: '/api/admin/policies', data: { type: props.type, title: editTitle.value, content: editContent.value } })
        } else {
          await request.put({ url: `/api/admin/policies/${editingId.value}`, data: { title: editTitle.value, content: editContent.value } })
        }
        cancelEdit()
        await loadPolicies()
      } catch (e: any) {
        alert(e?.message || '保存失败')
      } finally { saving.value = false }
    }

    const publishPolicy = async (id: number) => {
      if (!confirm('发布后将通知所有用户重新确认，确定发布？')) return
      try {
        await request.post({ url: `/api/admin/policies/${id}/publish` })
        await loadPolicies()
      } catch (e: any) {
        alert(e?.message || '发布失败')
      }
    }

    const deletePolicy = async (id: number) => {
      if (!confirm('确定删除？')) return
      try {
        await request.delete({ url: `/api/admin/policies/${id}` })
        await loadPolicies()
      } catch (e: any) {
        alert(e?.message || '删除失败')
      }
    }

    onMounted(loadPolicies)

    return () => {
      if (loading.value) return h('div', { class: 'flex justify-center py-12' }, h('div', { class: 'animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full' }))

      return h('div', { class: 'space-y-4' }, [
        h('div', { class: 'flex items-center justify-between' }, [
          h('span', { class: 'text-sm font-bold text-gray-800' }, `${props.title}版本列表`),
          h('button', { class: 'px-4 py-1.5 text-xs font-medium text-white bg-[#FF4757] rounded-full active:opacity-85', onClick: startNew }, '新建版本')
        ]),

        editingId.value !== null ? h('div', { class: 'bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]' }, [
          h('input', { class: 'w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none', value: editTitle.value, onInput: (e: any) => editTitle.value = e.target.value, placeholder: '标题' }),
          h('textarea', { class: 'w-full min-h-[300px] px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-y', value: editContent.value, onInput: (e: any) => editContent.value = e.target.value, placeholder: '正文内容（支持 HTML）', rows: 12 }),
          h('div', { class: 'flex gap-2' }, [
            h('button', { class: 'flex-1 h-10 rounded-full bg-gray-100 text-gray-600 text-sm font-medium active:opacity-85', onClick: cancelEdit }, '取消'),
            h('button', { class: 'flex-1 h-10 rounded-full bg-[#FF4757] text-white text-sm font-medium active:opacity-85', onClick: savePolicy }, saving.value ? '保存中...' : '保存')
          ])
        ]) : null,

        ...policies.value.map((p: any) => h('div', { key: p.id, class: 'bg-white rounded-2xl p-4 space-y-2 shadow-[0_1px_4px_rgba(0,0,0,0.04)]' }, [
          h('div', { class: 'flex items-center gap-2' }, [
            h('span', { class: 'text-sm font-medium text-gray-800 flex-1 truncate' }, p.title || `版本 ${p.version}`),
            h('span', { class: 'text-[10px] px-2 py-0.5 rounded-full font-medium', class: p.status === 'published' ? 'bg-green-100 text-green-700' : p.status === 'archived' ? 'bg-gray-100 text-gray-500' : 'bg-orange-100 text-orange-600' }, p.status === 'published' ? '已发布' : p.status === 'archived' ? '已归档' : '草稿')
          ]),
          h('div', { class: 'text-[11px] text-gray-400 flex gap-3' }, [
            h('span', null, `v${p.version}`),
            h('span', null, p.published_at ? `发布于 ${new Date(p.published_at).toLocaleDateString()}` : `创建于 ${new Date(p.create_time).toLocaleDateString()}`)
          ]),
          h('div', { class: 'flex gap-2 pt-1' }, [
            p.status !== 'published' && p.status !== 'archived' ? h('button', { class: 'text-xs text-blue-500 px-2 py-1 active:opacity-70', onClick: () => startEdit(p) }, '编辑') : null,
            p.status === 'draft' ? h('button', { class: 'text-xs text-green-500 px-2 py-1 active:opacity-70', onClick: () => publishPolicy(p.id) }, '发布') : null,
            p.status === 'published' ? h('text', { class: 'text-xs text-gray-400 px-2 py-1' }, `已发布 v${p.version}`) : null,
            p.status !== 'published' ? h('button', { class: 'text-xs text-red-400 px-2 py-1 active:opacity-70', onClick: () => deletePolicy(p.id) }, '删除') : null
          ])
        ])),

        policies.value.length === 0 && editingId.value === null ? h('div', { class: 'bg-white rounded-2xl p-8 text-center text-sm text-gray-400' }, `暂无${props.title}版本，点击"新建版本"开始编辑`) : null
      ])
    }
  }
})
</script>
