<template>
<div class="cpool">
  <div class="user-header"><h2>兑换码管理</h2><router-link to="/appstore/products" class="back-btn">&lt; 返回商品管理</router-link></div>

  <div class="search-bar" style="margin:12px 0">
    <button class="btn" @click="showGenerate = true">+ 生成兑换码</button>
    <select v-model="statusFilter" class="input" style="width:100px" @change="load">
      <option value="">全部</option><option value="unused">未使用</option><option value="used">已使用</option>
    </select>
    <input v-model="keyword" placeholder="搜索兑换码" class="input" style="flex:1;min-width:120px" @keyup.enter="load" />
  </div>

  <div class="card-table"><table>
    <thead><tr><th>兑换码</th><th>批次</th><th>奖励类型</th><th>奖励</th><th>状态</th><th>使用者</th><th>使用时间</th><th>到期时间</th></tr></thead>
    <tbody>
      <tr v-for="r in list" :key="r.id">
        <td style="font-family:monospace;font-size:12px"><span style="font-weight:600">{{ r.code }}</span></td>
        <td>{{ r.batch_id }}</td>
        <td>{{ r.reward_type === 'product' ? '商品' : r.reward_type === 'decoration' ? '装饰品' : '卡池' }}</td>
        <td>{{ r.product_name || r.decoration_name || r.card_pool_name }}</td>
        <td><span class="tag" :class="r.status === 'used' ? 'tag-used' : 'tag-unused'">{{ r.status === 'used' ? '已使用' : '未使用' }}</span></td>
        <td>{{ r.used_by_name || '-' }}</td>
        <td style="font-size:12px">{{ r.used_at ? r.used_at.substr(0,16) : '-' }}</td>
        <td style="font-size:12px">{{ r.expire_time ? r.expire_time.substr(0,16) : '永不过期' }}</td>
      </tr>
      <tr v-if="!list.length"><td colspan="9" style="text-align:center;padding:40px;color:#999">暂无兑换码</td></tr>
    </tbody>
  </table></div>

  <div class="pagination" v-if="total > pageSize">
    <button :disabled="page <= 1" @click="page--; load()">上一页</button>
    <span>{{ page }}/{{ totalPages }} ({{ total }}条)</span>
    <button :disabled="page >= totalPages" @click="page++; load()">下一页</button>
  </div>

  <!-- 生成弹窗 -->
  <div v-if="showGenerate" class="overlay" @click.self="showGenerate = false">
    <div class="sheet">
      <div class="sheet-header"><span>生成兑换码</span><span class="close" @click="showGenerate = false">&times;</span></div>
      <div class="sheet-body">
        <div class="field"><label>数量</label><input v-model.number="gen.count" type="number" min="1" max="500" class="input" /></div>
        <div class="field"><label>兑换奖励类型</label>
          <select v-model="gen.rewardType" class="input">
            <option value="decoration">装饰品</option><option value="card_pool">卡池卡密</option><option value="product">商品</option>
          </select>
        </div>
        <template v-if="gen.rewardType === 'decoration'">
          <div class="field"><label>装饰品</label><select v-model="gen.decorationId" class="input"><option :value="0">选择</option><option v-for="d in decorations" :key="d.id" :value="d.id">{{ d.name }}</option></select></div>
          <div class="field"><label>有效天数（0=永久）</label><input v-model.number="gen.durationDays" type="number" min="0" class="input" /></div>
        </template>
        <template v-if="gen.rewardType === 'card_pool'">
          <div class="field"><label>卡池</label><select v-model="gen.cardPoolId" class="input"><option :value="0">选择</option><option v-for="p in cardPools" :key="p.id" :value="p.id">{{ p.name }}</option></select></div>
        </template>
        <template v-if="gen.rewardType === 'product'">
          <div class="field"><label>商品ID</label><input v-model.number="gen.productId" type="number" class="input" /></div>
          <div class="field"><label>商品名称</label><input v-model="gen.productName" class="input" /></div>
        </template>
        <div class="field"><label>兑换码有效期（天，0=永久）</label><input v-model.number="gen.expireDays" type="number" min="0" class="input" /></div>
      </div>
      <div class="sheet-footer">
        <button class="btn" @click="showGenerate = false">取消</button>
        <button class="btn save-btn" @click="doGenerate" :disabled="generating">{{ generating ? '生成中...' : '确认生成' }}</button>
      </div>
      <div v-if="genResult.codes.length" class="gen-result">
        <div class="gen-result-title">已生成 {{ genResult.codes.length }} 个兑换码（请复制保存）</div>
        <textarea readonly class="input textarea" rows="8" :value="genResult.codes.join('\n')" style="font-family:monospace;font-size:12px" />
      </div>
    </div>
  </div>
</div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(30)
const totalPages = ref(0)
const statusFilter = ref('')
const keyword = ref('')
const showGenerate = ref(false)
const generating = ref(false)
const decorations = ref<any[]>([])
const cardPools = ref<any[]>([])

const gen = reactive({ count: 10, rewardType: 'decoration', decorationId: 0, durationDays: 0, cardPoolId: 0, productId: 0, productName: '', expireDays: 0 })
const genResult = reactive({ codes: [] as string[] })

async function load() {
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (statusFilter.value) params.status = statusFilter.value
    if (keyword.value) params.keyword = keyword.value
    const res = await request.get('/admin/redeem-codes', { params })
    list.value = res.list || []
    total.value = res.total || 0
    totalPages.value = Math.ceil(total.value / pageSize.value)
  } catch {}
}

async function doGenerate() {
  if (!gen.count || gen.count < 1 || gen.count > 500) return
  if (gen.rewardType === 'decoration' && !gen.decorationId) return
  if (gen.rewardType === 'card_pool' && !gen.cardPoolId) return
  generating.value = true
  try {
    const res = await request.post('/admin/redeem-codes/generate', {
      count: gen.count, rewardType: gen.rewardType,
      productId: gen.productId, productName: gen.productName,
      decorationId: gen.decorationId, cardPoolId: gen.cardPoolId,
      durationDays: gen.durationDays, expireDays: gen.expireDays
    })
    genResult.codes = res?.codes || []
    await load()
  } catch {}
  finally { generating.value = false }
}

async function loadRefs() {
  try {
    const [dRes, pRes] = await Promise.all([
      request.get('/decoration/all', { params: { type: 'avatar_frame' } }),
      request.get('/admin/card-pools', { params: { pageSize: 200 } })
    ])
    decorations.value = dRes || []
    cardPools.value = (pRes?.list || []).filter((p: any) => p.status === 'active')
  } catch {}
}

onMounted(() => { load(); loadRefs() })
</script>

<style scoped>
.cpool { max-width:1200px; margin:0 auto; padding:20px }
.search-bar { display:flex; gap:8px; align-items:center }
.card-table { overflow-x:auto }
.card-table table { width:100%; border-collapse:collapse; font-size:13px }
.card-table th, .card-table td { padding:8px 10px; border:1px solid #eee; text-align:left }
.card-table th { background:#f5f5f5; font-weight:600 }
.tag { padding:1px 8px; border-radius:4px; font-size:10px }
.tag-used { background:#E8F5E9; color:#4CAF50 }
.tag-unused { background:#FFF3E0; color:#FF9800 }
.pagination { display:flex; gap:10px; align-items:center; justify-content:center; margin-top:16px }
.pagination button { padding:6px 14px; border:1px solid #ddd; border-radius:4px; background:#fff; cursor:pointer }
.pagination button:disabled { opacity:.4 }

.overlay { position:fixed; top:0; left:0; right:0; bottom:0; z-index:100; background:rgba(0,0,0,.5); display:flex; align-items:flex-end }
.sheet { width:100%; background:#fff; border-radius:16px 16px 0 0; max-height:85vh; display:flex; flex-direction:column }
.sheet-header { display:flex; justify-content:space-between; align-items:center; padding:16px 18px; border-bottom:1px solid #f0f0f0; font-weight:700; font-size:16px }
.close { font-size:22px; cursor:pointer; color:#999 }
.sheet-body { padding:14px 18px; overflow-y:auto; flex:1 }
.sheet-footer { padding:12px 18px 20px; display:flex; gap:8px; justify-content:flex-end; border-top:1px solid #f0f0f0 }
.field { margin-bottom:10px }
.field label { display:block; font-size:12px; color:#666; margin-bottom:4px }
.input { width:100%; padding:7px 10px; border:1px solid #ddd; border-radius:8px; font-size:13px; box-sizing:border-box }
.textarea { resize:vertical; min-height:60px }
.btn { padding:7px 16px; border:1px solid #ddd; border-radius:8px; background:#fff; cursor:pointer; font-size:13px }
.save-btn { background:#FF6B6B; color:#fff; border:none }
.gen-result { padding:10px 18px 18px; border-top:1px solid #f0f0f0 }
.gen-result-title { font-size:13px; font-weight:600; margin-bottom:6px; color:#E65100 }
</style>
