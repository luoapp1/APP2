<template>
<div class="page">
  <div class="topbar">
    <button class="back-btn" @click="$router.back()">&larr;</button>
    <span class="title">兑换码管理</span>
  </div>

  <div class="content">
    <div class="search-bar">
      <div class="search-input-wrap">
        <svg class="search-icon" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#999" stroke-width="2"/><path d="M20 20l-3.5-3.5" stroke="#999" stroke-width="2"/></svg>
        <input v-model="keyword" placeholder="搜索用户ID" class="search-input" @keyup.enter="load" />
      </div>
      <button class="new-btn" @click="openAdd">+ 新增</button>
    </div>

    <div class="list" v-if="list.length">
      <div class="list-item" v-for="row in list" :key="row.id">
        <div class="item-top">
          <span class="code-mono">{{ row.code }}</span>
          <span class="item-time">{{ formatTime(row.create_time) }}</span>
        </div>
        <div class="item-body">
          <div class="item-field"><span class="f-label">产品</span><span class="f-val">{{ row.product_name }}</span></div>
          <div class="item-field"><span class="f-label">用户ID</span><span class="f-val">{{ row.user_id || '未绑定' }}</span></div>
          <div class="item-field"><span class="f-label">状态</span><span class="f-val"><span class="status-dot" :class="row.status === 'used' ? 'dot-used' : 'dot-avail'"></span>{{ row.status === 'used' ? '已使用' : '可用' }}</span></div>
        </div>
      </div>
    </div>
    <div class="empty" v-if="!list.length && !firstLoad">
      <div class="empty-text">暂无兑换码</div>
    </div>

    <div class="pager" v-if="total > pageSize">
      <button :disabled="page <= 1" @click="page--; load()">上一页</button>
      <span class="pager-info">{{ page }}/{{ totalPages }} 页 · {{ total }} 条</span>
      <button :disabled="page >= totalPages" @click="page++; load()">下一页</button>
    </div>

    <Teleport to="body">
      <div class="overlay" v-if="showAddPanel" @click.self="showAddPanel = false">
        <div class="panel">
          <div class="panel-title">新增兑换码</div>
          <div class="panel-field">
            <label>产品</label>
            <select v-model="form.productId" class="prod-select">
              <option value="" disabled>请选择产品</option>
              <option v-for="p in products" :key="p.id" :value="p.id">{{ p.name }} (ID: {{ p.id }})</option>
            </select>
          </div>
          <div class="panel-field">
            <label>兑换码</label>
            <textarea v-model="form.code" placeholder="兑换码" rows="2"></textarea>
          </div>
          <div class="panel-btns">
            <button class="btn-cancel" @click="showAddPanel = false">取消</button>
            <button class="btn-confirm" @click="submitAdd">确认</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const products = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const totalPages = ref(0)
const firstLoad = ref(true)
const keyword = ref('')
const showAddPanel = ref(false)
const form = ref({ productId: '', code: '' })

function formatTime(t: string) { if (!t) return ''; return t.replace('T', ' ').substring(0, 16) }

async function load() {
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (keyword.value) params.keyword = keyword.value
    const res = await request.get({ url: '/api/admin/redeem-codes', params })
    list.value = Array.isArray(res?.list) ? res.list : []
    total.value = res?.total || 0
    totalPages.value = Math.ceil(total.value / pageSize.value)
  } catch {} finally { firstLoad.value = false }
}

async function loadProducts() {
  try {
    const res = await request.get({ url: '/api/mall/products', params: { pageSize: 200, status: 'published' } })
    products.value = Array.isArray(res?.list) ? res.list : []
  } catch {}
}

function openAdd() {
  form.value = { productId: '', code: '' }
  showAddPanel.value = true
}

async function submitAdd() {
  if (!form.value.productId || !form.value.code) return
  try {
    await request.post({
      url: '/api/admin/redeem-codes',
      data: {
        code: form.value.code,
        productId: Number(form.value.productId)
      }
    })
    showAddPanel.value = false
    load()
  } catch {}
}

onMounted(() => { load(); loadProducts() })
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; }
.topbar { display: flex; align-items: center; padding: 14px 16px; background: #fff; gap: 12px; border-bottom: 1px solid #eee; position: sticky; top: 0; z-index: 10; }
.back-btn { border: none; background: none; font-size: 20px; cursor: pointer; color: #333; padding: 0; line-height: 1; }
.title { font-size: 17px; font-weight: 700; color: #1a1a1a; }
.content { padding: 14px; }

.search-bar { display: flex; gap: 8px; margin-bottom: 14px; }
.search-input-wrap { flex: 1; position: relative; display: flex; align-items: center; background: #fff; border-radius: 10px; padding: 0 12px; box-shadow: 0 1px 2px rgba(0,0,0,.04); }
.search-icon { width: 16px; height: 16px; flex-shrink: 0; }
.search-input { flex: 1; border: none; outline: none; padding: 10px 8px; font-size: 13px; background: transparent; }
.new-btn { padding: 10px 18px; border: none; background: #FF6B6B; color: #fff; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; }

.list { display: flex; flex-direction: column; gap: 10px; }
.list-item { background: #fff; border-radius: 12px; padding: 12px 14px; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.item-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.code-mono { font-family: monospace; font-size: 14px; font-weight: 700; color: #FF6B6B; }
.item-time { font-size: 11px; color: #aaa; }
.item-body { display: flex; flex-direction: column; gap: 6px; }
.item-field { display: flex; gap: 8px; font-size: 12px; }
.f-label { color: #999; flex-shrink: 0; min-width: 42px; }
.f-val { color: #333; display: flex; align-items: center; gap: 6px; }
.status-dot { width: 6px; height: 6px; border-radius: 50%; }
.dot-used { background: #BDBDBD; }
.dot-avail { background: #4CAF50; }

.empty { text-align: center; padding: 60px 20px; }
.empty-text { font-size: 14px; color: #bbb; }

.pager { display: flex; gap: 12px; align-items: center; justify-content: center; margin-top: 20px; padding-bottom: 10px; }
.pager button { padding: 8px 18px; border: 1px solid #e0e0e0; border-radius: 10px; background: #fff; cursor: pointer; font-size: 13px; color: #555; }
.pager button:disabled { opacity: .35; cursor: default; }
.pager-info { font-size: 12px; color: #999; }

.overlay { position: fixed; inset: 0; background: rgba(0,0,0,.4); display: flex; justify-content: center; align-items: center; z-index: 100; }
.panel { background: #fff; border-radius: 16px; padding: 24px; width: 85vw; max-width: 400px; }
.panel-title { font-size: 16px; font-weight: 700; margin-bottom: 16px; }
.panel-field { margin-bottom: 12px; }
.panel-field label { display: block; font-size: 12px; color: #888; margin-bottom: 4px; }
.panel-field input, .panel-field textarea, .panel-field select { width: 100%; padding: 10px 12px; border: 1px solid #e0e0e0; border-radius: 10px; font-size: 13px; box-sizing: border-box; }
.panel-field select { appearance: none; background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath d='M3 5l3 3 3-3' fill='none' stroke='%23999' stroke-width='1.5'/%3E%3C/svg%3E") no-repeat right 12px center; padding-right: 32px; }
.panel-field textarea { resize: vertical; }
.panel-btns { display: flex; gap: 10px; margin-top: 16px; }
.panel-btns button { flex: 1; padding: 10px; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; }
.btn-cancel { background: #f0f0f0; border: none; color: #666; }
.btn-confirm { background: #FF6B6B; border: none; color: #fff; }
</style>
