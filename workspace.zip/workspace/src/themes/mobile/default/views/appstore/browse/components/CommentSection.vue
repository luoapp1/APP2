<template>
  <div class="comment-section px-4 pt-4">
    <!-- Toast -->
    <div v-if="toastText" class="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 px-5 py-2.5 rounded-full text-sm text-white" style="background: rgba(0,0,0,0.75);">{{ toastText }}</div>

    <!-- 评分统计区 -->
    <div class="rating-stats-card">
      <div class="rating-overview">
        <div class="rating-left">
          <div class="rating-score">{{ toNum(ratingStats?.average).toFixed(1) }}</div>
          <div class="rating-count">{{ ratingStats?.total || 0 }}份评分</div>
        </div>
        <div class="rating-distribution">
          <div v-for="star in 5" :key="star" class="dist-row">
            <div class="dist-stars">
              <svg v-for="s in (6-star)" :key="s" class="dist-star" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            </div>
            <div class="dist-bar">
              <div class="dist-bar-inner" :style="{ width: starPercent(6-star) + '%' }" />
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 查看全部评价按钮 -->
    <button
      class="w-full py-2.5 rounded-xl text-sm font-medium text-teal-500 bg-teal-50 border border-teal-100 hover:bg-teal-100 active:scale-[0.98] transition-all mt-3"
      @click="router.push(`/appstore/${appId}/ratings`)"
    >
      查看全部评价
    </button>

    <!-- 评论入口按钮 -->
    <button
      class="w-full py-3 rounded-xl text-sm font-medium text-gray-400 bg-gray-50 border border-dashed border-gray-200 hover:border-teal-300 hover:text-teal-500 hover:bg-teal-50/30 transition-all active:scale-[0.98]"
      @click="showCommentSheet = true"
    >
      <span class="flex items-center justify-center gap-1.5">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        说说你的看法...
      </span>
    </button>

    <!-- 评论底部弹窗 -->
    <div v-if="showCommentSheet" class="fixed inset-0 z-[200]" @click.self="showCommentSheet = false">
      <div class="absolute inset-0 bg-black/40" @click="showCommentSheet = false"></div>
      <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl animate-slide-up" style="padding-bottom: max(20px, env(safe-area-inset-bottom));">
        <div class="flex items-center justify-between px-5 pt-4 pb-2">
          <span class="text-base font-semibold text-gray-900">发表评论</span>
          <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-gray-100" @click="showCommentSheet = false">
            <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="px-5 pb-3">
          <div class="flex items-center gap-1 mb-3">
            <svg v-for="s in 5" :key="s" class="w-6 h-6 cursor-pointer transition-all duration-150 hover:scale-110" :class="s <= commentRating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20" @click="commentRating = s"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <span class="text-xs text-gray-400 ml-1">{{ commentRating }} 分</span>
          </div>
          <textarea
            v-model="commentText"
            maxlength="200"
            placeholder="说说你的看法..."
            rows="4"
            class="w-full bg-gray-50 rounded-xl p-3.5 text-sm outline-none resize-none border-0 placeholder:text-gray-400 focus:ring-2 focus:ring-teal-100 focus:bg-white transition-all"
          />
          <div class="flex items-center justify-between mt-3">
            <span class="text-xs text-gray-400">{{ commentText.length }}/200</span>
            <button
              class="px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all duration-200 active:scale-95"
              style="background: linear-gradient(135deg, #00BFA5, #00d4b8)"
              @click="submitComment"
            >发表评论</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 评论排序 + 总数 -->
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-base font-bold text-gray-900">全部评论</h3>
      <div class="flex items-center gap-2">
        <span class="text-xs text-gray-400">{{ sortedComments.length }} 条</span>
        <div class="flex items-center gap-0.5 bg-gray-100 rounded-lg p-0.5">
          <button
            v-for="s in sortOptions"
            :key="s.value"
            class="px-2.5 py-1 rounded-md text-[11px] font-medium transition-all"
            :class="sortBy === s.value ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400 hover:text-gray-600'"
            @click="sortBy = s.value"
          >{{ s.label }}</button>
        </div>
      </div>
    </div>

    <!-- 评论列表 -->
    <div v-if="sortedComments.length > 0" class="pb-20">
      <div v-for="comment in sortedComments" :key="comment.id" class="py-3.5 border-b border-gray-100 last:border-b-0" :class="comment.isPinned ? 'bg-amber-50/30 -mx-4 px-4' : ''">
        <div class="flex items-start gap-2.5">
          <div class="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: comment.userAvatar && !comment.userAvatar.startsWith('#') ? 'transparent' : undefined }">
            <img v-if="comment.userAvatar && !comment.userAvatar.startsWith('#')" :src="comment.userAvatar" class="w-full h-full object-cover"  loading="lazy" />
            <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover"  loading="lazy" />
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-1.5 flex-wrap">
              <span class="text-[13px] font-semibold text-gray-800">{{ comment.userName }}</span>
              <span v-if="comment.isPinned" class="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 font-semibold">置顶</span>
              <span v-if="comment.purchased" class="text-[9px] px-1.5 py-0.5 rounded bg-green-100 text-green-700 font-semibold">{{ purchaseTypeLabel(comment.purchaseType) }}</span>
              <span v-if="isTipComment(comment.content)" class="text-[9px] px-1.5 py-0.5 rounded bg-teal-100 text-teal-700 font-semibold">打赏</span>
              <div v-if="comment.rating > 0" class="flex items-center gap-0.5 ml-auto">
                <svg v-for="s in 5" :key="s" class="w-3 h-3" :class="s <= comment.rating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              </div>
            </div>
            <p class="text-[13px] text-gray-600 mt-1 leading-relaxed" :class="isTipComment(comment.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(comment.content)"></p>
            <div class="flex items-center gap-3.5 mt-2">
              <span class="text-[11px] text-gray-400">{{ relativeTime(comment.createTime) }}</span>
              <span class="inline-flex items-center gap-1 text-[12px] cursor-pointer select-none" :class="comment.isLiked ? 'text-red-400' : 'text-gray-400'" @click.stop="handleLike(comment)">
                <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                <span class="font-medium">{{ comment.likeCount || 0 }}</span>
              </span>
              <span class="text-[12px] text-gray-400 cursor-pointer hover:text-teal-500 font-medium" @click.stop="openReply(comment)">回复</span>
              <div class="relative ml-auto">
                <button class="w-6 h-6 flex items-center justify-center rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors" @click.stop="menuCommentId = menuCommentId === comment.id ? 0 : comment.id">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
                </button>
                <div v-if="menuCommentId === comment.id" class="fixed inset-0 z-40" @click.stop="menuCommentId = 0"></div>
                <div v-if="menuCommentId === comment.id" class="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border border-gray-100 py-1.5 min-w-[100px] z-50" @click.stop>
                  <button class="w-full text-left px-4 py-2 text-[13px] text-gray-600 hover:bg-gray-50 transition-colors" @click.stop="handleReport(comment); menuCommentId = 0">举报</button>
                  <button v-if="canPin" class="w-full text-left px-4 py-2 text-[13px] text-amber-600 hover:bg-amber-50 transition-colors" @click.stop="handlePin(comment); menuCommentId = 0">{{ comment.isPinned ? '取消置顶' : '置顶' }}</button>
                  <button v-if="comment.userId === userStore.info.userId" class="w-full text-left px-4 py-2 text-[13px] text-red-500 hover:bg-red-50 transition-colors" @click.stop="confirmDelete(comment); menuCommentId = 0">删除</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 回复列表 -->
        <div v-if="comment.replies && comment.replies.length > 0" class="mt-2.5 ml-[34px]">
          <div v-for="reply in comment.replies" :key="reply.id" class="py-2 border-l-2 border-gray-100 pl-3">
            <div class="flex items-start gap-2">
              <div class="w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: reply.userAvatar && !reply.userAvatar.startsWith('#') ? 'transparent' : undefined }">
                <img v-if="reply.userAvatar && !reply.userAvatar.startsWith('#')" :src="reply.userAvatar" class="w-full h-full object-cover"  loading="lazy" />
                <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover"  loading="lazy" />
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1 flex-wrap">
                  <span class="text-[12px] font-semibold text-gray-700">{{ reply.userName }}</span>
                  <span v-if="reply.purchased" class="text-[9px] px-1 py-0.5 rounded bg-green-100 text-green-700 font-semibold">{{ purchaseTypeLabel(reply.purchaseType) }}</span>
                  <span v-if="isTipComment(reply.content)" class="text-[9px] px-1 py-0.5 rounded bg-teal-100 text-teal-700 font-semibold">打赏</span>
                </div>
                <p class="text-[12px] text-gray-600 mt-0.5 leading-relaxed" :class="isTipComment(reply.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(reply.content)"></p>
                <div class="flex items-center gap-3 mt-1">
                  <span class="text-[10px] text-gray-400">{{ relativeTime(reply.createTime) }}</span>
                  <span class="inline-flex items-center gap-0.5 text-[11px] cursor-pointer" :class="reply.isLiked ? 'text-red-400' : 'text-gray-400'" @click.stop="handleLike(reply)">
                    <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                    <span>{{ reply.likeCount || 0 }}</span>
                  </span>
                  <span v-if="reply.userId === userStore.info.userId" class="text-[11px] text-red-400 cursor-pointer hover:text-red-500" @click.stop="deleteReply(reply)">删除</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 回复输入框 -->
        <div v-if="replyTarget === comment.id" class="mt-2.5 ml-[34px]">
          <div class="flex items-center gap-2">
            <input v-model="replyText" maxlength="200" :placeholder="`回复 ${comment.userName}...`" class="flex-1 bg-gray-50 rounded-full px-3.5 py-1.5 text-xs outline-none border-0 focus:ring-2 focus:ring-teal-100 transition-all" @keyup.enter="doReply" />
            <button class="text-xs text-teal-500 font-semibold shrink-0" @click="doReply">发送</button>
            <button class="text-xs text-gray-400 shrink-0" @click="replyTarget = 0">取消</button>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="text-center py-20 text-gray-400">
      <svg class="w-20 h-20 mx-auto mb-4 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
      <p class="text-sm">还没有评论，快来发表第一条吧</p>
    </div>

    <!-- 举报弹窗 -->
    <div v-if="showReportInput" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 200;" @click.self="showReportInput = false">
      <div style="background: #fff; border-radius: 20px; width: 300px; padding: 24px 20px;">
        <div style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: #1f2937;">举报评论</div>
        <input v-model="reportReason" placeholder="请填写举报原因" style="width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 16px; transition: border-color .2s;" />
        <div style="display: flex; gap: 10px;">
          <button style="flex:1; padding: 10px; border-radius: 10px; border: none; background: #f3f4f6; color: #374151; font-size: 14px; font-weight: 600; cursor: pointer;" @click="showReportInput = false">取消</button>
          <button style="flex:1; padding: 10px; border-radius: 10px; border: none; background: #EF4444; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="doReport">提交举报</button>
        </div>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="showDeleteConfirm" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 200;" @click.self="showDeleteConfirm = false">
      <div style="background: #fff; border-radius: 20px; width: 280px; padding: 28px 24px 20px; text-align: center;">
        <div style="font-size: 16px; font-weight: 700; margin-bottom: 10px; color: #1f2937;">确认删除</div>
        <div style="font-size: 13px; color: #6b7280; margin-bottom: 24px;">确定要删除这条评论吗？</div>
        <div style="display: flex; gap: 10px;">
          <button style="flex:1; padding: 11px; border-radius: 10px; border: none; background: #f3f4f6; color: #374151; font-size: 14px; font-weight: 600; cursor: pointer;" @click="showDeleteConfirm = false">取消</button>
          <button style="flex:1; padding: 11px; border-radius: 10px; border: none; background: #EF4444; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="doDelete">确认删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import {
  fetchPostComment,
  fetchCommentLike,
  fetchDeleteComment,
  fetchReportComment,
  fetchReplyComment,
  fetchPinComment,
} from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import { toNum } from '@/utils'
import { sanitizeHtml } from '@/utils/ui/sanitize'

const props = defineProps<{
  appId: number
  comments: any[]
  ratingStats: any
  isOwner: boolean
  isAdmin: boolean
}>()

const emit = defineEmits<{
  (e: 'refresh'): void
  (e: 'commentCountChanged', count: number): void
}>()

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const commentText = ref('')
const commentRating = ref(5)
const showCommentSheet = ref(false)
const sortBy = ref('newest')

const sortOptions = [
  { label: '最新', value: 'newest' },
  { label: '最热', value: 'hottest' },
]

const sortedComments = computed(() => {
  let list = [...props.comments]
  if (sortBy.value === 'hottest') {
    list.sort((a: any, b: any) => {
      const score = (c: any) => (c.likeCount || 0) + (c.replies?.length || 0) * 0.5
      return score(b) - score(a)
    })
  }
  list.sort((a: any, b: any) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0))
  return list
})

function relativeTime(dateStr: string): string {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const min = Math.floor(diff / 60000)
  if (min < 1) return '刚刚'
  if (min < 60) return `${min}分钟前`
  const hours = Math.floor(min / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}天前`
  const months = Math.floor(days / 30)
  if (months < 12) return `${months}个月前`
  return dateStr.slice(0, 10)
}

const toastText = ref('')
const showToast = (text: string) => {
  toastText.value = text
  setTimeout(() => { toastText.value = '' }, 2000)
}

const starPercent = (star: number) => {
  const dist = props.ratingStats?.distribution || {}
  const max = Math.max(...Object.values(dist) as number[], 1)
  return Math.round(((dist[star] || 0) / max) * 100)
}

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return false
  }
  return true
}

const submitComment = async () => {
  if (!checkLogin()) return
  if (!commentText.value.trim()) return
  if (commentText.value.length > 200) { showToast('评论最多200字'); return }
  try {
    await fetchPostComment(props.appId, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      rating: commentRating.value,
      content: commentText.value
    })
    commentText.value = ''
    commentRating.value = 5
    showCommentSheet.value = false
    emit('refresh')
  } catch (e: any) { ElMessage.error('评论失败，请稍后再试'); console.error('[CommentSection] submitComment failed:', e?.message || e) }
}

const handleLike = async (comment: any) => {
  if (!checkLogin()) return
  try {
    const res: any = await fetchCommentLike(
      props.appId, comment.id, userStore.info.userId || 0
    )
    comment.isLiked = res.liked
    comment.likeCount += res.liked ? 1 : -1
    if (comment.likeCount < 0) comment.likeCount = 0
    showToast(res.liked ? '已点赞' : '已取消')
  } catch (e) { console.error('like err:', e); showToast('操作失败') }
}

const showDeleteConfirm = ref(false)
const deleteTarget = ref<any>(null)
const menuCommentId = ref(0)

const confirmDelete = (comment: any) => {
  deleteTarget.value = comment
  showDeleteConfirm.value = true
}

const doDelete = async () => {
  if (!deleteTarget.value) return
  try {
    await fetchDeleteComment(props.appId, deleteTarget.value.id, userStore.info.userId || 0)
    showToast('已删除')
    showDeleteConfirm.value = false
    emit('refresh')
  } catch { showToast('删除失败') }
}

const showReportInput = ref(false)
const reportTarget = ref<any>(null)
const reportReason = ref('')

const replyTarget = ref(0)
const replyText = ref('')

const isTipComment = (content: string) => content?.startsWith('[打赏')

const purchaseTypeLabel = (pt: string) => {
  if (pt === 'balance') return '余额已购'
  if (pt === 'points') return '积分已购'
  return '已购买'
}

const openReply = (comment: any) => {
  if (!userStore.info.userId) { showToast('请先登录'); return }
  replyTarget.value = replyTarget.value === comment.id ? 0 : comment.id
  replyText.value = ''
}

const doReply = async () => {
  if (!replyText.value.trim()) return
  if (replyText.value.length > 200) { showToast('回复最多200字'); return }
  try {
    await fetchReplyComment(props.appId, replyTarget.value, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || '匿名',
      content: replyText.value.trim()
    })
    replyTarget.value = 0
    replyText.value = ''
    showToast('回复成功')
    emit('refresh')
  } catch { showToast('回复失败') }
}

const deleteReply = async (reply: any) => {
  try {
    await fetchDeleteComment(props.appId, reply.id, userStore.info.userId || 0)
    showToast('已删除')
    emit('refresh')
  } catch { showToast('删除失败') }
}

const canPin = computed(() => {
  if (props.isOwner) return true
  const roles = userStore.info.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return true
  return false
})

const handlePin = async (comment: any) => {
  try {
    const res: any = await fetchPinComment(props.appId, comment.id, userStore.info.userId)
    showToast(res.msg || (comment.isPinned ? '已取消置顶' : '已置顶'))
    emit('refresh')
  } catch { showToast('操作失败') }
}

const handleReport = (comment: any) => {
  reportTarget.value = comment
  reportReason.value = ''
  showReportInput.value = true
}

const doReport = async () => {
  if (!reportReason.value.trim()) return
  try {
    await fetchReportComment(props.appId, reportTarget.value.id, userStore.info.userId || 0, reportReason.value)
    showReportInput.value = false
    showToast('举报已提交')
  } catch { showToast('举报失败') }
}
</script>

<style scoped>
.rating-stats-card {
  background: #f0f2f5;
  border-radius: 12px;
  padding: 12px 14px;
  margin-bottom: 12px;
}

.rating-overview {
  display: flex;
  align-items: center;
  gap: 16px;
}

.rating-left {
  text-align: center;
  flex-shrink: 0;
  min-width: 56px;
}

.rating-score {
  font-size: 32px;
  font-weight: 600;
  color: #1f2937;
  line-height: 1;
  letter-spacing: -1px;
}

.rating-count {
  font-size: 11px;
  color: #9ca3af;
  margin-top: 2px;
}

.rating-distribution {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.dist-row {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dist-stars {
  display: flex;
  align-items: center;
  gap: 1px;
  flex-shrink: 0;
}

.dist-star {
  width: 10px;
  height: 10px;
  color: #c4b5fd;
}

.dist-bar {
  flex: 1;
  height: 4px;
  background: #d1d5db;
  border-radius: 2px;
  overflow: hidden;
}

.dist-bar-inner {
  height: 100%;
  border-radius: 2px;
  background: #3D7BEA;
  transition: width .4s ease;
}

@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.animate-slide-up {
  animation: slide-up 0.25s ease-out;
}
</style>
