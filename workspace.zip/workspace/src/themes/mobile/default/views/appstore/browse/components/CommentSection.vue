<template>
  <div class="comment-section">
    <!-- Toast -->
    <div v-if="toastText" class="fixed top-20 left-1/2 transform -translate-x-1/2 z-[300] px-5 py-2.5 rounded-full text-sm text-white whitespace-nowrap" style="background: rgba(0,0,0,0.75);">{{ toastText }}</div>

    <!-- ========== LAYER 0: 主评论列表 ========== -->
    <div class="px-4 pt-4">
      <!-- 评分统计区 -->
      <div class="rating-stats-card">
        <div class="rating-overview">
          <div class="rating-left">
            <div class="rating-score">{{ toNum(ratingStats?.average).toFixed(1) }}</div>
            <div class="rating-count">{{ ratingStats?.total || 0 }}份评分</div>
          </div>
          <div class="rating-distribution">
            <div v-for="star in 5" :key="star" class="dist-row">
              <div class="dist-stars">
                <svg v-for="s in (6-star)" :key="s" class="dist-star" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              </div>
              <div class="dist-bar">
                <div class="dist-bar-inner" :style="{ width: starPercent(6-star) + '%' }" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 查看全部评价按钮 -->
      <button
        class="w-full py-2.5 rounded-xl text-sm font-medium text-teal-500 bg-teal-50 border border-teal-100 hover:bg-teal-100 active:scale-[0.98] transition-all mt-3"
        @click="router.push(`/appstore/${appId}/ratings`)"
      >
        查看全部评价
      </button>

      <!-- 评论排序 + 总数 -->
      <div class="flex items-center justify-between mb-4 mt-4">
        <h3 class="text-base font-bold text-gray-900">全部评论</h3>
        <div class="flex items-center gap-2">
          <span class="text-xs text-gray-400">{{ sortedComments.length }} 条</span>
          <div class="flex items-center gap-0.5 bg-gray-100 rounded-lg p-0.5">
            <button
              v-for="s in sortOptions"
              :key="s.value"
              class="px-2.5 py-1 rounded-md text-[11px] font-medium transition-all"
              :class="sortBy === s.value ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400 hover:text-gray-600'"
              @click="sortBy = s.value"
            >{{ s.label }}</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 评论列表 -->
    <div v-if="sortedComments.length > 0" class="pb-24 px-4">
      <div v-for="comment in sortedComments" :key="comment.id" class="py-3.5 border-b border-gray-100 last:border-b-0" :class="comment.isPinned ? 'bg-amber-50/30 -mx-4 px-4' : ''">
        <div class="flex items-start gap-2.5">
          <div class="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: comment.userAvatar && !comment.userAvatar.startsWith('#') ? 'transparent' : undefined }">
            <img v-if="comment.userAvatar && !comment.userAvatar.startsWith('#')" :src="comment.userAvatar" class="w-full h-full object-cover" loading="lazy" />
            <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-1.5 flex-wrap">
              <span class="text-[13px] font-semibold text-gray-800">{{ comment.userName }}</span>
              <span v-if="comment.isPinned" class="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 font-semibold">置顶</span>
              <span v-if="comment.purchased" class="text-[9px] px-1.5 py-0.5 rounded bg-green-100 text-green-700 font-semibold">{{ purchaseTypeLabel(comment.purchaseType) }}</span>
              <span v-if="isTipComment(comment.content)" class="text-[9px] px-1.5 py-0.5 rounded bg-teal-100 text-teal-700 font-semibold">打赏</span>
              <div v-if="comment.rating > 0" class="flex items-center gap-0.5 ml-auto">
                <svg v-for="s in 5" :key="s" class="w-3 h-3" :class="s <= comment.rating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              </div>
            </div>
            <p class="text-[13px] text-gray-600 mt-1 leading-relaxed" :class="isTipComment(comment.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(comment.content)"></p>
            <div class="flex items-center gap-3.5 mt-2">
              <span class="text-[11px] text-gray-400">{{ relativeTime(comment.createTime) }}</span>
              <span class="inline-flex items-center gap-1 text-[12px] cursor-pointer select-none" :class="comment.isLiked ? 'text-red-400' : 'text-gray-400'" @click.stop="handleLike(comment)">
                <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                <span class="font-medium">{{ comment.likeCount || 0 }}</span>
              </span>
              <span class="text-[12px] text-gray-400 cursor-pointer hover:text-teal-500 font-medium" @click.stop="openReplyPopup(comment)">回复</span>
              <div class="relative ml-auto">
                <button class="w-6 h-6 flex items-center justify-center rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors" @click.stop="menuCommentId = menuCommentId === comment.id ? 0 : comment.id">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
                </button>
                <div v-if="menuCommentId === comment.id" class="fixed inset-0 z-40" @click.stop="menuCommentId = 0"></div>
                <div v-if="menuCommentId === comment.id" class="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border border-gray-100 py-1.5 min-w-[100px] z-50" @click.stop>
                  <button class="w-full text-left px-4 py-2 text-[13px] text-gray-600 hover:bg-gray-50 transition-colors" @click.stop="handleReport(comment); menuCommentId = 0">举报</button>
                  <button v-if="canPin" class="w-full text-left px-4 py-2 text-[13px] text-amber-600 hover:bg-amber-50 transition-colors" @click.stop="handlePin(comment); menuCommentId = 0">{{ comment.isPinned ? '取消置顶' : '置顶' }}</button>
                  <button v-if="comment.userId === userStore.info.userId" class="w-full text-left px-4 py-2 text-[13px] text-red-500 hover:bg-red-50 transition-colors" @click.stop="confirmDelete(comment); menuCommentId = 0">删除</button>
                </div>
              </div>
            </div>

            <!-- 楼中楼：内联子回复 -->
            <div v-if="comment.replies && comment.replies.length > 0" class="mt-2.5 ml-1">
              <div class="bg-gray-100 rounded-xl px-3.5 py-2.5 space-y-1.5">
                <div v-for="reply in inlineReplies(comment)" :key="reply.id" class="text-[12px] leading-relaxed">
                  <span class="font-semibold text-gray-500">{{ reply.userName }}:</span>
                  <span class="text-gray-600 ml-1" :class="isTipComment(reply.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(reply.content)"></span>
                </div>
                <div v-if="comment.replies.length > 0" class="text-[12px] text-teal-500 font-medium hover:text-teal-600 cursor-pointer pt-1 border-t border-gray-200/60" @click.stop="openReplyPopup(comment)">
                  查看全部 {{ comment.replies.length }} 条回复
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="text-center py-20 text-gray-400 px-4">
      <svg class="w-20 h-20 mx-auto mb-4 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
      <p class="text-sm">还没有评论，快来发表第一条吧</p>
    </div>

    <!-- 底部固定输入栏 -->
    <div class="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-100 z-40 safe-area-bottom">
      <div class="flex items-center gap-2.5 px-4 py-2.5 max-w-[600px] mx-auto">
        <div class="flex-1 flex items-center gap-2 bg-gray-50 rounded-full px-4 py-2.5 cursor-pointer hover:bg-gray-100 transition-colors active:scale-[0.98]" @click="openMainCommentSheet">
          <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
          <span class="text-sm text-gray-400">说说你的看法...</span>
        </div>
        <div class="flex items-center gap-1">
          <button class="w-9 h-9 flex items-center justify-center rounded-full text-gray-400 hover:bg-gray-100 transition-colors" @click="openMainCommentSheet">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </button>
          <button class="w-9 h-9 flex items-center justify-center rounded-full text-gray-400 hover:bg-gray-100 transition-colors" @click="openMainCommentSheet">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
          </button>
        </div>
      </div>
    </div>

    <!-- ========== LAYER 1: 主评论发表弹窗 ========== -->
    <Transition name="sheet-slide">
      <div v-if="showMainSheet" class="fixed inset-0 z-[200]">
        <div class="absolute inset-0 bg-black/40" @click="showMainSheet = false"></div>
        <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl max-h-[85vh] overflow-y-auto" style="padding-bottom: max(20px, env(safe-area-inset-bottom));">
          <div class="flex items-center justify-between px-5 pt-4 pb-2">
            <span class="text-base font-semibold text-gray-900">发表评论</span>
            <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-gray-100" @click="showMainSheet = false">
              <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
          <div class="px-5 pb-3">
            <div class="flex items-center gap-1 mb-3">
              <svg v-for="s in 5" :key="s" class="w-6 h-6 cursor-pointer transition-all duration-150 hover:scale-110" :class="s <= commentRating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20" @click="commentRating = s"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              <span class="text-xs text-gray-400 ml-1">{{ commentRating }} 分</span>
            </div>
            <textarea
              ref="mainCommentInputRef"
              v-model="commentText"
              maxlength="200"
              placeholder="说说你的看法..."
              rows="5"
              class="w-full bg-gray-50 rounded-xl p-3.5 text-sm outline-none resize-none border-0 placeholder:text-gray-400 focus:ring-2 focus:ring-teal-100 focus:bg-white transition-all"
            />
            <div class="flex items-center justify-between mt-3">
              <span class="text-xs text-gray-400">{{ commentText.length }}/200</span>
              <button
                class="px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all duration-200 active:scale-95"
                style="background: linear-gradient(135deg, #00BFA5, #00d4b8)"
                @click="submitComment"
              >发表评论</button>
            </div>
          </div>
        </div>
      </div>
    </Transition>

    <!-- ========== LAYER 2: 回复列表弹窗 ========== -->
    <Transition name="sheet-slide">
      <div v-if="showReplyPopup" class="fixed inset-0 z-[200]">
        <div class="absolute inset-0 bg-black/40" @click="closeReplyPopup"></div>
        <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl flex flex-col" style="max-height: 85vh; padding-bottom: max(20px, env(safe-area-inset-bottom));">
          <!-- 弹窗头部 -->
          <div class="flex items-center justify-between px-5 pt-4 pb-3 border-b border-gray-100 flex-shrink-0">
            <span class="text-base font-semibold text-gray-900">回复详情</span>
            <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-gray-100" @click="closeReplyPopup">
              <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
          <!-- 父评论（置顶展示） -->
          <div class="px-5 py-3.5 border-b border-gray-100 bg-gray-50/50 flex-shrink-0" v-if="activeParentComment">
            <div class="flex items-start gap-2.5">
              <div class="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: activeParentComment.userAvatar && !activeParentComment.userAvatar.startsWith('#') ? 'transparent' : undefined }">
                <img v-if="activeParentComment.userAvatar && !activeParentComment.userAvatar.startsWith('#')" :src="activeParentComment.userAvatar" class="w-full h-full object-cover" loading="lazy" />
                <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span class="text-[13px] font-semibold text-gray-800">{{ activeParentComment.userName }}</span>
                  <span v-if="activeParentComment.purchased" class="text-[9px] px-1.5 py-0.5 rounded bg-green-100 text-green-700 font-semibold">{{ purchaseTypeLabel(activeParentComment.purchaseType) }}</span>
                  <span v-if="isTipComment(activeParentComment.content)" class="text-[9px] px-1.5 py-0.5 rounded bg-teal-100 text-teal-700 font-semibold">打赏</span>
                </div>
                <p class="text-[13px] text-gray-600 mt-1 leading-relaxed" :class="isTipComment(activeParentComment.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(activeParentComment.content)"></p>
                <div class="flex items-center gap-3 mt-2">
                  <span class="text-[11px] text-gray-400">{{ relativeTime(activeParentComment.createTime) }}</span>
                  <span class="inline-flex items-center gap-1 text-[12px] cursor-pointer select-none" :class="activeParentComment.isLiked ? 'text-red-400' : 'text-gray-400'" @click.stop="handleLike(activeParentComment)">
                    <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                    <span class="font-medium">{{ activeParentComment.likeCount || 0 }}</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <!-- 回复列表（可滚动） -->
          <div class="flex-1 overflow-y-auto px-5">
            <div class="py-2">
              <p class="text-xs text-gray-400 py-3">共 {{ replyCountForPopup }} 条回复</p>
              <div v-for="reply in popupReplies" :key="reply.id" class="py-3 border-b border-gray-50 last:border-b-0">
                <div class="flex items-start gap-2.5">
                  <div class="w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: reply.userAvatar && !reply.userAvatar.startsWith('#') ? 'transparent' : undefined }">
                    <img v-if="reply.userAvatar && !reply.userAvatar.startsWith('#')" :src="reply.userAvatar" class="w-full h-full object-cover" loading="lazy" />
                    <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-1 flex-wrap">
                      <span class="text-[13px] font-semibold text-gray-700">{{ reply.userName }}</span>
                      <span v-if="reply.purchased" class="text-[9px] px-1 py-0.5 rounded bg-green-100 text-green-700 font-semibold">{{ purchaseTypeLabel(reply.purchaseType) }}</span>
                      <span v-if="isTipComment(reply.content)" class="text-[9px] px-1 py-0.5 rounded bg-teal-100 text-teal-700 font-semibold">打赏</span>
                    </div>
                    <p class="text-[13px] text-gray-600 mt-1 leading-relaxed" :class="isTipComment(reply.content) ? 'text-teal-600 font-medium' : ''" v-html="sanitizeHtml(reply.content)"></p>
                    <div class="flex items-center gap-3 mt-1.5">
                      <span class="text-[11px] text-gray-400">{{ relativeTime(reply.createTime) }}</span>
                      <span class="inline-flex items-center gap-0.5 text-[11px] cursor-pointer select-none" :class="reply.isLiked ? 'text-red-400' : 'text-gray-400'" @click.stop="handleLike(reply)">
                        <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                        <span>{{ reply.likeCount || 0 }}</span>
                      </span>
                      <span @click.stop="deleteReply(reply)" class="text-[11px] text-red-400 cursor-pointer hover:text-red-500" v-if="reply.userId === userStore.info.userId">删除</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="h-20"></div>
            </div>
          </div>
          <!-- 底部回复输入栏 -->
          <div class="flex-shrink-0 border-t border-gray-100 px-5 py-2.5">
            <div class="flex items-center gap-2 bg-gray-50 rounded-full px-4 py-2.5 cursor-pointer hover:bg-gray-100 transition-colors active:scale-[0.98]" @click="showReplyInput = true">
              <span class="text-sm text-gray-400">回复 {{ activeParentComment?.userName || '' }}...</span>
              <div class="flex items-center gap-1.5 ml-auto">
                <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              </div>
            </div>
          </div>

          <!-- ========== LAYER 3: 回复输入面板 ========== -->
          <Transition name="sheet-slide">
            <div v-if="showReplyInput" class="absolute inset-0 z-10">
              <div class="absolute inset-0 bg-black/20" @click="showReplyInput = false"></div>
              <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl" style="padding-bottom: max(20px, env(safe-area-inset-bottom));">
                <div class="flex items-center justify-between px-5 pt-4 pb-2">
                  <span class="text-sm text-gray-500">回复 {{ activeParentComment?.userName || '' }}</span>
                  <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-gray-100" @click="showReplyInput = false">
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                  </button>
                </div>
                <div class="px-5 pb-3">
                  <textarea
                    ref="replyInputRef"
                    v-model="replyText"
                    maxlength="200"
                    placeholder="请输入回复..."
                    rows="4"
                    class="w-full bg-gray-50 rounded-xl p-3.5 text-sm outline-none resize-none border-0 placeholder:text-gray-400 focus:ring-2 focus:ring-teal-100 focus:bg-white transition-all"
                  />
                  <div class="flex items-center justify-between mt-3">
                    <span class="text-xs text-gray-400">{{ replyText.length }}/200</span>
                    <button
                      class="px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all duration-200 active:scale-95"
                      style="background: linear-gradient(135deg, #00BFA5, #00d4b8)"
                      @click="doReply"
                    >发送</button>
                  </div>
                </div>
              </div>
            </div>
          </Transition>
        </div>
      </div>
    </Transition>

    <!-- 举报弹窗 -->
    <div v-if="showReportInput" class="fixed inset-0 bg-black/50 flex items-center justify-center z-[300]" @click.self="showReportInput = false">
      <div class="bg-white rounded-[20px] w-[300px] p-6">
        <div class="text-base font-bold mb-4 text-gray-800">举报评论</div>
        <input v-model="reportReason" placeholder="请填写举报原因" class="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-sm outline-none mb-4 focus:border-teal-300 transition-colors" />
        <div class="flex gap-2.5">
          <button class="flex-1 py-2.5 rounded-[10px] bg-gray-100 text-gray-700 text-sm font-semibold" @click="showReportInput = false">取消</button>
          <button class="flex-1 py-2.5 rounded-[10px] bg-red-500 text-white text-sm font-semibold" @click="doReport">提交举报</button>
        </div>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="showDeleteConfirm" class="fixed inset-0 bg-black/50 flex items-center justify-center z-[300]" @click.self="showDeleteConfirm = false">
      <div class="bg-white rounded-[20px] w-[280px] p-7 text-center">
        <div class="text-base font-bold mb-2.5 text-gray-800">确认删除</div>
        <div class="text-[13px] text-gray-500 mb-6">确定要删除这条评论吗？</div>
        <div class="flex gap-2.5">
          <button class="flex-1 py-[11px] rounded-[10px] bg-gray-100 text-gray-700 text-sm font-semibold" @click="showDeleteConfirm = false">取消</button>
          <button class="flex-1 py-[11px] rounded-[10px] bg-red-500 text-white text-sm font-semibold" @click="doDelete">确认删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import {
  fetchPostComment,
  fetchCommentLike,
  fetchDeleteComment,
  fetchReportComment,
  fetchReplyComment,
  fetchPinComment,
} from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import { toNum } from '@/utils'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import { useLoginModalStore } from '@/store/modules/loginModal'

const props = defineProps<{
  appId: number
  comments: any[]
  ratingStats: any
  isOwner: boolean
  isAdmin: boolean
}>()

const emit = defineEmits<{
  (e: 'refresh'): void
  (e: 'commentCountChanged', count: number): void
}>()

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const maxInlineReplies = 5

// ---- Layer state ----
const showMainSheet = ref(false)
const showReplyPopup = ref(false)
const showReplyInput = ref(false)
const activeParentComment = ref<any>(null)

// ---- Input ----
const commentText = ref('')
const commentRating = ref(5)
const replyText = ref('')
const mainCommentInputRef = ref<HTMLTextAreaElement | null>(null)
const replyInputRef = ref<HTMLTextAreaElement | null>(null)

// ---- Sort ----
const sortBy = ref('newest')
const sortOptions = [
  { label: '最新', value: 'newest' },
  { label: '最热', value: 'hottest' },
]

const sortedComments = computed(() => {
  let list = [...props.comments]
  if (sortBy.value === 'hottest') {
    list.sort((a: any, b: any) => {
      const score = (c: any) => (c.likeCount || 0) + (c.replies?.length || 0) * 0.5
      return score(b) - score(a)
    })
  }
  list.sort((a: any, b: any) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0))
  return list
})

const inlineReplies = (comment: any) => {
  if (!comment.replies) return []
  return comment.replies.slice(0, maxInlineReplies)
}

const popupReplies = computed(() => {
  return activeParentComment.value?.replies || []
})

const replyCountForPopup = computed(() => {
  return activeParentComment.value?.replies?.length || 0
})

// ---- Toast ----
const toastText = ref('')
const showToast = (text: string) => {
  toastText.value = text
  setTimeout(() => { toastText.value = '' }, 2000)
}

// ---- Helpers ----
const relativeTime = (dateStr: string): string => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const min = Math.floor(diff / 60000)
  if (min < 1) return '刚刚'
  if (min < 60) return `${min}分钟前`
  const hours = Math.floor(min / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}天前`
  const months = Math.floor(days / 30)
  if (months < 12) return `${months}个月前`
  return dateStr.slice(0, 10)
}

const starPercent = (star: number) => {
  const dist = props.ratingStats?.distribution || {}
  const max = Math.max(...Object.values(dist) as number[], 1)
  return Math.round(((dist[star] || 0) / max) * 100)
}

const isTipComment = (content: string) => content?.startsWith('[打赏')

const purchaseTypeLabel = (pt: string) => {
  if (pt === 'balance') return '余额已购'
  if (pt === 'points') return '积分已购'
  return '已购买'
}

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    useLoginModalStore().open()
    return false
  }
  return true
}

// ---- Main comment sheet ----
const openMainCommentSheet = () => {
  if (!checkLogin()) return
  showMainSheet.value = true
  commentText.value = ''
  commentRating.value = 5
  nextTick(() => mainCommentInputRef.value?.focus())
}

const submitComment = async () => {
  if (!checkLogin()) return
  if (!commentText.value.trim()) return
  if (commentText.value.length > 200) { showToast('评论最多200字'); return }
  try {
    await fetchPostComment(props.appId, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      rating: commentRating.value,
      content: commentText.value
    })
    commentText.value = ''
    commentRating.value = 5
    showMainSheet.value = false
    emit('refresh')
  } catch (e: any) { ElMessage.error('评论失败，请稍后再试'); console.error('[CommentSection] submitComment failed:', e?.message || e) }
}

// ---- Reply popup ----
const openReplyPopup = (comment: any) => {
  if (!checkLogin()) return
  activeParentComment.value = comment
  showReplyPopup.value = true
  showReplyInput.value = false
  replyText.value = ''
}

const closeReplyPopup = () => {
  showReplyPopup.value = false
  showReplyInput.value = false
  activeParentComment.value = null
  replyText.value = ''
}

const doReply = async () => {
  if (!replyText.value.trim()) return
  if (replyText.value.length > 200) { showToast('回复最多200字'); return }
  if (!activeParentComment.value) return
  try {
    await fetchReplyComment(props.appId, activeParentComment.value.id, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || '匿名',
      content: replyText.value.trim()
    })
    replyText.value = ''
    showReplyInput.value = false
    showToast('回复成功')
    emit('refresh')
  } catch { showToast('回复失败') }
}

// ---- Like ----
const handleLike = async (comment: any) => {
  if (!checkLogin()) return
  try {
    const res: any = await fetchCommentLike(
      props.appId, comment.id, userStore.info.userId || 0
    )
    comment.isLiked = res.liked
    comment.likeCount += res.liked ? 1 : -1
    if (comment.likeCount < 0) comment.likeCount = 0
    showToast(res.liked ? '已点赞' : '已取消')
  } catch (e) { console.error('like err:', e); showToast('操作失败') }
}

// ---- Delete ----
const showDeleteConfirm = ref(false)
const deleteTarget = ref<any>(null)
const menuCommentId = ref(0)

const confirmDelete = (comment: any) => {
  deleteTarget.value = comment
  showDeleteConfirm.value = true
}

const doDelete = async () => {
  if (!deleteTarget.value) return
  try {
    await fetchDeleteComment(props.appId, deleteTarget.value.id, userStore.info.userId || 0)
    showToast('已删除')
    showDeleteConfirm.value = false
    emit('refresh')
  } catch { showToast('删除失败') }
}

const deleteReply = async (reply: any) => {
  try {
    await fetchDeleteComment(props.appId, reply.id, userStore.info.userId || 0)
    showToast('已删除')
    emit('refresh')
  } catch { showToast('删除失败') }
}

// ---- Report ----
const showReportInput = ref(false)
const reportTarget = ref<any>(null)
const reportReason = ref('')

const handleReport = (comment: any) => {
  reportTarget.value = comment
  reportReason.value = ''
  showReportInput.value = true
}

const doReport = async () => {
  if (!reportReason.value.trim()) return
  try {
    await fetchReportComment(props.appId, reportTarget.value.id, userStore.info.userId || 0, reportReason.value)
    showReportInput.value = false
    showToast('举报已提交')
  } catch { showToast('举报失败') }
}

// ---- Pin ----
const canPin = computed(() => {
  if (props.isOwner) return true
  const roles = userStore.info.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return true
  return false
})

const handlePin = async (comment: any) => {
  try {
    const res: any = await fetchPinComment(props.appId, comment.id, userStore.info.userId)
    showToast(res.msg || (comment.isPinned ? '已取消置顶' : '已置顶'))
    emit('refresh')
  } catch { showToast('操作失败') }
}
</script>

<style scoped>
.rating-stats-card {
  background: #f0f2f5;
  border-radius: 12px;
  padding: 12px 14px;
  margin-bottom: 0;
}

.rating-overview {
  display: flex;
  align-items: center;
  gap: 16px;
}

.rating-left {
  text-align: center;
  flex-shrink: 0;
  min-width: 56px;
}

.rating-score {
  font-size: 32px;
  font-weight: 600;
  color: #1f2937;
  line-height: 1;
  letter-spacing: -1px;
}

.rating-count {
  font-size: 11px;
  color: #9ca3af;
  margin-top: 2px;
}

.rating-distribution {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.dist-row {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dist-stars {
  display: flex;
  align-items: center;
  gap: 1px;
  flex-shrink: 0;
}

.dist-star {
  width: 10px;
  height: 10px;
  color: #c4b5fd;
}

.dist-bar {
  flex: 1;
  height: 4px;
  background: #d1d5db;
  border-radius: 2px;
  overflow: hidden;
}

.dist-bar-inner {
  height: 100%;
  border-radius: 2px;
  background: #3D7BEA;
  transition: width .4s ease;
}

.safe-area-bottom {
  padding-bottom: max(12px, env(safe-area-inset-bottom));
}

/* Layer slide animation */
.sheet-slide-enter-active {
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.sheet-slide-leave-active {
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}
.sheet-slide-enter-from .absolute.bottom-0 {
  transform: translateY(100%);
}
.sheet-slide-leave-to .absolute.bottom-0 {
  transform: translateY(100%);
}
.sheet-slide-enter-from .absolute.inset-0:not(.bottom-0) {
  opacity: 0;
}
.sheet-slide-leave-to .absolute.inset-0:not(.bottom-0) {
  opacity: 0;
}
</style>
