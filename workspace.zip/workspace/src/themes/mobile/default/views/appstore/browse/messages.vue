<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">消息中心</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">
      <div v-if="loading" style="text-align:center;padding:40px;color:#9ca3af">加载中...</div>

      <template v-else>
        <!-- 私信 -->
        <div style="margin-bottom:16px">
          <div style="font-size:13px;font-weight:600;color:#6b7280;padding:0 4px;margin-bottom:8px">私信</div>

          <div v-if="conversations.length === 0" style="text-align:center;padding:40px 20px;color:#9ca3af;background:#fff;border-radius:12px">
            <svg style="width:40px;height:40px;margin-bottom:8px" fill="none" stroke="#d1d5db" stroke-width="1.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <div style="font-size:13px">暂无私信</div>
          </div>

          <div
            v-for="conv in conversations"
            :key="conv.userId"
            style="background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center;gap:12px;cursor:pointer"
            @click="goChat(conv)"
          >
            <img
              v-if="conv.avatar"
              :src="conv.avatar"
              style="width:46px;height:46px;border-radius:50%;object-fit:cover;flex-shrink:0"
            />
            <div
              v-else
              style="width:46px;height:46px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:600;color:#fff"
              :style="{ background: avatarColor(conv.userId || conv.userName) }"
            >
              {{ (conv.userName || '?')[0] }}
            </div>

            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;justify-content:space-between">
                <span style="font-size:14px;font-weight:600;color:#1f2937">{{ conv.userName || '用户' }}</span>
                <span style="font-size:11px;color:#bbb;flex-shrink:0;margin-left:8px">{{ fmtTime(conv.lastTime) }}</span>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px">
                <span style="font-size:12px;color:#9ca3af;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ conv.lastMessage || '' }}</span>
                <span
                  v-if="conv.unreadCount > 0"
                  style="display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;border-radius:9px;background:#f44336;color:#fff;font-size:10px;font-weight:600;padding:0 5px;flex-shrink:0;margin-left:8px"
                >{{ conv.unreadCount > 99 ? '99+' : conv.unreadCount }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 通知 -->
        <div style="margin-bottom:16px">
          <div style="font-size:13px;font-weight:600;color:#6b7280;padding:0 4px;margin-bottom:8px">通知</div>
          <div
            style="background:#fff;border-radius:12px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;cursor:pointer"
            @click="goNotifications"
          >
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:40px;height:40px;border-radius:10px;background:#E3F2FD;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <svg style="width:20px;height:20px;color:#2196F3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </div>
              <span style="font-size:14px;font-weight:500;color:#1f2937">系统与互动通知</span>
            </div>
            <svg style="width:16px;height:16px;color:#ccc" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreMessages' })

const router = useRouter()
const userStore = useUserStore()

const conversations = ref<any[]>([])
const loading = ref(true)

const avatarPalette = ['#4A90D9', '#E91E63', '#9C27B0', '#FF9800', '#4CAF50', '#00BCD4', '#795548', '#607D8B']

function avatarColor(seed: any) {
  let hash = 0
  const s = String(seed || '')
  for (let i = 0; i < s.length; i++) hash = s.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

function fmtTime(t: string) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return t.slice(0, 10)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  const m = d.getMonth() + 1
  const day = d.getDate()
  return m + '/' + day
}

function goChat(conv: any) {
  router.push(`/appstore/chatroom-chat/${conv.userId}`)
}

function goNotifications() {
  router.push('/appstore/browse/notifications')
}

onMounted(async () => {
  try {
    const res = await request.get({ url: '/api/messages/conversations' })
    conversations.value = res?.list || res || []
  } catch {
    // ignore
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
</style>
