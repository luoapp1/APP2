<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">邀请码管理</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="flex items-center gap-2 px-3 pt-3 pb-2">
        <select v-model="filterStatus" class="h-9 px-3 text-xs bg-white rounded-lg border-none outline-none text-gray-600 flex-1" @change="loadData(1)">
          <option value="">全部状态</option>
          <option value="unused">未使用</option>
          <option value="used">已使用</option>
        </select>
        <button v-auth="'generate'" class="h-9 px-4 rounded-lg bg-[#FF4757] text-white text-xs font-medium active:bg-[#FF3767] flex-shrink-0" @click="showGenerate">生成邀请码</button>
        <button class="h-9 px-3 rounded-lg bg-white text-[#FF4757] text-xs border border-[#FF4757] font-medium active:bg-red-50 flex-shrink-0" @click="showConfig">基础配置</button>
      </div>

      <div class="bg-white mx-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1.5">
                  <span class="text-sm font-mono font-semibold text-gray-800 tracking-wide">{{ item.code }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' || item.status === 1 ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' || item.status === 1 ? '有效' : '已用' }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.type === 'admin' ? 'bg-indigo-50 text-indigo-600' : 'bg-teal-50 text-teal-600'">{{ item.type === 'admin' ? '系统' : '用户' }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>使用: {{ item.use_count || 0 }}/{{ item.max_uses || 1 }} <span v-if="item.used_by_name" class="ml-2">by {{ item.used_by_name }}</span></div>
                  <div v-if="item.reward_type" class="text-blue-500">{{ formatReward(item) }}</div>
                  <div>过期: {{ item.expires_at || '永久' }} <span v-if="item.used_at" class="ml-2">使用于 {{ item.used_at }}</span></div>
                  <div>创建: {{ item.create_time || '-' }}</div>
                </div>
              </div>
              <button v-auth="'delete'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100 flex-shrink-0 ml-2" @click.stop="confirmDelete(item)">删除</button>
            </div>
          </div>
          <div class="flex items-center justify-between px-4 py-3">
            <span class="text-xs text-gray-400">共 {{ total }} 条</span>
            <div class="flex gap-1">
              <button class="w-7 h-7 rounded text-xs bg-gray-100 text-gray-500 active:bg-gray-200 disabled:opacity-40" :disabled="currentPage <= 1" @click="loadData(currentPage - 1)">&lt;</button>
              <span class="text-xs text-gray-500 px-1 leading-7">{{ currentPage }}/{{ Math.ceil(total / pageSize) || 1 }}</span>
              <button class="w-7 h-7 rounded text-xs bg-gray-100 text-gray-500 active:bg-gray-200 disabled:opacity-40" :disabled="currentPage >= Math.ceil(total / pageSize)" @click="loadData(currentPage + 1)">&gt;</button>
            </div>
          </div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无邀请码</span></div>
      </div>
    </div>

    <div v-if="deleteVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="deleteVisible = false">
      <div class="absolute inset-0 bg-black/50"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[80vw] overflow-hidden">
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-500">确定要删除邀请码「{{ deleteTarget?.code || '' }}」吗？此操作不可撤销。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="deleteVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">删除</button>
        </div>
      </div>
    </div>

    <div v-if="generateVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="generateVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="generateVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[90vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="generateVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span class="text-base font-bold text-gray-800">生成邀请码</span>
          <button v-auth="'generate'" class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-sm font-medium active:opacity-85 shadow-sm shadow-red-200" :disabled="genLoading" @click="doGenerate">{{ genLoading ? '生成中...' : '生成' }}</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div class="grid grid-cols-3 gap-3">
            <div>
              <label class="text-xs text-gray-500 mb-1 block font-medium">数量</label>
              <input v-model.number="genForm.count" type="number" min="1" max="100" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block font-medium">最大使用次数</label>
              <input v-model.number="genForm.maxUses" type="number" min="1" max="9999" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block font-medium">有效期(天)</label>
              <input v-model.number="genForm.expiresDays" type="number" min="0" max="3650" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
          </div>
          <div class="text-[10px] text-gray-400">0天表示永久有效</div>

          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <span class="text-xs text-gray-500 font-medium">奖励设置（选填）</span>
            <div v-for="cur in availableCurrencies" :key="cur.currency_key" class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[10px] text-gray-400 mb-1 block">奖励{{ cur.display_name }}{{ cur.display_symbol ? '(' + cur.display_symbol + ')' : '' }}</label>
                <input v-model.number="genForm.rewards[cur.currency_key]" type="number" min="0" max="999999" step="0.01" placeholder="0=不奖励" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[10px] text-gray-400 mb-1 block">赠送会员</label>
                <select v-model.number="genForm.rewardLevelId" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none">
                  <option :value="null">不赠送</option>
                  <option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
                </select>
              </div>
            </div>
            <div v-if="genForm.rewardLevelId">
              <label class="text-[10px] text-gray-400 mb-1 block">会员天数</label>
              <input v-model.number="genForm.rewardDuration" type="number" min="1" max="3650" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" />
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="resultVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="resultVisible = false">
      <div class="absolute inset-0 bg-black/50"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[85vw] max-h-[80vh] overflow-hidden">
        <div class="p-4 text-center">
          <div class="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-2">
            <svg class="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-3">生成的邀请码</div>
          <div class="space-y-2 max-h-40 overflow-y-auto">
            <div v-for="c in generatedCodes" :key="c" class="text-sm font-mono px-3 py-2.5 bg-[#f0f9ff] rounded-lg border border-dashed border-blue-300 tracking-wider text-center select-all">{{ c }}</div>
          </div>
          <div class="text-[10px] text-amber-500 mt-3">请保存以上邀请码，关闭后将无法再次查看</div>
          <button class="mt-3 px-6 py-2 rounded-full bg-[#FF4757] text-white text-sm font-medium active:bg-[#FF3767]" @click="resultVisible = false">我已保存</button>
        </div>
      </div>
    </div>
    <div v-if="configVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="configVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="configVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[92vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="configVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span class="text-base font-bold text-gray-800">用户邀请码生成配置</span>
          <button class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-sm font-medium active:opacity-85 shadow-sm shadow-red-200" :disabled="cfgSaving" @click="saveConfig">{{ cfgSaving ? '保存中...' : '保存' }}</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">基础设置</div>
            <div class="flex items-center justify-between">
              <div>
                <div class="text-sm font-medium text-gray-700">付费生成开关</div>
                <div class="text-[10px] text-gray-400 mt-0.5">开启后，用户生成含奖励的邀请码需支付余额</div>
              </div>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfgForm.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfgForm.enabled = !cfgForm.enabled">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfgForm.enabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最大有效码数</label>
                <input v-model.number="cfgForm.maxCount" type="number" min="1" max="9999" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" />
                <div class="text-[10px] text-gray-400 mt-0.5">每位用户最多保留的有效邀请码数量</div>
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">最大使用次数上限</label>
                <input v-model.number="cfgForm.maxUsesLimit" type="number" min="1" max="9999" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" />
                <div class="text-[10px] text-gray-400 mt-0.5">单个邀请码允许的最大使用次数</div>
              </div>
            </div>
          </div>

          <div v-for="cur in availableCurrencies" :key="cur.currency_key" class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">{{ cur.display_name }}奖励阶梯定价</div>
            <div class="text-[10px] text-gray-400">{{ cur.display_name }}定价列表</div>
            <div v-for="(item, idx) in (cfgForm.currencyPricing[cur.currency_key] || [])" :key="idx" class="bg-white rounded-xl p-3 space-y-2 relative">
              <div class="flex items-center gap-2">
                <span class="text-xs text-gray-500 w-10">不超过</span>
                <input v-model.number="item.maxAmount" type="number" min="1" max="999999" class="flex-1 h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <span class="text-xs text-gray-500">{{ cur.display_name }}</span>
                <button class="w-6 h-6 rounded-full bg-red-50 text-red-400 flex items-center justify-center active:bg-red-100" @click="cfgForm.currencyPricing[cur.currency_key].splice(idx,1)">
                  <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
              <div class="flex items-center gap-2">
                <span class="text-xs text-gray-500">=</span>
                <input v-model.number="item.totalCost" type="number" min="0" step="0.01" class="w-20 h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <span class="text-xs text-gray-500">余额 /</span>
                <input v-model.number="item.quantity" type="number" min="1" max="999999" class="w-16 h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <span class="text-xs text-gray-500">{{ cur.display_name }}</span>
              </div>
            </div>
            <button class="w-full h-10 rounded-xl border border-dashed border-[#FF4757] text-[#FF4757] text-xs font-medium active:bg-red-50" @click="addCurrencyTier(cur.currency_key)">+ 添加阶梯</button>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">会员奖励定价</div>
            <div class="text-[10px] text-gray-400">会员定价列表</div>
            <div v-for="(item, idx) in cfgForm.pricingList" :key="'m'+idx" class="bg-white rounded-xl p-3">
              <div class="flex items-center gap-2">
                <span class="text-xs text-gray-500">天数</span>
                <input v-model.number="item.days" type="number" min="1" max="3650" class="flex-1 h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <span class="text-xs text-gray-500">=</span>
                <input v-model.number="item.cost" type="number" min="0" step="0.01" class="flex-1 h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <span class="text-xs text-gray-500">余额</span>
                <button class="w-6 h-6 rounded-full bg-red-50 text-red-400 flex items-center justify-center active:bg-red-100" @click="cfgForm.pricingList.splice(idx,1)">
                  <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
            </div>
            <button class="w-full h-10 rounded-xl border border-dashed border-[#FF4757] text-[#FF4757] text-xs font-medium active:bg-red-50" @click="cfgForm.pricingList.push({days:30,cost:100})">+ 添加定价</button>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">VIP折扣设置</div>
            <div class="flex items-center justify-between">
              <div>
                <div class="text-sm font-medium text-gray-700">VIP折扣开关</div>
                <div class="text-[10px] text-gray-400 mt-0.5">开启后，指定等级会员生成邀请码可按会员等级折扣率享受优惠</div>
              </div>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfgForm.vipEnabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfgForm.vipEnabled = !cfgForm.vipEnabled">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfgForm.vipEnabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="cfgForm.vipEnabled">
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">适用会员等级</label>
                <select v-model="cfgForm.vipLevelId" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none">
                  <option :value="null">选择会员等级</option>
                  <option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}（折扣率: {{ lv.discountRate ? (lv.discountRate * 100).toFixed(0) + '%' : '100%' }}）</option>
                </select>
                <div class="text-[10px] text-gray-400 mt-0.5">折扣率自动读取会员等级配置，无需手动设置</div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { fetchInviteList, fetchGenerateInvite, deleteInvite, fetchInviteGenerateConfig, saveInviteGenerateConfig, fetchInviteConfig, saveInviteConfig } from '@/api/invite'
import { fetchGetMembershipLevelList } from '@/api/operation'

defineOptions({ name: 'InviteManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false); const list = ref<any[]>([])
const total = ref(0); const currentPage = ref(1); const pageSize = ref(20)
const filterStatus = ref('')
const levelList = ref<any[]>([])

const loadLevels = async () => {
  try {
    const res: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
    levelList.value = (res && res.records) ? res.records : []
  } catch { levelList.value = [] }
}

const loadData = async (page?: number) => {
  if (page) currentPage.value = page
  loading.value = true
  try {
    const res: any = await fetchInviteList({ page: currentPage.value, pageSize: pageSize.value, status: filterStatus.value || undefined })
    list.value = res.list || []
    total.value = res.total || 0
  } finally { loading.value = false }
}

const formatReward = (row: any): string => {
  const parts: string[] = []
  const types = String(row.reward_type || '').split(',')
  const values = String(row.reward_value || '').split(',')
  const curMap: Record<string, string> = {}
  for (const c of availableCurrencies.value) curMap[c.currency_key] = c.display_name
  for (let i = 0; i < types.length; i++) {
    const t = types[i].trim()
    const v = values[i] || ''
    if (t === 'membership') parts.push(`会员${row.reward_duration || 30}天`)
    else {
      const name = curMap[t] || t
      parts.push(`${v}${name}`)
    }
  }
  return parts.join('、') || '-'
}

const generateVisible = ref(false); const genLoading = ref(false)
const genFormDefault = () => ({ count: 1, maxUses: 1, expiresDays: 0, rewards: {} as Record<string, number>, rewardLevelId: null as number | null, rewardDuration: 30 })
const genForm = reactive(genFormDefault())

const resultVisible = ref(false); const generatedCodes = ref<string[]>([])

const showGenerate = () => {
  Object.assign(genForm, genFormDefault())
  loadCurrencies()
  generateVisible.value = true
}

const doGenerate = async () => {
  genLoading.value = true
  try {
    const rewardTypes: string[] = []
    const rewardValues: string[] = []
    for (const [key, val] of Object.entries(genForm.rewards)) {
      if (Number(val) > 0) { rewardTypes.push(key); rewardValues.push(String(val)) }
    }
    if (genForm.rewardLevelId) { rewardTypes.push('membership'); rewardValues.push(String(genForm.rewardLevelId)) }
    const res: any = await fetchGenerateInvite({
      count: genForm.count, maxUses: genForm.maxUses, expiresDays: genForm.expiresDays,
      rewardType: rewardTypes.join(','), rewardValue: rewardValues.join(','),
      rewardDuration: genForm.rewardDuration
    })
    generatedCodes.value = res.codes || []
    generateVisible.value = false
    resultVisible.value = true
    loadData()
  } finally { genLoading.value = false }
}

const deleteVisible = ref(false); const deleteTarget = ref<any>(null)
const confirmDelete = (item: any) => {
  deleteTarget.value = item
  deleteVisible.value = true
}
const doDelete = async () => {
  if (!deleteTarget.value?.id) return
  deleteVisible.value = false
  try {
    await deleteInvite(deleteTarget.value.id)
    showToast('删除成功')
    loadData()
  } catch { showToast('删除失败', 'error') }
}

const loadCurrencies = async () => {
  if (availableCurrencies.value.length > 0) return
  try {
    const res: any = await fetchInviteGenerateConfig()
    availableCurrencies.value = (res && res.currencies) || []
  } catch { /* ignore */ }
}

onMounted(() => { loadData(); loadLevels(); loadCurrencies() })

const configVisible = ref(false)
const cfgSaving = ref(false)
const availableCurrencies = ref<{ currency_key: string; display_name: string; display_symbol?: string }[]>([])

const addCurrencyTier = (key: string) => {
  if (!cfgForm.currencyPricing[key]) cfgForm.currencyPricing[key] = []
  cfgForm.currencyPricing[key].push({ maxAmount: 100, quantity: 10, totalCost: 1 })
}

const cfgForm = reactive({
  enabled: false,
  maxCount: 5,
  maxUsesLimit: 10,
  currencyPricing: {} as Record<string, { maxAmount: number; quantity: number; totalCost: number }[]>,
  pricingList: [] as { days: number; cost: number }[],
  vipEnabled: false,
  vipLevelId: null as number | null
})

const showConfig = async () => {
  configVisible.value = true
  try {
    const basicRes: any = await fetchInviteConfig()
    cfgForm.maxCount = parseInt(basicRes.invite_user_max) || 5
    cfgForm.maxUsesLimit = parseInt(basicRes.invite_user_max_uses) || 10

    const res: any = await fetchInviteGenerateConfig()
    const c = res || {}
    cfgForm.enabled = c.enabled || false
    availableCurrencies.value = c.currencies || []
    const parsePricing = (arr: any) => Array.isArray(arr) ? arr.map((t: any) => ({ maxAmount: Number(t.maxAmount) || 100, quantity: Number(t.quantity) || 10, totalCost: Number(t.totalCost) || 1 })) : []
    cfgForm.currencyPricing = {}
    // new format: currencyPricing map
    if (c.currencyPricing && typeof c.currencyPricing === 'object') {
      for (const [key, arr] of Object.entries(c.currencyPricing)) {
        cfgForm.currencyPricing[key] = parsePricing(arr)
      }
    }
    // backward compat: old pointsPricing/balancePricing/expPricing
    if (c.pointsPricing && !cfgForm.currencyPricing.points) cfgForm.currencyPricing.points = parsePricing(c.pointsPricing)
    if (c.balancePricing && !cfgForm.currencyPricing.balance) cfgForm.currencyPricing.balance = parsePricing(c.balancePricing)
    if (c.expPricing && !cfgForm.currencyPricing.experience) cfgForm.currencyPricing.experience = parsePricing(c.expPricing)
    for (const ck of availableCurrencies.value) {
      if (!cfgForm.currencyPricing[ck.currency_key]) cfgForm.currencyPricing[ck.currency_key] = [{ maxAmount: 100, quantity: 10, totalCost: 1 }]
    }
    const pricing = c.membershipPricing || {}
    cfgForm.pricingList = Object.entries(pricing).map(([days, cost]) => ({ days: Number(days), cost: Number(cost) }))
    if (cfgForm.pricingList.length === 0) cfgForm.pricingList.push({ days: 30, cost: 100 })
    cfgForm.vipEnabled = c.vipDiscount?.enabled || false
    cfgForm.vipLevelId = c.vipDiscount?.levelId || null
  } catch {
    for (const ck of availableCurrencies.value) {
      cfgForm.currencyPricing[ck.currency_key] = [{ maxAmount: 100, quantity: 10, totalCost: 1 }]
    }
    cfgForm.pricingList = [{ days: 30, cost: 100 }]
  }
}

const saveConfig = async () => {
  cfgSaving.value = true
  try {
    const pricing: Record<string, number> = {}
    for (const item of cfgForm.pricingList) {
      if (item.days > 0 && item.cost > 0) pricing[String(item.days)] = item.cost
    }
    await saveInviteGenerateConfig({
      enabled: cfgForm.enabled,
      currencyPricing: Object.fromEntries(
        Object.entries(cfgForm.currencyPricing).map(([k, v]) => [k, v.filter(t => t.maxAmount > 0)])
      ),
      membershipPricing: pricing,
      vipDiscount: cfgForm.vipEnabled ? { enabled: true, levelId: cfgForm.vipLevelId } : { enabled: false, levelId: null }
    })
    await saveInviteConfig({
      invite_user_max: cfgForm.maxCount,
      invite_user_max_uses: cfgForm.maxUsesLimit
    })
    showToast('配置已保存')
    configVisible.value = false
  } catch (e: any) {
    showToast(e?.msg || e?.message || '保存失败', 'error')
  } finally {
    cfgSaving.value = false
  }
}
</script>
