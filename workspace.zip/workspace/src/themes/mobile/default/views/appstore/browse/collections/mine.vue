<template>
  <div class="mine-collections-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">我的合集</span>
      <button class="nav-action" @click="openCreate">新建</button>
    </div>

    <div class="page-content">
      <!-- 未登录 -->
      <div v-if="!isLogin" class="login-hint">
        <p>请先登录</p>
        <button class="btn btn-primary" @click="$router.push('/appstore/login')">去登录</button>
      </div>

      <LoadingState v-else-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadData" />
      <EmptyState v-else-if="!list.length" text="你还没有创建合集" action-text="创建第一个合集" @action="openCreate" />
      <div v-else class="collection-list">
        <div v-for="item in list" :key="item.id" class="collection-card">
          <div class="card-cover" @click="$router.push(`/appstore/collection/${item.id}`)">
            <img v-if="item.coverUrl" :src="item.coverUrl" loading="lazy" />
            <div v-else class="card-cover-placeholder">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
            </div>
          </div>
          <div class="card-body" @click="$router.push(`/appstore/collection/${item.id}`)">
            <div class="card-name">{{ item.name }}</div>
            <div class="card-meta">
              <span>{{ item.appCount || 0 }} 款应用</span>
              <span>{{ item.viewCount || 0 }} 浏览</span>
              <span>{{ item.likes || 0 }} 赞</span>
            </div>
            <div class="card-status">
              <span v-if="item.status === 'pending'" class="tag-pending">审核中</span>
              <span v-else-if="item.status === 'rejected'" class="tag-rejected">已拒绝</span>
              <span v-else class="tag-active" :class="{ private: !item.isPublic }">{{ item.isPublic ? '公开' : '私密' }}</span>
            </div>
          </div>
          <div class="card-actions">
            <button class="btn-sm" @click="openEdit(item)">编辑</button>
            <button class="btn-sm btn-sm-outline" @click="togglePublic(item)">
              {{ item.isPublic ? '设为私密' : '设为公开' }}
            </button>
            <button class="btn-sm btn-sm-danger" @click="confirmDelete(item)">删除</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 新建/编辑对话框 -->
    <div v-if="showDialog" class="dialog-overlay" @click.self="cancelDialog">
      <div class="dialog-panel">
        <div class="dialog-title">{{ isCreate ? '新建合集' : '编辑合集' }}</div>
        <div class="dialog-form">
          <div class="form-item">
            <label class="form-label">名称</label>
            <input v-model="form.name" class="form-input" placeholder="合集名称" />
          </div>
          <div class="form-item">
            <label class="form-label">描述</label>
            <textarea v-model="form.description" class="form-input form-textarea" placeholder="合集描述" rows="2" />
          </div>
          <div class="form-item">
            <label class="form-label">封面图URL</label>
            <input v-model="form.coverUrl" class="form-input" placeholder="封面图片链接" />
          </div>
          <div class="form-item">
            <label class="checkbox-label">
              <input type="checkbox" v-model="form.isPublic" /> 公开合集（公开后所有人可见，需审核）
            </label>
          </div>
        </div>
        <div class="dialog-actions">
          <button class="btn" @click="cancelDialog">取消</button>
          <button class="btn btn-primary" :disabled="saving" @click="doSave">{{ saving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>

    <!-- 删除确认 -->
    <div v-if="showDeleteDialog" class="dialog-overlay" @click.self="showDeleteDialog = false">
      <div class="dialog-panel dialog-small">
        <div class="dialog-title">确认删除</div>
        <p class="dialog-msg">确定要删除合集「{{ deletingItem?.name }}」吗？</p>
        <div class="dialog-actions">
          <button class="btn" @click="showDeleteDialog = false">取消</button>
          <button class="btn btn-danger" :disabled="saving" @click="doDelete">确认删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import {
  fetchMyCollections, fetchCreateCollection, fetchUpdateCollection, fetchDeleteCollection,
  fetchToggleCollectionPublic
} from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const userStore = useUserStore()
const route = useRoute()
const isLogin = computed(() => userStore.isLogin)

const loading = ref(false)
const error = ref('')
const list = ref([])
const saving = ref(false)

const showDialog = ref(false)
const isCreate = ref(true)
const editingId = ref(null)
const form = reactive({ name: '', description: '', coverUrl: '', isPublic: true })

const showDeleteDialog = ref(false)
const deletingItem = ref(null)

function resetForm() {
  form.name = ''; form.description = ''; form.coverUrl = ''; form.isPublic = true
  editingId.value = null
}

function openCreate() { isCreate.value = true; resetForm(); showDialog.value = true }
function openEdit(item) {
  isCreate.value = false; editingId.value = item.id
  form.name = item.name || ''; form.description = item.description || ''
  form.coverUrl = item.coverUrl || ''; form.isPublic = item.isPublic !== false
  showDialog.value = true
}
function cancelDialog() { showDialog.value = false; resetForm() }

async function doSave() {
  if (!form.name.trim()) { alert('请输入合集名称'); return }
  saving.value = true
  try {
    const params = { name: form.name, description: form.description, coverUrl: form.coverUrl, isPublic: form.isPublic }
    if (isCreate.value) { await fetchCreateCollection(params) }
    else { await fetchUpdateCollection(editingId.value, params) }
    showDialog.value = false; resetForm(); await loadData()
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '保存失败') }
  finally { saving.value = false }
}

async function togglePublic(item) {
  saving.value = true
  try { await fetchToggleCollectionPublic(item.id, !item.isPublic); item.isPublic = !item.isPublic; alert('已更新') }
  catch (e) { alert(e?.response?.data?.msg || e?.message || '操作失败') }
  finally { saving.value = false }
}

function confirmDelete(item) { deletingItem.value = item; showDeleteDialog.value = true }
async function doDelete() {
  saving.value = true
  try { await fetchDeleteCollection(deletingItem.value.id); showDeleteDialog.value = false; deletingItem.value = null; await loadData() }
  catch (e) { alert(e?.response?.data?.msg || e?.message || '删除失败') }
  finally { saving.value = false }
}

async function loadData() {
  loading.value = true; error.value = ''
  try { const res = await fetchMyCollections(); list.value = res || [] }
  catch (e) { error.value = e?.response?.data?.msg || e?.message || '加载失败' }
  finally { loading.value = false }
}

onMounted(() => {
  if (!isLogin.value) return
  loadData().then(() => {
    const editId = route.query.id
    if (editId) {
        const item = list.value.find((x) => String(x.id) === String(editId))
      if (item) openEdit(item)
    }
  })
})
</script>

<style scoped>
.mine-collections-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }
.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.nav-action { background: #6366F1; color: #fff; border: none; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
.nav-action:active { background: #4F46E5; }
.page-content { padding: 16px; }

.login-hint { text-align: center; padding: 60px 20px; color: #666; }
.login-hint p { margin-bottom: 16px; font-size: 15px; }

.collection-list { display: flex; flex-direction: column; gap: 12px; }
.collection-card { background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
.card-cover { width: 100%; height: 100px; overflow: hidden; cursor: pointer; }
.card-cover img { width: 100%; height: 100%; object-fit: cover; }
.card-cover-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #F59E0B, #EF4444); display: flex; align-items: center; justify-content: center; }
.card-body { padding: 10px 14px; cursor: pointer; }
.card-name { font-size: 15px; font-weight: 700; color: #1a1a1a; }
.card-meta { display: flex; gap: 12px; margin-top: 4px; font-size: 11px; color: #999; }
.card-status { margin-top: 4px; }
.tag-active { font-size: 10px; padding: 1px 6px; border-radius: 4px; background: #D1FAE5; color: #059669; }
.tag-active.private { background: #FEF3C7; color: #D97706; }
.tag-pending { font-size: 10px; padding: 1px 6px; border-radius: 4px; background: #EEF2FF; color: #6366F1; }
.tag-rejected { font-size: 10px; padding: 1px 6px; border-radius: 4px; background: #FEE2E2; color: #DC2626; }
.card-actions { display: flex; gap: 6px; padding: 0 14px 10px; }
.btn-sm { padding: 4px 10px; border-radius: 6px; border: 1px solid #e5e7eb; background: #fff; font-size: 11px; cursor: pointer; color: #555; }
.btn-sm:active { background: #f5f5f5; }
.btn-sm-outline { color: #6366F1; border-color: #C7D2FE; }
.btn-sm-danger { color: #EF4444; border-color: #FEE2E2; }
.btn-sm-danger:active { background: #FEF2F2; }

.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; display: flex; align-items: flex-end; justify-content: center; }
.dialog-panel { background: #fff; width: 100%; max-width: 420px; border-radius: 20px 20px 0 0; padding: 20px 16px max(20px, env(safe-area-inset-bottom)); max-height: 80vh; overflow-y: auto; }
.dialog-small { border-radius: 20px; margin: 0 16px 200px; }
.dialog-title { font-size: 17px; font-weight: 700; color: #1a1a1a; margin-bottom: 16px; text-align: center; }
.dialog-msg { font-size: 14px; color: #666; text-align: center; margin-bottom: 20px; }
.dialog-form { display: flex; flex-direction: column; gap: 12px; }
.form-item { display: flex; flex-direction: column; gap: 4px; }
.form-label { font-size: 12px; font-weight: 600; color: #555; }
.form-input { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box; }
.form-input:focus { border-color: #6366F1; }
.form-textarea { resize: vertical; }
.checkbox-label { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #555; cursor: pointer; }
.dialog-actions { display: flex; align-items: center; justify-content: flex-end; gap: 10px; margin-top: 16px; }
.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; font-weight: 500; }
.btn:active { background: #f5f5f5; }
.btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.btn-primary:active { background: #4F46E5; }
.btn-danger { background: #EF4444; color: #fff; border-color: #EF4444; }
.btn-danger:active { background: #DC2626; }
.btn:disabled { opacity: .5; cursor: not-allowed; }
</style>
