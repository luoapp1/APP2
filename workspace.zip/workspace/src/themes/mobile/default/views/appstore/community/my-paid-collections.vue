<template>
  <div class="my-collections-page">
    <div class="mc-head">
      <div class="mc-nav">
        <button class="mc-nav-back" @click="$router.back()">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span class="mc-nav-title">已购合集</span>
        <div class="mc-nav-create-ph"></div>
      </div>
    </div>

    <div class="mc-body" v-if="!loading">
      <div
        v-for="c in paidCollections"
        :key="c.id"
        class="col-card"
        @click="openCollection(c)"
      >
        <div class="col-cover">
          <img v-if="c.cover_image" :src="c.cover_image" class="col-cover-img"  loading="lazy" />
          <div v-else class="col-cover-ph"></div>
        </div>
        <div class="col-body">
          <div class="col-title">{{ c.title }}</div>
          <div class="col-desc" v-if="c.description">{{ c.description }}</div>
          <div class="col-stats">
            <span class="col-stat">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              {{ c.post_count }}篇
            </span>
            <span class="col-stat">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
              {{ c.view_count || 0 }}
            </span>
            <span v-if="c.subscribe_count > 0" class="col-stat col-stat-subs">{{ c.subscribe_count }}人已购</span>
          </div>
          <div class="col-footer">
            <span class="col-price-bought">已购买</span>
          </div>
        </div>
      </div>
      <div v-if="paidCollections.length === 0" class="mc-empty">
        <div class="mc-empty-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
        </div>
        <div class="mc-empty-text">还没有购买任何合集</div>
      </div>
    </div>
    <div v-else class="mc-loading">加载中...</div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchPaidCollections } from '@/api/community'

const router = useRouter()

const paidCollections = ref<any[]>([])
const loading = ref(true)

function openCollection(c: any) { router.push(`/community/collection/${c.id}`) }

async function loadPaidCollections() {
  loading.value = true
  try {
    const data: any = await fetchPaidCollections()
    paidCollections.value = data?.list || []
  } catch { paidCollections.value = [] }
  loading.value = false
}

onMounted(() => { loadPaidCollections() })
</script>

<style scoped>
.my-collections-page {
  min-height: 100vh;
  background: #f5f6fa;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}
.mc-head {
  position: sticky;
  top: 0;
  z-index: 10;
  background: #fff;
}
.mc-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 46px;
  padding: 0 16px;
  border-bottom: 1px solid #f0f0f0;
}
.mc-nav-back { background: none; border: none; padding: 4px; color: #333; cursor: pointer; display: flex; align-items: center; }
.mc-nav-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
.mc-nav-create-ph { width: 52px; }
.mc-body { padding: 12px 14px; }
.mc-loading { text-align: center; padding: 60px 0; color: #999; }

.col-card {
  background: #fff;
  border-radius: 14px;
  margin-bottom: 16px;
  overflow: hidden;
  cursor: pointer;
  box-shadow: 0 2px 12px rgba(0,0,0,.06);
  transition: transform .2s, box-shadow .2s;
}
.col-card:active { transform: scale(.985); box-shadow: 0 4px 16px rgba(0,0,0,.1); }
.col-cover { position: relative; height: 140px; overflow: hidden; }
.col-cover-img { width: 100%; height: 100%; object-fit: cover; }
.col-cover-ph { width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); }
.col-body { padding: 14px; }
.col-title { font-size: 16px; font-weight: 700; color: #1a1a2e; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.col-desc { font-size: 13px; color: #999; margin-top: 6px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.5; }
.col-stats { display: flex; gap: 14px; margin-top: 10px; }
.col-stat { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: #b0b0b0; }
.col-stat-subs { color: #6366f1; font-weight: 500; }
.col-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; padding-top: 12px; border-top: 1px solid #f5f5f5; }
.col-price-bought { font-size: 14px; font-weight: 600; color: #67c23a; }
.mc-empty { display: flex; flex-direction: column; align-items: center; padding: 60px 20px; }
.mc-empty-icon { margin-bottom: 12px; }
.mc-empty-text { font-size: 15px; color: #909399; margin-bottom: 16px; }
.mc-empty-btn { background: #6366f1; color: #fff; border: none; padding: 10px 28px; border-radius: 20px; font-size: 14px; cursor: pointer; }
</style>
