<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">充值金额配置</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
      <template v-else>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div v-for="(item, idx) in amounts" :key="idx" class="px-3 py-3 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center gap-2">
              <span class="text-xs text-gray-400 w-5 shrink-0">{{ idx + 1 }}</span>
              <div class="flex-1 min-w-0" @click="openDialog(idx)">
                <div class="flex items-center gap-2">
                  <span class="text-base font-bold text-[#3b82f6]">￥{{ item.amount }}</span>
                  <span v-if="item.label" class="text-xs text-gray-500 bg-[#f5f6f8] px-2 py-0.5 rounded">{{ item.label }}</span>
                  <span v-if="item.first_only" class="text-xs text-red-500 bg-red-50 px-2 py-0.5 rounded">首充</span>
                  <span v-if="item.status === 0" class="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded">禁用</span>
                </div>
                <div class="flex gap-1 flex-wrap mt-1">
                  <template v-if="hasAnyGift(item)">
                    <span v-if="item.gift_balance" class="gift-dot gift-balance">余额+{{ item.gift_balance }}</span>
                    <span v-if="item.gift_points" class="gift-dot gift-points">积分+{{ item.gift_points }}</span>
                    <span v-if="item.gift_experience" class="gift-dot gift-exp">经验+{{ item.gift_experience }}</span>
                    <span v-if="item._couponSummary" class="gift-dot gift-coupon">{{ item._couponSummary }}</span>
                    <span v-if="item._titleName" class="gift-dot gift-title">{{ item._titleName }}</span>
                    <span v-if="item._frameName" class="gift-dot gift-frame">{{ item._frameName }}</span>
                    <span v-if="item._memberName" class="gift-dot gift-member">{{ item._memberName }}{{ item.gift_member_days }}天</span>
                  </template>
                  <span v-else class="text-xs text-gray-300">无赠品</span>
                </div>
              </div>
              <button class="w-8 h-8 rounded-lg flex items-center justify-center text-red-400 active:bg-red-50 shrink-0" @click="removeAmount(idx)">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
          </div>
        </div>

        <div class="mx-3 mt-2">
          <button class="w-full h-10 bg-white text-[#FF4757] text-sm rounded-xl border border-dashed border-[#FF4757]/30 font-medium active:bg-red-50" @click="openDialog(-1)">+ 添加金额档位</button>
        </div>

        <div class="mx-3 mt-4 mb-8">
          <button class="w-full h-11 bg-[#FF4757] text-white text-sm rounded-xl font-medium active:opacity-80" :disabled="saving" @click="saveAll">{{ saving ? '保存中...' : '保存全部配置' }}</button>
        </div>
      </template>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex flex-col bg-white" style="top:0">
      <div class="flex items-center justify-between px-3 py-3 border-b border-gray-100 bg-white sticky top-0 z-10">
        <button class="text-[#FF4757] text-sm font-medium active:opacity-70" @click="dialogVisible = false">取消</button>
        <span class="text-base font-bold text-gray-800">{{ editIdx >= 0 ? '编辑金额档位' : '添加金额档位' }}</span>
        <button class="text-[#FF4757] text-sm font-medium active:opacity-70" @click="confirmDialog">确定</button>
      </div>
      <div v-if="form" class="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        <div class="section-block">
          <div class="section-label">基本信息</div>
          <div class="space-y-2">
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-16 shrink-0">金额</span>
              <span class="text-sm font-bold text-[#3b82f6]">￥</span>
              <input v-model.number="form.amount" type="number" step="0.01" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-16 shrink-0">标签</span>
              <input v-model="form.label" placeholder="如: 热门推荐" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-16 shrink-0">排序</span>
              <input v-model.number="form.sort_order" type="number" class="w-20 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
            <div class="flex items-center gap-4">
              <label class="flex items-center gap-1 text-sm text-gray-500">
                <input v-model="form.status" type="checkbox" :true-value="1" :false-value="0" class="w-4 h-4 rounded accent-[#FF4757]" /> 启用
              </label>
              <label class="flex items-center gap-1 text-sm text-gray-500">
                <input v-model="form.first_only" type="checkbox" class="w-4 h-4 rounded accent-[#FF4757]" /> 仅首充
              </label>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-16 shrink-0">文案</span>
              <input v-model="form.discount" placeholder="如: 限时加赠50积分" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
          </div>
        </div>

        <div class="section-block">
          <div class="section-label">数值赠送</div>
          <div class="flex gap-2">
            <div class="flex-1">
              <div class="text-xs text-gray-400 mb-1">余额</div>
              <input v-model.number="form.gift_balance" type="number" step="0.01" class="w-full h-9 px-2 text-sm bg-[#ecfdf5] rounded-lg border-none outline-none" />
            </div>
            <div class="flex-1">
              <div class="text-xs text-gray-400 mb-1">积分</div>
              <input v-model.number="form.gift_points" type="number" class="w-full h-9 px-2 text-sm bg-[#fef3c7] rounded-lg border-none outline-none" />
            </div>
            <div class="flex-1">
              <div class="text-xs text-gray-400 mb-1">经验</div>
              <input v-model.number="form.gift_experience" type="number" class="w-full h-9 px-2 text-sm bg-[#ede9fe] rounded-lg border-none outline-none" />
            </div>
          </div>
        </div>

        <div class="section-block">
          <div class="flex items-center justify-between mb-2">
            <span class="section-label" style="margin-bottom:0">优惠券赠送</span>
            <button class="text-xs text-[#FF4757] font-medium active:opacity-70" @click="addCoupon">+ 添加</button>
          </div>
          <div v-if="form._couponItems && form._couponItems.length" class="space-y-2">
            <div v-for="(ci, ciIdx) in form._couponItems" :key="ciIdx" class="flex items-center gap-2">
              <select v-model="ci.id" class="flex-1 h-8 px-1 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-500">
                <option :value="0">选择优惠券</option>
                <option v-for="c in couponList" :key="c.id" :value="c.id">{{ c.name }}</option>
              </select>
              <span class="text-xs text-gray-400">x</span>
              <input v-model.number="ci.count" type="number" min="1" max="99" class="w-14 h-8 px-1 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
              <button class="w-6 h-6 rounded flex items-center justify-center text-red-400 active:bg-red-50" @click="form._couponItems.splice(ciIdx, 1)">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
          </div>
          <div v-else class="text-xs text-gray-300 py-1">暂无优惠券</div>
        </div>

        <div class="section-block">
          <div class="section-label">权益赠送</div>
          <div class="space-y-2">
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-14 shrink-0">称号</span>
              <select v-model="form.gift_title_id" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-500">
                <option :value="0">不赠送</option>
                <option v-for="t in titleList" :key="t.id" :value="t.id">{{ t.name }}</option>
              </select>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-14 shrink-0">头像框</span>
              <select v-model="form.gift_avatar_frame_id" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-500">
                <option :value="0">不赠送</option>
                <option v-for="f in frameList" :key="f.id" :value="f.id">{{ f.name }}</option>
              </select>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-14 shrink-0">会员</span>
              <select v-model="form.gift_member_level_id" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-500">
                <option :value="0">不赠送</option>
                <option v-for="m in memberLevelList" :key="m.id" :value="m.id">{{ m.name }}</option>
              </select>
            </div>
            <div v-if="form.gift_member_level_id" class="flex items-center gap-2">
              <span class="text-sm text-gray-500 w-14 shrink-0">天数</span>
              <input v-model.number="form.gift_member_days" type="number" min="0" max="3650" class="w-24 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'RechargeAmountsMobile' })

interface CouponItem { id: number; count: number }

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false); const saving = ref(false)
const dialogVisible = ref(false)
const editIdx = ref(-1)
const form = ref<any>(null)
const couponList = ref<any[]>([])
const titleList = ref<any[]>([])
const frameList = ref<any[]>([])
const memberLevelList = ref<any[]>([])
const amounts = ref<any[]>([])

function hasAnyGift(item: any) {
  return item.gift_balance || item.gift_points || item.gift_experience
    || (item._couponItems && item._couponItems.length)
    || item.gift_title_id || item.gift_avatar_frame_id
    || (item.gift_member_level_id && item.gift_member_days)
    || item.first_only
}

function buildCouponSummary(items: CouponItem[]) {
  if (!items || !items.length) return ''
  return items.map(ci => {
    const c = couponList.value.find((x: any) => x.id === ci.id)
    const label = c ? c.name : '券'
    return ci.count > 1 ? `${label}x${ci.count}` : label
  }).join(' ')
}

function refreshSummaries() {
  amounts.value.forEach(a => {
    a._couponSummary = buildCouponSummary(a._couponItems)
    a._titleName = a.gift_title_id ? (titleList.value.find((t: any) => t.id === a.gift_title_id)?.name || '') : ''
    a._frameName = a.gift_avatar_frame_id ? (frameList.value.find((f: any) => f.id === a.gift_avatar_frame_id)?.name || '') : ''
    a._memberName = a.gift_member_level_id ? (memberLevelList.value.find((m: any) => m.id === a.gift_member_level_id)?.name || '') : ''
  })
}

function addCoupon() {
  if (!form.value._couponItems) form.value._couponItems = []
  form.value._couponItems.push({ id: 0, count: 1 })
}

function emptyForm() {
  return {
    amount: 0, label: '', discount: '', status: 1, sort_order: 0,
    gift_balance: 0, gift_points: 0, gift_experience: 0,
    _couponItems: [] as CouponItem[],
    gift_title_id: 0, gift_avatar_frame_id: 0,
    gift_member_level_id: 0, gift_member_days: 0,
    first_only: false
  }
}

function cloneForm(row: any) {
  return {
    amount: row.amount, label: row.label, discount: row.discount,
    status: row.status, sort_order: row.sort_order,
    gift_balance: row.gift_balance, gift_points: row.gift_points, gift_experience: row.gift_experience,
    _couponItems: (row._couponItems || []).map((ci: CouponItem) => ({ ...ci })),
    gift_title_id: row.gift_title_id || 0,
    gift_avatar_frame_id: row.gift_avatar_frame_id || 0,
    gift_member_level_id: row.gift_member_level_id || 0,
    gift_member_days: row.gift_member_days || 0,
    first_only: row.first_only
  }
}

function openDialog(idx: number) {
  editIdx.value = idx
  form.value = idx >= 0 ? cloneForm(amounts.value[idx]) : emptyForm()
  dialogVisible.value = true
}

function confirmDialog() {
  if (editIdx.value >= 0) {
    Object.assign(amounts.value[editIdx.value], form.value)
  } else {
    amounts.value.push({ ...form.value })
  }
  dialogVisible.value = false
  refreshSummaries()
}

const fetchRefData = async () => {
  const loadCoupons = async () => {
    try { const d: any = await request.get({ url: '/api/coupon/list', params: { status: '1', size: 9999 } }); couponList.value = d?.records || [] } catch {}
  }
  const loadTitles = async () => {
    try { const d: any = await request.get({ url: '/api/title/list' }); titleList.value = d || [] } catch {}
  }
  const loadFrames = async () => {
    try { const d: any = await request.get({ url: '/api/avatar-frame/list' }); frameList.value = d || [] } catch {}
  }
  const loadLevels = async () => {
    try { const d: any = await request.get({ url: '/api/membership/levels' }); memberLevelList.value = d || [] } catch {}
  }
  await Promise.allSettled([loadCoupons(), loadTitles(), loadFrames(), loadLevels()])
}

function mapRow(row: any) {
  let couponItems: CouponItem[] = []
  if (row.gift_coupon_ids) {
    try {
      const raw = typeof row.gift_coupon_ids === 'string' ? JSON.parse(row.gift_coupon_ids) : row.gift_coupon_ids
      if (Array.isArray(raw)) {
        couponItems = raw.map((x: any) => typeof x === 'object' ? { id: Number(x.id) || 0, count: Number(x.count) || 1 } : { id: Number(x) || 0, count: 1 })
      }
    } catch {}
  }
  return {
    amount: Number(row.amount) || 0,
    label: row.label || '',
    discount: row.discount || '',
    status: Number(row.status),
    sort_order: Number(row.sort_order) || 0,
    gift_balance: Number(row.gift_balance) || 0,
    gift_points: Number(row.gift_points) || 0,
    gift_experience: Number(row.gift_experience) || 0,
    _couponItems: couponItems,
    gift_title_id: Number(row.gift_title_id) || 0,
    gift_avatar_frame_id: Number(row.gift_avatar_frame_id) || 0,
    gift_member_level_id: Number(row.gift_member_level_id) || 0,
    gift_member_days: Number(row.gift_member_days) || 0,
    first_only: !!row.first_only,
    _couponSummary: buildCouponSummary(couponItems),
    _titleName: row.gift_title_id ? (titleList.value.find((t: any) => t.id === row.gift_title_id)?.name || '') : '',
    _frameName: row.gift_avatar_frame_id ? (frameList.value.find((f: any) => f.id === row.gift_avatar_frame_id)?.name || '') : '',
    _memberName: row.gift_member_level_id ? (memberLevelList.value.find((m: any) => m.id === row.gift_member_level_id)?.name || '') : ''
  }
}

const fetchData = async () => {
  loading.value = true
  try {
    const data: any = await request.get({ url: '/api/recharge/amounts' })
    amounts.value = (data || []).map(mapRow)
    refreshSummaries()
  } catch {}
  loading.value = false
}

const removeAmount = (idx: number) => {
  amounts.value.splice(idx, 1)
}

const saveAll = async () => {
  saving.value = true
  try {
    const payload = {
      amounts: amounts.value.map(a => ({
        amount: a.amount, label: a.label, discount: a.discount, status: a.status,
        sort_order: a.sort_order || 0,
        gift_balance: a.gift_balance || 0, gift_points: a.gift_points || 0, gift_experience: a.gift_experience || 0,
        gift_coupon_ids: (a._couponItems || []).filter((ci: CouponItem) => ci.id > 0),
        gift_title_id: a.gift_title_id || 0, gift_avatar_frame_id: a.gift_avatar_frame_id || 0,
        gift_member_level_id: Number(a.gift_member_level_id) || 0, gift_member_days: Number(a.gift_member_days) || 0,
        first_only: a.first_only ? 1 : 0
      }))
    }
    await request.post({ url: '/api/admin/recharge/amounts', data: payload })
    showToast('保存成功')
    fetchData()
  } catch { showToast('保存失败', 'error') }
  saving.value = false
}

onMounted(async () => {
  await fetchRefData()
  fetchData()
})
</script>

<style scoped>
.gift-dot { font-size: 10px; padding: 0px 6px; border-radius: 8px; line-height: 16px; white-space: nowrap; }
.gift-balance { background: #ecfdf5; color: #059669; }
.gift-points { background: #fef3c7; color: #d97706; }
.gift-exp { background: #ede9fe; color: #7c3aed; }
.gift-coupon { background: #fce7f3; color: #db2777; }
.gift-title { background: #e0f2fe; color: #0284c7; }
.gift-frame { background: #fef9c3; color: #ca8a04; }
.gift-member { background: #dcfce7; color: #16a34a; }

.section-block { padding-bottom: 4px; }
.section-label { font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px; }
</style>
