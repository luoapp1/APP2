<template>
  <teleport to="body">
    <div v-if="visible" class="mbp-mask" @click.self="close">
      <div class="mbp-popup">
        <!-- 顶部蓝色区域 -->
        <div class="mbp-header">
          <div class="mbp-header-side" />
          <div class="mbp-header-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
            <span class="mbp-header-title">确认购买</span>
          </div>
          <div class="mbp-header-side">
            <span class="mbp-close" @click="close">&times;</span>
          </div>
        </div>

        <div class="mbp-body">
          <!-- 加载中 -->
          <div v-if="loading" class="mbp-loading">
            <div class="mbp-spinner" />
            <span>加载中...</span>
          </div>

          <template v-else-if="product">
            <!-- 商品名称 -->
            <div class="mbp-product-row">
              <span class="mbp-product-tag" :class="product.priceType === 'points' ? 'mbp-tag-points' : 'mbp-tag-balance'">
                {{ product.priceType === 'points' ? '积分兑换' : '付费商品' }}
              </span>
              <span class="mbp-product-name">{{ product.name }}<template v-if="durationLabel">（{{ durationLabel }}）</template></span>
            </div>

            <!-- 规格选择 -->
            <div v-if="product.options && product.options.length > 1" class="mbp-options">
              <div
                v-for="opt in product.options"
                :key="opt.id"
                class="mbp-opt-item"
                :class="{ 'mbp-opt-active': selectedOption?.id === opt.id }"
                @click="selectedOption = opt"
              >
                <span class="mbp-opt-name">{{ getOptionLabel(opt) }}</span>
                <span class="mbp-opt-price">
                  {{ paymentMethod === 'points' ? (opt.pointsPrice || opt.price) + '积分' : '¥' + opt.price }}
                </span>
              </div>
            </div>

            <!-- 价格行 -->
            <div class="mbp-price-row">
              <span class="mbp-price-label">价格</span>
              <span class="mbp-price-value">
                <template v-if="couponDiscount > 0">
                  <span class="mbp-price-original">{{ paymentMethod === 'points' ? currentPrice + ' 积分' : '¥' + currentPrice }}</span>
                  <span>{{ paymentMethod === 'points' ? (currentPrice - couponDiscount) + ' 积分' : '¥' + (currentPrice - couponDiscount) }}</span>
                </template>
                <template v-else>
                  {{ paymentMethod === 'points' ? currentPrice + ' 积分' : '¥' + currentPrice }}
                </template>
              </span>
            </div>

            <!-- 优惠券 -->
            <div v-if="coupons.length" class="mbp-coupon-section">
              <div class="mbp-coupon-label">优惠券</div>
              <div class="mbp-coupon-trigger" @click="showCoupons = !showCoupons">
                <span v-if="selectedCoupon" class="mbp-coupon-selected">
                  {{ selectedCoupon.name || '优惠券' }} -{{ fmtCouponDiscount(selectedCoupon) }}
                </span>
                <span v-else class="mbp-coupon-placeholder">请选择优惠券（{{ coupons.length }}张可用）</span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
              </div>
              <div v-if="showCoupons" class="mbp-coupon-dropdown">
                <div
                  v-for="c in coupons"
                  :key="c.userCouponId"
                  class="mbp-coupon-item"
                  :class="{ 'mbp-coupon-active': selectedCoupon?.userCouponId === c.userCouponId }"
                  @click="selectCoupon(c)"
                >
                  <span class="mbp-coupon-name">{{ c.name || '优惠券' }}</span>
                  <span class="mbp-coupon-discount">-{{ fmtCouponDiscount(c) }}</span>
                </div>
              </div>
            </div>
            <div v-else class="mbp-coupon-none">
              <span>暂无可用优惠券</span>
            </div>

            <!-- 支付方式 -->
            <div class="mbp-pay-label">请选择支付方式</div>
            <div class="mbp-pay-options">
              <div
                v-for="pm in payMethods"
                :key="pm.value"
                class="mbp-pay-opt"
                :class="{ 'mbp-pay-active': paymentMethod === pm.value }"
                @click="paymentMethod = pm.value"
              >
                <div class="mbp-pay-icon" :style="{ color: pm.color }">
                  <svg v-if="pm.value === 'balance'" width="26" height="26" viewBox="0 0 24 24" fill="none" :stroke="pm.color" stroke-width="1.5"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
                  <svg v-else width="26" height="26" viewBox="0 0 24 24" :fill="pm.color"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <span>{{ pm.label }}</span>
              </div>
            </div>

            <!-- 余额模块 -->
            <div v-if="paymentMethod === 'balance'" class="mbp-balance">
              <div class="mbp-balance-top">
                <div class="mbp-balance-left">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
                  <span>我的余额</span>
                </div>
                <span class="mbp-balance-amount">¥ {{ userBalance }}</span>
              </div>
              <div v-if="userBalance < finalPrice" class="mbp-balance-warn">
                <span>抱歉，余额不足，请先充值</span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
              </div>
              <div v-else class="mbp-balance-ok">
                <span>余额充足，可立即支付</span>
              </div>
            </div>
            <div v-else-if="paymentMethod === 'points'" class="mbp-balance">
              <div class="mbp-balance-top">
                <div class="mbp-balance-left">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <span>我的积分</span>
                </div>
                <span class="mbp-balance-amount">{{ userPoints }} 积分</span>
              </div>
              <div v-if="userPoints < finalPrice" class="mbp-balance-warn">
                <span>抱歉，积分不足</span>
                <i class="fa fa-angle-right" style="color:#999" />
              </div>
              <div v-else class="mbp-balance-ok">
                <span>积分充足，可立即兑换</span>
              </div>
            </div>

            <!-- 协议确认 -->
            <div class="mbp-agreement">
              <label class="mbp-agree-label" @click.stop>
                <input type="checkbox" v-model="agreed" class="mbp-agree-check" />
                <span class="mbp-agree-text">
                  我已阅读并同意
                  <span class="mbp-agree-link" @click.stop="showAgreement = true">《用户协议》</span>
                </span>
              </label>
            </div>

            <!-- 支付按钮 -->
            <button
              class="mbp-pay-btn"
              :disabled="paying || !canPay || !agreed"
              @click="handlePay"
            >
              {{ paying ? '支付中...' : payBtnText }}
            </button>
          </template>
        </div>

        <!-- 协议预览 -->
        <div v-if="showAgreement" class="mbp-agree-modal">
          <div class="mbp-agree-modal-header">
            <span class="mbp-agree-modal-title">用户协议</span>
            <span class="mbp-agree-modal-close" @click="showAgreement = false">&times;</span>
          </div>
          <div class="mbp-agree-modal-body" v-html="agreementContent" />
        </div>

        <!-- Toast -->
        <div v-if="toastMsg" class="mbp-toast" :class="{ 'mbp-toast--error': toastMsg.includes('失败') }">{{ toastMsg }}</div>
      </div>
    </div>
  </teleport>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const props = defineProps<{ visible: boolean; productId: number }>()
const emit = defineEmits(['close', 'paid'])

const userStore = useUserStore()
const loading = ref(false)
const product = ref<any>(null)
const selectedOption = ref<any>(null)
const paymentMethod = ref('balance')
const paying = ref(false)
const agreed = ref(false)
const showAgreement = ref(false)
const agreementContent = ref('')
const agreementPolicyId = ref(0)
const toastMsg = ref('')
const coupons = ref<any[]>([])
const selectedCoupon = ref<any>(null)
const showCoupons = ref(false)

const userBalance = computed(() => Number(userStore.info.balance || 0))
const userPoints = computed(() => Number(userStore.info.points || 0))

const currentPrice = computed(() => {
  if (!product.value) return 0
  const usePoints = paymentMethod.value === 'points'
  if (selectedOption.value) {
    if (usePoints) return selectedOption.value.pointsPrice || selectedOption.value.price || 0
    return selectedOption.value.price || 0
  }
  if (usePoints) return product.value.pointsPrice || product.value.price || 0
  return product.value.price || 0
})

const canPay = computed(() => {
  if (paymentMethod.value === 'balance') return userBalance.value >= finalPrice.value
  if (paymentMethod.value === 'points') return userPoints.value >= finalPrice.value
  return true
})

const couponDiscount = computed(() => {
  if (!selectedCoupon.value) return 0
  return calcCouponDiscount(selectedCoupon.value)
})

const finalPrice = computed(() => Math.max(0, currentPrice.value - couponDiscount.value))

function calcCouponDiscount(c: any) {
  const type = c.type || ''
  const value = Number(c.value) || 0
  const maxDiscount = Number(c.max_discount) || 0
  const price = currentPrice.value
  if (type === 'fixed' || type === 'fixed_points') return Math.min(value, price)
  if (type === 'percent' || type === 'points_percent') {
    const d = Math.round(price * value / 100)
    return maxDiscount > 0 ? Math.min(d, maxDiscount) : Math.min(d, price)
  }
  return 0
}

function fmtCouponDiscount(c: any) {
  const d = calcCouponDiscount(c)
  return paymentMethod.value === 'points' ? d + '积分' : '¥' + d
}

function selectCoupon(c: any) {
  selectedCoupon.value = selectedCoupon.value?.userCouponId === c.userCouponId ? null : c
  showCoupons.value = false
}

const loadCoupons = async () => {
  if (!props.productId) return
  try {
    const res: any = await request.get({
      url: '/api/coupon/usable',
      params: { scene: 'mall', orderAmount: currentPrice.value, payType: paymentMethod.value }
    })
    coupons.value = (res?.data || res || []).filter(Boolean)
    selectedCoupon.value = null
    showCoupons.value = false
  } catch { coupons.value = [] }
}

const getDur = (cfg: any) => {
  if (!cfg) return ''
  if (cfg.decorationDurationDays > 0) return cfg.decorationDurationDays + '天'
  if ('decorationDurationDays' in cfg && cfg.decorationDurationDays === 0) return '永久'
  if (cfg.value > 0 && cfg.durationUnit === 'day') return cfg.value + '天'
  if (cfg.value === 0 && cfg.durationUnit === 'day') return '永久'
  return ''
}

const durationLabel = computed(() => {
  if (!product.value) return ''
  if (selectedOption.value) {
    const d = getDur(selectedOption.value.cardConfig)
    if (d) return d
  }
  if (product.value.durationDays > 0) return product.value.durationDays + '天'
  return ''
})

const getOptionLabel = (opt: any) => {
  const d = getDur(opt.cardConfig)
  if (d) return d
  return opt.name
}

const payBtnText = computed(() => {
  return paymentMethod.value === 'points' ? '立即支付 ' + finalPrice.value + ' 积分' : '立即支付 ¥' + finalPrice.value
})

const payMethods = [
  { label: '余额', value: 'balance', color: '#f97316' },
  { label: '积分', value: 'points', color: '#eab308' },
]

const loadProduct = async () => {
  if (!props.productId) return
  loading.value = true
  agreed.value = false
  try {
    const [res, agreeRes] = await Promise.all([
      request.get({ url: '/api/mall/products/' + props.productId }),
      request.get({ url: '/api/policy/current', params: { type: 'agreement' } }).catch(() => null),
    ])
    product.value = res
    if (res?.options?.length) {
      selectedOption.value = res.options[0]
    }
    if (res?.priceType === 'points') {
      paymentMethod.value = 'points'
    }
    if (agreeRes) {
      agreementPolicyId.value = agreeRes.id
      agreementContent.value = agreeRes.content || ''
    }
    loadCoupons()
  } catch {} finally { loading.value = false }
}

const close = () => emit('close')

const handlePay = async () => {
  if (paying.value || !canPay.value) return
  paying.value = true
  try {
    const body: any = {
      productId: props.productId,
      quantity: 1,
      paymentMethod: paymentMethod.value,
      agreedPolicyId: agreementPolicyId.value,
    }
    if (selectedOption.value) body.optionId = selectedOption.value.id
    if (selectedCoupon.value) body.userCouponId = selectedCoupon.value.userCouponId

    const orderRes: any = await request.post({ url: '/api/mall/orders', data: body, showErrorMessage: false })
    const orderId = orderRes?.data?.orderId || orderRes?.orderId || orderRes?.id

    if (orderId) {
      toastMsg.value = '支付成功'
      emit('paid')
      setTimeout(() => close(), 800)
    }
  } catch (e: any) {
    toastMsg.value = e?.msg || e?.message || '支付失败'
  } finally { paying.value = false }
}

watch(() => toastMsg.value, (v) => { if (v) setTimeout(() => { toastMsg.value = '' }, 2500) })
watch(() => props.visible, (v) => { if (v) loadProduct() })
watch(() => props.productId, () => { if (props.visible) loadProduct() })
watch([currentPrice, paymentMethod], () => { if (props.visible) loadCoupons() })
</script>

<style scoped>
.mbp-mask {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: rgba(0,0,0,.45);
  display: flex;
  align-items: flex-end;
  justify-content: center;
  padding: 0 12px 12px;
}
.mbp-popup {
  width: 100%;
  max-width: 540px;
  background: #fff;
  border-radius: 16px;
  overflow: hidden;
  animation: mbp-slideUp .25s ease-out;
}
@keyframes mbp-slideUp {
  from { transform: translateY(100%); }
  to   { transform: translateY(0); }
}

/* header */
.mbp-header {
  position: relative;
  background: linear-gradient(150deg, #4bb4ff 0%, #2892ee 100%);
  padding: 16px 6px 14px;
  display: flex;
  align-items: center;
  color: #fff;
}
.mbp-header-side {
  flex: 1;
  display: flex;
  align-items: center;
}
.mbp-header-side:last-child {
  justify-content: flex-end;
}
.mbp-header-center {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
}
.mbp-close {
  font-size: 22px;
  cursor: pointer;
  line-height: 1;
  padding: 0 8px;
}
.mbp-header-title { font-size: 14px; }

/* body */
.mbp-body { padding: 14px 16px; }
.mbp-loading { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 30px 0; color: #999; font-size: 13px; }
.mbp-spinner { width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #2892ee; border-radius: 50%; animation: mbp-spin .6s linear infinite; }
@keyframes mbp-spin { to { transform: rotate(360deg); } }

/* product */
.mbp-product-row { display: flex; align-items: center; gap: 6px; margin-bottom: 12px; }
.mbp-product-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; color: #fff; white-space: nowrap; }
.mbp-tag-balance { background: #f97316; }
.mbp-tag-points { background: #22a75d; }
.mbp-product-name { font-size: 13px; color: #1a1a2e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* options */
.mbp-options { display: flex; flex-direction: column; gap: 6px; margin-bottom: 12px; }
.mbp-opt-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; border: 1px solid #e6e6e6; border-radius: 8px; cursor: pointer; transition: all .2s; }
.mbp-opt-active { border-color: #e87fc8; background: #fff7fc; }
.mbp-opt-name { font-size: 13px; color: #333; }
.mbp-opt-price { font-size: 13px; font-weight: 600; color: #e87fc8; }

/* price */
.mbp-price-row { display: flex; justify-content: space-between; align-items: center; padding: 8px 8px; background: #f9fafb; border-radius: 8px; margin-bottom: 12px; }
.mbp-price-label { color: #999; font-size: 13px; }
.mbp-price-value { font-size: 20px; font-weight: 500; color: #1a1a2e; }
.mbp-price-original { font-size: 13px; color: #999; text-decoration: line-through; margin-right: 6px; }

/* coupon */
.mbp-coupon-section { margin-bottom: 12px; }
.mbp-coupon-label { color: #999; font-size: 12px; margin-bottom: 6px; }
.mbp-coupon-trigger { display: flex; align-items: center; justify-content: space-between; border: 1px solid #e6e6e6; border-radius: 8px; padding: 8px 10px; background: #fff; font-size: 13px; cursor: pointer; }
.mbp-coupon-selected { color: #e87fc8; }
.mbp-coupon-placeholder { color: #aaa; }
.mbp-coupon-dropdown { max-height: 150px; overflow-y: auto; border: 1px solid #e6e6e6; border-radius: 8px; border-top: none; border-top-left-radius: 0; border-top-right-radius: 0; }
.mbp-coupon-item { display: flex; align-items: center; justify-content: space-between; padding: 8px 10px; cursor: pointer; font-size: 12px; border-bottom: 1px solid #f5f5f5; background: #fff; }
.mbp-coupon-item:last-child { border-bottom: none; }
.mbp-coupon-active { background: #fff7fc; }
.mbp-coupon-name { color: #666; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
.mbp-coupon-discount { color: #e87fc8; font-weight: 600; flex-shrink: 0; margin-left: 6px; }
.mbp-coupon-none { color: #bbb; font-size: 12px; text-align: center; padding: 6px 0; }

/* pay methods */
.mbp-pay-label { color: #999; font-size: 12px; margin-bottom: 8px; }
.mbp-pay-options { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-bottom: 12px; }
.mbp-pay-opt { border: 1px solid #e6e6e6; border-radius: 10px; padding: 10px 4px; display: flex; flex-direction: column; align-items: center; cursor: pointer; transition: all .2s; }
.mbp-pay-active { border-color: #e87fc8; background: #fff7fc; }
.mbp-pay-icon { margin-bottom: 2px; font-size: 26px; }

/* balance */
.mbp-balance { background: #f7f7f7; border-radius: 10px; padding: 10px; margin-bottom: 14px; font-size: 12px; }
.mbp-balance-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.mbp-balance-left { display: flex; align-items: center; gap: 4px; }
.mbp-balance-amount { color: #2563eb; font-weight: 500; }
.mbp-balance-warn { background: #fce4ec; border-radius: 6px; padding: 6px 10px; display: flex; justify-content: space-between; align-items: center; color: #e53935; font-size: 12px; }
.mbp-balance-ok { background: #e8f5e9; border-radius: 6px; padding: 6px 10px; color: #2e7d32; font-size: 12px; }

/* agreement */
.mbp-agreement {
  margin-bottom: 14px;
  padding: 8px 0;
}
.mbp-agree-label {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}
.mbp-agree-check {
  width: 16px;
  height: 16px;
  accent-color: #2892ee;
  flex-shrink: 0;
}
.mbp-agree-text {
  font-size: 12px;
  color: #666;
}
.mbp-agree-link {
  color: #2892ee;
  cursor: pointer;
  text-decoration: underline;
}

/* agreement modal */
.mbp-agree-modal {
  position: absolute;
  inset: 0;
  background: #fff;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  z-index: 10;
}
.mbp-agree-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 16px;
  border-bottom: 1px solid #eee;
  flex-shrink: 0;
}
.mbp-agree-modal-title {
  font-size: 16px;
  font-weight: 600;
  color: #1a1a2e;
}
.mbp-agree-modal-close {
  font-size: 22px;
  cursor: pointer;
  color: #999;
  line-height: 1;
}
.mbp-agree-modal-body {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  font-size: 13px;
  color: #333;
  line-height: 1.8;
}
.mbp-pay-btn {
  width: 100%;
  padding: 12px 0;
  border-radius: 999px;
  border: none;
  background: linear-gradient(90deg, #ff7058, #ff4942);
  color: #fff;
  font-size: 15px;
  cursor: pointer;
  transition: opacity .2s;
}
.mbp-pay-btn:disabled {
  opacity: .5;
  cursor: not-allowed;
}

/* toast */
.mbp-toast {
  position: absolute;
  top: 56px;
  left: 50%;
  transform: translateX(-50%);
  background: #22a75d;
  color: #fff;
  padding: 6px 20px;
  border-radius: 20px;
  font-size: 13px;
  z-index: 20;
  white-space: nowrap;
  animation: mbp-toast-in .25s ease-out;
}
.mbp-toast--error {
  background: #ef4444;
}
@keyframes mbp-toast-in {
  from { opacity: 0; transform: translateX(-50%) translateY(-8px); }
  to   { opacity: 1; transform: translateX(-50%) translateY(0); }
}
</style>
