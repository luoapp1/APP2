<template>
  <div class="page">
    <div class="header">
      <svg class="header-back" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="header-title">{{ pageTitle }}</span>
      <span v-if="unreadCount > 0" class="header-badge">{{ unreadCount }}</span>
    </div>

    <div v-if="loading" class="loading-wrap">
      <div class="loading-spin" />
      <span class="loading-text">加载中...</span>
    </div>

    <template v-else-if="messages.length > 0">
      <div class="list">
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="msg-card"
          :class="{ unread: !msg.isRead }"
          @click="handleClick(msg)"
        >
          <div class="msg-avatar">
            <img v-if="realAvatar(msg.fromUserAvatar)" :src="realAvatar(msg.fromUserAvatar)!"  loading="lazy" />
            <img v-else src="@imgs/user/avatar.webp"  loading="lazy" />
          </div>
          <div class="msg-body">
            <div class="msg-name-row">
              <span class="msg-name">{{ displayName(msg) }}</span>
              <span class="msg-date">{{ fmtRelative(msg.createTime) }}</span>
            </div>
            <div class="msg-tags" v-if="roleTag(msg) || titleTag(msg)">
              <span v-if="roleTag(msg)" class="tag-role">{{ roleTag(msg) }}</span>
              <span v-if="titleTag(msg)" class="tag-title" :style="{ color: msg.fromUserTitleColor || '#409EFF', background: msg.fromUserTitleBg || '#ecf5ff' }">{{ titleTag(msg) }}</span>
            </div>
            <div class="msg-title">{{ msg.title }}</div>
            <div class="msg-preview" v-if="msg.content && msg.content !== msg.title">{{ msg.content }}</div>
          </div>
        </div>
      </div>
    </template>

    <div v-else class="empty">
      <svg class="empty-icon" viewBox="0 0 200 160" fill="none">
        <rect x="40" y="30" width="120" height="100" rx="12" fill="#f3f4f6"/>
        <rect x="56" y="50" width="30" height="4" rx="2" fill="#d1d5db"/>
        <rect x="56" y="60" width="50" height="4" rx="2" fill="#e5e7eb"/>
        <rect x="56" y="72" width="88" height="4" rx="2" fill="#e5e7eb"/>
        <rect x="56" y="84" width="70" height="4" rx="2" fill="#e5e7eb"/>
        <rect x="56" y="96" width="40" height="4" rx="2" fill="#e5e7eb"/>
        <circle cx="100" cy="30" r="20" fill="#e5e7eb"/>
        <path d="M94 26h12M100 22v12" stroke="#d1d5db" stroke-width="2.5" stroke-linecap="round"/>
      </svg>
      <span class="empty-text">{{ notifyType === 'comment' ? '暂无评论消息' : '暂无系统通知' }}</span>
      <span class="empty-sub">有新的通知会显示在这里</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchNotifications, fetchMarkNotificationsRead } from '@/api/message'
import type { NotificationItem } from '@/api/message'

const route = useRoute()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0

const notifyType = route.path.includes('/comments') ? 'comment' : ((route.query.type as string) || 'system')
const pageTitle = computed(() => notifyType === 'comment' ? '评论' : '系统')

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) avatarMap[`avatar:${match[1]}`] = (mod as any).default
}

const realAvatar = (avatar?: string): string | null => {
  if (!avatar) return null
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar.startsWith('http') || avatar.startsWith('/uploads')) return avatar
  return null
}

const avatarBg = (msg: NotificationItem) => {
  const colors = ['#4F8AF7', '#6C5CE7', '#00BFA5', '#F97316', '#EC4899', '#EF4444', '#8B5CF6', '#10B981']
  const name = displayName(msg) || '?'
  const hash = name.split('').reduce((s: number, c: string) => s + c.charCodeAt(0), 0)
  return colors[hash % colors.length]
}

const displayName = (msg: NotificationItem) => msg.fromUserName || '系统'

const roleMap: Record<string, string> = {
  R_SUPER: '超级管理员',
  R_ADMIN: '管理员',
  R_MOD: '版主',
  R_USER: '用户',
}

const titleTag = (msg: NotificationItem): string => msg.fromUserTitle || ''
const roleTag = (msg: NotificationItem): string => {
  if (!msg.fromUserRoles || msg.fromUserRoles === '[]') return ''
  try {
    const roles: string[] = JSON.parse(msg.fromUserRoles)
    const mapped = roles.map(r => roleMap[r] || r).filter(Boolean)
    return mapped[0] || ''
  } catch { return '' }
}

function handleClick(_msg: NotificationItem) {}

const messages = ref<NotificationItem[]>([])
const loading = ref(true)
const unreadCount = ref(0)

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  const s = t.replace(' ', 'T')
  if (/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/.test(s)) return new Date(s)
  return new Date(s + 'Z')
}

const fmtRelative = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return '刚刚'
  if (mins < 60) return `${mins}分钟前`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}天前`
  const y = d.getFullYear().toString().slice(2)
  const m = (d.getMonth() + 1).toString().padStart(2, '0')
  const day = d.getDate().toString().padStart(2, '0')
  return `${y}-${m}-${day}`
}

onMounted(async () => {
  try {
    const res: any = await fetchNotifications(myUserId, 1, notifyType)
    messages.value = res.list || []
    unreadCount.value = res.unread || 0
    await fetchMarkNotificationsRead(myUserId, notifyType)
  } catch {}
  loading.value = false
})
</script>

<style scoped>
.page {
  min-height: 100vh;
  background: var(--app-page-bg);
  padding-bottom: env(safe-area-inset-bottom, 0px);
}
.header {
  display: flex;
  align-items: center;
  padding: 14px 16px;
  background: var(--default-bg-color);
  gap: 10px;
  position: sticky; top: 0; z-index: 10;
}
.header-back {
  width: 24px; height: 24px; cursor: pointer; color: #333; flex-shrink: 0;
}
.header-title {
  font-size: 18px; font-weight: 700; color: #111;
}
.header-badge {
  margin-left: auto;
  background: #ef4444; color: #fff;
  font-size: 11px; font-weight: 700; min-width: 18px; text-align: center;
  padding: 2px 6px; border-radius: 9px; line-height: 1.4;
}

.loading-wrap {
  display: flex; flex-direction: column; align-items: center; gap: 16px;
  padding: 120px 0;
}
.loading-spin {
  width: 28px; height: 28px;
  border: 2.5px solid #e5e7eb; border-top-color: #6366f1;
  border-radius: 50%; animation: spin .7s linear infinite;
}
.loading-text { font-size: 13px; color: #9ca3af; }
@keyframes spin { to { transform: rotate(360deg); } }

.list {
  padding: 12px 14px 0;
  display: flex; flex-direction: column; gap: 10px;
}

.msg-card {
  display: flex; gap: 12px; align-items: flex-start;
  padding: 14px;
  background: var(--default-bg-color);
  border-radius: 14px;
  cursor: pointer; position: relative;
  transition: transform .15s, box-shadow .15s;
}
.msg-card:active { transform: scale(.985); }
.msg-card.unread {
  box-shadow: 0 2px 8px rgba(0,0,0,.06), 0 0 0 1px rgba(99,102,241,.12);
}

.msg-avatar {
  width: 46px; height: 46px; flex-shrink: 0; margin-top: 1px;
}
.msg-avatar img {
  width: 100%; height: 100%; border-radius: 50%; object-fit: cover;
  box-shadow: 0 0 0 1px rgba(0,0,0,.04);
}
.msg-avatar-placeholder {
  width: 100%; height: 100%; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 19px; font-weight: 700;
  box-shadow: 0 0 0 1px rgba(0,0,0,.04);
}

.msg-body { flex: 1; min-width: 0; }

.msg-name-row {
  display: flex; align-items: baseline; justify-content: space-between; gap: 8px;
}
.msg-name {
  font-size: 15px; font-weight: 600; color: #111;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.msg-date {
  font-size: 11px; color: #b0b0b0; flex-shrink: 0; font-weight: 400;
}

.msg-tags {
  display: flex; align-items: center; gap: 5px; margin-top: 5px;
}
.tag-role {
  display: inline-flex; align-items: center;
  padding: 2px 6px; border-radius: 4px;
  font-size: 10px; font-weight: 600; color: #6C5CE7;
  background: rgba(108,92,231,.08);
  letter-spacing: .2px;
}
.tag-title {
  display: inline-flex; align-items: center;
  padding: 2px 6px; border-radius: 4px;
  font-size: 10px; font-weight: 600; line-height: 1.4;
  letter-spacing: .2px;
}

.msg-title {
  font-size: 14px; color: #222; line-height: 1.55; margin-top: 7px;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}
.msg-preview {
  font-size: 13px; color: #888; line-height: 1.55; margin-top: 3px;
}

.empty {
  display: flex; flex-direction: column; align-items: center;
  padding: 80px 0; gap: 12px;
}
.empty-icon { width: 120px; height: 96px; }
.empty-text { font-size: 15px; color: #9ca3af; font-weight: 500; }
.empty-sub { font-size: 12px; color: #cbd5e1; }
</style>
