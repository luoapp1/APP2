<template>
  <div class="collections-page">
    <template v-if="!managingCollection">
      <div class="page-navbar">
        <button class="nav-back" @click="$router.back()">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span class="nav-title">应用合集</span>
        <button class="nav-action" @click="openCreate">新建合集</button>
      </div>

      <!-- 标签栏: 合集列表 / 审核队列 -->
      <div class="tab-bar">
        <button class="tab-btn" :class="{ active: tab === 'list' }" @click="tab = 'list'">合集列表</button>
        <button class="tab-btn" :class="{ active: tab === 'review' }" @click="switchReview">审核队列<sup v-if="reviewList.length" class="badge">{{ reviewList.length }}</sup></button>
      </div>

      <div class="page-content">
        <!-- 合集列表 -->
        <template v-if="tab === 'list'">
          <LoadingState v-if="loading" />
          <ErrorState v-else-if="error" :error="error" @retry="loadData" />
          <EmptyState v-else-if="!list.length" text="暂无应用合集" action-text="创建合集" @action="openCreate">
            <template #icon>
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
            </template>
          </EmptyState>
          <div v-else class="collections-grid">
            <div v-for="item in list" :key="item.id" class="collection-card" @click="enterManage(item)">
              <div class="collection-cover">
                <img v-if="item.coverUrl" :src="item.coverUrl" class="collection-cover-img" loading="lazy" />
                <div v-else class="collection-cover-placeholder">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
                </div>
                <span v-if="item.status !== 'active'" class="collection-status-tag">{{ item.status }}</span>
                <span v-if="item.isPinned" class="pin-tag">置顶</span>
                <span v-if="item.isFeatured" class="featured-tag">精选</span>
              </div>
              <div class="collection-info">
                <div class="collection-name">{{ item.name }}</div>
                <div v-if="item.description" class="collection-desc">{{ item.description }}</div>
                <div class="collection-meta">
                  <span>{{ item.appCount || 0 }} 款应用</span>
                  <span>{{ item.likes || 0 }} 赞</span>
                </div>
              </div>
              <div class="collection-actions" @click.stop>
                <button class="btn-icon" :class="{ active: item.isPinned }" title="置顶" @click="togglePin(item)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 00-1.11-1.79l-1.78-.9A2 2 0 0115 10.76V6h1a2 2 0 000-4H8a2 2 0 000 4h1v4.76a2 2 0 01-1.11 1.79l-1.78.9A2 2 0 005 15.24Z"/></svg>
                </button>
                <button class="btn-icon" :class="{ active: item.isFeatured }" title="精选" @click="toggleFeatured(item)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </button>
                <button class="btn-icon" title="编辑" @click="openEdit(item)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <button class="btn-icon btn-icon-danger" title="删除" @click="confirmDelete(item)">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                </button>
              </div>
            </div>
          </div>
        </template>

        <!-- 审核队列 -->
        <template v-if="tab === 'review'">
          <LoadingState v-if="reviewLoading" />
          <EmptyState v-else-if="!reviewList.length" text="暂无待审核合集" />
          <div v-else class="review-list">
            <div v-for="item in reviewList" :key="item.id" class="review-card">
              <div class="review-info">
                <div class="review-name">{{ item.name }}</div>
                <div class="review-desc" v-if="item.description">{{ item.description }}</div>
                <div class="review-meta">创建者: {{ item.creatorName || '未知' }} | {{ item.appCount || 0 }}款应用</div>
              </div>
              <div class="review-actions">
                <button class="btn btn-success btn-sm" :disabled="saving" @click="reviewItem(item, 'approve')">通过</button>
                <button class="btn btn-danger btn-sm" :disabled="saving" @click="reviewItem(item, 'reject')">拒绝</button>
              </div>
            </div>
          </div>
        </template>
      </div>
    </template>

    <!-- 合集内应用管理模式 -->
    <template v-else>
      <div class="page-navbar">
        <button class="nav-back" @click="managingCollection = null">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span class="nav-title">{{ managingCollection.name }}</span>
        <button class="nav-action" @click="openAddApp">添加应用</button>
      </div>
      <div class="page-content">
        <LoadingState v-if="appLoading" />
        <ErrorState v-else-if="appError" :error="appError" @retry="loadCollectionApps" />
        <EmptyState v-else-if="!managingApps.length" text="暂未收录应用" action-text="添加应用" @action="openAddApp" />
        <div v-else class="app-list">
          <div v-for="app in managingApps" :key="app.id" class="app-card">
            <div class="app-icon-wrap">
              <img v-if="app.icon" :src="app.icon" class="app-icon" loading="lazy" />
              <div v-else class="app-icon-placeholder" :style="{ background: app.iconBgColor || '#ccc' }">{{ (app.name || '?')[0] }}</div>
            </div>
            <div class="app-body">
              <div class="app-name">{{ app.name }}</div>
              <div class="app-meta">
                <span v-if="app.category">{{ app.category }}</span>
                <span v-if="app.rating !== undefined">{{ app.rating }} 分</span>
                <span v-if="app.downloads !== undefined">{{ formatNum(app.downloads) }} 下载</span>
              </div>
            </div>
            <button class="btn-remove" @click="doRemoveApp(app)">移除</button>
          </div>
        </div>
      </div>
    </template>

    <!-- 创建/编辑对话框 -->
    <div v-if="showDialog" class="dialog-overlay" @click.self="cancelDialog">
      <div class="dialog-panel">
        <div class="dialog-title">{{ isCreate ? '新建合集' : '编辑合集' }}</div>
        <div class="dialog-form">
          <div class="form-item"><label class="form-label">名称</label><input v-model="form.name" class="form-input" placeholder="合集名称" /></div>
          <div class="form-item"><label class="form-label">描述</label><textarea v-model="form.description" class="form-input form-textarea" placeholder="合集描述" rows="2" /></div>
          <div class="form-item"><label class="form-label">封面图URL</label><input v-model="form.coverUrl" class="form-input" placeholder="封面图片链接" /></div>
          <div class="form-row">
            <div class="form-item form-item-half"><label class="form-label">排序</label><input v-model="form.sortOrder" class="form-input" placeholder="0" type="number" /></div>
            <div class="form-item form-item-half"><label class="form-label">状态</label><select v-model="form.status" class="form-input"><option value="active">启用</option><option value="inactive">停用</option></select></div>
          </div>
        </div>
        <div class="dialog-actions">
          <button class="btn" @click="cancelDialog">取消</button>
          <button class="btn btn-primary" :disabled="saving" @click="doSave">{{ saving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>

    <!-- 删除确认 -->
    <div v-if="showDeleteDialog" class="dialog-overlay" @click.self="showDeleteDialog = false">
      <div class="dialog-panel dialog-small">
        <div class="dialog-title">确认删除</div>
        <p class="dialog-msg">确定要删除合集「{{ deletingItem?.name }}」吗？</p>
        <div class="dialog-actions">
          <button class="btn" @click="showDeleteDialog = false">取消</button>
          <button class="btn btn-danger" :disabled="saving" @click="doDelete">{{ saving ? '删除中...' : '确认删除' }}</button>
        </div>
      </div>
    </div>

    <!-- 添加应用 -->
    <div v-if="showAddAppDialog" class="dialog-overlay" @click.self="showAddAppDialog = false">
      <div class="dialog-panel">
        <div class="dialog-title">添加应用到合集</div>
        <div class="dialog-form">
          <div class="form-item"><label class="form-label">搜索应用</label><input v-model="appSearchKeyword" class="form-input" placeholder="输入应用名称搜索" @keyup.enter="searchApps" /></div>
          <LoadingState v-if="appSearchLoading" />
          <div v-else-if="appSearchResults.length" class="app-search-results">
            <div v-for="app in appSearchResults" :key="app.id" class="search-app-card" @click="doAddApp(app)">
              <div class="app-icon-wrap"><img v-if="app.icon" :src="app.icon" class="app-icon" loading="lazy" /><div v-else class="app-icon-placeholder" :style="{ background: app.iconBgColor || '#ccc' }">{{ (app.name || '?')[0] }}</div></div>
              <div class="app-body"><div class="app-name">{{ app.name }}</div><div class="app-meta">{{ app.packageName || app.category || '' }}</div></div>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
          </div>
          <div v-else-if="appSearchKeyword && !appSearchLoading" class="empty-hint">未找到匹配的应用</div>
        </div>
        <div class="dialog-actions"><button class="btn" @click="showAddAppDialog = false">完成</button></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import {
  fetchCollections, fetchCollectionDetail, fetchCreateCollection, fetchUpdateCollection,
  fetchDeleteCollection, fetchAddCollectionApps, fetchRemoveCollectionApp,
  fetchCollectionReviewList, fetchCollectionReview,
  fetchToggleCollectionPin, fetchToggleCollectionFeatured
} from '@/api/appstore'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const loading = ref(false)
const error = ref('')
const list = ref([])
const saving = ref(false)
const tab = ref('list')

const showDialog = ref(false)
const isCreate = ref(true)
const editingId = ref(null)
const form = reactive({ name: '', description: '', coverUrl: '', sortOrder: 0, status: 'active' })

const showDeleteDialog = ref(false)
const deletingItem = ref(null)

const managingCollection = ref(null)
const managingApps = ref([])
const appLoading = ref(false)
const appError = ref('')

const showAddAppDialog = ref(false)
const appSearchKeyword = ref('')
const appSearchLoading = ref(false)
const appSearchResults = ref([])

const reviewList = ref([])
const reviewLoading = ref(false)

function resetForm() {
  form.name = ''; form.description = ''; form.coverUrl = ''; form.sortOrder = 0; form.status = 'active'; editingId.value = null
}
function openCreate() { isCreate.value = true; resetForm(); showDialog.value = true }
function openEdit(item) {
  isCreate.value = false; editingId.value = item.id
  form.name = item.name || ''; form.description = item.description || ''; form.coverUrl = item.coverUrl || ''
  form.sortOrder = item.sortOrder || 0; form.status = item.status || 'active'; showDialog.value = true
}
function cancelDialog() { showDialog.value = false; resetForm() }

async function doSave() {
  if (!form.name.trim()) { alert('请输入合集名称'); return }
  saving.value = true
  try {
    const params = { name: form.name, description: form.description, coverUrl: form.coverUrl, sortOrder: Number(form.sortOrder) || 0, status: form.status }
    if (isCreate.value) await fetchCreateCollection(params)
    else await fetchUpdateCollection(editingId.value, params)
    showDialog.value = false; resetForm(); await loadData()
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '保存失败') }
  finally { saving.value = false }
}

function confirmDelete(item) { deletingItem.value = item; showDeleteDialog.value = true }

async function doDelete() {
  saving.value = true
  try {
    await fetchDeleteCollection(deletingItem.value.id)
    showDeleteDialog.value = false; deletingItem.value = null; await loadData()
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '删除失败') }
  finally { saving.value = false }
}

async function loadData() {
  loading.value = true; error.value = ''
  try { const res = await fetchCollections(); list.value = res || [] }
  catch (e) { error.value = e?.response?.data?.msg || e?.message || '加载失败' }
  finally { loading.value = false }
}

async function switchReview() { tab.value = 'review'; await loadReviewList() }

async function loadReviewList() {
  reviewLoading.value = true
  try { const res = await fetchCollectionReviewList(); reviewList.value = res || [] }
  catch (e) { /* ignore */ }
  finally { reviewLoading.value = false }
}

async function reviewItem(item, action) {
  saving.value = true
  try {
    await fetchCollectionReview(item.id, action)
    reviewList.value = reviewList.value.filter(r => r.id !== item.id)
    alert(action === 'approve' ? '已通过' : '已拒绝')
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '操作失败') }
  finally { saving.value = false }
}

async function togglePin(item) {
  try {
    await fetchToggleCollectionPin(item.id, !item.isPinned)
    item.isPinned = !item.isPinned
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '操作失败') }
}

async function toggleFeatured(item) {
  try {
    await fetchToggleCollectionFeatured(item.id, !item.isFeatured)
    item.isFeatured = !item.isFeatured
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '操作失败') }
}

async function enterManage(item) { managingCollection.value = item; await loadCollectionApps() }

async function loadCollectionApps() {
  appLoading.value = true; appError.value = ''
  try { const res = await fetchCollectionDetail(managingCollection.value.id); const d = res || {}; managingApps.value = d.items || [] }
  catch (e) { appError.value = e?.response?.data?.msg || e?.message || '加载失败' }
  finally { appLoading.value = false }
}

function openAddApp() { appSearchKeyword.value = ''; appSearchResults.value = []; showAddAppDialog.value = true }

async function searchApps() {
  if (!appSearchKeyword.value.trim()) return
  appSearchLoading.value = true
  try {
    const request = (await import('@/utils/http')).default
    const res = await request.get({ url: '/api/app/list', params: { keyword: appSearchKeyword.value, page: 1, pageSize: 20 } })
    const d = res || {}; appSearchResults.value = d.list || []
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '搜索失败') }
  finally { appSearchLoading.value = false }
}

async function doAddApp(app) {
  saving.value = true
  try {
    await fetchAddCollectionApps(managingCollection.value.id, [app.id])
    alert('添加成功')
    appSearchResults.value = appSearchResults.value.filter(a => a.id !== app.id)
    await loadCollectionApps()
  } catch (e) { alert(e?.response?.data?.msg || e?.message || '添加失败') }
  finally { saving.value = false }
}

async function doRemoveApp(app) {
  if (!confirm(`确定要从合集移除「${app.name}」吗？`)) return
  saving.value = true
  try { await fetchRemoveCollectionApp(managingCollection.value.id, app.appId); await loadCollectionApps() }
  catch (e) { alert(e?.response?.data?.msg || e?.message || '移除失败') }
  finally { saving.value = false }
}

function formatNum(n) {
  if (!n && n !== 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

onMounted(() => { loadData() })
</script>

<style scoped>
.collections-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }
.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.nav-action { background: #6366F1; color: #fff; border: none; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
.nav-action:active { background: #4F46E5; }

.tab-bar { display: flex; background: #fff; padding: 0 12px; border-bottom: 1px solid #f0f0f0; position: sticky; top: 44px; z-index: 9; }
.tab-btn { flex: 1; padding: 12px 0; font-size: 14px; font-weight: 600; color: #999; background: none; border: none; border-bottom: 2px solid transparent; cursor: pointer; position: relative; }
.tab-btn.active { color: #6366F1; border-bottom-color: #6366F1; }
.badge { background: #EF4444; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 8px; margin-left: 4px; font-weight: 700; }

.page-content { padding: 16px; }
.collections-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.collection-card { background: #fff; border-radius: 14px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.04); transition: transform .15s; position: relative; }
.collection-card:active { transform: scale(.98); }
.collection-cover { width: 100%; height: 110px; overflow: hidden; position: relative; }
.collection-cover-img { width: 100%; height: 100%; object-fit: cover; }
.collection-cover-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #F59E0B, #EF4444); display: flex; align-items: center; justify-content: center; }
.collection-status-tag { position: absolute; top: 6px; right: 6px; background: rgba(0,0,0,.55); color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 4px; }
.pin-tag { position: absolute; top: 6px; left: 6px; background: #6366F1; color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 4px; }
.featured-tag { position: absolute; top: 24px; left: 6px; background: #F59E0B; color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 4px; }
.collection-info { padding: 10px 12px; }
.collection-name { font-size: 14px; font-weight: 700; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.collection-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.collection-meta { display: flex; align-items: center; gap: 10px; margin-top: 6px; font-size: 11px; color: #888; }
.collection-actions { display: flex; gap: 4px; padding: 0 12px 10px; }
.btn-icon { width: 30px; height: 30px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #666; }
.btn-icon:active { background: #f5f5f5; }
.btn-icon.active { color: #6366F1; border-color: #6366F1; background: #EEF2FF; }
.btn-icon-danger { color: #EF4444; border-color: #FEE2E2; }
.btn-icon-danger:active { background: #FEF2F2; }

.review-list { display: flex; flex-direction: column; gap: 10px; }
.review-card { background: #fff; border-radius: 14px; padding: 14px 16px; box-shadow: 0 1px 3px rgba(0,0,0,.04); display: flex; align-items: center; gap: 12px; }
.review-info { flex: 1; min-width: 0; }
.review-name { font-size: 15px; font-weight: 700; color: #1a1a1a; }
.review-desc { font-size: 12px; color: #999; margin-top: 2px; }
.review-meta { font-size: 11px; color: #aaa; margin-top: 4px; }
.review-actions { display: flex; gap: 8px; flex-shrink: 0; }
.btn-sm { padding: 6px 14px; font-size: 12px; }
.btn-success { background: #10B981; color: #fff; border-color: #10B981; }
.btn-success:active { background: #059669; }

.app-list { display: flex; flex-direction: column; gap: 10px; }
.app-card { display: flex; align-items: center; gap: 10px; background: #fff; border-radius: 12px; padding: 10px 12px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.app-icon-wrap { flex-shrink: 0; }
.app-icon { width: 44px; height: 44px; border-radius: 10px; object-fit: cover; }
.app-icon-placeholder { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; }
.app-body { flex: 1; min-width: 0; }
.app-name { font-size: 14px; font-weight: 600; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.app-meta { font-size: 11px; color: #999; margin-top: 2px; display: flex; gap: 8px; }
.btn-remove { padding: 5px 10px; border-radius: 6px; border: 1px solid #FEE2E2; background: #fff; color: #EF4444; font-size: 12px; cursor: pointer; white-space: nowrap; }
.btn-remove:active { background: #FEF2F2; }

.app-search-results { display: flex; flex-direction: column; gap: 8px; max-height: 300px; overflow-y: auto; }
.search-app-card { display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 10px; cursor: pointer; border: 1px solid #f0f0f0; }
.search-app-card:active { background: #f9fafb; }
.empty-hint { text-align: center; color: #999; font-size: 13px; padding: 20px 0; }

.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100; display: flex; align-items: flex-end; justify-content: center; }
.dialog-panel { background: #fff; width: 100%; max-width: 420px; border-radius: 20px 20px 0 0; padding: 20px 16px max(20px, env(safe-area-inset-bottom)); max-height: 80vh; overflow-y: auto; }
.dialog-small { border-radius: 20px; margin: 0 16px 200px; }
.dialog-title { font-size: 17px; font-weight: 700; color: #1a1a1a; margin-bottom: 16px; text-align: center; }
.dialog-msg { font-size: 14px; color: #666; text-align: center; margin-bottom: 20px; }
.dialog-form { display: flex; flex-direction: column; gap: 12px; }
.form-item { display: flex; flex-direction: column; gap: 4px; }
.form-item-half { flex: 1; }
.form-row { display: flex; gap: 10px; }
.form-label { font-size: 12px; font-weight: 600; color: #555; }
.form-input { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box; }
.form-input:focus { border-color: #6366F1; }
.form-textarea { resize: vertical; }
.dialog-actions { display: flex; align-items: center; justify-content: flex-end; gap: 10px; margin-top: 16px; }
.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; white-space: nowrap; font-weight: 500; }
.btn:active { background: #f5f5f5; }
.btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.btn-primary:active { background: #4F46E5; }
.btn-danger { background: #EF4444; color: #fff; border-color: #EF4444; }
.btn-danger:active { background: #DC2626; }
.btn:disabled { opacity: .5; cursor: not-allowed; }
</style>
