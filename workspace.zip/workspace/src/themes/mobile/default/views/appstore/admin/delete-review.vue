<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">审核管理中心</span>
    </div>

    <!-- Tab 切换 -->
    <div class="bg-white px-4 pt-1 pb-3">
      <div class="flex bg-gray-100 rounded-xl p-1">
        <button
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-1.5"
          :class="activeTab === 'withdraw' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = 'withdraw'; fetchWithdrawData()"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          提现审核
        </button>
        <button
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-1.5"
          :class="activeTab === 'delete' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = 'delete'; fetchDeleteData()"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
          注销审核
        </button>
        <button
          class="flex-1 py-2.5 rounded-[10px] text-sm font-semibold transition-all duration-200 flex items-center justify-center gap-1.5"
          :class="activeTab === 'appeal' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = 'appeal'; fetchAppealData()"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
          申诉审核
        </button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- ====== 注销审核 ====== -->
      <template v-if="activeTab === 'delete'">
      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="flex items-center justify-between">
          <div class="text-center flex-1">
            <div class="text-xl font-bold text-[#F59E0B]">{{ stats.pending }}</div>
            <div class="text-[11px] text-gray-400 mt-1">待审核</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#10B981]">{{ stats.approved }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已通过</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#EF4444]">{{ stats.rejected }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已拒绝</div>
          </div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="tableData.length > 0">
          <div v-for="item in tableData" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showDelDetail(item)">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.username }}</span>
                  <span class="text-[10px] text-gray-400">ID:{{ item.id }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="statusTagClass(item.status)">{{ statusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>申请时间: {{ item.create_time }}</div>
                </div>
              </div>
              <div v-if="item.status === 'pending'" class="flex gap-2 ml-2 flex-shrink-0" @click.stop>
                <button v-auth="'approve'" class="text-xs px-2 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="handleApprove(item.id)">通过</button>
                <button v-auth="'reject'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="showRejectDialog(item.id)">拒绝</button>
              </div>
              <span v-else class="text-xs text-gray-300">已处理</span>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="pagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current - 1)">上一页</button>
            <span class="text-xs text-gray-400">{{ pagination.current }}/{{ totalPages }}</span>
            <button :disabled="pagination.current >= totalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current + 1)">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ pagination.total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无注销申请</span>
        </div>
      </div>
      </template>

      <!-- ====== 提现审核 ====== -->
      <template v-if="activeTab === 'withdraw'">
      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="flex items-center justify-between">
          <div class="text-center flex-1">
            <div class="text-xl font-bold text-[#F59E0B]">{{ wdStats.pending }}</div>
            <div class="text-[11px] text-gray-400 mt-1">待审核</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#10B981]">{{ wdStats.completed }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已打款</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#EF4444]">{{ wdStats.rejected }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已拒绝</div>
          </div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="wdLoading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="wdTableData.length > 0">
          <div v-for="item in wdTableData" :key="'wd-' + item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showWdDetail(item)">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.user_name }}</span>
                  <span class="text-[10px] text-gray-400">ID:{{ item.id }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="wdStatusTagClass(item.status)">{{ wdStatusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div class="text-[#FF4757] font-semibold">{{ (item.amount || 0) }} 元</div>
                  <div>申请时间: {{ item.create_time }}</div>
                </div>
              </div>
              <div v-if="item.status === 'pending'" class="flex gap-2 ml-2 flex-shrink-0" @click.stop>
                <button v-auth="'approve'" class="text-xs px-2 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="handleWithdrawApprove(item.id)">通过</button>
                <button v-auth="'reject'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="showWdRejectDialog(item.id)">拒绝</button>
              </div>
              <span v-else class="text-xs text-gray-300">已处理</span>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="wdPagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="wdPagination.current--; fetchWithdrawData()">上一页</button>
            <span class="text-xs text-gray-400">{{ wdPagination.current }}/{{ wdTotalPages }}</span>
            <button :disabled="wdPagination.current >= wdTotalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="wdPagination.current++; fetchWithdrawData()">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ wdPagination.total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无提现申请</span>
        </div>
      </div>
      </template>

      <!-- ====== 申诉审核 ====== -->
      <template v-if="activeTab === 'appeal'">
      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="flex items-center justify-between">
          <div class="text-center flex-1">
            <div class="text-xl font-bold text-[#F59E0B]">{{ appealStats.pending }}</div>
            <div class="text-[11px] text-gray-400 mt-1">待审核</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#10B981]">{{ appealStats.approved }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已通过</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#EF4444]">{{ appealStats.rejected }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已拒绝</div>
          </div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="appealLoading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="appealTableData.length > 0">
          <div v-for="item in appealTableData" :key="'ap-' + item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showAppealDetail(item)">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.username }}</span>
                  <span class="text-[10px] text-gray-400">用户ID:{{ item.user_id }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="appealStatusTagClass(item.status)">{{ appealStatusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-500 mb-1">
                  <span class="text-gray-400">申诉理由：</span>{{ item.reason || '-' }}
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>封禁截止：{{ item.banUntil || '永久封禁' }}</div>
                  <div>申请时间：{{ item.create_time }}</div>
                  <div v-if="item.status !== 'pending' && item.admin_note">处理备注：{{ item.admin_note }}</div>
                </div>
              </div>
              <div v-if="item.status === 'pending'" class="flex gap-2 ml-2 flex-shrink-0" @click.stop>
                <button v-auth="'approve'" class="text-xs px-2 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="handleAppealApprove(item.id)">通过</button>
                <button v-auth="'reject'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="showAppealRejectDialog(item.id)">拒绝</button>
              </div>
              <span v-else class="text-xs text-gray-300">已处理</span>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="appealPagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="appealPagination.current--; fetchAppealData()">上一页</button>
            <span class="text-xs text-gray-400">{{ appealPagination.current }}/{{ appealTotalPages }}</span>
            <button :disabled="appealPagination.current >= appealTotalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="appealPagination.current++; fetchAppealData()">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ appealPagination.total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无申诉申请</span>
        </div>
      </div>
      </template>

      <!-- 申诉拒绝原因弹窗 -->
      <div v-if="appealRejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="appealRejectVisible = false">
        <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden" @click.stop>
          <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
            <button class="text-gray-400" @click="appealRejectVisible = false">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
            <span class="text-sm font-bold text-gray-800">拒绝申诉</span>
            <button class="text-sm font-semibold text-[#FF4757]" @click="handleAppealReject">确认</button>
          </div>
          <div class="p-4">
            <label class="text-xs text-gray-500 mb-1 block">拒绝原因</label>
            <textarea v-model="appealRejectReason" rows="3" placeholder="请输入拒绝原因(可选)" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
          </div>
        </div>
      </div>
    </div>

    <!-- 注销详情弹窗 -->
    <div v-if="delDetailVisible" class="fixed inset-0 z-40 flex items-end justify-center bg-black/40" @click.self="delDetailVisible = false">
      <div class="bg-white rounded-t-2xl w-full max-h-[70vh] overflow-y-auto animate-slide-up" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 sticky top-0 bg-white border-b border-gray-100 rounded-t-2xl z-10">
          <span class="text-sm font-bold text-gray-800">注销详情</span>
          <button class="text-gray-400" @click="delDetailVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="p-4 space-y-3">
          <div v-for="(val, key) in delDetailItem" :key="key" class="flex items-start">
            <span class="text-xs text-gray-400 w-20 flex-shrink-0">{{ fieldLabel(key) }}</span>
            <span class="text-xs text-gray-800 break-all">{{ val ?? '-' }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 提现详情弹窗 -->
    <div v-if="wdDetailVisible" class="fixed inset-0 z-40 flex items-end justify-center bg-black/40" @click.self="wdDetailVisible = false">
      <div class="bg-white rounded-t-2xl w-full max-h-[70vh] overflow-y-auto animate-slide-up" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 sticky top-0 bg-white border-b border-gray-100 rounded-t-2xl z-10">
          <span class="text-sm font-bold text-gray-800">提现详情</span>
          <button class="text-gray-400" @click="wdDetailVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="p-4 space-y-3">
          <div v-for="(val, key) in wdDetailItem" :key="key" class="flex items-start">
            <span class="text-xs text-gray-400 w-20 flex-shrink-0">{{ fieldLabel(key) }}</span>
            <span class="text-xs text-gray-800 break-all">{{ formatWdValue(key, val) }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 拒绝原因弹窗 -->
    <div v-if="rejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="rejectVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="rejectVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">拒绝注销</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="handleReject">确认</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">拒绝原因</label>
          <textarea v-model="rejectReason" rows="3" placeholder="请输入拒绝原因(可选)" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>
    <!-- 提现拒绝原因弹窗 -->
    <div v-if="wdRejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="wdRejectVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="wdRejectVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">拒绝提现</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="handleWdReject">确认</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">拒绝原因</label>
          <textarea v-model="wdRejectRemark" rows="3" placeholder="请输入拒绝原因(可选)" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>

    <!-- 通用确认弹窗 -->
    <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="confirmVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">{{ confirmTitle }}</div>
          <div class="text-xs text-gray-400">{{ confirmDesc }}</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-blue-500 font-semibold border-l border-gray-100 active:bg-blue-50" @click="onConfirm">确定</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'DeleteReviewMobile' })

const activeTab = ref<'delete' | 'withdraw' | 'appeal'>('withdraw')

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

// --- 注销审核 ---
const loading = ref(false)
const tableData = ref<any[]>([])
const pagination = reactive({ current: 1, size: 20, total: 0 })
const totalPages = computed(() => Math.max(1, Math.ceil(pagination.total / pagination.size)))
const stats = reactive({ pending: 0, approved: 0, rejected: 0 })

const statusMap: Record<string, string> = { pending: '待审核', approved: '已通过', rejected: '已拒绝' }
const statusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', approved: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }
const statusText = (s: string) => statusMap[s] || s
const statusTagClass = (s: string) => statusClassMap[s] || 'bg-gray-100 text-gray-500'

const fetchDeleteData = async () => {
  loading.value = true
  try {
    const data: any = await request.get({ url: `/api/user/delete-requests?page=${pagination.current}&size=${pagination.size}` })
    const list = data?.records || data?.list || data || []
    tableData.value = list
    pagination.total = data?.total || list.length
    stats.pending = list.filter((r: any) => r.status === 'pending').length
    stats.approved = list.filter((r: any) => r.status === 'approved').length
    stats.rejected = list.filter((r: any) => r.status === 'rejected').length
  } catch {}
  loading.value = false
}

const goPage = (p: number) => { pagination.current = p; activeTab.value === 'delete' ? fetchDeleteData() : activeTab.value === 'appeal' ? fetchAppealData() : fetchWithdrawData() }

const handleApprove = (id: number) => {
  confirmTitle.value = '确认通过'
  confirmDesc.value = '确定通过该注销申请？'
  delApproveTargetId.value = id
  confirmVisible.value = true
}
const delApproveTargetId = ref(0)

const rejectVisible = ref(false)
const rejectTargetId = ref(0)
const rejectReason = ref('')

const showRejectDialog = (id: number) => {
  rejectTargetId.value = id
  rejectReason.value = ''
  rejectVisible.value = true
}

const handleReject = async () => {
  try {
    await request.post({ url: `/api/user/delete-request/${rejectTargetId.value}/review`, data: { status: 'rejected', admin_note: rejectReason.value || '' } })
    showToast('已拒绝注销申请')
    rejectVisible.value = false
    fetchDeleteData()
  } catch { showToast('操作失败', 'error') }
}

const delDetailVisible = ref(false)
const delDetailItem = ref<any>({})
const showDelDetail = (item: any) => {
  delDetailItem.value = item
  delDetailVisible.value = true
}

const fieldLabel = (key: string) => {
  const map: Record<string, string> = {
    id: 'ID', username: '用户名', user_id: '用户ID', user_name: '用户名',
    status: '状态', reason: '原因', admin_note: '备注', remark: '备注',
    amount: '金额', method: '方式', account: '账号', real_name: '真实姓名',
    reviewed_by_name: '审核人', reviewed_at: '审核时间',
    create_time: '申请时间', update_time: '处理时间',
    phone: '手机号', email: '邮箱', nickname: '昵称', banUntil: '封禁截止时间'
  }
  return map[key] || key
}

// --- 提现审核 ---
const wdLoading = ref(false)
const wdTableData = ref<any[]>([])
const wdPagination = reactive({ current: 1, size: 20, total: 0 })
const wdTotalPages = computed(() => Math.max(1, Math.ceil(wdPagination.total / wdPagination.size)))
const wdStats = reactive({ pending: 0, completed: 0, rejected: 0 })

const wdStatusMap: Record<string, string> = { pending: '待审核', completed: '已打款', rejected: '已拒绝' }
const wdStatusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', completed: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }
const wdStatusText = (s: string) => wdStatusMap[s] || s
const wdStatusTagClass = (s: string) => wdStatusClassMap[s] || 'bg-gray-100 text-gray-500'

const fetchWithdrawData = async () => {
  wdLoading.value = true
  try {
    const data: any = await request.get({ url: `/api/commission/withdraw/list?page=${wdPagination.current}&pageSize=${wdPagination.size}` })
    const list = data?.list || data?.data?.list || []
    wdTableData.value = list
    wdPagination.total = data?.total || data?.data?.total || list.length
    wdStats.pending = list.filter((r: any) => r.status === 'pending').length
    wdStats.completed = list.filter((r: any) => r.status === 'completed').length
    wdStats.rejected = list.filter((r: any) => r.status === 'rejected').length
  } catch {}
  wdLoading.value = false
}

const handleWithdrawApprove = (id: number) => {
  confirmTitle.value = '确认通过'
  confirmDesc.value = '确定通过该提现申请？'
  wdApproveTargetId.value = id
  confirmVisible.value = true
}
const wdApproveTargetId = ref(0)

const confirmVisible = ref(false)
const confirmTitle = ref('')
const confirmDesc = ref('')
const onConfirm = async () => {
  confirmVisible.value = false
  if (wdApproveTargetId.value) {
    try {
      await request.post({ url: '/api/commission/withdraw/review', data: { id: wdApproveTargetId.value, status: 'completed' } })
      showToast('提现已通过')
      wdApproveTargetId.value = 0
      fetchWithdrawData()
    } catch { showToast('操作失败', 'error') }
  } else if (delApproveTargetId.value) {
    try {
      await request.post({ url: `/api/user/delete-request/${delApproveTargetId.value}/review`, data: { status: 'approved' } })
      showToast('已通过注销申请')
      delApproveTargetId.value = 0
      fetchDeleteData()
    } catch { showToast('操作失败', 'error') }
  } else if (appealApproveTargetId.value) {
    try {
      await request.post({ url: `/api/user/appeal/${appealApproveTargetId.value}/review`, data: { status: 'approved' } })
      showToast('已通过申诉，账号已解封')
      appealApproveTargetId.value = 0
      fetchAppealData()
    } catch { showToast('操作失败', 'error') }
  }
}

const wdRejectVisible = ref(false)
const wdRejectTargetId = ref(0)
const wdRejectRemark = ref('')

const showWdRejectDialog = (id: number) => {
  wdRejectTargetId.value = id
  wdRejectRemark.value = ''
  wdRejectVisible.value = true
}

const handleWdReject = async () => {
  try {
    await request.post({ url: '/api/commission/withdraw/review', data: { id: wdRejectTargetId.value, status: 'rejected', remark: wdRejectRemark.value || '' } })
    showToast('提现已拒绝')
    wdRejectVisible.value = false
    fetchWithdrawData()
  } catch { showToast('操作失败', 'error') }
}

const wdDetailVisible = ref(false)
const wdDetailItem = ref<any>({})
const showWdDetail = (item: any) => {
  wdDetailItem.value = { ...item }
  wdDetailVisible.value = true
}

const formatWdValue = (key: string, val: any) => {
  if (val === null || val === undefined) return '-'
  if (key === 'method') {
    const map: Record<string, string> = { alipay: '支付宝', wechat: '微信', bank: '银行卡' }
    return map[val] || val
  }
  return val
}

// --- 申诉审核 ---
const appealLoading = ref(false)
const appealTableData = ref<any[]>([])
const appealPagination = reactive({ current: 1, size: 20, total: 0 })
const appealTotalPages = computed(() => Math.max(1, Math.ceil(appealPagination.total / appealPagination.size)))
const appealStats = reactive({ pending: 0, approved: 0, rejected: 0 })

const appealStatusMap: Record<string, string> = { pending: '待审核', approved: '已通过(已解封)', rejected: '已拒绝' }
const appealStatusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', approved: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }
const appealStatusText = (s: string) => appealStatusMap[s] || s
const appealStatusTagClass = (s: string) => appealStatusClassMap[s] || 'bg-gray-100 text-gray-500'

const fetchAppealData = async () => {
  appealLoading.value = true
  try {
    const data: any = await request.get({ url: `/api/user/appeals?page=${appealPagination.current}&pageSize=${appealPagination.size}` })
    const list = data?.list || data?.data?.list || []
    appealTableData.value = list
    appealPagination.total = data?.total || data?.data?.total || list.length
    appealStats.pending = list.filter((r: any) => r.status === 'pending').length
    appealStats.approved = list.filter((r: any) => r.status === 'approved').length
    appealStats.rejected = list.filter((r: any) => r.status === 'rejected').length
  } catch {}
  appealLoading.value = false
}

const handleAppealApprove = (id: number) => {
  appealApproveTargetId.value = id
  confirmTitle.value = '确认通过申诉'
  confirmDesc.value = '通过后将自动解封该用户账号，确定吗？'
  confirmVisible.value = true
}
const appealApproveTargetId = ref(0)

const appealRejectVisible = ref(false)
const appealRejectTargetId = ref(0)
const appealRejectReason = ref('')

const showAppealRejectDialog = (id: number) => {
  appealRejectTargetId.value = id
  appealRejectReason.value = ''
  appealRejectVisible.value = true
}

const handleAppealReject = async () => {
  try {
    await request.post({
      url: `/api/user/appeal/${appealRejectTargetId.value}/review`,
      data: { status: 'rejected', adminNote: appealRejectReason.value || '' }
    })
    showToast('已拒绝申诉')
    appealRejectVisible.value = false
    fetchAppealData()
  } catch { showToast('操作失败', 'error') }
}

const showAppealDetail = (item: any) => {
  delDetailItem.value = item
  delDetailVisible.value = true
}

onMounted(() => {
  fetchWithdrawData()
})
</script>

<style scoped>
.detail-sheet {
  animation: slide-up 0.25s ease-out;
}
@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
</style>
