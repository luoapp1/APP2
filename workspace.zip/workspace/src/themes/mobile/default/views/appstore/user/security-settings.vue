<template>
  <div class="security-page">
    <div class="security-navbar">
      <button class="security-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="security-title">安全设置</span>
      <div class="security-placeholder" />
    </div>

    <div class="security-content">
      <!-- 两步验证 -->
      <div class="security-card">
        <div class="card-header">
          <div class="card-header-left">
            <div class="card-icon" style="background: #EEF2FF">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            </div>
            <div>
              <div class="card-title">两步验证 (2FA)</div>
              <div class="card-subtitle">提升账号安全性</div>
            </div>
          </div>
          <div class="card-header-right">
            <span class="status-tag" :class="{ on: twoFA.enabled }">{{ twoFA.enabled ? '已启用' : '未启用' }}</span>
          </div>
        </div>

        <div class="card-body">
          <div class="setup-section" v-if="showSetupQR">
            <div class="setup-steps">
              <div class="setup-qr" v-if="setupData.qrCode" v-html="setupData.qrCode"></div>
              <div class="setup-secret-row">
                <span class="setup-secret-label">密钥</span>
                <code class="setup-secret-value">{{ setupData.secret }}</code>
              </div>
            </div>
            <div class="setup-verify">
              <input v-model="verifyToken" type="text" placeholder="输入6位验证码" class="setup-input" maxlength="6" />
              <button class="btn-primary" @click="handleVerify2FA" :disabled="verifyToken.length !== 6 || verifying">
                {{ verifying ? '验证中...' : '验证' }}
              </button>
            </div>
          </div>

          <div class="setup-section" v-if="showDisableInput">
            <div class="setup-verify">
              <input v-model="disableToken" type="text" placeholder="输入验证码以关闭" class="setup-input" maxlength="6" />
              <button class="btn-danger" @click="handleConfirmDisable" :disabled="disableToken.length !== 6 || disabling">
                {{ disabling ? '处理中...' : '确认关闭' }}
              </button>
            </div>
          </div>

          <div v-if="!showSetupQR && !showDisableInput" class="card-footer">
            <button class="btn-outline" v-if="twoFA.enabled" @click="showDisableInput = true">关闭两步验证</button>
            <button class="btn-primary" v-else @click="handleSetup2FA">开启两步验证</button>
          </div>
        </div>
      </div>

      <!-- 隐私设置 -->
      <div class="security-card">
        <div class="card-header">
          <div class="card-header-left">
            <div class="card-icon" style="background: #FEF3C7">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </div>
            <div>
              <div class="card-title">隐私设置</div>
              <div class="card-subtitle">控制你的个人信息可见性</div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <div class="toggle-row" v-for="(val, key) in privacySettings" :key="key">
            <div class="toggle-info">
              <span class="toggle-label">{{ privacyLabel(key) }}</span>
              <span class="toggle-desc">{{ privacyDesc(key) }}</span>
            </div>
            <label class="toggle">
              <input type="checkbox" v-model="privacySettings[key]" @change="handlePrivacyChange" />
              <span class="toggle-slider"></span>
            </label>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const userStore = useUserStore()

const twoFA = ref({ enabled: false })
const showSetupQR = ref(false)
const showDisableInput = ref(false)
const setupData = ref({ secret: '', qrCode: '' })
const verifyToken = ref('')
const disableToken = ref('')
const verifying = ref(false)
const disabling = ref(false)

const privacySettings = ref({
  hideBirthday: false,
  hideQq: false,
  hideEmail: false,
  hideAddress: false
})

onMounted(async () => {
  if (!userStore.isLogin) return
  const uid = userStore.info.userId
  try {
    const res = await request.get({ url: '/api/user/2fa/status' })
    if (res) {
      twoFA.value = { enabled: res.enabled || false }
    }
  } catch { /* ignore */ }
  try {
    const priv = await request.get({ url: '/api/user/privacy-settings' })
    if (priv) {
      privacySettings.value = {
        hideBirthday: !!priv.hideBirthday,
        hideQq: !!priv.hideQq,
        hideEmail: !!priv.hideEmail,
        hideAddress: !!priv.hideAddress
      }
    }
  } catch { /* ignore */ }
})

async function handleSetup2FA() {
  try {
    const res = await request.post({ url: '/api/user/2fa/setup', data: {} })
    setupData.value = { secret: res?.secret || '', qrCode: res?.qrCode || '' }
    showSetupQR.value = true
  } catch (e) { ElMessage.error(e?.msg || e?.message || '设置失败') }
}

async function handleVerify2FA() {
  if (verifyToken.value.length !== 6) return
  verifying.value = true
  try {
    await request.post({ url: '/api/user/2fa/verify', data: { token: verifyToken.value } })
    twoFA.value.enabled = true
    showSetupQR.value = false
    verifyToken.value = ''
    ElMessage.success('两步验证已成功启用')
  } catch (e) { ElMessage.error(e?.msg || e?.message || '验证失败') }
  verifying.value = false
}

async function handleConfirmDisable() {
  if (disableToken.value.length !== 6) return
  disabling.value = true
  try {
    await request.post({ url: '/api/user/2fa/disable', data: { token: disableToken.value } })
    twoFA.value.enabled = false
    showDisableInput.value = false
    disableToken.value = ''
    ElMessage.success('两步验证已关闭')
  } catch (e) { ElMessage.error(e?.msg || e?.message || '关闭失败') }
  disabling.value = false
}

async function handlePrivacyChange() {
  try {
    await request.put({ url: '/api/user/privacy-settings', data: { ...privacySettings.value } })
  } catch { /* ignore */ }
}

function privacyLabel(key) {
  const map = { hideBirthday: '隐藏生日', hideQq: '隐藏 QQ', hideEmail: '隐藏邮箱', hideAddress: '隐藏地址' }
  return map[key] || key
}

function privacyDesc(key) {
  const map = { hideBirthday: '在个人资料中隐藏生日信息', hideQq: '在个人资料中隐藏 QQ 号', hideEmail: '在个人资料中隐藏邮箱地址', hideAddress: '在个人资料中隐藏地址信息' }
  return map[key] || ''
}
</script>

<style scoped>
.security-page { min-height: 100vh; background: #F5F6FA; }
.security-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.security-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.security-back:active { background: #f0f0f0; }
.security-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.security-placeholder { width: 22px; }
.security-content { padding: 16px; display: flex; flex-direction: column; gap: 16px; }

.security-card { background: #fff; border-radius: 16px; overflow: hidden; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: 16px; }
.card-header-left { display: flex; align-items: center; gap: 12px; }
.card-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.card-title { font-size: 15px; font-weight: 600; color: #1f2937; }
.card-subtitle { font-size: 12px; color: #9CA3AF; margin-top: 2px; }
.status-tag { font-size: 12px; padding: 4px 10px; border-radius: 20px; background: #F3F4F6; color: #9CA3AF; font-weight: 500; }
.status-tag.on { background: #D1FAE5; color: #10B981; }

.card-body { padding: 0 16px 16px; }
.card-footer { padding: 0 16px 16px; }
.toggle-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #F3F4F6; }
.toggle-row:last-child { border-bottom: none; }
.toggle-info { flex: 1; min-width: 0; padding-right: 16px; }
.toggle-label { font-size: 14px; color: #374151; font-weight: 500; display: block; }
.toggle-desc { font-size: 12px; color: #9CA3AF; margin-top: 2px; display: block; }

.toggle { position: relative; display: inline-block; width: 48px; height: 26px; flex-shrink: 0; }
.toggle input { opacity: 0; width: 0; height: 0; }
.toggle-slider { position: absolute; inset: 0; background: #E5E7EB; border-radius: 26px; cursor: pointer; transition: background .2s; }
.toggle-slider::before { content: ''; position: absolute; width: 22px; height: 22px; left: 2px; top: 2px; background: #fff; border-radius: 50%; transition: transform .2s; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }
.toggle input:checked + .toggle-slider { background: #6366F1; }
.toggle input:checked + .toggle-slider::before { transform: translateX(22px); }

/* 2FA setup */
.setup-section { padding: 4px 0; }
.setup-steps { display: flex; flex-direction: column; align-items: center; }
.setup-qr { text-align: center; margin-bottom: 12px; padding: 12px; background: #F9FAFB; border-radius: 12px; }
.setup-qr :deep(svg) { max-width: 160px; height: auto; }
.setup-secret-row { display: flex; align-items: center; gap: 8px; margin-bottom: 16px; width: 100%; }
.setup-secret-label { font-size: 12px; color: #9CA3AF; white-space: nowrap; }
.setup-secret-value { flex: 1; font-size: 12px; font-family: monospace; background: #F9FAFB; padding: 6px 10px; border-radius: 8px; word-break: break-all; color: #6B7280; }
.setup-verify { display: flex; gap: 10px; align-items: center; }
.setup-input { flex: 1; padding: 10px 12px; border: 1px solid #E5E7EB; border-radius: 10px; font-size: 15px; outline: none; background: #F9FAFB; letter-spacing: 4px; text-align: center; }
.setup-input:focus { border-color: #6366F1; background: #fff; box-shadow: 0 0 0 3px rgba(99,102,241,0.1); }
.setup-input::placeholder { letter-spacing: 0; font-size: 13px; color: #D1D5DB; }

.btn-primary { padding: 10px 20px; background: linear-gradient(135deg, #6366F1, #818CF8); color: #fff; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; white-space: nowrap; }
.btn-primary:active { opacity: 0.85; }
.btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-danger { padding: 10px 20px; background: #EF4444; color: #fff; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; white-space: nowrap; }
.btn-danger:active { opacity: 0.85; }
.btn-danger:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-outline { padding: 10px 20px; background: #FEF2F2; color: #EF4444; border: 1px solid #FECACA; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; width: 100%; }
.btn-outline:active { background: #FEE2E2; }
</style>
