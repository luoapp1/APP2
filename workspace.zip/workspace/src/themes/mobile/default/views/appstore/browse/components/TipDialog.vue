<template>
  <div v-if="props.modelValue" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="close">
    <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px;">
      <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 8px;">打赏 {{ props.appName }}</div>
      <div style="display: flex; gap: 8px; margin-bottom: 12px;">
        <div style="flex: 1; padding: 8px; border-radius: 8px; text-align: center; font-size: 12px; cursor: pointer; border: 1px solid #e5e7eb;"
          :style="tipType === 'balance' ? { background: '#e6f9f6', borderColor: '#00BFA5', color: '#00BFA5', fontWeight: 600 } : { color: '#374151' }"
          @click="tipType = 'balance'">
          余额 ({{ balanceStr }})
        </div>
        <div style="flex: 1; padding: 8px; border-radius: 8px; text-align: center; font-size: 12px; cursor: pointer; border: 1px solid #e5e7eb;"
          :style="tipType === 'points' ? { background: '#e6f9f6', borderColor: '#00BFA5', color: '#00BFA5', fontWeight: 600 } : { color: '#374151' }"
          @click="tipType = 'points'">
          积分 ({{ userStore.info.points || 0 }})
        </div>
      </div>
      <div style="display: flex; gap: 8px; margin-bottom: 8px; flex-wrap: wrap;">
        <div v-for="amt in (tipType === 'balance' ? [1,2,5,8,10] : [1,3,5,10,20])" :key="amt" style="padding: 6px 12px; border-radius: 8px; font-size: 13px; cursor: pointer; border: 1px solid #e5e7eb;"
          :style="tipAmount === amt ? { background: '#00BFA5', color: '#fff', borderColor: '#00BFA5' } : { color: '#374151' }"
          @click="tipAmount = amt">{{ amt }}{{ tipType === 'balance' ? '元' : '积分' }}</div>
      </div>
      <div style="margin-bottom: 12px;">
        <input v-model.number="customAmount" type="number" placeholder="自定义金额" style="width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box;" @input="onCustomAmount" />
      </div>
      <div style="margin-bottom: 12px;">
        <input v-model="tipMessage" placeholder="留言(选填, 将显示在评论中)" style="width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box;" />
      </div>
      <div v-if="tipMsg" style="font-size: 12px; color: #00BFA5; margin-bottom: 8px; text-align: center;">{{ tipMsg }}</div>
      <div style="display: flex; gap: 10px;">
        <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer;" @click="close">取消</button>
        <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="doTip">确认打赏</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { fetchPostTip } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'

const props = defineProps<{
  appId: number
  appName: string
  modelValue: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  'tipped': []
}>()

const router = useRouter()
const userStore = useUserStore()

const tipType = ref('balance')
const tipAmount = ref(1)
const tipMsg = ref('')
const tipMessage = ref('')
const customAmount = ref<number | ''>('')

const balanceStr = computed(() => {
  const b = Number(userStore.info.balance || 0)
  return b.toFixed(2)
})

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    useLoginModalStore().open()
    return false
  }
  return true
}

function close() {
  emit('update:modelValue', false)
}

watch(() => props.modelValue, (val) => {
  if (val) {
    if (!checkLogin()) {
      emit('update:modelValue', false)
      return
    }
    tipType.value = 'balance'
    tipAmount.value = 1
    tipMsg.value = ''
    tipMessage.value = ''
    customAmount.value = ''
  }
})

const onCustomAmount = () => {
  if (customAmount.value && Number(customAmount.value) > 0) {
    tipAmount.value = Number(customAmount.value)
  }
}

watch(tipType, () => {
  tipAmount.value = 1
})

const doTip = async () => {
  try {
    const data = await fetchPostTip(props.appId, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      amount: tipAmount.value,
      tipType: tipType.value,
      message: tipMessage.value
    })
    if (data.newBalance !== undefined) userStore.info.balance = data.newBalance
    if (data.newPoints !== undefined) userStore.info.points = data.newPoints
    tipMsg.value = data.msg || '打赏成功'
    setTimeout(() => {
      emit('update:modelValue', false)
      emit('tipped')
    }, 800)
  } catch (e: any) {
    tipMsg.value = e?.msg || '打赏失败'
  }
}
</script>
