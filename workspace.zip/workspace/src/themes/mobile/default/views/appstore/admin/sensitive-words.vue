<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">敏感词管理</span>
    </div>

    <div v-if="loading" class="flex justify-center pt-40">
      <div class="animate-spin w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full" />
    </div>

    <template v-else>
      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="relative">
          <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <input
            v-model="searchKeyword"
            class="w-full h-10 rounded-lg bg-gray-100 pl-9 pr-3 text-sm text-gray-700 outline-none border-none"
            placeholder="搜索敏感词..."
            @input="filterWords"
          />
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <button class="w-full h-10 rounded-lg text-sm font-medium text-white active:opacity-80" style="background:#6366F1" @click="openDialog(null)">+ 添加敏感词</button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="filteredWords.length === 0" class="flex flex-col items-center py-12 text-gray-400">
          <span class="text-sm">{{ searchKeyword ? '未找到匹配的敏感词' : '暂无敏感词' }}</span>
        </div>
        <div v-for="item in filteredWords" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
          <div class="flex items-center justify-between">
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2 mb-1">
                <span class="text-sm font-semibold text-gray-800">{{ item.word }}</span>
                <span v-if="item.replacement" class="text-xs text-gray-400">
                  <svg class="w-3 h-3 inline-block mr-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                  {{ item.replacement }}
                </span>
              </div>
              <div class="flex items-center gap-2 text-xs">
                <span v-if="item.category" class="px-1.5 py-0.5 rounded text-white text-[10px]" :style="{ background: categoryColor(item.category) }">{{ item.category }}</span>
                <span class="text-gray-400">{{ item.create_time || item.createTime || '' }}</span>
              </div>
            </div>
            <div class="flex gap-1 flex-shrink-0 ml-2">
              <button class="px-2 py-1 text-[11px] rounded text-[#6366F1] bg-[#EEF2FF]" @click="openDialog(item)">编辑</button>
              <button class="px-2 py-1 text-[11px] rounded text-[#EF4444] bg-[#FEE2E2]" @click="confirmDelete(item)">删除</button>
            </div>
          </div>
        </div>
      </div>
    </template>

    <Teleport to="body">
      <div v-if="dialogVisible" class="fixed inset-0 z-[60]" @click.self="closeDialog">
        <div class="absolute inset-0 bg-black/50" />
        <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl p-5 pb-8 max-h-[80vh] overflow-y-auto">
          <div class="text-base font-semibold text-gray-800 mb-4">{{ editingWord ? '编辑敏感词' : '添加敏感词' }}</div>

          <div class="mb-4">
            <div class="text-xs text-gray-500 mb-1.5">敏感词 <span class="text-[#EF4444]">*</span></div>
            <input
              v-model="form.word"
              class="w-full h-10 px-3 text-sm border border-gray-200 rounded-lg outline-none focus:border-[#6366F1]"
              placeholder="请输入敏感词"
              maxlength="50"
            />
          </div>

          <div class="mb-4">
            <div class="text-xs text-gray-500 mb-1.5">替换词</div>
            <input
              v-model="form.replacement"
              class="w-full h-10 px-3 text-sm border border-gray-200 rounded-lg outline-none focus:border-[#6366F1]"
              placeholder="检测到敏感词时替换为此内容（可选）"
              maxlength="50"
            />
          </div>

          <div class="mb-4">
            <div class="text-xs text-gray-500 mb-1.5">分类</div>
            <input
              v-model="form.category"
              class="w-full h-10 px-3 text-sm border border-gray-200 rounded-lg outline-none focus:border-[#6366F1]"
              placeholder="如：政治、色情、广告等（可选）"
              maxlength="20"
            />
          </div>

          <div v-if="dialogMsg" class="text-xs text-[#EF4444] text-center mb-3">{{ dialogMsg }}</div>

          <div class="flex gap-3 mt-6">
            <button class="flex-1 h-11 rounded-lg text-sm font-medium bg-gray-100 text-gray-600 active:bg-gray-200" @click="closeDialog">取消</button>
            <button class="flex-1 h-11 rounded-lg text-sm font-medium text-white active:opacity-80" style="background:#6366F1" :disabled="dialogSaving" @click="handleSave">{{ dialogSaving ? '保存中...' : '保存' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <Teleport to="body">
      <div v-if="deleteVisible" class="fixed inset-0 z-[60] flex items-center justify-center p-4" @click.self="deleteVisible = false">
        <div class="absolute inset-0 bg-black/50" />
        <div class="relative bg-white rounded-2xl shadow-xl w-72 overflow-hidden">
          <div class="p-5 text-center">
            <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
              <svg class="w-6 h-6 text-[#EF4444]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </div>
            <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
            <div class="text-xs text-gray-400">确定要删除「{{ deleteTarget?.word }}」吗？此操作不可恢复。</div>
          </div>
          <div class="flex border-t border-gray-100">
            <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="deleteVisible = false">取消</button>
            <button class="flex-1 h-11 text-sm text-[#EF4444] font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">确定删除</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const loading = ref(true)
const words = ref([])
const filteredWords = ref([])
const searchKeyword = ref('')

const dialogVisible = ref(false)
const editingWord = ref(null)
const dialogSaving = ref(false)
const dialogMsg = ref('')
const form = reactive({ word: '', replacement: '', category: '' })

const deleteVisible = ref(false)
const deleteTarget = ref(null)

const categoryColors = {
  '政治': '#EF4444',
  '色情': '#F59E0B',
  '暴力': '#DC2626',
  '广告': '#8B5CF6',
  '其他': '#6B7280'
}

function categoryColor(cat) {
  return categoryColors[cat] || '#6B7280'
}

function filterWords() {
  const keyword = searchKeyword.value.toLowerCase()
  filteredWords.value = keyword
    ? words.value.filter(w => w.word.toLowerCase().includes(keyword))
    : words.value
}

async function loadWords() {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/community/sensitive-words' })
    const data = Array.isArray(res) ? res : (res?.data || res?.list || [])
    words.value = data
    filterWords()
  } catch (e) {
    words.value = []
    filteredWords.value = []
  } finally {
    loading.value = false
  }
}

function openDialog(item) {
  if (item) {
    editingWord.value = item
    form.word = item.word || ''
    form.replacement = item.replacement || ''
    form.category = item.category || ''
  } else {
    editingWord.value = null
    form.word = ''
    form.replacement = ''
    form.category = ''
  }
  dialogMsg.value = ''
  dialogVisible.value = true
}

function closeDialog() {
  dialogVisible.value = false
  editingWord.value = null
}

async function handleSave() {
  if (!form.word.trim()) {
    dialogMsg.value = '请输入敏感词'
    return
  }
  dialogSaving.value = true
  dialogMsg.value = ''
  try {
    await request.post({
      url: '/api/community/sensitive-words',
      data: {
        id: editingWord.value?.id || undefined,
        word: form.word.trim(),
        replacement: form.replacement.trim() || undefined,
        category: form.category.trim() || undefined
      }
    })
    closeDialog()
    loadWords()
  } catch (e) {
    dialogMsg.value = e?.message || '保存失败'
  } finally {
    dialogSaving.value = false
  }
}

function confirmDelete(item) {
  deleteTarget.value = item
  deleteVisible.value = true
}

async function doDelete() {
  if (!deleteTarget.value) return
  try {
    await request.del({ url: `/api/community/sensitive-words/${deleteTarget.value.id}` })
    deleteVisible.value = false
    deleteTarget.value = null
    loadWords()
  } catch (e) {
    /* ignore */
  }
}

onMounted(() => { loadWords() })
</script>

<style scoped>
input::placeholder { color: #c0c4cc; }
</style>
