<template>
  <div class="sm-page">
    <div class="sm-navbar">
      <button class="sm-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="sm-nav-title">数据分析</span>
      <div style="width:22px" />
    </div>

    <div class="sm-content">
      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadAll" />
      <template v-else>
        <div class="sm-section-title">数据概览</div>
        <div class="sm-stats-grid">
          <div class="sm-stat-card">
            <div class="sm-stat-val">{{ fmtNum(overview.totalPosts) }}</div>
            <div class="sm-stat-lbl">总帖子</div>
          </div>
          <div class="sm-stat-card">
            <div class="sm-stat-val">{{ fmtNum(overview.totalComments) }}</div>
            <div class="sm-stat-lbl">总评论</div>
          </div>
          <div class="sm-stat-card">
            <div class="sm-stat-val">{{ fmtNum(overview.totalSections) }}</div>
            <div class="sm-stat-lbl">板块数</div>
          </div>
          <div class="sm-stat-card sm-stat-accent">
            <div class="sm-stat-val">{{ fmtNum(overview.todayPosts) }}</div>
            <div class="sm-stat-lbl">今日帖</div>
          </div>
          <div class="sm-stat-card sm-stat-accent">
            <div class="sm-stat-val">{{ fmtNum(overview.todayComments) }}</div>
            <div class="sm-stat-lbl">今日评</div>
          </div>
          <div class="sm-stat-card sm-stat-warn">
            <div class="sm-stat-val">{{ fmtNum(overview.pendingCount) }}</div>
            <div class="sm-stat-lbl">待审核</div>
          </div>
          <div class="sm-stat-card sm-stat-warn">
            <div class="sm-stat-val">{{ fmtNum(overview.reportCount) }}</div>
            <div class="sm-stat-lbl">举报数</div>
          </div>
          <div class="sm-stat-card">
            <div class="sm-stat-val">{{ fmtNum(overview.essenceCount) }}</div>
            <div class="sm-stat-lbl">精华帖</div>
          </div>
          <div class="sm-stat-card">
            <div class="sm-stat-val">{{ fmtNum(overview.totalCollections) }}</div>
            <div class="sm-stat-lbl">合集数</div>
          </div>
          <div class="sm-stat-card sm-stat-danger">
            <div class="sm-stat-val">{{ fmtNum(overview.totalBans) }}</div>
            <div class="sm-stat-lbl">封禁数</div>
          </div>
        </div>

        <div class="sm-section-title">活跃用户</div>
        <div class="sm-active-row">
          <div class="sm-active-card">
            <div class="sm-active-val">{{ fmtNum(activeUsers.todayActiveUsers) }}</div>
            <div class="sm-active-lbl">今日活跃</div>
          </div>
          <div class="sm-active-card">
            <div class="sm-active-val">{{ fmtNum(activeUsers.weeklyActive) }}</div>
            <div class="sm-active-lbl">本周活跃</div>
          </div>
          <div class="sm-active-card">
            <div class="sm-active-val">{{ fmtNum(activeUsers.monthlyActive) }}</div>
            <div class="sm-active-lbl">本月活跃</div>
          </div>
        </div>

        <div class="sm-section-title">趋势分析 (近30天)</div>
        <div class="sm-tabs">
          <button v-for="t in trendTabs" :key="t.key" class="sm-tab" :class="{ on: trendTab === t.key }" @click="trendTab = t.key">{{ t.label }}</button>
        </div>
        <div class="sm-chart-wrap">
          <div v-if="!trends.length" class="sm-empty-chart">暂无趋势数据</div>
          <div v-else class="sm-bar-chart">
            <div v-for="item in trends" :key="item.date" class="sm-bar-row">
              <span class="sm-bar-date">{{ item.date?.slice(5) }}</span>
              <div class="sm-bar-track">
                <div class="sm-bar-fill" :style="{ width: barWidth(item) + '%' }"></div>
              </div>
              <span class="sm-bar-count">{{ trendValue(item) }}</span>
            </div>
          </div>
        </div>

        <div class="sm-section-title">板块健康度</div>
        <div v-if="!sections.length" class="sm-empty-sm">暂无板块数据</div>
        <div v-else class="sm-table-wrap">
          <div class="sm-table">
            <div class="sm-thead">
              <span class="sm-th sm-th-name">板块</span>
              <span class="sm-th">帖子</span>
              <span class="sm-th">浏览</span>
              <span class="sm-th">评论</span>
              <span class="sm-th">点赞</span>
              <span class="sm-th">近期</span>
              <span class="sm-th">版主</span>
            </div>
            <div v-for="s in sections" :key="s.name" class="sm-tr">
              <span class="sm-td sm-td-name">{{ s.name }}</span>
              <span class="sm-td">{{ fmtNum(s.postCount) }}</span>
              <span class="sm-td">{{ fmtNum(s.totalViews) }}</span>
              <span class="sm-td">{{ fmtNum(s.totalComments) }}</span>
              <span class="sm-td">{{ fmtNum(s.totalLikes) }}</span>
              <span class="sm-td">{{ fmtNum(s.recentPosts) }}</span>
              <span class="sm-td">{{ s.moderatorCount || 0 }}</span>
            </div>
          </div>
        </div>

        <div class="sm-section-title">合集收入</div>
        <div v-if="collections.totalPaid != null" class="sm-collection-summary">
          <div class="sm-col-card">
            <div class="sm-col-val">{{ fmtNum(collections.totalPaid) }}</div>
            <div class="sm-col-lbl">付费总数</div>
          </div>
          <div class="sm-col-card sm-col-accent">
            <div class="sm-col-val">{{ collections.totalRevenue || 0 }}</div>
            <div class="sm-col-lbl">总收入</div>
          </div>
        </div>
        <div v-if="!collections.list || !collections.list.length" class="sm-empty-sm">暂无合集数据</div>
        <div v-else class="sm-table-wrap">
          <div class="sm-table">
            <div class="sm-thead">
              <span class="sm-th sm-th-name">合集名称</span>
              <span class="sm-th">付费数</span>
              <span class="sm-th">收入</span>
            </div>
            <div v-for="c in (collections.list || []).slice(0, 10)" :key="c.name || c.id" class="sm-tr">
              <span class="sm-td sm-td-name">{{ c.name || c.title || '-' }}</span>
              <span class="sm-td">{{ fmtNum(c.paidCount || c.totalPaid) }}</span>
              <span class="sm-td sm-td-accent">{{ c.revenue || c.totalRevenue || 0 }}</span>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'

const loading = ref(false)
const error = ref('')

const overview = reactive({
  totalPosts: 0, totalComments: 0, totalSections: 0,
  todayPosts: 0, todayComments: 0, pendingCount: 0,
  reportCount: 0, essenceCount: 0,
  totalCollections: 0, totalBans: 0
})

const activeUsers = reactive({
  todayActiveUsers: 0, weeklyActive: 0, monthlyActive: 0
})

const trendTab = ref('posts')
const trendTabs = [
  { key: 'posts', label: '帖子' },
  { key: 'comments', label: '评论' },
  { key: 'users', label: '用户' }
]
const trends = ref([])

const sections = ref([])

const collections = reactive({ totalPaid: null, totalRevenue: 0, list: [] })

function fmtNum(n) {
  if (n == null) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

function trendValue(item) {
  if (trendTab.value === 'posts') return item.postCount || item.post_count || 0
  if (trendTab.value === 'comments') return item.commentCount || item.comment_count || 0
  return item.userCount || item.user_count || item.activeUsers || 0
}

function barWidth(item) {
  const max = trends.value.reduce((m, t) => Math.max(m, trendValue(t)), 0)
  if (!max) return 0
  return Math.round((trendValue(item) / max) * 100)
}

async function loadAll() {
  loading.value = true
  error.value = ''
  try {
    try {
      const d = await request.get({ url: '/api/community/analytics/overview' })
      Object.assign(overview, {
        totalPosts: (d && d.totalPosts) || (d && d.total_posts) || 0,
        totalComments: (d && d.totalComments) || (d && d.total_comments) || 0,
        totalSections: (d && d.totalSections) || (d && d.total_sections) || 0,
        todayPosts: (d && d.todayPosts) || (d && d.today_posts) || 0,
        todayComments: (d && d.todayComments) || (d && d.today_comments) || 0,
        pendingCount: (d && d.pendingCount) || (d && d.pending_count) || 0,
        reportCount: (d && d.reportCount) || (d && d.report_count) || 0,
        essenceCount: (d && d.essenceCount) || (d && d.essence_count) || 0,
        totalCollections: (d && d.totalCollections) || (d && d.total_collections) || 0,
        totalBans: (d && d.totalBans) || (d && d.total_bans) || 0
      })
      Object.assign(activeUsers, {
        todayActiveUsers: (d && d.todayActiveUsers) || (d && d.today_active_users) || 0,
        weeklyActive: (d && d.weeklyActive) || (d && d.weekly_active) || 0,
        monthlyActive: (d && d.monthlyActive) || (d && d.monthly_active) || 0
      })
    } catch (_) { /* ignore */ }

    try {
      const d = await request.get({ url: '/api/community/analytics/trends', params: { days: 30 } })
      const postsArr = Array.isArray(d && d.posts) ? d.posts : []
      const commentsArr = Array.isArray(d && d.comments) ? d.comments : []
      const usersArr = Array.isArray(d && d.users) ? d.users : []
      const dateMap = {}
      postsArr.forEach(function(p) { if (p.date) { var old = dateMap[p.date] || {}; dateMap[p.date] = { date: p.date, postCount: p.cnt || 0, commentCount: old.commentCount || 0, userCount: old.userCount || 0 } } })
      commentsArr.forEach(function(c) { if (c.date) { var old = dateMap[c.date] || {}; dateMap[c.date] = { date: c.date, postCount: old.postCount || 0, commentCount: c.cnt || 0, userCount: old.userCount || 0 } } })
      usersArr.forEach(function(u) { if (u.date) { var old = dateMap[u.date] || {}; dateMap[u.date] = { date: u.date, postCount: old.postCount || 0, commentCount: old.commentCount || 0, userCount: u.cnt || 0 } } })
      trends.value = Object.keys(dateMap).map(function(k) { return dateMap[k] }).sort(function(a, b) { return a.date.localeCompare(b.date) })
    } catch (_) { /* ignore */ }

    try {
      const d = await request.get({ url: '/api/community/analytics/sections' })
      const raw = d && (d.records || d.list || (Array.isArray(d) ? d : null))
      sections.value = Array.isArray(raw) ? raw : []
    } catch (_) { /* ignore */ }

    try {
      const d = await request.get({ url: '/api/community/analytics/collections' })
      collections.totalPaid = d && (d.totalPaid || d.total_paid)
      collections.totalRevenue = d && (d.totalRevenue || d.total_revenue) || 0
      const raw = d && (d.records || d.list || d.top || (Array.isArray(d) ? d : null))
      collections.list = Array.isArray(raw) ? raw : []
    } catch (_) { /* ignore */ }
  } catch (e) {
    error.value = (e && e.response && e.response.data && e.response.data.msg) || (e && e.message) || '加载数据失败'
  } finally {
    loading.value = false
  }
}

onMounted(() => { loadAll() })
</script>

<style scoped>
.sm-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.sm-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.sm-nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; transition: background .15s; }
.sm-nav-back:active { background: #f0f0f0; }
.sm-nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

.sm-content { padding: 16px; }

.sm-loading { display: flex; justify-content: center; padding: 48px 0; }
.sm-spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.sm-error { text-align: center; padding: 48px 16px; }
.sm-error-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }

.sm-section-title { font-size: 15px; font-weight: 700; color: #1a1a1a; margin-bottom: 12px; margin-top: 20px; }
.sm-section-title:first-child { margin-top: 0; }

.sm-stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 4px; }
.sm-stat-card { background: #fff; border-radius: 12px; padding: 16px 12px; text-align: center; }
.sm-stat-val { font-size: 22px; font-weight: 800; color: #1a1a1a; line-height: 1.2; }
.sm-stat-lbl { font-size: 12px; color: #999; margin-top: 4px; }
.sm-stat-accent .sm-stat-val { color: #00BFA5; }
.sm-stat-warn .sm-stat-val { color: #F59E0B; }
.sm-stat-danger .sm-stat-val { color: #EF4444; }

.sm-active-row { display: flex; gap: 10px; margin-bottom: 4px; }
.sm-active-card { flex: 1; background: #fff; border-radius: 12px; padding: 16px 12px; text-align: center; }
.sm-active-val { font-size: 20px; font-weight: 800; color: #6366F1; line-height: 1.2; }
.sm-active-lbl { font-size: 12px; color: #999; margin-top: 4px; }

.sm-tabs { display: flex; background: #fff; border-radius: 10px; padding: 4px; gap: 4px; margin-bottom: 12px; }
.sm-tab { flex: 1; padding: 8px 0; font-size: 13px; color: #888; background: none; border: none; border-radius: 8px; cursor: pointer; transition: all .12s; font-weight: 500; }
.sm-tab.on { background: #6366F1; color: #fff; font-weight: 600; }

.sm-chart-wrap { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 4px; }
.sm-empty-chart { text-align: center; padding: 32px 0; color: #bbb; font-size: 13px; }
.sm-bar-chart { display: flex; flex-direction: column; gap: 6px; }
.sm-bar-row { display: flex; align-items: center; gap: 8px; }
.sm-bar-date { font-size: 11px; color: #aaa; width: 46px; flex-shrink: 0; text-align: right; }
.sm-bar-track { flex: 1; height: 18px; background: #f0f2f5; border-radius: 4px; overflow: hidden; }
.sm-bar-fill { height: 100%; background: linear-gradient(90deg, #6366F1, #818CF8); border-radius: 4px; min-width: 2px; transition: width .3s; }
.sm-bar-count { font-size: 12px; color: #666; width: 40px; flex-shrink: 0; font-weight: 600; }

.sm-empty-sm { text-align: center; padding: 32px 16px; color: #bbb; font-size: 13px; }

.sm-table-wrap { background: #fff; border-radius: 12px; overflow: hidden; margin-bottom: 4px; overflow-x: auto; -webkit-overflow-scrolling: touch; }
.sm-table { min-width: 560px; }
.sm-thead { display: flex; background: #f8f9fc; border-bottom: 1px solid #eee; font-size: 12px; font-weight: 600; color: #888; }
.sm-th { flex: 1; padding: 10px 8px; text-align: center; }
.sm-th-name { flex: 2; text-align: left; }
.sm-tr { display: flex; border-bottom: 1px solid #f5f5f5; font-size: 13px; color: #333; }
.sm-tr:last-child { border-bottom: none; }
.sm-td { flex: 1; padding: 10px 8px; text-align: center; }
.sm-td-name { flex: 2; text-align: left; font-weight: 600; color: #1a1a1a; }
.sm-td-accent { color: #00BFA5; font-weight: 600; }

.sm-collection-summary { display: flex; gap: 10px; margin-bottom: 12px; }
.sm-col-card { flex: 1; background: #fff; border-radius: 12px; padding: 16px 12px; text-align: center; }
.sm-col-val { font-size: 20px; font-weight: 800; color: #1a1a1a; line-height: 1.2; }
.sm-col-lbl { font-size: 12px; color: #999; margin-top: 4px; }
.sm-col-accent .sm-col-val { color: #00BFA5; }

.sm-btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; transition: all .12s; white-space: nowrap; font-weight: 500; }
.sm-btn:active { background: #f5f5f5; }
.sm-btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.sm-btn-primary:active { background: #4F46E5; }
.sm-btn-danger { background: #EF4444; color: #fff; border-color: #EF4444; }
.sm-btn-danger:active { background: #DC2626; }
.sm-btn-ghost { border-color: transparent; color: #6366F1; background: transparent; }
.sm-btn-ghost:active { background: #EEF2FF; }
.sm-btn:disabled { opacity: .5; cursor: not-allowed; }

.sm-tag { display: inline-block; font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 600; }
.sm-tag-off { background: #FEE2E2; color: #DC2626; }
.sm-tag-ok { background: #D1FAE5; color: #059669; }
.sm-tag-essence { background: #FEF3C7; color: #D97706; }
</style>
