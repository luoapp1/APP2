<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()"><svg viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2.2"/></svg></button>
      <span class="title">卡池管理</span>
      <button class="save-btn" @click="showCreate = true">+ 新建</button>
    </div>

    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>

    <div v-else class="list">
      <div v-if="!pools.length" class="empty">暂无卡池，点击"+ 新建"创建</div>
      <div v-for="p in pools" :key="p.id" class="pool-card" @click="openPool(p)">
        <div class="pool-info">
          <div class="pool-name">{{ p.name }}</div>
          <div class="pool-meta">
            <span class="tag">{{ typeLabel(p.type) }}</span>
            <span class="tag" :class="p.status === 'active' ? 'tag-active' : 'tag-off'">{{ p.status === 'active' ? '启用' : '停用' }}</span>
            <span>卡密 {{ p.used_count || 0 }} / {{ p.total_count || 0 }}</span>
            <span v-if="p.expiry_days">有效期 {{ p.expiry_days }}天</span>
            <span v-if="p.total_count > 0 && p.total_count <= (p.warning_threshold || 20)" class="tag tag-warn">缺货预警</span>
            <span v-if="p.total_count === 0" class="tag tag-empty">已空</span>
          </div>
        </div>
        <span class="arrow">&#8250;</span>
      </div>
    </div>

    <!-- 创建/编辑弹窗 -->
    <div v-if="showCreate || editingPool" class="overlay" @click.self="closeEditor">
      <div class="sheet">
        <div class="sheet-header">
          <span>{{ editingPool ? '编辑卡池' : '新建卡池' }}</span>
          <span class="close" @click="closeEditor">&times;</span>
        </div>
        <div class="sheet-body">
          <div class="field"><label>名称 <span class="req">*</span></label><input v-model="form.name" class="input" placeholder="如：100元点券卡池" /></div>
          <div class="field"><label>类型</label><select v-model="form.type" class="input"><option value="card_key">卡密</option><option value="invite_code">邀请码</option></select></div>
          <div class="field"><label>卡密子类型</label><select v-model="form.card_type" class="input"><option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option><option value="free">通用卡</option></select></div>
          <template v-if="form.card_type === 'membership'">
            <div class="field"><label>会员等级</label><select v-model="form.target_id" class="input"><option :value="0">请选择</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div>
          </template>
          <div class="field-row">
            <div class="field"><label>{{ form.card_type === 'membership' ? '有效天数' : '发放数量' }}</label><input v-model.number="form.value" type="number" min="0" class="input" /></div>
            <div class="field" v-if="form.card_type === 'membership'"><label>时间单位</label><select v-model="form.duration_unit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div>
          </div>
          <div class="field"><label>有效期（天，0=永不过期）</label><input v-model.number="form.expiry_days" type="number" min="0" class="input" /></div>
          <div class="field"><label>补货预警阈值</label><input v-model.number="form.warning_threshold" type="number" min="0" class="input" placeholder="低于此数显示预警" /></div>
          <div class="field"><label>描述</label><input v-model="form.description" class="input" placeholder="可选" /></div>
        </div>
        <div class="sheet-footer">
          <button v-if="editingPool" class="btn-danger" @click="delPool">删除</button>
          <button class="btn-primary" @click="savePool">{{ editingPool ? '更新' : '创建' }}</button>
        </div>
      </div>
    </div>

    <!-- 导入卡密弹窗 -->
    <div v-if="importPool" class="overlay" @click.self="importPool = null">
      <div class="sheet">
        <div class="sheet-header">
          <span>导入卡密 - {{ importPool.name }}</span>
          <span class="close" @click="importPool = null">&times;</span>
        </div>
        <div class="sheet-body">
          <div class="field">
            <label>粘贴卡密（一行一个，格式：卡号:密码）</label>
            <textarea v-model="importText" class="input textarea" rows="8" placeholder="AA001:pass123&#10;AA002:pass456" />
          </div>
          <div class="field">
            <label>或上传 CSV 文件</label>
            <input type="file" accept=".csv,.txt" @change="handleFileImport" />
          </div>
          <div v-if="importResult" class="import-result">
            <div class="result-item">新增：{{ importResult.added }} 条</div>
            <div class="result-item">重复跳过：{{ importResult.duplicates }} 条</div>
            <div class="result-item">总计：{{ importResult.total }} 条</div>
          </div>
        </div>
        <div class="sheet-footer">
          <button class="btn-primary" @click="doImport" :disabled="!importText.trim()">导入</button>
        </div>
      </div>
    </div>

    <!-- 查看卡密列表弹窗 -->
    <div v-if="detailPool" class="overlay" @click.self="detailPool = null">
      <div class="sheet" style="max-height:90vh">
        <div class="sheet-header">
          <span>卡密列表 - {{ detailPool.name }}</span>
          <span class="close" @click="detailPool = null">&times;</span>
        </div>
        <div class="sheet-body" style="max-height:60vh;overflow-y:auto">
          <div class="pool-stats">
            <span>已用 {{ detailPool.used_count || 0 }} / 总计 {{ detailPool.total_count || 0 }}</span>
            <span v-if="detailPool.expiry_days">有效期 {{ detailPool.expiry_days }}天</span>
          </div>
          <table class="card-table" v-if="poolCards && poolCards.length">
            <thead><tr><th>卡号</th><th>密码</th></tr></thead>
            <tbody>
              <tr v-for="(c, i) in poolCards" :key="i">
                <td>{{ c.number }}</td>
                <td>{{ c.password }}</td>
              </tr>
            </tbody>
          </table>
          <div v-else class="empty">暂无卡密</div>
        </div>
        <div class="sheet-footer">
          <button class="btn-primary" @click="detailPool = null; openImport(detailPool)">导入卡密</button>
          <button class="btn-primary" @click="detailPool = null">关闭</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const pools = ref<any[]>([])
const loading = ref(true)
const showCreate = ref(false)
const editingPool = ref<any>(null)
const importPool = ref<any>(null)
const detailPool = ref<any>(null)
const importText = ref('')
const importResult = ref<any>(null)
const poolCards = ref<any[]>([])
const membershipLevels = ref<any[]>([])

const form = reactive({
  name: '', type: 'card_key', card_type: 'membership', target_id: 0,
  value: 0, duration_unit: 'day', expiry_days: 0, warning_threshold: 20, description: ''
})

function typeLabel(t: string) { return { card_key: '卡密', invite_code: '邀请码' }[t] || t }

async function loadPools() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/admin/card-pools' })
    pools.value = res.list || []
  } catch {} finally { loading.value = false }
}

function openPool(p: any) {
  detailPool.value = p
  loadPoolCards(p.id)
}

async function loadPoolCards(id: number) {
  try {
    const res: any = await request.get({ url: `/api/admin/card-pools/${id}` })
    poolCards.value = (res.cards_data || [])
    detailPool.value = res
  } catch {}
}

function closeEditor() {
  showCreate.value = false
  editingPool.value = null
  Object.assign(form, { name: '', type: 'card_key', card_type: 'membership', target_id: 0, value: 0, duration_unit: 'day', expiry_days: 0, warning_threshold: 20, description: '' })
}

async function savePool() {
  if (!form.name) return alert('请输入名称')
  try {
    if (editingPool.value) {
      await request.put({ url: `/api/admin/card-pools/${editingPool.value.id}`, data: form })
    } else {
      await request.post({ url: '/api/admin/card-pools', data: form })
    }
    closeEditor()
    await loadPools()
  } catch (e: any) { alert('保存失败: ' + (e.message || '未知错误')) }
}

async function delPool() {
  if (!confirm('确定删除？')) return
  try {
    await request.delete({ url: `/api/admin/card-pools/${editingPool.value.id}` })
    closeEditor()
    await loadPools()
  } catch (e: any) { alert('删除失败: ' + (e.message || '未知错误')) }
}

function openImport(p: any) { importPool.value = p; importText.value = ''; importResult.value = null }

async function doImport() {
  const lines = importText.value.split('\n').filter(l => l.trim())
  const cards = lines.map(line => {
    const [number, ...rest] = line.split(':')
    return { number: number.trim(), password: rest.join(':').trim() }
  })
  try {
    const res: any = await request.post({ url: `/api/admin/card-pools/${importPool.value.id}/import`, data: { cards } })
    importResult.value = res
    alert(`导入成功：新增 ${res.added} 条，重复 ${res.duplicates} 条`)
  } catch (e: any) { alert('导入失败: ' + (e.message || '未知错误')) }
}

function handleFileImport(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = (ev) => {
    importText.value = ev.target?.result as string || ''
    importResult.value = null
  }
  reader.readAsText(file)
}

async function loadMembershipLevels() {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = res || []
  } catch {}
}

onMounted(() => { loadPools(); loadMembershipLevels() })
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; position: sticky; top: 0; z-index: 10; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.save-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 16px; border-radius: 8px; font-size: 13px; cursor: pointer; }
.loading { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }
.empty { text-align: center; padding: 60px 20px; color: #ccc; font-size: 14px; }
.list { padding: 10px; }
.pool-card { background: #fff; border-radius: 10px; padding: 14px; margin-bottom: 8px; display: flex; align-items: center; cursor: pointer; }
.pool-card:active { background: #fafafa; }
.pool-info { flex: 1; }
.pool-name { font-size: 14px; font-weight: 600; color: #333; }
.pool-meta { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 4px; font-size: 11px; color: #999; align-items: center; }
.tag { background: #f0f0f0; padding: 1px 8px; border-radius: 4px; font-size: 10px; }
.tag-active { background: #E8F5E9; color: #4CAF50; }
.tag-off { background: #FFF3E0; color: #FF9800; }
.tag-warn { background: #FFF3E0; color: #E65100; }
.tag-empty { background: #FFEBEE; color: #C62828; }
.arrow { color: #ccc; font-size: 18px; }

.overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 100; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; }
.sheet { width: 100%; background: #fff; border-radius: 16px 16px 0 0; max-height: 85vh; display: flex; flex-direction: column; }
.sheet-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; border-bottom: 1px solid #f0f0f0; font-weight: 700; font-size: 16px; }
.close { font-size: 22px; cursor: pointer; color: #999; }
.sheet-body { padding: 14px 18px; overflow-y: auto; flex: 1; }
.sheet-footer { padding: 12px 18px 24px; display: flex; gap: 8px; justify-content: flex-end; border-top: 1px solid #f0f0f0; }

.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.req { color: #FF6B6B; }
.input { width: 100%; height: 38px; border: 1px solid #e0e0e0; border-radius: 8px; padding: 0 12px; font-size: 13px; outline: none; box-sizing: border-box; background: #fafafa; }
.input:focus { border-color: #FF6B6B; background: #fff; }
.textarea { height: auto; padding: 10px 12px; resize: none; }
.field-row { display: flex; gap: 8px; }
.field-row .field { flex: 1; }

.btn-primary { border: none; background: #FF6B6B; color: #fff; padding: 8px 20px; border-radius: 8px; font-size: 13px; cursor: pointer; }
.btn-primary:disabled { opacity: .5; }
.btn-danger { border: 1px solid #FF6B6B; background: #fff; color: #FF6B6B; padding: 8px 20px; border-radius: 8px; font-size: 13px; cursor: pointer; }

.import-result { background: #f5f6f8; border-radius: 8px; padding: 10px 14px; margin-top: 10px; }
.result-item { font-size: 12px; color: #666; padding: 2px 0; }

.pool-stats { font-size: 12px; color: #999; margin-bottom: 10px; display: flex; gap: 12px; }
.card-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.card-table th, .card-table td { padding: 8px 10px; border-bottom: 1px solid #f0f0f0; text-align: left; }
.card-table th { background: #fafafa; color: #666; font-weight: 600; position: sticky; top: 0; }
</style>
