<template>
  <div class="md-page">
    <!-- 顶部导航 -->
    <div class="md-header">
      <div class="md-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span class="md-title">我的装饰</span>
    </div>

    <!-- Tab 切换 -->
    <div class="md-tabs">
      <div
        v-for="tab in tabs"
        :key="tab.key"
        class="md-tab"
        :class="{ 'md-tab--active': activeTab === tab.key }"
        @click="switchTab(tab.key)"
      >{{ tab.label }}</div>
    </div>

    <!-- 内容区 -->
    <div class="md-body" @scroll="onBodyScroll" ref="bodyRef">
      <!-- 加载中 -->
      <div v-if="loading" class="md-loading">加载中...</div>

      <!-- 空态 -->
      <div v-else-if="!loading && items.length === 0" class="md-empty">暂无数据</div>

      <!-- 网格列表 -->
      <div v-else class="md-grid">
        <div
          v-for="item in items"
          :key="item.id"
          class="md-card"
          :class="{ 'md-card--active': item.isActive, 'md-card--unowned': !item.owned }"
          @click="handleClick(item)"
        >
          <div class="md-card-img-wrap">
            <img
              v-if="item.image_url"
              :src="$fixImgUrl(item.image_url)"
              class="md-card-img"
              loading="lazy"
            />
            <span v-else class="md-card-img-placeholder">{{ (item.name || '?')[0] }}</span>
            <div v-if="!item.owned" class="md-card-lock">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
            </div>
          </div>
          <div class="md-card-name">{{ item.name }}</div>
          <div class="md-card-status" :class="{ 'md-card-status--active': item.isActive }">
            {{ item.isActive ? '使用中' : (item.owned ? '未佩戴' : '未获取') }}
          </div>
          <div v-if="item.isActive" class="md-card-badge">使用中</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()

const tabs = [
  { key: 'avatar_frame', label: '头像框' },
  { key: 'title', label: '称号' },
  { key: 'avatar_effect', label: '头像特效' },
  { key: 'comment_background', label: '评论背景' },
  { key: 'nickname_effect', label: '昵称特效' },
  { key: 'home_bg', label: '主页背景' },
]

const activeTab = ref('avatar_frame')
const items = ref<any[]>([])
const activeId = ref(0)
const loading = ref(false)
const bodyRef = ref<HTMLElement>()

const isLogin = computed(() => userStore.isLogin)

const switchTab = (key: string) => {
  if (activeTab.value === key) return
  activeTab.value = key
  loadItems()
}

const loadItems = async () => {
  if (!isLogin.value) { items.value = []; return }
  loading.value = true
  try {
    const type = activeTab.value
    let res: any

    if (type === 'avatar_frame') {
      res = await request.get({ url: '/api/user/avatar-frames' })
      const data = res?.data || res || {}
      const list = data.items || []
      items.value = list.map((f: any) => ({
        ...f,
        image_url: f.image_url,
        owned: f.owned,
        isActive: f.isActive,
      }))
      activeId.value = data.activeId || 0
    } else if (type === 'title') {
      const [allRes, userRes] = await Promise.all([
        request.get({ url: '/api/title/list' }),
        request.get({ url: '/api/user/titles' }),
      ])
      const allTitles = allRes?.data || allRes || []
      const userTitles = userRes?.data || userRes || []
      const activeTitles = userRes?.active || []
      const ownedMap: Record<number, any> = {}
      userTitles.forEach((t: any) => { ownedMap[t.id || t.title_id] = t })
      const activeSet = new Set(activeTitles.map((t: any) => t.id || t.title_id))
      items.value = allTitles.map((t: any) => ({
        ...t,
        image_url: t.icon,
        owned: !!ownedMap[t.id],
        isActive: activeSet.has(t.id),
      }))
    } else {
      res = await request.get({ url: '/api/user/decorations-with-ownership', params: { type } })
      const data = res?.data || res || {}
      items.value = (data.items || []).map((d: any) => ({
        ...d,
        image_url: d.image_url,
        owned: d.owned,
        isActive: d.isActive,
      }))
      activeId.value = data.activeId || 0
    }
  } catch {} finally { loading.value = false }
}

const handleClick = async (item: any) => {
  if (loading.value || !item.owned) return
  const type = activeTab.value

  try {
    if (type === 'avatar_frame') {
      if (item.isActive) {
        await request.post({ url: '/api/user/active-frame', data: { frameId: 0 } })
      } else {
        await request.post({ url: '/api/user/active-frame', data: { frameId: item.id } })
      }
    } else if (type === 'title') {
      if (item.isActive) {
        await request.post({ url: '/api/user/active-title', data: { titleId: 0 } })
      } else {
        await request.post({ url: '/api/user/active-title', data: { titleId: item.id, slot: 1 } })
      }
    } else {
      if (item.isActive) {
        await request.post({ url: '/api/user/cancel-decoration', data: { type, decoration_id: item.id } })
      } else {
        await request.post({ url: '/api/user/activate-decoration', data: { type, decoration_id: item.id } })
      }
    }
    loadItems()
  } catch {}
}

const onBodyScroll = () => {}

onMounted(() => {
  if (isLogin.value) loadItems()
})
</script>

<style scoped>
.md-page { min-height: 100vh; display: flex; flex-direction: column; background: var(--app-page-bg, #f7f8fc); }
.md-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.md-back { cursor: pointer; }
.md-title { font-size: 17px; font-weight: 600; color: #222; }
.md-tabs { display: flex; gap: 0; padding: 0 8px; background: #fff; border-bottom: 1px solid #f3f4f6; overflow-x: auto; }
.md-tab { padding: 10px 12px; font-size: 13px; color: #9ca3af; cursor: pointer; white-space: nowrap; position: relative; flex-shrink: 0; }
.md-tab--active { color: #1f2937; font-weight: 600; }
.md-tab--active::after { content: ''; position: absolute; bottom: 0; left: 12px; right: 12px; height: 3px; border-radius: 2px; background: #FF4757; }
.md-body { flex: 1; overflow-y: auto; padding: 12px 16px; }
.md-loading { text-align: center; padding: 60px 0; color: #9ca3af; }
.md-empty { text-align: center; padding: 60px 0; color: #9ca3af; }
.md-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.md-card { background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; border: 2px solid transparent; position: relative; transition: all .15s; }
.md-card--active { border-color: #FF4757; transform: scale(1.03); }
.md-card--unowned { opacity: .5; }
.md-card-img-wrap { position: relative; width: 56px; height: 56px; margin-bottom: 8px; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; background: #f3f4f6; }
.md-card-img { width: 100%; height: 100%; object-fit: contain; }
.md-card-img-placeholder { font-size: 22px; font-weight: 800; color: #d1d5db; }
.md-card-lock { position: absolute; inset: 0; background: rgba(0,0,0,.35); display: flex; align-items: center; justify-content: center; border-radius: 8px; }
.md-card-name { font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; line-height: 1.2; margin-bottom: 4px; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.md-card-status { font-size: 10px; }
.md-card--unowned .md-card-status { color: #d1d5db; }
.md-card:not(.md-card--unowned) .md-card-status { color: #10b981; }
.md-card-status--active { color: #FF4757 !important; }
.md-card-badge { position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px; }
</style>
