<template>
  <div class="messages-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">&lt; 返回</button>
      <h2>消息中心</h2>
    </div>
    <div class="tabs">
      <button :class="{ active: activeTab === 'all' }" @click="activeTab = 'all'">全部</button>
      <button :class="{ active: activeTab === 'notification' }" @click="activeTab = 'notification'">通知</button>
      <button :class="{ active: activeTab === 'message' }" @click="activeTab = 'message'">私信</button>
      <button :class="{ active: activeTab === 'system' }" @click="activeTab = 'system'">系统</button>
    </div>
    <div class="msg-list">
      <div class="msg-item" v-for="msg in filteredMessages" :key="msg.id" @click="handleRead(msg)">
        <div class="msg-left">
          <div class="msg-avatar" :style="{ background: msg.avatarBg || '#4ECDC4' }">
            {{ (msg.from_user_name || '系')[0] }}
          </div>
        </div>
        <div class="msg-body">
          <div class="msg-header">
            <span class="msg-from">{{ msg.from_user_name || '系统消息' }}</span>
            <span class="msg-time">{{ formatTime(msg.create_time) }}</span>
          </div>
          <div class="msg-title">{{ msg.title || msg.content }}</div>
        </div>
        <div class="msg-unread" v-if="!msg.is_read"></div>
      </div>
      <div class="empty" v-if="filteredMessages.length === 0 && !loading">暂无消息</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { useRouter } from 'vue-router'
import request from '@/utils/http'

const userStore = useUserStore()
const router = useRouter()
const activeTab = ref('all')
const notifications = ref([])
const privateMessages = ref([])
const systemAlerts = ref([])
const loading = ref(true)

onMounted(async () => {
  const uid = userStore.info?.id
  try {
    const notifRes = await request.get({ url: '/api/notifications?page=1&pageSize=50' })
    const list = notifRes?.list || []
    notifications.value = list
      .filter(n => n.type !== 'announcement')
      .map(n => ({
        id: n.id,
        type: 'notification',
        title: n.title,
        content: n.content,
        from_user_name: n.fromUserName || '',
        from_user_id: n.fromUserId,
        is_read: n.isRead === 1,
        create_time: n.createTime,
        avatarBg: '#FF9800'
      }))
    systemAlerts.value = list
      .filter(n => n.type === 'announcement')
      .map(n => ({
        id: n.id,
        type: 'system',
        title: n.title,
        content: n.content,
        from_user_name: '系统消息',
        from_user_id: 0,
        is_read: n.isRead === 1,
        create_time: n.createTime,
        avatarBg: '#4CAF50'
      }))
  } catch {}
  try {
    const msgRes = await request.get({ url: '/api/messages/conversations', params: { userId: uid } })
    privateMessages.value = (Array.isArray(msgRes) ? msgRes : []).map(m => ({
      id: `conv-${m.userId}`,
      type: 'message',
      title: m.lastContent || '',
      content: m.lastContent || '',
      from_user_name: m.userName || '',
      from_user_id: m.userId,
      is_read: !m.unread,
      create_time: m.lastTime,
      avatarBg: '#2196F3'
    }))
  } catch {}
  loading.value = false
})

const allMessages = computed(() => {
  const all = [
    ...notifications.value,
    ...privateMessages.value,
    ...systemAlerts.value
  ]
  all.sort((a, b) => new Date(b.create_time || 0).getTime() - new Date(a.create_time || 0).getTime())
  return all
})

const filteredMessages = computed(() => {
  if (activeTab.value === 'all') return allMessages.value
  if (activeTab.value === 'notification') return notifications.value
  if (activeTab.value === 'message') return privateMessages.value
  if (activeTab.value === 'system') return systemAlerts.value
  return []
})

function handleRead(msg) {
  if (msg.type === 'notification' || msg.type === 'system') {
    request.post({ url: '/api/notifications/read-all' }).catch(() => {})
    const target = msg.type === 'notification' ? notifications : systemAlerts
    const item = target.value.find(i => i.id === msg.id)
    if (item) item.is_read = true
  } else if (msg.type === 'message' && msg.from_user_id) {
    router.push(`/chat/${msg.from_user_id}`)
  }
}

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  const now = new Date()
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  }
  return d.toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' })
}
</script>

<style scoped>
.messages-page { min-height: 100vh; background: #f5f5f5; }
.header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; }
.header h2 { margin: 0; font-size: 18px; }
.back-btn { background: none; border: none; color: #2196F3; font-size: 14px; cursor: pointer; }
.tabs { display: flex; background: #fff; border-bottom: 1px solid #eee; }
.tabs button { flex: 1; padding: 12px 0; border: none; background: none; font-size: 14px; color: #666; cursor: pointer; border-bottom: 2px solid transparent; }
.tabs button.active { color: #2196F3; border-bottom-color: #2196F3; }
.msg-list { background: #fff; }
.msg-item { display: flex; align-items: center; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; cursor: pointer; }
.msg-item:active { background: #f9f9f9; }
.msg-left { margin-right: 10px; }
.msg-avatar { width: 40px; height: 40px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 500; }
.msg-body { flex: 1; min-width: 0; }
.msg-header { display: flex; justify-content: space-between; align-items: center; }
.msg-from { font-size: 14px; font-weight: 500; color: #333; }
.msg-time { font-size: 11px; color: #bbb; }
.msg-title { font-size: 12px; color: #999; margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.msg-unread { width: 8px; height: 8px; border-radius: 50%; background: #f44336; margin-left: 10px; flex-shrink: 0; }
.empty { text-align: center; padding: 60px 0; color: #999; font-size: 14px; }
</style>
