<template>
  <div style="min-height: 100vh; background: #f5f6fa; padding-bottom: 40px; display: flex; flex-direction: column;">
    <div style="background: #fff; flex-shrink: 0; position: sticky; top: 0; z-index: 10;">
      <div style="display: flex; align-items: center; justify-content: space-between; height: 46px; padding: 0 16px; border-bottom: 1px solid #f0f0f0;">
        <button style="background: none; border: none; padding: 4px; color: #333; cursor: pointer; display: flex; align-items: center;" @click="$router.back()">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span style="font-size: 17px; font-weight: 600; color: #1a1a2e;">我的合集</span>
        <button v-if="collectionsActiveTab === 'mine'" style="background: #6366f1; color: #fff; border: none; padding: 6px 16px; border-radius: 16px; font-size: 14px; cursor: pointer;" @click="goCreateCollection">新建</button>
        <button v-else-if="collectionsActiveTab === 'apps'" style="background: #6366f1; color: #fff; border: none; padding: 6px 16px; border-radius: 16px; font-size: 14px; cursor: pointer;" @click="openAppColCreate">新建</button>
        <div v-else style="width: 52px;"></div>
      </div>
      <div style="padding: 10px 16px;">
        <div style="display: flex; background: #f2f3f6; border-radius: 10px; padding: 3px;">
          <button
            style="flex: 1; padding: 7px 0; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all .25s;"
            :style="collectionsActiveTab === 'mine' ? { color: '#1a1a2e', background: '#fff', fontWeight: '600', boxShadow: '0 1px 3px rgba(0,0,0,.08)' } : { color: '#999', background: 'transparent' }"
            @click="switchCollectionsTab('mine')"
          >帖子合集</button>
          <button
            style="flex: 1; padding: 7px 0; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all .25s;"
            :style="collectionsActiveTab === 'apps' ? { color: '#1a1a2e', background: '#fff', fontWeight: '600', boxShadow: '0 1px 3px rgba(0,0,0,.08)' } : { color: '#999', background: 'transparent' }"
            @click="switchCollectionsTab('apps')"
          >应用合集</button>
          <button
            style="flex: 1; padding: 7px 0; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all .25s;"
            :style="collectionsActiveTab === 'paid' ? { color: '#1a1a2e', background: '#fff', fontWeight: '600', boxShadow: '0 1px 3px rgba(0,0,0,.08)' } : { color: '#999', background: 'transparent' }"
            @click="switchCollectionsTab('paid')"
          >已购合集</button>
        </div>
      </div>
    </div>

    <div style="flex: 1; overflow-y: auto; padding: 12px 14px;">
      <template v-if="collectionsActiveTab === 'mine'">
        <div v-if="colLoading" style="text-align: center; padding: 80px 0; color: #999;">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d0d0d0" stroke-width="1.5" style="animation: spin 1s linear infinite; margin-bottom: 10px;"><circle cx="12" cy="12" r="10" stroke-dasharray="31.4" stroke-dashoffset="10"/></svg>
          <div style="font-size: 13px;">加载中...</div>
        </div>
        <template v-else>
          <div
            v-for="c in myCollectionsList"
            :key="c.id"
            style="background: #fff; border-radius: 12px; margin-bottom: 10px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.05); transition: transform .15s ease;"
            @click="openCollectionDetail(c)"
          >
            <div style="position: relative; height: 100px; overflow: hidden;">
              <img v-if="c.cover_image" :src="c.cover_image" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <div v-else style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.35)" stroke-width="1.2"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
              </div>
              <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 50px; background: linear-gradient(to top, rgba(0,0,0,.45), transparent); pointer-events: none;" />
              <div style="position: absolute; top: 8px; right: 8px; display: flex; gap: 5px;">
                <span :style="colStatusStyle(c.status)" style="font-size: 10px; padding: 2px 8px; border-radius: 8px; font-weight: 600; backdrop-filter: blur(6px);">{{ colStatusLabel(c.status) }}</span>
                <span v-if="c.is_paid" style="font-size: 10px; padding: 2px 8px; border-radius: 8px; font-weight: 600; color: #fff; background: rgba(245,108,108,.85); backdrop-filter: blur(6px);">付费</span>
              </div>
              <div v-if="c.is_paid && (c.price_balance || c.price_points)" style="position: absolute; bottom: 8px; right: 10px; z-index: 1;">
                <span v-if="c.price_balance > 0" style="font-size: 14px; font-weight: 800; color: #fff; text-shadow: 0 1px 3px rgba(0,0,0,.3);">{{ c.price_balance }}<span style="font-size: 9px; font-weight: 500; opacity: .8; margin-left: 1px;">余额</span></span>
                <span v-if="c.price_points > 0" style="font-size: 14px; font-weight: 800; color: #fff; text-shadow: 0 1px 3px rgba(0,0,0,.3); margin-left: 6px;">{{ c.price_points }}<span style="font-size: 9px; font-weight: 500; opacity: .8; margin-left: 1px;">积分</span></span>
              </div>
              <div v-if="!c.is_paid" style="position: absolute; bottom: 8px; left: 10px; z-index: 1; font-size: 11px; font-weight: 700; color: #67c23a; background: rgba(255,255,255,.85); padding: 2px 8px; border-radius: 6px;">免费</div>
            </div>
            <div style="padding: 10px 14px 12px;">
              <div style="font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 3px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">{{ c.title }}</div>
              <div v-if="c.description" style="font-size: 12px; color: #aaa; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 8px;">{{ c.description }}</div>
              <div style="display: flex; align-items: center; gap: 14px; font-size: 11px; color: #aaa; margin-bottom: 8px;">
                <span style="display: inline-flex; align-items: center; gap: 3px;">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  <span style="color: #333; font-weight: 600;">{{ c.post_count }}</span>篇
                </span>
                <span style="display: inline-flex; align-items: center; gap: 3px;">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                  <span style="color: #333; font-weight: 600;">{{ c.view_count || 0 }}</span>
                </span>
                <span v-if="c.subscribe_count > 0" style="display: inline-flex; align-items: center; gap: 3px; color: #6366f1;">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                  <span style="font-weight: 600;">{{ c.subscribe_count }}</span>
                </span>
              </div>
              <div style="display: flex; gap: 8px;">
                <button
                  style="flex: 1; padding: 7px 0; border: 1.5px solid #e0e2eb; border-radius: 8px; background: #fff; color: #6366f1; font-size: 12px; font-weight: 600; cursor: pointer;"
                  @click.stop="goEditCollection(c)"
                >编辑合集</button>
                <button
                  v-if="c.status === 'draft'"
                  style="flex: 1; padding: 7px 0; border: 1.5px solid #FEE2E2; border-radius: 8px; background: #FEF2F2; color: #EF4444; font-size: 12px; font-weight: 600; cursor: pointer;"
                  @click.stop="handleDeleteCollection(c)"
                >删除</button>
              </div>
            </div>
          </div>
          <div v-if="myCollectionsList.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 70px 20px;">
            <div style="width: 72px; height: 72px; background: linear-gradient(135deg, #f0f2f6, #e8ecf4); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 18px;">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#bbb" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
            </div>
            <div style="font-size: 15px; color: #aaa; margin-bottom: 6px;">还没有创建帖子合集</div>
            <div style="font-size: 12px; color: #ccc; margin-bottom: 18px;">将喜欢的帖子整理成合集，方便分享与查阅</div>
            <button style="background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; border: none; padding: 11px 32px; border-radius: 24px; font-size: 15px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 16px rgba(102,126,234,.35);" @click="goCreateCollection">创建第一个合集</button>
          </div>
        </template>
      </template>

      <template v-if="collectionsActiveTab === 'apps'">
        <div v-if="appColLoading" style="text-align: center; padding: 80px 0; color: #999;">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d0d0d0" stroke-width="1.5" style="animation: spin 1s linear infinite; margin-bottom: 10px;"><circle cx="12" cy="12" r="10" stroke-dasharray="31.4" stroke-dashoffset="10"/></svg>
          <div style="font-size: 13px;">加载中...</div>
        </div>
        <template v-else>
          <div
            v-for="c in appCollectionsList"
            :key="c.id"
            style="background: #fff; border-radius: 12px; margin-bottom: 12px; overflow: hidden; cursor: pointer; box-shadow: 0 1px 4px rgba(0,0,0,.06);"
            @click="$router.push('/appstore/collection/' + c.id)"
          >
            <div style="display: flex; align-items: stretch;">
              <div style="width: 90px; height: 90px; flex-shrink: 0; position: relative; overflow: hidden;">
                <img v-if="c.coverUrl" :src="c.coverUrl" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
                <div v-else style="width: 100%; height: 100%; background: linear-gradient(135deg, #F59E0B, #EF4444); display: flex; align-items: center; justify-content: center;">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
                </div>
              </div>
              <div style="flex: 1; padding: 12px 14px; display: flex; flex-direction: column; justify-content: center; min-width: 0;">
                <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 8px;">
                  <div style="font-size: 15px; font-weight: 700; color: #1a1a2e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;">{{ c.name }}</div>
                  <span :style="c.status === 'pending' ? 'background: #FEF3C7;color:#D97706' : c.status === 'rejected' ? 'background: #FEE2E2;color:#DC2626' : 'background: #D1FAE5;color:#059669'" style="font-size: 10px; padding: 2px 7px; border-radius: 6px; font-weight: 700; flex-shrink: 0; white-space: nowrap;">{{ c.status === 'pending' ? '审核中' : c.status === 'rejected' ? '已拒绝' : '已发布' }}</span>
                </div>
                <div v-if="c.description" style="font-size: 12px; color: #aaa; margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ c.description }}</div>
                <div style="display: flex; align-items: center; gap: 14px; margin-top: 6px; font-size: 11px; color: #bbb;">
                  <span style="display: flex; align-items: center; gap: 3px;">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                    {{ c.appCount || 0 }}款
                  </span>
                  <span style="display: flex; align-items: center; gap: 3px;">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                    {{ c.viewCount || 0 }}
                  </span>
                  <span style="display: flex; align-items: center; gap: 3px;">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
                    {{ c.likes || 0 }}
                  </span>
                </div>
                <div style="margin-top: 6px; display: flex; gap: 6px;">
                  <button style="flex: 1; padding: 4px 0; border: 1px solid #e5e7eb; border-radius: 6px; background: #fff; color: #6366f1; font-size: 11px; font-weight: 600; cursor: pointer;" @click.stop="openAppColEdit(c)">编辑</button>
                  <button style="flex: 1; padding: 4px 0; border: 1px solid #FEE2E2; border-radius: 6px; background: #FEF2F2; color: #EF4444; font-size: 11px; font-weight: 600; cursor: pointer;" @click.stop="handleDeleteAppCollection(c)">删除</button>
                </div>
              </div>
            </div>
          </div>
          <div v-if="appCollectionsList.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 70px 20px;">
            <div style="width: 64px; height: 64px; background: #f0f2f6; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 16px;">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#bbb" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
            </div>
            <div style="font-size: 14px; color: #bbb; margin-bottom: 16px;">还没有创建应用合集</div>
            <button style="background: linear-gradient(135deg, #F59E0B, #EF4444); color: #fff; border: none; padding: 10px 28px; border-radius: 22px; font-size: 14px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(245,158,11,.3);" @click="$router.push('/appstore/collections/mine')">去创建</button>
          </div>
        </template>
      </template>

      <template v-if="collectionsActiveTab === 'paid'">
        <div v-if="paidColLoading" style="text-align: center; padding: 80px 0; color: #999;">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d0d0d0" stroke-width="1.5" style="animation: spin 1s linear infinite; margin-bottom: 10px;"><circle cx="12" cy="12" r="10" stroke-dasharray="31.4" stroke-dashoffset="10"/></svg>
          <div style="font-size: 13px;">加载中...</div>
        </div>
        <template v-else>
          <div
            v-for="c in paidCollectionsList"
            :key="c.id"
            style="background: #fff; border-radius: 12px; margin-bottom: 12px; overflow: hidden; cursor: pointer; box-shadow: 0 1px 4px rgba(0,0,0,.06); transition: transform .15s;"
            @click="openCollectionDetail(c)"
          >
            <div style="position: relative; height: 120px; overflow: hidden; background: #f0f0f0;">
              <img v-if="c.cover_image" :src="c.cover_image" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
              <div v-else style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 60%, #f093fb 100%); display: flex; align-items: center; justify-content: center;">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.4)" stroke-width="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <div style="position: absolute; top: 8px; left: 8px; font-size: 11px; padding: 3px 10px; border-radius: 10px; font-weight: 700; color: #fff; background: #67c23a; box-shadow: 0 2px 6px rgba(103,194,58,.4);">已购买</div>
            </div>
            <div style="padding: 12px 14px 14px;">
              <div style="font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">{{ c.title }}</div>
              <div v-if="c.description" style="font-size: 12px; color: #aaa; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 8px;">{{ c.description }}</div>
              <div style="display: flex; align-items: center; gap: 16px; font-size: 12px; color: #bbb;">
                <span style="display: flex; align-items: center; gap: 3px;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  {{ c.post_count }}篇
                </span>
                <span style="display: flex; align-items: center; gap: 3px;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                  {{ c.view_count || 0 }}
                </span>
              </div>
            </div>
          </div>
          <div v-if="paidCollectionsList.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 70px 20px;">
            <div style="width: 64px; height: 64px; background: #f0f2f6; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 16px;">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#bbb" stroke-width="1.5"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
            </div>
            <div style="font-size: 14px; color: #bbb;">还没有购买任何合集</div>
          </div>
        </template>
      </template>
    </div>

    <div
      v-if="showAppColDialog"
      style="position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 110; display: flex; align-items: center; justify-content: center;"
      @click.self="cancelAppColDialog"
    >
      <div style="background: #fff; border-radius: 16px; width: 340px; padding: 24px 20px 20px; box-shadow: 0 12px 40px rgba(0,0,0,.15);">
        <div style="font-size: 16px; font-weight: 700; color: #1a1a2e; margin-bottom: 16px;">{{ isAppColCreate ? '新建应用合集' : '编辑应用合集' }}</div>
        <div style="margin-bottom: 12px;">
          <div style="font-size: 13px; font-weight: 600; color: #555; margin-bottom: 4px;">名称</div>
          <input v-model="appColForm.name" style="width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box;" placeholder="合集名称" />
        </div>
        <div style="margin-bottom: 12px;">
          <div style="font-size: 13px; font-weight: 600; color: #555; margin-bottom: 4px;">描述</div>
          <textarea v-model="appColForm.description" style="width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box; min-height: 64px; resize: vertical;" placeholder="合集描述（选填）" rows="2" />
        </div>
        <div style="margin-bottom: 12px;">
          <div style="font-size: 13px; font-weight: 600; color: #555; margin-bottom: 4px;">封面图URL</div>
          <input v-model="appColForm.coverUrl" style="width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 10px; font-size: 14px; outline: none; box-sizing: border-box;" placeholder="封面图片链接（选填）" />
        </div>
        <div style="margin-bottom: 14px;">
          <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555; cursor: pointer;">
            <input type="checkbox" v-model="appColForm.isPublic" style="width: 16px; height: 16px;" />
            公开合集（公开后所有人可见，需审核）
          </label>
        </div>
        <div style="display: flex; gap: 10px;">
          <button style="flex: 1; padding: 10px 0; border: 1.5px solid #e5e7eb; border-radius: 10px; background: #fff; color: #666; font-size: 14px; font-weight: 600; cursor: pointer;" @click="cancelAppColDialog">取消</button>
          <button style="flex: 1; padding: 10px 0; border: none; border-radius: 10px; background: linear-gradient(135deg, #6366f1, #8B5CF6); color: #fff; font-size: 14px; font-weight: 700; cursor: pointer;" :disabled="appColSaving" @click="doSaveAppCol">{{ appColSaving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { fetchMyCollections, fetchPaidCollections, deleteCollection } from '@/api/community'
import { sanitizeHtml } from '@/utils/ui/sanitize'

const router = useRouter()
const route = useRoute()

const collectionsActiveTab = ref('mine')
const myCollectionsList = ref([])
const paidCollectionsList = ref([])
const appCollectionsList = ref([])
const colLoading = ref(false)
const paidColLoading = ref(false)
const appColLoading = ref(false)

const showAppColDialog = ref(false)
const isAppColCreate = ref(true)
const appColSaving = ref(false)
const editingAppColId = ref(null)
const appColForm = ref({ name: '', description: '', coverUrl: '', isPublic: true })

function switchCollectionsTab(tab) {
  collectionsActiveTab.value = tab
  loadCollectionsData()
}

async function loadCollectionsData() {
  if (collectionsActiveTab.value === 'mine') {
    colLoading.value = true
    try {
      const data = await fetchMyCollections()
      myCollectionsList.value = data?.list || []
    } catch { myCollectionsList.value = [] }
    colLoading.value = false
  } else if (collectionsActiveTab.value === 'apps') {
    appColLoading.value = true
    try {
      const { fetchMyCollections: fetchAppMyCollections } = await import('@/api/appstore')
      const data = await fetchAppMyCollections()
      appCollectionsList.value = data || []
    } catch { appCollectionsList.value = [] }
    appColLoading.value = false
  } else {
    paidColLoading.value = true
    try {
      const data = await fetchPaidCollections()
      paidCollectionsList.value = data?.list || []
    } catch { paidCollectionsList.value = [] }
    paidColLoading.value = false
  }
}

function colStatusLabel(s) {
  const map = { draft: '草稿', serializing: '连载中', finished: '已完结' }
  return map[s] || s
}

function colStatusStyle(s) {
  const map = {
    draft: 'color: #6B7280; background: rgba(107,114,128,.15);',
    serializing: 'color: #7C3AED; background: rgba(124,58,237,.12);',
    finished: 'color: #059669; background: rgba(5,150,105,.12);'
  }
  return map[s] || 'color: #666; background: rgba(0,0,0,.1);'
}

function goCreateCollection() {
  router.push('/community/collection/create')
}

function goEditCollection(c) {
  router.push(`/community/collection/create?id=${c.id}`)
}

function openCollectionDetail(c) {
  router.push(`/community/collection/${c.id}`)
}

async function handleDeleteCollection(c) {
  if (!confirm(`确定删除合集「${c.title}」？删除后不可恢复。`)) return
  try {
    await deleteCollection(c.id)
    myCollectionsList.value = myCollectionsList.value.filter(x => x.id !== c.id)
  } catch (e) {
    alert(e.message || '删除失败')
  }
}

async function handleDeleteAppCollection(c) {
  if (!confirm(`确定删除应用合集「${c.name}」？删除后不可恢复。`)) return
  try {
    const { fetchDeleteCollection } = await import('@/api/appstore')
    await fetchDeleteCollection(c.id)
    appCollectionsList.value = appCollectionsList.value.filter(x => x.id !== c.id)
  } catch (e) {
    alert(e.message || '删除失败')
  }
}

function openAppColCreate() {
  isAppColCreate.value = true
  editingAppColId.value = null
  appColForm.value = { name: '', description: '', coverUrl: '', isPublic: true }
  showAppColDialog.value = true
}

function openAppColEdit(c) {
  isAppColCreate.value = false
  editingAppColId.value = c.id
  appColForm.value = {
    name: c.name || '',
    description: c.description || '',
    coverUrl: c.coverUrl || '',
    isPublic: c.isPublic !== false
  }
  showAppColDialog.value = true
}

function cancelAppColDialog() {
  showAppColDialog.value = false
}

async function doSaveAppCol() {
  if (!appColForm.value.name.trim()) return alert('请输入合集名称')
  appColSaving.value = true
  try {
    const { fetchCreateCollection, fetchUpdateCollection } = await import('@/api/appstore')
    const params = {
      name: appColForm.value.name,
      description: appColForm.value.description,
      coverUrl: appColForm.value.coverUrl,
      isPublic: appColForm.value.isPublic
    }
    if (isAppColCreate.value) {
      await fetchCreateCollection(params)
    } else {
      await fetchUpdateCollection(editingAppColId.value, params)
    }
    showAppColDialog.value = false
    appColLoading.value = true
    const { fetchMyCollections: fetchAppMyCollections } = await import('@/api/appstore')
    appCollectionsList.value = (await fetchAppMyCollections()) || []
    appColLoading.value = false
  } catch (e) {
    alert(e?.response?.data?.msg || e?.message || '保存失败')
  } finally {
    appColSaving.value = false
  }
}

watch(() => route.query.tab, (val) => {
  if (val === 'mine' || val === 'apps' || val === 'paid') {
    collectionsActiveTab.value = val
    loadCollectionsData()
  }
})

onMounted(() => {
  const tab = route.query.tab
  if (tab === 'mine' || tab === 'apps' || tab === 'paid') {
    collectionsActiveTab.value = tab
  }
  loadCollectionsData()
})
</script>

<style scoped>
@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
