<template>
  <div class="min-h-screen flex flex-col" style="background:var(--default-bg-color)">
    <!-- 顶部标题栏 -->
    <div class="px-4 py-3 flex items-center justify-between">
      <div class="text-base font-bold text-gray-800">私信</div>
      <div class="relative cursor-pointer" @click="$router.push('/appstore/browse/notifications')">
        <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        <div v-if="unreadNotifs > 0" class="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FF5777] text-white text-[9px] flex items-center justify-center">
          {{ unreadNotifs > 99 ? '99+' : unreadNotifs }}
        </div>
      </div>
    </div>

    <!-- 搜索栏 -->
    <div style="position:relative">
      <div class="search-bar">
        <svg class="search-icon" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="8" stroke="#999" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke="#999" stroke-width="2" stroke-linecap="round"/></svg>
        <input v-model="searchKeyword" @keyup.enter="doSearch" @input="onSearchInput" placeholder="搜索应用、帖子、商品" class="search-input" />
        <span v-if="searchKeyword" class="search-clear" @click="searchKeyword='';searchResults=[]">x</span>
      </div>
      <div class="search-results" v-if="searchResults.length > 0">
        <div class="sr-section" v-for="group in searchResults" :key="group.type">
          <div class="sr-section-title">{{ group.label }}</div>
          <div class="sr-item" v-for="item in group.items" :key="item.id" @click="goSearchResult(item)">
            <div class="sr-item-icon">{{ item.title?.[0] || '?' }}</div>
            <div class="sr-item-info">
              <div class="sr-item-name">{{ item.title }}</div>
              <div class="sr-item-desc">{{ item.description || '' }}</div>
            </div>
            <span class="sr-badge">{{ group.label }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto">

      <!-- 4个圆形功能按钮 -->
      <div class="px-4 py-4">
        <div class="flex justify-around">
          <div
            v-for="item in funcBtns"
            :key="item.label"
            class="flex flex-col items-center gap-1.5 cursor-pointer active:opacity-70"
            @click="handleFuncBtn(item.key)"
          >
            <div class="w-[50px] h-[50px] rounded-full flex items-center justify-center" :style="{ background: item.bg }">
              <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="item.icon"/></svg>
            </div>
            <span class="text-[11px] text-gray-600 font-medium">{{ item.label }}</span>
          </div>
        </div>
      </div>

      <div class="h-2" />

      <!-- 统一消息列表（聊天室 + 私信） -->
      <div class="">
        <div v-if="loadingConvs && loadingRooms" class="flex justify-center py-16">
          <div class="animate-spin w-5 h-5 border-2 border-[#00BFA5] border-t-transparent rounded-full" />
        </div>

        <div v-else-if="unifiedList.length === 0" class="flex flex-col items-center justify-center py-20">
          <svg class="w-16 h-16 text-gray-200 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
          </svg>
          <span class="text-sm text-gray-400">暂无消息</span>
        </div>

        <div v-else>
          <div
            v-for="item in unifiedList"
            :key="item._key"
            class="flex items-center gap-3 px-4 py-3 cursor-pointer active:bg-gray-50 border-b border-gray-50"
            @touchstart="item._type === 'chat' ? null : onTouchStart(item._conv)"
            @touchend="item._type === 'chat' ? enterRoom(item._room) : onTouchEnd(item._conv)"
            @touchmove="item._type === 'chat' ? null : onTouchCancel"
            @click="handleItemClick(item)"
          >
            <!-- 聊天室头像 -->
            <img
              v-if="item._type === 'chat' && resolveAvatar(item._room.avatar)"
              :src="resolveAvatar(item._room.avatar)"
              class="w-[48px] h-[48px] rounded-full object-cover flex-shrink-0"
            />
            <div
              v-else-if="item._type === 'chat'"
              class="w-[48px] h-[48px] rounded-full flex items-center justify-center flex-shrink-0"
              :style="{ background: iconBg(item._room.id) }"
            >
              <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
            </div>
            <!-- 私信用户头像 -->
            <img
              v-else-if="resolveAvatar(item._conv.userAvatar)"
              :src="resolveAvatar(item._conv.userAvatar)"
              class="w-[48px] h-[48px] rounded-full object-cover flex-shrink-0"
            />
            <img
              v-else
              src="@imgs/user/avatar.webp"
              class="w-[48px] h-[48px] rounded-full object-cover flex-shrink-0"
            />
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between">
                <span class="text-sm font-semibold text-gray-800">{{ item._type === 'chat' ? item._room.name : item._conv.userName }}</span>
                <span class="text-[10px] text-gray-400 flex-shrink-0 ml-2">{{ item._type === 'chat' ? (item._room.lastMsgTime ? fmtTime(item._room.lastMsgTime) : item._room.memberCount + '人') : fmtTime(item._conv.lastTime) }}</span>
              </div>
              <div class="text-xs text-gray-400 mt-0.5 truncate" :class="{ 'text-gray-700 font-medium': item._type === 'msg' && item._conv.unread > 0 }">
                <template v-if="item._type === 'chat'">{{ item._room.lastMsg || item._room.description || '群聊' }}</template>
                <template v-else>{{ item._conv.lastContent }}</template>
              </div>
            </div>
            <div v-if="item._type === 'msg' && item._conv.unread > 0" class="w-5 h-5 rounded-full bg-[#FF5777] text-white text-[10px] flex items-center justify-center flex-shrink-0">
              {{ item._conv.unread > 99 ? '99+' : item._conv.unread }}
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="showDeleteDialog" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="showDeleteDialog = false">
      <div class="bg-white rounded-xl w-72 overflow-hidden" @click.stop>
        <div class="px-6 py-5 text-center">
          <div class="text-base font-semibold text-gray-800 mb-2">删除该对话</div>
          <div class="text-sm text-gray-500">将不再显示此对话，对方再发消息时会重新出现</div>
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="showDeleteDialog = false">取消</div>
          <div class="flex-1 py-3 text-center text-base text-[#FF5777] font-medium cursor-pointer active:bg-gray-50" @click="confirmHide">删除</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchConversations, fetchNotifications, fetchHideConversation } from '@/api/message'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0
const unreadNotifs = ref(0)

const conversations = ref<any[]>([])
const loadingConvs = ref(false)
const myRooms = ref<any[]>([])
const loadingRooms = ref(false)

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) {
    avatarMap[`avatar:${match[1]}`] = (mod as any).default
  }
}

const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar.startsWith('http') || avatar.startsWith('/uploads')) return avatar.replace(/^http:\/\//i, 'https://')
  return ''
}

const colorPool = ['#AB47BC', '#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconBg = (id: number) => colorPool[id % colorPool.length]

const unifiedList = computed(() => {
  const items: any[] = []

  for (const r of myRooms.value) {
    items.push({ _type: 'chat', _key: 'chat-' + r.id, _room: r })
  }

  for (const c of conversations.value) {
    items.push({ _type: 'msg', _key: 'msg-' + c.userId, _conv: c })
  }

  return items
})

let longPressTimer: any = null
let longPressTarget: any = null
let isLongPressed = false
const showDeleteDialog = ref(false)
const pendingDeleteConv = ref<any>(null)

const handleItemClick = (item: any) => {
  if (item._type === 'chat') {
    enterRoom(item._room)
  }
}

const onTouchStart = (conv: any) => {
  if (conv.userId === 0 || conv.userId === -1) return
  isLongPressed = false
  longPressTarget = conv
  longPressTimer = setTimeout(() => {
    isLongPressed = true
    pendingDeleteConv.value = conv
    showDeleteDialog.value = true
  }, 600)
}

const onTouchEnd = (conv: any) => {
  if (longPressTimer) {
    clearTimeout(longPressTimer)
    longPressTimer = null
  }
  if (!isLongPressed) {
    openConversation(conv)
  }
}

const onTouchCancel = () => {
  if (longPressTimer) {
    clearTimeout(longPressTimer)
    longPressTimer = null
  }
  longPressTarget = null
}

const confirmHide = async () => {
  showDeleteDialog.value = false
  const conv = pendingDeleteConv.value
  if (!conv) return
  try {
    await fetchHideConversation(conv.userId, myUserId)
    conversations.value = conversations.value.filter(c => c.userId !== conv.userId)
  } catch {}
  pendingDeleteConv.value = null
}

const funcBtns = [
  { key: 'chatroom', label: '聊天室', bg: 'linear-gradient(135deg, #AB47BC, #8E24AA)', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z' },
  { key: 'comments', label: '评论消息', bg: 'linear-gradient(135deg, #448AFF, #2979FF)', icon: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z' },
  { key: 'notif', label: '系统通知', bg: 'linear-gradient(135deg, #FF5777, #EF4444)', icon: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
  { key: 'messages', label: '消息中心', bg: 'linear-gradient(135deg, #FF9800, #F57C00)', icon: 'M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z' },
  { key: 'sponsor', label: '赞助', bg: 'linear-gradient(135deg, #66BB6A, #43A047)', icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z' },
]

const handleFuncBtn = (key: string) => {
  if (key === 'chatroom') {
    router.push('/appstore/discover/chatrooms')
  } else if (key === 'comments') {
    router.push('/appstore/discover/comments')
  } else if (key === 'notif') {
    router.push('/appstore/browse/notifications')
  } else if (key === 'messages') {
    router.push('/appstore/browse/notifications')
  } else if (key === 'sponsor') {
    router.push('/appstore/reports')
  }
}

const enterRoom = (r: any) => {
  router.push(`/appstore/discover/chatroom/${r.id}`)
}

const openConversation = (conv: any) => {
  if (conv.userId === 0) {
    router.push('/appstore/browse/notifications')
  } else if (conv.userId === -1) {
    router.push('/appstore/discover/comments')
  } else {
    router.push(`/appstore/discover/chat/${conv.userId}`)
  }
}

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  const s = t.replace(' ', 'T')
  if (/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/.test(s)) return new Date(s)
  return new Date(s + 'Z')
}

const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
  if (diff < 2592000000) return Math.floor(diff / 2592000000) + '个月前'
  return (d.getMonth() + 1) + '/' + d.getDate()
}

const loadUnreadNotifs = async () => {
  try {
    const res: any = await fetchNotifications(myUserId, 1, 'system')
    unreadNotifs.value = res.unread || 0
  } catch {}
}

const loadConversations = async () => {
  loadingConvs.value = true
  try {
    const res: any = await fetchConversations(myUserId)
    const convs = Array.isArray(res) ? res : (res.list || [])
    conversations.value = convs
  } catch {}
  loadingConvs.value = false
}

const loadMyRooms = async () => {
  loadingRooms.value = true
  if (!myUserId) { loadingRooms.value = false; return }
  try {
    const res: any = await request.get({ url: '/api/chat-rooms/my', params: { userId: myUserId } })
    myRooms.value = Array.isArray(res) ? res : (res.list || [])
  } catch {}
  loadingRooms.value = false
}

const searchKeyword = ref('')
const searchResults = ref<any[]>([])
const onSearchInput = () => { if (!searchKeyword.value) searchResults.value = [] }
const doSearch = async () => {
  if (!searchKeyword.value.trim()) return
  try {
    const res: any = await request.get({ url: '/api/search', params: { keyword: searchKeyword.value, type: 'all' } })
    searchResults.value = [
      { type: 'apps', label: '应用/帖子', items: res?.apps || [] },
      { type: 'products', label: '商品', items: res?.products || [] },
      { type: 'assets', label: '素材', items: res?.assets || [] }
    ].filter(g => g.items.length > 0)
  } catch { searchResults.value = [] }
}
const goSearchResult = (item: any) => {
  if (item.type === 'product') router.push(`/appstore/mall-detail/${item.id}`)
  else if (item.type === 'post') router.push(`/community/post/${item.id}`)
  else router.push(`/appstore/browse/detail/${item.id}`)
}

onMounted(async () => {
  await loadUnreadNotifs()
  loadConversations()
  loadMyRooms()
})
</script>

<style scoped>
.search-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 16px 8px;
  padding: 8px 14px;
  background: #f3f4f6;
  border-radius: 22px;
}
.search-icon {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}
.search-input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-size: 14px;
  color: #111;
}
.search-input::placeholder {
  color: #9ca3af;
}
.search-clear {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: #d1d5db;
  color: #fff;
  font-size: 10px;
  cursor: pointer;
  line-height: 1;
}
.search-results {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 50;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,.12);
  max-height: 60vh;
  overflow-y: auto;
  margin: 4px 16px 0;
}
.sr-section {
  padding: 8px 0 4px;
}
.sr-section-title {
  font-size: 11px;
  color: #9ca3af;
  font-weight: 600;
  padding: 0 14px;
  margin-bottom: 4px;
}
.sr-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  cursor: pointer;
  transition: background .12s;
}
.sr-item:active {
  background: #f3f4f6;
}
.sr-item-icon {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background: #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
  color: #555;
  flex-shrink: 0;
}
.sr-item-info {
  flex: 1;
  min-width: 0;
}
.sr-item-name {
  font-size: 14px;
  color: #111;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sr-item-desc {
  font-size: 11px;
  color: #9ca3af;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sr-badge {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 8px;
  background: #eaf0fb;
  color: #3D7BEA;
  flex-shrink: 0;
}
</style>
