<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">任务管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex gap-2">
        <select v-model="filterStatus" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchData">
          <option value="">全部状态</option>
          <option value="1">启用</option>
          <option value="0">禁用</option>
        </select>
        <select v-model="filterDirection" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchData">
          <option value="">全部类型</option>
          <option value="earn">奖励任务</option>
          <option value="spend">惩罚规则</option>
        </select>
        <button v-auth="'add'" class="h-9 px-4 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openDialog(null)">新增</button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors" @click="openDialog(item)">
            <div class="flex items-start gap-3">
              <div v-if="item.icon" class="w-10 h-10 rounded-xl bg-[#f5f6f8] flex items-center justify-center flex-shrink-0 overflow-hidden">
                <img v-if="item.icon.startsWith('http')||item.icon.startsWith('/')" :src="$fixImgUrl(item.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <span v-else class="text-lg">{{ item.icon }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-0.5">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded"
                    :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded"
                    :class="item.direction === 'spend' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'">{{ item.direction === 'spend' ? '惩罚' : '奖励' }}</span>
                  <span v-if="item.direction !== 'spend'" class="text-[10px] px-1.5 py-0.5 rounded bg-purple-50 text-purple-600">{{ periodMap[item.task_type] || item.task_type }}</span>
                </div>
                <div class="text-xs text-gray-400">{{ actionMap[item.action_type] || item.action_type }}<template v-if="item.direction !== 'spend'"> | 目标 {{ item.target_count }}次</template></div>
                <div class="text-xs" :class="item.direction === 'spend' ? 'text-red-400' : 'text-gray-400'">{{ rewardSummary(item) }}</div>
                <div v-if="item.start_time || item.end_time" class="text-[10px] text-orange-400 mt-0.5">{{ item.start_time }} ~ {{ item.end_time }}</div>
              </div>
              <button v-auth="'delete'" class="flex-shrink-0 text-xs text-red-400 active:text-red-600 py-1" @click.stop="deleteItem(item)">删除</button>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无任务</span></div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑任务' : '新增任务' }}</span>
          <button v-auth="'edit'" class="text-sm font-semibold text-[#FF4757]" @click="saveTask">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">任务名称 *</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>

          <!-- 方向：奖励 / 惩罚 -->
          <div class="flex items-center justify-between py-2">
            <span class="text-sm text-gray-600">惩罚规则</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.direction === 'spend' ? 'bg-red-500' : 'bg-gray-200'" @click="form.direction = form.direction === 'spend' ? 'earn' : 'spend'">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.direction === 'spend' ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>

          <div><label class="text-xs text-gray-500 mb-1 block">描述</label><textarea v-model="form.description" rows="2" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>

          <!-- 图标上传 -->
          <div>
            <label class="text-xs text-gray-500 mb-1 block">任务图标</label>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-xl bg-[#f5f6f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-gray-100">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <svg v-else class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">
                {{ uploadingIcon ? '上传中...' : (form.icon ? '重新上传' : '上传图标') }}
              </button>
              <button v-if="form.icon" class="h-9 px-3 text-xs text-gray-400 active:text-red-400" @click="form.icon='';uploadedIconFile=null">移除</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
          </div>

          <!-- 周期 & 动作 (仅奖励模式) -->
          <div v-if="form.direction !== 'spend'" class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">周期 *</label><select v-model="form.task_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="daily">每日</option><option value="weekly">每周</option><option value="monthly">每月</option><option value="yearly">每年</option><option value="permanent">永久</option><option value="once">一次性</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">动作类型 *</label><select v-model="form.action_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="post">发帖</option><option value="comment">评论</option><option value="like">点赞</option><option value="checkin">签到</option><option value="share">分享</option><option value="download">下载</option><option value="register">注册</option><option value="follow">关注</option><option value="favorite">收藏</option><option value="purchase">购买</option><option value="upload">上传</option><option value="invite">邀请</option><option value="profile">完善资料</option><option value="view_post">浏览帖子</option></select></div>
          </div>

          <!-- 违规行为类型 (惩罚模式) -->
          <div v-if="form.direction === 'spend'">
            <label class="text-xs text-gray-500 mb-1 block">违规行为 *</label>
            <select v-model="form.action_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none">
              <optgroup label="社区帖子/评论">
                <option value="post_rejected">帖子被驳回</option>
                <option value="post_deleted">帖子被删除</option>
                <option value="post_locked">帖子被锁定</option>
                <option value="comment_deleted">评论被删除</option>
                <option value="block_word_triggered">发布违规内容(敏感词)</option>
              </optgroup>
              <optgroup label="举报与审核">
                <option value="report_verified">被举报经核实违规</option>
                <option value="report_abuse">滥用举报功能</option>
                <option value="appeal_rejected">申诉被驳回</option>
              </optgroup>
              <optgroup label="封禁与处罚">
                <option value="admin_banned">被管理员封禁</option>
                <option value="auto_banned">被自动封禁</option>
                <option value="chat_kicked">聊天室被踢出</option>
                <option value="chat_banned">聊天室被禁言</option>
              </optgroup>
              <optgroup label="用户行为">
                <option value="dm_harassment">私信骚扰核实</option>
                <option value="profile_violation">头像/昵称违规</option>
              </optgroup>
              <optgroup label="商城与交易">
                <option value="review_malicious">恶意差评核实</option>
                <option value="product_fraud">虚假商品下架</option>
                <option value="refund_abuse">恶意退款</option>
              </optgroup>
              <optgroup label="应用商店">
                <option value="app_rejected">应用被驳回</option>
                <option value="app_takedown">应用被下架</option>
                <option value="app_deleted">应用被删除</option>
              </optgroup>
              <optgroup label="投票与活动">
                <option value="vote_cheat">投票作弊</option>
                <option value="campaign_cheat">活动作弊</option>
              </optgroup>
            </select>
          </div>

          <!-- 目标 & 排序 (仅奖励模式) -->
          <div v-if="form.direction !== 'spend'" class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">目标次数</label><input v-model.number="form.target_count" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sort_order" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>

          <!-- 惩罚扣分配置 (惩罚模式) -->
          <div v-if="form.direction === 'spend'" class="bg-red-50/50 rounded-xl p-3 space-y-3">
            <div class="text-xs text-red-500 font-medium">惩罚配置</div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">扣除经验值</label><input v-model.number="form.exp_reward" type="number" min="1" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none text-red-500" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">排序</label><input v-model.number="form.sort_order" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">连违加成倍率（每次+）</label><input v-model.number="penaltyConfig.step_multiplier" type="number" min="0" step="0.1" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">最大倍率上限</label><input v-model.number="penaltyConfig.max_multiplier" type="number" min="1" step="0.5" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>

            <!-- 封禁天数档位 (仅管理员封禁) -->
            <div v-if="form.action_type === 'admin_banned'">
              <div class="flex items-center justify-between mb-2">
                <span class="text-[10px] text-gray-400">封禁天数扣分档位</span>
                <button class="text-xs text-[#FF4757] active:opacity-70" @click="addDurationBand">+ 添加档位</button>
              </div>
              <div v-for="(band, idx) in penaltyConfig.duration_bands" :key="idx" class="flex items-center gap-2 mb-2 bg-white rounded-lg p-2">
                <span class="text-[10px] text-gray-400 whitespace-nowrap">封禁</span>
                <input v-model.number="band.min_days" type="number" min="1" class="w-12 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none" />
                <span class="text-[10px] text-gray-400">~</span>
                <input v-model.number="band.max_days" type="number" min="1" class="w-12 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none" />
                <span class="text-[10px] text-gray-400 whitespace-nowrap">天，扣</span>
                <input v-model.number="band.amount" type="number" min="1" class="w-14 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none text-red-500" />
                <span class="text-[10px] text-gray-400">经验</span>
                <button class="text-red-400 text-xs active:opacity-70" @click="penaltyConfig.duration_bands.splice(idx,1)">删除</button>
              </div>
            </div>

            <!-- 附加惩罚 -->
            <div>
              <div class="flex items-center justify-between mb-2">
                <span class="text-[10px] text-gray-400">附加惩罚</span>
                <button class="text-xs text-[#FF4757] active:opacity-70" @click="addAdditionalAction">+ 添加</button>
              </div>
              <div v-for="(act, idx) in penaltyConfig.additional_actions" :key="idx" class="flex items-center gap-2 mb-2 bg-white rounded-lg p-2">
                <span class="text-[10px] text-gray-400 whitespace-nowrap">累计</span>
                <input v-model.number="act.trigger_count" type="number" min="1" class="w-14 h-8 px-2 text-xs bg-[#f5f6f8] rounded border-none outline-none" />
                <span class="text-[10px] text-gray-400 whitespace-nowrap">次，触发</span>
                <select v-model="act.action" class="flex-1 h-8 px-2 text-xs bg-[#f5f6f8] rounded border-none outline-none" @change="onActionTypeChange(act)">
                  <option value="mute_post">禁止发帖</option>
                  <option value="mute_all">全站禁言</option>
                  <option value="freeze_account">冻结账号</option>
                  <option value="ban_from_chat">禁止聊天室</option>
                  <option v-for="cur in availableCurrencies" :key="'pen_'+cur.currency_key" :value="cur.currency_key">扣{{ cur.display_name }}</option>
                </select>
                <template v-if="isCurrencyAction(act.action)">
                  <span class="text-[10px] text-gray-400 whitespace-nowrap">扣</span>
                  <input v-model.number="act.amount" type="number" min="1" class="w-14 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none text-red-500" />
                  <span class="text-[10px] text-gray-400">{{ getActionLabel(act.action) }}</span>
                </template>
                <template v-else>
                  <span class="text-[10px] text-gray-400">，</span>
                  <input v-model.number="act.duration_value" type="number" min="1" class="w-14 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none" />
                  <select v-model="act.duration_unit" class="w-14 h-8 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none">
                    <option value="minute">分钟</option>
                    <option value="hour">小时</option>
                    <option value="day">天</option>
                  </select>
                </template>
                <button class="text-red-400 text-xs active:opacity-70" @click="penaltyConfig.additional_actions.splice(idx,1)">删除</button>
              </div>
            </div>
          </div>

          <!-- 奖励设置 (仅奖励模式) -->
          <div v-if="form.direction !== 'spend'" class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">奖励设置</div>
            <div v-for="cur in availableCurrencies" :key="cur.currency_key" class="grid grid-cols-1 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">{{ cur.display_name }}{{ cur.display_symbol ? '(' + cur.display_symbol + ')' : '' }}</label><input v-model.number="form.currency_rewards[cur.currency_key]" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
            <div>
              <label class="text-[10px] text-gray-400 mb-1 block">称号</label>
              <select v-model.number="form.title_id" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none">
                <option :value="0">不授予称号</option>
                <option v-for="t in titleList" :key="t.id" :value="t.id">{{ t.name }}</option>
              </select>
            </div>
          </div>

          <!-- 卡密奖励(可选) -->
          <div class="rounded-xl border border-dashed border-gray-200 p-3 space-y-3" :class="showCardKey ? 'bg-orange-50/30' : ''">
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">卡密奖励 (可选)</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="showCardKey ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleCardKey">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="showCardKey ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="showCardKey">
              <div><label class="text-[10px] text-gray-400 mb-1 block">卡密类型</label><select v-model="form.card_key_type" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none"><option value="">选择类型</option><option value="membership">会员卡</option><option value="points">积分卡</option><option value="experience">经验卡</option><option value="balance">余额卡</option><option v-for="cur in availableCurrencies.filter(c => !['balance','points','experience'].includes(c.currency_key))" :key="cur.currency_key" :value="cur.currency_key">{{ cur.display_name }}卡</option></select></div>
              <div class="grid grid-cols-2 gap-3">
                <div><label class="text-[10px] text-gray-400 mb-1 block">数值</label><input v-model.number="form.card_key_value" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">天数</label><input v-model.number="form.card_key_duration" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              </div>
            </template>
          </div>

          <!-- 活动时间段(可选) -->
          <div class="rounded-xl border border-dashed border-gray-200 p-3 space-y-3" :class="showTimeRange ? 'bg-blue-50/30' : ''">
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">活动时间段 (可选)</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="showTimeRange ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleTimeRange">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="showTimeRange ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="showTimeRange">
              <div><label class="text-[10px] text-gray-400 mb-1 block">开始时间</label><input v-model="form.start_time" type="datetime-local" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">结束时间</label><input v-model="form.end_time" type="datetime-local" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </template>
          </div>

          <!-- 启用开关 -->
          <div class="flex items-center justify-between py-2"><span class="text-sm text-gray-600">启用</span><button v-auth="'toggle'" class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'TaskManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success'|'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success'|'error'='success') => { toastMsg.value=m; toastType.value=t; if(toastTimer)clearTimeout(toastTimer); toastTimer=setTimeout(()=>toastMsg.value='',2000) }

const loading=ref(false); const data=ref<any[]>([]); const filterStatus=ref(''); const filterDirection=ref('')

const periodMap: Record<string,string>={daily:'每日',weekly:'每周',monthly:'每月',yearly:'每年',permanent:'永久',once:'一次性'}
const actionMap: Record<string,string>={post:'发帖',comment:'评论',like:'点赞',checkin:'签到',share:'分享',download:'下载',register:'注册',follow:'关注',favorite:'收藏',purchase:'购买',upload:'上传',invite:'邀请',profile:'完善资料',view_post:'浏览帖子',post_rejected:'帖子被驳回',post_deleted:'帖子被删除',post_locked:'帖子被锁定',comment_deleted:'评论被删除',block_word_triggered:'违规内容(敏感词)',report_verified:'举报核实违规',report_abuse:'滥用举报',appeal_rejected:'申诉驳回',admin_banned:'管理员封禁',auto_banned:'自动封禁',chat_kicked:'聊天室踢出',chat_banned:'聊天室禁言',dm_harassment:'私信骚扰',profile_violation:'头像/昵称违规',review_malicious:'恶意差评',product_fraud:'虚假商品',refund_abuse:'恶意退款',app_rejected:'应用驳回',app_takedown:'应用下架',app_deleted:'应用删除',vote_cheat:'投票作弊',campaign_cheat:'活动作弊'}
const rewardSummary=(item:any)=>{
  if(item.direction==='spend'){ const p=[];if(item.exp_reward>0)p.push(`扣除 ${item.exp_reward} 经验`);try{const cfg=typeof item.penalty_config==='string'?JSON.parse(item.penalty_config):(item.penalty_config||{});if(cfg.additional_actions && cfg.additional_actions.length>0)p.push(`${cfg.additional_actions.length}项附加惩罚`)}catch{}return p.length>0?p.join(' | '):'无惩罚配置'}
  const p=[];if(item.points_reward>0)p.push(`${item.points_reward}积分`);if(item.exp_reward>0)p.push(`${item.exp_reward}经验`);if(item.balance_reward>0)p.push(`${item.balance_reward}元`)
  let crs={}; try{ crs = typeof item.currency_rewards==='string'?JSON.parse(item.currency_rewards):(item.currency_rewards||{}) }catch{}
  const curMap: Record<string,string>={}; for(const c of availableCurrencies.value)curMap[c.currency_key]=c.display_name
  for(const [k,v] of Object.entries(crs)){ if(Number(v)>0)p.push(`${v}${curMap[k]||k}`) }
  if(item.title_id)p.push('称号');if(item.card_key_type)p.push('卡密');return p.length>0?`奖励: ${p.join('、')}`:'无奖励'
}

const fetchData=async()=>{loading.value=true;try{const params:any={};if(filterStatus.value)params.status=filterStatus.value;if(filterDirection.value)params.direction=filterDirection.value;const res:any=await request.get({url:'/api/custom-task/list',params});data.value=res?.records||res?.data?.records||res||[]}catch{}loading.value=false}

// Icon upload
const iconInput=ref<HTMLInputElement>(); const uploadingIcon=ref(false); const uploadedIconFile=ref<File|null>(null)
const triggerIconUpload=()=>iconInput.value?.click()
const handleIconUpload=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploadingIcon.value=true;try{const fd=new FormData();fd.append('file',file);const res:any=await request.post({url:'/api/upload/membership-icon',data:fd,headers:{}});form.icon=res?.url||res?.data?.url||res?.data||'';uploadedIconFile.value=file;showToast('上传成功')}catch(e:any){showToast('上传失败: '+(e.message||''),'error')}uploadingIcon.value=false;input.value=''}

// Dialog
const dialogVisible=ref(false); const editId=ref<number|null>(null); const showCardKey=ref(false); const showTimeRange=ref(false)

const availableCurrencies = ref<{ currency_key: string; display_name: string; display_symbol?: string }[]>([])
const titleList = ref<{ id: number; name: string }[]>([])
const loadCurrencies = async () => {
  if (availableCurrencies.value.length > 0) return
  try {
    const res: any = await request.get({ url: '/api/invite/generate-config' })
    availableCurrencies.value = (res && res.currencies) || []
  } catch {}
}
const loadTitles = async () => {
  try {
    const res: any = await request.get({ url: '/api/title/list' })
    titleList.value = (res && res.data) || (res && res.list) || []
  } catch {}
}

const formDefault=()=>({name:'',description:'',icon:'',task_type:'once',action_type:'post_rejected',target_count:1,points_reward:0,exp_reward:30,balance_reward:0,currency_rewards:{} as Record<string,number>,title_id:0,card_key_type:'',card_key_value:0,card_key_duration:0,sort_order:0,start_time:'',end_time:'',status:'1',direction:'spend'})
const form=reactive(formDefault())
const penaltyConfig=reactive({step_multiplier:0.5,max_multiplier:5.0,duration_bands:[] as any[],additional_actions:[] as any[]})

const addAdditionalAction=()=>{penaltyConfig.additional_actions.push({trigger_count:3,action:'mute_post',duration_value:120,duration_unit:'minute'})}
const addDurationBand=()=>{penaltyConfig.duration_bands.push({min_days:1,max_days:1,amount:200})}

const toMinutes=(v:number,u:string)=>{if(u==='hour')return v*60;if(u==='day')return v*1440;return v}
const fromMinutes=(m:number)=>{if(m>=1440&&m%1440===0)return{value:m/1440,unit:'day'};if(m>=60&&m%60===0)return{value:m/60,unit:'hour'};return{value:m,unit:'minute'}}

const isCurrencyAction = (action: string) => {
  if (action === 'deduct_exp' || action === 'deduct_balance') return true
  return availableCurrencies.value.some(c => c.currency_key === action)
}
const getActionLabel = (action: string) => {
  if (action === 'deduct_exp') return '经验'
  if (action === 'deduct_balance') return '积分'
  const cur = availableCurrencies.value.find(c => c.currency_key === action)
  return cur ? cur.display_name : action
}
const onActionTypeChange=(act:any)=>{
  if(act.action==='deduct_exp'||act.action==='deduct_balance'||isCurrencyAction(act.action)){
    if(!act.amount)act.amount=100
  }else{
    if(!act.duration_value)act.duration_value=120
    if(!act.duration_unit)act.duration_unit='minute'
  }
}

const toggleCardKey=()=>{showCardKey.value=!showCardKey.value;if(!showCardKey.value){form.card_key_type='';form.card_key_value=0;form.card_key_duration=0}}
const toggleTimeRange=()=>{showTimeRange.value=!showTimeRange.value;if(!showTimeRange.value){form.start_time='';form.end_time=''}}

const formatDtLocal=(v:string)=>{if(!v)return'';return v.replace(' ','T').slice(0,16)}
const parseDtLocal=(v:string)=>{if(!v)return'';return v.replace('T',' ')+':00'}

const openDialog=(item:any|null)=>{
  editId.value=item?.id||null
  if(item){
    form.name=item.name||'';form.description=item.description||'';form.icon=item.icon||'';form.task_type=item.task_type||'once';form.action_type=item.action_type||'post_rejected';form.target_count=item.target_count||1
    form.points_reward=item.points_reward||0;form.exp_reward=item.exp_reward||0;form.balance_reward=item.balance_reward||0;form.title_id=item.title_id||0
    let crs={};try{crs=typeof item.currency_rewards==='string'?JSON.parse(item.currency_rewards):(item.currency_rewards||{})}catch{}form.currency_rewards=crs||{}
    form.card_key_type=item.card_key_type||'';form.card_key_value=item.card_key_value||0;form.card_key_duration=item.card_key_duration||0
    form.sort_order=item.sort_order||0
    form.start_time=formatDtLocal(item.start_time);form.end_time=formatDtLocal(item.end_time)
    form.status=item.status||'1'
    form.direction=item.direction||'earn'
    showCardKey.value=!!item.card_key_type
    showTimeRange.value=!!(item.start_time||item.end_time)
    if(item.penalty_config){
      try{
        const cfg=typeof item.penalty_config==='string'?JSON.parse(item.penalty_config):item.penalty_config
        penaltyConfig.step_multiplier=cfg.step_multiplier||0.5
        penaltyConfig.max_multiplier=cfg.max_multiplier||5.0
        penaltyConfig.duration_bands=cfg.duration_bands||[]
        penaltyConfig.additional_actions=(cfg.additional_actions||[]).map((a:any)=>{
          if(a.duration_minutes && !a.duration_value){
            const c=fromMinutes(a.duration_minutes)
            return {...a,duration_value:c.value,duration_unit:c.unit}
          }
          if(!a.duration_unit && (a.action==='mute_post'||a.action==='mute_all'||a.action==='freeze_account'||a.action==='ban_from_chat')) a.duration_unit='minute'
          if(!a.duration_value) a.duration_value=a.duration_minutes||120
          return a
        })
      }catch{Object.assign(penaltyConfig,{step_multiplier:0.5,max_multiplier:5.0,duration_bands:[],additional_actions:[]})}
    }else{
      Object.assign(penaltyConfig,{step_multiplier:0.5,max_multiplier:5.0,duration_bands:[],additional_actions:[]})
    }
  }else{
    Object.assign(form,formDefault())
    Object.assign(penaltyConfig,{step_multiplier:0.5,max_multiplier:5.0,additional_actions:[]})
    showCardKey.value=false;showTimeRange.value=false;uploadedIconFile.value=null
  }
  dialogVisible.value=true
}

const saveTask=async()=>{
  const data:any={id:editId.value||undefined,name:form.name,description:form.description,icon:form.icon,task_type:form.task_type,action_type:form.action_type,target_count:form.target_count,points_reward:form.points_reward,exp_reward:form.exp_reward,balance_reward:form.balance_reward,title_id:form.title_id,sort_order:form.sort_order,status:form.status,direction:form.direction}
  if(form.direction!=='spend'){
    const crs: Record<string,number>={}
    for(const [k,v] of Object.entries(form.currency_rewards||{})){if(Number(v)>0)crs[k]=Number(v)}
    if(Object.keys(crs).length>0)data.currency_rewards=JSON.stringify(crs)
  }
  if(form.direction==='spend'){
    const actions=penaltyConfig.additional_actions.map((a:any)=>{
      const b={...a}
      if(b.duration_value && b.duration_unit) b.duration_minutes=toMinutes(b.duration_value,b.duration_unit)
      return b
    })
    data.penalty_config=JSON.stringify({step_multiplier:penaltyConfig.step_multiplier,max_multiplier:penaltyConfig.max_multiplier,duration_bands:penaltyConfig.duration_bands||[],additional_actions:actions})
  }
  if(showCardKey.value){data.card_key_type=form.card_key_type;data.card_key_value=form.card_key_value;data.card_key_duration=form.card_key_duration}
  if(showTimeRange.value){data.start_time=parseDtLocal(form.start_time);data.end_time=parseDtLocal(form.end_time)}
  try{await request.post({url:'/api/custom-task/save',data});showToast('保存成功');dialogVisible.value=false;fetchData()}catch(e:any){showToast('保存失败: '+(e.message||'未知错误'),'error')}
}

const deleteItem=async(item:any)=>{if(!confirm(`确认删除任务 ${item.name}？`))return;try{await request.post({url:'/api/custom-task/delete',data:{id:item.id}});showToast('删除成功');fetchData()}catch{showToast('删除失败','error')}}

onMounted(()=>{fetchData();loadCurrencies();loadTitles()})
</script>
