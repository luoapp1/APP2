<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">任务管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex gap-2">
        <select v-model="filterStatus" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchData">
          <option value="">全部状态</option>
          <option value="1">启用</option>
          <option value="0">禁用</option>
        </select>
        <button v-auth="'add'" class="h-9 px-4 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openDialog(null)">新增任务</button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors" @click="openDialog(item)">
            <div class="flex items-start gap-3">
              <div v-if="item.icon" class="w-10 h-10 rounded-xl bg-[#f5f6f8] flex items-center justify-center flex-shrink-0 overflow-hidden">
                <img v-if="item.icon.startsWith('http')||item.icon.startsWith('/')" :src="$fixImgUrl(item.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <span v-else class="text-lg">{{ item.icon }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-0.5">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600">{{ periodMap[item.task_type] || item.task_type }}</span>
                </div>
                <div class="text-xs text-gray-400">{{ actionMap[item.action_type] || item.action_type }} | 目标 {{ item.target_count }}次</div>
                <div class="text-xs text-gray-400 mt-0.5">{{ rewardSummary(item) }}</div>
                <div v-if="item.start_time || item.end_time" class="text-[10px] text-orange-400 mt-0.5">{{ item.start_time }} ~ {{ item.end_time }}</div>
              </div>
              <button v-auth="'delete'" class="flex-shrink-0 text-xs text-red-400 active:text-red-600 py-1" @click.stop="deleteItem(item)">删除</button>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无任务</span></div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑任务' : '新增任务' }}</span>
          <button v-auth="'edit'" class="text-sm font-semibold text-[#FF4757]" @click="saveTask">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">任务名称 *</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">描述</label><textarea v-model="form.description" rows="2" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>

          <!-- 图标上传 -->
          <div>
            <label class="text-xs text-gray-500 mb-1 block">任务图标</label>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-xl bg-[#f5f6f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-gray-100">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <svg v-else class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">
                {{ uploadingIcon ? '上传中...' : (form.icon ? '重新上传' : '上传图标') }}
              </button>
              <button v-if="form.icon" class="h-9 px-3 text-xs text-gray-400 active:text-red-400" @click="form.icon='';uploadedIconFile=null">移除</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
          </div>

          <!-- 周期 & 动作 -->
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">周期 *</label><select v-model="form.task_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="daily">每日</option><option value="weekly">每周</option><option value="monthly">每月</option><option value="yearly">每年</option><option value="permanent">永久</option><option value="once">一次性</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">动作类型 *</label><select v-model="form.action_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="post">发帖</option><option value="comment">评论</option><option value="like">点赞</option><option value="checkin">签到</option><option value="share">分享</option><option value="download">下载</option><option value="register">注册</option><option value="follow">关注</option><option value="favorite">收藏</option><option value="purchase">购买</option><option value="upload">上传</option><option value="invite">邀请</option><option value="profile">完善资料</option><option value="view_post">浏览帖子</option></select></div>
          </div>

          <!-- 目标 & 排序 -->
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">目标次数</label><input v-model.number="form.target_count" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sort_order" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>

          <!-- 奖励设置 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">奖励设置</div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">积分</label><input v-model.number="form.points_reward" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">经验</label><input v-model.number="form.exp_reward" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">余额</label><input v-model.number="form.balance_reward" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">称号ID</label><input v-model.number="form.title_id" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
          </div>

          <!-- 卡密奖励(可选) -->
          <div class="rounded-xl border border-dashed border-gray-200 p-3 space-y-3" :class="showCardKey ? 'bg-orange-50/30' : ''">
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">卡密奖励 (可选)</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="showCardKey ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleCardKey">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="showCardKey ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="showCardKey">
              <div><label class="text-[10px] text-gray-400 mb-1 block">卡密类型</label><select v-model="form.card_key_type" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none"><option value="">选择类型</option><option value="membership">会员卡</option><option value="points">积分卡</option><option value="experience">经验卡</option><option value="balance">余额卡</option></select></div>
              <div class="grid grid-cols-2 gap-3">
                <div><label class="text-[10px] text-gray-400 mb-1 block">数值</label><input v-model.number="form.card_key_value" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">天数</label><input v-model.number="form.card_key_duration" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              </div>
            </template>
          </div>

          <!-- 活动时间段(可选) -->
          <div class="rounded-xl border border-dashed border-gray-200 p-3 space-y-3" :class="showTimeRange ? 'bg-blue-50/30' : ''">
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">活动时间段 (可选)</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="showTimeRange ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleTimeRange">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="showTimeRange ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="showTimeRange">
              <div><label class="text-[10px] text-gray-400 mb-1 block">开始时间</label><input v-model="form.start_time" type="datetime-local" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">结束时间</label><input v-model="form.end_time" type="datetime-local" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </template>
          </div>

          <!-- 启用开关 -->
          <div class="flex items-center justify-between py-2"><span class="text-sm text-gray-600">启用</span><button v-auth="'toggle'" class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'TaskManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success'|'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success'|'error'='success') => { toastMsg.value=m; toastType.value=t; if(toastTimer)clearTimeout(toastTimer); toastTimer=setTimeout(()=>toastMsg.value='',2000) }

const loading=ref(false); const data=ref<any[]>([]); const filterStatus=ref('')

const periodMap: Record<string,string>={daily:'每日',weekly:'每周',monthly:'每月',yearly:'每年',permanent:'永久',once:'一次性'}
const actionMap: Record<string,string>={post:'发帖',comment:'评论',like:'点赞',checkin:'签到',share:'分享',download:'下载',register:'注册',follow:'关注',favorite:'收藏',purchase:'购买',upload:'上传',invite:'邀请',profile:'完善资料',view_post:'浏览帖子'}
const rewardSummary=(item:any)=>{const p=[];if(item.points_reward>0)p.push(`${item.points_reward}积分`);if(item.exp_reward>0)p.push(`${item.exp_reward}经验`);if(item.balance_reward>0)p.push(`${item.balance_reward}元`);if(item.title_id)p.push('称号');if(item.card_key_type)p.push('卡密');return p.length>0?`奖励: ${p.join('、')}`:'无奖励'}

const fetchData=async()=>{loading.value=true;try{const params:any={};if(filterStatus.value)params.status=filterStatus.value;const res:any=await request.get({url:'/api/custom-task/list',params});data.value=res?.records||res?.data?.records||res||[]}catch{}loading.value=false}

// Icon upload
const iconInput=ref<HTMLInputElement>(); const uploadingIcon=ref(false); const uploadedIconFile=ref<File|null>(null)
const triggerIconUpload=()=>iconInput.value?.click()
const handleIconUpload=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploadingIcon.value=true;try{const fd=new FormData();fd.append('file',file);const res:any=await request.post({url:'/api/upload/membership-icon',data:fd,headers:{}});form.icon=res?.url||res?.data?.url||res?.data||'';uploadedIconFile.value=file;showToast('上传成功')}catch(e:any){showToast('上传失败: '+(e.message||''),'error')}uploadingIcon.value=false;input.value=''}

// Dialog
const dialogVisible=ref(false); const editId=ref<number|null>(null); const showCardKey=ref(false); const showTimeRange=ref(false)

const formDefault=()=>({name:'',description:'',icon:'',task_type:'daily',action_type:'post',target_count:1,points_reward:0,exp_reward:0,balance_reward:0,title_id:0,card_key_type:'',card_key_value:0,card_key_duration:0,sort_order:0,start_time:'',end_time:'',status:'1'})
const form=reactive(formDefault())

const toggleCardKey=()=>{showCardKey.value=!showCardKey.value;if(!showCardKey.value){form.card_key_type='';form.card_key_value=0;form.card_key_duration=0}}
const toggleTimeRange=()=>{showTimeRange.value=!showTimeRange.value;if(!showTimeRange.value){form.start_time='';form.end_time=''}}

const formatDtLocal=(v:string)=>{if(!v)return'';return v.replace(' ','T').slice(0,16)}
const parseDtLocal=(v:string)=>{if(!v)return'';return v.replace('T',' ')+':00'}

const openDialog=(item:any|null)=>{
  editId.value=item?.id||null
  if(item){
    form.name=item.name||'';form.description=item.description||'';form.icon=item.icon||'';form.task_type=item.task_type||'daily';form.action_type=item.action_type||'post';form.target_count=item.target_count||1
    form.points_reward=item.points_reward||0;form.exp_reward=item.exp_reward||0;form.balance_reward=item.balance_reward||0;form.title_id=item.title_id||0
    form.card_key_type=item.card_key_type||'';form.card_key_value=item.card_key_value||0;form.card_key_duration=item.card_key_duration||0
    form.sort_order=item.sort_order||0
    form.start_time=formatDtLocal(item.start_time);form.end_time=formatDtLocal(item.end_time)
    form.status=item.status||'1'
    showCardKey.value=!!item.card_key_type
    showTimeRange.value=!!(item.start_time||item.end_time)
  }else{
    Object.assign(form,formDefault())
    showCardKey.value=false;showTimeRange.value=false;uploadedIconFile.value=null
  }
  dialogVisible.value=true
}

const saveTask=async()=>{
  const data:any={id:editId.value||undefined,name:form.name,description:form.description,icon:form.icon,task_type:form.task_type,action_type:form.action_type,target_count:form.target_count,points_reward:form.points_reward,exp_reward:form.exp_reward,balance_reward:form.balance_reward,title_id:form.title_id,sort_order:form.sort_order,status:form.status}
  if(showCardKey.value){data.card_key_type=form.card_key_type;data.card_key_value=form.card_key_value;data.card_key_duration=form.card_key_duration}
  if(showTimeRange.value){data.start_time=parseDtLocal(form.start_time);data.end_time=parseDtLocal(form.end_time)}
  try{await request.post({url:'/api/custom-task/save',data});showToast('保存成功');dialogVisible.value=false;fetchData()}catch(e:any){showToast('保存失败: '+(e.message||'未知错误'),'error')}
}

const deleteItem=async(item:any)=>{if(!confirm(`确认删除任务 ${item.name}？`))return;try{await request.post({url:'/api/custom-task/delete',data:{id:item.id}});showToast('删除成功');fetchData()}catch{showToast('删除失败','error')}}

onMounted(()=>fetchData())
</script>
