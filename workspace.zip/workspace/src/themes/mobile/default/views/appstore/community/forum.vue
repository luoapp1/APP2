<template>
  <div class="forum-page mx-auto max-w-[430px] shadow-lg relative h-screen flex flex-col overflow-hidden" style="background:var(--default-bg-color)">
      <!-- STATUS BAR -->
      <div class="h-[34px] bg-white flex-shrink-0"/>

      <!-- NAVIGATION -->
      <div class="nav-bar bg-white flex-shrink-0">
        <div class="flex items-center justify-between h-[40px] px-4">
          <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
          <span class="text-[17px] text-[#111] font-bold">{{ sectionName }}</span>
          <div class="w-[32px] h-[32px] rounded-full bg-[#F0F0F0] flex items-center justify-center active:bg-[#E5E5E5]" @click="router.push('/community/search?sectionId=' + sectionId)">
            <svg class="w-[16px] h-[16px] text-[#666]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/></svg>
          </div>
        </div>
      </div>

      <!-- VIRTUAL POST LIST -->
      <div class="flex-1 min-h-0">
        <VirtualScroller :items="normalPosts" :estimated-height="260" :load-more-threshold="200" @load-more="onLoadMore">
          <template #before>
            <!-- HEADER AREA -->
            <div class="header-area">
              <!-- SECTION INFO -->
              <div class="bg-white px-5 py-3">
                <div class="flex items-center">
                  <div class="w-[56px] h-[56px] rounded-full flex items-center justify-center flex-shrink-0 mr-2 overflow-hidden" style="position:relative">
                    <span class="text-[20px] font-bold text-white w-full h-full flex items-center justify-center rounded-full" style="background:#22C1D0">{{ sectionName[0] }}</span>
                    <img v-if="sectionInfo?.icon" :src="$fixImgUrl(sectionInfo.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>

                  <div class="flex-1 min-w-0">
                    <div class="text-[16px] text-[#111] font-bold leading-tight">{{ sectionName }}</div>
                    <div class="text-[12px] text-[#999] mt-0.5 leading-tight">
                      帖子: {{ sectionInfo?.postCount || 0 }} | 今日浏览: {{ fmtCount(sectionInfo?.todayViewCount || 0) }} | 总浏览: {{ fmtCount(sectionInfo?.totalViewCount || 0) }}
                    </div>

                    <div v-if="moderators.length > 0" class="flex items-center gap-1 mt-1 active:opacity-70" @click="showModeratorModal = true">
                      <span class="text-[12px] text-[#999]">圈主：</span>
                      <div v-for="(mod, mi) in moderators" :key="mi" class="w-[18px] h-[18px] rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style="position:relative">
                        <img src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
                        <img v-if="mod.userAvatar" :src="mod.userAvatar" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                      </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="h-[14px] bg-white"/>

              <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="bg-white px-5">
                <div v-if="globalPinnedPosts.length > 0">
                  <div v-for="post in globalPinnedPosts" :key="'g-'+post.id"
                    class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
                    @click="openPostDetail(post.id)">
                    <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">全站</span>
                    <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
                    <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </div>
                <div v-if="sectionPinnedPosts.length > 0">
                  <div v-for="(post, i) in sectionPinnedPosts" :key="'p-'+post.id"
                    class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
                    @click="openPostDetail(post.id)">
                    <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">置顶</span>
                    <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
                    <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </div>
              </div>

              <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="h-[8px] bg-white"/>
            </div>

            <!-- EMPTY STATE -->
            <div v-if="normalPosts.length === 0 && !loading" class="flex flex-col items-center justify-center py-32 text-gray-300">
              <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
              </svg>
              <span class="text-[13px]">还没有帖子，来发布第一条吧</span>
            </div>
          </template>

          <template #sticky-header>
            <div class="tab-bar bg-white px-4 pt-1 pb-1.5">
              <div class="bg-[#F2F2F2] rounded-[10px] p-[3px] inline-flex">
                <div v-for="tab in tabs" :key="tab.key"
                  class="px-3 py-[5px] text-[12px] rounded-[8px] cursor-pointer transition-all duration-200"
                  :class="activeTab === tab.key ? 'bg-white text-[#1A1A1A] font-semibold shadow-sm' : 'text-[#999]'"
                  @click="switchTab(tab.key)">
                  {{ tab.label }}
                </div>
              </div>
            </div>
          </template>

          <template #default="{ item }">
            <FeedPostCard
              :post="item"
              :activeFrameUrl="activeFrameUrl"
              :currentUserId="currentUserId"
              @click="openPostDetail"
            />
          </template>
          <template #footer>
            <div v-if="loading || loadingMore" class="flex justify-center py-3">
              <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
            </div>
            <div v-else-if="noMore && normalPosts.length > 0" class="text-center py-3 text-[12px] text-[#DDD]">- 已加载全部 -</div>
          </template>
        </VirtualScroller>
      </div>

    <!-- MODERATOR MODAL -->
    <ModeratorModal :visible="showModeratorModal" :section-id="sectionId" @close="showModeratorModal = false"/>

    <!-- FLOATING BUTTON -->
    <button class="publish-float-btn fixed right-[16px] bottom-[130px] w-[48px] h-[48px] rounded-full bg-[#222] flex items-center justify-center z-50 active:scale-90 transition-transform"
      style="box-shadow: 0 2px 12px rgba(0,0,0,0.25)"
      @click="goToPublish">
      <svg class="w-[20px] h-[20px] text-white" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
        <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators } from '@/api/community'
import { fmtCount } from '@/utils'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import ModeratorModal from './ModeratorModal.vue'
import VirtualScroller from '@/components/core/VirtualScroller.vue'
import FeedPostCard from '@/components/FeedPostCard.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const sectionId = computed(() => Number(route.params.id) || 0)
const sectionName = computed(() => (route.query.name as string) || sectionInfo.value?.name || '综合讨论')

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const activeTab = ref('hot')
const showModeratorModal = ref(false)
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)

const tabs = [
  { key: 'hot', label: '热门' },
  { key: 'latest', label: '最新' },
  { key: 'recent_reply', label: '待回复' },
  { key: 'essence', label: '精华' }
]

const globalPinnedPosts = computed(() => postList.value.filter((p: any) => p.isGlobalPinned))
const sectionPinnedPosts = computed(() => postList.value.filter((p: any) => p.isPinned && !p.isGlobalPinned))
const normalPosts = computed(() => postList.value.filter((p: any) => !p.isPinned && !p.isGlobalPinned))

async function loadModerators() {
  if (!sectionId.value) return
  try { const r: any = await fetchModerators(sectionId.value); moderators.value = r?.data || r || [] } catch {}
}

async function loadSection() {
  if (!sectionId.value) return
  try { const r: any = await fetchCommunitySection(sectionId.value); sectionInfo.value = r.data || r } catch {}
}

async function loadPosts(reset = false) {
  if (reset) { page.value = 1; noMore.value = false; loading.value = true }
  else { loadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sectionId: sectionId.value, sort: activeTab.value, page: page.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          // Priority 1-5: permission-based blocks
          for (const node of doc.content) {
            if (node.type === 'paywall') {
              if (p.hasPurchased) continue
              previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }
              break
            }
            if (node.type === 'memberUnlock') {
              if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue
              previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }
              break
            }
            if (node.type === 'experienceUnlock') {
              const userExp = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0)
              if (userExp >= (node.attrs?.level || 0)) continue
              previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }
              break
            }
            if (node.type === 'commentUnlock') {
              if (p.hasCommented) continue
              previewCard = { type: 'commentUnlock' }
              break
            }
            if (node.type === 'titleUnlock') {
              if (p.viewerTitleIds && p.viewerTitleIds.includes(node.attrs?.titleId)) continue
              previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }
              break
            }
          }
          // Priority 4: login
          if (!previewCard && p.contentPermission === 'login') {
            previewCard = { type: 'login' }
          }
          if (previewCard && currentUserId.value && p.userId === currentUserId.value) {
            previewCard = null
          }
          // Priority 6-9: content cards (first match in block order)
          if (!previewCard) {
            for (const node of doc.content) {
              if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
              if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
              if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
              if (node.type === 'paragraph' && node.content) {
                for (const child of node.content) {
                  if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                    const txt = child.text || ''
                    const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                    if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                  }
                }
              }
              if (previewCard) break
            }
          }
        }
      } catch {}
      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        isGlobalPinned: !!p.isGlobalPinned,
        isHot: !!p.isHot || (p.likeCount || 0) >= 20 || (p.commentCount || 0) >= 30,
        _previewCard: previewCard
      }
    })
    if (reset) { postList.value = parsed } else { postList.value.push(...parsed) }
    if (list.length < 20) noMore.value = true
  } catch {} finally { loading.value = false; loadingMore.value = false }
}

function switchTab(tabKey: string) { if (activeTab.value !== tabKey) { activeTab.value = tabKey; loadPosts(true) } }
function openPostDetail(postId: number) { router.push(`/community/post/${postId}`) }
function goToPublish() { router.push(`/community/post/create/${sectionId.value}`) }

function onLoadMore() {
  if (loadingMore.value || noMore.value) return
  page.value++
  loadPosts(false)
}

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}

onMounted(async () => {
  await loadSection()
  loadModerators()
  loadPosts(true)
  loadActiveFrame()
})
</script>

<style scoped>
.publish-float-btn {
  right: max(16px, calc((100vw - 430px) / 2 + 16px));
}
</style>

<style>
.ct-hash { color: #6366F1; background: #EEF2FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-app { color: #0EA5E9; background: #F0F9FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-goods { color: #D48806; background: #FFFBE6; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-vote { color: #7C3AED; background: #F5F3FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-ref { color: #059669; background: #ECFDF5; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-img { color: #9CA3AF; font-size: 11px; }

/* Mobile frame effect on desktop */
@media (min-width: 431px) {
  body {
    background: #E8E8E8 !important;
  }
}
</style>
