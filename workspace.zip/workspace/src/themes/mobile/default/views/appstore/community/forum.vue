<template>
  <div class="forum-page mx-auto max-w-[430px] shadow-lg relative h-screen flex flex-col overflow-hidden" style="background:var(--default-bg-color)">
      <!-- STATUS BAR -->
      <div class="h-[34px] bg-white flex-shrink-0"/>

      <!-- NAVIGATION -->
      <div class="nav-bar bg-white flex-shrink-0">
        <div class="flex items-center justify-between h-[40px] px-4">
          <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
          <span class="text-[17px] text-[#111] font-bold">{{ sectionName }}</span>
          <div class="w-[32px] h-[32px] rounded-full bg-[#F0F0F0] flex items-center justify-center active:bg-[#E5E5E5]" @click="router.push('/community/search?sectionId=' + sectionId)">
            <svg class="w-[16px] h-[16px] text-[#666]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/></svg>
          </div>
        </div>
      </div>

      <!-- VIRTUAL POST LIST -->
      <div class="flex-1 min-h-0">
        <VirtualScroller :items="normalPosts" :estimated-height="260" :load-more-threshold="200" @load-more="onLoadMore">
          <template #before>
            <!-- HEADER AREA -->
            <div class="header-area">
              <!-- SECTION INFO -->
              <div class="bg-white px-5 py-3">
                <div class="flex items-center">
                  <div class="w-[56px] h-[56px] rounded-full flex items-center justify-center flex-shrink-0 mr-2 overflow-hidden" style="position:relative">
                    <span class="text-[20px] font-bold text-white w-full h-full flex items-center justify-center rounded-full" style="background:#22C1D0">{{ sectionName[0] }}</span>
                    <img v-if="sectionInfo?.icon" :src="$fixImgUrl(sectionInfo.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>

                  <div class="flex-1 min-w-0">
                    <div class="text-[16px] text-[#111] font-bold leading-tight">{{ sectionName }}</div>
                    <div class="text-[12px] text-[#999] mt-0.5 leading-tight">
                      帖子: {{ sectionInfo?.postCount || 0 }} | 今日浏览: {{ fmtCount(sectionInfo?.todayViewCount || 0) }} | 总浏览: {{ fmtCount(sectionInfo?.totalViewCount || 0) }}
                    </div>

                    <div v-if="moderators.length > 0" class="flex items-center gap-1 mt-1 active:opacity-70" @click="showModeratorModal = true">
                      <span class="text-[12px] text-[#999]">圈主：</span>
                      <div v-for="(mod, mi) in moderators" :key="mi" class="w-[18px] h-[18px] rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style="position:relative">
                        <img src="@imgs/user/avatar.webp" class="w-full h-full object-cover" loading="lazy" />
                        <img v-if="mod.userAvatar" :src="mod.userAvatar" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                      </div>
                      </div>
                  </div>
                </div>
              </div>

              <div class="h-[14px] bg-white"/>

              <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="bg-white px-5">
                <div v-if="globalPinnedPosts.length > 0">
                  <div v-for="post in globalPinnedPosts" :key="'g-'+post.id"
                    class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
                    @click="openPostDetail(post.id)">
                    <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">全站</span>
                    <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
                    <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </div>
                <div v-if="sectionPinnedPosts.length > 0">
                  <div v-for="(post, i) in sectionPinnedPosts" :key="'p-'+post.id"
                    class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
                    @click="openPostDetail(post.id)">
                    <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">置顶</span>
                    <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
                    <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </div>
              </div>

              <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="h-[8px] bg-white"/>
            </div>

            <!-- EMPTY STATE -->
            <div v-if="normalPosts.length === 0 && !loading" class="flex flex-col items-center justify-center py-32 text-gray-300">
              <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
              </svg>
              <span class="text-[13px]">还没有帖子，来发布第一条吧</span>
            </div>
          </template>

          <template #sticky-header>
            <div class="tab-bar bg-white px-4 pt-1 pb-1.5">
              <div class="bg-[#F2F2F2] rounded-[10px] p-[3px] inline-flex">
                <div v-for="tab in tabs" :key="tab.key"
                  class="px-3 py-[5px] text-[12px] rounded-[8px] cursor-pointer transition-all duration-200"
                  :class="activeTab === tab.key ? 'bg-white text-[#1A1A1A] font-semibold shadow-sm' : 'text-[#999]'"
                  @click="switchTab(tab.key)">
                  {{ tab.label }}
                </div>
              </div>
            </div>
          </template>

          <template #default="{ item }">
            <div class="bg-white mx-3 mb-2 rounded-xl px-3 pt-2.5 pb-2.5 cursor-pointer active:bg-[#FAFAFA] transition-colors"
              @click="openPostDetail(item.id)">

              <!-- Author Row -->
              <div class="flex items-center gap-0.5">
                <div class="post-avatar-wrap">
                  <img v-if="activeFrameUrl && item.userId === currentUserId" :src="activeFrameUrl" class="post-avatar-frame" loading="lazy" />
                  <div class="post-avatar">
                    <img src="@imgs/user/avatar.webp" class="post-avatar-pic" loading="lazy" />
                    <img v-if="item.userAvatar" :src="item.userAvatar" class="post-avatar-pic post-avatar-user" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>
                </div>
                <div class="post-author-info">
                  <div class="post-author-col">
                    <div class="post-author-row">
                      <span class="post-username">{{ item.userName }}</span>
                      <img v-for="(icon, idx) in (item.userAllTitleIcons || '').split('|||').filter(Boolean)" :key="idx" :src="icon" class="post-title-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                    </div>
                    <div class="post-author-meta">
                      <img v-if="item.userExpLevelIcon && item.userExpLevelIcon.startsWith('http')" :src="item.userExpLevelIcon" class="post-exp-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                      <img v-if="item.userMemberLevelIcon" :src="item.userMemberLevelIcon" class="post-member-name-icon" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                    </div>
                  </div>
                </div>
              </div>

              <!-- Post Content Area -->
              <div class="post-body">
                <!-- Badges Row -->
                <div class="post-badge-row">
                  <span v-if="item.isPinned" class="post-header-badge pin">置顶</span>
                  <span v-if="item.isEssence" class="post-header-badge essence">精华</span>
                  <span v-if="(item.likeCount || 0) >= 20 || (item.commentCount || 0) >= 30" class="post-header-badge hot">热帖</span>
                  <span v-if="item.customBadge" class="post-header-badge custom">{{ item.customBadge }}</span>
                  <span v-if="item.isLocked" class="post-header-badge lock">锁定</span>
                  <span v-for="(collaborator, ci) in (item.collectionList || [])" :key="'col-'+ci" class="post-header-badge collection">{{ collaborator }}</span>
                </div>

                <!-- Title -->
                <div class="text-[15px] text-[#1A1A1A] font-semibold leading-tight mt-1 line-clamp-2">
                  {{ item.title }}
                </div>

                <!-- Content Preview -->
                <div class="text-[13px] text-[#777] leading-[1.55] mt-1.5 line-clamp-2" v-html="stripContent(item.content)" />

                <!-- Preview Card (paywall/member/experience/comment/title unlock) -->
                <div v-if="item._previewCard" class="post-preview-card">
                  <!-- Paywall -->
                  <div v-if="item._previewCard.type === 'paywall'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FFF8E1] border border-[#FFE082] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#F59E0B]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">付费内容</div></div>
                    <span class="text-[12px] text-[#D48806] font-semibold">{{ item._previewCard.price || 0 }}{{ item._previewCard.priceType === 'points' ? '积分' : '元' }}购买</span>
                  </div>
                  <!-- Member Unlock -->
                  <div v-else-if="item._previewCard.type === 'memberUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FEF3C7] border border-[#FCD34D] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">{{ item._previewCard.levelName }}专属</div></div>
                    <span class="text-[12px] text-[#D48806]">开通会员</span>
                  </div>
                  <!-- Experience Unlock -->
                  <div v-else-if="item._previewCard.type === 'experienceUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#DBEAFE] border border-[#93C5FD] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#DBEAFE] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#3B82F6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#3B82F6] font-semibold">{{ item._previewCard.levelName }}以上</div></div>
                  </div>
                  <!-- Comment Unlock -->
                  <div v-else-if="item._previewCard.type === 'commentUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#D1FAE5] border border-[#A7F3D0] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#10B981]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#10B981] font-semibold">评论后可见</div></div>
                    <span class="text-[11px] text-[#888] flex-shrink-0">留下评论即可解锁</span>
                  </div>
                  <!-- Title Unlock -->
                  <div v-else-if="item._previewCard.type === 'titleUnlock'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#EDE9FE] border border-[#C4B5FD] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#8B5CF6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#8B5CF6] font-semibold">{{ item._previewCard.titleName }}</div></div>
                    <span class="text-[11px] text-[#888] flex-shrink-0">称号限定内容</span>
                  </div>
                  <!-- Login Gate -->
                  <div v-else-if="item._previewCard.type === 'login'" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#FFF0E0] border border-[#FFCC80] mt-2 mb-1 cursor-pointer">
                    <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
                      <svg class="w-4 h-4 text-[#F59E0B]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#D48806] font-semibold">登录后可见</div></div>
                  </div>
                  <!-- Content Cards: App -->
                  <div v-else-if="item._previewCard.type === 'app'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#F0F9FF] to-[#E0F2FE] border border-[#BAE6FD] mt-2 mb-1 cursor-pointer">
                    <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] flex items-center justify-center flex-shrink-0 shadow-sm">
                      <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#0C4A6E] font-semibold">{{ item._previewCard.name || '应用' }}</div></div>
                    <div class="w-6 h-6 rounded-full bg-[#E0F2FE] flex items-center justify-center flex-shrink-0">
                      <svg class="w-3.5 h-3.5 text-[#0EA5E9]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </div>
                  </div>
                  <!-- Content Cards: Goods -->
                  <div v-else-if="item._previewCard.type === 'goods'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#FFF7ED] to-[#FFEDD5] border border-[#FED7AA] mt-2 mb-1 cursor-pointer">
                    <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#D48806] to-[#F59E0B] flex items-center justify-center flex-shrink-0 overflow-hidden shadow-sm">
                      <img v-if="item._previewCard.image" :src="item._previewCard.image" class="w-full h-full object-cover" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'" />
                      <svg v-else class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#9A3412] font-semibold">{{ item._previewCard.name || '商品' }}</div></div>
                    <div class="w-6 h-6 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
                      <svg class="w-3.5 h-3.5 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </div>
                  </div>
                  <!-- Content Cards: Vote -->
                  <div v-else-if="item._previewCard.type === 'vote'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#F5F3FF] to-[#EDE9FE] border border-[#DDD6FE] mt-2 mb-1 cursor-pointer">
                    <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#A78BFA] flex items-center justify-center flex-shrink-0 shadow-sm">
                      <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#4C1D95] font-semibold">{{ item._previewCard.question || '投票' }}</div></div>
                    <div class="w-6 h-6 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
                      <svg class="w-3.5 h-3.5 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </div>
                  </div>
                  <!-- Content Cards: PostRef -->
                  <div v-else-if="item._previewCard.type === 'postRef'" class="flex items-center gap-2 px-3 py-3 rounded-xl bg-gradient-to-r from-[#ECFDF5] to-[#D1FAE5] border border-[#A7F3D0] mt-2 mb-1 cursor-pointer">
                    <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#059669] to-[#34D399] flex items-center justify-center flex-shrink-0 shadow-sm">
                      <svg class="w-6 h-6 text-white" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    </div>
                    <div class="flex-1 min-w-0"><div class="text-[13px] text-[#064E3B] font-semibold">{{ item._previewCard.title || item._previewCard.name || '关联帖子' }}</div></div>
                    <div class="w-6 h-6 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
                      <svg class="w-3.5 h-3.5 text-[#059669]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                    </div>
                  </div>
                </div>

                <!-- Images -->
                <div v-if="item.images && item.images.length" class="mt-2.5">
                  <div v-if="item.images.length === 1" class="rounded-xl overflow-hidden shadow-sm" style="max-height:200px">
                    <img :src="$fixImgUrl(item.images[0])" class="w-full object-cover" style="max-height:200px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>
                  <div v-else-if="item.images.length === 2" class="grid grid-cols-2 gap-1.5 rounded-xl overflow-hidden">
                    <img v-for="(img, idx) in item.images.slice(0,2)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:150px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>
                  <div v-else class="grid grid-cols-3 gap-1.5 rounded-xl overflow-hidden">
                    <img v-for="(img, idx) in item.images.slice(0,3)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:130px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>
                </div>
              </div>

              <!-- Tags + Stats -->
              <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-[#F5F5F5]">
                <div v-if="item.tags && item.tags.length" class="flex items-center gap-1.5 flex-wrap">
                  <span v-for="tag in item.tags.slice(0,4)" :key="tag" class="text-[10px] px-2 py-[2px] rounded text-[#666] bg-[#F5F5F5] font-medium flex-shrink-0">{{ tag }}</span>
                </div>
                <div class="flex items-center gap-3 text-[12px] text-[#B0B0B0] ml-auto flex-shrink-0">
                  <span class="inline-flex items-center gap-0.5">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                    {{ fmtCount(item.likeCount || 0) }}
                  </span>
                  <span class="inline-flex items-center gap-0.5">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                    {{ fmtCount(item.commentCount || 0) }}
                  </span>
                  <span class="inline-flex items-center gap-0.5">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                    {{ fmtCount(item.viewCount || 0) }}
                  </span>
                  <span class="text-[11px] text-[#B0B0B0] ml-1">{{ fmtRelativeTime(item.createTime) }}</span>
                </div>
          </div>
          </div>
          </template>
          <template #footer>
            <div v-if="loading || loadingMore" class="flex justify-center py-3">
              <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
            </div>
            <div v-else-if="noMore && normalPosts.length > 0" class="text-center py-3 text-[12px] text-[#DDD]">- 已加载全部 -</div>
          </template>
        </VirtualScroller>
      </div>

    <!-- MODERATOR MODAL -->
    <ModeratorModal :visible="showModeratorModal" :section-id="sectionId" @close="showModeratorModal = false"/>

    <!-- FLOATING BUTTON -->
    <button class="publish-float-btn fixed right-[16px] bottom-[130px] w-[48px] h-[48px] rounded-full bg-[#222] flex items-center justify-center z-50 active:scale-90 transition-transform"
      style="box-shadow: 0 2px 12px rgba(0,0,0,0.25)"
      @click="goToPublish">
      <svg class="w-[20px] h-[20px] text-white" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
        <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators } from '@/api/community'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import ModeratorModal from './ModeratorModal.vue'
import VirtualScroller from '@/components/core/VirtualScroller.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const sectionId = computed(() => Number(route.params.id) || 0)
const sectionName = computed(() => (route.query.name as string) || sectionInfo.value?.name || '综合讨论')

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const activeTab = ref('hot')
const showModeratorModal = ref(false)
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)

const tabs = [
  { key: 'hot', label: '热门' },
  { key: 'latest', label: '最新' },
  { key: 'recent_reply', label: '待回复' },
  { key: 'essence', label: '精华' }
]

const globalPinnedPosts = computed(() => postList.value.filter((p: any) => p.isGlobalPinned))
const sectionPinnedPosts = computed(() => postList.value.filter((p: any) => p.isPinned && !p.isGlobalPinned))
const normalPosts = computed(() => postList.value.filter((p: any) => !p.isPinned && !p.isGlobalPinned))

function stripContent(text: string) {
  if (!text) return ''
  try {
    const safe = text.replace(/\\\\\"/g, '\\"')
    const parsed = JSON.parse(safe)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
    if (parsed?.type === 'doc') {
      const parts: string[] = []
      function walk(n: any) {
        if (!n) return
        if (n.type === 'text') {
          const txt = n.text || ''
          const marks = (n.marks || []).map((m: any) => m.type)
          if (marks.includes('hashtag')) {
            const tags = txt.split(/\s+/).filter(Boolean)
            tags.forEach((t: string) => {
              parts.push(`<span class="ct-hash">${t}</span>`)
            })
          } else if (marks.includes('bold') && /^\[应用:/.test(txt)) {
            return
          } else {
            parts.push(txt)
          }
        } else if (n.type === 'goodsCard' || n.type === 'voteCard' || n.type === 'postRefCard' || n.type === 'memberUnlock' || n.type === 'experienceUnlock') {
          return
        } else if (n.type === 'image') {
          parts.push(`<span class="ct-img">[图片]</span>`)
        }
        if (n.content) n.content.forEach(walk)
      }
      if (parsed.content) parsed.content.forEach(walk)
      return parts.join(' ')
    }
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

async function loadModerators() {
  if (!sectionId.value) return
  try { const r: any = await fetchModerators(sectionId.value); moderators.value = r?.data || r || [] } catch {}
}

async function loadSection() {
  if (!sectionId.value) return
  try { const r: any = await fetchCommunitySection(sectionId.value); sectionInfo.value = r.data || r } catch {}
}

async function loadPosts(reset = false) {
  if (reset) { page.value = 1; noMore.value = false; loading.value = true }
  else { loadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sectionId: sectionId.value, sort: activeTab.value, page: page.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          // Priority 1-5: permission-based blocks
          for (const node of doc.content) {
            if (node.type === 'paywall') {
              if (p.hasPurchased) continue
              previewCard = { type: 'paywall', price: node.attrs?.price || 0, priceType: node.attrs?.priceType || 'balance' }
              break
            }
            if (node.type === 'memberUnlock') {
              if ((userStore.info?.levelId || 0) >= (node.attrs?.levelId || 0)) continue
              previewCard = { type: 'memberUnlock', levelId: node.attrs?.levelId || 1, levelName: node.attrs?.levelName || '会员' }
              break
            }
            if (node.type === 'experienceUnlock') {
              const userExp = Number((userStore.info as any)?.expLevel || (userStore.info as any)?.levelId || 0)
              if (userExp >= (node.attrs?.level || 0)) continue
              previewCard = { type: 'experienceUnlock', level: node.attrs?.level || 2, levelName: node.attrs?.levelName || 'Lv.2' }
              break
            }
            if (node.type === 'commentUnlock') {
              if (p.hasCommented) continue
              previewCard = { type: 'commentUnlock' }
              break
            }
            if (node.type === 'titleUnlock') {
              if (p.viewerTitleIds && p.viewerTitleIds.includes(node.attrs?.titleId)) continue
              previewCard = { type: 'titleUnlock', titleId: node.attrs?.titleId || 0, titleName: node.attrs?.titleName || '' }
              break
            }
          }
          // Priority 4: login
          if (!previewCard && p.contentPermission === 'login') {
            previewCard = { type: 'login' }
          }
          if (previewCard && currentUserId.value && p.userId === currentUserId.value) {
            previewCard = null
          }
          // Priority 6-9: content cards (first match in block order)
          if (!previewCard) {
            for (const node of doc.content) {
              if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
              if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
              if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
              if (node.type === 'paragraph' && node.content) {
                for (const child of node.content) {
                  if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                    const txt = child.text || ''
                    const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                    if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                  }
                }
              }
              if (previewCard) break
            }
          }
        }
      } catch {}
      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        isGlobalPinned: !!p.isGlobalPinned,
        _previewCard: previewCard
      }
    })
    if (reset) { postList.value = parsed } else { postList.value.push(...parsed) }
    if (list.length < 20) noMore.value = true
  } catch {} finally { loading.value = false; loadingMore.value = false }
}

function switchTab(tabKey: string) { if (activeTab.value !== tabKey) { activeTab.value = tabKey; loadPosts(true) } }
function openPostDetail(postId: number) { router.push(`/community/post/${postId}`) }
function goToPublish() { router.push(`/community/post/create/${sectionId.value}`) }

function onLoadMore() {
  if (loadingMore.value || noMore.value) return
  page.value++
  loadPosts(false)
}

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}

onMounted(async () => {
  await loadSection()
  loadModerators()
  loadPosts(true)
  loadActiveFrame()
})
</script>

<style scoped>
.line-clamp-1 { display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

.post-header-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 3px;
  font-weight: 600;
  margin-right: 5px;
  vertical-align: middle;
}
.post-header-badge.pin { color: #DC2626; background: #FEF2F2; }
.post-header-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-header-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-header-badge.custom { color: #508DFF; background: #F0F5FF; }
.post-header-badge.lock { color: #999; background: #F5F5F5; }
.post-header-badge.collection { color: #7C3AED; background: #F5F3FF; cursor: pointer; }

.publish-float-btn {
  right: max(16px, calc((100vw - 430px) / 2 + 16px));
}

.post-avatar-wrap {
  position: relative;
  width: 56px;
  height: 56px;
  flex-shrink: 0;
}
.post-avatar-frame {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
  z-index: 0;
}
.post-avatar {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  z-index: 1;
}
.post-avatar-pic {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}
.post-avatar-user {
  position: absolute;
  inset: 0;
  z-index: 1;
}

.post-author-info { flex: 1; min-width: 0; }
.post-author-col { display: flex; flex-direction: column; gap: 0; }
.post-author-row { display: flex; align-items: center; gap: 0; flex-wrap: wrap; }
.post-username { font-size: 15px; color: #1a1a1a; font-weight: 600; line-height: 1; }
.post-title-icon { width: 26px; height: 26px; object-fit: contain; flex-shrink: 0; vertical-align: middle; }
.post-author-meta {
  display: flex;
  align-items: center;
  gap: 2px;
  margin-top: -6px;
  font-size: 12px;
  flex-wrap: wrap;
}
.post-exp-icon { width: 32px; height: 32px; object-fit: contain; flex-shrink: 0; }
.post-member-name-icon { width: 22px; height: 22px; object-fit: contain; flex-shrink: 0; }
</style>

<style>
.ct-hash { color: #6366F1; background: #EEF2FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-app { color: #0EA5E9; background: #F0F9FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-goods { color: #D48806; background: #FFFBE6; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-vote { color: #7C3AED; background: #F5F3FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-ref { color: #059669; background: #ECFDF5; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-img { color: #9CA3AF; font-size: 11px; }

/* Mobile frame effect on desktop */
@media (min-width: 431px) {
  body {
    background: #E8E8E8 !important;
  }
}
</style>
