<template>
  <div style="min-height: 100vh; background: var(--default-bg-color);">
    <div style="background: var(--default-bg-color); padding: calc(env(safe-area-inset-top, 0px) + 8px) 16px 10px; display: flex; align-items: center; gap: 8px; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
      <div @click="$router.back()" style="cursor: pointer; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: rgba(0,0,0,0.04);">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 16px; font-weight: 600; color: #1f2937;">排行榜</span>
    </div>

    <div style="padding: 12px 16px;">
      <div style="display: flex; overflow-x: auto; white-space: nowrap; gap: 8px; margin-bottom: 12px; -webkit-overflow-scrolling: touch; padding-bottom: 2px;">
        <div
          v-for="t in tabs"
          :key="t.key"
          @click="switchTab(t.key)"
          style="padding: 10px 14px; border-radius: 20px; text-align: center; cursor: pointer; transition: all .2s; border: 1.5px solid transparent; flex-shrink: 0;"
          :style="activeTab === t.key ? { background: '#f0f5ff', borderColor: '#409EFF', color: '#409EFF' } : { background: '#fff', color: '#666' }"
        >
          <span style="font-size: 13px; font-weight: 500;">{{ t.label }}</span>
        </div>
      </div>

      <div style="display: flex; gap: 8px; margin-bottom: 12px;">
        <div
          v-for="p in displayPeriods"
          :key="p.key"
          @click="switchPeriod(p.key)"
          style="padding: 6px 14px; border-radius: 16px; cursor: pointer; transition: all .2s; border: 1.5px solid transparent; flex-shrink: 0;"
          :style="period === p.key ? { background: '#f0f5ff', borderColor: '#409EFF', color: '#409EFF' } : { background: '#fff', color: '#666' }"
        >
          <span style="font-size: 12px; font-weight: 500;">{{ p.label }}</span>
        </div>
      </div>

      <div v-if="loading" style="text-align: center; padding: 60px 0; color: #999;">加载中...</div>
      <div v-else-if="!list.length" style="text-align: center; padding: 60px 0; color: #999;">暂无数据</div>
      <div v-else>
        <div
          v-for="(item, idx) in list"
          :key="item.user_id"
          @click="goProfile(item.user_id)"
          style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #fff; border-radius: 10px; margin-bottom: 8px; cursor: pointer;"
        >
          <div style="width: 30px; text-align: center; flex-shrink: 0;">
            <span v-if="idx === 0" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #FFF7E6; color: #FAAD14; font-size: 13px; font-weight: 700;">1</span>
            <span v-else-if="idx === 1" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #F0F0F0; color: #999; font-size: 13px; font-weight: 700;">2</span>
            <span v-else-if="idx === 2" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #FFF0E6; color: #D4884A; font-size: 13px; font-weight: 700;">3</span>
            <span v-else style="font-size: 14px; font-weight: 600; color: #aaa;">{{ item.rank || idx + 1 }}</span>
            <span v-if="item.rankChange > 0" style="color: #10b981; font-size: 11px; margin-left: 2px;">↑{{ item.rankChange }}</span>
            <span v-if="item.rankChange < 0" style="color: #ef4444; font-size: 11px; margin-left: 2px;">↓{{ Math.abs(item.rankChange) }}</span>
          </div>
          <div style="position: relative; width: 56px; height: 56px; flex-shrink: 0;">
            <img
              v-if="activeFrameUrl && item.user_id === currentUserId()"
              :src="activeFrameUrl"
              style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
             loading="lazy" />
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; border-radius: 50%; overflow: hidden; background: #f3f4f6; z-index: 1;">
              <img :src="getAvatar(item)" style="width: 100%; height: 100%; object-fit: cover;"  loading="lazy" />
            </div>
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-size: 14px; font-weight: 500; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.nickname || item.username }}</div>
            <div style="font-size: 11px; color: #999; margin-top: 2px;">
              <span v-if="activeTab === 'apps'">{{ item.count }} 个应用</span>
              <span v-else-if="activeTab === 'posts'">{{ item.count }} 篇帖子</span>
              <span v-else-if="activeTab === 'experience'">
                <img v-if="item.level_icon" :src="item.level_icon" style="width:28px;height:28px;object-fit:contain;vertical-align:middle;margin-right:3px;display:inline;"  loading="lazy" />{{ item.count }} 经验
              </span>
              <span v-else-if="activeTab === 'points'">{{ item.count }} 积分</span>
              <span v-else-if="activeTab === 'donations'">{{ item.count }} 打赏</span>
              <span v-else-if="activeTab === 'favorites'">{{ item.count }} 收藏</span>
              <span v-else-if="activeTab === 'invite'">邀请 {{ item.count }} 人 | 佣金 &yen;{{ item.commission || 0 }}</span>
              <span v-else>{{ item.count }} 活跃</span>
            </div>
          </div>
          <button
            v-if="item.user_id !== currentUserId()"
            @click="(e) => handleFollow(item, e)"
            style="flex-shrink: 0; padding: 4px 12px; border-radius: 14px; font-size: 12px; border: none; cursor: pointer; font-weight: 500;"
            :style="item.is_followed ? { background: '#f0f0f0', color: '#999' } : { background: '#409EFF', color: '#fff' }"
          >
            {{ item.is_followed ? '已关注' : '+ 关注' }}
          </button>
          <svg style="width: 14px; height: 14px; color: #ccc; flex-shrink: 0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import { useLoginModalStore } from '@/store/modules/loginModal'

const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('apps')
const period = ref('')
const list = ref<any[]>([])
const loading = ref(false)
const activeFrameUrl = ref('')
const defaultAvatar = defaultAvatarImg

const tabs = [
  { key: 'invite', label: '邀请排行', desc: '邀请数' },
  { key: 'apps', label: '应用排行', desc: '发布数' },
  { key: 'posts', label: '帖子排行', desc: '帖子数' },
  { key: 'experience', label: '等级排行', desc: '经验值' },
  { key: 'points', label: '积分排行', desc: '积分数' },
  { key: 'donations', label: '打赏排行', desc: '打赏' },
  { key: 'favorites', label: '收藏排行', desc: '收藏' },
  { key: 'active-users', label: '活跃用户', desc: '活跃' },
]

const periods = [
  { key: '', label: '全部' },
  { key: 'week', label: '本周' },
  { key: 'month', label: '本月' },
  { key: 'year', label: '今年' },
]

const invitePeriods = [
  { key: 'all', label: '全部' },
  { key: 'today', label: '今日' },
  { key: 'week', label: '本周' },
  { key: 'month', label: '本月' },
]

const displayPeriods = computed(() => activeTab.value === 'invite' ? invitePeriods : periods)

const currentUserId = () => userStore.info?.userId || 0

function getAvatar(u: any) {
  if (u.avatar && (u.avatar.startsWith('http') || u.avatar.startsWith('/'))) return u.avatar
  return defaultAvatar
}

async function loadRanking(type: string) {
  loading.value = true
  try {
    if (type === 'invite') {
      const res: any = await request.get({ url: '/api/invite/ranking', params: { period: period.value, sortBy: 'inviteCount' } })
      const ranking = res?.data?.ranking || res?.ranking || []
      list.value = ranking.map((item: any) => ({
        user_id: item.userId,
        username: item.userName,
        avatar: item.avatar || '',
        nickname: item.userName || '',
        count: item.inviteCount || 0,
        commission: Number(item.commission || 0).toFixed(2),
      }))
    } else {
      const uid = currentUserId()
      const res: any = await request.get({ url: `/api/ranking/${type}`, params: { period: period.value, pageSize: 50, userId: uid } })
      list.value = (res?.list || []).map((item: any) => {
        if (item.level_icon && !(item.level_icon.startsWith('http') || item.level_icon.startsWith('/') || item.level_icon.startsWith('data:'))) {
          return { ...item, level_icon: '' }
        }
        return item
      })
    }
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

function switchTab(key: string) {
  activeTab.value = key
  period.value = ''
  loadRanking(key)
}

function switchPeriod(key: string) {
  period.value = key
  loadRanking(activeTab.value)
}

function goProfile(uid: number) {
  router.push(`/u/${uid}`)
}

onMounted(() => {
  const qTab = router.currentRoute.value.query?.tab as string
  if (qTab) activeTab.value = qTab
  loadRanking(activeTab.value)
  loadActiveFrame()
})

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}
</script>
