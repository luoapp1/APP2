<template>
  <div style="min-height:100vh;background:#f5f6fa;display:flex;flex-direction:column">
    <div style="background:#fff;display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f0f0f0">
      <button style="background:none;border:none;padding:4px;color:#333;cursor:pointer" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span style="font-size:17px;font-weight:600;color:#1a1a2e;margin-left:8px">我的订单</span>
    </div>

    <div class="tab-bar">
      <div
        v-for="tab in tabs"
        :key="tab.key"
        class="tab-item"
        :class="{ active: activeTab === tab.key }"
        @click="switchTab(tab.key)"
      >{{ tab.label }}</div>
    </div>

    <div style="flex:1;overflow-y:auto" class="order-list-wrap" @scroll="onScroll">
      <LoadingState v-if="loading && list.length === 0" />
      <ErrorState v-else-if="error" :error="error" retry-text="重新加载" @retry="refresh" />
      <EmptyState v-else-if="list.length === 0" text="暂无订单">
        <template #icon>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
        </template>
      </EmptyState>
      <div v-for="order in list" :key="order.id" class="order-card">
        <div class="order-header">
          <span class="order-no">订单号：{{ order.orderNo || order.id }}</span>
          <span class="order-time">{{ order.createdAt }}</span>
        </div>
        <div class="order-body">
          <div class="product-item" @click="goDetail(order.product)">
            <img v-if="order.product && order.product.coverImage" :src="order.product.coverImage" class="product-img"  loading="lazy" />
            <div v-else class="product-img product-img-placeholder" />
            <div class="product-info">
              <div class="product-name">{{ (order.product && order.product.name) || '商品' }}</div>
              <div class="product-meta">
                <span>数量：{{ order.quantity || 1 }}</span>
                <span class="product-price">{{ order.unitPrice != null ? order.unitPrice.toFixed(2) : '0.00' }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="order-footer">
          <div class="order-total">
            <span>共{{ order.quantity || 1 }}件</span>
            <span class="total-label">合计：</span>
            <span class="total-price">{{ order.totalAmount != null ? order.totalAmount.toFixed(2) : '0.00' }}</span>
          </div>
          <div class="order-status-tag" :class="statusClass(order.status)">{{ statusLabel(order.status) }}</div>
        </div>
        <div class="order-actions" v-if="orderActions(order).length > 0">
          <button
            v-for="action in orderActions(order)"
            :key="action.key"
            class="action-btn"
            :class="action.primary ? 'action-btn-primary' : ''"
            @click="action.handler(order)"
          >{{ action.label }}</button>
        </div>
      </div>
      <div v-if="loading && list.length > 0" style="text-align:center;padding:16px;color:#999;font-size:13px">加载更多...</div>
      <div v-if="noMore && list.length > 0" style="text-align:center;padding:16px;color:#999;font-size:13px">没有更多了</div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const router = useRouter()

const tabs = [
  { key: 'all', label: '全部' },
  { key: 'pending', label: '待付款' },
  { key: 'paid', label: '已支付' },
  { key: 'shipped', label: '已发货' },
  { key: 'completed', label: '已完成' }
]

const activeTab = ref('all')
const list = ref([])
const loading = ref(false)
const error = ref('')
const page = ref(1)
const pageSize = 20
const noMore = ref(false)

onMounted(() => fetchOrders())

function switchTab(key) {
  if (activeTab.value === key) return
  activeTab.value = key
  page.value = 1
  noMore.value = false
  list.value = []
  error.value = ''
  fetchOrders()
}

async function fetchOrders() {
  loading.value = true
  error.value = ''
  try {
    const params = { page: page.value, pageSize }
    if (activeTab.value !== 'all') {
      params.status = activeTab.value
    }
    const res = await request.get({ url: '/api/mall/orders/my', params })
    const newList = res?.list || []
    if (page.value === 1) {
      list.value = newList
    } else {
      list.value = list.value.concat(newList)
    }
    noMore.value = newList.length < pageSize
  } catch (e) {
    error.value = e?.msg || '加载失败，请稍后重试'
  }
  loading.value = false
}

function refresh() {
  page.value = 1
  noMore.value = false
  list.value = []
  fetchOrders()
}

async function loadMore() {
  if (loading.value || noMore.value) return
  page.value++
  await fetchOrders()
}

let scrollTimer = null
function onScroll(e) {
  if (scrollTimer) clearTimeout(scrollTimer)
  scrollTimer = setTimeout(() => {
    const el = e.target
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 60) {
      loadMore()
    }
  }, 100)
}

function goDetail(product) {
  if (product && product.id) {
    router.push(`/appstore/mall-detail/${product.id}`)
  }
}

function statusLabel(status) {
  const map = {
    pending: '待付款',
    paid: '已支付',
    shipped: '已发货',
    completed: '已完成',
    cancelled: '已取消'
  }
  return map[status] || status
}

function statusClass(status) {
  const map = {
    pending: 'status-pending',
    paid: 'status-paid',
    shipped: 'status-shipped',
    completed: 'status-completed',
    cancelled: 'status-cancelled'
  }
  return map[status] || ''
}

function orderActions(order) {
  const actions = []
  switch (order.status) {
    case 'pending':
      actions.push({ key: 'pay', label: '去支付', primary: true, handler: handlePay })
      break
    case 'paid':
      break
    case 'shipped':
      actions.push({ key: 'logistics', label: '查看物流', handler: handleLogistics })
      actions.push({ key: 'confirm', label: '确认收货', primary: true, handler: handleConfirmReceive })
      break
    case 'completed':
      actions.push({ key: 'review', label: '评价', handler: handleReview })
      actions.push({ key: 'rebuy', label: '再次购买', primary: true, handler: handleRebuy })
      break
  }
  return actions
}

function handlePay(order) {
  router.push(`/appstore/mall-detail/${order.product && order.product.id}`)
}

function handleLogistics(order) {
  router.push(`/appstore/mall-logistics?orderId=${order.id}`)
}

function handleConfirmReceive(order) {
  if (confirm('确认已收到商品吗？')) {
    confirmReceive(order)
  }
}

async function confirmReceive(order) {
  try {
    await request.put({ url: `/api/mall/orders/${order.id}/status`, data: { status: 'completed' } })
    order.status = 'completed'
  } catch (e) {
    alert(e?.msg || '操作失败')
  }
}

function handleReview(order) {
  if (order.product && order.product.id) {
    router.push(`/appstore/mall-reviews/${order.product.id}`)
  }
}

function handleRebuy(order) {
  if (order.product && order.product.id) {
    router.push(`/appstore/mall-detail/${order.product.id}`)
  }
}
</script>

<style scoped>
.tab-bar {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
  background: #fff;
  overflow-x: auto;
  white-space: nowrap;
  -webkit-overflow-scrolling: touch;
}
.tab-bar::-webkit-scrollbar { display: none; }
.tab-item {
  display: inline-block;
  padding: 6px 16px;
  border-radius: 20px;
  font-size: 13px;
  color: #666;
  background: #f5f6fa;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
}
.tab-item.active {
  background: #1a1a2e;
  color: #fff;
}
.order-list-wrap {
  padding: 12px;
}
.order-card {
  background: #fff;
  border-radius: 12px;
  padding: 14px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 10px;
  border-bottom: 1px solid #f5f5f5;
  margin-bottom: 10px;
}
.order-no {
  font-size: 13px;
  color: #333;
  font-weight: 500;
}
.order-time {
  font-size: 12px;
  color: #999;
}
.order-body {
  margin-bottom: 10px;
}
.product-item {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
}
.product-img {
  width: 64px;
  height: 64px;
  border-radius: 8px;
  object-fit: cover;
  flex-shrink: 0;
}
.product-img-placeholder {
  background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
}
.product-info {
  flex: 1;
  min-width: 0;
}
.product-name {
  font-size: 14px;
  font-weight: 500;
  color: #1a1a2e;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.product-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 6px;
  font-size: 12px;
  color: #999;
}
.product-price {
  color: #f56c6c;
  font-weight: 600;
}
.order-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 10px;
  border-top: 1px solid #f5f5f5;
}
.order-total {
  font-size: 13px;
  color: #666;
}
.total-label {
  margin-left: 8px;
}
.total-price {
  font-size: 15px;
  font-weight: 700;
  color: #f56c6c;
}
.order-status-tag {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 4px;
  font-weight: 500;
}
.status-pending { background: #f0f0f0; color: #999; }
.status-paid { background: #e6f0ff; color: #4a90d9; }
.status-shipped { background: #fff3e6; color: #e6a23c; }
.status-completed { background: #e6f9e6; color: #67c23a; }
.status-cancelled { background: #fee; color: #f56c6c; }
.order-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid #f5f5f5;
  margin-top: 10px;
}
.action-btn {
  padding: 6px 14px;
  border-radius: 16px;
  font-size: 12px;
  border: 1px solid #dcdfe6;
  background: #fff;
  color: #606266;
  cursor: pointer;
  transition: all 0.2s;
}
.action-btn-primary {
  background: #1a1a2e;
  color: #fff;
  border-color: #1a1a2e;
}
.action-btn:active {
  opacity: 0.8;
}
.retry-btn {
  background: #1a1a2e;
  color: #fff;
  border: none;
  padding: 8px 24px;
  border-radius: 20px;
  font-size: 13px;
  cursor: pointer;
}
</style>
