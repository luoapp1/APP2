<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">经验等级</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <button v-auth="'add'" class="w-full h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openDialog(null)">新增等级</button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors" @click="openDialog(item)">
            <div class="flex items-start justify-between">
              <div class="flex items-center gap-3">
                <div class="flex-shrink-0">
                  <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="w-8 h-8 rounded object-contain"  loading="lazy" />
                  <span v-else class="text-base font-bold" :style="{ color: item.textColor || '#fff' }">LV{{ item.level }}</span>
                </div>
                <div>
                  <div class="flex items-center gap-2 mb-0.5">
                    <span class="text-sm font-semibold text-gray-800">{{ item.name }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                  </div>
                  <div class="text-xs text-gray-400">等级 {{ item.level }} | 所需经验 {{ item.expRequired }}</div>
                  <div v-if="item.benefits" class="text-xs text-gray-400 mt-0.5 truncate max-w-[200px]">{{ item.benefits }}</div>
                </div>
              </div>
              <button v-auth="'delete'" class="ml-2 text-xs text-red-400 active:text-red-600 flex-shrink-0 py-1" @click.stop="deleteItem(item)">删除</button>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无经验等级</span></div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑等级' : '新增等级' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">等级名称</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">等级数值</label><input v-model.number="form.level" type="number" min="1" max="99" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">所需经验</label><input v-model.number="form.expRequired" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>

          <!-- 图标上传 -->
          <div>
            <label class="text-xs text-gray-500 mb-1 block">等级图标</label>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-xl bg-[#f5f6f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-gray-100">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <svg v-else class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">
                {{ uploadingIcon ? '上传中...' : (form.icon ? '重新上传' : '上传图标') }}
              </button>
              <button v-if="form.icon" class="h-9 px-3 text-xs text-gray-400 active:text-red-400" @click="form.icon=''">移除</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
          </div>

          <!-- 颜色选择 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">样式设置</div>
            <div class="flex gap-3">
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">图标色</label><input v-model="form.iconColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">文字色</label><input v-model="form.textColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">背景色</label><input v-model="form.bgColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
            </div>
            <!-- 预览 -->
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-gray-400">预览:</span>
              <span class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold" :style="{ background: form.bgColor || '#508DFF', color: form.textColor || '#fff' }">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-4 h-4 rounded object-cover"  loading="lazy" />
                <span>LV{{ form.level || 1 }}</span>
              </span>
            </div>
          </div>

          <div><label class="text-xs text-gray-500 mb-1 block">权益描述</label><textarea v-model="form.benefits" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="confirmVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-400">确定要删除「{{ confirmTarget?.name }}」吗？此操作不可恢复。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">确定删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'ExperienceMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const loading=ref(false);const data=ref<any[]>([])
const fetchData=async()=>{loading.value=true;try{const res:any=await request.get({url:'/api/operation/experience-level/list'});data.value=res?.records||res?.data?.records||res||[]}catch{}loading.value=false}

// Icon upload
const iconInput=ref<HTMLInputElement>();const uploadingIcon=ref(false)
const triggerIconUpload=()=>iconInput.value?.click()
const handleIconUpload=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploadingIcon.value=true;try{const fd=new FormData();fd.append('file',file);const res:any=await request.post({url:'/api/upload/experience-icon',data:fd,headers:{}});form.icon=res?.url||res?.data?.url||res?.data||'';showToast('上传成功')}catch(e:any){showToast('上传失败: '+(e.message||''),'error')}uploadingIcon.value=false;input.value=''}

const dialogVisible=ref(false);const editId=ref<number|null>(null)
const form=reactive({name:'',level:1,expRequired:0,icon:'',iconColor:'#00BFA5',textColor:'#FFFFFF',bgColor:'#508DFF',benefits:'',status:'1'})

const openDialog=(item:any|null)=>{editId.value=item?.id||null;if(item){form.name=item.name||'';form.level=item.level||1;form.expRequired=item.expRequired||0;form.icon=item.icon||'';form.iconColor=item.iconColor||'#00BFA5';form.textColor=item.textColor||'#FFFFFF';form.bgColor=item.bgColor||'#508DFF';form.benefits=item.benefits||'';form.status=item.status||'1'}else{Object.assign(form,{name:'',level:1,expRequired:0,icon:'',iconColor:'#00BFA5',textColor:'#FFFFFF',bgColor:'#508DFF',benefits:'',status:'1'})}dialogVisible.value=true}

const saveItem=async()=>{try{await request.post({url:'/api/operation/experience-level/save',data:{id:editId.value||undefined,...form}});showToast('保存成功');dialogVisible.value=false;fetchData()}catch(e:any){showToast('保存失败: '+(e.message||''),'error')}}
const deleteItem=(item:any)=>{confirmTarget.value=item;confirmVisible.value=true}
const confirmVisible=ref(false);const confirmTarget=ref<any>(null)
const doDelete=async()=>{if(!confirmTarget.value)return;try{await request.del({url:`/api/operation/experience-level/${confirmTarget.value.id}`});showToast('删除成功');confirmVisible.value=false;fetchData()}catch{showToast('删除失败','error')}}

onMounted(()=>fetchData())
</script>
