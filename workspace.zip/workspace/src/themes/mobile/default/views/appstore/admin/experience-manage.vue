<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <!-- 普通模式顶部 -->
    <div v-if="!compareMode" class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">经验等级</span>
    </div>

    <!-- 对比模式顶部 -->
    <div v-else class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="compareMode = false">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">权益对比</span>
    </div>

    <div class="flex-1 overflow-hidden">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- ===== 普通列表模式 ===== -->
      <template v-if="!compareMode">
        <div class="overflow-y-auto h-full pb-6">
          <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex gap-2">
            <button v-auth="'add'" class="flex-1 h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openDialog(null)">新增等级</button>
            <button class="flex-1 h-10 bg-white text-[#FF4757] text-sm rounded-lg font-medium border border-[#FF4757]/30 active:bg-red-50" @click="openCompare">权益对比</button>
          </div>

          <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
            <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
            <template v-else-if="data.length > 0">
              <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors" @click="openDialog(item)">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-3">
                    <div class="flex-shrink-0">
                      <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="w-8 h-8 rounded object-contain"  loading="lazy" />
                      <span v-else class="text-base font-bold" :style="{ color: item.textColor || '#fff' }">LV{{ item.level }}</span>
                    </div>
                    <div>
                      <div class="flex items-center gap-2 mb-0.5">
                        <span class="text-sm font-semibold text-gray-800">{{ item.name }}</span>
                        <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                      </div>
                      <div class="text-xs text-gray-400">等级 {{ item.level }} | 所需经验 {{ item.expRequired }}</div>
                      <div v-if="item.benefits" class="text-xs text-gray-400 mt-0.5 truncate max-w-[200px]">{{ item.benefits }}</div>
                    </div>
                  </div>
                  <button v-auth="'delete'" class="ml-2 text-xs text-red-400 active:text-red-600 flex-shrink-0 py-1" @click.stop="deleteItem(item)">删除</button>
                </div>
              </div>
              <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
            </template>
            <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无经验等级</span></div>
          </div>
        </div>
      </template>

      <!-- ===== 权益对比模式 ===== -->
      <div v-else class="h-full flex flex-col">
        <div v-if="compareLoading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <div v-else-if="compareLevels.length > 0" class="flex-1 overflow-auto">
          <table class="border-collapse">
            <thead>
              <tr>
                <th class="sticky left-0 z-10 bg-[#f0f1f3] px-3 py-3 text-xs font-medium text-gray-500 text-left min-w-[100px] border-b border-gray-100">权益项</th>
                <th v-for="lv in compareLevels" :key="lv.level" class="px-3 py-3 text-center border-b border-gray-100 min-w-[90px]" :class="lv.level === compareLevels[0].level ? 'bg-red-50' : 'bg-white'">
                  <div class="flex flex-col items-center gap-1">
                    <img v-if="lv.icon" :src="$fixImgUrl(lv.icon)" class="w-7 h-7 rounded object-contain" />
                    <span class="text-xs font-bold" :style="{ color: lv.textColor || lv.iconColor || '#508DFF' }">LV{{ lv.level }}</span>
                    <span class="text-[10px] text-gray-400 leading-tight">{{ Math.floor(lv.expRequired/1000) > 0 ? (Math.floor(lv.expRequired/1000) + 'k') : lv.expRequired }}</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              <template v-for="(group, mod) in compareGrouped" :key="mod">
                <tr>
                  <td :colspan="compareLevels.length + 1" class="sticky left-0 z-[5] bg-[#f0f1f3] px-3 py-1.5 text-[11px] font-medium text-gray-500">{{ modLabel(mod) }}</td>
                </tr>
                <tr v-for="p in group" :key="p.permissionKey" class="border-b border-gray-50">
                  <td class="sticky left-0 z-[5] bg-white px-3 py-2.5 text-xs text-gray-700 border-r border-gray-50">
                    <div class="text-[11px] font-medium">{{ p.permissionKey }}</div>
                    <div class="text-[10px] text-gray-400 leading-tight">{{ p.permissionName }}</div>
                  </td>
                  <td v-for="lv in compareLevels" :key="lv.level" class="px-2 py-2.5 text-center text-xs" :class="lv.level === compareLevels[0].level ? 'bg-red-50/30' : ''">
                    <template v-if="p.permissionKey === 'G1' || p.permissionKey === 'G2'">
                      <span v-if="p.levelValues[lv.level] && p.levelValues[lv.level] !== 'false' && p.levelValues[lv.level] !== ''" class="inline-block w-4 h-4 rounded-full bg-green-100 flex items-center justify-center">
                        <svg class="w-2.5 h-2.5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
                      </span>
                      <span v-else class="text-gray-300">-</span>
                    </template>
                    <template v-else-if="isBooleanPerm(p.permissionKey)">
                      <span v-if="p.levelValues[lv.level] === 'true'" class="inline-block w-4 h-4 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                        <svg class="w-2.5 h-2.5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
                      </span>
                      <span v-else class="text-gray-300">-</span>
                    </template>
                    <template v-else>
                      <span class="font-mono text-[11px]" :class="(p.levelValues[lv.level] || '') === '' ? 'text-gray-300' : 'text-gray-700'">
                        {{ (p.levelValues[lv.level] || '') === '' ? '-' : p.levelValues[lv.level] }}
                      </span>
                    </template>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
        <div v-else class="flex-1 flex items-center justify-center text-sm text-gray-400">暂无数据</div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑等级' : '新增等级' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">等级名称</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">等级数值</label><input v-model.number="form.level" type="number" min="1" max="99" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">所需经验</label><input v-model.number="form.expRequired" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>

          <div>
            <label class="text-xs text-gray-500 mb-1 block">等级图标</label>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-xl bg-[#f5f6f8] flex items-center justify-center overflow-hidden flex-shrink-0 border border-gray-100">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover"  loading="lazy" />
                <svg v-else class="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">
                {{ uploadingIcon ? '上传中...' : (form.icon ? '重新上传' : '上传图标') }}
              </button>
              <button v-if="form.icon" class="h-9 px-3 text-xs text-gray-400 active:text-red-400" @click="form.icon=''">移除</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload" />
          </div>

          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">样式设置</div>
            <div class="flex gap-3">
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">图标色</label><input v-model="form.iconColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">文字色</label><input v-model="form.textColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
              <div class="flex-1"><label class="text-[10px] text-gray-400 mb-1 block">背景色</label><input v-model="form.bgColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-white" /></div>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-gray-400">预览:</span>
              <span class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold" :style="{ background: form.bgColor || '#508DFF', color: form.textColor || '#fff' }">
                <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-4 h-4 rounded object-cover"  loading="lazy" />
                <span>LV{{ form.level || 1 }}</span>
              </span>
            </div>
          </div>

          <div><label class="text-xs text-gray-500 mb-1 block">权益描述</label><textarea v-model="form.benefits" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>

          <!-- 定时礼包 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">定时礼包</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.dailyGiftEnabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.dailyGiftEnabled = !form.dailyGiftEnabled">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.dailyGiftEnabled ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
            <template v-if="form.dailyGiftEnabled">
              <div><label class="text-[10px] text-gray-400 mb-1 block">间隔天数</label><input v-model.number="form.dailyGiftIntervalDays" type="number" min="1" max="365" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div class="grid grid-cols-2 gap-3">
                <div><label class="text-[10px] text-gray-400 mb-1 block">积分</label><input v-model.number="form.dailyGiftPoints" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">余额</label><input v-model.number="form.dailyGiftBalance" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              </div>
              <div class="grid grid-cols-2 gap-3">
                <div><label class="text-[10px] text-gray-400 mb-1 block">经验</label><input v-model.number="form.dailyGiftExperience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
                <div><label class="text-[10px] text-gray-400 mb-1 block">补签次数</label><input v-model.number="form.dailyGiftMakeupCount" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              </div>
            </template>
          </div>

          <!-- 首次达到等级赠送 -->
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <span class="text-xs text-gray-500 font-medium">首次达到等级赠送</span>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">积分</label><input v-model.number="form.firstGiftPoints" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">余额</label><input v-model.number="form.firstGiftBalance" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">经验</label><input v-model.number="form.firstGiftExperience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">补签次数</label><input v-model.number="form.firstGiftMakeupCount" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
          </div>

          <div>
            <button class="w-full flex items-center justify-between py-2 text-sm font-medium text-gray-700 active:opacity-70" @click="permExpanded = !permExpanded">
              <span>权限数值配置 ({{ permissions.length }}条)</span>
              <svg class="w-4 h-4 transition-transform" :class="{ 'rotate-90': permExpanded }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </button>
            <div v-if="permExpanded" class="space-y-1 mt-2 max-h-[50vh] overflow-y-auto bg-[#f5f6f8] rounded-lg p-2">
              <template v-for="(group, mod) in groupedPerms" :key="mod">
                <div class="text-xs text-gray-400 font-medium pt-2 pb-1 px-1">{{ modLabel(mod) }}</div>
                <div v-for="p in group" :key="p.permissionKey" class="flex items-center gap-2 bg-white rounded-lg px-3 py-1.5">
                  <span class="text-xs text-gray-500 w-8 flex-shrink-0 font-mono">{{ p.permissionKey }}</span>
                  <span class="text-[11px] text-gray-600 flex-1 truncate" :title="p.permissionName">{{ p.permissionName }}</span>
                  <template v-if="p.permissionKey === 'G1'">
                    <div class="relative">
                      <button class="h-7 px-2 text-[11px] bg-gray-50 rounded border-none outline-none text-left w-24 truncate flex-shrink-0" @click="toggleGSelect(p)" :title="frameSelectedNames(p.value)">
                        {{ frameSelectedNames(p.value) || '选择' }}
                      </button>
                      <div v-if="gOpen === p.permissionKey" class="absolute bottom-full right-0 mb-1 z-50 bg-white rounded-xl shadow-lg border border-gray-100 p-2 w-48 max-h-48 overflow-y-auto">
                        <label v-for="fr in frameList" :key="fr.id" class="flex items-center gap-2 px-2 py-1.5 rounded-lg active:bg-gray-50 cursor-pointer">
                          <input type="checkbox" :checked="isGSelected(p.value, fr.id)" @change="toggleGItem(p, fr.id)" class="w-4 h-4 rounded accent-[#FF4757]" />
                          <span class="text-xs text-gray-700 truncate">{{ fr.name }}</span>
                        </label>
                        <div v-if="frameList.length===0" class="text-xs text-gray-400 text-center py-2">暂无头像框</div>
                      </div>
                    </div>
                  </template>
                  <template v-else-if="p.permissionKey === 'G2'">
                    <div class="relative">
                      <button class="h-7 px-2 text-[11px] bg-gray-50 rounded border-none outline-none text-left w-24 truncate flex-shrink-0" @click="toggleGSelect(p)" :title="titleSelectedNames(p.value)">
                        {{ titleSelectedNames(p.value) || '选择' }}
                      </button>
                      <div v-if="gOpen === p.permissionKey" class="absolute bottom-full right-0 mb-1 z-50 bg-white rounded-xl shadow-lg border border-gray-100 p-2 w-48 max-h-48 overflow-y-auto">
                        <label v-for="tr in titleList" :key="tr.id" class="flex items-center gap-2 px-2 py-1.5 rounded-lg active:bg-gray-50 cursor-pointer">
                          <input type="checkbox" :checked="isGSelected(p.value, tr.id)" @change="toggleGItem(p, tr.id)" class="w-4 h-4 rounded accent-[#FF4757]" />
                          <span class="text-xs text-gray-700 truncate">{{ tr.name }}</span>
                        </label>
                        <div v-if="titleList.length===0" class="text-xs text-gray-400 text-center py-2">暂无称号</div>
                      </div>
                    </div>
                  </template>
                  <button class="w-8 h-5 rounded-full transition-colors relative flex-shrink-0"
                    v-else-if="isBooleanPerm(p.permissionKey)"
                    :class="p.value === 'true' ? 'bg-[#FF4757]' : 'bg-gray-300'"
                    @click="p.value = p.value === 'true' ? 'false' : 'true'">
                    <span class="w-3.5 h-3.5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform"
                      :class="p.value === 'true' ? 'left-4' : 'left-0.5'" />
                  </button>
                  <input v-else
                    :value="p.value"
                    @input="updatePermissionValue(p, $event.target.value)"
                    type="text"
                    class="w-14 h-7 px-1.5 text-[11px] bg-gray-50 rounded border-none outline-none text-center flex-shrink-0"
                  />
                  <button class="w-5 h-5 flex items-center justify-center text-gray-300 active:text-red-500 flex-shrink-0" @click="p.value = ''" title="清空">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                  </button>
                </div>
              </template>
            </div>
          </div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="confirmVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-400">确定要删除「{{ confirmTarget?.name }}」吗？此操作不可恢复。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">确定删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'ExperienceMobile' })

const MOD_LABELS: Record<string, string> = {
  community: '社区', mall: '商城', appstore: '应用', social: '社交',
  avatar: '形象', function: '功能', invite: '邀请', monetize: '变现'
}

const BOOLEAN_PERMS = new Set(['A1','A2','A5','A9','A10','B1','B3','B5','C1','C2','C5','C14','C15','C17','D4','D10','D13','E1','H3'])

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const loading=ref(false);const data=ref<any[]>([])
const fetchData=async()=>{loading.value=true;try{const res:any=await request.get({url:'/api/operation/experience-level/list'});data.value=res?.records||res?.data?.records||res||[]}catch{}loading.value=false}

const iconInput=ref<HTMLInputElement>();const uploadingIcon=ref(false)
const triggerIconUpload=()=>iconInput.value?.click()
const handleIconUpload=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploadingIcon.value=true;try{const fd=new FormData();fd.append('file',file);const res:any=await request.post({url:'/api/upload/experience-icon',data:fd,headers:{}});form.icon=res?.url||res?.data?.url||res?.data||'';showToast('上传成功')}catch(e:any){showToast('上传失败: '+(e.message||''),'error')}uploadingIcon.value=false;input.value=''}

const dialogVisible=ref(false);const editId=ref<number|null>(null)
const permExpanded=ref(false)
const permissions=ref<any[]>([])
const frameList=ref<any[]>([])
const titleList=ref<any[]>([])
const gOpen=ref('')

const form=reactive({name:'',level:1,expRequired:0,icon:'',iconColor:'#00BFA5',textColor:'#FFFFFF',bgColor:'#508DFF',benefits:'',status:'1',
  dailyGiftEnabled:false,dailyGiftIntervalDays:1,dailyGiftPoints:0,dailyGiftBalance:0,dailyGiftExperience:0,dailyGiftCouponIds:'',dailyGiftMakeupCount:0,
  firstGiftPoints:0,firstGiftBalance:0,firstGiftExperience:0,firstGiftCouponIds:'',firstGiftMakeupCount:0})

const groupedPerms = computed(() => {
  const groups: Record<string, any[]> = {}
  for (const p of permissions.value) {
    const m = p.module || 'community'
    if (!groups[m]) groups[m] = []
    groups[m].push(p)
  }
  return groups
})
const modLabel = (mod: string) => MOD_LABELS[mod] || mod

const toggleGSelect = (p: any) => { gOpen.value = gOpen.value === p.permissionKey ? '' : p.permissionKey }
const isGSelected = (val: string, id: number) => (val||'').split(',').includes(String(id))
const toggleGItem = (p: any, id: number) => {
  const ids = (p.value||'').split(',').filter(Boolean)
  const idx = ids.indexOf(String(id))
  if (idx>=0) ids.splice(idx,1); else ids.push(String(id))
  p.value = ids.join(',')
}
const getNames = (val: string, list: any[]) => (val||'').split(',').filter(Boolean).map(id => list.find(x=>x.id===Number(id))?.name||id).join(',') || ''
const frameSelectedNames = (val: string) => getNames(val, frameList.value)
const titleSelectedNames = (val: string) => getNames(val, titleList.value)

const fetchFrames = async () => {
  try { const res: any = await request.get({ url: '/api/avatar-frame/list' }); frameList.value = Array.isArray(res) ? res : (res?.data || []) } catch {}
}
const fetchTitles = async () => {
  try { const res: any = await request.get({ url: '/api/title/list' }); titleList.value = Array.isArray(res) ? res : (res?.data || []) } catch {}
}

const isBooleanPerm = (key: string) => BOOLEAN_PERMS.has(key)

const updatePermissionValue = (p: any, val: string) => { p.value = val }

const fetchPermissions = async (level: number) => {
  permExpanded.value = false
  permissions.value = []
  if (!level) return
  try {
    const res: any = await request.get({ url: `/api/operation/experience-level/permissions/${level}` })
    permissions.value = res?.data || res || []
  } catch {}
  fetchFrames(); fetchTitles()
}

const openDialog=(item:any|null)=>{
  editId.value=item?.id||null
  if(item){
    form.name=item.name||'';form.level=item.level||1;form.expRequired=item.expRequired||0
    form.icon=item.icon||'';form.iconColor=item.iconColor||'#00BFA5';form.textColor=item.textColor||'#FFFFFF'
    form.bgColor=item.bgColor||'#508DFF';form.benefits=item.benefits||'';form.status=item.status||'1'
    form.dailyGiftEnabled=!!item.dailyGiftEnabled;form.dailyGiftIntervalDays=item.dailyGiftIntervalDays||1
    form.dailyGiftPoints=item.dailyGiftPoints||0;form.dailyGiftBalance=item.dailyGiftBalance||0
    form.dailyGiftExperience=item.dailyGiftExperience||0;form.dailyGiftCouponIds=item.dailyGiftCouponIds||''
    form.dailyGiftMakeupCount=item.dailyGiftMakeupCount||0
    form.firstGiftPoints=item.firstGiftPoints||0;form.firstGiftBalance=item.firstGiftBalance||0
    form.firstGiftExperience=item.firstGiftExperience||0;form.firstGiftCouponIds=item.firstGiftCouponIds||''
    form.firstGiftMakeupCount=item.firstGiftMakeupCount||0
    fetchPermissions(item.level)
  }else{
    Object.assign(form,{name:'',level:1,expRequired:0,icon:'',iconColor:'#00BFA5',textColor:'#FFFFFF',bgColor:'#508DFF',benefits:'',status:'1',
      dailyGiftEnabled:false,dailyGiftIntervalDays:1,dailyGiftPoints:0,dailyGiftBalance:0,dailyGiftExperience:0,dailyGiftCouponIds:'',dailyGiftMakeupCount:0,
      firstGiftPoints:0,firstGiftBalance:0,firstGiftExperience:0,firstGiftCouponIds:'',firstGiftMakeupCount:0})
    permissions.value = []
  }
  dialogVisible.value=true
}

const saveItem=async()=>{
  try{
    await request.post({url:'/api/operation/experience-level/save',data:{id:editId.value||undefined,...form}})
    if (permissions.value.length > 0) {
      await request.put({
        url: `/api/operation/experience-level/permissions/${form.level}`,
        data: { permissions: permissions.value.map(p => ({ module: p.module, permissionKey: p.permissionKey, value: p.value })) }
      })
    }
    showToast('保存成功');dialogVisible.value=false;fetchData()
  }catch(e:any){showToast('保存失败: '+(e.message||''),'error')}
}
const deleteItem=(item:any)=>{confirmTarget.value=item;confirmVisible.value=true}
const confirmVisible=ref(false);const confirmTarget=ref<any>(null)
const doDelete=async()=>{if(!confirmTarget.value)return;try{await request.del({url:`/api/operation/experience-level/${confirmTarget.value.id}`});showToast('删除成功');confirmVisible.value=false;fetchData()}catch{showToast('删除失败','error')}}

// ===== 权益对比 =====
const compareMode = ref(false)
const compareLoading = ref(false)
const compareLevels = ref<any[]>([])
const comparePerms = ref<any[]>([])

const compareGrouped = computed(() => {
  const groups: Record<string, any[]> = {}
  for (const p of comparePerms.value) {
    const m = p.module || 'community'
    if (!groups[m]) groups[m] = []
    groups[m].push(p)
  }
  return groups
})

const openCompare = async () => {
  compareMode.value = true
  compareLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/operation/experience-level/permissions-compare' })
    const rawData = res?.data || res || {}
    const levels = rawData.levels || []
    const userLevel = rawData.userLevel || 0
    // 用户等级排第一，其余按等级降序
    const sorted = [...levels].sort((a: any, b: any) => {
      if (a.level === userLevel) return -1
      if (b.level === userLevel) return 1
      return b.level - a.level
    })
    compareLevels.value = sorted
    comparePerms.value = rawData.permissions || []
  } catch (e) {
    showToast('加载对比数据失败', 'error')
  }
  compareLoading.value = false
}

onMounted(()=>{fetchData()})
</script>
