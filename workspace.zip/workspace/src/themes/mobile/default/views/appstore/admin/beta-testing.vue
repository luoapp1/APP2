<template>
  <div class="beta-page">
    <div class="page-navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">灰度内测</span>
      <div style="width:22px" />
    </div>

    <div class="page-content">
      <LoadingState v-if="loading" />
      <ErrorState v-else-if="error" :error="error" @retry="loadData" />
      <EmptyState v-else-if="!list.length" text="暂无内测应用">
        <template #icon>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5" style="margin-bottom:12px"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
        </template>
      </EmptyState>
      <div v-else class="beta-list">
        <div v-for="item in list" :key="item.id" class="beta-item" @click="toggleExpand(item)">
          <div class="beta-main">
            <div class="beta-info">
              <div class="beta-name">{{ item.appName }}</div>
              <div class="beta-meta">
                <span class="beta-status" :class="statusClass(item.status)">{{ statusLabel(item.status) }}</span>
                <span>{{ item.currentTesters || 0 }} / {{ item.maxTesters || 0 }} 人</span>
              </div>
            </div>
            <svg :class="['beta-arrow', { rotated: expandedId === item.id }]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>
          </div>
          <div v-if="expandedId === item.id" class="beta-detail">
            <div v-if="testersLoading" class="detail-loading">加载中...</div>
            <div v-else-if="!testers.length" class="detail-empty">暂无测试用户</div>
            <div v-else class="tester-list">
              <div v-for="t in testers" :key="t.userId" class="tester-item">
                <div class="tester-avatar">{{ (t.username || '?')[0] }}</div>
                <span class="tester-name">{{ t.username }}</span>
                <span class="tester-time">{{ formatDate(t.joinedTime) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'
import ErrorState from '@/components/core/error/art-error-state/index.vue'
import LoadingState from '@/components/core/loading/art-loading-state/index.vue'
import EmptyState from '@/components/core/empty/art-empty-state/index.vue'

const loading = ref(false)
const error = ref('')
const list = ref([])
const expandedId = ref(null)
const testers = ref([])
const testersLoading = ref(false)

const statusMap = {
  'active': { label: '进行中', cls: 'status-active' },
  'paused': { label: '已暂停', cls: 'status-paused' },
  'ended': { label: '已结束', cls: 'status-ended' },
  '1': { label: '进行中', cls: 'status-active' },
  '0': { label: '已暂停', cls: 'status-paused' },
  '-1': { label: '已结束', cls: 'status-ended' }
}

function statusLabel(s) { return (statusMap[s] || statusMap['active']).label }
function statusClass(s) { return (statusMap[s] || statusMap['active']).cls }

function formatDate(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    if (isNaN(dt.getTime())) return String(d).slice(0, 10)
    return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`
  } catch { return String(d).slice(0, 10) }
}

async function toggleExpand(item) {
  if (expandedId.value === item.id) {
    expandedId.value = null
    return
  }
  expandedId.value = item.id
  testersLoading.value = true
  testers.value = []
  try {
    const res = await request.get({ url: `/api/appstore/beta/${item.appId}/users` })
    const d = res?.data || res || {}
    testers.value = d.list || []
  } catch { testers.value = [] }
  finally { testersLoading.value = false }
}

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    const res = await request.get({ url: '/api/appstore/beta/apps' })
    const d = res?.data || res || {}
    list.value = d.list || []
  } catch (e) {
    error.value = e?.response?.data?.msg || e?.message || '加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.beta-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

.page-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.nav-back:active { background: #f0f0f0; }
.nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

.page-content { padding: 16px; }

.load-wrap { display: flex; justify-content: center; padding: 48px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.err-wrap { text-align: center; padding: 48px 16px; }
.err-text { font-size: 14px; color: #EF4444; margin-bottom: 12px; }
.empty-wrap { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 60px 0; }
.empty-text { font-size: 14px; color: #999; }

.beta-list { display: flex; flex-direction: column; gap: 10px; }
.beta-item { background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,.04); }
.beta-main { display: flex; align-items: center; padding: 14px; cursor: pointer; }
.beta-main:active { background: #fafafa; }
.beta-info { flex: 1; min-width: 0; }
.beta-name { font-size: 15px; font-weight: 600; color: #1a1a1a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.beta-meta { display: flex; align-items: center; gap: 10px; margin-top: 4px; font-size: 12px; color: #999; }
.beta-status { padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; }
.status-active { background: #D1FAE5; color: #059669; }
.status-paused { background: #FEF3C7; color: #D97706; }
.status-ended { background: #F3F4F6; color: #9CA3AF; }
.beta-arrow { flex-shrink: 0; transition: transform .2s; }
.beta-arrow.rotated { transform: rotate(180deg); }

.beta-detail { border-top: 1px solid #f5f5f5; padding: 10px 14px 14px; }
.detail-loading { text-align: center; padding: 16px; color: #999; font-size: 13px; }
.detail-empty { text-align: center; padding: 20px; color: #bbb; font-size: 13px; }
.tester-list { display: flex; flex-direction: column; gap: 8px; }
.tester-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #fafafa; }
.tester-item:last-child { border-bottom: none; }
.tester-avatar { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; }
.tester-name { flex: 1; font-size: 14px; font-weight: 500; color: #333; }
.tester-time { font-size: 11px; color: #bbb; }

.btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; }
.btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.btn-primary:active { background: #4F46E5; }
</style>
