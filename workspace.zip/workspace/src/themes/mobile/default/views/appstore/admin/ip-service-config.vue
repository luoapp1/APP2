<template>
  <div class="cfg-page">
    <div class="cfg-navbar">
      <button class="cfg-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="cfg-title">IP 定位配置</span>
      <button class="cfg-save" @click="save" :disabled="saving">{{ saving ? '保存中' : '保存' }}</button>
    </div>

    <div class="cfg-content">
      <div class="cfg-card">
        <div class="cfg-row">
          <span class="cfg-label">启用 IP 定位</span>
          <label class="cfg-toggle">
            <input type="checkbox" v-model="form.enabled" />
            <span class="cfg-toggle-slider"></span>
          </label>
        </div>

        <div class="cfg-row">
          <span class="cfg-label">定位服务商</span>
          <select class="cfg-select" v-model="form.provider">
            <option value="free">免费 (ip-api.com)</option>
            <option value="tencent">腾讯云 IP 定位</option>
            <option value="aliyun">阿里云 IP 定位</option>
          </select>
        </div>

        <template v-if="form.provider !== 'free'">
          <div class="cfg-row">
            <span class="cfg-label">API Key</span>
            <div class="cfg-input-wrap">
              <input
                class="cfg-input"
                :type="showKey ? 'text' : 'password'"
                v-model="form.apiKey"
                placeholder="请输入 API Key"
              />
              <button class="cfg-eye" @click="showKey = !showKey">
                <svg v-if="showKey" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="1.8" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#CCC" stroke-width="1.8" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
              </button>
            </div>
          </div>
          <div class="cfg-row">
            <span class="cfg-label">API Secret</span>
            <div class="cfg-input-wrap">
              <input
                class="cfg-input"
                :type="showSecret ? 'text' : 'password'"
                v-model="form.apiSecret"
                placeholder="请输入 API Secret"
              />
              <button class="cfg-eye" @click="showSecret = !showSecret">
                <svg v-if="showSecret" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="1.8" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#CCC" stroke-width="1.8" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
              </button>
            </div>
          </div>
        </template>

        <div v-if="form.provider === 'tencent'" class="cfg-note">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>腾讯云使用 TC3-HMAC-SHA256 签名认证，需在控制台开通"IP 定位"服务并获取 SecretId 和 SecretKey。</span>
        </div>
        <div v-if="form.provider === 'aliyun'" class="cfg-note">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#409EFF" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>阿里云使用淘宝 IP 库，无需额外 API 密钥即可使用基础定位。</span>
        </div>
      </div>

      <div class="cfg-card cfg-test">
        <div class="cfg-row cfg-test-row" @click="showTest = !showTest">
          <span class="cfg-label">连接测试</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2" :style="{ transform: showTest ? 'rotate(90deg)' : '' }" style="transition: .2s"><path d="M9 18l6-6-6-6" stroke-linecap="round"/></svg>
        </div>
        <div v-if="showTest" class="cfg-test-body">
          <button class="cfg-test-btn" @click="testConnection" :disabled="testing">
            {{ testing ? '测试中...' : '测试连通性' }}
          </button>
          <div v-if="testResult" class="cfg-test-result" :class="testResult.error ? 'fail' : 'ok'">
            {{ testResult.msg }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const form = reactive({
  provider: 'free',
  apiKey: '',
  apiSecret: '',
  enabled: true
})

const saving = ref(false)
const showKey = ref(false)
const showSecret = ref(false)
const showTest = ref(false)
const testing = ref(false)
const testResult = ref<{ msg: string, error?: boolean } | null>(null)

onMounted(async () => {
  try {
    const res: any = await request.get({ url: '/api/sys-config/list' })
    const list = res?.data || (Array.isArray(res) ? res : [])
    if (Array.isArray(list)) {
      const map: Record<string, string> = {}
      for (const item of list) {
        map[item.config_key] = item.config_value
      }
      form.provider = map.ip_geo_provider || 'free'
      form.apiKey = map.ip_geo_api_key || ''
      form.apiSecret = map.ip_geo_api_secret || ''
      form.enabled = map.ip_geo_enabled !== '0'
    }
  } catch {}
})

async function save() {
  saving.value = true
  try {
    await request.post({
      url: '/api/sys-config/save',
      data: {
        configs: [
          { config_key: 'ip_geo_provider', config_value: form.provider },
          { config_key: 'ip_geo_api_key', config_value: form.apiKey },
          { config_key: 'ip_geo_api_secret', config_value: form.apiSecret },
          { config_key: 'ip_geo_enabled', config_value: form.enabled ? '1' : '0' }
        ]
      }
    })
    ElMessage.success('保存成功')
  } catch {
    ElMessage.error('保存失败')
  } finally {
    saving.value = false
  }
}

async function testConnection() {
  testing.value = true
  testResult.value = null
  try {
    const params = new URLSearchParams({
      provider: form.provider,
      ...(form.provider !== 'free' ? { apiKey: form.apiKey, apiSecret: form.apiSecret } : {})
    }).toString()
    const res: any = await request.get({ url: '/api/ip-geo/test?' + params })
    if (res?.location) {
      testResult.value = { msg: res.location, error: false }
    } else {
      testResult.value = { msg: '连接失败，无返回数据', error: true }
    }
  } catch {
    testResult.value = { msg: '连接测试失败', error: true }
  } finally {
    testing.value = false
  }
}
</script>

<style scoped>
.cfg-page { min-height: 100vh; background: #F5F6FA; }

.cfg-navbar {
  display: flex; align-items: center; padding: 10px 12px;
  background: #fff; position: sticky; top: 0; z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.05);
}

.cfg-back {
  background: none; border: none; padding: 4px; cursor: pointer;
  display: flex; color: #333; border-radius: 8px;
}
.cfg-back:active { background: #f0f0f0; }

.cfg-title {
  flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a;
}

.cfg-save {
  background: #409EFF; color: #fff; border: none; padding: 6px 14px;
  border-radius: 8px; font-size: 13px; cursor: pointer;
}
.cfg-save:active { background: #3078D0; }
.cfg-save:disabled { opacity: .6; }

.cfg-content { padding: 12px 16px; display: flex; flex-direction: column; gap: 12px; }

.cfg-card { background: #fff; border-radius: 12px; overflow: hidden; }

.cfg-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px; border-bottom: 1px solid #F0F0F0; gap: 12px;
}
.cfg-row:last-child { border-bottom: none; }

.cfg-label { font-size: 15px; color: #333; flex-shrink: 0; }

.cfg-select {
  border: 1px solid #E0E0E0; border-radius: 8px; padding: 8px 10px;
  font-size: 14px; color: #333; background: #fff; max-width: 180px; outline: none;
}
.cfg-select:focus { border-color: #409EFF; }

.cfg-input-wrap { display: flex; align-items: center; gap: 6px; flex: 1; max-width: 220px; }
.cfg-input {
  flex: 1; border: 1px solid #E0E0E0; border-radius: 8px; padding: 8px 10px;
  font-size: 14px; color: #333; outline: none; min-width: 0;
}
.cfg-input:focus { border-color: #409EFF; }
.cfg-input::placeholder { color: #CCC; }

.cfg-eye {
  background: none; border: none; padding: 2px; cursor: pointer; display: flex;
}

.cfg-toggle {
  position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0;
}
.cfg-toggle input { opacity: 0; width: 0; height: 0; }
.cfg-toggle-slider {
  position: absolute; cursor: pointer; inset: 0; background: #E0E0E0;
  border-radius: 12px; transition: .2s;
}
.cfg-toggle-slider::before {
  content: ''; position: absolute; height: 20px; width: 20px; left: 2px; bottom: 2px;
  background: #fff; border-radius: 50%; transition: .2s; box-shadow: 0 1px 3px rgba(0,0,0,.15);
}
.cfg-toggle input:checked + .cfg-toggle-slider { background: #10B981; }
.cfg-toggle input:checked + .cfg-toggle-slider::before { transform: translateX(20px); }

.cfg-note {
  display: flex; align-items: flex-start; gap: 8px; padding: 12px 16px;
  background: #F0F7FF; font-size: 12px; color: #666; line-height: 1.5;
}

.cfg-test-row { cursor: pointer; }
.cfg-test-row:active { background: #f5f5f5; }
.cfg-test-body { padding: 0 16px 16px; }
.cfg-test-btn {
  width: 100%; padding: 10px; border: 1px dashed #409EFF; border-radius: 10px;
  background: #F0F7FF; color: #409EFF; font-size: 14px; cursor: pointer;
}
.cfg-test-btn:active { background: #E0EEFF; }
.cfg-test-btn:disabled { opacity: .6; }

.cfg-test-result {
  margin-top: 10px; padding: 10px 12px; border-radius: 8px; font-size: 13px;
}
.cfg-test-result.ok { background: #F0FFF4; color: #16A34A; }
.cfg-test-result.fail { background: #FFF0F0; color: #DC2626; }
</style>
