<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">商品管理</span>
      <button class="add-btn" v-auth="'add'" @click="router.push('/appstore/mall-product-create')">+ 新增</button>
    </div>

    <div class="filters">
      <select v-model="filterStatus" @change="loadList" class="filter-select">
        <option value="">全部状态</option>
        <option value="published">已上架</option>
        <option value="draft">草稿</option>
        <option value="offline">已下架</option>
      </select>
      <select v-model="filterType" @change="loadList" class="filter-select">
        <option value="">全部类型</option>
        <option value="virtual_auto">自动虚拟</option>
        <option value="virtual_manual">手动发货</option>
        <option value="physical">实物商品</option>
      </select>
      <input v-model="keyword" placeholder="搜索商品..." class="search-input" @keydown.enter="loadList" />
    </div>

    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>
    <div v-else class="list">
      <div v-if="products.length === 0" class="empty">暂无商品</div>
      <div v-for="p in products" :key="p.id" class="item">
        <img v-if="p.coverImage" :src="fixImgUrl(p.coverImage)" class="item-img"  loading="lazy" />
        <div v-else class="item-img item-img-fb">{{ p.name[0] }}</div>
        <div class="item-info">
          <div class="item-name">{{ p.name }}</div>
          <div class="item-meta">
            <span class="type-tag" :class="'type-' + p.productType">{{ typeLabel(p.productType) }}</span>
            <span class="price-tag">{{ p.priceType === 'points' ? p.price + '积分' : '¥' + p.price }}</span>
            <span>{{ statusLabel(p.status) }}</span>
          </div>
          <div class="item-meta">库存: {{ p.stock }} | 销量: {{ p.salesCount || 0 }}</div>
        </div>
        <button class="action-btn edit" v-auth="'edit'" @click.stop="goEdit(p.id)">编辑</button>
        <button v-if="p.status === 'published'" class="action-btn off" v-auth="'edit'" @click.stop="toggleStatus(p)">下架</button>
        <button v-else class="action-btn on" v-auth="'edit'" @click.stop="toggleStatus(p)">上架</button>
        <button class="action-btn del" v-auth="'delete'" @click.stop="deleteProduct(p)">删除</button>
      </div>
    </div>

    <div v-if="total > pageSize" class="pager">
      <button :disabled="page <= 1" @click="page--; loadList()">上一页</button>
      <span>{{ page }} / {{ Math.ceil(total / pageSize) }}</span>
      <button :disabled="page >= Math.ceil(total / pageSize)" @click="page++; loadList()">下一页</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const products = ref<any[]>([])
const loading = ref(true)
const keyword = ref('')
const filterStatus = ref('')
const filterType = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

function goEdit(id: number) {
  router.push({ path: '/appstore/mall-product-create', query: { id } })
}
function typeLabel(t: string) {
  return { virtual_auto: '自动虚拟', virtual_manual: '手动发货', physical: '实物' }[t] || t
}
function statusLabel(s: string) {
  return { published: '已上架', draft: '草稿', offline: '已下架' }[s] || s
}

async function loadList() {
  loading.value = true
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (keyword.value) params.keyword = keyword.value
    if (filterStatus.value) params.status = filterStatus.value
    if (filterType.value) params.productType = filterType.value
    const res: any = await request.get({ url: '/api/mall/products', params })
    products.value = res?.list || []
    total.value = res?.total || 0
  } catch {} finally { loading.value = false }
}

async function toggleStatus(p: any) {
  const newStatus = p.status === 'published' ? 'offline' : 'published'
  try {
    await request.put({ url: `/api/mall/products/${p.id}`, data: { ...p, status: newStatus } })
    p.status = newStatus
  } catch {}
}

async function deleteProduct(p: any) {
  try {
    await ElMessageBox.confirm(`确定要删除商品「${p.name}」吗？删除后不可恢复。`, '删除确认', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await request.del({ url: `/api/mall/products/${p.id}` })
    ElMessage.success('删除成功')
    loadList()
  } catch {}
}

onMounted(loadList)
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.add-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; cursor: pointer; }

.filters { display: flex; gap: 8px; padding: 10px 14px; background: #fff; border-bottom: 1px solid #f0f0f0; }
.filter-select { flex: 1; padding: 6px 8px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 12px; background: #fff; }
.search-input { flex: 2; padding: 6px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 12px; }

.loading { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }

.list { padding: 8px 0; }
.empty { text-align: center; padding: 60px; color: #bbb; font-size: 14px; }
.item { display: flex; align-items: center; gap: 12px; padding: 12px 14px; background: #fff; margin: 0 10px 8px; border-radius: 12px; }
.item-img { width: 48px; height: 48px; border-radius: 10px; object-fit: cover; flex-shrink: 0; }
.item-img-fb { background: #FF6B6B; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 18px; }
.item-info { flex: 1; min-width: 0; }
.item-name { font-size: 14px; font-weight: 600; color: #222; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.item-meta { font-size: 11px; color: #999; margin-top: 3px; display: flex; gap: 8px; align-items: center; }
.type-tag { font-size: 10px; padding: 1px 6px; border-radius: 4px; font-weight: 600; }
.type-virtual_auto { background: #E8F5E9; color: #2E7D32; }
.type-virtual_manual { background: #FFF3E0; color: #E65100; }
.type-physical { background: #E3F2FD; color: #1565C0; }
.price-tag { color: #FF4757; font-weight: 600; }

.action-btn { border: none; padding: 5px 12px; border-radius: 6px; font-size: 12px; cursor: pointer; flex-shrink: 0; }
.action-btn.off { background: #f5f5f5; color: #FF6B6B; }
.action-btn.on { background: #E8F5E9; color: #2E7D32; }
.action-btn.del { background: #FFF0F0; color: #E53935; }
.action-btn.edit { background: #E3F2FD; color: #1976D2; }

.pager { display: flex; justify-content: center; align-items: center; gap: 16px; padding: 16px; font-size: 13px; color: #666; }
.pager button { border: 1px solid #ddd; background: #fff; padding: 6px 14px; border-radius: 8px; cursor: pointer; font-size: 12px; }
.pager button:disabled { opacity: 0.4; cursor: default; }
</style>
