<template>
  <Teleport to="body">
    <div v-if="visible" class="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-black/40" @click.self="close">
      <div class="bg-white rounded-t-2xl sm:rounded-2xl w-full sm:max-w-md max-h-[80vh] overflow-y-auto animate-slide-up" @click.stop>
        <!-- Header -->
        <div class="sticky top-0 bg-white/95 backdrop-blur z-10 flex items-center justify-between px-5 pt-5 pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#8B5CF6] flex items-center justify-center">
              <svg class="w-3.5 h-3.5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M3 3h18v18H3V3zm4 4v2h2V7H7zm0 4v2h2v-2H7zm0 4v2h2v-2H7zm4-8v2h6V7h-6zm0 4v2h6v-2h-6zm0 4v2h6v-2h-6z"/></svg>
            </div>
            <span class="text-[17px] text-[#1A1A1A] font-bold">版主团队</span>
          </div>
          <div class="w-8 h-8 rounded-full bg-[#F5F5F5] flex items-center justify-center cursor-pointer active:bg-gray-200" @click="close">
            <svg class="w-4 h-4 text-[#888]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M18 6L6 18M6 6l12 12"/></svg>
          </div>
        </div>

        <!-- Loading -->
        <div v-if="loading" class="flex justify-center py-16">
          <div class="w-6 h-6 border-2 border-[#6366F1] border-t-transparent rounded-full animate-spin"/>
        </div>

        <template v-else>
          <!-- Moderator list -->
          <div v-if="moderators.length > 0" class="px-5 pb-2">
            <div class="text-xs text-gray-400 font-medium py-2">共 {{ moderators.length }} 位版主</div>
            <div class="space-y-1.5">
              <div
                v-for="mod in moderators"
                :key="mod.userId"
                class="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-gray-50/60"
              >
                <div class="relative flex-shrink-0">
                  <div class="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center bg-gray-200">
                    <img v-if="mod.userAvatar" :src="mod.userAvatar" class="w-full h-full object-cover" loading="lazy" />
                    <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover"  loading="lazy" />
                  </div>
                  <div
                    class="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white"
                    :style="badgeClass(mod.role)"
                  >
                    <svg class="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                  </div>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm text-[#1A1A1A] font-semibold truncate">{{ mod.userName }}</div>
                  <span
                    class="inline-block text-[10px] px-2 py-0.5 rounded-full mt-0.5 font-medium"
                    :style="roleClass(mod.role)"
                  >{{ mod.role }}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 申请入口 -->
          <div class="px-5 pt-1 pb-5 border-t border-gray-100 mt-1">
            <!-- 已有申请状态 -->
            <div v-if="myApplication" class="flex items-center justify-between py-2.5">
              <div class="flex items-center gap-2">
                <span class="text-xs font-medium px-2 py-0.5 rounded-full" :class="statusBadge(myApplication.status)">{{ statusLabel(myApplication.status) }}</span>
                <span class="text-xs text-gray-400">期望: {{ myApplication.desiredRole || '版主' }}</span>
              </div>
              <span v-if="myApplication.status === 'rejected'" class="text-xs text-[#6366F1] font-medium active:opacity-60 cursor-pointer" @click="applyVisible = true">重新申请</span>
            </div>
            <div v-if="myApplication?.reviewComment" class="text-xs text-gray-400 mt-1 italic">审核意见: {{ myApplication.reviewComment }}</div>

            <!-- 申请中提示 -->
            <p v-if="!applyVisible && (!myApplication || myApplication.status === 'rejected')" class="text-xs text-gray-400 leading-relaxed">
              {{ moderators.length === 0 ? '暂未设置版主，' : '' }}立即申请成为版主，参与板块管理
            </p>

            <!-- 申请表单 -->
            <div v-if="applyVisible" class="mt-2 space-y-3">
              <div>
                <label class="text-xs text-gray-500 font-medium block mb-1.5">选择角色</label>
                <div class="flex gap-1.5 flex-wrap">
                  <span
                    v-for="r in roles" :key="r"
                    class="text-xs px-3 py-1.5 rounded-full border cursor-pointer transition-colors font-medium"
                    :class="applyRole === r ? 'border-[#6366F1] bg-[#EEF2FF] text-[#6366F1]' : 'border-gray-200 text-gray-500 active:bg-gray-50'"
                    @click="applyRole = r"
                  >{{ r }}</span>
                </div>
              </div>
              <div>
                <label class="text-xs text-gray-500 font-medium block mb-1.5">申请理由</label>
                <textarea v-model="applyReason" rows="3" class="w-full text-sm border border-gray-200 rounded-xl p-3 outline-none focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]/20 resize-none transition-shadow" placeholder="请简述您的申请理由..." />
              </div>
              <div class="flex gap-2.5 pt-1">
                <button class="flex-1 py-2.5 text-sm rounded-xl bg-gray-100 text-gray-600 font-medium active:bg-gray-200" @click="applyVisible = false">取消</button>
                <button class="flex-1 py-2.5 text-sm rounded-xl bg-[#6366F1] text-white font-medium disabled:opacity-40 active:bg-[#5558E6]" :disabled="!applyReason.trim() || applySubmitting" @click="doApply">
                  {{ applySubmitting ? '提交中...' : '提交申请' }}
                </button>
              </div>
            </div>

            <!-- 申请按钮 -->
            <button
              v-if="(!myApplication || myApplication.status === 'rejected') && !applyVisible"
              class="w-full mt-3 py-2.5 text-sm rounded-xl bg-[#6366F1] text-white font-medium active:bg-[#5558E6] transition-colors flex items-center justify-center gap-1.5"
              @click="applyVisible = true"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" d="M12 5v14M5 12h14"/></svg>
              {{ moderators.length === 0 ? '成为第一位版主' : '申请圈主' }}
            </button>
          </div>
        </template>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { fetchModerators, applyForModerator, fetchMyApplication } from '@/api/community'

const props = defineProps<{ visible: boolean; sectionId: number }>()
const emit = defineEmits<{ (e: 'close'): void }>()

const moderators = ref<any[]>([])
const loading = ref(false)
const myApplication = ref<any>(null)
const applyVisible = ref(false)
const applyReason = ref('')
const applyRole = ref('版主')
const applySubmitting = ref(false)
const roles = ['版主', '管理员', '超级版主', '审核员']

function statusLabel(s: string) {
  if (s === 'pending') return '审核中'
  if (s === 'approved') return '已通过'
  if (s === 'rejected') return '已拒绝'
  return s
}

function statusBadge(s: string) {
  if (s === 'pending') return 'bg-yellow-50 text-yellow-600'
  if (s === 'approved') return 'bg-green-50 text-green-600'
  return 'bg-red-50 text-red-600'
}

async function doApply() {
  applySubmitting.value = true
  try {
    await applyForModerator(props.sectionId, { reason: applyReason.value, desiredRole: applyRole.value })
    applyVisible.value = false
    applyReason.value = ''
    await load()
  } catch (e: any) {
    alert(e?.response?.data?.msg || e?.message || '申请失败')
  } finally { applySubmitting.value = false }
}

const avatarColors = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#E11D48','#7C3AED']
function avatarColor(name: string): string {
  let h = 0; for (let i = 0; i < (name||'').length; i++) h = name.charCodeAt(i) + ((h<<5)-h)
  return avatarColors[Math.abs(h) % avatarColors.length]
}

const ROLE_TAG_COLORS = ['#6366F1','#EF4444','#F97316','#16A34A','#8B5CF6','#E11D48','#06B6D4','#EC4899','#F59E0B','#14B8A6']
function roleColor(role: string): string {
  let h = 0; for (let i = 0; i < (role||'').length; i++) h = role.charCodeAt(i) + ((h<<5)-h)
  return ROLE_TAG_COLORS[Math.abs(h) % ROLE_TAG_COLORS.length]
}

function roleClass(role: string) {
  const c = roleColor(role)
  return { background: c + '18', color: c }
}

function badgeClass(role: string) {
  const c = roleColor(role)
  const r = parseInt(c.slice(1,3), 16)
  const g = parseInt(c.slice(3,5), 16)
  const b = parseInt(c.slice(5,7), 16)
  const darken = (v: number) => Math.max(0, Math.round(v * 0.75)).toString(16).padStart(2, '0')
  return { background: `linear-gradient(135deg, ${c}, #${darken(r)}${darken(g)}${darken(b)})` }
}

async function load() {
  if (!props.sectionId) return
  loading.value = true
  try {
    const res: any = await fetchModerators(props.sectionId)
    moderators.value = res?.data || res || []
    const app: any = await fetchMyApplication(props.sectionId)
    myApplication.value = app?.data || null
  } catch {} finally { loading.value = false }
}

function close() { emit('close') }

watch(() => props.visible, (v) => {
  if (v && props.sectionId) {
    applyVisible.value = false
    applyReason.value = ''
    load()
  }
})
</script>

<style scoped>
@keyframes slide-up {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
.animate-slide-up { animation: slide-up 0.2s ease-out; }
</style>
