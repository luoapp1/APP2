<template>
  <div v-if="modelValue" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="emit('update:modelValue', false)">
    <div style="background: #fff; border-radius: 16px; width: 340px; padding: 24px 20px 16px;">
      <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 8px;">购买应用</div>
      <div style="font-size: 14px; color: #374151; margin-bottom: 6px;">{{ app?.name }}</div>
      <div style="font-size: 13px; color: #6b7280; margin-bottom: 12px;">
        原价 <span style="font-weight: 600; color: #1f2937;">{{ app?.priceAmount }}{{ app?.priceType === 'balance' ? '元' : '积分' }}</span>
        <template v-if="hasMembershipDiscount">
          &nbsp; 折扣后 <span style="font-weight: 600; color: #ef4444;">{{ calculatedPrice }}{{ app?.priceType === 'balance' ? '元' : '积分' }}</span>
          <span style="font-size: 11px; color: #9ca3af;">&nbsp;({{ membershipDiscountLabel }})</span>
        </template>
      </div>
      <div style="margin-bottom: 12px;">
        <div style="font-size: 12px; color: #6b7280; margin-bottom: 6px;">选择优惠券</div>
        <el-select
          v-model="selectedCouponId"
          placeholder="不使用优惠券"
          clearable
          style="width:100%"
          popper-class="coupon-select-popper"
          @change="onPayCouponSelect"
        >
          <el-option :value="0" label="不使用优惠券" />
          <el-option
            v-for="c in usableCoupons"
            :key="c.userCouponId"
            :value="c.userCouponId"
            :label="couponLabel(c)"
          >
            <div class="coupon-dd-item">
              <span class="coupon-dd-left">{{ couponLabel(c) }}</span>
              <span class="coupon-dd-right">{{ c.expireTime ? '到期 '+fmtDate(c.expireTime) : '' }}</span>
            </div>
          </el-option>
        </el-select>
        <div v-if="usableCoupons.length === 0" style="font-size:11px;color:#ccc;margin-top:4px;">暂无可用的优惠券</div>
      </div>
      <template v-if="selectedCouponInfo">
        <div style="font-size: 12px; color: #00BFA5; margin-bottom: 8px;">
          优惠券抵扣: {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscountVal }}{{ isPointsCoupon ? '积分' : '' }}
          &nbsp; 实付: <span style="font-weight:700">{{ finalPayPrice }}{{ app?.priceType === 'balance' ? '元' : '积分' }}</span>
        </div>
      </template>
      <div style="font-size: 13px; color: #6b7280; margin-bottom: 16px;">购买后永久有效，可随时下载</div>
      <div v-if="buyMsg" style="font-size: 12px; color: #ef4444; margin-bottom: 8px; text-align: center;">{{ buyMsg }}</div>
      <div style="display: flex; gap: 10px;">
        <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer;" @click="emit('update:modelValue', false)">取消</button>
        <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="doBuy">确认购买</button>
      </div>
    </div>
  </div>
  <div v-if="toastText" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.75); color: #fff; padding: 10px 24px; border-radius: 8px; font-size: 14px; z-index: 200;">{{ toastText }}</div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { fetchPurchaseApp } from '@/api/appstore'
import { fetchUsableCoupons } from '@/api/coupon'
import { useUserStore } from '@/store/modules/user'

const props = defineProps<{
  appId: number
  modelValue: boolean
  app: { name: string; priceAmount: number; priceType: string; id?: number } | null
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
  (e: 'purchased'): void
}>()

const userStore = useUserStore()

function isFixedType(t: string) { return t?.endsWith('_fixed') || t === 'fixed' }
function isPercentType(t: string) { return t?.endsWith('_percent') || t === 'percent' }
function isPointsType(t: string) { return t?.startsWith('points_') || t === 'fixed_points' }
function isBalanceType(t: string) { return t?.startsWith('balance_') || t === 'fixed' || t === 'percent' }

const buyMsg = ref('')
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref<number>(0)

const selectedCouponInfo = computed(() => usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value) || null)

const isPointsCoupon = computed(() => {
  const c = selectedCouponInfo.value
  return c && isPointsType(c.type)
})

const hasMembershipDiscount = computed(() => {
  if (!props.app || !userStore.info) return false
  const pt = props.app.priceType || 'free'
  const ml = Number(userStore.info.levelId || 0)
  if (ml <= 0) return false
  if (pt === 'balance') return Number(userStore.info.discountRate || 1) < 1
  if (pt === 'points') return Number(userStore.info.pointsDiscountRate || 1) < 1
  return false
})

const membershipDiscountLabel = computed(() => {
  const pt = props.app?.priceType || 'free'
  if (pt === 'balance') return `会员${Math.round((userStore.info.discountRate || 1) * 100)}折`
  if (pt === 'points') return `积分${Math.round((userStore.info.pointsDiscountRate || 1) * 100)}折`
  return ''
})

const calculatedPrice = computed(() => {
  if (!props.app || !hasMembershipDiscount.value) return props.app?.priceAmount || 0
  const rate = Number(userStore.info.discountRate || userStore.info.pointsDiscountRate || 1)
  const amt = Number(props.app?.priceAmount || 0)
  return Math.round(amt * rate * 100) / 100
})

const couponDiscountVal = computed(() => {
  const c = selectedCouponInfo.value
  if (!c) return 0
  const base = calculatedPrice.value
  if (isFixedType(c.type)) return Math.min(c.value, base)
  if (isPercentType(c.type)) {
    let disc = Math.floor(base * c.value / 100 * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPayPrice = computed(() => Math.max(0, calculatedPrice.value - couponDiscountVal.value))

const toastText = ref('')
const showToast = (text: string) => {
  toastText.value = text
  setTimeout(() => { toastText.value = '' }, 2000)
}

async function loadUsableCoupons(price: number, priceType: string) {
  if (!userStore.info?.userId) return
  try {
    const res: any = await fetchUsableCoupons({ scene: 'content_buy', orderAmount: price, payType: priceType })
    usableCoupons.value = res?.data || res || []
  } catch { usableCoupons.value = [] }
}

function onPayCouponSelect(val: number) {
  selectedCouponId.value = val || 0
}

function couponLabel(c: any) {
  const isPoints = isPointsType(c.type)
  const isFixed = isFixedType(c.type)
  const prefix = isFixed ? `${isPoints ? '' : '¥'}${c.value}${isPoints ? '积分' : ''}` : `${c.value}折`
  const suffix = c.isMultiUse && c.remainingValue !== null ? `(剩${isPoints ? '' : '¥'}${c.remainingValue}${isPoints ? '积分' : ''})` : ''
  return `${prefix} ${c.name}${suffix}`
}

function fmtDate(ts: string) {
  if (!ts) return ''
  return ts.slice(0, 10)
}

watch(() => props.modelValue, async (val) => {
  if (val && props.app) {
    buyMsg.value = ''
    selectedCouponId.value = 0
    if (!userStore.info?.userId) {
      buyMsg.value = '请先登录'
      return
    }
    const pt = props.app.priceType || 'free'
    const amt = Number(props.app.priceAmount || 0)
    const rate = hasMembershipDiscount.value
      ? Number(userStore.info.discountRate || userStore.info.pointsDiscountRate || 1)
      : 1
    const memberPrice = Math.round(amt * rate * 100) / 100
    await loadUsableCoupons(memberPrice, pt)
  }
})

const doBuy = async () => {
  if (!props.app) return
  buyMsg.value = ''
  try {
    const pt = props.app.priceType || 'free'
    const res: any = await fetchPurchaseApp(Number(props.appId), userStore.info.userId, pt, selectedCouponId.value || 0)
    showToast(res?.alreadyPurchased ? '您已购买过，可直接下载' : '购买成功')
    if (res?.newBalance !== undefined) userStore.info.balance = res.newBalance
    if (res?.newPoints !== undefined) userStore.info.points = res.newPoints
    selectedCouponId.value = 0
    emit('update:modelValue', false)
    emit('purchased')
  } catch (e: any) {
    buyMsg.value = e?.msg || '购买失败'
  }
}
</script>

<style>
.coupon-select-popper .el-select-dropdown__item {
  height: auto;
  padding: 0;
}
.coupon-dd-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  width: 100%;
}
.coupon-dd-left { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; min-width: 0; }
.coupon-dd-right { font-size: 11px; color: #999; margin-left: 8px; white-space: nowrap; }
</style>
