<template>
  <div class="coupon-page">
    <!-- 顶部导航栏 -->
    <div class="top-header">
      <div class="header-back" @click="$router.back()">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M15 19l-7-7 7-7"/></svg>
      </div>
      <div class="header-title">优惠券中心</div>
      <div class="header-right" />
    </div>

    <!-- 统计横幅 -->
    <div class="stats-row">
      <div class="stat-box">
        <div class="stat-icon s1">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" stroke-width="1.8"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" stroke-width="1.8"/></svg>
        </div>
        <span class="stat-num">{{ availableCoupons.length }}</span>
        <span class="stat-label">可领取</span>
      </div>
      <div class="stat-div" />
      <div class="stat-box">
        <div class="stat-icon s2">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 13l4 4L19 7"/></svg>
        </div>
        <span class="stat-num">{{ myCount }}</span>
        <span class="stat-label">已领取</span>
      </div>
      <div class="stat-div" />
      <div class="stat-box">
        <div class="stat-icon s3">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <span class="stat-num">{{ historyCount }}</span>
        <span class="stat-label">已使用</span>
      </div>
    </div>

    <!-- 吸附导航区 -->
    <div class="sticky-nav">
      <div class="main-tabs">
        <button :class="{ active: tab === 'all' }" @click="switchTab('all')">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><rect x="2" y="7" width="20" height="14" rx="2" stroke-width="1.8"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" stroke-width="1.8"/></svg>
          全部优惠券
        </button>
        <button :class="{ active: tab === 'my' }" @click="switchTab('my')">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
          我的优惠券{{ myCount ? ` (${myCount})` : '' }}
        </button>
        <button :class="{ active: tab === 'history' }" @click="switchTab('history')">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="9" stroke-width="1.8"/><polyline stroke-width="1.8" points="12,7 12,12 15,15"/></svg>
          使用记录
        </button>
      </div>

      <!-- 分类标签 (仅全部优惠券tab) -->
      <div v-if="tab === 'all'" class="tag-scroll">
        <div class="tag-list">
          <span
            v-for="tg in tagList"
            :key="tg.key"
            class="tag-pill"
            :class="{ active: curCategory === tg.key }"
            @click="curCategory = tg.key"
          >{{ tg.label }}</span>
        </div>
      </div>

      <!-- 子Tab (仅我的优惠券tab) -->
      <div v-if="tab === 'my'" class="my-bar">
        <span :class="{ active: myTab === 'unused' }" @click="myTab = 'unused'">未使用 ({{ myCoupons.filter((c:any) => c.status === 'unused').length }})</span>
        <span :class="{ active: myTab === 'used' }" @click="myTab = 'used'">已使用</span>
        <span :class="{ active: myTab === 'expired' }" @click="myTab = 'expired'">已过期</span>
      </div>
    </div>

    <!-- ====== 全部优惠券 ====== -->
    <template v-if="tab === 'all'">
      <!-- 新人专享 -->
      <div v-if="newUserCoupons.length" class="scene-card new-user-scene">
        <div class="scene-top">
          <div class="scene-title">
            <span class="scene-emoji">&#127873;</span>
            <span>新人专享礼包</span>
          </div>
          <span class="scene-badge new">限新用户</span>
        </div>
        <p class="scene-desc">注册即可领取，助你开启精彩之旅</p>
        <div class="scene-cards">
          <div v-for="c in newUserCoupons" :key="c.id" class="ticket-card tc-new" :class="{ off: !c.canClaim }" @click="handleClaim(c)">
            <div class="tc-notch ntop" /><div class="tc-notch nbot" />
            <div class="tc-left">
              <div class="tc-price">
                <template v-if="c.type === 'fixed'">
                  <b class="tc-sym">&#165;</b><b class="tc-val">{{ c.value }}</b>
                </template>
                <template v-else-if="c.type?.startsWith('points_')">
                  <b class="tc-val">{{ c.value }}</b><b class="tc-sym">积分</b>
                </template>
                <template v-else-if="c.type === 'percent'">
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">折</b>
                </template>
                <template v-else>
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">积分折</b>
                </template>
              </div>
              <div class="tc-limit">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}</div>
            </div>
            <div class="tc-mid">
              <div class="tc-name">{{ c.name }}</div>
              <span class="tc-tag">{{ c.categoryLabel || '新人券' }}</span>
              <span v-if="c.levelRequired" class="tc-tag level-tag">{{ c.levelRequired.names.join('/') }}专属</span>
              <div class="tc-date">领后{{ c.validDays || 30 }}天有效</div>
            </div>
              <div class="tc-btn">
                <span v-if="c.canClaim" class="btn-grab">立即领取</span>
                <span v-else-if="c.claimStatus === 'level_required'" class="btn-grab disabled">{{ c.levelRequired?.names?.join('/') || '会员' }}专属</span>
                <span v-else-if="c.claimStatus === 'claimed'" class="btn-grab got">已领取</span>
                <span v-else class="btn-grab got">已领取</span>
              </div>
          </div>
        </div>
      </div>

      <!-- 推荐好券 -->
      <div v-if="recommendCoupons.length" class="scene-card rec-scene">
        <div class="scene-top">
          <div class="scene-title">
            <span class="scene-emoji">&#11088;</span>
            <span>推荐好券</span>
          </div>
          <span class="scene-badge rec">精选推荐</span>
        </div>
        <div class="scene-cards">
          <div v-for="c in recommendCoupons" :key="c.id" class="ticket-card tc-rec" :class="{ off: !c.canClaim }" @click="handleClaim(c)">
            <div class="tc-notch ntop" /><div class="tc-notch nbot" />
            <div class="tc-left">
              <div class="tc-price">
                <template v-if="c.type === 'fixed'">
                  <b class="tc-sym">&#165;</b><b class="tc-val">{{ c.value }}</b>
                </template>
                <template v-else-if="c.type?.startsWith('points_')">
                  <b class="tc-val">{{ c.value }}</b><b class="tc-sym">积分</b>
                </template>
                <template v-else-if="c.type === 'percent'">
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">折</b>
                </template>
                <template v-else>
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">积分折</b>
                </template>
              </div>
              <div class="tc-limit">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}</div>
            </div>
            <div class="tc-mid">
              <div class="tc-name">{{ c.name }}</div>
              <span class="tc-tag">{{ c.categoryLabel || '推荐券' }}</span>
              <div class="tc-date">领后{{ c.validDays || 30 }}天有效</div>
            </div>
              <div class="tc-btn">
                <span v-if="c.canClaim" class="btn-grab">立即领取</span>
                <span v-else-if="c.claimStatus === 'level_required'" class="btn-grab disabled">{{ c.levelRequired?.names?.join('/') || '会员' }}专属</span>
                <span v-else-if="c.claimStatus === 'claimed'" class="btn-grab got">已领取</span>
                <span v-else class="btn-grab got">已领取</span>
              </div>
          </div>
        </div>
      </div>

      <!-- 会员专属 -->
      <div v-if="memberCoupons.length" class="scene-card member-scene">
        <div class="scene-top">
          <div class="scene-title">
            <span class="scene-emoji">&#128142;</span>
            <span>会员专属</span>
          </div>
          <span class="scene-badge vip">VIP</span>
        </div>
        <div class="scene-cards">
          <div v-for="c in memberCoupons" :key="c.id" class="ticket-card tc-vip" :class="{ off: !c.canClaim }" @click="handleClaim(c)">
            <div class="tc-notch ntop" /><div class="tc-notch nbot" />
            <div class="tc-left">
              <div class="tc-price">
                <template v-if="c.type === 'fixed'">
                  <b class="tc-sym">&#165;</b><b class="tc-val">{{ c.value }}</b>
                </template>
                <template v-else-if="c.type?.startsWith('points_')">
                  <b class="tc-val">{{ c.value }}</b><b class="tc-sym">积分</b>
                </template>
                <template v-else-if="c.type === 'percent'">
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">折</b>
                </template>
                <template v-else>
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">积分折</b>
                </template>
              </div>
              <div class="tc-limit">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}</div>
            </div>
            <div class="tc-mid">
              <div class="tc-name">{{ c.name }}</div>
              <span class="tc-tag">{{ c.categoryLabel || '通用券' }}</span>
              <span v-if="c.levelRequired" class="tc-tag level-tag">{{ c.levelRequired.names.join('/') }}专属</span>
              <div class="tc-date">领后{{ c.validDays || 30 }}天有效</div>
            </div>
              <div class="tc-btn">
                <span v-if="c.canClaim" class="btn-grab">立即领取</span>
                <span v-else-if="c.claimStatus === 'level_required'" class="btn-grab disabled">{{ c.levelRequired?.names?.join('/') || '会员' }}专属</span>
                <span v-else-if="c.claimStatus === 'claimed'" class="btn-grab got">已领取</span>
                <span v-else class="btn-grab got">已领取</span>
              </div>
          </div>
        </div>
      </div>

      <!-- 限时抢券 -->
      <div v-if="rushCoupons.length" class="scene-card rush-scene">
        <div class="scene-top">
          <div class="scene-title">
            <span class="scene-emoji">&#9201;</span>
            <span>限时抢券</span>
          </div>
          <span class="scene-badge end">已结束</span>
        </div>
        <div class="scene-cards">
          <div v-for="c in rushCoupons" :key="c.id" class="ticket-card tc-rush off">
            <div class="tc-notch ntop" /><div class="tc-notch nbot" />
            <div class="tc-left">
              <div class="tc-price"><b class="tc-sym">&#165;</b><b class="tc-val">{{ c.value }}</b></div>
              <div class="tc-limit">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}</div>
            </div>
            <div class="tc-mid">
              <div class="tc-name">{{ c.name }}</div>
              <span class="tc-tag">{{ c.categoryLabel || '限时抢券' }}</span>
              <div class="tc-date">每人限领{{ c.perUserLimit }}张</div>
            </div>
            <div class="tc-btn"><span class="btn-grab got">已结束</span></div>
          </div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="scene-card">
        <div class="scene-top">
          <div class="scene-title">{{ catLabel }}</div>
        </div>
        <div v-if="allCoupons.length === 0" class="empty">
          <svg fill="none" stroke="#ccc" viewBox="0 0 24 24" width="52" height="52" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" x2="21" y1="9" y2="9"/><line x1="9" x2="9" y1="21" y2="9"/></svg>
          <p>暂无优惠券</p>
        </div>
        <div v-else class="scene-cards">
          <div v-for="c in allCoupons" :key="c.id" class="ticket-card tc-base" :class="{ off: !c.canClaim }" @click="handleClaim(c)">
            <div class="tc-notch ntop" /><div class="tc-notch nbot" />
            <div class="tc-left">
              <div class="tc-price">
                <template v-if="c.type === 'fixed'">
                  <b class="tc-sym">&#165;</b><b class="tc-val">{{ c.value }}</b>
                </template>
                <template v-else-if="c.type?.startsWith('points_')">
                  <b class="tc-val">{{ c.value }}</b><b class="tc-sym">积分</b>
                </template>
                <template v-else-if="c.type === 'percent'">
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">折</b>
                </template>
                <template v-else>
                  <b class="tc-val">{{ c.value / 10 }}</b><b class="tc-sym">积分折</b>
                </template>
              </div>
              <div class="tc-limit">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}</div>
            </div>
            <div class="tc-mid">
              <div class="tc-name">{{ c.name }}</div>
              <span class="tc-tag">{{ c.scopeLabel === '通用' ? '通用券' : c.scopeLabel === '会员' ? '会员券' : '商品券' }}</span>
              <div class="tc-date">领后{{ c.validDays || 30 }}天有效</div>
            </div>
              <div class="tc-btn">
                <span v-if="c.canClaim" class="btn-grab">立即领取</span>
                <span v-else-if="c.claimStatus === 'level_required'" class="btn-grab disabled">{{ c.levelRequired?.names?.join('/') || '会员' }}专属</span>
                <span v-else-if="c.claimStatus === 'claimed'" class="btn-grab got">已领取</span>
                <span v-else class="btn-grab got">已领取</span>
              </div>
          </div>
        </div>
      </div>
    </template>

    <!-- ====== 我的优惠券 ====== -->
    <template v-if="tab === 'my'">
      <div v-if="myCoupons.length === 0" class="empty">
        <svg fill="none" stroke="#ccc" viewBox="0 0 24 24" width="52" height="52" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" x2="21" y1="9" y2="9"/><line x1="9" x2="9" y1="21" y2="9"/></svg>
        <p>{{ myTab === 'unused' ? '暂无可用优惠券' : myTab === 'used' ? '暂无使用记录' : '暂无过期优惠券' }}</p>
      </div>
      <div v-else class="my-list">
        <div v-for="c in myCoupons" :key="c.id" class="my-item" :class="{ used: c.status === 'used', expired: c.status === 'expired' }">
           <div class="mi-left">
            <div class="mi-val">
              <template v-if="c.type === 'fixed'"><b class="mi-sym">&#165;</b><b class="mi-num">{{ c.value }}</b></template>
              <template v-else-if="c.type?.startsWith('points_')"><b class="mi-num">{{ c.value }}</b></template>
              <template v-else-if="c.type === 'percent'"><b class="mi-num">{{ c.value / 10 }}</b></template>
              <template v-else><b class="mi-num">{{ c.value / 10 }}</b></template>
            </div>
            <div class="mi-cond">{{ c.minOrder > 0 ? `满${c.minOrder}元` : '无门槛' }}<span class="mi-unit">{{ unitLabel(c.type) }}</span></div>
          </div>
          <div class="mi-mid">
            <div class="mi-name">{{ c.name }}</div>
            <div class="mi-date">
              <template v-if="c.status === 'unused'">
                有效期至 {{ fmt(c.expireTime) }}
                <span v-if="c.isMultiUse && c.remainingValue !== null" class="mi-remain">剩¥{{ c.remainingValue }}</span>
              </template>
              <template v-else>
                使用: {{ fmt(c.useTime) }}
                <span v-if="c.useAmount" class="mi-amount">减¥{{ c.useAmount }}</span>
              </template>
            </div>
          </div>
          <div class="mi-act" v-if="c.status === 'unused'" @click="goAppstore">
            <span>去使用</span>
          </div>
          <div class="mi-act" v-else-if="c.status === 'used'">
            <span class="mi-done">已使用</span>
          </div>
          <div class="mi-act" v-else>
            <span class="mi-done off">已过期</span>
          </div>
        </div>
      </div>
    </template>

    <!-- ====== 使用记录 ====== -->
    <template v-if="tab === 'history'">
      <div v-if="historyList.length === 0" class="empty">
        <svg fill="none" stroke="#ccc" viewBox="0 0 24 24" width="52" height="52" stroke-width="1"><circle cx="12" cy="12" r="9"/><polyline points="12,7 12,12 15,15"/></svg>
        <p>暂无使用记录</p>
      </div>
      <div v-else class="his-list">
        <div v-for="h in historyList" :key="h.id" class="his-row">
          <div class="hr-info">
            <div class="hr-name">{{ h.name }}</div>
            <div class="hr-time">{{ fmt(h.useTime) }}</div>
          </div>
          <div class="hr-amt">-&#165;{{ h.useAmount || h.value }}</div>
        </div>
      </div>
    </template>

    <!-- 底部安全区占位 -->
    <div class="bottom-safe" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchAvailableCoupons, fetchClaimCoupon, fetchMyCoupons, fetchCouponHistory, fetchCouponOptions } from '@/api/coupon'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)

const tab = ref('all')
const curCategory = ref('')
const myTab = ref('unused')
const availableCoupons = ref<any[]>([])
const myCoupons = ref<any[]>([])
const historyList = ref<any[]>([])
const myCount = ref(0)
const historyCount = ref(0)
const typeLabelsAll = ref<Record<string, string>>({})

const tagList = [
  { key: '', label: '全部' },
  { key: 'general', label: '通用券' },
  { key: 'member', label: '会员券' },
  { key: 'product', label: '商品券' },
  { key: 'event', label: '限时活动' },
]

const catLabel = computed(() => {
  const m: any = { '': '', general: '平台通用券', member: '会员专享券', product: '商品优惠券', event: '限时活动', rush: '限时抢券' }
  return m[curCategory.value] || '全部优惠券'
})

const newUserCoupons = computed(() => (curCategory.value ? [] : availableCoupons.value.filter((c: any) => c.isNewUser && !c.isRush && !c.isRecommend && !c.levelRequired)))
const recommendCoupons = computed(() => (curCategory.value ? [] : availableCoupons.value.filter((c: any) => c.isRecommend && !c.isNewUser && !c.isRush && !c.levelRequired)))
const memberCoupons = computed(() => (curCategory.value ? [] : availableCoupons.value.filter((c: any) => c.levelRequired)))
const rushCoupons = computed(() => (curCategory.value ? [] : availableCoupons.value.filter((c: any) => c.isRush)))
const allCoupons = computed(() => {
  let list = availableCoupons.value.filter((c: any) => !c.isNewUser && !c.isRecommend && !c.isRush && !c.levelRequired)
  if (curCategory.value) {
    if (curCategory.value === 'event') list = list.filter((c: any) => c.category === 'event' || c.category === 'rush')
    else list = list.filter((c: any) => c.category === curCategory.value)
  }
  return list
})

function fmt(d: string) { if (!d) return '--'; try { return new Date(d).toLocaleDateString('zh-CN') } catch { return d } }
function unitLabel(t: string): string {
  if (t === 'fixed') return ''
  if (t?.endsWith('_percent') || t === 'percent') return '折'
  if (t === 'fixed_points' || t?.startsWith('points_')) return '积分'
  return typeLabelsAll.value[t] || ''
}
function goMembership() { router.push('/appstore/browse/membership') }
function goAppstore() { router.push('/appstore/browse') }

async function handleClaim(c: any) {
  if (!isLogin.value) { ElMessage.warning('请先登录'); return }
  if (!c.canClaim) {
    if (c.claimStatus === 'level_required') {
      ElMessage.warning(`仅限${c.levelRequired?.names?.join('/') || '指定会员'}领取`)
    } else if (c.claimStatus === 'sold_out') {
      ElMessage.warning('该优惠券已领完')
    } else {
      ElMessage.warning('已领取过该优惠券')
    }
    return
  }
  try {
    await fetchClaimCoupon(c.id)
    c.claimedByUser = (c.claimedByUser || 0) + 1
    c.canClaim = c.perUserLimit === 0 || c.claimedByUser < c.perUserLimit
    ElMessage.success('领取成功')
    loadCounts()
  } catch (e: any) {
    ElMessage.error(e?.message || e?.msg || '领取失败')
  }
}

function switchTab(t: string) { tab.value = t; if (t === 'my') { loadMyCoupons(); loadCounts(); } if (t === 'history') loadHistory() }

async function loadAvailable() { try { const res: any = await fetchAvailableCoupons(); availableCoupons.value = res || [] } catch {} }
async function loadMyCoupons() { try { const res: any = await fetchMyCoupons({ status: myTab.value }); myCoupons.value = res || []; if (myTab.value === 'unused') myCount.value = (res || []).length } catch {} }
async function loadHistory() { try { const res: any = await fetchCouponHistory(); historyList.value = res || [] } catch {} }
async function loadCounts() {
  try { const u: any = await fetchMyCoupons({ status: 'unused' }); myCount.value = (u || []).length; const h: any = await fetchCouponHistory(); historyCount.value = (h || []).length } catch {}
}

watch(myTab, () => { if (tab.value === 'my') loadMyCoupons() })
onMounted(() => { loadAvailable(); loadCounts(); loadOptions() })
async function loadOptions() { try { const res: any = await fetchCouponOptions(); typeLabelsAll.value = res?.typeLabelsAll || {} } catch {} }
</script>

<style scoped>
.coupon-page {
  max-width: 480px;
  margin: 0 auto;
  min-height: 100vh;
  background: var(--default-bg-color);
}

/* 顶部导航 */
.top-header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: var(--default-bg-color);
  position: sticky;
  top: 0;
  z-index: 40;
  border-bottom: 1px solid #f0f0f5;
}
.header-back {
  width: 36px; height: 36px;
  display: flex; align-items: center; justify-content: center;
  border-radius: 10px;
  cursor: pointer;
  color: #333;
  transition: background .15s;
}
.header-back:hover { background: #f5f5f5; }
.header-back svg { width: 22px; height: 22px; }
.header-title {
  flex: 1;
  text-align: center;
  font-size: 17px;
  font-weight: 700;
  color: #1a1a2e;
  margin-right: 36px;
}
.header-right { width: 36px; }

/* 统计行 */
.stats-row {
  display: flex;
  align-items: center;
  margin: 14px 14px 0;
  padding: 14px 20px;
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.stat-box {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
}
.stat-icon {
  width: 34px; height: 34px;
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
}
.stat-icon svg { width: 18px; height: 18px; }
.s1 { background: #e0f2fe; color: #0284c7; }
.s2 { background: #dcfce7; color: #16a34a; }
.s3 { background: #fef3c7; color: #ca8a04; }
.stat-num { font-size: 22px; font-weight: 800; color: #1a1a2e; }
.stat-label { font-size: 11px; color: #94a3b8; }
.stat-div { width: 1px; height: 36px; background: #f0f0f5; }

/* 吸附导航区 */
.sticky-nav {
  position: sticky;
  top: 60px;
  z-index: 39;
  background: #f7f8fc;
  padding: 10px 14px 8px;
  margin: 0;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  will-change: transform;
}

/* 主 Tab */
.main-tabs {
  display: flex;
  margin: 0;
  padding: 4px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.main-tabs button {
  flex: 1;
  display: flex; align-items: center; justify-content: center; gap: 5px;
  padding: 10px 8px;
  border: none; border-radius: 9px;
  background: transparent;
  color: #94a3b8;
  font-size: 13px; font-weight: 600;
  cursor: pointer;
  transition: all .2s;
}
.main-tabs button.active {
  background: #00BFA5;
  color: #fff;
  box-shadow: 0 2px 8px rgba(0,191,165,.35);
}

/* 分类标签 */
.tag-scroll {
  margin: 8px 0 0;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.tag-scroll::-webkit-scrollbar { display: none; }
.tag-list {
  display: flex; gap: 7px;
  white-space: nowrap;
}
.tag-pill {
  display: inline-block;
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 13px; font-weight: 500;
  background: #fff;
  color: #64748b;
  cursor: pointer;
  border: 1.5px solid transparent;
  transition: all .18s;
  flex-shrink: 0;
}
.tag-pill.active {
  background: #e6faf7;
  color: #00BFA5;
  border-color: #00BFA5;
  font-weight: 700;
}

/* 场景卡片 */
.scene-card {
  margin: 0 14px 14px;
  background: #fff;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.scene-top {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 8px;
}
.scene-title {
  display: flex; align-items: center; gap: 6px;
  font-size: 16px; font-weight: 700; color: #1a1a2e;
}
.scene-emoji { font-size: 18px; }
.scene-badge {
  font-size: 11px; padding: 2px 9px; border-radius: 12px;
  font-weight: 600;
}
.scene-badge.new { background: #fef3c7; color: #b45309; }
.scene-badge.rec { background: #ede9fe; color: #6d28d9; }
.scene-badge.end { background: #f1f5f9; color: #94a3b8; }
.scene-badge.vip { background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #fff; }
.scene-desc { font-size: 13px; color: #94a3b8; margin: 0 0 12px; }

.scene-cards {
  display: flex; flex-direction: column; gap: 10px;
}

/* 优惠券票卡 */
.ticket-card {
  display: flex; align-items: stretch;
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  min-height: 94px;
  cursor: pointer;
  transition: all .2s;
}
.ticket-card:active { transform: scale(.985); }
.ticket-card.off { opacity: .5; }
.ticket-card.off:active { transform: none; }

.tc-new {
  background: linear-gradient(135deg, #fffbeb, #fff7ed 60%, #fff);
  border: 1.5px solid #fcd34d;
}
.tc-rec {
  background: linear-gradient(135deg, #faf5ff, #f5f3ff 60%, #fff);
  border: 1.5px solid #ddd6fe;
}
.tc-rush {
  background: linear-gradient(135deg, #fff1f2, #ffe4e6 60%, #fff);
  border: 1.5px solid #fecdd3;
}
.tc-base {
  background: #fafbfe;
  border: 1.5px solid #e8ecf2;
}
.tc-vip {
  background: linear-gradient(135deg, #fffbeb, #fef3c7 60%, #fff);
  border: 1.5px solid #fbbf24;
}

.tc-notch {
  position: absolute;
  left: 86px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #f7f8fc;
  z-index: 2;
}
.tc-notch.ntop { top: -8px; }
.tc-notch.nbot { bottom: -8px; }

.tc-left {
  width: 95px;
  flex-shrink: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  padding: 8px 0;
  border-right: 1.5px dashed #e2e8f0;
  position: relative;
  z-index: 1;
}
.tc-price { display: flex; align-items: baseline; }
.tc-sym { font-size: 13px; }
.tc-val { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
.tc-new .tc-price { color: #d97706; }
.tc-rec .tc-price { color: #7c3aed; }
.tc-rush .tc-price { color: #9ca3af; }
.tc-base .tc-price { color: #00BFA5; }
.tc-vip .tc-price { color: #d97706; }
.tc-limit { font-size: 11px; color: #94a3b8; margin-top: 2px; font-weight: 500; }

.tc-mid {
  flex: 1; display: flex; flex-direction: column; justify-content: center;
  padding: 8px 12px; min-width: 0; gap: 5px; position: relative; z-index: 1;
}
.tc-name {
  font-size: 14px; font-weight: 700; color: #1a1a2e;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.tc-tag {
  display: inline-block;
  font-size: 10px; padding: 2px 7px; border-radius: 4px;
  font-weight: 600;
  align-self: flex-start;
}
.tc-new .tc-tag { background: #fef3c7; color: #92400e; }
.tc-rec .tc-tag { background: #ede9fe; color: #6d28d9; }
.tc-rush .tc-tag { background: #fce7f3; color: #9d174d; }
.tc-base .tc-tag { background: #e6faf7; color: #0d9488; }
.tc-vip .tc-tag { background: #fef3c7; color: #92400e; }
.tc-tag.level-tag { background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #fff; }
.tc-date { font-size: 11px; color: #bbb; }

.tc-btn {
  display: flex; align-items: center;
  padding-right: 12px; flex-shrink: 0;
  position: relative; z-index: 1;
}
.btn-grab {
  display: inline-block;
  padding: 7px 16px; border-radius: 18px;
  font-size: 12px; font-weight: 700; white-space: nowrap;
  transition: all .2s;
}
.tc-new .btn-grab { background: linear-gradient(135deg, #f59e0b, #d97706); color: #fff; }
.tc-rec .btn-grab { background: linear-gradient(135deg, #a78bfa, #7c3aed); color: #fff; }
.tc-base .btn-grab { background: linear-gradient(135deg, #00BFA5, #009688); color: #fff; }
.tc-vip .btn-grab { background: linear-gradient(135deg, #f59e0b, #d97706); color: #fffbeb; }
.tc-vip .btn-grab.disabled { background: #fef3c7; color: #92400e; }
.btn-grab.disabled { background: #f1f5f9; color: #94a3b8; cursor: not-allowed; }
.btn-grab.got { background: #e5e7eb !important; color: #9ca3af !important; }

/* 空状态 */
.empty {
  display: flex; flex-direction: column; align-items: center; gap: 10px;
  padding: 60px 0; color: #bbb; font-size: 14px;
}

/* 我的 - 子 Tab */
.my-bar {
  display: flex;
  margin: 8px 0 0;
  background: #fff;
  border-radius: 11px;
  padding: 3px;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.my-bar span {
  flex: 1;
  text-align: center;
  padding: 9px 6px;
  border-radius: 9px;
  font-size: 13px; font-weight: 600;
  color: #94a3b8;
  cursor: pointer;
  transition: all .2s;
}
.my-bar span.active {
  background: #00BFA5;
  color: #fff;
  box-shadow: 0 2px 6px rgba(0,191,165,.3);
}

/* 我的列表 */
.my-list {
  margin: 0 14px;
  display: flex; flex-direction: column; gap: 10px;
}
.my-item {
  display: flex; align-items: stretch;
  background: #fff;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
  transition: opacity .2s;
}
.my-item.used { opacity: .7; }
.my-item.expired { opacity: .4; }

.mi-left {
  width: 85px; flex-shrink: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: 3px;
  background: linear-gradient(135deg, #f0fdf4, #ecfeff);
}
.mi-val { display: flex; align-items: baseline; color: #00BFA5; }
.mi-sym { font-size: 12px; }
.mi-num { font-size: 18px; font-weight: 800; letter-spacing: -0.5px; }
.mi-cond { font-size: 11px; color: #94a3b8; font-weight: 500; }

.mi-mid {
  flex: 1; display: flex; flex-direction: column; justify-content: center;
  padding: 12px; min-width: 0;
}
.mi-name { font-size: 15px; font-weight: 700; color: #1a1a2e; }
.mi-date { font-size: 12px; color: #94a3b8; margin-top: 3px; }
.mi-remain { color: #f59e0b; font-weight: 600; margin-left: 6px; }
.mi-amount { color: #ef4444; margin-left: 6px; }

.mi-act {
  display: flex; align-items: center;
  padding-right: 14px; flex-shrink: 0;
}
.mi-act > span {
  padding: 6px 14px; border-radius: 16px;
  font-size: 13px; font-weight: 700;
  background: #00BFA5; color: #fff;
  cursor: pointer;
}
.mi-done { background: #e0f2fe !important; color: #0284c7 !important; cursor: default !important; }
.mi-done.off { background: #f1f5f9 !important; color: #94a3b8 !important; }

/* 使用记录 */
.his-list {
  margin: 0 14px;
  display: flex; flex-direction: column;
  background: #fff;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.his-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;
}
.his-row:last-child { border-bottom: none; }
.hr-name { font-size: 15px; font-weight: 700; color: #1a1a2e; }
.hr-time { font-size: 12px; color: #94a3b8; margin-top: 2px; }
.hr-amt { font-size: 16px; font-weight: 800; color: #16a34a; }

/* 底部安全区 */
.bottom-safe { height: 70px; }
</style>
