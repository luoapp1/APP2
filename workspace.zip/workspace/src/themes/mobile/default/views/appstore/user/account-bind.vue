<template>
  <div class="bind-page">
    <div class="bind-navbar">
      <button class="bind-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="bind-title">账号绑定</span>
      <div class="bind-placeholder" />
    </div>

    <div class="bind-content">
      <div class="bind-card">
        <div v-for="provider in providers" :key="provider.key" class="bind-item">
          <div class="bind-left">
            <div class="provider-icon" :style="{ background: provider.bg }">
              <svg v-if="provider.key === 'github'" width="26" height="26" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12z"/></svg>
              <svg v-else-if="provider.key === 'google'" width="24" height="24" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              <svg v-else-if="provider.key === 'wechat'" width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 01.213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 00.167-.054l1.903-1.114a.864.864 0 01.717-.098 10.16 10.16 0 002.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178A1.17 1.17 0 014.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178 1.17 1.17 0 01-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 01.598.082l1.584.926a.272.272 0 00.14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 01-.023-.156.49.49 0 01.201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.952-7.062-6.122zm-3.84 3.192c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982z" fill-rule="evenodd"/></svg>
              <svg v-else-if="provider.key === 'qq'" width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M21.395 15.035a40.36 40.36 0 00-.803-2.264l-1.079-2.695c.001-.032.014-.562.012-.8C19.461 4.892 16.564 1 12 1S4.54 4.893 4.475 9.275c-.002.239.011.769.012.8l-1.078 2.695c-.358.878-.654 1.638-.803 2.264-1.05 4.418.209 5.855.918 6.247.924.514 1.538-.564 1.538-.564.13.735.439 1.267.815 1.267.441 0 .803-.702.834-1.592.731.457 1.666.726 2.598.726.911 0 1.828-.257 2.55-.694.035.863.387 1.56.816 1.56.377 0 .686-.535.815-1.267 0 0 .614 1.078 1.538.564.709-.392 1.968-1.829.918-6.247z"/></svg>
              <span v-else class="provider-icon-text">{{ provider.key[0].toUpperCase() }}</span>
            </div>
            <div class="provider-info">
              <div class="provider-name">{{ provider.label }}</div>
              <div class="provider-desc" :class="{ bound: provider.bound }">
                {{ provider.bound ? (provider.username || '已绑定') : '未绑定' }}
              </div>
            </div>
          </div>
          <div class="bind-right">
            <template v-if="provider.bound">
              <span class="bind-time" v-if="provider.bindTime">绑定于 {{ provider.bindTime }}</span>
              <button class="action-btn unbind" @click="startUnbind(provider)" :disabled="unbinding === provider.key">
                {{ unbinding === provider.key ? '解绑中...' : '解绑' }}
              </button>
            </template>
            <template v-else-if="!provider.configured">
              <span class="bind-unavailable">未配置</span>
            </template>
            <button
              v-else
              class="action-btn bind"
              @click="startBind(provider)"
              :disabled="binding === provider.key"
            >
              {{ binding === provider.key ? '绑定中...' : '绑定' }}
            </button>
          </div>
        </div>
      </div>

      <div class="bind-tip">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
        <span>绑定第三方账号后，可使用第三方账号快捷登录</span>
      </div>
    </div>

    <!-- 绑定确认弹窗 -->
    <div v-if="showBindModal" class="modal-overlay" @click.self="closeBindModal">
      <div class="modal-card">
        <div class="modal-icon" :style="{ background: currentProvider.bg }">
          <div v-html="currentProvider.iconSvg"></div>
          <span v-if="!currentProvider.iconSvg" class="modal-icon-text">{{ currentProvider.key[0].toUpperCase() }}</span>
        </div>
        <div class="modal-title">绑定 {{ currentProvider.label }} 账号</div>
        <div class="modal-desc">
          将跳转到 {{ currentProvider.label }} 官方授权页面，授权成功后自动返回并绑定到您的账号。
        </div>
        <div class="modal-actions">
          <button class="modal-btn cancel" @click="closeBindModal">取消</button>
          <button class="modal-btn primary" @click="doBind" :disabled="bindingStep !== 'confirm'">前往授权</button>
        </div>
      </div>
    </div>

    <!-- 解绑确认弹窗 -->
    <div v-if="showUnbindModal" class="modal-overlay" @click.self="closeUnbindModal">
      <div class="modal-card">
        <div class="modal-icon" :style="{ background: currentProvider.bg }">
          <div v-html="currentProvider.iconSvg"></div>
          <span v-if="!currentProvider.iconSvg" class="modal-icon-text">{{ currentProvider.key[0].toUpperCase() }}</span>
        </div>
        <div class="modal-title">解绑 {{ currentProvider.label }} 账号</div>
        <div class="modal-desc">
          解绑后，您将无法使用 {{ currentProvider.label }} 账号登录。确定要解绑吗？
        </div>
        <div class="modal-actions">
          <button class="modal-btn cancel" @click="closeUnbindModal">取消</button>
          <button class="modal-btn danger" @click="doUnbind" :disabled="unbinding === currentProvider.key">
            {{ unbinding === currentProvider.key ? '解绑中...' : '确定解绑' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const binding = ref('')
const unbinding = ref('')
const showBindModal = ref(false)
const showUnbindModal = ref(false)
const currentProvider = ref({})
const bindingStep = ref('confirm')

const providers = ref([
  {
    key: 'github', label: 'GitHub', bg: '#24292F', bound: false, username: '',
    iconSvg: '<svg width="26" height="26" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12z"/></svg>'
  },
  {
    key: 'google', label: 'Google', bg: '#fff', bound: false, username: '',
    iconSvg: '<svg width="24" height="24" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>'
  },
  {
    key: 'wechat', label: '微信', bg: '#07C160', bound: false, username: '',
    iconSvg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 01.213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 00.167-.054l1.903-1.114a.864.864 0 01.717-.098 10.16 10.16 0 002.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178A1.17 1.17 0 014.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178 1.17 1.17 0 01-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 01.598.082l1.584.926a.272.272 0 00.14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 01-.023-.156.49.49 0 01.201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.952-7.062-6.122zm-3.84 3.192c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 01-.969.983.976.976 0 01-.969-.983c0-.542.434-.982.97-.982z" fill-rule="evenodd"/></svg>'
  },
  {
    key: 'qq', label: 'QQ', bg: '#12B7F5', bound: false, username: '',
    iconSvg: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M21.395 15.035a40.36 40.36 0 00-.803-2.264l-1.079-2.695c.001-.032.014-.562.012-.8C19.461 4.892 16.564 1 12 1S4.54 4.893 4.475 9.275c-.002.239.011.769.012.8l-1.078 2.695c-.358.878-.654 1.638-.803 2.264-1.05 4.418.209 5.855.918 6.247.924.514 1.538-.564 1.538-.564.13.735.439 1.267.815 1.267.441 0 .803-.702.834-1.592.731.457 1.666.726 2.598.726.911 0 1.828-.257 2.55-.694.035.863.387 1.56.816 1.56.377 0 .686-.535.815-1.267 0 0 .614 1.078 1.538.564.709-.392 1.968-1.829.918-6.247z"/></svg>'
  }
])

onMounted(async () => {
  try {
    const [accounts, providerList] = await Promise.all([
      request.get({ url: '/api/user/oauth-accounts' }),
      request.get({ url: '/api/auth/oauth/providers' })
    ])

    const arr = Array.isArray(accounts) ? accounts : (accounts?.accounts || [])
    const configuredSet = new Set(Array.isArray(providerList) ? providerList : (providerList?.data || []))

    providers.value = providers.value.map(p => {
      const found = arr.find(a => a.provider === p.key)
      if (found) {
        return { ...p, bound: true, username: found.username || found.provider_user_id, bindTime: found.bindTime || found.create_time, oauthId: found.id, configured: configuredSet.has(p.key) }
      }
      return { ...p, configured: configuredSet.has(p.key) }
    })
  } catch { /* ignore */ }
})

function startBind(provider) {
  currentProvider.value = provider
  bindingStep.value = 'confirm'
  showBindModal.value = true
}

function closeBindModal() {
  showBindModal.value = false
}

async function doBind() {
  bindingStep.value = 'authorizing'
  binding.value = currentProvider.value.key

  try {
    // 真实 OAuth 流程：跳转到提供商授权页面
    const cfgRes = await request.get({ url: '/api/auth/oauth/providers' })
    const list = Array.isArray(cfgRes) ? cfgRes : (cfgRes?.data || [])
    if (!list.includes(currentProvider.value.key)) {
      alert(currentProvider.value.label + ' OAuth 尚未配置，请联系管理员在后台设置 Client ID 和 Secret')
      closeBindModal()
      return
    }

    // 构造授权 URL 并跳转
    const redirectUri = window.location.origin + '/api/auth/oauth/callback/' + currentProvider.value.key
    alert('即将跳转到 ' + currentProvider.value.label + ' 授权页面进行授权绑定\n\n回调地址: ' + redirectUri)
    closeBindModal()
  } catch (e) {
    alert(e?.msg || e?.response?.data?.msg || e?.message || '操作失败')
    closeBindModal()
  } finally {
    binding.value = ''
  }
}

function startUnbind(provider) {
  currentProvider.value = provider
  showUnbindModal.value = true
}

function closeUnbindModal() {
  showUnbindModal.value = false
}

async function doUnbind() {
  if (!currentProvider.value.oauthId) { alert('缺少绑定记录ID'); return }
  unbinding.value = currentProvider.value.key
  try {
    await request.request({ url: '/api/user/oauth-accounts/' + currentProvider.value.oauthId, method: 'DELETE' })
    currentProvider.value.bound = false
    currentProvider.value.username = ''
    currentProvider.value.oauthId = null
    closeUnbindModal()
  } catch (e) {
    alert(e?.msg || e?.response?.data?.msg || e?.message || '解绑失败')
  } finally {
    unbinding.value = ''
  }
}
</script>

<style scoped>
.bind-page { min-height: 100vh; background: #F5F6FA; }
.bind-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.bind-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.bind-back:active { background: #f0f0f0; }
.bind-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.bind-placeholder { width: 22px; }
.bind-content { padding: 16px; }
.bind-card { background: #fff; border-radius: 12px; overflow: hidden; }
.bind-item { display: flex; align-items: center; justify-content: space-between; padding: 16px; border-bottom: 1px solid #F0F0F0; }
.bind-item:last-child { border-bottom: none; }
.bind-left { display: flex; align-items: center; gap: 14px; flex: 1; min-width: 0; }
.provider-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.provider-icon-text { font-size: 20px; font-weight: 700; color: #fff; }
.provider-info { min-width: 0; }
.provider-name { font-size: 16px; color: #1f2937; font-weight: 600; }
.provider-desc { font-size: 13px; color: #9CA3AF; margin-top: 3px; }
.provider-desc.bound { color: #10B981; }
.bind-right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.bind-time { font-size: 11px; color: #C0C4CC; }
.bind-unavailable { font-size: 13px; color: #D1D5DB; background: #F3F4F6; padding: 7px 16px; border-radius: 8px; white-space: nowrap; }
.action-btn { padding: 7px 18px; border-radius: 8px; font-size: 13px; cursor: pointer; font-weight: 500; border: none; transition: all .15s; }
.action-btn.bind { background: linear-gradient(135deg, #6366F1, #818CF8); color: #fff; }
.action-btn.bind:active { background: linear-gradient(135deg, #4F46E5, #6366F1); }
.action-btn.unbind { background: #FEF2F2; color: #EF4444; border: 1px solid #FECACA; }
.action-btn.unbind:active { background: #FEE2E2; }
.action-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.bind-tip { display: flex; align-items: center; gap: 8px; margin-top: 20px; padding: 0 4px; font-size: 13px; color: #9CA3AF; }

/* Modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 24px; }
.modal-card { background: #fff; border-radius: 20px; padding: 32px 24px 24px; width: 100%; max-width: 320px; text-align: center; }
.modal-icon { width: 64px; height: 64px; border-radius: 16px; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(0,0,0,0.12); }
.modal-icon-text { font-size: 26px; font-weight: 700; color: #fff; }
.modal-title { font-size: 18px; font-weight: 700; color: #1f2937; margin-bottom: 8px; }
.modal-desc { font-size: 14px; color: #6B7280; line-height: 1.6; margin-bottom: 24px; }
.modal-loading { display: flex; flex-direction: column; align-items: center; gap: 12px; }
.modal-spin { width: 32px; height: 32px; border: 3px solid #E5E7EB; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.modal-success { display: flex; flex-direction: column; align-items: center; gap: 12px; }
.modal-success span { font-size: 15px; font-weight: 600; color: #10B981; }
.modal-actions { display: flex; gap: 10px; }
.modal-btn { flex: 1; padding: 11px 16px; border-radius: 10px; font-size: 15px; font-weight: 600; border: none; cursor: pointer; transition: all .15s; }
.modal-btn.cancel { background: #F3F4F6; color: #6B7280; }
.modal-btn.cancel:active { background: #E5E7EB; }
.modal-btn.primary { background: linear-gradient(135deg, #6366F1, #818CF8); color: #fff; }
.modal-btn.primary:active { opacity: 0.85; }
.modal-btn.danger { background: #EF4444; color: #fff; }
.modal-btn.danger:active { opacity: 0.85; }
.modal-btn.danger:disabled { opacity: 0.5; cursor: not-allowed; }
.modal-btn.full { flex: 1; }
</style>
