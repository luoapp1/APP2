<template>
  <div class="my-collections-page">
      <div class="mc-head">
      <div class="mc-nav">
        <button class="mc-nav-back" @click="$router.back()">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <span class="mc-nav-title">{{ navTitle }}</span>
        <button v-if="activeTab === 'collections'" class="mc-nav-create" @click="goCreate">新建</button>
        <div v-else class="mc-nav-create-ph"></div>
      </div>

      <div class="mc-tabs">
        <div class="mc-tabs-track">
          <button
            v-for="tab in tabs"
            :key="tab.key"
            class="mc-tab"
            :class="{ active: activeTab === tab.key }"
            @click="switchTab(tab.key)"
          >{{ tab.label }}</button>
        </div>
      </div>
    </div>

    <!-- 帖子合集 -->
    <template v-if="activeTab === 'collections'">
      <div class="mc-body" v-if="!colLoading">
        <div
          v-for="c in collections"
          :key="c.id"
          class="col-card"
          @click="openCollection(c)"
        >
          <div class="col-cover">
            <img v-if="c.cover_image" :src="c.cover_image" class="col-cover-img" />
            <div v-else class="col-cover-ph"></div>
            <div class="col-cover-overlay">
              <span :class="['col-status-badge', colStatusClass(c.status)]">{{ colStatusLabel(c.status) }}</span>
            </div>
          </div>
          <div class="col-body">
            <div class="col-title">{{ c.title }}</div>
            <div class="col-desc" v-if="c.description">{{ c.description }}</div>
            <div class="col-stats">
              <span class="col-stat">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                {{ c.post_count }}篇
              </span>
              <span class="col-stat">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ c.view_count || 0 }}
              </span>
              <span v-if="c.subscribe_count > 0" class="col-stat col-stat-subs">{{ c.subscribe_count }}人已购</span>
            </div>
            <div class="col-footer">
              <div class="col-price">
                <template v-if="c.is_paid">
                  <span v-if="c.price_balance > 0" class="col-price-num">{{ c.price_balance }}<i>余额</i></span>
                  <span v-if="c.price_points > 0" class="col-price-num">{{ c.price_points }}<i>积分</i></span>
                </template>
                <span v-else class="col-price-free">免费合集</span>
              </div>
              <div class="col-actions">
                <button class="col-btn-edit" @click.stop="goEdit(c)">编辑</button>
                <button v-if="c.status === 'draft'" class="col-btn-del" @click.stop="handleDelete(c)">删除</button>
              </div>
            </div>
          </div>
        </div>
        <div v-if="collections.length === 0" class="mc-empty">
          <div class="mc-empty-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
          </div>
          <div class="mc-empty-text">还没有创建合集</div>
          <button class="mc-empty-btn" @click="goCreate">创建第一个合集</button>
        </div>
      </div>
      <div v-else class="mc-loading">加载中...</div>
    </template>

    <!-- 已购合集 -->
    <template v-if="activeTab === 'paid'">
      <div class="mc-body" v-if="!paidLoading">
        <div
          v-for="c in paidCollections"
          :key="c.id"
          class="col-card"
          @click="openCollection(c)"
        >
          <div class="col-cover">
            <img v-if="c.cover_image" :src="c.cover_image" class="col-cover-img" />
            <div v-else class="col-cover-ph"></div>
          </div>
          <div class="col-body">
            <div class="col-title">{{ c.title }}</div>
            <div class="col-desc" v-if="c.description">{{ c.description }}</div>
            <div class="col-stats">
              <span class="col-stat">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                {{ c.post_count }}篇
              </span>
              <span class="col-stat">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ c.view_count || 0 }}
              </span>
              <span v-if="c.subscribe_count > 0" class="col-stat col-stat-subs">{{ c.subscribe_count }}人已购</span>
            </div>
            <div class="col-footer">
              <span class="col-price-bought">已购买</span>
            </div>
          </div>
        </div>
        <div v-if="paidCollections.length === 0" class="mc-empty">
          <div class="mc-empty-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
          </div>
          <div class="mc-empty-text">还没有购买任何合集</div>
        </div>
      </div>
      <div v-else class="mc-loading">加载中...</div>
    </template>

    <!-- 已通过 / 审核中 -->
    <template v-else>
      <div class="posts-body" @touchstart="onTouchStart" @touchmove="onTouchMove" @touchend="onTouchEnd">
        <div v-if="posts.length === 0 && !postLoading" class="mc-empty">
          <div class="mc-empty-text">{{ activeTab === 'approved' ? '暂无已通过的帖子' : '暂无审核中的帖子' }}</div>
        </div>

        <div v-if="posts.length > 0" class="post-count-bar">
          <span>共 {{ postTotalCount }} 篇{{ activeTab === 'approved' ? '已通过' : '审核中' }}</span>
        </div>

        <div v-if="refreshing" class="mc-refresh-hint">释放刷新</div>

        <div v-for="post in posts" :key="post.id" class="post-card" @click="openPost(post.id)">
          <div class="post-card-inner">
            <div class="post-author">
              <div class="post-avatar" :style="{ background: avatarColor(post.userName) }">{{ post.userName?.[0] || '?' }}</div>
              <div class="post-author-col">
                <span class="post-username">{{ post.userName }}</span>
                <span class="post-time">{{ fmtRelativeTime(post.createTime) }}</span>
                <span v-if="post.sectionName" class="post-section-name">{{ post.sectionName }}</span>
              </div>
            </div>

            <div class="post-title">
              <span v-if="post.isEssence" class="post-badge essence">精</span>
              <span v-if="post.isHot" class="post-badge hot">热</span>
              <span v-if="post.isLocked" class="post-badge lock">锁</span>
              <span v-if="post.collectionId" class="post-badge collection" @click.stop="$router.push('/community/collection/' + post.collectionId)">合集</span>
              <span v-if="activeTab === 'pending'" class="post-badge pending">审核中</span>
              {{ post.title }}
            </div>

            <div class="post-content" v-if="post.content || (post.images && post.images.length)">
              <div v-if="post._previewCard?.type === 'app'" class="post-preview app" @click.stop="openPost(post.id)">
                <div class="preview-icon app-bg"><svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4" stroke-linecap="round"/></svg></div>
                <div class="preview-text">{{ post._previewCard.name || '应用' }}</div>
                <svg class="w-4 h-4 text-[#BBB]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
              </div>
              <div v-else-if="post._previewCard?.type === 'goods'" class="post-preview goods" @click.stop="openPost(post.id)">
                <div class="preview-icon goods-bg"><img v-if="post._previewCard.image" :src="$fixImgUrl(post._previewCard.image)" class="w-full h-full object-cover" @error="($event.target as HTMLImageElement).style.display='none'"/><svg v-else class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg></div>
                <div class="preview-text">{{ post._previewCard.name || '商品' }}</div>
                <svg class="w-4 h-4 text-[#BBB]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
              </div>
              <div v-else-if="post._previewCard?.type === 'vote'" class="post-preview vote" @click.stop="openPost(post.id)">
                <div class="preview-icon vote-bg"><svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div>
                <div class="preview-text">{{ post._previewCard.question || '投票' }}</div>
                <svg class="w-4 h-4 text-[#BBB]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
              </div>
              <div v-else-if="post._previewCard?.type === 'postRef'" class="post-preview ref" @click.stop="openPost(post.id)">
                <div class="preview-icon ref-bg"><svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg></div>
                <div class="preview-text">{{ post._previewCard.title || '引用帖子' }}</div>
                <svg class="w-4 h-4 text-[#BBB]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
              </div>
              <div v-else class="post-text" v-html="stripContent(post.content)"></div>
            </div>

            <div v-if="post.images && post.images.length" class="post-images">
              <div v-if="post.images.length === 1" class="post-img-single">
                <img :src="$fixImgUrl(post.images[0])" class="w-full object-cover" style="max-height:160px" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div v-else-if="post.images.length === 2" class="post-img-2">
                <img v-for="(img, idx) in post.images.slice(0,2)" :key="idx" :src="img" class="w-full object-cover aspect-square" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div v-else class="post-img-3">
                <img v-for="(img, idx) in post.images.slice(0,3)" :key="idx" :src="img" class="w-full object-cover aspect-square" loading="lazy" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
            </div>

            <div class="post-footer">
              <div v-if="post.tags && post.tags.length" class="post-tags">
                <span v-for="tag in post.tags.slice(0,3)" :key="tag" class="post-tag">{{ tag }}</span>
              </div>
              <div class="post-stats">
                <button v-if="activeTab === 'pending'" class="post-btn-edit" @click.stop="editPost(post.id)">编辑</button>
                <span class="stat">
                  <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                  {{ fmtCount(post.likeCount || 0) }}
                </span>
                <span class="stat">
                  <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                  {{ fmtCount(post.commentCount || 0) }}
                </span>
                <span class="stat">
                  <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                  {{ fmtCount(post.viewCount || 0) }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div v-if="postLoading && posts.length === 0" class="mc-loading">加载中...</div>
        <div v-else-if="postLoadingMore" class="mc-loading-more">加载更多...</div>
        <div v-else-if="postNoMore && posts.length > 0" class="mc-loading-end">- 已加载全部 -</div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchMyCollections, fetchPaidCollections, deleteCollection, fetchCommunityPosts } from '@/api/community'
import { useUserStore } from '@/store/modules/user'

const router = useRouter()
const userStore = useUserStore()

const activeTab = ref<'approved' | 'collections' | 'paid' | 'pending'>('collections')
const tabs = [
  { key: 'approved' as const, label: '已通过' },
  { key: 'collections' as const, label: '帖子合集' },
  { key: 'paid' as const, label: '已购合集' },
  { key: 'pending' as const, label: '审核中' }
]

const navTitle = computed(() => {
  const map: Record<string, string> = { approved: '已通过', collections: '我的合集', paid: '已购合集', pending: '审核中' }
  return map[activeTab.value] || '我的合集'
})

const myUserId = computed(() => userStore.info?.userId || 0)

// === Collections ===
const collections = ref<any[]>([])
const colLoading = ref(true)

// === Paid Collections ===
const paidCollections = ref<any[]>([])
const paidLoading = ref(true)

// === Posts ===
const posts = ref<any[]>([])
const postLoading = ref(false)
const postLoadingMore = ref(false)
const postNoMore = ref(false)
const postPage = ref(1)
const postTotalCount = ref(0)
const refreshing = ref(false)
let touchStartY = 0
let pullingDown = false

// === Collections logic ===
function colStatusLabel(s: string) {
  const map: Record<string, string> = { draft: '草稿', serializing: '连载中', finished: '已完结' }
  return map[s] || s
}
function colStatusClass(s: string) {
  return s === 'finished' ? 'mc-status-finished' : s === 'serializing' ? 'mc-status-serializing' : ''
}
function openCollection(c: any) { router.push(`/community/collection/${c.id}`) }
function goCreate() { router.push('/community/collection/create') }
function goEdit(c: any) { router.push(`/community/collection/create?id=${c.id}`) }

async function handleDelete(c: any) {
  if (!confirm(`确定删除合集「${c.title}」？删除后不可恢复。`)) return
  try {
    await deleteCollection(c.id)
    collections.value = collections.value.filter(x => x.id !== c.id)
  } catch (e: any) {
    alert(e.message || '删除失败')
  }
}

async function loadCollections() {
  colLoading.value = true
  try {
    const data: any = await fetchMyCollections()
    collections.value = data?.list || []
  } catch { collections.value = [] }
  colLoading.value = false
}

async function loadPaidCollections() {
  paidLoading.value = true
  try {
    const data: any = await fetchPaidCollections()
    paidCollections.value = data?.list || []
  } catch { paidCollections.value = [] }
  paidLoading.value = false
}

// === Posts logic ===
function stripContent(text: string) {
  if (!text) return ''
  try {
    const safe = text.replace(/\\\\\"/g, '\\"')
    const parsed = JSON.parse(safe)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
    if (parsed?.type === 'doc') {
      const parts: string[] = []
      function walk(n: any) {
        if (!n) return
        if (n.type === 'text') {
          const txt = n.text || ''
          const marks = (n.marks || []).map((m: any) => m.type)
          if (marks.includes('hashtag')) {
            const tags = txt.split(/\s+/).filter(Boolean)
            tags.forEach((t: string) => { parts.push(`<span class="ct-hash">${t}</span>`) })
          } else if (marks.includes('bold') && /^\[应用:/.test(txt)) {
            return
          } else {
            parts.push(txt)
          }
        } else if (n.type === 'goodsCard' || n.type === 'voteCard' || n.type === 'postRefCard' || n.type === 'memberUnlock' || n.type === 'experienceUnlock') {
          return
        } else if (n.type === 'image') {
          parts.push(`<span class="ct-img">[图片]</span>`)
        }
        if (n.content) n.content.forEach(walk)
      }
      if (parsed.content) parsed.content.forEach(walk)
      return parts.join(' ')
    }
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

async function loadPosts(reset = false) {
  if (reset) { postPage.value = 1; postNoMore.value = false; postLoading.value = true }
  else { postLoadingMore.value = true }

  const status = activeTab.value === 'approved' ? 'published' : 'pending'
  try {
    const res: any = await fetchCommunityPosts({
      userId: myUserId.value,
      status,
      page: postPage.value,
      pageSize: 20
    })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    postTotalCount.value = res?.data?.total || res?.total || list.length
    const parsed = list.map((p: any) => {
      let previewCard: any = null
      try {
        const safe = (p.content || '').replace(/\\\\\"/g, '\\"')
        const doc = JSON.parse(safe)
        if (doc?.type === 'doc' && doc.content) {
          for (const node of doc.content) {
            if (node.type === 'goodsCard') { previewCard = { type: 'goods', ...node.attrs }; break }
            if (node.type === 'voteCard') { previewCard = { type: 'vote', ...node.attrs }; break }
            if (node.type === 'postRefCard') { previewCard = { type: 'postRef', ...node.attrs }; break }
            if (node.type === 'paragraph' && node.content) {
              for (const child of node.content) {
                if (child.type === 'text' && (child.marks || []).some((m: any) => m.type === 'bold')) {
                  const txt = child.text || ''
                  const m = txt.match(/\[应用:([^|\]]+)(?:\|(\d+)\|(\d+))?/)
                  if (m) { previewCard = { type: 'app', name: m[1], id: m[2], cat: m[3] }; break }
                }
              }
            }
            if (previewCard) break
          }
        }
      } catch {}

      return {
        ...p,
        tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
        images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
        _previewCard: previewCard
      }
    })

    if (reset) { posts.value = parsed } else { posts.value.push(...parsed) }
    if (list.length < 20) postNoMore.value = true
  } catch { if (reset) posts.value = [] }
  postLoading.value = false
  postLoadingMore.value = false
}

function openPost(id: number) { router.push(`/community/post/${id}`) }
function editPost(id: number) { router.push(`/community/post/edit/${id}`) }

function onTouchStart(e: TouchEvent) {
  if (activeTab.value === 'collections') return
  touchStartY = e.touches[0].clientY
  pullingDown = false
}

function onTouchMove(e: TouchEvent) {
  if (activeTab.value === 'collections') return
  if (postLoading.value || postLoadingMore.value) return
  const deltaY = e.touches[0].clientY - touchStartY
  if (deltaY > 50 && window.scrollY === 0) {
    pullingDown = true
    refreshing.value = true
  }
}

async function onTouchEnd() {
  if (pullingDown && refreshing.value) {
    refreshing.value = false
    pullingDown = false
    await loadPosts(true)
  }
}

function switchTab(key: 'approved' | 'collections' | 'paid' | 'pending') {
  if (activeTab.value === key) return
  activeTab.value = key
  if (key === 'collections') {
    if (collections.value.length === 0) loadCollections()
  } else if (key === 'paid') {
    if (paidCollections.value.length === 0) loadPaidCollections()
  } else {
    loadPosts(true)
  }
}

function onScroll() {
  if (activeTab.value === 'collections') return
  if (postLoadingMore.value || postNoMore.value) return
  const { scrollHeight, clientHeight } = document.documentElement
  const top = window.scrollY || document.documentElement.scrollTop
  if (scrollHeight - top - clientHeight < 80) { postPage.value++; loadPosts(false) }
}

onMounted(async () => {
  await loadCollections()
  window.addEventListener('scroll', onScroll, { passive: true })
})

onUnmounted(() => { window.removeEventListener('scroll', onScroll) })
</script>

<style scoped>
.my-collections-page {
  min-height: 100vh;
  background: #f5f6fa;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}

/* === HEAD === */
.mc-head {
  position: sticky;
  top: 0;
  z-index: 10;
  background: #fff;
}
.mc-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 46px;
  padding: 0 16px;
  border-bottom: 1px solid #f0f0f0;
}
.mc-nav-back { background: none; border: none; padding: 4px; color: #333; cursor: pointer; display: flex; align-items: center; }
.mc-nav-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
.mc-nav-create { background: #6366f1; color: #fff; border: none; padding: 6px 16px; border-radius: 16px; font-size: 14px; cursor: pointer; }
.mc-nav-create-ph { width: 52px; }

/* === TABS === */
.mc-tabs {
  padding: 10px 16px;
}
.mc-tabs-track {
  display: flex;
  background: #f2f3f6;
  border-radius: 10px;
  padding: 3px;
}
.mc-tab {
  flex: 1;
  padding: 7px 0;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  color: #999;
  background: transparent;
  cursor: pointer;
  transition: all .25s ease;
  position: relative;
}
.mc-tab.active {
  color: #1a1a2e;
  background: #fff;
  font-weight: 600;
  box-shadow: 0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.04);
}

/* === Collections === */
.mc-body { padding: 12px 14px; }
.mc-loading { text-align: center; padding: 60px 0; color: #999; }

.col-card {
  background: #fff;
  border-radius: 14px;
  margin-bottom: 16px;
  overflow: hidden;
  cursor: pointer;
  box-shadow: 0 2px 12px rgba(0,0,0,.06);
  transition: transform .2s, box-shadow .2s;
}
.col-card:active {
  transform: scale(.985);
  box-shadow: 0 4px 16px rgba(0,0,0,.1);
}

/* cover */
.col-cover {
  position: relative;
  height: 140px;
  overflow: hidden;
}
.col-cover-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.col-cover-ph {
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
}
.col-cover-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  padding: 10px 12px;
  display: flex;
  justify-content: flex-end;
  background: linear-gradient(to bottom, rgba(0,0,0,.35) 0%, transparent 100%);
}
.col-status-badge {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 10px;
  font-weight: 600;
  color: #fff;
  background: rgba(255,255,255,.25);
  backdrop-filter: blur(8px);
}
.col-status-badge.mc-status-serializing { color: #a7f3d0; }
.col-status-badge.mc-status-finished { color: #c4b5fd; }

/* body */
.col-body { padding: 14px; }
.col-title {
  font-size: 16px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.col-desc {
  font-size: 13px;
  color: #999;
  margin-top: 6px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.5;
}
.col-stats {
  display: flex;
  gap: 14px;
  margin-top: 10px;
}
.col-stat {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #b0b0b0;
}
.col-stat-subs { color: #6366f1; font-weight: 500; }

/* footer */
.col-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #f5f5f5;
}
.col-price { display: flex; gap: 8px; align-items: center; }
.col-price-num {
  font-size: 18px;
  font-weight: 800;
  color: #f56c6c;
  line-height: 1;
}
.col-price-num i {
  font-style: normal;
  font-size: 11px;
  font-weight: 500;
  color: #f56c6c;
  margin-left: 2px;
  opacity: .8;
}
.col-price-free {
  font-size: 14px;
  font-weight: 600;
  color: #67c23a;
}
.col-price-bought {
  font-size: 14px;
  font-weight: 600;
  color: #67c23a;
}
.col-actions { display: flex; gap: 8px; }
.col-btn-edit {
  background: #6366f1;
  color: #fff;
  border: none;
  padding: 7px 16px;
  border-radius: 16px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}
.col-btn-del {
  background: #fef0f0;
  color: #f56c6c;
  border: none;
  padding: 7px 16px;
  border-radius: 16px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

/* Posts */
.posts-body { padding: 8px 12px; padding-bottom: 100px; }

.post-card {
  background: #fff;
  border-radius: 12px;
  margin-bottom: 10px;
  box-shadow: 0 1px 3px rgba(0,0,0,.04);
  cursor: pointer;
}
.post-card:active { background: #fafafa; }
.post-card-inner { padding: 12px; }

.post-author {
  display: flex;
  align-items: center;
  gap: 8px;
}
.post-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  flex-shrink: 0;
}
.post-author-col {
  display: flex;
  flex-direction: column;
  gap: 1px;
}
.post-username { font-size: 14px; font-weight: 600; color: #1a1a2e; }
.post-time { font-size: 11px; color: #999; }

.post-title {
  margin-top: 10px;
  font-size: 15px;
  font-weight: 600;
  color: #111;
  line-height: 1.45;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.post-badge {
  display: inline-flex;
  align-items: center;
  font-size: 11px;
  padding: 1px 6px;
  border-radius: 3px;
  font-weight: 600;
  margin-right: 4px;
  vertical-align: middle;
}
.post-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-badge.lock { color: #999; background: #F5F5F5; }
.post-badge.collection { color: #7C3AED; background: #F5F3FF; }
.post-badge.pending { color: #D48806; background: #FEFCE8; }

.post-content { margin-top: 8px; }
.post-text {
  font-size: 13px;
  color: #999;
  line-height: 1.55;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.post-preview {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 500;
}
.post-preview.app { background: #F0F9FF; border: 1px solid #BAE6FD; color: #0C4A6E; }
.post-preview.goods { background: #FFFBE6; border: 1px solid #FDE68A; color: #92400E; }
.post-preview.vote { background: #F5F3FF; border: 1px solid #DDD6FE; color: #5B21B6; }
.post-preview.ref { background: #ECFDF5; border: 1px solid #A7F3D0; color: #064E3B; }
.preview-icon { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; overflow: hidden; }
.preview-icon.app-bg { background: linear-gradient(135deg, #0EA5E9, #38BDF8); }
.preview-icon.goods-bg { background: linear-gradient(135deg, #D48806, #F59E0B); }
.preview-icon.vote-bg { background: linear-gradient(135deg, #7C3AED, #A78BFA); }
.preview-icon.ref-bg { background: linear-gradient(135deg, #059669, #34D399); }
.preview-text { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.post-images { margin-top: 8px; }
.post-images img { border-radius: 8px; }
.post-img-single { border-radius: 8px; overflow: hidden; }
.post-img-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
.post-img-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 4px; }

.post-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
  padding-top: 8px;
  border-top: 1px solid #f5f5f5;
}
.post-tags { display: flex; gap: 4px; flex-wrap: wrap; }
.post-tag {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
  background: #f5f5f5;
  color: #666;
}
.post-stats { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.stat { display: inline-flex; align-items: center; gap: 2px; font-size: 12px; color: #b0b0b0; }

.post-btn-edit {
  background: #EFF6FF;
  color: #3B82F6;
  border: none;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  margin-right: auto;
}

.post-section-name {
  font-size: 11px;
  color: #6366f1;
  background: #EEF2FF;
  padding: 1px 8px;
  border-radius: 8px;
  margin-top: 2px;
  display: inline-block;
  max-width: fit-content;
}

.post-count-bar {
  padding: 4px 0 8px;
  font-size: 12px;
  color: #999;
  text-align: center;
}

.mc-refresh-hint {
  text-align: center;
  padding: 8px 0;
  font-size: 12px;
  color: #6366f1;
}

.mc-loading-more { text-align: center; padding: 16px; color: #bbb; font-size: 13px; }
.mc-loading-end { text-align: center; padding: 16px; color: #ddd; font-size: 12px; }

.mc-empty { display: flex; flex-direction: column; align-items: center; padding: 60px 20px; }
.mc-empty-icon { margin-bottom: 12px; }
.mc-empty-text { font-size: 15px; color: #909399; margin-bottom: 16px; }
.mc-empty-btn { background: #6366f1; color: #fff; border: none; padding: 10px 28px; border-radius: 20px; font-size: 14px; cursor: pointer; }
</style>

<style>
.ct-hash { color: #6366F1; background: #EEF2FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-img { color: #9CA3AF; font-size: 11px; }
</style>
