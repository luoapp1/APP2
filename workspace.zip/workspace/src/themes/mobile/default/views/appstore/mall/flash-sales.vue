<template>
  <div class="page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="title">限时秒杀</span>
    </div>
    <main class="main">
      <div v-if="loading" class="loading">加载中...</div>
      <div v-else-if="list.length === 0" class="empty">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c0c4cc" stroke-width="1.5"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
        <div>暂无秒杀活动</div>
      </div>
      <template v-else>
        <div v-for="item in list" :key="item.id" class="card">
          <div class="card-header">
            <span class="flash-badge">限时秒杀</span>
            <span class="countdown" :class="{ overdue: countdowns[item.id] <= 0 }">
              {{ formatCountdown(countdowns[item.id]) }}
            </span>
          </div>
          <div class="card-body" @click="$router.push('/appstore/mall-detail/' + item.productId)">
            <div class="card-img-wrap">
              <div v-if="item.coverImage" class="card-img" :style="{ backgroundImage: 'url(' + item.coverImage + ')' }" />
              <div v-else class="card-img card-img-fb">
                <span>{{ item.productName }}</span>
              </div>
            </div>
            <div class="card-info">
              <div class="card-name">{{ item.productName }}</div>
              <div class="card-price-row">
                <span class="flash-price">{{ item.flashPrice }} R币</span>
                <span class="original-price">{{ item.originalPrice }} R币</span>
              </div>
              <div class="card-progress">
                <div class="progress-bar">
                  <div class="progress-fill" :style="{ width: progressPercent(item) + '%' }" />
                </div>
                <span class="progress-text">已抢{{ item.soldCount }}件 / 共{{ item.stockCount }}件</span>
              </div>
            </div>
          </div>
        </div>
      </template>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import request from '@/utils/http'

const list = ref([])
const loading = ref(true)
const countdowns = ref({})
let timer = null

onMounted(async () => {
  try {
    const res = await request.get({ url: '/api/mall/flash-sales?status=active' })
    list.value = res?.list || []
    list.value.forEach(item => {
      countdowns.value[item.id] = calcRemaining(item.endTime)
    })
  } catch (e) { console.error(e) }
  loading.value = false
  timer = setInterval(() => {
    list.value.forEach(item => {
      countdowns.value[item.id] = calcRemaining(item.endTime)
    })
  }, 1000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})

function calcRemaining(endTime) {
  const diff = new Date(endTime).getTime() - Date.now()
  return Math.max(0, Math.floor(diff / 1000))
}

function formatCountdown(seconds) {
  if (seconds <= 0) return '已结束'
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  const pad = (n) => String(n).padStart(2, '0')
  return `${pad(h)}:${pad(m)}:${pad(s)}`
}

function progressPercent(item) {
  if (!item.stockCount || item.stockCount <= 0) return 0
  return Math.min(100, Math.round((item.soldCount / item.stockCount) * 100))
}
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6fa }
.header { background: linear-gradient(135deg, #FF1744, #FF5252); display: flex; align-items: center; padding: 12px 16px; position: sticky; top: 0; z-index: 10 }
.back-btn { background: none; border: none; padding: 4px; color: #fff; cursor: pointer }
.title { font-size: 17px; font-weight: 600; color: #fff; margin-left: 8px }
.main { padding: 12px }
.loading { text-align: center; padding: 60px 0; color: #999 }
.empty { text-align: center; padding: 80px 0; color: #999 }
.card { background: #fff; border-radius: 12px; padding: 14px; margin-bottom: 12px }
.card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px }
.flash-badge { background: linear-gradient(135deg, #FF1744, #FF5252); color: #fff; font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 4px }
.countdown { font-size: 16px; font-weight: 700; color: #FF1744; font-family: monospace }
.countdown.overdue { color: #999 }
.card-body { display: flex; gap: 12px; cursor: pointer }
.card-img-wrap { width: 100px; height: 100px; flex-shrink: 0 }
.card-img { width: 100%; height: 100%; border-radius: 8px; background-size: cover; background-position: center }
.card-img-fb { background: linear-gradient(135deg, #f0f0f0, #e0e0e0); display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px; text-align: center; overflow: hidden; padding: 8px }
.card-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px }
.card-name { font-size: 14px; font-weight: 600; color: #1a1a2e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
.card-price-row { display: flex; align-items: baseline; gap: 8px }
.flash-price { font-size: 17px; font-weight: 700; color: #FF1744 }
.original-price { font-size: 12px; color: #bbb; text-decoration: line-through }
.card-progress { display: flex; flex-direction: column; gap: 4px }
.progress-bar { height: 6px; background: #f5f5f5; border-radius: 3px; overflow: hidden }
.progress-fill { height: 100%; background: linear-gradient(90deg, #FF1744, #FF5252); border-radius: 3px; transition: width .3s }
.progress-text { font-size: 11px; color: #bbb }
</style>
