<template>
  <div class="settings-page">
    <div class="settings-navbar">
      <button class="settings-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="settings-title">设置</span>
      <div class="settings-placeholder" />
    </div>

    <div class="settings-content">
      <div v-for="(group, gi) in settingGroups" :key="gi" class="settings-card">
        <div
          v-for="(item, ii) in group"
          :key="ii"
          class="settings-item"
          :class="{ 'has-border': ii < group.length - 1 }"
          @click="handleItemClick(item)"
        >
          <div class="settings-item-left">
            <div class="settings-item-icon" v-html="item.icon" />
            <span class="settings-item-label">{{ item.label }}</span>
          </div>
          <div class="settings-item-right">
            <span v-if="item.status" class="settings-item-status">{{ item.status }}</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C0C4CC" stroke-width="2" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'

const router = useRouter()

const urlMap = ref<Record<string, string>>({})

const labelKeyMap: Record<string, string> = {
  '帮助与反馈': 'site_help_url',
  '用户协议': 'site_agreement_url',
  '隐私政策与个人信息清单': 'site_privacy_url',
  '安全条款': 'site_security_url',
  '关于': 'site_about_url'
}

onMounted(async () => {
  try {
    const res: any = await request.get({ url: '/api/sys-config/list' })
    if (Array.isArray(res)) {
      const map: Record<string, string> = {}
      for (const item of res) {
        if (item.config_key && item.config_value) map[item.config_key] = item.config_value
      }
      urlMap.value = map
    }
  } catch {}
})

const settingGroups = [
  [
    {
      label: '头像与个人信息',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
      route: '/appstore/profile/edit'
    },
    {
      label: '账号与绑定',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
      route: '/appstore/account-bind'
    }
  ],
  [
    {
      label: '隐私设置',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>',
      route: '/appstore/security-settings'
    },
    {
      label: '收货地址',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',
      route: '/appstore/addresses'
    },
    {
      label: '个人空间',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
      route: '/appstore/personal-space'
    }
  ],
  [
    {
      label: '订阅消息提醒',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>',
      route: '/appstore/notification-settings'
    }
  ],
  [
    {
      label: '我的认证',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg>',
      route: '/appstore/verification'
    }
  ],
  [
    {
      label: '青少年模式',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>',
      route: null,
      status: '未开启'
    },
    {
      label: '缓存清理',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>',
      route: null
    },
    {
      label: '帮助与反馈',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
      route: null
    },
    {
      label: '用户协议',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
      route: null
    },
    {
      label: '隐私政策与个人信息清单',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
      route: null
    },
    {
      label: '安全条款',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
      route: null
    },
    {
      label: '关于',
      icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
      route: null
    }
  ]
]

function handleItemClick(item) {
  const key = labelKeyMap[item.label]
  if (key) {
    const url = urlMap.value[key]
    if (url) { window.open(url, '_blank'); return }
  }
  if (item.route) {
    router.push(item.route)
  }
}
</script>

<style scoped>
.settings-page {
  min-height: 100vh;
  background: #F5F6FA;
}

.settings-navbar {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.05);
}

.settings-back {
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  display: flex;
  color: #333;
  border-radius: 8px;
}

.settings-back:active {
  background: #f0f0f0;
}

.settings-title {
  flex: 1;
  text-align: center;
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
}

.settings-placeholder {
  width: 22px;
}

.settings-content {
  padding: 12px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.settings-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
}

.settings-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  cursor: pointer;
  transition: background .15s;
}

.settings-item:active {
  background: #f5f5f5;
}

.settings-item.has-border {
  border-bottom: 1px solid #F0F0F0;
}

.settings-item-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.settings-item-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.settings-item-label {
  font-size: 15px;
  color: #333;
  font-weight: 400;
}

.settings-item-right {
  display: flex;
  align-items: center;
  gap: 6px;
}

.settings-item-status {
  font-size: 13px;
  color: #999;
}
</style>
