<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">举报申诉处理</span>
    </div>

    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="loading" class="flex justify-center py-12">
        <div class="w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full animate-spin" />
      </div>

      <template v-else-if="appeals.length > 0">
        <div v-for="item in appeals" :key="item.id" class="bg-white mx-3 mt-3 rounded-xl px-4 py-3">
          <div class="flex items-start gap-3">
            <div class="w-10 h-10 rounded-full bg-[#EEF2FF] flex items-center justify-center flex-shrink-0">
              <span class="text-sm font-bold text-[#6366F1]">{{ (item.reporterName || '?')[0] }}</span>
            </div>
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-2 mb-0.5">
                <span class="text-sm font-semibold text-gray-800 truncate">{{ item.reporterName || '匿名' }}</span>
                <span class="text-[11px] px-1.5 py-0.5 rounded" :class="item.targetType === 'post' ? 'bg-blue-50 text-blue-500' : 'bg-purple-50 text-purple-500'">{{ item.targetType === 'post' ? '帖子' : '评论' }}</span>
              </div>
              <div class="grid gap-2 mt-2">
                <div class="bg-[#f5f6f8] rounded-lg px-3 py-2">
                  <div class="text-[11px] text-gray-400 mb-0.5">举报类型</div>
                  <div class="text-xs text-gray-500">{{ item.category || '-' }}</div>
                </div>
                <div class="bg-[#f5f6f8] rounded-lg px-3 py-2">
                  <div class="text-[11px] text-gray-400 mb-0.5">举报原因</div>
                  <div class="text-xs text-gray-700">{{ item.reportReason || '-' }}</div>
                </div>
                <div class="bg-[#EEF2FF] rounded-lg px-3 py-2">
                  <div class="text-[11px] text-[#6366F1] mb-0.5">申诉理由</div>
                  <div class="text-xs text-gray-700">{{ item.appealReason || '-' }}</div>
                </div>
              </div>
              <div class="text-[11px] text-gray-400 mt-2">{{ (item.createTime || '').slice(0, 16) || '-' }}</div>
            </div>
          </div>
          <div class="flex items-center gap-2 mt-3 pt-3 border-t border-gray-50">
            <button class="sm-btn flex-1 h-8 text-xs rounded-lg font-medium" style="background:#D1FAE5;color:#059669" @click="confirmAction(item, 'accept')">采纳申诉</button>
            <button class="sm-btn flex-1 h-8 text-xs rounded-lg font-medium" style="background:#FEE2E2;color:#DC2626" @click="confirmAction(item, 'reject')">驳回申诉</button>
          </div>
        </div>
        <div class="text-center text-xs text-gray-400 py-4">共 {{ appeals.length }} 条</div>
      </template>

      <div v-else class="flex flex-col items-center py-12 text-gray-400">
        <span class="text-sm">暂无申诉</span>
      </div>
    </div>

    <Teleport to="body">
      <div v-if="confirmVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="confirmVisible = false">
        <div class="absolute inset-0 bg-black/40" @click="confirmVisible = false" />
        <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden relative z-10" @click.stop>
          <div class="p-5 text-center">
            <div class="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" :class="confirmActionType === 'accept' ? 'bg-green-50' : 'bg-red-50'">
              <svg v-if="confirmActionType === 'accept'" class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <svg v-else class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div class="text-sm font-semibold text-gray-800 mb-1">{{ confirmActionType === 'accept' ? '确认采纳申诉' : '确认驳回申诉' }}</div>
            <div class="text-xs text-gray-400">{{ confirmActionType === 'accept' ? '采纳后将恢复相关内容' : '驳回后将维持原处理决定' }}</div>
          </div>
          <div class="flex border-t border-gray-100">
            <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="confirmVisible = false">取消</button>
            <button class="flex-1 h-11 text-sm font-semibold border-l border-gray-100 active:opacity-80" :class="confirmActionType === 'accept' ? 'text-green-600 active:bg-green-50' : 'text-red-500 active:bg-red-50'" @click="doConfirmAction">{{ confirmActionType === 'accept' ? '采纳' : '驳回' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'AppealManageMobile' })

const toastMsg = ref('')
const toastType = ref('success')
let toastTimer = null
const showToast = (m, t = 'success') => {
  toastMsg.value = m
  toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const loading = ref(false)
const appeals = ref([])

const fetchData = async () => {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/community/moderator/appeals' })
    appeals.value = res?.records || res?.data?.records || res?.data || res || []
  } catch (e) {
    console.error('fetchData error:', e)
  }
  loading.value = false
}

const confirmVisible = ref(false)
const confirmTarget = ref(null)
const confirmActionType = ref('accept')

const confirmAction = (item, action) => {
  confirmTarget.value = item
  confirmActionType.value = action
  confirmVisible.value = true
}

const doConfirmAction = async () => {
  if (!confirmTarget.value) return
  try {
    await request.post({
      url: `/api/community/moderator/appeal/${confirmTarget.value.id}/handle`,
      data: { action: confirmActionType.value }
    })
    showToast(confirmActionType.value === 'accept' ? '已采纳申诉' : '已驳回申诉')
    confirmVisible.value = false
    fetchData()
  } catch (e) {
    showToast('操作失败', 'error')
  }
}

onMounted(() => fetchData())
</script>
