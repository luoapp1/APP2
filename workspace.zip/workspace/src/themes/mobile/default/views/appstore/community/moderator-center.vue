<template>
  <div class="mc-page">
    <div class="mc-navbar">
      <button class="mc-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="mc-nav-title">版主中心</span>
      <button class="mc-nav-more" @click="showMenu = !showMenu" v-if="hasAccess">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
      </button>
    </div>

    <div v-if="!hasAccess" class="mc-empty">
      <div class="mc-empty-icon">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
      </div>
      <p class="mc-empty-title">无版主权限</p>
      <p class="mc-empty-desc">您不是任何板块的版主或审核员，无法访问版主中心。</p>
    </div>

    <div v-else class="mc-body">
      <div class="mc-stats-row">
        <div class="mc-stat" @click="activeTab='pending'">
          <div class="mc-stat-icon mc-stat-icon-pending">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          </div>
          <div class="mc-stat-num">{{ stats.pendingCount }}</div>
          <div class="mc-stat-label">待审核</div>
        </div>
        <div class="mc-stat mc-stat-warn" @click="activeTab='reports'">
          <div class="mc-stat-icon mc-stat-icon-report">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>
          </div>
          <div class="mc-stat-num">{{ stats.reportCount }}</div>
          <div class="mc-stat-label">举报</div>
        </div>
        <div class="mc-stat mc-stat-info" @click="activeTab='unlocks'">
          <div class="mc-stat-icon mc-stat-icon-unlock">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 019.9-1"/></svg>
          </div>
          <div class="mc-stat-num">{{ stats.unlockCount }}</div>
          <div class="mc-stat-label">解锁申请</div>
        </div>
        <div class="mc-stat mc-stat-green" @click="activeTab='bans'">
          <div class="mc-stat-icon mc-stat-icon-ban">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
          </div>
          <div class="mc-stat-num">{{ bans.length }}</div>
          <div class="mc-stat-label">禁言中</div>
        </div>
      </div>
      <div class="mc-stats-sub">
        <span>今日审核 {{ extStats.todayReviewCount || 0 }} 篇</span>
        <span class="mc-stats-sub-right">总帖 {{ extStats.totalPosts || 0 }} · 总评 {{ extStats.totalComments || 0 }}</span>
      </div>

      <div class="mc-section-info" v-if="mySections.length">
        <span class="mc-section-label">板块：</span>
        <span v-for="s in mySections" :key="s.id" class="mc-section-tag" :style="{ background: s.iconBgColor || '#6366F1' }" @click="openSectionSettings(s)">
          <img v-if="s.icon" :src="fixImg(s.icon)" class="mc-section-tag-icon"  loading="lazy" />
          {{ s.name }}
        </span>
      </div>

      <!-- Tabs -->
      <div class="mc-tabs">
        <button v-for="t in tabs" :key="t.key" class="mc-tab" :class="{ on: activeTab===t.key }" @click="switchTab(t.key)">
          {{ t.label }}<span v-if="t.badge>0" class="mc-tab-badge">{{ t.badge }}</span>
        </button>
      </div>

      <!-- Pending posts -->
      <div v-show="activeTab==='pending'" class="mc-content">
        <div class="mc-toolbar" v-if="pendingPosts.length">
          <input v-model="searchKeyword" class="mc-search" placeholder="搜索标题..." @input="filterPending" />
          <button v-if="selectedIds.length" class="mc-btn mc-btn-sm mc-btn-approve" @click="batchDialog='approve'">批量通过({{selectedIds.length}})</button>
          <button v-if="selectedIds.length" class="mc-btn mc-btn-sm mc-btn-reject" @click="batchDialog='reject'">批量驳回</button>
        </div>
        <div class="mc-list">
          <div v-if="!filteredPending.length && !loadingPending" class="mc-empty-list">暂无待审核帖子</div>
          <div v-for="post in filteredPending" :key="post.id" class="mc-card" :class="{ selected: selectedIds.includes(post.id) }">
            <div class="mc-card-check" @click="toggleSelect(post.id)">
              <div class="mc-checkbox" :class="{ on: selectedIds.includes(post.id) }">
                <svg v-if="selectedIds.includes(post.id)" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            </div>
            <div class="mc-card-body">
              <div class="mc-card-header">
                <img v-if="post.userAvatar" :src="fixImg(post.userAvatar)" class="mc-card-avatar"  loading="lazy" />
                <span v-else class="mc-card-avatar-plc">{{ (post.userName||'?').charAt(0) }}</span>
                <span class="mc-card-username">{{ post.userName||'匿名' }}</span>
                <span v-if="post.sectionId" class="mc-card-section-tag">{{ sectionLabel(post.sectionId) }}</span>
                <span class="mc-card-time">{{ fmt(post.createTime) }}</span>
              </div>
              <div class="mc-card-title" @click="viewPost(post)">{{ post.title }}</div>
              <div class="mc-card-content" v-if="post.content">{{ strip(post.content).substring(0,150) }}</div>
              <div class="mc-card-images" v-if="post.images&&post.images.length">
                <img v-for="(img,i) in post.images.slice(0,4)" :src="fixImg(img)" class="mc-card-img" :key="img"  loading="lazy" />
              </div>
              <div class="mc-card-actions">
                <button class="mc-btn mc-btn-approve" @click="approvePost(post)">通过</button>
                <button class="mc-btn mc-btn-reject" @click="rejectPost(post)">驳回</button>
                <button class="mc-btn mc-btn-outline" @click="viewPost(post)">详情</button>
                <button class="mc-btn mc-btn-outline" @click="openMoveDialog(post)">移动</button>
                <button class="mc-btn mc-btn-outline" @click="openEditDialog(post)">编辑</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Reports -->
      <div v-show="activeTab==='reports'" class="mc-content">
        <div class="mc-list">
          <div v-if="!reports.length && !loadingReports" class="mc-empty-list">暂无待处理举报</div>
          <div v-for="r in reports" :key="r.id" class="mc-card">
            <div class="mc-card-body">
              <div class="mc-card-header">
                <span :class="['mc-card-type-badge', r.targetType==='post'?'mc-card-type-post':'mc-card-type-comment']">{{ r.targetType==='post'?'帖子':'评论' }}</span>
                <span class="mc-card-username">{{ r.reporterName||'匿名' }} 举报</span>
                <span class="mc-card-time">{{ fmt(r.createTime) }}</span>
              </div>
              <div class="mc-card-title mc-card-title-sm">{{ r.reportReason }}</div>
              <div class="mc-card-content" v-if="r.reportDetail">{{ r.reportDetail }}</div>
              <div class="mc-card-quote" v-if="r.targetTitle">{{ r.targetTitle }}</div>
              <div class="mc-card-actions">
                <button class="mc-btn mc-btn-approve" @click="ignoreReport(r)">忽略</button>
                <button class="mc-btn mc-btn-reject" @click="r.targetType==='comment' ? deleteComment(r) : viewPost({id: r.targetId})">
                  {{ r.targetType==='comment' ? '删除评论' : '处理帖子' }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unlock requests -->
      <div v-show="activeTab==='unlocks'" class="mc-content">
        <div class="mc-list">
          <div v-if="!unlockRequests.length && !loadingUnlocks" class="mc-empty-list">暂无解锁申请</div>
          <div v-for="ur in unlockRequests" :key="ur.id" class="mc-card">
            <div class="mc-card-body">
              <div class="mc-card-title">解锁申请：{{ ur.postTitle||'未知帖子' }}</div>
              <div class="mc-card-content" v-if="ur.reason">{{ ur.reason }}</div>
              <div class="mc-card-actions">
                <button class="mc-btn mc-btn-approve" @click="handleUnlock(ur,'approve')">通过</button>
                <button class="mc-btn mc-btn-reject" @click="handleUnlock(ur,'reject')">拒绝</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Ban management -->
      <div v-show="activeTab==='bans'" class="mc-content">
        <div class="mc-toolbar">
          <select v-if="mySections.length>1" v-model="banSectionId" class="mc-select" @change="loadBans">
            <option :value="0">全部板块</option>
            <option v-for="s in mySections" :value="s.id" :key="s.id">{{ s.name }}</option>
          </select>
          <button class="mc-btn mc-btn-primary" @click="openBanDialog()">+ 禁言用户</button>
        </div>
        <div class="mc-list">
          <div v-if="!bans.length && !loadingBans" class="mc-empty-list">暂无禁言记录</div>
          <div v-for="b in bans" :key="b.id" class="mc-card">
            <div class="mc-card-body">
              <div class="mc-card-header">
                <span class="mc-card-avatar-plc mc-card-avatar-plc-ban">{{ (b.bannedUserName||'?').charAt(0) }}</span>
                <span class="mc-card-username">{{ b.bannedUserName||'未知' }}</span>
                <span :class="['mc-card-ban-status', b.isActive?'mc-card-ban-active':'mc-card-ban-expired']">{{ b.isActive?'生效中':'已解除' }}</span>
              </div>
              <div class="mc-card-content">{{ b.reason||'未填写原因' }}</div>
              <div class="mc-card-time">禁言至 {{ fmt(b.banUntil) }}</div>
              <button v-if="b.isActive" class="mc-btn mc-btn-approve" style="margin-top:8px" @click="unbanUser(b)">解除禁言</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Logs -->
      <div v-show="activeTab==='logs'" class="mc-content">
        <div class="mc-list">
          <div v-if="!logs.length && !loadingLogs" class="mc-empty-list">暂无操作记录</div>
          <div v-for="l in logs" :key="l.id" class="mc-card mc-card-log">
            <div class="mc-card-body" style="display:flex;align-items:center;gap:12px;">
              <span :class="['mc-log-badge', l.action.includes('approve')||l.action.includes('通过')?'mc-log-badge-ok':l.action.includes('reject')||l.action.includes('驳回')||l.action.includes('delete')?'mc-log-badge-bad':'mc-log-badge-info']">{{ l.action }}</span>
              <span class="mc-card-content" style="flex:1;margin:0;">{{ l.detail }}</span>
              <span class="mc-card-time" style="flex-shrink:0;">{{ fmt(l.createTime) }}</span>
            </div>
          </div>
        </div>
      </div>
      </div>

      <!-- Config -->
      <div v-show="activeTab==='config'" class="mc-content">
        <div class="mc-config-tabs">
          <button v-for="c in configSubTabs" :key="c.key" class="mc-config-tab" :class="{ on: configSubTab===c.key }" @click="configSubTab=c.key">
            {{ c.label }}
          </button>
        </div>

        <!-- 敏感词管理 -->
        <div v-show="configSubTab==='sensitive'" class="mc-config-body">
          <div class="mc-cfg-toolbar">
            <div class="mc-cfg-input-wrap">
              <svg class="mc-cfg-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input v-model="swForm.word" class="mc-cfg-input mc-cfg-input-has-icon" placeholder="输入敏感词" @keyup.enter="saveSensitiveWord" />
            </div>
            <select v-model="swForm.level" class="mc-cfg-select">
              <option value="block">拦截</option>
              <option value="review">待审</option>
              <option value="warn">警告</option>
            </select>
            <input v-model="swForm.replacement" class="mc-cfg-input mc-cfg-sm" placeholder="替换词" />
            <button class="mc-cfg-btn-primary" @click="saveSensitiveWord">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="mc-cfg-btn-icon"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              {{ swForm.id ? '保存' : '添加' }}
            </button>
            <button v-if="swForm.id" class="mc-cfg-btn-ghost" @click="resetSwForm">取消</button>
          </div>

          <div class="mc-cfg-list-head">
            <span class="mc-cfg-list-title">敏感词库 · {{ sensitiveWords.length }} 条</span>
            <div class="mc-cfg-list-stats">
              <span class="mc-cfg-stat-chip mc-cfg-stat-chip-block">拦截 {{ countByLevel('block') }}</span>
              <span class="mc-cfg-stat-chip mc-cfg-stat-chip-review">待审 {{ countByLevel('review') }}</span>
              <span class="mc-cfg-stat-chip mc-cfg-stat-chip-warn">警告 {{ countByLevel('warn') }}</span>
            </div>
          </div>

          <div v-if="!sensitiveWords.length" class="mc-empty-list">暂无敏感词，在上方输入框中添加</div>
          <div v-else class="mc-cfg-list">
            <div v-for="(w, idx) in sensitiveWords" :key="w.id" class="mc-cfg-row" :class="'mc-cfg-row-lvl-'+w.level">
              <span class="mc-cfg-row-idx">{{ idx + 1 }}</span>
              <span class="mc-cfg-row-word">{{ w.word }}</span>
              <span v-if="w.replacement" class="mc-cfg-row-replace">{{ w.replacement }}</span>
              <span :class="['mc-cfg-row-tag', 'mc-cfg-row-tag-'+w.level]">{{ w.level==='block'?'拦截':w.level==='review'?'待审':'警告' }}</span>
              <div class="mc-cfg-row-actions">
                <button class="mc-cfg-btn-icon-only" title="编辑" @click="editSensitiveWord(w)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <button class="mc-cfg-btn-icon-only mc-cfg-btn-icon-only-del" title="删除" @click="delSensitiveWord(w.id)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 规则引擎管理 -->
        <div v-show="configSubTab==='rules'" class="mc-config-body">
          <div class="mc-cfg-toolbar">
            <select v-model="ruleFilterType" class="mc-cfg-select" @change="loadModRules">
              <option value="">全部规则</option>
              <option value="post">帖子</option>
              <option value="comment">评论</option>
            </select>
            <span class="mc-cfg-toolbar-info">{{ modRules.length }} 条 · 启用 {{ modRules.filter(r=>r.enabled).length }}</span>
            <button class="mc-cfg-btn-primary" @click="startNewRule" style="margin-left:auto;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="mc-cfg-btn-icon"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              新增
            </button>
          </div>

          <div v-if="!modRules.length" class="mc-empty-list">暂无规则，点击"新增"创建</div>
          <div v-else class="mc-cfg-list">
            <div v-for="r in modRules" :key="r.id" class="mc-cfg-row mc-cfg-row-rule" :class="{ 'mc-cfg-row-off': !r.enabled }">
              <div class="mc-cfg-row-body">
                <div class="mc-cfg-row-name">
                  {{ r.display_name || r.name }}
                  <span v-if="!r.enabled" class="mc-cfg-meta-tag mc-cfg-meta-off" style="margin-left:6px;">已停用</span>
                </div>
                <div class="mc-cfg-row-meta">
                  <span class="mc-cfg-meta-tag">{{ r.target_type==='post'?'帖子':r.target_type==='comment'?'评论':r.target_type==='app'?'应用':'商品' }}</span>
                  <span :class="['mc-cfg-meta-tag', r.action==='block'?'mc-cfg-meta-block':'mc-cfg-meta-pending']">{{ r.action==='block'?'拦截':'待审' }}</span>
                  <span class="mc-cfg-meta-tag mc-cfg-meta-prio">P{{ r.priority }}</span>
                  <span v-if="r.config" class="mc-cfg-row-desc-inline">{{ formatRuleConfig(r) }}</span>
                </div>
              </div>
              <div class="mc-cfg-row-actions">
                <button class="mc-cfg-btn-icon-only" title="编辑" @click="editRule(r)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <label class="mc-switch" :title="r.enabled?'停用':'启用'">
                  <input type="checkbox" :checked="!!r.enabled" @change="toggleRule(r)">
                  <span class="mc-switch-slider"></span>
                </label>
              </div>
            </div>
          </div>

          <!-- 规则编辑弹窗 -->
          <div v-if="ruleEdit.id||ruleEdit.isNew" class="mc-overlay" @click.self="closeRuleEdit">
            <div class="mc-dialog">
              <div class="mc-dialog-title">{{ ruleEdit.isNew ? '新增规则' : '编辑规则' }}</div>
              <label class="mc-label">规则名称</label>
              <input v-model="ruleEdit.name" class="mc-dialog-input" />
              <label class="mc-label">显示名称</label>
              <input v-model="ruleEdit.display_name" class="mc-dialog-input" />
              <label class="mc-label">目标类型</label>
              <select v-model="ruleEdit.target_type" class="mc-dialog-input">
                <option value="post">帖子</option>
                <option value="comment">评论</option>
                <option value="app">应用</option>
                <option value="product">商品</option>
              </select>
              <label class="mc-label">动作</label>
              <select v-model="ruleEdit.action" class="mc-dialog-input">
                <option value="pending">待审</option>
                <option value="block">拒绝</option>
              </select>
              <label class="mc-label">配置参数 (JSON)</label>
              <textarea v-model="ruleEdit.config" class="mc-dialog-input" rows="3" />
              <label class="mc-label">优先级</label>
              <input v-model.number="ruleEdit.priority" type="number" class="mc-dialog-input" />
              <div class="mc-dialog-actions">
                <button class="mc-cfg-btn-ghost" @click="closeRuleEdit">取消</button>
                <button class="mc-cfg-btn-primary" @click="saveRule">保存</button>
              </div>
            </div>
          </div>
        </div>

        <!-- 质量评分 -->
        <div v-show="configSubTab==='quality'" class="mc-config-body">
          <div class="mc-cfg-toolbar">
            <select v-model="qualityTargetType" class="mc-cfg-select" @change="loadQualityDims">
              <option value="post">帖子</option>
              <option value="app">应用</option>
              <option value="product">商品</option>
            </select>
            <span class="mc-cfg-toolbar-info">{{ qualityDims.length }} 个维度</span>
            <button class="mc-cfg-btn-primary" @click="startNewDim" style="margin-left:auto;">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="mc-cfg-btn-icon"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              新增
            </button>
          </div>
          <div class="mc-cfg-card" v-if="qualityThresholds.high != null">
            <div class="mc-cfg-add-row">
              <span style="font-size:12px;color:#999;flex-shrink:0;">阈值</span>
              <input v-model.number="qualityThresholds.high" class="mc-cfg-input mc-cfg-sm" placeholder="高分" />
              <span style="color:#ccc;">~</span>
              <input v-model.number="qualityThresholds.low" class="mc-cfg-input mc-cfg-sm" placeholder="低分" />
              <button class="mc-cfg-btn-primary" @click="saveQualityThresholds">更新</button>
            </div>
          </div>
          <div v-if="!qualityDims.length" class="mc-empty-list">暂无维度，点击"新增"创建</div>
          <div v-else class="mc-cfg-list">
            <div v-for="d in qualityDims" :key="d.id" class="mc-cfg-row mc-cfg-row-rule" :class="{ 'mc-cfg-row-off': !d.enabled }">
              <div class="mc-cfg-row-body">
                <div class="mc-cfg-row-name">{{ d.display_name }} <span style="font-weight:400;color:#aaa;font-size:12px;">{{ d.dim_key }}</span></div>
                <div class="mc-cfg-row-meta">
                  <span class="mc-cfg-meta-tag">满分 {{ d.max_score }}</span>
                  <span class="mc-cfg-meta-tag">排序 {{ d.sort_order }}</span>
                  <span v-if="!d.enabled" class="mc-cfg-meta-tag mc-cfg-meta-off">已停用</span>
                </div>
              </div>
              <div class="mc-cfg-row-actions">
                <button class="mc-cfg-btn-icon-only" title="编辑" @click="editDim(d)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <button class="mc-cfg-btn-icon-only mc-cfg-btn-icon-only-del" title="删除" @click="delDim(d.id)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 等级矩阵 -->
        <div v-show="configSubTab==='level'" class="mc-config-body">
          <div class="mc-cfg-card mc-cfg-legend-card">
            <div class="mc-cfg-list-title" style="margin-bottom:6px;">裁定说明</div>
            <div class="mc-cfg-legend-row">
              <span class="mc-lvl-chip mc-lvl-published">直接发布</span>
              <span class="mc-lvl-chip mc-lvl-pending">人工审核</span>
              <span class="mc-lvl-chip mc-lvl-draft">存为草稿</span>
              <span class="mc-lvl-chip mc-lvl-block">直接拒绝</span>
            </div>
            <div class="mc-cfg-legend-row" style="margin-top:4px;font-size:10px;color:#aaa;">
              L0~L4 = 用户等级 0~5 · 夜间{{ levelNightInfo }}降 {{ levelNightInfo ? '1' : '?' }} 级 · 命中review敏感词 = 强制审核
            </div>
          </div>

          <div v-if="!levelMatrix.length" class="mc-empty-list">暂无矩阵数据</div>
          <div v-else class="mc-cfg-list">
            <div v-for="m in levelMatrix" :key="m.target_type" class="mc-cfg-row mc-lvl-row">
              <div class="mc-cfg-row-body">
                <div class="mc-cfg-row-name" style="margin-bottom:4px;">{{ m.target_type==='post'?'帖子':m.target_type==='comment'?'评论':m.target_type==='edit'?'编辑':m.target_type==='app'?'应用':'商品' }}</div>
                <div class="mc-lvl-bar">
                  <span v-for="(v,i) in parseLevels(m.levels)" :key="i" :class="['mc-lvl-item', 'mc-lvl-'+lvlColor(v)]">
                    <span class="mc-lvl-lv">L{{ i }}</span>
                    <span class="mc-lvl-val">{{ verdictLabel(v) }}</span>
                  </span>
                </div>
                <div class="mc-lvl-extra">
                  夜间 {{ m.night_start_hour || 0 }}:00~{{ m.night_end_hour || 8 }}:00 降 {{ m.night_level_penalty || 1 }} 级 · review词→{{ verdictLabel(m.review_word_verdict) }}
                </div>
              </div>
              <div class="mc-cfg-row-actions">
                <button class="mc-cfg-btn-icon-only" title="编辑" @click="editLevelMatrix(m)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
              </div>
            </div>
          </div>
          <!-- 编辑等级矩阵弹窗 -->
          <div v-if="levelEdit.target_type" class="mc-overlay" @click.self="closeLevelEdit">
            <div class="mc-dialog">
              <div class="mc-dialog-title">编辑 {{ levelEdit.target_type==='post'?'帖子':levelEdit.target_type==='comment'?'评论':levelEdit.target_type==='edit'?'编辑':levelEdit.target_type==='app'?'应用':'商品' }}</div>
              <label class="mc-label">等级裁定 (5个等级, 逗号分隔)</label>
              <input v-model="levelEdit.levelsStr" class="mc-dialog-input" placeholder="pending,pending,published,published,published" />
              <label class="mc-label">夜间降级数</label>
              <input v-model.number="levelEdit.night_level_penalty" type="number" class="mc-dialog-input" />
              <label class="mc-label">夜间时段 (小时)</label>
              <div style="display:flex;gap:8px;">
                <input v-model.number="levelEdit.night_start_hour" type="number" class="mc-dialog-input" placeholder="0" />
                <input v-model.number="levelEdit.night_end_hour" type="number" class="mc-dialog-input" placeholder="8" />
              </div>
              <label class="mc-label">命中 review 敏感词裁定</label>
              <select v-model="levelEdit.review_word_verdict" class="mc-dialog-input">
                <option value="pending">pending</option>
                <option value="block">block</option>
                <option value="draft">draft</option>
              </select>
              <div class="mc-dialog-actions">
                <button class="mc-cfg-btn-ghost" @click="closeLevelEdit">取消</button>
                <button class="mc-cfg-btn-primary" @click="saveLevelMatrix">保存</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Dialogs -->
    <div v-if="showMenu" class="mc-overlay" @click.self="showMenu=false">
      <div class="mc-dialog">
        <div class="mc-dialog-title">设置</div>
        <button v-for="s in mySections" :key="s.id" class="mc-menu-item" @click="showMenu=false; openSectionSettings(s)">{{ s.name }} — 编辑公告/规则</button>
        <button v-for="s in mySections" :key="'r'+s.id" class="mc-menu-item mc-menu-danger" @click="resignSection(s)">辞去 {{ s.name }} {{ s.role }}</button>
      </div>
    </div>

    <div v-if="rejectDialog.post" class="mc-overlay" @click.self="closeReject">
      <div class="mc-dialog">
        <div class="mc-dialog-title">驳回帖子</div>
        <textarea v-model="rejectDialog.reason" class="mc-dialog-input" placeholder="驳回原因" rows="3"/>
        <div class="mc-dialog-actions">
          <button class="mc-btn mc-btn-ghost" @click="closeReject">取消</button>
          <button class="mc-btn mc-btn-reject" @click="doReject">确认</button>
        </div>
      </div>
    </div>

    <div v-if="approveConfirm.show" class="mc-overlay" @click.self="closeApproveConfirm">
      <div class="mc-dialog">
        <div class="mc-dialog-title">审核通过</div>
        <p class="mc-dialog-text">确认通过帖子「{{ approveConfirm.post?.title }}」？</p>
        <div class="mc-dialog-actions">
          <button class="mc-btn mc-btn-ghost" @click="closeApproveConfirm">取消</button>
          <button class="mc-btn mc-btn-approve" @click="doApprove">确认通过</button>
        </div>
      </div>
    </div>

    <div v-if="ignoreDialog.report" class="mc-overlay" @click.self="closeIgnore">
      <div class="mc-dialog">
        <div class="mc-dialog-title">确认忽略</div><p class="mc-dialog-text">忽略此举报？</p>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeIgnore">取消</button><button class="mc-btn mc-btn-reject" @click="doIgnore">确认</button></div>
      </div>
    </div>

    <div v-if="unlockDialog.req" class="mc-overlay" @click.self="closeUnlock">
      <div class="mc-dialog">
        <div class="mc-dialog-title">{{ unlockDialog.action==='approve'?'通过解锁':'拒绝解锁' }}</div>
        <textarea v-if="unlockDialog.action==='reject'" v-model="unlockDialog.reply" class="mc-dialog-input" placeholder="拒绝原因" rows="2"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeUnlock">取消</button><button class="mc-btn" :class="unlockDialog.action==='approve'?'mc-btn-approve':'mc-btn-reject'" @click="doHandleUnlock">确认</button></div>
      </div>
    </div>

    <div v-if="moveDialog.post" class="mc-overlay" @click.self="closeMove">
      <div class="mc-dialog">
        <div class="mc-dialog-title">移动帖子</div>
        <select v-model="moveDialog.targetId" class="mc-select mc-dialog-select">
          <option :value="0">请选择目标板块</option>
          <option v-for="s in mySections" :value="s.id" :key="s.id">{{ s.name }}</option>
        </select>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeMove">取消</button><button class="mc-btn mc-btn-approve" @click="doMove">确认</button></div>
      </div>
    </div>

    <div v-if="banDialog.show" class="mc-overlay" @click.self="closeBan">
      <div class="mc-dialog">
        <div class="mc-dialog-title">禁言用户</div>
        <input v-model="banDialog.uid" class="mc-dialog-input" placeholder="用户ID" style="margin-bottom:8px"/>
        <input v-model="banDialog.reason" class="mc-dialog-input" placeholder="禁言原因" style="margin-bottom:8px"/>
        <select v-model="banDialog.days" class="mc-select mc-dialog-select">
          <option :value="1">1天</option><option :value="3">3天</option><option :value="7">7天</option><option :value="30">30天</option>
        </select>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeBan">取消</button><button class="mc-btn mc-btn-reject" @click="doBan">确认</button></div>
      </div>
    </div>

    <div v-if="batchDialog" class="mc-overlay" @click.self="batchDialog=''">
      <div class="mc-dialog">
        <div class="mc-dialog-title">{{ batchDialog==='approve'?'批量通过':'批量驳回' }}</div>
        <p class="mc-dialog-text">确认{{ batchDialog==='approve'?'通过':'驳回' }}选中的 {{ selectedIds.length }} 篇帖子？</p>
        <textarea v-if="batchDialog==='reject'" v-model="batchReason" class="mc-dialog-input" placeholder="驳回原因" rows="2"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="batchDialog=''">取消</button><button class="mc-btn" :class="batchDialog==='approve'?'mc-btn-approve':'mc-btn-reject'" @click="doBatch">确认</button></div>
      </div>
    </div>

    <div v-if="editDialog.post" class="mc-overlay" @click.self="closeEdit">
      <div class="mc-dialog" style="max-width:380px">
        <div class="mc-dialog-title">编辑帖子</div>
        <input v-model="editDialog.title" class="mc-dialog-input" placeholder="标题" style="margin-bottom:8px"/>
        <textarea v-model="editDialog.content" class="mc-dialog-input" placeholder="内容" rows="4"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeEdit">取消</button><button class="mc-btn mc-btn-approve" @click="doEdit">保存</button></div>
      </div>
    </div>

    <div v-if="sectionDialog.section" class="mc-overlay" @click.self="closeSection">
      <div class="mc-dialog" style="max-width:380px">
        <div class="mc-dialog-title">板块设置 — {{ sectionDialog.section.name }}</div>
        <label class="mc-label">公告</label>
        <textarea v-model="sectionDialog.announcement" class="mc-dialog-input" rows="3" style="margin-bottom:8px"/>
        <label class="mc-label">规则</label>
        <textarea v-model="sectionDialog.rules" class="mc-dialog-input" rows="3" style="margin-bottom:8px"/>
        <label class="mc-label">Banner图片URL</label>
        <input v-model="sectionDialog.bannerUrl" class="mc-dialog-input" placeholder="https://..." style="margin-bottom:8px"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="closeSection">取消</button><button class="mc-btn mc-btn-approve" @click="doUpdateSection">保存</button></div>
      </div>
    </div>

    <!-- Delete comment dialog -->
    <div v-if="deleteCommentDialog.report" class="mc-overlay" @click.self="closeDeleteComment">
      <div class="mc-dialog">
        <div class="mc-dialog-title">删除评论</div>
        <p class="mc-dialog-text">确定删除这条评论？此操作不可恢复。</p>
        <div class="mc-dialog-actions">
          <button class="mc-btn mc-btn-ghost" @click="closeDeleteComment">取消</button>
          <button class="mc-btn mc-btn-reject" @click="doDeleteComment">确认删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()

const hasAccess = ref(false); const mySections = ref([])
const activeTab = ref('pending')
const showMenu = ref(false); const searchKeyword = ref(''); const selectedIds = ref([])
const loadingPending = ref(false); const loadingReports = ref(false); const loadingUnlocks = ref(false)
const loadingLogs = ref(false); const loadingBans = ref(false); const banSectionId = ref(0)
const batchDialog = ref(''); const batchReason = ref(''); const deleteCommentDialog = reactive({ report:null })

const stats = reactive({ pendingCount:0, reportCount:0, unlockCount:0 })
const extStats = reactive({ todayReviewCount:0, todayReportHandled:0, totalPosts:0, totalComments:0 })
const pendingPosts = ref([]); const reports = ref([]); const unlockRequests = ref([])
const logs = ref([]); const bans = ref([])

const rejectDialog = reactive({ post:null, reason:'' }); const ignoreDialog = reactive({ report:null })
const approveConfirm = reactive({ show:false, post:null })
const unlockDialog = reactive({ req:null, action:'', reply:'' }); const moveDialog = reactive({ post:null, targetId:0 })
const banDialog = reactive({ show:false, uid:'', reason:'', days:7 })
const editDialog = reactive({ post:null, title:'', content:'' })
const sectionDialog = reactive({ section:null, announcement:'', rules:'', bannerUrl:'' })

const filteredPending = computed(() => {
  const arr = Array.isArray(pendingPosts.value) ? pendingPosts.value : []
  if (!searchKeyword.value) return arr
  const kw = searchKeyword.value.toLowerCase()
  return arr.filter(p => (p.title||'').toLowerCase().includes(kw) || (p.userName||'').toLowerCase().includes(kw))
})

const tabs = computed(() => [
  { key:'pending', label:'审核', badge:stats.pendingCount },
  { key:'reports', label:'举报', badge:stats.reportCount },
  { key:'unlocks', label:'解锁', badge:stats.unlockCount },
  { key:'bans', label:'禁言', badge:Array.isArray(bans.value) ? bans.value.length : 0 },
  { key:'logs', label:'日志', badge:0 },
  { key:'config', label:'配置', badge:0 }
])

function fAPI(url, params) { return request.get({ url, params }).catch(e => { console.error(url, e); return null }) }
function pAPI(url, body) { return request.post({ url, data: body }).catch(e => { console.error(url, e); return null }) }
function strip(h) {
  if (!h) return ''
  try {
    const raw = typeof h === 'string' ? h : JSON.stringify(h)
    const t = raw.trim()
    if (t.startsWith('{"type":"doc"')) {
      const doc = JSON.parse(t)
      const texts = []
      const walk = (node) => { if (!node) return; if (node.text) texts.push(String(node.text)); if (node.content && Array.isArray(node.content)) node.content.forEach(walk) }
      walk(doc)
      return texts.join('').replace(/<[^>]+>/g, '')
    }
  } catch {}
  return h.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ')
}
function fmt(t) { if(!t) return ''; const d=new Date(t); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}` }
function pad(n) { return String(n).padStart(2,'0') }
function fixImg(u) { return u || '' }

function actLabel(a) {
  const m={ approve:'通过', reject:'驳回', pin:'置顶', unpin:'取消置顶', essence:'加精', unessence:'取消精华', hot:'热帖', unhot:'取消热帖', lock:'锁定', unlock:'解锁', ignore_report:'忽略举报', delete_post:'删除', move_post:'移动', edit_post:'编辑', ban_user:'禁言', unban_user:'解禁', resign:'辞职', delete_comment:'删评', update_section:'板块设置', approve_unlock:'通过解锁', reject_unlock:'拒绝解锁' }
  return m[a]||a
}

function sectionLabel(id) {
  const s = mySections.value.find(x => x.id===id)
  return s ? s.name : ''
}

function switchTab(k) { activeTab.value=k; if(k==='pending') loadPending(); else if(k==='reports') loadReports(); else if(k==='unlocks') loadUnlocks(); else if(k==='bans') loadBans(); else if(k==='logs') loadLogs(); else if(k==='config') { loadSensitiveWords(); loadModRules(); loadQualityDims(); loadLevelMatrix() } }

function loadStats() { 
  fAPI('/api/community/moderator/stats').then(d=>{ 
    try {
      if(d) {
        stats.pendingCount = d.pendingPosts || 0
        extStats.todayReviewCount = d.todayActions || 0
      }
    } catch(e) {
      console.error('[ModeratorCenter] loadStats error:', e, 'data:', d)
    }
  }).catch(e => console.error('[ModeratorCenter] loadStats api error:', e))
}
function loadExtStats() { 
  fAPI('/api/community/moderator/enhanced-stats').then(d=>{ 
    try {
      if(d) {
        stats.reportCount = d.pendingReports || 0
        extStats.totalPosts = d.totalPosts || 0
        extStats.totalComments = d.totalComments || 0
      }
    } catch(e) {
      console.error('[ModeratorCenter] loadExtStats error:', e, 'data:', d)
    }
  }).catch(e => console.error('[ModeratorCenter] loadExtStats api error:', e))
}

async function loadMySections() {
  try {
    let d = await fAPI('/api/community/moderator/my-sections')
    if (Array.isArray(d) && d.length) { mySections.value=d; hasAccess.value=true; if(!banSectionId.value) banSectionId.value=d[0].id; return }
    d = await fAPI('/api/community/user/'+(userStore.getUserInfo?.userId || 0)+'/moderator-sections')
    if (Array.isArray(d) && d.length) { mySections.value=d.map(x=>({id:x.sectionId,name:x.sectionName,iconBgColor:x.iconBgColor,role:x.role,postCount:0})); hasAccess.value=true }
  } catch(e) {
    console.error('[ModeratorCenter] loadMySections error:', e)
  }
}

function loadPending() {
  loadingPending.value=true
  fAPI('/api/community/admin/posts/pending').then(d=>{
    if (d) {
      const list = d.list
      pendingPosts.value = Array.isArray(list) ? list : (Array.isArray(d) ? d : [])
    }
    loadingPending.value=false
  }).catch(()=>{ loadingPending.value=false })
}

function loadReports() { loadingReports.value=true; fAPI('/api/community/admin/reports').then(d=>{ if(d) reports.value=Array.isArray(d)?d:(d.list||d.data||[]); loadingReports.value=false }).catch(()=>{ loadingReports.value=false }) }
function loadUnlocks() { loadingUnlocks.value=true; fAPI('/api/community/admin/unlock-requests').then(d=>{ if(d) unlockRequests.value=Array.isArray(d)?d:(d.list||d.data||[]); loadingUnlocks.value=false }).catch(()=>{ loadingUnlocks.value=false }) }
function loadLogs() { loadingLogs.value=true; fAPI('/api/community/moderator/logs').then(d=>{ if(d) logs.value=Array.isArray(d)?d:(Array.isArray(d.data)?d.data:[]); loadingLogs.value=false }).catch(()=>{ loadingLogs.value=false }) }

function loadBans() {
  loadingBans.value=true
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  if (!sid) { bans.value=[]; loadingBans.value=false; return }
  fAPI('/api/community/moderator/section/'+sid+'/bans').then(d=>{ if(d) bans.value=Array.isArray(d)?d:(d.list||[]); loadingBans.value=false }).catch(()=>{ loadingBans.value=false })
}

// ==================== Config Panel ====================
const configSubTab = ref('sensitive')
const configSubTabs = [
  { key: 'sensitive', label: '敏感词' },
  { key: 'rules', label: '规则引擎' },
  { key: 'quality', label: '质量评分' },
  { key: 'level', label: '等级矩阵' }
]

const sensitiveWords = ref([])
const swForm = reactive({ id: 0, word: '', level: 'warn', replacement: '' })

function resetSwForm() { swForm.id=0; swForm.word=''; swForm.level='warn'; swForm.replacement='' }
function loadSensitiveWords() {
  fAPI('/api/community/sensitive-words').then(d=>{ if(Array.isArray(d)) sensitiveWords.value=d; else if(d?.data && Array.isArray(d.data)) sensitiveWords.value=d.data }).catch(()=>{})
}
function editSensitiveWord(w) { swForm.id=w.id; swForm.word=w.word; swForm.level=w.level||'warn'; swForm.replacement=w.replacement||'' }
function countByLevel(lv) { return sensitiveWords.value.filter(w=>w.level===lv).length }
async function saveSensitiveWord() {
  if (!swForm.word.trim()) return
  await pAPI('/api/community/sensitive-words', { id: swForm.id||undefined, word: swForm.word, level: swForm.level, replacement: swForm.replacement })
  resetSwForm(); loadSensitiveWords()
}
async function delSensitiveWord(id) {
  if (!confirm('确认删除该敏感词？')) return
  await request.post({ url: '/api/community/sensitive-words/'+id, data: {} })
  loadSensitiveWords()
}

const modRules = ref([])
const ruleFilterType = ref('')
function loadModRules() {
  const params = {}
  if (ruleFilterType.value) params.target_type = ruleFilterType.value
  fAPI('/api/community/moderation-rules', params).then(d=>{ if(Array.isArray(d)) modRules.value=d; else if(d?.data && Array.isArray(d.data)) modRules.value=d.data }).catch(()=>{})
}
async function toggleRule(r) {
  await pAPI('/api/community/moderation-rules/toggle', { id: r.id, enabled: r.enabled ? 0 : 1 })
  loadModRules()
}

function formatRuleConfig(r) {
  try {
    const c = typeof r.config === 'string' ? JSON.parse(r.config) : (r.config || {})
    const parts = []
    if (c.maxCount != null) parts.push(`上限${c.maxCount}次`)
    if (c.windowMinutes != null) parts.push(`窗口${c.windowMinutes}分钟`)
    if (c.maxLinks != null) parts.push(`外链≤${c.maxLinks}`)
    if (c.maxEmoji != null) parts.push(`表情≤${c.maxEmoji}`)
    if (c.minLength != null) parts.push(`最少${c.minLength}字`)
    if (c.threshold != null) parts.push(`相似度>${(c.threshold*100).toFixed(0)}%`)
    if (c.maxAccounts != null) parts.push(`同IP≤${c.maxAccounts}号`)
    return parts.length > 0 ? parts.join(' | ') : ''
  } catch { return '' }
}

const ruleEdit = reactive({})
function editRule(r) {
  Object.assign(ruleEdit, { ...r, isNew: false, config: typeof r.config==='string'?r.config:JSON.stringify(r.config||{},null,2) })
}
function startNewRule() { Object.assign(ruleEdit, { isNew: true, name:'', display_name:'', target_type:'post', action:'pending', config:'{}', priority:0 }) }
function closeRuleEdit() { Object.keys(ruleEdit).forEach(k=>delete ruleEdit[k]) }
async function saveRule() {
  const data = { ...ruleEdit }
  try { data.config = JSON.parse(data.config) } catch {}
  await pAPI('/api/community/moderation-rules', data)
  closeRuleEdit(); loadModRules()
}

// ==================== Quality Score & Level Matrix ====================
const qualityTargetType = ref('post')
const qualityDims = ref([])
const qualityThresholds = reactive({ high: null, low: null })
const levelMatrix = ref([])
const levelEdit = reactive({})

function loadQualityDims() {
  fAPI('/api/community/quality-dims/'+qualityTargetType.value).then(d=>{
    if (d) {
      qualityDims.value = Array.isArray(d.dims) ? d.dims : []
      const t = d.thresholds
      if (t) {
        const map = {}
        if (Array.isArray(t)) t.forEach(x=>{ map[x.config_key] = x.config_value })
        else if (typeof t === 'object') Object.assign(map, t)
        qualityThresholds.high = parseFloat(map.threshold_high) || 0.7
        qualityThresholds.low = parseFloat(map.threshold_low) || 0.4
      }
    }
  }).catch(()=>{})
}
function saveQualityThresholds() {
  pAPI('/api/community/quality-thresholds', { threshold_high: qualityThresholds.high, threshold_low: qualityThresholds.low })
}
function editDim(d) {
  // Not implemented in this version - admin can adjust via DB or future UI
  alert('编辑维度：' + d.display_name + ' (dim_key=' + d.dim_key + ') —— 当前版本请在 DB 中修改 rules JSON')
}
function startNewDim() {
  alert('新增维度请在 DB quality_score_dims 表手动添加')
}
function delDim(id) {
  if (!confirm('确认删除该评分维度？')) return
  request.post({ url: '/api/community/quality-dims/'+id, data: {} }).then(()=>{ loadQualityDims() })
}
function loadLevelMatrix() {
  fAPI('/api/community/level-matrix').then(d=>{ if(d) levelMatrix.value = Array.isArray(d) ? d : (Array.isArray(d.data) ? d.data : []) }).catch(()=>{})
}
function parseLevels(v) {
  try { return typeof v === 'string' ? JSON.parse(v) : (v || []) } catch { return ['pending','pending','published','published','published'] }
}
function verdictLabel(v) {
  const m = { published: '直接发布', pending: '人工审核', pending_review: '待管理审核', draft: '存为草稿', block: '直接拒绝', blocked: '直接拒绝' }
  return m[v] || v
}
function lvlColor(v) {
  if (v==='published') return 'pub'
  if (v==='pending'||v==='pending_review') return 'pending'
  if (v==='draft') return 'draft'
  return 'block'
}
const levelNightInfo = computed(() => {
  if (!levelMatrix.value.length) return ''
  const m = levelMatrix.value[0]
  return (m.night_start_hour != null ? m.night_start_hour : 0) + ':00~' + (m.night_end_hour != null ? m.night_end_hour : 8) + ':00'
})
function editLevelMatrix(m) {
  const lvls = parseLevels(m.levels)
  levelEdit.target_type = m.target_type
  levelEdit.levelsStr = lvls.join(',')
  levelEdit.night_level_penalty = m.night_level_penalty || 1
  levelEdit.night_start_hour = m.night_start_hour || 0
  levelEdit.night_end_hour = m.night_end_hour || 8
  levelEdit.review_word_verdict = m.review_word_verdict || 'pending'
}
function closeLevelEdit() { Object.keys(levelEdit).forEach(k=>delete levelEdit[k]) }
async function saveLevelMatrix() {
  const levels = levelEdit.levelsStr.split(',').map(s=>s.trim()).filter(Boolean)
  await pAPI('/api/community/level-matrix', {
    target_type: levelEdit.target_type,
    levels,
    night_level_penalty: levelEdit.night_level_penalty,
    night_start_hour: levelEdit.night_start_hour,
    night_end_hour: levelEdit.night_end_hour,
    review_word_verdict: levelEdit.review_word_verdict
  })
  closeLevelEdit()
  loadLevelMatrix()
}

function toggleSelect(id) {
  const i = selectedIds.value.indexOf(id)
  if (i>=0) selectedIds.value.splice(i,1); else selectedIds.value.push(id)
}

function filterPending() {}
function viewPost(p) { router.push('/community/post/'+p.id) }

function approvePost(p) { approveConfirm.post=p; approveConfirm.show=true }
function doApprove() { const p=approveConfirm.post; pAPI('/api/community/admin/post/'+p.id+'/approve').then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==p.id); stats.pendingCount=Math.max(0,stats.pendingCount-1); loadExtStats() }; closeApproveConfirm() }).catch(()=>{ closeApproveConfirm() }) }
function closeApproveConfirm() { approveConfirm.show=false; approveConfirm.post=null }
function rejectPost(p) { rejectDialog.post=p; rejectDialog.reason='' }
function doReject() { const p=rejectDialog.post; pAPI('/api/community/admin/post/'+p.id+'/reject',{reason:rejectDialog.reason||'内容不符合规范'}).then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==p.id); stats.pendingCount=Math.max(0,stats.pendingCount-1); loadExtStats() }; closeReject() }).catch(()=>{ closeReject() }) }

function doBatch() {
  if (!selectedIds.value.length) return
  const url = batchDialog.value==='approve' ? '/api/community/moderator/posts/batch-approve' : '/api/community/moderator/posts/batch-reject'
  const body = batchDialog.value==='approve' ? { ids:selectedIds.value } : { ids:selectedIds.value, reason:batchReason.value||'内容不符合规范' }
  pAPI(url, body).then(r=>{ if(r!==null){ selectedIds.value=[]; loadPending(); loadStats(); loadExtStats() }; batchDialog.value=''; batchReason.value='' }).catch(()=>{ batchDialog.value='' })
}

function ignoreReport(r) { ignoreDialog.report=r }
function doIgnore() { pAPI('/api/community/admin/report/ignore/'+ignoreDialog.report.id).then(r=>{ if(r!==null){ reports.value=reports.value.filter(x=>x.id!==ignoreDialog.report.id); stats.reportCount=Math.max(0,stats.reportCount-1); loadExtStats() }; closeIgnore() }).catch(()=>{ closeIgnore() }) }

function deleteComment(r) { deleteCommentDialog.report=r }
function doDeleteComment() {
  const r = deleteCommentDialog.report
  pAPI('/api/community/moderator/comment/'+r.targetId).then(r2=>{
    if(r2!==null){ reports.value=reports.value.filter(x=>x.id!==r.id); stats.reportCount=Math.max(0,stats.reportCount-1) }
    closeDeleteComment()
  }).catch(()=>{ closeDeleteComment() })
}

function openMoveDialog(p) { moveDialog.post=p; moveDialog.targetId=0 }
function doMove() {
  if (!moveDialog.targetId) return
  pAPI('/api/community/moderator/post/'+moveDialog.post.id+'/move',{targetSectionId:moveDialog.targetId}).then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==moveDialog.post.id); stats.pendingCount=Math.max(0,stats.pendingCount-1) }; closeMove() })
}

function openEditDialog(p) { editDialog.post=p; editDialog.title=p.title||''; editDialog.content=textContent(p.content)||'' }
function closeReject() { rejectDialog.post=null; rejectDialog.reason='' }
function closeIgnore() { ignoreDialog.report=null }
function closeUnlock() { unlockDialog.req=null; unlockDialog.action=''; unlockDialog.reply='' }
function closeMove() { moveDialog.post=null; moveDialog.targetId=0 }
function closeBan() { banDialog.show=false; banDialog.uid=''; banDialog.reason=''; banDialog.days=7 }
function closeEdit() { editDialog.post=null; editDialog.title=''; editDialog.content='' }
function closeSection() { sectionDialog.section=null; sectionDialog.announcement=''; sectionDialog.rules=''; sectionDialog.bannerUrl='' }
function closeDeleteComment() { deleteCommentDialog.report=null }
function textContent(h) { // parse both HTML and Tiptap JSON
  if (!h) return ''
  try { const s = String(h).trim(); if (s.startsWith('{"type":"doc"')) { const doc=JSON.parse(s); const t=[]; const w=(n)=>{if(!n)return;if(n.text)t.push(String(n.text));if(n.content&&Array.isArray(n.content))n.content.forEach(w)}; w(doc); return t.join('') } } catch {}
  return String(h).replace(/<[^>]+>/g,'')
}
function doEdit() { pAPI('/api/community/moderator/post/'+editDialog.post.id+'/edit',{title:editDialog.title,content:editDialog.content}).then(r=>{ if(r!==null) loadPending(); closeEdit() }) }

function openBanDialog() { banDialog.show=true; banDialog.uid=''; banDialog.reason=''; banDialog.days=7 }
function doBan() {
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  pAPI('/api/community/moderator/section/'+sid+'/ban',{bannedUserId:Number(banDialog.uid),reason:banDialog.reason,days:banDialog.days}).then(r=>{ if(r!==null) loadBans(); closeBan() })
}

function unbanUser(b) {
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  pAPI('/api/community/moderator/section/'+sid+'/ban/'+b.bannedUserId).then(r=>{ if(r!==null) loadBans() })
}

function handleUnlock(ur, a) { unlockDialog.req=ur; unlockDialog.action=a; unlockDialog.reply='' }
function doHandleUnlock() { const ur=unlockDialog.req; pAPI('/api/community/admin/unlock-request/'+ur.id+'/handle',{action:unlockDialog.action,reply:unlockDialog.reply}).then(r=>{ if(r!==null){ unlockRequests.value=unlockRequests.value.filter(u=>u.id!==ur.id); stats.unlockCount=Math.max(0,stats.unlockCount-1) }; closeUnlock() }).catch(()=>{ closeUnlock() }) }

async function openSectionSettings(s) {
  sectionDialog.section=s
  const info = await fAPI('/api/community/section/'+s.id+'/info')
  if (info) { sectionDialog.announcement=info.announcement||''; sectionDialog.rules=info.rules||''; sectionDialog.bannerUrl=info.bannerUrl||'' }
}

function doUpdateSection() {
  pAPI('/api/community/moderator/section/'+sectionDialog.section.id+'/update-info',{
    announcement:sectionDialog.announcement, rules:sectionDialog.rules, bannerUrl:sectionDialog.bannerUrl
  }).then(r=>{ if(r!==null) closeSection() })
}

async function resignSection(s) {
  if (!confirm('确定辞去「'+s.name+'」的'+s.role+'职务？')) return
  await pAPI('/api/community/moderator/resign/'+s.id)
  loadMySections().then(()=>{ if(!mySections.value.length) hasAccess.value=false; loadStats(); loadExtStats() })
}

onMounted(async ()=>{
  try {
    await loadMySections()
    if (hasAccess.value) { loadStats(); loadExtStats(); loadPending() }
  } catch(e) {
    console.error('[ModeratorCenter] onMounted error:', e)
  }
})
</script>

<style scoped>
.mc-page { min-height:100vh; background:#f5f5f8; padding-bottom:80px; }

/* Navbar */
.mc-navbar { display:flex; align-items:center; padding:14px 16px; padding-top:calc(14px + env(safe-area-inset-top,0px)); background:#fff; position:sticky; top:0; z-index:10; }
.mc-nav-back { background:none; border:none; color:#555; cursor:pointer; padding:6px; display:flex; align-items:center; border-radius:10px; transition:background .15s; }
.mc-nav-back:active { background:#f0f0f5; }
.mc-nav-title { flex:1; text-align:center; font-size:18px; font-weight:700; color:#1a1a2e; letter-spacing:-.2px; }
.mc-nav-more { background:none; border:none; color:#999; cursor:pointer; padding:6px; border-radius:10px; }

/* Empty state */
.mc-empty { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:120px 24px; }
.mc-empty-icon { width:88px; height:88px; border-radius:50%; background:#f0f0f5; display:flex; align-items:center; justify-content:center; margin-bottom:20px; color:#bbb; }
.mc-empty-title { font-size:17px; font-weight:700; color:#999; margin:0 0 8px; }
.mc-empty-desc { font-size:13px; color:#bbb; margin:0; text-align:center; max-width:260px; line-height:1.5; }

.mc-body { padding:16px; }

/* Stats */
.mc-stats-row { display:flex; gap:10px; margin-bottom:10px; }
.mc-stat { flex:1; background:#fff; border-radius:14px; padding:12px 6px 10px; text-align:center; cursor:pointer; box-shadow:0 1px 3px rgba(0,0,0,.04); transition:all .15s; }
.mc-stat:active { transform:scale(.96); }
.mc-stat-icon { width:28px; height:28px; border-radius:10px; margin:0 auto 6px; display:flex; align-items:center; justify-content:center; }
.mc-stat-icon svg { width:15px; height:15px; }
.mc-stat-num { font-size:22px; font-weight:800; color:#1a1a2e; line-height:1; }
.mc-stat-label { font-size:10px; color:#999; margin-top:2px; font-weight:500; }
.mc-stats-sub { display:flex; justify-content:space-between; font-size:11px; color:#b0b0b8; padding:2px 6px 16px; }

/* Section info */
.mc-section-info { display:flex; flex-wrap:wrap; align-items:center; gap:8px; margin-bottom:14px; padding:12px 14px; background:#fff; border-radius:14px; box-shadow:0 1px 3px rgba(0,0,0,.04); }
.mc-section-label { font-size:12px; color:#999; font-weight:500; flex-shrink:0; }
.mc-section-tag { display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:20px; font-size:12px; color:#fff; cursor:pointer; font-weight:500; transition:transform .15s,opacity .15s; }
.mc-section-tag:active { transform:scale(.95); opacity:.85; }
.mc-section-tag-icon { width:18px; height:18px; border-radius:50%; object-fit:cover; border:1.5px solid rgba(255,255,255,.3); }

/* Tabs */
.mc-tabs { display:flex; background:#fff; border-radius:14px; overflow-x:auto; margin-bottom:14px; box-shadow:0 1px 3px rgba(0,0,0,.04); padding:3px; }
.mc-tab { flex:1; min-width:fit-content; padding:10px 0; text-align:center; border:none; background:none; font-size:13px; color:#999; cursor:pointer; position:relative; white-space:nowrap; font-weight:600; border-radius:11px; transition:all .2s; }
.mc-tab.on { background:#6366F1; color:#fff; box-shadow:0 2px 6px rgba(99,102,241,.3); }
.mc-tab-badge { position:absolute; top:1px; right:4px; min-width:16px; height:16px; line-height:16px; font-size:9px; background:#EF4444; color:#fff; border-radius:8px; padding:0 5px; font-weight:700; }

/* Toolbar */
.mc-toolbar { display:flex; gap:8px; margin-bottom:12px; align-items:center; }
.mc-search { flex:1; min-width:120px; padding:10px 14px; border:1.5px solid #ebeef2; border-radius:12px; font-size:13px; outline:none; background:#fff; transition:all .2s; }
.mc-search:focus { border-color:#6366F1; box-shadow:0 0 0 3px rgba(99,102,241,.08); }

.mc-content { min-height:150px; }
.mc-list { display:flex; flex-direction:column; gap:10px; }
.mc-empty-list { text-align:center; padding:60px 0; color:#bbb; font-size:14px; }

/* Cards */
.mc-card { background:#fff; border-radius:16px; padding:16px; box-shadow:0 1px 3px rgba(0,0,0,.04); display:flex; gap:12px; transition:all .15s; border:1.5px solid transparent; }
.mc-card:active { box-shadow:0 1px 4px rgba(0,0,0,.06); }
.mc-card.selected { border-color:#6366F1; box-shadow:0 0 0 1px rgba(99,102,241,.15); }
.mc-card-log { padding:12px 14px; }
.mc-card-check { display:flex; align-items:flex-start; padding-top:3px; flex-shrink:0; }
.mc-checkbox { width:22px; height:22px; border:2px solid #d5d5dd; border-radius:7px; display:flex; align-items:center; justify-content:center; color:#fff; cursor:pointer; transition:all .15s; }
.mc-checkbox.on { background:#6366F1; border-color:#6366F1; }
.mc-card-body { flex:1; min-width:0; }
.mc-card-header { display:flex; align-items:center; gap:8px; margin-bottom:8px; }
.mc-card-avatar { width:28px; height:28px; border-radius:50%; object-fit:cover; }
.mc-card-avatar-plc { width:28px; height:28px; border-radius:50%; background:linear-gradient(135deg,#6366F1,#8B5CF6); color:#fff; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700; flex-shrink:0; }
.mc-card-avatar-plc-ban { width:32px; height:32px; background:linear-gradient(135deg,#EF4444,#F97316); }
.mc-card-username { font-size:13px; font-weight:600; color:#1a1a2e; }
.mc-card-time { font-size:11px; color:#bbb; margin-left:auto; white-space:nowrap; }
.mc-card-section-tag { font-size:10px; padding:3px 8px; background:#EEF2FF; color:#6366F1; border-radius:8px; font-weight:500; white-space:nowrap; }
.mc-card-type-badge { font-size:10px; padding:3px 8px; border-radius:8px; font-weight:700; }
.mc-card-type-post { background:#EEF2FF; color:#6366F1; }
.mc-card-type-comment { background:#FEF3C7; color:#B45309; }
.mc-card-ban-status { font-size:10px; padding:3px 8px; border-radius:8px; font-weight:600; margin-left:auto; }
.mc-card-ban-active { background:#FEE2E2; color:#DC2626; }
.mc-card-ban-expired { background:#f3f4f6; color:#999; }
.mc-card-title { font-size:15px; font-weight:700; color:#1a1a2e; margin-bottom:6px; line-height:1.4; cursor:pointer; }
.mc-card-title-sm { font-size:14px; }
.mc-card-content { font-size:13px; color:#777; line-height:1.5; margin-bottom:8px; word-break:break-word; }
.mc-card-quote { font-size:12px; color:#999; padding:8px 12px; background:#f8f8fc; border-radius:8px; border-left:3px solid #e0e0e8; margin-bottom:8px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-card-images { display:flex; gap:6px; margin-bottom:8px; overflow-x:auto; }
.mc-card-img { width:72px; height:72px; border-radius:10px; object-fit:cover; flex-shrink:0; }
.mc-card-actions { display:flex; gap:6px; flex-wrap:wrap; }

/* Buttons */
.mc-btn { padding:7px 14px; border-radius:10px; border:none; font-size:12px; cursor:pointer; font-weight:600; white-space:nowrap; transition:all .15s; }
.mc-btn:active { transform:scale(.95); }
.mc-btn-approve { background:#6366F1; color:#fff; }
.mc-btn-approve:active { background:#4F46E5; }
.mc-btn-primary { background:linear-gradient(135deg,#6366F1,#8B5CF6); color:#fff; }
.mc-btn-reject { background:#FEE2E2; color:#EF4444; }
.mc-btn-reject:active { background:#FECACA; }
.mc-btn-outline { background:#fff; color:#666; border:1.5px solid #e5e7eb; }
.mc-btn-outline:active { background:#f9fafb; }
.mc-btn-ghost { background:#f3f4f6; color:#666; }

/* Select */
.mc-select { padding:8px 12px; border:1.5px solid #ebeef2; border-radius:10px; font-size:13px; background:#fff; outline:none; transition:border-color .2s; }
.mc-select:focus { border-color:#6366F1; }

/* Log badge */
.mc-log-badge { font-size:10px; padding:3px 8px; border-radius:8px; font-weight:700; white-space:nowrap; text-transform:uppercase; }
.mc-log-badge-ok { background:#ECFDF5; color:#059669; }
.mc-log-badge-bad { background:#FEE2E2; color:#DC2626; }
.mc-log-badge-info { background:#EEF2FF; color:#6366F1; }

.mc-overlay { position:fixed; inset:0; background:rgba(0,0,0,.45); backdrop-filter:blur(2px); display:flex; align-items:center; justify-content:center; z-index:100; padding:24px; }
.mc-dialog { background:#fff; border-radius:16px; padding:24px; width:100%; max-width:340px; max-height:80vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,.15); }
.mc-dialog-title { font-size:17px; font-weight:700; color:#1a1a2e; margin-bottom:16px; text-align:center; }
.mc-dialog-text { font-size:14px; color:#777; margin-bottom:14px; text-align:center; }
.mc-dialog-input { width:100%; border:1.5px solid #ebeef2; border-radius:10px; padding:10px 12px; font-size:13px; outline:none; box-sizing:border-box; resize:vertical; transition:border-color .2s; }
.mc-dialog-input:focus { border-color:#6366F1; }
.mc-dialog-select { width:100%; margin-bottom:10px; }
.mc-dialog-actions { display:flex; gap:10px; justify-content:flex-end; margin-top:18px; }
.mc-label { font-size:12px; color:#999; display:block; margin-bottom:4px; font-weight:500; }
.mc-menu-item { display:block; width:100%; text-align:left; border:none; background:none; padding:12px 0; font-size:14px; color:#333; cursor:pointer; border-bottom:1px solid #f0f0f0; border-radius:0; }
.mc-menu-item:active { background:#f7f7fa; }
.mc-menu-danger { color:#EF4444; font-weight:600; }

/* Config Panel */
.mc-config-tabs { display:flex; gap:3px; margin-bottom:8px; background:#f3f4f6; border-radius:10px; padding:2px; }
.mc-config-tab { flex:1; border:none; background:transparent; color:#888; font-size:13px; padding:7px 0; border-radius:9px; cursor:pointer; font-weight:600; transition:all .2s; }
.mc-config-tab.on { background:#fff; color:#6366F1; box-shadow:0 1px 2px rgba(0,0,0,.06); }
.mc-config-body { display:flex; flex-direction:column; gap:4px; }

/* Toolbar (add row) */
.mc-cfg-toolbar { display:flex; gap:4px; align-items:center; background:#fff; border-radius:10px; padding:6px 8px; box-shadow:0 1px 2px rgba(0,0,0,.03); }
.mc-cfg-toolbar-info { font-size:11px; color:#aaa; white-space:nowrap; }
.mc-cfg-card { background:#fff; border-radius:10px; padding:8px; box-shadow:0 1px 2px rgba(0,0,0,.03); margin-bottom:4px; }
.mc-cfg-add-row { display:flex; gap:6px; align-items:center; }

/* Inputs */
.mc-cfg-input-wrap { flex:1; position:relative; }
.mc-cfg-input-icon { position:absolute; left:8px; top:50%; transform:translateY(-50%); width:12px; height:12px; color:#bbb; pointer-events:none; }
.mc-cfg-input { flex:1; min-width:60px; border:1.5px solid #ebeef2; border-radius:7px; padding:7px 8px; font-size:13px; outline:none; background:#fafbfc; transition:all .2s; box-sizing:border-box; width:100%; }
.mc-cfg-input-has-icon { padding-left:26px; }
.mc-cfg-input:focus { border-color:#6366F1; background:#fff; box-shadow:0 0 0 2px rgba(99,102,241,.06); }
.mc-cfg-sm { width:56px; flex:0 0 56px; }
.mc-cfg-select { border:1.5px solid #ebeef2; border-radius:7px; padding:7px 4px; font-size:12px; outline:none; background:#fafbfc; transition:all .2s; }
.mc-cfg-select:focus { border-color:#6366F1; background:#fff; }

/* Buttons */
.mc-cfg-btn-icon { width:13px; height:13px; margin-right:2px; vertical-align:-1px; flex-shrink:0; }
.mc-cfg-btn-primary { display:inline-flex; align-items:center; gap:1px; border:none; background:linear-gradient(135deg,#6366F1,#8B5CF6); color:#fff; font-size:12px; padding:7px 10px; border-radius:7px; cursor:pointer; white-space:nowrap; font-weight:600; box-shadow:0 1px 4px rgba(99,102,241,.2); transition:all .15s; }
.mc-cfg-btn-primary:active { transform:scale(.96); opacity:.85; }
.mc-cfg-btn-ghost { border:none; background:#f3f4f6; color:#777; font-size:12px; padding:7px 8px; border-radius:7px; cursor:pointer; white-space:nowrap; font-weight:500; }

/* Icon-only buttons */
.mc-cfg-btn-icon-only { display:flex; align-items:center; justify-content:center; width:26px; height:26px; border:1.5px solid #e8e8f0; background:#fff; color:#aaa; border-radius:7px; cursor:pointer; transition:all .15s; padding:0; }
.mc-cfg-btn-icon-only svg { width:13px; height:13px; }
.mc-cfg-btn-icon-only:hover { background:#EEF2FF; color:#6366F1; border-color:#6366F1; }
.mc-cfg-btn-icon-only:active { transform:scale(.92); }
.mc-cfg-btn-icon-only-del:hover { background:#FEE2E2; color:#EF4444; border-color:#EF4444; }

/* List */
.mc-cfg-list { display:flex; flex-direction:column; gap:0; }
.mc-cfg-list-head { display:flex; justify-content:space-between; align-items:center; padding:0 4px 4px; }
.mc-cfg-list-title { font-size:11px; color:#999; font-weight:600; letter-spacing:.3px; }
.mc-cfg-list-stats { display:flex; gap:4px; }
.mc-cfg-stat-chip { font-size:9px; padding:1px 6px; border-radius:4px; font-weight:600; }
.mc-cfg-stat-chip-block { background:#FEE2E2; color:#DC2626; }
.mc-cfg-stat-chip-review { background:#FEF3C7; color:#B45309; }
.mc-cfg-stat-chip-warn { background:#DBEAFE; color:#2563EB; }

/* List rows */
.mc-cfg-row { display:flex; align-items:center; padding:5px 8px; background:#fff; border-radius:8px; gap:6px; transition:all .15s; border:1px solid transparent; }
.mc-cfg-row:hover { border-color:#e8e8f0; }
.mc-cfg-row-lvl-block { border-left:2px solid #EF4444; }
.mc-cfg-row-lvl-review { border-left:2px solid #F59E0B; }
.mc-cfg-row-lvl-warn { border-left:2px solid #3B82F6; }
.mc-cfg-row-off { opacity:.4; }
.mc-cfg-row-rule { align-items:flex-start; }
.mc-cfg-row-idx { width:14px; text-align:center; font-size:10px; color:#d0d0d8; font-weight:400; flex-shrink:0; }
.mc-cfg-row-body { flex:1; min-width:0; }
.mc-cfg-row-word { font-size:13px; font-weight:600; color:#1a1a2e; }
.mc-cfg-row-name { font-size:13px; font-weight:600; color:#1a1a2e; margin-bottom:1px; }
.mc-cfg-row-replace { font-size:11px; color:#6366F1; background:#EEF2FF; padding:1px 7px; border-radius:6px; font-weight:500; margin-left:6px; }
.mc-cfg-row-tag { font-size:9px; padding:1px 6px; border-radius:5px; font-weight:700; white-space:nowrap; }
.mc-cfg-row-tag-block { background:#FEE2E2; color:#DC2626; }
.mc-cfg-row-tag-review { background:#FEF3C7; color:#B45309; }
.mc-cfg-row-tag-warn { background:#DBEAFE; color:#2563EB; }
.mc-cfg-row-desc-inline { font-size:11px; color:#bbb; }
.mc-cfg-row-meta { display:flex; gap:4px; flex-wrap:wrap; align-items:center; }
.mc-cfg-row-actions { display:flex; align-items:center; gap:4px; flex-shrink:0; margin-left:auto; }

/* Meta tags */
.mc-cfg-meta-tag { font-size:10px; padding:2px 7px; border-radius:5px; font-weight:500; background:#f3f4f6; color:#666; }
.mc-cfg-meta-block { background:#FEE2E2; color:#DC2626; font-weight:600; }
.mc-cfg-meta-pending { background:#FEF3C7; color:#B45309; font-weight:600; }
.mc-cfg-meta-prio { background:#EEF2FF; color:#6366F1; font-weight:600; }
.mc-cfg-meta-off { background:#f3f4f6; color:#bbb; }

/* Switch */
.mc-switch { position:relative; display:inline-block; width:42px; height:24px; flex-shrink:0; }
.mc-switch input { opacity:0; width:0; height:0; }
.mc-switch-slider { position:absolute; top:0;left:0;right:0;bottom:0; background:#d5d8df; border-radius:24px; cursor:pointer; transition:.2s; }
.mc-switch-slider::before { content:''; position:absolute; height:18px; width:18px; left:3px; bottom:3px; background:#fff; border-radius:50%; transition:.2s; box-shadow:0 1px 2px rgba(0,0,0,.12); }
.mc-switch input:checked+.mc-switch-slider { background:#6366F1; }
.mc-switch input:checked+.mc-switch-slider::before { transform:translateX(18px); }

/* Level matrix legend */
.mc-cfg-legend-card { padding:10px 12px; }
.mc-cfg-legend-row { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }

/* Level legend chips */
.mc-lvl-chip { font-size:10px; padding:3px 10px; border-radius:12px; font-weight:600; }
.mc-lvl-chip.mc-lvl-published { background:#ECFDF5; color:#059669; }
.mc-lvl-chip.mc-lvl-pending { background:#EEF2FF; color:#6366F1; }
.mc-lvl-chip.mc-lvl-draft { background:#FEF3C7; color:#B45309; }
.mc-lvl-chip.mc-lvl-block { background:#FEE2E2; color:#DC2626; }

/* Level bar */
.mc-lvl-row { align-items:flex-start; padding:10px 12px; }
.mc-lvl-bar { display:flex; gap:4px; margin-top:4px; }
.mc-lvl-item { flex:1; text-align:center; padding:5px 2px; border-radius:8px; font-size:10px; display:flex; flex-direction:column; gap:2px; }
.mc-lvl-lv { font-weight:700; font-size:9px; opacity:.6; }
.mc-lvl-val { font-weight:600; }
.mc-lvl-pub { background:#ECFDF5; color:#059669; }
.mc-lvl-pending { background:#EEF2FF; color:#6366F1; }
.mc-lvl-draft { background:#FEF3C7; color:#B45309; }
.mc-lvl-block { background:#FEE2E2; color:#DC2626; }
.mc-lvl-extra { font-size:10px; color:#bbb; margin-top:6px; }
</style>
