<template>
  <div class="mc-page">
    <div class="mc-navbar">
      <button class="mc-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="mc-nav-title">版主中心</span>
      <button class="mc-nav-more" @click="showMenu = !showMenu" v-if="hasAccess">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
      </button>
    </div>

    <div v-if="!hasAccess" class="mc-empty">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
      <p>无版主权限</p>
      <p class="mc-empty-desc">您不是任何板块的版主或审核员，无法访问版主中心。</p>
    </div>

    <div v-else class="mc-body">
      <!-- Enhanced stats -->
      <div class="mc-stats-row">
        <div class="mc-stat" @click="activeTab='pending'">
          <div class="mc-stat-num">{{ stats.pendingCount }}</div><div class="mc-stat-label">待审核</div>
        </div>
        <div class="mc-stat mc-stat-warn" @click="activeTab='reports'">
          <div class="mc-stat-num">{{ stats.reportCount }}</div><div class="mc-stat-label">举报</div>
        </div>
        <div class="mc-stat mc-stat-info" @click="activeTab='unlocks'">
          <div class="mc-stat-num">{{ stats.unlockCount }}</div><div class="mc-stat-label">解锁</div>
        </div>
        <div class="mc-stat mc-stat-green" @click="activeTab='bans'">
          <div class="mc-stat-num">{{ bans.length }}</div><div class="mc-stat-label">禁言</div>
        </div>
      </div>
      <div class="mc-stats-sub">
        <span>今日审核 {{ extStats.todayReviewCount || 0 }} | 处理举报 {{ extStats.todayReportHandled || 0 }}</span>
        <span class="mc-stats-sub-right">总帖 {{ extStats.totalPosts || 0 }} | 总评 {{ extStats.totalComments || 0 }}</span>
      </div>

      <div class="mc-section-info" v-if="mySections.length">
        <span class="mc-section-label">我的板块：</span>
        <span v-for="s in mySections" :key="s.id" class="mc-section-tag" :style="{ background: s.iconBgColor || '#6366F1' }" @click="openSectionSettings(s)">
          <img v-if="s.icon" :src="fixImg(s.icon)" class="mc-section-tag-icon" />
          {{ s.name }}<span class="mc-section-role">{{ s.role }}</span>
        </span>
      </div>

      <!-- Tabs -->
      <div class="mc-tabs">
        <button v-for="t in tabs" :key="t.key" class="mc-tab" :class="{ on: activeTab===t.key }" @click="switchTab(t.key)">
          {{ t.label }}<span v-if="t.badge>0" class="mc-tab-badge">{{ t.badge }}</span>
        </button>
      </div>

      <!-- Pending posts -->
      <div v-if="activeTab==='pending'" class="mc-content">
        <div class="mc-toolbar" v-if="pendingPosts.length">
          <input v-model="searchKeyword" class="mc-search" placeholder="搜索标题..." @input="filterPending" />
          <button v-if="selectedIds.length" class="mc-btn mc-btn-sm mc-btn-approve" @click="batchDialog='approve'">批量通过({{selectedIds.length}})</button>
          <button v-if="selectedIds.length" class="mc-btn mc-btn-sm mc-btn-reject" @click="batchDialog='reject'">批量驳回</button>
        </div>
        <div class="mc-list">
          <div v-if="!filteredPending.length && !loadingPending" class="mc-empty-list">暂无待审核帖子</div>
          <div v-for="post in filteredPending" :key="post.id" class="mc-card" :class="{ selected: selectedIds.includes(post.id) }">
            <div class="mc-card-check" @click="toggleSelect(post.id)">
              <div class="mc-checkbox" :class="{ on: selectedIds.includes(post.id) }">{{ selectedIds.includes(post.id) ? '&#10003;' : '' }}</div>
            </div>
            <div class="mc-card-body-wrap">
              <div class="mc-card-header">
                <img v-if="post.userAvatar" :src="fixImg(post.userAvatar)" class="mc-card-avatar" />
                <span v-else class="mc-card-avatar-plc">{{ post.userName?.charAt(0)||'?' }}</span>
                <span class="mc-card-username">{{ post.userName||'匿名' }}</span>
                <span class="mc-card-time">{{ fmt(post.createTime) }}</span>
                <span v-if="post.sectionId" class="mc-card-section-tag">{{ sectionLabel(post.sectionId) }}</span>
              </div>
              <div class="mc-card-title" @click="viewPost(post)">{{ post.title }}</div>
              <div class="mc-card-content" v-if="post.content">{{ strip(post.content).substring(0,150) }}</div>
              <div class="mc-card-images" v-if="post.images&&post.images.length">
                <img v-for="(img,i) in post.images.slice(0,4)" :src="fixImg(img)" class="mc-card-img" :key="i" />
              </div>
              <div class="mc-card-actions">
                <button class="mc-btn mc-btn-approve" @click="approvePost(post)">通过</button>
                <button class="mc-btn mc-btn-reject" @click="rejectPost(post)">驳回</button>
                <button class="mc-btn mc-btn-view" @click="viewPost(post)">详情</button>
                <button class="mc-btn mc-btn-ghost" @click="openMoveDialog(post)">移动</button>
                <button class="mc-btn mc-btn-ghost" @click="openEditDialog(post)">编辑</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Reports -->
      <div v-if="activeTab==='reports'" class="mc-content">
        <div class="mc-list">
          <div v-if="!reports.length && !loadingReports" class="mc-empty-list">暂无待处理举报</div>
          <div v-for="r in reports" :key="r.id" class="mc-card">
            <div class="mc-card-header">
              <span class="mc-report-badge">{{ r.targetType==='post'?'帖子':'评论' }}</span>
              <span class="mc-card-username">{{ r.reporterName||'匿名' }}</span>
              <span class="mc-card-time">{{ fmt(r.createTime) }}</span>
            </div>
            <div class="mc-card-title">{{ r.reportReason }}</div>
            <div class="mc-card-content" v-if="r.reportDetail">{{ r.reportDetail }}</div>
            <div class="mc-card-target">{{ r.targetTitle||'内容已删除' }}</div>
            <div class="mc-card-actions">
              <button class="mc-btn mc-btn-approve" @click="ignoreReport(r)">忽略</button>
              <button class="mc-btn mc-btn-reject" @click="r.targetType==='comment' ? deleteComment(r) : viewPost({id: r.targetId})">
                {{ r.targetType==='comment' ? '删评论' : '处理帖子' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Unlock requests -->
      <div v-if="activeTab==='unlocks'" class="mc-content">
        <div class="mc-list">
          <div v-if="!unlockRequests.length && !loadingUnlocks" class="mc-empty-list">暂无解锁申请</div>
          <div v-for="ur in unlockRequests" :key="ur.id" class="mc-card">
            <div class="mc-card-title">申请解锁：{{ ur.postTitle||'未知' }}</div>
            <div class="mc-card-content" v-if="ur.reason">{{ ur.reason }}</div>
            <div class="mc-card-actions">
              <button class="mc-btn mc-btn-approve" @click="handleUnlock(ur,'approve')">通过</button>
              <button class="mc-btn mc-btn-reject" @click="handleUnlock(ur,'reject')">拒绝</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Ban management -->
      <div v-if="activeTab==='bans'" class="mc-content">
        <div class="mc-section-select" v-if="mySections.length>1">
          <span class="mc-section-label">选择板块：</span>
          <select v-model="banSectionId" class="mc-select" @change="loadBans">
            <option :value="0">全部板块</option>
            <option v-for="s in mySections" :value="s.id" :key="s.id">{{ s.name }}</option>
          </select>
        </div>
        <div class="mc-toolbar">
          <button class="mc-btn mc-btn-sm mc-btn-reject" @click="openBanDialog()">+ 禁言用户</button>
        </div>
        <div class="mc-list">
          <div v-if="!bans.length && !loadingBans" class="mc-empty-list">暂无禁言记录</div>
          <div v-for="b in bans" :key="b.id" class="mc-card">
            <div>{{ b.bannedUserName }} — {{ b.reason||'无原因' }}</div>
            <div class="mc-card-time">至 {{ fmt(b.banUntil) }} | {{ b.isActive ? '生效中' : '已解除' }}</div>
            <button v-if="b.isActive" class="mc-btn mc-btn-approve" style="margin-top:6px" @click="unbanUser(b)">解除禁言</button>
          </div>
        </div>
      </div>

      <!-- Logs -->
      <div v-if="activeTab==='logs'" class="mc-content">
        <div class="mc-list mc-logs">
          <div v-if="!logs.length && !loadingLogs" class="mc-empty-list">暂无操作记录</div>
          <div v-for="l in logs" :key="l.id" class="mc-log-item">
            <span class="mc-log-action">{{ actLabel(l.action) }}</span>
            <span class="mc-log-detail">{{ l.detail }}</span>
            <span class="mc-log-time">{{ fmt(l.createTime) }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Dialogs -->
    <div v-if="showMenu" class="mc-overlay" @click.self="showMenu=false">
      <div class="mc-dialog">
        <div class="mc-dialog-title">设置</div>
        <button v-for="s in mySections" :key="s.id" class="mc-menu-item" @click="showMenu=false; openSectionSettings(s)">{{ s.name }} — 编辑公告/规则</button>
        <button v-for="s in mySections" :key="'r'+s.id" class="mc-menu-item mc-menu-danger" @click="resignSection(s)">辞去 {{ s.name }} {{ s.role }}</button>
      </div>
    </div>

    <div v-if="rejectDialog.post" class="mc-overlay" @click.self="rejectDialog={}">
      <div class="mc-dialog">
        <div class="mc-dialog-title">驳回帖子</div>
        <textarea v-model="rejectDialog.reason" class="mc-dialog-input" placeholder="驳回原因" rows="3"/>
        <div class="mc-dialog-actions">
          <button class="mc-btn mc-btn-ghost" @click="rejectDialog={}">取消</button>
          <button class="mc-btn mc-btn-reject" @click="doReject">确认</button>
        </div>
      </div>
    </div>

    <div v-if="ignoreDialog.report" class="mc-overlay" @click.self="ignoreDialog={}">
      <div class="mc-dialog">
        <div class="mc-dialog-title">确认忽略</div><p class="mc-dialog-text">忽略此举报？</p>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="ignoreDialog={}">取消</button><button class="mc-btn mc-btn-reject" @click="doIgnore">确认</button></div>
      </div>
    </div>

    <div v-if="unlockDialog.req" class="mc-overlay" @click.self="unlockDialog={}">
      <div class="mc-dialog">
        <div class="mc-dialog-title">{{ unlockDialog.action==='approve'?'通过解锁':'拒绝解锁' }}</div>
        <textarea v-if="unlockDialog.action==='reject'" v-model="unlockDialog.reply" class="mc-dialog-input" placeholder="拒绝原因" rows="2"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="unlockDialog={}">取消</button><button class="mc-btn" :class="unlockDialog.action==='approve'?'mc-btn-approve':'mc-btn-reject'" @click="doHandleUnlock">确认</button></div>
      </div>
    </div>

    <div v-if="moveDialog.post" class="mc-overlay" @click.self="moveDialog={}">
      <div class="mc-dialog">
        <div class="mc-dialog-title">移动帖子</div>
        <select v-model="moveDialog.targetId" class="mc-select mc-dialog-select">
          <option :value="0">请选择目标板块</option>
          <option v-for="s in mySections" :value="s.id" :key="s.id">{{ s.name }}</option>
        </select>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="moveDialog={}">取消</button><button class="mc-btn mc-btn-approve" @click="doMove">确认</button></div>
      </div>
    </div>

    <div v-if="banDialog.show" class="mc-overlay" @click.self="banDialog={}">
      <div class="mc-dialog">
        <div class="mc-dialog-title">禁言用户</div>
        <input v-model="banDialog.uid" class="mc-dialog-input" placeholder="用户ID" style="margin-bottom:8px"/>
        <input v-model="banDialog.reason" class="mc-dialog-input" placeholder="禁言原因" style="margin-bottom:8px"/>
        <select v-model="banDialog.days" class="mc-select mc-dialog-select">
          <option :value="1">1天</option><option :value="3">3天</option><option :value="7">7天</option><option :value="30">30天</option>
        </select>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="banDialog={}">取消</button><button class="mc-btn mc-btn-reject" @click="doBan">确认</button></div>
      </div>
    </div>

    <div v-if="batchDialog" class="mc-overlay" @click.self="batchDialog=''">
      <div class="mc-dialog">
        <div class="mc-dialog-title">{{ batchDialog==='approve'?'批量通过':'批量驳回' }}</div>
        <p class="mc-dialog-text">确认{{ batchDialog==='approve'?'通过':'驳回' }}选中的 {{ selectedIds.length }} 篇帖子？</p>
        <textarea v-if="batchDialog==='reject'" v-model="batchReason" class="mc-dialog-input" placeholder="驳回原因" rows="2"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="batchDialog=''">取消</button><button class="mc-btn" :class="batchDialog==='approve'?'mc-btn-approve':'mc-btn-reject'" @click="doBatch">确认</button></div>
      </div>
    </div>

    <div v-if="editDialog.post" class="mc-overlay" @click.self="editDialog={}">
      <div class="mc-dialog" style="max-width:380px">
        <div class="mc-dialog-title">编辑帖子</div>
        <input v-model="editDialog.title" class="mc-dialog-input" placeholder="标题" style="margin-bottom:8px"/>
        <textarea v-model="editDialog.content" class="mc-dialog-input" placeholder="内容" rows="4"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="editDialog={}">取消</button><button class="mc-btn mc-btn-approve" @click="doEdit">保存</button></div>
      </div>
    </div>

    <div v-if="sectionDialog.section" class="mc-overlay" @click.self="sectionDialog={}">
      <div class="mc-dialog" style="max-width:380px">
        <div class="mc-dialog-title">板块设置 — {{ sectionDialog.section.name }}</div>
        <label class="mc-label">公告</label>
        <textarea v-model="sectionDialog.announcement" class="mc-dialog-input" rows="3" style="margin-bottom:8px"/>
        <label class="mc-label">规则</label>
        <textarea v-model="sectionDialog.rules" class="mc-dialog-input" rows="3" style="margin-bottom:8px"/>
        <label class="mc-label">Banner图片URL</label>
        <input v-model="sectionDialog.bannerUrl" class="mc-dialog-input" placeholder="https://..." style="margin-bottom:8px"/>
        <div class="mc-dialog-actions"><button class="mc-btn mc-btn-ghost" @click="sectionDialog={}">取消</button><button class="mc-btn mc-btn-approve" @click="doUpdateSection">保存</button></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()

const hasAccess = ref(false); const mySections = ref([])
const activeTab = ref('pending')
const showMenu = ref(false); const searchKeyword = ref(''); const selectedIds = ref([])
const loadingPending = ref(false); const loadingReports = ref(false); const loadingUnlocks = ref(false)
const loadingLogs = ref(false); const loadingBans = ref(false); const banSectionId = ref(0)
const batchDialog = ref(''); const batchReason = ref('')

const stats = reactive({ pendingCount:0, reportCount:0, unlockCount:0 })
const extStats = reactive({ todayReviewCount:0, todayReportHandled:0, totalPosts:0, totalComments:0 })
const pendingPosts = ref([]); const reports = ref([]); const unlockRequests = ref([])
const logs = ref([]); const bans = ref([])

const rejectDialog = reactive({ post:null, reason:'' }); const ignoreDialog = reactive({ report:null })
const unlockDialog = reactive({ req:null, action:'', reply:'' }); const moveDialog = reactive({ post:null, targetId:0 })
const banDialog = reactive({ show:false, uid:'', reason:'', days:7 })
const editDialog = reactive({ post:null, title:'', content:'' })
const sectionDialog = reactive({ section:null, announcement:'', rules:'', bannerUrl:'' })

const filteredPending = computed(() => {
  if (!searchKeyword.value) return pendingPosts.value
  const kw = searchKeyword.value.toLowerCase()
  return pendingPosts.value.filter(p => (p.title||'').toLowerCase().includes(kw) || (p.userName||'').toLowerCase().includes(kw))
})

const tabs = computed(() => [
  { key:'pending', label:'审核', badge:stats.pendingCount },
  { key:'reports', label:'举报', badge:stats.reportCount },
  { key:'unlocks', label:'解锁', badge:stats.unlockCount },
  { key:'bans', label:'禁言', badge:bans.value.length },
  { key:'logs', label:'日志', badge:0 }
])

function fAPI(url, params) { return request.get({ url, params }).catch(e => { console.error(url, e); return null }) }
function pAPI(url, body) { return request.post({ url, data: body }).catch(e => { console.error(url, e); return null }) }
function strip(h) { return h ? h.replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ') : '' }
function fmt(t) { if(!t) return ''; const d=new Date(t); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}` }
function pad(n) { return String(n).padStart(2,'0') }
function fixImg(u) { return u || '' }

function actLabel(a) {
  const m={ approve:'通过', reject:'驳回', pin:'置顶', unpin:'取消置顶', essence:'加精', unessence:'取消精华', hot:'热帖', unhot:'取消热帖', lock:'锁定', unlock:'解锁', ignore_report:'忽略举报', delete_post:'删除', move_post:'移动', edit_post:'编辑', ban_user:'禁言', unban_user:'解禁', resign:'辞职', delete_comment:'删评', update_section:'板块设置', approve_unlock:'通过解锁', reject_unlock:'拒绝解锁' }
  return m[a]||a
}

function sectionLabel(id) {
  const s = mySections.value.find(x => x.id===id)
  return s ? s.name : ''
}

function switchTab(k) { activeTab.value=k; if(k==='pending') loadPending(); else if(k==='reports') loadReports(); else if(k==='unlocks') loadUnlocks(); else if(k==='bans') loadBans(); else if(k==='logs') loadLogs() }

function loadStats() { fAPI('/api/community/moderator/stats').then(d=>{ if(d) Object.assign(stats,d) }) }
function loadExtStats() { fAPI('/api/community/moderator/enhanced-stats').then(d=>{ if(d) Object.assign(extStats,d) }) }

async function loadMySections() {
  let d = await fAPI('/api/community/moderator/my-sections')
  if (d && d.length) { mySections.value=d; hasAccess.value=true; if(!banSectionId.value) banSectionId.value=d[0].id; return }
  d = await fAPI('/api/community/user/'+userStore.getUserInfo?.userId+'/moderator-sections')
  if (d && d.length) { mySections.value=d.map(x=>({id:x.sectionId,name:x.sectionName,iconBgColor:x.iconBgColor,role:x.role,postCount:0})); hasAccess.value=true }
}

function loadPending() {
  loadingPending.value=true
  fAPI('/api/community/admin/posts/pending').then(d=>{
    if(d) pendingPosts.value=d.list||d||[]
    loadingPending.value=false
  }).catch(()=>{ loadingPending.value=false })
}

function loadReports() { loadingReports.value=true; fAPI('/api/community/admin/reports').then(d=>{ if(d) reports.value=Array.isArray(d)?d:(d.data||[]); loadingReports.value=false }).catch(()=>{ loadingReports.value=false }) }
function loadUnlocks() { loadingUnlocks.value=true; fAPI('/api/community/admin/unlock-requests').then(d=>{ if(d) unlockRequests.value=Array.isArray(d)?d:(d.data||[]); loadingUnlocks.value=false }).catch(()=>{ loadingUnlocks.value=false }) }
function loadLogs() { loadingLogs.value=true; fAPI('/api/community/moderator/logs').then(d=>{ if(d) logs.value=Array.isArray(d)?d:(d.data||[]); loadingLogs.value=false }).catch(()=>{ loadingLogs.value=false }) }

function loadBans() {
  loadingBans.value=true
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  if (!sid) { bans.value=[]; loadingBans.value=false; return }
  fAPI('/api/community/moderator/section/'+sid+'/bans').then(d=>{ if(d) bans.value=Array.isArray(d)?d:[]; loadingBans.value=false }).catch(()=>{ loadingBans.value=false })
}

function toggleSelect(id) {
  const i = selectedIds.value.indexOf(id)
  if (i>=0) selectedIds.value.splice(i,1); else selectedIds.value.push(id)
}

function filterPending() {}
function viewPost(p) { router.push('/community/post/'+p.id) }

function approvePost(p) { pAPI('/api/community/admin/post/'+p.id+'/approve').then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==p.id); stats.pendingCount=Math.max(0,stats.pendingCount-1); loadExtStats() } }) }
function rejectPost(p) { rejectDialog.post=p; rejectDialog.reason='' }
function doReject() { const p=rejectDialog.post; pAPI('/api/community/admin/post/'+p.id+'/reject',{reason:rejectDialog.reason||'内容不符合规范'}).then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==p.id); stats.pendingCount=Math.max(0,stats.pendingCount-1); loadExtStats() }; rejectDialog.post=null }).catch(()=>{ rejectDialog.post=null }) }

function doBatch() {
  if (!selectedIds.value.length) return
  const url = batchDialog.value==='approve' ? '/api/community/moderator/posts/batch-approve' : '/api/community/moderator/posts/batch-reject'
  const body = batchDialog.value==='approve' ? { ids:selectedIds.value } : { ids:selectedIds.value, reason:batchReason.value||'内容不符合规范' }
  pAPI(url, body).then(r=>{ if(r!==null){ selectedIds.value=[]; loadPending(); loadStats(); loadExtStats() }; batchDialog.value=''; batchReason.value='' }).catch(()=>{ batchDialog.value='' })
}

function ignoreReport(r) { ignoreDialog.report=r }
function doIgnore() { pAPI('/api/community/admin/report/ignore/'+ignoreDialog.report.id).then(r=>{ if(r!==null){ reports.value=reports.value.filter(x=>x.id!==ignoreDialog.report.id); stats.reportCount=Math.max(0,stats.reportCount-1); loadExtStats() }; ignoreDialog.report=null }).catch(()=>{ ignoreDialog.report=null }) }

function deleteComment(r) {
  if (!confirm('确定删除这条评论？')) return
  pAPI('/api/community/moderator/comment/'+r.targetId).then(r2=>{
    if(r2!==null){ reports.value=reports.value.filter(x=>x.id!==r.id); stats.reportCount=Math.max(0,stats.reportCount-1) }
  })
}

function openMoveDialog(p) { moveDialog.post=p; moveDialog.targetId=0 }
function doMove() {
  if (!moveDialog.targetId) return
  pAPI('/api/community/moderator/post/'+moveDialog.post.id+'/move',{targetSectionId:moveDialog.targetId}).then(r=>{ if(r!==null){ pendingPosts.value=pendingPosts.value.filter(x=>x.id!==moveDialog.post.id); stats.pendingCount=Math.max(0,stats.pendingCount-1) }; moveDialog.post=null })
}

function openEditDialog(p) { editDialog.post=p; editDialog.title=p.title||''; editDialog.content=p.content||'' }
function doEdit() { pAPI('/api/community/moderator/post/'+editDialog.post.id+'/edit',{title:editDialog.title,content:editDialog.content}).then(r=>{ if(r!==null) loadPending(); editDialog.post=null }) }

function openBanDialog() { banDialog.show=true; banDialog.uid=''; banDialog.reason=''; banDialog.days=7 }
function doBan() {
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  pAPI('/api/community/moderator/section/'+sid+'/ban',{bannedUserId:Number(banDialog.uid),reason:banDialog.reason,days:banDialog.days}).then(r=>{ if(r!==null) loadBans(); banDialog.show=false })
}

function unbanUser(b) {
  const sid = banSectionId.value || (mySections.value[0]?.id || 0)
  pAPI('/api/community/moderator/section/'+sid+'/ban/'+b.bannedUserId).then(r=>{ if(r!==null) loadBans() })
}

function handleUnlock(ur, a) { unlockDialog.req=ur; unlockDialog.action=a; unlockDialog.reply='' }
function doHandleUnlock() { const ur=unlockDialog.req; pAPI('/api/community/admin/unlock-request/'+ur.id+'/handle',{action:unlockDialog.action,reply:unlockDialog.reply}).then(r=>{ if(r!==null){ unlockRequests.value=unlockRequests.value.filter(u=>u.id!==ur.id); stats.unlockCount=Math.max(0,stats.unlockCount-1) }; unlockDialog.req=null }).catch(()=>{ unlockDialog.req=null }) }

async function openSectionSettings(s) {
  sectionDialog.section=s
  const info = await fAPI('/api/community/section/'+s.id+'/info')
  if (info) { sectionDialog.announcement=info.announcement||''; sectionDialog.rules=info.rules||''; sectionDialog.bannerUrl=info.bannerUrl||'' }
}

function doUpdateSection() {
  pAPI('/api/community/moderator/section/'+sectionDialog.section.id+'/update-info',{
    announcement:sectionDialog.announcement, rules:sectionDialog.rules, bannerUrl:sectionDialog.bannerUrl
  }).then(r=>{ if(r!==null) sectionDialog.section=null })
}

async function resignSection(s) {
  if (!confirm('确定辞去「'+s.name+'」的'+s.role+'职务？')) return
  await pAPI('/api/community/moderator/resign/'+s.id)
  loadMySections().then(()=>{ if(!mySections.value.length) hasAccess.value=false; loadStats(); loadExtStats() })
}

onMounted(async ()=>{
  await loadMySections()
  if (hasAccess.value) { loadStats(); loadExtStats(); loadPending() }
})
</script>

<style scoped>
.mc-page { min-height:100vh; background:var(--bg-body,#f5f5f5); padding-bottom:40px; }
.mc-navbar { display:flex; align-items:center; padding:12px 14px; background:#fff; border-bottom:1px solid var(--border-light,#eee); position:sticky; top:0; z-index:10; }
.mc-nav-back { background:none; border:none; color:var(--text-secondary,#666); cursor:pointer; padding:4px; display:flex; align-items:center; }
.mc-nav-title { flex:1; text-align:center; font-size:17px; font-weight:600; color:var(--text-primary,#222); }
.mc-nav-more { background:none; border:none; color:var(--text-secondary,#666); cursor:pointer; padding:4px; }

.mc-empty { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:60px 20px; color:var(--text-secondary,#999); }
.mc-empty svg { margin-bottom:16px; }
.mc-empty p { font-size:16px; font-weight:600; margin:0; }
.mc-empty-desc { font-size:13px; font-weight:400; color:var(--text-tertiary,#aaa); margin-top:8px!important; text-align:center; max-width:260px; }

.mc-body { padding:12px; }

.mc-stats-row { display:flex; gap:8px; margin-bottom:6px; }
.mc-stat { flex:1; background:#fff; border-radius:10px; padding:10px 8px; text-align:center; cursor:pointer; box-shadow:0 1px 3px rgba(0,0,0,.05); }
.mc-stat-num { font-size:22px; font-weight:700; color:var(--primary,#6366F1); }
.mc-stat-label { font-size:11px; color:var(--text-secondary,#888); margin-top:2px; }
.mc-stat-warn .mc-stat-num { color:#F59E0B; }
.mc-stat-info .mc-stat-num { color:#3B82F6; }
.mc-stat-green .mc-stat-num { color:#10B981; }
.mc-stats-sub { display:flex; justify-content:space-between; font-size:11px; color:var(--text-tertiary,#aaa); padding:4px 8px 10px; }
.mc-stats-sub-right { text-align:right; }

.mc-section-info { display:flex; flex-wrap:wrap; align-items:center; gap:6px; margin-bottom:10px; padding:8px 10px; background:#fff; border-radius:8px; }
.mc-section-label { font-size:12px; color:var(--text-secondary,#888); }
.mc-section-tag { display:inline-flex; align-items:center; gap:3px; padding:3px 8px; border-radius:12px; font-size:11px; color:#fff; cursor:pointer; }
.mc-section-tag-icon { width:14px; height:14px; border-radius:50%; }
.mc-section-role { font-size:10px; opacity:.8; margin-left:2px; }

.mc-tabs { display:flex; background:#fff; border-radius:8px; overflow-x:auto; margin-bottom:10px; box-shadow:0 1px 3px rgba(0,0,0,.05); }
.mc-tab { flex:1; min-width:fit-content; padding:10px 0; text-align:center; border:none; background:none; font-size:12px; color:var(--text-secondary,#888); cursor:pointer; position:relative; white-space:nowrap; }
.mc-tab.on { color:var(--primary,#6366F1); font-weight:600; box-shadow:inset 0 -2px var(--primary,#6366F1); }
.mc-tab-badge { position:absolute; top:2px; right:2px; min-width:16px; height:16px; line-height:16px; font-size:10px; background:#EF4444; color:#fff; border-radius:8px; padding:0 4px; }

.mc-toolbar { display:flex; gap:6px; margin-bottom:10px; flex-wrap:wrap; align-items:center; }
.mc-search { flex:1; min-width:120px; padding:6px 10px; border:1px solid var(--border-light,#e0e0e0); border-radius:6px; font-size:13px; outline:none; background:#fff; }
.mc-search:focus { border-color:var(--primary,#6366F1); }
.mc-section-select { display:flex; align-items:center; gap:8px; margin-bottom:8px; }

.mc-content { min-height:150px; }
.mc-list { display:flex; flex-direction:column; gap:8px; }
.mc-empty-list { text-align:center; padding:40px 0; color:var(--text-tertiary,#aaa); font-size:14px; }

.mc-card { background:#fff; border-radius:10px; padding:12px; box-shadow:0 1px 3px rgba(0,0,0,.05); display:flex; gap:10px; }
.mc-card.selected { border:2px solid var(--primary,#6366F1); }
.mc-card-check { display:flex; align-items:flex-start; padding-top:2px; }
.mc-checkbox { width:20px; height:20px; border:2px solid #d0d0d0; border-radius:4px; display:flex; align-items:center; justify-content:center; font-size:12px; color:#fff; cursor:pointer; }
.mc-checkbox.on { background:var(--primary,#6366F1); border-color:var(--primary,#6366F1); }
.mc-card-body-wrap { flex:1; min-width:0; }
.mc-card-header { display:flex; align-items:center; gap:6px; margin-bottom:6px; }
.mc-card-avatar { width:24px; height:24px; border-radius:50%; object-fit:cover; }
.mc-card-avatar-plc { width:24px; height:24px; border-radius:50%; background:var(--primary,#6366F1); color:#fff; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:600; }
.mc-card-username { font-size:12px; font-weight:500; color:var(--text-primary,#222); }
.mc-card-time { font-size:10px; color:var(--text-tertiary,#aaa); margin-left:auto; }
.mc-card-section-tag { font-size:10px; padding:1px 6px; background:#EEF2FF; color:var(--primary,#6366F1); border-radius:4px; }
.mc-report-badge { font-size:10px; padding:2px 6px; border-radius:4px; background:#FEF2F2; color:#EF4444; font-weight:500; }
.mc-card-title { font-size:14px; font-weight:600; color:var(--text-primary,#222); margin-bottom:4px; line-height:1.4; cursor:pointer; }
.mc-card-content { font-size:12px; color:var(--text-secondary,#666); line-height:1.5; margin-bottom:6px; word-break:break-word; }
.mc-card-images { display:flex; gap:4px; margin-bottom:6px; }
.mc-card-img { width:64px; height:64px; border-radius:6px; object-fit:cover; }
.mc-card-target { margin-bottom:6px; padding:6px 8px; background:var(--bg-body,#f8f8f8); border-radius:6px; font-size:11px; color:var(--text-secondary,#666); }
.mc-card-actions { display:flex; gap:6px; flex-wrap:wrap; }
.mc-btn { padding:5px 12px; border-radius:6px; border:none; font-size:12px; cursor:pointer; font-weight:500; white-space:nowrap; }
.mc-btn-sm { padding:4px 8px; font-size:11px; }
.mc-btn-approve { background:var(--primary,#6366F1); color:#fff; }
.mc-btn-reject { background:#FEF2F2; color:#EF4444; border:1px solid #FECACA; }
.mc-btn-ghost { background:#f0f0f0; color:var(--text-secondary,#666); }
.mc-btn-view { background:#EFF6FF; color:#3B82F6; border:1px solid #BFDBFE; }

.mc-select { padding:6px 10px; border:1px solid var(--border-light,#e0e0e0); border-radius:6px; font-size:13px; background:#fff; outline:none; }

.mc-logs .mc-log-item { display:flex; align-items:center; gap:8px; padding:10px 14px; background:#fff; border-radius:8px; font-size:12px; box-shadow:0 1px 2px rgba(0,0,0,.03); }
.mc-log-action { padding:2px 6px; border-radius:4px; background:#EEF2FF; color:var(--primary,#6366F1); font-weight:500; white-space:nowrap; }
.mc-log-detail { flex:1; color:var(--text-secondary,#666); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.mc-log-time { color:var(--text-tertiary,#aaa); white-space:nowrap; }

.mc-overlay { position:fixed; inset:0; background:rgba(0,0,0,.4); display:flex; align-items:center; justify-content:center; z-index:100; padding:20px; }
.mc-dialog { background:#fff; border-radius:12px; padding:20px; width:100%; max-width:340px; max-height:80vh; overflow-y:auto; }
.mc-dialog-title { font-size:16px; font-weight:600; color:var(--text-primary,#222); margin-bottom:12px; }
.mc-dialog-text { font-size:14px; color:var(--text-secondary,#666); margin-bottom:12px; }
.mc-dialog-input { width:100%; border:1px solid var(--border-light,#e0e0e0); border-radius:8px; padding:8px 10px; font-size:13px; outline:none; box-sizing:border-box; resize:vertical; }
.mc-dialog-input:focus { border-color:var(--primary,#6366F1); }
.mc-dialog-select { width:100%; margin-bottom:8px; }
.mc-dialog-actions { display:flex; gap:10px; justify-content:flex-end; margin-top:14px; }
.mc-label { font-size:12px; color:var(--text-secondary,#888); display:block; margin-bottom:4px; }
.mc-menu-item { display:block; width:100%; text-align:left; border:none; background:none; padding:10px 0; font-size:14px; color:var(--text-primary,#222); cursor:pointer; border-bottom:1px solid var(--border-light,#f0f0f0); }
.mc-menu-danger { color:#EF4444; }
</style>
