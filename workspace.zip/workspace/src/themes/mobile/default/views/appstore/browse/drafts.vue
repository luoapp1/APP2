<template>
  <div class="drafts-page">
    <div class="drafts-navbar">
      <button class="drafts-back" @click="$router.push('/appstore/mine')">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="drafts-title">草稿箱</span>
      <div class="drafts-placeholder" />
    </div>

    <div class="drafts-content" v-if="drafts.length > 0">
      <div
        v-for="item in drafts"
        :key="item.key"
        class="draft-card"
        @click="continueEdit(item)"
        @touchstart="touchStart($event, item)"
        @touchmove="touchMove($event, item)"
        @touchend="touchEnd($event, item)"
      >
        <div class="draft-title">{{ item.title }}</div>
        <div class="draft-summary">{{ item.summary }}</div>
        <div class="draft-time">{{ item.timeStr }}</div>
        <button class="draft-delete-btn" @click.stop="deleteDraft(item.key)">删除</button>
      </div>
    </div>

    <div class="drafts-empty" v-else>
      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#C0C4CC" stroke-width="1.5" stroke-linecap="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
      <p>暂无草稿</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

interface DraftItem {
  key: string
  title: string
  summary: string
  time: number
  timeStr: string
  path: string
}

const drafts = ref<DraftItem[]>([])

function decodeContent(encoded: string): string {
  try {
    return decodeURIComponent(escape(atob(encoded)))
  } catch {
    return atob(encoded)
  }
}

function extractText(html: string): string {
  try {
    const div = document.createElement('div')
    div.innerHTML = html
    return div.textContent || div.innerText || ''
  } catch {
    return html.replace(/<[^>]*>/g, '').substring(0, 100)
  }
}

function pathLabel(pathType: string): string {
  if (pathType.includes('post_edit') || pathType.includes('p_edit')) return '编辑帖子'
  if (pathType.includes('post_create') || pathType.includes('p_create')) return '新建帖子'
  return '帖子草稿'
}

function loadDrafts() {
  const items: DraftItem[] = []
  try {
    const keys = Object.keys(localStorage).filter((k) => k.startsWith('draft_'))
    for (const key of keys) {
      try {
        const raw = localStorage.getItem(key)
        if (!raw) continue
        const data = JSON.parse(raw)
        if (!data.time || !data.content) continue
        const html = decodeContent(data.content)
        const text = extractText(html)
        const pathType = key.replace('draft_', '')
        const title = pathLabel(pathType)
        items.push({
          key,
          title,
          summary: text.substring(0, 100) || '(空内容)',
          time: data.time,
          timeStr: formatTime(data.time),
          path: hashToPath(key)
        })
      } catch {}
    }
  } catch {}
  items.sort((a, b) => b.time - a.time)
  drafts.value = items
}

function hashToPath(key: string): string {
  const hash = key.replace('draft_', '')
  if (hash.includes('post_edit')) return '/community/post-edit'
  if (hash.includes('p_edit')) return '/p/edit/0'
  if (hash.includes('p_create') || hash.includes('post_create')) return '/p/create'
  return '/community/mycollections'
}

function formatTime(ts: number): string {
  const now = Date.now()
  const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  const d = new Date(ts)
  return `${d.getMonth() + 1}月${d.getDate()}日 ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function continueEdit(item: DraftItem) {
  router.push(item.path)
}

function deleteDraft(key: string) {
  try {
    localStorage.removeItem(key)
    drafts.value = drafts.value.filter((d) => d.key !== key)
  } catch {}
}

let startX = 0
let currentItem: DraftItem | null = null

function touchStart(e: TouchEvent, item: DraftItem) {
  startX = e.touches[0].clientX
  currentItem = item
}

function touchMove(e: TouchEvent, _item: DraftItem) {}
function touchEnd(_e: TouchEvent, _item: DraftItem) {
  startX = 0
  currentItem = null
}

onMounted(loadDrafts)
</script>

<style scoped>
.drafts-page { min-height: 100vh; background: #F5F6FA; }
.drafts-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.drafts-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; }
.drafts-back:active { background: #f0f0f0; }
.drafts-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.drafts-placeholder { width: 22px; }
.drafts-content { padding: 12px 16px; display: flex; flex-direction: column; gap: 10px; }
.draft-card { position: relative; background: #fff; border-radius: 12px; padding: 16px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); display: flex; flex-direction: column; gap: 6px; }
.draft-card:active { background: #f8f8f8; }
.draft-title { font-size: 16px; font-weight: 600; color: #1a1a1a; }
.draft-summary { font-size: 13px; color: #999; line-height: 1.5; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.draft-time { font-size: 12px; color: #C0C4CC; display: flex; align-items: center; justify-content: space-between; }
.draft-delete-btn { position: absolute; right: 12px; bottom: 14px; padding: 5px 12px; border: none; border-radius: 16px; background: rgba(244,67,54,.1); color: #f44336; font-size: 12px; cursor: pointer; }
.draft-delete-btn:active { background: rgba(244,67,54,.2); }
.drafts-empty { display: flex; flex-direction: column; align-items: center; padding: 80px 0; gap: 16px; }
.drafts-empty p { font-size: 14px; color: #999; margin: 0; }
</style>
