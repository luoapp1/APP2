<template>
  <div class="app-manage-page">
    <div class="page-header">
      <div class="header-left" @click="handleGoBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
      </div>
      <div class="header-center">
        <div class="header-title">应用管理</div>
        <div class="header-sub">共 {{ total }} 条</div>
      </div>
      <div class="header-right" @click="searchOpen = !searchOpen">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card stat-card--total"><div class="stat-card-value">{{ total }}</div><div class="stat-card-label">全部</div></div>
      <div class="stat-card stat-card--online"><div class="stat-card-value">{{ statusCounts.online }}</div><div class="stat-card-label">上架</div></div>
      <div class="stat-card stat-card--offline"><div class="stat-card-value">{{ statusCounts.offline }}</div><div class="stat-card-label">下架</div></div>
      <div class="stat-card stat-card--pinned"><div class="stat-card-value">{{ statusCounts.pinned }}</div><div class="stat-card-label">置顶</div></div>
    </div>

    <div class="filter-tabs">
      <span :class="['filter-tab', { active: activeStatus === '' }]" @click="handleStatusChange('')">全部</span>
      <span :class="['filter-tab', { active: activeStatus === '1' }]" @click="handleStatusChange('1')">上架</span>
      <span :class="['filter-tab', { active: activeStatus === '0' }]" @click="handleStatusChange('0')">下架</span>
    </div>

    <div v-if="searchOpen" class="search-bar">
      <input ref="searchInputRef" v-model="searchKeyword" class="search-input" placeholder="搜索应用名称/包名" @keyup.enter="fetchData" />
      <button class="search-btn" @click="fetchData">搜索</button>
    </div>

    <div class="pagination-wrap">
      <el-pagination
        small
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50]"
        :total="total"
        layout="total, sizes, prev, pager, next"
        @current-change="fetchData"
        @size-change="handleSizeChange"
      />
    </div>

    <div class="content-area">
      <div v-if="loading" style="display:flex;justify-content:center;padding:40px 0">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2" style="animation:spin 0.8s linear infinite"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>
      </div>

      <div v-else-if="list.length === 0" class="empty-state">
        <svg class="empty-icon" viewBox="0 0 120 120" fill="none">
          <rect x="36" y="30" width="48" height="60" rx="6" stroke="#CDD6E8" stroke-width="1.5" fill="white"/>
          <path d="M42 48h36M42 58h28M42 68h20" stroke="#E8EDF5" stroke-width="3" stroke-linecap="round"/>
          <rect x="20" y="24" width="80" height="10" rx="5" fill="#E8EDF5" opacity="0.6"/>
        </svg>
        <p class="empty-text">暂无应用</p>
      </div>

      <div v-else class="app-list">
        <div v-for="item in list" :key="item.id" class="app-card">
          <div class="card-main" @click="toggleExpand(item.id)">
            <div class="card-icon" :style="{ background: item.iconBgColor || '#00BFA5' }">
              <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="icon-img"  loading="lazy" />
              <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div class="card-info">
              <div class="card-name">
                {{ item.name }}
                <span v-if="item.isPinned" class="pinned-badge">置顶</span>
              </div>
              <div class="card-meta">{{ item.packageName || '-' }}</div>
              <div class="card-meta-sub">v{{ item.version || '-' }} · {{ item.sizeMb }} MB · {{ item.downloads || 0 }} 下载</div>
              <div class="card-time">{{ item.updateTime || item.createTime || '-' }}</div>
            </div>
            <svg :class="['card-arrow', { rotated: expandedId === item.id }]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>
          </div>

          <div v-if="expandedId === item.id" class="card-detail-list">
            <div class="sub-item">
              <div class="sub-item-header">
                <span :class="['status-badge', item.status === '1' ? 'status-approved' : 'status-rejected']">{{ item.status === '1' ? '上架' : '下架' }}</span>
                <span class="sub-item-version">v{{ item.version }}</span>
                <span class="sub-item-time">{{ item.createTime }}</span>
              </div>

              <div class="sub-item-body">
                <div class="detail-row"><span class="detail-label">大小</span><span class="detail-value">{{ item.sizeMb || 0 }} MB</span></div>
                <div class="detail-row"><span class="detail-label">版本代码</span><span class="detail-value">{{ item.versionCode || '-' }}</span></div>
                <div class="detail-row"><span class="detail-label">评分</span><span class="detail-value" style="color:#f59e0b;font-weight:500">{{ '★'.repeat(Math.round(item.rating || 0)) }}{{ item.rating || '-' }}</span></div>
                <div class="detail-row"><span class="detail-label">收费</span><span class="detail-value" :style="{ color: priceColor(item), fontWeight: 500 }">{{ formatPrice(item) }}</span></div>
                <div class="detail-row" v-if="item.description"><span class="detail-label">描述</span><span class="detail-value">{{ item.description }}</span></div>
                <div v-if="item.tags && item.tags.length" class="detail-section">
                  <div class="detail-section-title">标签</div>
                  <div class="tags-row">
                    <span v-for="(t, ti) in item.tags" :key="ti" class="tag-badge" style="background:#ccfbf1;color:#0d9488">{{ t }}</span>
                  </div>
                </div>
                <div v-if="item.officialTags && item.officialTags.length" class="detail-section">
                  <div class="detail-section-title">官方标签</div>
                  <div class="tags-row">
                    <span v-for="ot in item.officialTags" :key="ot.id" class="tag-badge" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
                  </div>
                </div>
              </div>

              <div class="sub-item-actions">
                <button v-auth="'edit'" class="action-btn action-edit-info" @click.stop="openEdit(item)">编辑</button>
                <button class="action-btn action-preview" @click.stop="openDemo(item)">预览</button>
                <button class="action-btn action-comments" @click.stop="openComments(item)">评论</button>
                <button v-auth="'toggle'" class="action-btn action-pin" @click.stop="handlePin(item)">{{ item.isPinned ? '取消置顶' : '置顶' }}</button>
                <button v-auth="'delete'" class="action-btn action-delete" @click.stop="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <button v-auth="'edit'" class="fab-add" @click="openEdit(null)">+</button>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="dialog-overlay" @click.self="dialogVisible = false">
      <div class="edit-panel">
        <div class="edit-panel-header">
          <button class="edit-panel-back" @click="dialogVisible = false">取消</button>
          <div class="edit-panel-title">{{ editId ? '编辑应用' : '新增应用' }}</div>
          <button v-auth="'edit'" class="edit-panel-save" @click="saveItem">保存</button>
        </div>
        <div class="edit-panel-body">
          <div class="edit-field">
            <label class="edit-label">应用名称 *</label>
            <input v-model="form.name" class="edit-input" placeholder="如：神奇影视" />
          </div>
          <div class="edit-field">
            <label class="edit-label">包名 *</label>
            <input v-model="form.packageName" class="edit-input" placeholder="如：com.example.app" />
          </div>
          <div class="edit-field">
            <label class="edit-label">版本号</label>
            <input v-model="form.version" class="edit-input" placeholder="如：1.3.0" />
          </div>
          <div class="edit-field">
            <label class="edit-label">版本代码</label>
            <input v-model="form.versionCode" class="edit-input" placeholder="如：130" />
          </div>
          <div class="edit-field">
            <label class="edit-label">大小(MB)</label>
            <input v-model.number="form.sizeMb" type="number" class="edit-input" placeholder="应用大小" />
          </div>
          <div class="edit-field">
            <label class="edit-label">图标颜色</label>
            <input v-model="form.iconBgColor" type="color" class="edit-input" style="height:40px;padding:4px 12px" />
          </div>
          <div class="edit-field">
            <label class="edit-label">评分</label>
            <input v-model.number="form.rating" type="number" min="0" max="5" step="0.1" class="edit-input" />
          </div>
          <div class="edit-field">
            <label class="edit-label">下载量</label>
            <input v-model.number="form.downloads" type="number" min="0" class="edit-input" />
          </div>
          <div class="edit-field">
            <label class="edit-label">收费方式</label>
            <div class="edit-price-type">
              <button :class="['edit-price-btn', { active: form.priceType === 'free' || !form.priceType }]" @click="form.priceType = 'free'; form.priceAmount = 0">免费</button>
              <button :class="['edit-price-btn', { active: form.priceType === 'balance' }]" @click="form.priceType = 'balance'">余额</button>
              <button :class="['edit-price-btn', { active: form.priceType === 'points' }]" @click="form.priceType = 'points'">积分</button>
            </div>
          </div>
          <div class="edit-field" v-if="form.priceType === 'balance' || form.priceType === 'points'">
            <label class="edit-label">{{ form.priceType === 'balance' ? '价格(元)' : '价格(积分)' }}</label>
            <input v-model.number="form.priceAmount" type="number" min="0" step="0.01" class="edit-input" />
          </div>
          <div class="edit-field">
            <label class="edit-label">上架</label>
            <div class="edit-price-type">
              <button :class="['edit-price-btn', { active: form.status === '1' }]" @click="form.status = '1'">上架</button>
              <button :class="['edit-price-btn', { active: form.status === '0' }]" @click="form.status = '0'">下架</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 确认删除弹窗 -->
    <div v-if="showConfirm" class="dialog-overlay" @click.self="showConfirm = false">
      <div class="dialog-panel">
        <div class="dialog-title">确认删除</div>
        <div class="dialog-app-name">{{ confirmText }}</div>
        <div class="dialog-buttons">
          <button class="dialog-btn dialog-btn-cancel" @click="showConfirm = false">取消</button>
          <button class="dialog-btn dialog-btn-confirm" @click="doConfirmed">确定删除</button>
        </div>
      </div>
    </div>

    <!-- 评论管理弹窗 -->
    <div v-if="commentVisible" class="dialog-overlay" @click.self="commentVisible = false">
      <div class="comment-panel">
        <div class="edit-panel-header">
          <button class="edit-panel-back" @click="commentVisible = false">关闭</button>
          <div class="edit-panel-title">评论管理</div>
          <div class="edit-panel-save" style="color:#9ca3af;font-weight:400">{{ commentList.length }} 条</div>
        </div>
        <div class="edit-panel-body">
          <div v-if="commentLoading" style="display:flex;justify-content:center;padding:40px 0">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2" style="animation:spin 0.8s linear infinite"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>
          </div>
          <div v-else-if="commentList.length === 0" style="text-align:center;padding:40px 0;color:#9ca3af;font-size:13px">暂无评论</div>
          <div v-else class="comment-list">
            <div v-for="c in commentList" :key="c.id" class="comment-item">
              <div class="comment-user">{{ c.userName || '匿名用户' }}</div>
              <div class="comment-rating" style="color:#f59e0b">{{ '★'.repeat(c.rating || 0) }}{{ '☆'.repeat(5 - (c.rating || 0)) }}</div>
              <div class="comment-content">{{ c.content || '-' }}</div>
              <div class="comment-time">{{ c.createTime || '-' }}</div>
              <button class="comment-delete-btn" @click="handleDeleteComment(c)">删除</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Toast -->
    <div v-if="toastMsg" class="toast" :class="toastType === 'error' ? 'toast-error' : 'toast-success'">{{ toastMsg }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElPagination } from 'element-plus'
import { fetchAppList, fetchSaveApp, fetchDeleteApp, fetchPinApp, fetchAppDetail, fetchAdminDeleteComment } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'

defineOptions({ name: 'AppManageMobile' })

const router = useRouter()
const userStore = useUserStore()

const showConfirm = ref(false)
const confirmText = ref('')
let pendingAction: (() => void) | null = null
const doConfirmed = () => { showConfirm.value = false; if (pendingAction) pendingAction() }
const askConfirm = (text: string, action: () => void) => { confirmText.value = text; pendingAction = action; showConfirm.value = true }

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false)
const list = ref<any[]>([])
const searchKeyword = ref('')
const searchOpen = ref(false)
const searchInputRef = ref<HTMLInputElement>()
const activeStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const statusCounts = reactive({ online: 0, offline: 0, pinned: 0 })
const expandedId = ref<number | null>(null)

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await fetchAppList({
      keyword: searchKeyword.value,
      status: activeStatus.value,
      page: page.value,
      pageSize: pageSize.value
    })
    list.value = res?.list || []
    total.value = res?.total || list.value.length
    if (res?.onlineCount !== undefined) {
      statusCounts.online = res.onlineCount
      statusCounts.offline = res.offlineCount
    } else {
      statusCounts.online = 0
      statusCounts.offline = 0
    }
    statusCounts.pinned = list.value.filter((i: any) => i.isPinned).length
  } catch (_e: unknown) { void _e }
  loading.value = false
}

function handleStatusChange(value: string) { activeStatus.value = value; page.value = 1; fetchData() }
function handleSizeChange() { page.value = 1; fetchData() }
function handleGoBack() { router.back() }

function toggleExpand(id: number) {
  expandedId.value = expandedId.value === id ? null : id
}

function formatPrice(item: any): string {
  const pt = item.priceType || 'free'
  const pa = Number(item.priceAmount || 0)
  if (pt === 'free' || pa <= 0) return '免费'
  if (pt === 'balance') return `余额 ${pa} 元`
  if (pt === 'points') return `积分 ${pa}`
  return '免费'
}

function priceColor(item: any): string {
  const pt = item.priceType || 'free'
  if (pt === 'free') return '#10B981'
  if (pt === 'balance') return '#F59E0B'
  if (pt === 'points') return '#8B5CF6'
  return '#10B981'
}

const dialogVisible = ref(false)
const editId = ref<number | null>(null)
const formDefault = () => ({ name: '', packageName: '', version: '', versionCode: '', sizeMb: 0, iconBgColor: '#00BFA5', rating: 0, downloads: 0, priceType: 'free', priceAmount: 0, status: '1', userId: 0 })
const form = reactive(formDefault())

function openEdit(item: any | null) {
  editId.value = item?.id || null
  if (item) {
    form.name = item.name || ''; form.packageName = item.packageName || ''
    form.version = item.version || ''; form.versionCode = item.versionCode || ''
    form.sizeMb = item.sizeMb || 0; form.iconBgColor = item.iconBgColor || '#00BFA5'
    form.rating = item.rating || 0; form.downloads = item.downloads || 0
    form.priceType = item.priceType || 'free'; form.priceAmount = item.priceAmount || 0
    form.status = item.status || '1'; form.userId = item.userId || 0
  } else {
    Object.assign(form, formDefault())
    form.userId = userStore.info.userId
  }
  dialogVisible.value = true
}

async function saveItem() {
  if (!form.name.trim()) { showToast('请输入应用名称', 'error'); return }
  if (!form.packageName.trim()) { showToast('请输入包名', 'error'); return }
  try {
    const data: any = {
      name: form.name.trim(), packageName: form.packageName.trim(),
      version: form.version, versionCode: form.versionCode,
      sizeMb: form.sizeMb, iconBgColor: form.iconBgColor,
      rating: form.rating, downloads: form.downloads,
      priceType: form.priceType, priceAmount: form.priceAmount,
      status: form.status
    }
    if (!editId.value) { data.userId = form.userId || userStore.info.userId }
    if (editId.value) data.id = editId.value
    await fetchSaveApp(data)
    showToast('保存成功')
    dialogVisible.value = false
    fetchData()
  } catch (e: any) { showToast(e?.message || '保存失败', 'error') }
}

function openDemo(item: any) { router.push(`/appstore/detail/${item.id}`) }

async function handlePin(item: any) {
  try {
    await fetchPinApp(item.id, !item.isPinned)
    showToast(item.isPinned ? '已取消置顶' : '已置顶')
    expandedId.value = null
    fetchData()
  } catch (_e: unknown) { showToast('操作失败', 'error') }
}

function deleteItem(item: any) {
  askConfirm(`确认删除「${item.name}」？删除后对应的投稿记录也将一并删除。`, async () => {
    try {
      await fetchDeleteApp(item.id)
      showToast('删除成功')
      expandedId.value = null
      fetchData()
    } catch (_e: unknown) { showToast('删除失败', 'error') }
  })
}

const commentVisible = ref(false)
const commentLoading = ref(false)
const commentList = ref<any[]>([])
const commentAppId = ref(0)

async function openComments(item: any) {
  commentAppId.value = item.id
  commentVisible.value = true
  commentLoading.value = true
  commentList.value = []
  try {
    const data: any = await fetchAppDetail(item.id)
    commentList.value = data?.comments || []
  } catch (_e: unknown) { void _e }
  commentLoading.value = false
}

function handleDeleteComment(c: any) {
  askConfirm(`确认删除该评论？`, async () => {
    try {
      await fetchAdminDeleteComment(c.id)
      commentList.value = commentList.value.filter((x: any) => x.id !== c.id)
      showToast('已删除')
    } catch (_e: unknown) { showToast('删除失败', 'error') }
  })
}

onMounted(() => fetchData())
</script>

<style scoped>
@keyframes spin { to { transform: rotate(360deg); } }
.app-manage-page { min-height: 100vh; background: var(--app-page-bg); padding-bottom: 80px; }
.page-header { display: flex; align-items: center; padding: 12px 16px; background: #fff; position: sticky; top: 0; z-index: 10; }
.header-left, .header-right { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.header-center { flex: 1; text-align: center; }
.header-title { font-size: 17px; font-weight: 600; color: #1f2937; }
.header-sub { font-size: 11px; color: #9ca3af; margin-top: 1px; }
.stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; padding: 10px 12px; background: #fff; border-top: 1px solid #f3f4f6; }
.stat-card { text-align: center; padding: 6px 2px; border-radius: 10px; }
.stat-card--total { background: #f3f4f6; } .stat-card--online { background: #d1fae5; } .stat-card--offline { background: #fee2e2; } .stat-card--pinned { background: #fff7ed; }
.stat-card-value { font-size: 18px; font-weight: 700; color: #1f2937; }
.stat-card-label { font-size: 10px; color: #6b7280; margin-top: 2px; }
.filter-tabs { display: flex; gap: 6px; padding: 10px 16px; background: #fff; border-top: 1px solid #f3f4f6; overflow-x: auto; white-space: nowrap; }
.filter-tab { font-size: 12px; padding: 5px 12px; border-radius: 20px; background: #f3f4f6; color: #6b7280; cursor: pointer; flex-shrink: 0; border: 1px solid transparent; transition: all 0.2s; }
.filter-tab.active { background: #00BFA5; color: #fff; border-color: #00BFA5; }
.search-bar { display: flex; gap: 8px; padding: 8px 16px 12px; background: #fff; border-top: 1px solid #f3f4f6; }
.search-input { flex: 1; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 20px; font-size: 13px; outline: none; background: #f9fafb; }
.search-input:focus { border-color: #00BFA5; background: #fff; }
.search-btn { padding: 8px 16px; border: none; border-radius: 20px; background: #00BFA5; color: #fff; font-size: 13px; cursor: pointer; }
.pagination-wrap { display: flex; justify-content: center; padding: 8px 8px; background: #fff; }
.content-area { padding: 8px 16px 0; }
.empty-state { display: flex; flex-direction: column; align-items: center; padding: 60px 0; }
.empty-icon { width: 80px; height: 80px; }
.empty-text { font-size: 13px; color: #9ca3af; margin-top: 12px; }
.app-list { display: flex; flex-direction: column; gap: 8px; }
.app-card { background: #fff; border-radius: 14px; padding: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
.card-main { display: flex; align-items: flex-start; gap: 12px; cursor: pointer; }
.card-icon { width: 46px; height: 46px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; overflow: hidden; }
.icon-img { width: 100%; height: 100%; object-fit: cover; }
.card-info { flex: 1; min-width: 0; }
.card-name { font-size: 15px; font-weight: 600; color: #1f2937; display: flex; align-items: center; gap: 8px; }
.pinned-badge { font-size: 10px; padding: 2px 7px; border-radius: 10px; background: #fff7ed; color: #ea580c; font-weight: 500; flex-shrink: 0; }
.card-meta { font-size: 12px; color: #6b7280; margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.card-meta-sub { font-size: 11px; color: #9ca3af; margin-top: 2px; }
.card-time { font-size: 11px; color: #b0b7c3; margin-top: 4px; }
.card-arrow { flex-shrink: 0; margin-top: 4px; transition: transform 0.2s; }
.card-arrow.rotated { transform: rotate(180deg); }
.card-detail-list { margin-top: 8px; padding-top: 8px; border-top: 1px solid #f3f4f6; }
.sub-item { padding: 10px 0 10px 12px; border-left: 3px solid #00BFA5; margin-left: 4px; }
.sub-item-header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.sub-item-version { font-size: 13px; font-weight: 600; color: #1f2937; }
.sub-item-time { font-size: 11px; color: #b0b7c3; margin-left: auto; }
.status-badge { font-size: 10px; padding: 2px 7px; border-radius: 10px; font-weight: 500; flex-shrink: 0; }
.status-pending { background: #fef3c7; color: #d97706; } .status-approved { background: #d1fae5; color: #059669; } .status-rejected { background: #fee2e2; color: #dc2626; }
.sub-item-body { margin-bottom: 6px; }
.sub-item-actions { display: flex; gap: 6px; margin-top: 8px; }
.detail-section { margin-bottom: 8px; }
.detail-section-title { font-size: 12px; font-weight: 600; color: #6b7280; margin-bottom: 6px; }
.detail-row { display: flex; gap: 8px; padding: 3px 0; font-size: 12px; }
.detail-label { color: #9ca3af; flex-shrink: 0; min-width: 60px; }
.detail-value { color: #374151; word-break: break-all; }
.tags-row { display: flex; flex-wrap: wrap; gap: 6px; }
.tag-badge { font-size: 11px; padding: 3px 10px; border-radius: 12px; font-weight: 500; }
.action-btn { padding: 6px 10px; border: none; border-radius: 8px; font-size: 11px; font-weight: 500; cursor: pointer; white-space: nowrap; }
.action-edit-info { background: #e0e7ff; color: #4f46e5; }
.action-preview { background: #d1fae5; color: #059669; }
.action-comments { background: #dbeafe; color: #2563eb; }
.action-pin { background: #fff7ed; color: #ea580c; }
.action-delete { background: #fee2e2; color: #dc2626; }
.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 24px; }
.dialog-panel { background: #fff; border-radius: 16px; width: 100%; max-width: 340px; padding: 24px 20px 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
.dialog-title { font-size: 17px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
.dialog-app-name { font-size: 13px; color: #6b7280; margin-bottom: 16px; }
.dialog-buttons { display: flex; gap: 10px; margin-top: 16px; }
.dialog-btn { flex: 1; padding: 10px; border: none; border-radius: 10px; font-size: 14px; font-weight: 500; cursor: pointer; }
.dialog-btn-cancel { background: #f3f4f6; color: #374151; }
.dialog-btn-confirm { background: #ef4444; color: #fff; }
.edit-panel { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 -10px 40px rgba(0,0,0,0.2); position: fixed; bottom: 0; left: 0; right: 0; }
.edit-panel-header { display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; border-bottom: 1px solid #f3f4f6; }
.edit-panel-back { font-size: 14px; color: #6b7280; background: none; border: none; cursor: pointer; padding: 0; }
.edit-panel-title { font-size: 16px; font-weight: 600; color: #1f2937; }
.edit-panel-save { font-size: 14px; color: #00BFA5; font-weight: 600; background: none; border: none; cursor: pointer; padding: 0; }
.edit-panel-body { padding: 16px; overflow-y: auto; flex: 1; }
.edit-field { margin-bottom: 14px; }
.edit-label { display: block; font-size: 12px; color: #6b7280; margin-bottom: 4px; font-weight: 500; }
.edit-input { width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box; }
.edit-input:focus { border-color: #00BFA5; }
.edit-price-type { display: flex; gap: 8px; }
.edit-price-btn { flex: 1; padding: 8px 0; border: 1px solid #e5e7eb; border-radius: 8px; background: #f9fafb; color: #6b7280; font-size: 13px; cursor: pointer; transition: all 0.2s; }
.edit-price-btn.active { background: #e6f9f6; border-color: #00BFA5; color: #00BFA5; font-weight: 600; }
.fab-add { position: fixed; bottom: 24px; right: 24px; width: 48px; height: 48px; background: #00BFA5; border: none; border-radius: 50%; color: #fff; font-size: 24px; display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 4px 16px rgba(0,191,165,0.35); z-index: 50; }
.comment-panel { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 -10px 40px rgba(0,0,0,0.2); position: fixed; bottom: 0; left: 0; right: 0; z-index: 1001; }
.comment-list { display: flex; flex-direction: column; gap: 0; }
.comment-item { padding: 12px 0; border-bottom: 1px solid #f3f4f6; }
.comment-item:last-child { border-bottom: none; }
.comment-user { font-size: 14px; font-weight: 600; color: #1f2937; }
.comment-rating { font-size: 12px; margin-top: 2px; letter-spacing: 1px; }
.comment-content { font-size: 13px; color: #374151; margin-top: 6px; line-height: 1.5; }
.comment-time { font-size: 11px; color: #b0b7c3; margin-top: 4px; }
.comment-delete-btn { margin-top: 8px; padding: 4px 12px; border: none; border-radius: 6px; background: #fee2e2; color: #dc2626; font-size: 11px; font-weight: 500; cursor: pointer; }
.toast { position: fixed; top: 60px; left: 50%; transform: translateX(-50%); z-index: 2000; padding: 8px 20px; border-radius: 20px; font-size: 13px; font-weight: 500; color: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.toast-success { background: #00BFA5; }
.toast-error { background: #FF4757; }
</style>
