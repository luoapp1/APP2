<template>
  <div class="history-page">
    <div class="history-navbar">
      <button class="history-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="history-title">登录日志</span>
      <button class="history-action" @click="showLogoutConfirm = true" :disabled="loading">下线其他设备</button>
    </div>

    <div v-if="loading && list.length === 0" class="history-loading">
      <span>加载中...</span>
    </div>

    <div v-else-if="list.length === 0" class="history-empty">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#CCC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      <span>暂无登录记录</span>
    </div>

    <div v-else class="history-list">
      <div v-for="item in list" :key="item.id" class="history-item">
        <div class="history-device-icon">
          <svg v-if="item.device_type === 'Mobile'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
          <svg v-else-if="item.device_type === 'Tablet'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/></svg>
          <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
        </div>
        <div class="history-info">
          <div class="history-top">
            <span class="history-location">{{ item.ip_city || item.ip_province || item.ip || '未知地点' }}</span>
            <span v-if="item.is_new_device" class="history-badge">新设备</span>
          </div>
          <div class="history-detail">
            <span>{{ [item.os, item.browser].filter(Boolean).join(' ') || '未知设备' }}</span>
            <span class="history-sep">|</span>
            <span>{{ item.ip }}</span>
          </div>
          <div class="history-time">{{ fmtTime(item.create_time) }}</div>
        </div>
      </div>
    </div>

    <div v-if="hasMore && !loading" class="history-more" @click="loadMore">
      加载更多
    </div>
    <div v-if="loadingMore" class="history-loading">加载中...</div>

    <div v-if="showLogoutConfirm" class="overlay" @click.self="showLogoutConfirm = false">
      <div class="confirm-card">
        <div class="confirm-title">下线其他设备</div>
        <div class="confirm-desc">将退出除当前设备外的所有登录会话</div>
        <div class="confirm-btns">
          <button class="confirm-btn cancel" @click="showLogoutConfirm = false">取消</button>
          <button class="confirm-btn danger" @click="logoutAll" :disabled="loggingOut">{{ loggingOut ? '处理中...' : '确认下线' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const list = ref<any[]>([])
const page = ref(1)
const total = ref(0)
const loading = ref(false)
const loadingMore = ref(false)
const showLogoutConfirm = ref(false)
const loggingOut = ref(false)

const pageSize = 20
const hasMore = ref(false)

onMounted(() => {
  fetchHistory()
})

async function fetchHistory() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/login-history', params: { page: 1, pageSize } })
    if (res) {
      list.value = res.list || []
      total.value = res.total || 0
      hasMore.value = list.value.length < total.value
    }
  } catch {} finally {
    loading.value = false
  }
}

async function loadMore() {
  if (loadingMore.value) return
  loadingMore.value = true
  page.value++
  try {
    const res: any = await request.get({ url: '/api/login-history', params: { page: page.value, pageSize } })
    if (res) {
      list.value.push(...(res.list || []))
      hasMore.value = list.value.length < (res.total || total.value)
    }
  } catch {} finally {
    loadingMore.value = false
  }
}

async function logoutAll() {
  loggingOut.value = true
  try {
    await request.post({ url: '/api/auth/logout-all' })
    ElMessage.success('其他设备已下线')
    showLogoutConfirm.value = false
  } catch {
    ElMessage.error('操作失败')
  } finally {
    loggingOut.value = false
  }
}

function fmtTime(t: string) {
  if (!t) return ''
  const d = new Date(t.replace(/-/g, '/'))
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
  return t.substring(0, 16)
}
</script>

<style scoped>
.history-page {
  min-height: 100vh;
  background: #F5F6FA;
}

.history-navbar {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 10;
  box-shadow: 0 1px 3px rgba(0,0,0,.05);
}

.history-back {
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  display: flex;
  color: #333;
  border-radius: 8px;
}

.history-back:active { background: #f0f0f0; }

.history-title {
  flex: 1;
  text-align: center;
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
}

.history-action {
  background: none;
  border: none;
  font-size: 13px;
  color: #FF4757;
  padding: 4px 8px;
  cursor: pointer;
  border-radius: 6px;
}

.history-action:active { background: #FFF0F0; }

.history-loading, .history-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 80px 20px;
  color: #999;
  font-size: 14px;
}

.history-list {
  padding: 12px 16px;
}

.history-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  background: #fff;
  padding: 12px 14px;
  border-radius: 12px;
  margin-bottom: 10px;
}

.history-device-icon {
  margin-top: 2px;
  flex-shrink: 0;
}

.history-info {
  flex: 1;
  min-width: 0;
}

.history-top {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 2px;
}

.history-location {
  font-size: 15px;
  color: #333;
  font-weight: 500;
}

.history-badge {
  font-size: 10px;
  color: #FF4757;
  background: #FFF0F0;
  padding: 1px 6px;
  border-radius: 4px;
}

.history-detail {
  font-size: 12px;
  color: #999;
  display: flex;
  align-items: center;
  gap: 4px;
  flex-wrap: wrap;
}

.history-sep {
  color: #DDD;
}

.history-time {
  font-size: 12px;
  color: #BBB;
  margin-top: 2px;
}

.history-more {
  text-align: center;
  padding: 14px;
  font-size: 14px;
  color: #409EFF;
  cursor: pointer;
}

.overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  padding: 20px;
}

.confirm-card {
  background: #fff;
  border-radius: 14px;
  padding: 24px 20px 20px;
  width: 100%;
  max-width: 300px;
  text-align: center;
}

.confirm-title {
  font-size: 17px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
}

.confirm-desc {
  font-size: 14px;
  color: #888;
  margin-bottom: 20px;
}

.confirm-btns {
  display: flex;
  gap: 12px;
}

.confirm-btn {
  flex: 1;
  padding: 10px 0;
  border-radius: 10px;
  border: none;
  font-size: 15px;
  cursor: pointer;
  transition: .15s;
}

.confirm-btn.cancel {
  background: #F2F3F5;
  color: #666;
}

.confirm-btn.cancel:active { background: #E5E6EB; }

.confirm-btn.danger {
  background: #FF4757;
  color: #fff;
}

.confirm-btn.danger:active { background: #E63950; }
.confirm-btn.danger:disabled { opacity: .6; }
</style>
