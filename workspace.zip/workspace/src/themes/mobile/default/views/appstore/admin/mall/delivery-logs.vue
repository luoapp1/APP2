<template>
<div class="cpool">
  <div class="user-header"><h2>发货记录</h2><router-link to="/appstore/products" class="back-btn">&lt; 返回商品管理</router-link></div>

  <!-- 到期提醒 -->
  <div class="expiring-panel" v-if="expiringItems.length">
    <div class="expiring-title">到期提醒 ({{ expiringItems.length }}项)</div>
    <div v-for="item in expiringItems" :key="item.type + '-' + (item.id || item.poolId)" class="expiring-item">
      <span class="expiring-tag" :class="item.type === 'decoration' ? 'tag-dec' : 'tag-pool'">{{ item.type === 'decoration' ? '装饰品' : '卡池' }}</span>
      <span v-if="item.type === 'decoration'">{{ item.name }} — 用户{{ item.userId }} 于 {{ formatTime(item.expireTime) }} 到期</span>
      <span v-else>{{ item.name }} — {{ item.expiringCount }}/{{ item.total }} 张即将过期</span>
    </div>
  </div>

  <!-- 筛选栏 -->
  <div class="search-bar">
    <input v-model="filters.keyword" placeholder="卡号/内容搜索" class="input" style="flex:1;min-width:120px" @keyup.enter="load" />
    <select v-model="filters.cardType" class="input" style="width:120px" @change="load"><option value="">全部类型</option><option value="card_key">卡密</option><option value="auto_recharge">自动充值</option><option value="invite_code">邀请码</option><option value="custom">自定义卡密</option><option value="card_pool">选择卡池</option><option value="text">文本内容</option></select>
    <button class="btn" @click="load">搜索</button>
  </div>

  <!-- 统计 -->
  <div style="margin:12px 0;font-size:13px;color:#888" v-if="stats.length">近30天: {{ stats.map((s: any) => typeLabel(s.card_type) + ' ' + s.cnt + '次').join('，') }}</div>

  <!-- 表格 -->
  <div class="card-table"><table>
    <thead><tr><th>ID</th><th>订单ID</th><th>用户ID</th><th>商品</th><th>发货类型</th><th>卡号</th><th>发货内容</th><th>时间</th></tr></thead>
    <tbody>
      <tr v-for="row in list" :key="row.id">
        <td>{{ row.id }}</td>
        <td><router-link :to="'/appstore/orders/edit/' + row.order_id">{{ row.order_id }}</router-link></td>
        <td>{{ row.user_id }}</td>
        <td>{{ row.product_name }}</td>
        <td>{{ typeLabel(row.card_type) }}</td>
        <td style="font-family:monospace;font-size:12px">{{ row.card_number }}</td>
        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px" :title="row.delivery_info">{{ row.delivery_info }}</td>
        <td style="font-size:12px">{{ formatTime(row.create_time) }}</td>
      </tr>
      <tr v-if="!list.length"><td colspan="8" style="text-align:center;padding:40px;color:#999">暂无发送记录</td></tr>
    </tbody>
  </table></div>

  <!-- 分页 -->
  <div class="pagination" v-if="total > pageSize">
    <button :disabled="page <= 1" @click="page--; load()">上一页</button>
    <span>第 {{ page }} / {{ totalPages }} 页（共 {{ total }} 条）</span>
    <button :disabled="page >= totalPages" @click="page++; load()">下一页</button>
  </div>
</div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const stats = ref<any[]>([])
const expiringItems = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

const filters = reactive({ keyword: '', cardType: '' })

const totalPages = ref(0)

const typeLabels: Record<string, string> = {
  card_key: '卡密', auto_recharge: '自动充值', invite_code: '邀请码',
  custom: '自定义卡密', card_pool: '选择卡池', text: '文本内容'
}

function typeLabel(t: string) { return typeLabels[t] || t }

function formatTime(t: string) {
  if (!t) return ''
  return t.replace('T', ' ').substring(0, 19)
}

async function load() {
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (filters.keyword) params.keyword = filters.keyword
    if (filters.cardType) params.cardType = filters.cardType
    const res = await request.get('/admin/delivery-logs', { params })
    list.value = res.list || []
    total.value = res.total || 0
    totalPages.value = Math.ceil(total.value / pageSize.value)
  } catch (e) { /* ignore */ }
}

async function loadStats() {
  try {
    const res = await request.get('/admin/delivery-logs/stats')
    stats.value = res || []
  } catch (e) { /* ignore */ }
}

async function loadExpiring() {
  try {
    const res = await request.get('/admin/delivery-logs/expiring?days=7')
    expiringItems.value = res?.items || []
  } catch (e) { /* ignore */ }
}

onMounted(() => { load(); loadStats(); loadExpiring() })
</script>

<style scoped>
.cpool { max-width:1200px; margin:0 auto; padding:20px }
.search-bar { display:flex; gap:8px; align-items:center; margin:12px 0 }

.expiring-panel { background:#FFF8E1; border:1px solid #FFB74D; border-radius:10px; padding:12px 14px; margin-bottom:12px }
.expiring-title { font-size:14px; font-weight:600; color:#E65100; margin-bottom:8px }
.expiring-item { display:flex; gap:8px; align-items:center; font-size:12px; color:#666; margin-bottom:4px }
.expiring-tag { padding:1px 6px; border-radius:4px; font-size:10px; color:#fff }
.tag-dec { background:#FF7043 }
.tag-pool { background:#8D6E63 }

.card-table { overflow-x:auto }
.card-table table { width:100%; border-collapse:collapse; font-size:13px }
.card-table th, .card-table td { padding:8px 10px; border:1px solid #eee; text-align:left }
.card-table th { background:#f5f5f5; font-weight:600 }
.pagination { display:flex; gap:10px; align-items:center; justify-content:center; margin-top:16px }
.pagination button { padding:6px 14px; border:1px solid #ddd; border-radius:4px; background:#fff; cursor:pointer }
.pagination button:disabled { opacity:.4; cursor:default }
</style>
