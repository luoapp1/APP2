<template>
<div class="page">
  <div class="topbar">
    <button class="back-btn" @click="$router.back()">&larr;</button>
    <span class="title">发货记录</span>
  </div>

  <div class="content">
    <div class="stats-cards" v-if="stats.length">
      <div class="stat-card" v-for="s in stats" :key="s.card_type">
        <span class="stat-num">{{ s.cnt }}</span>
        <span class="stat-label">{{ typeLabel(s.card_type) }}</span>
      </div>
    </div>
    <div class="stats-hint-row" v-if="stats.length">最近30天发卡统计</div>

    <div class="alert-card" v-if="expiringItems.length">
      <div class="alert-title">即将到期提醒</div>
      <div class="alert-item" v-for="item in expiringItems" :key="item.type + '-' + (item.id || item.poolId)">
        <div class="alert-dot" :class="item.type === 'decoration' ? 'dot-dec' : 'dot-pool'"></div>
        <span class="alert-text">
          <template v-if="item.type === 'decoration'">{{ item.name }} · 用户{{ item.userId }} · {{ formatTime(item.expireTime) }}</template>
          <template v-else>{{ item.name }} · {{ item.expiringCount }}/{{ item.total }} 张</template>
        </span>
      </div>
    </div>

    <div class="search-bar">
      <div class="search-input-wrap">
        <svg class="search-icon" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#999" stroke-width="2"/><path d="M20 20l-3.5-3.5" stroke="#999" stroke-width="2"/></svg>
        <input v-model="filters.keyword" placeholder="搜索卡号/内容" class="search-input" @keyup.enter="load" />
      </div>
      <select v-model="filters.cardType" class="type-select" @change="load">
        <option value="">全部</option>
        <option value="card_key">卡密</option>
        <option value="auto_recharge">自动充值</option>
        <option value="invite_code">邀请码</option>
        <option value="custom">自定义</option>
        <option value="card_pool">卡池</option>
        <option value="text">文本</option>
      </select>
    </div>

    <div class="list" v-if="list.length">
      <div class="list-item" v-for="row in list" :key="row.id">
        <div class="item-top">
          <span class="item-type-tag" :class="'tag-' + (row.card_type || '')">{{ typeLabel(row.card_type) }}</span>
          <span class="item-time">{{ formatTime(row.create_time) }}</span>
        </div>
        <div class="item-body">
          <div class="item-field"><span class="f-label">商品</span><span class="f-val">{{ row.product_name }}</span></div>
          <div class="item-field"><span class="f-label">卡号</span><span class="f-val mono">{{ row.card_number || '-' }}</span></div>
          <div class="item-field"><span class="f-label">用户ID</span><span class="f-val">{{ row.user_id }} · 订单{{ row.order_id }}</span></div>
          <div class="item-field" v-if="row.delivery_info"><span class="f-label">内容</span><span class="f-val">{{ row.delivery_info }}</span></div>
        </div>
      </div>
    </div>
    <div class="empty" v-if="!list.length && !firstLoad">
      <div class="empty-text">暂无发送记录</div>
    </div>

    <div class="pager" v-if="total > pageSize">
      <button :disabled="page <= 1" @click="page--; load()">上一页</button>
      <span class="pager-info">{{ page }}/{{ totalPages }} 页 · {{ total }} 条</span>
      <button :disabled="page >= totalPages" @click="page++; load()">下一页</button>
    </div>
  </div>
</div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const stats = ref<any[]>([])
const expiringItems = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const totalPages = ref(0)
const firstLoad = ref(true)
const filters = reactive({ keyword: '', cardType: '' })

const typeLabels: Record<string, string> = {
  card_key: '卡密', auto_recharge: '自动充值', invite_code: '邀请码',
  custom: '自定义', card_pool: '卡池', text: '文本'
}

function typeLabel(t: string) { return typeLabels[t] || t || '其他' }
function formatTime(t: string) { if (!t) return ''; return t.replace('T', ' ').substring(0, 16) }

async function load() {
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (filters.keyword) params.keyword = filters.keyword
    if (filters.cardType) params.cardType = filters.cardType
    const res = await request.get({ url: '/api/admin/delivery-logs', params })
    list.value = Array.isArray(res.list) ? res.list : []
    total.value = res.total || 0
    totalPages.value = Math.ceil(total.value / pageSize.value)
  } catch {} finally { firstLoad.value = false }
}

async function loadStats() {
  try {
    const res = await request.get({ url: '/api/admin/delivery-logs/stats' })
    stats.value = Array.isArray(res) ? res : []
  } catch {}
}

async function loadExpiring() {
  try {
    const res = await request.get({ url: '/api/admin/delivery-logs/expiring', params: { days: 7 }, showErrorMessage: false })
    expiringItems.value = Array.isArray(res?.items) ? res.items : []
  } catch {}
}

onMounted(() => { load(); loadStats(); loadExpiring() })
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; }
.topbar { display: flex; align-items: center; padding: 14px 16px; background: #fff; gap: 12px; border-bottom: 1px solid #eee; position: sticky; top: 0; z-index: 10; }
.back-btn { border: none; background: none; font-size: 20px; cursor: pointer; color: #333; padding: 0; line-height: 1; }
.title { font-size: 17px; font-weight: 700; color: #1a1a1a; }
.content { padding: 14px; }

.stats-cards { display: flex; gap: 10px; margin-bottom: 12px; }
.stat-card { flex: 1; background: #fff; border-radius: 12px; padding: 14px 12px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.stat-num { font-size: 24px; font-weight: 800; color: #FF6B6B; display: block; }
.stat-label { font-size: 11px; color: #888; margin-top: 4px; display: block; }
.stats-hint-row { font-size: 12px; color: #aaa; margin-bottom: 12px; }

.alert-card { background: #FFF9ED; border: 1px solid #FFD699; border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; }
.alert-title { font-size: 13px; font-weight: 700; color: #CC7A00; margin-bottom: 8px; }
.alert-item { display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; }
.alert-dot { width: 6px; height: 6px; border-radius: 50%; margin-top: 5px; flex-shrink: 0; }
.dot-dec { background: #FF7043; }
.dot-pool { background: #8D6E63; }
.alert-text { font-size: 12px; color: #8B6914; line-height: 1.4; }

.search-bar { display: flex; gap: 8px; margin-bottom: 14px; }
.search-input-wrap { flex: 1; position: relative; display: flex; align-items: center; background: #fff; border-radius: 10px; padding: 0 12px; box-shadow: 0 1px 2px rgba(0,0,0,.04); }
.search-icon { width: 16px; height: 16px; flex-shrink: 0; }
.search-input { flex: 1; border: none; outline: none; padding: 10px 8px; font-size: 13px; background: transparent; }
.type-select { border: none; background: #fff; border-radius: 10px; padding: 10px 8px; font-size: 12px; color: #666; box-shadow: 0 1px 2px rgba(0,0,0,.04); cursor: pointer; outline: none; }

.list { display: flex; flex-direction: column; gap: 10px; }
.list-item { background: #fff; border-radius: 12px; padding: 12px 14px; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.item-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.item-type-tag { font-size: 10px; padding: 3px 8px; border-radius: 6px; font-weight: 600; }
.tag-card_key, .tag-auto_recharge { background: #E3F2FD; color: #1565C0; }
.tag-invite_code { background: #F3E5F5; color: #7B1FA2; }
.tag-custom { background: #FFF3E0; color: #E65100; }
.tag-card_pool { background: #E8F5E9; color: #2E7D32; }
.tag-text { background: #ECEFF1; color: #546E7A; }
.tag-decoration { background: #FCE4EC; color: #C62828; }
.item-time { font-size: 11px; color: #aaa; }
.item-body { display: flex; flex-direction: column; gap: 6px; }
.item-field { display: flex; gap: 8px; font-size: 12px; }
.f-label { color: #999; flex-shrink: 0; min-width: 42px; }
.f-val { color: #333; word-break: break-all; }
.mono { font-family: monospace; font-size: 11px; }

.empty { text-align: center; padding: 60px 20px; }
.empty-text { font-size: 14px; color: #bbb; }

.pager { display: flex; gap: 12px; align-items: center; justify-content: center; margin-top: 20px; padding-bottom: 10px; }
.pager button { padding: 8px 18px; border: 1px solid #e0e0e0; border-radius: 10px; background: #fff; cursor: pointer; font-size: 13px; color: #555; }
.pager button:disabled { opacity: .35; cursor: default; }
.pager-info { font-size: 12px; color: #999; }
</style>
