<template>
  <div class="page">
    <div class="top-bar">
      <div class="back-btn" @click="$router.back()">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
        </svg>
      </div>
      <span class="top-title" v-if="info">我的{{ info.name }}</span>
      <div class="headphones">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="16" height="16">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3 18v-6a9 9 0 0118 0v6"/>
          <path d="M21 19a2 2 0 01-2 2h-1a2 2 0 01-2-2v-3a2 2 0 012-2h3zM3 19a2 2 0 002 2h1a2 2 0 002-2v-3a2 2 0 00-2-2H3z"/>
        </svg>
      </div>
    </div>

    <div class="content" v-if="info">
      <div class="safety-banner">
        <svg fill="currentColor" viewBox="0 0 24 24" width="15" height="15" class="shield-icon">
          <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
        </svg>
        <span class="safety-text">安全保障中</span>
      </div>

      <div class="detail-card" :style="{ background: info.cardBg }">
        <div class="detail-body">
          <div class="detail-left">
            <div class="detail-circle">
              <span class="detail-circle-text" :style="{ color: info.color }">{{ info.icon }}</span>
            </div>
            <div>
              <div class="detail-name">{{ info.name }}</div>
              <div class="detail-type">{{ info.type }}</div>
            </div>
          </div>
          <div class="detail-right">
            <div class="detail-balance">{{ fmt(info.balance, info.dp) }}</div>
            <span class="detail-tag">可用余额</span>
          </div>
        </div>
        <div class="detail-footer">
          <span class="detail-card-btn" @click="showCardNum = !showCardNum">{{ showCardNum && info.accountNumber ? info.accountNumber : '查看卡号' }}</span>
          <span class="detail-footer-btn" @click="goBills">交易记录</span>
        </div>
      </div>

      <div v-if="tasks.length > 0" style="background:#fff;border-radius:12px;padding:16px;margin-top:12px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="font-size:15px;font-weight:600;color:#333;">{{ info.name }}任务</div>
          <div style="font-size:12px;color:#999;">完成任务赚取{{ info.name }}</div>
        </div>
        <div v-for="(task, idx) in tasks" :key="idx" style="display:flex;align-items:center;gap:12px;padding:12px 0;border-top:1px solid #f5f5f5;">
          <div style="width:36px;height:36px;border-radius:10px;background:#f0f5ff;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">{{ task.emoji }}</div>
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:500;color:#333;">{{ task.name }}</div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
              <div style="flex:1;height:4px;background:#f3f4f6;border-radius:999px;overflow:hidden;">
                <div :style="{ width:(task.done/task.max*100)+'%',height:'100%',background:task.done>=task.max?'#10b981':'#409EFF',borderRadius:'999px',transition:'width .3s' }"></div>
              </div>
              <span style="font-size:11px;color:#999;flex-shrink:0;">{{ task.done }}/{{ task.max }}</span>
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-size:13px;font-weight:700;color:#f59e0b;">+{{ task.rwAmt }}{{ info.name }}</div>
          </div>
        </div>
      </div>

      <div class="task-empty" v-else-if="tasksLoaded && tasks.length === 0" />

      <div class="manage-row">
        <div class="manage-left">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="15" height="15">
            <circle cx="12" cy="12" r="3"/>
            <path d="M19.4 15a2 2 0 00-2.4.3l-1-.5a7 7 0 01-1-.51l-1 .5a2 2 0 00-2.4-.3 7.3 7.3 0 01-1 .2H9a2 2 0 00-1.6.8L6 14.5a7 7 0 011-1.11A2 2 0 006 12a2 2 0 00-1-1.39A7 7 0 016 9.5l1.4 1.1A2 2 0 009 11.5h.6a7.3 7.3 0 011 .21 2 2 0 012.4-.31l1 .51a7 7 0 011-.51l1-.5a2 2 0 012.4.3A7.3 7.3 0 0119 11.5h.6a2 2 0 001.6-.8L22 9.5a7 7 0 01-1 1.11A2 2 0 0118 12a2 2 0 011 1.39A7 7 0 0120 14.5l-1.4-1.1a2 2 0 00-1.6-.8h-.6a1 1 0 00-1 .2z"/>
          </svg>
          <span class="manage-text">{{ info.name }}管理</span>
        </div>
        <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="12" height="12" class="arrow-icon">
          <path d="M9 18l6-6-6-6"/>
        </svg>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreCurrencyDetail' })

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const info = ref<any>(null)
const tasks = ref<any[]>([])
const tasksLoaded = ref(false)
const showCardNum = ref(false)

const fmt = (v: number, dp: number) => v.toFixed(dp)

const actionLabels: Record<string, string> = {
  post: '发帖', comment: '评论', like: '点赞', checkin: '签到', share: '分享',
  download: '下载应用', register: '注册', follow: '关注', favorite: '收藏',
  purchase: '购买', upload: '上传文件', invite: '邀请好友', profile: '完善资料',
  view_post: '浏览帖子',
}

const actionEmoji: Record<string, string> = {
  checkin: '📅', post: '📝', comment: '💬', like: '❤️', share: '📤',
  download: '📥', register: '🎉', follow: '👥', favorite: '⭐', purchase: '🛒',
  upload: '🎨', invite: '✉️', profile: '👤', view_post: '👀'
}

const typeLabels: Record<string, string> = { daily: '每日', weekly: '每周', monthly: '每月', yearly: '每年', permanent: '永久', once: '一次性' }

const gradients = [
  { bg: 'linear-gradient(180deg, #ffaa22 0%, #e68c00 100%)', color: '#f59e0b' },
  { bg: 'linear-gradient(180deg, #8b5cf6 0%, #7c3aed 100%)', color: '#8b5cf6' },
  { bg: 'linear-gradient(180deg, #2290ee 0%, #1573c2 100%)', color: '#2290ee' },
  { bg: 'linear-gradient(180deg, #10b981 0%, #059669 100%)', color: '#10b981' },
  { bg: 'linear-gradient(180deg, #ef4444 0%, #dc2626 100%)', color: '#ef4444' },
  { bg: 'linear-gradient(180deg, #ec4899 0%, #db2777 100%)', color: '#ec4899' },
  { bg: 'linear-gradient(180deg, #06b6d4 0%, #0891b2 100%)', color: '#06b6d4' },
  { bg: 'linear-gradient(180deg, #f97316 0%, #ea580c 100%)', color: '#f97316' },
]

function adjustColor(hex: string, amount: number): string {
  const num = parseInt(hex.replace('#', ''), 16)
  const r = Math.max(0, Math.min(255, ((num >> 16) & 255) + amount))
  const g = Math.max(0, Math.min(255, ((num >> 8) & 255) + amount))
  const b = Math.max(0, Math.min(255, (num & 255) + amount))
  return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1)}`
}

function getTaskReward(task: any, key: string): number {
  if (rewardFields[key]) return Number(task[rewardFields[key]] || 0)
  if (task.currency_rewards) {
    try {
      const cr = typeof task.currency_rewards === 'string' ? JSON.parse(task.currency_rewards) : task.currency_rewards
      return Number(cr[key] || 0)
    } catch { return 0 }
  }
  return 0
}

const rewardFields: Record<string, string> = {
  points: 'points_reward',
  experience: 'exp_reward',
  balance: 'balance_reward',
}

async function loadTasks(key: string) {
  tasksLoaded.value = false
  try {
    const uid = userStore.info?.userId
    if (!uid) return
    const taskRes: any = await request.get({ url: '/api/custom-task/my', params: { userId: uid } })
    const all = Array.isArray(taskRes) ? taskRes : (taskRes?.data || [])
    tasks.value = all
      .filter((t: any) => getTaskReward(t, key) > 0)
      .map((t: any) => ({
        name: t.name,
        emoji: actionEmoji[t.action_type] || '✅',
        done: t.progress || 0,
        max: t.target_count || 1,
        rwAmt: getTaskReward(t, key),
        id: t.id,
      }))
    tasksLoaded.value = true
  } catch {}
}

const goBills = () => {
  const key = route.query.key as string
  if (key) router.push({ path: '/appstore/bills', query: { key } })
}

onMounted(() => {
  const key = route.query.key as string
  if (!key) return

  const g = gradients[0]
  info.value = {
    key,
    name: key,
    icon: key.charAt(0).toUpperCase(),
    type: '虚拟币',
    balance: 0,
    dp: 0,
    cardBg: g.bg,
    color: g.color,
    accountNumber: '',
  }

  request.get<any[]>({ url: '/api/currency-settings', showErrorMessage: false }).then(settings => {
    const arr = Array.isArray(settings) ? settings : []
    const idx = arr.findIndex((s: any) => s.currency_key === key)
    if (idx === -1) return
    const s = arr[idx]
    const gi = gradients[idx % gradients.length]
    const c = s.card_color
    info.value = {
      key,
      name: s.display_name || key,
      icon: (s.display_icon || s.display_symbol || s.display_name?.charAt(0) || key.charAt(0)).substring(0, 2),
      type: s.currency_type === 'quota' ? '次数' : '虚拟币',
      balance: 0,
      dp: s.decimal_places || 0,
      cardBg: c ? `linear-gradient(180deg, ${c} 0%, ${adjustColor(c, -20)} 100%)` : gi.bg,
      color: c || gi.color,
      accountNumber: '',
    }
  }).catch(() => {})

  request.get<any>({ url: '/api/user/currency-balance', showErrorMessage: false }).then(res => {
    const currencies = res?.currencies || res?.data?.currencies || []
    const item = currencies.find((c: any) => c.currency_key === key)
    if (item && info.value) {
      info.value.balance = item.available || 0
      info.value.accountNumber = item.account_number || ''
    }
  }).catch(() => {})

  loadTasks(key)
})
</script>

<style scoped>
.page { min-height: 100vh; background: #f9f9fb; display: flex; flex-direction: column; }

.top-bar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px; background: #fff;
}
.back-btn { cursor: pointer; color: #000; }
.top-title { font-size: 16px; font-weight: 500; }
.headphones { color: #000; cursor: pointer; }

.content { padding: 10px 14px; flex: 1; }

.safety-banner {
  background: #e8f0ff; border-radius: 8px;
  padding: 10px 14px; margin-bottom: 10px;
  display: flex; align-items: center; gap: 6px;
}
.shield-icon { color: #3b82f6; }
.safety-text { color: #3b82f6; font-size: 13px; }

.detail-card { border-radius: 8px; color: #fff; overflow: hidden; }

.detail-body {
  padding: 14px; display: flex; justify-content: space-between; align-items: flex-start;
}
.detail-left { display: flex; align-items: center; gap: 8px; }
.detail-circle {
  width: 40px; height: 40px; border-radius: 50%; background: #fff;
  display: flex; align-items: center; justify-content: center;
}
.detail-circle-text { font-size: 17px; }
.detail-name { font-size: 15px; font-weight: 500; }
.detail-type { opacity: .9; margin-top: 2px; font-size: 11px; }
.detail-right { text-align: right; }
.detail-balance { font-size: 15px; }
.detail-tag {
  display: inline-block; margin-top: 5px; font-size: 11px;
  background: rgba(255,255,255,.25); padding: 2px 6px; border-radius: 4px;
}
.detail-footer {
  display: flex; align-items: center;
  padding: 0; background: rgba(0,0,0,.1); font-size: 12px;
}
.detail-card-btn, .detail-footer-btn {
  flex: 1; text-align: center; padding: 10px 0; cursor: pointer; user-select: none;
}

.manage-row {
  background: #fff; border-radius: 8px; margin-top: 10px;
  padding: 12px; display: flex; align-items: center; justify-content: space-between;
  cursor: pointer;
}
.manage-left { display: flex; align-items: center; gap: 8px; }
.manage-text { font-size: 14px; }
.arrow-icon { color: #d1d5db; }

.task-empty { height: 60px; }
</style>
