<template>
  <div class="balance-page">
    <div class="balance-back" @click="$router.back()">
      <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="18" height="18">
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
      </svg>
    </div>

    <div class="balance-body">
      <div class="balance-avatar">¥</div>
      <div class="balance-title">我的零钱</div>
      <div class="balance-amount">{{ formatAmount(balance, 'balance') }}</div>
    </div>

    <div class="balance-bottom">
      <button class="balance-btn recharge-btn">充值</button>
      <button class="balance-btn withdraw-btn">提现</button>
      <div class="balance-faq">
        <a href="#" class="faq-link">常见问题</a>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useCurrency } from '@/composables/useCurrency'

defineOptions({ name: 'AppStoreBalance' })

const { balance, formatAmount, load: loadCurrency } = useCurrency()

onMounted(loadCurrency)
</script>

<style scoped>
.balance-page {
  min-height: 100vh;
  background: #fff;
  display: flex;
  flex-direction: column;
}

.balance-back {
  padding: 12px;
  cursor: pointer;
  color: #000;
}

.balance-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 24px;
}

.balance-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: #f59e0b;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 28px;
  font-weight: 500;
}

.balance-title {
  margin-top: 14px;
  font-size: 18px;
  color: #000;
}

.balance-amount {
  margin-top: 8px;
  font-size: 40px;
  font-weight: 600;
  color: #000;
}

.balance-bottom {
  padding: 0 20px 32px;
}

.balance-btn {
  border: none;
  border-radius: 16px;
  padding: 13px 0;
  font-size: 15px;
  cursor: pointer;
  display: block;
  width: 100%;
  max-width: 220px;
  margin: 0 auto;
}

.recharge-btn {
  background: #096bff;
  color: #fff;
}

.withdraw-btn {
  background: #f6f6f6;
  color: #000;
  margin-top: 10px;
}

.balance-faq {
  text-align: center;
  margin-top: 20px;
}

.faq-link {
  color: #096bff;
  font-size: 15px;
  text-decoration: none;
}
</style>
