<template>
  <div style="min-height: 100vh; display: flex; flex-direction: column; background: var(--app-page-bg)">
    <!-- 顶部导航栏 -->
    <div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">{{ activeTab === 'titles' ? '我的印记' : '头像管理' }}</span>
    </div>

    <!-- Tab 切换条 -->
    <div style="display: flex; justify-content: center; gap: 32px; padding: 12px 16px 0; background: #fff; border-bottom: 1px solid #f3f4f6;">
      <div
        v-for="tab in mainTabs"
        :key="tab.key"
        @click="switchMainTab(tab.key)"
        style="padding: 6px 4px; cursor: pointer; position: relative; transition: all 0.2s;"
        :style="{
          color: activeTab === tab.key ? '#1f2937' : '#9ca3af',
          fontWeight: activeTab === tab.key ? '600' : '400',
          fontSize: '15px'
        }"
      >
        {{ tab.label }}
        <div
          v-if="activeTab === tab.key"
          style="position: absolute; bottom: -1px; left: 50%; transform: translateX(-50%); width: 24px; height: 3px; border-radius: 2px; background: #FF4757;"
        />
      </div>
    </div>

    <div style="flex: 1; overflow-y: auto;">

      <!-- ========== 头像框区 ========== -->
      <template v-if="activeTab === 'frames'">
        <div style="padding-bottom: 16px">
          <!-- 顶部头像预览 -->
          <div
            style="display: flex; flex-direction: column; align-items: center; padding: 24px 16px 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px"
          >
            <div style="position: relative; width: 120px; height: 120px; margin: 0 auto 12px">
              <img
                v-if="activeFrameUrl"
                :src="activeFrameUrl"
                style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none"
              />
              <img
                :src="userAvatar"
                style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 80px; height: 80px; border-radius: 50%; object-fit: cover"
              />
            </div>
            <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 4px">
              {{ activeFrameName || '未使用头像框' }}
            </div>
            <div style="display: flex; gap: 8px">
              <button
                v-if="activeFrameId"
                style="font-size: 12px; color: #ef4444; border: none; background: none; cursor: pointer"
                @click="handleCancelFrame"
              >取消使用</button>
              <button
                style="font-size: 12px; color: #00bfa5; border: none; background: none; cursor: pointer"
                :disabled="autoGrantLoading"
                @click="handleAutoGrant"
              >{{ autoGrantLoading ? '同步中...' : '同步获取' }}</button>
            </div>
          </div>

          <!-- 未登录 -->
          <div v-if="!isLogin" style="text-align: center; padding: 40px; color: #9ca3af">
            <p style="margin-bottom: 16px">请先登录后查看</p>
            <button
              style="padding: 10px 32px; border-radius: 8px; border: none; background: #00bfa5; color: #fff; font-size: 14px; cursor: pointer"
              @click="$router.push('/appstore/browse/login')"
            >去登录</button>
          </div>

          <!-- 头像框列表 -->
          <div v-else style="padding: 0 16px">
            <div style="font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 12px">
              头像框列表
              <span style="font-size: 12px; color: #9ca3af; margin-left: 4px">(点击使用)</span>
            </div>

            <div v-if="loading" style="text-align: center; padding: 40px; color: #9ca3af">加载中...</div>
            <div v-else-if="grantMsg" style="text-align: center; color: #00bfa5; font-size: 13px; padding: 8px 0">{{ grantMsg }}</div>

            <div v-else style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px">
              <div
                v-for="frame in frames"
                :key="frame.id"
                style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; border: 2px solid transparent; position: relative"
                :style="{
                  borderColor: frame.isActive ? '#00bfa5' : 'transparent',
                  opacity: frame.owned ? '1' : '0.55'
                }"
                @click="handleSelectFrame(frame)"
              >
                <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px">
                  <img
                    :src="$fixImgUrl(frame.image_url)"
                    style="width: 100%; height: 100%; object-fit: contain; border-radius: 8px"
                  />
                  <div
                    v-if="!frame.owned"
                    style="position: absolute; inset: 0; background: rgba(0,0,0,.3); border-radius: 8px; display: flex; align-items: center; justify-content: center"
                  >
                    <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
                    </svg>
                  </div>
                </div>
                <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 4px; line-height: 1.2">
                  {{ frame.name }}
                </div>
                <div style="font-size: 10px; color: #9ca3af; text-align: center">
                  {{ (frame.owned ? '' : '(未获取) ') + getObtainLabel(frame.obtain_type || frame.obtainType) }}
                </div>
                <div v-if="frame.isActive" style="position: absolute; top: 4px; right: 4px; background: #00bfa5; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px">使用中</div>
              </div>
            </div>

            <div v-if="!loading && frames.length === 0" style="text-align: center; padding: 40px; color: #9ca3af">
              暂未上传头像框
            </div>
          </div>
        </div>
      </template>

      <!-- ========== 称号区 ========== -->
      <template v-if="activeTab === 'titles'">
        <!-- 个人信息区 -->
        <div style="display: flex; align-items: center; padding: 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px;">
          <img :src="userAvatar" style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover; flex-shrink: 0" />
          <div style="margin-left: 12px; flex: 1;">
            <div style="font-size: 17px; font-weight: 600; color: #1f2937; margin-bottom: 2px;">
              {{ userInfo.nickname || userInfo.userName || '用户' }}
            </div>
            <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
              <span style="font-size: 12px; color: #9ca3af;">已佩戴印记</span>
              <template v-if="activeTitles.length > 0">
                <span
                  v-for="at in activeTitles"
                  :key="at.id"
                  style="font-size: 11px; padding: 2px 8px; border-radius: 10px; font-weight: 500;"
                  :style="{ background: getTitleColorMap(at.id).bg || '#f0f5ff', color: getTitleColorMap(at.id).color || '#409EFF' }"
                >{{ at.name }}</span>
              </template>
              <span v-else style="font-size: 11px; color: #ccc;">无</span>
            </div>
          </div>
        </div>

        <!-- 称号分类 Tab -->
        <div style="padding: 0 16px 14px; display: flex; gap: 6px; overflow-x: auto;">
          <div
            v-for="cat in titleCategoryTabs"
            :key="cat.key"
            @click="activeTitleCategory = cat.key; loadTitleCategory()"
            style="padding: 7px 16px; border-radius: 20px; font-size: 13px; font-weight: 500; cursor: pointer; transition: all .2s; white-space: nowrap; flex-shrink: 0;"
            :style="{ background: activeTitleCategory === cat.key ? '#1f2937' : '#fff', color: activeTitleCategory === cat.key ? '#fff' : '#6b7280', boxShadow: activeTitleCategory === cat.key ? '0 2px 8px rgba(0,0,0,.12)' : '0 1px 2px rgba(0,0,0,.04)' }"
          >{{ cat.label }}</div>
        </div>

        <!-- 称号网格 -->
        <div v-if="titleLoading" style="text-align: center; padding: 60px 0; color: #9ca3af;">加载中...</div>
        <div v-else style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; padding: 0 16px 32px;">
          <div
            v-for="title in displayTitles"
            :key="title.id"
            @click="handleTitleClick(title)"
            style="background: #fff; border-radius: 16px; padding: 14px 8px 10px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; transition: all .2s; box-shadow: 0 1px 3px rgba(0,0,0,.04);"
            :style="title.isActive ? { border: '2px solid #FF4757', transform: 'scale(1.02)' } : { border: '2px solid transparent' }"
          >
            <!-- 分类角标 -->
            <div v-if="title.category" style="position: absolute; top: 6px; left: 6px; font-size: 9px; padding: 1px 6px; border-radius: 6px; font-weight: 500;" :style="{ background: catBg(title.category), color: catColor(title.category) }">{{ catLabel(title.category) }}</div>
            <!-- 称号图标 -->
            <div style="width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 8px; position: relative; transition: all .3s;" :style="{ background: title.owned ? title.icon ? '#fff' : (title.bg_color || title.bgColor || '#ecf5ff') : '#f9fafb', boxShadow: title.isActive ? '0 0 0 3px rgba(255,71,87,.15)' : 'none' }">
              <img v-if="title.icon" :src="$fixImgUrl(title.icon)" style="width: 42px; height: 42px; object-fit: contain;" :style="{ filter: title.owned ? 'none' : 'grayscale(100%)', opacity: title.owned ? 1 : 0.45 }" />
              <span v-else style="font-size: 22px; font-weight: 800;" :style="{ color: title.owned ? (title.color || '#409EFF') : '#d1d5db' }">{{ (title.name || '?')[0] }}</span>
            </div>
            <!-- 名称 -->
            <div style="font-size: 13px; text-align: center; line-height: 1.3; margin-bottom: 3px; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" :style="{ color: title.owned ? '#1f2937' : '#9ca3af', fontWeight: title.owned ? '600' : '400' }">{{ title.name }}</div>
            <!-- 状态 -->
            <div style="font-size: 10px; font-weight: 500;" :style="{ color: title.isActive ? '#FF4757' : (title.owned ? '#10b981' : '#d1d5db') }">
              {{ title.isActive ? '使用中' : (title.owned ? '未佩戴' : '未获取') }}
            </div>
          </div>
        </div>

        <div v-if="!titleLoading && displayTitles.length === 0" style="text-align: center; padding: 60px 0; color: #9ca3af;">
          暂无称号
        </div>
      </template>
    </div>

    <!-- 称号详情弹窗 -->
    <div v-if="titleDetailVisible" class="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4" @click.self="titleDetailVisible = false">
      <div class="bg-white rounded-t-3xl sm:rounded-2xl shadow-xl w-full sm:max-w-sm max-h-[75vh] overflow-hidden sm:overflow-visible animate-slide-up" @click.stop>
        <!-- 图标头部 -->
        <div style="padding: 28px 16px 20px; display: flex; flex-direction: column; align-items: center; position: relative; background: linear-gradient(135deg, #f8f9fc 0%, #f0f4ff 100%);">
          <button style="position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; border-radius: 50%; background: rgba(0,0,0,.06); border: none; display: flex; align-items: center; justify-content: center; cursor: pointer;" @click="titleDetailVisible = false">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
          <div style="width: 88px; height: 88px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 14px; box-shadow: 0 4px 16px rgba(0,0,0,.08);" :style="{ background: titleDetail?.owned ? (titleDetail.bg_color || titleDetail.bgColor || '#fff') : '#f3f4f6' }">
            <img v-if="titleDetail?.icon" :src="$fixImgUrl(titleDetail.icon)" style="width: 60px; height: 60px; object-fit: contain;" :style="{ filter: titleDetail?.owned ? 'none' : 'grayscale(100%)', opacity: titleDetail?.owned ? 1 : 0.5 }" />
            <span v-else style="font-size: 32px; font-weight: 800;" :style="{ color: titleDetail?.owned ? (titleDetail.color || '#409EFF') : '#d1d5db' }">{{ (titleDetail?.name || '?')[0] }}</span>
          </div>
          <div style="font-size: 19px; font-weight: 700; color: #1f2937; margin-bottom: 2px;">{{ titleDetail?.name }}</div>
          <div v-if="titleDetail?.description" style="font-size: 12px; color: #9ca3af; text-align: center; max-width: 260px;">{{ titleDetail.description }}</div>
          <div style="display: flex; gap: 8px; margin-top: 10px; align-items: center;">
            <span v-if="titleDetail?.category" style="font-size: 10px; padding: 2px 8px; border-radius: 8px; font-weight: 500;" :style="{ background: catBg(titleDetail.category), color: catColor(titleDetail.category) }">{{ catLabel(titleDetail.category) }}</span>
            <span v-if="titleDetail?.owned" style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #ecfdf5; color: #059669; font-weight: 500;">已获得</span>
            <span v-else style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #f3f4f6; color: #9ca3af; font-weight: 500;">未获得</span>
            <span v-if="titleDetail?.isActive" style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #fef2f2; color: #FF4757; font-weight: 500;">使用中</span>
          </div>
        </div>
        <!-- 获取条件区 -->
        <div style="padding: 20px 20px 0;">
          <div style="font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#FF4757" stroke-width="2"/><path d="M12 7v5l3 3" stroke="#FF4757" stroke-width="2" stroke-linecap="round"/></svg>获取方式
          </div>
          <div style="background: #f9fafb; border-radius: 14px; padding: 14px 16px; margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
              <span style="font-size: 14px; font-weight: 600; color: #1f2937;">{{ conditionLabel(titleDetail) }}</span>
              <svg v-if="titleDetail?.owned" width="20" height="20" viewBox="0 0 24 24" fill="#10b981"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            </div>
            <div v-if="isNumericCondition(titleDetail)" style="margin-top: 8px;">
              <div style="height: 4px; background: #e5e7eb; border-radius: 2px; overflow: hidden;">
                <div style="height: 100%; border-radius: 2px; transition: width .5s;" :style="{ width: titleDetail?.owned ? '100%' : '0%', background: titleDetail?.owned ? '#10b981' : '#FF4757' }" />
              </div>
              <div style="display: flex; justify-content: space-between; margin-top: 4px; font-size: 10px; color: #9ca3af;">
                <span>0</span>
                <span>{{ conditionValue(titleDetail) }}</span>
              </div>
            </div>
          </div>
          <div v-if="titleDetail?.expire_days || titleDetail?.expireDays" style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #f59e0b; margin-bottom: 12px; background: #fffbeb; border-radius: 10px; padding: 8px 12px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            获取后 {{ titleDetail.expire_days || titleDetail.expireDays }} 天内有效，到期自动回收
          </div>
        </div>
        <!-- 操作按钮 -->
        <div style="padding: 0 20px 20px; display: flex; flex-direction: column; gap: 8px;">
          <template v-if="titleDetail?.owned">
            <button
              v-if="!titleDetail?.isActive && activeTitles.length < 3"
              style="width: 100%; height: 46px; background: linear-gradient(135deg, #FF4757, #ff6b81); color: #fff; border: none; border-radius: 14px; font-size: 15px; font-weight: 600; cursor: pointer;"
              @click="() => { 
                var td = titleDetail;
                if (!td || !td.id) return;
                var used = activeTitles.map(function(a) { return a.slot; });
                var fs = 1; while (used.indexOf(fs) !== -1) fs++;
                request.post({ url: '/api/user/active-title', data: { titleId: td.id, slot: fs } })
                  .then(() => { 
                    loadUserTitles();
                    titleDetailVisible = false;
                  })
                  .catch((e: any) => { alert('请求失败: ' + (e?.message || '未知错误')); });
              }"
            >佩戴称号</button>
            <button
              v-else-if="titleDetail?.isActive"
              style="width: 100%; height: 46px; background: #fff; color: #666; border: 1.5px solid #e5e7eb; border-radius: 14px; font-size: 15px; font-weight: 500; cursor: pointer;"
              @click="() => { 
                var td = titleDetail;
                if (!td || !td.id) return;
                request.post({ url: '/api/user/active-title', data: { titleId: 0, slot: td.activeSlot || 1 } })
                  .then(() => { 
                    loadUserTitles();
                    titleDetailVisible = false;
                  })
                  .catch((e: any) => { alert('取消失败: ' + (e?.message || '未知错误')); });
              }"
            >取消佩戴</button>
            <div v-else style="text-align: center; font-size: 12px; color: #f59e0b; background: #fffbeb; border-radius: 10px; padding: 10px;">已达佩戴上限(3个)，请先取消一个</div>
          </template>
          <div v-else style="text-align: center; padding: 8px 0; font-size: 12px; color: #9ca3af;">达到条件后自动获得</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames, fetchActiveFrame, fetchAutoGrantFrame } from '@/api/avatar-frame'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()

// ===== 通用 =====
const isLogin = computed(() => userStore.isLogin)
const userInfo = computed(() => userStore.info || {})
const userAvatar = computed(() => userInfo.value.avatar || defaultAvatarImg)

const mainTabs = [
  { key: 'frames', label: '头像框' },
  { key: 'titles', label: '称号' },
]
const activeTab = ref('frames')

function switchMainTab(key: string) {
  activeTab.value = key
  if (key === 'titles') {
    loadTitleCategories()
    loadUserTitles()
    loadTitleCategory()
  }
}

// ===== 头像框 =====
const loading = ref(false)
const autoGrantLoading = ref(false)
const frames = ref<any[]>([])
const activeFrameId = ref(0)
const activeFrameName = ref('')
const activeFrameUrl = ref('')
const switchingId = ref(0)
const grantMsg = ref('')

function getObtainLabel(type: string) {
  if (type === 'experience') return '经验等级获取'
  if (type === 'membership') return '会员等级获取'
  if (type === 'activity') return '活动获取'
  return '手动授予'
}

async function loadFrames() {
  if (!isLogin.value) return
  loading.value = true
  try {
    const res: any = await fetchUserAvatarFrames()
    frames.value = (res.frames || []).sort((a: any, b: any) => {
      if (a.owned === b.owned) return 0
      return a.owned ? -1 : 1
    })
    activeFrameId.value = res.activeFrameId || 0
    const activeFrame = frames.value.find((f: any) => f.isActive)
    activeFrameName.value = activeFrame?.name || ''
    activeFrameUrl.value = activeFrame?.image_url || ''
  } catch {} finally { loading.value = false }
}

async function handleSelectFrame(frame: any) {
  if (!frame.owned) return
  if (frame.isActive) return
  switchingId.value = frame.id
  try {
    await fetchActiveFrame(frame.id)
    activeFrameId.value = frame.id
    activeFrameName.value = frame.name
    activeFrameUrl.value = frame.image_url
    frames.value.forEach((f: any) => { f.isActive = f.id === frame.id })
  } catch {} finally { switchingId.value = 0 }
}

async function handleCancelFrame() {
  switchingId.value = -1
  try {
    await fetchActiveFrame(0)
    activeFrameId.value = 0
    activeFrameName.value = ''
    activeFrameUrl.value = ''
    frames.value.forEach((f: any) => { f.isActive = false })
  } catch {} finally { switchingId.value = 0 }
}

async function handleAutoGrant() {
  autoGrantLoading.value = true
  grantMsg.value = ''
  try {
    const res: any = await fetchAutoGrantFrame()
    grantMsg.value = res.message || '操作成功'
    loadFrames()
  } catch { grantMsg.value = '操作失败，请重试' }
  finally {
    autoGrantLoading.value = false
    setTimeout(() => { grantMsg.value = '' }, 3000)
  }
}

// ===== 称号 =====
const titleLoading = ref(false)
const allTitles = ref<any[]>([])
const userTitles = ref<any[]>([])
const activeTitles = ref<{ id: number; name: string; slot: number }[]>([])
const activeTitleCategory = ref('')
const titleCategories = ref<{key: string; label: string}[]>([])
const titleDetailVisible = ref(false)
const titleDetail = ref<any>(null)

const conditionMap: Record<string, string> = {
  manual: '手动授予', post_count: '发布帖子数', like_received: '获得点赞数', comment_count: '发表评论数',
  checkin_days: '签到天数', coin_received: '累计余额收入', likes_given: '主动点赞数', follower_count: '粉丝数',
  following_count: '关注人数', collection_count: '创建合集数', favorite_count: '收藏帖子数',
  vote_participated: '参与投票次数', task_completed: '完成任务数', topic_followed: '关注话题数',
  draft_count: '草稿数量', mall_orders: '商城下单次数', chat_messages: '聊天发言数',
  content_purchased: '付费购买次数', app_count: '安装应用数', app_comments: '应用评论数',
  post_shared: '帖子转发数', experience_total: '累计经验值', points_earned: '累计积分收入',
  points_spent: '累计积分支出', membership_count: '购买会员次数', recharge_total: '累计充值金额',
  invite_success: '成功邀请人数', balance_spent: '累计余额支出', report_count: '举报次数',
  withdraw_total: '累计提现金额', game_played: '游戏总场次', game_won: '游戏胜场数',
  mall_review_count: '商城评价次数', coupon_used_count: '使用优惠券次数', message_sent: '发送私信数',
  rating_count: '评分次数', trust_level: '社区信任等级', app_favorite_count: '收藏应用数',
  collection_favorite_count: '收藏合集数', mall_favorite_count: '收藏商品数', verified: '通过实名认证',
  has_role: '拥有角色'
}

function conditionLabel(t: any) {
  const ct = t.condition_type || t.conditionType || 'manual'
  const cv = t.condition_value || t.conditionValue || ''
  if (ct === 'manual') return '手动授予'
  if (ct === 'has_role') return `拥有角色 ${cv || 'N/A'}`
  const label = conditionMap[ct] || ct
  return cv ? `${label} >= ${cv}` : label
}

function isNumericCondition(t: any) {
  const ct = t?.condition_type || t?.conditionType || 'manual'
  return ct !== 'manual' && ct !== 'has_role' && ct !== 'verified'
}

function conditionValue(t: any) {
  return t?.condition_value || t?.conditionValue || '0'
}
const categoryLabelMap: Record<string, string> = {

  '成就': '成就', '活动': '活动', '消费': '消费', '社交': '社交', '管理员': '管理员'
}

const categoryColorMap: Record<string, string> = {
  '成就': '#FF9800', '活动': '#E91E63', '消费': '#4CAF50', '社交': '#2196F3', '管理员': '#9C27B0'
}
const categoryBgMap: Record<string, string> = {
  '成就': '#FFF3E0', '活动': '#FCE4EC', '消费': '#E8F5E9', '社交': '#E3F2FD', '管理员': '#F3E5F5'
}

function catLabel(v: string) { return categoryLabelMap[v] || v }
function catColor(v: string) { return categoryColorMap[v] || '#999' }
function catBg(v: string) { return categoryBgMap[v] || '#f3f4f6' }

const titleCategoryTabs = computed(() => {
  const tabs = [{ key: '', label: '全部' }]
  for (const cat of titleCategories.value) {
    tabs.push({ key: cat.key, label: cat.label })
  }
  return tabs
})

const displayTitles = computed(() => {
  let list = allTitles.value
  if (activeTitleCategory.value) {
    list = list.filter(t => t.category === activeTitleCategory.value)
  }
  const activeIds = new Set(activeTitles.value.map(t => t.id))
  return list.map(t => {
    const ut = userTitles.value.find((u: any) => u.id === t.id)
    return {
      ...t,
      owned: !!ut,
      isActive: activeIds.has(t.id),
      grantTime: ut?.grant_time || '',
      activeSlot: activeTitles.value.find(a => a.id === t.id)?.slot || 0,
    }
  }).sort((a, b) => {
    if (a.owned && !b.owned) return -1
    if (!a.owned && b.owned) return 1
    if (a.owned && b.owned) {
      if (!a.grantTime && !b.grantTime) return 0
      if (!a.grantTime) return 1
      if (!b.grantTime) return -1
      return new Date(a.grantTime).getTime() - new Date(b.grantTime).getTime()
    }
    return 0
  })
})

function getTitleColorMap(titleId: number) {
  const t = userTitles.value.find((u: any) => u.id === titleId)
  return { color: t?.color || '#409EFF', bg: t?.bg_color || t?.bgColor || '#f0f5ff' }
}

async function loadTitleCategories() {
  if (!isLogin.value) return
  try {
    const res: any = await request.get({ url: '/api/title/categories' })
    const apiCats: string[] = res?.data || res || []
    const allKeys = new Set(['成就', '活动', '消费', '社交', '管理员', ...apiCats])
    titleCategories.value = Array.from(allKeys).map((c: string) => ({
      key: c,
      label: categoryLabelMap[c] || c
    }))
  } catch {
    titleCategories.value = [
      { key: '成就', label: '成就' },
      { key: '活动', label: '活动' },
      { key: '消费', label: '消费' },
      { key: '社交', label: '社交' },
      { key: '管理员', label: '管理员' },
    ]
  }
}

async function loadTitleCategory() {
  titleLoading.value = true
  try {
    const params: any = {}
    if (activeTitleCategory.value) params.category = activeTitleCategory.value
    const res: any = await request.get({ url: '/api/title/list', params })
    allTitles.value = res?.data || res || []
  } catch {} finally { titleLoading.value = false }
}

async function loadUserTitles() {
  if (!isLogin.value) return
  try {
    const res: any = await request.get({ url: '/api/user/titles' })
    userTitles.value = res?.data || res || []
    const atRes: any = await request.get({ url: '/api/user/active-titles' })
    activeTitles.value = atRes || []
  } catch {}
}

async function handleTitleClick(title: any) {
  titleDetail.value = { ...title, owned: title.owned, isActive: title.isActive }
  titleDetailVisible.value = true
}

onMounted(() => {
  if (isLogin.value) {
    loadFrames()
    loadUserTitles()
  }
})
</script>
