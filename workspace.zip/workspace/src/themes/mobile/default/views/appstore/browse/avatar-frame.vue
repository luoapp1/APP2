<template>
  <div style="min-height: 100vh; display: flex; flex-direction: column; background: var(--app-page-bg)">
    <!-- 顶部导航栏 -->
    <div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">{{ activeTab === 'titles' ? '我的印记' : '头像管理' }}</span>
    </div>

    <!-- Tab 切换条 -->
    <div class="main-tabs-scroll" style="display: flex; gap: 28px; padding: 12px 16px 0; background: #fff; border-bottom: 1px solid #f3f4f6; overflow-x: auto; white-space: nowrap; -webkit-overflow-scrolling: touch; scroll-behavior: smooth;">
      <div
        v-for="tab in mainTabs"
        :key="tab.key"
        @click="switchMainTab(tab.key)"
        style="padding: 6px 4px; cursor: pointer; position: relative; transition: all 0.2s; flex-shrink: 0;"
        :style="{
          color: activeTab === tab.key ? '#1f2937' : '#9ca3af',
          fontWeight: activeTab === tab.key ? '600' : '400',
          fontSize: '15px'
        }"
      >
        {{ tab.label }}
        <div
          v-if="activeTab === tab.key"
          style="position: absolute; bottom: -1px; left: 50%; transform: translateX(-50%); width: 24px; height: 3px; border-radius: 2px; background: #FF4757;"
        />
      </div>
    </div>

    <div style="flex: 1; overflow-y: auto;">

          <!-- ========== 头像框区 ========== -->
      <template v-if="activeTab === 'frames'">
        <div style="padding-bottom: 16px">
          <!-- 统一预览卡片 -->
          <div
            style="display: flex; flex-direction: column; align-items: center; padding: 12px 16px 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px;"
          >
            <div
              style="width: calc(100% - 32px); max-width: 340px; margin: 0 auto 8px; border-radius: 14px; overflow: hidden;"
              :style="previewCommentBgUrl ? { backgroundImage: 'url(' + $fixImgUrl(previewCommentBgUrl) + ')', backgroundSize: 'cover', backgroundPosition: 'center' } : { background: '#fff' }"
            >
              <div style="padding: 10px; background: rgba(255,255,255,0.88)">
                <div style="display: flex; gap: 10px">
                    <div style="position: relative; width: 72px; height: 72px; flex-shrink: 0; margin-top: 2px">
                      <img v-if="activeFrameUrl" :src="activeFrameUrl" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0;" loading="lazy" />
                      <img v-if="previewAvatarEffectUrl" :src="$fixImgUrl(previewAvatarEffectUrl)" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                      <img v-if="!previewAvatarEffectUrl" :src="userAvatar" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                    </div>
                    <div style="flex:1; min-width: 0;">
                      <div style="display: flex; align-items: center; gap: 2px; margin-bottom: 2px; flex-wrap: wrap;">
                        <span :style="previewNicknameStyle" :class="previewNicknameClass">{{ (userInfo.nickname || userInfo.userName || '用户').slice(0, 10) }}</span>
                      <img v-if="userProfile?.expIcon && userProfile.expIcon.startsWith('http')" :src="userProfile.expIcon" style="width: 40px; height: 28px; object-fit: contain; flex-shrink: 0; margin-left: 2px;" loading="lazy" />
                      <template v-for="t in (userProfile?.activeTitles || [])" :key="'ti'+t.id">
                        <img v-if="t.icon && t.icon.startsWith('http')" :src="t.icon" style="width: 22px; height: 22px; object-fit: contain; flex-shrink: 0;" loading="lazy" />
                      </template>
                        <span style="flex:1;"></span>
                        <span style="font-size: 9px; color: #aaa;">#3楼</span>
                      </div>
                      <div style="display: flex; gap: 4px; margin: 2px 0;">
                        <template v-if="activeTitles.length > 0">
                          <span v-for="t in activeTitles" :key="'tag'+t.id" style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px;" :style="{ color: getTitleColorMap(t.id).color || '#7c3aed', background: (getTitleColorMap(t.id).bg || '#ede9fe') + 'B3' }">{{ t.name }}</span>
                        </template>
                        <span v-else style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; color: #6b7280; background: #f3f4f6B3;">{{ userInfo.levelName || '普通用户' }}</span>
                      </div>
                      <div style="font-size: 13px; color: #222; line-height: 1.5;">{{ previewCardBottomText }}</div>
                      <div style="display: flex; align-items: center; gap: 12px; margin-top: 6px;">
                        <span style="font-size: 11px; color: #bbb;">1分钟前</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>2</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>5</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          <!-- 取消使用按钮 -->
          <div v-if="activeFrameId" style="text-align: center; padding: 4px 0 0;">
            <button @click="handleCancelFrame" style="font-size: 13px; color: #ef4444; border: 1px solid #ef4444; background: #fff; border-radius: 8px; padding: 6px 20px; cursor: pointer;">取消使用</button>
          </div>

          <!-- 头像框 3 列网格 -->
          <div v-if="!loading" style="padding: 4px 16px 32px">
            <div v-if="ownedFrames.length > 0" :style="{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }">
              <div
                v-for="frame in ownedFrames"
                :key="frame.id"
                @click="frame.isActive ? handleCancelFrame() : handleSelectFrame(frame)"
                style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; transition: all .15s;"
                :style="frame.owned ? { border: '2px solid ' + (frame.isActive ? '#FF4757' : 'transparent') } : { border: '2px solid transparent', opacity: '0.55' }"
              >
                <div style="position: relative; width: 56px; height: 56px; margin-bottom: 8px;">
                  <img v-if="frame.image_url" :src="$fixImgUrl(frame.image_url)" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0;" loading="lazy" />
                  <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 40px; height: 40px; border-radius: 50%; overflow: hidden; z-index: 1;">
                    <img :src="userAvatar" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
                    <div v-if="!frame.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.3); display: flex; align-items: center; justify-content: center;">
                      <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                    </div>
                  </div>
                </div>
                <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 2px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ frame.name }}</div>
                <div style="font-size: 10px; color: #9ca3af;">{{ getObtainLabel(frame.acquire_type) }}</div>
                <div v-if="frame.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(frame) }}</div>
              </div>
            </div>
            <div v-else style="text-align: center; padding: 40px 0;">
              <div style="font-size: 14px; color: #9ca3af; margin-bottom: 20px;">还未使用头像框，可领取免费头像框体验</div>
              <button
                @click="handleAutoGrant"
                :disabled="autoGrantLoading"
                style="padding: 10px 32px; background: linear-gradient(135deg, #FF4757, #ff6b81); color: #fff; border: none; border-radius: 24px; font-size: 15px; font-weight: 600; cursor: pointer;"
              >{{ autoGrantLoading ? '领取中...' : '领取免费头像框' }}</button>
              <div v-if="grantMsg" style="margin-top: 12px; font-size: 13px;" :style="{ color: grantMsg.includes('失败') ? '#ef4444' : '#10b981' }">{{ grantMsg }}</div>
            </div>
          </div>
          <div v-if="loading" style="text-align: center; padding: 60px 0; color: #9ca3af;">加载中...</div>
        </div>
      </template>

      <!-- ========== 称号区 ========== -->
      <template v-else-if="activeTab === 'titles'">
        <div style="padding-bottom: 16px">
          <!-- 统一预览卡片 -->
          <div
            style="display: flex; flex-direction: column; align-items: center; padding: 12px 16px 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px;"
          >
            <div
              style="width: calc(100% - 32px); max-width: 340px; margin: 0 auto 8px; border-radius: 14px; overflow: hidden;"
              :style="previewCommentBgUrl ? { backgroundImage: 'url(' + $fixImgUrl(previewCommentBgUrl) + ')', backgroundSize: 'cover', backgroundPosition: 'center' } : { background: '#fff' }"
            >
              <div style="padding: 10px; background: rgba(255,255,255,0.88)">
                <div style="display: flex; gap: 10px">
                    <div style="position: relative; width: 72px; height: 72px; flex-shrink: 0; margin-top: 2px">
                      <img v-if="activeFrameUrl" :src="activeFrameUrl" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0;" loading="lazy" />
                      <img v-if="previewAvatarEffectUrl" :src="$fixImgUrl(previewAvatarEffectUrl)" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                      <img v-if="!previewAvatarEffectUrl" :src="userAvatar" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                    </div>
                    <div style="flex:1; min-width: 0;">
                      <div style="display: flex; align-items: center; gap: 2px; margin-bottom: 2px; flex-wrap: wrap;">
                        <span :style="previewNicknameStyle" :class="previewNicknameClass">{{ (userInfo.nickname || userInfo.userName || '用户').slice(0, 10) }}</span>
                      <img v-if="userProfile?.expIcon && userProfile.expIcon.startsWith('http')" :src="userProfile.expIcon" style="width: 40px; height: 28px; object-fit: contain; flex-shrink: 0; margin-left: 2px;" loading="lazy" />
                      <template v-for="t in (userProfile?.activeTitles || [])" :key="'ti'+t.id">
                        <img v-if="t.icon && t.icon.startsWith('http')" :src="t.icon" style="width: 22px; height: 22px; object-fit: contain; flex-shrink: 0;" loading="lazy" />
                      </template>
                        <span style="flex:1;"></span>
                        <span style="font-size: 9px; color: #aaa;">#3楼</span>
                      </div>
                      <div style="display: flex; gap: 4px; margin: 2px 0;">
                        <template v-if="activeTitles.length > 0">
                          <span v-for="t in activeTitles" :key="'tag'+t.id" style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px;" :style="{ color: getTitleColorMap(t.id).color || '#7c3aed', background: (getTitleColorMap(t.id).bg || '#ede9fe') + 'B3' }">{{ t.name }}</span>
                        </template>
                        <span v-else style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; color: #6b7280; background: #f3f4f6B3;">{{ userInfo.levelName || '普通用户' }}</span>
                      </div>
                      <div style="font-size: 13px; color: #222; line-height: 1.5;">{{ previewCardBottomText }}</div>
                      <div style="display: flex; align-items: center; gap: 12px; margin-top: 6px;">
                        <span style="font-size: 11px; color: #bbb;">1分钟前</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>2</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>5</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          <!-- 称号分类 Tab -->
          <div v-if="titleCategoryTabs.length > 1" style="display: flex; gap: 12px; padding: 0 16px 12px; overflow-x: auto; white-space: nowrap; -webkit-overflow-scrolling: touch;">
            <div
              v-for="cat in titleCategoryTabs"
              :key="cat.key"
              @click="activeTitleCategory = cat.key; loadTitleCategory()"
              style="padding: 6px 14px; border-radius: 20px; font-size: 13px; cursor: pointer; transition: all .15s; flex-shrink: 0;"
              :style="{ background: activeTitleCategory === cat.key ? '#FF4757' : '#f3f4f6', color: activeTitleCategory === cat.key ? '#fff' : '#6b7280', fontWeight: activeTitleCategory === cat.key ? '600' : '400' }"
            >{{ cat.label }}</div>
          </div>

          <!-- 称号网格 -->
          <div v-if="titleLoading" style="text-align: center; padding: 60px 0; color: #9ca3af;">加载中...</div>
          <div v-else style="padding: 0 16px 32px">
            <div v-if="ownedDisplayTitles.length > 0" :style="{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }">
              <div
                v-for="title in ownedDisplayTitles"
                :key="title.id"
                @click="handleTitleClick(title)"
                style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; position: relative; transition: all .15s;"
                :style="{ border: '2px solid ' + (title.isActive ? '#FF4757' : 'transparent'), opacity: title.owned ? '1' : '0.55' }"
              >
                <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center;" :style="{ background: title.owned ? (title.bg_color || title.bgColor || '#f3f4f6') : '#f3f4f6' }">
                  <img v-if="title.icon" :src="$fixImgUrl(title.icon)" style="width: 100%; height: 100%; object-fit: cover;" :style="{ filter: title.owned ? 'none' : 'grayscale(100%)', opacity: title.owned ? 1 : 0.5 }" loading="lazy" />
                  <span v-else style="font-size: 22px; font-weight: 800;" :style="{ color: title.owned ? (title.color || '#409EFF') : '#d1d5db' }">{{ (title.name || '?')[0] }}</span>
                  <div v-if="!title.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.3); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                  </div>
                </div>
                <span v-if="title.category" style="font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 500; margin-bottom: 4px; line-height: 14px;" :style="{ color: catColor(title.category), background: catBg(title.category) }">{{ catLabel(title.category) }}</span>
                <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 2px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ title.name }}</div>
                <div style="font-size: 10px;" :style="{ color: title.isActive ? '#FF4757' : (title.owned ? '#10b981' : '#d1d5db') }">{{ title.isActive ? '使用中' : (title.owned ? '未使用' : '未获得') }}</div>
                <div v-if="title.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(title) }}</div>
              </div>
            </div>
            <div v-else-if="!titleLoading" style="text-align: center; padding: 60px 0; color: #9ca3af;">暂无已获得的称号</div>
          </div>
        </div>
      </template>

      <!-- ========== 其他装饰品区（头像特效/评论背景/昵称特效/主页背景） ========== -->
      <template v-else>
        <div style="padding-bottom: 16px">
          <!-- 统一预览卡片 -->
          <div
            style="display: flex; flex-direction: column; align-items: center; padding: 12px 16px 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px;"
          >
            <div
              style="width: calc(100% - 32px); max-width: 340px; margin: 0 auto 8px; border-radius: 14px; overflow: hidden;"
              :style="previewCommentBgUrl ? { backgroundImage: 'url(' + $fixImgUrl(previewCommentBgUrl) + ')', backgroundSize: 'cover', backgroundPosition: 'center' } : { background: '#fff' }"
            >
              <div style="padding: 10px; background: rgba(255,255,255,0.88)">
                <div style="display: flex; gap: 10px">
                    <div style="position: relative; width: 72px; height: 72px; flex-shrink: 0; margin-top: 2px">
                      <img v-if="activeFrameUrl" :src="activeFrameUrl" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0;" loading="lazy" />
                      <img v-if="previewAvatarEffectUrl" :src="$fixImgUrl(previewAvatarEffectUrl)" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                      <img v-if="!previewAvatarEffectUrl" :src="userAvatar" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 52px; height: 52px; border-radius: 50%; object-fit: cover; z-index: 1;" loading="lazy" />
                    </div>
                    <div style="flex:1; min-width: 0;">
                      <div style="display: flex; align-items: center; gap: 2px; margin-bottom: 2px; flex-wrap: wrap;">
                        <span :style="previewNicknameStyle" :class="previewNicknameClass">{{ (userInfo.nickname || userInfo.userName || '用户').slice(0, 10) }}</span>
                      <img v-if="userProfile?.expIcon && userProfile.expIcon.startsWith('http')" :src="userProfile.expIcon" style="width: 40px; height: 28px; object-fit: contain; flex-shrink: 0; margin-left: 2px;" loading="lazy" />
                      <template v-for="t in (userProfile?.activeTitles || [])" :key="'ti'+t.id">
                        <img v-if="t.icon && t.icon.startsWith('http')" :src="t.icon" style="width: 22px; height: 22px; object-fit: contain; flex-shrink: 0;" loading="lazy" />
                      </template>
                        <span style="flex:1;"></span>
                        <span style="font-size: 9px; color: #aaa;">#3楼</span>
                      </div>
                      <div style="display: flex; gap: 4px; margin: 2px 0;">
                        <template v-if="activeTitles.length > 0">
                          <span v-for="t in activeTitles" :key="'tag'+t.id" style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px;" :style="{ color: getTitleColorMap(t.id).color || '#7c3aed', background: (getTitleColorMap(t.id).bg || '#ede9fe') + 'B3' }">{{ t.name }}</span>
                        </template>
                        <span v-else style="font-size: 10px; padding: 0 6px; border-radius: 6px; font-weight: 500; line-height: 16px; color: #6b7280; background: #f3f4f6B3;">{{ userInfo.levelName || '普通用户' }}</span>
                      </div>
                      <div style="font-size: 13px; color: #222; line-height: 1.5;">{{ previewCardBottomText }}</div>
                      <div style="display: flex; align-items: center; gap: 12px; margin-top: 6px;">
                        <span style="font-size: 11px; color: #bbb;">1分钟前</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>2</span>
                        <span style="display: inline-flex; align-items: center; gap: 2px; font-size: 11px; color: #aaa;"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>5</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <template v-if="activeNewTypeItem">
                <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 4px">{{ activeNewTypeItem.name }}</div>
                <button
                  v-if="activeNewTypeItem.isActive"
                  style="font-size: 12px; color: #ef4444; border: none; background: none; cursor: pointer; padding: 4px 12px;"
                  @click="handleNewTypeClick(activeNewTypeItem)"
                >取消使用</button>
              </template>
              <template v-else>
                <div style="font-size: 14px; font-weight: 600; color: #9ca3af; margin-bottom: 4px">未使用{{ typeLabel }}</div>
                <div style="font-size: 12px; color: #bbb;">点击下方已拥有的装饰来使用</div>
              </template>
            </div>
          </div>

          <div style="padding: 0 16px 32px">
            <div v-if="newTypeLoading" style="text-align: center; padding: 60px 0; color: #9ca3af;">加载中...</div>
            <div v-else :style="{ display: 'grid', gap: '10px', gridTemplateColumns: (activeTab === 'comment_background' || activeTab === 'nickname_effect') ? 'repeat(2, 1fr)' : (activeTab === 'home_bg' ? 'repeat(3, 1fr)' : 'repeat(3, 1fr)') }">
              <div
                v-for="item in ownedNewTypeItems"
                :key="item.id"
                :style="(activeTab === 'comment_background' || activeTab === 'nickname_effect' || activeTab === 'home_bg') ? {
                  background: '#fff', borderRadius: '14px', overflow: 'hidden', cursor: 'pointer', border: '2px solid ' + (item.isActive ? '#FF4757' : 'transparent'), position: 'relative', opacity: item.owned ? '1' : '0.55',
                } : {
                  background: '#fff', borderRadius: '14px', padding: '12px 8px', display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer', border: '2px solid ' + (item.isActive ? '#FF4757' : 'transparent'), position: 'relative', transition: 'all .15s', opacity: item.owned ? '1' : '0.55',
                }"
                @click="handleNewTypeClick(item)"
              >
                <!-- 评论背景：长方形预览 -->
                <template v-if="activeTab === 'comment_background'">
                  <div style="width: 100%; height: 50px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
                    <img v-if="item.image_url" :src="$fixImgUrl(item.image_url)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
                    <span v-else style="font-size: 16px; color: #d1d5db;">无预览图</span>
                    <div v-if="!item.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.3); display: flex; align-items: center; justify-content: center;">
                      <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                    </div>
                  </div>
                  <div style="padding: 8px 8px 6px;">
                    <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
                    <div style="font-size: 9px;" :style="{ color: item.isActive ? '#FF4757' : (item.owned ? '#10b981' : '#d1d5db') }">{{ item.isActive ? '使用中' : (item.owned ? '未使用' : '未获取') }}</div>
                  </div>
                  <div v-if="item.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                  <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(item) }}</div>
                </template>
                <!-- 昵称特效：长方形预览+效果 -->
                <template v-else-if="activeTab === 'nickname_effect'">
                  <div style="width: 100%; height: 64px; background: #fafbfc; display: flex; align-items: center; gap: 8px; padding: 0 10px; position: relative; overflow: hidden; border-left: 3px solid #e8ecf1;">
                    <img :src="userAvatar" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex-shrink: 0;" loading="lazy" />
                    <div style="flex: 1; min-width: 0;">
                      <span :style="{ fontSize: '13px', fontWeight: '600', color: '#00BFA5', ...nicknameEffectStyle(item.config_json || '{}') }" :class="nicknameEffectAnim(item.config_json || '{}')">{{ (item.name || '昵称').slice(0, 6) }}</span>
                      <div style="font-size: 9px; color: #bbb; margin-top: 1px;">点击查看效果</div>
                    </div>
                    <div v-if="!item.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.2); display: flex; align-items: center; justify-content: center; border-radius: 0;">
                      <svg style="width: 18px; height: 18px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                    </div>
                  </div>
                  <div style="padding: 8px 8px 6px;">
                    <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
                    <div style="font-size: 9px;" :style="{ color: item.isActive ? '#FF4757' : (item.owned ? '#10b981' : '#d1d5db') }">{{ item.isActive ? '使用中' : (item.owned ? '未使用' : '未获取') }}</div>
                  </div>
                  <div v-if="item.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                  <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(item) }}</div>
                </template>
                <template v-else-if="activeTab === 'home_bg'">
                  <div style="width: 100%; height: 190px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
                    <img v-if="item.image_url" :src="$fixImgUrl(item.image_url)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
                    <span v-else style="font-size: 14px; color: #d1d5db;">无预览图</span>
                    <div v-if="!item.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.3); display: flex; align-items: center; justify-content: center;">
                      <svg style="width: 18px; height: 18px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                    </div>
                  </div>
                  <div style="padding: 8px 8px 6px;">
                    <div style="font-size: 12px; font-weight: 600; color: #1f2937; margin-bottom: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                      <span style="font-size: 9px;" :style="{ color: item.isActive ? '#FF4757' : (item.owned ? '#10b981' : '#d1d5db') }">{{ item.isActive ? '使用中' : (item.owned ? '未使用' : '未获取') }}</span>
                      <button v-if="item.image_url" style="font-size: 9px; color: #00bfa5; border: 1px solid #00bfa5; background: #fff; border-radius: 4px; padding: 1px 6px; cursor: pointer; margin-left: 4px;" @click.stop="handleHomeBgPreview(item)">预览</button>
                    </div>
                  </div>
                  <div v-if="item.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                  <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(item) }}</div>
                </template>
                <!-- 其他类型：圆形图标 -->
                <template v-else>
                <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; background: #f3f4f6;">
                  <img v-if="item.image_url" :src="$fixImgUrl(item.image_url)" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy" />
                  <span v-else style="font-size: 22px; font-weight: 800; color: #d1d5db;">{{ (item.name || '?')[0] }}</span>
                  <div v-if="!item.owned" style="position: absolute; inset: 0; background: rgba(0,0,0,.3); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                  </div>
                </div>
                <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 4px; line-height: 1.2; width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.name }}</div>
                <div style="font-size: 10px;" :style="{ color: item.isActive ? '#FF4757' : (item.owned ? '#10b981' : '#d1d5db') }">
                  {{ item.isActive ? '使用中' : (item.owned ? '未使用' : '未获取') }}
                </div>
                <div v-if="item.isActive" style="position: absolute; top: 4px; right: 4px; background: #FF4757; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px;">使用中</div>
                <div style="position: absolute; top: 4px; left: 4px; background: rgba(16,185,129,.12); color: #10b981; font-size: 9px; padding: 1px 5px; border-radius: 4px; font-weight: 500; line-height: 14px;">{{ getItemDurationLabel(item) }}</div>
      </template>
      </div>
    </div>

    </div>

</template>
    </div>

    <!-- 称号详情弹窗 -->
    <div v-if="titleDetailVisible" class="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4" @click.self="titleDetailVisible = false">
      <div class="bg-white rounded-t-3xl sm:rounded-2xl shadow-xl w-full sm:max-w-sm max-h-[75vh] overflow-hidden sm:overflow-visible animate-slide-up" @click.stop>
        <!-- 图标头部 -->
        <div style="padding: 28px 16px 20px; display: flex; flex-direction: column; align-items: center; position: relative; background: linear-gradient(135deg, #f8f9fc 0%, #f0f4ff 100%);">
          <button style="position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; border-radius: 50%; background: rgba(0,0,0,.06); border: none; display: flex; align-items: center; justify-content: center; cursor: pointer;" @click="titleDetailVisible = false">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
          <div style="width: 88px; height: 88px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 14px; box-shadow: 0 4px 16px rgba(0,0,0,.08);" :style="{ background: titleDetail?.owned ? (titleDetail.bg_color || titleDetail.bgColor || '#fff') : '#f3f4f6' }">
            <img v-if="titleDetail?.icon" :src="$fixImgUrl(titleDetail.icon)" style="width: 60px; height: 60px; object-fit: contain;" :style="{ filter: titleDetail?.owned ? 'none' : 'grayscale(100%)', opacity: titleDetail?.owned ? 1 : 0.5 }"  loading="lazy" />
            <span v-else style="font-size: 32px; font-weight: 800;" :style="{ color: titleDetail?.owned ? (titleDetail.color || '#409EFF') : '#d1d5db' }">{{ (titleDetail?.name || '?')[0] }}</span>
          </div>
          <div style="font-size: 19px; font-weight: 700; color: #1f2937; margin-bottom: 2px;">{{ titleDetail?.name }}</div>
          <div v-if="titleDetail?.description" style="font-size: 12px; color: #9ca3af; text-align: center; max-width: 260px;">{{ titleDetail.description }}</div>
          <div style="display: flex; gap: 8px; margin-top: 10px; align-items: center;">
            <span v-if="titleDetail?.category" style="font-size: 10px; padding: 2px 8px; border-radius: 8px; font-weight: 500;" :style="{ background: catBg(titleDetail.category), color: catColor(titleDetail.category) }">{{ catLabel(titleDetail.category) }}</span>
            <span v-if="titleDetail?.owned" style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #ecfdf5; color: #059669; font-weight: 500;">已获得</span>
            <span v-else style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #f3f4f6; color: #9ca3af; font-weight: 500;">未获得</span>
            <span v-if="titleDetail?.isActive" style="font-size: 11px; padding: 2px 10px; border-radius: 10px; background: #fef2f2; color: #FF4757; font-weight: 500;">使用中</span>
          </div>
        </div>
        <!-- 获取条件区 -->
        <div style="padding: 20px 20px 0;">
          <div style="font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#FF4757" stroke-width="2"/><path d="M12 7v5l3 3" stroke="#FF4757" stroke-width="2" stroke-linecap="round"/></svg>获取方式
          </div>
          <div style="background: #f9fafb; border-radius: 14px; padding: 14px 16px; margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
              <span style="font-size: 14px; font-weight: 600; color: #1f2937;">{{ conditionLabel(titleDetail) }}</span>
              <svg v-if="titleDetail?.owned" width="20" height="20" viewBox="0 0 24 24" fill="#10b981"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            </div>
            <div v-if="isNumericCondition(titleDetail)" style="margin-top: 8px;">
              <div style="height: 4px; background: #e5e7eb; border-radius: 2px; overflow: hidden;">
                <div style="height: 100%; border-radius: 2px; transition: width .5s;" :style="{ width: titleDetail?.owned ? '100%' : '0%', background: titleDetail?.owned ? '#10b981' : '#FF4757' }" />
              </div>
              <div style="display: flex; justify-content: space-between; margin-top: 4px; font-size: 10px; color: #9ca3af;">
                <span>0</span>
                <span>{{ conditionValue(titleDetail) }}</span>
              </div>
            </div>
          </div>
          <div v-if="titleDetail?.expire_days || titleDetail?.expireDays" style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #f59e0b; margin-bottom: 12px; background: #fffbeb; border-radius: 10px; padding: 8px 12px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            获取后 {{ titleDetail.expire_days || titleDetail.expireDays }} 天内有效，到期自动回收
          </div>
        </div>
        <!-- 操作按钮 -->
        <div style="padding: 0 20px 20px; display: flex; flex-direction: column; gap: 8px;">
          <template v-if="titleDetail?.owned">
            <button
              v-if="!titleDetail?.isActive && activeTitles.length < 3"
              style="width: 100%; height: 46px; background: linear-gradient(135deg, #FF4757, #ff6b81); color: #fff; border: none; border-radius: 14px; font-size: 15px; font-weight: 600; cursor: pointer;"
              @click="() => { 
                var td = titleDetail;
                if (!td || !td.id) return;
                var used = activeTitles.map(function(a) { return a.slot; });
                var fs = 1; while (used.indexOf(fs) !== -1) fs++;
                request.post({ url: '/api/user/active-title', data: { titleId: td.id, slot: fs } })
                  .then(() => { 
                    loadUserTitles();
                    loadUserProfile();
                    titleDetailVisible = false;
                  })
                  .catch((e: any) => { alert('请求失败: ' + (e?.message || '未知错误')); });
              }"
            >佩戴称号</button>
            <button
              v-else-if="titleDetail?.isActive"
              style="width: 100%; height: 46px; background: #fff; color: #666; border: 1.5px solid #e5e7eb; border-radius: 14px; font-size: 15px; font-weight: 500; cursor: pointer;"
              @click="() => { 
                var td = titleDetail;
                if (!td || !td.id) return;
                request.post({ url: '/api/user/active-title', data: { titleId: 0, slot: td.activeSlot || 1 } })
                  .then(() => { 
                    loadUserTitles();
                    loadUserProfile();
                    titleDetailVisible = false;
                  })
                  .catch((e: any) => { alert('取消失败: ' + (e?.message || '未知错误')); });
              }"
            >取消佩戴</button>
            <div v-else style="text-align: center; font-size: 12px; color: #f59e0b; background: #fffbeb; border-radius: 10px; padding: 10px;">已达佩戴上限(3个)，请先取消一个</div>
          </template>
          <div v-else style="text-align: center; padding: 8px 0; font-size: 12px; color: #9ca3af;">达到条件后自动获得</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'
import { fetchUserAvatarFrames, fetchActiveFrame, fetchAutoGrantFrame } from '@/api/avatar-frame'
import request from '@/utils/http'
import { nicknameEffectStyle, nicknameEffectAnim } from '@/utils/nickname-effect'

const router = useRouter()
const userStore = useUserStore()
const loginModalStore = useLoginModalStore()

// ===== 通用 =====
const isLogin = computed(() => userStore.isLogin)
const userInfo = computed(() => userStore.info || {})
const userAvatar = computed(() => userInfo.value.avatar || defaultAvatarImg)

const mainTabs = [
  { key: 'frames', label: '头像框' },
  { key: 'titles', label: '称号' },
  { key: 'avatar_effect', label: '头像特效' },
  { key: 'comment_background', label: '评论背景' },
  { key: 'nickname_effect', label: '昵称特效' },
  { key: 'home_bg', label: '主页背景' },
]
const activeTab = ref('frames')
const newTypeKeys = ['avatar_effect', 'comment_background', 'nickname_effect', 'home_bg']
const isNewTypeTab = computed(() => newTypeKeys.includes(activeTab.value))

function switchMainTab(key: string) {
  activeTab.value = key
  previewSelectedItem.value = null
  if (key === 'titles') {
    loadTitleCategories()
    loadUserTitles()
    loadTitleCategory()
  } else if (newTypeKeys.includes(key)) {
    loadNewType()
    if (key === 'comment_background') {
      loadUserProfile()
    }
  } else if (key === 'frames') {
    loadAllActiveForPreview()
  }
}

// ===== 统一预览卡片数据 =====
const activeCommentBg = ref<any>(null)
const activeNicknameEffect = ref<any>(null)
const activeAvatarEffect = ref<any>(null)

async function loadAllActiveForPreview() {
  if (!isLogin.value) return
  try {
    const res: any = await request.get({ url: '/api/user/all-decorations' })
    const data = res?.data || res || {}
    const findActive = (list: any[]) => list?.find((i: any) => i.is_active) || null
    activeCommentBg.value = findActive(data.comment_background || [])
    activeNicknameEffect.value = findActive(data.nickname_effect || [])
    activeAvatarEffect.value = findActive(data.avatar_effect || [])
  } catch {}
}

// ===== 头像框 =====
const loading = ref(false)
const autoGrantLoading = ref(false)
const frames = ref<any[]>([])
const activeFrameId = ref(0)
const activeFrameName = ref('')
const activeFrameUrl = ref('')
const switchingId = ref(0)
const grantMsg = ref('')

function getObtainLabel(type: string) {
  if (type === 'experience') return '经验等级获取'
  if (type === 'membership') return '会员等级获取'
  if (type === 'activity') return '活动获取'
  return '手动授予'
}

async function loadFrames() {
  if (!isLogin.value) return
  loading.value = true
  try {
    const res: any = await fetchUserAvatarFrames()
    frames.value = (res.frames || []).sort((a: any, b: any) => {
      if (a.owned === b.owned) return 0
      return a.owned ? -1 : 1
    })
    activeFrameId.value = res.activeFrameId || 0
    const activeFrame = frames.value.find((f: any) => f.isActive)
    activeFrameName.value = activeFrame?.name || ''
    activeFrameUrl.value = activeFrame?.image_url || ''
  } catch {} finally { loading.value = false }
}

async function handleSelectFrame(frame: any) {
  if (!frame.owned) return
  if (frame.isActive) return
  switchingId.value = frame.id
  try {
    await fetchActiveFrame(frame.id)
    activeFrameId.value = frame.id
    activeFrameName.value = frame.name
    activeFrameUrl.value = frame.image_url
    frames.value.forEach((f: any) => { f.isActive = f.id === frame.id })
  } catch {} finally { switchingId.value = 0 }
}

async function handleCancelFrame() {
  switchingId.value = -1
  try {
    await fetchActiveFrame(0)
    activeFrameId.value = 0
    activeFrameName.value = ''
    activeFrameUrl.value = ''
    frames.value.forEach((f: any) => { f.isActive = false })
  } catch {} finally { switchingId.value = 0 }
}

async function handleAutoGrant() {
  autoGrantLoading.value = true
  grantMsg.value = ''
  try {
    const res: any = await fetchAutoGrantFrame()
    grantMsg.value = res.message || '操作成功'
    loadFrames()
  } catch { grantMsg.value = '操作失败，请重试' }
  finally {
    autoGrantLoading.value = false
    setTimeout(() => { grantMsg.value = '' }, 3000)
  }
}

// ===== 称号 =====
const titleLoading = ref(false)
const allTitles = ref<any[]>([])
const userTitles = ref<any[]>([])
const activeTitles = ref<{ id: number; name: string; slot: number }[]>([])
const activeTitleCategory = ref('')
const titleCategories = ref<{key: string; label: string}[]>([])
const titleDetailVisible = ref(false)
const titleDetail = ref<any>(null)

const conditionMap: Record<string, string> = {
  manual: '手动授予', post_count: '发布帖子数', like_received: '获得点赞数', comment_count: '发表评论数',
  checkin_days: '签到天数', coin_received: '累计余额收入', likes_given: '主动点赞数', follower_count: '粉丝数',
  following_count: '关注人数', collection_count: '创建合集数', favorite_count: '收藏帖子数',
  vote_participated: '参与投票次数', task_completed: '完成任务数', topic_followed: '关注话题数',
  draft_count: '草稿数量', mall_orders: '商城下单次数', chat_messages: '聊天发言数',
  content_purchased: '付费购买次数', app_count: '安装应用数', app_comments: '应用评论数',
  post_shared: '帖子转发数', experience_total: '累计经验值', points_earned: '累计积分收入',
  points_spent: '累计积分支出', membership_count: '购买会员次数', recharge_total: '累计充值金额',
  invite_success: '成功邀请人数', balance_spent: '累计余额支出', report_count: '举报次数',
  withdraw_total: '累计提现金额', game_played: '游戏总场次', game_won: '游戏胜场数',
  mall_review_count: '商城评价次数', coupon_used_count: '使用优惠券次数', message_sent: '发送私信数',
  rating_count: '评分次数', trust_level: '社区信任等级', app_favorite_count: '收藏应用数',
  collection_favorite_count: '收藏合集数', mall_favorite_count: '收藏商品数', verified: '通过实名认证',
  has_role: '拥有角色'
}

function conditionLabel(t: any) {
  const ct = t.condition_type || t.conditionType || 'manual'
  const cv = t.condition_value || t.conditionValue || ''
  if (ct === 'manual') return '手动授予'
  if (ct === 'has_role') return `拥有角色 ${cv || 'N/A'}`
  const label = conditionMap[ct] || ct
  return cv ? `${label} >= ${cv}` : label
}

function isNumericCondition(t: any) {
  const ct = t?.condition_type || t?.conditionType || 'manual'
  return ct !== 'manual' && ct !== 'has_role' && ct !== 'verified'
}

function conditionValue(t: any) {
  return t?.condition_value || t?.conditionValue || '0'
}
const categoryLabelMap: Record<string, string> = {

  '成就': '成就', '活动': '活动', '消费': '消费', '社交': '社交', '管理员': '管理员'
}

const categoryColorMap: Record<string, string> = {
  '成就': '#FF9800', '活动': '#E91E63', '消费': '#4CAF50', '社交': '#2196F3', '管理员': '#9C27B0'
}
const categoryBgMap: Record<string, string> = {
  '成就': '#FFF3E0', '活动': '#FCE4EC', '消费': '#E8F5E9', '社交': '#E3F2FD', '管理员': '#F3E5F5'
}

function catLabel(v: string) { return categoryLabelMap[v] || v }
function catColor(v: string) { return categoryColorMap[v] || '#999' }
function catBg(v: string) { return categoryBgMap[v] || '#f3f4f6' }

const titleCategoryTabs = computed(() => {
  const tabs = [{ key: '', label: '全部' }]
  for (const cat of titleCategories.value) {
    tabs.push({ key: cat.key, label: cat.label })
  }
  return tabs
})

const displayTitles = computed(() => {
  let list = allTitles.value
  if (activeTitleCategory.value) {
    list = list.filter(t => t.category === activeTitleCategory.value)
  }
  const activeIds = new Set(activeTitles.value.map(t => t.id))
  return list.map(t => {
    const ut = userTitles.value.find((u: any) => u.id === t.id)
    return {
      ...t,
      owned: !!ut,
      isActive: activeIds.has(t.id),
      grantTime: ut?.grant_time || '',
      expireTime: ut?.expire_time || null,
      activeSlot: activeTitles.value.find(a => a.id === t.id)?.slot || 0,
    }
  }).sort((a, b) => {
    if (a.owned && !b.owned) return -1
    if (!a.owned && b.owned) return 1
    if (a.owned && b.owned) {
      if (!a.grantTime && !b.grantTime) return 0
      if (!a.grantTime) return 1
      if (!b.grantTime) return -1
      return new Date(a.grantTime).getTime() - new Date(b.grantTime).getTime()
    }
    return 0
  })
})

const ownedFrames = computed(() => frames.value.filter(f => f.owned))
const ownedDisplayTitles = computed(() => displayTitles.value.filter(t => t.owned))
const ownedNewTypeItems = computed(() => newTypeItems.value.filter(i => i.owned))

function formatDurationLabel(expireTime: string | null): string {
  if (!expireTime) return '永久'
  const days = Math.ceil((new Date(expireTime + ' UTC').getTime() - Date.now()) / 86400000)
  if (days <= 0) return '已过期'
  if (days >= 365) return Math.floor(days / 365) + '年'
  if (days >= 60) return Math.floor(days / 30) + '个月'
  return days + '天'
}

function getItemDurationLabel(item: any): string {
  if (item.expireTime !== undefined) return formatDurationLabel(item.expireTime)
  return '永久'
}

function getTitleColorMap(titleId: number) {
  const t = userTitles.value.find((u: any) => u.id === titleId)
  return { color: t?.color || '#409EFF', bg: t?.bg_color || t?.bgColor || '#f0f5ff' }
}

async function loadTitleCategories() {
  if (!isLogin.value) return
  try {
    const res: any = await request.get({ url: '/api/title/categories' })
    const apiCats: string[] = res?.data || res || []
    const allKeys = new Set(['成就', '活动', '消费', '社交', '管理员', ...apiCats])
    titleCategories.value = Array.from(allKeys).map((c: string) => ({
      key: c,
      label: categoryLabelMap[c] || c
    }))
  } catch {
    titleCategories.value = [
      { key: '成就', label: '成就' },
      { key: '活动', label: '活动' },
      { key: '消费', label: '消费' },
      { key: '社交', label: '社交' },
      { key: '管理员', label: '管理员' },
    ]
  }
}

async function loadTitleCategory() {
  titleLoading.value = true
  try {
    const params: any = {}
    if (activeTitleCategory.value) params.category = activeTitleCategory.value
    const res: any = await request.get({ url: '/api/title/list', params })
    allTitles.value = res?.data || res || []
  } catch {} finally { titleLoading.value = false }
}

async function loadUserTitles() {
  if (!isLogin.value) return
  try {
    const res: any = await request.get({ url: '/api/user/titles' })
    userTitles.value = res?.data || res || []
    const atRes: any = await request.get({ url: '/api/user/active-titles' })
    activeTitles.value = atRes || []
  } catch {}
}

async function handleTitleClick(title: any) {
  titleDetail.value = { ...title, owned: title.owned, isActive: title.isActive }
  titleDetailVisible.value = true
}

// ===== 其他装饰品（头像特效/评论背景/昵称特效/主页背景） =====
const newTypeItems = ref<any[]>([])
const newTypeLoading = ref(false)
const userProfile = ref<any>(null)
const profileLoading = ref(false)

async function loadUserProfile() {
  const uid = (userInfo.value as any).userId
  if (!uid) return
  profileLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/user/profile', params: { userId: uid } })
    userProfile.value = res?.data || res || null
  } catch {} finally { profileLoading.value = false }
}

const typeLabelMap: Record<string, string> = {
  avatar_effect: '头像特效',
  comment_background: '评论背景',
  nickname_effect: '昵称特效',
  home_bg: '主页背景',
}
const typeLabel = computed(() => typeLabelMap[activeTab.value] || '装饰')

const activeNewTypeItem = computed(() => newTypeItems.value.find((item: any) => item.isActive) || null)
const previewSelectedItem = ref<any>(null)

const previewCommentBgUrl = computed(() => {
  if (activeTab.value === 'comment_background') {
    if (previewSelectedItem.value?.image_url) return previewSelectedItem.value.image_url
    if (activeNewTypeItem.value?.image_url) return activeNewTypeItem.value.image_url
  }
  return activeCommentBg.value?.image_url || ''
})
const previewNicknameCfg = computed(() => {
  if (activeTab.value === 'nickname_effect') {
    if (previewSelectedItem.value?.config_json) return previewSelectedItem.value.config_json
    if (activeNewTypeItem.value?.config_json) return activeNewTypeItem.value.config_json
  }
  return activeNicknameEffect.value?.config_json || null
})
const previewNicknameStyle = computed(() => {
  const cfg = previewNicknameCfg.value
  if (!cfg) return { fontSize: '12px', fontWeight: '600', color: '#00BFA5' }
  return { fontSize: '12px', fontWeight: '600', color: '#00BFA5', ...nicknameEffectStyle(cfg) }
})
const previewNicknameClass = computed(() => {
  const cfg = previewNicknameCfg.value
  if (!cfg) return ''
  return nicknameEffectAnim(cfg)
})
const previewAvatarEffectUrl = computed(() => {
  if (activeTab.value === 'avatar_effect') {
    if (previewSelectedItem.value?.image_url) return previewSelectedItem.value.image_url
    if (activeNewTypeItem.value?.image_url) return activeNewTypeItem.value.image_url
  }
  return activeAvatarEffect.value?.image_url || ''
})
const previewCardBottomText = computed(() => {
  const map: Record<string, string> = {
    frames: '头像框效果预览，选择不同头像框可切换样式。',
    titles: '称号效果预览，选择不同称号可切换样式。',
    avatar_effect: '头像特效效果预览，选择不同特效可切换样式。',
    comment_background: '评论背景效果预览，选择不同背景可切换卡片样式。',
    nickname_effect: '昵称特效效果预览，选择不同特效可切换样式。',
  }
  return map[activeTab.value] || ''
})

async function loadNewType() {
  newTypeLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/user/decorations-with-ownership', params: { type: activeTab.value } })
    const data = res?.data || res || {}
    newTypeItems.value = (data.items || [])
  } catch {} finally { newTypeLoading.value = false }
}

async function handleNewTypeClick(item: any) {
  if (!item.owned || newTypeLoading.value) return
  previewSelectedItem.value = item
  const type = activeTab.value
  try {
    if (item.isActive) {
      await request.post({ url: '/api/user/cancel-decoration', data: { type, decoration_id: item.id } })
    } else {
      await request.post({ url: '/api/user/activate-decoration', data: { type, decoration_id: item.id } })
    }
    loadNewType()
  } catch {}
}

function handleHomeBgPreview(item: any) {
  if (!item.image_url) return
  const uid = (userInfo.value as any).userId
  const encoded = btoa(unescape(encodeURIComponent(item.image_url)))
  const resolved = router.resolve({
    path: `/appstore/profile/${uid}`,
    query: { pbg: encoded }
  })
  window.open(resolved.href, '_blank')
}

onMounted(() => {
  if (isLogin.value) {
    loadFrames()
    loadUserTitles()
    loadAllActiveForPreview()
    loadUserProfile()
  }
})
</script>

<style scoped>
.main-tabs-scroll::-webkit-scrollbar {
  display: none;
}
.main-tabs-scroll {
  scrollbar-width: none;
  -ms-overflow-style: none;
}
</style>
