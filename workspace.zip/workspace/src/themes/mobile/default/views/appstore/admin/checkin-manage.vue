<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">签到管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="flex items-center justify-between">
          <span class="text-sm text-gray-600">签到开关</span>
          <button v-auth="'toggle'" class="w-10 h-6 rounded-full transition-colors relative" :class="checkinEnabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="toggleCheckin">
            <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="checkinEnabled ? 'translate-x-4.5' : 'left-0.5'" />
          </button>
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="groups.length > 0">
          <div v-for="item in groups" :key="item.id" class="px-4 py-3 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2.5 min-w-0">
                <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: item.iconColor || '#508DFF' }">
                  <span class="text-base text-white">{{ item.icon || 'S' }}</span>
                </div>
                <div class="min-w-0">
                  <div class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</div>
                  <div class="text-[11px] text-gray-400">{{ item.levelName || '不限等级' }} · 基础 {{ item.points }}/{{ item.experience }}/{{ item.balance }} · 加成 {{ item.pointsConsecutive }}/{{ item.experienceConsecutive }}/{{ item.balanceConsecutive }}</div>
                </div>
              </div>
              <div class="flex items-center gap-1 flex-shrink-0">
                <button v-auth="'edit'" class="text-xs px-2.5 py-1 rounded-full bg-[#FF4757]/10 text-[#FF4757] active:bg-[#FF4757]/20" @click.stop="openDialog(item)">编辑</button>
                <button v-auth="'delete'" class="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 active:bg-gray-200" @click.stop="(e) => { e.stopPropagation(); deleteItem(item) }">删除</button>
              </div>
            </div>
            <div v-if="milestonesByGroup[item.id]?.length" class="mt-2.5 pt-2.5 border-t border-gray-100">
              <div class="text-[11px] text-gray-400 mb-1.5">阶梯奖励</div>
              <div class="flex flex-wrap gap-1.5">
                <div v-for="ms in milestonesByGroup[item.id]" :key="ms.id" class="bg-[#f5f6f8] rounded-lg px-2.5 py-1.5 text-xs cursor-pointer active:bg-gray-200 transition-colors" @click="openMilestoneDialog(ms, item.id)">
                  <span class="font-medium text-gray-700">D+{{ ms.days }}</span>
                  <span class="text-gray-400 ml-1">{{ ms.points }}|{{ ms.experience }}|{{ ms.balance }}</span>
                  <span v-if="ms.card_key_type" class="text-orange-400 ml-1">卡</span>
                </div>
              </div>
            </div>
            <button v-auth="'add'" class="mt-2 text-[11px] text-gray-400 active:text-[#FF4757]" @click.stop="openMilestoneDialog(null, item.id)">+ 添加阶梯</button>
          </div>
          <div class="text-center text-xs text-gray-400 py-3">共 {{ groups.length }} 条 [{{ Date.now() % 100000 }}]</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无签到规则组</span></div>
      </div>

      <button v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑规则组' : '新增规则组' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">组名</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">图标</label><input v-model="form.icon" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">图标颜色</label><input v-model="form.iconColor" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer bg-[#f5f6f8]" /></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">适用等级</label>
            <select v-model.number="form.levelId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none">
              <option :value="0">不限等级</option>
              <option v-for="lv in memberLevels" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
            </select>
          </div>
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">基础奖励</div>
            <div class="grid grid-cols-3 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">积分</label><input v-model.number="form.points" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">经验</label><input v-model.number="form.experience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">余额</label><input v-model.number="form.balance" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
          </div>
          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">连续签到加成</div>
            <div class="grid grid-cols-3 gap-3">
              <div><label class="text-[10px] text-gray-400 mb-1 block">积分加成</label><input v-model.number="form.pointsConsecutive" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">经验加成</label><input v-model.number="form.experienceConsecutive" type="number" min="0" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
              <div><label class="text-[10px] text-gray-400 mb-1 block">余额加成</label><input v-model.number="form.balanceConsecutive" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            </div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sortOrder" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>

    <!-- 阶梯奖励编辑弹窗 -->
    <div v-if="msDialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="msDialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="msDialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ msEditId ? '编辑阶梯奖励' : '新增阶梯奖励' }}</span>
          <div class="flex items-center gap-3">
            <button v-if="msEditId" class="text-sm text-red-400" @click="deleteMilestone({ id: msEditId, days: msForm.days })">删除</button>
            <button class="text-sm font-semibold text-[#FF4757]" @click="saveMilestone">保存</button>
          </div>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-3">
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">连续天数</label><input v-model.number="msForm.days" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="msForm.sortOrder" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="grid grid-cols-3 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">积分</label><input v-model.number="msForm.points" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">经验</label><input v-model.number="msForm.experience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">余额</label><input v-model.number="msForm.balance" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="pt-2 border-t border-gray-100">
            <div class="text-xs text-gray-500 font-medium mb-2">卡密奖励 (可选)</div>
            <div><label class="text-[11px] text-gray-400 mb-1 block">卡密类型</label><select v-model="msForm.cardKeyType" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="">无</option><option value="membership">会员卡</option><option value="points">积分卡</option><option value="recharge">充值卡</option></select></div>
            <div class="mt-2"><label class="text-[11px] text-gray-400 mb-1 block">卡密值</label><input v-model.number="msForm.cardKeyValue" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div class="grid grid-cols-2 gap-3 mt-2">
              <div><label class="text-[11px] text-gray-400 mb-1 block">时长</label><input v-model.number="msForm.cardKeyDuration" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
              <div><label class="text-[11px] text-gray-400 mb-1 block">时长单位</label><select v-model="msForm.cardKeyDurationUnit" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="">-</option><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div>
            </div>
            <div class="grid grid-cols-3 gap-3 mt-2">
              <div><label class="text-[11px] text-gray-400 mb-1 block">额外积分</label><input v-model.number="msForm.cardKeyExtraPoints" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
              <div><label class="text-[11px] text-gray-400 mb-1 block">额外经验</label><input v-model.number="msForm.cardKeyExtraExperience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
              <div><label class="text-[11px] text-gray-400 mb-1 block">额外余额</label><input v-model.number="msForm.cardKeyExtraBalance" type="number" min="0" step="0.01" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 确认删除弹窗 -->
    <div v-if="showConfirm" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showConfirm = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="text-center pt-6 pb-2 px-4">
          <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-red-50 flex items-center justify-center">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">{{ confirmText }}</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="showConfirm = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-medium border-l border-gray-100 active:bg-red-50" @click="doConfirmed">删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'CheckinManageMobile' })

const showConfirm = ref(false)
const confirmText = ref('')
let pendingAction: (() => void) | null = null
const doConfirmed = () => {
  showConfirm.value = false
  if (pendingAction) pendingAction()
}
const askConfirm = (text: string, action: () => void) => {
  confirmText.value = text
  pendingAction = action
  showConfirm.value = true
}

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const checkinEnabled = ref(false)
const fetchEnabled = async () => {
  try {
    const res: any = await request.get({ url: '/api/checkin/enabled-status' })
    checkinEnabled.value = res?.enabled || res?.data?.enabled || false
  } catch (e) { /* ignore */ }
}

const toggleCheckin = async () => {
  const newStatus = !checkinEnabled.value
  try {
    await request.post({ url: '/api/checkin/enabled-status', data: { enabled: newStatus } })
    checkinEnabled.value = newStatus
    showToast(newStatus ? '签到已开启' : '签到已关闭')
  } catch (e) { showToast('操作失败', 'error') }
}

const memberLevels = ref<any[]>([])
const loadMemberLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    memberLevels.value = res?.records || []
  } catch (e) { /* ignore */ }
}

const loading = ref(false); const groups = ref<any[]>([])
const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/operation/checkin-group/list' })
    const list = res?.records || res?.data?.records || []
    groups.value = list
  } catch (e) { console.error('fetchData error:', e) }
  loading.value = false
}

const milestonesByGroup = ref<Record<number, any[]>>({})
const loadAllMilestones = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/checkin-milestone/list' })
    const all: any[] = res?.records || res?.data?.records || []
    const map: Record<number, any[]> = {}
    for (const m of all) {
      const gid = m.group_id || m.groupId
      if (!map[gid]) map[gid] = []
      map[gid].push(m)
    }
    milestonesByGroup.value = { ...map }
  } catch (e) { console.error('loadAllMilestones error:', e) }
}


const dialogVisible = ref(false); const editId = ref<number | null>(null)
const formDefault = () => ({ name: '', levelId: 0, icon: 'S', iconColor: '#508DFF', points: 0, experience: 0, balance: 0, pointsConsecutive: 0, experienceConsecutive: 0, balanceConsecutive: 0, sortOrder: 0, status: '1' })
const form = reactive(formDefault())

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) {
    form.name = item.name || ''; form.levelId = item.levelId || item.level_id || 0
    form.icon = item.icon || 'S'; form.iconColor = item.iconColor || item.icon_color || '#508DFF'
    form.points = item.points || 0; form.experience = item.experience || 0; form.balance = item.balance || 0
    form.pointsConsecutive = item.pointsConsecutive || item.points_consecutive || 0
    form.experienceConsecutive = item.experienceConsecutive || item.experience_consecutive || 0
    form.balanceConsecutive = item.balanceConsecutive || item.balance_consecutive || 0
    form.sortOrder = item.sortOrder || item.sort_order || 0; form.status = item.status || '1'
  } else {
    Object.assign(form, formDefault())
  }
  dialogVisible.value = true
}

const saveItem = async () => {
  try {
    const data = { ...form }
    if (editId.value) data.id = editId.value
    await request.post({ url: '/api/operation/checkin-group/save', data })
    showToast('保存成功')
    dialogVisible.value = false
    fetchData()
    loadAllMilestones()
  } catch (e) { showToast('保存失败', 'error') }
}

const deleteItem = (item: any) => {
  askConfirm(`确认删除规则组「${item.name}」？`, async () => {
    try {
      await request.del({ url: `/api/operation/checkin-group/${item.id}` })
      showToast('删除成功')
      fetchData()
      loadAllMilestones()
    } catch (e) { showToast('删除失败', 'error') }
  })
}

const msDialogVisible = ref(false); const msEditId = ref<number | null>(null); const msGroupId = ref(0)
const msFormDefault = () => ({ days: 7, points: 0, experience: 0, balance: 0, sortOrder: 0, cardKeyType: '', cardKeyValue: 0, cardKeyDuration: 0, cardKeyDurationUnit: '', cardKeyExtraPoints: 0, cardKeyExtraExperience: 0, cardKeyExtraBalance: 0 })
const msForm = reactive(msFormDefault())

const openMilestoneDialog = (item: any | null, groupId?: number) => {
  if (groupId != null) msGroupId.value = groupId
  msEditId.value = item?.id || null
  if (item) {
    msForm.days = item.days || 1; msForm.points = item.points || 0; msForm.experience = item.experience || 0
    msForm.balance = item.balance || 0; msForm.sortOrder = item.sort_order || 0
    msForm.cardKeyType = item.card_key_type || ''; msForm.cardKeyValue = item.card_key_value || 0
    msForm.cardKeyDuration = item.card_key_duration || 0; msForm.cardKeyDurationUnit = item.card_key_duration_unit || ''
    msForm.cardKeyExtraPoints = item.card_key_extra_points || 0; msForm.cardKeyExtraExperience = item.card_key_extra_experience || 0
    msForm.cardKeyExtraBalance = item.card_key_extra_balance || 0
  } else {
    Object.assign(msForm, msFormDefault())
  }
  msDialogVisible.value = true
}

const saveMilestone = async () => {
  try {
    const data: any = { ...msForm, groupId: msGroupId.value }
    if (msEditId.value) data.id = msEditId.value
    await request.post({ url: '/api/operation/checkin-milestone/save', data })
    showToast('保存成功')
    msDialogVisible.value = false
    loadAllMilestones()
  } catch (e) { showToast('保存失败', 'error') }
}

const deleteMilestone = (item: any) => {
  askConfirm(`确认删除第 ${item.days} 天阶梯奖励？`, async () => {
    try {
      await request.del({ url: `/api/operation/checkin-milestone/${item.id}` })
      showToast('删除成功')
      msDialogVisible.value = false
      loadAllMilestones()
    } catch (e) { showToast('删除失败', 'error') }
  })
}

onMounted(() => { fetchEnabled(); fetchData(); loadMemberLevels(); loadAllMilestones() })
</script>
