<template>
  <div class="address-page">
    <div class="header">
      <button class="back-btn" @click="$router.back()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="title">收货地址</span>
      <button class="add-icon-btn" @click="openAdd">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
      </button>
    </div>

    <div class="body" ref="bodyRef">
      <div v-if="loading" class="loading-state">
        <div class="loading-ring"></div>
        <p>加载中...</p>
      </div>

      <div v-else-if="list.length === 0" class="empty-state">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#d0d5dd" stroke-width="1.2">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
          <circle cx="12" cy="10" r="3"/>
        </svg>
        <p>暂无收货地址</p>
        <span>点击右上角添加新地址</span>
      </div>

      <template v-else>
        <div v-for="addr in list" :key="addr.id" class="addr-card" :class="{ default: addr.isDefault }">
          <div class="card-top">
            <div class="card-user">
              <span class="user-avatar">{{ addr.name?.charAt(0) || '?' }}</span>
              <div>
                <div class="user-name">{{ addr.name }}</div>
                <div class="user-phone">{{ addr.phone }}</div>
              </div>
            </div>
            <span v-if="addr.isDefault" class="default-badge">默认</span>
          </div>
          <div class="card-address">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            {{ addr.province }}{{ addr.city }}{{ addr.district }} {{ addr.detail }}
          </div>
          <div class="card-actions">
            <button class="act edit" @click="openEdit(addr)">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              编辑
            </button>
            <button v-if="!addr.isDefault" class="act set-default" @click="setDefault(addr)">设为默认</button>
            <button class="act del" @click="handleDelete(addr)">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/></svg>
              删除
            </button>
          </div>
        </div>
      </template>

      <div class="bottom-bar" v-if="list.length > 0">
        <button class="add-btn" @click="openAdd">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
          新增收货地址
        </button>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <teleport to="body">
      <transition name="sheet" mode="out-in">
        <div v-if="showEdit" class="overlay" @click.self="showEdit = false">
          <div class="sheet" @click.stop>
            <div class="sheet-handle"></div>
            <div class="sheet-title">{{ editingId ? '编辑地址' : '新增地址' }}</div>
            <div class="form-scroll">
              <div class="form-group">
                <label>收货人</label>
                <input v-model="form.name" placeholder="请输入姓名" />
              </div>
              <div class="form-group">
                <label>联系电话</label>
                <input v-model="form.phone" placeholder="请输入手机号码" type="tel" />
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>省份</label>
                  <input v-model="form.province" placeholder="省" />
                </div>
                <div class="form-group">
                  <label>城市</label>
                  <input v-model="form.city" placeholder="市" />
                </div>
                <div class="form-group">
                  <label>区/县</label>
                  <input v-model="form.district" placeholder="区/县" />
                </div>
              </div>
              <div class="form-group">
                <label>详细地址</label>
                <textarea v-model="form.detail" placeholder="街道、门牌号等" rows="2"></textarea>
              </div>
              <div class="form-group checkbox-row" @click="form.isDefault = !form.isDefault">
                <span class="checkbox-box" :class="{ checked: form.isDefault }">
                  <svg v-if="form.isDefault" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
                </span>
                <label>设为默认收货地址</label>
              </div>
            </div>
            <div class="sheet-actions">
              <button class="btn-cancel" @click="showEdit = false">取消</button>
              <button class="btn-confirm" :disabled="saving" @click="handleSave">{{ saving ? '保存中...' : '保存' }}</button>
            </div>
          </div>
        </div>
      </transition>
    </teleport>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const list = ref([])
const loading = ref(true)
const saving = ref(false)
const showEdit = ref(false)
const editingId = ref(0)
const form = ref({ name: '', phone: '', province: '', city: '', district: '', detail: '', isDefault: false })

onMounted(() => fetchList())

async function fetchList() {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/user/addresses' })
    list.value = res || []
  } catch (e) { console.error(e) }
  loading.value = false
}

function openAdd() {
  editingId.value = 0
  form.value = { name: '', phone: '', province: '', city: '', district: '', detail: '', isDefault: false }
  showEdit.value = true
}

function openEdit(addr) {
  editingId.value = addr.id
  form.value = { ...addr, isDefault: addr.isDefault === 1 }
  showEdit.value = true
}

async function handleSave() {
  const f = form.value
  if (!f.name.trim()) return ElMessage.warning('请输入收货人姓名')
  if (!/^\d{11}$/.test(f.phone)) return ElMessage.warning('请输入正确的11位手机号码')
  if (!f.province.trim() || !f.city.trim() || !f.district.trim()) return ElMessage.warning('请完整填写省/市/区')
  if (!f.detail.trim()) return ElMessage.warning('请输入详细地址')

  saving.value = true
  const data = { ...form.value, isDefault: form.value.isDefault }
  try {
    if (editingId.value) {
      await request.put({ url: `/api/user/addresses/${editingId.value}`, data })
    } else {
      await request.post({ url: '/api/user/addresses', data })
    }
    showEdit.value = false
    fetchList()
  } catch (e) { alert(e?.msg || '保存失败') }
  finally { saving.value = false }
}

async function handleDelete(addr) {
  if (!confirm(`确定删除地址 "${addr.name}" 吗？`)) return
  try {
    await request.del({ url: `/api/user/addresses/${addr.id}` })
    fetchList()
  } catch (e) { alert(e?.msg || '删除失败') }
}

async function setDefault(addr) {
  try {
    await request.put({ url: `/api/user/addresses/${addr.id}/default`, data: {} })
    fetchList()
  } catch (e) { alert(e?.msg || '设置失败') }
}
</script>

<style scoped>
.address-page {
  min-height: 100vh;
  background: #f5f6fa;
  display: flex;
  flex-direction: column;
}

.header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #fff;
  gap: 12px;
}
.header .title {
  flex: 1;
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
}
.back-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  background: #f5f5f5;
  border: none;
  border-radius: 10px;
  color: #333;
  cursor: pointer;
}
.add-icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  background: #FF5722;
  border: none;
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
}

.body {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
}

/* 地址卡片 */
.addr-card {
  background: #fff;
  border-radius: 14px;
  padding: 16px;
  margin-bottom: 12px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
  transition: all 0.2s;
}
.addr-card.default {
  border: 1.5px solid #FF5722;
  box-shadow: 0 2px 12px rgba(255,87,34,0.08);
}
.card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}
.card-user {
  display: flex;
  align-items: center;
  gap: 10px;
}
.user-avatar {
  width: 38px;
  height: 38px;
  border-radius: 12px;
  background: linear-gradient(135deg, #FF5722, #FF8A65);
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}
.user-name {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
}
.user-phone {
  font-size: 12px;
  color: #999;
  margin-top: 2px;
}
.default-badge {
  background: linear-gradient(135deg, #FFF3E0, #FFE0B2);
  color: #E65100;
  font-size: 11px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 20px;
}
.card-address {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  font-size: 13px;
  color: #666;
  padding: 10px 0;
  border-top: 1px solid #f5f5f5;
  border-bottom: 1px solid #f5f5f5;
  line-height: 1.5;
}
.card-address svg {
  margin-top: 2px;
  flex-shrink: 0;
}
.card-actions {
  display: flex;
  gap: 6px;
  margin-top: 10px;
}
.act {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 6px 14px;
  border: none;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s;
}
.act.edit {
  background: #f0f5ff;
  color: #3B82F6;
}
.act.edit:active { background: #dbeafe; }
.act.set-default {
  background: #fff7ed;
  color: #FF5722;
}
.act.set-default:active { background: #ffedd5; }
.act.del {
  background: #fef2f2;
  color: #EF4444;
}
.act.del:active { background: #fee2e2; }

/* 底部新增按钮 */
.bottom-bar {
  padding: 12px 0;
  position: sticky;
  bottom: 0;
}
.add-btn {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 14px;
  background: linear-gradient(135deg, #FF5722, #FF8A65);
  color: #fff;
  border: none;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(255,87,34,0.25);
  transition: all 0.2s;
}
.add-btn:active { transform: scale(0.98); opacity: 0.9; }

/* 空/加载状态 */
.empty-state {
  text-align: center;
  padding: 80px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.empty-state p { font-size: 15px; color: #999; margin: 0; margin-top: 4px; }
.empty-state span { font-size: 12px; color: #ccc; }
.loading-state {
  text-align: center;
  padding: 80px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.loading-state p { font-size: 14px; color: #999; margin: 0; }
.loading-ring {
  width: 30px;
  height: 30px;
  border: 3px solid #f0f0f0;
  border-top-color: #FF5722;
  border-radius: 50%;
  animation: spin .8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* 底部弹窗 */
.overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.4);
  z-index: 200;
  display: flex;
  align-items: flex-end;
}
.sheet {
  background: #fff;
  width: 100%;
  border-radius: 20px 20px 0 0;
  padding: 0 0 24px;
  max-height: 80vh;
  display: flex;
  flex-direction: column;
}
.sheet-handle {
  width: 36px;
  height: 4px;
  background: #ddd;
  border-radius: 2px;
  margin: 12px auto 4px;
}
.sheet-title {
  font-size: 17px;
  font-weight: 700;
  color: #1a1a2e;
  padding: 8px 20px 16px;
  text-align: center;
}
.form-scroll {
  overflow-y: auto;
  padding: 0 20px;
  max-height: 50vh;
}
.form-group {
  margin-bottom: 14px;
}
.form-group label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: #666;
  margin-bottom: 6px;
}
.form-group input,
.form-group textarea {
  width: 100%;
  padding: 11px 14px;
  border: 1.5px solid #eee;
  border-radius: 10px;
  font-size: 14px;
  color: #333;
  background: #f9fafb;
  box-sizing: border-box;
  outline: none;
  transition: border-color .2s;
  font-family: inherit;
}
.form-group input:focus,
.form-group textarea:focus {
  border-color: #FF5722;
  background: #fff;
}
.form-group textarea { resize: none; }
.form-row {
  display: flex;
  gap: 10px;
}
.form-row .form-group { flex: 1; }
.checkbox-row {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  padding: 4px 0;
}
.checkbox-box {
  width: 20px;
  height: 20px;
  border: 2px solid #ddd;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all .2s;
}
.checkbox-box.checked {
  background: #FF5722;
  border-color: #FF5722;
}
.checkbox-row label {
  font-size: 14px;
  color: #333;
  margin: 0;
  cursor: pointer;
}
.sheet-actions {
  display: flex;
  gap: 12px;
  padding: 16px 20px 0;
}
.btn-cancel,
.btn-confirm {
  flex: 1;
  padding: 13px;
  border: none;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all .15s;
}
.btn-cancel {
  background: #f5f5f5;
  color: #666;
}
.btn-cancel:active { background: #eee; }
.btn-confirm {
  background: linear-gradient(135deg, #FF5722, #FF8A65);
  color: #fff;
}
.btn-confirm:active { opacity: .85; }
.btn-confirm:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* 弹窗动画 */
.sheet-enter-active { transition: all .3s ease-out; }
.sheet-leave-active { transition: all .25s ease-in; }
.sheet-enter-from { opacity: 0; }
.sheet-enter-from .sheet { transform: translateY(100%); }
.sheet-leave-to { opacity: 0; }
.sheet-leave-to .sheet { transform: translateY(100%); }

/* 全局不滚动 */
:global(body.no-scroll) { overflow: hidden; }
</style>
