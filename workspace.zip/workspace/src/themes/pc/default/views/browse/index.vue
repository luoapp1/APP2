<template>
  <div class="pc-browse">
    <div class="pc-header">
      <div class="pc-search-bar">
        <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
        <input v-model="searchText" placeholder="搜索应用、游戏..." class="pc-search-input" @keyup.enter="doSearch" />
      </div>
      <div class="pc-header-actions">
        <button class="pc-btn pc-btn-primary" @click="goUpload">上传应用</button>
      </div>
    </div>

    <div class="pc-content" v-if="apps.length">
      <div class="pc-section">
        <h3 class="pc-section-title">精品推荐</h3>
        <div class="pc-app-grid">
          <div v-for="app in apps.slice(0, 8)" :key="app.id" class="pc-app-card" @click="openDetail(app.id)">
            <div class="pc-app-icon" :style="{ background: app.iconBgColor || iconColor(app.name) }">
                <img v-if="app.icon" :src="fixImgUrl(app.icon)" />
              <svg v-else viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </div>
            <div class="pc-app-info">
              <h4 class="pc-app-name">{{ app.name }}</h4>
              <p class="pc-app-desc">{{ app.description || '暂无描述' }}</p>
              <div class="pc-app-meta">
                <span class="pc-app-rating">★ {{ app.rating || '0' }}</span>
                <span class="pc-app-size">{{ app.size_mb || 0 }} MB</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="pc-section" v-if="apps.length > 8">
        <h3 class="pc-section-title">全部应用</h3>
        <div class="pc-app-grid">
          <div v-for="app in apps.slice(8)" :key="app.id" class="pc-app-card" @click="openDetail(app.id)">
            <div class="pc-app-icon" :style="{ background: app.iconBgColor || iconColor(app.name) }">
                <img v-if="app.icon" :src="fixImgUrl(app.icon)" />
              <svg v-else viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </div>
            <div class="pc-app-info">
              <h4 class="pc-app-name">{{ app.name }}</h4>
              <p class="pc-app-desc">{{ app.description || '暂无描述' }}</p>
              <div class="pc-app-meta">
                <span class="pc-app-rating">★ {{ app.rating || '0' }}</span>
                <span class="pc-app-size">{{ app.size_mb || 0 }} MB</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else class="pc-empty">
      <p>暂无应用数据</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchPublicApps } from '@/api/appstore'
import { fixImgUrl } from '@/utils'
import { iconColor } from '@/utils/ui'

defineOptions({ name: 'PcBrowse' })

const router = useRouter()
const searchText = ref('')
const apps = ref<any[]>([])

const openDetail = (id: number) => router.push(`/a/${id}`)
const goUpload = () => router.push('/appstore/submissions')
const doSearch = () => {
  if (searchText.value.trim()) {
    router.push(`/appstore/category?q=${encodeURIComponent(searchText.value)}`)
  }
}

onMounted(async () => {
  try {
    const res = await fetchPublicApps()
    apps.value = res || []
  } catch {}
})
</script>

<style scoped>
.pc-browse {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px 32px;
}

.pc-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 32px;
}

.pc-search-bar {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 10px 16px;
  max-width: 480px;
}

.search-icon {
  width: 20px;
  height: 20px;
  color: #9ca3af;
  flex-shrink: 0;
}

.pc-search-input {
  border: none;
  outline: none;
  font-size: 14px;
  color: #374151;
  background: transparent;
  width: 100%;
}

.pc-search-input::placeholder {
  color: #9ca3af;
}

.pc-header-actions {
  display: flex;
  gap: 8px;
}

.pc-btn {
  padding: 8px 20px;
  border-radius: 8px;
  border: 1px solid #e5e7eb;
  background: #fff;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.15s;
  color: #374151;
}

.pc-btn:hover {
  background: #f9fafb;
}

.pc-btn-primary {
  background: #3D7BEA;
  color: #fff;
  border-color: #3D7BEA;
}

.pc-btn-primary:hover {
  background: #2563eb;
}

.pc-section {
  margin-bottom: 32px;
}

.pc-section-title {
  font-size: 18px;
  font-weight: 700;
  color: #111827;
  margin-bottom: 16px;
}

.pc-app-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 16px;
}

.pc-app-card {
  display: flex;
  gap: 14px;
  padding: 20px;
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.pc-app-card:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  transform: translateY(-2px);
}

.pc-app-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: #fff;
  overflow: hidden;
}

.pc-app-icon img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.pc-app-icon svg {
  width: 28px;
  height: 28px;
}

.pc-app-info {
  flex: 1;
  min-width: 0;
}

.pc-app-name {
  font-size: 15px;
  font-weight: 600;
  color: #111827;
  margin-bottom: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.pc-app-desc {
  font-size: 12px;
  color: #9ca3af;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.pc-app-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #6b7280;
}

.pc-empty {
  text-align: center;
  padding: 80px 0;
  color: #9ca3af;
}
</style>
