<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import { fetchAppDetail, fetchAppList, fetchPostComment, fetchCommentLike, fetchDeleteComment, fetchReportComment, fetchReplyComment, fetchPinComment, fetchPurchaseApp, fetchPurchaseStatus, fetchPurchasers, fetchUsableCoupons } from '@/api/appstore'
import { toNum, fmtCount, relativeTime, iconColor } from '@/utils'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const app = ref<any>(null)
const comments = ref<any[]>([])
const appList = ref<any[]>([])
const activeTab = ref('detail')
const purchased = ref(false)
const loading = ref(true)
const commentPage = ref(1)
const commentPageSize = 20
const commentTotal = ref(0)
const commentSort = ref('latest')
const showCommentDialog = ref(false)
const commentText = ref('')
const commentRating = ref(5)
const submitLoading = ref(false)
const showTipDialog = ref(false)
const showDownloadDialog = ref(false)
const showPurchaseDialog = ref(false)
const tipAmount = ref(0)
const purchasedList = ref<any[]>([])
const showPurchaserDialog = ref(false)
const coupons = ref<any[]>([])
const selectedCoupon = ref<any>(null)

const isLogin = computed(() => userStore.isLogin)
const isAdmin = computed(() => {
  const roles = userStore.info?.roles || []
  return roles.includes('R_ADMIN') || roles.includes('R_SUPER')
})

async function loadApp() {
  const id = route.params.id as string
  if (!id) return
  loading.value = true
  try {
    const res = await fetchAppDetail(id)
    app.value = res.data || res
  } catch (e: any) {
    ElMessage.error(e.message || '加载失败')
  } finally {
    loading.value = false
  }
}

async function loadComments() {
  const id = route.params.id as string
  try {
    const res = await fetchPostComment({
      appId: id,
      page: commentPage.value,
      pageSize: commentPageSize,
      sort: commentSort.value
    })
    comments.value = res.data?.list || res.list || []
    commentTotal.value = res.data?.total || res.total || 0
  } catch (e) { /* ignore */ }
}

async function loadPurchaseStatus() {
  if (!isLogin.value) return
  const id = route.params.id as string
  try {
    const res = await fetchPurchaseStatus(id)
    purchased.value = res.data?.purchased || res.purchased || false
  } catch (e) { /* ignore */ }
}

function goBack() { router.back() }

onMounted(() => { loadApp(); loadComments(); loadPurchaseStatus() })
watch(() => route.params.id, () => { loadApp(); loadComments(); loadPurchaseStatus() })
</script>

<template>
  <div class="pc-detail-page">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <h2 v-if="app">{{ app.name }}</h2>
    </div>

    <div v-if="loading" class="loading-state">
      <el-skeleton :rows="8" animated />
    </div>

    <div v-else-if="app" class="detail-layout">
      <div class="detail-sidebar">
        <div class="app-card">
          <img :src="$fixImgUrl(app.icon)" class="app-icon"  loading="lazy" />
          <h3>{{ app.name }}</h3>
          <p class="app-package">{{ app.packageName }}</p>
          <div class="app-meta">
            <span>v{{ app.version || app.latestVersion }}</span>
            <span>{{ toNum(app.size) }} MB</span>
            <span>{{ fmtCount(app.downloads) }} 下载</span>
          </div>
          <el-button type="primary" size="large" class="download-btn" @click="showDownloadDialog = true">
            {{ purchased ? '已购买' : (app.price > 0 ? `¥${app.price}` : '免费下载') }}
          </el-button>
        </div>

        <div class="tags-section">
          <h4>标签</h4>
          <div class="tag-list">
            <el-tag v-for="tag in (app.tags || [])" :key="tag" size="small">{{ tag }}</el-tag>
          </div>
        </div>
      </div>

      <div class="detail-main">
        <div class="tab-bar">
          <el-radio-group v-model="activeTab" size="default">
            <el-radio-button value="detail">详情</el-radio-button>
            <el-radio-button value="discuss">讨论</el-radio-button>
            <el-radio-button value="versions">版本</el-radio-button>
          </el-radio-group>
        </div>

        <div class="tab-content">
          <div v-if="activeTab === 'detail'" class="detail-body">
            <div class="screenshots" v-if="app.screenshots?.length">
              <h4>应用截图</h4>
              <div class="screenshot-list">
                <img v-for="(s, i) in app.screenshots" :key="i" :src="s" class="screenshot"  loading="lazy" />
              </div>
            </div>
            <div class="description-section">
              <h4>应用介绍</h4>
              <div class="description" v-html="app.description || '暂无介绍'"></div>
            </div>
          </div>

          <div v-if="activeTab === 'discuss'" class="discuss-body">
            <div class="comment-header">
              <el-input v-model="commentText" type="textarea" :rows="3" placeholder="写下你的评论..." />
              <div class="comment-actions">
                <el-rate v-model="commentRating" />
                <el-button type="primary" @click="showCommentDialog = true" :disabled="!commentText.trim()">发表评论</el-button>
              </div>
            </div>

            <div class="comment-sort">
              <el-radio-group v-model="commentSort" size="small" @change="loadComments">
                <el-radio-button value="latest">最新</el-radio-button>
                <el-radio-button value="hot">最热</el-radio-button>
              </el-radio-group>
            </div>

            <div class="comment-list">
              <div v-if="comments.length === 0" class="empty-state">暂无评论</div>
              <div v-for="c in comments" :key="c.id" class="comment-item">
                <img :src="$fixImgUrl(c.avatar || c.user?.avatar)" class="comment-avatar"  loading="lazy" />
                <div class="comment-body">
                  <div class="comment-user">{{ c.nickname || c.user?.nickname }}</div>
                  <div class="comment-text" v-html="c.content"></div>
                  <div class="comment-time">{{ relativeTime(c.createTime || c.createdAt) }}</div>
                </div>
              </div>
            </div>
          </div>

          <div v-if="activeTab === 'versions'" class="versions-body">
            <div v-if="!app.versions?.length" class="empty-state">暂无版本信息</div>
            <div v-for="v in (app.versions || [])" :key="v.id" class="version-item">
              <span class="version-tag">v{{ v.version }}</span>
              <span>{{ toNum(v.size) }} MB</span>
              <span>{{ v.updateTime || v.createdAt }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-detail-page {
  padding: 0 24px 24px;
  max-width: 1200px;
}
.page-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid var(--el-border-color-light);
  margin-bottom: 24px;
}
.page-header h2 { margin: 0; font-size: 20px; }
.loading-state { padding: 40px; }
.detail-layout { display: flex; gap: 32px; }
.detail-sidebar { width: 280px; flex-shrink: 0; }
.detail-main { flex: 1; min-width: 0; }
.app-card {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0,0,0,.08);
}
.app-icon { width: 80px; height: 80px; border-radius: 16px; margin-bottom: 12px; }
.app-package { color: #999; font-size: 12px; margin: 4px 0; }
.app-meta { display: flex; justify-content: center; gap: 12px; color: #666; font-size: 13px; margin: 12px 0; }
.download-btn { width: 100%; margin-top: 12px; }
.tags-section { margin-top: 20px; }
.tags-section h4 { margin: 0 0 8px; font-size: 14px; color: #333; }
.tag-list { display: flex; flex-wrap: wrap; gap: 6px; }
.tab-bar { margin-bottom: 20px; }
.tab-content { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
.screenshots h4, .description-section h4 { margin: 0 0 12px; font-size: 15px; }
.screenshot-list { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 8px; }
.screenshot { height: 300px; border-radius: 8px; object-fit: cover; }
.description { font-size: 14px; line-height: 1.8; color: #555; }
.comment-header { margin-bottom: 16px; }
.comment-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 8px; }
.comment-sort { margin-bottom: 16px; }
.comment-list { display: flex; flex-direction: column; gap: 16px; }
.comment-item { display: flex; gap: 12px; }
.comment-avatar { width: 36px; height: 36px; border-radius: 50%; }
.comment-body { flex: 1; }
.comment-user { font-size: 14px; font-weight: 500; }
.comment-text { font-size: 14px; color: #333; margin: 4px 0; }
.comment-time { font-size: 12px; color: #999; }
.empty-state { text-align: center; color: #999; padding: 40px 0; }
.versions-body { display: flex; flex-direction: column; gap: 12px; }
.version-item { display: flex; gap: 16px; padding: 12px; background: #f8f9fa; border-radius: 8px; font-size: 13px; }
.version-tag { font-weight: 600; color: var(--el-color-primary); }
</style>
