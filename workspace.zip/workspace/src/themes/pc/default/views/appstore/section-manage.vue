<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunitySections, fetchModeratorApplications, approveApplication, rejectApplication, updateCommunitySection } from '@/api/community'
import { ElMessage } from 'element-plus'

const router = useRouter()
const sections = ref<any[]>([])
const appVisible = ref(false)
const applications = ref<any[]>([])
const appLoading = ref(false)

const rejectVisible = ref(false)
const rejectId = ref(0)
const rejectReason = ref('')
const rejectSubmitting = ref(false)

const settingsVisible = ref(false)
const settingsSection = ref<any>(null)
const settingsHotThreshold = ref(100)
const settingsViewCooldown = ref(30)
const settingsSubmitting = ref(false)

const approveVisible = ref(false)
const approveId = ref(0)
const approveRole = ref('版主')
const approveSubmitting = ref(false)
const availableRoles = ['版主', '管理员', '超级版主', '审核员']

onMounted(async () => {
  try { const res = await fetchCommunitySections(); sections.value = res.data || res || [] } catch (e) {}
})

async function loadApplications() {
  appLoading.value = true
  try {
    const res = await fetchModeratorApplications()
    applications.value = res.data || res || []
  } catch (e) { /* ignore */ }
  finally { appLoading.value = false }
}

function showApplications() {
  appVisible.value = true
  loadApplications()
}

function showReject(id: number) {
  rejectId.value = id
  rejectReason.value = ''
  rejectVisible.value = true
}

async function doReject() {
  rejectSubmitting.value = true
  try {
    await rejectApplication(rejectId.value, rejectReason.value)
    ElMessage.success('已拒绝')
    rejectVisible.value = false
    loadApplications()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '操作失败')
  }
  finally { rejectSubmitting.value = false }
}

function showApprove(id: number) {
  approveId.value = id
  approveRole.value = '版主'
  approveVisible.value = true
}

async function doApprove() {
  approveSubmitting.value = true
  try {
    await approveApplication(approveId.value, approveRole.value)
    ElMessage.success('已通过')
    approveVisible.value = false
    loadApplications()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '操作失败')
  }
  finally { approveSubmitting.value = false }
}

function showSettings(section: any) {
  settingsSection.value = section
  settingsHotThreshold.value = section.hotThreshold ?? 100
  settingsViewCooldown.value = section.viewCooldown ?? 30
  settingsVisible.value = true
}

async function doSaveSettings() {
  settingsSubmitting.value = true
  try {
    const s = settingsSection.value
    await updateCommunitySection(s.id, {
      id: s.id, name: s.name, icon: s.icon || '', iconBgColor: s.iconBgColor || '#00BFA5',
      description: s.description || '', todayHeat: s.todayHeat || 0, totalHeat: s.totalHeat || 0,
      postCount: s.postCount || 0, viewCount: s.viewCount || 0, sortOrder: s.sortOrder || 0,
      status: s.status || 'active', visibility: s.visibility || 'public',
      postPermission: s.postPermission || 'all', viewPermission: s.viewPermission || 'all',
      viewLevelRequired: s.viewLevelRequired || 0,
      hotThreshold: settingsHotThreshold.value, viewCooldown: settingsViewCooldown.value
    })
    s.hotThreshold = settingsHotThreshold.value
    s.viewCooldown = settingsViewCooldown.value
    ElMessage.success('设置已保存')
    settingsVisible.value = false
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '保存失败')
  }
  finally { settingsSubmitting.value = false }
}

function statusLabel(s: string) {
  if (s === 'pending') return '待审核'
  if (s === 'approved') return '已通过'
  if (s === 'rejected') return '已拒绝'
  return s
}

function statusType(s: string) {
  if (s === 'pending') return 'warning'
  if (s === 'approved') return 'success'
  return 'danger'
}
</script>

<template>
  <div class="pc-page">
    <div class="page-header">
      <el-button text @click="router.back()">&larr; 返回</el-button>
      <h2>板块管理</h2>
      <el-button type="primary" @click="showApplications">申请列表</el-button>
    </div>

    <div class="content-card">
      <el-table :data="sections" v-if="sections.length">
        <el-table-column prop="name" label="板块名" />
        <el-table-column prop="todayHeat" label="今日热度" />
        <el-table-column label="操作">
          <template #default="{ row }">
            <el-button size="small" type="primary" plain>编辑</el-button>
            <el-button size="small" type="warning" plain @click="showSettings(row)">设置</el-button>
            <el-button size="small" type="danger" plain>删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div v-else class="empty">暂无板块</div>
    </div>

    <!-- 申请列表弹窗 -->
    <el-dialog v-model="appVisible" title="版主申请列表" width="800px">
      <el-table :data="applications" v-loading="appLoading" max-height="450">
        <el-table-column prop="userName" label="申请人" width="110" />
        <el-table-column prop="sectionName" label="板块" width="110" />
        <el-table-column prop="desiredRole" label="期望角色" width="90" />
        <el-table-column prop="reason" label="申请理由" min-width="150" show-overflow-tooltip />
        <el-table-column label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="申请时间" width="160">
          <template #default="{ row }">{{ row.createTime?.slice(0, 16)?.replace('T', ' ') }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <template v-if="row.status === 'pending'">
              <el-button size="small" type="success" @click="showApprove(row.id)">通过</el-button>
              <el-button size="small" type="danger" @click="showReject(row.id)">拒绝</el-button>
            </template>
            <span v-else class="processed-text">
              {{ row.reviewedByName || '-' }}
            </span>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <!-- 通过确认弹窗 -->
    <el-dialog v-model="approveVisible" title="通过申请" width="380px">
      <el-form label-width="80px">
        <el-form-item label="角色">
          <el-select v-model="approveRole" placeholder="选择角色" style="width:100%">
            <el-option v-for="r in availableRoles" :key="r" :label="r" :value="r" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="approveVisible = false">取消</el-button>
        <el-button type="success" :loading="approveSubmitting" @click="doApprove">确认通过</el-button>
      </template>
    </el-dialog>

    <!-- 板块设置弹窗 -->
    <el-dialog v-model="settingsVisible" :title="`板块设置 - ${settingsSection?.name || ''}`" width="480px">
      <el-form label-width="120px" v-if="settingsSection">
        <el-form-item label="热帖热度阈值">
          <el-input-number v-model="settingsHotThreshold" :min="1" :max="99999" :step="10" controls-position="right" style="width:100%" />
          <div class="form-tip">帖子热度达到此值后将被标记为"热帖"</div>
        </el-form-item>
        <el-form-item label="浏览计数冷却">
          <template #label>
            <span>浏览计数冷却 <span style="color:#909399;font-weight:400">(秒)</span></span>
          </template>
          <el-input-number v-model="settingsViewCooldown" :min="1" :max="86400" :step="5" controls-position="right" style="width:100%" />
          <div class="form-tip">同一用户在冷却时间内重复访问只计为 1 次浏览，防止刷量</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="settingsVisible = false">取消</el-button>
        <el-button type="primary" :loading="settingsSubmitting" @click="doSaveSettings">保存设置</el-button>
      </template>
    </el-dialog>

    <!-- 拒绝弹窗 -->
    <el-dialog v-model="rejectVisible" title="拒绝申请" width="400px">
      <el-form label-width="80px">
        <el-form-item label="拒绝理由">
          <el-input v-model="rejectReason" type="textarea" :rows="3" placeholder="可选填拒绝理由..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectVisible = false">取消</el-button>
        <el-button type="danger" :loading="rejectSubmitting" @click="doReject">确认拒绝</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.pc-page { padding: 0 24px 24px; max-width: 1000px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; flex: 1; }
.content-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.empty { text-align: center; padding: 60px; color: #999; }
.processed-text { font-size: 12px; color: #999; }
.form-tip { font-size: 12px; color: #909399; margin-top: 4px; line-height: 1.5; }
</style>
