<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import {
  fetchCommunityPost,
  fetchPostComments,
  createPostComment,
  likePost,
  fetchTopics
} from '@/api/community'
import { fmtRelativeTime, fmtCount } from '@/utils'
import { extractTextFromDoc } from '@/utils/tiptap'
import { sanitizeHtml } from '@/utils/ui/sanitize'
import { ElMessage, ElMessageBox } from 'element-plus'
import VersionDiff from '@/components/community/VersionDiff.vue'

  const route = useRoute()
  const router = useRouter()
  const userStore = useUserStore()

  const postId = computed(() => route.params.id as string)
  const post = ref<any>(null)
  const comments = ref<any[]>([])
  const topicMap = ref<Record<string, number>>({})
  const loading = ref(true)
  const commentText = ref('')
  const submitting = ref(false)
  const showVersions = ref(false)

  const renderedContent = computed(() => {
    const raw = post.value?.content || ''
    if (!raw) return ''
    try {
      const parsed = JSON.parse(raw)
      if (parsed && parsed.type === 'doc') {
        const html = tiptapToHtml(parsed)
        if (html) return html
        return extractTextFromDoc(parsed)
      }
      if (Array.isArray(parsed)) {
        const html = blocksToHtml(parsed)
        if (html) return html
        return (parsed as any[]).map((b) => escapeHtml(b.value || b.text || '')).join('<br>')
      }
    } catch {}
    if (raw.trim().startsWith('{') || raw.trim().startsWith('[')) {
      try {
        const doc = JSON.parse(raw)
        if (doc?.type === 'doc') return extractTextFromDoc(doc)
      } catch {}
    }
    return raw.replace(/<img\s/gi, '<img loading="lazy" ')
  })

  function sanitizeContent(html: string): string {
    return sanitizeHtml(html)
  }

  function extractTextFromDoc(doc: any): string {
    if (!doc?.content) return ''
    return doc.content
      .map((node: any) => {
        const t = extractNodeText(node)
        if (node.type === 'voteCard') return '[投票] ' + (node.attrs?.question || '')
        return t
      })
      .filter(Boolean)
      .join('<br>')
  }

  function extractNodeText(node: any): string {
    if (!node) return ''
    if (node.type === 'text') return escapeHtml(node.text || '')
    if (node.type === 'hardBreak') return ''
    if (node.content) return node.content.map(extractNodeText).join('')
    return ''
  }

  function tiptapToHtml(doc: any): string {
    if (!doc?.content) return ''
    return doc.content.map((node: any) => renderNode(node)).join('')
  }

  function renderNode(node: any): string {
    if (!node) return ''
    switch (node.type) {
      case 'paragraph': {
        const text = (node.content || []).map((n: any) => renderInline(n)).join('')
        return `<p>${text || '<br>'}</p>`
      }
      case 'heading': {
        const level = node.attrs?.level || 1
        const text = (node.content || []).map((n: any) => renderInline(n)).join('')
        return `<h${level}>${text}</h${level}>`
      }
      case 'image': {
        const src = node.attrs?.src || ''
        return `<img src="${src}" loading="lazy" style="max-width:100%;border-radius:8px;margin:8px 0;" />`
      }
      case 'paywall': {
        const label =
          node.attrs?.priceType === 'points'
            ? `${node.attrs?.price || 0}积分`
            : `￥${node.attrs?.price || 0}`
        return `<div style="display:flex;align-items:center;gap:10px;margin:16px 0;padding:12px 8px;background:#f9f9f9;border-radius:8px;"><span style="flex:1;height:1px;background:#e5e5e5;"></span><span style="font-size:12px;color:#999;">以下内容需付费 ${label} 后查看</span><span style="flex:1;height:1px;background:#e5e5e5;"></span></div>`
      }
      case 'blockquote': {
        const inner = (node.content || []).map((n: any) => renderNode(n)).join('')
        return `<blockquote style="border-left:3px solid #508DFF;padding-left:12px;color:#666;margin:8px 0;">${inner}</blockquote>`
      }
      case 'codeBlock': {
        const text = (node.content || []).map((n: any) => n.text || '').join('')
        return `<pre style="background:#f5f5f5;padding:12px;border-radius:8px;overflow-x:auto;margin:8px 0;"><code>${escapeHtml(text)}</code></pre>`
      }
      case 'bulletList':
      case 'orderedList': {
        const tag = node.type === 'orderedList' ? 'ol' : 'ul'
        const items = (node.content || [])
          .map((item: any) => {
            const inner = (item.content || [])
              .filter((n: any) => n.type !== 'listItem')
              .map((n: any) => renderNode(n))
              .join('')
            return `<li>${inner}</li>`
          })
          .join('')
        return `<${tag}>${items}</${tag}>`
      }
      case 'listItem': {
        const inner = (node.content || []).map((n: any) => renderInline(n)).join('')
        return inner
      }
      case 'horizontalRule':
        return '<hr />'
      case 'voteCard': {
        const q = escapeHtml(node.attrs?.question || '')
        let opts: string[] = []
        try {
          opts =
            typeof node.attrs?.options === 'string'
              ? JSON.parse(node.attrs.options)
              : node.attrs?.options || []
        } catch {}
        const mc = node.attrs?.maxSelect || 1
        return `<div style="background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef;"><div style="font-weight:600;font-size:14px;margin-bottom:8px">${q}</div><div style="font-size:12px;color:#999">${opts.length}个选项 · 最多选${mc}项</div></div>`
      }
      case 'goodsCard': {
        const t = escapeHtml(node.attrs?.title || '')
        const p = escapeHtml(node.attrs?.price || '')
        const img = escapeHtml(node.attrs?.image || '')
        const lk = escapeHtml(node.attrs?.link || '')
        return `<div style="display:flex;gap:12px;background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef;"><img src="${img}" style="width:60px;height:60px;border-radius:6px;object-fit:cover" onerror="this.style.display='none'" /><div style="flex:1"><div style="font-weight:600;font-size:14px">${t}</div><div style="color:#508DFF;font-weight:600;margin-top:4px">${p}</div></div></div>`
      }
      case 'audioBlock': {
        const src = escapeHtml(node.attrs?.src || '')
        const t = escapeHtml(node.attrs?.title || '')
        return `<div style="background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef;"><div style="font-size:14px;font-weight:600;margin-bottom:6px">${t || '音频'}</div><audio src="${src}" controls style="width:100%"></audio></div>`
      }
      case 'fileAttachment': {
        const n = escapeHtml(node.attrs?.name || '')
        const s = escapeHtml(node.attrs?.size || '')
        const u = escapeHtml(node.attrs?.url || '')
        return `<div style="display:flex;align-items:center;gap:10px;background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef;"><span style="font-size:24px">📁</span><div style="flex:1"><div style="font-weight:600;font-size:14px">${n}</div><div style="font-size:12px;color:#999">${s}</div></div><a href="${u}" target="_blank" style="color:#508DFF;font-size:13px">下载</a></div>`
      }
      case 'noticeBanner': {
        const t = node.attrs?.type || 'info'
        const c = escapeHtml(node.attrs?.content || '')
        const colors: Record<string, string> = {
          info: '#dbeafe,#1e40af',
          warning: '#fef3c7,#92400e',
          success: '#d1fae5,#065f46',
          error: '#fee2e2,#991b1b'
        }
        const [bg, fg] = (colors[t] || colors.info).split(',')
        return `<div style="background:${bg};color:${fg};border-radius:8px;padding:12px;margin:12px 0;font-size:14px">${c}</div>`
      }
      case 'updateLog': {
        const v = escapeHtml(node.attrs?.version || '')
        const d = escapeHtml(node.attrs?.date || '')
        let changes: string[] = node.attrs?.changes || []
        if (typeof changes === 'string') {
          try {
            changes = JSON.parse(changes)
          } catch {
            changes = [changes]
          }
        }
        const items = (Array.isArray(changes) ? changes : [])
          .map((c: string) => `<li>${escapeHtml(c)}</li>`)
          .join('')
        return `<div style="background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef;"><div style="font-weight:700;font-size:15px">v${v} <span style="font-weight:400;font-size:12px;color:#999;margin-left:8px">${d}</span></div><ul style="margin:8px 0 0;padding-left:18px;font-size:13px">${items}</ul></div>`
      }
      case 'passwordUnlock': {
        const h = escapeHtml(node.attrs?.hint || '')
        const c = escapeHtml(node.attrs?.content || '')
        return `<div style="background:#fef2f2;border:1px dashed #fca5a5;border-radius:8px;padding:16px;margin:12px 0;text-align:center"><div style="font-size:24px;margin-bottom:8px">🔐</div><div style="font-weight:600;color:#dc2626;font-size:14px">${h || '输入密码后即可查看以下内容'}</div><div style="font-size:12px;color:#f87171;margin-top:4px">密码保护内容</div></div>`
      }
      case 'galleryBlock': {
        let images: string[] = []
        try {
          images =
            typeof node.attrs?.images === 'string'
              ? JSON.parse(node.attrs.images)
              : node.attrs?.images || []
        } catch {}
        const imgs = (Array.isArray(images) ? images : [])
          .map(
            (img: string) =>
              `<img src="${escapeHtml(img)}" loading="lazy" style="width:100%;height:200px;object-fit:cover;border-radius:8px;flex-shrink:0" />`
          )
          .join('')
        return `<div style="display:flex;gap:8px;overflow-x:auto;padding:4px 0;margin:12px 0">${imgs}</div>`
      }
      case 'originalStatement': {
        const a = escapeHtml(node.attrs?.author || '')
        const l = escapeHtml(node.attrs?.license || '')
        const r = escapeHtml(node.attrs?.reprintRule || '')
        return `<div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:12px;margin:12px 0;font-size:13px"><div style="font-size:18px;margin-bottom:6px">©️</div><div style="font-weight:600;color:#0369a1">原创声明</div><div style="color:#0284c7;margin-top:2px">作者：${a} · ${l}</div><div style="color:#7dd3fc;margin-top:2px;font-size:12px">${r}</div></div>`
      }
      case 'sourceQuote': {
        const u = escapeHtml(node.attrs?.url || '')
        const a = escapeHtml(node.attrs?.author || '')
        const p = escapeHtml(node.attrs?.platform || '')
        const n = escapeHtml(node.attrs?.note || '')
        return `<div style="background:#f8f9fa;border-left:3px solid #508DFF;border-radius:0 8px 8px 0;padding:10px 14px;margin:12px 0;font-size:13px"><div style="font-weight:600;color:#333;margin-bottom:4px">📎 转载自 ${p}</div><div>原作者：${a}</div><a href="${u}" target="_blank" style="color:#508DFF;font-size:12px">${u}</a><div style="color:#999;font-size:12px;margin-top:4px">${n}</div></div>`
      }
      case 'followUnlock': {
        const h = escapeHtml(node.attrs?.hint || '')
        return `<div style="background:#f0fdf4;border:1px dashed #86efac;border-radius:8px;padding:16px;margin:12px 0;text-align:center"><div style="font-size:24px;margin-bottom:8px">👤</div><div style="font-weight:600;color:#166534;font-size:14px">关注作者后即可查看以下内容</div><div style="font-size:12px;color:#4ade80;margin-top:4px">${h}</div></div>`
      }
      case 'commentUnlock': {
        const mc = node.attrs?.minCommentCount || 1
        return `<div style="background:#faf5ff;border:1px dashed #c4b5fd;border-radius:8px;padding:16px;margin:12px 0;text-align:center"><div style="font-size:24px;margin-bottom:8px">💬</div><div style="font-weight:600;color:#6d28d9;font-size:14px">发布${mc}条评论后即可查看以下内容</div><div style="font-size:12px;color:#a78bfa;margin-top:4px">评论互动机密内容</div></div>`
      }
      case 'postRefCard': {
        const pid = node.attrs?.postId || 0
        const tit = escapeHtml(node.attrs?.title || '')
        const au = escapeHtml(node.attrs?.author || '')
        const sn = escapeHtml(node.attrs?.sectionName || '')
        const sum = escapeHtml(node.attrs?.summary || '')
        return `<a href="#/community/post/${pid}" style="text-decoration:none;display:block;color:inherit"><div style="display:flex;background:#f8fafc;border:1px solid #e2e8f0;border-left:4px solid #6366f1;border-radius:10px;padding:14px 16px;margin:14px 0;align-items:center;gap:12px;transition:background .2s"><div style="flex:1;min-width:0"><div style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg><span style="font-size:12px;color:#818cf8;font-weight:500">引用帖子</span></div><div style="font-size:14px;font-weight:600;color:#1e293b;line-height:1.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${tit}</div>${au || sn ? `<div style="font-size:12px;color:#94a3b8;margin-top:4px">${[au, sn].filter(Boolean).join(' · ')}</div>` : ''}${sum ? `<div style="font-size:12px;color:#94a3b8;line-height:1.5;margin-top:6px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical">${sum}</div>` : ''}</div><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg></div></a>`
      }
      default: {
        if (node.content) return node.content.map((n: any) => renderNode(n)).join('')
        return ''
      }
    }
  }

  function renderInline(node: any): string {
    if (!node) return ''
    if (node.type === 'text') {
      let text = escapeHtml(node.text || '')
      if (node.marks) {
        for (const mark of node.marks) {
          switch (mark.type) {
            case 'bold':
              text = `<strong>${text}</strong>`
              break
            case 'italic':
              text = `<em>${text}</em>`
              break
            case 'code':
              text = `<code style="background:#f5f5f5;padding:2px 6px;border-radius:4px;font-size:13px;color:#e11d48;">${text}</code>`
              break
            case 'strike':
              text = `<s>${text}</s>`
              break
            case 'underline':
              text = `<u>${text}</u>`
              break
            case 'highlight':
              text = `<mark style="background:#fef08a;padding:0 2px;border-radius:2px">${text}</mark>`
              break
            case 'subscript':
              text = `<sub>${text}</sub>`
              break
            case 'superscript':
              text = `<sup>${text}</sup>`
              break
            case 'link':
              text = `<a href="${escapeHtml(mark.attrs?.href || '#')}" target="_blank" rel="noopener">${text}</a>`
              break
            case 'hashtag': {
              const parts = text.split(/(#[^\s#]+)/g)
              if (parts.length > 1) {
                text = parts
                  .map((part) => {
                    if (part.startsWith('#') && part.length > 1) {
                      const tagName = part.slice(1)
                      const tId = topicMap.value[tagName]
                      if (tId)
                        return `<a href="/community/topic/${tId}" style="color:#6366f1;font-weight:700;text-decoration:none">${escapeHtml(part)}</a>`
                      return escapeHtml(part)
                    }
                    return escapeHtml(part)
                  })
                  .join('')
              } else {
                const tagName = text.startsWith('#') ? text.slice(1) : text
                const tId = topicMap.value[tagName]
                if (tId)
                  text = `<a href="/community/topic/${tId}" style="color:#6366f1;font-weight:700;text-decoration:none">${text}</a>`
              }
              break
            }
            case 'textStyle': {
              const attrs = mark.attrs || {}
              let style = ''
              if (attrs.color) style += `color:${escapeHtml(attrs.color)};`
              if (attrs.fontFamily) style += `font-family:${escapeHtml(attrs.fontFamily)};`
              if (style) text = `<span style="${style}">${text}</span>`
              break
            }
          }
        }
      }
      return text
    }
    if (node.type === 'image') {
      return `<img src="${node.attrs?.src || ''}" loading="lazy" style="max-width:100%;border-radius:8px;margin:4px 0;" />`
    }
    if (node.type === 'hardBreak') return '<br />'
    return ''
  }

  function blocksToHtml(blocks: any[]): string {
    return blocks
      .map((b: any) => {
        if (b.type === 'text') return `<p>${escapeHtml(b.value || '').replace(/\n/g, '<br>')}</p>`
        if (b.type === 'image' && b.images)
          return b.images
            .map(
              (img: string) =>
                `<img src="${img}" loading="lazy" style="max-width:100%;border-radius:8px;margin:8px 0;" />`
            )
            .join('')
        return ''
      })
      .join('')
  }

  function escapeHtml(str: string): string {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
  }

  const summaryText = computed(() => extractTextFromDoc(post.value?.content || '').slice(0, 150))

  function formatScheduledBanner(dt: string): string {
  if (!dt) return ''
  const d = new Date(dt)
  return `${d.getFullYear()}/${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getDate().toString().padStart(2, '0')} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`
}

async function loadPost() {
    loading.value = true
    try {
      try {
        const topics: any = await fetchTopics()
        if (topics?.list) {
          const map: Record<string, number> = {}
          topics.list.forEach((t: any) => {
            if (t.name) map[t.name] = t.id
          })
          topicMap.value = map
        }
      } catch {}
      const res = await fetchCommunityPost(postId.value)
      post.value = res.data || res
    } catch (e) {
      /* ignore */
    } finally {
      loading.value = false
    }
  }

  async function loadComments() {
    try {
      const res = await fetchPostComments({ postId: postId.value, page: 1, pageSize: 50 })
      comments.value = res.data?.list || res.list || []
    } catch (e) {
      /* ignore */
    }
  }

  async function submitComment() {
    if (!commentText.value.trim()) return
    submitting.value = true
    try {
      await createPostComment({ postId: postId.value, content: commentText.value })
      commentText.value = ''
      ElMessage.success('评论成功')
      await loadComments()
    } catch (e: any) {
      ElMessage.error(e.message || '评论失败')
    } finally {
      submitting.value = false
    }
  }

  async function handleLike() {
    try {
      await likePost(postId.value)
      if (post.value) post.value.isLiked = !post.value.isLiked
    } catch (e) {
      /* ignore */
    }
  }

  function goBack() {
    router.back()
  }

  async function handleDeletePost() {
    if (!post.value) return
    try {
      await ElMessageBox.confirm('确定要删除该帖子吗？删除后帖子将移入回收站，可恢复。', '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
      const res = await fetch(`/api/community/post/${post.value.id}`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken } })
      const data = await res.json()
      if (data.code === 200) { ElMessage.success('已移入回收站'); router.push('/community') }
      else { ElMessage.error(data.msg || '删除失败') }
    } catch {}
  }

  async function handleRestorePost() {
    if (!post.value) return
    try {
      await ElMessageBox.confirm('确定要恢复该帖子吗？', '确认恢复', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'info' })
      const res = await fetch(`/api/community/post/${post.value.id}/restore`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken } })
      const data = await res.json()
      if (data.code === 200) { ElMessage.success('帖子已恢复'); loadPost() }
      else { ElMessage.error(data.msg || '恢复失败') }
    } catch {}
  }

  async function handlePermanentDeletePost() {
    if (!post.value) return
    try {
      await ElMessageBox.confirm('永久删除后将无法恢复，确定要永久删除吗？', '永久删除', { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' })
      const res = await fetch(`/api/community/post/${post.value.id}/permanent`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken } })
      const data = await res.json()
      if (data.code === 200) { ElMessage.success('已永久删除'); router.push('/community') }
      else { ElMessage.error(data.msg || '删除失败') }
    } catch {}
  }

  const isPostOwner = computed(() => post.value?.userId === userStore.info?.userId)
  const isAdminUser = computed(() => {
    const roles = userStore.info?.roles || []
    return roles.includes('R_ADMIN') || roles.includes('R_SUPER')
  })

  onMounted(() => {
    loadPost()
    loadComments()
  })

  watch(postId, () => {
    if (postId.value) {
      loadPost()
      loadComments()
    }
  })
</script>

<template>
  <div class="pc-post-detail">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
    </div>
    <div v-if="loading" class="loading"><el-skeleton :rows="6" animated /></div>
    <div v-else-if="post" class="post-detail-layout">
      <div class="post-main">
        <div class="post-article">
          <h1>{{ post.title }}</h1>
          <div v-if="(post as any)?.isDeleted" class="deleted-banner">此帖子已被删除，仅作者可见。</div>
          <div v-if="post.status === 'scheduled'" class="status-banner status-scheduled">将于 {{ formatScheduledBanner((post as any).scheduledTime) }} 自动发布，仅自己可见</div>
          <div v-if="(post as any)?.isHidden" class="status-banner status-hidden">该帖已自动隐藏，仅作者和管理员可见<span v-if="(post as any).autoHideAt">（自动隐藏时间：{{ formatScheduledBanner((post as any).autoHideAt) }}）</span></div>
          <div v-if="(post as any)?.autoHideAt && !(post as any)?.isHidden && post.status !== 'scheduled'" class="status-banner status-auto-hide">将于 {{ formatScheduledBanner((post as any).autoHideAt) }} 自动隐藏</div>
          <div class="post-meta">
            <div class="author">
              <el-avatar :size="36" :src="$fixImgUrl(post.avatar || post.user?.avatar)" />
              <span class="author-name">{{ post.nickname || post.user?.nickname }}</span>
            </div>
            <div class="meta-actions">
              <span class="meta-time">{{
                fmtRelativeTime(post.createTime || post.createdAt)
              }}</span>
              <el-button text size="small" @click="showVersions = !showVersions"
                >历史版本</el-button
              >
              <template v-if="(post as any)?.isDeleted">
                <el-button v-if="isPostOwner" text size="small" type="success" @click="handleRestorePost">恢复</el-button>
                <el-button v-if="isPostOwner" text size="small" type="danger" @click="handlePermanentDeletePost">永久删除</el-button>
              </template>
              <template v-else>
                <el-button v-if="isPostOwner || isAdminUser" text size="small" type="danger" @click="handleDeletePost">删除</el-button>
              </template>
            </div>
          </div>
          <VersionDiff
            v-if="showVersions"
            :post-id="Number(postId)"
            @close="showVersions = false"
          />
          <div class="post-content" v-html="sanitizeContent(renderedContent)"></div>
          <div class="post-actions">
            <el-button
              :type="post.isLiked ? 'primary' : 'default'"
              @click="handleLike"
              :icon="post.isLiked ? 'StarFilled' : 'Star'"
            >
              赞 {{ fmtCount(post.likeCount || 0) }}
            </el-button>
            <span class="stat">{{ fmtCount(post.viewCount || 0) }} 浏览</span>
            <span class="stat">{{ fmtCount(post.commentCount || 0) }} 评论</span>
          </div>
        </div>

        <div class="comment-section">
          <h3>评论 ({{ comments.length }})</h3>
          <div class="comment-input">
            <el-input
              v-model="commentText"
              type="textarea"
              :rows="3"
              placeholder="写下你的评论..."
            />
            <div class="comment-submit">
              <el-button type="primary" :loading="submitting" @click="submitComment"
                >发表评论</el-button
              >
            </div>
          </div>
          <div class="comment-list">
            <div v-for="c in comments" :key="c.id" class="comment-item">
              <el-avatar :size="32" :src="$fixImgUrl(c.avatar || c.user?.avatar)" />
              <div class="comment-body">
                <div class="comment-user">{{ c.nickname || c.user?.nickname }}</div>
                <div class="comment-text" v-html="sanitizeContent(c.content)"></div>
                <div class="comment-time">{{ fmtRelativeTime(c.createTime || c.createdAt) }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
  .pc-post-detail {
    padding: 0 24px 24px;
    max-width: 900px;
  }
  .page-header {
    padding: 16px 0;
    margin-bottom: 20px;
  }
  .post-article {
    background: #fff;
    border-radius: 12px;
    padding: 28px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
  }
  .post-article h1 {
    margin: 0 0 16px;
    font-size: 22px;
  }
  .post-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px solid #f0f0f0;
  }
  .author {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .author-name {
    font-size: 14px;
    font-weight: 500;
  }
  .meta-time {
    font-size: 13px;
    color: #999;
  }
  .meta-actions {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .post-content {
    font-size: 15px;
    line-height: 1.8;
    color: #333;
    margin-bottom: 20px;
  }
  .post-actions {
    display: flex;
    align-items: center;
    gap: 16px;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
  }
  .stat {
    font-size: 13px;
    color: #999;
  }
  .deleted-banner {
    background: #FFF3E0;
    border: 1px solid #FFB74D;
    border-radius: 6px;
    padding: 8px 14px;
    font-size: 13px;
    color: #E65100;
    margin-bottom: 16px;
  }
  .status-banner {
    border-radius: 6px;
    padding: 8px 14px;
    font-size: 13px;
    margin-bottom: 16px;
  }
  .status-scheduled { background: #E0E7FF; border: 1px solid #A5B4FC; color: #3730A3; }
  .status-auto-hide { background: #F3E8FF; border: 1px solid #C4B5FD; color: #6B21A8; }
  .status-hidden { background: #F3F4F6; border: 1px solid #D1D5DB; color: #6B7280; }
  }
  .comment-section {
    margin-top: 24px;
  }
  .comment-section h3 {
    margin: 0 0 16px;
    font-size: 16px;
  }
  .comment-input {
    margin-bottom: 20px;
  }
  .comment-submit {
    display: flex;
    justify-content: flex-end;
    margin-top: 8px;
  }
  .comment-list {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .comment-item {
    display: flex;
    gap: 10px;
  }
  .comment-body {
    flex: 1;
  }
  .comment-user {
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 4px;
  }
  .comment-text {
    font-size: 14px;
    color: #333;
    line-height: 1.6;
  }
  .comment-time {
    font-size: 12px;
    color: #999;
    margin-top: 4px;
  }
  .loading {
    padding: 40px;
  }

  .post-content :deep(h1) {
    font-size: 22px;
    font-weight: 700;
    margin: 16px 0 8px;
  }
  .post-content :deep(h2) {
    font-size: 19px;
    font-weight: 700;
    margin: 14px 0 6px;
  }
  .post-content :deep(h3) {
    font-size: 17px;
    font-weight: 600;
    margin: 12px 0 4px;
  }
  .post-content :deep(blockquote) {
    border-left: 3px solid #508dff;
    padding-left: 12px;
    color: #666;
    margin: 8px 0;
  }
  .post-content :deep(pre) {
    background: #f5f5f5;
    padding: 12px;
    border-radius: 8px;
    overflow-x: auto;
    margin: 8px 0;
  }
  .post-content :deep(pre code) {
    background: none;
    padding: 0;
    color: #333;
  }
  .post-content :deep(img) {
    max-width: 100%;
    border-radius: 8px;
    margin: 8px 0;
  }
  .post-content :deep(ul),
  .post-content :deep(ol) {
    padding-left: 20px;
    margin: 8px 0;
  }
  .post-content :deep(a) {
    color: #508dff;
  }
</style>
