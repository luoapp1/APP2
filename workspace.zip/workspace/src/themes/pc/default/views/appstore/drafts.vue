<template>
  <div class="pc-drafts-page">
    <div class="page-header">
      <button class="back-btn" @click="$router.push('/appstore/mine')">&larr; 返回</button>
      <h2>草稿箱</h2>
    </div>

    <div class="drafts-list" v-if="drafts.length > 0">
      <div v-for="item in drafts" :key="item.key" class="draft-card">
        <div class="draft-info">
          <div class="draft-title">{{ item.title }}</div>
          <div class="draft-summary">{{ item.summary }}</div>
          <div class="draft-time">{{ item.timeStr }}</div>
        </div>
        <div class="draft-actions">
          <el-button type="primary" size="small" @click="continueEdit(item)">继续编辑</el-button>
          <el-button type="danger" size="small" plain @click="deleteDraft(item.key)">删除</el-button>
        </div>
      </div>
    </div>

    <div class="drafts-empty" v-else>
      <el-empty description="暂无草稿" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const router = useRouter()

interface DraftItem {
  key: string
  title: string
  summary: string
  time: number
  timeStr: string
  path: string
}

const drafts = ref<DraftItem[]>([])

function decodeContent(encoded: string): string {
  try { return decodeURIComponent(escape(atob(encoded))) } catch { return atob(encoded) }
}

function extractText(html: string): string {
  try {
    const div = document.createElement('div')
    div.innerHTML = html
    return div.textContent || div.innerText || ''
  } catch { return html.replace(/<[^>]*>/g, '').substring(0, 100) }
}

function pathLabel(pathType: string): string {
  if (pathType.includes('post_edit') || pathType.includes('p_edit')) return '编辑帖子'
  if (pathType.includes('post_create') || pathType.includes('p_create')) return '新建帖子'
  return '帖子草稿'
}

function loadDrafts() {
  const items: DraftItem[] = []
  try {
    const keys = Object.keys(localStorage).filter((k) => k.startsWith('draft_'))
    for (const key of keys) {
      try {
        const raw = localStorage.getItem(key)
        if (!raw) continue
        const data = JSON.parse(raw)
        if (!data.time || !data.content) continue
        const html = decodeContent(data.content)
        const text = extractText(html)
        const pathType = key.replace('draft_', '')
        items.push({
          key,
          title: pathLabel(pathType),
          summary: text.substring(0, 100) || '(空内容)',
          time: data.time,
          timeStr: formatTime(data.time),
          path: hashToPath(key)
        })
      } catch {}
    }
  } catch {}
  items.sort((a, b) => b.time - a.time)
  drafts.value = items
}

function hashToPath(key: string): string {
  const hash = key.replace('draft_', '')
  if (hash.includes('post_edit')) return '/community/post-edit'
  if (hash.includes('p_edit')) return '/p/edit/0'
  if (hash.includes('p_create') || hash.includes('post_create')) return '/p/create'
  return '/community/mycollections'
}

function formatTime(ts: number): string {
  const diff = Date.now() - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  const d = new Date(ts)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

function continueEdit(item: DraftItem) { router.push(item.path) }

function deleteDraft(key: string) {
  try {
    localStorage.removeItem(key)
    drafts.value = drafts.value.filter((d) => d.key !== key)
    ElMessage.success('已删除')
  } catch {}
}

onMounted(loadDrafts)
</script>

<style scoped>
.pc-drafts-page { padding: 0 24px 24px; max-width: 800px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.back-btn { background: none; border: none; color: var(--el-color-primary); cursor: pointer; font-size: 14px; }
.drafts-list { display: flex; flex-direction: column; gap: 12px; }
.draft-card { display: flex; align-items: center; justify-content: space-between; background: #fff; border-radius: 10px; padding: 16px 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.draft-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.draft-title { font-size: 15px; font-weight: 600; color: #1a1a1a; }
.draft-summary { font-size: 13px; color: #999; }
.draft-time { font-size: 12px; color: #C0C4CC; }
.draft-actions { display: flex; gap: 8px; flex-shrink: 0; }
.drafts-empty { padding: 80px 0; }
</style>
