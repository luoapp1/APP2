<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchMyInvite, fetchInviteConfig, fetchInviteGenerateConfig, fetchGenerateUserInvite } from '@/api/invite'
import { useUserStore } from '@/store/modules/user'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const myCodes = ref<any[]>([])
const config = ref<any>(null)
const loading = ref(false)

async function load() {
  try {
    const [codesRes, cfgRes] = await Promise.all([fetchMyInvite(), fetchInviteConfig()])
    myCodes.value = codesRes.data?.list || codesRes.list || []
    config.value = cfgRes.data || cfgRes || {}
  } catch (e) {}
}

async function generateCode() {
  try {
    const res = await fetchInviteGenerateConfig()
    const genCfg = res.data || res
    await ElMessageBox.confirm('确定生成新的邀请码？', '确认')
    const gRes = await fetchGenerateUserInvite(genCfg)
    ElMessage.success('邀请码生成成功')
    await load()
  } catch (e: any) { if (e !== 'cancel') ElMessage.error(e.message || '生成失败') }
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>邀请福利</h2><el-button type="primary" plain size="small" @click="router.push('/operation/invite-ranking')">查看排行榜</el-button></div>
    <div class="content-card"><div class="toolbar"><el-button type="primary" @click="generateCode">生成邀请码</el-button></div>
      <el-table :data="myCodes" v-if="myCodes.length"><el-table-column prop="code" label="邀请码" /><el-table-column prop="status" label="状态"><template #default="{ row }"><el-tag :type="row.status === 'active' ? 'success' : 'info'">{{ row.status }}</el-tag></template></el-table-column><el-table-column prop="use_count" label="使用次数" /><el-table-column prop="max_uses" label="最大次数" /><el-table-column prop="create_time" label="创建时间" /></el-table>
      <div v-else class="empty">暂无邀请码，点击上方按钮生成</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 900px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .toolbar { margin-bottom: 16px; } .empty { text-align: center; padding: 60px 0; color: #999; font-size: 14px; }</style>
