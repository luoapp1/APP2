<template>
  <div class="pc-page">
    <div class="page-header">
      <button class="back-btn" @click="$router.push('/appstore/mine')">&larr; 返回</button>
      <h2>合集</h2>
      <div class="tab-bar">
        <button :class="['tab-btn', { active: activeTab === 'mine' }]" @click="switchTab('mine')">帖子合集</button>
        <button :class="['tab-btn', { active: activeTab === 'paid' }]" @click="switchTab('paid')">已购合集</button>
      </div>
      <el-button v-if="activeTab === 'mine'" type="primary" size="small" @click="goCreate">新建合集</el-button>
    </div>

    <!-- 帖子合集 -->
    <template v-if="activeTab === 'mine'">
      <div class="col-grid" v-if="collections.length > 0">
        <div v-for="c in collections" :key="c.id" class="col-card" @click="openCollection(c)">
          <div class="col-cover">
            <img v-if="c.cover_image" :src="c.cover_image" />
            <div v-else class="col-cover-ph"></div>
            <div class="col-status">{{ colStatusLabel(c.status) }}</div>
          </div>
          <div class="col-body">
            <div class="col-title">{{ c.title }}</div>
            <div class="col-desc" v-if="c.description">{{ c.description }}</div>
            <div class="col-stats">
              <span>{{ c.post_count }}篇</span>
              <span>{{ c.view_count || 0 }}浏览</span>
              <span v-if="c.subscribe_count > 0">{{ c.subscribe_count }}人已购</span>
            </div>
            <div class="col-footer">
              <div class="col-price">
                <template v-if="c.is_paid">
                  <span v-if="c.price_balance > 0" class="price-num">{{ c.price_balance }}余额</span>
                  <span v-if="c.price_points > 0" class="price-num">{{ c.price_points }}积分</span>
                </template>
                <span v-else class="price-free">免费合集</span>
              </div>
              <div class="col-actions">
                <el-button size="small" @click.stop="goEdit(c)">编辑</el-button>
                <el-button v-if="c.status === 'draft'" size="small" type="danger" plain @click.stop="handleDelete(c)">删除</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-empty" v-else-if="!colLoading">
        <el-empty description="还没有创建合集">
          <el-button type="primary" @click="goCreate">创建第一个合集</el-button>
        </el-empty>
      </div>
    </template>

    <!-- 已购合集 -->
    <template v-if="activeTab === 'paid'">
      <div class="col-grid" v-if="paidCollections.length > 0">
        <div v-for="c in paidCollections" :key="c.id" class="col-card" @click="openCollection(c)">
          <div class="col-cover">
            <img v-if="c.cover_image" :src="c.cover_image" />
            <div v-else class="col-cover-ph"></div>
          </div>
          <div class="col-body">
            <div class="col-title">{{ c.title }}</div>
            <div class="col-desc" v-if="c.description">{{ c.description }}</div>
            <div class="col-stats">
              <span>{{ c.post_count }}篇</span>
              <span>{{ c.view_count || 0 }}浏览</span>
              <span v-if="c.subscribe_count > 0">{{ c.subscribe_count }}人已购</span>
            </div>
            <div class="col-footer">
              <span class="bought-tag">已购买</span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-empty" v-else-if="!paidLoading">
        <el-empty description="还没有购买任何合集" />
      </div>
    </template>

    <div v-if="(activeTab === 'mine' && colLoading) || (activeTab === 'paid' && paidLoading)" style="text-align:center;padding:40px;">
      <el-icon class="is-loading"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg></el-icon>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { fetchMyCollections, fetchPaidCollections, deleteCollection } from '@/api/community'

const router = useRouter()
const activeTab = ref<'mine' | 'paid'>('mine')
const collections = ref<any[]>([])
const colLoading = ref(true)
const paidCollections = ref<any[]>([])
const paidLoading = ref(true)

function colStatusLabel(s: string) {
  const map: Record<string, string> = { draft: '草稿', serializing: '连载中', finished: '已完结' }
  return map[s] || s
}
function openCollection(c: any) { router.push(`/community/collection/${c.id}`) }
function goCreate() { router.push('/community/collection/create') }
function goEdit(c: any) { router.push(`/community/collection/create?id=${c.id}`) }

async function handleDelete(c: any) {
  if (!confirm(`确定删除合集「${c.title}」？删除后不可恢复。`)) return
  try {
    await deleteCollection(c.id)
    collections.value = collections.value.filter(x => x.id !== c.id)
    ElMessage.success('已删除')
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

async function loadCollections() {
  colLoading.value = true
  try {
    const data: any = await fetchMyCollections()
    collections.value = data?.list || []
  } catch { collections.value = [] }
  colLoading.value = false
}

async function loadPaidCollections() {
  paidLoading.value = true
  try {
    const data: any = await fetchPaidCollections()
    paidCollections.value = data?.list || []
  } catch { paidCollections.value = [] }
  paidLoading.value = false
}

function switchTab(key: 'mine' | 'paid') {
  if (activeTab.value === key) return
  activeTab.value = key
  if (key === 'paid' && paidCollections.value.length === 0) loadPaidCollections()
}

onMounted(() => { loadCollections() })
</script>

<style scoped>
.pc-page { padding: 0 24px 24px; max-width: 1000px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; flex-wrap: wrap; }
.page-header h2 { margin: 0; font-size: 20px; }
.back-btn { background: none; border: none; color: var(--el-color-primary); cursor: pointer; font-size: 14px; }
.tab-bar { display: flex; background: #f2f3f6; border-radius: 8px; padding: 3px; margin-left: auto; gap: 0; }
.tab-btn {
  padding: 5px 16px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  color: #999;
  background: transparent;
  cursor: pointer;
  transition: all .2s;
}
.tab-btn.active { color: #1a1a2e; background: #fff; font-weight: 600; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
.col-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
.col-card { background: #fff; border-radius: 12px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.06); transition: box-shadow .2s; }
.col-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.1); }
.col-cover { position: relative; height: 140px; overflow: hidden; }
.col-cover img { width: 100%; height: 100%; object-fit: cover; }
.col-cover-ph { width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); }
.col-status { position: absolute; top: 10px; right: 10px; font-size: 12px; padding: 3px 10px; border-radius: 10px; color: #fff; background: rgba(255,255,255,.25); backdrop-filter: blur(8px); }
.col-body { padding: 14px; }
.col-title { font-size: 15px; font-weight: 600; color: #1a1a2e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.col-desc { font-size: 13px; color: #999; margin-top: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.col-stats { display: flex; gap: 14px; margin-top: 10px; font-size: 12px; color: #b0b0b0; }
.col-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; padding-top: 12px; border-top: 1px solid #f5f5f5; }
.col-price { display: flex; gap: 6px; align-items: center; }
.price-num { font-size: 16px; font-weight: 700; color: #f56c6c; }
.price-free { font-size: 14px; font-weight: 600; color: #67c23a; }
.bought-tag { font-size: 14px; font-weight: 600; color: #67c23a; }
.col-actions { display: flex; gap: 6px; }
.col-empty { padding: 60px 0; }
</style>
