<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchExpLevelList } from '@/api/operation'

defineOptions({ name: 'AppStoreExperience' })

const router = useRouter()
const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)
const levels = ref<any[]>([])
const currentLevel = ref<any>({})
const todayExp = ref(0)
const nextExp = ref(0)

const userExp = computed(() => userStore.info?.experience || 0)
const expRemain = computed(() => Math.max(0, nextExp.value - userExp.value))
const expPercent = computed(() => {
  if (!nextExp.value) return 0
  const prevExp = currentLevel.value.expRequired || 0
  const range = nextExp.value - prevExp
  if (range <= 0) return 100
  return Math.min(100, Math.round(((userExp.value - prevExp) / range) * 100))
})

async function loadData() {
  try {
    const data: any = await fetchExpLevelList()
    const list = data?.records || data || []
    if (list.length > 0) {
      const sorted = [...list].sort((a: any, b: any) => (a.level || 0) - (b.level || 0)).map((lv: any) => {
        if (lv.icon && !(lv.icon.startsWith('http') || lv.icon.startsWith('/') || lv.icon.startsWith('data:'))) {
          return { ...lv, icon: '' }
        }
        return lv
      })
      levels.value = sorted
      const exp = userExp.value
      let cur = sorted[0]
      let nxt: any = null
      for (const l of sorted) {
        const req = l.expRequired || l.exp_required || 0
        if (req <= exp) cur = l
        if (req > exp && !nxt) nxt = l
      }
      currentLevel.value = cur
      if (cur.icon && !(cur.icon.startsWith('http') || cur.icon.startsWith('/') || cur.icon.startsWith('data:'))) {
        currentLevel.value = { ...cur, icon: '' }
      }
      nextExp.value = nxt ? (nxt.expRequired || nxt.exp_required || 0) : (cur.expRequired || cur.exp_required || 0) + 1000
    }
  } catch (_e) { void _e }
}

onMounted(() => { if (isLogin.value) loadData() })
</script>

<template>
  <div class="exp-page">
    <div class="page-header"><el-button text @click="router.back()">返回</el-button><h2>经验详情</h2></div>

    <div v-if="!isLogin" style="text-align:center;padding:80px 0;color:#999;">请先登录</div>

    <div v-else class="exp-content">
      <div class="exp-card">
        <div class="exp-card-header">
          <img v-if="currentLevel.icon" :src="$fixImgUrl(currentLevel.icon)" class="level-img"  loading="lazy" />
          <div>
            <div class="level-name">{{ currentLevel.name || 'Lv.1' }}</div>
            <div class="level-nums">{{ userExp }}/{{ nextExp }}</div>
          </div>
        </div>
        <div class="exp-progress-wrap">
          <div class="exp-progress-bar"><div class="exp-progress-fill" :style="{ width: expPercent + '%' }" /></div>
          <div class="exp-progress-text">升级还需{{ expRemain }}经验</div>
        </div>
      </div>

      <div class="exp-panel">
        <div class="panel-title">成长体系</div>
        <div class="growth-bar">
          <div v-for="(lv, idx) in levels" :key="lv.level" :class="['growth-item', { active: lv.level === currentLevel.level, done: lv.level < currentLevel.level }]">
            <img v-if="lv.icon" :src="$fixImgUrl(lv.icon)" class="growth-icon"  loading="lazy" />
            <div class="growth-name">{{ lv.name || 'Lv.'+lv.level }}</div>
            <div class="growth-exp">{{ lv.expRequired || 0 }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.exp-page { padding: 0 24px 24px; max-width: 800px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.exp-content { display: flex; flex-direction: column; gap: 20px; }
.exp-card { background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 16px; padding: 28px; color: #fff; }
.exp-card-header { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; }
.level-img { width: 48px; height: 48px; object-fit: contain; }
.level-name { font-size: 24px; font-weight: 700; }
.level-nums { font-size: 14px; opacity: .85; margin-top: 4px; }
.exp-progress-wrap { margin-top: 8px; }
.exp-progress-bar { background: rgba(255,255,255,.2); border-radius: 999px; height: 10px; overflow: hidden; margin-bottom: 8px; }
.exp-progress-fill { height: 100%; background: #fff; border-radius: 999px; transition: width .3s; }
.exp-progress-text { font-size: 13px; opacity: .9; }
.exp-panel { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.panel-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 16px; }
.growth-bar { display: flex; gap: 0; overflow-x: auto; }
.growth-item { flex: 1; text-align: center; opacity: .4; min-width: 60px; }
.growth-item.done { opacity: .75; }
.growth-item.active { opacity: 1; }
.growth-icon { width: 32px; height: 32px; object-fit: contain; }
.growth-item.active .growth-icon { width: 40px; height: 40px; }
.growth-name { font-size: 11px; color: #333; margin-top: 4px; font-weight: 500; }
.growth-item.active .growth-name { font-weight: 700; }
.growth-exp { font-size: 10px; color: #999; margin-top: 2px; }
</style>
