<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchExpLevelList } from '@/api/mine'
import { formatNum } from '@/utils'
import { UserFilled, Wallet, Document, Calendar, Share, Ticket, Trophy, Upload, Notebook } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()

const expLevels = ref<any[]>([])
const currentLevelIcon = ref('')
const expCurrent = ref(0)
const expMax = ref(100)

const isLogin = computed(() => userStore.isLogin)
const userInfo = computed(() => userStore.info)
const isAdmin = computed(() => {
  const roles = userStore.info?.roles || []
  return roles.includes('R_ADMIN') || roles.includes('R_SUPER')
})

async function loadExpLevels() {
  try {
    const res = await fetchExpLevelList()
    const list = res.data || res || []
    expLevels.value = list
    const exp = userInfo.value?.experience || 0
    const levels = list.sort((a: any, b: any) => a.experience - b.experience)
    for (let i = levels.length - 1; i >= 0; i--) {
      if (exp >= levels[i].experience) {
        expCurrent.value = exp - levels[i].experience
        expMax.value = (levels[i + 1]?.experience || levels[i].experience + 1000) - levels[i].experience
        const icon = levels[i].icon
        currentLevelIcon.value = (icon && (icon.startsWith('http') || icon.startsWith('/') || icon.startsWith('data:'))) ? icon : ''
        break
      }
    }
  } catch (e) { /* ignore */ }
}

function goLogin() { router.push('/appstore/browse/login') }
function goProfile() { router.push(`/u/${userInfo.value?.userId}`) }
function goPath(path: string) { router.push(path) }

onMounted(() => { if (isLogin.value) loadExpLevels() })
</script>

<template>
  <div class="pc-mine-page">
    <div class="page-header"><h2>个人中心</h2></div>

    <div v-if="!isLogin" class="not-login">
      <div class="login-prompt">
        <el-icon :size="48"><UserFilled /></el-icon>
        <p>登录后查看更多内容</p>
        <el-button type="primary" @click="goLogin">立即登录</el-button>
      </div>
    </div>

    <div v-else class="mine-layout">
      <div class="mine-sidebar">
        <div class="user-card" @click="goProfile">
          <el-avatar :size="64" :src="$fixImgUrl(userInfo?.avatar)" />
          <h3>{{ userInfo?.nickname || userInfo?.username }}</h3>
          <div class="user-level">
            <img v-if="currentLevelIcon" :src="currentLevelIcon" class="level-icon" />
            {{ userInfo?.levelName || '普通用户' }}
          </div>
        </div>

        <div class="balance-section">
          <div class="balance-item">
            <span class="label">余额</span>
            <span class="value">{{ formatNum(userInfo?.balance || 0) }}</span>
          </div>
          <div class="balance-item">
            <span class="label">积分</span>
            <span class="value">{{ formatNum(userInfo?.points || 0) }}</span>
          </div>
        </div>

        <div class="exp-bar" v-if="expMax > 0">
          <div class="exp-label">经验值 {{ expCurrent }}/{{ expMax }}</div>
          <el-progress :percentage="Math.min(100, Math.round((expCurrent / expMax) * 100))" :stroke-width="8" />
        </div>

        <div class="menu-section">
          <div class="menu-item" @click="goPath('/appstore/assets')">
            <el-icon><Wallet /></el-icon> 我的资产
          </div>
          <div class="menu-item" @click="goPath('/appstore/records')">
            <el-icon><Document /></el-icon> 数据明细
          </div>
          <div class="menu-item" @click="goPath('/appstore/checkin')">
            <el-icon><Calendar /></el-icon> 每日签到
          </div>
          <div class="menu-item" @click="goPath('/appstore/invite')">
            <el-icon><Share /></el-icon> 邀请福利
          </div>
          <div class="menu-item" @click="goPath('/appstore/coupon')">
            <el-icon><Ticket /></el-icon> 优惠券中心
          </div>
          <div class="menu-item" @click="goPath('/appstore/ranking')">
            <el-icon><Trophy /></el-icon> 排行榜
          </div>
          <div class="menu-item" @click="goPath('/appstore/submissions')">
            <el-icon><Upload /></el-icon> 应用投稿
          </div>
          <div class="menu-item" @click="goPath('/appstore/drafts')">
            <el-icon><Notebook /></el-icon> 草稿箱
          </div>
        </div>
      </div>

      <div class="mine-content">
        <div class="welcome-card">
          <h3>欢迎回来，{{ userInfo?.nickname || userInfo?.username }}</h3>
          <p>在这里管理您的应用、资产和个人信息</p>
        </div>

        <div class="quick-stats">
          <div class="stat-card">
            <div class="stat-value">{{ formatNum(userInfo?.fansCount || 0) }}</div>
            <div class="stat-label">粉丝</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ formatNum(userInfo?.followCount || 0) }}</div>
            <div class="stat-label">关注</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ formatNum(userInfo?.balance || 0) }}</div>
            <div class="stat-label">余额</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ formatNum(userInfo?.points || 0) }}</div>
            <div class="stat-label">积分</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-mine-page { padding: 0 24px 24px; max-width: 1200px; }
.page-header { padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.not-login { display: flex; justify-content: center; padding: 80px 0; }
.login-prompt { text-align: center; color: #999; }
.login-prompt p { margin: 16px 0; font-size: 15px; }
.mine-layout { display: flex; gap: 28px; }
.mine-sidebar { width: 260px; flex-shrink: 0; }
.mine-content { flex: 1; }
.user-card { background: #fff; border-radius: 12px; padding: 28px 20px; text-align: center; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; }
.user-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.user-card h3 { margin: 12px 0 4px; font-size: 16px; }
.user-level { color: #999; font-size: 13px; display: flex; align-items: center; justify-content: center; gap: 4px; }
.level-icon { width: 20px; height: 20px; object-fit: contain; }
.balance-section { display: flex; gap: 8px; margin-top: 16px; }
.balance-item { flex: 1; background: #fff; border-radius: 10px; padding: 14px 12px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.balance-item .label { display: block; font-size: 12px; color: #999; margin-bottom: 4px; }
.balance-item .value { font-size: 18px; font-weight: 700; color: var(--el-color-primary); }
.exp-bar { margin-top: 14px; padding: 0 4px; }
.exp-label { font-size: 12px; color: #888; margin-bottom: 6px; }
.menu-section { margin-top: 16px; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.menu-item { display: flex; align-items: center; gap: 10px; padding: 13px 18px; cursor: pointer; font-size: 14px; color: #333; transition: background .2s; }
.menu-item:hover { background: #f5f7fa; }
.menu-item + .menu-item { border-top: 1px solid #f0f0f0; }
.welcome-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; padding: 28px; color: #fff; margin-bottom: 20px; }
.welcome-card h3 { margin: 0 0 8px; font-size: 18px; }
.welcome-card p { margin: 0; opacity: .85; font-size: 14px; }
.quick-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.stat-card { background: #fff; border-radius: 10px; padding: 20px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.stat-value { font-size: 24px; font-weight: 700; color: #333; margin-bottom: 4px; }
.stat-label { font-size: 13px; color: #999; }
</style>
