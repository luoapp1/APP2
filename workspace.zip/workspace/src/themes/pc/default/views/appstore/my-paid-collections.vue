<template>
  <div class="pc-page">
    <div class="page-header">
      <button class="back-btn" @click="$router.push('/appstore/mine')">&larr; 返回</button>
      <h2>已购合集</h2>
    </div>

    <div class="col-grid" v-if="paidCollections.length > 0">
      <div v-for="c in paidCollections" :key="c.id" class="col-card" @click="openCollection(c)">
        <div class="col-cover">
          <img v-if="c.cover_image" :src="c.cover_image" />
          <div v-else class="col-cover-ph"></div>
        </div>
        <div class="col-body">
          <div class="col-title">{{ c.title }}</div>
          <div class="col-desc" v-if="c.description">{{ c.description }}</div>
          <div class="col-stats">
            <span>{{ c.post_count }}篇</span>
            <span>{{ c.view_count || 0 }}浏览</span>
            <span v-if="c.subscribe_count > 0">{{ c.subscribe_count }}人已购</span>
          </div>
          <div class="col-footer">
            <span class="bought-tag">已购买</span>
          </div>
        </div>
      </div>
    </div>

    <div class="col-empty" v-else-if="!loading">
      <el-empty description="还没有购买任何合集" />
    </div>

    <div v-if="loading" style="text-align:center;padding:40px;">
      <el-icon class="is-loading"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg></el-icon>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchPaidCollections } from '@/api/community'

const router = useRouter()
const paidCollections = ref<any[]>([])
const loading = ref(true)

function openCollection(c: any) { router.push(`/community/collection/${c.id}`) }

async function loadPaidCollections() {
  loading.value = true
  try {
    const data: any = await fetchPaidCollections()
    paidCollections.value = data?.list || []
  } catch { paidCollections.value = [] }
  loading.value = false
}

onMounted(() => { loadPaidCollections() })
</script>

<style scoped>
.pc-page { padding: 0 24px 24px; max-width: 1000px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; flex: 1; }
.back-btn { background: none; border: none; color: var(--el-color-primary); cursor: pointer; font-size: 14px; }
.col-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
.col-card { background: #fff; border-radius: 12px; overflow: hidden; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.06); transition: box-shadow .2s; }
.col-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.1); }
.col-cover { position: relative; height: 140px; overflow: hidden; }
.col-cover img { width: 100%; height: 100%; object-fit: cover; }
.col-cover-ph { width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); }
.col-body { padding: 14px; }
.col-title { font-size: 15px; font-weight: 600; color: #1a1a2e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.col-desc { font-size: 13px; color: #999; margin-top: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.col-stats { display: flex; gap: 14px; margin-top: 10px; font-size: 12px; color: #b0b0b0; }
.col-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; padding-top: 12px; border-top: 1px solid #f5f5f5; }
.bought-tag { font-size: 14px; font-weight: 600; color: #67c23a; }
.col-empty { padding: 60px 0; }
</style>
