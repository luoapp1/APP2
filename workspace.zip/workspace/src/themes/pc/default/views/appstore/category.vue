<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchAppList, fetchCategoryList } from '@/api/appstore'
import { toNum, fmtCount, iconColor } from '@/utils'

const router = useRouter()
const activeTab = ref('category')
const activeCategory = ref('all')
const appList = ref<any[]>([])
const categories = ref<any[]>([])
const loading = ref(true)
const priceFilter = ref('all')
const searchKeyword = ref('')
const showSearch = ref(false)

async function loadData() {
  loading.value = true
  try {
    const [appRes, catRes] = await Promise.all([fetchAppList({}), fetchCategoryList()])
    appList.value = appRes.data?.list || appRes.list || []
    categories.value = catRes.data || catRes || []
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

const filteredApps = computed(() => {
  let list = appList.value
  if (activeCategory.value !== 'all') {
    list = list.filter((a: any) => a.categoryId === activeCategory.value || a.category === activeCategory.value)
  }
  if (priceFilter.value === 'free') list = list.filter((a: any) => !a.price || a.price <= 0)
  if (priceFilter.value === 'paid') list = list.filter((a: any) => a.price > 0)
  if (searchKeyword.value) {
    const kw = searchKeyword.value.toLowerCase()
    list = list.filter((a: any) => a.name?.toLowerCase().includes(kw) || a.description?.toLowerCase().includes(kw))
  }
  return list
})

const rankedApps = computed(() => {
  return [...appList.value].sort((a: any, b: any) => (b.downloads || 0) - (a.downloads || 0))
})

function goDetail(id: string) { router.push(`/a/${id}`) }

onMounted(loadData)
</script>

<template>
  <div class="pc-category-page">
    <div class="page-header">
      <h2>应用分类</h2>
      <el-input v-model="searchKeyword" placeholder="搜索应用..." clearable class="search-input">
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
    </div>

    <el-tabs v-model="activeTab" class="main-tabs">
      <el-tab-pane label="分类浏览" name="category">
        <div class="category-layout">
          <div class="cat-sidebar">
            <div v-for="cat in [{ id: 'all', name: '全部应用' }, ...categories]" :key="cat.id"
              :class="['cat-item', { active: activeCategory === cat.id }]"
              @click="activeCategory = cat.id">
              {{ cat.name }}
            </div>
          </div>
          <div class="cat-content">
            <div class="filter-bar">
              <el-radio-group v-model="priceFilter" size="small">
                <el-radio-button value="all">全部</el-radio-button>
                <el-radio-button value="free">免费</el-radio-button>
                <el-radio-button value="paid">付费</el-radio-button>
              </el-radio-group>
              <span class="count">{{ filteredApps.length }} 个应用</span>
            </div>
            <div v-if="loading" class="loading"><el-skeleton :rows="4" animated /></div>
            <div v-else class="app-grid">
              <div v-for="app in filteredApps" :key="app.id" class="app-card" @click="goDetail(app.id)">
                <img :src="$fixImgUrl(app.icon)" class="app-icon"  loading="lazy" />
                <div class="app-info">
                  <div class="app-name">{{ app.name }}</div>
                  <div class="app-desc">{{ (app.description || '').slice(0, 60) }}</div>
                  <div class="app-stats">
                    <span>{{ toNum(app.size) }} MB</span>
                    <span>{{ fmtCount(app.downloads) }} 下载</span>
                    <span v-if="app.price > 0" class="price">¥{{ app.price }}</span>
                    <span v-else class="free">免费</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-tab-pane>

      <el-tab-pane label="排行榜" name="rank">
        <div v-if="loading" class="loading"><el-skeleton :rows="4" animated /></div>
        <div v-else class="rank-list">
          <div v-for="(app, idx) in rankedApps" :key="app.id" class="rank-item" @click="goDetail(app.id)">
            <span class="rank-num" :class="{ top: idx < 3 }">{{ idx + 1 }}</span>
            <img :src="$fixImgUrl(app.icon)" class="rank-icon"  loading="lazy" />
            <div class="rank-info">
              <div class="app-name">{{ app.name }}</div>
              <div class="app-stats">{{ fmtCount(app.downloads) }} 下载</div>
            </div>
            <el-button size="small" type="primary" plain>查看</el-button>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<style scoped>
.pc-category-page { padding: 0 24px 24px; max-width: 1200px; }
.page-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; margin-bottom: 16px; }
.page-header h2 { margin: 0; font-size: 20px; }
.search-input { width: 300px; }
.main-tabs { margin-top: 8px; }
.category-layout { display: flex; gap: 24px; }
.cat-sidebar { width: 160px; flex-shrink: 0; background: #fff; border-radius: 8px; padding: 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.cat-item { padding: 10px 16px; cursor: pointer; font-size: 14px; color: #555; transition: all .2s; }
.cat-item:hover { background: #f5f7fa; }
.cat-item.active { color: var(--el-color-primary); background: #ecf5ff; font-weight: 600; }
.cat-content { flex: 1; min-width: 0; }
.filter-bar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.count { color: #999; font-size: 13px; }
.app-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 12px; }
.app-card { display: flex; gap: 14px; padding: 16px; background: #fff; border-radius: 10px; cursor: pointer; transition: box-shadow .2s; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.app-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.app-icon { width: 56px; height: 56px; border-radius: 12px; flex-shrink: 0; }
.app-info { flex: 1; min-width: 0; }
.app-name { font-size: 15px; font-weight: 600; margin-bottom: 4px; }
.app-desc { font-size: 12px; color: #999; margin-bottom: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.app-stats { display: flex; gap: 12px; font-size: 12px; color: #888; }
.price { color: #f56c6c; font-weight: 600; }
.free { color: #67c23a; }
.rank-list { display: flex; flex-direction: column; gap: 8px; }
.rank-item { display: flex; align-items: center; gap: 14px; padding: 14px 20px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; }
.rank-item:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.rank-num { width: 28px; text-align: center; font-size: 15px; font-weight: 600; color: #999; }
.rank-num.top { color: var(--el-color-primary); font-size: 18px; }
.rank-icon { width: 44px; height: 44px; border-radius: 10px; }
.rank-info { flex: 1; }
.loading { padding: 20px; }
</style>
