<template>
  <div class="pc-blocklist-page">
    <div class="page-header">
      <button class="back-btn" @click="$router.push('/appstore/settings')">&larr; 返回设置</button>
      <h2>黑名单</h2>
    </div>

    <div class="blocklist-list" v-if="list.length > 0">
      <div v-for="item in list" :key="item.id" class="block-card">
        <div class="block-user" @click="goProfile(item.blockedId)">
          <el-avatar :size="48" :src="$fixImgUrl(item.blockedAvatar)" />
          <div class="block-info">
            <div class="block-name">{{ item.blockedNickname || item.blockedUsername }}</div>
            <div class="block-time">拉黑于 {{ formatTime(item.createTime) }}</div>
          </div>
        </div>
        <el-button type="danger" size="small" plain @click="unblock(item)">解除拉黑</el-button>
      </div>
    </div>

    <div class="blocklist-empty" v-else-if="!loading">
      <el-empty description="暂无拉黑用户" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const list = ref<any[]>([])
const loading = ref(false)

async function loadList() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/user/blocked' })
    list.value = res.data?.list || res.list || []
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

async function unblock(item: any) {
  try {
    await request.delete({ url: `/api/user/${item.blockedId}/block` })
    list.value = list.value.filter((u: any) => u.blockedId !== item.blockedId)
    ElMessage.success('已解除拉黑')
  } catch (e) {
    ElMessage.error('操作失败')
  }
}

function goProfile(userId: number) { router.push(`/u/${userId}`) }

function formatTime(ts: string): string {
  if (!ts) return ''
  const d = new Date(ts)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

onMounted(loadList)
</script>

<style scoped>
.pc-blocklist-page { padding: 0 24px 24px; max-width: 800px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.back-btn { background: none; border: none; color: var(--el-color-primary); cursor: pointer; font-size: 14px; }
.blocklist-list { display: flex; flex-direction: column; gap: 10px; }
.block-card { display: flex; align-items: center; justify-content: space-between; background: #fff; border-radius: 10px; padding: 14px 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.block-user { display: flex; align-items: center; gap: 14px; cursor: pointer; flex: 1; }
.block-info { display: flex; flex-direction: column; gap: 2px; }
.block-name { font-size: 15px; font-weight: 500; color: #1a1a1a; }
.block-time { font-size: 12px; color: #999; }
.blocklist-empty { padding: 80px 0; }
</style>
