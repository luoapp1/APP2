<script setup lang="ts">
import { ref, computed, onMounted, reactive } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { createCommunityPost, uploadCommunityImage, deleteCommunityImage, fetchTopics } from '@/api/community'
import { fetchAppList } from '@/api/appstore'
import { ElMessage } from 'element-plus'
import TipTapEditor from '@/components/editor/TipTapEditor.vue'
import { extractImagesFromDoc, isDocEmpty } from '@/utils/tiptap'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const editorRef = ref<any>(null)
const editorContent = ref<any>({ type: 'doc', content: [{ type: 'paragraph' }] })
const imgInput = ref<HTMLInputElement>()
const uploadedImageUrls = ref<string[]>([])

const form = ref({ title: '', contentPermission: 'public', contentPrice: 0, contentPriceType: 'balance' })
const loading = ref(false)
const showTopicPicker = ref(false)
const topicSearchQuery = ref('')
const availableTopics = ref<any[]>([])
const selectedTopicIds = ref<number[]>([])
const selectedTopicNames = ref<Record<number, string>>({})
const showPaywallModal = ref(false)
const showAppSelector = ref(false)
const appList = ref<any[]>([])
const filteredAppList = ref<any[]>([])
const appSearchQuery = ref('')
const paywallPrice = ref(0)
const paywallPriceType = ref('balance')
const sectionId = ref(Number(route.params.sectionId) || 0)

const showVoteModal = ref(false)
const showGoodsModal = ref(false)
const showAudioModal = ref(false)
const showFileModal = ref(false)
const showNoticeModal = ref(false)
const showUpdateLogModal = ref(false)
const showPasswordModal = ref(false)
const showGalleryModal = ref(false)
const showOriginalModal = ref(false)
const showSourceQuoteModal = ref(false)
const showFollowUnlockModal = ref(false)
const showCommentUnlockModal = ref(false)

const voteForm = reactive({ question: '', options: ['', ''], maxSelect: 1 })
const goodsForm = reactive({ title: '', price: '', image: '', link: '' })
const audioForm = reactive({ src: '', title: '' })
const fileForm = reactive({ name: '', size: '', url: '' })
const noticeForm = reactive({ type: 'info', content: '' })
const updateLogForm = reactive({ version: '', date: '', changes: '' })
const passwordForm = reactive({ password: '', hint: '', content: '' })
const galleryForm = reactive({ images: ['', ''] })
const originalForm = reactive({ author: '', license: 'CC BY 4.0', reprintRule: '' })
const sourceQuoteForm = reactive({ url: '', author: '', platform: '', note: '' })
const followUnlockForm = reactive({ hint: '' })
const commentUnlockForm = reactive({ minCommentCount: 1 })

const filteredTopics = computed(() => {
  if (!topicSearchQuery.value) return availableTopics.value.slice(0, 20)
  const q = topicSearchQuery.value.toLowerCase()
  return availableTopics.value.filter((t: any) => t.name.toLowerCase().includes(q)).slice(0, 20)
})
const editorEmpty = computed(() => isDocEmpty(editorContent.value))
function getUserId(): number { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }

async function loadTopics() {
  try { const resp = await fetchTopics(); availableTopics.value = (resp?.list || resp || []) } catch {}
}
function toggleTopic(topic: any) {
  const idx = selectedTopicIds.value.indexOf(topic.id)
  if (idx > -1) { selectedTopicIds.value.splice(idx, 1); delete selectedTopicNames.value[topic.id] }
  else { selectedTopicIds.value.push(topic.id); selectedTopicNames.value[topic.id] = topic.name }
}
function removeTopic(topicId: number) {
  const idx = selectedTopicIds.value.indexOf(topicId); if (idx > -1) selectedTopicIds.value.splice(idx, 1)
  delete selectedTopicNames.value[topicId]
}
async function loadAppList() {
  try {
    const res: any = await fetchAppList({ page: 1, pageSize: 200 })
    const list = Array.isArray(res) ? res : (res.list || res.data || [])
    appList.value = list; filteredAppList.value = list
  } catch {}
}
function filterApps() {
  const q = appSearchQuery.value.toLowerCase()
  filteredAppList.value = appList.value.filter((a: any) => a.name?.toLowerCase().includes(q) || a.category?.toLowerCase().includes(q))
}
function selectAppInline(app: any) {
  editorRef.value?.editor?.chain().focus().insertContent({
    type: 'paragraph', content: [{ type: 'text', text: ` [应用:${app.name}|${app.appId || app.id}|${app.description || app.category || ''}] `, marks: [{ type: 'bold' }] }]
  }).run()
  showAppSelector.value = false; appSearchQuery.value = ''
}
function insertPaywall() {
  if (paywallPrice.value <= 0) return
  editorRef.value?.insertPaywall(paywallPrice.value, paywallPriceType.value)
  showPaywallModal.value = false; paywallPrice.value = 0
}

function insertVote() {
  if (!voteForm.question.trim()) { ElMessage.warning('请输入投票问题'); return }
  editorRef.value?.insertVoteCard({
    question: voteForm.question,
    options: JSON.stringify(voteForm.options.filter((o: string) => o.trim())),
    maxSelect: voteForm.maxSelect
  })
  voteForm.question = ''; voteForm.options = ['', '']; voteForm.maxSelect = 1; showVoteModal.value = false
}
function insertGoods() { editorRef.value?.insertGoodsCard({ ...goodsForm }); goodsForm.title = ''; goodsForm.price = ''; goodsForm.image = ''; goodsForm.link = ''; showGoodsModal.value = false }
function insertAudio() { editorRef.value?.insertAudioBlock({ ...audioForm }); audioForm.src = ''; audioForm.title = ''; showAudioModal.value = false }
function insertFile() { editorRef.value?.insertFileAttachment({ ...fileForm }); fileForm.name = ''; fileForm.size = ''; fileForm.url = ''; showFileModal.value = false }
function insertNotice() { editorRef.value?.insertNoticeBanner({ ...noticeForm }); noticeForm.type = 'info'; noticeForm.content = ''; showNoticeModal.value = false }
function insertUpdateLog() {
  editorRef.value?.insertUpdateLog({ ...updateLogForm, changes: updateLogForm.changes.split('\n').filter(Boolean) })
  updateLogForm.version = ''; updateLogForm.date = ''; updateLogForm.changes = ''; showUpdateLogModal.value = false
}
function insertPassword() { editorRef.value?.insertPasswordUnlock({ ...passwordForm }); passwordForm.password = ''; passwordForm.hint = ''; passwordForm.content = ''; showPasswordModal.value = false }
function insertGallery() {
  const imgs = galleryForm.images.filter((i: string) => i.trim())
  editorRef.value?.insertGalleryBlock({ images: JSON.stringify(imgs) })
  galleryForm.images = ['', '']; showGalleryModal.value = false
}
function insertOriginal() { editorRef.value?.insertOriginalStatement({ ...originalForm }); originalForm.author = ''; originalForm.license = 'CC BY 4.0'; originalForm.reprintRule = ''; showOriginalModal.value = false }
function insertSourceQuote() { editorRef.value?.insertSourceQuote({ ...sourceQuoteForm }); sourceQuoteForm.url = ''; sourceQuoteForm.author = ''; sourceQuoteForm.platform = ''; sourceQuoteForm.note = ''; showSourceQuoteModal.value = false }
function insertFollowUnlock() { editorRef.value?.insertFollowUnlock({ hint: followUnlockForm.hint }); followUnlockForm.hint = ''; showFollowUnlockModal.value = false }
function insertCommentUnlock() { editorRef.value?.insertCommentUnlock({ minCommentCount: commentUnlockForm.minCommentCount }); commentUnlockForm.minCommentCount = 1; showCommentUnlockModal.value = false }
function addImage() { imgInput.value?.click() }
async function onImageUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  const urls: string[] = []
  for (const f of Array.from(files)) {
    try {
      const res: any = await uploadCommunityImage(f)
      const url = res?.url || res?.data?.url || res
      if (url) {
        uploadedImageUrls.value.push(url)
        urls.push(url)
      }
    } catch (err) { ElMessage.error('图片上传失败') }
  }
  if (urls.length > 0) {
    const html = urls.map(u => `<img src="${u}" />`).join('')
    editorRef.value?.editor?.chain().focus().insertContent(html).run()
  }
  (e.target as HTMLInputElement).value = ''
}
async function submit() {
  if (!form.value.title.trim()) { ElMessage.warning('请输入标题'); return }
  if (editorEmpty.value) { ElMessage.warning('请输入内容'); return }
  loading.value = true
  try {
    const content = JSON.stringify(editorContent.value)
    const images = extractImagesFromDoc(JSON.stringify(editorContent.value))
    await createCommunityPost({
      ...form.value, content, sectionId: sectionId.value,
      device: 'pc', tags: JSON.stringify([]), images: JSON.stringify(images),
      topicId: selectedTopicIds.value[0] || 0, topicIds: selectedTopicIds.value, userId: getUserId()
    })
    ElMessage.success('发布成功')
    router.back()
  } catch (e: any) { ElMessage.error(e.message || '发布失败') }
  finally { loading.value = false }
}
function goBack() { router.back() }
onMounted(loadTopics)
</script>

<template>
  <div class="pc-post-create">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <h2>发布帖子</h2>
    </div>
    <div class="form-card">
      <el-form label-position="top">
        <el-form-item label="标题">
          <el-input v-model="form.title" placeholder="请输入帖子标题" maxlength="100" show-word-limit />
        </el-form-item>
        <el-form-item label="话题">
          <div class="topic-area">
            <el-tag v-for="tid in selectedTopicIds" :key="tid" closable type="info" size="small" @close="removeTopic(tid)" style="margin-right:6px;margin-bottom:6px;">
              #{{ selectedTopicNames[tid] || tid }}
            </el-tag>
            <el-popover v-model:visible="showTopicPicker" placement="bottom-start" :width="300" trigger="click">
              <template #reference>
                <el-button size="small" @click="showTopicPicker = !showTopicPicker">{{ selectedTopicIds.length > 0 ? '添加话题' : '选择话题' }}</el-button>
              </template>
              <el-input v-model="topicSearchQuery" placeholder="搜索话题..." size="small" clearable style="margin-bottom:8px;" />
              <div style="max-height:240px;overflow-y:auto;">
                <div v-for="t in filteredTopics" :key="t.id" class="tp-item" :class="{ 'tp-item-on': selectedTopicIds.includes(t.id) }" @click="toggleTopic(t)">
                  <span v-if="t.icon" class="tp-icon">{{ t.icon }}</span>
                  <span class="tp-name">{{ t.name }}</span>
                  <span v-if="t.postCount" class="tp-count">{{ t.postCount }} 帖</span>
                  <el-icon v-if="selectedTopicIds.includes(t.id)" color="#6366f1" style="margin-left:4px;"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></el-icon>
                </div>
                <div v-if="filteredTopics.length === 0" class="tp-empty">暂无话题</div>
              </div>
            </el-popover>
          </div>
        </el-form-item>
        <el-form-item label="内容">
          <div class="editor-wrapper">
            <TipTapEditor ref="editorRef" v-model="editorContent" placeholder="分享你的想法..." />
          </div>
        </el-form-item>
        <el-form-item>
          <div class="btn-row">
            <el-button-group style="margin-right:12px;">
              <el-button size="small" @click="addImage">图片</el-button>
              <el-button size="small" @click="showPaywallModal = true">付费分割</el-button>
              <el-button size="small" @click="showAppSelector = true; loadAppList()">插入应用</el-button>
            </el-button-group>
            <el-button-group style="margin-right:12px;">
              <el-button size="small" @click="showVoteModal = true" title="投票">📊 投票</el-button>
              <el-button size="small" @click="showGoodsModal = true" title="商品">🛒 商品</el-button>
              <el-button size="small" @click="showAudioModal = true" title="音频">🎵 音频</el-button>
              <el-button size="small" @click="showFileModal = true" title="附件">📁 附件</el-button>
            </el-button-group>
            <el-button-group style="margin-right:12px;">
              <el-button size="small" @click="showNoticeModal = true" title="公告">📢 公告</el-button>
              <el-button size="small" @click="showUpdateLogModal = true" title="更新日志">📋 更新</el-button>
              <el-button size="small" @click="showPasswordModal = true" title="密码解锁">🔐 密码</el-button>
              <el-button size="small" @click="showGalleryModal = true" title="轮播图集">🎞 图集</el-button>
            </el-button-group>
            <el-button-group style="margin-right:12px;">
              <el-button size="small" @click="showOriginalModal = true" title="原创声明">© 原创</el-button>
              <el-button size="small" @click="showSourceQuoteModal = true" title="转载引用">📎 转载</el-button>
              <el-button size="small" @click="showFollowUnlockModal = true" title="关注解锁">👤 关注</el-button>
              <el-button size="small" @click="showCommentUnlockModal = true" title="评论解锁">💬 评论</el-button>
            </el-button-group>
            <el-select v-model="form.contentPermission" size="small" style="width:130px;">
              <el-option label="公开" value="public" />
              <el-option label="登录可见" value="login" />
              <el-option label="评论可见" value="comment" />
            </el-select>
          </div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="loading" @click="submit" size="large">发布</el-button>
          <el-button @click="goBack" size="large">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
    <input ref="imgInput" type="file" accept="image/*" multiple hidden @change="onImageUpload" />
    <el-dialog v-model="showPaywallModal" title="付费内容设置" width="360px">
      <el-form label-width="60px">
        <el-form-item label="价格"><el-input-number v-model="paywallPrice" :min="0" style="width:100%" /></el-form-item>
        <el-form-item label="单位"><el-select v-model="paywallPriceType" style="width:100%"><el-option label="余额" value="balance" /><el-option label="积分" value="points" /></el-select></el-form-item>
      </el-form>
      <template #footer><el-button @click="showPaywallModal = false">取消</el-button><el-button type="primary" @click="insertPaywall">插入</el-button></template>
    </el-dialog>
    <el-dialog v-model="showAppSelector" title="插入应用" width="480px">
      <el-input v-model="appSearchQuery" placeholder="搜索应用..." @input="filterApps" style="margin-bottom:12px;" />
      <div style="max-height:360px;overflow-y:auto;">
        <div v-for="a in filteredAppList" :key="a.id" class="app-item" @click="selectAppInline(a)">
          <div class="app-item-icon" :style="{ background: a.iconBgColor || '#508DFF' }">
            <img v-if="a.icon" :src="$fixImgUrl(a.icon)" class="app-item-img" /><span v-else>{{ (a.name || 'A')[0] }}</span>
          </div>
          <div class="app-item-info"><div class="app-item-name">{{ a.name }}</div><div class="app-item-desc">{{ a.description || a.category || '' }}</div></div>
        </div>
        <div v-if="filteredAppList.length === 0" style="text-align:center;padding:20px;color:#bbb;">暂无应用</div>
      </div>
    </el-dialog>

    <el-dialog v-model="showVoteModal" title="添加投票" width="400px">
      <el-input v-model="voteForm.question" placeholder="投票问题" style="margin-bottom:10px" />
      <div v-for="(_, i) in voteForm.options" :key="i" style="display:flex;gap:6px;margin-bottom:8px">
        <el-input v-model="voteForm.options[i]" :placeholder="`选项 ${i+1}`" />
        <el-button @click="voteForm.options.splice(i,1)" type="danger" :icon="'Delete'" circle size="small" />
      </div>
      <el-button @click="voteForm.options.push('')" size="small" style="margin-bottom:10px">+ 添加选项</el-button>
      <el-input-number v-model="voteForm.maxSelect" :min="1" placeholder="最多可选几项" style="width:100%" />
      <template #footer><el-button @click="showVoteModal = false">取消</el-button><el-button type="primary" @click="insertVote">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showGoodsModal" title="添加商品" width="400px">
      <el-input v-model="goodsForm.title" placeholder="商品名称" style="margin-bottom:10px" />
      <el-input v-model="goodsForm.price" placeholder="价格" style="margin-bottom:10px" />
      <el-input v-model="goodsForm.image" placeholder="图片链接" style="margin-bottom:10px" />
      <el-input v-model="goodsForm.link" placeholder="商品链接" />
      <template #footer><el-button @click="showGoodsModal = false">取消</el-button><el-button type="primary" @click="insertGoods">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showAudioModal" title="添加音频" width="400px">
      <el-input v-model="audioForm.src" placeholder="音频链接" style="margin-bottom:10px" />
      <el-input v-model="audioForm.title" placeholder="音频标题" />
      <template #footer><el-button @click="showAudioModal = false">取消</el-button><el-button type="primary" @click="insertAudio">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showFileModal" title="添加附件" width="400px">
      <el-input v-model="fileForm.name" placeholder="文件名" style="margin-bottom:10px" />
      <el-input v-model="fileForm.size" placeholder="文件大小" style="margin-bottom:10px" />
      <el-input v-model="fileForm.url" placeholder="文件链接" />
      <template #footer><el-button @click="showFileModal = false">取消</el-button><el-button type="primary" @click="insertFile">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showNoticeModal" title="添加公告" width="400px">
      <el-select v-model="noticeForm.type" style="width:100%;margin-bottom:10px">
        <el-option label="信息" value="info" /><el-option label="警告" value="warning" /><el-option label="成功" value="success" /><el-option label="错误" value="error" />
      </el-select>
      <el-input v-model="noticeForm.content" type="textarea" :rows="3" placeholder="公告内容" />
      <template #footer><el-button @click="showNoticeModal = false">取消</el-button><el-button type="primary" @click="insertNotice">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showUpdateLogModal" title="添加更新日志" width="400px">
      <el-input v-model="updateLogForm.version" placeholder="版本号" style="margin-bottom:10px" />
      <el-input v-model="updateLogForm.date" placeholder="日期" style="margin-bottom:10px" />
      <el-input v-model="updateLogForm.changes" type="textarea" :rows="4" placeholder="更新内容（每行一条）" />
      <template #footer><el-button @click="showUpdateLogModal = false">取消</el-button><el-button type="primary" @click="insertUpdateLog">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showPasswordModal" title="密码解锁块" width="400px">
      <el-input v-model="passwordForm.password" placeholder="解锁密码" style="margin-bottom:10px" />
      <el-input v-model="passwordForm.hint" placeholder="密码提示" style="margin-bottom:10px" />
      <el-input v-model="passwordForm.content" type="textarea" :rows="3" placeholder="锁定内容" />
      <template #footer><el-button @click="showPasswordModal = false">取消</el-button><el-button type="primary" @click="insertPassword">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showGalleryModal" title="轮播图集" width="400px">
      <div v-for="(_, i) in galleryForm.images" :key="i" style="display:flex;gap:6px;margin-bottom:8px">
        <el-input v-model="galleryForm.images[i]" :placeholder="`图片链接 ${i+1}`" />
        <el-button @click="galleryForm.images.splice(i,1)" type="danger" :icon="'Delete'" circle size="small" />
      </div>
      <el-button @click="galleryForm.images.push('')" size="small">+ 添加图片</el-button>
      <template #footer><el-button @click="showGalleryModal = false">取消</el-button><el-button type="primary" @click="insertGallery">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showOriginalModal" title="原创声明" width="400px">
      <el-input v-model="originalForm.author" placeholder="作者名" style="margin-bottom:10px" />
      <el-select v-model="originalForm.license" style="width:100%;margin-bottom:10px">
        <el-option label="CC BY 4.0" value="CC BY 4.0" /><el-option label="CC BY-SA 4.0" value="CC BY-SA 4.0" /><el-option label="CC BY-NC 4.0" value="CC BY-NC 4.0" /><el-option label="CC BY-ND 4.0" value="CC BY-ND 4.0" /><el-option label="All Rights Reserved" value="All Rights Reserved" />
      </el-select>
      <el-input v-model="originalForm.reprintRule" placeholder="转载规则" />
      <template #footer><el-button @click="showOriginalModal = false">取消</el-button><el-button type="primary" @click="insertOriginal">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showSourceQuoteModal" title="转载来源引用" width="400px">
      <el-input v-model="sourceQuoteForm.url" placeholder="原文链接" style="margin-bottom:10px" />
      <el-input v-model="sourceQuoteForm.author" placeholder="原作者" style="margin-bottom:10px" />
      <el-input v-model="sourceQuoteForm.platform" placeholder="来源平台" style="margin-bottom:10px" />
      <el-input v-model="sourceQuoteForm.note" placeholder="备注说明" />
      <template #footer><el-button @click="showSourceQuoteModal = false">取消</el-button><el-button type="primary" @click="insertSourceQuote">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showFollowUnlockModal" title="关注解锁" width="400px">
      <el-input v-model="followUnlockForm.hint" type="textarea" :rows="3" placeholder="解锁后的内容（用户关注后可见）" />
      <template #footer><el-button @click="showFollowUnlockModal = false">取消</el-button><el-button type="primary" @click="insertFollowUnlock">插入</el-button></template>
    </el-dialog>

    <el-dialog v-model="showCommentUnlockModal" title="评论解锁" width="400px">
      <el-input-number v-model="commentUnlockForm.minCommentCount" :min="1" placeholder="最少评论数" style="width:100%" />
      <template #footer><el-button @click="showCommentUnlockModal = false">取消</el-button><el-button type="primary" @click="insertCommentUnlock">插入</el-button></template>
    </el-dialog>
  </div>
</template>

<style scoped>
.pc-post-create { padding: 0 24px 24px; max-width: 900px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.form-card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.topic-area { display: flex; align-items: center; flex-wrap: wrap; gap: 4px; }
.tp-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; cursor: pointer; border-radius: 6px; transition: background .15s; }
.tp-item:hover { background: #f0f0f0; }
.tp-item-on { background: #edf2ff; color: #6366f1; font-weight: 600; }
.tp-icon { font-size: 16px; }
.tp-name { flex: 1; }
.tp-count { font-size: 11px; color: #adb5bd; }
.tp-empty { padding: 16px; text-align: center; color: #adb5bd; font-size: 13px; }
.editor-wrapper { width: 100%; border: 1px solid var(--el-border-color); border-radius: 6px; min-height: 300px; display: flex; }
.btn-row { display: flex; align-items: center; gap: 8px; }
.app-item { display: flex; align-items: center; gap: 10px; padding: 10px 0; border-bottom: 1px solid #f5f5f5; cursor: pointer; }
.app-item:hover { background: #fafafa; }
.app-item-icon { width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 16px; font-weight: 600; overflow: hidden; flex-shrink: 0; }
.app-item-img { width: 100%; height: 100%; object-fit: cover; }
.app-item-info { flex: 1; min-width: 0; }
.app-item-name { font-size: 14px; font-weight: 500; }
.app-item-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
