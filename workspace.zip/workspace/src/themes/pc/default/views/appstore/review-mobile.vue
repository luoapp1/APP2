<script setup lang="ts">
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const router = useRouter()

const list = ref<any[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

const keyword = ref('')
const statusFilter = ref('')

const stats = reactive({
  pendingCount: 0,
  approvedTodayCount: 0,
  rejectedTodayCount: 0,
  totalCount: 0
})

const rejectVisible = ref(false)
const rejectId = ref(0)
const rejectName = ref('')
const rejectReason = ref('')
const rejectSubmitting = ref(false)

const expandedRows = ref<number[]>([])
const detailCache = ref<Record<number, any>>({})

async function fetchList() {
  loading.value = true
  try {
    const res: any = await request.get({
      url: '/api/submission/review-list',
      params: {
        keyword: keyword.value || undefined,
        submissionStatus: statusFilter.value || undefined,
        page: page.value,
        pageSize: pageSize.value
      }
    })
    list.value = res.list || []
    total.value = res.total || 0
    stats.pendingCount = res.pendingCount || 0
    stats.approvedCount = res.approvedCount || 0
    stats.rejectedCount = res.rejectedCount || 0
    stats.totalCount = res.total || 0
  } catch (e) { /* handled by interceptor */ }
  finally { loading.value = false }
}

async function fetchStats() {
  try {
    const res: any = await request.get({
      url: '/api/submission/review-list',
      params: { page: 1, pageSize: 1 }
    })
    stats.pendingCount = res.pendingCount || 0
    stats.approvedCount = res.approvedCount || 0
    stats.rejectedCount = res.rejectedCount || 0
    stats.totalCount = res.total || 0
  } catch { /* ignore */ }
}

onMounted(async () => {
  fetchStats()
  fetchList()
})

function onSearch() {
  page.value = 1
  fetchList()
}

function onPageChange(p: number) {
  page.value = p
  fetchList()
}

function onSizeChange(s: number) {
  pageSize.value = s
  page.value = 1
  fetchList()
}

function showReject(row: any) {
  rejectId.value = row.id
  rejectName.value = row.name
  rejectReason.value = ''
  rejectVisible.value = true
}

async function doReject() {
  rejectSubmitting.value = true
  try {
    await request.put({
      url: `/api/submission/${rejectId.value}/status`,
      data: {
        submissionStatus: 'rejected',
        reviewComment: rejectReason.value
      }
    })
    ElMessage.success('已拒绝')
    rejectVisible.value = false
    fetchList()
    fetchStats()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '操作失败')
  } finally {
    rejectSubmitting.value = false
  }
}

async function doApprove(row: any) {
  try {
    await request.put({
      url: `/api/submission/${row.id}/status`,
      data: {
        submissionStatus: 'approved'
      }
    })
    ElMessage.success('已通过')
    fetchList()
    fetchStats()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '操作失败')
  }
}

async function loadDetail(row: any) {
  if (detailCache.value[row.id]) return
  try {
    const res: any = await request.get({ url: `/api/submission/${row.id}` })
    detailCache.value[row.id] = res
  } catch { /* ignore */ }
}

function onExpand(row: any, rows: any[]) {
  expandedRows.value = rows.map((r: any) => r.id)
  loadDetail(row)
}

function statusLabel(s: string) {
  if (s === 'pending') return '待审核'
  if (s === 'approved') return '已通过'
  if (s === 'rejected') return '已拒绝'
  if (s === 'removed') return '已下架'
  if (s === 'draft') return '草稿'
  return s || '-'
}

function statusType(s: string) {
  if (s === 'pending') return 'warning'
  if (s === 'approved') return 'success'
  if (s === 'rejected') return 'danger'
  if (s === 'removed') return 'info'
  return 'info'
}

const statusOptions = [
  { label: '全部', value: '' },
  { label: '待审核', value: 'pending' },
  { label: '已通过', value: 'approved' },
  { label: '已拒绝', value: 'rejected' }
]

function parseArray(v: any) {
  if (!v) return []
  if (Array.isArray(v)) return v
  try { return JSON.parse(v) } catch { return [] }
}
</script>

<template>
  <div class="pc-page">
    <div class="page-header">
      <el-button text @click="router.back()">&larr; 返回</el-button>
      <h2>投稿审核</h2>
    </div>

    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-value">{{ stats.pendingCount }}</div>
        <div class="stat-label">待审核</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">{{ stats.approvedCount }}</div>
        <div class="stat-label">已通过</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">{{ stats.rejectedCount }}</div>
        <div class="stat-label">已拒绝</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">{{ stats.totalCount }}</div>
        <div class="stat-label">总数</div>
      </div>
    </div>

    <div class="content-card">
      <div class="filter-bar">
        <el-input
          v-model="keyword"
          placeholder="搜索应用名 / 包名"
          clearable
          style="width: 260px"
          @keyup.enter="onSearch"
        />
        <el-select v-model="statusFilter" placeholder="审核状态" clearable style="width: 140px" @change="onSearch">
          <el-option v-for="opt in statusOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
        <el-button type="primary" @click="onSearch">搜索</el-button>
      </div>

      <el-table
        :data="list"
        v-loading="loading"
        style="width: 100%"
        @expand-change="onExpand"
        :row-key="(r: any) => r.id"
      >
        <el-table-column type="expand">
          <template #default="{ row }">
            <div class="expand-detail" v-loading="!detailCache[row.id]">
              <template v-if="detailCache[row.id]">
                <div class="detail-section">
                  <div class="detail-title">应用描述</div>
                  <div class="detail-desc">{{ detailCache[row.id].description || '暂无描述' }}</div>
                </div>
                <div class="detail-section" v-if="parseArray(detailCache[row.id].screenshots).length">
                  <div class="detail-title">截图预览</div>
                  <div class="screenshot-list">
                    <img
                      v-for="(img, idx) in parseArray(detailCache[row.id].screenshots)"
                      :key="idx"
                      :src="img"
                      class="screenshot-thumb"
                    />
                  </div>
                </div>
                <div class="detail-section">
                  <div class="detail-title">版本信息</div>
                  <div class="version-info">
                    <span>版本号: {{ detailCache[row.id].version || '-' }}</span>
                    <span>版本代码: {{ detailCache[row.id].versionCode || '-' }}</span>
                    <span>大小: {{ detailCache[row.id].sizeMb || 0 }} MB</span>
                  </div>
                </div>
                <div class="detail-section" v-if="detailCache[row.id].reviewComment">
                  <div class="detail-title">审核备注</div>
                  <div class="detail-desc">{{ detailCache[row.id].reviewComment }}</div>
                </div>
              </template>
              <div v-else style="padding: 20px; color: #999;">加载中...</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="应用名" min-width="150" />
        <el-table-column prop="packageName" label="包名" min-width="180" />
        <el-table-column prop="version" label="版本" width="100" />
        <el-table-column prop="userName" label="提交人" width="110" />
        <el-table-column prop="category" label="分类" width="100" />
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusType(row.submissionStatus)" size="small">
              {{ statusLabel(row.submissionStatus) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="提交时间" width="170">
          <template #default="{ row }">
            {{ row.createTime?.slice(0, 16)?.replace('T', ' ') || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <template v-if="row.submissionStatus === 'pending'">
              <el-button size="small" type="success" @click="doApprove(row)">通过</el-button>
              <el-button size="small" type="danger" @click="showReject(row)">拒绝</el-button>
            </template>
            <span v-else style="font-size: 12px; color: #999;">-</span>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap" v-if="total > 0">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next"
          :total="total"
          :page-size="pageSize"
          :current-page="page"
          :page-sizes="[10, 20, 50]"
          @current-change="onPageChange"
          @size-change="onSizeChange"
        />
      </div>

      <div v-if="!loading && list.length === 0" class="empty">暂无投稿数据</div>
    </div>

    <el-dialog v-model="rejectVisible" :title="`拒绝投稿 - ${rejectName}`" width="460px">
      <el-form label-width="80px">
        <el-form-item label="拒绝理由">
          <el-input v-model="rejectReason" type="textarea" :rows="4" placeholder="请填写拒绝理由（可选）..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectVisible = false">取消</el-button>
        <el-button type="danger" :loading="rejectSubmitting" @click="doReject">确认拒绝</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.pc-page { padding: 0 24px 24px; max-width: 1200px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; flex: 1; }

.stats-row { display: flex; gap: 16px; margin-bottom: 20px; }
.stat-card { flex: 1; background: #fff; border-radius: 12px; padding: 20px 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); text-align: center; }
.stat-value { font-size: 28px; font-weight: 700; color: #303133; line-height: 1.2; }
.stat-label { font-size: 13px; color: #909399; margin-top: 6px; }

.content-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.filter-bar { display: flex; gap: 12px; margin-bottom: 20px; align-items: center; }

.empty { text-align: center; padding: 60px; color: #999; }
.pagination-wrap { display: flex; justify-content: center; margin-top: 20px; }

.expand-detail { padding: 16px 40px; }
.detail-section { margin-bottom: 16px; }
.detail-title { font-size: 14px; font-weight: 600; color: #303133; margin-bottom: 8px; }
.detail-desc { font-size: 13px; color: #606266; line-height: 1.6; }

.screenshot-list { display: flex; gap: 10px; flex-wrap: wrap; }
.screenshot-thumb { width: 120px; height: 120px; object-fit: cover; border-radius: 8px; border: 1px solid #ebeef5; }

.version-info { display: flex; gap: 24px; font-size: 13px; color: #606266; }
</style>
