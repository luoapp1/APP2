<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunityPosts, searchUsers } from '@/api/community'
import { fetchAppList } from '@/api/appstore'

const router = useRouter()
const keyword = ref('')
const activeTab = ref('post')
const loading = ref(false)
const searched = ref(false)

const postResults = ref<any[]>([])
const appResults = ref<any[]>([])
const userResults = ref<any[]>([])

const tabs = [
  { key: 'post', label: '帖子' },
  { key: 'app', label: '应用' },
  { key: 'user', label: '用户' }
]

const avatarPalette = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#84CC16','#E11D48','#0EA5E9','#7C3AED']
function avatarColor(n: string): string {
  let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h)
  return avatarPalette[Math.abs(h) % avatarPalette.length]
}

function stripContent(text: string): string {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/<[^>]*>/g, '').trim()).filter(Boolean).join(' ').slice(0, 120)
    if (parsed?.type === 'doc') { const parts: string[] = []; function walk(n: any) { if (n.type === 'text') parts.push(n.text || ''); if (n.content) n.content.forEach(walk) }; if (parsed.content) parsed.content.forEach(walk); return parts.join(' ').trim().slice(0, 120) }
  } catch {}
  const stripTags = text.replace(/<[^>]*>/g, ' ').replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim()
  return stripTags.length > 120 ? stripTags.slice(0, 120) + '...' : stripTags
}

function fmtCount(n: number): string {
  if (!n || n === 0) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1).replace(/\.0$/, '') + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d = new Date(time)
  if (isNaN(d.getTime())) return time.slice(0, 10)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`
  if (diff < 259200000) return `${Math.floor(diff / 86400000)}天前`
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

function highlight(text: string) {
  if (!keyword.value || !text) return escapeHtml(text || '')
  const escaped = escapeHtml(text)
  const escapedKw = escapeHtml(keyword.value)
  const re = new RegExp(`(${escapedKw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
  return escaped.replace(re, '<mark style="background:#fef08a;border-radius:2px;padding:0 1px">$1</mark>')
}

function switchTab(key: string) {
  activeTab.value = key
  if (searched.value) doSearch()
}

async function doSearch() {
  const kw = keyword.value.trim()
  if (!kw) { searched.value = false; return }
  loading.value = true; searched.value = true
  try {
    if (activeTab.value === 'post') {
      const res: any = await fetchCommunityPosts({ keyword: kw, pageSize: 50 })
      postResults.value = Array.isArray(res?.data?.list) ? res.data.list : (Array.isArray(res?.list) ? res.list : [])
    } else if (activeTab.value === 'app') {
      const res: any = await fetchAppList({ keyword: kw, pageSize: 50 })
      appResults.value = Array.isArray(res?.data?.list) ? res.data.list : (Array.isArray(res?.list) ? res.list : (Array.isArray(res) ? res : []))
    } else if (activeTab.value === 'user') {
      const res: any = await searchUsers(kw)
      userResults.value = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : [])
    }
  } catch {} finally { loading.value = false }
}

function goPost(id: number) { router.push(`/community/post/${id}`) }
function goApp(id: number) { router.push(`/detail/${id}`) }
function goUser(id: number) { router.push(`/profile/${id}`) }
</script>

<template>
  <div class="pc-search">
    <div class="search-hd">
      <h2>搜索</h2>
      <div class="search-input-wrap">
        <svg class="search-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
        <input v-model="keyword" placeholder="搜索帖子、应用、用户..." class="search-input" @keydown.enter="doSearch" />
        <el-button v-if="keyword" type="primary" size="small" @click="doSearch">搜索</el-button>
      </div>
    </div>

    <div class="tabs">
      <el-tabs v-model="activeTab" @tab-change="() => switchTab(activeTab)">
        <el-tab-pane v-for="tab in tabs" :key="tab.key" :label="tab.label" :name="tab.key" />
      </el-tabs>
    </div>

    <div v-if="!searched" class="empty-hint">输入关键词开始搜索</div>
    <div v-else-if="loading" class="empty-hint">搜索中...</div>
    <div v-else class="results">
      <!-- 帖子结果 (广场风格卡片) -->
      <div v-if="activeTab === 'post'">
        <div v-if="postResults.length === 0" class="empty-hint">未找到相关帖子</div>
        <div v-for="post in postResults" :key="post.id" class="post-card" @click="goPost(post.id)">
          <div class="post-author">
            <div class="post-avatar">
              <img v-if="post.userAvatar" :src="post.userAvatar" class="av-img" />
              <template v-else>{{ (post.userName || '?')[0] }}</template>
            </div>
            <div class="post-author-info">
              <div class="post-author-row">
                <span class="post-username">{{ post.userName }}</span>
                <span v-if="post.userExpLevelName" class="post-level-badge" :style="{ color: post.userExpLevelTextColor || '#FFFFFF', background: post.userExpLevelBgColor || '#508DFF' }">{{ post.userExpLevelName }}</span>
                <span v-if="post.userIsVerified" class="post-verified">认证</span>
                <span v-if="post.isEssence" class="post-badge post-badge-essence">精</span>
                <span v-if="post.isHot" class="post-badge post-badge-hot">热</span>
                <span v-if="post.customBadge" class="post-badge post-badge-custom">{{ post.customBadge }}</span>
              </div>
              <div class="post-author-meta">
                <span class="post-level-name" :style="{ color: post.userLevelTextColor || '#508DFF' }">{{ post.userLevelName || '普通用户' }}</span>
                <template v-if="post.device"><span class="post-meta-dot">·</span><span class="post-device">{{ post.device }}</span></template>
              </div>
            </div>
          </div>
          <div class="post-title" v-html="highlight(post.title)"></div>
          <div v-if="post.content" class="post-content">{{ stripContent(post.content) }}</div>
          <div v-if="post.images && post.images.length" class="post-images">
            <div v-if="post.images.length === 1" class="post-img-single">
              <img :src="$fixImgUrl(post.images[0])" loading="lazy" alt=""/>
            </div>
            <div v-else-if="post.images.length === 2" class="post-img-grid2">
              <img v-for="(img, idx) in post.images.slice(0,2)" :key="idx" :src="img" loading="lazy" alt=""/>
            </div>
            <div v-else class="post-img-grid3">
              <img v-for="(img, idx) in post.images.slice(0,3)" :key="idx" :src="img" loading="lazy" alt=""/>
            </div>
          </div>
          <div class="post-footer">
            <div v-if="post.tags && post.tags.length" class="post-tags">
              <span v-for="tag in post.tags.slice(0,3)" :key="tag" class="post-tag">{{ tag }}</span>
            </div>
            <div class="post-stats">
              <span>{{ fmtRelativeTime(post.createTime) }}</span>
              <span class="post-stat">
                <svg class="stat-svg" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ fmtCount(post.viewCount) }}
              </span>
              <span class="post-stat">
                <svg class="stat-svg" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                {{ fmtCount(post.commentCount) }}
              </span>
              <span class="post-stat">
                <svg class="stat-svg" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                {{ fmtCount(post.likeCount) }}
              </span>
              <span v-if="post.images && post.images.length" class="post-stat">
                <svg class="stat-svg" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path stroke-linecap="round" stroke-linejoin="round" d="M21 15l-5-5L5 21"/></svg>
                {{ post.images.length }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- 应用结果 -->
      <div v-if="activeTab === 'app'">
        <div v-if="appResults.length === 0" class="empty-hint">未找到相关应用</div>
        <div v-for="item in appResults" :key="item.id" class="item" @click="goApp(item.id)">
          <img v-if="item.icon" :src="$fixImgUrl(item.icon)" class="item-av" />
          <div v-else class="item-av" :style="{ background: item.iconBgColor || '#14B8A6' }">{{ (item.name || '?')[0] }}</div>
          <div class="item-info">
            <div class="item-title" v-html="highlight(item.name)"></div>
            <div class="item-meta">{{ item.category }} · {{ item.downloads || 0 }} 下载</div>
          </div>
        </div>
      </div>

      <!-- 用户结果 -->
      <div v-if="activeTab === 'user'">
        <div v-if="userResults.length === 0" class="empty-hint">未找到相关用户</div>
        <div v-for="item in userResults" :key="item.id" class="item" @click="goUser(item.id)">
          <img v-if="item.avatar && !item.avatar.startsWith('avatar:')" :src="$fixImgUrl(item.avatar)" class="item-av user-av" />
          <div v-else class="item-av user-av" :style="{ background: avatarColor(item.nickname || item.username || '') }">{{ (item.nickname || item.username || '?')[0] }}</div>
          <div class="item-info">
            <div class="item-title" v-html="highlight(item.nickname || item.username)"></div>
            <div class="item-meta">@{{ item.username }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-search { max-width: 800px; margin: 0 auto; padding: 24px; }
.search-hd { margin-bottom: 16px; }
.search-hd h2 { font-size: 20px; font-weight: 700; margin-bottom: 16px; }
.search-input-wrap { display: flex; align-items: center; gap: 12px; background: #f5f5f5; border-radius: 12px; padding: 0 16px; }
.search-icon { width: 18px; height: 18px; color: #999; flex-shrink: 0; }
.search-input { flex: 1; border: none; outline: none; background: transparent; font-size: 14px; padding: 12px 0; color: #333; }
.search-input::placeholder { color: #bbb; }
.tabs { border-bottom: 1px solid #eee; margin-bottom: 16px; }
.empty-hint { text-align: center; padding: 60px 0; color: #bbb; font-size: 14px; }
.results { }

/* 广场风格帖子卡片 */
.post-card {
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 16px;
  padding: 16px;
  margin-bottom: 12px;
  cursor: pointer;
  transition: background .15s;
}
.post-card:hover { background: #fafafa; }

.post-author { display: flex; align-items: flex-start; gap: 10px; }
.post-avatar {
  width: 38px; height: 38px; border-radius: 50%; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  background: #508DFF; color: #fff; font-weight: 700; font-size: 14px; overflow: hidden;
}
.av-img { width: 100%; height: 100%; object-fit: cover; }
.post-author-info { flex: 1; min-width: 0; }
.post-author-row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.post-username { font-size: 14px; color: #222; font-weight: 600; }
.post-level-badge { font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 700; line-height: 1.4; }
.post-verified { font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 700; color: #059669; background: #ECFDF5; line-height: 1.4; }
.post-badge { font-size: 10px; padding: 1px 6px; border-radius: 4px; font-weight: 700; line-height: 1.4; }
.post-badge-essence { color: #EA580C; background: #FFF7ED; }
.post-badge-hot { color: #DC2626; background: #FEF2F2; }
.post-badge-custom { color: #C62828; background: #FCE4EC; }
.post-author-meta { display: flex; align-items: center; gap: 2px; margin-top: 2px; font-size: 12px; }
.post-level-name { color: #508DFF; font-weight: 500; }
.post-meta-dot { color: #DDD; }
.post-device { color: #B0B0B0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.post-title { margin-top: 10px; font-size: 16px; color: #111; font-weight: 700; line-height: 1.45; }
.post-content {
  margin-top: 4px; font-size: 13px; color: #AAA; line-height: 1.6;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}

.post-images { margin-top: 10px; }
.post-img-single { border-radius: 10px; overflow: hidden; }
.post-img-single img { width: 100%; max-height: 180px; object-fit: cover; }
.post-img-grid2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px; border-radius: 10px; overflow: hidden; }
.post-img-grid2 img { width: 100%; max-height: 140px; object-fit: cover; aspect-ratio: 1 / 1; }
.post-img-grid3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; border-radius: 10px; overflow: hidden; }
.post-img-grid3 img { width: 100%; max-height: 110px; object-fit: cover; aspect-ratio: 1 / 1; }

.post-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 10px; }
.post-tags { display: flex; align-items: center; gap: 6px; flex: 1; min-width: 0; overflow: hidden; }
.post-tag { font-size: 10px; padding: 2px 8px; border-radius: 20px; color: #508DFF; background: #EEF2FF; font-weight: 500; flex-shrink: 0; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.post-stats { display: flex; align-items: center; gap: 12px; font-size: 12px; color: #B8B8B8; margin-left: auto; flex-shrink: 0; }
.post-stat { display: inline-flex; align-items: center; gap: 2px; }
.stat-svg { width: 13px; height: 13px; }

/* 应用/用户列表项 */
.item { display: flex; align-items: center; gap: 14px; padding: 14px; border-bottom: 1px solid #f5f5f5; cursor: pointer; border-radius: 8px; transition: background .15s; }
.item:hover { background: #fafafa; }
.item-av { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 16px; font-weight: 700; flex-shrink: 0; object-fit: cover; }
.user-av { border-radius: 50%; }
.item-info { flex: 1; min-width: 0; }
.item-title { font-size: 14px; font-weight: 600; color: #222; }
.item-meta { font-size: 12px; color: #999; margin-top: 2px; }
</style>
