<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators, applyForModerator, fetchMyApplication } from '@/api/community'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import { useUserStore } from '@/store/modules/user'
import { fmtCount, fmtRelativeTime, stripContent } from '@/utils'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const activeTab = ref('hot')
const loading = ref(false)
const page = ref(1)
const total = ref(0)
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)

const applyVisible = ref(false)
const applyReason = ref('')
const applyRole = ref('版主')
const applySubmitting = ref(false)
const myApplication = ref<any>(null)
const availableRoles = ['版主', '管理员', '超级版主', '审核员']

const boardName = computed(() => route.query.name || sectionInfo.value?.name || '板块')

async function loadSection() {
  try {
    const id = route.params.id as string
    const res = await fetchCommunitySection(id)
    sectionInfo.value = res.data || res
  } catch (e) { /* ignore */ }
}

async function loadPosts() {
  loading.value = true
  try {
    const id = route.params.id as string
    const res = await fetchCommunityPosts({
      sectionId: id, sort: activeTab.value,
      page: page.value, pageSize: 20
    })
    postList.value = res.data?.list || res.list || []
    total.value = res.data?.total || res.total || 0
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function loadModerators() {
  try {
    const id = route.params.id as string
    const res = await fetchModerators(id)
    moderators.value = res.data || res || []
  } catch (e) { /* ignore */ }
}

async function loadMyApplication() {
  try {
    const id = route.params.id as string
    const res = await fetchMyApplication(id)
    myApplication.value = res.data || null
  } catch (e) { /* ignore */ }
}

function goPost(id: string) { router.push(`/p/${id}`) }
function goCreate() { router.push(`/p/create/${route.params.id}`) }
function goBack() { router.back() }
function changeTab(tab: string) { activeTab.value = tab; page.value = 1; loadPosts() }

function showApply() { applyReason.value = ''; applyRole.value = '版主'; applyVisible.value = true }

async function submitApply() {
  applySubmitting.value = true
  try {
    const id = route.params.id as string
    await applyForModerator(id, { reason: applyReason.value, desiredRole: applyRole.value })
    applyVisible.value = false
    ElMessage.success('申请已提交，请等待管理员审核')
    await loadMyApplication()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || e?.message || '提交失败')
  }
  finally { applySubmitting.value = false }
}

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}

onMounted(() => { loadSection(); loadPosts(); loadModerators(); loadMyApplication(); loadActiveFrame() })
</script>

<template>
  <div class="pc-forum-page">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <div>
        <h2>{{ boardName }}</h2>
        <p class="board-stats" v-if="sectionInfo">
          帖子 {{ sectionInfo.postCount || 0 }} · 今日浏览 {{ sectionInfo.todayViewCount || 0 }} · 总浏览 {{ sectionInfo.totalViewCount || 0 }}
        </p>
      </div>
      <el-button type="primary" @click="goCreate">发布帖子</el-button>
    </div>

    <div class="forum-layout">
      <div class="forum-main">
        <div class="tab-bar">
          <el-radio-group v-model="activeTab" size="small" @change="changeTab">
            <el-radio-button value="hot">热门</el-radio-button>
            <el-radio-button value="latest">最新</el-radio-button>
            <el-radio-button value="recent_reply">待回复</el-radio-button>
            <el-radio-button value="essence">精华</el-radio-button>
          </el-radio-group>
        </div>

        <div v-if="loading" class="loading"><el-skeleton :rows="5" animated /></div>
        <div v-else class="post-list">
          <div v-for="p in postList" :key="p.id" class="post-card" @click="goPost(p.id)">
            <div class="post-avatar-wrap">
              <img v-if="activeFrameUrl && (p.userId || p.user?.id) === currentUserId" :src="activeFrameUrl" class="post-avatar-frame"  loading="lazy" />
              <div class="post-avatar-inner">
                <el-avatar :size="48" :src="$fixImgUrl(p.avatar || p.user?.avatar)" />
              </div>
            </div>
            <div class="post-body">
              <div class="post-header">
                <span class="post-author">{{ p.nickname || p.user?.nickname }}</span>
                <el-tag v-if="p.isPinned" size="small" type="danger">置顶</el-tag>
                <span class="post-time">{{ fmtRelativeTime(p.createTime || p.createdAt) }}</span>
              </div>
              <div class="post-title">{{ p.title }}</div>
              <div class="post-summary">{{ stripContent(p.content || '').slice(0, 150) }}</div>
              <div class="post-stats">
                <span>{{ fmtCount(p.viewCount || 0) }} 浏览</span>
                <span>{{ fmtCount(p.commentCount || 0) }} 回复</span>
                <span>{{ fmtCount(p.likeCount || 0) }} 赞</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="forum-sidebar">
        <div class="sidebar-card" v-if="moderators.length">
          <h4>圈主</h4>
          <div v-for="m in moderators" :key="m.userId || m.id" class="mod-item">
            <el-avatar :size="32" :src="$fixImgUrl(m.userAvatar)" />
            <span>{{ m.userName || m.nickname || m.username }}</span>
          </div>
        </div>

        <div class="sidebar-card">
          <h4>申请圈主</h4>
          <template v-if="myApplication">
            <div class="apply-status">
              <el-tag v-if="myApplication.status === 'pending'" type="warning" size="small">审核中</el-tag>
              <el-tag v-else-if="myApplication.status === 'approved'" type="success" size="small">已通过</el-tag>
              <el-tag v-else type="danger" size="small">已拒绝</el-tag>
              <span class="apply-desired">角色: {{ myApplication.desiredRole || '版主' }}</span>
            </div>
            <div v-if="myApplication.reason" class="apply-info">申请理由: {{ myApplication.reason }}</div>
            <div v-if="myApplication.reviewComment" class="apply-info">审核意见: {{ myApplication.reviewComment }}</div>
          </template>
          <el-button v-else type="primary" size="small" plain style="width:100%" @click="showApply">申请圈主</el-button>
        </div>

        <div class="sidebar-card" v-if="sectionInfo">
          <h4>板块信息</h4>
          <div class="info-row"><span>帖子数</span><span>{{ sectionInfo.postCount || 0 }}</span></div>
          <div class="info-row"><span>今日浏览</span><span>{{ sectionInfo.todayViewCount || 0 }}</span></div>
          <div class="info-row"><span>总浏览</span><span>{{ sectionInfo.totalViewCount || 0 }}</span></div>
        </div>
      </div>
    </div>

    <el-dialog v-model="applyVisible" title="申请圈主" width="420px">
      <el-form label-width="80px">
        <el-form-item label="期望角色">
          <el-select v-model="applyRole" placeholder="选择角色" style="width:100%">
            <el-option v-for="r in availableRoles" :key="r" :label="r" :value="r" />
          </el-select>
        </el-form-item>
        <el-form-item label="申请理由">
          <el-input v-model="applyReason" type="textarea" :rows="4" placeholder="请简述您的申请理由..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="applyVisible = false">取消</el-button>
        <el-button type="primary" :loading="applySubmitting" @click="submitApply">提交申请</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.pc-forum-page { padding: 0 24px 24px; max-width: 1100px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.board-stats { margin: 4px 0 0; font-size: 12px; color: #999; }
.forum-layout { display: flex; gap: 24px; }
.forum-main { flex: 1; min-width: 0; }
.forum-sidebar { width: 240px; flex-shrink: 0; }
.tab-bar { margin-bottom: 16px; }
.post-list { display: flex; flex-direction: column; gap: 10px; }
.post-card { display: flex; gap: 14px; padding: 16px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; }
.post-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.post-body { flex: 1; min-width: 0; }
.post-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.post-author { font-size: 14px; font-weight: 500; }
.post-time { font-size: 12px; color: #999; margin-left: auto; }
.post-title { font-size: 16px; font-weight: 600; margin-bottom: 6px; }
.post-summary { font-size: 13px; color: #777; line-height: 1.5; margin-bottom: 8px; }
.post-stats { display: flex; gap: 16px; font-size: 12px; color: #aaa; }
.sidebar-card { background: #fff; border-radius: 10px; padding: 16px; margin-bottom: 14px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.sidebar-card h4 { margin: 0 0 12px; font-size: 14px; color: #333; }
.mod-item { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 13px; }
.info-row { display: flex; justify-content: space-between; font-size: 13px; color: #666; padding: 6px 0; }
.apply-status { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.apply-desired { font-size: 12px; color: #666; }
.apply-info { font-size: 12px; color: #999; margin-top: 4px; }
.loading { padding: 20px; }

.post-avatar-wrap {
  position: relative;
  width: 68px;
  height: 68px;
  flex-shrink: 0;
}
.post-avatar-frame {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
  z-index: 0;
}
.post-avatar-inner {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1;
}
</style>
