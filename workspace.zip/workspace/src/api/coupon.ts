import request from '@/utils/http'

export function fetchCouponList(params: any) {
  return request.get({ url: '/api/coupon/list', params })
}

export function fetchCreateCoupon(data: any) {
  return request.post({ url: '/api/coupon', data })
}

export function fetchUpdateCoupon(id: number, data: any) {
  return request.put({ url: `/api/coupon/${id}`, data })
}

export function fetchDeleteCoupon(id: number) {
  return request.del({ url: `/api/coupon/${id}` })
}

export function fetchAvailableCoupons(params?: any) {
  return request.get({ url: '/api/coupon/available', params })
}

export function fetchClaimCoupon(id: number) {
  return request.post({ url: `/api/coupon/claim/${id}` })
}

export function fetchMyCoupons(params?: any) {
  return request.get({ url: '/api/coupon/my', params })
}

export function fetchUsableCoupons(params?: any) {
  return request.get({ url: '/api/coupon/usable', params })
}

export function fetchCouponHistory() {
  return request.get({ url: '/api/coupon/history' })
}

export function fetchUseCoupon(data: any) {
  return request.post({ url: '/api/coupon/use', data })
}

export function fetchCouponOptions() {
  return request.get({ url: '/api/coupon/options' })
}
