import request from '@/utils/http'

export interface SubmissionItem {
  id: number
  appId: number
  userId: number
  userName: string
  name: string
  packageName: string
  category: string
  description: string
  icon: string
  version: string
  versionCode: string
  sizeMb: number
  downloads: number
  rating: number
  coinCount: number
  coinPeople: number
  reviewCount: number
  fiveStarCount: number
  screenshots: any[]
  tags: string[]
  downloadUrl: string
  submissionStatus: string
  reviewComment: string
  reviewBy: string
  reviewTime: string
  createTime: string
  updateTime: string
}

export interface SubmissionStats {
  totalDownloads: number
  totalReviews: number
  totalFiveStar: number
  totalCoins: number
  statusCount: Array<{ status: string; count: number }>
}

export function fetchSubmissionStats(userId?: number) {
  return request.get({ url: '/api/submission/stats', params: { userId } })
}

export function fetchSubmissionList(params: Record<string, unknown>) {
  return request.get({ url: '/api/submission/list', params })
}

export function fetchSubmissionDetail(id: number) {
  return request.get({ url: `/api/submission/${id}` })
}

export function fetchSaveSubmission(params: Record<string, unknown>) {
  return request.post({ url: '/api/submission/save', data: params })
}

export function fetchSubmitReview(id: number) {
  return request.post({ url: `/api/submission/${id}/submit` })
}

export function fetchUpdateSubmissionStatus(id: number, params: Record<string, unknown>) {
  return request.put({ url: `/api/submission/${id}/status`, data: params })
}

export function fetchDeleteSubmission(id: number) {
  return request.del({ url: `/api/submission/${id}` })
}

export function fetchReviewList(params?: Record<string, unknown>) {
  return request.get({ url: '/api/submission/review-list', params })
}

export function fetchSubmissionVersions(params?: Record<string, unknown>) {
  return request.get({ url: '/api/submission/versions', params })
}

export function fetchSubmissionDrafts(userId: number, page = 1, pageSize = 20) {
  return request.get({ url: '/api/submission/drafts', params: { userId, page, pageSize } })
}

export function fetchDeleteDrafts(userId: number, ids?: number[]) {
  return request.del({ url: '/api/submission/drafts', data: { userId, ids } })
}
