import request from '@/utils/http'

export { fetchExpLevelList } from './operation'

export const fetchBalanceRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/balance-records', params })

export const fetchPointsRecords = (params: any) =>
  request.get({ url: '/api/operation/points-record/list', params })

export const fetchFollowers = (userId: number, page = 1) =>
  request.get({ url: `/api/user/${userId}/followers`, params: { page, pageSize: 20 } })

export const fetchFollowing = (userId: number, page = 1) =>
  request.get({ url: `/api/user/${userId}/following`, params: { page, pageSize: 20 } })

export const fetchContentPurchases = (userId: number, page = 1) =>
  request.get({ url: '/api/content/purchases/my', params: { userId, page, pageSize: 20 } })

export const fetchOrders = (page = 1) =>
  request.get({ url: '/api/settlement/orders', params: { page, pageSize: 20 } })

export const fetchMallOrders = (page = 1) =>
  request.get({ url: '/api/mall/orders/my', params: { page, pageSize: 20 } })

export const fetchMallOrderDetail = (orderId: number) =>
  request.get({ url: `/api/mall/orders/${orderId}` })

export const fetchMallOrderTracking = (orderId: number) =>
  request.get({ url: `/api/mall/orders/${orderId}/tracking` })

export const fetchMallReviews = (params: Record<string, unknown>) =>
  request.get({ url: '/api/mall/reviews', params })

export const fetchMallFavoritesList = (userId: number) =>
  request.get({ url: '/api/mall/favorites', params: { userId } })

export const fetchToggleMallFavorite = (productId: number, userId: number) =>
  request.post({ url: `/api/mall/favorites/${productId}`, data: { userId } })

export const fetchCreateAfterSale = (params: Record<string, unknown>) =>
  request.post({ url: '/api/mall/after-sales', data: params })

export const fetchMallAfterSales = (params?: Record<string, unknown>) =>
  request.get({ url: '/api/mall/after-sales', params })

export const fetchUserAddresses = (userId: number) =>
  request.get({ url: '/api/user/addresses', params: { userId } })

export const fetchSaveAddress = (params: Record<string, unknown>) =>
  request.post({ url: '/api/user/addresses', data: params })

export const fetchUpdateAddress = (id: number, params: Record<string, unknown>) =>
  request.put({ url: `/api/user/addresses/${id}`, data: params })

export const fetchDeleteAddress = (id: number, userId: number) =>
  request.del({ url: `/api/user/addresses/${id}`, params: { userId } })

export const fetchSetDefaultAddress = (id: number, userId: number) =>
  request.put({ url: `/api/user/addresses/${id}/default`, data: { userId } })

export const fetchRechargeOrders = (params: Record<string, unknown>) =>
  request.get({ url: '/api/recharge/orders', params })

export const fetchRechargeOrderStatus = (orderNo: string) =>
  request.get({ url: `/api/recharge/order/${orderNo}/status` })

export const fetchRechargeCreate = (params: Record<string, unknown>) =>
  request.post({ url: '/api/recharge/create', data: params })

export const removeFollower = (followerId: number) =>
  request.del({ url: `/api/user/${followerId}/remove-follower` })

export const fetchExperienceRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/experience-records', params })

export const fetchCurrencySettings = () =>
  request.get({ url: '/api/currency-settings' })

export const fetchCurrencyBalances = () =>
  request.get({ url: '/api/user/currency-balance' })

export const fetchCurrencyTransactions = (params: { currency_key?: string; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/currency-transactions', params })

export const fetchMembershipRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/membership-records', params })
