import request from '@/utils/http'

export const doCheckin = () =>
  request.post({ url: '/api/checkin' })

export const fetchCheckinStatus = () =>
  request.get({ url: '/api/checkin/status' })

export const fetchCheckinHistory = (params?: any) =>
  request.get({ url: '/api/checkin/history', params })

export const fetchCheckinRanking = (params?: any) =>
  request.get({ url: '/api/checkin/ranking', params })

export const doMakeupCheckin = (data: { cardNo: string; password: string; date?: string }) =>
  request.post({ url: '/api/checkin/makeup', data })

export const doMakeupCheckinByPoints = (date?: string) =>
  request.post({ url: '/api/checkin/makeup/points', data: date ? { date } : {} })

export const doMakeupCheckinByBalance = (date?: string) =>
  request.post({ url: '/api/checkin/makeup/balance', data: date ? { date } : {} })

export const doMakeupCheckinFree = (date?: string) =>
  request.post({ url: '/api/checkin/makeup/free', data: date ? { date } : {} })

export const fetchMakeupsAvailable = () =>
  request.get({ url: '/api/checkin/makeups/available' })
