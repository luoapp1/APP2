import request from '@/utils/http'

export const fetchCustomTasks = (params?: any) =>
  request.get({ url: '/api/custom-task/list', params })

export const fetchTaskList = fetchCustomTasks

export const saveCustomTask = (data: any) =>
  request.post({ url: '/api/custom-task/save', data })

export const saveTask = saveCustomTask

export const deleteCustomTask = (id: number) =>
  request.post({ url: '/api/custom-task/delete', data: { id } })

export const deleteTask = deleteCustomTask

export const fetchMyTasks = (userId: number) =>
  request.get({ url: '/api/custom-task/my', params: { userId } })

export const doCustomTask = (data: { taskId: number; resourceUrl?: string; remark?: string }) =>
  request.post({ url: '/api/custom-task/do', data })

export const doTask = doCustomTask

export const fetchPenaltyLogs = (params: any) =>
  request.get({ url: '/api/operation/penalty/logs', params })

export const fetchPenaltyStats = (params: any) =>
  request.get({ url: '/api/operation/penalty/stats', params })

export const manualPenalty = (data: { userId: number; amount: number; reason?: string; skipNotification?: boolean }) =>
  request.post({ url: '/api/operation/penalty/manual', data })
