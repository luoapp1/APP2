import request from '@/utils/http'

export function fetchGetCardKeyList(params: Api.Operation.CardKeySearchParams) {
  return request.get<Api.Operation.CardKeyList>({ url: '/api/operation/cardkey/list', params })
}

export function fetchCreateCardKeys(params: { count: number; type: string; targetId: number; value: number; duration?: number; durationUnit?: string; prefix?: string; extraPoints?: number; extraExperience?: number }) {
  return request.post<Api.Operation.CardKeyItem[]>({ url: '/api/operation/cardkey/create', params })
}

export function fetchDeleteCardKey(id: number) {
  return request.del({ url: `/api/operation/cardkey/${id}` })
}

export function fetchModerationQueue(params: { page?: number; limit?: number; type?: string }) {
  return request.get({ url: '/api/admin/moderation/queue', params })
}

export function fetchModerationStats() {
  return request.get({ url: '/api/admin/moderation/queue/stats' })
}

export function fetchGetMembershipLevelList(params: Api.Operation.MembershipLevelSearchParams) {
  return request.get<Api.Operation.MembershipLevelList>({ url: '/api/operation/membership-level/list', params })
}

export function fetchSaveMembershipLevel(params: Api.Operation.MembershipLevelItem) {
  return request.post({ url: '/api/operation/membership-level/save', params })
}

export function fetchDeleteMembershipLevel(id: number) {
  return request.del({ url: `/api/operation/membership-level/${id}` })
}

export function fetchGetMemberList(params: Api.Operation.MemberSearchParams) {
  return request.get<Api.Operation.MemberList>({ url: '/api/operation/member/list', params })
}

export function fetchUpdateMemberLevel(params: { userId: number; level: number }) {
  return request.post({ url: '/api/operation/member/update-level', params })
}

export function fetchGetPointsRecordList(params: Api.Operation.PointsRecordSearchParams) {
  return request.get<Api.Operation.PointsRecordList>({ url: '/api/operation/points-record/list', params })
}

export function fetchAdjustPoints(params: { userId: number; points: number; description: string }) {
  return request.post({ url: '/api/operation/points-record/adjust', params })
}

export function fetchExpLevelList(params?: any) {
  return request.get({ url: '/api/operation/experience-level/list', params })
}

export function fetchExpLevelSave(data: any) {
  return request.post({ url: '/api/operation/experience-level/save', params: data })
}

export function fetchExpLevelDelete(id: number) {
  return request.del({ url: `/api/operation/experience-level/${id}` })
}

export function fetchPluginList(params?: any) {
  return request.get({ url: '/api/plugins/list', params, showErrorMessage: false })
}

export function fetchPluginUpload(formData: FormData) {
  return request.post({ url: '/api/plugins/upload', data: formData, showErrorMessage: false })
}

export function fetchPluginToggle(id: number) {
  return request.put({ url: `/api/plugins/${id}/toggle`, showErrorMessage: false })
}

export function fetchPluginDelete(id: number) {
  return request.del({ url: `/api/plugins/${id}`, showErrorMessage: false })
}

export function fetchPluginUpgrade(id: number, formData: FormData) {
  return request.post({ url: `/api/plugins/${id}/upgrade`, data: formData, showErrorMessage: false })
}

export function fetchPluginInject() {
  return request.get({ url: '/api/plugins/inject', showErrorMessage: false })
}

export function fetchPluginUpdateConfig(pluginName: string, data: Record<string, any>) {
  return request.put({ url: `/api/plugins/${pluginName}/config`, data })
}

export function fetchGetCheckinGroupList(params?: any) {
  return request.get({ url: '/api/operation/checkin-group/list', params })
}

export function fetchSaveCheckinGroup(data: any) {
  return request.post({ url: '/api/operation/checkin-group/save', params: data })
}

export function fetchDeleteCheckinGroup(id: number) {
  return request.del({ url: `/api/operation/checkin-group/${id}` })
}

export function fetchGetCheckinMilestoneList(params?: any) {
  return request.get({ url: '/api/operation/checkin-milestone/list', params })
}

export function fetchSaveCheckinMilestone(data: any) {
  return request.post({ url: '/api/operation/checkin-milestone/save', params: data })
}

export function fetchDeleteCheckinMilestone(id: number) {
  return request.del({ url: `/api/operation/checkin-milestone/${id}` })
}
