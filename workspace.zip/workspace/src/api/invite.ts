import request from '@/utils/http'

export const fetchGenerateInvite = (data?: any) =>
  request.post({ url: '/api/invite/generate', data })

export const fetchInviteList = (params: any) =>
  request.get({ url: '/api/invite/list', params })

export const fetchInviteVerify = (code: string) =>
  request.post({ url: '/api/invite/verify', data: { code } })

export const fetchInviteUse = (code: string, userId: number, userName: string) =>
  request.post({ url: '/api/invite/use', data: { code, userId, userName } })

export const fetchInviteRequired = () =>
  request.get({ url: '/api/invite/required' })

export const fetchMyInvite = () =>
  request.get({ url: '/api/invite/my' })

export const fetchGenerateUserInvite = (data?: any) =>
  request.post({ url: '/api/invite/generate-user', data })

export const fetchInviteConfig = () =>
  request.get({ url: '/api/invite/config' })

export const saveInviteConfig = (data: any) =>
  request.post({ url: '/api/invite/config/save', data })

export const fetchInviteGenerateConfig = () =>
  request.get({ url: '/api/invite/generate-config' })

export const saveInviteGenerateConfig = (data: any) =>
  request.post({ url: '/api/invite/generate-config/save', data })

export const deleteInvite = (id: number) =>
  request.del({ url: `/api/invite/${id}` })

export const deleteMyInvite = (id: number) =>
  request.del({ url: `/api/invite/my/${id}` })

export const revokeMyInvite = (id: number) =>
  request.post({ url: `/api/invite/my/revoke/${id}` })

// 统一推广码 API
export const fetchUserCodes = () =>
  request.get({ url: '/api/user-codes' })

export const createUserCode = (data: { label?: string; maxUses?: number }) =>
  request.post({ url: '/api/user-codes', data })

export const deleteUserCode = (id: number) =>
  request.del({ url: `/api/user-codes/${id}` })

export const fetchDefaultCode = () =>
  request.post({ url: '/api/user-codes/default' })

export const revokeUserCode = (id: number) =>
  request.post({ url: `/api/user-codes/${id}/revoke` })

export const recordCodeClick = (code: string) =>
  request.post({ url: `/api/user-codes/click/${code}` })

export const verifyUserCode = (code: string) =>
  request.get({ url: `/api/user-codes/verify/${code}` })

export const fetchCommissionDashboard = () =>
  request.get({ url: '/api/commission/stats/dashboard' })

export const fetchCommissionRecords = (params: any) =>
  request.get({ url: '/api/commission/records', params })
