import request from '@/utils/http'
import { cachedRequest, clearCache } from '@/utils/http/cache'
import type { BaseResponse } from '@/types/common/response'
import type { ListResponse } from '@/types/api/models'

const SECTIONS_CACHE_KEY = 'community:sections'
const TOPICS_CACHE_KEY = 'community:topics'

export interface CommunitySection {
  id: number
  name: string
  icon: string
  iconBgColor: string
  description: string
  todayHeat: number
  totalHeat: number
  postCount: number
  viewCount: number
  sortOrder: number
  status: string
  createTime: string
}

export interface CommunityPost {
  id: number
  sectionId: number
  userId: number
  userName: string
  userAvatar: string
  title: string
  content: string
  device: string
  tags: string[]
  officialTags: string[]
  images: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  isPinned: boolean
  isGlobalPinned: boolean
  customBadge?: string
  isEssence: boolean
  isHot: boolean
  isLocked: boolean
  status: string
  rejectReason?: string
  likeCount: number
  commentCount: number
  coinCount: number
  viewCount: number
  favoriteCount: number
  scheduledTime: string
  createTime: string
  updateTime: string
  isLiked?: boolean
  isFavorited?: boolean
  soldCount?: number
  comments?: CommunityComment[]
  collectionId?: number
  collectionTitle?: string
}

export interface CommunityComment {
  id: number
  postId: number
  parentId: number
  userId: number
  userName: string
  userAvatar: string
  content: string
  images?: string[]
  likeCount: number
  replyCount: number
  isPinned: number
  userIsVerified?: number
  userExpLevelName?: string
  userTitleIcon?: string
  userTitleName?: string
  userTitleColor?: string
  userTitleBgColor?: string
  createTime: string
  replies?: CommunityComment[]
}

export interface CommunityDraft {
  id: number
  userId: number
  sectionId: number
  title: string
  content: string
  images: string[]
  tags: string[]
  officialTags: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  createTime: string
  updateTime: string
}

export interface BannedUser {
  id: number
  userId: number
  userName: string
  reason: string
  bannedUntil: string
  createTime: string
}

export interface CommunityCollection {
  id: number
  userId: number
  userName: string
  userAvatar: string
  title: string
  description: string
  coverImage: string
  postCount: number
  status: string
  isPaid: boolean
  price: number
  previewCount: number
  viewCount: number
  subscribeCount: number
  sortMode: string
  sectionId: number
  createTime: string
  updateTime: string
}

export interface CollectionPost {
  sortOrder: number
  isPreview: boolean
  postId: number
  id: number
  title: string
  postStatus: string
  postUserId: number
  postUserName: string
  viewCount: number
  commentCount: number
  likeCount: number
  summary: string
  postCreateTime: string
  invalid?: boolean
  invalidReason?: string
}

export interface CollectionDetail extends CommunityCollection {
  posts: CollectionPost[]
  isAuthor: boolean
  hasPaid: boolean
  hidden: boolean
  reason?: string
}

// ============ 分区相关 API ============

export function fetchCommunitySections(all?: boolean): Promise<CommunitySection[]> {
  const q = all ? '?all=true' : ''
  const cacheKey = all ? `${SECTIONS_CACHE_KEY}:all` : SECTIONS_CACHE_KEY
  return cachedRequest<CommunitySection[]>(cacheKey, () => request.get({ url: `/api/community/sections${q}` }))
}

export function fetchCommunitySection(id: number): Promise<CommunitySection> {
  return request.get<CommunitySection>({ url: `/api/community/section/${id}` })
}

export function createCommunitySection(data: {
  name: string
  icon?: string
  iconBgColor?: string
  description?: string
  sortOrder?: number
  status?: string
}): Promise<CommunitySection> {
  return request.post({ url: '/api/community/section', data }).then((res) => {
    clearCache(SECTIONS_CACHE_KEY)
    return res as CommunitySection
  })
}

export function updateCommunitySection(id: number, data: Record<string, unknown>): Promise<CommunitySection> {
  return request.post({ url: '/api/community/section', data: { ...data, id } }).then((res) => {
    clearCache(SECTIONS_CACHE_KEY)
    return res as CommunitySection
  })
}

export function deleteCommunitySection(id: number): Promise<void> {
  return request.del({ url: `/api/community/section/${id}` }).then((res) => {
    clearCache(SECTIONS_CACHE_KEY)
    return res as void
  })
}

// ============ 图片上传 API ============

export async function uploadCommunityImage(file: File): Promise<string> {
  const { compressFromPolicy } = await import('@/utils/uploadCompress')
  const { file: compressedFile } = await compressFromPolicy(file)
  const formData = new FormData()
  formData.append('file', compressedFile, compressedFile.name)
  return request.post<string>({ url: '/api/community/upload-image', data: formData })
}

export function deleteCommunityImage(url: string): Promise<void> {
  return request.post({ url: '/api/community/delete-image', data: { url } })
}

// ============ 帖子相关 API ============

export function fetchCommunityPosts(params: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: '/api/community/posts', params })
}

export function fetchCommunityPost(id: number, userId?: number): Promise<CommunityPost> {
  const q = userId ? `?userId=${userId}` : ''
  return request.get<CommunityPost>({ url: `/api/community/post/${id}${q}`, showErrorMessage: false })
}

export function createCommunityPost(data: Record<string, unknown>): Promise<CommunityPost> {
  return request.post<CommunityPost>({ url: '/api/community/post', data })
}

export function updateCommunityPost(id: number, data: Record<string, unknown>): Promise<CommunityPost> {
  return request.put<CommunityPost>({ url: `/api/community/post/${id}`, data })
}

export function deleteCommunityPost(id: number, userId: number): Promise<void> {
  return request.del({ url: `/api/community/post/${id}`, data: { userId } })
}

// ============ 帖子互动 API ============

export function likePost(id: number, userId: number): Promise<{ liked: boolean; likeCount: number }> {
  return request.post({ url: `/api/community/post/${id}/like`, data: { userId } })
}

export function favoritePost(id: number, userId: number): Promise<{ favorited: boolean }> {
  return request.post({ url: `/api/community/post/${id}/favorite`, data: { userId } })
}

export function fetchUserFavorites(params: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: '/api/community/user/favorites', params })
}

export function pinPost(id: number, userId: number): Promise<{ pinned: boolean }> {
  return request.post({ url: `/api/community/post/${id}/pin`, data: { userId } })
}

export function globalPinPost(id: number, userId: number): Promise<{ globalPinned: boolean }> {
  return request.post({ url: `/api/community/post/${id}/global-pin`, data: { userId } })
}

export function setCustomBadge(id: number, badge: string): Promise<void> {
  return request.post({ url: `/api/community/post/${id}/custom-badge`, data: { badge } })
}

export function essencePost(id: number, userId: number): Promise<{ essence: boolean }> {
  return request.post({ url: `/api/community/post/${id}/essence`, data: { userId } })
}

export function hotPost(id: number, userId: number): Promise<{ hot: boolean }> {
  return request.post({ url: `/api/community/post/${id}/hot`, data: { userId } })
}

export function lockPost(id: number, userId: number): Promise<{ locked: boolean }> {
  return request.post({ url: `/api/community/post/${id}/lock`, data: { userId } })
}

export function sendCoin(id: number, data: { userId: number; amount: number; coinType?: string }): Promise<{ coinCount: number }> {
  return request.post({ url: `/api/community/post/${id}/coin`, data })
}

export function fetchCoinLogs(id: number, page = 1): Promise<BaseResponse<ListResponse<unknown>>> {
  return request.get({ url: `/api/community/post/${id}/coin-logs`, params: { page, pageSize: 50 } })
}

// ============ 评论相关 API ============

export function fetchComments(postId: number, params: Record<string, unknown>): Promise<BaseResponse<{ list: CommunityComment[]; total: number }>> {
  return request.get({ url: `/api/community/post/${postId}/comments`, params })
}

export function fetchPostComments(params: Record<string, unknown>): Promise<BaseResponse<{ list: CommunityComment[]; total: number }>> {
  return fetchComments(params.postId as number, params)
}

export function postComment(postId: number, data: Record<string, unknown>): Promise<CommunityComment> {
  return request.post<CommunityComment>({ url: `/api/community/post/${postId}/comment`, data })
}

export function createPostComment(data: Record<string, unknown>): Promise<CommunityComment> {
  return postComment(data.postId as number, data)
}

export function deleteComment(id: number, userId: number): Promise<void> {
  return request.del({ url: `/api/community/comment/${id}`, data: { userId } })
}

export function likeComment(commentId: number): Promise<{ liked: boolean; likeCount: number }> {
  return request.post({ url: `/api/community/comment/${commentId}/like` })
}

export function pinComment(id: number): Promise<{ pinned: boolean }> {
  return request.post({ url: `/api/community/comment/${id}/pin` })
}

// ============ 草稿相关 API ============

export function fetchDrafts(userId: number): Promise<CommunityDraft[]> {
  return request.get<CommunityDraft[]>({ url: '/api/community/drafts', params: { userId } })
}

export function fetchMyPosts(params: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: '/api/community/posts', params })
}

export function saveDraft(data: Record<string, unknown>): Promise<CommunityDraft> {
  return request.post<CommunityDraft>({ url: '/api/community/draft', data })
}

export function deleteDraft(id: number, userId: number): Promise<void> {
  return request.del({ url: `/api/community/draft/${id}`, data: { userId } })
}

// ============ 管理相关 API ============

export function fetchAdminPosts(params: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: '/api/community/admin/posts', params })
}

export function updatePostStatus(id: number, data: { userId: number; status: string }): Promise<void> {
  return request.put({ url: `/api/community/admin/post/${id}/status`, data })
}

export function banUser(data: { userId: number; targetUserId: number; reason?: string; duration?: number }): Promise<void> {
  return request.post({ url: '/api/community/admin/ban', data })
}

export function unbanUser(userId: number, targetUserId: number): Promise<void> {
  return request.post({ url: '/api/community/admin/unban', data: { userId, targetUserId } })
}

export function fetchBannedUsers(userId: number): Promise<BannedUser[]> {
  return request.get<BannedUser[]>({ url: '/api/community/admin/banned', params: { userId } })
}

export function fetchModerators(sectionId: number): Promise<Record<string, unknown>[]> {
  return request.get({ url: `/api/community/section/${sectionId}/moderators` })
}

export function addModerator(sectionId: number, data: { userId: number; userName: string; userAvatar?: string; role?: string }): Promise<void> {
  return request.post({ url: `/api/community/section/${sectionId}/moderator`, data })
}

export function removeModerator(sectionId: number, userId: number): Promise<void> {
  return request.del({ url: `/api/community/section/${sectionId}/moderator/${userId}` })
}

export function applyForModerator(sectionId: number, data: { reason?: string; desiredRole?: string }): Promise<void> {
  return request.post({ url: `/api/community/section/${sectionId}/apply`, data })
}

export function fetchMyApplication(sectionId: number): Promise<Record<string, unknown>> {
  return request.get({ url: `/api/community/section/${sectionId}/my-application` })
}

export function fetchModeratorApplications(sectionId?: number): Promise<Record<string, unknown>[]> {
  if (sectionId) return request.get({ url: `/api/community/section/${sectionId}/applications` })
  return request.get({ url: '/api/community/applications' })
}

export function approveApplication(id: number, role?: string): Promise<void> {
  return request.post({ url: `/api/community/application/${id}/approve`, data: { role } })
}

export function rejectApplication(id: number, reason?: string): Promise<void> {
  return request.post({ url: `/api/community/application/${id}/reject`, data: { reason } })
}

export function fetchUserModeratorSections(userId: number): Promise<CommunitySection[]> {
  return request.get<CommunitySection[]>({ url: `/api/community/user/${userId}/moderator-sections` })
}

export function fetchPendingPosts(page = 1, pageSize = 20): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: '/api/community/admin/posts/pending', params: { page, pageSize } })
}

export function approvePost(postId: number): Promise<void> {
  return request.post({ url: `/api/community/admin/post/${postId}/approve` })
}

export function rejectPost(postId: number, reason: string): Promise<void> {
  return request.post({ url: `/api/community/admin/post/${postId}/reject`, data: { reason } })
}

// ============ 用户搜索 / 举报 API ============

export function searchUsers(keyword: string): Promise<Record<string, unknown>[]> {
  return request.get({ url: '/api/community/user/search', params: { keyword } })
}

export function reportPost(postId: number, reason?: string, detail?: string): Promise<void> {
  return request.post({
    url: `/api/community/post/${postId}/report`,
    data: { reportReason: reason, reportDetail: detail }
  })
}

export function reportComment(commentId: number, reason?: string, detail?: string): Promise<void> {
  return request.post({
    url: `/api/community/comment/${commentId}/report`,
    data: { reportReason: reason, reportDetail: detail }
  })
}

export function requestUnlock(postId: number, reason?: string): Promise<void> {
  return request.post({ url: `/api/community/post/${postId}/request-unlock`, data: { reason } })
}

export function fetchUnlockRequests(): Promise<Record<string, unknown>[]> {
  return request.get({ url: '/api/community/admin/unlock-requests' })
}

export function handleUnlockRequest(id: number, action: string, reply?: string): Promise<void> {
  return request.post({ url: `/api/community/admin/unlock-request/${id}/handle`, data: { action, reply } })
}

export function fetchReports(): Promise<Record<string, unknown>[]> {
  return request.get({ url: '/api/community/admin/reports' })
}

export function ignoreReport(id: number): Promise<void> {
  return request.post({ url: `/api/community/admin/report/ignore/${id}` })
}

export function deleteReportPost(postId: number): Promise<void> {
  return request.del({ url: `/api/community/admin/report/post/${postId}` })
}

export function deleteReportComment(commentId: number): Promise<void> {
  return request.del({ url: `/api/community/admin/report/comment/${commentId}` })
}

// ============ 话题相关 API ============

export function fetchTopics(params?: Record<string, unknown>): Promise<Record<string, unknown>[]> {
  return cachedRequest(TOPICS_CACHE_KEY, () => request.get({ url: '/api/community/topics', params }))
}

export function fetchTopicDetail(id: number): Promise<Record<string, unknown>> {
  return request.get({ url: `/api/community/topics/${id}` })
}

export function createTopic(data: Record<string, unknown>): Promise<void> {
  return request.post({ url: '/api/community/topics', data })
}

export function updateTopic(id: number, data: Record<string, unknown>): Promise<void> {
  return request.put({ url: `/api/community/topics/${id}`, data })
}

export function deleteTopic(id: number): Promise<void> {
  return request.del({ url: `/api/community/topics/${id}` })
}

export function fetchTopicConfig(): Promise<Record<string, unknown>> {
  return request.get({ url: '/api/community/topics/config' })
}

export function updateTopicConfig(data: Record<string, unknown>): Promise<void> {
  return request.put({ url: '/api/community/topics/config', data })
}

export function fetchTopicPosts(id: number, params?: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityPost>>> {
  return request.get({ url: `/api/community/topics/${id}/posts`, params })
}

export function followTopic(id: number): Promise<void> {
  return request.post({ url: `/api/community/topics/${id}/follow` })
}

export function unfollowTopic(id: number): Promise<void> {
  return request.del({ url: `/api/community/topics/${id}/follow` })
}

export function checkTopicFollow(id: number): Promise<{ followed: boolean }> {
  return request.get({ url: `/api/community/topics/${id}/follow` })
}

export function fetchTopicFollowers(id: number, params?: Record<string, unknown>): Promise<Record<string, unknown>[]> {
  return request.get({ url: `/api/community/topics/${id}/followers`, params })
}

export function fetchMembershipLevels(): Promise<Record<string, unknown>[]> {
  return request.get({ url: '/api/membership/levels' })
}

export function fetchExperienceLevels(): Promise<Record<string, unknown>[]> {
  return request.get({ url: '/api/operation/experience-level/list' })
}

// ============ 合集相关 API ============

export function createCollection(data: Record<string, unknown>): Promise<CommunityCollection> {
  return request.post<CommunityCollection>({ url: '/api/community/collection', data })
}

export function updateCollection(id: number, data: Record<string, unknown>): Promise<CommunityCollection> {
  return request.put<CommunityCollection>({ url: `/api/community/collection/${id}`, data })
}

export function deleteCollection(id: number): Promise<void> {
  return request.del({ url: `/api/community/collection/${id}` })
}

export function fetchCollection(id: number): Promise<CollectionDetail> {
  return request.get<CollectionDetail>({ url: `/api/community/collection/${id}` })
}

export function fetchMyCollections(params?: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityCollection>>> {
  return request.get({ url: '/api/community/collection/mine', params })
}

export function fetchUserCollections(userId: number, params?: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityCollection>>> {
  return request.get({ url: `/api/community/collection/user/${userId}`, params })
}

export function fetchPaidCollections(params?: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityCollection>>> {
  return request.get({ url: '/api/community/collection/paid', params })
}

export function addPostsToCollection(id: number, postIds: number[], isPreview?: boolean): Promise<void> {
  return request.post({ url: `/api/community/collection/${id}/posts`, data: { postIds, isPreview } })
}

export function removePostsFromCollection(id: number, postIds: number[]): Promise<void> {
  return request.del({ url: `/api/community/collection/${id}/posts`, data: { postIds } })
}

export function sortCollectionPosts(id: number, sortedPostIds: number[]): Promise<void> {
  return request.put({ url: `/api/community/collection/${id}/posts/sort`, data: { sortedPostIds } })
}

export function setPostPreview(collectionId: number, postId: number, isPreview: boolean): Promise<void> {
  return request.put({ url: `/api/community/collection/${collectionId}/posts/${postId}/preview`, data: { isPreview } })
}

export function buyCollection(id: number, payType: string = 'balance'): Promise<void> {
  return request.post({ url: `/api/community/collection/${id}/buy`, data: { payType } })
}

export function checkCollectionPaid(id: number): Promise<{ paid: boolean }> {
  return request.get({ url: `/api/community/collection/${id}/check-paid` })
}

export function fetchPostCollection(postId: number): Promise<CollectionDetail | null> {
  return request.get({ url: `/api/community/post/${postId}/collection` })
}

export function fetchFeaturedCollections(params?: Record<string, unknown>): Promise<BaseResponse<ListResponse<CommunityCollection>>> {
  return request.get({ url: '/api/community/collections/featured', params })
}
