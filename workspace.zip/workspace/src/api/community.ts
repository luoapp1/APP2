import request from '@/utils/http'

export interface CommunitySection {
  id: number
  name: string
  icon: string
  iconBgColor: string
  description: string
  todayHeat: number
  totalHeat: number
  postCount: number
  viewCount: number
  sortOrder: number
  status: string
  createTime: string
}

export interface CommunityPost {
  id: number
  sectionId: number
  userId: number
  userName: string
  userAvatar: string
  title: string
  content: string
  device: string
  tags: string[]
  officialTags: string[]
  images: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  isPinned: boolean
  isGlobalPinned: boolean
  customBadge?: string
  isEssence: boolean
  isHot: boolean
  isLocked: boolean
  status: string
  rejectReason?: string
  likeCount: number
  commentCount: number
  coinCount: number
  viewCount: number
  favoriteCount: number
  scheduledTime: string
  createTime: string
  updateTime: string
  isLiked?: boolean
  isFavorited?: boolean
  soldCount?: number
  comments?: CommunityComment[]
  collectionId?: number
  collectionTitle?: string
}

export interface CommunityComment {
  id: number
  postId: number
  parentId: number
  userId: number
  userName: string
  userAvatar: string
  content: string
  images?: string[]
  likeCount: number
  replyCount: number
  isPinned: number
  userIsVerified?: number
  userExpLevelName?: string
  userTitleIcon?: string
  userTitleName?: string
  userTitleColor?: string
  userTitleBgColor?: string
  createTime: string
  replies?: CommunityComment[]
}

export interface CommunityDraft {
  id: number
  userId: number
  sectionId: number
  title: string
  content: string
  images: string[]
  tags: string[]
  officialTags: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  createTime: string
  updateTime: string
}

export interface BannedUser {
  id: number
  userId: number
  userName: string
  reason: string
  bannedUntil: string
  createTime: string
}

export function fetchCommunitySections(all?: boolean) {
  const q = all ? '?all=true' : ''
  return request.get({ url: `/api/community/sections${q}` })
}

export function fetchCommunitySection(id: number) {
  return request.get({ url: `/api/community/section/${id}` })
}

export function createCommunitySection(data: { name: string; icon?: string; iconBgColor?: string; description?: string; sortOrder?: number; status?: string }) {
  return request.post({ url: '/api/community/section', data })
}

export function updateCommunitySection(id: number, data: Record<string, unknown>) {
  return request.post({ url: '/api/community/section', data: { ...data, id } })
}

export function deleteCommunitySection(id: number) {
  return request.del({ url: `/api/community/section/${id}` })
}

export function uploadCommunityImage(file: File) {
  const formData = new FormData()
  formData.append('file', file)
  return request.post({ url: '/api/community/upload-image', data: formData, headers: { 'Content-Type': 'multipart/form-data' } })
}

export function deleteCommunityImage(url: string) {
  return request.post({ url: '/api/community/delete-image', data: { url } })
}

export function fetchCommunityPosts(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/posts', params })
}

export function fetchCommunityPost(id: number, userId?: number) {
  const q = userId ? `?userId=${userId}` : ''
  return request.get({ url: `/api/community/post/${id}${q}` })
}

export function createCommunityPost(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/post', data })
}

export function updateCommunityPost(id: number, data: Record<string, unknown>) {
  return request.put({ url: `/api/community/post/${id}`, data })
}

export function deleteCommunityPost(id: number, userId: number) {
  return request.del({ url: `/api/community/post/${id}`, data: { userId } })
}

export function likePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/like`, data: { userId } })
}

export function favoritePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/favorite`, data: { userId } })
}

export function fetchUserFavorites(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/user/favorites', params })
}

export function pinPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/pin`, data: { userId } })
}

export function globalPinPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/global-pin`, data: { userId } })
}

export function setCustomBadge(id: number, badge: string) {
  return request.post({ url: `/api/community/post/${id}/custom-badge`, data: { badge } })
}

export function essencePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/essence`, data: { userId } })
}

export function hotPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/hot`, data: { userId } })
}

export function lockPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/lock`, data: { userId } })
}

export function sendCoin(id: number, data: { userId: number; amount: number; coinType?: string }) {
  return request.post({ url: `/api/community/post/${id}/coin`, data })
}

export function fetchCoinLogs(id: number, page = 1) {
  return request.get({ url: `/api/community/post/${id}/coin-logs`, params: { page, pageSize: 50 } })
}

export function fetchComments(postId: number, params: Record<string, unknown>) {
  return request.get({ url: `/api/community/post/${postId}/comments`, params })
}

export function fetchPostComments(params: Record<string, unknown>) {
  return fetchComments(params.postId as number, params)
}

export function postComment(postId: number, data: Record<string, unknown>) {
  return request.post({ url: `/api/community/post/${postId}/comment`, data })
}

export function createPostComment(data: Record<string, unknown>) {
  return postComment(data.postId as number, data)
}

export function deleteComment(id: number, userId: number) {
  return request.del({ url: `/api/community/comment/${id}`, data: { userId } })
}

export function likeComment(commentId: number) {
  return request.post({ url: `/api/community/comment/${commentId}/like` })
}

export function pinComment(id: number) {
  return request.post({ url: `/api/community/comment/${id}/pin` })
}

export function fetchDrafts(userId: number) {
  return request.get({ url: '/api/community/drafts', params: { userId } })
}

export function fetchMyPosts(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/posts', params })
}

export function saveDraft(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/draft', data })
}

export function deleteDraft(id: number, userId: number) {
  return request.del({ url: `/api/community/draft/${id}`, data: { userId } })
}

export function fetchAdminPosts(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/admin/posts', params })
}

export function updatePostStatus(id: number, data: { userId: number; status: string }) {
  return request.put({ url: `/api/community/admin/post/${id}/status`, data })
}

export function banUser(data: { userId: number; targetUserId: number; reason?: string; duration?: number }) {
  return request.post({ url: '/api/community/admin/ban', data })
}

export function unbanUser(userId: number, targetUserId: number) {
  return request.post({ url: '/api/community/admin/unban', data: { userId, targetUserId } })
}

export function fetchBannedUsers(userId: number) {
  return request.get({ url: '/api/community/admin/banned', params: { userId } })
}

export function fetchModerators(sectionId: number) {
  return request.get({ url: `/api/community/section/${sectionId}/moderators` })
}

export function addModerator(sectionId: number, data: { userId: number; userName: string; userAvatar?: string; role?: string }) {
  return request.post({ url: `/api/community/section/${sectionId}/moderator`, data })
}

export function removeModerator(sectionId: number, userId: number) {
  return request.del({ url: `/api/community/section/${sectionId}/moderator/${userId}` })
}

export function applyForModerator(sectionId: number, data: { reason?: string; desiredRole?: string }) {
  return request.post({ url: `/api/community/section/${sectionId}/apply`, data })
}

export function fetchMyApplication(sectionId: number) {
  return request.get({ url: `/api/community/section/${sectionId}/my-application` })
}

export function fetchModeratorApplications(sectionId?: number) {
  if (sectionId) return request.get({ url: `/api/community/section/${sectionId}/applications` })
  return request.get({ url: '/api/community/applications' })
}

export function approveApplication(id: number, role?: string) {
  return request.post({ url: `/api/community/application/${id}/approve`, data: { role } })
}

export function rejectApplication(id: number, reason?: string) {
  return request.post({ url: `/api/community/application/${id}/reject`, data: { reason } })
}

export function fetchUserModeratorSections(userId: number) {
  return request.get({ url: `/api/community/user/${userId}/moderator-sections` })
}

export function fetchPendingPosts(page = 1, pageSize = 20) {
  return request.get({ url: '/api/community/admin/posts/pending', params: { page, pageSize } })
}

export function approvePost(postId: number) {
  return request.post({ url: `/api/community/admin/post/${postId}/approve` })
}

export function rejectPost(postId: number, reason: string) {
  return request.post({ url: `/api/community/admin/post/${postId}/reject`, data: { reason } })
}

export function searchUsers(keyword: string) {
  return request.get({ url: '/api/community/user/search', params: { keyword } })
}

export function reportPost(postId: number, reason?: string, detail?: string) {
  return request.post({ url: `/api/community/post/${postId}/report`, data: { reportReason: reason, reportDetail: detail } })
}

export function reportComment(commentId: number, reason?: string, detail?: string) {
  return request.post({ url: `/api/community/comment/${commentId}/report`, data: { reportReason: reason, reportDetail: detail } })
}

export function requestUnlock(postId: number, reason?: string) {
  return request.post({ url: `/api/community/post/${postId}/request-unlock`, data: { reason } })
}

export function fetchUnlockRequests() {
  return request.get({ url: '/api/community/admin/unlock-requests' })
}

export function handleUnlockRequest(id: number, action: string, reply?: string) {
  return request.post({ url: `/api/community/admin/unlock-request/${id}/handle`, data: { action, reply } })
}

export function fetchReports() {
  return request.get({ url: '/api/community/admin/reports' })
}

export function ignoreReport(id: number) {
  return request.post({ url: `/api/community/admin/report/ignore/${id}` })
}

export function deleteReportPost(postId: number) {
  return request.del({ url: `/api/community/admin/report/post/${postId}` })
}

export function deleteReportComment(commentId: number) {
  return request.del({ url: `/api/community/admin/report/comment/${commentId}` })
}

export function fetchTopics(params?: Record<string, unknown>) {
  return request.get({ url: '/api/community/topics', params })
}

export function fetchTopicDetail(id: number) {
  return request.get({ url: `/api/community/topics/${id}` })
}

export function createTopic(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/topics', data })
}

export function updateTopic(id: number, data: Record<string, unknown>) {
  return request.put({ url: `/api/community/topics/${id}`, data })
}

export function deleteTopic(id: number) {
  return request.del({ url: `/api/community/topics/${id}` })
}

export function fetchTopicConfig() {
  return request.get({ url: '/api/community/topics/config' })
}

export function updateTopicConfig(data: Record<string, unknown>) {
  return request.put({ url: '/api/community/topics/config', data })
}

export function fetchTopicPosts(id: number, params?: Record<string, unknown>) {
  return request.get({ url: `/api/community/topics/${id}/posts`, params })
}

export function followTopic(id: number) {
  return request.post({ url: `/api/community/topics/${id}/follow` })
}

export function unfollowTopic(id: number) {
  return request.del({ url: `/api/community/topics/${id}/follow` })
}

export function checkTopicFollow(id: number) {
  return request.get({ url: `/api/community/topics/${id}/follow` })
}

export function fetchTopicFollowers(id: number, params?: Record<string, unknown>) {
  return request.get({ url: `/api/community/topics/${id}/followers`, params })
}

export function fetchMembershipLevels() {
  return request.get({ url: '/api/membership/levels' })
}

export function fetchExperienceLevels() {
  return request.get({ url: '/api/operation/experience-level/list' })
}

// ============ 合集相关 API ============

export interface CommunityCollection {
  id: number
  userId: number
  userName: string
  userAvatar: string
  title: string
  description: string
  coverImage: string
  postCount: number
  status: string
  isPaid: boolean
  price: number
  previewCount: number
  viewCount: number
  subscribeCount: number
  sortMode: string
  sectionId: number
  createTime: string
  updateTime: string
}

export interface CollectionPost {
  sortOrder: number
  isPreview: boolean
  postId: number
  id: number
  title: string
  postStatus: string
  postUserId: number
  postUserName: string
  viewCount: number
  commentCount: number
  likeCount: number
  summary: string
  postCreateTime: string
  invalid?: boolean
  invalidReason?: string
}

export interface CollectionDetail extends CommunityCollection {
  posts: CollectionPost[]
  isAuthor: boolean
  hasPaid: boolean
  hidden: boolean
  reason?: string
}

export function createCollection(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/collection', data })
}

export function updateCollection(id: number, data: Record<string, unknown>) {
  return request.put({ url: `/api/community/collection/${id}`, data })
}

export function deleteCollection(id: number) {
  return request.del({ url: `/api/community/collection/${id}` })
}

export function fetchCollection(id: number) {
  return request.get({ url: `/api/community/collection/${id}` })
}

export function fetchMyCollections(params?: Record<string, unknown>) {
  return request.get({ url: '/api/community/collection/mine', params })
}

export function fetchUserCollections(userId: number, params?: Record<string, unknown>) {
  return request.get({ url: `/api/community/collection/user/${userId}`, params })
}

export function fetchPaidCollections(params?: Record<string, unknown>) {
  return request.get({ url: '/api/community/collection/paid', params })
}

export function addPostsToCollection(id: number, postIds: number[], isPreview?: boolean) {
  return request.post({ url: `/api/community/collection/${id}/posts`, data: { postIds, isPreview } })
}

export function removePostsFromCollection(id: number, postIds: number[]) {
  return request.del({ url: `/api/community/collection/${id}/posts`, data: { postIds } })
}

export function sortCollectionPosts(id: number, sortedPostIds: number[]) {
  return request.put({ url: `/api/community/collection/${id}/posts/sort`, data: { sortedPostIds } })
}

export function setPostPreview(collectionId: number, postId: number, isPreview: boolean) {
  return request.put({ url: `/api/community/collection/${collectionId}/posts/${postId}/preview`, data: { isPreview } })
}

export function buyCollection(id: number, payType: 'balance' | 'points' = 'balance') {
  return request.post({ url: `/api/community/collection/${id}/buy`, data: { payType } })
}

export function checkCollectionPaid(id: number) {
  return request.get({ url: `/api/community/collection/${id}/check-paid` })
}

export function fetchPostCollection(postId: number) {
  return request.get({ url: `/api/community/post/${postId}/collection` })
}

export function fetchFeaturedCollections(params?: Record<string, unknown>) {
  return request.get({ url: '/api/community/collections/featured', params })
}
