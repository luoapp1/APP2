import { ref } from 'vue'

export function useToast() {
  const toastMsg = ref('')
  const toastType = ref<'success' | 'error' | 'info'>('success')
  let toastTimer: ReturnType<typeof setTimeout> | null = null

  function showToast(msg: string, type: 'success' | 'error' | 'info' = 'success', duration = 2000) {
    toastMsg.value = msg
    toastType.value = type
    if (toastTimer) clearTimeout(toastTimer)
    toastTimer = setTimeout(() => {
      toastMsg.value = ''
    }, duration)
  }

  return { toastMsg, toastType, showToast }
}
