import { ref, computed } from 'vue'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

export interface CurrencySetting {
  id: number
  currency_key: string
  display_name: string
  display_icon: string
  display_symbol: string
  decimal_places: number
  sort_order: number
  is_visible: number
  is_exchangeable: number
  description: string
}

export interface CurrencyBalance {
  currency_key: string
  display_name: string
  display_symbol: string
  decimal_places: number
  available: number
  frozen: number
  total: number
}

export function useCurrency() {
  const settings = ref<CurrencySetting[]>([])
  const balances = ref<CurrencyBalance[]>([])
  const loaded = ref(false)
  const loading = ref(false)

  const visibleSettings = computed(() =>
    settings.value.filter(s => s.is_visible === 1).sort((a, b) => a.sort_order - b.sort_order)
  )

  const balanceMap = computed(() => {
    const map: Record<string, CurrencyBalance> = {}
    for (const b of balances.value) {
      map[b.currency_key] = b
    }
    return map
  })

  const balance = computed(() => balanceMap.value.balance?.available || 0)
  const points = computed(() => balanceMap.value.points?.available || 0)
  const experience = computed(() => balanceMap.value.experience?.available || 0)

  async function load() {
    if (loaded.value || loading.value) return
    loading.value = true
    try {
      const [settingsRes, balancesRes] = await Promise.all([
        request.get({ url: '/api/currency-settings' }),
        request.get({ url: '/api/user/currency-balance' }),
      ])
      settings.value = Array.isArray(settingsRes) ? settingsRes : (settingsRes?.data || [])

      let currencyList = balancesRes?.currencies || balancesRes?.data?.currencies || balancesRes?.data || []
      if (currencyList && !Array.isArray(currencyList)) {
        currencyList = Object.values(currencyList)
      }
      balances.value = currencyList
      loaded.value = true
    } finally {
      loading.value = false
    }
  }

  function formatAmount(amount: number, currencyKey: string): string {
    const s = getSetting(currencyKey)
    if (!s) return String(amount)
    const fixed = amount.toFixed(s.decimal_places)
    return s.display_symbol ? `${s.display_symbol}${fixed}` : fixed
  }

  function getSetting(currencyKey: string): CurrencySetting | undefined {
    return settings.value.find(s => s.currency_key === currencyKey)
  }

  return {
    settings,
    balances,
    loaded,
    loading,
    visibleSettings,
    balanceMap,
    balance,
    points,
    experience,
    load,
    formatAmount,
    getSetting,
  }
}
