import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useLoginModalStore = defineStore('loginModal', () => {
  const show = ref(false)
  const pendingAction = ref<(() => void) | null>(null)

  function open(onSuccess?: () => void) {
    show.value = true
    if (onSuccess) {
      pendingAction.value = onSuccess
    }
  }

  function close() {
    show.value = false
    pendingAction.value = null
  }

  function onLoginSuccess() {
    show.value = false
    const action = pendingAction.value
    pendingAction.value = null
    if (action) {
      action()
    }
  }

  return { show, open, close, onLoginSuccess }
})
