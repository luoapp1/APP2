import { defineStore } from 'pinia'
import { ref } from 'vue'

export type LoginModalPanel = 'sms' | 'pwd' | 'register'

export const useLoginModalStore = defineStore('loginModal', () => {
  const show = ref(false)
  const initialPanel = ref<LoginModalPanel>('sms')
  const pendingAction = ref<(() => void) | null>(null)

  function open(onSuccess?: () => void) {
    initialPanel.value = 'sms'
    show.value = true
    if (onSuccess) {
      pendingAction.value = onSuccess
    }
  }

  function openRegister(onSuccess?: () => void) {
    initialPanel.value = 'register'
    show.value = true
    if (onSuccess) {
      pendingAction.value = onSuccess
    }
  }

  function close() {
    show.value = false
    pendingAction.value = null
  }

  function onLoginSuccess() {
    show.value = false
    const action = pendingAction.value
    pendingAction.value = null
    if (action) {
      action()
    }
  }

  return { show, initialPanel, open, openRegister, close, onLoginSuccess }
})
