<template>
  <div class="empty-wrap">
    <slot name="icon" />
    <p class="empty-text">{{ text }}</p>
    <button v-if="actionText" class="btn btn-primary" @click="$emit('action')">{{ actionText }}</button>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  text: string
  actionText?: string
}>()

defineEmits<{
  action: []
}>()
</script>

<style scoped>
.empty-wrap {
  text-align: center;
  padding: 60px 0;
}
.empty-text {
  font-size: 14px;
  color: #999;
  margin: 0 0 12px;
}
.btn {
  display: inline-block;
  padding: 8px 20px;
  border-radius: 6px;
  font-size: 14px;
  border: 1px solid #ddd;
  background: #fff;
  cursor: pointer;
}
.btn-primary {
  background: #409eff;
  border-color: #409eff;
  color: #fff;
}
</style>
