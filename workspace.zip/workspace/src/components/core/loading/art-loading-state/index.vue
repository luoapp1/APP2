<template>
  <div class="loading-state">
    <div class="spin" />
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.loading-state {
  text-align: center;
  padding: 60px 0;
}
.spin {
  display: inline-block;
  width: 28px;
  height: 28px;
  border: 3px solid #e5e7eb;
  border-top-color: #409eff;
  border-radius: 50%;
  animation: art-spin 0.8s linear infinite;
}
@keyframes art-spin {
  to { transform: rotate(360deg); }
}
</style>
