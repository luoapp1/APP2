<template>
  <div class="err-wrap">
    <p class="err-text">{{ error }}</p>
    <button class="btn btn-primary" @click="$emit('retry')">{{ retryText }}</button>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  error: string
  retryText?: string
}>()

defineEmits<{
  retry: []
}>()
</script>

<style scoped>
.err-wrap {
  text-align: center;
  padding: 60px 0;
}
.err-text {
  font-size: 14px;
  color: #999;
  margin-bottom: 12px;
}
.btn {
  display: inline-block;
  padding: 8px 20px;
  border-radius: 6px;
  font-size: 14px;
  border: 1px solid #ddd;
  background: #fff;
  cursor: pointer;
}
.btn-primary {
  background: #409eff;
  border-color: #409eff;
  color: #fff;
}
</style>
