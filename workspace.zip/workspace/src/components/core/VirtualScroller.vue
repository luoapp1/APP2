<template>
  <div ref="containerRef" class="vs-container" @scroll="onScroll">
    <div ref="beforeRef" class="vs-before">
      <slot name="before" />
    </div>
    <div v-if="$slots['sticky-header']" ref="stickyHeaderRef" class="vs-sticky-header">
      <slot name="sticky-header" />
    </div>
    <div class="vs-spacer" :style="{ height: totalHeight + 'px' }" />
    <div v-if="$slots.footer" class="vs-footer">
      <slot name="footer" />
    </div>
    <div class="vs-viewport" :style="{ top: viewportTop + 'px', transform: `translateY(${offsetY}px)` }">
      <div
        v-for="item in visibleItems"
        :key="item.key"
        :ref="(el) => setItemRef(item.index, el)"
      >
        <slot :item="item.data" :index="item.index" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, nextTick, useSlots } from 'vue'

const slots = useSlots()

const props = withDefaults(defineProps<{
  items: any[]
  itemKey?: string
  estimatedHeight?: number
  preload?: number
  loadMoreThreshold?: number
}>(), {
  itemKey: 'id',
  estimatedHeight: 200,
  preload: 4,
  loadMoreThreshold: 400
})

const emit = defineEmits<{
  loadMore: []
}>()

const containerRef = ref<HTMLElement | null>(null)
const beforeRef = ref<HTMLElement | null>(null)
const stickyHeaderRef = ref<HTMLElement | null>(null)
const itemRefs = ref<Map<number, HTMLElement>>(new Map())
const sizes = ref<Map<number, number>>(new Map())
const containerHeight = ref(600)
const beforeHeight = ref(0)
const stickyHeaderHeight = ref(0)
const scrollTop = ref(0)
const observer = ref<ResizeObserver | null>(null)
const beforeObserver = ref<ResizeObserver | null>(null)
const stickyHeaderObserver = ref<ResizeObserver | null>(null)

const viewportTop = computed(() => beforeHeight.value + stickyHeaderHeight.value)

const effectiveScrollTop = computed(() => Math.max(0, scrollTop.value - viewportTop.value))

const totalHeight = computed(() => {
  let h = 0
  for (let i = 0; i < props.items.length; i++) {
    h += sizes.value.get(i) || props.estimatedHeight
  }
  return h
})

const startIndex = computed(() => {
  if (props.items.length === 0) return 0
  let offset = 0
  for (let i = 0; i < props.items.length; i++) {
    const h = sizes.value.get(i) || props.estimatedHeight
    if (offset + h > effectiveScrollTop.value) {
      return Math.max(0, i - props.preload)
    }
    offset += h
  }
  return Math.max(0, props.items.length - 1)
})

const endIndex = computed(() => {
  let offset = 0
  for (let i = 0; i < props.items.length; i++) {
    offset += sizes.value.get(i) || props.estimatedHeight
    if (offset > effectiveScrollTop.value + containerHeight.value) {
      return Math.min(props.items.length, i + props.preload + 1)
    }
  }
  return props.items.length
})

const offsetY = computed(() => {
  let y = 0
  for (let i = 0; i < startIndex.value; i++) {
    y += sizes.value.get(i) || props.estimatedHeight
  }
  return y
})

const visibleItems = computed(() => {
  return props.items.slice(startIndex.value, endIndex.value).map((data, i) => ({
    data,
    index: startIndex.value + i,
    key: data[props.itemKey] || startIndex.value + i
  }))
})

const visibleItemsHeight = computed(() => {
  let h = 0
  for (let i = startIndex.value; i < endIndex.value && i < props.items.length; i++) {
    h += sizes.value.get(i) || props.estimatedHeight
  }
  return h
})

function setItemRef(index: number, el: any) {
  if (el) {
    itemRefs.value.set(index, el instanceof HTMLElement ? el : el.$el || el)
  }
}

function measureItems() {
  itemRefs.value.forEach((el, index) => {
    if (el) {
      const h = el.offsetHeight
      if (h > 0 && sizes.value.get(index) !== h) {
        sizes.value.set(index, h)
      }
    }
  })
  itemRefs.value.clear()
}

function onScroll() {
  if (!containerRef.value) return
  scrollTop.value = containerRef.value.scrollTop

  const { scrollHeight, clientHeight } = containerRef.value
  if (scrollHeight - scrollTop.value - clientHeight < props.loadMoreThreshold) {
    emit('loadMore')
  }

  nextTick(() => measureItems())
}

onMounted(() => {
  if (!containerRef.value) return
  containerHeight.value = containerRef.value.clientHeight

  observer.value = new ResizeObserver(() => {
    if (containerRef.value) {
      containerHeight.value = containerRef.value.clientHeight
    }
  })
  observer.value.observe(containerRef.value)

  if (beforeRef.value) {
    beforeHeight.value = beforeRef.value.offsetHeight
    beforeObserver.value = new ResizeObserver(() => {
      if (beforeRef.value) {
        beforeHeight.value = beforeRef.value.offsetHeight
      }
    })
    beforeObserver.value.observe(beforeRef.value)
  }

  if (stickyHeaderRef.value) {
    stickyHeaderHeight.value = stickyHeaderRef.value.offsetHeight
    stickyHeaderObserver.value = new ResizeObserver(() => {
      if (stickyHeaderRef.value) {
        stickyHeaderHeight.value = stickyHeaderRef.value.offsetHeight
      }
    })
    stickyHeaderObserver.value.observe(stickyHeaderRef.value)
  }
})

onUnmounted(() => {
  observer.value?.disconnect()
  beforeObserver.value?.disconnect()
  stickyHeaderObserver.value?.disconnect()
})
</script>

<style scoped>
.vs-container {
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  position: relative;
  -webkit-overflow-scrolling: touch;
}

.vs-sticky-header {
  position: sticky;
  top: 0;
  z-index: 50;
}

.vs-viewport {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
}

.vs-footer {
}
</style>
