<template>
  <Teleport to="body">
    <Transition name="modal-fade">
      <div v-if="visible" class="fixed inset-0 z-[10000] flex items-end sm:items-center justify-center">
        <div class="absolute inset-0 bg-black/50" @click="() => {}" />
        <div class="relative bg-white w-full sm:w-[420px] sm:max-w-[95vw] sm:rounded-2xl rounded-t-2xl max-h-[85vh] flex flex-col animate-slide-up">
          <div class="px-5 py-4 border-b border-gray-100 flex items-center justify-between flex-shrink-0">
            <h3 class="text-base font-bold text-gray-800">{{ title }}</h3>
            <svg v-if="!required" class="w-5 h-5 text-gray-400 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="later">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </div>
          <div class="flex-1 overflow-y-auto px-5 py-4">
            <div v-if="loading" class="flex justify-center py-8">
              <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
            </div>
            <div v-else-if="content" class="text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none" v-html="content" />
            <div v-else class="text-sm text-gray-400 py-8 text-center">暂无内容</div>
          </div>
          <div class="px-5 py-4 border-t border-gray-100 flex-shrink-0 space-y-2">
            <button
              class="w-full h-11 rounded-full bg-[#FF4757] text-white text-sm font-medium active:opacity-85"
              :disabled="submitting"
              @click="agree"
            >{{ submitting ? '提交中...' : '我已阅读并同意' }}</button>
            <button
              v-if="!required"
              class="w-full h-11 rounded-full bg-gray-100 text-gray-500 text-sm font-medium active:opacity-75"
              @click="later"
            >稍后再说</button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const props = withDefaults(defineProps<{
  policyType?: string
  required?: boolean
}>(), {
  policyType: '',
  required: false
})

const emit = defineEmits(['agreed', 'later'])

const visible = ref(false)
const loading = ref(true)
const submitting = ref(false)
const title = ref('')
const content = ref('')
const type = ref('')

const typeLabels: Record<string, string> = {
  privacy: '隐私政策更新',
  agreement: '用户协议更新'
}

const loadPolicy = async (t: string) => {
  loading.value = true
  try {
    const res = await request.get({ url: '/api/policy/current', params: { type: t } })
    const d = res?.data
    if (d) {
      title.value = typeLabels[t] || d.title || '政策更新'
      content.value = d.content || ''
      type.value = t
    }
  } catch {} finally { loading.value = false }
}

const agree = async () => {
  submitting.value = true
  try {
    await request.post({ url: '/api/policy/consent', data: { type: type.value } })
    visible.value = false
    emit('agreed', type.value)
  } catch {} finally { submitting.value = false }
}

const later = () => {
  visible.value = false
  emit('later')
}

const checkAndShow = async () => {
  try {
    const res = await request.get({ url: '/api/policy/check-consent' })
    const data = res?.data || {}
    const types = props.policyType ? [props.policyType] : Object.keys(typeLabels)

    for (const t of types) {
      if (data[t] && !data[t].consented) {
        await loadPolicy(t)
        if (content.value) {
          visible.value = true
          return
        }
      }
    }
  } catch {}
}

onMounted(checkAndShow)

defineExpose({ checkAndShow, show: () => { visible.value = true }, hide: () => { visible.value = false } })
</script>

<style scoped>
.modal-fade-enter-active,
.modal-fade-leave-active {
  transition: all 0.25s ease;
}
.modal-fade-enter-from,
.modal-fade-leave-to {
  opacity: 0;
}
.animate-slide-up {
  animation: slideUp 0.3s ease;
}
@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
@media (min-width: 640px) {
  .animate-slide-up {
    animation: fadeIn 0.3s ease;
  }
  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
}
</style>
