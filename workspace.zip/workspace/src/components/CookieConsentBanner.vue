<template>
  <Teleport to="body">
    <Transition name="cookie-slide">
      <div v-if="visible" class="fixed bottom-0 left-0 right-0 z-[9999]">
        <div class="mx-3 mb-3 bg-white rounded-2xl shadow-[0_-4px_24px_rgba(0,0,0,0.12)] p-5">
          <h3 class="text-base font-bold text-gray-800 mb-2">{{ config.title }}</h3>
          <p class="text-sm text-gray-500 leading-relaxed mb-4">{{ config.content }}</p>

          <div v-if="showCategories && config.categories.length > 0" class="space-y-2 mb-4">
            <label v-for="cat in config.categories" :key="cat.key" class="flex items-center gap-3 py-1.5">
              <input
                type="checkbox"
                :checked="cat.required || selections.includes(cat.key)"
                :disabled="cat.required"
                class="w-4 h-4 accent-[#FF4757] rounded"
                @change="toggleCategory(cat.key)"
              />
              <div class="flex-1">
                <span class="text-sm text-gray-700">{{ cat.label }}</span>
                <span class="text-[11px] text-gray-400 ml-1">{{ cat.required ? '(必需)' : '' }}</span>
                <div class="text-[11px] text-gray-400">{{ cat.description }}</div>
              </div>
            </label>
          </div>

          <div class="flex gap-3">
            <button
              v-if="config.declineText"
              class="flex-1 h-10 rounded-full border border-gray-200 text-sm text-gray-500 font-medium active:bg-gray-50"
              @click="acceptEssential"
            >{{ config.declineText }}</button>
            <button
              class="flex-1 h-10 rounded-full bg-[#FF4757] text-white text-sm font-medium active:opacity-85"
              @click="acceptAll"
            >{{ config.agreeText }}</button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const visible = ref(false)
const showCategories = ref(false)
const selections = ref<string[]>([])
const config = reactive({
  title: 'Cookie 声明',
  content: '',
  agreeText: '同意全部',
  declineText: '仅必要',
  categories: [] as { key: string; label: string; description: string; required: boolean }[]
})

const toggleCategory = (key: string) => {
  const idx = selections.value.indexOf(key)
  if (idx >= 0) selections.value.splice(idx, 1)
  else selections.value.push(key)
}

const acceptAll = async () => {
  const all = config.categories.map(c => c.key)
  await sendConsent(all.length > 0 ? all : ['necessary'])
  visible.value = false
}

const acceptEssential = async () => {
  const essential = config.categories.filter(c => c.required).map(c => c.key)
  await sendConsent(essential.length > 0 ? essential : ['necessary'])
  visible.value = false
}

const sendConsent = async (categories: string[]) => {
  try {
    await request.post({ url: '/api/cookie-consent/accept', data: { categories } })
  } catch {}
}

onMounted(async () => {
  try {
    const statusRes = await request.get({ url: '/api/cookie-consent/status' })
    if (statusRes?.data?.consented) return
  } catch {}

  try {
    const cfgRes = await request.get({ url: '/api/cookie-consent/config' })
    const d = cfgRes?.data
    if (!d || !d.enabled) return
    config.title = d.title || 'Cookie 声明'
    config.content = d.content || ''
    config.agreeText = d.agreeText || '同意全部'
    config.declineText = d.declineText || '仅必要'
    config.categories = d.categories || []
    showCategories.value = config.categories.length > 0
    selections.value = config.categories.map(c => c.key)
    visible.value = true
  } catch {}
})
</script>

<style scoped>
.cookie-slide-enter-active,
.cookie-slide-leave-active {
  transition: all 0.3s ease;
}
.cookie-slide-enter-from,
.cookie-slide-leave-to {
  transform: translateY(100%);
  opacity: 0;
}
</style>
