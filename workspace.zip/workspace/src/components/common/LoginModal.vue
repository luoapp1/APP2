<template>
  <Teleport to="body">
    <Transition name="login-modal">
      <div v-if="loginModalStore.show" class="modal-overlay" @click.self="loginModalStore.close()">
        <div class="modal-card">
          <div class="modal-close" @click="loginModalStore.close()"></div>

          <Transition name="toast">
            <div v-if="toastMsg" class="modal-toast" @click="toastMsg = ''">{{ toastMsg }}</div>
          </Transition>

          <!-- 面板1：免密登录 -->
          <div v-if="panel === 'sms'" class="modal-panel">
            <h1 class="modal-title">登录</h1>
            <div class="modal-sub">
              没有账号？<a class="modal-link modal-link-pink" @click="panel = 'register'">立即注册 &gt;</a>
            </div>

            <div class="modal-input-group">
              <div class="modal-input-item" :class="{ 'modal-input-focus': smsInputFocus }">
                <input
                  v-model="smsForm.phone"
                  type="text"
                  placeholder="手机号或邮箱"
                  @input="onSmsInputChange"
                  @focus="smsInputFocus = true"
                  @blur="smsInputFocus = false"
                />
              </div>
              <div v-if="smsCodeVisible" class="modal-input-code-row">
                <input
                  v-model="smsForm.code"
                  type="text"
                  placeholder="验证码"
                  maxlength="6"
                />
                <button class="modal-send-code-btn" :disabled="smsCountdown > 0" @click="sendSmsCode">
                  {{ smsCountdown > 0 ? `${smsCountdown}s` : '发送验证码' }}
                </button>
              </div>
            </div>

            <div class="modal-row">
              <label class="modal-checkbox">
                <input type="checkbox" v-model="smsForm.remember" checked />
                <span>记住登录</span>
              </label>
              <a class="modal-link" @click="panel = 'pwd'">账号密码登录</a>
            </div>

            <button class="modal-btn modal-btn-login" :disabled="smsLoading" @click="handleSmsSubmit">
              <span>&#8680;</span> {{ smsLoading ? '登录中...' : '登录' }}
            </button>
          </div>

          <!-- 面板2：账号密码登录 -->
          <div v-if="panel === 'pwd'" class="modal-panel">
            <template v-if="!showForgotPwd">
              <h1 class="modal-title">登录</h1>
              <div class="modal-sub">
                没有账号？<a class="modal-link modal-link-pink" @click="panel = 'register'">立即注册 &gt;</a>
              </div>

              <div class="modal-input-item">
                <input
                  v-model="pwdForm.username"
                  type="text"
                  placeholder="用户名/手机号/邮箱"
                  @keyup.enter="handlePwdLogin"
                />
              </div>
              <div class="modal-input-item">
                <div class="modal-pwd-wrap">
                  <input
                    v-model="pwdForm.password"
                    :type="showPwd ? 'text' : 'password'"
                    placeholder="登录密码"
                    @keyup.enter="handlePwdLogin"
                  />
                  <svg class="modal-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" @click="showPwd = !showPwd">
                    <template v-if="showPwd">
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                      <line x1="1" y1="1" x2="23" y2="23"/>
                    </template>
                    <template v-else>
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                      <circle cx="12" cy="12" r="3"/>
                    </template>
                  </svg>
                </div>
              </div>

              <div class="modal-row">
                <label class="modal-checkbox">
                  <input type="checkbox" v-model="pwdForm.remember" checked />
                  <span>记住登录</span>
                </label>
                <div class="modal-row-links">
                  <a class="modal-link" @click="showForgotPwd = true">找回密码</a>
                  <a class="modal-link" @click="panel = 'sms'">免密登录</a>
                </div>
              </div>

              <button class="modal-btn modal-btn-login" :disabled="pwdLoading" @click="handlePwdLogin">
                <span>&#8680;</span> {{ pwdLoading ? '登录中...' : '登录' }}
              </button>
            </template>

            <template v-else>
              <h1 class="modal-title">找回密码</h1>
              <div class="modal-sub">
                <a class="modal-link" @click="showForgotPwd = false">&lt; 返回登录</a>
              </div>

              <div class="modal-input-group">
                <div class="modal-input-item" :class="{ 'modal-input-focus': resetInputFocus }">
                  <input
                    v-model="resetForm.email"
                    type="text"
                    placeholder="请输入注册邮箱"
                    @focus="resetInputFocus = true"
                    @blur="resetInputFocus = false"
                  />
                </div>
                <div class="modal-input-code-row">
                  <input
                    v-model="resetForm.code"
                    type="text"
                    placeholder="验证码"
                    maxlength="6"
                  />
                  <button class="modal-send-code-btn" :disabled="resetCountdown > 0" @click="sendResetCode">
                    {{ resetCountdown > 0 ? `${resetCountdown}s` : '发送验证码' }}
                  </button>
                </div>
                <div class="modal-input-item">
                  <div class="modal-pwd-wrap">
                    <input
                      v-model="resetForm.password"
                      :type="showResetPwd ? 'text' : 'password'"
                      placeholder="设置新密码"
                    />
                    <svg class="modal-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" @click="showResetPwd = !showResetPwd">
                      <template v-if="showResetPwd">
                        <path d="M1 1l22 22"/><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/>
                      </template>
                      <template v-else>
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                      </template>
                    </svg>
                  </div>
                </div>
              </div>

              <button class="modal-btn modal-btn-login" :disabled="resetLoading" @click="handleResetPassword" style="margin-top:20px">
                {{ resetLoading ? '重置中...' : '重置密码' }}
              </button>
            </template>
          </div>

          <!-- 面板3：注册 -->
          <div v-if="panel === 'register'" class="modal-panel">
            <h1 class="modal-title">注册</h1>
            <div class="modal-sub">
              已有账号，<a class="modal-link modal-link-pink" @click="panel = 'sms'">立即登录 &gt;</a>
            </div>

            <div class="modal-input-item">
              <input
                v-model="regForm.username"
                type="text"
                placeholder="输入账号"
              />
            </div>
            <div class="modal-input-item">
              <input
                v-model="regForm.email"
                type="text"
                placeholder="手机号或邮箱"
              />
            </div>
            <div v-if="regForm.email" class="modal-input-item">
              <div class="modal-input-code-row">
                <input
                  v-model="regForm.verifyCode"
                  type="text"
                  :placeholder="/@/.test(regForm.email) ? '请输入邮箱验证码' : '请输入短信验证码'"
                  maxlength="6"
                />
                <button
                  class="modal-send-code-btn"
                  :disabled="regCountdown > 0 || !regForm.email"
                  @click="sendRegCode"
                >{{ regCountdown > 0 ? regCountdown + 's' : '发送验证码' }}</button>
              </div>
            </div>
            <div class="modal-input-item">
              <div class="modal-pwd-wrap">
                <input
                  v-model="regForm.password"
                  :type="showRegPwd ? 'text' : 'password'"
                  placeholder="设置密码"
                />
                <svg
                  class="modal-eye"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  @click="showRegPwd = !showRegPwd"
                >
                  <template v-if="showRegPwd">
                    <path d="M1 1l22 22"/>
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
                    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
                    <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/>
                  </template>
                  <template v-else>
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </template>
                </svg>
              </div>
            </div>

            <div class="modal-input-item">
              <input
                v-model="regForm.inviteCode"
                type="text"
                :placeholder="inviteRequired ? '邀请码（必填）' : '邀请码（选填）'"
              />
            </div>

            <button class="modal-btn modal-btn-register" :disabled="regLoading" @click="handleRegister" style="margin-top:20px">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
              {{ regLoading ? '注册中...' : '注册' }}
            </button>
            <div class="modal-tip" style="margin-top:24px">
              注册即表示同意<a class="modal-link modal-link-pink" href="javascript:void(0)">用户协议</a>
            </div>
          </div>

          <!-- 共享区域 -->
          <div v-if="panel !== 'register'">
            <div class="modal-divider">社交账号登录</div>
            <div class="modal-social-box">
              <button
                v-for="provider in allSocialProviders"
                :key="provider"
                class="modal-social-btn"
                :class="provider"
                @click="handleSocialClick(provider)"
              >
                <svg v-if="provider === 'github'" viewBox="0 0 24 24" fill="currentColor" width="18" height="18">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                <svg v-else-if="provider === 'google'" viewBox="0 0 24 24" width="18" height="18">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <svg v-else-if="provider === 'wechat'" viewBox="0 0 24 24" width="18" height="18">
                  <path fill="#fff" d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 01.213.665l-.39 1.48a.3.3 0 00.242.454l1.903-1.114a.864.864 0 01.717-.098 10.16 10.16 0 002.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178A1.17 1.17 0 014.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 01-1.162 1.178 1.17 1.17 0 01-1.162-1.178c0-.651.52-1.18 1.162-1.18z"/>
                  <path fill="#fff" d="M14.588 13.62c-3.106 0-5.74 2.3-5.74 5.19 0 2.89 2.634 5.19 5.74 5.19.425 0 .85-.04 1.263-.12l1.485.86c.072.04.165.05.233.02.069-.03.107-.1.087-.17l-.212-1.04c1.123-.87 1.886-2.12 1.886-3.54 0-2.89-2.633-5.38-5.742-5.38zm-2.506 3.61c.481 0 .871.39.871.87 0 .47-.39.86-.871.86s-.871-.39-.871-.86a.869.869 0 01.871-.87zm4.126 0c.482 0 .871.39.871.87 0 .47-.39.86-.871.86s-.871-.39-.871-.86a.87.87 0 01.871-.87z"/>
                </svg>
                <svg v-else-if="provider === 'qq'" viewBox="0 0 24 24" width="18" height="18">
                  <path fill="#fff" d="M18 16.5c-.5 1.2-2 2.5-3.5 2-1-.4-1.7-2-2.5-2-.8 0-1.5 1.6-2.5 2-1.5.5-3-.8-3.5-2-.8-1.8.2-3.5 1-4.5.3-.4.5-.6.5-1 0-.5-.2-1.2-.5-1.5-.5-.5-.8-.3-.8-.8 0-.5.7-.8 1.3-.8.8 0 1.5.3 2 .5.3.1.5.2.7.2.3 0 .5-.2 1-.2s.7.2 1 .2c.2 0 .4-.1.7-.2.5-.2 1.2-.5 2-.5.6 0 1.3.3 1.3.8 0 .5-.3.3-.8.8-.3.3-.5 1-.5 1.5 0 .4.2.6.5 1 .8 1 1.8 2.7 1 4.5z"/>
                </svg>
              </button>
            </div>
            <div class="modal-tip">
              使用社交账号登录即表示同意<a class="modal-link modal-link-pink" href="javascript:void(0)">用户协议</a>
            </div>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'
import { fetchLogin, fetchGetUserInfo } from '@/api/auth'
import { fetchSendEmailCode } from '@/api/email'
import request from '@/utils/http'

defineOptions({ name: 'LoginModal' })

const router = useRouter()
const userStore = useUserStore()
const loginModalStore = useLoginModalStore()

type Panel = 'sms' | 'pwd' | 'register'
const panel = ref<Panel>('sms')
const showPwd = ref(false)
const showRegPwd = ref(false)
const pwdLoading = ref(false)
const smsLoading = ref(false)
const smsCountdown = ref(0)
const smsInputFocus = ref(false)
const regLoading = ref(false)
const showForgotPwd = ref(false)
const resetLoading = ref(false)
const resetCountdown = ref(0)
const resetInputFocus = ref(false)
const showResetPwd = ref(false)
const resetForm = reactive({
  email: '',
  code: '',
  password: ''
})
const toastMsg = ref('')
let toastTimer: ReturnType<typeof setTimeout> | null = null

function showToast(msg: string) {
  toastMsg.value = msg
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 3000)
}

const isSmsEmail = computed(() => /@/.test(smsForm.phone))
const smsCodeVisible = computed(() => smsForm.phone.trim().length > 0)

const pwdForm = reactive({
  username: '',
  password: '',
  remember: true
})

const smsForm = reactive({
  phone: '',
  code: '',
  remember: true
})

const regForm = reactive({
  username: '',
  email: '',
  password: '',
  inviteCode: '',
  verifyCode: ''
})

const regCountdown = ref(0)
const inviteRequired = ref(false)

const saved = localStorage.getItem('login_remember')
if (saved) {
  try {
    const { username } = JSON.parse(saved)
    if (username) pwdForm.username = username
  } catch {}
}

const enabledProviders = ref<string[]>([])

const allSocialProviders = ['qq', 'wechat', 'github', 'google']

function handleSocialClick(provider: string) {
  if (enabledProviders.value.includes(provider)) {
    window.location.href = `/api/oauth/${provider}/login`
  } else {
    showToast('该登录方式暂未开启')
  }
}

onMounted(async () => {
  try {
    const res: any = await request.get({ url: '/api/oauth/providers' })
    enabledProviders.value = res?.data || res || []
  } catch {
    enabledProviders.value = []
  }
  try {
    const inviteRes: any = await request.get({ url: '/api/invite/config' })
    if (inviteRes?.data) {
      inviteRequired.value = inviteRes.data.register_invite_required === 'true'
    }
  } catch {}
})

watch(panel, (val) => {
  if (val === 'sms') {
    smsForm.phone = ''
    smsForm.code = ''
    smsCountdown.value = 0
  }
  showForgotPwd.value = false
})

async function handlePwdLogin() {
  if (!pwdForm.username || !pwdForm.password) return
  pwdLoading.value = true
  try {
    if (pwdForm.remember) {
      localStorage.setItem('login_remember', JSON.stringify({ username: pwdForm.username }))
    } else {
      localStorage.removeItem('login_remember')
    }

    const res: any = await fetchLogin({ userName: pwdForm.username, password: pwdForm.password })

    if (res.need2FA) {
      showToast('需要两步验证，请使用独立登录页面')
      return
    }

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    loginModalStore.onLoginSuccess()
  } catch (err: any) {
    showToast(err?.message || err?.msg || '登录失败')
  } finally {
    pwdLoading.value = false
  }
}

function onSmsInputChange() {
  // Auto-show/hide code area based on input (handled by computed)
}

async function sendSmsCode() {
  const value = smsForm.phone
  if (!value || smsCountdown.value > 0) return
  const isEmail = /@/.test(value)
  try {
    const url = isEmail ? '/api/email/send-code' : '/api/sms/send-code'
    const data = isEmail ? { email: value, type: 'login' } : { phone: value, type: 'login' }
    await request.post({ url, data })
    smsCountdown.value = 60
    const timer = setInterval(() => {
      smsCountdown.value--
      if (smsCountdown.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (err: any) {
    showToast(err?.message || '发送失败')
  }
}

async function handleSmsSubmit() {
  const value = smsForm.phone
  if (!value) return
  if (!smsForm.code) return
  smsLoading.value = true
  const isEmail = /@/.test(value)
  try {
    const res: any = await request.post({
      url: isEmail ? '/api/auth/email-login' : '/api/auth/sms-login',
      data: isEmail ? { email: value, code: smsForm.code } : { phone: value, code: smsForm.code }
    })

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    loginModalStore.onLoginSuccess()
  } catch (err: any) {
    showToast(err?.message || err?.msg || '登录失败')
  } finally {
    smsLoading.value = false
  }
}

async function sendResetCode() {
  if (!resetForm.email || resetCountdown.value > 0) return
  const isEmail = /@/.test(resetForm.email)
  if (!isEmail) { showToast('请输入有效的邮箱地址'); return }
  try {
    await request.post({
      url: '/api/email/send-code',
      data: { email: resetForm.email, type: 'password_reset' }
    })
    resetCountdown.value = 60
    const timer = setInterval(() => {
      resetCountdown.value--
      if (resetCountdown.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (err: any) {
    showToast(err?.message || '发送失败')
  }
}

async function handleResetPassword() {
  if (!resetForm.email || !resetForm.code || !resetForm.password) return
  if (resetForm.password.length < 6) { showToast('密码至少6位'); return }
  resetLoading.value = true
  try {
    await request.post({
      url: '/api/auth/reset-password',
      data: { email: resetForm.email, code: resetForm.code, password: resetForm.password }
    })
    showToast('密码重置成功，请重新登录')
    showForgotPwd.value = false
    resetForm.email = ''
    resetForm.code = ''
    resetForm.password = ''
    resetCountdown.value = 0
  } catch (err: any) {
    showToast(err?.message || '重置失败')
  } finally {
    resetLoading.value = false
  }
}

async function sendRegCode() {
  const value = regForm.email
  if (!value || regCountdown.value > 0) return
  const isEmail = /@/.test(value)
  try {
    const url = isEmail ? '/api/email/send-code' : '/api/sms/send-code'
    const data = isEmail ? { email: value, type: 'register' } : { phone: value, type: 'register' }
    await request.post({ url, data })
    regCountdown.value = 60
    const timer = setInterval(() => {
      regCountdown.value--
      if (regCountdown.value <= 0) clearInterval(timer)
    }, 1000)
    showToast('验证码已发送')
  } catch (err: any) {
    const msg = err?.message || '发送失败'
    if (/60.*秒|稍后.*试|频繁|rate/i.test(msg)) {
      regCountdown.value = parseInt((msg.match(/\d+/) || ['60'])[0]) || 60
      const timer = setInterval(() => {
        regCountdown.value--
        if (regCountdown.value <= 0) clearInterval(timer)
      }, 1000)
      return
    }
    showToast(msg)
  }
}

async function handleRegister() {
  if (!regForm.username || !regForm.email || !regForm.password) return
  if (inviteRequired.value && !regForm.inviteCode) {
    showToast('请填写邀请码')
    return
  }
  regLoading.value = true
  try {
    const isEmail = /@/.test(regForm.email)
    await request.post({
      url: '/api/auth/register',
      data: {
        username: regForm.username,
        password: regForm.password,
        inviteCode: regForm.inviteCode || undefined,
        email: isEmail ? regForm.email : undefined,
        emailCode: isEmail ? (regForm.verifyCode || undefined) : undefined,
        phone: !isEmail ? regForm.email : undefined,
        smsCode: !isEmail ? (regForm.verifyCode || undefined) : undefined
      }
    })

    const loginRes: any = await fetchLogin({ userName: regForm.username, password: regForm.password })
    userStore.setToken(loginRes.token, loginRes.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    loginModalStore.onLoginSuccess()
  } catch (err: any) {
    showToast(err?.message || err?.msg || '注册失败')
  } finally {
    regLoading.value = false
  }
}

</script>

<style scoped>
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.modal-card {
  position: relative;
  width: 100%;
  max-width: 340px;
  max-height: 90vh;
  overflow-y: auto;
  background: #fff;
  border-radius: 14px;
  padding: 20px 20px;
}

.modal-close {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 28px;
  height: 28px;
  cursor: pointer;
  opacity: 0.6;
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal-close:hover {
  opacity: 1;
}
.modal-close::before,
.modal-close::after {
  content: '';
  position: absolute;
  width: 18px;
  height: 2px;
  background: #666;
  top: 13px;
  left: 5px;
}
.modal-close::before {
  transform: rotate(45deg);
}
.modal-close::after {
  transform: rotate(-45deg);
}
.modal-close:hover {
  opacity: 1;
}
.modal-close::before,
.modal-close::after {
  content: '';
  position: absolute;
  width: 16px;
  height: 2px;
  background: #666;
  top: 9px;
  left: 2px;
}
.modal-close::before {
  transform: rotate(45deg);
}
.modal-close::after {
  transform: rotate(-45deg);
}

.modal-title {
  font-size: 28px;
  font-weight: 500;
  color: #333;
  margin-bottom: 6px;
  position: relative;
}
.modal-title::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: -8px;
  width: 48px;
  height: 2px;
  background: #ff3488;
  border-radius: 2px;
}

.modal-sub {
  font-size: 13px;
  color: #666;
  margin: 14px 0 22px;
}

.modal-link {
  color: #555;
  cursor: pointer;
  text-decoration: none;
  font-size: 12px;
  transition: color 0.15s;
}
.modal-link:hover {
  color: #333;
}
.modal-link-pink {
  color: #ff3488;
}
.modal-link-pink:hover {
  color: #e03078;
}

.modal-input-item {
  border-bottom: 1px solid #eee;
  padding: 6px 0;
  margin-bottom: 8px;
}
.modal-input-item input {
  width: 100%;
  border: none;
  outline: none;
  font-size: 14px;
  color: #333;
  background: transparent;
}
.modal-input-item input::placeholder {
  color: #bbb;
}

.modal-input-focus {
  border-bottom: 2px solid #ff3488;
}

.modal-input-group {
  margin-bottom: 0;
}

.modal-input-code-row {
  display: flex;
  align-items: center;
  gap: 10px;
  border-bottom: 1px solid #eee;
  padding: 6px 0;
  margin-bottom: 10px;
}
.modal-input-code-row input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 14px;
  background: transparent;
}
.modal-input-code-row input::placeholder {
  color: #bbb;
}

.modal-send-code-btn {
  background: #e8f4ff;
  color: #2196f3;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  white-space: nowrap;
  cursor: pointer;
  transition: background 0.15s;
}
.modal-send-code-btn:hover {
  background: #d0eaff;
}
.modal-send-code-btn:disabled {
  background: #f0f0f0;
  color: #ccc;
  cursor: not-allowed;
}
.modal-input-item input::placeholder {
  color: #bbb;
}

.modal-pwd-wrap {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.modal-pwd-wrap input {
  flex: 1;
}
.modal-eye {
  width: 18px;
  height: 18px;
  color: #aaa;
  cursor: pointer;
  flex-shrink: 0;
}
.modal-eye:hover {
  color: #666;
}

.modal-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 12px 0 20px;
}
.modal-row-links {
  display: flex;
  gap: 8px;
}

.modal-checkbox {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  color: #555;
  cursor: pointer;
}
.modal-checkbox input[type='checkbox'] {
  width: 16px;
  height: 16px;
  accent-color: #ff3488;
}

.modal-btn {
  width: 100%;
  height: 42px;
  border-radius: 999px;
  border: none;
  font-size: 15px;
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: opacity 0.2s;
}
.modal-btn:hover {
  opacity: 0.9;
}
.modal-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.modal-btn-login {
  background: linear-gradient(90deg, #42aaff, #2396f3);
}
.modal-btn-register {
  background: #38d468;
}

.modal-divider {
  margin: 26px 0 20px;
  text-align: center;
  color: #999;
  font-size: 12px;
  position: relative;
}
.modal-divider::before,
.modal-divider::after {
  content: '';
  position: absolute;
  top: 50%;
  width: 32%;
  height: 1px;
  background: #eee;
}
.modal-divider::before {
  left: 0;
}
.modal-divider::after {
  right: 0;
}

.modal-social-box {
  display: flex;
  justify-content: center;
  gap: 12px;
  margin-bottom: 20px;
}

.modal-social-btn {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  cursor: pointer;
  transition: transform 0.15s, opacity 0.15s;
}
.modal-social-btn:hover {
  transform: scale(1.08);
  opacity: 0.9;
}
.modal-social-btn.qq {
  background: #13b8f6;
}
.modal-social-btn.wechat {
  background: #3ac558;
}
.modal-social-btn.github {
  background: #333;
}
.modal-social-btn.google {
  background: #fff;
  border: 1px solid #e0e0e0;
  color: #333;
}

.modal-tip {
  text-align: center;
  font-size: 12px;
  color: #999;
}

.modal-toast {
  position: absolute;
  top: 56px;
  left: 20px;
  right: 20px;
  background: rgba(0, 0, 0, 0.78);
  color: #fff;
  font-size: 13px;
  text-align: center;
  padding: 10px 16px;
  border-radius: 8px;
  z-index: 10;
  cursor: pointer;
  line-height: 1.4;
  pointer-events: auto;
}

/* Toast transition */
.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}
.toast-enter-from,
.toast-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}

/* Transition */
.login-modal-enter-active,
.login-modal-leave-active {
  transition: opacity 0.25s ease;
}
.login-modal-enter-active .modal-card,
.login-modal-leave-active .modal-card {
  transition: transform 0.25s ease, opacity 0.25s ease;
}
.login-modal-enter-from,
.login-modal-leave-to {
  opacity: 0;
}
.login-modal-enter-from .modal-card {
  transform: scale(0.92) translateY(20px);
  opacity: 0;
}
.login-modal-leave-to .modal-card {
  transform: scale(0.92) translateY(20px);
  opacity: 0;
}
</style>
