<template>
  <div class="tiptap-root" :class="{ 'tiptap-fullscreen': isFullscreen }">
    <div class="inline-toolbar" v-if="showToolbar">
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleBold().run()"
        :class="{ 'it-active': editor?.isActive('bold') }"
        title="粗体"
        ><strong>B</strong></button
      >
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleItalic().run()"
        :class="{ 'it-active': editor?.isActive('italic') }"
        title="斜体"
        ><em>I</em></button
      >
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleStrike().run()"
        :class="{ 'it-active': editor?.isActive('strike') }"
        title="删除线"
        ><s>S</s></button
      >
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleUnderline().run()"
        :class="{ 'it-active': editor?.isActive('underline') }"
        title="下划线"
        ><u>U</u></button
      >
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleHighlight().run()"
        :class="{ 'it-active': editor?.isActive('highlight') }"
        title="高亮"
        ><span style="background: #fef08a; padding: 0 2px">H</span></button
      >
      <button
        class="it-color-btn"
        @mousedown.prevent
        @click.stop
        @click="toggleColorPicker"
        title="文字颜色"
      >
        <span class="it-color-swatch" :style="{ background: currentColor }">A</span>
        <input
          ref="colorInput"
          type="color"
          class="it-color-popup"
          @input="setTextColor(($event.target as HTMLInputElement).value)"
          @mousedown.stop
        />
      </button>
      <select
        class="it-font-select"
        @mousedown.stop
        @change="setFontFamily(($event.target as HTMLSelectElement).value)"
        title="字体"
      >
        <option value="">字体</option>
        <option value="SimSun, serif">宋体</option>
        <option value="SimHei, sans-serif">黑体</option>
        <option value="KaiTi, serif">楷体</option>
        <option value="'Microsoft YaHei', sans-serif">微软雅黑</option>
        <option value="'PingFang SC', sans-serif">苹方</option>
        <option value="FangSong, serif">仿宋</option>
        <option value="Arial, sans-serif">Arial</option>
        <option value="Georgia, serif">Georgia</option>
        <option value="'Courier New', monospace">等宽</option>
      </select>
      <span class="it-sep"></span>
      <button @mousedown.prevent @click="setFontSize('12px')" title="小号">A</button>
      <button @mousedown.prevent @click="setFontSize('16px')" title="中号"
        ><strong>A</strong></button
      >
      <button @mousedown.prevent @click="setFontSize('20px')" title="大号"
        ><strong style="font-size: 16px">A</strong></button
      >
      <span class="it-sep"></span>
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleSuperscript().run()"
        :class="{ 'it-active': editor?.isActive('superscript') }"
        title="上标"
        >x²</button
      >
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleSubscript().run()"
        :class="{ 'it-active': editor?.isActive('subscript') }"
        title="下标"
        >x₂</button
      >
      <span class="it-sep"></span>
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleTaskList().run()"
        :class="{ 'it-active': editor?.isActive('taskList') }"
        title="任务清单"
        >☑</button
      >
      <span class="it-sep"></span>
      <button
        @mousedown.prevent
        @click="editor?.chain().focus().toggleCodeBlock().run()"
        :class="{ 'it-active': editor?.isActive('codeBlockHighlight') }"
        title="代码块"
        >&lt;/&gt;</button
      >
      <span class="it-sep"></span>
      <button @mousedown.prevent @click="linkSet" title="链接">🔗</button>
      <span style="flex: 1"></span>
      <button
        @mousedown.prevent
        @click="togglePreviewViewport"
        :class="{ 'it-active': isPreview }"
        title="预览"
        >{{ isPreview ? '✎ 编辑' : '◉ 预览' }}</button
      >
      <button
        @mousedown.prevent
        @click="toggleMarkdownMode"
        :class="{ 'it-active': isMarkdownMode }"
        title="Markdown源码"
        >MD</button
      >
      <select
        v-if="isPreview"
        class="it-font-select"
        style="max-width: 70px"
        @mousedown.stop
        @change="previewViewport = ($event.target as HTMLSelectElement).value"
        title="预览视口"
      >
        <option value="pc">PC</option>
        <option value="mobile">手机</option>
      </select>
      <button @mousedown.prevent @click="beautifyContent" title="一键排版">✨</button>
      <button
        @mousedown.prevent
        @click="toggleFullscreen"
        :title="isFullscreen ? '退出全屏' : '全屏编辑'"
        >{{ isFullscreen ? '⛶' : '⛶' }}</button
      >
    </div>
    <div class="draft-banner" v-if="hasDraft && !draftRestored">
      <span>检测到未发布的草稿</span>
      <button class="db-restore-btn" @click="restoreDraft">恢复草稿</button>
      <button class="db-discard-btn" @click="discardDraft">丢弃</button>
    </div>
    <div
      ref="editorEl"
      class="tiptap-editor"
      @click="onEditorClick"
      :class="{
        'preview-mobile': isPreview && previewViewport === 'mobile',
        'preview-pc': isPreview && previewViewport === 'pc'
      }"
    ></div>
    <textarea
      v-if="isMarkdownMode"
      v-model="markdownText"
      class="markdown-source-editor"
      @input="onMarkdownInput"
      placeholder="输入 Markdown 内容..."
    ></textarea>
    <div class="editor-footer" v-if="editor">
      <span class="ef-draft" v-if="draftSaved">已保存草稿</span>
      <span class="ef-count">{{ charCount }} 字</span>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { ref, onMounted, onBeforeUnmount, shallowRef, nextTick, watch } from 'vue'
  import { Editor } from '@tiptap/core'

  import StarterKit from '@tiptap/starter-kit'
  import Highlight from '@tiptap/extension-highlight'
  import Underline from '@tiptap/extension-underline'
  import Image from '@tiptap/extension-image'
  import Placeholder from '@tiptap/extension-placeholder'
  import Subscript from '@tiptap/extension-subscript'
  import Superscript from '@tiptap/extension-superscript'
  import TextAlign from '@tiptap/extension-text-align'
  import Link from '@tiptap/extension-link'
  import TaskList from '@tiptap/extension-task-list'
  import TaskItem from '@tiptap/extension-task-item'
  import Dropcursor from '@tiptap/extension-dropcursor'
  import CharacterCount from '@tiptap/extension-character-count'
  import Youtube from '@tiptap/extension-youtube'
  import Mention from '@tiptap/extension-mention'

  import { VoteCard } from './extensions/vote-card'
  import { GoodsCard } from './extensions/goods-card'
  import { AudioBlock } from './extensions/audio-block'
  import { FileAttachment } from './extensions/file-attachment'
  import { NoticeBanner } from './extensions/notice-banner'
  import { UpdateLog } from './extensions/update-log'
  import { PasswordUnlock } from './extensions/password-unlock'
  import { GalleryBlock } from './extensions/gallery-block'
  import { OriginalStatement } from './extensions/original-statement'
  import { SourceQuote, FollowUnlock, CommentUnlock } from './extensions/social-unlocks'
  import { Paywall } from './extensions/paywall'
  import { MemberUnlock } from './extensions/member-unlock'
  import { ExperienceUnlock } from './extensions/experience-unlock'
  import { TitleUnlock } from './extensions/title-unlock'
  import { FontSize } from './extensions/font-size'
  import { TextColor } from './extensions/text-color'
  import { TextFont } from './extensions/text-font'
  import { CodeBlockHighlight } from './extensions/code-block-highlight'
  import { VideoEmbed } from './extensions/video-embed'
  import { DragHandle } from './extensions/drag-handle'
  import { PostRefCard } from './extensions/post-ref-card'
  import { LevelPrivilegeCard } from './extensions/level-privilege-card'
  import { Hashtag } from './extensions/hashtag'

  const props = defineProps<{ modelValue: any; placeholder?: string; draftExpireHours?: number }>()
  const emit = defineEmits<{ 'update:modelValue': [value: any]; 'hashtag-click': [tag: string] }>()

  const editorEl = ref<HTMLElement>()
  const colorInput = ref<HTMLInputElement>()
  const editor = shallowRef<Editor | null>(null)
  const showToolbar = ref(false)
  const charCount = ref(0)
  const currentColor = ref('#000000')
  const isFullscreen = ref(false)
  const isPreview = ref(false)
  const previewViewport = ref('pc')
  const isMarkdownMode = ref(false)
  const markdownText = ref('')
  const draftSaved = ref(false)
  const hasDraft = ref(false)
  const draftRestored = ref(true)
  const draftContent = ref('')

  function getDraftExpireMs() {
    return (props.draftExpireHours ?? 24) * 60 * 60 * 1000
  }

  function getDraftKey() {
    return 'draft_' + window.location.hash.replace(/[^a-zA-Z0-9]/g, '_')
  }

  function encodeContent(content: string): string {
    try {
      return btoa(unescape(encodeURIComponent(content)))
    } catch {
      return btoa(content)
    }
  }

  function decodeContent(encoded: string): string {
    try {
      return decodeURIComponent(escape(atob(encoded)))
    } catch {
      return atob(encoded)
    }
  }

  let draftTimer: ReturnType<typeof setTimeout> | null = null
  function autoSave(html: string) {
    if (draftTimer) clearTimeout(draftTimer)
    draftTimer = setTimeout(() => {
      try {
        const data = { content: encodeContent(html), time: Date.now() }
        localStorage.setItem(getDraftKey(), JSON.stringify(data))
        draftSaved.value = true
        setTimeout(() => {
          draftSaved.value = false
        }, 2000)
      } catch (_) {}
    }, 1500)
  }

  function loadDraft(): string | null {
    try {
      const raw = localStorage.getItem(getDraftKey())
      if (!raw) return null
      const data = JSON.parse(raw)
      if (data.time && Date.now() - data.time > getDraftExpireMs()) {
        localStorage.removeItem(getDraftKey())
        return null
      }
      return data.content ? decodeContent(data.content) : null
    } catch (_) {
      return null
    }
  }

  function clearDraft() {
    try {
      localStorage.removeItem(getDraftKey())
    } catch (_) {}
  }

  function clearAllDrafts() {
    try {
      const keys = Object.keys(localStorage).filter((k) => k.startsWith('draft_'))
      keys.forEach((k) => localStorage.removeItem(k))
    } catch (_) {}
  }

  function restoreDraft() {
    if (draftContent.value && editor.value) {
      editor.value.commands.setContent(draftContent.value)
    }
    draftRestored.value = true
    hasDraft.value = false
  }

  function discardDraft() {
    clearDraft()
    hasDraft.value = false
    draftRestored.value = true
  }

  function linkSet() {
    if (!editor.value) return
    const prev = editor.value.getAttributes('link').href || ''
    const url = window.prompt('链接地址', prev)
    if (url === null) return
    if (url === '') {
      editor.value.chain().focus().extendMarkRange('link').unsetLink().run()
      return
    }
    editor.value
      .chain()
      .focus()
      .extendMarkRange('link')
      .setLink({ href: /^https?:\/\//.test(url) ? url : 'https://' + url })
      .run()
  }

  function setFontSize(size: string) {
    editor.value?.chain().focus().setFontSize(size).run()
  }

  function setTextColor(color: string) {
    currentColor.value = color
    editor.value?.chain().focus().setTextColor(color).run()
  }

  function toggleColorPicker() {
    colorInput.value?.click()
  }

  function toggleFullscreen() {
    isFullscreen.value = !isFullscreen.value
    if (isFullscreen.value) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
  }

  function togglePreviewViewport() {
    isPreview.value = !isPreview.value
    if (editor.value) {
      editor.value.setEditable(!isPreview.value)
    }
  }

  function toggleMarkdownMode() {
    if (isMarkdownMode.value) {
      isMarkdownMode.value = false
      if (editor.value) {
        editor.value.setEditable(true)
      }
    } else {
      if (isPreview.value) {
        isPreview.value = false
      }
      if (editor.value) {
        markdownText.value = htmlToMarkdown(editor.value.getHTML())
        editor.value.setEditable(false)
      }
      isMarkdownMode.value = true
    }
  }

  function simpleMarkdownToHtml(md: string): string {
    let html = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    // Code blocks
    html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_: string, lang: string, code: string) => {
      return `<pre><code class="language-${lang || ''}">${code}</code></pre>`
    })
    // Headers
    html = html.replace(/^#### (.+)$/gm, '<h4>$1</h4>')
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>')
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>')
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>')
    // Bold/Italic
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Strikethrough
    html = html.replace(/~~(.+?)~~/g, '<s>$1</s>')
    // Links
    html = html.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>')
    // Images
    html = html.replace(
      /!\[(.+?)\]\((.+?)\)/g,
      '<img src="$2" alt="$1" style="max-width:100%;border-radius:8px;margin:8px 0;"  loading="lazy" />'
    )
    // Unordered lists
    html = html.replace(/^\- (.+)$/gm, '<li>$1</li>')
    html = html.replace(/(<li>.*<\/li>)/s, (match: string) => {
      if (match.includes('</li><li>')) return `<ul>${match}</ul>`
      return match
    })
    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>')
    // Blockquotes
    html = html.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
    // Horizontal rules
    html = html.replace(/^---$/gm, '<hr />')
    // Line breaks
    html = html.replace(/\n\n/g, '</p><p>')
    html = html.replace(/\n/g, '<br />')
    if (!html.startsWith('<')) html = '<p>' + html
    if (!html.endsWith('>')) html = html + '</p>'
    return html
  }

  function htmlToMarkdown(html: string): string {
    let md = html
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/p>/gi, '\n\n')
      .replace(/<h1>(.+?)<\/h1>/gi, '# $1\n')
      .replace(/<h2>(.+?)<\/h2>/gi, '## $1\n')
      .replace(/<h3>(.+?)<\/h3>/gi, '### $1\n')
      .replace(/<h4>(.+?)<\/h4>/gi, '#### $1\n')
      .replace(/<strong><em>(.+?)<\/em><\/strong>/gi, '***$1***')
      .replace(/<strong>(.+?)<\/strong>/gi, '**$1**')
      .replace(/<em>(.+?)<\/em>/gi, '*$1*')
      .replace(/<s>(.+?)<\/s>/gi, '~~$1~~')
      .replace(/<code>(.+?)<\/code>/gi, '`$1`')
      .replace(/<a\s+href="(.+?)"[^>]*>(.+?)<\/a>/gi, '[$2]($1)')
      .replace(/<img\s+src="(.+?)"[^ loading="lazy">]*\/?>/gi, '![]($1)')
      .replace(/<blockquote>(.+?)<\/blockquote>/gi, '> $1')
      .replace(/<hr\s*\/?>/gi, '\n---\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/\n{3,}/g, '\n\n')
      .trim()
    return md
  }

  function onMarkdownInput() {
    if (editor.value && isMarkdownMode.value) {
      const html = simpleMarkdownToHtml(markdownText.value)
      editor.value.commands.setContent(html)
    }
  }

  function beautifyContent() {
    if (!editor.value) return
    const ed = editor.value
    ed.view.focus()
    ed.state.doc.descendants((node, pos) => {
      if (node.isText && node.text) {
        const text = node.text
          .replace(/([a-zA-Z0-9])([\u4e00-\u9fff])/g, '$1 $2')
          .replace(/([\u4e00-\u9fff])([a-zA-Z0-9])/g, '$1 $2')
          .replace(/ {2,}/g, ' ')
          .trim()
        if (text !== node.text) {
          const tr = ed.state.tr.insertText(text, pos, pos + node.nodeSize - 1)
          ed.view.dispatch(tr)
        }
      }
    })
    ed.view.focus()
  }

  function setFontFamily(family: string) {
    if (!family) {
      editor.value?.chain().focus().unsetTextFont().run()
    } else {
      editor.value?.chain().focus().setTextFont(family).run()
    }
  }

  function onEditorClick(e: MouseEvent) {
    const ed = editor.value
    if (!ed) return
    const target = e.target as HTMLElement
    const text = target.textContent || ''
    const pos = ed.view.posAtDOM(target, 0)
    const resolved = ed.state.doc.resolve(pos)
    const node = resolved.parent
    if (node.type.name !== 'paragraph') return

    const sel = window.getSelection()
    if (!sel || sel.rangeCount === 0) return
    const range = sel.getRangeAt(0)
    const textNode = range.startContainer
    if (textNode.nodeType !== 3) return

    const fullText = textNode.textContent || ''
    const offset = range.startOffset

    let start = offset
    while (start > 0 && fullText[start - 1] !== ' ' && fullText[start - 1] !== '\n') start--
    let end = offset
    while (
      end < fullText.length &&
      fullText[end] !== ' ' &&
      fullText[end] !== '\n' &&
      fullText[end] !== '#'
    )
      end--

    const word = fullText.slice(start, end)
    if (word.startsWith('#') && word.length > 1) {
      const tag = word.slice(1)
      emit('hashtag-click', tag)
    }
  }

  defineExpose({
    insertVoteCard(data: any) {
      editor.value?.commands.insertContent({ type: 'voteCard', attrs: data })
    },
    insertGoodsCard(data: any) {
      editor.value?.commands.insertContent({ type: 'goodsCard', attrs: data })
    },
    insertAudioBlock(data: any) {
      editor.value?.commands.insertContent({ type: 'audioBlock', attrs: data })
    },
    insertFileAttachment(data: any) {
      editor.value?.commands.insertContent({ type: 'fileAttachment', attrs: data })
    },
    insertNoticeBanner(data: any) {
      editor.value?.commands.insertContent({ type: 'noticeBanner', attrs: data })
    },
    insertUpdateLog(data: any) {
      editor.value?.commands.insertContent({ type: 'updateLog', attrs: data })
    },
    insertPasswordUnlock(data: any) {
      editor.value?.commands.insertContent({ type: 'passwordUnlock', attrs: data })
    },
    insertGalleryBlock(data: any) {
      editor.value?.commands.insertContent({ type: 'galleryBlock', attrs: data })
    },
    insertOriginalStatement(data: any) {
      editor.value?.commands.insertContent({ type: 'originalStatement', attrs: data })
    },
    insertSourceQuote(data: any) {
      editor.value?.commands.insertContent({ type: 'sourceQuote', attrs: data })
    },
    insertFollowUnlock(data: any) {
      editor.value?.commands.insertContent({ type: 'followUnlock', attrs: data })
    },
    insertCommentUnlock(data: any) {
      editor.value?.commands.insertContent({ type: 'commentUnlock', attrs: data })
    },
    insertPaywall(price: number, priceType: string) {
      editor.value?.commands.insertContent({ type: 'paywall', attrs: { price, priceType } })
    },
    insertMemberUnlock(levelId: number, levelName: string) {
      editor.value?.commands.insertContent({ type: 'memberUnlock', attrs: { levelId, levelName } })
    },
    insertExperienceUnlock(level: number, levelName: string) {
      editor.value?.commands.insertContent({
        type: 'experienceUnlock',
        attrs: { level, levelName }
      })
    },
    insertTitleUnlock(titleId: number, titleName: string) {
      editor.value?.commands.insertContent({ type: 'titleUnlock', attrs: { titleId, titleName } })
    },
    insertVideoEmbed(attrs: { type: string; id: string; title?: string }) {
      editor.value?.commands.insertContent({ type: 'videoEmbed', attrs })
    },
    insertPostRef(attrs: {
      postId: number
      title: string
      author?: string
      sectionName?: string
      summary?: string
    }) {
      editor.value?.commands.insertContent({ type: 'postRefCard', attrs })
    },
    insertLevelPrivilege(attrs: {
      level: number
      levelName: string
      privileges: string[]
      currentUserLevel: number
    }) {
      editor.value?.commands.insertContent({
        type: 'levelPrivilegeCard',
        attrs: { ...attrs, privileges: JSON.stringify(attrs.privileges) }
      })
    },
    get editor() {
      return editor.value
    },
    toggleToolbar() {
      showToolbar.value = !showToolbar.value
    },
    getCharacterCount() {
      return editor.value?.storage?.characterCount?.characters?.() ?? 0
    },
    clearAllDrafts
  })

  onMounted(async () => {
    await nextTick()
    if (!editorEl.value) return
    const e = new Editor({
      element: editorEl.value,
      content: props.modelValue,
      extensions: [
        StarterKit.configure({ codeBlock: false }),
        Highlight,
        Underline,
        Image,
        Placeholder.configure({ placeholder: props.placeholder || '请输入内容...' }),
        Subscript,
        Superscript,
        TextAlign.configure({ types: ['heading', 'paragraph'] }),
        Link.configure({ openOnClick: false }),
        TaskList,
        TaskItem.configure({ nested: true }),
        Dropcursor,
        CharacterCount,
        Youtube,
        FontSize,
        TextColor,
        TextFont,
        CodeBlockHighlight,
        VideoEmbed,
        DragHandle,
        PostRefCard,
        LevelPrivilegeCard,
        Hashtag,
        VoteCard,
        GoodsCard,
        AudioBlock,
        FileAttachment,
        NoticeBanner,
        UpdateLog,
        PasswordUnlock,
        GalleryBlock,
        OriginalStatement,
        SourceQuote,
        FollowUnlock,
        CommentUnlock,
        Paywall,
        MemberUnlock,
        ExperienceUnlock,
        TitleUnlock,
        Mention.configure({
          HTMLAttributes: { class: 'mention' },
          suggestion: {
            char: '@',
            items: async ({ query }: { query: string }) => {
              if (!query || query.length < 1) return []
              try {
                const res = await fetch(`/api/user/search?keyword=${encodeURIComponent(query)}`)
                const data = await res.json()
                const users = data?.data || data || []
                return (Array.isArray(users) ? users : []).slice(0, 10).map((u: any) => ({
                  id: u.username || u.userName || u.name,
                  label: u.nickname || u.username || u.userName || u.name
                }))
              } catch {
                return []
              }
            },
            render: () => {
              let popup: HTMLElement | null = null
              return {
                onStart: (props: any) => {
                  if (!props.clientRect) return
                  popup = document.createElement('div')
                  popup.className = 'mention-suggestions'
                  document.body.appendChild(popup)
                },
                onUpdate: (props: any) => {
                  if (!popup) return
                  popup.innerHTML = ''
                  const box = document.createElement('div')
                  if (props.items.length === 0) {
                    box.innerHTML = '<div class="mention-empty">无匹配用户</div>'
                  } else {
                    props.items.forEach((item: any, index: number) => {
                      const el = document.createElement('div')
                      el.className =
                        'mention-item' + (index === props.selectedIndex ? ' mention-selected' : '')
                      el.textContent = '@' + item.label
                      el.addEventListener('click', () => props.command(item))
                      box.appendChild(el)
                    })
                  }
                  popup.appendChild(box)
                  if (props.clientRect) {
                    const rect = props.clientRect()
                    popup.style.position = 'fixed'
                    popup.style.left = rect.left + 'px'
                    popup.style.top = rect.bottom + 4 + 'px'
                  }
                },
                onExit: () => {
                  if (popup) {
                    popup.remove()
                    popup = null
                  }
                },
                onKeyDown: (props: any) => {
                  if (props.event.key === 'Escape') {
                    if (popup) {
                      popup.remove()
                      popup = null
                    }
                    return true
                  }
                  return (['ArrowUp', 'ArrowDown', 'Enter'] as string[]).includes(props.event.key)
                }
              }
            }
          }
        })
      ],
      editable: true,
      onUpdate: ({ editor: ed }: any) => {
        emit('update:modelValue', ed.getJSON())
        charCount.value = ed.storage?.characterCount?.characters?.() ?? 0
        autoSave(ed.getHTML())
      }
    })
    editor.value = e

    setTimeout(() => {
      const draft = loadDraft()
      if (draft) {
        const text = e.getText().trim()
        if (!text) {
          draftContent.value = draft
          hasDraft.value = true
          draftRestored.value = false
        }
      }
    }, 300)
  })

  watch(
    () => props.modelValue,
    (val) => {
      const ed = editor.value
      if (ed) {
        const cur = ed.getJSON()
        if (JSON.stringify(cur) !== JSON.stringify(val)) {
          ed.commands.setContent(val)
        }
      }
    }
  )

  onBeforeUnmount(() => {
    document.body.style.overflow = ''
    editor.value?.destroy()
  })
</script>

<style>
  .tiptap-root {
    position: relative;
  }
  .tiptap-fullscreen {
    position: fixed;
    inset: 0;
    z-index: 9999;
    background: #fff;
    display: flex;
    flex-direction: column;
    padding: 16px;
  }
  .tiptap-fullscreen .tiptap-editor {
    flex: 1;
    overflow: auto;
  }
  .tiptap-fullscreen .tiptap-editor .ProseMirror {
    min-height: calc(100vh - 160px);
  }
  .draft-banner {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: #fff7e6;
    border: 1px solid #ffd666;
    border-radius: 6px 6px 0 0;
    font-size: 13px;
    color: #d48806;
    margin-bottom: 0;
  }
  .draft-banner span {
    flex: 1;
  }
  .db-restore-btn {
    border: 1px solid #d48806;
    background: #fff;
    color: #d48806;
    padding: 4px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
  }
  .db-restore-btn:hover {
    background: #fff1cc;
  }
  .db-discard-btn {
    border: none;
    background: transparent;
    color: #999;
    padding: 4px 8px;
    cursor: pointer;
    font-size: 12px;
  }
  .db-discard-btn:hover {
    color: #666;
  }
  .tiptap-editor .ProseMirror {
    outline: none;
    min-height: 120px;
    padding-left: 4px;
  }
  .tiptap-editor .ProseMirror p.is-editor-empty:first-child::before {
    color: #adb5bd;
    content: attr(data-placeholder);
    float: left;
    height: 0;
    pointer-events: none;
  }
  .tiptap-editor .ProseMirror img {
    width: 30%;
    max-width: 200px;
    height: auto;
    margin: 1.5%;
    border-radius: 6px;
    cursor: pointer;
    display: inline-block;
    vertical-align: top;
  }
  .tiptap-editor .ProseMirror .hashtag {
    color: #508dff;
    font-weight: 500;
    cursor: pointer;
  }
  .tiptap-editor .ProseMirror .hashtag:hover {
    text-decoration: underline;
  }
  .tiptap-editor .ProseMirror .mention {
    color: #508dff;
    font-weight: 500;
    background: #edf2ff;
    padding: 0 2px;
    border-radius: 3px;
    cursor: pointer;
  }
  .inline-toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    padding: 6px 8px;
    border-bottom: 1px solid #eee;
    background: #fafafa;
  }
  .inline-toolbar button {
    background: none;
    border: none;
    padding: 5px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    color: #666;
    min-width: 28px;
    text-align: center;
    user-select: none;
  }
  .inline-toolbar button:hover {
    background: #e8e8e8;
    color: #333;
  }
  .inline-toolbar .it-active {
    background: #edf2ff;
    color: #508dff;
  }
  .it-color-btn {
    position: relative;
    overflow: hidden;
  }
  .it-color-swatch {
    display: inline-block;
    width: 16px;
    height: 16px;
    border-radius: 2px;
    border: 1px solid #ccc;
    color: #fff;
    font-size: 9px;
    line-height: 16px;
    text-align: center;
    background: #000;
  }
  .it-color-popup {
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    opacity: 0;
    pointer-events: none;
  }
  .it-font-select {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 2px 4px;
    font-size: 12px;
    background: #fff;
    cursor: pointer;
    color: #666;
    max-width: 80px;
  }
  .it-font-select:hover {
    border-color: #508dff;
  }
  .it-font-select:focus {
    outline: none;
    border-color: #508dff;
  }
  .it-sep {
    width: 1px;
    background: #ddd;
    margin: 2px 4px;
    align-self: stretch;
  }
  .editor-footer {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    padding: 4px 8px;
    border-top: 1px solid #f0f0f0;
  }
  .ef-draft {
    font-size: 11px;
    color: #67c23a;
  }
  .ef-count {
    font-size: 11px;
    color: #adb5bd;
  }
  .drag-handle {
    user-select: none;
  }
  .drag-active .drag-handle-icon {
    color: #508dff;
  }
  .preview-mobile {
    max-width: 375px;
    margin: 0 auto;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 8px;
    min-height: 667px;
  }
  .preview-pc {
    max-width: 100%;
    border: 1px solid #e5e7eb;
    border-radius: 4px;
    padding: 12px;
  }
  .preview-mobile .ProseMirror,
  .preview-pc .ProseMirror {
    padding: 12px;
  }
  .ProseMirror:hover .drag-handle-icon {
    opacity: 1;
  }
  .markdown-source-editor {
    width: 100%;
    min-height: 300px;
    border: none;
    outline: none;
    resize: vertical;
    padding: 12px;
    font-family: 'Courier New', monospace;
    font-size: 14px;
    line-height: 1.6;
    background: #fafafa;
    color: #333;
  }
  .tiptap-fullscreen .markdown-source-editor {
    min-height: calc(100vh - 160px);
    flex: 1;
  }
  .mention-suggestions {
    z-index: 99999;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    max-width: 240px;
    max-height: 280px;
    overflow-y: auto;
  }
  .mention-item {
    padding: 8px 12px;
    font-size: 13px;
    cursor: pointer;
    color: #333;
  }
  .mention-item:hover,
  .mention-selected {
    background: #edf2ff;
    color: #508dff;
  }
  .mention-empty {
    padding: 10px 12px;
    font-size: 12px;
    color: #999;
    text-align: center;
  }
</style>
