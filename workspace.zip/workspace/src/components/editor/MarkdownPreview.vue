<template>
  <div class="markdown-preview" :class="{ 'markdown-preview-mobile': viewport === 'mobile' }">
    <div v-if="!html" class="md-empty">
      <p>暂无内容</p>
    </div>
    <div v-else class="md-content" v-html="html"></div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  content: string
  viewport?: string
}>()

const html = computed(() => {
  if (!props.content) return ''
  try {
    let md = props.content
    // Strip HTML tags first for pure markdown
    md = md.replace(/<[^>]*>/g, '').trim()
    if (!md) return ''
    return parseMarkdown(md)
  } catch {
    return props.content
  }
})

function parseMarkdown(text: string): string {
  let html = text

  // Escape HTML
  html = html.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

  // Code blocks (```)
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, lang, code) => {
    const escaped = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    return `<pre><code class="language-${lang}">${escaped}</code></pre>`
  })

  // Inline code
  html = html.replace(/`([^`]+)`/g, (_m, code) => {
    const escaped = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    return `<code>${escaped}</code>`
  })

  // Bold and italic (must be before headers)
  html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>')

  // Strikethrough
  html = html.replace(/~~(.+?)~~/g, '<del>$1</del>')

  // Headers
  html = html.replace(/^###### (.+)$/gm, '<h6>$1</h6>')
  html = html.replace(/^##### (.+)$/gm, '<h5>$1</h5>')
  html = html.replace(/^#### (.+)$/gm, '<h4>$1</h4>')
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>')
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>')

  // Horizontal rules
  html = html.replace(/^(---|\*\*\*|___)\s*$/gm, '<hr>')

  // Blockquotes
  html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>')

  // Unordered lists
  html = html.replace(/^[\*\-] (.+)$/gm, '<li>$1</li>')
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')

  // Ordered lists
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
  // Fix ordered lists that were not matched by the unordered list regex
  // Already handled above

  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')

  // Images
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1" loading="lazy">')

  // Paragraphs - wrap lines that are not already wrapped in block elements
  html = html.replace(/^(?!<[a-z]|$)(.+)$/gm, '<p>$1</p>')

  // Clean up double paragraphs
  html = html.replace(/<\/p>\s*<p>/g, '<br>')
  html = html.replace(/<p><(h[1-6]|ul|ol|pre|blockquote|hr|img)/g, '<$1')
  html = html.replace(/<\/(h[1-6]|ul|ol|pre|blockquote|hr)>(\s*)<\/p>/g, '</$1>$2')

  // Handle table-like content
  html = html.replace(/<p>\|(.+)\|<\/p>/g, '<div class="md-table-row">$1</div>')

  return html
}
</script>

<style scoped>
.markdown-preview {
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  padding: 16px;
  min-height: 120px;
  overflow-y: auto;
}
.markdown-preview-mobile {
  max-width: 375px;
  margin: 0 auto;
  border-radius: 12px;
  min-height: 500px;
}
.md-empty {
  text-align: center;
  color: #adb5bd;
  padding: 40px 0;
  font-size: 14px;
}
.md-content {
  line-height: 1.8;
  color: #303133;
  font-size: 14px;
  word-break: break-word;
}
.md-content :deep(h1) { font-size: 1.8em; font-weight: 700; margin: 0.8em 0 0.4em; border-bottom: 2px solid #eee; padding-bottom: 0.3em; }
.md-content :deep(h2) { font-size: 1.5em; font-weight: 700; margin: 0.7em 0 0.3em; border-bottom: 1px solid #eee; padding-bottom: 0.2em; }
.md-content :deep(h3) { font-size: 1.25em; font-weight: 600; margin: 0.6em 0 0.2em; }
.md-content :deep(h4) { font-size: 1.1em; font-weight: 600; margin: 0.5em 0 0.2em; }
.md-content :deep(h5) { font-size: 1em; font-weight: 600; margin: 0.4em 0 0.2em; }
.md-content :deep(h6) { font-size: 0.9em; font-weight: 600; color: #909399; margin: 0.3em 0 0.2em; }
.md-content :deep(p) { margin: 0.5em 0; }
.md-content :deep(code) { background: #f5f7fa; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace; font-size: 0.9em; color: #e74c3c; }
.md-content :deep(pre) { background: #282c34; color: #abb2bf; padding: 16px; border-radius: 6px; overflow-x: auto; margin: 0.8em 0; }
.md-content :deep(pre code) { background: none; color: inherit; padding: 0; font-size: 13px; }
.md-content :deep(blockquote) { border-left: 4px solid #508DFF; padding: 8px 16px; margin: 0.8em 0; background: #f0f2f5; border-radius: 0 4px 4px 0; color: #606266; }
.md-content :deep(ul), .md-content :deep(ol) { padding-left: 24px; margin: 0.5em 0; }
.md-content :deep(li) { margin: 0.2em 0; }
.md-content :deep(a) { color: #508DFF; text-decoration: none; }
.md-content :deep(a:hover) { text-decoration: underline; }
.md-content :deep(img) { max-width: 100%; height: auto; border-radius: 6px; margin: 0.5em 0; }
.md-content :deep(hr) { border: none; border-top: 1px solid #e5e7eb; margin: 1em 0; }
.md-content :deep(del) { color: #909399; }
.md-content :deep(strong) { font-weight: 700; }
.md-content :deep(em) { font-style: italic; }
.md-content :deep(.md-table-row) { display: flex; gap: 0; }
.md-content :deep(.md-table-row > *) { flex: 1; padding: 4px 8px; }
</style>
