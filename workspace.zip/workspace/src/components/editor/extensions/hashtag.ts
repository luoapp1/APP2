import { Mark, markInputRule, markPasteRule } from '@tiptap/core'

const inputRegex = /(?:^|\s)(#[^\s#]+)\s$/
const pasteRegex = /(?:^|\s)(#[^\s#]+)/g

export const Hashtag = Mark.create({
  name: 'hashtag',

  parseHTML() {
    return [{ tag: 'span.hashtag' }]
  },

  renderHTML() {
    return ['span', { class: 'hashtag' }, 0]
  },

  addInputRules() {
    return [markInputRule({ find: inputRegex, type: this.type })]
  },

  addPasteRules() {
    return [markPasteRule({ find: pasteRegex, type: this.type })]
  }
})
