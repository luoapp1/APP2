import { Node } from '@tiptap/core'

export const AudioBlock = Node.create({
  name: 'audioBlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      src: { default: '' },
      title: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="audio-block"]' }]
  },

  renderHTML({ node }) {
    return ['div', {
      'data-type': 'audio-block',
      'data-src': node.attrs.src || '',
      contenteditable: 'false',
      style: 'background:#f8f9fa;border-radius:8px;padding:8px 12px;margin:8px 0;border:1px solid #e9ecef;display:flex;align-items:center;gap:8px'
    },
      ['span', { style: 'font-size:20px' }, '🎵'],
      ['span', { style: 'flex:1;font-size:13px;color:#666;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, node.attrs.title || '音频文件'],
      ['audio', { src: node.attrs.src || '', controls: 'true', style: 'width:100%;max-width:200px;height:32px' }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'audio-block')
      dom.style.cssText = 'background:#f8f9fa;border-radius:8px;padding:8px 12px;margin:8px 0;border:1px solid #e9ecef;display:flex;align-items:center;gap:8px'

      const icon = document.createElement('span')
      icon.textContent = '🎵'
      icon.style.cssText = 'font-size:20px'

      const title = document.createElement('span')
      title.style.cssText = 'flex:1;font-size:13px;color:#666;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
      title.textContent = node.attrs.title || '音频文件'

      const audio = document.createElement('audio')
      audio.src = node.attrs.src || ''
      audio.controls = true
      audio.style.cssText = 'width:100%;max-width:200px;height:32px'

      dom.appendChild(icon)
      dom.appendChild(title)
      dom.appendChild(audio)
      return { dom }
    }
  }
})
