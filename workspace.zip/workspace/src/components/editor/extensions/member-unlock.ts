import { Node } from '@tiptap/core'

export const MemberUnlock = Node.create({
  name: 'memberUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      levelId: { default: 1, parseHTML: (el) => Number(el.getAttribute('data-level-id')) || 1 },
      levelName: { default: '普通会员', parseHTML: (el) => el.getAttribute('data-level-name') || '普通会员' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="memberUnlock"]' }]
  },

  renderHTML({ node }) {
    const { levelId, levelName } = node.attrs
    return ['div', {
      'data-type': 'memberUnlock',
      'data-level-id': levelId,
      'data-level-name': levelName,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#FFD700;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#D48806;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容 ${levelName} 会员可见`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#FFD700;min-width:20px' }]
    ]
  }
})
