import { Node } from '@tiptap/core'

export const ExperienceUnlock = Node.create({
  name: 'experienceUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      level: { default: 2, parseHTML: (el) => Number(el.getAttribute('data-level')) || 2 },
      levelName: { default: 'Lv.2', parseHTML: (el) => el.getAttribute('data-level-name') || 'Lv.2' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="experienceUnlock"]' }]
  },

  renderHTML({ node }) {
    const { level, levelName } = node.attrs
    return ['div', {
      'data-type': 'experienceUnlock',
      'data-level': level,
      'data-level-name': levelName,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#508DFF;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#508DFF;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容经验等级 ${levelName} 可见`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#508DFF;min-width:20px' }]
    ]
  }
})
