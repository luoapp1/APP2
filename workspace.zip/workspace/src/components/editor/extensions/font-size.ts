import { Mark } from '@tiptap/core'

export const FontSize = Mark.create({
  name: 'fontSize',

  addAttributes() {
    return {
      size: {
        default: null,
        parseHTML: (el: HTMLElement) => el.style.fontSize?.replace(/["']/g, '') || null,
        renderHTML: (attrs: Record<string, any>) => {
          if (!attrs.size) return {}
          return { style: `font-size: ${attrs.size}` }
        }
      }
    }
  },

  parseHTML() {
    return [{ tag: 'span[style*="font-size"]' }]
  },

  renderHTML({ HTMLAttributes }: any) {
    return ['span', HTMLAttributes, 0]
  },

  addCommands() {
    return {
      setFontSize:
        (size: string) =>
        ({ commands }: any) => {
          return commands.setMark(this.name, { size })
        },
      unsetFontSize:
        () =>
        ({ commands }: any) => {
          return commands.unsetMark(this.name)
        }
    } as any
  }
})
