import { Node } from '@tiptap/core'

function getEmbedUrl(type: string, id: string): string {
  switch (type) {
    case 'youtube': return `https://www.youtube.com/embed/${id}`
    case 'bilibili': return `https://player.bilibili.com/player.html?bvid=${id}&page=1&high_quality=1`
    case 'tencent': return `https://v.qq.com/txp/iframe/player.html?vid=${id}`
    case 'douyin': return `https://open.douyin.com/player/video?vid=${id}&autoplay=0`
    case 'kuaishou': return `https://www.kuaishou.com/embed/${id}`
    default: return ''
  }
}

function parseVideoUrl(url: string): { type: string; id: string } | null {
  const u = url.trim()
  if (!u) return null

  // YouTube
  let m = u.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/)
  if (m) return { type: 'youtube', id: m[1] }

  // B站
  m = u.match(/bilibili\.com\/video\/(BV[a-zA-Z0-9]+)/)
  if (m) return { type: 'bilibili', id: m[1] }
  m = u.match(/b23\.tv\/([a-zA-Z0-9]+)/)
  if (m) return { type: 'bilibili', id: m[1] }

  // 腾讯视频
  m = u.match(/v\.qq\.com\/x\/page\/([a-zA-Z0-9]+)\.html/)
  if (m) return { type: 'tencent', id: m[1] }
  m = u.match(/v\.qq\.com\/x\/cover\/[^/]+\/([a-zA-Z0-9]+)\.html/)
  if (m) return { type: 'tencent', id: m[1] }

  // 抖音
  m = u.match(/douyin\.com\/video\/(\d+)/)
  if (m) return { type: 'douyin', id: m[1] }
  m = u.match(/douyin\.com\/embed\/video\/(\d+)/)
  if (m) return { type: 'douyin', id: m[1] }

  // 快手
  m = u.match(/kuaishou\.com\/short-video\/([a-zA-Z0-9]+)/)
  if (m) return { type: 'kuaishou', id: m[1] }
  m = u.match(/kuaishou\.com\/fw\/video\/([a-zA-Z0-9]+)/)
  if (m) return { type: 'kuaishou', id: m[1] }

  return null
}

export { parseVideoUrl }

export const VideoEmbed = Node.create({
  name: 'videoEmbed',
  group: 'block',
  atom: true,
  draggable: false,
  isolating: true,

  addAttributes() {
    return {
      type: { default: 'youtube' },
      id: { default: '' },
      title: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="video-embed"]' }]
  },

  renderHTML({ node }) {
    const embedUrl = getEmbedUrl(node.attrs.type, node.attrs.id)
    return ['div', {
      'data-type': 'video-embed',
      'data-video-type': node.attrs.type,
      'data-video-id': node.attrs.id,
      style: 'position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;margin:12px 0'
    },
      ['iframe', {
        src: embedUrl,
        style: 'position:absolute;top:0;left:0;width:100%;height:100%;border-radius:8px',
        frameborder: '0',
        allowfullscreen: 'true',
        allow: 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture'
      }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'video-embed')
      dom.style.cssText = 'position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;margin:12px 0'

      const embedUrl = getEmbedUrl(node.attrs.type, node.attrs.id)
      const iframe = document.createElement('iframe')
      iframe.src = embedUrl
      iframe.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;border-radius:8px'
      iframe.setAttribute('frameborder', '0')
      iframe.setAttribute('allowfullscreen', 'true')
      iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture')

      dom.appendChild(iframe)
      return { dom }
    }
  },

  addCommands() {
    return {
      insertVideoEmbed:
        (attrs: { type: string; id: string; title?: string }) =>
        ({ commands }: any) => {
          return commands.insertContent({ type: this.name, attrs })
        }
    } as any
  }
})
