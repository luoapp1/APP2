import { Node } from '@tiptap/core'

export const SourceQuote = Node.create({
  name: 'sourceQuote',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      url: { default: '' },
      author: { default: '' },
      platform: { default: '' },
      note: { default: '' },
      quoteText: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="source-quote"]' }]
  },

  renderHTML({ node }) {
    const domain = node.attrs.url ? new URL(node.attrs.url).hostname : ''
    return ['div', {
      'data-type': 'source-quote',
      'data-url': node.attrs.url || '',
      contenteditable: 'false',
      style: 'background:#f8f9fa;border:1px solid #e9ecef;border-radius:12px;padding:16px;margin:12px 0;font-family:sans-serif'
    },
      ['div', {
        style: 'display:flex;align-items:center;gap:8px;margin-bottom:10px'
      },
        ['span', { style: 'font-size:14px' }, '📎'],
        ['span', { style: 'font-size:13px;font-weight:600;color:#495057' }, '引用来源']
      ],
      ['div', { style: 'border-top:1px solid #dee2e6;margin:8px 0' }],
      node.attrs.author ? ['div', { style: 'font-size:13px;color:#212529;margin-bottom:4px' },
        ['span', { style: 'color:#868e96' }, '作者：'], node.attrs.author
      ] : ['div'],
      node.attrs.platform ? ['div', { style: 'font-size:13px;color:#212529;margin-bottom:4px' },
        ['span', { style: 'color:#868e96' }, '来源：'], node.attrs.platform
      ] : ['div'],
      node.attrs.url ? ['a', {
        href: node.attrs.url, target: '_blank', rel: 'noopener noreferrer',
        style: 'display:inline-block;font-size:12px;color:#4263eb;margin-top:4px;text-decoration:none;word-break:break-all'
      }, domain || node.attrs.url] : ['div'],
      node.attrs.quoteText ? ['div', {
        style: 'margin-top:10px;padding:8px 12px;background:#fff;border-left:3px solid #4263eb;border-radius:0 6px 6px 0;font-size:13px;color:#495057;line-height:1.6'
      }, node.attrs.quoteText] : ['div'],
      node.attrs.note ? ['div', { style: 'font-size:11px;color:#adb5bd;margin-top:6px' }, node.attrs.note] : ['div']
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'source-quote')
      dom.style.cssText = 'background:#f8f9fa;border:1px solid #e9ecef;border-radius:12px;padding:16px;margin:12px 0;font-family:sans-serif'

      const header = document.createElement('div')
      header.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:10px'
      const icon = document.createElement('span')
      icon.textContent = '📎'
      icon.style.cssText = 'font-size:14px'
      const title = document.createElement('span')
      title.textContent = '引用来源'
      title.style.cssText = 'font-size:13px;font-weight:600;color:#495057'
      header.appendChild(icon)
      header.appendChild(title)
      dom.appendChild(header)

      const divider = document.createElement('div')
      divider.style.cssText = 'border-top:1px solid #dee2e6;margin:8px 0'
      dom.appendChild(divider)

      if (node.attrs.author) {
        const author = document.createElement('div')
        author.style.cssText = 'font-size:13px;color:#212529;margin-bottom:4px'
        author.innerHTML = '<span style="color:#868e96">作者：</span>'
        author.appendChild(document.createTextNode(node.attrs.author))
        dom.appendChild(author)
      }

      if (node.attrs.platform) {
        const platform = document.createElement('div')
        platform.style.cssText = 'font-size:13px;color:#212529;margin-bottom:4px'
        platform.innerHTML = '<span style="color:#868e96">来源：</span>'
        platform.appendChild(document.createTextNode(node.attrs.platform))
        dom.appendChild(platform)
      }

      if (node.attrs.url) {
        const domain = new URL(node.attrs.url).hostname
        const link = document.createElement('a')
        link.href = node.attrs.url
        link.target = '_blank'
        link.rel = 'noopener noreferrer'
        link.textContent = domain
        link.style.cssText = 'display:inline-block;font-size:12px;color:#4263eb;margin-top:4px;text-decoration:none;word-break:break-all'
        dom.appendChild(link)
      }

      if (node.attrs.quoteText) {
        const quote = document.createElement('div')
        quote.textContent = node.attrs.quoteText
        quote.style.cssText = 'margin-top:10px;padding:8px 12px;background:#fff;border-left:3px solid #4263eb;border-radius:0 6px 6px 0;font-size:13px;color:#495057;line-height:1.6'
        dom.appendChild(quote)
      }

      if (node.attrs.note) {
        const note = document.createElement('div')
        note.textContent = node.attrs.note
        note.style.cssText = 'font-size:11px;color:#adb5bd;margin-top:6px'
        dom.appendChild(note)
      }

      return { dom }
    }
  }
})

export const FollowUnlock = Node.create({
  name: 'followUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      authorId: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-author-id')) || 0 },
      authorName: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="follow-unlock"]' }]
  },

  renderHTML({ node }) {
    return ['div', {
      'data-type': 'follow-unlock',
      'data-author-id': node.attrs.authorId,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#93c5fd;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#3B82F6;white-space:nowrap;flex-shrink:0;line-height:1' }, `关注 ${node.attrs.authorName || '作者'} 后查看以下内容`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#93c5fd;min-width:20px' }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'follow-unlock')
      dom.style.cssText = 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'

      const left = document.createElement('span')
      left.setAttribute('contenteditable', 'false')
      left.style.cssText = 'flex:1;height:1px;background:#93c5fd;min-width:20px'

      const text = document.createElement('span')
      text.setAttribute('contenteditable', 'false')
      text.textContent = `关注 ${node.attrs.authorName || '作者'} 后查看以下内容`
      text.style.cssText = 'font-size:12px;color:#3B82F6;white-space:nowrap;flex-shrink:0;line-height:1'

      const right = document.createElement('span')
      right.setAttribute('contenteditable', 'false')
      right.style.cssText = 'flex:1;height:1px;background:#93c5fd;min-width:20px'

      dom.appendChild(left)
      dom.appendChild(text)
      dom.appendChild(right)
      return { dom }
    }
  }
})

export const CommentUnlock = Node.create({
  name: 'commentUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      minCommentCount: { default: 1, parseHTML: (el) => Number(el.getAttribute('data-min-comments')) || 1 }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="comment-unlock"]' }]
  },

  renderHTML({ node }) {
    const count = node.attrs.minCommentCount || 1
    return ['div', {
      'data-type': 'comment-unlock',
      'data-min-comments': count,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#c4b5fd;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#7c3aed;white-space:nowrap;flex-shrink:0;line-height:1' }, `发布 ${count} 条评论后查看以下内容`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#c4b5fd;min-width:20px' }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'comment-unlock')
      dom.style.cssText = 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'

      const left = document.createElement('span')
      left.setAttribute('contenteditable', 'false')
      left.style.cssText = 'flex:1;height:1px;background:#c4b5fd;min-width:20px'

      const text = document.createElement('span')
      text.setAttribute('contenteditable', 'false')
      text.textContent = `发布 ${node.attrs.minCommentCount || 1} 条评论后查看以下内容`
      text.style.cssText = 'font-size:12px;color:#7c3aed;white-space:nowrap;flex-shrink:0;line-height:1'

      const right = document.createElement('span')
      right.setAttribute('contenteditable', 'false')
      right.style.cssText = 'flex:1;height:1px;background:#c4b5fd;min-width:20px'

      dom.appendChild(left)
      dom.appendChild(text)
      dom.appendChild(right)
      return { dom }
    }
  }
})
