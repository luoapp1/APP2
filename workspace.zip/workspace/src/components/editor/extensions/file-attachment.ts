import { Node } from '@tiptap/core'

export const FileAttachment = Node.create({
  name: 'fileAttachment',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      src: { default: '' },
      name: { default: '' },
      size: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="file-attachment"]' }]
  },

  renderHTML({ node }) {
    const { name, size, src } = node.attrs
    return ['div', {
      'data-type': 'file-attachment',
      'data-src': src || '',
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:8px;background:#f8f9fa;border:1px solid #e9ecef;border-radius:8px;padding:10px 12px;margin:8px 0'
    },
      ['span', { style: 'font-size:24px' }, '📄'],
      ['div', { style: 'flex:1;min-width:0' },
        ['div', { style: 'font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, name || '未知文件'],
        ['div', { style: 'font-size:11px;color:#999;margin-top:2px' }, size || '']
      ],
      ['div', { style: 'background:#508DFF;color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;flex-shrink:0;cursor:pointer' }, '下载']
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'file-attachment')
      dom.style.cssText = 'display:flex;align-items:center;gap:8px;background:#f8f9fa;border:1px solid #e9ecef;border-radius:8px;padding:10px 12px;margin:8px 0'

      const icon = document.createElement('span')
      icon.textContent = '📄'
      icon.style.cssText = 'font-size:24px'

      const info = document.createElement('div')
      info.style.cssText = 'flex:1;min-width:0'

      const namDiv = document.createElement('div')
      namDiv.style.cssText = 'font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
      namDiv.textContent = node.attrs.name || '未知文件'

      const sizeDiv = document.createElement('div')
      sizeDiv.style.cssText = 'font-size:11px;color:#999;margin-top:2px'
      sizeDiv.textContent = node.attrs.size || ''

      info.appendChild(namDiv)
      info.appendChild(sizeDiv)

      const btn = document.createElement('div')
      btn.style.cssText = 'background:#508DFF;color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;flex-shrink:0'
      btn.textContent = '下载'

      dom.appendChild(icon)
      dom.appendChild(info)
      dom.appendChild(btn)
      return { dom }
    }
  }
})
