import { Node } from '@tiptap/core'

const platformColors: Record<string, string> = {
  '默认云盘': '#6B7280',
  '360网盘': '#22C55E',
  '百度云盘': '#3B82F6',
  '天翼云盘': '#6366F1',
  '城通网盘': '#F97316',
  '腾讯微云': '#06B6D4',
  '夸克云盘': '#A855F7',
  'Github仓库': '#475569',
  'Gitee仓库': '#EF4444',
  '蓝奏云网盘': '#F59E0B'
}

const platformIcons: Record<string, string> = {
  '默认云盘': '☁',
  '360网盘': '360',
  '百度云盘': '百',
  '天翼云盘': '翼',
  '城通网盘': '城',
  '腾讯微云': '微',
  '夸克云盘': '夸',
  'Github仓库': 'GH',
  'Gitee仓库': 'GE',
  '蓝奏云网盘': '蓝'
}

export { platformColors, platformIcons }

export const FileAttachment = Node.create({
  name: 'fileAttachment',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      src: { default: '' },
      name: { default: '' },
      size: { default: '' },
      platform: { default: '' },
      extractCode: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="file-attachment"]' }]
  },

  renderHTML({ node }) {
    const { name, size, src, platform, extractCode } = node.attrs
    return ['div', {
      'data-type': 'file-attachment',
      'data-src': src || '',
      'data-platform': platform || '',
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;background:#f8f9fa;border:1px solid #e9ecef;border-radius:12px;padding:14px 16px;margin:8px 0'
    },
      ['div', { style: 'width:40px;height:40px;flex-shrink:0;display:flex;align-items:center;justify-content:center;border-radius:12px;font-size:14px;font-weight:700;color:#fff;background:' + (platformColors[platform] || '#6B7280') }, platformIcons[platform] || '云'],
      ['div', { style: 'flex:1;min-width:0' },
        ['div', { style: 'font-size:14px;font-weight:600;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, name || '未知文件'],
        ['div', { style: 'font-size:12px;color:#888;margin-top:4px' }, (platform ? '来源：' + platform : '') + (extractCode ? ' | 提取码：' + extractCode : '') + (size ? ' | ' + size : '')]
      ],
      ['div', { style: 'width:38px;height:38px;flex-shrink:0;background:#508DFF;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer' },
        ['svg', { width: '18', height: '18', fill: '#fff', viewBox: '0 0 1024 1024' },
          ['path', { d: 'M832 512h-128V128a32 32 0 00-32-32H352a32 32 0 00-32 32v384H192a32 32 0 00-24.96 52.48l320 384a32 32 0 0049.92 0l320-384A32 32 0 00832 512zM640 512V160h-256v352H640z' }]
        ]
      ]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'file-attachment')
      dom.style.cssText = 'display:flex;align-items:center;gap:12px;background:#f8f9fa;border:1px solid #e9ecef;border-radius:12px;padding:14px 16px;margin:8px 0'

      const platform = node.attrs.platform || ''
      const color = platformColors[platform] || '#6B7280'
      const ico = platformIcons[platform] || '云'

      const iconBox = document.createElement('div')
      iconBox.style.cssText = `width:40px;height:40px;flex-shrink:0;display:flex;align-items:center;justify-content:center;border-radius:12px;font-size:14px;font-weight:700;color:#fff;background:${color}`
      iconBox.textContent = ico

      const info = document.createElement('div')
      info.style.cssText = 'flex:1;min-width:0'

      const namDiv = document.createElement('div')
      namDiv.style.cssText = 'font-size:14px;font-weight:600;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
      namDiv.textContent = node.attrs.name || '未知文件'

      const metaDiv = document.createElement('div')
      metaDiv.style.cssText = 'font-size:12px;color:#888;margin-top:4px'
      const parts: string[] = []
      if (platform) parts.push('来源：' + platform)
      if (node.attrs.extractCode) parts.push('提取码：' + node.attrs.extractCode)
      if (node.attrs.size) parts.push(node.attrs.size)
      metaDiv.textContent = parts.join(' | ')

      info.appendChild(namDiv)
      info.appendChild(metaDiv)

      const btn = document.createElement('div')
      btn.style.cssText = 'width:38px;height:38px;flex-shrink:0;background:#508DFF;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer'
      btn.innerHTML = '<svg width="18" height="18" fill="#fff" viewBox="0 0 1024 1024"><path d="M832 512h-128V128a32 32 0 00-32-32H352a32 32 0 00-32 32v384H192a32 32 0 00-24.96 52.48l320 384a32 32 0 0049.92 0l320-384A32 32 0 00832 512zM640 512V160h-256v352H640z"/></svg>'

      dom.appendChild(iconBox)
      dom.appendChild(info)
      dom.appendChild(btn)
      return { dom }
    }
  }
})
