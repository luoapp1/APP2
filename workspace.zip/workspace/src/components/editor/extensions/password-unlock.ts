import { Node } from '@tiptap/core'

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hashBuffer = await crypto.subtle.digest('SHA-256', data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

export const PasswordUnlock = Node.create({
  name: 'passwordUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      passwordHash: { default: '' },
      hint: { default: '' },
      price: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-price')) || 0 },
      priceType: { default: 'balance' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="password-unlock"]' }]
  },

  renderHTML({ node }) {
    const { price, priceType, hint } = node.attrs
    const priceLabel = priceType === 'points' ? `${price}积分` : `￥${price}`
    return ['div', {
      'data-type': 'password-unlock',
      'data-price': price,
      'data-price-type': priceType,
      contenteditable: 'false',
      style: 'display:flex;flex-direction:column;align-items:center;gap:8px;background:#fafafa;border:1px dashed #ddd;border-radius:8px;padding:20px;margin:16px 0;text-align:center'
    },
      ['div', { style: 'font-size:28px' }, '🔒'],
      ['div', { style: 'font-size:14px;font-weight:600;color:#333' }, `以下内容需付费 ${priceLabel} 或输入密码解锁`],
      hint ? ['div', { style: 'font-size:12px;color:#999' }, `提示：${hint}`] : ['div']
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'password-unlock')
      dom.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:8px;background:#fafafa;border:1px dashed #ddd;border-radius:8px;padding:20px;margin:16px 0;text-align:center'

      const icon = document.createElement('div')
      icon.textContent = '🔒'
      icon.style.cssText = 'font-size:28px'

      const label = document.createElement('div')
      const p = node.attrs.price || 0
      const pt = node.attrs.priceType || 'balance'
      label.textContent = `以下内容需付费 ${pt === 'points' ? p + '积分' : '￥' + p} 或输入密码解锁`
      label.style.cssText = 'font-size:14px;font-weight:600;color:#333'

      dom.appendChild(icon)
      dom.appendChild(label)

      if (node.attrs.hint) {
        const hint = document.createElement('div')
        hint.textContent = `提示：${node.attrs.hint}`
        hint.style.cssText = 'font-size:12px;color:#999'
        dom.appendChild(hint)
      }

      return { dom }
    }
  }
})

export { hashPassword }
