import { Node } from '@tiptap/core'

let globalLabelMap: Record<string, string> = { balance: '￥', points: '积分' }

export function setUnlockCurrencyLabels(map: Record<string, string>) {
  globalLabelMap = { ...globalLabelMap, ...map }
}

function formatPriceLabel(price: number, priceType: string): string {
  const label = globalLabelMap[priceType] || priceType
  return label === '￥' ? `￥${price}` : `${price}${label}`
}

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hashBuffer = await crypto.subtle.digest('SHA-256', data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

export { hashPassword }

export const PasswordUnlock = Node.create({
  name: 'passwordUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      price: { default: 0 },
      priceType: { default: 'balance' },
      hint: { default: '' },
      passwordHash: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="password-unlock"]' }]
  },

  renderHTML({ node }) {
    const { price, priceType, hint } = node.attrs
    const priceLabel = formatPriceLabel(price, priceType)
    const label = hint ? `以下内容需密码解锁（提示：${hint}）` : '以下内容需密码解锁'
    return ['div', {
      'data-type': 'password-unlock',
      'data-price': price,
      'data-price-type': priceType,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d4d4d8;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#71717a;white-space:nowrap;flex-shrink:0;line-height:1' }, label],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d4d4d8;min-width:20px' }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'password-unlock')
      dom.style.cssText = 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'

      const left = document.createElement('span')
      left.setAttribute('contenteditable', 'false')
      left.style.cssText = 'flex:1;height:1px;background:#d4d4d8;min-width:20px'

      const text = document.createElement('span')
      text.setAttribute('contenteditable', 'false')
      const h = node.attrs.hint
      text.textContent = h ? `以下内容需密码解锁（提示：${h}）` : '以下内容需密码解锁'
      text.style.cssText = 'font-size:12px;color:#71717a;white-space:nowrap;flex-shrink:0;line-height:1'

      const right = document.createElement('span')
      right.setAttribute('contenteditable', 'false')
      right.style.cssText = 'flex:1;height:1px;background:#d4d4d8;min-width:20px'

      dom.appendChild(left)
      dom.appendChild(text)
      dom.appendChild(right)
      return { dom }
    }
  }
})
