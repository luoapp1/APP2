<template>
  <div class="mention-list">
    <div v-if="items.length === 0" class="mention-empty">未找到用户</div>
    <button
      v-for="(item, index) in items"
      :key="item.id"
      class="mention-item"
      :class="{ 'mention-item-active': index === selectedIndex }"
      @click="selectItem(index)"
    >
      <span class="mention-label">{{ item.label }}</span>
      <span class="mention-username">@{{ item.username }}</span>
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps<{
  items: { id: string; label: string; username: string }[]
  command: (item: { id: string; label: string }) => void
}>()

const selectedIndex = ref(0)

function selectItem(index: number) {
  const item = props.items[index]
  if (item) {
    props.command({ id: item.id, label: item.label })
  }
}

function onKeyDown(event: { key: string }) {
  if (event.key === 'ArrowUp') {
    selectedIndex.value = (selectedIndex.value + props.items.length - 1) % props.items.length
    return true
  }
  if (event.key === 'ArrowDown') {
    selectedIndex.value = (selectedIndex.value + 1) % props.items.length
    return true
  }
  if (event.key === 'Enter') {
    selectItem(selectedIndex.value)
    return true
  }
  return false
}

defineExpose({ onKeyDown })
</script>

<style scoped>
.mention-list {
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  padding: 4px;
  min-width: 200px;
  max-height: 240px;
  overflow-y: auto;
}
.mention-empty {
  padding: 8px 12px;
  color: #909399;
  font-size: 13px;
  text-align: center;
}
.mention-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 8px 12px;
  border: none;
  background: none;
  cursor: pointer;
  border-radius: 4px;
  text-align: left;
  font-size: 13px;
}
.mention-item:hover,
.mention-item-active {
  background: #edf2ff;
}
.mention-label {
  color: #303133;
  font-weight: 500;
}
.mention-username {
  color: #909399;
  font-size: 12px;
}
</style>
