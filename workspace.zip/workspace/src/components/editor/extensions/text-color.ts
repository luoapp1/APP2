import { Mark } from '@tiptap/core'

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    textColor: {
      setTextColor: (color: string) => ReturnType
      unsetTextColor: () => ReturnType
    }
  }
}

export const TextColor = Mark.create({
  name: 'textColor',

  addAttributes() {
    return {
      color: {
        default: null,
        parseHTML: (el: HTMLElement) => el.style.color || null,
        renderHTML: (attrs: Record<string, any>) => {
          if (!attrs.color) return {}
          return { style: `color: ${attrs.color}` }
        }
      }
    }
  },

  parseHTML() {
    return [{ tag: 'span[style*="color"]' }]
  },

  renderHTML({ HTMLAttributes }: any) {
    return ['span', HTMLAttributes, 0]
  },

  addCommands() {
    return {
      setTextColor:
        (color: string) =>
        ({ commands }: any) => {
          return commands.setMark(this.name, { color })
        },
      unsetTextColor:
        () =>
        ({ commands }: any) => {
          return commands.unsetMark(this.name)
        }
    } as any
  }
})
