import { Mark } from '@tiptap/core'

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    textFont: {
      setTextFont: (fontFamily: string) => ReturnType
      unsetTextFont: () => ReturnType
    }
  }
}

export const TextFont = Mark.create({
  name: 'textFont',

  addAttributes() {
    return {
      fontFamily: {
        default: null,
        parseHTML: (el: HTMLElement) => el.style.fontFamily?.replace(/["']/g, '') || null,
        renderHTML: (attrs: Record<string, any>) => {
          if (!attrs.fontFamily) return {}
          return { style: `font-family: ${attrs.fontFamily}` }
        }
      }
    }
  },

  parseHTML() {
    return [{ tag: 'span[style*="font-family"]' }]
  },

  renderHTML({ HTMLAttributes }: any) {
    return ['span', HTMLAttributes, 0]
  },

  addCommands() {
    return {
      setTextFont:
        (fontFamily: string) =>
        ({ commands }: any) => {
          return commands.setMark(this.name, { fontFamily })
        },
      unsetTextFont:
        () =>
        ({ commands }: any) => {
          return commands.unsetMark(this.name)
        }
    } as any
  }
})
