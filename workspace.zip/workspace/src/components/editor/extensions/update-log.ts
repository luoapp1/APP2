import { Node } from '@tiptap/core'

export const UpdateLog = Node.create({
  name: 'updateLog',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      version: { default: '' },
      date: { default: '' },
      added: { default: '' },
      fixed: { default: '' },
      improved: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="update-log"]' }]
  },

  renderHTML({ node }) {
    const { version, date, added, fixed, improved } = node.attrs
    const sections = [
      { label: '新增', content: added, color: '#22c55e' },
      { label: '修复', content: fixed, color: '#ef4444' },
      { label: '优化', content: improved, color: '#508DFF' }
    ].filter(s => s.content)

    return ['div', {
      'data-type': 'update-log',
      'data-version': version || '',
      'data-date': date || '',
      contenteditable: 'false',
      style: 'background:#fafafa;border:1px solid #e9ecef;border-radius:8px;padding:14px;margin:12px 0'
    },
      ['div', { style: 'font-weight:700;font-size:15px;margin-bottom:2px' }, `v${version || '1.0.0'}`],
      ['div', { style: 'font-size:11px;color:#999;margin-bottom:10px' }, date || ''],
      ...sections.map(s => ['div', { style: 'margin-top:6px' },
        ['span', { style: `display:inline-block;background:${s.color};color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;margin-right:6px` }, s.label],
        ['span', { style: 'font-size:13px;color:#333' }, s.content]
      ])
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'update-log')
      dom.style.cssText = 'background:#fafafa;border:1px solid #e9ecef;border-radius:8px;padding:14px;margin:12px 0'

      const title = document.createElement('div')
      title.style.cssText = 'font-weight:700;font-size:15px;margin-bottom:2px'
      title.textContent = `v${node.attrs.version || '1.0.0'}`

      const date = document.createElement('div')
      date.style.cssText = 'font-size:11px;color:#999;margin-bottom:10px'
      date.textContent = node.attrs.date || ''

      dom.appendChild(title)
      dom.appendChild(date)

      const sections = [
        { label: '新增', content: node.attrs.added, color: '#22c55e' },
        { label: '修复', content: node.attrs.fixed, color: '#ef4444' },
        { label: '优化', content: node.attrs.improved, color: '#508DFF' }
      ]

      sections.forEach(s => {
        if (!s.content) return
        const row = document.createElement('div')
        row.style.cssText = 'margin-top:6px;display:flex;align-items:flex-start;gap:6px'

        const tag = document.createElement('span')
        tag.style.cssText = `display:inline-block;background:${s.color};color:#fff;padding:1px 6px;border-radius:3px;font-size:11px;white-space:nowrap`
        tag.textContent = s.label

        const txt = document.createElement('span')
        txt.style.cssText = 'font-size:13px;color:#333'
        txt.textContent = s.content

        row.appendChild(tag)
        row.appendChild(txt)
        dom.appendChild(row)
      })

      return { dom }
    }
  }
})
