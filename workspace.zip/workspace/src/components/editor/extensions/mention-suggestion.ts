import { VueRenderer } from '@tiptap/vue-3'
import tippy from 'tippy.js'
import MentionList from './MentionList.vue'

export default {
  items: async ({ query: searchQuery }: { query: string }) => {
    if (!searchQuery || searchQuery.length < 1) return []
    try {
      const { default: request } = await import('@/utils/http')
      const res: any = await request.get({
        url: '/api/community/user/search',
        params: { keyword: searchQuery }
      })
      if (Array.isArray(res)) {
        return res.slice(0, 10).map((u: any) => ({
          id: u.id.toString(),
          label: u.nickname || u.username,
          username: u.username
        }))
      }
      return []
    } catch {
      return []
    }
  },

  render: () => {
    let component: VueRenderer
    let popup: any

    return {
      onStart: (props: any) => {
        component = new VueRenderer(MentionList, {
          props,
          editor: props.editor
        })

        if (!props.clientRect) return

        popup = tippy('body', {
          getReferenceClientRect: props.clientRect,
          appendTo: () => document.body,
          content: component.element,
          showOnCreate: true,
          interactive: true,
          trigger: 'manual',
          placement: 'bottom-start'
        })
      },

      onUpdate(props: any) {
        component.updateProps(props)
        if (!props.clientRect) return
        popup[0].setProps({
          getReferenceClientRect: props.clientRect
        })
      },

      onKeyDown(props: any) {
        if (props.event.key === 'Escape') {
          popup[0].hide()
          return true
        }
        return component.ref?.onKeyDown(props)
      },

      onExit() {
        popup[0].destroy()
        component.destroy()
      }
    }
  }
}
