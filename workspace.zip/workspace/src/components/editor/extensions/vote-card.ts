import { Node } from '@tiptap/core'

export const VoteCard = Node.create({
  name: 'voteCard',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      question: { default: '' },
      options: { default: '[]', parseHTML: (el) => el.getAttribute('data-options') || '[]' },
      voteId: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-vote-id')) || 0 },
      maxSelect: { default: 1, parseHTML: (el) => Number(el.getAttribute('data-max-select')) || 1 },
      endTime: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="vote-card"]' }]
  },

  renderHTML({ node }) {
    const { question, options, voteId, maxSelect, endTime } = node.attrs
    let optsStr = ''
    try { optsStr = typeof options === 'string' ? options : JSON.stringify(options) } catch {}
    return ['div', {
      'data-type': 'vote-card',
      'data-question': question || '',
      'data-options': optsStr,
      'data-vote-id': voteId,
      'data-max-select': maxSelect,
      'data-end-time': endTime || '',
      contenteditable: 'false',
      style: 'background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef'
    },
      ['div', { style: 'font-weight:600;font-size:14px;margin-bottom:8px' }, question || '投票标题'],
      ['div', { style: 'font-size:12px;color:#999' }, `共 ${(typeof options === 'string' ? JSON.parse(options) : options || []).length} 个选项 · 最多选${maxSelect}项`]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'vote-card')
      dom.style.cssText = 'background:#f8f9fa;border-radius:8px;padding:12px;margin:12px 0;border:1px solid #e9ecef'

      const title = document.createElement('div')
      title.style.cssText = 'font-weight:600;font-size:14px;margin-bottom:8px'
      title.textContent = node.attrs.question || '投票标题'

      const info = document.createElement('div')
      info.style.cssText = 'font-size:12px;color:#999'
      let opts = node.attrs.options
      if (typeof opts === 'string') { try { opts = JSON.parse(opts) } catch {} }
      const count = Array.isArray(opts) ? opts.length : 0
      info.textContent = `共 ${count} 个选项 · 最多选${node.attrs.maxSelect || 1}项`

      dom.appendChild(title)
      dom.appendChild(info)
      return { dom }
    }
  }
})
