import { Node } from '@tiptap/core'

export const GalleryBlock = Node.create({
  name: 'galleryBlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      images: { default: '[]', parseHTML: (el) => el.getAttribute('data-images') || '[]' },
      captions: { default: '[]', parseHTML: (el) => el.getAttribute('data-captions') || '[]' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="gallery-block"]' }]
  },

  renderHTML({ node }) {
    let images: string[] = []
    try { images = JSON.parse(node.attrs.images || '[]') } catch {}
    const first = images[0] || ''

    return ['div', {
      'data-type': 'gallery-block',
      'data-images': node.attrs.images || '[]',
      contenteditable: 'false',
      style: 'border:1px solid #e9ecef;border-radius:8px;overflow:hidden;margin:12px 0'
    },
      ['div', {
        style: `width:100%;height:180px;background:#f0f0f0 url(${first}) center/cover no-repeat`
      }],
      ['div', { style: 'display:flex;gap:4px;padding:8px' },
        ...images.slice(0, 5).map((img: string, i: number) =>
          ['div', {
            style: `width:48px;height:48px;border-radius:4px;background:#e0e0e0 url(${img}) center/cover no-repeat;flex-shrink:0;opacity:${i === 0 ? '1' : '0.6'};border:${i === 0 ? '2px solid #508DFF' : '1px solid transparent'}`
          }]
        ),
        ['div', { style: 'font-size:11px;color:#999;display:flex;align-items:center;padding:0 4px' }, `${images.length} 张图片`]
      ]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'gallery-block')
      dom.style.cssText = 'border:1px solid #e9ecef;border-radius:8px;overflow:hidden;margin:12px 0'

      let images: string[] = []
      try { images = JSON.parse(node.attrs.images || '[]') } catch {}

      const preview = document.createElement('div')
      preview.style.cssText = `width:100%;height:180px;background:#f0f0f0 url(${images[0] || ''}) center/cover no-repeat`

      const thumbs = document.createElement('div')
      thumbs.style.cssText = 'display:flex;gap:4px;padding:8px;overflow-x:auto'

      images.slice(0, 6).forEach((img, i) => {
        const thumb = document.createElement('div')
        thumb.style.cssText = `width:48px;height:48px;border-radius:4px;background:#e0e0e0 url(${img}) center/cover no-repeat;flex-shrink:0;opacity:${i === 0 ? '1' : '0.6'};border:${i === 0 ? '2px solid #508DFF' : '1px solid transparent'}`
        thumbs.appendChild(thumb)
      })

      const badge = document.createElement('div')
      badge.style.cssText = 'font-size:11px;color:#999;display:flex;align-items:center;padding:0 4px;white-space:nowrap'
      badge.textContent = `${images.length} 张`

      thumbs.appendChild(badge)
      dom.appendChild(preview)
      dom.appendChild(thumbs)

      return { dom }
    }
  }
})
