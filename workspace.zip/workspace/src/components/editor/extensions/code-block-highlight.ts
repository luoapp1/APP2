import { Node } from '@tiptap/core'
import hljs from 'highlight.js'
import 'highlight.js/styles/github.css'

export const CodeBlockHighlight = Node.create({
  name: 'codeBlockHighlight',
  group: 'block',
  content: 'text*',
  defining: true,
  isolating: true,

  addAttributes() {
    return {
      language: { default: 'plaintext' }
    }
  },

  parseHTML() {
    return [{ tag: 'pre code' }]
  },

  renderHTML({ HTMLAttributes }) {
    return ['pre', ['code', HTMLAttributes, 0]]
  },

  addNodeView() {
    return ({ node, getPos }) => {
      const dom = document.createElement('div')
      dom.style.cssText = 'position:relative;margin:12px 0;border-radius:8px;overflow:hidden;background:#f6f8fa;border:1px solid #e1e4e8'

      const header = document.createElement('div')
      header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:6px 12px;background:#e8ecf0;border-bottom:1px solid #dde0e4'
      
      const lang = document.createElement('span')
      lang.textContent = node.attrs.language || 'text'
      lang.style.cssText = 'font-size:11px;color:#57606a;font-weight:500;text-transform:uppercase'
      
      const copyBtn = document.createElement('button')
      copyBtn.textContent = '复制'
      copyBtn.style.cssText = 'background:transparent;border:1px solid #d0d7de;border-radius:4px;padding:2px 8px;font-size:11px;color:#57606a;cursor:pointer'
      copyBtn.addEventListener('click', () => {
        const codeEl = dom.querySelector('code')
        navigator.clipboard.writeText(codeEl?.textContent || '').catch(() => {})
        copyBtn.textContent = '已复制'
        setTimeout(() => { copyBtn.textContent = '复制' }, 1500)
      })
      
      header.appendChild(lang)
      header.appendChild(copyBtn)
      dom.appendChild(header)

      const pre = document.createElement('pre')
      pre.style.cssText = 'position:relative;margin:0;padding:14px 16px;overflow-x:auto;font-size:13px;line-height:1.6;font-family:ui-monospace,SFMono-Regular,SF Mono,Menlo,Consolas,Liberation Mono,monospace'
      
      const code = document.createElement('code')
      pre.appendChild(code)
      dom.appendChild(pre)

      function applyHighlight() {
        const text = code.textContent || ''
        try {
          const langName = node.attrs.language || 'plaintext'
          if (langName !== 'plaintext') {
            const result = hljs.highlight(text, { language: langName, ignoreIllegals: true })
            code.innerHTML = result.value
          }
        } catch {
          code.textContent = text
        }
      }

      setTimeout(() => applyHighlight(), 10)

      return {
        dom,
        contentDOM: code,
        update: (updatedNode: any) => {
          if (updatedNode.type.name !== this.name) return false
          lang.textContent = updatedNode.attrs.language || 'text'

          setTimeout(() => {
            const text = code.textContent || ''
            try {
              const langName = updatedNode.attrs.language || 'plaintext'
              if (langName !== 'plaintext') {
                const result = hljs.highlight(text, { language: langName, ignoreIllegals: true })
                if (code.textContent === text) {
                  code.innerHTML = result.value
                }
              }
            } catch {}
          }, 20)
          
          return true
        },
        selectNode() {},
        stopEvent() { return false },
        ignoreMutation(mutation: MutationRecord) {
          if (mutation.type === 'characterData' && code.contains(mutation.target)) return false
          return true
        }
      }
    }
  },

  addCommands() {
    return {
      toggleCodeBlock:
        () =>
        ({ commands }: any) => {
          return commands.toggleNode(this.name, 'paragraph')
        }
    } as any
  }
})
