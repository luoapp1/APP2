import { Node } from '@tiptap/core'

export const NoticeBanner = Node.create({
  name: 'noticeBanner',
  group: 'block',
  content: 'inline*',
  isolating: true,

  addAttributes() {
    return {
      type: { default: 'info', parseHTML: (el) => el.getAttribute('data-banner-type') || 'info' },
      title: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="notice-banner"]' }]
  },

  renderHTML({ node, HTMLAttributes }) {
    const colors: Record<string, string> = {
      info: '#eff6ff;border-left:4px solid #508DFF;color:#1e40af',
      warning: '#fffbeb;border-left:4px solid #f59e0b;color:#92400e',
      danger: '#fef2f2;border-left:4px solid #ef4444;color:#991b1b',
      success: '#f0fdf4;border-left:4px solid #22c55e;color:#166534'
    }
    const style = `padding:10px 14px;margin:12px 0;border-radius:4px;background:${colors[HTMLAttributes.type || 'info']}`
    const typeLabels: Record<string, string> = { info: '系统公告', warning: '福利活动', danger: '风险警告', success: '付费须知' }
    const label = typeLabels[HTMLAttributes.type] || '公告'
    return [
      'div',
      { ...HTMLAttributes, 'data-type': 'notice-banner', 'data-banner-type': HTMLAttributes.type, style, contenteditable: 'false' },
      ['div', { style: 'font-size:12px;font-weight:600;margin-bottom:4px' }, `${label}：${HTMLAttributes.title || ''}`],
      ['div', { 'data-banner-content': 'true', style: 'font-size:13px;line-height:1.5' }, 0]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const colors: Record<string, any> = {
        info: { bg: '#eff6ff', border: '#508DFF', text: '#1e40af' },
        warning: { bg: '#fffbeb', border: '#f59e0b', text: '#92400e' },
        danger: { bg: '#fef2f2', border: '#ef4444', text: '#991b1b' },
        success: { bg: '#f0fdf4', border: '#22c55e', text: '#166534' }
      }
      const c = colors[node.attrs.type] || colors.info
      const typeLabels: Record<string, string> = { info: '系统公告', warning: '福利活动', danger: '风险警告', success: '付费须知' }

      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'notice-banner')
      dom.style.cssText = `padding:10px 14px;margin:12px 0;border-radius:4px;background:${c.bg};border-left:4px solid ${c.border};color:${c.text}`

      const header = document.createElement('div')
      header.style.cssText = 'font-size:12px;font-weight:600;margin-bottom:4px'
      header.textContent = `${typeLabels[node.attrs.type] || '公告'}：${node.attrs.title || ''}`

      const content = document.createElement('div')
      content.style.cssText = 'font-size:13px;line-height:1.5'

      dom.appendChild(header)
      dom.appendChild(content)

      return {
        dom,
        contentDOM: content
      }
    }
  }
})
