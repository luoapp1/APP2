import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'

const DRAG_HANDLE_KEY = new PluginKey('dragHandle')

export const DragHandle = Extension.create({
  name: 'dragHandle',

  addProseMirrorPlugins() {
    const handleEl = createHandle()

    const plugin = new Plugin({
      key: DRAG_HANDLE_KEY,
      view(editorView) {
        const editorDom = editorView.dom
        const editorParent = editorDom.parentElement || editorDom

        editorParent.style.position = editorParent.style.position || 'relative'

        if (handleEl) {
          editorParent.appendChild(handleEl)
        }

        const hide = () => {
          if (handleEl) handleEl.style.opacity = '0'
        }

        const updatePosition = (e: MouseEvent) => {
          if (!handleEl) return
          const target = e.target as HTMLElement
          const editorRect = editorView.dom.getBoundingClientRect()
          const pos = editorView.posAtCoords({ left: e.clientX, top: e.clientY })

          if (!pos || pos.inside < 0) {
            hide()
            return
          }

          const $pos = editorView.state.doc.resolve(pos.pos)
          if ($pos.depth < 1) {
            hide()
            return
          }

          const blockPos = $pos.before($pos.depth)
          const coords = editorView.coordsAtPos(blockPos)
          const blockNode = editorView.state.doc.nodeAt(blockPos)

          if (!blockNode || !blockNode.isBlock) {
            hide()
            return
          }

          requestAnimationFrame(() => {
            if (!handleEl) return
            handleEl.style.top = `${coords.top - editorRect.top}px`
            handleEl.style.left = `${target.closest('.ProseMirror') ? coords.left - editorRect.left - 30 : -28}px`
            handleEl.style.opacity = '0.8'
          })
        }

        const onMouseMove = (e: MouseEvent) => {
          if (e.target && (e.target as HTMLElement).closest('.ProseMirror')) {
            updatePosition(e)
          } else {
            hide()
          }
        }

        const onMouseLeave = () => hide()

        editorDom.addEventListener('mousemove', onMouseMove)
        editorDom.addEventListener('mouseleave', onMouseLeave)

        const onHandleMouseDown = (e: MouseEvent) => {
          e.preventDefault()
          if (!handleEl) return
          handleEl.style.opacity = '1'
          handleEl.style.cursor = 'grabbing'
        }

        const onHandleMouseUp = () => {
          if (!handleEl) return
          handleEl.style.opacity = '0'
          handleEl.style.cursor = 'grab'
        }

        const onHandleDragStart = (e: DragEvent) => {
          const rect = editorView.dom.getBoundingClientRect()
          const top = parseInt(handleEl!.style.top) || 0
          const targetY = rect.top + top + 10
          const pos = editorView.posAtCoords({ left: rect.left + 50, top: targetY })
          if (!pos || pos.inside < 0) return
          const $pos = editorView.state.doc.resolve(pos.pos)
          const blockPos = $pos.before($pos.depth)
          e.dataTransfer?.setData('text/plain', String(blockPos))
          e.dataTransfer!.effectAllowed = 'move'
        }

        const onHandleDragEnd = () => {
          hide()
          handleEl!.style.cursor = 'grab'
        }

        if (handleEl) {
          handleEl.addEventListener('mousedown', onHandleMouseDown)
          handleEl.addEventListener('mouseup', onHandleMouseUp)
          handleEl.addEventListener('dragstart', onHandleDragStart)
          handleEl.addEventListener('dragend', onHandleDragEnd)
        }

        const onHandleDragOver = (e: DragEvent) => e.preventDefault()

        const onHandleDrop = (e: DragEvent) => {
          e.preventDefault()
          const from = parseInt(e.dataTransfer?.getData('text/plain') || '')
          if (isNaN(from) || from < 0) return

          const rect = editorView.dom.getBoundingClientRect()
          const top = parseInt(handleEl!.style.top) || 0
          const targetY = rect.top + top + 5
          const cursorPos = editorView.posAtCoords({ left: rect.left + 50, top: targetY })
          if (!cursorPos || cursorPos.inside < 0) return

          const $target = editorView.state.doc.resolve(cursorPos.pos)
          const targetBefore = $target.before($target.depth)
          if (targetBefore === from) return

          const sourceNode = editorView.state.doc.nodeAt(from)
          if (!sourceNode) return

          const fromIdx = editorView.state.doc.resolve(from).index(editorView.state.doc.resolve(from).depth - 1)
          const toIdx = editorView.state.doc.resolve(targetBefore).index(editorView.state.doc.resolve(targetBefore).depth - 1)
          const parentDepth = editorView.state.doc.resolve(from).depth - 1
          const parentPos = editorView.state.doc.resolve(from).before(parentDepth)
          const parent = editorView.state.doc.nodeAt(parentPos)
          if (!parent) return

          const adjustedTo = toIdx > fromIdx ? toIdx + 1 : toIdx
          const tr = editorView.state.tr

          const parentStart = editorView.state.doc.resolve(parentPos).start(parentDepth)
          const absFrom = from
          const absTo = absFrom + sourceNode.nodeSize
          tr.delete(absFrom, absTo)

          let insertAbsPos = parentStart
          for (let i = 0; i < Math.min(adjustedTo, parent.childCount); i++) {
            insertAbsPos += parent.child(i).nodeSize
          }

          tr.insert(insertAbsPos, sourceNode)
          editorView.dispatch(tr)
          editorView.focus()
          hide()
        }

        setTimeout(() => {
          if (handleEl) {
            handleEl.addEventListener('dragover', onHandleDragOver)
            handleEl.addEventListener('drop', onHandleDrop)
          }
        }, 100)

        return {
          destroy() {
            editorDom.removeEventListener('mousemove', onMouseMove)
            editorDom.removeEventListener('mouseleave', onMouseLeave)
            if (handleEl) {
              handleEl.removeEventListener('mousedown', onHandleMouseDown)
              handleEl.removeEventListener('mouseup', onHandleMouseUp)
              handleEl.removeEventListener('dragstart', onHandleDragStart)
              handleEl.removeEventListener('dragend', onHandleDragEnd)
              handleEl.removeEventListener('dragover', onHandleDragOver)
              handleEl.removeEventListener('drop', onHandleDrop)
              handleEl.remove()
            }
          }
        }
      }
    })

    return [plugin]
  }
})

function createHandle() {
  const el = document.createElement('div')
  el.className = 'drag-handle'
  el.innerHTML = '<span class="drag-handle-icon">⠿</span>'
  el.style.cssText = 'position:absolute;left:-28px;top:-9999px;width:22px;height:22px;display:flex;align-items:center;justify-content:center;cursor:grab;z-index:50;opacity:0;border-radius:4px;background:#f0f0f0;color:#999;font-size:14px;transition:opacity .15s'
  el.setAttribute('draggable', 'true')
  return el
}
