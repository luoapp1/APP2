import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'

const DRAG_HANDLE_KEY = new PluginKey('dragHandle')

export const DragHandle = Extension.create({
  name: 'dragHandle',

  addProseMirrorPlugins() {
    let handleEl: HTMLElement | null = null

    const createHandle = () => {
      const el = document.createElement('div')
      el.className = 'drag-handle'
      el.innerHTML = '<span class="drag-handle-icon">⠿</span>'
      el.style.cssText = 'position:absolute;left:-28px;top:-9999px;width:22px;height:22px;display:flex;align-items:center;justify-content:center;cursor:grab;z-index:50;opacity:0;border-radius:4px;background:#f0f0f0;color:#999;font-size:14px;transition:opacity .15s'
      el.setAttribute('draggable', 'true')
      return el
    }

    handleEl = createHandle()

    const plugin = new Plugin({
      key: DRAG_HANDLE_KEY,
      view(editorView) {
        const editorDom = editorView.dom
        const editorParent = editorDom.parentElement || editorDom

        editorParent.style.position = editorParent.style.position || 'relative'

        if (handleEl) {
          editorParent.appendChild(handleEl)
        }

        const hide = () => {
          if (handleEl) handleEl.style.opacity = '0'
        }

        const updatePosition = (e: MouseEvent) => {
          if (!handleEl) return
          const target = e.target as HTMLElement
          const editorRect = editorView.dom.getBoundingClientRect()
          const pos = editorView.posAtCoords({ left: e.clientX, top: e.clientY })

          if (!pos || pos.inside < 0) {
            hide()
            return
          }

          const $pos = editorView.state.doc.resolve(pos.pos)
          if ($pos.depth < 1) {
            hide()
            return
          }

          const blockPos = $pos.before($pos.depth)
          const coords = editorView.coordsAtPos(blockPos)
          const blockNode = editorView.state.doc.nodeAt(blockPos)

          if (!blockNode || !blockNode.isBlock) {
            hide()
            return
          }

          requestAnimationFrame(() => {
            if (!handleEl) return
            handleEl.style.top = `${coords.top - editorRect.top}px`
            handleEl.style.left = `${target.closest('.ProseMirror') ? coords.left - editorRect.left - 30 : -28}px`
            handleEl.style.opacity = '0.8'
          })
        }

        const onMouseMove = (e: MouseEvent) => {
          if (e.target && (e.target as HTMLElement).closest('.ProseMirror')) {
            updatePosition(e)
          } else {
            hide()
          }
        }

        const onMouseLeave = () => hide()

        editorDom.addEventListener('mousemove', onMouseMove)
        editorDom.addEventListener('mouseleave', onMouseLeave)

        if (handleEl) {
          handleEl.addEventListener('mousedown', (e: MouseEvent) => {
            e.preventDefault()
            if (!handleEl) return
            handleEl.style.opacity = '1'
            handleEl.style.cursor = 'grabbing'
          })

          handleEl.addEventListener('mouseup', () => {
            if (!handleEl) return
            handleEl.style.opacity = '0'
            handleEl.style.cursor = 'grab'
          })

          handleEl.addEventListener('dragstart', (e: DragEvent) => {
            const rect = editorView.dom.getBoundingClientRect()
            const top = parseInt(handleEl!.style.top) || 0
            const targetY = rect.top + top + 10
            const pos = editorView.posAtCoords({ left: rect.left + 50, top: targetY })
            if (!pos || pos.inside < 0) return
            const $pos = editorView.state.doc.resolve(pos.pos)
            const blockPos = $pos.before($pos.depth)
            e.dataTransfer?.setData('text/plain', String(blockPos))
            e.dataTransfer!.effectAllowed = 'move'
          })

          handleEl.addEventListener('dragend', () => {
            hide()
            handleEl!.style.cursor = 'grab'
          })
        }

        setTimeout(() => {
          if (handleEl) {
            handleEl.addEventListener('dragover', (e: DragEvent) => e.preventDefault())
            handleEl.addEventListener('drop', (e: DragEvent) => {
              e.preventDefault()
              const from = parseInt(e.dataTransfer?.getData('text/plain') || '')
              if (isNaN(from) || from < 0) return

              const rect = editorView.dom.getBoundingClientRect()
              const top = parseInt(handleEl!.style.top) || 0
              const targetY = rect.top + top + 5
              const cursorPos = editorView.posAtCoords({ left: rect.left + 50, top: targetY })
              if (!cursorPos || cursorPos.inside < 0) return

              const $target = editorView.state.doc.resolve(cursorPos.pos)
              const targetBefore = $target.before($target.depth)
              if (targetBefore === from) return

              const sourceNode = editorView.state.doc.nodeAt(from)
              if (!sourceNode) return

              const fromIdx = editorView.state.doc.resolve(from).index(editorView.state.doc.resolve(from).depth - 1)
              const toIdx = editorView.state.doc.resolve(targetBefore).index(editorView.state.doc.resolve(targetBefore).depth - 1)
              const parentDepth = editorView.state.doc.resolve(from).depth - 1
              const parentPos = editorView.state.doc.resolve(from).before(parentDepth)
              const parent = editorView.state.doc.nodeAt(parentPos)
              if (!parent) return

              const adjustedTo = toIdx > fromIdx ? toIdx + 1 : toIdx
              const tr = editorView.state.tr

              const parentStart = editorView.state.doc.resolve(parentPos).start(parentDepth)
              const absFrom = from
              const absTo = absFrom + sourceNode.nodeSize
              tr.delete(absFrom, absTo)

              const children = parent.content
              let insertAbsPos = parentStart
              for (let i = 0; i < Math.min(adjustedTo, children.childCount); i++) {
                insertAbsPos += children.child(i).nodeSize
              }

              tr.insert(insertAbsPos, sourceNode)
              editorView.dispatch(tr)
              editorView.focus()
              hide()
            })
          }
        }, 100)

        return {
          destroy() {
            editorDom.removeEventListener('mousemove', onMouseMove)
            editorDom.removeEventListener('mouseleave', onMouseLeave)
            if (handleEl) {
              handleEl.remove()
              handleEl = null
            }
          }
        }
      }
    })

    return [plugin]
  },

  onDestroy() {
    handleEl = null
  }
})
