import { Node } from '@tiptap/core'

export const OriginalStatement = Node.create({
  name: 'originalStatement',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      author: { default: '' },
      license: { default: 'all-rights', parseHTML: (el) => el.getAttribute('data-license') || 'all-rights' },
      allowReprint: { default: 'no', parseHTML: (el) => el.getAttribute('data-allow-reprint') || 'no' },
      reprintRule: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="original-statement"]' }]
  },

  renderHTML({ node }) {
    const licenseLabels: Record<string, string> = {
      'all-rights': '保留所有权利',
      'cc-by': 'CC BY 署名',
      'cc-by-sa': 'CC BY-SA 署名-相同方式共享',
      'cc-by-nc': 'CC BY-NC 署名-非商业性使用',
      'cc-by-nd': 'CC BY-ND 署名-禁止演绎'
    }
    const allowLabels: Record<string, string> = {
      'no': '禁止转载',
      'yes': '允许转载',
      'need-permit': '需授权转载'
    }
    return ['div', {
      'data-type': 'original-statement',
      'data-license': node.attrs.license,
      'data-allow-reprint': node.attrs.allowReprint,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 14px;margin:12px 0'
    },
      ['div', { style: 'font-size:24px;flex-shrink:0' }, '©'],
      ['div', { style: 'flex:1;min-width:0' },
        ['div', { style: 'font-size:14px;font-weight:600;color:#166534' }, '原创声明'],
        ['div', { style: 'font-size:12px;color:#16a34a;margin-top:4px' },
          `作者：${node.attrs.author || '未知'} · 许可证：${licenseLabels[node.attrs.license] || '保留所有权利'}`],
        ['div', { style: 'font-size:11px;color:#86efac;margin-top:2px' },
          `${allowLabels[node.attrs.allowReprint] || '禁止转载'}${node.attrs.reprintRule ? ' · ' + node.attrs.reprintRule : ''}`]
      ]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const licenseLabels: Record<string, string> = {
        'all-rights': '保留所有权利', 'cc-by': 'CC BY 署名', 'cc-by-sa': 'CC BY-SA',
        'cc-by-nc': 'CC BY-NC', 'cc-by-nd': 'CC BY-ND'
      }
      const allowLabels: Record<string, string> = { 'no': '禁止转载', 'yes': '允许转载', 'need-permit': '需授权转载' }

      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'original-statement')
      dom.style.cssText = 'display:flex;align-items:center;gap:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 14px;margin:12px 0'

      const icon = document.createElement('div')
      icon.textContent = '©'
      icon.style.cssText = 'font-size:24px;flex-shrink:0'

      const info = document.createElement('div')
      info.style.cssText = 'flex:1;min-width:0'

      const title = document.createElement('div')
      title.textContent = '原创声明'
      title.style.cssText = 'font-size:14px;font-weight:600;color:#166534'

      const detail = document.createElement('div')
      detail.textContent = `作者：${node.attrs.author || '未知'} · ${licenseLabels[node.attrs.license] || '保留所有权利'}`
      detail.style.cssText = 'font-size:12px;color:#16a34a;margin-top:4px'

      const rule = document.createElement('div')
      rule.textContent = `${allowLabels[node.attrs.allowReprint] || '禁止转载'}${node.attrs.reprintRule ? ' · ' + node.attrs.reprintRule : ''}`
      rule.style.cssText = 'font-size:11px;color:#86efac;margin-top:2px'

      info.appendChild(title)
      info.appendChild(detail)
      info.appendChild(rule)
      dom.appendChild(icon)
      dom.appendChild(info)
      return { dom }
    }
  }
})
