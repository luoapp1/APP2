import { Node } from '@tiptap/core'

export const GoodsCard = Node.create({
  name: 'goodsCard',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      goodsId: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-goods-id')) || 0 },
      name: { default: '' },
      price: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-price')) || 0 },
      image: { default: '' },
      link: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="goods-card"]' }]
  },

  renderHTML({ node }) {
    const { goodsId, name, price, image, link } = node.attrs
    return ['div', {
      'data-type': 'goods-card',
      'data-goods-id': goodsId,
      'data-price': price,
      'data-name': name || '',
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #e9ecef;border-radius:8px;padding:10px;margin:12px 0'
    },
      ['div', {
        style: `width:56px;height:56px;border-radius:6px;background:#f0f0f0 url(${image || ''}) center/cover no-repeat;flex-shrink:0`
      }],
      ['div', { style: 'flex:1;min-width:0' },
        ['div', { style: 'font-size:14px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, name || '商品名称'],
        ['div', { style: 'font-size:16px;font-weight:700;color:#e74c3c;margin-top:4px' }, `￥${price}`]
      ],
      ['div', {
        style: 'background:#508DFF;color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;flex-shrink:0;cursor:pointer'
      }, '立即购买']
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'goods-card')
      dom.style.cssText = 'display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #e9ecef;border-radius:8px;padding:10px;margin:12px 0'

      const img = document.createElement('div')
      img.style.cssText = `width:56px;height:56px;border-radius:6px;background:#f0f0f0 url(${node.attrs.image || ''}) center/cover no-repeat;flex-shrink:0`

      const info = document.createElement('div')
      info.style.cssText = 'flex:1;min-width:0'

      const name = document.createElement('div')
      name.style.cssText = 'font-size:14px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
      name.textContent = node.attrs.name || '商品名称'

      const price = document.createElement('div')
      price.style.cssText = 'font-size:16px;font-weight:700;color:#e74c3c;margin-top:4px'
      price.textContent = `￥${node.attrs.price || 0}`

      info.appendChild(name)
      info.appendChild(price)

      const btn = document.createElement('div')
      btn.style.cssText = 'background:#508DFF;color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;flex-shrink:0'
      btn.textContent = '立即购买'

      dom.appendChild(img)
      dom.appendChild(info)
      dom.appendChild(btn)
      return { dom }
    }
  }
})
