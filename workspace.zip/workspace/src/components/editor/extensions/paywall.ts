import { Node } from '@tiptap/core'

export const Paywall = Node.create({
  name: 'paywall',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      price: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-price')) || 0 },
      priceType: { default: 'balance', parseHTML: (el) => el.getAttribute('data-price-type') || 'balance' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="paywall"]' }]
  },

  renderHTML({ node }) {
    const { price, priceType } = node.attrs
    const label = priceType === 'points' ? `${price}积分` : `￥${price}`
    return ['div', {
      'data-type': 'paywall',
      'data-price': price,
      'data-price-type': priceType,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d0d0d0;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#999;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容需付费 ${label} 后查看`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d0d0d0;min-width:20px' }]
    ]
  }
})
