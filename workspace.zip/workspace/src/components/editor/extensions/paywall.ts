import { Node } from '@tiptap/core'

let globalLabelMap: Record<string, string> = { balance: '￥', points: '积分' }

export function setPaywallCurrencyLabels(map: Record<string, string>) {
  globalLabelMap = { ...globalLabelMap, ...map }
}

function formatSingleLabel(price: number, currencyKey: string): string {
  const label = globalLabelMap[currencyKey] || currencyKey
  return label === '￥' ? `￥${price}` : `${price}${label}`
}

export const Paywall = Node.create({
  name: 'paywall',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      price: { default: 0 },
      priceType: { default: 'balance' },
      prices: {
        default: [],
        parseHTML: (el) => {
          const raw = el.getAttribute('data-prices')
          if (raw) { try { return JSON.parse(raw) } catch {} }
          return []
        },
        renderHTML: (attrs) => ({ 'data-prices': JSON.stringify(attrs.prices) })
      }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="paywall"]' }]
  },

  renderHTML({ node }) {
    const { price, priceType, prices } = node.attrs
    let label: string
    if (Array.isArray(prices) && prices.length) {
      label = prices.map((p: any) => formatSingleLabel(p.price, p.currencyKey)).join(' / ')
    } else {
      label = formatSingleLabel(price, priceType || 'balance')
    }
    return ['div', {
      'data-type': 'paywall',
      'data-price': price,
      'data-price-type': priceType,
      'data-prices': JSON.stringify(prices || []),
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d0d0d0;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#999;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容需付费 ${label} 后查看`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#d0d0d0;min-width:20px' }]
    ]
  }
})
