import { Node } from '@tiptap/core'

export const PostRefCard = Node.create({
  name: 'postRefCard',
  group: 'block',
  content: '',
  atom: true,
  isolating: true,

  addAttributes() {
    return {
      postId: { default: 0 },
      title: { default: '' },
      author: { default: '' },
      sectionName: { default: '' },
      summary: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="post-ref"]' }]
  },

  renderHTML({ node }) {
    const href = `#/community/post/${node.attrs.postId}`
    return ['div', {
      'data-type': 'post-ref',
      'data-post-id': node.attrs.postId,
      contenteditable: 'false',
      style: 'background:#f0f6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px 16px;margin:12px 0;cursor:pointer;position:relative'
    },
      ['div', { style: 'display:flex;align-items:center;gap:8px;margin-bottom:8px' },
        ['span', { style: 'font-size:14px' }, '📌'],
        ['span', { style: 'font-size:13px;font-weight:600;color:#1e40af' }, node.attrs.title || '引用帖子'],
        ['span', { style: 'font-size:11px;color:#fff;background:#3b82f6;padding:2px 8px;border-radius:10px;margin-left:auto' }, '点击查看']
      ],
      ['div', { style: 'font-size:12px;color:#6b7280;margin-bottom:4px' },
        node.attrs.author ? `${node.attrs.author}` : '',
        node.attrs.sectionName ? ` · ${node.attrs.sectionName}` : ''
      ],
      node.attrs.summary ? ['div', { style: 'font-size:12px;color:#9ca3af;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden' }, node.attrs.summary] : ['div'],
      ['a', { href, style: 'position:absolute;inset:0;z-index:1;text-decoration:none' }]
    ]
  },

  addNodeView() {
    return ({ node, editor }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'post-ref')
      dom.style.cssText = 'background:#f0f6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px 16px;margin:12px 0;cursor:pointer;position:relative'

      const header = document.createElement('div')
      header.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:8px'

      const icon = document.createElement('span')
      icon.textContent = '📌'
      icon.style.cssText = 'font-size:14px'
      header.appendChild(icon)

      const title = document.createElement('span')
      title.textContent = node.attrs.title || '引用帖子'
      title.style.cssText = 'font-size:13px;font-weight:600;color:#1e40af'
      header.appendChild(title)

      const badge = document.createElement('span')
      badge.textContent = '点击查看'
      badge.style.cssText = 'font-size:11px;color:#fff;background:#3b82f6;padding:2px 8px;border-radius:10px;margin-left:auto'
      header.appendChild(badge)

      dom.appendChild(header)

      if (node.attrs.author || node.attrs.sectionName) {
        const meta = document.createElement('div')
        meta.style.cssText = 'font-size:12px;color:#6b7280;margin-bottom:4px'
        meta.textContent = [node.attrs.author, node.attrs.sectionName].filter(Boolean).join(' · ')
        dom.appendChild(meta)
      }

      if (node.attrs.summary) {
        const summary = document.createElement('div')
        summary.textContent = node.attrs.summary
        summary.style.cssText = 'font-size:12px;color:#9ca3af;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden'
        dom.appendChild(summary)
      }

      dom.addEventListener('click', () => {
        const postId = node.attrs.postId
        if (postId) {
          const base = window.location.hash.replace(/\/p\/create\/.*/, '')
          window.location.hash = `${base}/community/post/${postId}`
        }
      })

      return { dom }
    }
  },

  addCommands() {
    return {
      insertPostRef:
        (attrs: { postId: number; title: string; author?: string; sectionName?: string; summary?: string }) =>
        ({ commands }: any) => {
          return commands.insertContent({ type: this.name, attrs })
        }
    } as any
  }
})
