import { Node } from '@tiptap/core'

export const PostRefCard = Node.create({
  name: 'postRefCard',
  group: 'block',
  content: '',
  atom: true,
  isolating: true,

  addAttributes() {
    return {
      postId: { default: 0 },
      title: { default: '' },
      author: { default: '' },
      sectionName: { default: '' },
      summary: { default: '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="post-ref"]' }]
  },

  renderHTML({ node }) {
    const href = `#/community/post/${node.attrs.postId}`
    return ['div', {
      'data-type': 'post-ref',
      'data-post-id': node.attrs.postId,
      contenteditable: 'false',
      style: 'background:#f0f6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px 16px;margin:12px 0;cursor:pointer;position:relative'
    },
      ['div', { style: 'display:flex;align-items:center;gap:8px' },
        ['span', { style: 'font-size:14px' }, '\u{1F4CC}'],
        ['span', { style: 'font-size:13px;font-weight:600;color:#1e40af' }, node.attrs.title || '\u5F15\u7528\u5E16\u5B50']
      ],
      ['a', { href, style: 'position:absolute;inset:0;z-index:1;text-decoration:none' }]
    ]
  },

  addNodeView() {
    return ({ node }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'post-ref')
      dom.style.cssText = 'background:#f0f6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px 16px;margin:12px 0;cursor:pointer;position:relative'

      const header = document.createElement('div')
      header.style.cssText = 'display:flex;align-items:center;gap:8px'

      const icon = document.createElement('span')
      icon.textContent = '\u{1F4CC}'
      icon.style.cssText = 'font-size:14px'
      header.appendChild(icon)

      const title = document.createElement('span')
      title.textContent = node.attrs.title || '\u5F15\u7528\u5E16\u5B50'
      title.style.cssText = 'font-size:13px;font-weight:600;color:#1e40af'
      header.appendChild(title)

      dom.appendChild(header)

      dom.addEventListener('click', () => {
        const postId = node.attrs.postId
        if (postId) {
          const base = window.location.hash.replace(/\/p\/create\/.*/, '')
          window.location.hash = `${base}/community/post/${postId}`
        }
      })

      return { dom }
    }
  },

  addCommands() {
    return {
      insertPostRef:
        (attrs: { postId: number; title: string; author?: string; sectionName?: string; summary?: string }) =>
        ({ commands }: any) => {
          return commands.insertContent({ type: this.name, attrs })
        }
    } as any
  }
})
