import { Node } from '@tiptap/core'

export const LevelPrivilegeCard = Node.create({
  name: 'levelPrivilegeCard',
  group: 'block',
  content: '',
  atom: true,
  isolating: true,

  addAttributes() {
    return {
      level: { default: 1 },
      levelName: { default: '普通会员' },
      privileges: { default: '[]' },
      currentUserLevel: { default: 0 },
      showAction: { default: true }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="level-privilege"]' }]
  },

  renderHTML({ node }) {
    const privs: string[] = JSON.parse(node.attrs.privileges || '[]')
    return ['div', {
      'data-type': 'level-privilege',
      'data-level': node.attrs.level,
      style: 'background:linear-gradient(135deg,#fef3c7,#fef9c3);border:1px solid #fcd34d;border-radius:14px;padding:16px;margin:12px 0'
    },
      ['div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:10px' },
        ['div', { style: 'display:flex;align-items:center;gap:8px' },
          ['span', { style: 'font-size:20px' }, '👑'],
          ['span', { style: 'font-size:15px;font-weight:700;color:#92400e' }, `Lv.${node.attrs.level} ${node.attrs.levelName}`]
        ],
        ['span', { style: 'font-size:11px;background:#f59e0b;color:#fff;padding:3px 10px;border-radius:12px;font-weight:600' }, '等级权益']
      ],
      ['div', { style: 'display:flex;flex-direction:column;gap:6px' },
        ...privs.map((p: string) => ['div', { style: 'display:flex;align-items:center;gap:6px;font-size:13px;color:#78350f' },
          ['span', { style: 'color:#f59e0b;font-size:16px' }, '✦'],
          ['span', {}, p]
        ])
      ],
      node.attrs.currentUserLevel < node.attrs.level
        ? ['div', { style: 'margin-top:12px;text-align:center' },
          ['span', { style: 'display:inline-block;background:#f59e0b;color:#fff;padding:6px 24px;border-radius:20px;font-size:13px;font-weight:600;cursor:pointer' },
            `升级到 Lv.${node.attrs.level} 解锁以上权益`
          ]
        ]
        : ['div', { style: 'margin-top:12px;text-align:center' },
          ['span', { style: 'display:inline-block;background:#10b981;color:#fff;padding:6px 24px;border-radius:20px;font-size:13px;font-weight:600' }, '你已解锁以上权益']
        ]
    ]
  },

  addNodeView() {
    return ({ node, editor }) => {
      const dom = document.createElement('div')
      dom.setAttribute('data-type', 'level-privilege')
      dom.style.cssText = 'background:linear-gradient(135deg,#fef3c7,#fef9c3);border:1px solid #fcd34d;border-radius:14px;padding:16px;margin:12px 0;position:relative'

      const header = document.createElement('div')
      header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:10px'

      const left = document.createElement('div')
      left.style.cssText = 'display:flex;align-items:center;gap:8px'

      const crown = document.createElement('span')
      crown.textContent = '👑'
      crown.style.cssText = 'font-size:20px'
      left.appendChild(crown)

      const label = document.createElement('span')
      label.textContent = `Lv.${node.attrs.level} ${node.attrs.levelName}`
      label.style.cssText = 'font-size:15px;font-weight:700;color:#92400e'
      left.appendChild(label)

      header.appendChild(left)

      const badge = document.createElement('span')
      badge.textContent = '等级权益'
      badge.style.cssText = 'font-size:11px;background:#f59e0b;color:#fff;padding:3px 10px;border-radius:12px;font-weight:600'
      header.appendChild(badge)

      dom.appendChild(header)

      const privs: string[] = JSON.parse(node.attrs.privileges || '[]')
      const list = document.createElement('div')
      list.style.cssText = 'display:flex;flex-direction:column;gap:6px'

      privs.forEach((p: string) => {
        const item = document.createElement('div')
        item.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:13px;color:#78350f'

        const star = document.createElement('span')
        star.textContent = '✦'
        star.style.cssText = 'color:#f59e0b;font-size:16px'
        item.appendChild(star)

        const text = document.createElement('span')
        text.textContent = p
        item.appendChild(text)

        list.appendChild(item)
      })

      dom.appendChild(list)

      const action = document.createElement('div')
      action.style.cssText = 'margin-top:12px;text-align:center'

      if (node.attrs.currentUserLevel < node.attrs.level) {
        const btn = document.createElement('span')
        btn.textContent = `升级到 Lv.${node.attrs.level} 解锁以上权益`
        btn.style.cssText = 'display:inline-block;background:#f59e0b;color:#fff;padding:6px 24px;border-radius:20px;font-size:13px;font-weight:600;cursor:pointer'
        btn.addEventListener('click', () => {
          window.location.hash = '#/user/level'
        })
        action.appendChild(btn)
      } else {
        const unlocked = document.createElement('span')
        unlocked.textContent = '你已解锁以上权益'
        unlocked.style.cssText = 'display:inline-block;background:#10b981;color:#fff;padding:6px 24px;border-radius:20px;font-size:13px;font-weight:600'
        action.appendChild(unlocked)
      }

      dom.appendChild(action)

      return { dom }
    }
  },

  addCommands() {
    return {
      insertLevelPrivilege:
        (attrs: { level: number; levelName: string; privileges: string[]; currentUserLevel: number }) =>
        ({ commands }: any) => {
          return commands.insertContent({
            type: this.name,
            attrs: { ...attrs, privileges: JSON.stringify(attrs.privileges) }
          })
        }
    } as any
  }
})
