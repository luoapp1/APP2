import { Node } from '@tiptap/core'

export const TitleUnlock = Node.create({
  name: 'titleUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      titleId: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-title-id')) || 0 },
      titleName: { default: '', parseHTML: (el) => el.getAttribute('data-title-name') || '' },
      icon: { default: '', parseHTML: (el) => el.getAttribute('data-title-icon') || '' },
      color: { default: '#409EFF', parseHTML: (el) => el.getAttribute('data-title-color') || '#409EFF' },
      bgColor: { default: '#ecf5ff', parseHTML: (el) => el.getAttribute('data-title-bg-color') || '#ecf5ff' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="titleUnlock"]' }]
  },

  renderHTML({ node }) {
    const { titleId, titleName, icon, color, bgColor } = node.attrs
    return ['div', {
      'data-type': 'titleUnlock',
      'data-title-id': titleId,
      'data-title-name': titleName,
      'data-title-icon': icon,
      'data-title-color': color,
      'data-title-bg-color': bgColor,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#6366F1;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#6366F1;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容需要称号「${titleName}」才可查看`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#6366F1;min-width:20px' }]
    ]
  }
})
