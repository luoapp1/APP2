import { Node } from '@tiptap/core'

export const TitleUnlock = Node.create({
  name: 'titleUnlock',
  group: 'block',
  content: '',
  isolating: true,

  addAttributes() {
    return {
      titleId: { default: 0, parseHTML: (el) => Number(el.getAttribute('data-title-id')) || 0 },
      titleName: { default: '', parseHTML: (el) => el.getAttribute('data-title-name') || '' }
    }
  },

  parseHTML() {
    return [{ tag: 'div[data-type="titleUnlock"]' }]
  },

  renderHTML({ node }) {
    const { titleId, titleName } = node.attrs
    return ['div', {
      'data-type': 'titleUnlock',
      'data-title-id': titleId,
      'data-title-name': titleName,
      contenteditable: 'false',
      style: 'display:flex;align-items:center;gap:12px;margin:20px 0;padding:4px 0;user-select:none'
    },
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#6366F1;min-width:20px' }],
      ['span', { contenteditable: 'false', style: 'font-size:12px;color:#6366F1;white-space:nowrap;flex-shrink:0;line-height:1' }, `以下内容需要称号「${titleName}」才可查看`],
      ['span', { contenteditable: 'false', style: 'flex:1;height:1px;background:#6366F1;min-width:20px' }]
    ]
  }
})
