<template>
  <div
    class="bg-white mx-3 mb-2 rounded-xl px-3 pt-2.5 pb-2.5 cursor-pointer active:bg-[#FAFAFA] transition-colors"
    @click="$emit('click', post.id)"
  >
    <!-- Author Row -->
    <div class="flex items-center gap-0.5">
      <div class="post-avatar-wrap">
        <img v-if="activeFrameUrl && post.userId === currentUserId" :src="activeFrameUrl" class="post-avatar-frame" />
        <div class="post-avatar">
          <img src="@imgs/user/avatar.webp" class="post-avatar-pic" />
          <img v-if="post.userAvatar" :src="post.userAvatar" class="post-avatar-pic post-avatar-user" @error="($event.target as HTMLImageElement).style.display='none'"/>
        </div>
      </div>
      <div class="post-author-info">
        <div class="post-author-col">
          <div class="post-author-row">
            <span class="post-username">{{ post.userName }}</span>
            <img v-for="(icon, idx) in (post.userAllTitleIcons || '').split('|||').filter(Boolean)" :key="idx" :src="icon" class="post-title-icon" @error="($event.target as HTMLImageElement).style.display='none'" />
          </div>
          <div class="post-author-meta">
            <img v-if="post.userExpLevelIcon && post.userExpLevelIcon.startsWith('http')" :src="post.userExpLevelIcon" class="post-exp-icon" @error="($event.target as HTMLImageElement).style.display='none'" />
            <img v-if="post.userMemberLevelIcon" :src="post.userMemberLevelIcon" class="post-member-name-icon" @error="($event.target as HTMLImageElement).style.display='none'" />
          </div>
        </div>
      </div>
    </div>

    <!-- Title -->
    <div class="mt-2.5 text-[16px] text-[#111] font-bold leading-[1.45] line-clamp-2">
      <span v-if="post.isPinned" class="post-header-badge pin">置顶</span>
      <span v-if="post.isEssence" class="post-header-badge essence">精</span>
      <span v-if="post.isHot" class="post-header-badge hot">热</span>
      <span v-if="post.customBadge" class="post-header-badge custom">{{ post.customBadge }}</span>
      <span v-if="post.isLocked" class="post-header-badge lock">锁</span>
      <span v-if="post.collectionId" class="post-header-badge collection" @click.stop="$router.push('/community/collection/' + post.collectionId)">合集</span>
      {{ post.title }}
    </div>

    <!-- Content + Thumbnail -->
    <div class="mt-2" v-if="post.content || post._previewCard || (post.images && post.images.length)">
      <!-- === LOCK CARDS === -->
      <!-- 付费解锁 -->
      <div v-if="post._previewCard?.type === 'paywall'" class="relative bg-gradient-to-br from-[#FFF7ED] via-white to-white rounded-2xl p-4 shadow-md border border-[#FED7AA] overflow-hidden mt-1">
        <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
          <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          付费阅读
        </div>
        <div class="absolute top-2.5 right-3 bg-[#22C55E] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm" v-if="post.soldCount > 0">
          已售 {{ post.soldCount }}
        </div>
        <div class="flex items-center gap-2 mt-2 mb-4">
          <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-[#F97316]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          </div>
          <span class="text-[13px] text-[#555] font-medium">该帖子部分内容已隐藏</span>
        </div>
        <div class="text-center mb-4">
           <div class="inline-flex items-baseline gap-0.5">
             <span v-if="post._previewCard.priceType !== 'points'" class="text-[18px] font-bold text-[#F97316] self-start mt-1">￥</span>
             <span class="text-[40px] font-black text-[#F97316] leading-none tracking-tight">{{ post._previewCard.price || 0 }}</span>
             <span v-if="post._previewCard.priceType === 'points'" class="text-[13px] font-bold text-[#F97316] self-end mb-1">积分</span>
           </div>
          <div class="text-[11px] text-[#999] mt-0.5">
            付费后可查看完整内容
          </div>
        </div>
        <div class="bg-[#FAFAFA] rounded-xl px-3.5 py-2.5 flex items-center justify-between mb-3">
          <div class="flex items-center gap-1.5">
            <div class="w-5 h-5 rounded-full bg-[#FEF3C7] flex items-center justify-center">
              <svg class="w-3 h-3 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 15c6.67-4 13.33-4 20 0"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <span class="text-[12px] font-medium text-[#888]">黄金</span>
             <span class="text-[12px] font-bold text-[#D48806]">{{ post._previewCard.priceType === 'points' ? Math.floor((post._previewCard.price || 0) * 0.9) + '积分' : '￥' + Math.floor((post._previewCard.price || 0) * 0.9) }}</span>
           </div>
           <div class="w-px h-4 bg-[#E5E5E5]"></div>
           <div class="flex items-center gap-1.5">
             <div class="w-5 h-5 rounded-full bg-[#EDE9FE] flex items-center justify-center">
               <svg class="w-3 h-3 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2"/></svg>
             </div>
             <span class="text-[12px] font-medium text-[#888]">至尊</span>
             <span class="text-[12px] font-bold text-[#7C3AED]">{{ post._previewCard.priceType === 'points' ? Math.floor((post._previewCard.price || 0) * 0.8) + '积分' : '￥' + Math.floor((post._previewCard.price || 0) * 0.8) }}</span>
          </div>
        </div>
        <div @click.stop="$emit('click', post.id)" class="bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-orange-200/50">
            立即购买
          </div>
        </div>

        <!-- 会员专属 -->
        <div v-else-if="post._previewCard?.type === 'memberUnlock'" class="relative bg-gradient-to-br from-[#FFFDF5] via-white to-white rounded-2xl p-4 shadow-md border border-[#FDE68A] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#D48806] to-[#F59E0B] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 15c6.67-4 13.33-4 20 0"/><circle cx="12" cy="7" r="4"/></svg>
           会员专属
         </div>
         <div class="flex items-center gap-2 mt-2 mb-4">
           <div class="w-8 h-8 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
             <svg class="w-4 h-4 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
           </div>
           <span class="text-[13px] text-[#555] font-medium">该帖子内容仅 {{ post._previewCard.levelName }} 会员可见</span>
         </div>
         <div class="bg-[#FEFCE8] rounded-xl px-3.5 py-2.5 mb-3 flex items-center gap-2">
           <svg class="w-4 h-4 text-[#D48806] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
           <span class="text-[11px] text-[#92400E]">开通会员享受专属内容与更多权益</span>
         </div>
         <div @click.stop="$router.push('/membership')" class="bg-gradient-to-r from-[#D48806] to-[#F59E0B] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-amber-200/50">
           开通会员
         </div>
       </div>

       <!-- 经验等级限制 -->
       <div v-else-if="post._previewCard?.type === 'experienceUnlock'" class="relative bg-gradient-to-br from-[#F0F7FF] via-white to-white rounded-2xl p-4 shadow-md border border-[#BFDBFE] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
           等级限制
         </div>
         <div class="flex items-center gap-2 mt-2 mb-4">
           <div class="w-8 h-8 rounded-full bg-[#DBEAFE] flex items-center justify-center flex-shrink-0">
             <svg class="w-4 h-4 text-[#3B82F6]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
           </div>
           <span class="text-[13px] text-[#555] font-medium">需经验等级 {{ post._previewCard.levelName }} 及以上</span>
         </div>
         <div class="bg-[#EFF6FF] rounded-xl px-3.5 py-2.5 mb-3 flex items-center gap-2">
           <svg class="w-4 h-4 text-[#3B82F6] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
           <span class="text-[11px] text-[#1E40AF]">每日签到和发帖可获得经验值</span>
         </div>
         <div @click.stop="$router.push('/checkin')" class="bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-blue-200/50">
           提升经验
         </div>
       </div>

       <!-- 登录可见 -->
       <div v-else-if="post._previewCard?.type === 'login'" class="relative bg-gradient-to-br from-[#F4F7FF] via-white to-[#FAFBFF] rounded-2xl p-5 shadow-md border border-[#C7D2FE] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#6366F1] to-[#818CF8] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="7" r="4"/><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/></svg>
           登录可见
         </div>
         <div class="flex flex-col items-center text-center mt-1 mb-4">
           <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center mb-3 shadow-lg shadow-indigo-200/40">
             <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
           </div>
           <span class="text-[14px] text-[#374151] font-semibold">该帖子内容已隐藏</span>
           <span class="text-[12px] text-[#9CA3AF] mt-1">登录后即可查看完整内容</span>
         </div>
         <div class="flex gap-3">
           <div @click.stop="$router.push('/auth/login')" class="flex-1 bg-gradient-to-r from-[#6366F1] to-[#818CF8] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-indigo-300/40">
             立即登录
           </div>
           <div @click.stop="$router.push('/auth/register')" class="flex-1 border-2 border-[#C7D2FE] text-[#6366F1] text-[14px] font-bold text-center py-3 rounded-xl active:bg-[#EEF2FF] transition-colors">
             注册账号
           </div>
         </div>
       </div>

       <!-- 评论解锁 -->
       <div v-else-if="post._previewCard?.type === 'commentUnlock'" class="relative bg-gradient-to-br from-[#F0FDF4] via-white to-white rounded-2xl p-4 shadow-md border border-[#A7F3D0] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#22C55E] to-[#4ADE80] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
           评论解锁
         </div>
         <div class="flex items-center gap-2 mt-2 mb-3">
           <div class="w-8 h-8 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
             <svg class="w-4 h-4 text-[#22C55E]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
           </div>
           <span class="text-[13px] text-[#555] font-medium">该帖子内容已隐藏，请评论后查看</span>
         </div>
         <div class="flex items-center gap-3 mb-4">
           <span class="flex-1 h-px bg-[#D1FAE5]"></span>
           <span class="text-[11px] text-[#888] flex-shrink-0">留下评论即可解锁</span>
           <span class="flex-1 h-px bg-[#D1FAE5]"></span>
         </div>
         <div @click.stop="$emit('click', post.id)" class="bg-gradient-to-r from-[#22C55E] to-[#4ADE80] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-green-200/50 flex items-center justify-center gap-2">
           <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
           去评论
         </div>
       </div>

       <!-- 称号解锁 -->
       <div v-else-if="post._previewCard?.type === 'titleUnlock'" class="relative bg-gradient-to-br from-[#F5F3FF] via-white to-white rounded-2xl p-4 shadow-md border border-[#DDD6FE] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777z"/><circle cx="12" cy="12" r="3"/><path d="M22 12A10 10 0 1112 2"/></svg>
           称号解锁
         </div>
         <div class="flex items-center gap-2 mt-2 mb-3">
           <div class="w-8 h-8 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
             <svg class="w-4 h-4 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
           </div>
           <span class="text-[13px] text-[#555] font-medium">需拥有称号「{{ post._previewCard.titleName }}」才可查看</span>
         </div>
         <div class="flex items-center gap-3 mb-4">
           <span class="flex-1 h-px bg-[#DDD6FE]"></span>
           <span class="text-[11px] text-[#888] flex-shrink-0">称号限定内容</span>
           <span class="flex-1 h-px bg-[#DDD6FE]"></span>
         </div>
         <div @click.stop="$emit('click', post.id)" class="bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-violet-200/50 flex items-center justify-center gap-2">
           <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" viewBox="0 0 24 24"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777z"/></svg>
           查看详情
         </div>
       </div>

       <!-- contentFiltered 降级付费卡 -->
       <div v-else-if="post.contentFiltered" class="relative bg-gradient-to-br from-[#FFF7ED] via-white to-white rounded-2xl p-4 shadow-md border border-[#FED7AA] overflow-hidden mt-1">
         <div class="absolute -top-1 left-3 bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[11px] font-bold px-3 py-[5px] rounded-b-xl flex items-center gap-1 shadow-sm">
           <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
           付费阅读
         </div>
         <div class="absolute top-2.5 right-3 bg-[#22C55E] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm" v-if="post.soldCount > 0">
           已售 {{ post.soldCount }}
         </div>
         <div class="flex items-center gap-2 mt-2 mb-4">
           <div class="w-8 h-8 rounded-full bg-[#FFF0E0] flex items-center justify-center flex-shrink-0">
             <svg class="w-4 h-4 text-[#F97316]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
           </div>
           <span class="text-[13px] text-[#555] font-medium">该帖子部分内容已隐藏</span>
         </div>
         <div class="text-center mb-4">
          <div class="inline-flex items-baseline gap-0.5">
              <span v-if="post.contentPriceType !== 'points'" class="text-[18px] font-bold text-[#F97316] self-start mt-1">￥</span>
              <span class="text-[40px] font-black text-[#F97316] leading-none tracking-tight">{{ post.contentPrice || 0 }}</span>
              <span v-if="post.contentPriceType === 'points'" class="text-[13px] font-bold text-[#F97316] self-end mb-1">积分</span>
            </div>
           <div class="text-[11px] text-[#999] mt-0.5">
             付费后可查看完整内容
           </div>
         </div>
         <div @click.stop="$emit('click', post.id)" class="bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white text-[14px] font-bold text-center py-3 rounded-xl active:scale-[0.98] transition-transform shadow-lg shadow-orange-200/50">
            立即购买
          </div>
        </div>

        <!-- Normal text content -->
       <div v-else-if="post.content && !['app','goods','vote','postRef'].includes(post._previewCard?.type)" class="text-[13px] text-[#999] leading-[1.6] line-clamp-2" v-html="stripContent(post.content)"></div>

       <!-- 预览卡片 -->
       <div v-if="post._previewCard?.type === 'app'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#F0F9FF] to-[#FAFEFF] rounded-xl p-3.5 border border-[#BAE6FD] active:bg-[#E0F2FE] transition-colors shadow-sm">
         <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#0EA5E9] to-[#38BDF8] flex items-center justify-center flex-shrink-0 shadow-sm">
           <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4" stroke-linecap="round"/></svg>
         </div>
         <div class="flex-1 min-w-0">
           <div class="text-[13px] font-semibold text-[#0C4A6E] truncate">{{ post._previewCard.name || '应用' }}</div>
           <div class="text-[11px] text-[#38BDF8] mt-0.5">点击查看详情</div>
         </div>
         <div class="w-6 h-6 rounded-full bg-[#E0F2FE] flex items-center justify-center flex-shrink-0">
           <svg class="w-3.5 h-3.5 text-[#0EA5E9]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
         </div>
       </div>
       <div v-else-if="post._previewCard?.type === 'goods'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#FFFBE6] to-[#FFFEF5] rounded-xl p-3.5 border border-[#FDE68A] active:bg-[#FEF3C7] transition-colors shadow-sm">
         <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#D48806] to-[#F59E0B] flex items-center justify-center flex-shrink-0 overflow-hidden shadow-sm">
           <img v-if="post._previewCard.image" :src="$fixImgUrl(post._previewCard.image)" class="w-full h-full object-cover" @error="($event.target as HTMLImageElement).style.display='none'" />
           <svg v-else class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
         </div>
         <div class="flex-1 min-w-0">
           <div class="text-[13px] font-semibold text-[#92400E] truncate">{{ post._previewCard.name || '商品' }}</div>
           <div class="text-[12px] text-[#D48806] font-bold mt-0.5">{{ post._previewCard.price ? (typeof post._previewCard.price === 'number' ? '￥' + post._previewCard.price : post._previewCard.price) : '' }}</div>
         </div>
         <div class="w-6 h-6 rounded-full bg-[#FEF3C7] flex items-center justify-center flex-shrink-0">
           <svg class="w-3.5 h-3.5 text-[#D48806]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
         </div>
       </div>
       <div v-else-if="post._previewCard?.type === 'vote'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#F5F3FF] to-[#FDFBFF] rounded-xl p-3.5 border border-[#DDD6FE] active:bg-[#EDE9FE] transition-colors shadow-sm">
         <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#A78BFA] flex items-center justify-center flex-shrink-0 shadow-sm">
           <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
         </div>
         <div class="flex-1 min-w-0">
           <div class="text-[13px] font-semibold text-[#5B21B6] truncate">{{ post._previewCard.question || '投票' }}</div>
           <div class="text-[11px] text-[#A78BFA] mt-0.5">点击参与投票</div>
         </div>
         <div class="w-6 h-6 rounded-full bg-[#EDE9FE] flex items-center justify-center flex-shrink-0">
           <svg class="w-3.5 h-3.5 text-[#7C3AED]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
         </div>
       </div>
       <div v-else-if="post._previewCard?.type === 'postRef'" class="mt-2 flex items-center gap-3 bg-gradient-to-r from-[#ECFDF5] to-[#F6FFFA] rounded-xl p-3.5 border border-[#A7F3D0] active:bg-[#D1FAE5] transition-colors shadow-sm">
         <div class="w-[48px] h-[48px] rounded-xl bg-gradient-to-br from-[#059669] to-[#34D399] flex items-center justify-center flex-shrink-0 shadow-sm">
           <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
         </div>
         <div class="flex-1 min-w-0">
           <div class="text-[13px] font-semibold text-[#064E3B] truncate">{{ post._previewCard.title || '引用帖子' }}</div>
           <div class="text-[11px] text-[#34D399] mt-0.5">{{ post._previewCard.sectionName || '查看原帖' }}</div>
         </div>
         <div class="w-6 h-6 rounded-full bg-[#D1FAE5] flex items-center justify-center flex-shrink-0">
           <svg class="w-3.5 h-3.5 text-[#059669]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
         </div>
       </div>

       <!-- Images -->
       <div v-if="post.images && post.images.length" class="mt-2.5">
         <div v-if="post.images.length === 1" class="rounded-xl overflow-hidden shadow-sm" style="max-height:200px">
           <img :src="$fixImgUrl(post.images[0])" class="w-full object-cover" style="max-height:200px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
         </div>
         <div v-else-if="post.images.length === 2" class="grid grid-cols-2 gap-1.5 rounded-xl overflow-hidden">
           <img v-for="(img, idx) in post.images.slice(0,2)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:150px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
         </div>
         <div v-else class="grid grid-cols-3 gap-1.5 rounded-xl overflow-hidden">
           <img v-for="(img, idx) in post.images.slice(0,3)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:130px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
         </div>
       </div>
     </div>

     <!-- Tags + Stats -->
     <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-[#F5F5F5]">
       <div v-if="post.tags && post.tags.length" class="flex items-center gap-1.5 flex-wrap">
         <span v-for="tag in post.tags.slice(0,4)" :key="tag" class="text-[10px] px-2 py-[2px] rounded text-[#666] bg-[#F5F5F5] font-medium flex-shrink-0">{{ tag }}</span>
       </div>
       <div class="flex items-center gap-3 text-[12px] text-[#B0B0B0] ml-auto flex-shrink-0">
         <span class="inline-flex items-center gap-0.5">
           <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
           {{ fmtCount(post.likeCount || 0) }}
         </span>
         <span class="inline-flex items-center gap-0.5">
           <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
           {{ fmtCount(post.commentCount || 0) }}
         </span>
         <span class="inline-flex items-center gap-0.5">
           <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
           {{ fmtCount(post.viewCount || 0) }}
         </span>
         <span class="text-[11px] text-[#B0B0B0] ml-1">{{ fmtRelativeTime(post.createTime) }}</span>
       </div>
     </div>
   </div>
</template>

<script setup lang="ts">
defineProps<{
  post: any
  activeFrameUrl: string
  currentUserId: number
}>()

defineEmits<{
  click: [postId: number]
}>()

function stripContent(text: string) {
  if (!text) return ''
  try {
    const safe = text.replace(/\\\\\"/g, '\\"')
    const parsed = JSON.parse(safe)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
    if (parsed?.type === 'doc') {
      const parts: string[] = []
      function walk(n: any) {
        if (!n) return
        if (n.type === 'text') {
          const txt = n.text || ''
          const marks = (n.marks || []).map((m: any) => m.type)
          if (marks.includes('hashtag')) {
            const tags = txt.split(/\s+/).filter(Boolean)
            tags.forEach((t: string) => {
              parts.push(`<span class="ct-hash">${t}</span>`)
            })
          } else if (marks.includes('bold') && /^\[应用:/.test(txt)) {
            return
          } else {
            parts.push(txt)
          }
        } else if (n.type === 'image') {
          parts.push(`<span class="ct-img">[图片]</span>`)
        }
        if (n.content) n.content.forEach(walk)
      }
      if (parsed.content) parsed.content.forEach(walk)
      return parts.join(' ')
    }
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}
</script>

<style scoped>
.line-clamp-1 { display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

.post-header-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 3px;
  font-weight: 600;
  margin-right: 5px;
  vertical-align: middle;
}
.post-header-badge.pin { color: #DC2626; background: #FEF2F2; }
.post-header-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-header-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-header-badge.custom { color: #508DFF; background: #F0F5FF; }
.post-header-badge.lock { color: #999; background: #F5F5F5; }
.post-header-badge.collection { color: #7C3AED; background: #F5F3FF; cursor: pointer; }

.post-avatar-wrap {
  position: relative;
  width: 56px;
  height: 56px;
  flex-shrink: 0;
}
.post-avatar-frame {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
  z-index: 0;
}
.post-avatar {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  z-index: 1;
}
.post-avatar-pic {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}
.post-avatar-user {
  position: absolute;
  inset: 0;
  z-index: 1;
}

.post-author-info { flex: 1; min-width: 0; }
.post-author-col { display: flex; flex-direction: column; gap: 0; }
.post-author-row { display: flex; align-items: center; gap: 0; flex-wrap: wrap; }
.post-username { font-size: 15px; color: #1a1a1a; font-weight: 600; line-height: 1; }
.post-title-icon { width: 26px; height: 26px; object-fit: contain; flex-shrink: 0; vertical-align: middle; }
.post-author-meta {
  display: flex;
  align-items: center;
  gap: 2px;
  margin-top: -6px;
  font-size: 12px;
  flex-wrap: wrap;
}
.post-exp-icon { width: 32px; height: 32px; object-fit: contain; flex-shrink: 0; }
.post-member-name-icon { width: 22px; height: 22px; object-fit: contain; flex-shrink: 0; }
</style>

<style>
.ct-hash { color: #6366F1; background: #EEF2FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-app { color: #0EA5E9; background: #F0F9FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-goods { color: #D48806; background: #FFFBE6; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-vote { color: #7C3AED; background: #F5F3FF; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-ref { color: #059669; background: #ECFDF5; padding: 0 3px; border-radius: 3px; font-size: 11px; margin: 0 1px; }
.ct-img { color: #9CA3AF; font-size: 11px; }
</style>
