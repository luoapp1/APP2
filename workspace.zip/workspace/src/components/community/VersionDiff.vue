<template>
  <div class="version-diff">
    <div class="vd-header">
      <h3>历史版本对比</h3>
      <el-button text size="small" @click="$emit('close')">关闭</el-button>
    </div>
    <div v-if="loading" class="vd-loading">
      <el-skeleton :rows="5" animated />
    </div>
    <div v-else-if="revisions.length === 0" class="vd-empty"> 暂无历史版本 </div>
    <div v-else class="vd-content">
      <div class="vd-selectors">
        <div class="vd-select">
          <label>旧版本</label>
          <el-select
            v-model="oldRevId"
            placeholder="选择旧版本"
            size="small"
            @change="loadComparison"
          >
            <el-option
              v-for="r in revisions"
              :key="r.id"
              :label="`v${r.version} - ${r.editSummary || '无摘要'} (${fmtTime(r.createTime)})`"
              :value="r.id"
            />
          </el-select>
        </div>
        <div class="vd-select">
          <label>新版本</label>
          <el-select
            v-model="newRevId"
            placeholder="选择新版本"
            size="small"
            @change="loadComparison"
          >
            <el-option
              v-for="r in revisions"
              :key="r.id"
              :label="`v${r.version} - ${r.editSummary || '无摘要'} (${fmtTime(r.createTime)})`"
              :value="r.id"
            />
          </el-select>
        </div>
      </div>
      <div v-if="diffContent" class="vd-result">
        <div class="vd-pane">
          <div class="vd-pane-title">旧版本 (v{{ oldRevVer }})</div>
          <div class="vd-pane-content" v-html="oldContent"></div>
        </div>
        <div class="vd-pane">
          <div class="vd-pane-title">新版本 (v{{ newRevVer }})</div>
          <div class="vd-pane-content" v-html="newContent"></div>
        </div>
      </div>
      <div v-if="diffContent" class="vd-diff-pane">
        <div class="vd-pane-title">差异对比</div>
        <div class="vd-pane-content vd-diff-html" v-html="diffContent"></div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { ref, onMounted } from 'vue'
  import request from '@/utils/http'

  defineOptions({ name: 'VersionDiff' })

  const props = defineProps<{
    postId: number
  }>()

  defineEmits<{
    (e: 'close'): void
  }>()

  const revisions = ref<any[]>([])
  const loading = ref(true)
  const oldRevId = ref<number | null>(null)
  const newRevId = ref<number | null>(null)
  const oldContent = ref('')
  const newContent = ref('')
  const diffContent = ref('')
  const oldRevVer = ref(0)
  const newRevVer = ref(0)

  function fmtTime(t: string) {
    if (!t) return ''
    return new Date(t).toLocaleString('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  async function loadRevisions() {
    loading.value = true
    try {
      const res: any = await request.get({ url: `/api/community/post/${props.postId}/revisions` })
      revisions.value = res?.data || res || []
      if (revisions.value.length >= 2) {
        newRevId.value = revisions.value[0]?.id
        oldRevId.value = revisions.value[1]?.id
        await loadComparison()
      }
    } catch {
      loading.value = false
    }
  }

  async function loadComparison() {
    if (!oldRevId.value || !newRevId.value) return
    try {
      const [oldRes, newRes]: any[] = await Promise.all([
        request.get({ url: `/api/community/post/${props.postId}/revisions/${oldRevId.value}` }),
        request.get({ url: `/api/community/post/${props.postId}/revisions/${newRevId.value}` })
      ])
      const oldRev = oldRes?.data || oldRes
      const newRev = newRes?.data || newRes
      oldContent.value = formatContent(oldRev?.content || '')
      newContent.value = formatContent(newRev?.content || '')
      oldRevVer.value = oldRev?.version || 0
      newRevVer.value = newRev?.version || 0

      const oldTitle = oldRev?.title || ''
      const newTitle = newRev?.title || ''
      diffContent.value = generateDiff(
        oldTitle + '\n' + (oldRev?.content || ''),
        newTitle + '\n' + (newRev?.content || '')
      )
    } catch {
      /* ignore */
    }
  }

  function formatContent(content: string): string {
    try {
      const parsed = JSON.parse(content)
      if (parsed?.type === 'doc' && parsed.content) {
        let html = ''
        for (const node of parsed.content) {
          html += renderTiptapNode(node)
        }
        return html || escapeHtml(content)
      }
      if (Array.isArray(parsed)) {
        return parsed.map((b: any) => `<p>${escapeHtml(b.value || b.text || '')}</p>`).join('')
      }
    } catch {
      /* ignore */
    }
    return escapeHtml(content)
  }

  function renderTiptapNode(node: any): string {
    if (!node) return ''
    switch (node.type) {
      case 'paragraph': {
        const text = (node.content || []).map((n: any) => renderTiptapInline(n)).join('')
        return `<p>${text || '&nbsp;'}</p>`
      }
      case 'heading': {
        const lv = node.attrs?.level || 1
        const text = (node.content || []).map((n: any) => renderTiptapInline(n)).join('')
        return `<h${lv}>${text}</h${lv}>`
      }
      case 'image': {
        const src = node.attrs?.src || ''
        return `<img src="${src}" style="max-width:200px;border-radius:6px;margin:6px 0;" />`
      }
      case 'codeBlock': {
        const text = (node.content || []).map((n: any) => escapeHtml(n.text || '')).join('')
        return `<pre><code>${text}</code></pre>`
      }
      case 'bulletList':
      case 'orderedList': {
        const tag = node.type === 'orderedList' ? 'ol' : 'ul'
        const items = (node.content || [])
          .map((item: any) => {
            const inner = (item.content || []).map((n: any) => renderTiptapNode(n)).join('')
            return `<li>${inner}</li>`
          })
          .join('')
        return `<${tag}>${items}</${tag}>`
      }
      case 'blockquote': {
        const inner = (node.content || []).map((n: any) => renderTiptapNode(n)).join('')
        return `<blockquote>${inner}</blockquote>`
      }
      case 'paywall':
        return '<div class="vd-placeholder">[付费分割]</div>'
      case 'voteCard':
        return '<div class="vd-placeholder">[投票卡片]</div>'
      case 'galleryBlock':
        return '<div class="vd-placeholder">[图集]</div>'
      default: {
        if (node.content) return node.content.map((n: any) => renderTiptapNode(n)).join('')
        return ''
      }
    }
  }

  function renderTiptapInline(node: any): string {
    if (!node) return ''
    if (node.type === 'text') {
      let text = escapeHtml(node.text || '')
      if (node.marks) {
        for (const m of node.marks) {
          if (m.type === 'bold') text = `<strong>${text}</strong>`
          if (m.type === 'italic') text = `<em>${text}</em>`
          if (m.type === 'code') text = `<code>${text}</code>`
          if (m.type === 'link') text = `<a href="${m.attrs?.href || '#'}">${text}</a>`
        }
      }
      return text
    }
    if (node.type === 'image')
      return `<img src="${node.attrs?.src || ''}" style="max-width:80px" />`
    if (node.type === 'hardBreak') return '<br />'
    return ''
  }

  function escapeHtml(s: string): string {
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
  }

  function generateDiff(oldText: string, newText: string): string {
    const oldLines = oldText.split('\n')
    const newLines = newText.split('\n')
    let result = '<div class="vd-diff-lines">'
    const maxLen = Math.max(oldLines.length, newLines.length)
    for (let i = 0; i < maxLen; i++) {
      const oLine = oldLines[i] || ''
      const nLine = newLines[i] || ''
      if (oLine === nLine) {
        result += `<div class="vd-line-eq">${escapeHtml(oLine) || '&nbsp;'}</div>`
      } else {
        if (oLine) result += `<div class="vd-line-old">- ${escapeHtml(oLine)}</div>`
        if (nLine) result += `<div class="vd-line-new">+ ${escapeHtml(nLine)}</div>`
      }
    }
    result += '</div>'
    return result
  }

  onMounted(() => {
    loadRevisions()
  })
</script>

<style scoped>
  .version-diff {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    margin-top: 16px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
  }
  .vd-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f0f0f0;
  }
  .vd-header h3 {
    margin: 0;
    font-size: 16px;
  }
  .vd-selectors {
    display: flex;
    gap: 16px;
    margin-bottom: 16px;
    flex-wrap: wrap;
  }
  .vd-select {
    flex: 1;
    min-width: 200px;
  }
  .vd-select label {
    display: block;
    font-size: 12px;
    color: #999;
    margin-bottom: 4px;
  }
  .vd-result {
    display: flex;
    gap: 12px;
    margin-bottom: 16px;
  }
  .vd-pane {
    flex: 1;
    min-width: 0;
  }
  .vd-pane-title {
    font-size: 12px;
    font-weight: 600;
    color: #666;
    margin-bottom: 6px;
    padding: 6px 10px;
    background: #f5f5f5;
    border-radius: 4px;
  }
  .vd-pane-content {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #eee;
    border-radius: 6px;
    padding: 10px;
    font-size: 13px;
    line-height: 1.6;
  }
  .vd-diff-pane {
    margin-top: 12px;
  }
  .vd-diff-lines {
    font-family: 'Courier New', monospace;
    font-size: 12px;
  }
  .vd-line-eq {
    padding: 2px 8px;
    color: #999;
  }
  .vd-line-old {
    padding: 2px 8px;
    background: #fee2e2;
    color: #991b1b;
  }
  .vd-line-new {
    padding: 2px 8px;
    background: #d1fae5;
    color: #065f46;
  }
  .vd-placeholder {
    padding: 6px 10px;
    background: #f5f5f5;
    border-radius: 4px;
    font-size: 12px;
    color: #999;
    margin: 4px 0;
  }
  .vd-empty {
    padding: 30px;
    text-align: center;
    color: #999;
  }
  .vd-loading {
    padding: 20px;
  }
  .vd-pane-content :deep(img) {
    max-width: 100%;
  }
</style>
