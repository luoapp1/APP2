import { AppRouteRecord } from '@/types/router'

export const operationRoutes: AppRouteRecord = {
  path: '/operation',
  name: 'Operation',
  component: '/index/index',
  meta: {
    title: 'menus.operation.title',
    icon: 'ri:settings-3-line',
    roles: ['R_SUPER', 'R_ADMIN']
  },
  children: [
    {
      path: 'cardkey',
      name: 'CardKey',
      component: '/operation/cardkey/index',
      meta: {
        title: 'menus.operation.cardkey',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'membership',
      name: 'Membership',
      component: '/operation/membership/index',
      meta: {
        title: 'menus.operation.membership',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'coupon',
      name: 'Coupon',
      component: '/operation/coupon/index',
      meta: {
        title: 'menus.operation.coupon',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'points',
      name: 'Points',
      component: '/operation/points/index',
      meta: {
        title: 'menus.operation.points',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'experience',
      name: 'ExperienceLevel',
      component: '/operation/experience/index',
      meta: {
        title: 'menus.operation.experience',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'plugins',
      name: 'Plugins',
      component: '/operation/plugins/index',
      meta: {
        title: 'menus.operation.plugins',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'title',
      name: 'TitleManage',
      component: '/operation/title/index',
      meta: {
        title: 'menus.operation.titleManage',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'commission',
      name: 'CommissionManage',
      component: '/operation/commission/index',
      meta: {
        title: 'menus.operation.commission',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.config', authMark: 'config' }
        ]
      }
    },
    {
      path: 'filepolicy',
      name: 'FilePolicyManage',
      component: '/operation/filepolicy/index',
      meta: {
        title: 'menus.operation.filePolicy',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'membership-products',
      name: 'MembershipProducts',
      component: '/operation/membership-products/index',
      meta: {
        title: 'menus.operation.membershipProducts',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'membership-purchases',
      name: 'MembershipPurchases',
      component: '/operation/membership-purchases/index',
      meta: {
        title: 'menus.operation.membershipPurchases',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'content-purchases',
      name: 'ContentPurchases',
      component: '/operation/content-purchases/index',
      meta: {
        title: 'menus.operation.contentPurchases',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'checkin',
      name: 'CheckinManage',
      component: '/operation/checkin/index',
      meta: {
        title: 'menus.operation.checkin',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'settlement',
      name: 'SettlementManage',
      component: '/operation/settlement/index',
      meta: {
        title: 'menus.operation.settlement',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'layout-themes',
      name: 'LayoutThemesManage',
      component: '/operation/layout-themes/index',
      meta: {
        title: 'menus.operation.layoutThemes',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'avatar-frame',
      name: 'AvatarFrameManage',
      component: '/operation/avatar-frame/index',
      meta: {
        title: 'menus.operation.avatarFrame',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'payment-config',
      name: 'PaymentConfig',
      component: '/operation/payment-config/index',
      meta: {
        title: 'menus.operation.paymentConfig',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'recharge-amounts',
      name: 'RechargeAmounts',
      component: '/operation/recharge-amounts/index',
      meta: {
        title: 'menus.operation.rechargeAmounts',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'game-center',
      name: 'GameCenter',
      component: '/operation/game-center/index',
      meta: {
        title: 'menus.operation.gameCenter',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'developer-analytics',
      name: 'DeveloperAnalytics',
      component: '/operation/developer-analytics/index',
      meta: {
        title: 'menus.operation.developerAnalytics',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'push-notification',
      name: 'PushNotification',
      component: '/operation/notification/PushNotification',
      meta: {
        title: 'menus.operation.pushNotification',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.send', authMark: 'send' },
          { title: 'actions.manage', authMark: 'manage' }
        ]
      }
    },
    {
      path: 'invite-ranking',
      name: 'InviteRanking',
      component: '/operation/invite/InviteRanking',
      meta: {
        title: 'menus.operation.inviteRanking',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'checkin-calendar',
      name: 'CheckinCalendar',
      component: '/operation/checkin/CheckinCalendar',
      meta: {
        title: 'menus.operation.checkinCalendar',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'ab-test',
      name: 'ABTestList',
      component: '/operation/ab-test/ABTestList',
      meta: {
        title: 'menus.operation.abTest',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'ab-test/create',
      name: 'ABTestCreate',
      component: '/operation/ab-test/ABTestCreate',
      meta: {
        title: 'menus.operation.abTestCreate',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'funnel-analysis',
      name: 'FunnelAnalysis',
      component: '/operation/analytics/FunnelAnalysis',
      meta: {
        title: 'menus.operation.funnelAnalysis',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' }
        ]
      }
    },
    {
      path: 'campaign',
      name: 'CampaignList',
      component: '/operation/campaign/CampaignList',
      meta: {
        title: 'menus.operation.campaign',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'campaign/create',
      name: 'CampaignEditor',
      component: '/operation/campaign/CampaignEditor',
      meta: {
        title: 'menus.operation.campaignCreate',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    }
  ]
}
