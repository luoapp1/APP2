import { AppRouteRecord } from '@/types/router'

export const systemRoutes: AppRouteRecord = {
  path: '/system',
  name: 'System',
  component: '/index/index',
  meta: {
    title: 'menus.system.title',
    icon: 'ri:user-3-line',
    roles: ['R_SUPER', 'R_ADMIN']
  },
  children: [
    {
      path: 'user',
      name: 'User',
      component: '/system/user',
      meta: {
        title: 'menus.system.user',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'role',
      name: 'Role',
      component: '/system/role',
      meta: {
        title: 'menus.system.role',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'user-center',
      name: 'UserCenter',
      component: '/system/user-center',
      meta: {
        title: 'menus.system.userCenter',
        isHide: true,
        keepAlive: true,
        isHideTab: true
      }
    },
    {
      path: 'menu',
      name: 'Menus',
      component: '/system/menu',
      meta: {
        title: 'menus.system.menu',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'delete-review',
      name: 'DeleteReview',
      component: '/system/user/delete-review',
      meta: {
        title: '注销审核',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '审核', authMark: 'review' }
        ]
      }
    },
    {
      path: 'verification',
      name: 'Verification',
      component: '/system/verification/index',
      meta: {
        title: '蓝V认证审核',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '审核', authMark: 'review' }
        ]
      }
    },
    {
      path: 'invite',
      name: 'InviteManage',
      component: '/system/invite/index',
      meta: {
        title: '邀请码管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'email',
      name: 'EmailConfig',
      component: '/system/email/index',
      meta: {
        title: '邮件配置',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'filerepo',
      name: 'FileRepository',
      component: '/system/filerepo/index',
      meta: {
        title: '文件仓库',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'recycle',
      name: 'RecycleBin',
      component: '/system/recycle/index',
      meta: {
        title: '回收站',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '恢复', authMark: 'restore' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'syslog',
      name: 'SystemLog',
      component: '/system/syslog/index',
      meta: {
        title: '系统日志',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '查看', authMark: 'view' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'sysconfig',
      name: 'SysConfig',
      component: '/system/sysconfig/index',
      meta: {
        title: '系统配置',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '编辑', authMark: 'edit' }
        ]
      }
    },
    {
      path: 'task',
      name: 'CustomTask',
      component: '/system/task/index',
      meta: {
        title: '任务管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '新增', authMark: 'add' },
          { title: '编辑', authMark: 'edit' },
          { title: '删除', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'oauth-config',
      name: 'OAuthConfig',
      component: '/system/oauth-config/index',
      meta: {
        title: 'OAuth配置',
        keepAlive: true,
        roles: ['R_SUPER'],
        authList: [
          { title: '编辑', authMark: 'edit' }
        ]
      }
    }
  ]
}
