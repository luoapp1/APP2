import { AppRouteRecord } from '@/types/router'

export const appstoreRoutes: AppRouteRecord = {
  path: '/appstore',
  name: 'AppStore',
  component: '/index/index',
  meta: {
    title: 'menus.appstore.title',
    icon: 'ri:apps-2-line',
    roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
  },
  children: [
    {
      path: 'list',
      name: 'AppStoreList',
      component: '/appstore/list',
      meta: {
        title: 'menus.appstore.list',
        keepAlive: true,
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'detail/:id',
      name: 'AppStoreDetail',
      component: '/appstore/detail',
      meta: {
        title: 'menus.appstore.detail',
        isHide: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER'],
        keepAlive: false
      }
    },
    {
      path: 'admin-category',
      name: 'AppCategory',
      component: '/appstore/category',
      meta: {
        title: 'menus.appstore.category',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'reports',
      name: 'AppReports',
      component: '/appstore/reports',
      meta: {
        title: 'menus.appstore.reports',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' },
          { title: 'actions.handle', authMark: 'handle' }
        ]
      }
    },
    {
      path: 'my-submissions',
      name: 'MySubmissions',
      component: '/appstore/submissions',
      meta: {
        title: 'menus.appstore.mySubmissions',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    },
    {
      path: 'review',
      name: 'SubmissionReview',
      component: '/appstore/review',
      meta: {
        title: 'menus.appstore.review',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.approve', authMark: 'approve' },
          { title: 'actions.reject', authMark: 'reject' }
        ]
      }
    },
    {
      path: 'review-mobile',
      name: 'SubmissionReviewMobile',
      component: '/appstore/review/mobile',
      meta: {
        title: 'menus.appstore.review',
        isHide: true,
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'official-tags',
      name: 'OfficialTags',
      component: '/appstore/official-tags',
      meta: {
        title: 'menus.appstore.officialTags',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'mall-manage',
      name: 'MallManage',
      component: '/appstore/admin/mall/mall-manage',
      meta: {
        title: 'menus.appstore.mallManage',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'mall-product-create',
      name: 'MallProductCreate',
      component: '/appstore/admin/mall/mall-product-create',
      meta: {
        title: 'menus.appstore.mallProductCreate',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'card-pool',
      name: 'CardPool',
      component: '/appstore/admin/mall/card-pool',
      meta: {
        title: 'menus.appstore.cardPool',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'delivery-logs',
      name: 'DeliveryLogs',
      component: '/appstore/admin/mall/delivery-logs',
      meta: {
        title: 'menus.appstore.deliveryLogs',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'redeem-codes',
      name: 'RedeemCodes',
      component: '/appstore/admin/mall/redeem-codes',
      meta: {
        title: 'menus.appstore.redeemCodes',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-orders',
      name: 'MallOrders',
      component: '/appstore/admin/mall/mall-orders',
      meta: {
        title: 'menus.appstore.mallOrders',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' },
          { title: 'actions.handle', authMark: 'handle' }
        ]
      }
    },
    {
      path: 'mall-categories',
      name: 'MallCategories',
      component: '/appstore/admin/mall/mall-categories',
      meta: {
        title: 'menus.appstore.mallCategories',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'mall-after-sales',
      name: 'MallAfterSales',
      component: '/appstore/admin/mall/mall-after-sales',
      meta: {
        title: 'menus.appstore.mallAfterSales',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.view', authMark: 'view' },
          { title: 'actions.handle', authMark: 'handle' }
        ]
      }
    },
    {
      path: 'mall-promotions',
      name: 'MallPromotions',
      component: '/appstore/admin/mall/mall-promotions',
      meta: {
        title: 'menus.appstore.mallPromotions',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'topic-manage',
      name: 'TopicManage',
      component: '/appstore/admin/topic-manage',
      meta: {
        title: 'menus.appstore.topicManage',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: 'actions.add', authMark: 'add' },
          { title: 'actions.edit', authMark: 'edit' },
          { title: 'actions.delete', authMark: 'delete' }
        ]
      }
    },
    {
      path: 'rating-detail/:id',
      name: 'RatingDetail',
      component: '/appstore/RatingDetail',
      meta: {
        title: 'menus.appstore.ratingDetail',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    },
    {
      path: 'compare',
      name: 'AppCompare',
      component: '/appstore/AppCompare',
      meta: {
        title: '应用对比',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    },
    {
      path: 'dev/analytics',
      name: 'DevAnalytics',
      component: '/operation/developer-analytics/index',
      meta: {
        title: '开发者分析',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN'],
        authList: [
          { title: '查看', authMark: 'view' }
        ]
      }
    },
    {
      path: 'my-decorations',
      name: 'MyDecorations',
      component: '/appstore/decoration/index',
      meta: {
        title: '我的装扮',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    }
  ]
}
