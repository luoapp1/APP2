import { AppRouteRecordRaw } from '@/utils/router'
import { themeComponent, mobileComponent } from '@/utils/theme'

/**
 * 静态路由配置（不需要权限就能访问的路由）
 */
export const staticRoutes: AppRouteRecordRaw[] = [
  {
    path: '/appstore/browse',
    name: 'AppStoreBrowse',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/index.vue'),
      () => import('@/themes/pc/default/views/browse/index.vue')
    ),
    meta: { title: 'menus.appstore.browse', isHideTab: true }
  },
  {
    path: '/community',
    name: 'Community',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/sections.vue'),
      () => import('@/themes/pc/default/views/appstore/community/sections.vue')
    ),
    meta: { title: 'menus.community.title', isHideTab: true }
  },
  {
    path: '/s/:id',
    name: 'CommunitySection',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/forum.vue'),
      () => import('@/themes/pc/default/views/appstore/community/forum.vue')
    ),
    meta: { title: 'menus.community.section', isHideTab: true }
  },
  {
    path: '/community/search',
    name: 'CommunitySearch',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/search.vue'),
      () => import('@/themes/pc/default/views/appstore/community/search.vue')
    ),
    meta: { title: 'menus.community.search', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/community/post/:id',
    name: 'CommunityPostDetail',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/post-detail.vue'),
      () => import('@/themes/pc/default/views/appstore/community/post-detail.vue')
    ),
    meta: { title: 'menus.community.postDetail', isHideTab: true }
  },
  {
    path: '/community/collection/:id',
    name: 'CommunityCollectionDetail',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/collection-detail.vue')
    ),
    meta: { title: 'menus.community.collection', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/community/my-collections',
    name: 'CommunityMyCollections',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/my-collections.vue')
    ),
    meta: { title: 'menus.community.myCollections', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/community/my-collections-list',
    name: 'CommunityMyCollectionsList',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/my-collections-list.vue'),
      () => import('@/themes/pc/default/views/appstore/my-collections-list.vue')
    ),
    meta: { title: 'menus.community.myCollectionsList', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/community/topic/:id',
    name: 'CommunityTopic',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/topic-posts.vue'),
      () => import('@/themes/pc/default/views/appstore/community/topic-posts.vue')
    ),
    meta: { title: 'menus.community.topic', isHideTab: true }
  },
  {
    path: '/community/game-hall',
    name: 'CommunityGameHall',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/game-hall.vue'),
      () => import('@/themes/pc/default/views/appstore/community/game-hall.vue')
    ),
    meta: { title: 'menus.community.gameHall', isHideTab: true }
  },
  // ============ 发现页(私信)子页面 ============
  {
    path: '/appstore/discover/chatrooms',
    name: 'DiscoverChatrooms',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/chatrooms.vue')
    ),
    meta: { title: 'menus.discover.chatrooms', isHideTab: true }
  },
  {
    path: '/appstore/discover/comments',
    name: 'DiscoverComments',
    component: () => import('@/themes/pc/default/views/appstore/discover-comments.vue'),
    meta: { title: 'menus.discover.comments', isHideTab: true }
  },
  {
    path: '/appstore/discover/chatroom/:id',
    name: 'DiscoverChatroom',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/chatroom-chat.vue')
    ),
    meta: { title: 'menus.discover.chatroom', isHideTab: true }
  },
  {
    path: '/appstore/discover/chat/:userId',
    name: 'DiscoverChat',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/discover-chat.vue'),
      () => import('@/themes/pc/default/views/appstore/discover-chat.vue')
    ),
    meta: { title: 'menus.discover.chat', isHideTab: true }
  },
  {
    path: '/chat/:userId',
    name: 'PCChatShort',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/discover-chat.vue'),
      () => import('@/themes/pc/default/views/appstore/discover-chat.vue')
    ),
    meta: { title: 'menus.discover.chat', isHideTab: true }
  },
  {
    path: '/chatroom/:id',
    name: 'PCChatroomShort',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/chatroom-chat.vue')
    ),
    meta: { title: 'menus.discover.chatroom', isHideTab: true }
  },
  {
    path: '/appstore/invite',
    name: 'AppInvite',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/invite.vue'),
      () => import('@/themes/pc/default/views/appstore/invite.vue')
    ),
    meta: { title: 'menus.appstore.invite', isHideTab: true }
  },
  {
    path: '/appstore/updates',
    name: 'AppUpdates',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/updates.vue'),
      () => import('@/themes/pc/default/views/appstore/updates.vue')
    ),
    meta: { title: 'menus.appstore.updates', isHideTab: true }
  },
  {
    path: '/appstore/footprints',
    name: 'AppFootprints',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/footprints.vue'),
      () => import('@/themes/pc/default/views/appstore/footprints.vue')
    ),
    meta: { title: 'menus.appstore.footprints', isHideTab: true }
  },
  {
    path: '/appstore/chatrooms',
    name: 'AppChatrooms',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/chatrooms.vue')
    ),
    meta: { title: 'menus.appstore.chatrooms', isHideTab: true }
  },
  {
    path: '/appstore/discover-chat',
    name: 'AppDiscoverChat',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/discover-chat.vue'),
      () => import('@/themes/pc/default/views/appstore/discover-chat.vue')
    ),
    meta: { title: 'menus.appstore.discoverChat', isHideTab: true }
  },
  {
    path: '/appstore/verification',
    name: 'AppVerification',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/verification.vue')
    ),
    meta: { title: 'menus.appstore.verification', isHideTab: true }
  },
  {
    path: '/appstore/assets',
    name: 'AppAssets',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/assets.vue')
    ),
    meta: { title: 'menus.appstore.assets', isHideTab: true }
  },
  {
    path: '/appstore/balance',
    name: 'AppBalance',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/balance.vue')
    ),
    meta: { title: 'menus.appstore.balance', isHideTab: true }
  },
  {
    path: '/appstore/accounts',
    name: 'AppAccounts',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/accounts.vue')
    ),
    meta: { title: 'menus.appstore.accounts', isHideTab: true }
  },
  {
    path: '/appstore/currency-detail',
    name: 'AppCurrencyDetail',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/currency-detail.vue')
    ),
    meta: { title: 'menus.appstore.currencyDetail', isHideTab: true }
  },
  {
    path: '/appstore/bills',
    name: 'AppBills',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/bills.vue')
    ),
    meta: { title: '账单', isHideTab: true }
  },
  {
    path: '/appstore/admin-center',
    name: 'AppAdminCenter',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/admin-center.vue')
    ),
    meta: { title: 'menus.appstore.adminCenter', isHideTab: true }
  },
  {
    path: '/appstore/personal-space',
    name: 'AppPersonalSpace',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/personal-space.vue')
    ),
    meta: { title: 'menus.appstore.personalSpace', isHideTab: true }
  },
  {
    path: '/appstore/browse/membership',
    name: 'AppMembership',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/membership.vue')
    ),
    meta: { title: 'menus.appstore.membership', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/profile/:userId?',
    name: 'AppProfile',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/profile.vue'),
      () => import('@/themes/pc/default/views/appstore/profile.vue')
    ),
    meta: { title: 'menus.appstore.profile', isHideTab: true }
  },
  {
    path: '/appstore/profile/edit',
    name: 'AppProfileEdit',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/profile-edit.vue'),
      () => import('@/themes/pc/default/views/appstore/profile-edit.vue')
    ),
    meta: { title: 'menus.appstore.profileEdit', isHideTab: true }
  },
  {
    path: '/appstore/submissions',
    name: 'AppSubmissions',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/submissions/index.vue'),
      () => import('@/themes/pc/default/views/appstore/submissions/index.vue')
    ),
    meta: { title: 'menus.appstore.submissions', isHideTab: true }
  },
  {
    path: '/appstore/submissions/edit',
    name: 'AppSubmissionsEdit',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/submissions/edit-form.vue'),
      () => import('@/themes/pc/default/views/appstore/submissions/edit.vue')
    ),
    meta: { title: 'menus.appstore.submissionsEdit', isHideTab: true }
  },
  {
    path: '/appstore/submissions/edit-zip',
    name: 'AppSubmissionsEditZip',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/submissions/edit-zip.vue'),
      () => import('@/themes/pc/default/views/appstore/submissions/edit.vue')
    ),
    meta: { title: 'menus.appstore.submissionsEdit', isHideTab: true }
  },
  {
    path: '/appstore/submissions/success',
    name: 'AppSubmissionsSuccess',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/submissions/success.vue'),
      () => import('@/themes/pc/default/views/appstore/submissions/success.vue')
    ),
    meta: { title: 'menus.appstore.submissionsSuccess', isHideTab: true }
  },
  {
    path: '/community/my-favorites',
    name: 'CommunityMyFavorites',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/my-favorites.vue')
    ),
    meta: { title: 'menus.community.myFavorites', isHideTab: true }
  },
  {
    path: '/community/vote/:id',
    name: 'CommunityVoteDetail',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/standalone-votes.vue')
    ),
    meta: { title: 'menus.community.voteDetail', isHideTab: true }
  },
  {
    path: '/community/moderator',
    name: 'CommunityModeratorCenter',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/moderator-center.vue')
    ),
    meta: { title: 'menus.community.moderator', isHideTab: true }
  },
  {
    path: '/appstore/records',
    name: 'AppRecords',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/records.vue')
    ),
    meta: { title: 'menus.appstore.records', isHideTab: true }
  },
  {
    path: '/appstore/mall',
    name: 'AppMallHome',
    redirect: '/appstore/mall-cart'
  },
  {
    path: '/appstore/membership',
    redirect: '/appstore/browse/membership'
  },
  {
    path: '/checkin',
    redirect: '/appstore/game'
  },
  {
    path: '/membership',
    redirect: '/appstore/browse/membership'
  },
  {
    path: '/appstore/checkin',
    name: 'AppCheckin',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/checkin.vue')
    ),
    meta: { title: 'menus.appstore.checkin', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/experience',
    name: 'AppExperience',
    component: () => import('@/themes/mobile/default/views/appstore/browse/experience.vue'),
    meta: { title: 'menus.appstore.experience', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/scheduled-posts',
    name: 'ScheduledPosts',
    component: () => import('@/themes/mobile/default/views/appstore/browse/scheduled-posts.vue'),
    meta: { title: 'menus.appstore.scheduledPosts', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/drafts',
    name: 'AppDrafts',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/drafts.vue'),
      () => import('@/themes/pc/default/views/appstore/drafts.vue')
    ),
    meta: { title: 'menus.appstore.drafts', isHideTab: true }
  },
  {
    path: '/appstore/blocklist',
    name: 'AppBlocklist',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/blocklist.vue'),
      () => import('@/themes/pc/default/views/appstore/blocklist.vue')
    ),
    meta: { title: 'menus.appstore.blocklist', isHideTab: true }
  },
  {
    path: '/appstore/coupon',
    name: 'AppCoupon',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/coupon.vue')
    ),
    meta: { title: 'menus.appstore.coupon', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/my-decorations',
    name: 'AppMyDecorations',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/my-decorations.vue')
    ),
    meta: { title: '我的装饰', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/appstore/avatar-frame',
    name: 'AppAvatarFrame',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/avatar-frame.vue')
    ),
    meta: { title: 'menus.appstore.avatarFrame', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/p/create/:sectionId?',
    name: 'PostCreate',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/post-edit.vue'),
      () => import('@/themes/pc/default/views/appstore/community/post-edit.vue')
    ),
    meta: { title: 'menus.community.postCreate', isHideTab: true }
  },
  {
    path: '/p/edit/:id',
    name: 'PostEdit',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/post-edit.vue'),
      () => import('@/themes/pc/default/views/appstore/community/post-edit.vue')
    ),
    meta: { title: 'menus.community.postEdit', isHideTab: true }
  },
  {
    path: '/p/:id',
    name: 'PostShort',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/post-detail.vue'),
      () => import('@/themes/pc/default/views/appstore/community/post-detail.vue')
    ),
    meta: { title: 'menus.community.postDetail', isHideTab: true }
  },
  {
    path: '/t/create',
    name: 'TopicCreate',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/topic-create.vue')
    ),
    meta: { title: 'menus.community.topicCreate', isHideTab: true }
  },
  {
    path: '/t/:id',
    name: 'TopicShort',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/community/topic-posts.vue'),
      () => import('@/themes/pc/default/views/appstore/community/topic-posts.vue')
    ),
    meta: { title: 'menus.community.topic', isHideTab: true }
  },
  {
    path: '/cl/create',
    name: 'CollectionCreate',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/create-collection.vue')
    ),
    meta: { title: 'menus.community.collectionCreate', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/cl/:id',
    name: 'CollectionShort',
    component: mobileComponent(
      () => import('@/themes/mobile/default/views/appstore/community/collection-detail.vue')
    ),
    meta: { title: 'menus.community.collection', isHideTab: true, hideBottomNav: true }
  },
  {
    path: '/u/edit',
    name: 'ProfileEditShort',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/profile-edit.vue'),
      () => import('@/themes/pc/default/views/appstore/profile-edit.vue')
    ),
    meta: { title: 'menus.appstore.profileEdit', isHideTab: true }
  },
  {
    path: '/u/:id',
    name: 'ProfileShort',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/profile.vue'),
      () => import('@/themes/pc/default/views/appstore/profile.vue')
    ),
    meta: { title: 'menus.appstore.profile', isHideTab: true }
  },
  {
    path: '/appstore/game',
    name: 'AppDiscover',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/game.vue'),
      () => import('@/themes/pc/default/views/appstore/game.vue')
    ),
    meta: { title: 'menus.appstore.discover', isHideTab: true }
  },
  {
    path: '/appstore/mine',
    name: 'AppMine',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/mine.vue'),
      () => import('@/themes/pc/default/views/appstore/mine.vue')
    ),
    meta: { title: 'menus.appstore.mine', isHideTab: true }
  },
  {
    path: '/appstore/mall-mobile',
    name: 'MallMobile',
    component: () => import('@/themes/mobile/default/views/appstore/browse/mall.vue'),
    meta: { title: '商城', isHideTab: true }
  },
  {
    path: '/appstore/ranking',
    name: 'AppStoreRanking',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/ranking.vue'),
      () => import('@/themes/pc/default/views/appstore/ranking.vue')
    ),
    meta: { title: 'menus.appstore.ranking', isHideTab: true }
  },
  {
    path: '/appstore/browse/detail/:id',
    name: 'AppStoreBrowseDetail',
    alias: '/a/:id',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/detail.vue'),
      () => import('@/themes/pc/default/views/appstore/browse/detail.vue')
    ),
    meta: { title: 'menus.appstore.detail', isHideTab: true }
  },
  {
    path: '/appstore/category',
    name: 'AppStoreCategory',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/category.vue'),
      () => import('@/themes/pc/default/views/appstore/category.vue')
    ),
    meta: { title: 'menus.appstore.category', isHideTab: true }
  },
  {
    path: '/appstore/browse/login',
    name: 'AppStoreLogin',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/login.vue'),
      () => import('@/themes/pc/default/views/appstore/browse/login.vue')
    ),
    meta: { title: 'menus.login.title', isHideTab: true, isPublic: true }
  },
  {
    path: '/auth/login',
    name: 'Login',
    component: () => import('@views/auth/login/index.vue'),
    meta: { title: 'menus.login.title', isHideTab: true, isPublic: true }
  },
  {
    path: '/auth/register',
    name: 'Register',
    component: () => import('@views/auth/register/index.vue'),
    meta: { title: 'menus.register.title', isHideTab: true, isPublic: true }
  },
  {
    path: '/auth/forget-password',
    name: 'ForgetPassword',
    component: () => import('@views/auth/forget-password/index.vue'),
    meta: { title: 'menus.forgetPassword.title', isHideTab: true, isPublic: true }
  },
  {
    path: '/appstore/mall-detail/:id',
    name: 'MallDetail',
    component: () => import('@/themes/mobile/default/views/appstore/mall/detail.vue'),
    meta: { title: 'menus.appstore.mallDetail', isHideTab: true }
  },
  {
    path: '/appstore/mall-reviews/:id',
    name: 'MallReviews',
    component: () => import('@/themes/mobile/default/views/appstore/mall/reviews.vue'),
    meta: { title: 'menus.appstore.mallReviews', isHideTab: true }
  },
  {
    path: '/appstore/digital-assets',
    name: 'DigitalAssets',
    component: () => import('@/themes/mobile/default/views/appstore/mall/digital-assets.vue'),
    meta: { title: 'menus.appstore.digitalAssets', keepAlive: false }
  },
  // 商城管理
  {
    path: '/appstore/mall-manage',
    name: 'MallManageStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/mall-manage.vue'),
    meta: { title: 'menus.appstore.mallManage', isHideTab: true }
  },
  {
    path: '/appstore/mall-product-create',
    name: 'MallProductCreateStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/mall-product-create.vue'),
    meta: { title: 'menus.appstore.mallProductCreate', isHideTab: true }
  },
  {
    path: '/appstore/card-pool',
    name: 'CardPoolStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/card-pool.vue'),
    meta: { title: 'menus.appstore.cardPool', isHideTab: true }
  },
  {
    path: '/appstore/mall-orders',
    name: 'MallOrdersStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/mall-orders.vue'),
    meta: { title: 'menus.appstore.mallOrders', isHideTab: true }
  },
  {
    path: '/appstore/mall-categories',
    name: 'MallCategoriesStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/mall-categories.vue'),
    meta: { title: 'menus.appstore.mallCategories', isHideTab: true }
  },
  {
    path: '/appstore/mall-after-sales',
    name: 'MallAfterSalesStatic',
    component: () => import('@/themes/mobile/default/views/appstore/mall/after-sales.vue'),
    meta: { title: 'menus.appstore.mallAfterSales', keepAlive: false }
  },
  {
    path: '/appstore/mall-logistics',
    name: 'MallLogistics',
    component: () => import('@/themes/mobile/default/views/appstore/mall/logistics.vue'),
    meta: { title: 'menus.appstore.mallLogistics', keepAlive: false }
  },
  {
    path: '/appstore/mall-cart',
    name: 'MallCart',
    component: () => import('@/themes/mobile/default/views/appstore/mall/cart.vue'),
    meta: { title: 'menus.appstore.mallCart', keepAlive: false }
  },
  {
    path: '/appstore/mall-my-orders',
    name: 'MallOrdersUser',
    component: () => import('@/themes/mobile/default/views/appstore/mall/orders.vue'),
    meta: { title: 'menus.appstore.mallMyOrders', keepAlive: false }
  },
  {
    path: '/appstore/mall-promotions',
    name: 'MallPromotionsStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/mall-promotions.vue'),
    meta: { title: 'menus.appstore.mallPromotions', isHideTab: true }
  },
  {
    path: '/appstore/tag-manage',
    name: 'TagManage',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/tag-manage.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/tag-manage.vue')
    ),
    meta: { title: 'menus.appstore.tagManage', isHideTab: true }
  },
  {
    path: '/appstore/analytics-dashboard',
    name: 'AnalyticsDashboard',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/analytics-dashboard.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/analytics-dashboard.vue')
    ),
    meta: { title: 'menus.appstore.analyticsDashboard', isHideTab: true }
  },
  {
    path: '/appstore/moderator-applications',
    name: 'ModeratorApplications',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/moderator-applications.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/moderator-applications.vue')
    ),
    meta: { title: 'menus.appstore.moderatorApplications', isHideTab: true }
  },
  {
    path: '/appstore/appeal-manage',
    name: 'AppealManage',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/appeal-manage.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/appeal-manage.vue')
    ),
    meta: { title: 'menus.appstore.appealManage', isHideTab: true }
  },
  {
    path: '/appstore/sensitive-words',
    name: 'SensitiveWords',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/sensitive-words.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/sensitive-words.vue')
    ),
    meta: { title: 'menus.appstore.sensitiveWords', isHideTab: true }
  },
  {
    path: '/appstore/unlock-requests',
    name: 'UnlockRequests',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/unlock-requests.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/unlock-requests.vue')
    ),
    meta: { title: 'menus.appstore.unlockRequests', isHideTab: true }
  },
  {
    path: '/403',
    name: 'Exception403Static',
    component: () => import('@views/exception/403/index.vue'),
    meta: { title: '403', isHideTab: true, isPublic: true }
  },
  {
    path: '/appstore/operation/avatar-effect',
    name: 'OperationAvatarEffect',
    component: () => import('@/views/operation/avatar-effect/index.vue'),
    meta: { title: '头像特效管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/comment-background',
    name: 'OperationCommentBackground',
    component: () => import('@/views/operation/comment-background/index.vue'),
    meta: { title: '评论背景墙管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/nickname-effect',
    name: 'OperationNicknameEffect',
    component: () => import('@/views/operation/nickname-effect/index.vue'),
    meta: { title: '昵称特效管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/home-bg',
    name: 'OperationHomeBg',
    component: () => import('@/views/operation/home-bg/index.vue'),
    meta: { title: '主页背景管理', isHideTab: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'Exception404Static',
    component: () => import('@views/exception/404/index.vue'),
    meta: { title: '404', isHideTab: true, isPublic: true }
  },
  {
    path: '/500',
    name: 'Exception500Static',
    component: () => import('@views/exception/500/index.vue'),
    meta: { title: '500', isHideTab: true, isPublic: true }
  },
  {
    path: '/appstore/mobile-console',
    name: 'MobileConsole',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mobile-console.vue'),
    meta: { title: 'menus.appstore.mobileConsole', isHideTab: true, isPublic: true }
  },
  {
    path: '/outside',
    component: () => import('@views/index/index.vue'),
    name: 'Outside',
    meta: { title: 'menus.outside.title' },
    children: [
  {
    path: '/appstore/delivery-logs',
    name: 'DeliveryLogsStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/delivery-logs.vue'),
    meta: { title: 'menus.appstore.deliveryLogs', isHideTab: true }
  },
  {
    path: '/appstore/redeem-codes',
    name: 'RedeemCodesStatic',
    component: () => import('@/themes/mobile/default/views/appstore/admin/mall/redeem-codes.vue'),
    meta: { title: 'menus.appstore.redeemCodes', isHideTab: true }
  },
  {
        path: '/outside/iframe/:path',
        name: 'Iframe',
        component: () => import('@/views/outside/Iframe.vue'),
        meta: { title: 'iframe' }
      }
    ]
  },
  {
    path: '/appstore/mall-favorites',
    name: 'MallFavorites',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/mall/favorites.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.mallFavorites', isHideTab: true }
  },
  {
    path: '/appstore/addresses',
    name: 'Addresses',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/mall/addresses.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.addresses', isHideTab: true }
  },
  {
    path: '/appstore/security-settings',
    name: 'SecuritySettings',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/security-settings.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.securitySettings', isHideTab: true }
  },
  {
    path: '/appstore/notification-settings',
    name: 'NotificationSettings',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/notification-settings.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.notificationSettings', isHideTab: true }
  },
  {
    path: '/appstore/login-history',
    name: 'LoginHistory',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/login-history.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.loginHistory', isHideTab: true }
  },
  {
    path: '/appstore/account-bind',
    name: 'AccountBind',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/account-bind.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.accountBind', isHideTab: true }
  },
  {
    path: '/appstore/settings',
    name: 'Settings',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/settings.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.settings', isHideTab: true }
  },
  {
    path: '/appstore/developer-analytics',
    name: 'DevAnalytics',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/developer-analytics.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.devAnalytics', isHideTab: true }
  },
  {
    path: '/appstore/version-changelog',
    name: 'VersionChangelog',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/version-changelog.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.versionChangelog', isHideTab: true }
  },
  {
    path: '/appstore/admin/bundles',
    name: 'AdminBundles',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/bundles.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/bundles.vue')
    ),
    meta: { title: 'menus.appstore.adminBundles', isHideTab: true }
  },
  {
    path: '/appstore/admin/collections',
    name: 'AdminCollections',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/collections.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/collections.vue')
    ),
    meta: { title: 'menus.appstore.adminCollections', isHideTab: true }
  },
  {
    path: '/appstore/admin/beta-testing',
    name: 'BetaTesting',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/admin/beta-testing.vue'),
      () => import('@/themes/mobile/default/views/appstore/admin/beta-testing.vue')
    ),
    meta: { title: 'menus.appstore.betaTesting', isHideTab: true }
  },
  {
    path: '/appstore/dashboard-stats',
    name: 'DashboardStats',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/dashboard-stats.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.dashboardStats', isHideTab: true }
  },
  {
    path: '/appstore/commission-dashboard',
    name: 'CommissionDashboard',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/commission-dashboard.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.commissionDashboard', isHideTab: true }
  },
  {
    path: '/appstore/promotion-materials',
    name: 'PromotionMaterials',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/promotion-materials.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.promotionMaterials', isHideTab: true }
  },
  {
    path: '/appstore/commission-orders',
    name: 'CommissionOrders',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/user/commission-orders.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.commissionOrders', isHideTab: true }
  },
  {
    path: '/appstore/browse/notifications',
    name: 'AppStoreNotifications',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/notifications.vue'),
      () => import('@views/index/index.vue')
    ),
    meta: { title: 'menus.appstore.notifications', isHideTab: true }
  },
  {
    path: '/appstore/collection/:id',
    name: 'CollectionDetail',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/collection-detail.vue'),
      () => import('@/themes/mobile/default/views/appstore/browse/collection-detail.vue')
    ),
    meta: { title: '应用合集', isHideTab: true }
  },
  {
    path: '/appstore/collections/mine',
    name: 'CollectionsMine',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/collections/mine.vue'),
      () => import('@/themes/mobile/default/views/appstore/browse/collections/mine.vue')
    ),
    meta: { title: '我的合集', isHideTab: true }
  },
  {
    path: '/appstore/my-collections',
    name: 'MyCollections',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/collections/my-collections.vue'),
      () => import('@/themes/mobile/default/views/appstore/browse/collections/my-collections.vue')
    ),
    meta: { title: '我的合集', isHideTab: true }
  },
  {
    path: '/appstore/collections/ranking',
    name: 'CollectionsRanking',
    component: themeComponent(
      () => import('@/themes/mobile/default/views/appstore/browse/collections/ranking.vue'),
      () => import('@/themes/mobile/default/views/appstore/browse/collections/ranking.vue')
    ),
    meta: { title: '合集排行榜', isHideTab: true }
  },
  {
    path: '/appstore/:id/ratings',
    name: 'RatingDetail',
    component: () => import('@/views/appstore/RatingDetail.vue'),
    meta: { title: '评分详情', isHideTab: true }
  },
  {
    path: '/appstore/compare',
    name: 'AppCompareStatic',
    component: () => import('@/views/appstore/AppCompare.vue'),
    meta: { title: '应用对比', isHideTab: true }
  },
  {
    path: '/appstore/dev/analytics',
    name: 'DevAnalyticsStatic',
    component: () => import('@/views/operation/developer-analytics/index.vue'),
    meta: { title: '开发者分析', isHideTab: true }
  },
  // ============ 管理中心 - 系统管理 ============
  {
    path: '/appstore/user-manage',
    name: 'UserManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/user-manage.vue'),
    meta: { title: 'menus.admin.userManage', isHideTab: true }
  },
  {
    path: '/appstore/role-manage',
    name: 'RoleManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/role-manage.vue'),
    meta: { title: 'menus.admin.roleManage', isHideTab: true }
  },
  {
    path: '/appstore/menu-manage',
    name: 'MenuManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/menu-manage.vue'),
    meta: { title: 'menus.admin.menuManage', isHideTab: true }
  },
  {
    path: '/appstore/delete-review',
    name: 'DeleteReview',
    component: () => import('@/themes/mobile/default/views/appstore/admin/delete-review.vue'),
    meta: { title: 'menus.admin.deleteReview', isHideTab: true }
  },
  {
    path: '/appstore/verification-manage',
    name: 'VerificationManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/verification-manage.vue'),
    meta: { title: 'menus.admin.verificationManage', isHideTab: true }
  },
  {
    path: '/appstore/invite-manage',
    name: 'InviteManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/invite-manage.vue'),
    meta: { title: 'menus.admin.inviteManage', isHideTab: true }
  },
  {
    path: '/appstore/email-config',
    name: 'EmailConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/email-config.vue'),
    meta: { title: 'menus.admin.emailConfig', isHideTab: true }
  },
  {
    path: '/appstore/recycle',
    name: 'Recycle',
    component: () => import('@/themes/mobile/default/views/appstore/browse/recycle.vue'),
    meta: { title: '我的回收站', isHideTab: true }
  },
  {
    path: '/appstore/syslog',
    name: 'Syslog',
    component: () => import('@/themes/mobile/default/views/appstore/admin/syslog.vue'),
    meta: { title: 'menus.admin.syslog', isHideTab: true }
  },
  {
    path: '/appstore/site-config',
    name: 'SiteConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/site-config.vue'),
    meta: { title: 'menus.admin.siteConfig', isHideTab: true }
  },
  {
    path: '/appstore/compliance-settings',
    name: 'ComplianceSettings',
    component: () => import('@/themes/mobile/default/views/appstore/admin/compliance-settings.vue'),
    meta: { title: 'menus.admin.complianceSettings', isHideTab: true }
  },
  {
    path: '/appstore/task-manage',
    name: 'TaskManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/task-manage.vue'),
    meta: { title: 'menus.admin.taskManage', isHideTab: true }
  },
  {
    path: '/appstore/email-templates',
    name: 'EmailTemplates',
    component: () => import('@/themes/mobile/default/views/appstore/admin/email-templates.vue'),
    meta: { title: 'menus.admin.emailTemplates', isHideTab: true }
  },
  {
    path: '/appstore/email-push',
    name: 'EmailPush',
    component: () => import('@/themes/mobile/default/views/appstore/admin/email-push.vue'),
    meta: { title: 'menus.admin.emailPush', isHideTab: true }
  },
  // ============ 管理中心 - 运营管理 ============
  {
    path: '/appstore/cardkey-manage',
    name: 'CardkeyManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/cardkey-manage.vue'),
    meta: { title: 'menus.admin.cardkeyManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/membership',
    name: 'OperationMembership',
    component: () => import('@/themes/mobile/default/views/appstore/admin/membership-manage.vue'),
    meta: { title: 'menus.admin.membershipManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/coupon',
    name: 'OperationCoupon',
    component: () => import('@/themes/mobile/default/views/appstore/admin/coupon-manage.vue'),
    meta: { title: 'menus.admin.couponManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/points',
    name: 'OperationPoints',
    component: () => import('@/themes/mobile/default/views/appstore/admin/points-manage.vue'),
    meta: { title: 'menus.admin.pointsManage', isHideTab: true }
  },
  {
    path: '/appstore/experience-manage',
    name: 'ExperienceManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/experience-manage.vue'),
    meta: { title: 'menus.admin.experienceManage', isHideTab: true }
  },
  {
    path: '/appstore/currency-manage',
    name: 'CurrencyManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/currency-manage.vue'),
    meta: { title: 'menus.admin.currencyManage', isHideTab: true }
  },
  {
    path: '/appstore/plugin-manage',
    name: 'PluginManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/plugin-manage.vue'),
    meta: { title: 'menus.admin.pluginManage', isHideTab: true }
  },
  {
    path: '/appstore/title-manage',
    name: 'TitleManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/title-manage.vue'),
    meta: { title: 'menus.admin.titleManage', isHideTab: true }
  },
  {
    path: '/appstore/commission-manage',
    name: 'CommissionManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/commission-manage.vue'),
    meta: { title: 'menus.admin.commissionManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/settlement',
    name: 'OperationSettlement',
    component: () => import('@/themes/mobile/default/views/appstore/admin/settlement.vue'),
    meta: { title: 'menus.admin.settlement', isHideTab: true }
  },
  {
    path: '/appstore/operation/membership-products',
    name: 'OperationMembershipProducts',
    component: () => import('@/themes/mobile/default/views/appstore/admin/membership-products.vue'),
    meta: { title: 'menus.admin.membershipProducts', isHideTab: true }
  },
  {
    path: '/appstore/operation/purchase-records',
    name: 'OperationPurchaseRecords',
    component: () => import('@/themes/mobile/default/views/appstore/admin/purchase-records.vue'),
    meta: { title: 'menus.admin.purchaseRecords', isHideTab: true }
  },
  {
    path: '/appstore/operation/content-purchases',
    name: 'OperationContentPurchases',
    component: () => import('@/themes/mobile/default/views/appstore/admin/content-purchases.vue'),
    meta: { title: 'menus.admin.contentPurchases', isHideTab: true }
  },
  {
    path: '/appstore/operation/game-center',
    name: 'OperationGameCenter',
    component: () => import('@/themes/mobile/default/views/appstore/admin/game-center-manage.vue'),
    meta: { title: 'menus.admin.gameCenter', isHideTab: true }
  },
  {
    path: '/appstore/operation/checkin',
    name: 'OperationCheckin',
    component: () => import('@/themes/mobile/default/views/appstore/admin/checkin-manage.vue'),
    meta: { title: 'menus.admin.checkinManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/layout-themes',
    name: 'OperationLayoutThemes',
    component: () => import('@/themes/mobile/default/views/appstore/admin/layout-themes.vue'),
    meta: { title: 'menus.admin.layoutThemes', isHideTab: true }
  },
  {
    path: '/appstore/operation/avatar-frame',
    name: 'OperationAvatarFrame',
    component: () => import('@/themes/mobile/default/views/appstore/admin/avatar-frame-manage.vue'),
    meta: { title: 'menus.admin.avatarFrameManage', isHideTab: true }
  },
  {
    path: '/appstore/operation/payment-config',
    name: 'OperationPaymentConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/payment-config.vue'),
    meta: { title: 'menus.admin.paymentConfig', isHideTab: true }
  },
  {
    path: '/appstore/operation/recharge-amounts',
    name: 'OperationRechargeAmounts',
    component: () => import('@/themes/mobile/default/views/appstore/admin/recharge-amounts.vue'),
    meta: { title: 'menus.admin.rechargeAmounts', isHideTab: true }
  },
  // ============ 管理中心 - 应用商店 ============
  {
    path: '/appstore/list',
    name: 'AppManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/app-manage.vue'),
    meta: { title: 'menus.admin.appManage', isHideTab: true }
  },
  {
    path: '/appstore/category-manage',
    name: 'CategoryManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/category-manage.vue'),
    meta: { title: 'menus.admin.categoryManage', isHideTab: true }
  },
  {
    path: '/appstore/reports',
    name: 'ReportsManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/reports.vue'),
    meta: { title: 'menus.admin.reports', isHideTab: true }
  },
  {
    path: '/appstore/review-mobile',
    name: 'ReviewMobile',
    component: () => import('@/themes/mobile/default/views/appstore/admin/review-mobile.vue'),
    meta: { title: 'menus.admin.reviewMobile', isHideTab: true }
  },
  {
    path: '/appstore/official-tags',
    name: 'OfficialTags',
    component: () => import('@/themes/mobile/default/views/appstore/admin/official-tags.vue'),
    meta: { title: 'menus.admin.officialTags', isHideTab: true }
  },
  {
    path: '/appstore/section-manage',
    name: 'SectionManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/section-manage.vue'),
    meta: { title: 'menus.admin.sectionManage', isHideTab: true }
  },
  {
    path: '/appstore/topic-manage',
    name: 'TopicManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/topic-manage.vue'),
    meta: { title: 'menus.admin.topicManage', isHideTab: true }
  },
  {
    path: '/appstore/post-review',
    name: 'PostReview',
    component: () => import('@/themes/mobile/default/views/appstore/admin/post-review.vue'),
    meta: { title: 'menus.admin.postReview', isHideTab: true }
  },
  {
    path: '/appstore/sms-config',
    name: 'SmsConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/sms-config.vue'),
    meta: { title: 'menus.admin.smsConfig', isHideTab: true }
  },
  {
    path: '/appstore/ip-service-config',
    name: 'IpServiceConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/ip-service-config.vue'),
    meta: { title: 'menus.admin.ipServiceConfig', isHideTab: true }
  },
  {
    path: '/appstore/oauth-config',
    name: 'OauthConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/oauth-config.vue'),
    meta: { title: 'menus.admin.oauthConfig', isHideTab: true }
  },
  {
    path: '/appstore/logistics-config',
    name: 'LogisticsConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/logistics-config.vue'),
    meta: { title: 'menus.admin.logisticsConfig', isHideTab: true }
  },
  // ============ 管理中心 - 文件管理 ============
  {
    path: '/appstore/storage-files',
    name: 'StorageFiles',
    component: () => import('@/themes/mobile/default/views/appstore/admin/storage-files.vue'),
    meta: { title: 'menus.admin.storageFiles', isHideTab: true }
  },
  {
    path: '/appstore/storage-config',
    name: 'StorageConfig',
    component: () => import('@/themes/mobile/default/views/appstore/admin/storage-config.vue'),
    meta: { title: 'menus.admin.storageConfig', isHideTab: true }
  },
  {
    path: '/appstore/file-repo-manage',
    name: 'FileRepoManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/file-repo-manage.vue'),
    meta: { title: 'menus.admin.fileRepoManage', isHideTab: true }
  },
  {
    path: '/appstore/file-policy-manage',
    name: 'FilePolicyManage',
    component: () => import('@/themes/mobile/default/views/appstore/admin/file-policy-manage.vue'),
    meta: { title: 'menus.admin.filePolicyManage', isHideTab: true }
  },
  {
    path: '/appstore/data-export',
    name: 'DataExport',
    component: () => import('@/themes/mobile/default/views/appstore/user/data-export.vue'),
    meta: { title: '数据导出', isHideTab: true }
  }
]
