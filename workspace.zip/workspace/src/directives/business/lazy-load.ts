/**
 * v-lazy 图片懒加载指令
 *
 * 基于 IntersectionObserver 的图片懒加载指令。
 * 当图片元素进入视口时才加载真实的图片资源。
 *
 * ## 主要功能
 *
 * - 懒加载 - 使用 IntersectionObserver 检测元素可见性
 * - 占位图 - 加载前显示占位图或背景色
 * - 渐入效果 - 加载完成后添加淡入动画
 * - 错误处理 - 加载失败时显示默认占位图
 * - 自动清理 - 加载完成后自动断开观察器
 *
 * ## 使用示例
 *
 * ```vue
 * <template>
 *   <!-- 基础用法 -->
 *   <img v-lazy="imageUrl" alt="图片">
 *
 *   <!-- 带占位图 -->
 *   <img v-lazy="{ src: imageUrl, placeholder: '/placeholder.png' }">
 * </template>
 * ```
 *
 * @module directives/lazy-load
 * @author Art Design Pro Team
 */

import type { App, Directive, DirectiveBinding } from 'vue'

export interface LazyLoadOptions {
  src: string
  placeholder?: string
}

export type LazyLoadDirective = Directive<HTMLImageElement, string | LazyLoadOptions>

const DEFAULT_PLACEHOLDER = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 400 300%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22400%22 height=%22300%22/%3E%3C/svg%3E'

const observerMap = new WeakMap<HTMLImageElement, IntersectionObserver>()

function createObserver(img: HTMLImageElement, src: string) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const target = entry.target as HTMLImageElement
          const img = new Image()
          img.onload = () => {
            target.src = src
            target.style.transition = 'opacity 0.4s ease'
            target.style.opacity = '1'
            target.classList.add('lazy-loaded')
          }
          img.onerror = () => {
            target.style.opacity = '1'
          }
          img.src = src
          observer.unobserve(target)
          observerMap.delete(target)
        }
      })
    },
    {
      rootMargin: '100px',
      threshold: 0.01
    }
  )

  observer.observe(img)
  observerMap.set(img, observer)
}

const lazyLoadDirective: LazyLoadDirective = {
  mounted(el: HTMLImageElement, binding: DirectiveBinding) {
    const value = binding.value
    const src = typeof value === 'string' ? value : value?.src || ''
    const placeholder = typeof value === 'object' ? value?.placeholder : undefined

    el.style.opacity = '0'
    el.src = placeholder || DEFAULT_PLACEHOLDER

    if (src) {
      createObserver(el, src)
    }
  },

  updated(el: HTMLImageElement, binding: DirectiveBinding) {
    const value = binding.value
    const src = typeof value === 'string' ? value : value?.src || ''

    if (!src) return

    const existingObserver = observerMap.get(el)
    if (existingObserver) {
      existingObserver.unobserve(el)
      observerMap.delete(el)
    }
    createObserver(el, src)
  },

  unmounted(el: HTMLImageElement) {
    const observer = observerMap.get(el)
    if (observer) {
      observer.disconnect()
      observerMap.delete(el)
    }
  }
}

export function setupLazyLoadDirective(app: App) {
  app.directive('lazy', lazyLoadDirective)
}
