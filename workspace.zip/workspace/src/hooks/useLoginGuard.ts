import { computed } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { useLoginModalStore } from '@/store/modules/loginModal'

export function useLoginGuard() {
  const userStore = useUserStore()
  const loginModalStore = useLoginModalStore()

  const isLogin = computed(() => userStore.isLogin)

  function requireLogin(onSuccess?: () => void): boolean {
    if (!userStore.isLogin) {
      loginModalStore.open(onSuccess)
      return false
    }
    return true
  }

  return { requireLogin, isLogin }
}
