const AUTO_REFRESH_KEY = 'art_site_auto_refresh'
const SESSION_KEY = '__art_session_active'
const SKIP_FLAG = '__art_skip_autoload'

declare global { interface Window { [SKIP_FLAG]?: boolean } }

export function initAutoRefreshSession(): void {
  try {
    if (sessionStorage.getItem(SESSION_KEY)) return
    sessionStorage.setItem(SESSION_KEY, '1')
  } catch {}

  try {
    if (localStorage.getItem(AUTO_REFRESH_KEY) === '0') {
      ;(window as any)[SKIP_FLAG] = true
    }
  } catch {}
}

export function clearAutoRefreshFlag(): void {
  ;(window as any)[SKIP_FLAG] = false
}

export function shouldSkipAutoLoad(): boolean {
  return !!(window as any)[SKIP_FLAG]
}

export { AUTO_REFRESH_KEY, SESSION_KEY, SKIP_FLAG }
