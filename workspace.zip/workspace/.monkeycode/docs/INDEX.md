# Art Design Pro 文档

面向设计与创意社区的综合性 Web 平台文档。本文档涵盖系统架构、API 参考、开发指南和功能模块说明。

**快速链接**：[架构](./ARCHITECTURE.md) | [接口](./INTERFACES.md) | [开发者指南](./DEVELOPER_GUIDE.md)

---

## 核心文档

### [架构](./ARCHITECTURE.md)
系统设计、技术栈、组件结构和数据流程。从这里开始了解系统如何运作。

### [接口](./INTERFACES.md)
全部 ~460 个 API 端点的完整文档，包含 HTTP 方法、路径、参数和响应格式。集成或使用此系统的参考。

### [开发者指南](./DEVELOPER_GUIDE.md)
环境搭建、宝塔面板部署、定时任务详解、开发工作流和编码规范。贡献者必读。

---

## 功能模块

| 模块 | 描述 | 详解 |
|------|------|------|
| 社区 (`server/routes/community/`) | 帖子发布、评论、投票、付费内容、版主审核 | [README](./模块/community.md) |
| 应用商店 (`server/routes/appstore.cjs`) | 应用发布、版本管理、评论评分、打赏购买 | [README](./模块/appstore.md) |
| 商城 (`server/routes/mall.cjs`) | 商品管理、购物车、订单、物流、售后 | [README](./模块/mall.md) |
| 聊天室与私信 (`server/routes/chat-room.cjs`) | 群组聊天、私信、WebSocket 实时推送 | [README](./模块/chat-room.md) |
| 用户与认证 (`server/routes/user.cjs`) | 登录注册、2FA、OAuth、角色权限 | [README](./模块/user-auth.md) |
| 合集 (`server/routes/collection.cjs`) | 精选内容合集、付费阅读、进度追踪 | [README](./模块/collection.md) |
| 通知 (`server/routes/notification.cjs`) | 系统通知、推送、用户偏好 | [README](./模块/notification.md) |

---

## 核心概念

理解这些领域概念有助于导航代码库：

| 概念 | 说明 |
|------|------|
| **Section / 板块** | 社区的内容分区，每个板块可有独立的版主和审核规则 |
| **Post / 帖子** | 社区的基本内容单元，支持富文本、投票、付费内容、资源附件 |
| **Application / 应用** | 应用商店的核心实体，支持多版本、评论、购买和打赏 |
| **Product / 商品** | 商城的交易实体，支持实物和虚拟商品 |
| **Collection / 合集** | 多帖子的精选集合，支持付费和章节组织 |
| **Chat Room / 聊天室** | 群组实时聊天空间，支持消息、文件、礼物和成员管理 |

---

## 已知问题

- [已知问题清单](./模块/known-issues.md) — 4 个致命 Bug、8 个高危安全漏洞、30+ 个中等性能问题

---

## 入门指南

### 项目新人

按此路径学习：
1. **[架构](./ARCHITECTURE.md)** — 了解全局
2. **[核心概念](#核心概念)** — 学习领域术语
3. **[开发者指南](./DEVELOPER_GUIDE.md)** — 搭建环境
4. **[接口](./INTERFACES.md)** — 探索公开 API

### 需要集成

1. **[接口](./INTERFACES.md)** — API 契约和认证
2. **[架构](./ARCHITECTURE.md)** — 系统边界和数据流

### 首次贡献

1. **[开发者指南](./DEVELOPER_GUIDE.md)** — 搭建和工作流
2. **[已知问题](./模块/known-issues.md)** — 可修复的 Bug 和安全问题
3. **[模块文档](#功能模块)** — 按需阅读对应模块的 README

---

## 快速参考

### 命令

```bash
npm run dev              # 启动前端 :3333
cd server && node index.cjs  # 启动后端 :3001
cd server && node seed.cjs   # 数据库初始化
npm run build            # 生产构建
```

### 重要文件

| 文件 | 目的 |
|------|------|
| `server/index.cjs` | 后端入口 |
| `server/database.cjs` | 数据库连接和建表（2189 行） |
| `server/scheduler.cjs` | 定时任务调度器 |
| `src/main.ts` | 前端入口 |
| `vite.config.ts` | 前端构建配置（含 API 代理） |
| `server/.env` | 环境变量 |

### 定时任务

| 任务 | 周期 |
|------|------|
| 计划发帖发布 | 60 秒 |
| 订单自动确认 | 60 秒 |
| 会话清理 | 5 分钟 |
| 2FA 会话清理 | 5 分钟 |
| 速率限制清理 | 5 分钟 |
| IP 缓存清理 | 10 分钟 |
