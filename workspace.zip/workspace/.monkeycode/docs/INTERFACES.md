# 接口文档 — Art Design Pro

本文档完整记录了 Art Design Pro 后端所有公开 API 端点。共约 460 个端点，分为 20 个业务模块。

**Base URL**：`http://localhost:3001/api`

**认证方式**：Bearer Token，登录后获取，请求头 `Authorization: Bearer <token>`

**响应格式**：所有接口返回标准 JSON 格式 `{ code: number, msg?: string, data?: any }`

---

## 目录

1. [认证与系统](#1-认证与系统-systemcjs)
2. [用户管理](#2-用户管理-usercjs)
3. [应用商店](#3-应用商店-appstorecjs)
4. [商城](#4-商城-mallcjs)
5. [社区帖子](#5-社区帖子-community-postscjs)
6. [社区管理](#6-社区管理-community-admincjs)
7. [版主中心](#7-版主中心-community-moderatorcjs)
8. [社区板块管理](#8-社区板块管理-community-sectionscjs)
9. [社区互动](#9-社区互动-community-interactionscjs)
10. [聊天室与私信](#10-聊天室与私信-chat-roomcjs)
11. [合集与收藏](#11-合集与收藏-collectioncjs)
12. [通知](#12-通知-notificationcjs)
13. [文件上传](#13-文件上传-uploadcjs)
14. [邮件与短信](#14-邮件与短信-emailcjs)
15. [搜索](#15-搜索-searchcjs)
16. [运营管理](#16-运营管理-operationcjs)
17. [双因素认证](#17-双因素认证-two-factorcjs)
18. [结算](#18-结算-settlementcjs)
19. [插件系统](#19-插件系统-pluginsscjs)
20. [推荐系统](#20-推荐系统-recommendcjs)

---

## 1. 认证与系统 (system.cjs)

### 登录

| 端点 | 方法 | 认证 |
|------|------|------|
| `/api/auth/login` | POST | 无 |

**请求体**：
| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `userName` / `username` | string | 是 | 用户名 |
| `password` | string | 是 | 密码 |

**响应**：
```json
{ "code": 200, "msg": "登录成功", "data": { "token": "...", "refreshToken": "..." } }
```
启用 2FA 时返回 `{ "need2FA": true, "tempToken": "..." }`

---

| 端点 | 方法 | 认证 |
|------|------|------|
| `/api/auth/login/2fa` | POST | 无 |

**请求体**：`tempToken`, `code`（6 位数字）

**响应**：`{ "code": 200, "data": { "token": "...", "refreshToken": "..." } }`

### 用户信息

| 端点 | 方法 | 认证 |
|------|------|------|
| `/api/user/info` | GET | Bearer Token |

**响应**：
```json
{
  "code": 200,
  "data": {
    "buttons": [],
    "roles": ["R_USER"],
    "userId": 1,
    "userName": "admin",
    "email": "admin@example.com",
    "avatar": "/uploads/avatar.jpg",
    "phone": "13800138000",
    "gender": 1,
    "nickname": "管理员",
    "bio": "这是个人简介",
    "points": 1000,
    "balance": 50.00,
    "experience": 500,
    "levelId": 1,
    "levelName": "青铜",
    "expireTime": null,
    "discountRate": 10
  }
}
```

### OAuth 相关

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/auth/oauth/providers` | GET | 无 | 支持的 OAuth 提供商列表 |
| `/api/auth/oauth/login` | POST | 无 | OAuth 登录（开发中） |
| `/api/auth/oauth/bind` | POST | Bearer | 绑定 OAuth 账号 |
| `/api/user/oauth-accounts` | GET | Bearer | 我的 OAuth 绑定列表 |
| `/api/user/oauth-accounts/:id` | DELETE | Bearer | 解绑 OAuth |
| `/api/admin/oauth-configs` | GET | 无 | OAuth 配置列表 |
| `/api/admin/oauth-configs` | POST | 无 | 保存 OAuth 配置 |

### 角色与菜单

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/role/list` | GET | 无 | 角色列表（分页） |
| `/api/role/save` | POST | 无 | 创建/更新角色 |
| `/api/role/:id` | DELETE | 无 | 删除角色 |
| `/api/role/:id/permissions` | GET | 无 | 查看角色权限 |
| `/api/role/:id/permissions` | POST | 无 | 设置角色权限 |
| `/api/v3/system/menus/simple` | GET | Session | 树形菜单（前端导航） |

### 仪表盘

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/dashboard/stats` | GET | 无 | 基本统计（用户数/在线/积分/卡密/今日新增） |
| `/api/admin/console-stats` | GET | 无 | 综合统计（含社区/商城/应用商店/聊天等各模块） |

### 搜索

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/search` | GET | 无 | 全局搜索：`?q=关键词&type=all,post,app,product&page=1&pageSize=20` |

---

## 2. 用户管理 (user.cjs)

### 注册与密码

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/auth/register` | POST | 无 | 注册：`username`, `password`, `inviteCode`(可选) |
| `/api/auth/change-pwd` | POST | 无 | 修改密码：`userId`, `oldPassword`, `newPassword` |
| `/api/user/change-email` | POST | 无 | 修改邮箱：`userId`, `email`, `emailCode`, `password` |

### 用户列表与 CRUD（管理员）

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/list` | GET | 管理员 | 用户列表（含排序/筛选）：`current`, `size`, `userName`, `sortField`, `sortOrder` |
| `/api/user/update` | POST | 管理员+edit | 更新用户（含角色/积分/会员/封禁等全部字段） |
| `/api/user/create` | POST | 管理员+add | 创建用户 |
| `/api/user/:id` | DELETE | 管理员+delete | 软删除（status=4） |

### 个人资料

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/profile` | GET | 无 | 查看用户资料：`?userId=1` |
| `/api/user/profile` | PUT | 无 | 更新个人资料（昵称/简介/头像/背景等） |
| `/api/user/:id` | GET | 无 | 用户公开信息 |
| `/api/user/search` | GET | 无 | 扫码搜索用户：`?keyword=xxx` |
| `/api/user/by-username/:username` | GET | 无 | 按用户名查找 |

### 用户评论

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/comments` | GET | 无 | 用户的应用评论 `?userId=1&page=1&pageSize=20` |
| `/api/user/community-comments` | GET | 无 | 用户的社区评论 |

### 用户应用

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/apps` | GET | 无 | 用户上传的应用列表 `?userId=1&page=1&pageSize=20` |

### 记录查询

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/balance-records` | GET | 无 | 余额变动记录 |
| `/api/user/experience-records` | GET | 无 | 经验变动记录 |
| `/api/user/membership-records` | GET | 无 | 会员购买记录 |
| `/api/user/membership-purchases/:userId` | GET | 管理员 | 某用户的会员购买记录 |

### 隐私设置

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/privacy-settings` | GET | Bearer | 获取隐私设置 |
| `/api/user/privacy-settings` | PUT | Bearer | 更新隐私设置 |

### 申诉与注销

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/appeal` | POST | 无 | 提交申诉：`userId`, `reason`, `type` |
| `/api/user/appeals` | GET | 无 | 申诉列表 `?page=1&pageSize=20&status=pending` |
| `/api/user/appeal/:id/review` | POST | 无 | 审核申诉：`action`(approve/reject), `reply` |
| `/api/user/delete-request` | POST | 无 | 申请注销：`userId`, `reason` |
| `/api/user/delete-requests` | GET | 无 | 注销申请列表 |
| `/api/user/delete-request/:id/review` | POST | 无 | 审核注销申请 |

### 仪表盘

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/dashboard/stats` | GET | Bearer | 用户仪表盘统计（帖子数/评论数等） |

---

## 3. 应用商店 (appstore.cjs)

### 应用列表与详情

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/list` | GET | optional | 应用列表：`?keyword=&category=&status=&page=1&pageSize=20` |
| `/api/app/hot-today` | GET | 无 | 今日热门：`?limit=5` |
| `/api/app/trending-week` | GET | 无 | 本周趋势：`?limit=9` |
| `/api/app/:id/detail` | GET | 无 | 应用详情（含评论/版本/打赏/评分统计） |
| `/api/app/:id/versions` | GET | 无 | 应用版本列表 |
| `/api/app/:id/changelog` | GET | 无 | 更新日志 |
| `/api/app/:id/related` | GET | 无 | 关联应用推荐 |
| `/api/app/:id/analytics` | GET | 无 | 应用数据分析 |

### 应用管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/save` | POST | Bearer+approve | 创建/更新应用（作者编辑后需重新审核） |
| `/api/app/:id` | DELETE | Bearer+delete | 删除应用（同时删除评论/版本/打赏） |
| `/api/app/upload` | POST | 无 | 上传 APK |
| `/api/app/uploads` | GET | 无 | 上传记录列表 |
| `/api/app/:id/pin` | POST | 无 | 置顶应用 |
| `/api/app/:id/official` | POST | 无 | 设为官方 |
| `/api/app/:id/featured` | POST | 无 | 设为精选 |

### 应用版本

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/version/save` | POST | 无 | 创建/更新版本 |
| `/api/app/version/:id` | DELETE | 无 | 删除版本 |

### 评论与评分

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/:id/comment` | POST | 无 | 发布评论：`userId`, `content`, `rating`（30 秒限流，仅一次评分） |
| `/api/app/:id/comment/:cid/like` | POST | 无 | 点赞/取消评论 |
| `/api/app/:id/comment/:cid` | DELETE | 无 | 删除评论：`?userId=` |
| `/api/app/:id/comment/:cid/reply` | POST | 无 | 回复评论 |
| `/api/app/:id/comment/:cid/pin` | POST | 无 | 置顶评论（最多 3 条） |
| `/api/app/comment/:id` | DELETE | 无 | 管理员删除评论 |
| `/api/app/comment/:id/ignore` | POST | 无 | 忽略举报 |
| `/api/app/:appId/comment/:cid/report` | POST | 无 | 举报评论 |
| `/api/app/reports` | GET | 无 | 举报列表 |
| `/api/appstore/:id/ratings` | GET | 无 | 评分详情 |

### 打赏与购买

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/:id/tip` | POST | 无 | 打赏：`userId`, `amount`, `tipType`, `message` |
| `/api/app/:id/tips` | GET | 无 | 打赏记录 |
| `/api/app/:id/purchase` | POST | 无 | 购买/支付应用 |
| `/api/app/:id/purchase-status` | GET | 无 | 检查购买状态：`?userId=` |
| `/api/app/:id/purchasers` | GET | 无 | 购买者列表 |

### 内测

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/app/:id/beta` | GET | 无 | 内测信息 |
| `/api/app/:id/beta-users` | POST | 无 | 注册内测 |

### 收藏与套包

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/appstore/:id/favorite` | POST | Bearer | 收藏/取消应用 |
| `/api/appstore/favorites` | GET | Bearer | 我的收藏 |
| `/api/appstore/bundles` | GET | 无 | 套包列表 |
| `/api/appstore/bundles` | POST | Bearer | 创建套包 |
| `/api/appstore/bundles/:id` | PUT/DELETE | Bearer | 更新/删除套包 |
| `/api/appstore/bundles/:id/apps` | POST/DELETE(/:appId) | Bearer | 添加/移除应用 |

### 分类

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/category/list` | GET | 无 | 分类列表 |
| `/api/category/save` | POST | Bearer+add | 创建/更新分类 |
| `/api/category/:id` | DELETE | Bearer+delete | 删除分类 |

### 合集

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/appstore/collections` | GET | 无 | 合集列表 |
| `/api/appstore/collections/:id` | GET | 无 | 合集详情（含应用列表） |
| `/api/appstore/collections` | POST | Bearer+approve | 创建合集 |
| `/api/appstore/collections/:id` | PUT/DELETE | Bearer+approve/delete | 更新/删除合集 |
| `/api/appstore/collections/:id/apps` | POST | Bearer+approve | 添加应用 |
| `/api/appstore/collections/:id/apps/:appId` | DELETE | Bearer+delete | 移除应用 |

### 申诉

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/appeal/submit` | POST | Bearer | 提交申诉 |
| `/api/admin/appeals` | GET | Bearer | 申诉列表 |
| `/api/admin/appeals/:id` | PUT | Bearer | 处理申诉 |

### 统计

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/appstore/developer/analytics` | GET | 无 | 开发者统计 |
| `/api/appstore/dev/analytics/:id` | GET | 无 | 单个应用开发者分析 |

---

## 4. 商城 (mall.cjs)

### 商品

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/products` | GET | 无 | 商品列表：`?categoryId=1&sortBy=sales&page=1&pageSize=20` |
| `/api/mall/products/:id` | GET | 无 | 商品详情（含选项和图片） |
| `/api/mall/products` | POST | Bearer+add | 创建商品 |
| `/api/mall/products/:id` | PUT/DELETE | Bearer+edit/delete | 更新/删除商品 |

### 分类

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/categories/all` | GET | 无 | 所有分类 |
| `/api/mall/categories` | GET | 无 | 顶级分类 |
| `/api/mall/categories` | POST | Bearer+add | 创建分类 |
| `/api/mall/categories/:id` | PUT/DELETE | Bearer+edit/delete | 更新/删除分类 |

### 购物车

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/cart` | GET | Bearer | 购物车列表 |
| `/api/mall/cart` | POST | Bearer | 加入购物车：`productId`, `optionId`(可选), `quantity` |
| `/api/mall/cart/:id` | PUT/DELETE | Bearer | 更新数量/删除 |
| `/api/mall/cart/clear` | POST | Bearer | 清空购物车：`ids`(数组,可选) |
| `/api/mall/cart/checkout` | POST | Bearer | 结算：`cartIds`, `addressId`, `remark`, `userCouponId` |

### 订单

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/orders` | POST | Bearer | 直接下单 |
| `/api/mall/orders` | GET | 无 | 所有订单（管理员） |
| `/api/mall/orders/my` | GET | 无 | 我的订单：`?userId=1&status=&page=1&pageSize=20` |
| `/api/mall/orders/:id` | GET | 无 | 订单详情 |
| `/api/mall/orders/:id/pay` | POST | Bearer | 支付订单 |
| `/api/mall/orders/:id/status` | PUT | Bearer+handle | 更新订单状态 |
| `/api/mall/orders/:id/tracking` | GET | 无 | 物流追踪 |

### 评价

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/reviews` | GET | optional | 商品评价：`?productId=1&page=1&pageSize=20` |
| `/api/mall/reviews/check` | GET | Bearer | 检查是否已评价：`?productId=1` |
| `/api/mall/reviews` | POST | Bearer | 发布评价：`productId`, `rating`, `content`, `images` |
| `/api/mall/reviews/:id` | PUT | Bearer | 更新评价 |
| `/api/mall/reviews/:id/like` | PUT | Bearer | 点赞评价 |
| `/api/mall/reviews/:id/reply` | PUT | 无 | 商家回复 |

### 地址

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/user/addresses` | GET/POST | Bearer | 地址列表/添加 |
| `/api/user/addresses/:id` | PUT/DELETE | Bearer | 更新/删除地址 |
| `/api/user/addresses/:id/default` | PUT | Bearer | 设为默认 |

### 售后

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/after-sales` | GET | 无 | 售后列表 |
| `/api/mall/after-sales` | POST | Bearer | 申请售后：`orderId`, `reason`, `type`, `refundAmount` |
| `/api/mall/after-sales/:id` | PUT | Bearer+handle | 处理售后 |

### 促销

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/promotions` | GET/POST | 无/Bearer+add | 促销列表/创建 |
| `/api/mall/promotions/:id` | PUT/DELETE | Bearer+edit/delete | 更新/删除促销 |

### 收藏

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/mall/favorites/:productId` | POST | Bearer | 收藏/取消 |
| `/api/mall/favorites` | GET | Bearer | 收藏列表 |

---

## 5. 社区帖子 (community-posts.cjs)

### 帖子列表与详情

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/posts` | GET | optional | 帖子列表：`?sectionId=1&sort=latest&page=1&pageSize=20&keyword=&tags=&userId=` |
| `/api/community/post/:id` | GET | optional | 帖子详情（浏览量+1，含评论树） |

**sort 参数可选值**：`latest`, `recent_reply`, `most_likes`, `most_favorites`, `essence`, `hot`, `trending`, `views`, `pinned`

### 帖子 CRUD

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post` | POST | Bearer | 发帖：`sectionId`, `title`, `content`, `device`, `tags`, `images`, `hasResource`, `resourceType`, `resourcePrice`, `resourcePriceType`, `extractCode`, `permission`, `scheduledTime`, `draftId`, `contentPermission`, `contentPrice`, `contentPriceType`, `accessPassword`, `accessPasswordTips`, `topicId`, `topicIds`, `coverImage`, `autoHideAt` |
| `/api/community/post/:id` | PUT | Bearer | 编辑帖子（生成版本记录） |
| `/api/community/post/:id` | DELETE | Bearer | 删除帖子（作者软删除） |
| `/api/community/post/:id/restore` | POST | Bearer | 恢复已删除帖子 |
| `/api/community/post/:id/permanent` | DELETE | Bearer | 永久删除（管理员） |

### 帖子历史版本

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/revisions` | GET | Bearer | 历史版本列表 |
| `/api/community/post/:id/revisions/:revId` | GET | Bearer | 历史版本详情 |
| `/api/community/post/:id/revisions/:revId/restore` | POST | Bearer | 恢复到历史版本 |

### 帖子审核

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/admin/posts/pending` | GET | Bearer | 待审核帖子 |
| `/api/community/admin/post/:id/approve` | POST | Bearer | 审核通过 |
| `/api/community/admin/post/:id/reject` | POST | Bearer | 审核驳回：`reason` |
| `/api/community/admin/posts` | GET | Bearer | 管理员帖子列表 |
| `/api/community/admin/post/:id/status` | PUT | Bearer | 修改帖子状态 |

---

## 6. 社区管理 (community-admin.cjs)

### 禁言管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/admin/ban` | POST | Bearer | 禁言：`userId`, `reason`, `duration`(小时,可选) |
| `/api/community/admin/unban` | POST | Bearer | 解除禁言：`userId` |
| `/api/community/admin/banned` | GET | Bearer | 禁言列表 |
| `/api/community/admin/auto-ban-settings` | GET/POST | Bearer | 自动封禁设置 |

### 用户搜索与统计

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/user/search` | GET | Bearer | 搜索用户：`?keyword=`（>=1 字符） |
| `/api/community/user/:userId/stats` | GET | 无 | 用户统计（帖子/评论/点赞/收藏数） |
| `/api/community/user/:userId/recent-posts` | GET | 无 | 最近 5 篇帖子 |
| `/api/community/user/:userId/recent-comments` | GET | 无 | 最近 5 条评论 |
| `/api/community/user/:userId/trust-level` | GET | 无 | 信用等级 |
| `/api/community/user/:userId/community-profile` | GET | 无 | 社区档案（含徽章/等级/统计） |
| `/api/community/admin/trust-levels/calculate` | POST | Bearer | 重新计算所有用户信用等级 |

### 举报管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/report` | POST | Bearer | 举报帖子 |
| `/api/community/comment/:id/report` | POST | Bearer | 举报评论 |
| `/api/community/admin/reports` | GET | Bearer | 举报列表（管理员/版主） |
| `/api/community/admin/report/ignore/:id` | POST | Bearer | 忽略举报 |
| `/api/community/admin/report/post/:id` | DELETE | Bearer | 下架被举报帖子 |
| `/api/community/admin/report/comment/:id` | DELETE | Bearer+管理员 | 删除被举报评论 |
| `/api/community/report/:id/appeal` | POST | Bearer | 举报人申诉 |
| `/api/community/moderator/appeals` | GET | Bearer+管理员 | 申诉列表 |
| `/api/community/moderator/appeal/:id/handle` | POST | Bearer+管理员 | 处理申诉 |
| `/api/community/report-categories` | GET | 无 | 举报分类 |

### 解锁请求

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/request-unlock` | POST | Bearer | 作者申请解锁 |
| `/api/community/admin/unlock-requests` | GET | Bearer | 解锁请求列表 |
| `/api/community/admin/unlock-request/:id/handle` | POST | Bearer | 处理解锁请求 |

### 标签管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/tags` | GET | 无 | 标签列表：`?keyword=&sort=post_count&section_id=1&limit=50` |
| `/api/community/tags` | POST | Bearer+管理员 | 创建/更新标签 |
| `/api/community/tags/:id` | DELETE | Bearer+管理员 | 删除标签 |
| `/api/community/tags/merge` | POST | Bearer+管理员 | 合并标签：`sourceId`, `targetId` |
| `/api/community/tags/sync` | POST | Bearer+管理员 | 同步标签计数 |
| `/api/community/tags/cloud` | GET | 无 | 标签云 |
| `/api/community/tags/hot` | GET | 无 | 热门标签 |

### 敏感词

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/sensitive-words` | GET/POST/DELETE(:id) | 无/Bearer | 敏感词列表管理 |

### 分析统计

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/analytics/overview` | GET | 无 | 社区概况 |
| `/api/community/analytics/trends` | GET | 无 | 趋势数据：`?period=week` |
| `/api/community/analytics/sections` | GET | 无 | 板块统计 |
| `/api/community/analytics/collections` | GET | 无 | 合集统计 |
| `/api/community/analytics/user-ranking` | GET | 无 | 用户排名：`?type=posts` |
| `/api/community/analytics/quality-scores` | GET | 无 | 质量评分 |

### 排行榜

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/rankings/essence` | GET | 无 | 精华排行 |
| `/api/community/rankings/donations` | GET | 无 | 捐赠排行 |
| `/api/community/rankings/sections-active` | GET | 无 | 活跃板块排行 |
| `/api/community/rankings/daily` | GET | 无 | 每日排行 |

### 图片管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/admin/images` | GET | Bearer | 社区图片管理 |
| `/api/community/admin/images/batch-delete` | POST | Bearer | 批量删除图片 |
| `/api/community/admin/image-stats` | GET | Bearer | 图片统计 |

### 导出

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/admin/export/posts` | GET | Bearer | 导出帖子 |
| `/api/community/admin/export/reports` | GET | Bearer | 导出举报 |
| `/api/community/admin/export/users` | GET | Bearer | 导出用户 |

---

## 7. 版主中心 (community-moderator.cjs)

### 统计

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/moderator/stats` | GET | Bearer | 版主统计（待审核帖子/评论/今日操作） |
| `/api/community/moderator/enhanced-stats` | GET | Bearer | 增强统计 |

### 日志与分区

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/moderator/logs` | GET | Bearer | 操作日志：`?page=1&pageSize=20` |
| `/api/community/moderator/my-sections` | GET | Bearer | 我的版块列表 |

### 批量操作

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/moderator/posts/batch-approve` | POST | Bearer | 批量通过：`ids`(数组) |
| `/api/community/moderator/posts/batch-reject` | POST | Bearer | 批量驳回：`ids`, `reason` |
| `/api/community/moderator/posts/batch-delete` | POST | Bearer | 批量删除 |
| `/api/community/moderator/posts/batch-move` | POST | Bearer | 批量移动：`ids`, `targetSectionId` |
| `/api/community/moderator/posts/batch-essence` | POST | Bearer | 批量设精 |
| `/api/community/moderator/posts/batch-pin` | POST | Bearer | 批量置顶 |
| `/api/community/moderator/posts/batch-lock` | POST | Bearer | 批量锁定 |
| `/api/community/moderator/comments/batch-delete` | POST | Bearer | 批量删除评论 |

### 单操作

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/moderator/comment/:id` | DELETE | Bearer | 删除评论 |
| `/api/community/moderator/post/:id/move` | POST | Bearer | 移动帖子 |
| `/api/community/moderator/post/:id/edit` | POST | Bearer | 版主编辑帖子 |
| `/api/community/moderator/resign/:sectionId` | POST | Bearer | 辞去版主 |
| `/api/community/moderator/section/:id/update-info` | POST | Bearer | 更新版块信息 |

### 封禁管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/moderator/section/:sectionId/ban` | POST | Bearer | 版块内封禁：`userId`, `reason`, `duration`(小时) |
| `/api/community/moderator/section/:sectionId/ban/:bannedUserId` | DELETE | Bearer | 解除封禁 |
| `/api/community/moderator/section/:sectionId/bans` | GET | Bearer | 封禁列表 |

---

## 8. 社区板块管理 (community-sections.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/sections` | GET | 无 | 板块列表 |
| `/api/community/section/:id` | GET | 无 | 板块详情 |
| `/api/community/section/:id/info` | GET | 无 | 板块基本信息 |
| `/api/community/section` | POST | Bearer+管理员 | 创建板块：`name`, `description`, `icon`, `iconBgColor`, `sortOrder`, `visibility`, `postPermission`, `reviewRequired` |
| `/api/community/section/:id` | DELETE | Bearer+管理员 | 删除板块 |
| `/api/community/section/:id/moderators` | GET | 无 | 版主列表 |
| `/api/community/section/:id/moderator` | POST | Bearer | 添加/更新版主：`userId`, `role` |
| `/api/community/section/:id/moderator/:userId` | DELETE | Bearer | 移除版主 |
| `/api/community/user/:userId/moderator-sections` | GET | 无 | 用户管理的版块 |
| `/api/community/section/:id/apply` | POST | Bearer | 申请版主：`reason`, `experience` |
| `/api/community/section/:id/applications` | GET | Bearer | 申请列表 |
| `/api/community/section/:id/my-application` | GET | Bearer | 我的申请状态 |
| `/api/community/applications` | GET | Bearer | 所有申请列表 |
| `/api/community/application/:id/approve` | POST | Bearer | 通过申请：`role` |
| `/api/community/application/:id/reject` | POST | Bearer | 拒绝申请：`reason` |

---

## 9. 社区互动 (community-interactions.cjs)

### 点赞/收藏/投币

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/like` | POST | Bearer | 点赞/取消帖子 |
| `/api/community/comment/:id/like` | POST | Bearer | 点赞/取消评论 |
| `/api/community/post/:id/favorite` | POST | Bearer | 收藏/取消帖子 |
| `/api/community/user/favorites` | GET | Bearer | 收藏列表：`?page=1&pageSize=20&type=` |
| `/api/community/post/:id/coin` | POST | Bearer | 投币打赏：`amount` |
| `/api/community/post/:id/coin-logs` | GET | 无 | 投币记录 |

### 置顶/精华/热门/锁定

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/pin` | POST | Bearer+版主/管理员 | 板块内置顶 |
| `/api/community/post/:id/global-pin` | POST | Bearer+管理员 | 全局置顶 |
| `/api/community/post/:id/custom-badge` | POST | Bearer+管理员 | 自定义徽章 |
| `/api/community/post/:id/essence` | POST | Bearer+版主/管理员 | 设精/取消 |
| `/api/community/post/:id/hot` | POST | Bearer+版主/管理员 | 设为热门 |
| `/api/community/post/:id/lock` | POST | Bearer+版主/管理员 | 锁定/解锁 |

### 评论

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/comments` | GET | 无 | 评论列表：`?page=1&pageSize=20&sort=` |
| `/api/community/post/:id/comment` | POST | Bearer | 发布评论：`content`, `parentId`(回复时), `images` |
| `/api/community/comment/:id` | DELETE | Bearer | 删除评论（作者或管理员） |
| `/api/community/comment/:id/pin` | POST | Bearer+版主/管理员 | 置顶评论 |
| `/api/community/moderator/comments/pending` | GET | Bearer | 待审核评论 |
| `/api/community/moderator/comment/:id/approve` | POST | Bearer | 审核通过 |
| `/api/community/moderator/comment/:id/reject` | POST | Bearer | 审核驳回 |
| `/api/community/moderator/comments/batch-approve` | POST | Bearer | 批量通过 |
| `/api/community/moderator/comments/batch-reject` | POST | Bearer | 批量驳回 |

### 附件与资源

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/attach/purchase` | POST | Bearer | 购买附件/资源 |
| `/api/community/attach/purchased` | GET | Bearer | 已购附件列表 |

### 投票

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/post/:id/vote` | POST | Bearer | 创建投票 |
| `/api/community/vote/:voteId/cast` | POST | Bearer | 投票：`optionIndex` |
| `/api/community/post/:id/votes` | GET | 无 | 获取投票数据 |
| `/api/community/vote/:voteId/close` | POST | Bearer | 关闭投票 |

### 草稿

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/drafts` | GET | Bearer | 草稿列表 |
| `/api/community/draft` | POST | Bearer | 保存草稿 |
| `/api/community/draft/:id` | DELETE | Bearer | 删除草稿 |

---

## 10. 聊天室与私信 (chat-room.cjs)

### 聊天室

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/chat-rooms` | GET | optional | 聊天室列表：`?page=1&pageSize=20&keyword=&category=&sort=` |
| `/api/chat-rooms/my` | GET | Bearer | 我加入的聊天室 |
| `/api/chat-rooms/can-create` | GET | Bearer | 是否有创建权限 |
| `/api/chat-rooms/:roomId` | GET | optional | 聊天室详情 |
| `/api/chat-rooms` | POST | Bearer | 创建聊天室：`name`, `description`, `avatar`, `maxMembers`, `isPrivate`, `password` |
| `/api/chat-rooms/:roomId` | PUT/DELETE | Bearer | 更新/删除（群主/管理员） |
| `/api/chat-rooms/:roomId/join` | POST | Bearer | 加入：`password`(私密房间) |
| `/api/chat-rooms/:roomId/leave` | POST | Bearer | 退出 |
| `/api/chat-rooms/:roomId/invite` | POST | Bearer | 邀请用户：`userIds`(数组) |
| `/api/chat-rooms/:roomId/dissolve` | DELETE | Bearer | 解散（群主） |
| `/api/chat-rooms/:roomId/avatar` | POST | Bearer | 上传头像 |

### 成员管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/chat-rooms/:roomId/members` | GET | optional | 成员列表 |
| `/api/chat-rooms/:roomId/mute/:userId` | PUT | Bearer | 禁言：`duration`(分钟) |
| `/api/chat-rooms/:roomId/unmute/:userId` | PUT | Bearer | 解除禁言 |
| `/api/chat-rooms/:roomId/kick/:userId` | POST | Bearer | 踢出 |
| `/api/chat-rooms/:roomId/ban/:userId` | POST/DELETE | Bearer | 拉黑/解除拉黑 |
| `/api/chat-rooms/:roomId/set-admin/:userId` | PUT | Bearer | 设为管理员（群主） |
| `/api/chat-rooms/:roomId/transfer/:userId` | POST | Bearer | 转让群主 |

### 消息

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/chat-rooms/:roomId/messages` | GET | optional | 消息列表：`?page=1&pageSize=20&beforeId=` |
| `/api/chat-rooms/:roomId/messages` | POST | Bearer | 发送消息：`content`, `type`(text/image/file), `replyTo` |
| `/api/chat-rooms/:roomId/messages/:msgId/recall` | PUT | Bearer | 撤回消息 |
| `/api/chat-rooms/:roomId/messages/:msgId/report` | POST | Bearer | 举报消息 |
| `/api/chat-rooms/:roomId/messages/search` | GET | Bearer | 搜索消息：`?keyword=&userId=&startDate=&endDate=` |

### 私信

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/messages/conversations` | GET | Bearer | 私信会话列表 |
| `/api/messages/:targetUserId` | GET/POST | Bearer | 获取/发送私信 |
| `/api/messages/:id/recall` | PUT | Bearer | 撤回消息 |
| `/api/messages/:id/report` | POST | Bearer | 举报私信 |
| `/api/messages/search` | GET | Bearer | 搜索私信 |
| `/api/messages/upload-image` | POST | Bearer | 上传私信图片 |
| `/api/messages/conversations/:partnerId` | DELETE | Bearer | 删除对话 |
| `/api/messages/orders` | GET | Bearer | 订单消息 |

### 其他

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/chat-rooms/:roomId/pins` | GET/POST | optional/Bearer | 置顶消息管理 |
| `/api/chat-rooms/:roomId/pins/:messageId` | DELETE | Bearer | 取消置顶 |
| `/api/chat-rooms/:roomId/files` | GET/POST/DELETE(:fileId) | Bearer | 群文件管理 |
| `/api/chat-rooms/:roomId/gifts` | GET | 无 | 礼物列表 |
| `/api/chat-rooms/:roomId/gift/send` | POST | Bearer | 送礼物 |
| `/api/chat-rooms/:roomId/stats` | GET | 无 | 聊天室统计 |
| `/api/chat-rooms/:roomId/admin-logs` | GET | Bearer | 管理日志 |
| `/api/chat-rooms/limit-upgrades` | GET | Bearer | 扩容申请列表 |
| `/api/chat-rooms/limit-upgrades/:upgradeId` | PUT | Bearer | 处理扩容申请 |
| `/api/chat-rooms/:roomId/limit-upgrade` | POST | Bearer | 申请扩容 |

---

## 11. 合集与收藏 (collection.cjs)

### 合集 CRUD

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/collection` | POST | Bearer | 创建合集：`title`, `description`, `cover`, `status`, `price`, `priceType`, `sections` |
| `/api/community/collection/:id` | GET/PUT/DELETE | optional/Bearer/Bearer | 详情/更新/删除 |
| `/api/community/collection/mine` | GET | Bearer | 我的合集 |
| `/api/community/collection/user/:userId` | GET | 无 | 用户的合集 |
| `/api/community/collection/paid` | GET | Bearer | 已购合集 |
| `/api/community/collections/featured` | GET | 无 | 精选合集 |

### 合集内容管理

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/collection/:id/posts` | POST | Bearer | 添加帖子：`postIds`(数组) |
| `/api/community/collection/:id/posts` | DELETE | Bearer | 移除帖子：`postIds`(数组) |
| `/api/community/collection/:id/posts/sort` | PUT | Bearer | 排序：`postIds`(数组) |
| `/api/community/collection/:id/posts/batch-sort` | PUT | Bearer | 批量调整章节和帖子排序 |
| `/api/community/collection/:id/posts/:postId/preview` | PUT | Bearer | 设置预览长度 |

### 购买与阅读进度

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/collection/:id/buy` | POST | Bearer | 购买合集 |
| `/api/community/collection/:id/check-paid` | GET | Bearer | 是否已购买 |
| `/api/community/collection/:id/progress` | GET/POST | Bearer | 阅读进度 |
| `/api/community/collection/:id/post/:postId` | GET | 无 | 合集内单帖详情 |

### 评论与评分

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/collection/:id/comment` | POST | Bearer | 合集评论 |
| `/api/community/collection/:id/comments` | GET | 无 | 评论列表 |
| `/api/community/collection/:id/rate` | POST | Bearer | 评分：`rating`(1-5) |
| `/api/community/collection/:id/rating` | GET | 无 | 评分统计 |

### 分享

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/collection/:id/share` | POST | Bearer | 分享（记录） |
| `/api/community/collection/:id/share-stats` | GET | 无 | 分享统计 |

### 收藏夹

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/community/favorite/groups` | GET/POST | Bearer | 收藏夹列表/创建 |
| `/api/community/favorite/groups/:id` | PUT/DELETE | Bearer | 更新/删除 |
| `/api/community/favorite/groups/reorder` | POST | Bearer | 排序收藏夹 |
| `/api/community/favorite/groups/:id/visibility` | PUT | Bearer | 修改可见性 |
| `/api/community/favorite/groups/:id/follow` | POST/DELETE | Bearer | 关注/取消关注 |
| `/api/community/favorite/groups/following` | GET | Bearer | 关注的收藏夹 |
| `/api/community/favorite/groups/user/:uid` | GET | 无 | 用户收藏夹 |
| `/api/community/favorite/move` | POST | Bearer | 移动收藏 |
| `/api/community/favorite/items` | GET | Bearer | 收藏列表 |
| `/api/community/favorite/items/user/:uid` | GET | 无 | 用户公开收藏 |
| `/api/community/favorite/collections` | GET | Bearer | 收藏夹内容 |

---

## 12. 通知 (notification.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/notifications` | GET | optional | 通知列表：`?page=1&pageSize=20&type=` |
| `/api/notifications/read-all` | POST | Bearer | 全部已读 |
| `/api/notifications/:id/read` | POST | Bearer | 标记单条已读 |
| `/api/notifications/types` | GET | 无 | 通知类型列表 |
| `/api/notifications/push/register` | POST | Bearer | 注册推送设备：`deviceToken`, `platform` |
| `/api/user/notification-settings` | GET/PUT | Bearer | 通知设置 |
| `/api/admin/chat-reports` | GET | 无 | 聊天举报管理 |
| `/api/admin/chat-reports/:id` | PUT | 无 | 处理聊天举报 |

---

## 13. 文件上传 (upload.cjs)

| 端点 | 方法 | 认证 | Content-Type | 说明 |
|------|------|------|-------------|------|
| `/api/upload/avatar` | POST | 无 | multipart | 上传头像 |
| `/api/upload/background` | POST | 无 | multipart | 上传背景图 |
| `/api/upload/experience-icon` | POST | 无 | multipart | 上传经验等级图标 |
| `/api/upload/membership-icon` | POST | 无 | multipart | 上传会员等级图标 |
| `/api/upload/apk` | POST | 无 | multipart | 上传 APK |
| `/api/upload/file` | POST | Bearer | multipart | 通用文件上传 |
| `/api/upload/batch-temp` | POST | Bearer | multipart | 批量临时上传（最多 20） |
| `/api/upload/batch-commit` | POST | Bearer | JSON | 批量提交：`{ tempIds: [], refType, refId }` |
| `/api/upload/delete-uploaded` | POST | Bearer | JSON | 删除上传文件：`{ urls: [] }` |
| `/api/upload/parse-download-url` | POST | 无 | JSON | 解析下载链接 |
| `/api/upload/quota` | GET | Bearer | 无 | 存储配额 |
| `/api/upload/storage-quota` | GET | Bearer | 无 | Quota 计算 |

---

## 14. 邮件与短信 (email.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/email/config` | GET | Bearer | SMTP 配置详情 |
| `/api/email/config` | POST | Bearer+edit | 保存 SMTP 配置 |
| `/api/email/configs` | GET | 无 | 邮件配置清单 |
| `/api/email/templates` | GET | 无 | 邮件模板列表 |
| `/api/email/test` | POST | Bearer+test | 发送测试邮件：`{ email }` |
| `/api/email/test-notify` | POST | 无 | 测试通知邮件 |
| `/api/email/test-notify-all` | POST | 无 | 测试所有管理员通知 |
| `/api/email/send-code` | POST | 无 | 发送邮箱验证码：`{ email, type }` |
| `/api/email/verify-code` | POST | 无 | 验证邮箱验证码：`{ email, code, type }` |
| `/api/auth/reset-password` | POST | 无 | 通过邮箱重置密码：`{ email, code, password }` |
| `/api/sms/send-code` | POST | 无 | 发送短信验证码：`{ phone, type }` |
| `/api/sms/verify-code` | POST | 无 | 验证短信验证码：`{ phone, code, type }` |

---

## 15. 搜索 (search.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/search` | GET | 无 | 全局搜索：`?q=关键词&type=all,post,app,product&page=1&pageSize=20` |

---

## 16. 运营管理 (operation.cjs)

### 签到

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/checkin` | POST | Bearer | 签到 |
| `/api/checkin/status` | GET | Bearer | 签到状态 |
| `/api/checkin/history` | GET | Bearer | 签到历史 |
| `/api/checkin/makeup` | POST | Bearer | 补签 |
| `/api/checkin/ranking` | GET | Bearer | 签到排行 |

### 会员

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/membership/levels` | GET | 无 | 会员等级列表 |
| `/api/membership/products` | GET | 无 | 会员商品 |
| `/api/membership/buy` | POST | Bearer | 购买会员 |
| `/api/operation/membership-level/list` | GET | 无 | 会员等级（管理） |
| `/api/operation/membership-level/save` | POST | 无 | 创建/更新等级 |
| `/api/operation/membership-level/:id` | DELETE | 无 | 删除等级 |
| `/api/operation/member/list` | GET | 无 | 会员管理列表 |
| `/api/operation/member/update-level` | POST | 无 | 手动设置会员等级 |

### 积分与经验

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/operation/points-record/list` | GET | 无 | 积分记录列表 |
| `/api/operation/points-record/adjust` | POST | 无 | 手动调整积分 |
| `/api/operation/experience-level/list` | GET | 无 | 经验等级列表 |
| `/api/operation/experience-level/save` | POST | 无 | 创建/更新经验等级 |
| `/api/operation/experience-level/:id` | DELETE | 无 | 删除经验等级 |

### 卡密

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/operation/cardkey/list` | GET | 无 | 卡密列表 |
| `/api/operation/cardkey/create` | POST | 无 | 生成卡密 |
| `/api/operation/cardkey/:id` | DELETE | 无 | 删除卡密 |
| `/api/operation/cardkey/import` | POST | 无 | 导入卡密 |
| `/api/cardkey/redeem` | POST | 无 | 兑换卡密 |

### 佣金

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/commission/rules` | GET | Bearer | 佣金规则 |
| `/api/commission/rule/save` | POST | Bearer | 保存规则 |
| `/api/commission/records` | GET | Bearer | 佣金记录 |
| `/api/commission/referral` | GET | Bearer | 推荐信息 |
| `/api/commission/withdraw` | POST | Bearer | 提现申请 |

### 转账

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/transfer/points` | POST | Bearer | 积分转账 |
| `/api/transfer/balance` | POST | Bearer | 余额转账 |
| `/api/transfer/records` | GET | Bearer | 转账记录 |
| `/api/transfer/config` | GET | Bearer | 转账配置 |

### 优惠券

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/coupon/list` | GET | 无 | 优惠券列表 |
| `/api/coupon/:id` | GET | 无 | 优惠券详情 |
| `/api/coupon/claim/:id` | POST | Bearer | 领取优惠券 |
| `/api/coupon/my` | GET | Bearer | 我的优惠券 |
| `/api/coupon/available` | GET | Bearer | 可用优惠券 |
| `/api/coupon/usable` | GET | Bearer | 当前可用 |

### 任务系统

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/custom-task/list` | GET | Bearer | 任务列表 |
| `/api/custom-task/my` | GET | Bearer | 我的任务进度 |
| `/api/custom-task/do` | POST | Bearer | 执行任务 |
| `/api/custom-task/save` | POST | Bearer | 创建/更新任务 |

---

## 17. 双因素认证 (two-factor.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/two-factor/status/:userId` | GET | 无 | 查询 2FA 状态 |
| `/api/two-factor/my-status` | GET | Bearer | 我的 2FA 状态 |
| `/api/two-factor/setup` | POST | Bearer | 生成密钥和二维码：`password` |
| `/api/two-factor/enable` | POST | Bearer | 验证并启用：`code`, `secret` |
| `/api/two-factor/disable` | POST | Bearer | 禁用：`password`, `code` |
| `/api/two-factor/verify` | POST | 无 | 验证 TOTP：`userId`, `code` |

---

## 18. 结算 (settlement.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/settlement/create-order` | POST | Bearer | 创建结算订单 |
| `/api/settlement/confirm` | POST | Bearer | 确认结算 |
| `/api/settlement/request-refund` | POST | Bearer | 申请退款：`orderId`, `reason` |
| `/api/settlement/respond-refund` | POST | Bearer | 处理退款：`refundId`, `action`(accept/reject) |
| `/api/settlement/report-to-admin` | POST | Bearer | 向管理员举报 |
| `/api/settlement/admin-reports` | GET | Bearer | 举报列表 |
| `/api/settlement/admin-refund` | POST | Bearer | 管理员退款 |
| `/api/settlement/orders` | GET | Bearer | 订单列表 |
| `/api/settlement/pending-stats` | GET | Bearer | 待处理统计 |
| `/api/settlement/config` | GET/POST | 无 | 配置管理 |
| `/api/settlement/config/:id` | PUT/DELETE | 无 | 更新/删除配置 |
| `/api/settlement/user-config` | GET | Bearer | 用户结算配置 |
| `/api/settlement/validate-transfer` | POST | Bearer | 验证转账 |

---

## 19. 插件系统 (plugins.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/plugins/list` | GET | 无 | 插件列表 |
| `/api/plugins/upload` | POST | Bearer+upload | 上传插件包（zip） |
| `/api/plugins/:id/toggle` | PUT | Bearer+toggle | 启用/禁用 |
| `/api/plugins/:id` | DELETE | Bearer+delete | 卸载插件 |
| `/api/plugins/:id/upgrade` | POST | Bearer | 升级插件 |
| `/api/plugins/:name/config` | PUT | Bearer+config | 更新插件配置 |
| `/api/plugins/inject` | GET | 无 | 获取前端注入代码 |
| `/api/plugins/:id/detail` | GET | Bearer | 插件详情 |
| `/api/plugins/extensions/state` | GET | Bearer | 扩展状态 |

---

## 20. 推荐系统 (recommend.cjs)

| 端点 | 方法 | 认证 | 说明 |
|------|------|------|------|
| `/api/appstore/recommend` | GET | optional | 应用个性化推荐 |
| `/api/recommend/for-you` | GET | optional | 为你推荐 |
| `/api/recommend/hot-tags` | GET | 无 | 热门标签 |

---

## 认证中间件参考

| 中间件 | 来源 | 说明 |
|--------|------|------|
| `authRequired` | system.cjs | 强制 Bearer Token 认证 |
| `optionalAuth` | system.cjs | 可选认证（有 token 时设 req.user） |
| `requirePermission(authMark)` | system.cjs | 权限检查（R_SUPER 直接通过） |
| `adminRequired` | user.cjs | 管理员认证（R_SUPER 或 R_ADMIN） |
| `getUserId` | community-utils.cjs | 从 token 获取 userId |
| `isAdmin` / `isAdminById` | community-utils.cjs | 社区管理员检查 |
| `canManageModAction` | community-utils.cjs | 版主操作权限 |
| `isModeratorOfSection` | community-utils.cjs | 板块版主检查 |
