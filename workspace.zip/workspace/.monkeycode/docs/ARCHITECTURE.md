# 系统架构文档 — Art Design Pro

## 概述

Art Design Pro 是一个面向设计/创意社区的综合性 Web 平台，提供应用商店、社区论坛、商城、聊天室、积分系统、版主审核等功能。系统采用前后端分离架构，前端基于 Vue 3 + TypeScript + Vite，后端基于 Node.js + Express + MariaDB（MySQL），支持移动端和 PC 端双主题。

核心能力：
- 多角色用户体系（普通用户 / 版主 / 审核员 / 管理员 / 超级管理员）
- 社区帖子发布与管理（富文本编辑器 / 投票 / 付费墙 / 资源附件）
- 版主审核中心（帖子审核 / 举报处理 / 禁言管理）
- 应用商店与商城（应用发布 / 商品购买 / 购物车 / 订单）
- 实时聊天室与私信（WebSocket + HTTP 轮询）
- 积分与等级系统（发帖 / 评论 / 打赏 / 每日签到）
- 第三方 OAuth 登录（GitHub / Google / 微信等）
- 两因素认证（2FA / TOTP）
- 定时任务调度（计划发帖 / 订单自动确认 / 会话清理）

## 技术栈

**前端**
- Vue 3.5（Composition API + `<script setup>`）
- TypeScript
- Vite 7（开发构建）
- Vue Router（Hash 模式路由）
- Pinia（状态管理）
- TipTap（富文本编辑器，基于 ProseMirror）
- ECharts（数据可视化图表）
- Element Plus（PC 端 UI 组件库）
- Axios（HTTP 客户端）
- WebSocket（实时通信）

**后端**
- Node.js 22
- Express
- MariaDB / MySQL（mysql2 连接池）
- bcryptjs（密码哈希）
- speakeasy（TOTP 两因素认证）
- nodemailer（邮件发送）
- multer（文件上传）
- node-cron / setInterval（定时任务）

**部署与环境**
- 前端端口：3333（Vite dev server，含 API 反向代理）
- 后端端口：3001（Express API server）
- 数据库：MariaDB，库名 `art_design_pro`，用户 `artpro`
- 文件存储：本地磁盘上传目录 `server/uploads/`

## 项目结构

```
workspace/                          # 工作区根目录
├── server/                         # 后端 Express 服务
│   ├── index.cjs                   # 入口文件：Express app 初始化、中间件、路由注册
│   ├── config.cjs                  # 配置加载（.env + 全局配置）
│   ├── database.cjs                # 数据库连接池 + 建表 DDL（2189 行）
│   ├── seed.cjs                    # 种子数据初始化
│   ├── scheduler.cjs               # 定时任务调度器
│   ├── middleware/                  # 中间件
│   │   ├── auth.cjs                # 认证中间件
│   │   ├── rate-limit.cjs          # 速率限制
│   │   ├── error-handler.cjs       # 错误处理
│   │   └── security.cjs            # XSS 防护、请求日志
│   ├── routes/                     # API 路由（按业务模块拆分）
│   │   ├── system.cjs              # 系统配置、OAuth、角色权限、统计
│   │   ├── auth.cjs                # 登录/注册/注销
│   │   ├── user.cjs                # 用户资料、申诉、封禁
│   │   ├── appstore.cjs            # 应用商店（1956 行）
│   │   ├── mall.cjs                # 商城（1659 行）
│   │   ├── community/              # 社区模块（拆分为多子文件）
│   │   │   ├── community.cjs       # 路由注册入口（67 行）
│   │   │   ├── community-posts.cjs     # 帖子 CRUD（1122 行）
│   │   │   ├── community-admin.cjs     # 管理员功能（1453 行）
│   │   │   ├── community-moderator.cjs # 版主中心（498 行）
│   │   │   ├── community-sections.cjs  # 板块管理
│   │   │   ├── community-interactions.cjs # 互动（赞/收藏/打赏）
│   │   │   └── community-utils.cjs     # 共享工具函数
│   │   ├── chat-room.cjs           # 聊天室（1498 行）
│   │   ├── collection.cjs          # 合集管理（1370 行）
│   │   ├── notification.cjs        # 通知系统
│   │   ├── upload.cjs              # 文件上传
│   │   ├── email.cjs               # 邮件发送
│   │   ├── search.cjs              # 搜索
│   │   ├── operation.cjs           # 运营管理（签到/任务/抽奖）
│   │   ├── two-factor.cjs          # 2FA 认证
│   │   ├── settlement.cjs          # 结算/订单自动确认
│   │   ├── plugins.cjs             # 插件系统
│   │   └── recommend.cjs           # 推荐系统
│   ├── plugins/                    # 内置插件
│   │   ├── event-bus.cjs           # 事件总线
│   │   ├── scheduler.cjs           # 调度器
│   │   └── feature-panel/          # 功能面板
│   ├── middleware/                  # 中间件（auth/rate-limit/error-handler/security）
│   └── utils/                      # 工具（ip-geo 等）
│
├── src/                            # 前端源代码
│   ├── main.ts                     # 应用入口
│   ├── App.vue                     # 根组件
│   ├── router/                     # 路由配置
│   │   ├── index.ts                # 路由创建
│   │   ├── routes/                 # 路由定义
│   │   │   └── staticRoutes.ts     # 静态路由表（1141 行）
│   │   └── guards/                 # 路由守卫
│   │       └── beforeEach.ts       # 全局前置守卫（认证检查）
│   ├── store/                      # Pinia 状态管理
│   │   └── modules/                # 各模块 store
│   │       ├── user.ts             # 用户状态
│   │       ├── app.ts              # 应用全局状态
│   │       └── worktab.ts          # 工作台标签页
│   ├── themes/                     # 主题（移动端 + PC 端）
│   │   ├── mobile/default/views/appstore/
│   │   │   ├── browse/             # 浏览/首页（index, detail, profile, mine 等）
│   │   │   ├── community/          # 社区（post-detail, post-edit, forum, sections 等）
│   │   │   ├── mall/               # 商城
│   │   │   ├── submissions/        # 投稿
│   │   │   ├── admin/              # 管理后台
│   │   │   └── community/          # 社区组件
│   │   └── pc/default/views/appstore/
│   │       ├── community/          # PC 端社区
│   │       └── ...
│   ├── components/                 # 共享组件
│   │   ├── editor/                 # TipTap 富文本编辑器（1029 行）
│   │   │   └── extensions/         # 27 个编辑器扩展
│   │   ├── core/                   # 核心 UI 组件（表单/图表/表格）
│   │   ├── community/              # 社区共享组件
│   │   └── ErrorState.vue          # 统一错误状态组件
│   ├── utils/                      # 工具函数
│   │   ├── http/                   # HTTP 客户端（index.ts + cache.ts）
│   │   ├── socket/                 # WebSocket 客户端
│   │   ├── storage/                # 本地存储
│   │   ├── ui/                     # UI 工具（colors, sanitize, loading）
│   │   └── sys/                    # 系统工具（升级/错误处理）
│   ├── hooks/                      # 组合式函数
│   ├── api/                        # API 封装层
│   ├── directives/                 # Vue 指令
│   ├── locales/                    # 国际化
│   └── styles/                     # 全局样式
│
├── index.html                      # HTML 入口
├── vite.config.ts                  # Vite 构建配置（含 API 代理）
├── package.json                    # 依赖与脚本
├── tsconfig.json                   # TypeScript 配置
└── server/.env                     # 后端环境变量
```

## 子系统架构

```mermaid
flowchart TB
    subgraph Client["客户端"]
        Mobile["移动端 SPA<br/>Vue 3 + Vant"]
        PC["PC 端 SPA<br/>Vue 3 + Element Plus"]
    end

    subgraph Frontend["前端 (Vite :3333)"]
        Router["Vue Router<br/>Hash 模式"]
        Stores["Pinia Stores<br/>user / app / worktab"]
        HTTP["Axios HTTP 客户端<br/>请求去重 / 缓存 / 重试"]
        WS["WebSocket 客户端<br/>实时消息 / 心跳"]
        Editor["TipTap 编辑器<br/>27 个扩展"]
    end

    subgraph Backend["后端 (Express :3001)"]
        Middleware["中间件层<br/>CORS / auth / rate-limit / XSS"]
        Routes["路由层<br/>system / user / community / mall / appstore"]
        Scheduler["调度器<br/>node-cron / setInterval"]
        EventBus["事件总线<br/>插件系统"]
    end

    subgraph Data["数据层"]
        DB["MariaDB<br/>art_design_pro"]
        FS["文件存储<br/>server/uploads/"]
    end

    Mobile --> Router
    PC --> Router
    Router --> Stores
    HTTP --> Middleware
    WS --> Backend
    Middleware --> Routes
    Routes --> DB
    Routes --> FS
    Scheduler --> DB
```

## 认证与授权流程

```mermaid
sequenceDiagram
    participant User as 用户浏览器
    participant FE as 前端
    participant BE as Express 服务端
    participant DB as MariaDB

    User->>FE: 输入用户名+密码
    FE->>BE: POST /api/auth/login
    BE->>DB: SELECT users WHERE username=?
    DB-->>BE: 用户记录（含 bcrypt 密码哈希）
    BE->>BE: bcrypt.compare(password, hash)
    BE->>DB: INSERT INTO sessions (token, user_id, roles, created_at)
    BE-->>FE: { code: 200, token, userInfo }
    FE->>FE: 存储 token + userInfo 到 Pinia/localStorage

    Note over FE,BE: 后续每次请求...

    FE->>BE: GET /api/xxx (Authorization: Bearer <token>)
    BE->>BE: getUserId(req) 从 token 获取 userId
    BE->>BE: isAdmin(req) / isAdminById(userId) 检查角色
    BE-->>FE: 数据或 401/403
```

**角色层级**：
| 角色 | 权限 |
|------|------|
| R_SUPER | 超级管理员，所有权限 |
| R_ADMIN | 管理员，管理后台 |
| 版主（管理员级） | 审核帖子 / 处理举报 / 禁言 / 编辑帖子 |
| 版主（审核员级） | 仅审核帖子 |
| 普通用户 | 发帖 / 评论 / 收藏 / 打赏 |

**关键鉴权函数位置**：
- `server/routes/community/community-utils.cjs` — `getUserId(req)`, `isAdmin(req)`, `isAdminById(userId)`, `getModeratorSectionIds(userId)`, `isModeratorOfSection(userId, sectionId)`
- `server/middleware/auth.cjs` — `authRequired`, `adminRequired` 中间件

## 数据流：社区发帖完整流程

```mermaid
sequenceDiagram
    participant User as 用户
    participant Editor as TipTap 编辑器
    participant FE as 前端组件
    participant Upload as 上传接口
    participant API as /api/community/post
    participant Mod as 版主审核
    participant DB as MariaDB

    User->>Editor: 编辑内容（文字/图片/投票/付费）
    Editor->>FE: 提交表单
    FE->>Upload: 上传图片（如需要）
    Upload-->>FE: 图片 URL
    FE->>API: POST /api/community/post (body: 标题+内容+板块)
    API->>API: checkSensitiveWords(content)
    API->>DB: INSERT community_posts (status='pending' 或 'published')
    API-->>FE: { code: 200, postId }

    Note over Mod: 如板块开启审核...

    Mod->>DB: SELECT pending posts
    Mod->>API: POST /api/community/admin/post/:id/approve
    API->>DB: UPDATE status='published'
    API->>API: incrementPostCount + 通知作者
```

## 子系统详解

### 社区子系统 (`server/routes/community/`)
- **目的**：社区核心——帖子/评论的 CRUD、审核、管理
- **位置**：`server/routes/community/`
- **关键文件**：`community-posts.cjs`(1122行)、`community-admin.cjs`(1453行)、`community-moderator.cjs`(498行)、`community-utils.cjs`(447行)
- **前端对应**：`src/themes/{mobile,pc}/default/views/appstore/community/`

### 版主审核子系统
- **目的**：版主查看待审核帖子、处理举报、管理禁言
- **位置**：`community-moderator.cjs` + 前端 `moderator-center.vue`
- **流程**：获取版主所属板块 → 列出待审核内容 → 通过/驳回 → 记录日志

### 定时任务调度器 (`server/scheduler.cjs`)
```
任务列表：
├── 计划发帖发布器         每 60 秒 (community.cjs:17)
├── 结算订单自动确认       每 60 秒 (settlement.cjs:645)
├── 会话清理               每 5 分钟 (system.cjs:14)
├── 2FA 临时会话清理       每 5 分钟 (two-factor.cjs:41)
├── 速率限制缓存清理       每 5 分钟 (rate-limit.cjs:11)
├── IP 地理位置缓存清理    每 10 分钟 (ip-geo.cjs:264)
└── 调度器降级定时器       每 60 秒 (scheduler.cjs:44)
```

### 事件总线 (`server/plugins/event-bus.cjs`)
- 用于插件系统的事件发布/订阅
- 社区事件：POST_CREATED、COMMENT_CREATED、SECTION_CREATED 等
- 可被插件监听以扩展功能（如自动打标签、内容同步）

### WebSocket 实时通信 (`src/utils/socket/index.ts`)
- 心跳检测：每 5 秒
- Ping 发送：每 10 秒
- 自动重连：每 20 秒，最多 10 次
- 离线消息队列

## 已知问题

详见 `当前工作区/.monkeycode/audit-report.md`，主要问题概览：
- 4 个致命 Bug：投票页崩溃、收藏/点赞竞态、打赏无事务、级联删除孤儿数据
- 8 个高危安全漏洞：未认证端点、XSS、CSRF、信息泄露
- 30+ 个中等性能/质量问题：N+1 查询、内存泄漏、重复代码
