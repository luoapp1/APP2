# 用户与认证模块

用户与认证模块管理身份验证、用户资料、社交关系、安全设置等核心功能。

## 结构

```
server/routes/
├── user.cjs               # 用户管理（32 个端点）
├── two-factor.cjs         # 2FA 认证

src/views/
├── auth/login/index.vue          # 登录页
├── auth/login/modules/
│   ├── TwoFactorAuth.vue         # 两步验证
│   └── OAuthLogin.vue            # OAuth 登录
├── auth/register/index.vue       # 注册页
├── auth/forget-password/index.vue # 忘记密码
└── user/security/TwoFactorSetup.vue # 2FA 设置

src/store/modules/
├── user.ts                       # 用户状态（token/userInfo/roles）
├── app.ts                        # 应用全局状态
└── worktab.ts                    # 工作台标签页

src/api/
└── auth.ts                       # 认证 API
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `user.cjs` | 用户 CRUD / 资料 / 密码 / 申诉 / 注销 / 2FA |
| `store/user.ts` | Pinia 用户状态管理 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `../middleware/auth.cjs` — 认证中间件
- `speakeasy` — TOTP 算法库

**依赖本模块的**：
- 所有需要认证的前端页面
- 所有需要用户信息的功能（发帖/评论/购买等）

## 认证流程

```mermaid
sequenceDiagram
    participant User
    participant FE as 前端
    participant Auth as /api/auth/login
    participant DB as MariaDB
    participant 2FA as 2FA 模块

    User->>FE: 输入用户名+密码
    FE->>Auth: POST { userName, password }
    Auth->>DB: SELECT users WHERE username=?
    DB-->>Auth: user record
    Auth->>Auth: bcrypt.compare()
    
    alt 未启用2FA
        Auth->>DB: INSERT sessions
        Auth-->>FE: { token, userInfo }
        FE->>FE: Pinia + localStorage 保存
    else 已启用2FA
        Auth-->>FE: { need2FA: true, tempToken }
        User->>FE: 输入 6 位验证码
        FE->>Auth: POST /api/auth/login/2fa { tempToken, code }
        Auth->>2FA: speakeasy.totp.verify()
        Auth->>DB: INSERT sessions
        Auth-->>FE: { token, userInfo }
    end
```

## 角色层级

| 角色 | 标识 | 说明 |
|------|------|------|
| 超级管理员 | R_SUPER | 所有权限 |
| 管理员 | R_ADMIN | 管理后台权限 |
| 版主（管理员级） | section moderator | 审核/禁言/编辑 |
| 版主（审核员级） | section reviewer | 仅审核 |
| 普通用户 | R_USER | 基础功能 |

## 用户系统

- 登录：用户名 + 密码（bcrypt）
- 注册：用户名 + 密码 + 邀请码（可选）
- 密码重置：邮箱验证码
- 2FA：TOTP（speakeasy 实现）
- OAuth：GitHub / Google / 微信（开发中）
- 隐私设置：可隐藏 QQ/邮箱/生日/地址
- 账号注销：申请-审核流程
- 申诉：封禁后申诉流程

## 规范

### 密码要求
- 至少 6 个字符
- 使用 bcrypt 哈希存储（10 轮 salt）

### 认证 Token
- 登录后生成随机 token
- 前端存储在 localStorage + Pinia
- 每次请求通过 `Authorization: Bearer <token>` 发送
- 会话存储在数据库中，支持过期清理

## 添加新功能

### 添加新的 OAuth 提供商
1. 在 `system.cjs` 的 OAuth 配置路由中注册
2. 实现 OAuth 回调处理
3. 在前端 `OAuthLogin.vue` 中添加入口
