# 通知系统模块

通知系统管理用户之间的消息通知，包括帖子互动通知、系统公告和推送通知。

## 结构

```
server/routes/
├── notification.cjs       # 通知路由（734 行）

src/views/operation/notification/
├── PushNotification.vue   # 推送通知管理
├── push.vue               # 推送发送
└── templates.vue          # 推送模板

src/themes/mobile/default/views/appstore/browse/
└── notifications.vue      # 通知列表
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `notification.cjs` | 通知获取/已读/推送注册/敏感词管理 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `community-utils.cjs` — 鉴权函数

**依赖本模块的**：
- 前端通知中心
- 所有产生通知的业务模块（社区/商城/聊天）

## 通知类型

| 类型 | 触发场景 |
|------|---------|
| follow | 用户被关注 |
| comment | 帖子被评论 |
| like | 帖子/评论被点赞 |
| purchase | 内容被购买 |
| system | 系统公告 |
| reply | 评论被回复 |
| mention | 被 @ 提及 |

## 通知偏好

用户可以在 `通知设置` 中选择想接收的通知类型，前端根据偏好过滤通知列表。

## 规范

### 通知查询
- 分页查询，按创建时间倒序
- 返回未读数量
- 支持按类型过滤

### 已读管理
- 单条已读：`POST /api/notifications/:id/read`
- 全部已读：`POST /api/notifications/read-all`

## 添加新功能

### 添加新的通知类型
1. 在业务代码中触发通知时传入新 type
2. 在前端通知偏好中添加对应开关
3. 在 `notifications.vue` 中添加渲染模板
