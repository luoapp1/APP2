# 社区模块

社区是 Art Design Pro 的核心社交模块，提供基于板块的论坛功能，支持帖子发布、评论、投票、付费内容、资源附件等完整的内容创作与消费流程。

## 结构

```
server/routes/community/
├── community.js              # 路由注册入口（67 行）
├── community-posts.cjs       # 帖子 CRUD（1122 行）
├── community-admin.cjs       # 管理员功能（1453 行）
├── community-moderator.cjs   # 版主中心（498 行）
├── community-sections.cjs    # 板块管理
├── community-interactions.cjs # 互动（赞/收藏/打赏）
└── community-utils.cjs       # 共享工具函数（447 行）

src/themes/{mobile,pc}/default/views/appstore/community/
├── forum.vue            # 论坛主页（帖子列表）
├── post-detail.vue      # 帖子详情
├── post-create.vue      # PC 发帖
├── post-edit.vue        # 编辑帖子
├── sections.vue         # 板块列表
├── search.vue           # 搜索
├── topic-create.vue     # 创建话题
├── topic-posts.vue      # 话题帖子
├── moderator-center.vue # 版主中心
├── ModeratorModal.vue   # 版主操作弹窗
└── components/
    ├── CommentSection.vue    # 评论区域
    ├── PostContentBlocks.vue # 帖子内容块
    └── PostMenu.vue          # 帖子菜单

src/components/editor/
├── index.vue            # TipTap 富文本编辑器（1029 行）
└── extensions/          # 27 个编辑器扩展
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `community-posts.cjs` | 帖子发布/编辑/删除/审核的核心逻辑 |
| `community-admin.cjs` | 禁言管理、举报处理、标签管理、统计分析 |
| `community-moderator.cjs` | 版主批量操作、日志、封禁管理 |
| `community-utils.cjs` | 共享鉴权函数：getUserId / isAdmin / isModeratorOfSection |
| `editor/index.vue` | TipTap 富文本编辑器，集成了 27 个自定义扩展 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `../scheduler.cjs` — 计划发帖调度
- `../middleware/auth.cjs` — 认证中间件
- `../plugins/event-bus.cjs` — 事件总线（POST_CREATED 等事件）

**依赖本模块的**：
- 前端社区页面
- 通知系统（发帖/评论触发通知）
- 运营系统（经验/积分变动）

## 帖子生命周期

```mermaid
stateDiagram-v2
    [*] --> Draft: 保存草稿
    [*] --> Pending: 发布（需审核）
    [*] --> Published: 发布（免审核）
    Draft --> Pending: 发布草稿
    Draft --> Published: 发布草稿（免审核）
    Pending --> Published: 审核通过
    Pending --> Rejected: 审核驳回
    Published --> Locked: 锁定
    Published --> Hidden: 隐藏
    Published --> Deleted: 作者删除
    Locked --> Published: 解锁
    Hidden --> Published: 恢复显示
    Deleted --> Published: 恢复
    Deleted --> [*]: 永久删除
```

## 板块审核模式

板块可设置 `reviewRequired` 字段：
- `true`：所有帖子需审核通过后才可见
- `false`：发布即展示（若含敏感词仍需审核）

发帖权限由 `postPermission` 控制：
- `all`：所有用户可发帖
- `member`：仅会员可发帖
- `moderator`：仅版主及以上

## 帖子状态标记

| 标记 | 说明 | 操作者 |
|------|------|--------|
| 精华 | 高质量内容，在板块顶部展示 | 版主/管理员 |
| 置顶 | 固定在板块顶部 | 版主/管理员 |
| 全局置顶 | 所有板块顶部显示 | 管理员 |
| 热门 | 高热度内容标记 | 版主/管理员 |
| 锁定 | 禁止新评论（关闭讨论） | 版主/管理员 |
| 自定义徽章 | 管理员设定的特殊标记 | 管理员 |

## 规范

### 错误处理
- 帖子不存在：404
- 无权限操作：403 `{ code: 403, msg: '没有操作权限' }`
- 被禁言：403 `{ code: 403, msg: '您已被禁言至 XXXX-XX-XX' }`
- 参数缺失：400 `{ code: 400, msg: '标题不能为空' }`

### 敏感词检测
发帖和评论时自动检测敏感词，命中则触发审核流程。

### 付费内容
帖子可设置：
- `contentPrice` / `contentPriceType`：内容付费金额和类型
- `hasResource` / `resourcePrice`：资源附件付费
- `accessPassword`：付费后提取码

## 添加新功能

### 添加新的帖子排序方式
1. 在 `community-posts.cjs` 的 SQL ORDER BY 中添加新分支
2. 在前端论坛页面的排序选项中添加新项

### 添加新编辑器扩展
1. 在 `src/components/editor/extensions/` 创建新扩展文件
2. 在 `editor/index.vue` 中注册扩展
3. 更新渲染端以支持新内容类型
