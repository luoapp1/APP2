# 应用商店模块

应用商店是 Art Design Pro 的应用发现、分发和交易平台，支持应用发布、版本管理、评论评分、打赏、购买、审核等完整生态。

## 结构

```
server/routes/
├── appstore.cjs           # 应用 CRUD（1956 行）

src/themes/{mobile,pc}/default/views/appstore/
├── browse/
│   ├── index.vue          # 首页/应用列表
│   ├── detail.vue         # 应用详情
│   ├── category.vue       # 分类浏览
│   ├── ranking.vue        # 排行榜
│   ├── updates.vue        # 更新日志
│   ├── mine.vue           # 我的
│   ├── profile.vue        # 个人主页
│   └── purchases.vue      # 购买记录
├── list/index.vue         # 管理端应用列表
├── review/index.vue       # 审核
├── submissions/
│   ├── index.vue          # 提交管理
│   ├── edit-form.vue      # 提交编辑表单
│   └── success.vue        # 提交成功
├── category/index.vue     # 分类管理
├── reports/index.vue      # 举报管理
└── compare/index.vue      # 应用对比

src/api/
├── appstore.ts            # 应用 API 封装
├── submission.ts          # 提交 API 封装
└── app-favorite.ts        # 收藏 API 封装
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `appstore.cjs` | 应用/版本/评论 CRUD、打赏、购买、分类、合集管理 |
| `submission.ts` | 前端提交编辑表单的 API 调用 |
| `detail.vue` | 应用详情展示（含版本、评论、打赏、评分） |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `../middleware/auth.cjs` — 认证中间件
- `../routes/upload.cjs` — APK 上传
- `../routes/settlement.cjs` — 结算系统

**依赖本模块的**：
- 前端应用浏览/管理页面
- 通知系统（新版本/评论等触发）
- 推荐系统

## 应用提交工作流

```mermaid
stateDiagram-v2
    [*] --> Draft: 创建草稿
    Draft --> Submitted: 提交审核
    Submitted --> Approved: 审核通过
    Submitted --> Rejected: 审核驳回
    Approved --> Published: 上架
    Published --> UpdatePending: 提交更新
    UpdatePending --> Approved: 更新通过
    Published --> TakenDown: 下架
    Rejected --> Draft: 重新编辑
    TakenDown --> [*]
```

## 应用版本管理

每个应用可有多个版本：
- 当前版本标记：`isCurrent`
- 版本号格式：SemVer（如 `1.0.0`）
- 版本代码：整数递增（`versionCode`）
- 更新日志：每条版本附带 `updateContent`

## 评论与评分

- 每用户每应用仅可评分一次
- 评论 30 秒限流
- 评论支持回复树（嵌套）
- 评论可置顶（最多 3 条）

## 规范

### 应用数据字段

```javascript
{
  name: string,           // 应用名称
  packageName: string,    // 包名（唯一）
  version: string,        // 版本号
  versionCode: number,    // 版本代码
  icon: string,           // 图标 URL
  iconBgColor: string,    // 图标背景色
  sizeMb: number,         // 大小（MB）
  downloadUrl: string,    // 下载地址
  description: string,    // 应用描述
  screenshots: array,     // 截图 URL 数组
  tags: array,            // 标签
  category: string,       // 分类
  price_type: string,     // 免费/金币/余额
  price_amount: number,   // 价格
  developer: string,      // 开发者
  isPinned: boolean,      // 置顶
  isOfficial: boolean,    // 官方
  isFeatured: boolean,    // 精选
  status: string          // draft/submitted/approved/published/taken_down
}
```

### 错误处理
- 应用不存在：404
- 权限不足：403
- 参数缺失：400

## 添加新功能

### 添加新的应用排序/筛选维度
1. 在 `appstore.cjs` 的 SQL 查询中添加 WHERE / ORDER BY 分支
2. 在前端 `index.vue` 中添加对应 UI 控件
