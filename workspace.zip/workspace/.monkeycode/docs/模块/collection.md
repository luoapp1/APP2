# 合集模块

合集是社区的高级内容组织方式，允许将多个帖子集合为一个付费或免费的精选内容集合。

## 结构

```
server/routes/
├── collection.cjs         # 合集全部路由（1370 行）

src/themes/{mobile,pc}/default/views/appstore/community/
├── my-collections.vue         # 我的合集
├── my-collections-list.vue    # 合集列表
├── create-collection.vue      # 创建合集
├── collection-detail.vue      # 合集详情
└── my-paid-collections.vue    # 已购合集
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `collection.cjs` | 合集 CRUD / 内容管理 / 购买 / 进度 / 评论评分 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `community-utils.cjs` — 鉴权函数

**依赖本模块的**：
- 前端合集页面
- 通知系统
- 结算系统（合集购买）

## 合集结构

```javascript
{
  title: string,           // 合集标题
  description: string,     // 合集描述
  cover: string,           // 封面图 URL
  status: 'serializing' | 'finished',  // 连载中 / 已完结
  price: number,           // 价格
  priceType: 'coin' | 'balance' | 'free',  // 价格类型
  sections: [{             // 章节（可选）
    title: string,
    posts: [number]        // 帖子 ID 数组
  }]
}
```

## 合集状态

```mermaid
stateDiagram-v2
    [*] --> Draft: 创建
    Draft --> Serializing: 发布
    Serializing --> Finished: 完结
    Draft --> [*]: 删除
    Serializing --> [*]: 删除
    Finished --> [*]: 删除
```

## 规范

### 合集购买
- 创建者可以设置付费金额
- 购买后解锁所有章节的完整内容
- 阅读进度自动保存

### 分类
- 免费合集：所有人可阅读
- 付费合集：需购买后阅读

## 添加新功能

### 添加新的合集排序
1. 在 `collection.cjs` 的查询中添加新的 ORDER BY 分支
2. 在前端添加对应的排序控件
