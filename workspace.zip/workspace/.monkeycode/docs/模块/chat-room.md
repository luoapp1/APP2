# 聊天室与私信模块

聊天室与私信模块提供实时通信功能，包括群组聊天室和一对一私信，支持 WebSocket 实时推送。

## 结构

```
server/routes/
├── chat-room.cjs          # 聊天室全部路由（1498 行）

src/themes/{mobile,pc}/default/views/appstore/browse/
├── chatrooms.vue          # 聊天室列表
├── chatroom-chat.vue      # 聊天室界面
├── discover-chat.vue      # 发现/会话
├── mine.vue               # 我的（含对话列表）
└── personal-space.vue     # 个人空间

src/utils/socket/
└── index.ts               # WebSocket 客户端
  - 心跳检测：每 5 秒
  - Ping 发送：每 10 秒
  - 自动重连：每 20 秒，最多 10 次
  - 离线消息队列

src/api/
└── message.ts             # 消息 API 封装
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `chat-room.cjs` | 聊天室 CRUD / 消息 / 成员管理 / 群文件 / 礼物 |
| `socket/index.ts` | WebSocket 客户端，管理实时消息推送 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `../middleware/auth.cjs` — 认证中间件
- `../routes/upload.cjs` — 图片上传

**依赖本模块的**：
- 前端聊天页面
- 通知系统（新消息提醒）

## 聊天室角色

| 角色 | 权限 |
|------|------|
| 群主 | 所有权限：解散、转让、设置管理、踢人、禁言 |
| 管理员 | 踢人、禁言、置顶消息 |
| 成员 | 发消息、上传文件、送礼物 |
| 禁言成员 | 仅可查看，不可发言 |

## 消息功能

- 文本消息
- 图片消息
- 文件消息（群组）
- 消息撤回（2 分钟内）
- 消息举报
- 敏感词自动替换
- 语音消息（预留）

## 聊天室类型

| 类型 | 说明 |
|------|------|
| public | 公开聊天室（所有人可搜索和加入） |
| private | 私密聊天室（需要密码加入） |

## 规范

### WebSocket 连接流程
1. 前端建立 WebSocket 连接
2. 每 5 秒心跳检测
3. 每 10 秒发送 ping
4. 断线后每 20 秒自动重连（最多 10 次）
5. 重连后补发离线消息

### 错误处理
- 聊天室不存在：404
- 无权限操作：403
- 成员已满：400

## 添加新功能

### 添加新的消息类型
1. 在 `chat-room.cjs` 的消息发送接口中添加新 type 处理
2. 在前端 `chatroom-chat.vue` 中添加对应渲染
