# 商城模块

商城是 Art Design Pro 的实物/虚拟商品交易平台，支持商品浏览、购物车、下单、支付、物流、评价、售后等完整的电商流程。

## 结构

```
server/routes/
├── mall.cjs               # 商城全部路由（1659 行）

src/views/
├── admin/mall/
│   ├── mall-manage/       # 商品管理
│   ├── mall-product-create/  # 商品创建
│   ├── mall-orders/       # 订单管理
│   ├── mall-categories/   # 分类管理
│   ├── mall-after-sales/  # 售后管理
│   └── mall-promotions/   # 促销管理

src/api/
├── mine.ts                # 我的相关 API（含商城订单等）
└── mall.ts                # 商城 API
```

## 关键文件

| 文件 | 目的 |
|------|------|
| `mall.cjs` | 所有商城路由：商品/分类/购物车/订单/评价/售后/促销 |

## 依赖

**本模块依赖**：
- `../database.cjs` — 数据库连接
- `../middleware/auth.cjs` — 认证中间件

**依赖本模块的**：
- 前端商城页面
- 通知系统（订单状态变更）
- 结算系统

## 订单状态流转

```mermaid
stateDiagram-v2
    [*] --> Pending: 创建订单
    Pending --> Paid: 支付
    Pending --> Cancelled: 取消
    Paid --> Shipped: 发货
    Shipped --> Delivered: 确认收货
    Delivered --> Completed: 自动确认
    Delivered --> Refunding: 申请售后
    Paid --> Refunding: 申请退款
    Refunding --> Refunded: 退款完成
    Refunding --> Rejected: 拒绝退款
    Completed --> [*]
    Cancelled --> [*]
    Refunded --> [*]
    Rejected --> [*]
```

## 商品类型

| 类型 | 说明 |
|------|------|
| physical | 实物商品（需物流） |
| virtual | 虚拟商品（无需物流，自动发货） |
| service | 服务类商品 |

## 价格类型

| 类型 | 说明 |
|------|------|
| free | 免费 |
| coin | 金币支付 |
| balance | 余额支付 |
| mixed | 混合支付 |

## 规范

### 购物车结算流程
1. 选择购物车商品 → `POST /api/mall/cart/checkout`
2. 传入 `cartIds`, `addressId`, `userCouponId`
3. 后端创建订单、扣除余额、更新库存
4. 返回订单 ID

### 错误处理
- 库存不足：400
- 余额不足：400
- 优惠券无效：400

## 添加新功能

### 添加新的商品类型
1. 在 `mall.cjs` 的商品创建/更新处理中添加新 `productType` 校验
2. 在前端商品创建表单中添加对应的选项
