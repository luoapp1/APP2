# 开发者指南 — Art Design Pro

## 环境搭建

### 前置条件

- Node.js >= 22
- MariaDB / MySQL 8.0+
- npm 或 pnpm

### 克隆与安装

```bash
# 克隆仓库
git clone <repo-url>
cd workspace

# 安装前端依赖
npm install

# 安装后端依赖
cd server
npm install
cd ..
```

### 数据库配置

编辑 `server/.env`：

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=artpro
DB_PASSWORD=your_password
DB_NAME=art_design_pro
PORT=3001
```

数据库初始化：

```bash
# 进入 server 目录
cd server

# 执行数据库初始化（建表 + 种子数据）
node seed.cjs
```

数据库 OOM 在 `server/database.cjs`，共 2189 行，涵盖所有表的 DDL 定义。

### 运行

```bash
# 启动后端（端口 3001）
cd server
node index.cjs

# 启动前端（端口 3333，含 API 反向代理）
npm run dev
```

启动后访问：
- 前端：`http://localhost:3333`
- 后端 API：`http://localhost:3001/api`

## 环境变量

| 变量 | 必需 | 描述 | 示例 |
|------|------|------|------|
| `DB_HOST` | 是 | 数据库主机 | `localhost` |
| `DB_PORT` | 是 | 数据库端口 | `3306` |
| `DB_USER` | 是 | 数据库用户 | `artpro` |
| `DB_PASSWORD` | 是 | 数据库密码 | `your_password` |
| `DB_NAME` | 是 | 数据库名称 | `art_design_pro` |
| `PORT` | 否 | 后端监听端口 | `3001` |
| `FILE_UPLOAD_DIR` | 否 | 文件上传目录 | `./uploads` |

**绝不提交密钥**。使用 `.env` 文件管理敏感配置。

## 宝塔面板部署指南

### 1. 环境准备（宝塔面板）

在宝塔面板中安装以下软件：
- Node.js 版本管理器（安装 Node.js 22）
- MySQL 8.0（或 MariaDB 10.6+）
- Nginx（用于反向代理）

### 2. 创建站点

在宝塔面板「网站」-「Node 项目」中添加：
- 项目目录：选择 workspace/server
- 启动文件：`index.cjs`
- 项目端口：`3001`
- 运行用户：`www`

### 3. 数据库配置

在宝塔面板「数据库」中创建：
- 数据库名：`art_design_pro`
- 用户名：`artpro`
- 密码：自行设定

SSH 终端执行初始化：

```bash
# 进入后端目录
cd /www/wwwroot/your-site/server

# 安装依赖
npm install --production

# 初始化数据库
node seed.cjs
```

### 4. Nginx 反向代理配置

在宝塔面板站点配置中添加：

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:3001;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
}

location /uploads/ {
    alias /www/wwwroot/your-site/server/uploads/;
}

location / {
    # 前端静态文件路径
    alias /www/wwwroot/your-site/dist/;
    try_files $uri $uri/ /index.html;
}
```

### 5. 前端构建

```bash
# 在项目根目录
npm install
npm run build

# 产物输出在 dist/ 目录
```

### 6. 启动

在宝塔面板 Node 项目列表中启动项目，或通过 PM2：

```bash
# 后端
cd /www/wwwroot/your-site/server
pm2 start index.cjs --name "art-design-backend"

# 保存 PM2 进程列表
pm2 save
pm2 startup
```

### 7. 定时任务

项目内置了定时任务（`server/scheduler.cjs`），包括：
- 计划发帖自动发布（每 60 秒）
- 订单自动确认收货（每 60 秒）
- 会话过期清理（每 5 分钟）
- 2FA 临时会话清理（每 5 分钟）
- 速率限制缓存清理（每 5 分钟）
- IP 地理位置缓存清理（每 10 分钟）

无需额外配置 cron，启动后端即自动运行。

---

## 开发工作流

### 项目脚本

```bash
# 前端
npm run dev          # 启动前端开发服务器（:3333）
npm run build        # 生产构建
npm run typecheck    # TypeScript 类型检查

# 后端
cd server
node index.cjs       # 启动后端（:3001）
node seed.cjs        # 数据库初始化
```

### 代码质量工具

| 工具 | 说明 |
|------|------|
| TypeScript | 前端类型检查 |
| ESLint | 代码检查 |
| Prettier | 代码格式化 |

### 分支策略

- `main` — 生产就绪代码
- `feature/*` — 新功能
- `fix/*` — Bug 修复

---

## 常见任务

### 添加新 API 端点

**需修改的文件**：
1. `server/routes/<module>.cjs` — 添加路由处理器
2. 如有新表，在 `server/database.cjs` 中添加建表语句

**步骤**：
1. 在路由文件中定义 `router.<method>('/path', handler)`
2. 通过 `getUserId(req)` 获取当前用户
3. 编写数据库查询
4. 返回标准 JSON 格式 `{ code, msg, data }`

**示例提交**：`feat(api): add POST /api/community/post/:id/sticky endpoint`

### 添加新数据库表

**修改文件**：`server/database.cjs`

**步骤**：
1. 在 `initializeDatabase()` 函数中添加 `CREATE TABLE IF NOT EXISTS ...` 语句
2. 确保添加索引和外键
3. 运行 `node seed.cjs` 重新初始化

### 添加新前端页面

**修改文件**：
1. 在 `src/router/routes/staticRoutes.ts` 中添加路由定义
2. 在对应主题目录下创建 `.vue` 文件
   - 移动端：`src/themes/mobile/default/views/appstore/`
   - PC 端：`src/themes/pc/default/views/appstore/`

**步骤**：
1. 在 `staticRoutes.ts` 中添加路由对象（name, path, component）
2. 创建 Vue SFC 文件（使用 `<script setup lang="ts">`）
3. 使用 `src/utils/http/index.ts` 中的 `$http` 发起请求

### 添加新主题

**需要创建的文件**：
1. `src/themes/<new-theme>/default/views/` — 页面组件
2. `src/themes/<new-theme>/default/styles/` — 样式文件

**步骤**：
1. 创建主题目录结构
2. 实现对应路由的页面组件
3. 在路由配置中注册主题

### 修复 Bug

**流程**：
1. 定位报错来源（前端控制台 / 后端日志）
2. 在相关路由/组件文件中定位根因
3. 用最小改动修复
4. 检查是否有类似问题

**示例提交**：`fix(community): handle empty comment list gracefully`

---

## 编码规范

### 文件组织

- 每个文件一个组件/类/模块
- 相关文件放在同一目录
- 后端路由按业务模块拆分到 `server/routes/<module>.cjs`

### 命名

| 类型 | 约定 | 示例 |
|------|------|------|
| 文件 | kebab-case / PascalCase | `user-service.ts`, `AppStore.vue` |
| 类 | PascalCase | `UserService` |
| 函数 | camelCase | `getUserById` |
| 常量 | SCREAMING_SNAKE | `MAX_RETRIES` |
| Vue 组件 | PascalCase | `PostDetail.vue` |

### 错误处理（后端）

```javascript
// 推荐：具体的错误状态码和消息
res.status(400).json({ code: 400, msg: '标题不能为空' });

// 服务器错误
res.status(500).json({ code: 500, msg: '服务器内部错误' });
```

### HTTP 请求（前端）

```typescript
import { $http } from '@/utils/http';

// GET 请求
const { data } = await $http.get('/api/community/posts', { params: { sectionId: 1 } });

// POST 请求
const { data } = await $http.post('/api/community/post', { title: '标题', content: '内容' });
```

### 日志（后端）

```javascript
// 包含上下文
console.log(`[Community] User ${userId} created post ${postId}`);

// 错误日志
console.error(`[Community] Failed to create post:`, error.message);
```

### 测试

- 暂无统一的测试框架
- 手动测试通过 Postman / curl 验证 API 端点
- 前端通过浏览器控制台验证状态

---

## 定时任务详解

### 调度器说明

`server/scheduler.cjs` — 内置调度器，不需要外部 crontab。

**工作原理**：
- 优先使用 `node-cron` 插件（`scheduler/plugin.cjs`）
- 降级时使用 `setInterval` 作为后备
- 降级定时器每 60 秒检查一次，自动恢复 cron 模式

### 任务列表

| 任务 | 文件 | 周期 | 说明 |
|------|------|------|------|
| 计划发帖 | `community.cjs:17` | 60 秒 | 检查 `scheduledTime` 到期的帖子并自动发布 |
| 订单自动确认 | `settlement.cjs:645` | 60 秒 | 到期订单自动确认收货，解冻资金 |
| 会话清理 | `system.cjs:14` | 5 分钟 | 清理过期的 sessions |
| 2FA 会话清理 | `two-factor.cjs:41` | 5 分钟 | 清理 2FA 临时会话 |
| 速率限制清理 | `rate-limit.cjs:11` | 5 分钟 | 清理过期的速率限制记录 |
| IP 地理位置清理 | `ip-geo.cjs:264` | 10 分钟 | 清理过期的 IP 缓存 |
| 调度器降级检查 | `scheduler.cjs:44` | 60 秒 | 检查并恢复 cron 模式 |

---

## Vite 反向代理配置

`当前工作区/vite.config.ts` 已配置 API 代理：

```typescript
server: {
  port: 3333,
  proxy: {
    '/api': {
      target: 'http://localhost:3001',
      changeOrigin: true
    }
  }
}
```

前端请求 `/api/*` 自动转发到后端 `3001` 端口。

---

## 项目架构速查

| 层 | 技术 | 文件位置 |
|----|------|---------|
| 前端框架 | Vue 3 + TypeScript | `src/` |
| 构建工具 | Vite 7 | `vite.config.ts` |
| 状态管理 | Pinia | `src/store/modules/` |
| UI 组件（移动端） | Vant | `src/themes/mobile/` |
| UI 组件（PC 端） | Element Plus | `src/themes/pc/` |
| 富文本编辑器 | TipTap (ProseMirror) | `src/components/editor/` |
| HTTP 客户端 | Axios | `src/utils/http/` |
| WebSocket | 自建 | `src/utils/socket/` |
| 后端框架 | Express | `server/index.cjs` |
| 数据库 | MySQL/MariaDB (mysql2) | `server/database.cjs` |
| 认证 | Bearer Token + bcrypt | `server/middleware/auth.cjs` |
| 2FA | speakeasy (TOTP) | `server/routes/two-factor.cjs` |
| 邮件 | nodemailer | `server/routes/email.cjs` |
| 文件上传 | multer | `server/routes/upload.cjs` |
| 调度 | node-cron + setInterval | `server/scheduler.cjs` |

## 快速命令参考

```bash
# 前端开发
npm run dev              # 启动前端 :3333
npm run build            # 生产构建
npm run typecheck        # TS 类型检查

# 后端
cd server && node index.cjs   # 启动后端 :3001
cd server && node seed.cjs    # 数据库初始化
```
