# 代码全面审查报告

## 一、致命 Bug（必须立即修改）

### 1.1 运行时崩溃：投票页 `escapeHtml` 未定义

- **严重等级**: 致命
- **类型**: 必须立即修改
- **文件**: `src/themes/mobile/default/views/appstore/community/post-detail.vue`
- **行号**: L1154-L1162
- **描述**: `loadVoteResults()` 中调用 `escapeHtml(o.text)` 但该函数未定义/未导入，投票结果页面必定抛出 `ReferenceError: escapeHtml is not defined`，导致投票功能白屏崩溃。
- **复现**: 进入任意有投票的帖子详情页，查看投票结果 → 白屏。
- **修复代码**:

```javascript
// 在 post-detail.vue <script setup> 中添加函数定义
function escapeHtml(text: string): string {
  if (!text) return ''
  const map: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }
  return String(text).replace(/[&<>"']/g, c => map[c] || c)
}
```

---

### 1.2 数据不一致：收藏/点赞竞态条件

- **严重等级**: 致命
- **类型**: 必须立即修改
- **文件**: `server/routes/community/community-interactions.cjs`
- **行号**: L69-L113
- **描述**: 收藏/点赞 toggle 逻辑为"先查是否存在 → 存在则删 → 不存在则插"，无事务/行锁。两个并发请求可同时检测到"不存在"并都插入，导致重复数据和计数错误。
- **复现**: 快速双击收藏/点赞按钮 → 数据重复插入。
- **修复代码**:

```javascript
// 方案1：使用 INSERT ... ON DUPLICATE KEY（需要先建 UNIQUE 索引）
// ALTER TABLE community_likes ADD UNIQUE INDEX idx_user_post (user_id, post_id);
await query(
  `INSERT INTO community_likes (user_id, post_id, create_time) VALUES (?, ?, NOW())
   ON DUPLICATE KEY UPDATE is_deleted = IF(is_deleted = 1, 0, 1)`,
  [userId, postId]
)

// 方案2：使用行级锁（MySQL InnoDB）
await query('START TRANSACTION')
await query('SELECT id FROM community_likes WHERE user_id=? AND post_id=? FOR UPDATE', [userId, postId])
// ... 判断并操作
await query('COMMIT')
```

---

### 1.3 数据不一致：打赏操作无事务保护

- **严重等级**: 致命
- **类型**: 必须立即修改
- **文件**: `server/routes/community/community-interactions.cjs`
- **行号**: L394-L457
- **描述**: 打赏流程：扣余额 → 插入打赏记录 → 增加 post.coin_count → 插入日志，未封装在事务中。中间步骤失败会导致余额扣了但帖子没收到的数据不一致。
- **修复代码**:

```javascript
await query('START TRANSACTION')
try {
  await query('UPDATE users SET balance = balance - ? WHERE id=? AND balance >= ?', [amount, userId, amount])
  // 检查 affectedRows
  await query('INSERT INTO community_coin_logs ...', [...])
  await query('UPDATE community_posts SET coin_count = coin_count + ? WHERE id=?', [amount, postId])
  await query('INSERT INTO community_coin_logs ...', [...])
  await query('COMMIT')
} catch (e) {
  await query('ROLLBACK')
  throw e
}
```

---

### 1.4 级联删除导致孤儿数据

- **严重等级**: 致命
- **类型**: 必须立即修改
- **文件**: `server/routes/community/community-posts.cjs`
- **行号**: L836-L907
- **描述**: 删除帖子时设置 `is_deleted=1`，但不级联处理评论/点赞/收藏/投币/解锁请求。这些关联数据变成孤儿，查询帖子统计时出现脏数据。
- **修复代码**:

```javascript
// 删除帖子时级联标记关联数据
await query('UPDATE community_comments SET is_deleted=1, status="deleted" WHERE post_id=?', [postId])
await query('DELETE FROM community_likes WHERE post_id=?', [postId])
await query('DELETE FROM community_favorites WHERE post_id=?', [postId])
// ... 然后是删除帖子本身
```

---

## 二、严重 Bug

### 2.1 后端 7 个端点无认证检查

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `server/routes/system.cjs`、`server/routes/user.cjs`
- **行号**: system.cjs:L586, L712, L421-458, L683, L630-679 / user.cjs:L844, L856, L925, L939
- **描述**: `/api/role/list`、`/api/admin/console-stats`、`/api/admin/oauth-configs`(GET/POST)、`/api/dashboard/stats`、`/api/role/:id/permissions`(GET/POST)、`/api/user/delete-requests`、`/api/user/appeals` 完全无需登录即可访问，可获取全平台用户数/订单金额/充值金额/OAuth 密钥等敏感信息。
- **修复代码**:

```javascript
// 在每个端点开头添加
app.get('/api/admin/console-stats', async (req, res) => {
  const userId = await getUserId(req)
  if (!userId) return res.json({ code: 401, msg: '请先登录' })
  if (!await isAdminById(userId)) return res.json({ code: 403, msg: '无权限' })
  // ... 原有逻辑
})
```

---

### 2.2 修改密码接口不验证身份

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `server/routes/user.cjs`
- **行号**: L772
- **描述**: `POST /api/auth/change-pwd` 仅从 request body 取 `userId`，不验证 token/cookie 是否属于该用户。攻击者只需知道 userId 和旧密码（可爆破）即可改任意用户密码。
- **修复代码**:

```javascript
app.post('/api/auth/change-pwd', async (req, res) => {
  const userId = await getUserId(req)   // 改为从 session/token 获取
  if (!userId) return res.json({ code: 401, msg: '请先登录' })
  const { oldPwd, newPwd } = req.body
  // ... 验证旧密码匹配当前用户
})
```

---

### 2.3 6 处 XSS：v-html 未净化用户内容

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件列表**:
  - `src/themes/mobile/default/views/appstore/browse/detail.vue` L346, L383 — 评论内容
  - `src/themes/pc/default/views/appstore/browse/detail.vue` L165 — 评论内容
  - `src/themes/mobile/default/views/appstore/browse/profile.vue` L349 — 社区评论
  - `src/themes/mobile/default/views/appstore/browse/mine.vue` L836 — 管理员配置弹窗 HTML
  - `src/themes/mobile/default/views/appstore/mall/detail.vue` L153 — 商品描述
  - `src/components/editor/extensions/social-unlocks.ts` L80, L87 — innerHTML 拼接用户属性
- **描述**: 直接使用 `v-html` 渲染用户生成内容，未调用 `sanitizeHtml()`，攻击者可在评论/商品描述中注入 `<script>` 窃取 cookie/token。
- **修复代码（以 detail.vue 评论为例）**:

```html
<!-- 修改前 -->
<div v-html="comment.content"></div>

<!-- 修改后 -->
<div v-html="sanitizeHtml(comment.content)"></div>
```

```javascript
// 在 <script setup> 中添加
function sanitizeHtml(html: string): string {
  if (!html) return ''
  const div = document.createElement('div')
  div.textContent = html
  return div.innerHTML
}
```

- **social-unlocks.ts 修复**:

```typescript
// 修改前
author.innerHTML = '<span style="...">作者：</span>' + node.attrs.author

// 修改后
const span = document.createElement('span')
span.textContent = node.attrs.author
author.textContent = '作者：'
author.appendChild(span)
```

---

### 2.4 全局缺少 CSRF 保护

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `src/utils/http/index.ts`、`server/index.cjs`
- **描述**: 所有 API 请求无 CSRF token，基于 cookie 的认证方式下全站可被 CSRF 攻击。
- **修复代码**:

```javascript
// 服务端：生成 CSRF token
const crypto = require('crypto')
app.use((req, res, next) => {
  if (!req.cookies.csrf_token) {
    const token = crypto.randomBytes(32).toString('hex')
    res.cookie('csrf_token', token, { httpOnly: false, sameSite: 'strict' })
  }
  next()
})

// 验证中间件
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next()
  const cookieToken = req.cookies.csrf_token
  const headerToken = req.headers['x-csrf-token']
  if (cookieToken && headerToken && cookieToken === headerToken) return next()
  res.status(403).json({ code: 403, msg: 'CSRF token invalid' })
})
```

```typescript
// 前端：在 http/index.ts 拦截器中添加
axios.interceptors.request.use(config => {
  const token = document.cookie.match(/csrf_token=([^;]+)/)?.[1]
  if (token) config.headers['X-CSRF-Token'] = token
  return config
})
```

---

### 2.5 681+ 处错误信息泄露

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `server/routes/` 下几乎所有文件
- **描述**: 所有 catch 块使用 `res.json({ code: 500, msg: e.message })` 直接返回原始错误信息给客户端，暴露数据库表结构、SQL 语句、内部文件路径。
- **修复代码**:

```javascript
// 统一错误响应工具函数（建议添加到 server/utils/ 中）
function safeError(res, e, context = '') {
  console.error(`[${context}]`, e)  // 仅在服务端日志打印完整错误
  res.json({ code: 500, msg: '服务器内部错误，请稍后重试' })
}

// 批量替换：把所有 catch (e) { res.json({ code: 500, msg: e.message }) }
// 替换为           catch (e) { safeError(res, e, 'endpoint-name') }
```

---

### 2.6 支付重定向开放跳转

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `src/themes/mobile/default/views/appstore/browse/assets.vue`
- **行号**: L397
- **描述**: `window.location.href = res.payUrl` 直接跳转到 API 返回的 URL，不验证域名。若 API 被劫持或返回恶意 URL，用户会被导向钓鱼网站。
- **修复代码**:

```typescript
const ALLOWED_PAY_DOMAINS = ['pay.example.com', 'alipay.com', 'api.mch.weixin.qq.com']

function safeRedirect(url: string) {
  try {
    const u = new URL(url)
    if (ALLOWED_PAY_DOMAINS.some(d => u.hostname.endsWith(d))) {
      window.location.href = url
    } else {
      ElMessage.error('支付链接异常，请联系管理员')
    }
  } catch {
    ElMessage.error('支付链接格式错误')
  }
}

// 修改前
window.location.href = res.payUrl
// 修改后
safeRedirect(res.payUrl)
```

---

### 2.7 `isAdminById` 实现不一致导致鉴权失效

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `server/routes/community-topics.cjs` L43-L48
- **描述**: 该文件自己实现了一版 `isAdminById`，用 `rows[0].role === 'admin'` 判断。但 users 表的 roles 字段是 JSON 数组 `["R_SUPER"]`，不是字符串 `"admin"`。该实现永远返回 false。
- **修复代码**:

```javascript
// 删除 community-topics.cjs 中的本地 isAdminById 实现
// 改为从 community-utils.cjs 导入
const { isAdminById } = require('./community/community-utils.cjs')
```

---

### 2.8 文件删除不验证所有权

- **严重等级**: 高（安全）
- **类型**: 必须立即修改
- **文件**: `server/routes/upload.cjs` L795-L811
- **描述**: `POST /api/upload/delete-uploaded` 仅凭 downloadUrl 查找并删除文件，不检查请求者是否为文件所有者。任意登录用户可删除他人的上传文件。
- **修复代码**:

```javascript
app.post('/api/upload/delete-uploaded', async (req, res) => {
  const userId = await getUserId(req)
  if (!userId) return res.json({ code: 401, msg: '请先登录' })
  
  const file = await query('SELECT user_id, file_path FROM uploads WHERE download_url=?', [req.body.downloadUrl])
  if (!file.length) return res.json({ code: 404, msg: '文件不存在' })
  if (file[0].user_id !== userId && !await isAdminById(userId)) {
    return res.json({ code: 403, msg: '无权删除他人文件' })
  }
  // ... 删除逻辑
})
```

---

## 三、中等 Bug

### 3.1 art-drag-verify 重复事件监听器泄漏

- **严重等级**: 中
- **类型**: 必须立即修改
- **文件**: `src/components/core/forms/art-drag-verify/index.vue`
- **行号**: L152-L153, L185-L186, L190-L193
- **描述**: `touchstart`/`touchmove` 被顶层 <script setup> 和 onMounted 各添加一次，但 onBeforeUnmount 只移除一次。顶层添加的监听器永不清理，组件每次挂载累积 2 个 document 级监听器。
- **修复代码**:

```typescript
// 删除 L152-L153 的顶层 addEventListener：
// document.addEventListener('touchstart', handleTouchStart)  ← 删除
// document.addEventListener('touchmove', handleTouchMove)    ← 删除

// 仅保留 onMounted 中的注册和 onBeforeUnmount 中的清理
```

---

### 3.2 PC profile-edit 定时器未清理

- **严重等级**: 中
- **类型**: 必须立即修改
- **文件**: `src/themes/pc/default/views/appstore/profile-edit.vue`
- **行号**: L67
- **描述**: `emailTimer` 仅在 `closeEmailDialog()` 中清理，用户直接离开页面时残留。
- **修复代码**:

```vue
<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'

onBeforeUnmount(() => {
  if (emailTimer) { clearInterval(emailTimer); emailTimer = null }
})
</script>
```

---

### 3.3 忘记密码页定时器未清理

- **严重等级**: 中
- **类型**: 必须立即修改
- **文件**: `src/views/auth/forget-password/index.vue`
- **行号**: L147
- **描述**: 倒计时期间浏览器后退离开，`countdownTimer` 残留。
- **修复代码**: 同上，添加 `onBeforeUnmount(() => { if (countdownTimer) clearInterval(countdownTimer) })`

---

### 3.4 管理员无法永久删除他人帖子

- **严重等级**: 中
- **类型**: 必须立即修改
- **文件**: `server/routes/community/community-posts.cjs`
- **行号**: L885-L907
- **描述**: `DELETE /api/community/post/:id/permanent` 仅 `post.user_id !== userId` 时返回 403，管理员无法删除违规帖子。
- **修复代码**:

```javascript
const isAdminUser = await isAdminById(userId)
if (post[0].user_id !== userId && !isAdminUser) {
  return res.json({ code: 403, msg: '无权操作' })
}
```

---

### 3.5 CommentSection watcher 竞态导致监听器泄漏

- **严重等级**: 中
- **类型**: 必须立即修改
- **文件**: `src/themes/mobile/default/views/appstore/community/components/CommentSection.vue`
- **行号**: L232-L244
- **描述**: watcher 中用 `setTimeout(() => document.addEventListener(...), 0)` 添加监听器，但 setTimeout 触发前若 commentMenuId 变 null，移除逻辑和添加逻辑产生竞态。
- **修复代码**:

```typescript
let menuTimer: ReturnType<typeof setTimeout> | null = null

watch(commentMenuId, (newVal) => {
  if (newVal) {
    menuTimer = setTimeout(() => {
      closeCommentMenuHandler = (e: MouseEvent) => { /* ... */ }
      document.addEventListener('click', closeCommentMenuHandler)
    }, 0)
  } else {
    if (menuTimer) { clearTimeout(menuTimer); menuTimer = null }
    if (closeCommentMenuHandler) {
      document.removeEventListener('click', closeCommentMenuHandler)
      closeCommentMenuHandler = null
    }
  }
})
```

---

### 3.6 速率限制缺口

- **严重等级**: 中（安全）
- **类型**: 必须立即修改
- **文件**: `server/index.cjs`
- **行号**: L83-L87
- **描述**: 密码修改、2FA 验证、发帖、评论、所有上传端点无速率限制，可被暴力破解或刷量攻击。
- **修复代码**:

```javascript
// 在 index.cjs 中为敏感端点添加速率限制
app.use('/api/auth/change-pwd', strictLimiter)       // 密码修改：严格限制
app.use('/api/auth/login/2fa', strictLimiter)         // 2FA：严格限制
app.use('/api/community/post', generalLimiter)         // 发帖
app.use(/\/api\/community\/post\/\d+\/comment/, generalLimiter)  // 评论
app.use('/api/upload', strictLimiter)                  // 上传
```

---

## 四、性能优化（迭代优化）

### 4.1 6 处完整 echarts 导入浪费数百 KB

- **严重等级**: 中
- **文件**: `src/views/appstore/RatingDetail.vue` L103, `src/views/operation/checkin/CheckinCalendar.vue` L67, `src/views/operation/analytics/FunnelAnalysis.vue` L72, `src/views/operation/checkin/calendar.vue` L67, `src/views/operation/developer-analytics/index.vue` L75, `src/themes/mobile/default/views/appstore/detail/rating.vue` L80
- **描述**: 这 6 个文件用 `import * as echarts from 'echarts'` 导入完整库（gzip 前 ~1MB），项目已有模块化 echarts 配置 `src/plugins/echarts.ts`。
- **修复代码**:

```typescript
// 修改前
import * as echarts from 'echarts'

// 修改后
import { echarts } from '@/plugins/echarts'
// 确保 plugins/echarts.ts 导出 echarts 实例
```

---

### 4.2 110+ 处 v-for 使用索引作 key

- **严重等级**: 中
- **文件**: `CommentSection.vue`、`chatroom-chat.vue`、`mall/detail.vue`、`FeedPostCard.vue` 等约 110 处
- **描述**: `:key="index"` 导致列表变动时 DOM 复用错乱、组件状态错位、不必要的重渲染。
- **修复代码**:

```html
<!-- 修改前 -->
<div v-for="(item, i) in list" :key="i">{{ item.name }}</div>

<!-- 修改后 -->
<div v-for="item in list" :key="item.id">{{ item.name }}</div>
```

---

### 4.3 post-edit.vue 不必要的 deep: true

- **严重等级**: 中
- **文件**: `src/themes/mobile/default/views/appstore/community/post-edit.vue`
- **行号**: L834-L836
- **描述**: 监视 `[form.title, form.sectionId, selectedTags.value, uploadedImages.value, coverImage.value]` 时使用 `{ deep: true }`，但这些值已是 ref/computed，引用变化即可触发。
- **修复代码**:

```javascript
// 修改前
watch([...], fn, { deep: true })

// 修改后
watch([...], fn)
```

---

### 4.4 art-line-chart 大数据 deep watch

- **严重等级**: 中
- **文件**: `src/components/core/charts/art-line-chart/index.vue`
- **行号**: L361
- **描述**: 图表数据点可达数千，`watch([...], renderChart, { deep: true })` 每次都深度比较整个数据集。
- **修复代码**: 将 deep 比较改为浅引用比较，或添加防抖：

```typescript
import { useDebounceFn } from '@vueuse/core'

const debouncedRender = useDebounceFn(renderChart, 200)
watch(watchSources, debouncedRender)
```

---

### 4.5 24 处 computed 每次返回新对象导致不必要的子组件重渲染

- **严重等级**: 低
- **文件**: `moderator-center.vue` L315, `art-drag-verify/index.vue` L204/L222, `art-table/index.vue` L181/L244/L258 等
- **描述**: `() => [{ ... }]` 或 `() => ({ ... })` 每次返回新对象字面量，依赖此 computed 的子组件每次都检测到引用变化并重渲染。
- **修复代码**:

```typescript
// 对于静态配置数据，使用 shallowRef + markRaw
const options = shallowRef([...])
// 或使用 v-memo 在模板中避免重渲染
<div v-for="item in items" :key="item.id" v-memo="[item.id, item.updated]">
```

---

### 4.6 话题列表 N+1 查询

- **严重等级**: 中
- **文件**: `server/routes/community-topics.cjs` L68-L89
- **描述**: 获取话题列表后，对每个话题分别执行 2 条 SQL（统计帖数、关注数），话题多时严重阻塞。
- **修复代码**:

```javascript
// 使用 JOIN + GROUP BY 一次查询完成
const topics = await query(`
  SELECT t.*, COUNT(DISTINCT p.id) as postCount, COUNT(DISTINCT f.id) as followerCount
  FROM community_topics t
  LEFT JOIN community_posts p ON p.topic_id = t.id AND p.status='published' AND p.is_deleted=0
  LEFT JOIN community_topic_follows f ON f.topic_id = t.id
  GROUP BY t.id
  ORDER BY t.sort_order ASC
`)
```

---

## 五、死代码清理（迭代优化）

### 5.1 完全失效的帖子收藏 API

- **严重等级**: 低
- **文件**: `src/api/post-favorite.ts` + `server/routes/post-favorite.cjs`（76行）
- **描述**: 前端 API 模块和对应的后端路由都从未被任何代码调用。
- **建议**: 如果不需要此功能，删除这两个文件和 `server/index.cjs` 中的路由注册。

### 5.2 未使用的前端 API 封装

- **严重等级**: 低
- **文件**: `src/api/transfer.ts`、`src/composables/useToast.ts`、`src/utils/ui/emojo.ts`、`src/utils/ui/tabs.ts`、`src/utils/ui/iconify-loader.ts`
- **描述**: 全校 0 处导入引用，iconify-loader 整文件被注释。
- **建议**: 删除。

### 5.3 冗余依赖 @vue/reactivity

- **严重等级**: 低
- **文件**: `package.json` L77
- **描述**: 0 处直接导入，Vue 已内置该模块。
- **建议**: `npm uninstall @vue/reactivity`

### 5.4 调试脚本 check_levels.js

- **文件**: `/workspace/check_levels.js`
- **描述**: 使用 better-sqlite3（项目用 mysql2），永远无法运行。
- **建议**: 删除。

---

## 六、重复代码整合（迭代优化）

### 6.1 iconColor() + colorPool 重复 14 次

- **文件**: `browse/index.vue`、`browse/category.vue`、`browse/detail.vue`、`browse/game.vue`、`browse/discover-chat.vue`、`browse/chatroom-chat.vue`、`browse/chatrooms.vue`、`browse/updates.vue`、`submissions/index.vue`、`submissions/file-picker.vue`、`community/sections.vue`、`mall/reviews.vue`、`mall/detail.vue`、`pc/views/appstore/game.vue`
- **描述**: 中心版本在 `src/utils/ui/colors.ts`，所有本地副本应删除并从中心导入。
- **修复代码**:

```typescript
// 替换所有本地定义
import { iconColor } from '@/utils/ui'
```

### 6.2 stripContent() 重复 8 次

- **文件**: browse/index.vue、search.vue（移动+PC）、FeedPostCard.vue、forum.vue、my-favorites.vue、my-collections.vue、topic-posts.vue
- **描述**: 应抽取为 `src/utils/text.ts` 中的共享函数。
- **修复代码**:

```typescript
// src/utils/text.ts
export function stripContent(text: string): string {
  if (!text) return ''
  try {
    if (text.startsWith('{"type":"doc"')) { /* TipTap JSON 解析逻辑 */ }
  } catch {}
  return text.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ')
}
```

---

## 七、功能增强建议（迭代优化）

### 7.1 PC 端功能缺口（高优先级）

| 缺失功能 | 移动端文件 | 影响 |
|----------|-----------|------|
| 版主中心 | `community/moderator-center.vue` | PC 管理员无法审核 |
| 通知中心 | `browse/notifications.vue` | PC 无通知查看入口 |
| 聊天室聊天 | `browse/chatroom-chat.vue` | PC 无实时群聊 |
| 商城 | `mall/detail.vue`, `orders.vue` | PC 无购物功能 |
| 合集创建 | `community/create-collection.vue` | PC 只能看不能建 |
| 计划发帖 | `browse/scheduled-posts.vue` | PC 无定时发布 |

### 7.2 PC 用户资料不完整

- **文件**: `src/themes/pc/default/views/appstore/profile.vue`（156行）
- **描述**: 相比移动端（1867行），缺少：回复/关注/粉丝/收藏/礼物标签页、称号/头像框显示、背景图、关注/私信/打赏按钮。
- **建议**: 对齐移动端的资料页功能。

### 7.3 编辑器缺少功能

- **文件**: `src/components/editor/TipTapEditor.vue`
- **缺失**: 图片缩放调整、表格、视频直接嵌入（有 YouTube 但缺通用视频）、查找替换、水平线。

### 7.4 管理功能缺失

- **批量用户操作**：`src/views/system/user/index.vue` 有选中功能但无批量操作按钮
- **审核日志搜索**：`src/views/system/syslog/index.vue` 无关键字搜索、操作者/目标/IP 筛选
- **数据导出入口**：后端已有 CSV 导出端点，管理 UI 无按钮
- **社区仪表盘**：无帖子/评论趋势图表、审核统计面板

### 7.5 数据完整性加固

- 点赞/收藏/投币/禁言使用硬删除，无审计追踪
- `community_banned_users` 禁言记录被直接 DELETE
- 评论用 `status` 字段而非 `is_deleted`，与其他表不一致

---

## 八、日常开销监控（迭代优化）

### 8.1 聊天每 3 秒轮询

- **文件**: `discover-chat.vue`（移动+PC）、`chatroom-chat.vue`
- **描述**: 3 个位置各自 `setInterval(load, 3000)`，持续发送 HTTP GET。
- **建议**: 替换为 WebSocket 推送（`src/utils/socket/index.ts` 已有基础设施）或延长间隔至 10-15 秒。

### 8.2 WebSocket 心跳频繁

- **文件**: `src/utils/socket/index.ts` L45-L46
- **描述**: 每 5 秒心跳检测 + 每 10 秒 Ping 发送。
- **建议**: 页面不可见时暂停心跳（`document.hidden` + `visibilitychange` 事件）。

### 8.3 7 个服务端定时器常驻

- **文件**: `community.cjs:17`（60s）、`settlement.cjs:645`（60s）、`system.cjs:14`（5min）、`two-factor.cjs:41`（5min）、`rate-limit.cjs:11`（5min）、`ip-geo.cjs:264`（10min）、`scheduler.cjs:44`（60s 降级）
- **描述**: 其中社区计划发帖和结算自动确认每次执行都做 DB 查询。
- **建议**: 合并为统一调度器，社区定时任务添加 `if (hasPendingScheduled)` 短路判断。

---

## 九、代码规范（迭代优化）

### 9.1 50+ 处静默吞错误

- **文件**: 全局
- **描述**: `catch {}`、`catch { /* ignore */ }` 导致操作失败时用户无任何反馈。
- **建议**: 至少添加 `console.error` 和用户提示。

### 9.2 全局 console.log 残留

- **描述**: 多处开发调试日志未清理。
- **建议**: 使用 ESLint `no-console` 规则 + Vite `esbuild.drop` 配置自动移除。

### 9.3 main.ts 空 touchstart 监听器

- **文件**: `src/main.ts` L13-L17
- **描述**: 为 passive 优化添加的空白监听器，可用 CSS `touch-action` 替代。
- **修复代码**: 删除该 `document.addEventListener` 块。

---

## 十、补充：深度扫描追加发现

### 10.1 8 处 N+1 循环 DB 查询（补充）

| # | 文件 | 行号 | 模式 |
|---|------|------|------|
| . | notification.cjs | L181-L194 | 会话列表对每个对话做 3 条独立查询 |
| . | notification.cjs | L538-L543 | 敏感词逐条 SELECT 检查再 INSERT |
| . | collection.cjs | L109-L129 | 添加帖子到合集逐条验证 + 逐条 INSERT |
| . | collection.cjs | L578-L581 | 逐条 UPDATE 排序 |
| . | collection.cjs | L903-L905 | 逐条 UPDATE 分组移动 |
| . | system.cjs | L444-L453 | OAuth 配置逐条 upsert |
| . | appstore.cjs | L1260-L1498 | 3 处批量 INSERT IGNORE 逐条循环 |
| . | mall.cjs | L245-L286 | 创建订单逐商品循环（含自动发货+减库存） |

**统一修复方案**：循环 INSERT 改为 `INSERT INTO ... VALUES (...), (...), (...)` 批量插入；循环 SELECT 改为 `WHERE id IN (...)` 批量查询。

---

### 10.2 TypeScript `:any` 类型共 1791 处

最严重 10 文件：chatroom-chat.vue(58)、records.vue(55)、detail.vue(40)、mine.vue(36)、membership.vue(35)、post-detail.vue(32)、profile.vue(32)、section-manage.vue(28)、assets.vue(27)、post-edit.vue(25)

### 10.3 超大文件（前端 18 个 + 后端 7 个超过 800 行）

前端 1000+ 行文件：profile.vue(1867)、detail.vue(1756)、mine.vue(1624)、index.vue(1581)、chatroom-chat.vue(1530)、submissions/edit-form.vue(1433)、membership.vue(1267)、post-edit.vue(1222)、section-manage.vue(1142)、staticRoutes.ts(1141)、TipTapEditor.vue(1029)、user-manage.vue(1017)、my-favorites.vue(1001)

后端 1000+ 行文件：database.cjs(2189)、appstore.cjs(1956)、mall.cjs(1659)、chat-room.cjs(1498)、community-admin.cjs(1453)、content.cjs(1408)、collection.cjs(1370)

### 10.4 Console 日志泛滥

前端 ~80 处 console 调用，socket/index.ts(21处)、worktab.ts(16处)、moderator-center.vue(8处) 最为严重。后端 152 处，collection.cjs(44处)、plugins.cjs(22处) 最多。

### 10.5 缺失 JSDoc 的导出

| 文件 | 缺失项 |
|------|--------|
| `src/utils/ui/sanitize.ts` | sanitizeSvg, sanitizeHtml |
| `src/utils/ui/colors.ts` | 全部 10 个导出函数 |
| `src/utils/router.ts` | configureNProgress, setPageTitle, formatMenuTitle |
| `src/utils/imageCompressWorker.ts` | compressInWorker |

### 10.6 重复 API 请求

`/api/operation/membership-level/list` 被 11 处各自独立请求，`/api/sys-config/list` 被 5 处请求，应统一使用已有的 `cachedRequest` 工具。

### 10.7 .gitignore 缺失关键条目

**严重**：`.env`、`*.sql`、`backup/` 均未忽略。仓库中已有 3 个 SQL dump 文件（合计 ~1.9MB）。

---

## 最终汇总

| 严重等级 | 数量 | 类别 |
|---------|------|------|
| 致命 | 4 | 运行时崩溃、竞态数据不一致、孤儿数据 |
| 高（安全） | 9 | 未认证端点、XSS、CSRF、信息泄露、越权、.gitignore |
| 中 | 30+ | N+1 查询、内存泄漏、速率限制、超大文件、性能 |
| 低/迭代 | 40+ | any 类型、死代码、重复代码、功能增强、代码规范 |

**建议优先级**：致命 Bug → 安全漏洞 → N+1 / 竞态 → 超大文件拆分 → 性能优化 → 代码规范 → 功能增强
