# 需求文档 — 惩罚任务系统

## 简介

将违规处罚机制整合到现有任务管理系统中，扩展 `custom_tasks` 表支持惩罚型（expense）规则，建立事件驱动的统一处罚引擎，对社区、审核、封禁、用户行为、商城、应用商店、投票活动等 7 大模块的 30 条违规行为进行经验扣除和附加惩罚。

## 术语表

- **惩罚规则（Penalty Task）**：`custom_tasks` 表中 `direction='spend'` 的记录，定义违规行为与扣除经验的映射关系
- **正向任务（Earn Task）**：`custom_tasks` 表中 `direction='earn'` 的记录，现有正向奖励任务
- **处罚引擎（Penalty Engine）**：统一的事件处理函数，根据违规行为匹配惩罚规则并执行经验扣减
- **连续违规加成**：同一用户在同一违规范类别下多次触发的倍数惩罚机制
- **等级降级保护**：单日经验扣除超过阈值时触发的系统通知机制

## 需求

### 需求 1：数据库扩展

**用户故事：** AS 系统管理员, I want 在 `custom_tasks` 表中扩展惩罚相关字段，so that 正向任务和惩罚规则可以在同一管理界面维护。

#### 验收标准

1. `custom_tasks` 表 SHALL 新增 `direction` 字段，类型 `VARCHAR(10) DEFAULT 'earn'`，可选值 `earn` / `spend`
2. `custom_tasks` 表 SHALL 新增 `penalty_config` 字段，类型 `TEXT`，存储 JSON 格式的附加惩罚配置（如禁言时长、累计触发上限等）
3. `experience_records` 表 SHALL 新增 `type` 字段，类型 `VARCHAR(10) DEFAULT 'earn'`，可选值 `earn` / `expense`
4. `experience_records` 表 SHALL 新增 `task_id` 字段，类型 `INTEGER DEFAULT 0`，关联触发记录的任务 ID
5. 系统 SHALL 新建 `user_violation_counts` 表，包含 `user_id`, `task_id`, `count`, `last_time` 字段，用于追踪连续违规次数

### 需求 2：处罚引擎

**用户故事：** AS 系统开发者, I want 事件驱动的统一处罚引擎，so that 所有违规操作点只需发射事件即可自动匹配规则并执行扣分。

#### 验收标准

1. 系统 SHALL 在 `custom-task.cjs` 中新增 `executePenalty(userId, userName, violationActionType, metadata)` 函数
2. 当处罚引擎被调用时，系统 SHALL 查询 `custom_tasks` 表中 `direction='spend'` 且 `action_type` 匹配的启用规则
3. 当匹配到惩罚规则时，系统 SHALL 检查 `user_violation_counts` 表中该用户该规则的累计次数
4. 当累计次数大于 0 时，系统 SHALL 按 `penalty_config.multiplier` 配置对扣分值进行连续违规加成（默认 ×1.5，每次递增）
5. 系统 SHALL 调用 `deductExperience()` 函数执行经验扣减并写入 `experience_records`（type='expense'）
6. 系统 SHALL 更新 `user_violation_counts` 表的计数和时间
7. 系统 SHALL 检查 `penalty_config` 中的附加惩罚（如累计 N 次触发禁言），并执行对应操作
8. 系统 SHALL 发送系统通知告知用户经验被扣除及原因

### 需求 3：附加惩罚执行

**用户故事：** AS 社区管理员, I want 惩罚规则支持配置附加惩罚动作，so that 严重或累计违规可以触发禁言、禁发帖等附加制裁。

#### 验收标准

1. `penalty_config` JSON SHALL 支持 `additional_actions` 数组，每项包含 `trigger_count`（触发次数）和 `action`（动作类型）
2. 系统 SHALL 支持以下附加动作类型：`mute_post`（禁止发帖）、`mute_comment`（禁止评论）、`mute_all`（全站禁言）
3. 当附加动作触发时，系统 SHALL 记录持续时间（`duration_minutes`）并在到期后自动恢复
4. 系统 SHALL 在 `community_banned_users` 或新表中记录附加惩罚的状态和到期时间

### 需求 4：等级降级保护

**用户故事：** AS 普通用户, I want 当日经验扣除过多时收到预警通知，so that 我能及时了解账户异常并停止违规行为。

#### 验收标准

1. 系统 SHALL 在 `sys_config` 表中配置 `exp_daily_deduct_warning` 阈值（默认 500）
2. 当单次扣除完成后，系统 SHALL 查询当日该用户所有 `type='expense'` 的 `experience_records` 累计值
3. 当当日累计扣除超过阈值时，系统 SHALL 发送系统通知"你的经验值今日下降过快，请注意遵守社区规范"
4. 同一用户当日同一阈值 SHALL 仅触发一次通知

### 需求 5：管理员手动扣分

**用户故事：** AS 管理员, I want 在用户管理界面手动对用户执行经验扣分，so that 处理未覆盖的特殊违规场景。

#### 验收标准

1. `POST /api/user/update` 接口在处理 `experience` 字段减少时，系统 SHALL 自动写入 `experience_records` 表（type='expense', source='管理员手动调整'）
2. 系统 SHALL 提供 `POST /api/operation/penalty/manual` 接口，接受 `userId`, `amount`, `reason` 参数
3. 手动扣分接口 SHALL 支持 `skip_notification` 参数控制是否发送通知

### 需求 6：申诉恢复

**用户故事：** AS 普通用户, I want 申诉成功时自动恢复被扣除的经验值，so that 误判不会造成永久损失。

#### 验收标准

1. 当管理员审批申诉为"通过"（approve）时，系统 SHALL 查询该申诉相关时间段内的经验扣分记录
2. 系统 SHALL 补回被扣除的经验值并写入 `experience_records`（type='earn', source='申诉恢复'）
3. 系统 SHALL 发送通知告知用户经验已恢复

### 需求 7：前端管理界面

**用户故事：** AS 管理员, I want 在现有任务管理页面中管理惩罚规则，so that 正向任务和惩罚规则统一维护。

#### 验收标准

1. `task-manage.vue` 页面 SHALL 支持按 `direction`（earn/spend）筛选任务列表
2. 新增/编辑任务弹窗 SHALL 包含 `direction` 切换开关
3. 当 `direction='spend'` 时，弹窗 SHALL 展示附加惩罚配置面板（累计触发禁言、连续违规加成倍率等）
4. `action_type` 下拉在 `direction='spend'` 时 SHALL 展示违规行为类型列表（post_rejected, comment_deleted, report_verified 等）
5. 惩罚规则列表 SHALL 在奖励区域显示扣除经验值（红色样式）

### 需求 8：30 条预置惩罚规则

**用户故事：** AS 系统初始化者, I want 系统首次启动时预置 30 条默认惩罚规则，so that 管理员无需从零配置即可使用处罚功能。

#### 验收标准

1. 系统 SHALL 在 `seed.cjs` 中预置 30 条惩罚规则，`direction='spend'`, `status='1'`
2. 预置规则 SHALL 覆盖社区（C1-C9）、举报审核（R1-R3）、封禁处罚（B1-B6）、用户行为（U1-U4）、商城交易（M1-M4）、应用商店（A1-A2）、投票活动（V1-V2）7 个模块
3. 每条预置规则 SHALL 包含默认扣分值、连续违规加成倍率、附加惩罚配置
4. 管理员 SHALL 可以修改或禁用任意预置规则

### 需求 9：事件触发点改造

**用户故事：** AS 系统开发者, I want 在所有违规操作点接入处罚引擎，so that 违规行为自动触发对应的经验扣除。

#### 验收标准

1. 以下操作点 SHALL 在业务逻辑完成后发射违规事件或直接调用处罚引擎：
   - 帖子驳回（`community/moderation-queue.cjs`）
   - 帖子删除（`community/community-admin.cjs`）
   - 帖子锁定（`community/community-admin.cjs`）
   - 评论删除（`community/community-interactions.cjs`）
   - 敏感词阻断（`community/sensitive_words` 相关）
   - 举报通过（举报审核 `approve`）
   - 恶意举报（举报 `reject` + 反查）
   - 申诉驳回（申诉 `reject`）
   - 管理员封禁（`user-block.cjs`）
   - 自动封禁（`community_auto_bans` 相关）
   - 聊天室踢出/禁言（`chat-room.cjs`）
   - 私信骚扰核实（私信举报）
   - 头像/昵称/签名强制清除（用户资料审核）
   - 商城评价删除（`mall.cjs`）
   - 商品下架（`mall.cjs`）
   - 应用驳回（`appstore.cjs`）
   - 应用下架（`appstore.cjs`）
   - 投票作弊检测（`vote.cjs`）
   - 活动作弊检测（`campaign.cjs`）
2. 每个触发点 SHALL 传入对应的 `violationActionType` 和必要的 `metadata`（如被操作内容 ID、操作原因等）

### 需求 10：扣分日志与统计

**用户故事：** AS 管理员, I want 查看用户的经验扣分历史和违规统计，so that 评估用户的社区行为表现。

#### 验收标准

1. `GET /api/operation/penalty/logs` 接口 SHALL 支持按 `userId`, `taskId`, `startTime`, `endTime` 筛选查询
2. `GET /api/operation/penalty/stats` 接口 SHALL 返回指定时间段内各惩罚规则的触发次数和总扣分值
3. 用户个人中心的经验流水 SHALL 区分 `earn` / `expense` 类型并以不同颜色展示
