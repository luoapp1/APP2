# 惩罚任务系统

Feature Name: penalty-task-system
Updated: 2026-07-20

## Description

扩展现有 `custom_tasks` 任务系统，增加惩罚型（spend）规则支持。建立事件驱动的统一处罚引擎 `executePenalty()`，在各业务模块的违规操作点接入，实现经验自动扣除、连续违规加成、附加惩罚执行、等级降级保护和申诉恢复机制。

## Architecture

```mermaid
graph TD
    A["用户违规行为"] --> B["业务模块检测"]
    B --> C["发射违规事件 或 直接调用"]
    C --> D["executePenalty() 处罚引擎"]

    D --> E["匹配 custom_tasks direction=spend 规则"]
    E --> F["查询 user_violation_counts 累计次数"]
    F --> G["计算扣分值 基础扣分 x 连续违规倍率"]
    G --> H["deductExperience() 执行扣分"]
    H --> I["UPDATE users.experience"]
    H --> J["INSERT experience_records type=expense"]
    G --> K["UPDATE user_violation_counts 计数+1"]

    G --> L{"penalty_config 附加惩罚?"}
    L -->|累计 N 次触发| M["执行禁言/禁发帖/禁评论"]
    M --> N["写入 community_banned_users"]

    G --> O{"当日累计扣除 > 阈值?"}
    O -->|是| P["发送等级降级保护通知"]

    H --> Q["发送经验扣除通知"]
```

### 处罚引擎工作流程

```mermaid
flowchart TD
    A["executePenalty(userId, userName, actionType, metadata)"] --> B{"查询匹配的 spend 规则"}
    B -->|无匹配| C["结束，无惩罚"]
    B -->|有匹配| D{"检查规则 status"}
    D -->|disabled| C
    D -->|enabled| E["获取 user_violation_counts"]
    E --> F["count = existingCount + 1"]
    F --> G["multiplier = 1 + (count - 1) x penalty_config.step_multiplier"]
    G --> H["finalAmount = baseAmount x multiplier"]
    H --> I["deductExperience(userId, userName, finalAmount, source, desc)"]
    I --> J["保存/更新 user_violation_counts"]
    J --> K{"penalty_config.additional_actions?"}
    K -->|有| L{"count >= trigger_count?"}
    L -->|是| M["执行附加动作 mute_post/mute_comment/mute_all"]
    L -->|否| N["跳过"]
    K -->|无| N
    M --> O["检查日累计扣除阈值"]
    N --> O
    O --> P{"日累计 > 500?"}
    P -->|是| Q["发送降级保护通知"]
    P -->|否| R["发送扣除通知"]
    Q --> S["结束"]
    R --> S
```

## Components and Interfaces

### 1. 数据库迁移

#### 1.1 `custom_tasks` 表增加字段

```sql
ALTER TABLE custom_tasks
  ADD COLUMN IF NOT EXISTS direction VARCHAR(10) DEFAULT 'earn' COMMENT 'earn=正向奖励 spend=惩罚扣分',
  ADD COLUMN IF NOT EXISTS penalty_config TEXT COMMENT '惩罚配置JSON',
  ADD COLUMN IF NOT EXISTS start_time DATETIME NULL,
  ADD COLUMN IF NOT EXISTS end_time DATETIME NULL;
```

**`penalty_config` JSON 结构**：
```json
{
  "step_multiplier": 0.5,
  "max_multiplier": 5.0,
  "additional_actions": [
    {
      "trigger_count": 3,
      "action": "mute_post",
      "duration_minutes": 120
    }
  ],
  "daily_deduction_limit": 500
}
```

#### 1.2 `experience_records` 表增加字段

```sql
ALTER TABLE experience_records
  ADD COLUMN IF NOT EXISTS type VARCHAR(10) DEFAULT 'earn' COMMENT 'earn=获得 expense=扣除',
  ADD COLUMN IF NOT EXISTS task_id INTEGER DEFAULT 0 COMMENT '关联惩罚规则ID';
```

#### 1.3 新建 `user_violation_counts` 表

```sql
CREATE TABLE IF NOT EXISTS user_violation_counts (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  user_id INTEGER NOT NULL,
  task_id INTEGER NOT NULL,
  count INTEGER DEFAULT 0,
  last_time DATETIME DEFAULT NOW(),
  UNIQUE KEY uk_user_task (user_id, task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 2. 核心模块

#### 2.1 `server/routes/custom-task.cjs` — 惩罚引擎核心

**新增函数**：

| 函数 | 签名 | 功能 |
|------|------|------|
| `executePenalty` | `(userId, userName, actionType, metadata)` | 入口函数，匹配规则并执行全套处罚流程 |
| `calculatePenaltyAmount` | `(baseAmount, currentCount, penaltyConfig)` | 计算连续违规加成后的最终扣分值 |
| `executeAdditionalActions` | `(userId, actionType, penaltyConfig, currentCount)` | 检查并执行附加惩罚动作 |
| `checkDailyLimit` | `(userId, threshold)` | 检查当日累计扣除是否超过阈值 |
| `deductExperience` | `(userId, userName, amount, source, description)` | 执行经验扣减并记录流水 |
| `restoreExperience` | `(userId, userName, amount, source, description)` | 申诉成功后恢复经验 |

**路由扩展**：

| 方法 | 路径 | 功能 |
|------|------|------|
| GET | `/api/operation/penalty/logs` | 扣分日志查询 |
| GET | `/api/operation/penalty/stats` | 惩罚统计 |
| POST | `/api/operation/penalty/manual` | 管理员手动扣分 |

#### 2.2 `server/routes/account-utils.cjs` — 新增扣除函数

```javascript
async function deductExperience(userId, userName, amount, source, description) {
  // 扣减 users.experience (GREATEST(0, ...))
  // 写入 experience_records (type='expense')
}

async function addExperience(userId, userName, amount, source, description) {
  // 增加 users.experience
  // 写入 experience_records (type='earn')
}
```

### 3. 事件触发点接入

| 文件 | 违规行为 | actionType | 接入位置 |
|------|---------|-----------|---------|
| `community/moderation-queue.cjs` | 帖子驳回 | `post_rejected` | 驳回操作后 |
| `community/community-admin.cjs` | 帖子删除 | `post_deleted` | 删除操作后 |
| `community/community-admin.cjs` | 帖子锁定 | `post_locked` | 锁定操作后 |
| `community/community-interactions.cjs` | 评论删除 | `comment_deleted` | 删除操作后 |
| 敏感词中间件 | 违规内容 | `block_word_triggered` | 拦截后 |
| `abuse-admin.cjs` | 举报核实 | `report_verified` | approve 后 |
| `abuse-admin.cjs` | 恶意举报 | `report_abuse` | reject + 反查后 |
| `appeals.cjs` | 申诉驳回 | `appeal_rejected` | reject 后 |
| `user-block.cjs` | 管理员封禁 | `admin_banned` | 封禁后 |
| `community_auto_bans` | 自动封禁 | `auto_banned` | 触发后 |
| `chat-room.cjs` | 聊天室踢出 | `chat_kicked` | 踢出后 |
| `chat-room-admin.cjs` | 聊天室封禁 | `chat_banned` | 封禁后 |
| 私信举报 | 私信骚扰 | `dm_harassment` | 举报核实后 |
| 用户资料审核 | 资料违规 | `profile_violation` | 强制清除后 |
| `mall.cjs` | 恶意差评 | `review_malicious` | 举报核实后 |
| `mall.cjs` | 商品欺诈 | `product_fraud` | 下架后 |
| `mall.cjs` | 恶意退款 | `refund_abuse` | 检测到后 |
| `appstore.cjs` | 应用驳回 | `app_rejected` | 驳回后 |
| `appstore.cjs` | 应用下架 | `app_takedown` | 下架后 |
| `vote.cjs` | 投票作弊 | `vote_cheat` | 检测后 |
| `campaign.cjs` | 活动作弊 | `campaign_cheat` | 检测后 |

### 4. 前端组件改造

#### 4.1 `src/themes/mobile/default/views/appstore/admin/task-manage.vue`

新增内容：
- 筛选栏增加 `direction` 筛选（全部 / 奖励 / 惩罚）
- 列表项增加方向标签（绿色"奖励" / 红色"惩罚"）
- 编辑弹窗增加 `direction` 开关
- `direction='spend'` 时展示：
  - 扣分值输入（替代奖励值）
  - 连续违规加成配置面板
  - 附加惩罚配置（累计次数 + 禁言类型 + 时长）
  - 日扣除上限配置
- `action_type` 在 spend 模式下列出违规行为类型

#### 4.2 `src/api/task.ts`

新增接口调用：
```typescript
fetchPenaltyLogs(params)  → GET  /api/operation/penalty/logs
fetchPenaltyStats(params) → GET  /api/operation/penalty/stats
manualPenalty(data)       → POST /api/operation/penalty/manual
```

## Data Models

### custom_tasks 惩罚型记录示例

```json
{
  "id": 101,
  "name": "帖子被驳回",
  "direction": "spend",
  "action_type": "post_rejected",
  "exp_reward": 30,
  "penalty_config": {
    "step_multiplier": 0.5,
    "additional_actions": [
      {
        "trigger_count": 3,
        "action": "mute_post",
        "duration_minutes": 120
      }
    ]
  },
  "status": "1"
}
```

### user_violation_counts 记录示例

```json
{
  "user_id": 5,
  "task_id": 101,
  "count": 3,
  "last_time": "2026-07-20 15:30:00"
}
```

### experience_records 惩罚记录示例

```json
{
  "user_id": 5,
  "user_name": "user5",
  "amount": -67,
  "type": "expense",
  "source": "帖子被驳回（第3次，x1.5加成）",
  "task_id": 101
}
```

## Correctness Properties

- 经验值下限始终为 0（`GREATEST(0, experience - amount)`）
- 同一用户同一惩罚规则在同一时间窗口内不会重复计数（由 user_violation_counts 唯一约束保证）
- 处罚引擎调用是幂等的——同一违规事件不会触发两次扣分
- 连续违规计数在 `user_violation_counts.count` 中原子递增
- 申诉恢复仅恢复已扣分记录的对应经验值，不会重复恢复

## Error Handling

| 错误场景 | 处理方式 |
|---------|---------|
| 未匹配到惩罚规则 | 静默跳过，不影响原有业务流程 |
| 用户不存在 | 记录警告日志，跳过扣分 |
| 经验值已为 0 | 扣分后保持为 0，不报错 |
| 数据库写入失败 | 回滚扣分操作，上报错误日志 |
| 并发冲突 | 依赖 `user_violation_counts` 唯一约束和数据库行锁 |

## Test Strategy

- 单元测试：`deductExperience()` / `calculatePenaltyAmount()` 函数
- 集成测试：`executePenalty()` 完整流程（模拟违规事件）
- 回归测试：确保正向 `progressTasksByAction` 不受影响
- 前端测试：惩罚规则 CRUD 流程、列表筛选
