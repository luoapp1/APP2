# 需求文档：商城装饰品升级

## 概述

将头像框、称号、头像特效、评论背景墙、昵称特效五种装饰类型接入商城系统，支持用户通过积分/余额购买获得装饰品，并新增统一的装扮管理页面。

## 术语表

- **装饰品**：头像框、称号、头像特效、评论背景墙、昵称特效的统称
- **装扮**：用户已拥有且当前佩戴中的装饰品状态
- **装饰类型**：avatar_frame / title / avatar_effect / comment_background / nickname_effect
- **product_subtype**：商城商品与装饰类型的映射字段

---

## 需求

### 需求 1：头像框接入商城

**用户故事：** AS 普通用户，I want 通过商城购买头像框，so that 我能用积分或余额获得更多头像框装饰。

#### 验收标准

1. WHEN 管理员在商城创建商品并选择 product_subtype 为 avatar_frame，系统 SHALL 显示已有头像框列表供选择绑定
2. WHEN 用户完成支付，系统 SHALL 自动在 user_avatar_frames 表中插入记录，obtain_type 标记为 "mall"
3. WHEN 用户已拥有该头像框，系统 SHALL 阻止重复购买并提示"已拥有"
4. IF 支付失败，系统 SHALL 回滚订单状态且不授予头像框

### 需求 2：称号接入商城

**用户故事：** AS 普通用户，I want 通过商城购买称号，so that 我能用积分或余额获得更多称号标识。

#### 验收标准

1. WHEN 管理员在商城创建商品并选择 product_subtype 为 title，系统 SHALL 显示已有称号列表供选择绑定
2. WHEN 用户完成支付，系统 SHALL 自动在 user_titles 表中插入记录，grant_by 标记为 "mall"
3. WHEN 用户已拥有该称号，系统 SHALL 阻止重复购买并提示"已拥有"
4. IF 称号设置了有效期，系统 SHALL 在授予时计算 expire_time

### 需求 3：头像特效管理模块

**用户故事：** AS 管理员，I want 上传和管理头像特效资源，so that 用户可以购买和使用头像周围动态特效。

#### 验收标准

1. WHEN 管理员访问头像特效管理页，系统 SHALL 展示所有头像特效列表（名称、预览图、状态、创建时间）
2. WHEN 管理员点击新增，系统 SHALL 允许上传特效资源文件和预览图，填写名称
3. WHEN 管理员保存特效，系统 SHALL 将特效信息写入 decorations 表（type=avatar_effect）
4. WHEN 管理员启用/禁用某特效，系统 SHALL 立即生效且已被购买的用户不受影响
5. WHEN 管理员删除某特效，IF 该特效已被购买，系统 SHALL 先提示确认

### 需求 4：评论背景墙管理模块

**用户故事：** AS 管理员，I want 上传和管理评论背景墙资源，so that 用户可以购买个性化评论背景。

#### 验收标准

1. WHEN 管理员访问评论背景墙管理页，系统 SHALL 展示所有背景墙列表（名称、预览图、状态、创建时间）
2. WHEN 管理员点击新增，系统 SHALL 允许上传背景图片和填写名称、适用场景描述
3. WHEN 管理员保存背景墙，系统 SHALL 将信息写入 decorations 表（type=comment_background）

### 需求 5：昵称特效管理模块

**用户故事：** AS 管理员，I want 配置和管理昵称特效，so that 用户可以购买个性化昵称样式。

#### 验收标准

1. WHEN 管理员访问昵称特效管理页，系统 SHALL 展示所有昵称特效列表（名称、预览图、状态、CSS 类名）
2. WHEN 管理员点击新增，系统 SHALL 允许配置特效参数（文字颜色、渐变、描边、阴影等）和上传预览图
3. WHEN 管理员保存昵称特效，系统 SHALL 将特效配置 JSON 写入 decorations 表（type=nickname_effect）

### 需求 6：统一装扮管理页面（用户端）

**用户故事：** AS 普通用户，I want 在一个页面集中管理所有装饰品，so that 我能方便地切换佩戴的头像框、称号、特效、背景等。

#### 验收标准

1. WHEN 用户访问装扮管理页，系统 SHALL 以 Tab 形式展示 5 种装饰类型
2. WHILE 用户在头像框 Tab，系统 SHALL 展示已拥有头像框列表，当前佩戴的标记为"使用中"
3. WHEN 用户点击某头像框，系统 SHALL 立即激活该头像框并更新 users.active_frame_id
4. WHEN 用户点击佩戴中的装饰品，系统 SHALL 取消佩戴恢复默认状态
5. WHILE 用户在头像特效/评论背景/昵称特效 Tab，系统 SHALL 展示已拥有的对应装饰品

### 需求 7：商城商品创建流程适配

**用户故事：** AS 管理员，I want 在创建商城商品时能选择装饰类型并绑定具体装饰品，so that 用户能通过商城购买装饰品。

#### 验收标准

1. WHEN 管理员选择 product_subtype 为装饰类型时，系统 SHALL 展示对应装饰品选择器
2. WHEN 管理员选中某装饰品后，系统 SHALL 自动填充商品名称、描述和图片为该装饰品的信息
3. WHEN 商品详情页展示装饰类商品，系统 SHALL 提供"试穿"预览功能

### 需求 8：购买后自动发货

**用户故事：** AS 系统，I want 在用户支付装饰类商品后自动授予装饰品，so that 用户体验流畅无需等待。

#### 验收标准

1. WHEN 订单支付成功且 product_subtype 为装饰类型，系统 SHALL 自动在对应关联表中插入记录
2. WHEN 发货成功，系统 SHALL 发送系统通知告知用户已获得装饰品
3. IF 发货失败，系统 SHALL 记录错误日志并通知管理员

### 需求 9：装饰品有效期管理

**用户故事：** AS 管理员，I want 设置装饰品的有效期，so that 能实现限时装饰品的运营策略。

#### 验收标准

1. WHEN 管理员创建装饰品，系统 SHALL 允许设置有效期（天），0 表示永久
2. WHILE 装饰品临近过期（剩余 3 天），系统 SHALL 发送通知提醒用户
3. WHEN 装饰品过期，系统 SHALL 自动卸下该装饰品并恢复默认状态

---

## 非功能性需求

1. 统一采用 `decorations` 表管理头像特效、评论背景墙、昵称特效三种新装饰类型
2. 管理页模板复用已有的头像框管理页模式（avatar-frame-manage.vue）
3. 文件上传复用已有的 upload 接口和 multer 中间件
4. 前端特效渲染采用纯 CSS 方案，昵称特效使用 CSS text-shadow / background-clip，头像特效使用 CSS animation
5. 装饰品购买防重校验在支付环节完成
