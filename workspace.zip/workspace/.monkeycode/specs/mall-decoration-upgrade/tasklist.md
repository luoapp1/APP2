# 需求实施计划

- [ ] 1. 数据库变更
  - [ ] 1.1 在 database.cjs 的 initTables 中添加 decorations 表和 user_decorations 表的建表语句
    - decorations 表支持 avatar_effect / comment_background / nickname_effect 三种 type
    - user_decorations 表关联用户与装饰品
  - [ ] 1.2 在 database.cjs 中添加 users 表新增字段的 ALTER 语句（active_avatar_effect_id, active_comment_background_id, active_nickname_effect_id）
  - [ ] 1.3 在 database.cjs 中添加 mall_products 表新增字段的 ALTER 语句（product_subtype, decoration_id, duration_days）

- [ ] 2. 后端装饰品管理 API
  - [ ] 2.1 创建 server/routes/decoration.cjs，实现 decorations 表的 CRUD
    - GET /api/decoration/list?type=xxx 按类型获取启用列表
    - GET /api/decoration/all?type=xxx 管理员获取全部
    - POST /api/decoration/save 新增/编辑
    - DELETE /api/decoration/:id 删除
    - POST /api/decoration/upload 上传资源文件
  - [ ] 2.2 在 server/index.cjs 中注册 decorationRoutes

- [ ] 3. 后端用户装扮 API
  - [ ] 3.1 创建 server/routes/user-decoration.cjs，实现用户装扮管理
    - GET /api/user/decorations?type=xxx 获取用户拥有的装饰品列表
    - POST /api/user/activate-decoration 激活/取消装饰品（更新 users 表对应字段）
    - GET /api/user/all-decorations 获取用户所有类型装扮状态汇总
  - [ ] 3.2 在 server/index.cjs 中注册 userDecorationRoutes

- [ ] 4. 检查点 - 数据库和后端 API 可通过手动测试验证

- [ ] 5. 商城发货机制适配
  - [ ] 5.1 在 server/routes/mall.cjs 中实现 grantDecoration 函数
    - 根据 product_subtype 分发到 user_avatar_frames / user_titles / user_decorations 表
    - 使用 INSERT IGNORE 防重
  - [ ] 5.2 在虚拟商品支付成功回调中调用 grantDecoration
    - 在 /api/mall/orders/:id/pay 支付成功后增加 decoration 类型商品的处理分支

- [ ] 6. 前端新管理页面
  - [ ] 6.1 创建 src/views/operation/avatar-effect/index.vue 头像特效管理页
    - 表格展示（名称、预览图、状态开关、操作列）
    - 新增/编辑弹窗（名称、特效资源上传、预览图上传、有效期设置）
  - [ ] 6.2 创建 src/views/operation/comment-background/index.vue 评论背景墙管理页
    - 表格展示同 6.1
    - 新增/编辑弹窗（名称、背景图片上传、预览图、描述）
  - [ ] 6.3 创建 src/views/operation/nickname-effect/index.vue 昵称特效管理页
    - 表格展示同 6.1
    - 新增/编辑弹窗（名称、CSS 类名、特效参数 JSON 配置、预览图上传）

- [ ] 7. 前端装扮管理页面
  - [ ] 7.1 创建 src/themes/mobile/default/views/appstore/decoration/index.vue
    - Tab 切换 5 种装饰类型
    - 每个 Tab 展示已拥有装饰品网格（预览图+名称+激活按钮）
    - 支持激活/取消佩戴

- [ ] 8. 商城商品创建页适配
  - [ ] 8.1 修改 mall-product-create.vue，增加 product_subtype 选择下拉
    - 选项：avatar_frame / title / avatar_effect / comment_background / nickname_effect
  - [ ] 8.2 在 mall-product-create.vue 中实现装饰品选择器弹窗
    - 根据选择的 product_subtype 调用对应 API 获取列表
    - 选中后自动填充商品名称、描述、图片
  - [ ] 8.3 提交时携带 product_subtype、decoration_id、duration_days 字段

- [ ] 9. 菜单与路由配置
  - [ ] 9.1 在 src/router/modules/operation.ts 中新增三个管理页路由
  - [ ] 9.2 在 src/router/modules/appstore.ts（或相应文件）中新增装扮管理页路由

- [ ] 10. 检查点 - 验证完整流程（管理创建装饰品 → 上架商城商品 → 用户购买 → 装扮激活）
