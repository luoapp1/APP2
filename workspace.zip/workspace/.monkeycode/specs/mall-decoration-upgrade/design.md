# 技术设计文档：商城装饰品升级

Feature Name: mall-decoration-upgrade
Updated: 2026-07-24

## 1. 概述

将五种装饰类型（头像框、称号、头像特效、评论背景墙、昵称特效）接入商城系统，新增三个管理模块和统一装扮管理页面。

## 2. 架构

```mermaid
graph TD
    A["商城管理端"] --> B["创建/编辑商品"]
    B --> C["选择 product_subtype"]
    C --> D["弹出装饰品选择器"]
    D --> E1["头像框列表"]
    D --> E2["称号列表"]
    D --> E3["头像特效列表"]
    D --> E4["评论背景列表"]
    D --> E5["昵称特效列表"]

    F["用户浏览商城"] --> G["商品详情"]
    G --> H["试穿预览"]
    G --> I["购买"]
    I --> J["支付"]
    J --> K["自动发货 grantDecoration"]

    L["用户装扮管理"] --> M["Tab切换 5 类装饰"]
    M --> N["激活/取消佩戴"]

    O["管理员"] --> P1["头像特效管理页"]
    O --> P2["评论背景管理页"]
    O --> P3["昵称特效管理页"]
```

## 3. 数据模型

### 3.1 新增表：decorations

```sql
CREATE TABLE decorations (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  type VARCHAR(30) NOT NULL COMMENT 'avatar_effect / comment_background / nickname_effect',
  name VARCHAR(100) NOT NULL,
  image_url VARCHAR(500) DEFAULT '' COMMENT '预览图',
  preview_url VARCHAR(500) DEFAULT '' COMMENT '效果预览图',
  config_json TEXT COMMENT '特效配置JSON',
  css_class VARCHAR(100) DEFAULT '' COMMENT 'CSS类名',
  description VARCHAR(500) DEFAULT '',
  obtain_type VARCHAR(20) DEFAULT 'manual',
  duration_days INT DEFAULT 0 COMMENT '有效期天数，0=永久',
  status VARCHAR(2) DEFAULT '1',
  sort_order INT DEFAULT 0,
  create_time DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
```

### 3.2 新增表：user_decorations

```sql
CREATE TABLE user_decorations (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  user_id INTEGER NOT NULL,
  decoration_id INTEGER NOT NULL,
  decoration_type VARCHAR(30) NOT NULL,
  is_active TINYINT(1) DEFAULT 0,
  obtain_type VARCHAR(20) DEFAULT 'manual',
  expire_time DATETIME NULL,
  create_time DATETIME DEFAULT NOW(),
  UNIQUE KEY uix_user_decoration (user_id, decoration_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
```

### 3.3 users 表新增字段

```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS active_avatar_effect_id INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS active_comment_background_id INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS active_nickname_effect_id INT DEFAULT 0;
```

### 3.4 现有表 mall_products 新增字段

```sql
ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS product_subtype VARCHAR(30) DEFAULT '';
ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS decoration_id INT DEFAULT 0;
ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS duration_days INT DEFAULT 0;
```

## 4. 组件与接口

### 4.1 后端新增文件

| 文件 | 说明 |
|------|------|
| `server/routes/decoration.cjs` | 统一的装饰品 CRUD API |
| `server/database.cjs` | 在 initTables 中新增 decorations、user_decorations 建表语句 |

### 4.2 后端新增 API

#### 装饰品管理 API（/api/decoration）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/decoration/list?type=xxx` | 按类型获取启用装饰品列表 |
| GET | `/api/decoration/all?type=xxx` | 管理员获取全部装饰品 |
| POST | `/api/decoration/save` | 新增/编辑装饰品 |
| DELETE | `/api/decoration/:id` | 删除装饰品 |
| POST | `/api/decoration/upload` | 上传装饰品资源文件 |

#### 用户装扮 API（/api/user）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/user/decorations?type=xxx` | 获取用户拥有的装饰品 |
| POST | `/api/user/activate-decoration` | 激活/取消装饰品 |
| GET | `/api/user/all-decorations` | 获取用户所有类型的装扮状态 |

### 4.3 前端新增文件

| 文件 | 说明 |
|------|------|
| `src/views/operation/avatar-effect/index.vue` | 头像特效管理页 |
| `src/views/operation/comment-background/index.vue` | 评论背景墙管理页 |
| `src/views/operation/nickname-effect/index.vue` | 昵称特效管理页 |
| `src/themes/mobile/default/views/appstore/decoration/index.vue` | 用户装扮管理页 |

### 4.4 前端修改文件

| 文件 | 修改内容 |
|------|----------|
| `src/themes/mobile/default/views/appstore/admin/mall/mall-product-create.vue` | 增加 product_subtype 选择和装饰品选择器 |
| `server/routes/mall.cjs` | 增加 decoration 类型发货逻辑 |
| `src/router/modules/operation.ts` | 新增三个管理页路由 |
| `src/router/modules/appstore.ts` | 新增装扮管理页路由 |

## 5. 核心流程

### 5.1 管理员上架装饰品商品

```mermaid
sequenceDiagram
    participant Admin as 管理员
    participant UI as 商品创建页
    participant API as mall API
    participant DecAPI as decoration API

    Admin->>UI: 选择 product_subtype = "avatar_frame"
    UI->>DecAPI: GET /api/avatar-frame/all
    DecAPI-->>UI: 返回头像框列表
    Admin->>UI: 选择具体头像框，设置价格
    UI->>API: POST /api/mall/products (含 product_subtype, decoration_id, target_name)
    API-->>UI: 返回商品信息
```

### 5.2 用户购买装饰品商品

```mermaid
sequenceDiagram
    participant User as 用户
    participant Mall as 商城
    participant Pay as 支付模块
    participant Grant as 发货模块

    User->>Mall: 下单装饰品商品
    Mall->>Pay: 扣余额/积分
    Pay-->>Mall: 支付成功
    Mall->>Grant: grantDecoration(userId, product)
    Grant->>Grant: INSERT user_avatar_frames / user_titles / user_decorations
    Grant->>Grant: 发送系统通知
    Mall-->>User: 购买成功，已获得装饰品
```

### 5.3 发货函数 grantDecoration

```javascript
async function grantDecoration(userId, userName, product) {
  const { product_subtype, decoration_id, target_id, target_name, duration_days } = product

  switch (product_subtype) {
    case 'avatar_frame':
      await query(
        'INSERT IGNORE INTO user_avatar_frames (user_id, frame_id, is_active, obtain_type) VALUES (?,?,0,"mall")',
        [userId, decoration_id]
      )
      break
    case 'title':
      await query(
        'INSERT IGNORE INTO user_titles (user_id, title_id, is_active, grant_by) VALUES (?,?,1,"mall")',
        [userId, decoration_id]
      )
      break
    case 'avatar_effect':
    case 'comment_background':
    case 'nickname_effect':
      const expireTime = duration_days > 0
        ? new Date(Date.now() + duration_days * 86400000)
        : null
      await query(
        'INSERT IGNORE INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type, expire_time) VALUES (?,?,?,1,"mall",?)',
        [userId, decoration_id, product_subtype, expireTime]
      )
      break
  }
}
```

## 6. 前端组件设计

### 6.1 装饰品管理页（通用模板）

三个新模块的管理页结构相同，复用 avatar-frame-manage.vue 的模式：

```
模板结构：
├── 顶部操作栏（新增按钮、搜索）
├── 数据表格（图标列、名称、状态开关、操作列）
└── 新增/编辑弹窗（名称、图片上传、参数配置、有效期设置）
```

### 6.2 装扮管理页

```
模板结构：
├── Tab 栏（头像框 | 称号 | 头像特效 | 评论背景 | 昵称特效）
└── 每个 Tab：
    ├── 当前佩戴的装饰品（高亮显示"使用中"）
    ├── 装饰品网格列表（预览图 + 名称 + 点击激活按钮）
    └── 未拥有的装饰品灰色显示，引导去商城购买
```

### 6.3 装饰品选择器组件

可复用组件，用于商城商品创建时选择装饰品：

```vue
<DecorationPicker
  :decoration-type="productSubtype"
  v-model="selectedDecoration"
/>
```

内部根据 type 调用对应的 API 获取列表，展示预览图和名称。

## 7. 错误处理

| 场景 | 处理策略 |
|------|----------|
| 重复购买 | INSERT IGNORE 防重，返回"已拥有"提示 |
| 支付失败 | 事务回滚，不授予装饰品 |
| 发货失败 | 记录错误日志，返回明确错误信息，订单标记为异常待处理 |
| 装饰品被删除但用户已拥有 | user_decorations 保留记录，用户仍可使用（软删除策略） |
| 过期装饰品仍在使用 | 登录时检查并自动卸下 |

## 8. 测试策略

| 测试类型 | 覆盖内容 |
|----------|----------|
| 单元测试 | grantDecoration 函数各种 product_subtype 分支 |
| API 测试 | decoration CRUD、用户装扮切换、购买流程 |
| 集成测试 | 完整购买-发货-装扮-切换流程 |

## 9. 菜单路由规划

```
运营管理 (menu_id=2)
├── ...
├── 头像框管理     /operation/avatar-frame       (已有)
├── 称号管理       /operation/title              (已有)
├── 头像特效管理   /operation/avatar-effect      (新增)
├── 评论背景管理   /operation/comment-background  (新增)
└── 昵称特效管理   /operation/nickname-effect    (新增)

应用中心
└── 我的装扮       /appstore/my-decorations      (新增)
```

## 10. 参考文件

- 商城 API: `当前工作区` `/server/routes/mall.cjs`
- 头像框管理 API: `当前工作区` `/server/routes/avatar-frame.cjs`
- 称号管理 API: `当前工作区` `/server/routes/title.cjs`
- 头像框管理前端: `当前工作区` `/src/themes/mobile/default/views/appstore/admin/avatar-frame-manage.vue`
- 商城商品创建: `当前工作区` `/src/themes/mobile/default/views/appstore/admin/mall/mall-product-create.vue`
- 操作管理路由: `当前工作区` `/src/router/modules/operation.ts`
