# "我的"页面功能增强

Feature Name: mine-page-enhancements
Updated: 2026-07-18

## 描述

为 Art Design Pro 社区平台的"我的"页面增加草稿箱、帖子删除与回收、用户黑名单三个功能模块。复用现有后端 API 和数据库表结构，主要工作集中在前端 UI 实现和部分后端查漏补缺。

## 架构

```mermaid
graph TD
    A["Mobile 我的页面 (mine.vue)"] --> B["草稿箱入口"]
    A --> C["黑名单入口"]
    B --> D["草稿列表页 (drafts.vue)"]
    D --> E["GET /api/community/drafts"]
    D --> F["DELETE /api/community/draft/:id"]
    D --> G["跳转帖子编辑页 (post-edit + draftId)"]
    C --> H["黑名单列表页 (blocklist.vue)"]
    H --> I["GET /api/user/blocked"]
    H --> J["DELETE /api/user/:id/block"]
    K["帖子详情页 (post-detail.vue)"] --> L["删除按钮"]
    L --> M["POST /api/community/post/:id/delete (软删除)"]
    K --> N["恢复按钮(回收态)"]
    N --> O["POST /api/community/post/:id/restore"]
    K --> P["永久删除按钮(回收态)"]
    P --> Q["DELETE /api/community/post/:id/permanent"]
    R["我的帖子列表页"] --> S["回收态帖子展示"]
```

## 组件与接口

### 1. 草稿箱

**前端新增文件：**
- `src/themes/mobile/default/views/appstore/browse/drafts.vue` — 移动端草稿列表页
- `src/themes/pc/default/views/appstore/drafts.vue` — PC 端草稿列表页

**前端修改文件：**
- `src/themes/mobile/default/views/appstore/browse/mine.vue` — 在 funcIcons 数组中新增"草稿箱"入口
- `src/themes/pc/default/views/appstore/mine.vue` — 在侧边栏菜单中新增"草稿箱"入口
- `src/router/routes/staticRoutes.ts` — 新增 `/appstore/drafts` 路由

**后端：** 无需修改（现有 API 已完整）

**现有 API：**
| 方法 | 路径 | 用途 |
|------|------|------|
| GET | `/api/community/drafts` | 获取草稿列表（参数 userId）|
| POST | `/api/community/draft` | 新建/更新草稿 |
| DELETE | `/api/community/draft/:id` | 删除草稿 |

### 2. 帖子删除与回收

**后端新增 API：**
| 方法 | 路径 | 用途 |
|------|------|------|
| POST | `/api/community/post/:id/delete` | 软删除帖子（作者/版主）|
| POST | `/api/community/post/:id/restore` | 恢复已删除帖子 |
| DELETE | `/api/community/post/:id/permanent` | 永久删除帖子 |

**前端修改文件：**
- `src/themes/mobile/default/views/appstore/community/post-detail.vue` — 添加删除/恢复/永久删除按钮
- `src/themes/pc/default/views/appstore/community/post-detail.vue` — 同上
- `src/themes/mobile/default/views/appstore/browse/scheduled-posts.vue` — 定时帖子支持删除
- `src/themes/mobile/default/views/appstore/community/my-collections.vue` — 我的帖子列表支持回收态展示

**后端修改文件：**
- `server/routes/community.cjs` — 新增删除/恢复/永久删除路由

### 3. 用户黑名单

**前端新增文件：**
- `src/themes/mobile/default/views/appstore/browse/blocklist.vue` — 移动端黑名单列表页
- `src/themes/pc/default/views/appstore/blocklist.vue` — PC 端黑名单列表页

**前端修改文件：**
- `src/themes/mobile/default/views/appstore/browse/mine.vue` — funcIcons 或 menuItems 中新增"黑名单"入口
- `src/themes/mobile/default/views/appstore/browse/profile.vue` — 个人主页添加"拉黑/取消拉黑"按钮
- `src/themes/pc/default/views/appstore/profile.vue` — 同上
- `src/router/routes/staticRoutes.ts` — 新增 `/appstore/blocklist` 路由

**后端：** 现有 API 已完整

**现有 API：**
| 方法 | 路径 | 用途 |
|------|------|------|
| POST | `/api/user/:id/block` | 拉黑用户 |
| DELETE | `/api/user/:id/block` | 取消拉黑 |
| GET | `/api/user/blocked` | 获取黑名单列表（分页）|
| GET | `/api/user/block-status/:id` | 检查拉黑状态 |

## 数据模型

### community_drafts（已有表，无需修改）
```
id, user_id, section_id, title, content, images, tags, official_tags,
has_resource, resource_type, resource_url, resource_price, resource_price_type,
extract_code, permission, create_time, update_time
```

### community_posts（已有表，关注 is_deleted 字段）
```
is_deleted TINYINT(1) DEFAULT 0 — 帖子回收态标记
deleted_at DATETIME NULL — 删除时间
```

### user_blocks（已有表，无需修改）
```
id, blocker_id, blocked_id, reason, status, create_time, reviewed, review_notes
```

## 正确性约束

- 草稿仅对创建者可见，列表接口需验证 `user_id` 匹配
- 帖子删除仅作者或版主可操作，后端验证身份
- 帖子恢复仅作者可操作
- 永久删除仅作者可操作，需二次确认
- 黑名单影响评论和私信功能：被拉黑用户发起的请求需后端拦截
- 拉黑/取消拉黑操作需实时生效，不依赖缓存

## 错误处理

| 场景 | 处理方式 |
|------|---------|
| 草稿列表加载失败 | 显示"加载失败，请重试"，提供重试按钮 |
| 删除草稿失败 | 显示错误提示，保留草稿在列表 |
| 删帖失败（无权限） | 显示"无权限执行此操作" |
| 黑名单操作失败 | 显示错误提示，按钮恢复原状态 |
| 被拉黑用户尝试评论 | 后端返回 403，前端显示"已被作者拉黑" |
| 被拉黑用户尝试发私信 | 后端返回 403，前端显示"已被对方拉黑" |

## 测试策略

- 单元测试：后端新增 API 路由的权限验证和数据库操作
- 集成测试：草稿的 CRUD 完整流程、帖子删除-恢复-永久删除流程
- 前端测试：组件渲染、空状态、错误状态、路由跳转

## 参考

- 项目探索报告（本次会话 Task Agent 输出）
- `server/routes/community.cjs` — 社区帖子路由
- `server/routes/user-block.cjs` — 黑名单路由
- `server/database.cjs` — 数据库表结构
