/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: art_design_pro
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `art_design_pro`
--

/*!40000 DROP DATABASE IF EXISTS `art_design_pro`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `art_design_pro` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `art_design_pro`;

--
-- Table structure for table `ab_test_variants`
--

DROP TABLE IF EXISTS `ab_test_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ab_test_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `ratio` int(11) DEFAULT 0,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `impressions` int(11) DEFAULT 0,
  `conversions` int(11) DEFAULT 0,
  `conversion_rate` double DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ab_test_variants`
--

LOCK TABLES `ab_test_variants` WRITE;
/*!40000 ALTER TABLE `ab_test_variants` DISABLE KEYS */;
/*!40000 ALTER TABLE `ab_test_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ab_tests`
--

DROP TABLE IF EXISTS `ab_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ab_tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `target_page` varchar(500) DEFAULT '',
  `goal` varchar(50) DEFAULT 'ctr',
  `traffic` int(11) DEFAULT 50,
  `status` varchar(20) DEFAULT 'draft',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ab_tests`
--

LOCK TABLES `ab_tests` WRITE;
/*!40000 ALTER TABLE `ab_tests` DISABLE KEYS */;
/*!40000 ALTER TABLE `ab_tests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_beta_users`
--

DROP TABLE IF EXISTS `app_beta_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_beta_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_user` (`app_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_beta_users`
--

LOCK TABLES `app_beta_users` WRITE;
/*!40000 ALTER TABLE `app_beta_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_beta_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_bundle_items`
--

DROP TABLE IF EXISTS `app_bundle_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_bundle_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bundle_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bundle_app` (`bundle_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_bundle_items`
--

LOCK TABLES `app_bundle_items` WRITE;
/*!40000 ALTER TABLE `app_bundle_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_bundle_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_bundles`
--

DROP TABLE IF EXISTS `app_bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_bundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `price_balance` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_bundles`
--

LOCK TABLES `app_bundles` WRITE;
/*!40000 ALTER TABLE `app_bundles` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_bundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_categories`
--

DROP TABLE IF EXISTS `app_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` char(1) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_categories`
--

LOCK TABLES `app_categories` WRITE;
/*!40000 ALTER TABLE `app_categories` DISABLE KEYS */;
INSERT INTO `app_categories` VALUES
(1,'工具','',1,'1','2026-07-10 22:39:49'),
(2,'创作','',2,'1','2026-07-10 22:39:49'),
(3,'效率','',3,'1','2026-07-10 22:39:49'),
(4,'生活','',4,'1','2026-07-10 22:39:49'),
(5,'游戏','',5,'1','2026-07-10 22:39:49'),
(6,'教育','',6,'1','2026-07-10 22:39:49'),
(7,'社交','',7,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_clicks`
--

DROP TABLE IF EXISTS `app_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_time` (`app_id`,`create_time`),
  KEY `idx_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_clicks`
--

LOCK TABLES `app_clicks` WRITE;
/*!40000 ALTER TABLE `app_clicks` DISABLE KEYS */;
INSERT INTO `app_clicks` VALUES
(1,1,0,'2026-07-10 22:49:26'),
(2,1,0,'2026-07-10 22:49:26'),
(3,1,0,'2026-07-10 22:49:26'),
(4,1,0,'2026-07-10 22:49:26'),
(5,1,0,'2026-07-10 22:49:26'),
(6,1,0,'2026-07-10 22:49:26'),
(7,1,0,'2026-07-10 22:49:26'),
(8,1,0,'2026-07-10 22:49:26'),
(9,1,0,'2026-07-10 22:49:26'),
(10,1,0,'2026-07-10 22:49:26'),
(11,1,0,'2026-07-10 22:49:26'),
(12,1,0,'2026-07-10 22:49:26'),
(13,1,0,'2026-07-10 22:49:26'),
(14,1,0,'2026-07-10 22:49:26'),
(15,1,0,'2026-07-10 22:49:26'),
(16,1,0,'2026-07-10 22:49:26'),
(17,1,0,'2026-07-10 22:49:26'),
(18,1,0,'2026-07-10 22:49:26'),
(19,1,0,'2026-07-10 22:49:26'),
(20,1,0,'2026-07-10 22:49:26'),
(21,3,0,'2026-07-10 22:49:26'),
(22,3,0,'2026-07-10 22:49:26'),
(23,3,0,'2026-07-10 22:49:26'),
(24,3,0,'2026-07-10 22:49:26'),
(25,3,0,'2026-07-10 22:49:26'),
(26,3,0,'2026-07-10 22:49:26'),
(27,3,0,'2026-07-10 22:49:26'),
(28,3,0,'2026-07-10 22:49:26'),
(29,3,0,'2026-07-10 22:49:26'),
(30,3,0,'2026-07-10 22:49:26'),
(31,3,0,'2026-07-10 22:49:26'),
(32,3,0,'2026-07-10 22:49:26'),
(33,3,0,'2026-07-10 22:49:26'),
(34,3,0,'2026-07-10 22:49:26'),
(35,3,0,'2026-07-10 22:49:26'),
(36,3,0,'2026-07-10 22:49:26'),
(37,3,0,'2026-07-10 22:49:26'),
(38,3,0,'2026-07-10 22:49:26'),
(39,6,0,'2026-07-10 22:49:26'),
(40,6,0,'2026-07-10 22:49:26'),
(41,6,0,'2026-07-10 22:49:26'),
(42,6,0,'2026-07-10 22:49:26'),
(43,6,0,'2026-07-10 22:49:26'),
(44,6,0,'2026-07-10 22:49:26'),
(45,6,0,'2026-07-10 22:49:26'),
(46,6,0,'2026-07-10 22:49:26'),
(47,6,0,'2026-07-10 22:49:26'),
(48,6,0,'2026-07-10 22:49:26'),
(49,6,0,'2026-07-10 22:49:26'),
(50,6,0,'2026-07-10 22:49:26'),
(51,6,0,'2026-07-10 22:49:26'),
(52,6,0,'2026-07-10 22:49:26'),
(53,6,0,'2026-07-10 22:49:26'),
(54,4,0,'2026-07-10 22:49:26'),
(55,4,0,'2026-07-10 22:49:26'),
(56,4,0,'2026-07-10 22:49:26'),
(57,4,0,'2026-07-10 22:49:26'),
(58,4,0,'2026-07-10 22:49:26'),
(59,4,0,'2026-07-10 22:49:26'),
(60,4,0,'2026-07-10 22:49:26'),
(61,4,0,'2026-07-10 22:49:26'),
(62,4,0,'2026-07-10 22:49:26'),
(63,4,0,'2026-07-10 22:49:26'),
(64,4,0,'2026-07-10 22:49:26'),
(65,4,0,'2026-07-10 22:49:26'),
(66,2,0,'2026-07-10 22:49:26'),
(67,2,0,'2026-07-10 22:49:26'),
(68,2,0,'2026-07-10 22:49:26'),
(69,2,0,'2026-07-10 22:49:26'),
(70,2,0,'2026-07-10 22:49:26'),
(71,2,0,'2026-07-10 22:49:26'),
(72,2,0,'2026-07-10 22:49:26'),
(73,2,0,'2026-07-10 22:49:26'),
(74,2,0,'2026-07-10 22:49:26'),
(75,2,0,'2026-07-10 22:49:26'),
(76,5,0,'2026-07-10 22:49:26'),
(77,5,0,'2026-07-10 22:49:26'),
(78,5,0,'2026-07-10 22:49:26'),
(79,5,0,'2026-07-10 22:49:26'),
(80,5,0,'2026-07-10 22:49:26'),
(81,5,0,'2026-07-10 22:49:26'),
(82,5,0,'2026-07-10 22:49:26'),
(83,7,0,'2026-07-10 22:49:26'),
(84,7,0,'2026-07-10 22:49:26'),
(85,7,0,'2026-07-10 22:49:26'),
(86,7,0,'2026-07-10 22:49:26'),
(87,7,0,'2026-07-10 22:49:26'),
(88,8,0,'2026-07-10 22:49:26'),
(89,8,0,'2026-07-10 22:49:26'),
(90,8,0,'2026-07-10 22:49:26'),
(91,9,0,'2026-07-10 22:49:26'),
(92,9,0,'2026-07-10 22:49:26'),
(93,9,0,'2026-07-09 22:49:26'),
(94,9,0,'2026-07-09 22:49:26'),
(95,9,0,'2026-07-09 22:49:26'),
(96,9,0,'2026-07-09 22:49:26'),
(97,9,0,'2026-07-09 22:49:26'),
(98,9,0,'2026-07-09 22:49:26'),
(99,9,0,'2026-07-09 22:49:26'),
(100,9,0,'2026-07-09 22:49:26'),
(101,9,0,'2026-07-09 22:49:26'),
(102,9,0,'2026-07-09 22:49:26'),
(103,9,0,'2026-07-09 22:49:26'),
(104,9,0,'2026-07-09 22:49:26'),
(105,9,0,'2026-07-09 22:49:26'),
(106,9,0,'2026-07-09 22:49:26'),
(107,9,0,'2026-07-09 22:49:26'),
(108,9,0,'2026-07-09 22:49:26'),
(109,9,0,'2026-07-09 22:49:26'),
(110,9,0,'2026-07-09 22:49:26'),
(111,9,0,'2026-07-09 22:49:26'),
(112,9,0,'2026-07-09 22:49:26'),
(113,9,0,'2026-07-09 22:49:26'),
(114,9,0,'2026-07-09 22:49:26'),
(115,9,0,'2026-07-09 22:49:26'),
(116,9,0,'2026-07-08 22:49:26'),
(117,9,0,'2026-07-08 22:49:26'),
(118,9,0,'2026-07-08 22:49:26'),
(119,9,0,'2026-07-08 22:49:26'),
(120,9,0,'2026-07-08 22:49:26'),
(121,9,0,'2026-07-08 22:49:26'),
(122,9,0,'2026-07-08 22:49:26'),
(123,9,0,'2026-07-08 22:49:26'),
(124,9,0,'2026-07-08 22:49:26'),
(125,9,0,'2026-07-08 22:49:26'),
(126,9,0,'2026-07-08 22:49:26'),
(127,9,0,'2026-07-08 22:49:26'),
(128,9,0,'2026-07-08 22:49:26'),
(129,9,0,'2026-07-08 22:49:26'),
(130,9,0,'2026-07-08 22:49:26'),
(131,9,0,'2026-07-08 22:49:26'),
(132,9,0,'2026-07-07 22:49:26'),
(133,9,0,'2026-07-07 22:49:26'),
(134,9,0,'2026-07-07 22:49:26'),
(135,9,0,'2026-07-07 22:49:26'),
(136,9,0,'2026-07-07 22:49:26'),
(137,9,0,'2026-07-07 22:49:26'),
(138,9,0,'2026-07-06 22:49:26'),
(139,9,0,'2026-07-06 22:49:26'),
(140,9,0,'2026-07-06 22:49:26'),
(141,9,0,'2026-07-06 22:49:26'),
(142,9,0,'2026-07-05 22:49:26'),
(143,9,0,'2026-07-05 22:49:26'),
(144,9,0,'2026-07-05 22:49:26'),
(145,9,0,'2026-07-04 22:49:26'),
(146,9,0,'2026-07-04 22:49:26'),
(147,8,0,'2026-07-09 22:49:26'),
(148,8,0,'2026-07-09 22:49:26'),
(149,8,0,'2026-07-09 22:49:26'),
(150,8,0,'2026-07-09 22:49:26'),
(151,8,0,'2026-07-09 22:49:26'),
(152,8,0,'2026-07-09 22:49:26'),
(153,8,0,'2026-07-09 22:49:26'),
(154,8,0,'2026-07-09 22:49:26'),
(155,8,0,'2026-07-09 22:49:26'),
(156,8,0,'2026-07-09 22:49:26'),
(157,8,0,'2026-07-09 22:49:26'),
(158,8,0,'2026-07-09 22:49:26'),
(159,8,0,'2026-07-09 22:49:26'),
(160,8,0,'2026-07-09 22:49:26'),
(161,8,0,'2026-07-08 22:49:26'),
(162,8,0,'2026-07-08 22:49:26'),
(163,8,0,'2026-07-08 22:49:26'),
(164,8,0,'2026-07-08 22:49:26'),
(165,8,0,'2026-07-08 22:49:26'),
(166,8,0,'2026-07-08 22:49:26'),
(167,8,0,'2026-07-08 22:49:26'),
(168,8,0,'2026-07-08 22:49:26'),
(169,8,0,'2026-07-08 22:49:26'),
(170,8,0,'2026-07-07 22:49:26'),
(171,8,0,'2026-07-07 22:49:26'),
(172,8,0,'2026-07-07 22:49:26'),
(173,8,0,'2026-07-07 22:49:26'),
(174,8,0,'2026-07-07 22:49:26'),
(175,8,0,'2026-07-07 22:49:26'),
(176,8,0,'2026-07-06 22:49:26'),
(177,8,0,'2026-07-06 22:49:26'),
(178,8,0,'2026-07-06 22:49:26'),
(179,8,0,'2026-07-06 22:49:26'),
(180,8,0,'2026-07-05 22:49:26'),
(181,8,0,'2026-07-05 22:49:26'),
(182,8,0,'2026-07-05 22:49:26'),
(183,8,0,'2026-07-04 22:49:26'),
(184,8,0,'2026-07-04 22:49:26'),
(185,7,0,'2026-07-09 22:49:26'),
(186,7,0,'2026-07-09 22:49:26'),
(187,7,0,'2026-07-09 22:49:26'),
(188,7,0,'2026-07-09 22:49:26'),
(189,7,0,'2026-07-09 22:49:26'),
(190,7,0,'2026-07-09 22:49:26'),
(191,7,0,'2026-07-09 22:49:26'),
(192,7,0,'2026-07-09 22:49:26'),
(193,7,0,'2026-07-09 22:49:26'),
(194,7,0,'2026-07-09 22:49:26'),
(195,7,0,'2026-07-08 22:49:26'),
(196,7,0,'2026-07-08 22:49:26'),
(197,7,0,'2026-07-08 22:49:26'),
(198,7,0,'2026-07-08 22:49:26'),
(199,7,0,'2026-07-08 22:49:26'),
(200,7,0,'2026-07-08 22:49:26'),
(201,7,0,'2026-07-08 22:49:26'),
(202,7,0,'2026-07-08 22:49:26'),
(203,7,0,'2026-07-08 22:49:26'),
(204,7,0,'2026-07-07 22:49:26'),
(205,7,0,'2026-07-07 22:49:26'),
(206,7,0,'2026-07-07 22:49:26'),
(207,7,0,'2026-07-07 22:49:26'),
(208,7,0,'2026-07-07 22:49:26'),
(209,7,0,'2026-07-06 22:49:26'),
(210,7,0,'2026-07-06 22:49:26'),
(211,7,0,'2026-07-06 22:49:26'),
(212,7,0,'2026-07-06 22:49:26'),
(213,7,0,'2026-07-05 22:49:26'),
(214,7,0,'2026-07-05 22:49:26'),
(215,7,0,'2026-07-05 22:49:26'),
(216,7,0,'2026-07-04 22:49:26'),
(217,5,0,'2026-07-09 22:49:26'),
(218,5,0,'2026-07-09 22:49:26'),
(219,5,0,'2026-07-09 22:49:26'),
(220,5,0,'2026-07-09 22:49:26'),
(221,5,0,'2026-07-09 22:49:26'),
(222,5,0,'2026-07-09 22:49:26'),
(223,5,0,'2026-07-09 22:49:26'),
(224,5,0,'2026-07-09 22:49:26'),
(225,5,0,'2026-07-09 22:49:26'),
(226,5,0,'2026-07-09 22:49:26'),
(227,5,0,'2026-07-08 22:49:26'),
(228,5,0,'2026-07-08 22:49:26'),
(229,5,0,'2026-07-08 22:49:26'),
(230,5,0,'2026-07-08 22:49:26'),
(231,5,0,'2026-07-08 22:49:26'),
(232,5,0,'2026-07-08 22:49:26'),
(233,5,0,'2026-07-08 22:49:26'),
(234,5,0,'2026-07-07 22:49:26'),
(235,5,0,'2026-07-07 22:49:26'),
(236,5,0,'2026-07-07 22:49:26'),
(237,5,0,'2026-07-07 22:49:26'),
(238,5,0,'2026-07-06 22:49:26'),
(239,5,0,'2026-07-06 22:49:26'),
(240,5,0,'2026-07-05 22:49:26'),
(241,5,0,'2026-07-05 22:49:26'),
(242,5,0,'2026-07-05 22:49:26'),
(243,5,0,'2026-07-04 22:49:26'),
(244,1,0,'2026-07-09 22:49:26'),
(245,1,0,'2026-07-09 22:49:26'),
(246,1,0,'2026-07-09 22:49:26'),
(247,1,0,'2026-07-09 22:49:26'),
(248,1,0,'2026-07-09 22:49:26'),
(249,1,0,'2026-07-09 22:49:26'),
(250,1,0,'2026-07-09 22:49:26'),
(251,1,0,'2026-07-09 22:49:26'),
(252,1,0,'2026-07-09 22:49:26'),
(253,1,0,'2026-07-09 22:49:26'),
(254,1,0,'2026-07-08 22:49:26'),
(255,1,0,'2026-07-08 22:49:26'),
(256,1,0,'2026-07-08 22:49:26'),
(257,1,0,'2026-07-08 22:49:26'),
(258,1,0,'2026-07-08 22:49:26'),
(259,1,0,'2026-07-08 22:49:26'),
(260,1,0,'2026-07-07 22:49:26'),
(261,1,0,'2026-07-07 22:49:26'),
(262,1,0,'2026-07-07 22:49:26'),
(263,1,0,'2026-07-06 22:49:26'),
(264,1,0,'2026-07-06 22:49:26'),
(265,1,0,'2026-07-06 22:49:26'),
(266,1,0,'2026-07-05 22:49:26'),
(267,1,0,'2026-07-05 22:49:26'),
(268,1,0,'2026-07-04 22:49:26');
/*!40000 ALTER TABLE `app_clicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_collection_items`
--

DROP TABLE IF EXISTS `app_collection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_collection_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_collection_app` (`collection_id`,`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_collection_items`
--

LOCK TABLES `app_collection_items` WRITE;
/*!40000 ALTER TABLE `app_collection_items` DISABLE KEYS */;
INSERT INTO `app_collection_items` VALUES
(1,1,12,0,'2026-07-19 14:00:34'),
(2,2,10,0,'2026-07-19 14:00:34'),
(3,2,11,0,'2026-07-19 14:00:34'),
(4,3,12,0,'2026-07-19 14:00:34'),
(5,4,12,0,'2026-07-19 17:41:26');
/*!40000 ALTER TABLE `app_collection_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_collections`
--

DROP TABLE IF EXISTS `app_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `creator_id` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `is_public` tinyint(1) DEFAULT 1,
  `likes` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_collections`
--

LOCK TABLES `app_collections` WRITE;
/*!40000 ALTER TABLE `app_collections` DISABLE KEYS */;
INSERT INTO `app_collections` VALUES
(1,'开发者必备工具','精选开发调试、代码编辑和效率提升工具','',1,1,'active',0,1,2,1,1,10,'2026-07-19 14:00:28','2026-07-20 03:54:56'),
(2,'影音娱乐精选','热门视频、音乐和直播应用合集','',1,1,'active',0,1,0,0,0,6,'2026-07-19 14:00:28','2026-07-19 15:20:15'),
(3,'开学季必备','学习工具、笔记应用和校园生活助手','',1,1,'active',0,1,0,0,0,20,'2026-07-19 14:00:28','2026-07-20 03:54:54'),
(4,'666','5895','',19,19,'active',0,0,0,0,0,24,'2026-07-19 15:31:05','2026-07-19 21:08:43');
/*!40000 ALTER TABLE `app_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_comments`
--

DROP TABLE IF EXISTS `app_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(20) DEFAULT '#FF5777',
  `device` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '',
  `content` text DEFAULT NULL,
  `likes` int(11) DEFAULT 0,
  `replies` int(11) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `is_pinned` tinyint(1) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_comments_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_comments`
--

LOCK TABLES `app_comments` WRITE;
/*!40000 ALTER TABLE `app_comments` DISABLE KEYS */;
INSERT INTO `app_comments` VALUES
(1,5,0,13,'','#FF5777','','','很好用',0,0,0,0,5.0,'2026-05-13 22:39:54'),
(2,1,0,5,'','#FF5777','','','推荐！',0,0,0,0,5.0,'2026-05-29 22:39:54'),
(4,3,0,10,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-05-12 22:39:54'),
(5,2,0,2,'','#FF5777','','','需要改进',0,0,0,0,5.0,'2026-07-03 22:39:54'),
(6,7,0,7,'','#FF5777','','','很棒的应用',0,0,0,0,5.0,'2026-05-22 22:39:54'),
(8,5,0,6,'','#FF5777','','','推荐！',0,0,0,0,4.0,'2026-07-07 22:39:54'),
(9,4,0,15,'','#FF5777','','','不错',0,0,0,0,4.0,'2026-06-25 22:39:54'),
(10,4,0,7,'','#FF5777','','','还可以',0,0,0,0,5.0,'2026-06-05 22:39:54'),
(14,12,0,19,'alexmorgan','#448AFF','','','6',1,0,0,0,5.0,'2026-07-12 21:51:42');
/*!40000 ALTER TABLE `app_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_daily_stats`
--

DROP TABLE IF EXISTS `app_daily_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_daily_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `stat_date` date NOT NULL,
  `downloads` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_app_date` (`app_id`,`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_daily_stats`
--

LOCK TABLES `app_daily_stats` WRITE;
/*!40000 ALTER TABLE `app_daily_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_daily_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorite_group_follows`
--

DROP TABLE IF EXISTS `app_favorite_group_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorite_group_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_follower` (`group_id`,`follower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorite_group_follows`
--

LOCK TABLES `app_favorite_group_follows` WRITE;
/*!40000 ALTER TABLE `app_favorite_group_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_favorite_group_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorite_groups`
--

DROP TABLE IF EXISTS `app_favorite_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorite_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认收藏夹',
  `sort_order` int(11) DEFAULT 0,
  `is_public` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorite_groups`
--

LOCK TABLES `app_favorite_groups` WRITE;
/*!40000 ALTER TABLE `app_favorite_groups` DISABLE KEYS */;
INSERT INTO `app_favorite_groups` VALUES
(1,19,'默认收藏夹',0,0,'2026-07-16 14:16:37'),
(2,10001,'默认收藏夹',0,0,'2026-07-16 15:21:23'),
(3,10002,'默认收藏夹',0,0,'2026-07-21 15:25:35');
/*!40000 ALTER TABLE `app_favorite_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_favorites`
--

DROP TABLE IF EXISTS `app_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`app_id`),
  KEY `idx_app_favorites_user` (`user_id`),
  KEY `idx_app_favorites_app` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_favorites`
--

LOCK TABLES `app_favorites` WRITE;
/*!40000 ALTER TABLE `app_favorites` DISABLE KEYS */;
INSERT INTO `app_favorites` VALUES
(1,9,1,0,'2026-06-05 22:39:54'),
(2,10,5,0,'2026-06-18 22:39:54'),
(3,2,8,0,'2026-07-09 22:39:54'),
(4,4,2,0,'2026-05-12 22:39:54'),
(5,3,6,0,'2026-05-12 22:39:54'),
(6,11,1,0,'2026-05-13 22:39:54'),
(7,6,4,0,'2026-06-29 22:39:54'),
(8,11,6,0,'2026-06-15 22:39:54'),
(9,9,6,0,'2026-06-19 22:39:54'),
(10,6,6,0,'2026-06-12 22:39:54'),
(12,15,4,0,'2026-07-07 22:39:54'),
(13,7,9,0,'2026-07-07 22:39:54'),
(14,7,2,0,'2026-05-25 22:39:54'),
(15,5,3,0,'2026-05-14 22:39:54'),
(19,19,12,8,'2026-07-16 13:58:16'),
(20,10001,12,2,'2026-07-16 15:21:24'),
(21,1,1,1,'2026-07-16 19:28:14');
/*!40000 ALTER TABLE `app_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_official_tags`
--

DROP TABLE IF EXISTS `app_official_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_official_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `color` varchar(20) DEFAULT '#2563eb',
  `bg_color` varchar(20) DEFAULT '#dbeafe',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_official_tags`
--

LOCK TABLES `app_official_tags` WRITE;
/*!40000 ALTER TABLE `app_official_tags` DISABLE KEYS */;
INSERT INTO `app_official_tags` VALUES
(1,'热门','#2563eb','#dbeafe',1,'1','2026-07-10 22:39:49'),
(2,'推荐','#2563eb','#dbeafe',2,'1','2026-07-10 22:39:49'),
(3,'新品','#2563eb','#dbeafe',3,'1','2026-07-10 22:39:49'),
(4,'精品','#2563eb','#dbeafe',4,'1','2026-07-10 22:39:49');
/*!40000 ALTER TABLE `app_official_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_purchases`
--

DROP TABLE IF EXISTS `app_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'free',
  `original_price` decimal(10,2) DEFAULT 0.00,
  `paid_price` decimal(10,2) DEFAULT 0.00,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_purchases_app` (`app_id`),
  KEY `idx_app_purchases_user` (`user_id`),
  KEY `idx_app_purchases_user_app` (`user_id`,`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_purchases`
--

LOCK TABLES `app_purchases` WRITE;
/*!40000 ALTER TABLE `app_purchases` DISABLE KEYS */;
INSERT INTO `app_purchases` VALUES
(1,9,6,'','free',0.00,12.79,1.0,'2026-05-12 22:39:54'),
(2,3,6,'','free',0.00,5.03,1.0,'2026-05-21 22:39:54'),
(3,7,8,'','free',0.00,16.36,1.0,'2026-06-22 22:39:54'),
(4,9,7,'','free',0.00,28.55,1.0,'2026-05-15 22:39:54'),
(5,1,8,'','free',0.00,14.38,1.0,'2026-07-08 22:39:54'),
(6,2,15,'','free',0.00,17.64,1.0,'2026-06-15 22:39:54');
/*!40000 ALTER TABLE `app_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_store`
--

DROP TABLE IF EXISTS `app_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `description` text DEFAULT NULL,
  `update_content` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `developer` varchar(100) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `categories` text DEFAULT NULL,
  `category_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `is_pinned` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `official_tags` text DEFAULT NULL,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `is_featured` tinyint(1) DEFAULT 0,
  `is_official` tinyint(1) DEFAULT 0,
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_store_status` (`status`),
  KEY `idx_app_category_status` (`category_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_store`
--

LOCK TABLES `app_store` WRITE;
/*!40000 ALTER TABLE `app_store` DISABLE KEYS */;
INSERT INTO `app_store` VALUES
(1,'Pro Photo Editor','AIGram.pro.editor','1.2.3','120','','camera',0.0,3865,3.7,'专业级照片编辑工具，AI智能修图',NULL,NULL,'[\"photo\",\"editor\",\"AI\"]','',0,0,'bobwang','工具',NULL,0,'1',0,14,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-05-12 22:39:49','2026-07-10 22:39:49'),
(2,'Pixel Draw','Pixel.Draw.app','2.0.1','101','','brush',0.0,791,4.0,'像素风绘画应用，支持图层和动画',NULL,NULL,'[\"draw\",\"pixel\",\"art\"]','',0,0,'pixel_art','工具',NULL,0,'1',0,1,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-08 22:39:49','2026-07-10 22:39:49'),
(3,'Code Helper','Code.Helper.pro','3.5.0','200','','code',0.0,4675,2.9,'智能代码助手，支持多种编程语言',NULL,NULL,'[\"code\",\"dev\",\"tool\"]','',0,0,'code_ninja','工具',NULL,0,'1',0,2,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-22 22:39:49','2026-07-10 22:39:49'),
(4,'Music Maker','Music.Maker.studio','1.0.0','80','','music',0.0,4272,4.1,'AI驱动的音乐创作工作室',NULL,NULL,'[\"music\",\"create\",\"AI\"]','',0,0,'tech_guru','创作',NULL,0,'1',0,7,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-04 22:39:49','2026-07-10 22:39:49'),
(5,'Video Snap','Video.Snap.lite','4.2.1','95','','video',0.0,2168,4.0,'短视频快速剪辑和滤镜工具',NULL,NULL,'[\"video\",\"edit\",\"social\"]','',0,0,'frontend_dev','创作',NULL,0,'1',0,5,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-23 22:39:49','2026-07-10 22:39:49'),
(7,'Mind Map Pro','Mind.Map.visual','1.5.2','75','','mindmap',0.0,2839,3.4,'思维导图可视化工具',NULL,NULL,'[\"mindmap\",\"study\",\"visual\"]','',0,0,'design_master','效率',NULL,0,'1',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(10,'待审核应用','com.demo.pending','0.1.0','30','','default',0.0,1265,3.1,'这是一个待审核的应用',NULL,NULL,'[\"test\"]','',0,0,'mobile_dev','工具',NULL,0,'0',0,4,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-04-24 22:39:49','2026-07-10 22:39:49'),
(11,'已拒绝应用','com.demo.rejected','0.1.0','20','','default',0.0,648,4.2,'这是一个被拒绝的应用',NULL,NULL,'[\"test\"]','',0,0,'game_dev','工具',NULL,0,'2',0,11,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-06-03 22:39:49','2026-07-10 22:39:49'),
(12,'百变引擎','百变引擎_13.7.07','13.7.07','100','','#00BFA5',19.5,0,5.0,'66',NULL,'[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','6666',0,0,'alexmorgan','工具',NULL,0,'1',1,19,'[]','public',0.00,'free','','',1,0,1,1,0,1,'free',0.00,'2026-07-11 11:50:41','2026-07-11 11:50:41'),
(13,'测试应用','com.test.app','1.0.0','100','','#00BFA5',0.0,0,0.0,'A3测试',NULL,NULL,NULL,'',0,0,'','工具',NULL,0,'0',0,0,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'free',0.00,'2026-07-20 07:14:47','2026-07-20 07:14:47'),
(14,'付费应用','com.test.paid','1.0.0','100','','#00BFA5',0.0,0,0.0,'A5测试',NULL,NULL,NULL,'',0,0,'','工具',NULL,0,'0',0,0,NULL,'public',0.00,'free','','',0,0,0,1,0,1,'paid',150.00,'2026-07-20 07:14:47','2026-07-20 07:14:47');
/*!40000 ALTER TABLE `app_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_tips`
--

DROP TABLE IF EXISTS `app_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(64) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tip_type` varchar(20) DEFAULT 'balance',
  `message` varchar(255) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_tips_app` (`app_id`),
  KEY `idx_app_tips_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_tips`
--

LOCK TABLES `app_tips` WRITE;
/*!40000 ALTER TABLE `app_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_uploads`
--

DROP TABLE IF EXISTS `app_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `name` varchar(200) NOT NULL,
  `package_name` varchar(200) DEFAULT '',
  `category` varchar(100) DEFAULT '工具',
  `description` text DEFAULT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `version` varchar(50) DEFAULT '1.0.0',
  `version_code` varchar(50) DEFAULT '100',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `download_url` varchar(500) DEFAULT '',
  `screenshots` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `version_type` varchar(20) DEFAULT '',
  `has_ads` int(11) DEFAULT 0,
  `requires_network` int(11) DEFAULT 1,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `coin_count` int(11) DEFAULT 0,
  `coin_people` int(11) DEFAULT 0,
  `review_count` int(11) DEFAULT 0,
  `five_star_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '0',
  `submission_status` varchar(20) DEFAULT 'draft',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `price_type` varchar(20) DEFAULT 'free',
  `price_amount` decimal(10,2) DEFAULT 0.00,
  `official_tags` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_app_uploads_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_uploads`
--

LOCK TABLES `app_uploads` WRITE;
/*!40000 ALTER TABLE `app_uploads` DISABLE KEYS */;
INSERT INTO `app_uploads` VALUES
(1,0,0,'','E2E App','com.e2e.test','工具','Test app','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-10 19:34:30','2026-07-10 19:34:30'),
(2,3,0,'','E2E Test App','com.e2e.app','工具','Real E2E test application','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-10 20:07:11','free',0.00,NULL,'2026-07-10 19:37:24','2026-07-10 20:07:11'),
(3,0,0,'','test_crud_app','com.test.crud','工具','CRUD test app','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:09:51','2026-07-10 20:09:51'),
(4,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:11:45','2026-07-10 20:11:45'),
(5,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:26','2026-07-10 20:13:26'),
(6,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:13:56','2026-07-10 20:13:56'),
(7,0,0,'','test_crud_app','com.test.crud','工具','CRUD test','','#4ECDC4','1.0.0','1',10.0,'https://example.com/test.apk','\"[]\"','\"[]\"','',0,0,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'\"[]\"','2026-07-10 20:17:40','2026-07-10 20:17:40'),
(8,12,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','66','','#00BFA5','13.7.07','100',19.5,'6666','[\"/uploads/1783770613292-211438868.jpg\"]','[\"官方版\"]','官方版',1,1,0,1,0,0.0,0,0,0,0,'0','approved','','alexmorgan','2026-07-11 11:50:41','free',0.00,'[]','2026-07-11 11:50:19','2026-07-11 11:50:41'),
(9,0,19,'alexmorgan','百变引擎','百变引擎_13.7.07','工具','','/uploads/icon-1783816289499-38219570.png','#00BFA5','13.7.07','100',19.5,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk','[]','[\"官方版\"]','官方版',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,'[]','2026-07-12 00:32:20','2026-07-12 00:32:20'),
(10,0,19,'alexmorgan','icu.nullptr.nativetest','Native Test ++_Mean Minotaur','工具','66666','/uploads/icon-1784462813909-354136982.png','#00BFA5','MeanMinotaur','100',1.0,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/apk/apk-1784462812954-251622320.apk','[\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462835968.jpg\",\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462837341.jpg\"]','[\"开发版\"]','开发版',0,1,0,1,0,0.0,0,0,0,0,'0','pending',NULL,'',NULL,'balance',3.00,'[]','2026-07-19 12:07:17','2026-07-19 12:09:13'),
(11,0,19,'alexmorgan','icu.nullptr.nativetest','Native Test ++_Mean Minotaur','工具','66666','/uploads/icon-1784462813909-354136982.png','#00BFA5','MeanMinotaur','100',1.0,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/apk/apk-1784462812954-251622320.apk','[\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462844065.jpg\",\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462845270.jpg\"]','[\"开发版\"]','开发版',0,1,0,1,0,0.0,0,0,0,0,'0','pending',NULL,'',NULL,'balance',3.00,'[]','2026-07-19 12:07:25','2026-07-19 12:09:11'),
(12,0,19,'alexmorgan','icu.nullptr.nativetest','Native Test ++_Mean Minotaur','工具','8888','/uploads/icon-1784462912249-380199123.png','#00BFA5','MeanMinotaur','100',1.0,'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/apk/apk-1784462911326-204029218.apk','[\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462929151.jpg\",\"http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462929855.jpg\"]','[\"Alpha版\"]','Alpha版',0,1,0,1,0,0.0,0,0,0,0,'0','pending',NULL,'',NULL,'points',30.00,'[]','2026-07-19 12:08:50','2026-07-19 12:09:10'),
(13,0,1,'bobwang','测试应用','com.test.app','工具','A3测试','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'1','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-20 07:14:47','2026-07-20 07:14:47'),
(14,0,1,'bobwang','付费应用','com.test.paid','工具','A5测试','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'1','draft',NULL,'',NULL,'paid',150.00,NULL,'2026-07-20 07:14:47','2026-07-20 07:14:47'),
(15,0,3,'tech_guru','测试应用投稿','','工具','测试描述','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','draft',NULL,'',NULL,'free',0.00,NULL,'2026-07-21 00:25:29','2026-07-21 00:25:29'),
(16,0,19,'alexmorgan','Alex未通过应用','','工具','一个有问题的应用','','#00BFA5','1.0.0','100',0.0,'',NULL,NULL,'',0,1,0,1,0,0.0,0,0,0,0,'0','rejected',NULL,'',NULL,'free',0.00,NULL,'2026-07-21 00:25:52','2026-07-21 00:25:52');
/*!40000 ALTER TABLE `app_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_versions`
--

DROP TABLE IF EXISTS `app_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `version` varchar(50) NOT NULL,
  `version_code` varchar(50) DEFAULT '',
  `size_mb` decimal(10,1) DEFAULT 0.0,
  `downloads` int(11) DEFAULT 0,
  `rating` decimal(2,1) DEFAULT 0.0,
  `update_content` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `download_url` varchar(500) DEFAULT '',
  `is_current` tinyint(1) DEFAULT 0,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `official_tags` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `screenshots` text DEFAULT NULL,
  `has_ads` int(11) DEFAULT 0,
  `has_paid_content` int(11) DEFAULT 0,
  `is_free` int(11) DEFAULT 1,
  `requires_network` int(11) DEFAULT 0,
  `version_type` varchar(20) DEFAULT 'release',
  PRIMARY KEY (`id`),
  KEY `idx_app_versions_app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_versions`
--

LOCK TABLES `app_versions` WRITE;
/*!40000 ALTER TABLE `app_versions` DISABLE KEYS */;
INSERT INTO `app_versions` VALUES
(2,3,'3.5.4.5','216',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-30 22:39:54',NULL,NULL,0,0,1,0,'release'),
(4,5,'2.3.7.1','783',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-06-02 22:39:54',NULL,NULL,0,0,1,0,'release'),
(8,4,'3.7.5.2','690',0.0,0,0.0,'Bug修复和性能优化',NULL,'',0,0,'',NULL,'1','2026-05-16 22:39:54',NULL,NULL,0,0,1,0,'release'),
(9,0,'13.7.07','100',19.5,0,0.0,'','[\"官方版\"]','6666',1,19,'alexmorgan',NULL,'1','2026-07-11 11:50:41','66','[\"/uploads/1783770613292-211438868.jpg\"]',0,0,1,0,'release');
/*!40000 ALTER TABLE `app_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatar_frames`
--

DROP TABLE IF EXISTS `avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(500) DEFAULT '',
  `thumbnail_url` varchar(500) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `obtain_type` varchar(20) DEFAULT 'manual',
  `exp_level_required` int(11) DEFAULT 0,
  `member_level_required` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_frames`
--

LOCK TABLES `avatar_frames` WRITE;
/*!40000 ALTER TABLE `avatar_frames` DISABLE KEYS */;
INSERT INTO `avatar_frames` VALUES
(1,'金色边框','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/frame-1784063200439-382993529.gif','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-14 21:06:43'),
(2,'炫彩边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-11 16:28:24'),
(3,'简约边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(4,'节日边框','','','','manual',0,0,0,'1','2026-07-10 22:39:54','2026-07-10 22:39:54'),
(5,'金色边框','/frames/gold.png','/frames/gold_thumb.png','金闪闪的会员框','membership',0,0,1,'1','2026-07-11 21:07:13','2026-07-11 21:07:13'),
(6,'钻石边框','/frames/diamond.png','/frames/diamond_thumb.png','钻石边框','membership',0,0,2,'1','2026-07-11 21:07:13','2026-07-11 21:07:13');
/*!40000 ALTER TABLE `avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_records`
--

DROP TABLE IF EXISTS `balance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_balance_records_user` (`user_id`),
  KEY `idx_balance_records_ctime` (`create_time`),
  KEY `idx_balance_records_user_time` (`user_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_records`
--

LOCK TABLES `balance_records` WRITE;
/*!40000 ALTER TABLE `balance_records` DISABLE KEYS */;
INSERT INTO `balance_records` VALUES
(1,19,'alexmorgan','earn',5000.00,5000.00,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 获得5000元余额',0,'','2026-07-11 08:41:23'),
(2,19,'alexmorgan','expense',10.00,4990.00,'会员购买','购买黄金会员',0,'','2026-07-11 08:56:31'),
(3,19,'alexmorgan','expense',10.00,4980.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:35'),
(4,19,'alexmorgan','expense',10.00,4970.00,'会员购买','购买黄金会员',0,'','2026-07-11 09:14:38'),
(5,19,'Alex Morgan','expense',1.00,4969.00,'帖子打赏','打赏帖子「开源项目推荐合集」',0,'','2026-07-11 11:39:17'),
(6,1,'bobwang','expense',10.00,78.50,'会员购买','购买黄金会员',0,'','2026-07-11 20:37:08'),
(7,1,'bobwang','earn',3.00,91.50,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:37:08'),
(8,4,'design_master','expense',10.00,0.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:38:36'),
(9,4,'design_master','earn',3.00,13.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:38:36'),
(14,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:48:23'),
(15,21,'testcoupon','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:43'),
(16,21,'testcoupon','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:43'),
(17,21,'testcoupon','expense',10.00,88.00,'会员购买','购买黄金会员',0,'','2026-07-11 20:49:53'),
(18,21,'testcoupon','earn',3.00,101.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 20:49:53'),
(19,22,'titletest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:07:31'),
(20,22,'titletest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:07:31'),
(21,23,'birthdaytest','expense',10.00,90.00,'会员购买','购买黄金会员',0,'','2026-07-11 21:08:20'),
(22,23,'birthdaytest','earn',8.00,108.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-11 21:08:20'),
(23,19,'alexmorgan','expense',5.00,4964.00,'会员购买','购买黄金会员',0,'','2026-07-12 00:11:10'),
(24,19,'alexmorgan','earn',3.00,4972.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 00:11:10'),
(25,19,'alexmorgan','expense',48.00,4919.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:34:02'),
(26,19,'alexmorgan','expense',48.00,4871.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:34:26'),
(27,19,'alexmorgan','expense',20.00,4851.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:35:24'),
(28,19,'alexmorgan','expense',48.00,4803.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:35:40'),
(29,19,'alexmorgan','expense',10.00,4793.00,'会员购买','购买黄金会员',0,'','2026-07-12 10:37:22'),
(30,19,'alexmorgan','earn',3.00,4806.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 10:37:22'),
(31,19,'alexmorgan','expense',20.00,4776.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:37:35'),
(32,19,'alexmorgan','expense',10.00,4766.00,'会员购买','购买黄金会员',0,'','2026-07-12 10:37:47'),
(33,19,'alexmorgan','earn',3.00,4779.00,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-12 10:37:47'),
(34,19,'alexmorgan','expense',20.00,4749.00,'会员购买','购买至尊会员',0,'','2026-07-12 10:37:54'),
(35,19,'alexmorgan','expense',10.00,4739.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:12:49'),
(36,19,'alexmorgan','expense',10.00,4729.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:12:58'),
(37,19,'alexmorgan','expense',10.00,4719.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:13:05'),
(38,19,'alexmorgan','expense',20.00,4699.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:13:08'),
(39,19,'alexmorgan','expense',20.00,4679.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:13:13'),
(40,19,'alexmorgan','expense',20.00,4659.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:15:35'),
(41,19,'alexmorgan','expense',10.00,4649.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:15:38'),
(42,19,'alexmorgan','expense',10.00,4639.00,'会员购买','购买黄金会员',0,'','2026-07-12 11:15:40'),
(43,19,'alexmorgan','expense',20.00,4619.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:36'),
(44,19,'alexmorgan','expense',20.00,4599.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:38'),
(45,19,'alexmorgan','expense',20.00,4579.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:40'),
(46,19,'alexmorgan','expense',20.00,4559.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:44'),
(47,19,'alexmorgan','expense',20.00,4539.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:17:47'),
(48,19,'alexmorgan','expense',48.00,4491.00,'会员购买','购买至尊会员',0,'','2026-07-12 11:21:15'),
(49,19,'alexmorgan','expense',10.00,4481.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:49:54'),
(50,19,'alexmorgan','expense',10.00,4471.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:50:03'),
(51,19,'alexmorgan','expense',10.00,4461.00,'会员购买','购买黄金会员',0,'','2026-07-12 16:50:07'),
(52,19,'alexmorgan','expense',48.00,4413.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:19'),
(53,19,'alexmorgan','expense',48.00,4365.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:22'),
(54,19,'alexmorgan','expense',48.00,4317.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:50:30'),
(55,19,'alexmorgan','expense',48.00,4269.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:51:41'),
(56,19,'alexmorgan','expense',48.00,4221.00,'会员购买','购买至尊会员',0,'','2026-07-12 16:52:12'),
(57,19,'alexmorgan','expense',15.00,4206.00,'会员购买','购买钻石会员',0,'','2026-07-12 20:36:22'),
(58,19,'alexmorgan','expense',20.00,4186.00,'会员购买','购买至尊会员',0,'','2026-07-12 20:36:40'),
(59,19,'alexmorgan','expense',15.00,4171.00,'会员购买','购买钻石会员',0,'','2026-07-12 20:36:48'),
(60,19,'alexmorgan','expense',48.00,4123.00,'会员购买','购买至尊会员',0,'','2026-07-12 20:46:00'),
(61,19,'alexmorgan','expense',20.00,4103.00,'会员购买','购买至尊会员',0,'','2026-07-12 22:19:55'),
(62,19,'alexmorgan','expense',10.00,4093.00,'会员购买','购买黄金会员',0,'','2026-07-12 23:00:31'),
(63,19,'alexmorgan','expense',48.00,4045.00,'会员购买','购买至尊会员',0,'','2026-07-12 23:01:02'),
(64,7,'user7','earn',87.49,500.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-12 23:39:30'),
(65,19,'alexmorgan','expense',500.00,3545.00,'余额提现','提现申请 alipay 123456',0,'','2026-07-12 23:39:43'),
(66,8,'user8','earn',84.19,180.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-12 23:45:35'),
(67,19,'alexmorgan','earn',500.00,3545.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-13 14:24:58'),
(68,19,'alexmorgan','earn',500.00,3545.00,'提现退回','提现申请被拒绝，退回余额',0,'','2026-07-13 14:24:58'),
(69,1,'bobwang','expense',4.50,77.00,'内容购买','购买帖子 #21 (黄金会员90%折扣)',0,'','2026-07-15 04:20:52'),
(70,19,'alexmorgan','earn',0.45,3545.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-15 04:20:52'),
(71,19,'alexmorgan','earn',10.00,3555.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-15 04:21:03'),
(72,10001,'35735712','earn',2000.00,2000.00,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 获得2000元余额',0,'','2026-07-16 00:16:12'),
(73,10001,'35735712','expense',10.00,1990.00,'内容购买','购买帖子 #22',0,'','2026-07-16 00:16:50'),
(74,19,'alexmorgan','earn',1.00,3556.45,'内容收益','帖子 #22 销售分佣',0,'','2026-07-16 00:16:50'),
(75,19,'alexmorgan','earn',10.00,3566.45,'内容收益','帖子 #21 销售分佣',0,'','2026-07-16 00:17:36'),
(76,10001,'35735712','expense',5.00,1985.00,'内容购买','购买帖子 #21',0,'','2026-07-16 00:17:45'),
(77,19,'alexmorgan','earn',0.50,3566.95,'内容收益','帖子 #21 销售分佣',0,'','2026-07-16 00:17:45'),
(78,19,'alexmorgan','earn',5.00,3571.95,'content_purchase','订单结算: 购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',72,'order_settle','2026-07-16 00:19:36'),
(79,10001,'35735712','expense',12.00,1973.00,'余额提现','提现申请 alipay 122',0,'','2026-07-16 00:20:17'),
(80,1,'','consume',-20.00,57.00,'collection_purchase','购买合集《社区功能测试合集》',0,'','2026-07-16 01:12:14'),
(81,19,'','income',20.00,3591.95,'collection_income','合集《社区功能测试合集》销售收入',0,'','2026-07-16 01:12:14'),
(82,10001,'35735712','expense',8.88,1964.12,'内容购买','购买帖子 #23',0,'','2026-07-16 15:43:53'),
(83,19,'alexmorgan','earn',0.89,3592.84,'内容收益','帖子 #23 销售分佣',0,'','2026-07-16 15:43:53'),
(84,19,'alexmorgan','expense',9.00,3583.84,'商城购物','购买商品《移动端组件库》 (优惠券抵扣¥1)',0,'','2026-07-16 19:42:21'),
(85,19,'alexmorgan','earn',10.00,3593.84,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-16 19:42:21'),
(86,19,'alexmorgan','expense',9.20,3584.64,'商城购物','购买商品《移动端组件库》 (优惠券抵扣¥0.8)',0,'','2026-07-16 19:42:28'),
(87,19,'alexmorgan','earn',10.00,3594.64,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-16 19:42:28'),
(88,3,'tech_guru','spend',199.00,301.00,'商城购物','商城下单，共1件商品',0,'','2026-07-17 15:05:59'),
(89,19,'alexmorgan','earn',10.00,3604.64,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:37:47'),
(90,19,'alexmorgan','expense',9.80,3594.84,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 15:39:56'),
(91,19,'alexmorgan','earn',10.00,3604.84,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:39:56'),
(92,19,'alexmorgan','expense',9.80,3595.04,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 15:41:24'),
(93,19,'alexmorgan','earn',10.00,3605.04,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 15:41:24'),
(94,19,'alexmorgan','spend',2999.00,606.04,'商城购物','商城下单，共1件商品',0,'','2026-07-17 15:52:58'),
(95,19,'alexmorgan','expense',2939.02,23367.02,'商城购物','购买商品《手机》',0,'','2026-07-17 16:35:31'),
(96,3,'tech_guru','expense',13.50,297.45,'推广码生成','生成推广码 带定价测试（2项奖励）',0,'','2026-07-17 17:20:28'),
(97,3,'tech_guru','earn',13.50,310.95,'推广码撤销','撤销推广码 EB571FEE 退款',0,'','2026-07-17 17:20:38'),
(100,10005,'promo_test1','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:41:17'),
(101,10006,'promo_buyer','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:42:42'),
(102,10007,'promo_test2','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 17:44:52'),
(104,10008,'promo_pts','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:01:17'),
(106,10009,'promo_pts2','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:02:02'),
(107,10009,'promo_pts2','expense',2939.02,7060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:03:44'),
(108,10010,'promo_dbg','expense',2939.02,2060.98,'商城购物','购买商品《手机》',0,'','2026-07-17 18:05:00'),
(109,10011,'promo_dual','expense',9.80,4990.20,'商城购物','购买商品《移动端组件库》',0,'','2026-07-17 18:39:28'),
(110,10011,'promo_dual','earn',10.00,5000.20,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:28'),
(111,19,'alexmorgan','earn',0.29,23367.31,'推广返佣','mall #31 返佣',0,'','2026-07-17 18:39:28'),
(112,10011,'promo_dual','earn',10.00,5010.20,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:28'),
(113,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:39:50'),
(114,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:42:55'),
(115,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:47:26'),
(116,10011,'promo_dual','earn',10.00,5010.00,'商城购买赠送','购买《移动端组件库》赠送¥10',0,'','2026-07-17 18:47:59'),
(117,19,'alexmorgan','expense',48.00,23319.31,'会员购买','购买至尊会员',0,'','2026-07-17 19:37:42'),
(118,3,'tech_guru','earn',1.44,312.39,'推广返佣','membership #18 返佣',0,'','2026-07-17 19:37:43'),
(119,19,'alexmorgan','expense',15.00,23304.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:46'),
(120,3,'tech_guru','earn',0.45,312.84,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:46'),
(121,19,'alexmorgan','expense',15.00,23289.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:50'),
(122,3,'tech_guru','earn',0.45,313.29,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:50'),
(123,19,'alexmorgan','expense',15.00,23274.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:37:57'),
(124,3,'tech_guru','earn',0.45,313.74,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:37:57'),
(125,19,'alexmorgan','expense',10.00,23264.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:38:02'),
(126,19,'alexmorgan','earn',3.00,23277.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:38:02'),
(127,3,'tech_guru','earn',0.30,314.04,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:38:02'),
(128,19,'alexmorgan','expense',48.00,23219.31,'会员购买','购买至尊会员',0,'','2026-07-17 19:38:04'),
(129,3,'tech_guru','earn',1.44,315.48,'推广返佣','membership #18 返佣',0,'','2026-07-17 19:38:04'),
(130,19,'alexmorgan','expense',10.00,23209.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:09'),
(131,19,'alexmorgan','earn',3.00,23222.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:43:09'),
(132,3,'tech_guru','earn',0.30,315.78,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:09'),
(133,19,'alexmorgan','expense',10.00,23202.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:15'),
(134,19,'alexmorgan','earn',3.00,23215.31,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-17 19:43:15'),
(135,3,'tech_guru','earn',0.30,316.08,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:15'),
(136,19,'alexmorgan','expense',10.00,23195.31,'会员购买','购买黄金会员',0,'','2026-07-17 19:43:19'),
(137,3,'tech_guru','earn',0.30,316.38,'推广返佣','membership #19 返佣',0,'','2026-07-17 19:43:19'),
(138,19,'alexmorgan','expense',15.00,23180.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:23'),
(139,3,'tech_guru','earn',0.45,316.83,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:23'),
(140,19,'alexmorgan','expense',15.00,23165.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:27'),
(141,3,'tech_guru','earn',0.45,317.28,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:27'),
(142,19,'alexmorgan','expense',15.00,23150.31,'会员购买','购买钻石会员',0,'','2026-07-17 19:43:32'),
(143,3,'tech_guru','earn',0.45,317.73,'推广返佣','membership #13 返佣',0,'','2026-07-17 19:43:32'),
(144,19,'alexmorgan','expense',2939.02,20211.29,'商城购物','购买商品《手机》',0,'','2026-07-17 23:58:36'),
(145,3,'tech_guru','earn',88.17,405.90,'推广返佣','mall #37 返佣',0,'','2026-07-17 23:58:36'),
(146,19,'alexmorgan','expense',10.00,20201.29,'会员购买','购买黄金会员',0,'','2026-07-19 04:10:29'),
(147,19,'alexmorgan','earn',3.00,20214.29,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-19 04:10:29'),
(148,3,'tech_guru','earn',0.30,406.20,'推广返佣','membership #24 返佣',0,'','2026-07-19 04:10:29'),
(149,2,'','expense',50.00,0.00,'','累计违规 4 次触发附加扣除积分',0,'','2026-07-20 17:42:17'),
(150,2,'','expense',50.00,0.00,'','累计违规 5 次触发附加扣除积分',0,'','2026-07-20 17:48:36'),
(151,19,'alexmorgan','expense',10.00,20194.29,'会员购买','购买黄金会员',0,'','2026-07-21 00:23:38'),
(152,19,'alexmorgan','earn',3.00,20207.29,'会员开通赠送','开通黄金会员赠送余额',0,'','2026-07-21 00:23:38'),
(153,3,'tech_guru','earn',0.30,406.50,'推广返佣','membership #24 返佣',0,'','2026-07-21 00:23:38'),
(154,2,'lisa_chen','expense',50.00,450.00,'余额转账','转账给 bobwang(含手续费0.00)',0,'','2026-07-21 16:06:58'),
(155,1,'bobwang','earn',50.00,550.00,'余额转账','收到 lisa_chen 转账',0,'','2026-07-21 16:06:58'),
(156,1,'bobwang','earn',100.00,650.00,'余额充值','充值订单 TEST_TXN_001',0,'','2026-07-21 16:12:14'),
(157,2,'lisa_chen','earn',50.00,500.00,'余额充值','充值订单 TEST_TXN_002',0,'','2026-07-21 16:12:14');
/*!40000 ALTER TABLE `balance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balance_transfer_records`
--

DROP TABLE IF EXISTS `balance_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fee` decimal(10,2) DEFAULT 0.00,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_transfer_records`
--

LOCK TABLES `balance_transfer_records` WRITE;
/*!40000 ALTER TABLE `balance_transfer_records` DISABLE KEYS */;
INSERT INTO `balance_transfer_records` VALUES
(1,2,'lisa_chen',1,'bobwang',50.00,0.00,'','2026-07-21 16:06:58');
/*!40000 ALTER TABLE `balance_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `browse_history`
--

DROP TABLE IF EXISTS `browse_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `browse_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_type` varchar(10) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_title` varchar(300) DEFAULT '',
  `item_cover` varchar(500) DEFAULT '',
  `item_url` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_browse_history_user` (`user_id`),
  KEY `idx_browse_history_item` (`item_type`,`item_id`),
  KEY `idx_browse_history_ctime` (`create_time`),
  KEY `idx_browse_history_user_time` (`user_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=855 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `browse_history`
--

LOCK TABLES `browse_history` WRITE;
/*!40000 ALTER TABLE `browse_history` DISABLE KEYS */;
INSERT INTO `browse_history` VALUES
(10,19,'app',8,'Weather AI','','/a/8','2026-07-11 11:42:25'),
(11,19,'app',6,'Task Flow','','/a/6','2026-07-11 11:43:03'),
(12,19,'app',9,'Fitness Coach','','/a/9','2026-07-11 11:43:25'),
(22,19,'app',4,'Music Maker','','/a/4','2026-07-12 21:52:05'),
(66,19,'post',5,'Vue3 + TypeScript 实战','','/p/5','2026-07-13 18:34:16'),
(67,19,'post',4,'我的应用开发历程','','/p/4','2026-07-13 18:34:20'),
(97,19,'post',1,'666','','/s/1','2026-07-14 10:53:36'),
(100,19,'post',16,'666','','/p/16','2026-07-14 11:43:42'),
(103,19,'post',17,'8888888888','','/p/17','2026-07-14 12:01:25'),
(104,19,'post',10,'面试经历分享','','/p/10','2026-07-14 12:01:36'),
(105,19,'post',8,'移动开发趋势2026','','/p/8','2026-07-14 12:01:42'),
(241,19,'app',1,'Pro Photo Editor','','/a/1','2026-07-15 04:25:43'),
(527,19,'post',23,'【付费解锁测试】精品设计教程 - 从入门到精通','','/p/23','2026-07-15 18:51:37'),
(681,10001,'post',21,'付费内容与权限解锁功能全套测试 - 会员权益篇','','/p/21','2026-07-16 00:18:07'),
(682,10001,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 00:18:10'),
(683,10001,'post',19,'编辑器文字格式功能全面测试 - 基础排版篇','','/p/19','2026-07-16 00:18:24'),
(685,10001,'post',28,'【测试】称号解锁功能 - 设计达人专属内容','','/p/28','2026-07-16 00:23:08'),
(694,19,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 12:33:54'),
(695,19,'post',19,'编辑器文字格式功能全面测试 - 基础排版篇','','/p/19','2026-07-16 12:33:55'),
(696,19,'post',20,'社区卡片与多媒体模块功能测试 - 互动组件篇','','/p/20','2026-07-16 12:33:57'),
(697,19,'post',21,'付费内容与权限解锁功能全套测试 - 会员权益篇','','/p/21','2026-07-16 12:33:58'),
(721,10001,'post',27,'【评论解锁】隐藏的设计资源链接 - 评论即可查看','','/p/27','2026-07-16 15:43:30'),
(723,10001,'post',26,'【登录可见】社区新人必读 - 发帖规范与积分规则详解','','/p/26','2026-07-16 15:43:41'),
(725,10001,'post',23,'【付费解锁测试】精品设计教程 - 从入门到精通','','/p/23','2026-07-16 15:43:54'),
(730,10001,'post',29,'666','','/p/29','2026-07-16 16:41:42'),
(735,10001,'post',22,'666','','/p/22','2026-07-16 19:31:46'),
(737,10001,'app',7,'Mind Map Pro','','/a/7','2026-07-16 19:32:20'),
(738,10001,'app',12,'百变引擎','','/a/12','2026-07-16 19:32:25'),
(740,19,'post',29,'666','','/p/29','2026-07-16 19:42:56'),
(741,19,'post',22,'666','','/p/22','2026-07-16 21:35:50'),
(746,19,'app',7,'Mind Map Pro','','/a/7','2026-07-16 22:54:05'),
(747,19,'post',18,'66666','','/p/18','2026-07-17 02:26:02'),
(758,19,'post',25,'【等级限制】Lv.2 经验等级专属 - 进阶设计技巧分享','','/p/25','2026-07-17 23:05:33'),
(763,19,'post',31,'888','','/p/31','2026-07-18 00:10:05'),
(765,19,'post',30,'29922929','','/p/30','2026-07-18 00:10:19'),
(780,19,'post',32,'99999','','/p/32','2026-07-18 14:05:34'),
(782,19,'post',34,'Test Post Title','','/p/34','2026-07-19 06:23:44'),
(787,19,'app',12,'百变引擎','','/a/12','2026-07-20 07:19:00'),
(788,19,'post',59,'Alex的未通过帖','','/p/59','2026-07-21 00:30:47'),
(796,19,'post',33,'定时','','/p/33','2026-07-21 04:03:17'),
(829,19,'post',57,'管线reject保留测试','','/p/57','2026-07-21 04:54:43'),
(830,19,'post',39,'测试审核管线帖子','','/p/39','2026-07-21 04:54:46'),
(832,19,'post',28,'【测试】称号解锁功能 - 设计达人专属内容','','/p/28','2026-07-21 04:55:06'),
(833,19,'post',56,'敏感帖子','','/p/56','2026-07-21 04:55:09'),
(834,19,'post',24,'【会员专属】黄金会员专属福利 - 设计素材大礼包','','/p/24','2026-07-21 04:55:11'),
(851,19,'post',55,'管线测试帖-Tech','','/p/55','2026-07-21 05:01:20'),
(852,19,'post',26,'【登录可见】社区新人必读 - 发帖规范与积分规则详解','','/p/26','2026-07-21 06:50:56'),
(853,10002,'app',1,'Test','','','2026-07-21 15:28:58'),
(854,19,'post',27,'【评论解锁】隐藏的设计资源链接 - 评论即可查看','','/p/27','2026-07-21 18:08:25');
/*!40000 ALTER TABLE `browse_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(50) DEFAULT 'discount',
  `status` varchar(20) DEFAULT 'draft',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT '',
  `description` text DEFAULT NULL,
  `page_title` varchar(200) DEFAULT '',
  `page_content` text DEFAULT NULL,
  `rules` text DEFAULT NULL,
  `rewards` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`rewards`)),
  `max_participants` int(11) DEFAULT 0,
  `participant_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_campaigns_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_keys`
--

DROP TABLE IF EXISTS `card_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_no` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'membership',
  `target_id` int(11) DEFAULT 0,
  `target_name` varchar(100) DEFAULT '',
  `value` int(11) DEFAULT 0,
  `extra_points` int(11) DEFAULT 0,
  `extra_experience` int(11) DEFAULT 0,
  `extra_balance` decimal(10,2) DEFAULT 0.00,
  `duration` int(11) DEFAULT 0,
  `duration_unit` varchar(10) DEFAULT '',
  `status` varchar(2) DEFAULT '0',
  `create_by` varchar(100) DEFAULT '管理员',
  `create_time` datetime DEFAULT current_timestamp(),
  `redeem_by` varchar(100) DEFAULT '',
  `redeem_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_no` (`card_no`),
  KEY `idx_card_keys_card_no` (`card_no`),
  KEY `idx_card_keys_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_keys`
--

LOCK TABLES `card_keys` WRITE;
/*!40000 ALTER TABLE `card_keys` DISABLE KEYS */;
INSERT INTO `card_keys` VALUES
(1,'CDK-KHWVRT97','0kmgb0','points',0,'',462,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(2,'CDK-5290BIZB','hpmpf2','points',0,'',403,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(3,'CDK-RV1LEJFT','0c65nx','points',0,'',153,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(4,'CDK-RZEZXZ38','pjkj1k','points',0,'',211,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(5,'CDK-DHIJ209G','ux6bph','points',0,'',593,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(6,'CDK-B03HO2DX','w2gns1','points',0,'',123,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(7,'CDK-GO78G7ZS','6kxhzr','points',0,'',404,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(8,'CDK-EQI7TQLR','qp3uc1','points',0,'',568,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(9,'CDK-5XH0BZBA','s17s02','points',0,'',512,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(10,'CDK-55Y88WZ9','fpawmz','points',0,'',581,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(11,'CDK-KT12HIH0','0ve3ri','points',0,'',555,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(12,'CDK-YG0XEHLD','1iyd5a','points',0,'',289,0,0,0.00,0,'','0','管理员','2026-07-10 22:39:53','',NULL),
(13,'CDK-VNXEKNE9','vcwhtn','points',0,'',495,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(14,'CDK-8JFVFCN8','yxnsyx','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(15,'CDK-2IQ5GVLW','54fvq5','points',0,'',493,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(16,'CDK-376FCU46','qj8d61','points',0,'',428,0,0,0.00,0,'','1','管理员','2026-07-10 22:39:53','','2026-07-10 22:39:53'),
(17,'CDK-NU7STSR7','7ok43h','points',0,'',342,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(18,'CDK-LSQZ95KR','8kustz','points',0,'',344,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(19,'CDK-V63CBG8O','xznppx','points',0,'',234,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(20,'CDK-38YSP7G6','a1j12m','points',0,'',250,0,0,0.00,0,'','2','管理员','2026-07-10 22:39:53','',NULL),
(21,'CDKEY-MRG47L1VS1EE','VDIR0Q5M','balance',1,'5000元余额',5000,99999,2000,0.00,12,'month','1','管理员','2026-07-11 08:41:04','alexmorgan','2026-07-11 08:41:23'),
(22,'CDKEY-MRMRD84EXRNR','TB75YMFP','balance',1,'2000元余额',2000,10000,5000,0.00,12,'month','1','管理员','2026-07-16 00:15:55','35735712','2026-07-16 00:16:12');
/*!40000 ALTER TABLE `card_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gift_records`
--

DROP TABLE IF EXISTS `chat_gift_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gift_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT 0,
  `gift_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `points_cost` int(11) DEFAULT 0,
  `message_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_gift_records_room` (`room_id`),
  KEY `idx_chat_gift_records_gift` (`gift_id`),
  KEY `idx_chat_gift_records_from` (`from_user_id`),
  KEY `idx_chat_gift_records_to` (`to_user_id`),
  KEY `idx_chat_gift_records_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gift_records`
--

LOCK TABLES `chat_gift_records` WRITE;
/*!40000 ALTER TABLE `chat_gift_records` DISABLE KEYS */;
INSERT INTO `chat_gift_records` VALUES
(1,3,1,2,7,3,0,0,'2026-07-10 22:39:53'),
(2,3,2,15,4,8,0,0,'2026-07-10 22:39:53'),
(3,1,3,15,6,6,0,0,'2026-07-10 22:39:53'),
(4,2,4,9,15,6,0,0,'2026-07-10 22:39:53'),
(5,4,1,3,5,2,0,0,'2026-07-10 22:39:53'),
(6,2,2,14,4,5,0,0,'2026-07-10 22:39:53'),
(7,2,3,12,11,7,0,0,'2026-07-10 22:39:53'),
(8,3,4,9,10,8,0,0,'2026-07-10 22:39:53'),
(9,1,1,8,5,8,0,0,'2026-07-10 22:39:53'),
(10,4,2,11,2,3,0,0,'2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gift_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_gifts`
--

DROP TABLE IF EXISTS `chat_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `price` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `animation` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_gifts`
--

LOCK TABLES `chat_gifts` WRITE;
/*!40000 ALTER TABLE `chat_gifts` DISABLE KEYS */;
INSERT INTO `chat_gifts` VALUES
(1,'flower','',5,'coin','',0,'active','2026-07-10 22:39:53'),
(2,'heart','',10,'coin','',0,'active','2026-07-10 22:39:53'),
(3,'star','',20,'coin','',0,'active','2026-07-10 22:39:53'),
(4,'rocket','',50,'coin','',0,'active','2026-07-10 22:39:53');
/*!40000 ALTER TABLE `chat_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_reports`
--

DROP TABLE IF EXISTS `chat_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT 0,
  `target_user_id` int(11) DEFAULT 0,
  `conversation_id` int(11) DEFAULT 0,
  `reason` varchar(50) DEFAULT '',
  `detail` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `handler_id` int(11) DEFAULT 0,
  `handle_notes` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `handle_time` datetime DEFAULT NULL,
  `room_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_chat_reports_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_reports`
--

LOCK TABLES `chat_reports` WRITE;
/*!40000 ALTER TABLE `chat_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_admin_logs`
--

DROP TABLE IF EXISTS `chat_room_admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_user_id` int(11) DEFAULT 0,
  `target_user_name` varchar(100) DEFAULT '',
  `detail` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_admin_logs`
--

LOCK TABLES `chat_room_admin_logs` WRITE;
/*!40000 ALTER TABLE `chat_room_admin_logs` DISABLE KEYS */;
INSERT INTO `chat_room_admin_logs` VALUES
(1,5,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"1\"','2026-07-12 12:19:47'),
(2,6,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"审批制测试群\"','2026-07-16 20:44:28'),
(3,7,19,'alexmorgan','create',19,'alexmorgan','创建了聊天室 \"审批测试群2\"','2026-07-16 20:50:06'),
(4,7,19,'alexmorgan','approve_join',10003,'test_joiner','审核通过入群申请','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_bans`
--

DROP TABLE IF EXISTS `chat_room_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'temp',
  `reason` text DEFAULT '',
  `ban_until` datetime DEFAULT NULL,
  `banned_by` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`),
  KEY `idx_chat_room_bans_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_bans`
--

LOCK TABLES `chat_room_bans` WRITE;
/*!40000 ALTER TABLE `chat_room_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_files`
--

DROP TABLE IF EXISTS `chat_room_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT 'other',
  `file_size` int(11) DEFAULT 0,
  `mime_type` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_room_files_room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_files`
--

LOCK TABLES `chat_room_files` WRITE;
/*!40000 ALTER TABLE `chat_room_files` DISABLE KEYS */;
INSERT INTO `chat_room_files` VALUES
(1,5,19,'alexmorgan','chat_1783859261750_1377.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg','image',0,'image/jpg','2026-07-12 12:27:42'),
(2,5,19,'alexmorgan','chat_1783860297159_7139.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg','image',0,'image/jpg','2026-07-12 12:44:57');
/*!40000 ALTER TABLE `chat_room_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_join_requests`
--

DROP TABLE IF EXISTS `chat_room_join_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_join_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(200) DEFAULT '',
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_join_requests`
--

LOCK TABLES `chat_room_join_requests` WRITE;
/*!40000 ALTER TABLE `chat_room_join_requests` DISABLE KEYS */;
INSERT INTO `chat_room_join_requests` VALUES
(1,6,10003,'test_joiner','','我对这个群聊话题很感兴趣，希望加入交流','pending',0,'','','2026-07-16 20:47:51',NULL),
(2,7,10003,'test_joiner','','我对这个话题很感兴趣','approved',19,'alexmorgan','欢迎加入我们!','2026-07-16 20:50:06','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_join_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_limit_upgrades`
--

DROP TABLE IF EXISTS `chat_room_limit_upgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_limit_upgrades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `current_limit` int(11) DEFAULT 50,
  `request_limit` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_limit_upgrades`
--

LOCK TABLES `chat_room_limit_upgrades` WRITE;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_limit_upgrades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_members`
--

DROP TABLE IF EXISTS `chat_room_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` varchar(20) DEFAULT 'member',
  `muted_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `join_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_id` (`room_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_members`
--

LOCK TABLES `chat_room_members` WRITE;
/*!40000 ALTER TABLE `chat_room_members` DISABLE KEYS */;
INSERT INTO `chat_room_members` VALUES
(1,1,2,'member',NULL,'active','2026-07-10 22:39:53'),
(2,1,3,'member',NULL,'active','2026-07-10 22:39:53'),
(3,1,4,'owner',NULL,'active','2026-07-10 22:39:53'),
(4,1,7,'member',NULL,'active','2026-07-10 22:39:53'),
(5,1,9,'member',NULL,'active','2026-07-10 22:39:53'),
(6,1,10,'member',NULL,'active','2026-07-10 22:39:53'),
(7,1,11,'member',NULL,'active','2026-07-10 22:39:53'),
(8,1,12,'member',NULL,'active','2026-07-10 22:39:53'),
(9,1,13,'member',NULL,'active','2026-07-10 22:39:53'),
(10,1,14,'member',NULL,'active','2026-07-10 22:39:53'),
(11,2,3,'member',NULL,'active','2026-07-10 22:39:53'),
(12,2,4,'member',NULL,'active','2026-07-10 22:39:53'),
(13,2,5,'owner',NULL,'active','2026-07-10 22:39:53'),
(14,2,6,'member',NULL,'active','2026-07-10 22:39:53'),
(15,2,8,'member',NULL,'active','2026-07-10 22:39:53'),
(16,2,9,'member',NULL,'active','2026-07-10 22:39:53'),
(17,2,11,'member',NULL,'active','2026-07-10 22:39:53'),
(18,2,12,'member',NULL,'active','2026-07-10 22:39:53'),
(19,2,13,'member',NULL,'active','2026-07-10 22:39:53'),
(20,2,14,'member',NULL,'active','2026-07-10 22:39:53'),
(21,2,15,'member',NULL,'active','2026-07-10 22:39:53'),
(22,2,16,'member',NULL,'active','2026-07-10 22:39:53'),
(23,3,2,'owner',NULL,'active','2026-07-10 22:39:53'),
(24,3,3,'member',NULL,'active','2026-07-10 22:39:53'),
(25,3,5,'member',NULL,'active','2026-07-10 22:39:53'),
(26,3,6,'member',NULL,'active','2026-07-10 22:39:53'),
(27,3,7,'member',NULL,'active','2026-07-10 22:39:53'),
(28,3,8,'member',NULL,'active','2026-07-10 22:39:53'),
(29,3,9,'member',NULL,'active','2026-07-10 22:39:53'),
(30,3,10,'member',NULL,'active','2026-07-10 22:39:53'),
(31,3,11,'member',NULL,'active','2026-07-10 22:39:53'),
(32,3,13,'member',NULL,'active','2026-07-10 22:39:53'),
(33,3,14,'member',NULL,'active','2026-07-10 22:39:53'),
(34,3,15,'member',NULL,'active','2026-07-10 22:39:53'),
(35,3,16,'member',NULL,'active','2026-07-10 22:39:53'),
(36,4,5,'member',NULL,'active','2026-07-10 22:39:53'),
(37,4,6,'member',NULL,'active','2026-07-10 22:39:53'),
(38,4,7,'member',NULL,'active','2026-07-10 22:39:53'),
(39,4,9,'member',NULL,'active','2026-07-10 22:39:53'),
(40,4,10,'member',NULL,'active','2026-07-10 22:39:53'),
(41,4,11,'member',NULL,'active','2026-07-10 22:39:53'),
(42,4,12,'member',NULL,'active','2026-07-10 22:39:53'),
(43,4,13,'owner',NULL,'active','2026-07-10 22:39:53'),
(44,4,16,'member',NULL,'active','2026-07-10 22:39:53'),
(45,5,19,'owner',NULL,'active','2026-07-12 12:19:47'),
(46,5,10001,'member',NULL,'active','2026-07-16 19:34:56'),
(47,6,19,'owner',NULL,'active','2026-07-16 20:44:28'),
(48,7,19,'owner',NULL,'active','2026-07-16 20:50:06'),
(49,7,10003,'member',NULL,'active','2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_room_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_messages`
--

DROP TABLE IF EXISTS `chat_room_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `content` text DEFAULT '',
  `image_url` text DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `mention_ids` text DEFAULT '[]',
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  `order_card` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_room_messages_user` (`from_user_id`),
  KEY `idx_chat_room_messages_room` (`room_id`),
  KEY `idx_chat_room_messages_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_messages`
--

LOCK TABLES `chat_room_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_messages` DISABLE KEYS */;
INSERT INTO `chat_room_messages` VALUES
(1,1,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 07:39:53'),
(2,1,13,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 08:39:53'),
(3,1,16,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 09:39:53'),
(4,1,10,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 17:39:53'),
(5,1,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 13:39:53'),
(6,1,6,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-09 11:39:53'),
(7,1,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 22:39:53'),
(8,2,10,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 15:39:53'),
(9,2,4,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 22:39:53'),
(10,2,13,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-09 18:39:53'),
(11,2,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 13:39:53'),
(12,2,6,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 23:39:53'),
(13,2,8,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 18:39:53'),
(14,2,11,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 01:39:53'),
(15,2,6,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-10 12:39:53'),
(16,2,4,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 04:39:53'),
(17,3,14,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-09 10:39:53'),
(18,3,2,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-09 10:39:53'),
(19,3,14,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 01:39:53'),
(20,3,8,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-09 10:39:53'),
(21,3,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-09 12:39:53'),
(22,3,7,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 22:39:53'),
(23,3,12,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 05:39:53'),
(24,4,5,'','','这是聊天消息 #1','','text','[]',0,'none','','2026-07-10 08:39:53'),
(25,4,14,'','','这是聊天消息 #2','','text','[]',0,'none','','2026-07-10 18:39:53'),
(26,4,4,'','','这是聊天消息 #3','','text','[]',0,'none','','2026-07-10 19:39:53'),
(27,4,11,'','','这是聊天消息 #4','','text','[]',0,'none','','2026-07-10 12:39:53'),
(28,4,5,'','','这是聊天消息 #5','','text','[]',0,'none','','2026-07-10 22:39:53'),
(29,4,9,'','','这是聊天消息 #6','','text','[]',0,'none','','2026-07-10 00:39:53'),
(30,4,16,'','','这是聊天消息 #7','','text','[]',0,'none','','2026-07-10 14:39:53'),
(31,4,13,'','','这是聊天消息 #8','','text','[]',0,'none','','2026-07-09 06:39:53'),
(32,4,7,'','','这是聊天消息 #9','','text','[]',0,'none','','2026-07-09 22:39:53'),
(33,4,16,'','','这是聊天消息 #10','','text','[]',0,'none','','2026-07-09 20:39:53'),
(34,4,5,'','','这是聊天消息 #11','','text','[]',0,'none','','2026-07-09 10:39:53'),
(35,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','6','','text','[]',0,'none','','2026-07-12 12:27:34'),
(36,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg','text','[]',0,'none','','2026-07-12 12:27:42'),
(37,5,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw.png','','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg','text','[]',0,'none','','2026-07-12 12:44:57'),
(38,5,10001,'35735712','#448AFF','666','','text','[]',0,'none','','2026-07-16 19:35:02'),
(39,5,10001,'35735712','#448AFF','[投诉反馈]','','text','[]',0,'none','','2026-07-16 19:39:06'),
(40,7,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','6','','text','[]',0,'none','','2026-07-17 03:03:45');
/*!40000 ALTER TABLE `chat_room_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_pinned_messages`
--

DROP TABLE IF EXISTS `chat_room_pinned_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_pinned_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `pinned_by` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_pinned_messages`
--

LOCK TABLES `chat_room_pinned_messages` WRITE;
/*!40000 ALTER TABLE `chat_room_pinned_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_room_pinned_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `avatar` varchar(500) DEFAULT '',
  `owner_id` int(11) NOT NULL,
  `password` varchar(100) DEFAULT '',
  `max_members` int(11) DEFAULT 500,
  `member_limit` int(11) DEFAULT 50,
  `join_mode` varchar(20) DEFAULT 'public',
  `status` varchar(20) DEFAULT 'active',
  `chat_enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_chat_rooms_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_rooms`
--

LOCK TABLES `chat_rooms` WRITE;
/*!40000 ALTER TABLE `chat_rooms` DISABLE KEYS */;
INSERT INTO `chat_rooms` VALUES
(1,'设计交流群','','',4,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(2,'技术讨论组','','',5,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(3,'综合聊天室','','',2,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(4,'AI爱好者','','',13,'',200,50,'public','1',1,'2026-07-10 22:39:53'),
(5,'1','2','',19,'',500,50,'public','active',1,'2026-07-12 12:19:46'),
(6,'审批制测试群','用于测试入群申请流程','',19,'',500,50,'public','active',1,'2026-07-16 20:44:28'),
(7,'审批测试群2','完整测试入群流程','',19,'',500,50,'public','active',1,'2026-07-16 20:50:06');
/*!40000 ALTER TABLE `chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_groups`
--

DROP TABLE IF EXISTS `checkin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level_id` int(11) DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#409EFF',
  `points` int(11) DEFAULT 5,
  `experience` int(11) DEFAULT 2,
  `balance` decimal(10,2) DEFAULT 0.00,
  `points_consecutive` int(11) DEFAULT 2,
  `experience_consecutive` int(11) DEFAULT 1,
  `balance_consecutive` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_groups`
--

LOCK TABLES `checkin_groups` WRITE;
/*!40000 ALTER TABLE `checkin_groups` DISABLE KEYS */;
INSERT INTO `checkin_groups` VALUES
(1,'默认分组',0,'S','#409EFF',10,2,0.00,2,1,0.00,0,'1','2026-07-10 22:39:54','2026-07-11 17:17:44');
/*!40000 ALTER TABLE `checkin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_milestones`
--

DROP TABLE IF EXISTS `checkin_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT 0,
  `days` int(11) NOT NULL DEFAULT 3,
  `points` int(11) DEFAULT 0,
  `experience` int(11) DEFAULT 0,
  `balance` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `card_key_duration_unit` varchar(10) DEFAULT '',
  `card_key_extra_points` int(11) DEFAULT 0,
  `card_key_extra_experience` int(11) DEFAULT 0,
  `card_key_extra_balance` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_milestones`
--

LOCK TABLES `checkin_milestones` WRITE;
/*!40000 ALTER TABLE `checkin_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_records`
--

DROP TABLE IF EXISTS `checkin_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `checkin_date` date NOT NULL,
  `consecutive_days` int(11) DEFAULT 1,
  `points_earned` int(11) DEFAULT 0,
  `experience_earned` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`checkin_date`),
  KEY `idx_checkin_records_user_date` (`user_id`,`checkin_date`),
  KEY `idx_checkin_records_user_time` (`user_id`,`checkin_date`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_records`
--

LOCK TABLES `checkin_records` WRITE;
/*!40000 ALTER TABLE `checkin_records` DISABLE KEYS */;
INSERT INTO `checkin_records` VALUES
(1,3,'','2026-07-10',2,18,0,'2026-07-10 22:39:53'),
(2,7,'','2026-07-10',14,17,0,'2026-07-10 22:39:53'),
(3,9,'','2026-07-10',2,16,0,'2026-07-10 22:39:53'),
(4,6,'','2026-07-10',7,21,0,'2026-07-10 22:39:53'),
(5,10,'','2026-07-10',7,7,0,'2026-07-10 22:39:53'),
(6,14,'','2026-07-09',13,6,0,'2026-07-09 22:39:53'),
(7,11,'','2026-07-09',12,20,0,'2026-07-09 22:39:53'),
(8,12,'','2026-07-09',8,13,0,'2026-07-09 22:39:53'),
(9,2,'','2026-07-09',7,9,0,'2026-07-09 22:39:53'),
(10,8,'','2026-07-08',2,11,0,'2026-07-08 22:39:53'),
(11,11,'','2026-07-08',12,12,0,'2026-07-08 22:39:53'),
(12,2,'','2026-07-08',14,17,0,'2026-07-08 22:39:53'),
(13,6,'','2026-07-07',11,18,0,'2026-07-07 22:39:53'),
(14,13,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(15,8,'','2026-07-07',1,11,0,'2026-07-07 22:39:53'),
(16,2,'','2026-07-07',5,6,0,'2026-07-07 22:39:53'),
(17,5,'','2026-07-06',15,6,0,'2026-07-06 22:39:53'),
(18,12,'','2026-07-06',14,8,0,'2026-07-06 22:39:53'),
(19,13,'','2026-07-06',13,11,0,'2026-07-06 22:39:53'),
(20,10,'','2026-07-06',11,15,0,'2026-07-06 22:39:53'),
(21,9,'','2026-07-06',2,23,0,'2026-07-06 22:39:53'),
(22,4,'','2026-07-06',7,12,0,'2026-07-06 22:39:53'),
(23,11,'','2026-07-05',4,5,0,'2026-07-05 22:39:53'),
(24,13,'','2026-07-05',7,18,0,'2026-07-05 22:39:53'),
(25,6,'','2026-07-05',15,7,0,'2026-07-05 22:39:53'),
(26,3,'','2026-07-05',1,10,0,'2026-07-05 22:39:53'),
(27,11,'','2026-07-04',1,18,0,'2026-07-04 22:39:53'),
(28,2,'','2026-07-04',7,20,0,'2026-07-04 22:39:53'),
(29,4,'','2026-07-04',12,20,0,'2026-07-04 22:39:53'),
(30,12,'','2026-07-04',1,12,0,'2026-07-04 22:39:53'),
(31,12,'','2026-07-03',14,15,0,'2026-07-03 22:39:53'),
(32,14,'','2026-07-03',15,13,0,'2026-07-03 22:39:53'),
(33,2,'','2026-07-03',14,11,0,'2026-07-03 22:39:53'),
(34,13,'','2026-07-03',1,12,0,'2026-07-03 22:39:53'),
(35,3,'','2026-07-03',8,5,0,'2026-07-03 22:39:53'),
(36,15,'','2026-07-02',12,13,0,'2026-07-02 22:39:53'),
(37,4,'','2026-07-02',14,13,0,'2026-07-02 22:39:53'),
(38,2,'','2026-07-02',11,7,0,'2026-07-02 22:39:53'),
(39,11,'','2026-07-01',10,16,0,'2026-07-01 22:39:53'),
(40,8,'','2026-07-01',9,12,0,'2026-07-01 22:39:53'),
(41,7,'','2026-07-01',6,6,0,'2026-07-01 22:39:53'),
(42,5,'','2026-07-01',10,24,0,'2026-07-01 22:39:53'),
(43,14,'','2026-06-30',6,17,0,'2026-06-30 22:39:53'),
(44,2,'','2026-06-30',10,21,0,'2026-06-30 22:39:53'),
(45,7,'','2026-06-30',1,14,0,'2026-06-30 22:39:53'),
(46,13,'','2026-06-30',2,9,0,'2026-06-30 22:39:53'),
(47,11,'','2026-06-29',5,22,0,'2026-06-29 22:39:53'),
(48,14,'','2026-06-29',5,19,0,'2026-06-29 22:39:53'),
(49,10,'','2026-06-29',11,24,0,'2026-06-29 22:39:53'),
(50,8,'','2026-06-29',10,24,0,'2026-06-29 22:39:53'),
(51,11,'','2026-06-28',15,18,0,'2026-06-28 22:39:53'),
(52,14,'','2026-06-28',7,19,0,'2026-06-28 22:39:53'),
(53,7,'','2026-06-28',6,5,0,'2026-06-28 22:39:53'),
(54,8,'','2026-06-28',9,24,0,'2026-06-28 22:39:53'),
(55,12,'','2026-06-28',15,12,0,'2026-06-28 22:39:53'),
(56,2,'','2026-06-28',9,20,0,'2026-06-28 22:39:53'),
(57,15,'','2026-06-27',1,5,0,'2026-06-27 22:39:53'),
(58,2,'','2026-06-27',6,9,0,'2026-06-27 22:39:53'),
(59,4,'','2026-06-27',14,18,0,'2026-06-27 22:39:53'),
(60,13,'','2026-06-26',1,5,0,'2026-06-26 22:39:53'),
(61,9,'','2026-06-26',15,20,0,'2026-06-26 22:39:53'),
(62,2,'','2026-06-26',5,11,0,'2026-06-26 22:39:53'),
(63,5,'','2026-06-25',5,10,0,'2026-06-25 22:39:53'),
(64,10,'','2026-06-25',7,5,0,'2026-06-25 22:39:53'),
(65,15,'','2026-06-25',15,15,0,'2026-06-25 22:39:53'),
(66,5,'','2026-06-24',8,24,0,'2026-06-24 22:39:53'),
(67,6,'','2026-06-24',7,24,0,'2026-06-24 22:39:53'),
(68,15,'','2026-06-24',8,23,0,'2026-06-24 22:39:53'),
(69,2,'','2026-06-24',12,12,0,'2026-06-24 22:39:53'),
(70,14,'','2026-06-23',12,18,0,'2026-06-23 22:39:53'),
(71,15,'','2026-06-23',1,19,0,'2026-06-23 22:39:53'),
(72,6,'','2026-06-23',13,20,0,'2026-06-23 22:39:53'),
(73,5,'','2026-06-23',5,22,0,'2026-06-23 22:39:53'),
(74,2,'','2026-06-23',1,23,0,'2026-06-23 22:39:53'),
(75,14,'','2026-06-22',5,21,0,'2026-06-22 22:39:53'),
(76,5,'','2026-06-22',10,16,0,'2026-06-22 22:39:53'),
(77,9,'','2026-06-22',5,5,0,'2026-06-22 22:39:53'),
(78,10,'','2026-06-22',6,10,0,'2026-06-22 22:39:53'),
(79,15,'','2026-06-22',14,17,0,'2026-06-22 22:39:53'),
(80,8,'','2026-06-22',1,17,0,'2026-06-22 22:39:53'),
(81,6,'','2026-06-21',8,15,0,'2026-06-21 22:39:53'),
(82,4,'','2026-06-21',8,22,0,'2026-06-21 22:39:53'),
(83,14,'','2026-06-21',8,8,0,'2026-06-21 22:39:53'),
(84,10,'','2026-06-21',6,21,0,'2026-06-21 22:39:53'),
(85,7,'','2026-06-21',6,5,0,'2026-06-21 22:39:53'),
(86,12,'','2026-06-21',8,20,0,'2026-06-21 22:39:53'),
(87,9,'','2026-06-21',5,8,0,'2026-06-21 22:39:53'),
(88,8,'','2026-06-21',11,21,0,'2026-06-21 22:39:53'),
(89,4,'','2026-06-20',14,22,0,'2026-06-20 22:39:53'),
(90,5,'','2026-06-20',5,23,0,'2026-06-20 22:39:53'),
(91,15,'','2026-06-20',6,22,0,'2026-06-20 22:39:53'),
(92,6,'','2026-06-20',2,11,0,'2026-06-20 22:39:53'),
(93,7,'','2026-06-20',7,7,0,'2026-06-20 22:39:53'),
(94,9,'','2026-06-20',12,23,0,'2026-06-20 22:39:53'),
(95,14,'','2026-06-20',3,12,0,'2026-06-20 22:39:53'),
(96,14,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(97,7,'','2026-06-19',2,21,0,'2026-06-19 22:39:53'),
(98,15,'','2026-06-19',15,10,0,'2026-06-19 22:39:53'),
(99,2,'','2026-06-19',12,7,0,'2026-06-19 22:39:53'),
(100,12,'','2026-06-19',1,15,0,'2026-06-19 22:39:53'),
(101,9,'','2026-06-18',1,19,0,'2026-06-18 22:39:53'),
(102,6,'','2026-06-18',10,6,0,'2026-06-18 22:39:53'),
(103,3,'','2026-06-18',4,10,0,'2026-06-18 22:39:53'),
(104,10,'','2026-06-18',6,11,0,'2026-06-18 22:39:53'),
(105,2,'','2026-06-17',6,9,0,'2026-06-17 22:39:53'),
(106,7,'','2026-06-17',11,24,0,'2026-06-17 22:39:53'),
(107,9,'','2026-06-17',6,11,0,'2026-06-17 22:39:53'),
(108,15,'','2026-06-17',7,16,0,'2026-06-17 22:39:53'),
(109,5,'','2026-06-17',6,22,0,'2026-06-17 22:39:53'),
(110,8,'','2026-06-16',3,10,0,'2026-06-16 22:39:53'),
(111,15,'','2026-06-16',6,21,0,'2026-06-16 22:39:53'),
(112,10,'','2026-06-16',6,18,0,'2026-06-16 22:39:53'),
(113,2,'','2026-06-16',14,14,0,'2026-06-16 22:39:53'),
(114,4,'','2026-06-15',15,24,0,'2026-06-15 22:39:53'),
(115,11,'','2026-06-15',12,17,0,'2026-06-15 22:39:53'),
(116,13,'','2026-06-15',11,10,0,'2026-06-15 22:39:53'),
(117,8,'','2026-06-15',6,8,0,'2026-06-15 22:39:53'),
(118,13,'','2026-06-14',6,23,0,'2026-06-14 22:39:53'),
(119,5,'','2026-06-14',12,6,0,'2026-06-14 22:39:53'),
(120,12,'','2026-06-14',13,6,0,'2026-06-14 22:39:53'),
(121,9,'','2026-06-14',10,10,0,'2026-06-14 22:39:53'),
(122,11,'','2026-06-14',6,10,0,'2026-06-14 22:39:53'),
(123,7,'','2026-06-13',4,22,0,'2026-06-13 22:39:53'),
(124,6,'','2026-06-13',8,12,0,'2026-06-13 22:39:53'),
(125,5,'','2026-06-13',9,11,0,'2026-06-13 22:39:53'),
(126,2,'','2026-06-13',1,7,0,'2026-06-13 22:39:53'),
(127,13,'','2026-06-13',5,11,0,'2026-06-13 22:39:53'),
(128,13,'','2026-06-12',14,19,0,'2026-06-12 22:39:53'),
(129,2,'','2026-06-12',14,7,0,'2026-06-12 22:39:53'),
(130,6,'','2026-06-12',3,9,0,'2026-06-12 22:39:53'),
(131,8,'','2026-06-12',4,22,0,'2026-06-12 22:39:53'),
(132,15,'','2026-06-12',1,17,0,'2026-06-12 22:39:53'),
(133,7,'','2026-06-12',8,12,0,'2026-06-12 22:39:53'),
(134,15,'','2026-06-11',11,14,0,'2026-06-11 22:39:53'),
(135,4,'','2026-06-11',15,5,0,'2026-06-11 22:39:53'),
(136,7,'','2026-06-11',14,17,0,'2026-06-11 22:39:53'),
(137,19,'alexmorgan','2026-07-12',1,10,2,'2026-07-12 11:19:10'),
(139,19,'alexmorgan','2026-07-17',1,10,2,'2026-07-17 23:39:01');
/*!40000 ALTER TABLE `checkin_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_favorite_groups`
--

DROP TABLE IF EXISTS `collection_favorite_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_favorite_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认收藏夹',
  `sort_order` int(11) DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_favorite_groups`
--

LOCK TABLES `collection_favorite_groups` WRITE;
/*!40000 ALTER TABLE `collection_favorite_groups` DISABLE KEYS */;
INSERT INTO `collection_favorite_groups` VALUES
(1,1,'默认收藏夹',0,0,'2026-07-16 01:23:44'),
(2,1,'编程教程',1,0,'2026-07-16 01:27:18'),
(3,1,'小说合集',2,0,'2026-07-16 01:27:18'),
(4,19,'默认收藏夹',0,0,'2026-07-16 04:06:09'),
(8,19,'266666',1,0,'2026-07-16 11:04:40'),
(9,10001,'默认收藏夹',0,0,'2026-07-16 15:55:13');
/*!40000 ALTER TABLE `collection_favorite_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_favorites`
--

DROP TABLE IF EXISTS `collection_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_collection` (`user_id`,`collection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_favorites`
--

LOCK TABLES `collection_favorites` WRITE;
/*!40000 ALTER TABLE `collection_favorites` DISABLE KEYS */;
INSERT INTO `collection_favorites` VALUES
(5,19,1,0,'2026-07-19 15:20:25'),
(6,1,1,0,'2026-07-19 15:25:44');
/*!40000 ALTER TABLE `collection_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_likes`
--

DROP TABLE IF EXISTS `collection_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_collection_user` (`collection_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_likes`
--

LOCK TABLES `collection_likes` WRITE;
/*!40000 ALTER TABLE `collection_likes` DISABLE KEYS */;
INSERT INTO `collection_likes` VALUES
(1,1,1,'2026-07-19 15:06:23'),
(2,1,19,'2026-07-19 15:20:26');
/*!40000 ALTER TABLE `collection_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_read_progress`
--

DROP TABLE IF EXISTS `collection_read_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_read_progress` (
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `last_post_id` int(11) DEFAULT 0,
  `progress_pct` decimal(5,2) DEFAULT 0.00,
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  UNIQUE KEY `uk_user_collection` (`user_id`,`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_read_progress`
--

LOCK TABLES `collection_read_progress` WRITE;
/*!40000 ALTER TABLE `collection_read_progress` DISABLE KEYS */;
INSERT INTO `collection_read_progress` VALUES
(1,1,1,25.00,'2026-07-16 19:29:20');
/*!40000 ALTER TABLE `collection_read_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_reports`
--

DROP TABLE IF EXISTS `collection_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `reason` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `handled_by` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_reports`
--

LOCK TABLES `collection_reports` WRITE;
/*!40000 ALTER TABLE `collection_reports` DISABLE KEYS */;
INSERT INTO `collection_reports` VALUES
(1,1,1,'测试举报','pending',0,'2026-07-19 15:06:23','2026-07-19 15:06:23');
/*!40000 ALTER TABLE `collection_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_id` (`comment_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
INSERT INTO `comment_likes` VALUES
(4,14,19),
(3,45,19),
(2,47,19);
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_records`
--

DROP TABLE IF EXISTS `commission_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0,
  `order_type` varchar(30) DEFAULT '',
  `order_amount` decimal(10,2) DEFAULT 0.00,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `referrer_id` int(11) NOT NULL,
  `referrer_name` varchar(100) DEFAULT '',
  `rate` decimal(5,2) DEFAULT 0.00,
  `level` int(11) DEFAULT 1,
  `reward_type` varchar(20) DEFAULT 'balance',
  `amount` decimal(10,2) DEFAULT 0.00,
  `points_amount` decimal(10,2) DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_commission_records_user` (`user_id`),
  KEY `idx_commission_records_referrer` (`referrer_id`),
  KEY `idx_commission_records_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_records`
--

LOCK TABLES `commission_records` WRITE;
/*!40000 ALTER TABLE `commission_records` DISABLE KEYS */;
INSERT INTO `commission_records` VALUES
(1,1,'',236.00,9,'user9',10,'user10',0.00,1,'balance',14.81,0.00,'completed','2026-07-01 22:39:54'),
(2,2,'',144.00,11,'user11',12,'user12',0.00,1,'balance',11.19,0.00,'completed','2026-06-18 22:39:54'),
(3,3,'',165.00,8,'user8',9,'user9',0.00,1,'balance',17.71,0.00,'completed','2026-06-24 22:39:54'),
(4,4,'',113.00,8,'user8',9,'user9',0.00,1,'balance',17.55,0.00,'completed','2026-06-23 22:39:54'),
(5,5,'',84.00,5,'user5',6,'user6',0.00,1,'balance',14.54,0.00,'completed','2026-07-05 22:39:54'),
(6,6,'',182.00,8,'user8',9,'user9',0.00,1,'balance',6.23,0.00,'completed','2026-07-08 22:39:54'),
(7,7,'',99.00,12,'user12',13,'user13',0.00,1,'balance',23.75,0.00,'completed','2026-07-01 22:39:54'),
(8,8,'',125.00,3,'user3',4,'user4',0.00,1,'balance',20.88,0.00,'completed','2026-06-25 22:39:54'),
(9,21,'post',4.50,19,'',0,'',10.00,1,'balance',0.45,0.00,'completed','2026-07-15 04:20:52'),
(10,21,'post',100.00,19,'',0,'',10.00,1,'balance',10.00,0.00,'completed','2026-07-15 04:21:03'),
(11,22,'post',10.00,19,'',0,'',10.00,1,'balance',1.00,0.00,'completed','2026-07-16 00:16:50'),
(12,21,'post',100.00,19,'',0,'',10.00,1,'balance',10.00,0.00,'completed','2026-07-16 00:17:36'),
(13,21,'post',5.00,19,'',0,'',10.00,1,'balance',0.50,0.00,'completed','2026-07-16 00:17:45'),
(14,23,'post',8.88,19,'',0,'',10.00,1,'balance',0.89,0.00,'completed','2026-07-16 15:43:53'),
(22,31,'mall',9.80,10011,'',19,'alexmorgan',3.00,1,'balance',0.29,0.00,'completed','2026-07-17 18:39:28'),
(23,36,'mall',980.00,10011,'',19,'alexmorgan',5.00,1,'points',0.00,49.00,'completed','2026-07-17 18:47:59'),
(24,18,'membership',48.00,19,'',3,'tech_guru',3.00,1,'balance',1.44,0.00,'completed','2026-07-17 19:37:43'),
(25,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:46'),
(26,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:50'),
(27,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:37:57'),
(28,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:38:02'),
(29,18,'membership',48.00,19,'',3,'tech_guru',3.00,1,'balance',1.44,0.00,'completed','2026-07-17 19:38:04'),
(30,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:09'),
(31,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:15'),
(32,19,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-17 19:43:19'),
(33,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:23'),
(34,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:27'),
(35,13,'membership',15.00,19,'',3,'tech_guru',3.00,1,'balance',0.45,0.00,'completed','2026-07-17 19:43:32'),
(36,37,'mall',2939.02,19,'',3,'tech_guru',3.00,1,'balance',88.17,0.00,'completed','2026-07-17 23:58:36'),
(37,24,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-19 04:10:29'),
(38,24,'membership',10.00,19,'',3,'tech_guru',3.00,1,'balance',0.30,0.00,'completed','2026-07-21 00:23:38');
/*!40000 ALTER TABLE `commission_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_rules`
--

DROP TABLE IF EXISTS `commission_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `order_type` varchar(30) DEFAULT 'all',
  `rate` decimal(5,2) DEFAULT 0.00,
  `points_rate` decimal(5,2) DEFAULT 0.00,
  `reward_type` varchar(20) DEFAULT 'balance',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `invite_code_id` int(11) DEFAULT 0,
  `invite_code_type` varchar(20) DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `level` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_rules`
--

LOCK TABLES `commission_rules` WRITE;
/*!40000 ALTER TABLE `commission_rules` DISABLE KEYS */;
INSERT INTO `commission_rules` VALUES
(1,'一级返佣','all',10.00,0.00,'balance',1,'',0,0,'','1','2026-07-10 22:39:54',1),
(2,'二级返佣','all',5.00,0.00,'balance',2,'',0,0,'','1','2026-07-10 22:39:54',1),
(3,'默认返佣(全局)','all',3.00,1.00,'balance',0,'',0,0,'','1','2026-07-17 17:44:43',0),
(4,'积分返佣(全局)','all',0.00,5.00,'points',0,'',0,0,'','1','2026-07-17 18:01:17',0);
/*!40000 ALTER TABLE `commission_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_attach_purchases`
--

DROP TABLE IF EXISTS `community_attach_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_attach_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attach_url` varchar(500) NOT NULL DEFAULT '',
  `coin_type` varchar(20) NOT NULL DEFAULT 'coin',
  `coin_amount` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_attach_purchases`
--

LOCK TABLES `community_attach_purchases` WRITE;
/*!40000 ALTER TABLE `community_attach_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_attach_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_auto_bans`
--

DROP TABLE IF EXISTS `community_auto_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_auto_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `report_count` int(11) DEFAULT 0 COMMENT '触发时的举报次数',
  `banned_until` datetime DEFAULT NULL,
  `triggered_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_triggered` (`user_id`,`triggered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_auto_bans`
--

LOCK TABLES `community_auto_bans` WRITE;
/*!40000 ALTER TABLE `community_auto_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_auto_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_banned_users`
--

DROP TABLE IF EXISTS `community_banned_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_banned_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `banned_until` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `is_active` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_community_banned_users_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_banned_users`
--

LOCK TABLES `community_banned_users` WRITE;
/*!40000 ALTER TABLE `community_banned_users` DISABLE KEYS */;
INSERT INTO `community_banned_users` VALUES
(5,2,'','累计违规 3 次触发禁言','2026-07-21 10:14:02','2026-07-21 00:14:02',1);
/*!40000 ALTER TABLE `community_banned_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_coin_logs`
--

DROP TABLE IF EXISTS `community_coin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_coin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '',
  `to_user_id` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) DEFAULT 0,
  `coin_type` varchar(20) DEFAULT 'coin',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coin_logs_post_id` (`post_id`),
  KEY `idx_coin_logs_from_user` (`from_user_id`),
  KEY `idx_coin_logs_to_user` (`to_user_id`),
  KEY `idx_coin_logs_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_coin_logs`
--

LOCK TABLES `community_coin_logs` WRITE;
/*!40000 ALTER TABLE `community_coin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_coin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_collection_posts`
--

DROP TABLE IF EXISTS `community_collection_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_collection_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_preview` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`),
  UNIQUE KEY `collection_id` (`collection_id`,`post_id`),
  KEY `idx_community_collection_posts_collection` (`collection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_collection_posts`
--

LOCK TABLES `community_collection_posts` WRITE;
/*!40000 ALTER TABLE `community_collection_posts` DISABLE KEYS */;
INSERT INTO `community_collection_posts` VALUES
(4,1,28,4,0,'2026-07-15 20:48:23');
/*!40000 ALTER TABLE `community_collection_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_collections`
--

DROP TABLE IF EXISTS `community_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `post_count` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'draft',
  `is_paid` tinyint(1) DEFAULT 0,
  `price_balance` decimal(10,2) DEFAULT 0.00,
  `price_points` int(11) DEFAULT 0,
  `preview_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `subscribe_count` int(11) DEFAULT 0,
  `sort_mode` varchar(20) DEFAULT 'manual',
  `section_id` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `share_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_community_collections_user_id` (`user_id`),
  KEY `idx_community_collections_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_collections`
--

LOCK TABLES `community_collections` WRITE;
/*!40000 ALTER TABLE `community_collections` DISABLE KEYS */;
INSERT INTO `community_collections` VALUES
(1,19,'alexmorgan','','社区功能测试合集','本合集收录了社区各功能模块的测试帖子，方便查阅各功能状态。包括编辑器文字格式、卡片与多媒体、付费内容等功能测试。','',1,'serializing',1,20.00,200,1,0,2,'manual',1,0,'2026-07-15 20:48:18','2026-07-16 01:11:09',43),
(2,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','666','666','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-15 20:57:30','2026-07-15 20:57:30',0),
(3,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','666','666','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-15 20:57:33','2026-07-15 20:57:33',0),
(6,19,'alexmorgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','1','2','',0,'draft',0,0.00,0,0,0,0,'manual',0,0,'2026-07-16 00:10:18','2026-07-16 00:10:26',0),
(7,10001,'35735712','','666','','',0,'finished',0,0.00,0,0,0,0,'manual',0,0,'2026-07-16 00:20:58','2026-07-16 00:21:32',0);
/*!40000 ALTER TABLE `community_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_comments`
--

DROP TABLE IF EXISTS `community_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `content` text NOT NULL,
  `images` text DEFAULT '[]',
  `like_count` int(11) DEFAULT 0,
  `reply_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `is_pinned` tinyint(1) DEFAULT 0,
  `reported` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'published',
  `is_deleted` tinyint(4) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_community_comments_post_id` (`post_id`),
  KEY `idx_community_comments_parent_id` (`parent_id`),
  KEY `idx_comments_post_deleted_parent` (`post_id`,`is_deleted`,`parent_id`,`create_time`),
  KEY `idx_comments_post_parent_time` (`post_id`,`parent_id`,`create_time`),
  KEY `idx_community_comments_user` (`user_id`),
  KEY `idx_community_comments_ctime` (`create_time`),
  KEY `idx_comments_post_time` (`post_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comments`
--

LOCK TABLES `community_comments` WRITE;
/*!40000 ALTER TABLE `community_comments` DISABLE KEYS */;
INSERT INTO `community_comments` VALUES
(54,27,0,10001,'user_10001','','66','[]',0,0,'2026-07-16 15:43:21',0,0,'published',0,NULL),
(63,33,0,2,'Lisa管线昵称','','管线通知测试评论','[]',0,0,'2026-07-21 00:12:43',0,0,'published',0,NULL),
(64,0,0,2,'lisa_chen','','待审核评论测试','[]',0,0,'2026-07-21 00:13:11',0,0,'pending',0,NULL),
(65,0,0,2,'lisa_chen','','待驳回评论测试','[]',0,0,'2026-07-21 00:13:11',0,0,'pending',0,NULL),
(66,49,0,2,'lisa_chen','','待审评论A','[]',0,0,'2026-07-21 00:13:38',0,0,'pending',0,NULL),
(67,49,0,2,'lisa_chen','','待审评论B','[]',0,0,'2026-07-21 00:13:38',0,0,'rejected',0,NULL),
(68,49,0,2,'lisa_chen','','单评论A','[]',0,0,'2026-07-21 00:14:02',0,0,'published',0,NULL),
(69,49,0,2,'lisa_chen','','单评论B','[]',0,0,'2026-07-21 00:14:02',0,0,'rejected',0,NULL),
(70,55,0,3,'tech_guru','','批通评论1','[]',0,0,'2026-07-21 00:14:46',0,0,'published',0,NULL),
(71,55,0,3,'tech_guru','','批通评论2','[]',0,0,'2026-07-21 00:14:46',0,0,'published',0,NULL);
/*!40000 ALTER TABLE `community_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_drafts`
--

DROP TABLE IF EXISTS `community_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_drafts_user_id` (`user_id`),
  KEY `idx_community_drafts_ctime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_drafts`
--

LOCK TABLES `community_drafts` WRITE;
/*!40000 ALTER TABLE `community_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_favorites`
--

DROP TABLE IF EXISTS `community_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_favorites_post_user` (`post_id`,`user_id`),
  KEY `idx_community_favorites_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_favorites`
--

LOCK TABLES `community_favorites` WRITE;
/*!40000 ALTER TABLE `community_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_likes`
--

DROP TABLE IF EXISTS `community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`user_id`),
  KEY `idx_community_likes_post_user` (`post_id`,`user_id`),
  KEY `idx_community_likes_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_likes`
--

LOCK TABLES `community_likes` WRITE;
/*!40000 ALTER TABLE `community_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderator_bans`
--

DROP TABLE IF EXISTS `community_moderator_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderator_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `banned_user_id` int(11) NOT NULL,
  `banned_user_name` varchar(100) DEFAULT '',
  `reason` varchar(500) DEFAULT '',
  `ban_type` varchar(20) DEFAULT 'section_mute',
  `ban_until` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section_user` (`section_id`,`banned_user_id`),
  KEY `idx_active` (`is_active`,`ban_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderator_bans`
--

LOCK TABLES `community_moderator_bans` WRITE;
/*!40000 ALTER TABLE `community_moderator_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_moderator_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderator_logs`
--

DROP TABLE IF EXISTS `community_moderator_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderator_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `moderator_id` int(11) NOT NULL,
  `moderator_name` varchar(100) DEFAULT '',
  `action` varchar(50) NOT NULL,
  `target_type` varchar(30) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section` (`section_id`),
  KEY `idx_moderator` (`moderator_id`),
  KEY `idx_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderator_logs`
--

LOCK TABLES `community_moderator_logs` WRITE;
/*!40000 ALTER TABLE `community_moderator_logs` DISABLE KEYS */;
INSERT INTO `community_moderator_logs` VALUES
(1,0,19,'alexmorgan','approve','post',32,'审核通过《99999》','2026-07-18 14:05:38'),
(2,0,1,'bobwang','reject','post',51,'驳回《Lisa待审帖B》','2026-07-21 00:13:38'),
(3,1,1,'bobwang','batch_approve','post',52,'批量审核通过帖子「Lisa待审帖C」','2026-07-21 00:13:38'),
(4,0,1,'bobwang','approve','post',53,'审核通过《Lisa单帖通过》','2026-07-21 00:14:02'),
(5,0,1,'bobwang','reject','post',54,'驳回《Lisa单帖驳回》','2026-07-21 00:14:02'),
(6,0,1,'bobwang','approve','post',55,'审核通过《管线测试帖-Tech》','2026-07-21 00:14:46');
/*!40000 ALTER TABLE `community_moderator_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_moderators`
--

DROP TABLE IF EXISTS `community_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `role` varchar(20) DEFAULT '版主',
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_moderators`
--

LOCK TABLES `community_moderators` WRITE;
/*!40000 ALTER TABLE `community_moderators` DISABLE KEYS */;
INSERT INTO `community_moderators` VALUES
(1,1,19,'Alex Morgan','','管理员',0,'2026-07-13 18:31:33'),
(7,1,2,'lisa_chen','','审核员',0,'2026-07-15 19:31:36'),
(8,1,10001,'35735712','','管理员',0,'2026-07-16 17:07:01');
/*!40000 ALTER TABLE `community_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_revisions`
--

DROP TABLE IF EXISTS `community_post_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `editor_id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `edit_summary` varchar(500) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_revisions`
--

LOCK TABLES `community_post_revisions` WRITE;
/*!40000 ALTER TABLE `community_post_revisions` DISABLE KEYS */;
INSERT INTO `community_post_revisions` VALUES
(1,30,19,'29922929','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"66666\"}]}]}','[]','用户编辑',1,'2026-07-18 00:10:18'),
(2,33,19,'定时','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"65929923\"}]}]}','[]','用户编辑',1,'2026-07-18 04:38:46');
/*!40000 ALTER TABLE `community_post_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_post_topics`
--

DROP TABLE IF EXISTS `community_post_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_post_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id` (`post_id`,`topic_id`),
  KEY `idx_post_topics_post` (`post_id`),
  KEY `idx_post_topics_topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_post_topics`
--

LOCK TABLES `community_post_topics` WRITE;
/*!40000 ALTER TABLE `community_post_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_post_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_posts`
--

DROP TABLE IF EXISTS `community_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `title` varchar(500) DEFAULT '',
  `content` longtext DEFAULT '',
  `device` varchar(100) DEFAULT '',
  `tags` text DEFAULT '[]',
  `official_tags` text DEFAULT '[]',
  `images` longtext DEFAULT '[]',
  `has_resource` int(11) DEFAULT 0,
  `resource_type` varchar(20) DEFAULT '',
  `resource_url` text DEFAULT '',
  `resource_price` double DEFAULT 0,
  `resource_price_type` varchar(20) DEFAULT 'free',
  `extract_code` varchar(100) DEFAULT '',
  `permission` varchar(20) DEFAULT 'public',
  `is_pinned` int(11) DEFAULT 0,
  `is_essence` int(11) DEFAULT 0,
  `is_hot` int(11) DEFAULT 0,
  `hot_manually_disabled` tinyint(1) DEFAULT 0,
  `is_global_pinned` tinyint(1) DEFAULT 0,
  `custom_badge` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'published',
  `is_hidden` tinyint(1) DEFAULT 0,
  `like_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `coin_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `favorite_count` int(11) DEFAULT 0,
  `topic_id` int(11) DEFAULT 0,
  `content_permission` varchar(20) DEFAULT 'public',
  `content_price` decimal(10,2) DEFAULT 0.00,
  `content_price_type` varchar(20) DEFAULT 'free',
  `access_password` varchar(100) DEFAULT '',
  `access_password_tips` varchar(500) DEFAULT '',
  `cover_url` varchar(500) DEFAULT '',
  `is_edited` int(11) DEFAULT 0,
  `edit_count` int(11) DEFAULT 0,
  `edited_at` datetime DEFAULT NULL,
  `avatar_frame` varchar(500) DEFAULT '',
  `name_color` varchar(20) DEFAULT '',
  `is_anonymous` int(11) DEFAULT 0,
  `is_deleted` tinyint(1) DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  `edition` int(11) DEFAULT 1,
  `community_id` int(11) DEFAULT 0,
  `community_name` varchar(100) DEFAULT '',
  `community_icon` varchar(500) DEFAULT '',
  `review_status` varchar(20) DEFAULT 'approved',
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` varchar(100) DEFAULT '',
  `review_reason` text DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `locked` int(11) DEFAULT 0,
  `is_locked` int(11) DEFAULT 0,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT 0,
  `locked_reason` varchar(500) DEFAULT '',
  `share_count` int(11) DEFAULT 0,
  `content_type` varchar(20) DEFAULT 'text',
  `attachment_urls` text DEFAULT NULL,
  `hidden_content` text DEFAULT NULL,
  `hidden_attachment_urls` text DEFAULT NULL,
  `free_read` int(11) DEFAULT 0,
  `free_count` int(11) DEFAULT 500,
  `cover_width` int(11) DEFAULT 0,
  `cover_height` int(11) DEFAULT 0,
  `duration_us` int(11) DEFAULT 0,
  `size_mb` decimal(10,2) DEFAULT 0.00,
  `mime_type` varchar(100) DEFAULT '',
  `voice_url` varchar(500) DEFAULT '',
  `voice_duration` int(11) DEFAULT 0,
  `video_width` int(11) DEFAULT 0,
  `video_height` int(11) DEFAULT 0,
  `original_lang` varchar(10) DEFAULT '',
  `translations` text DEFAULT NULL,
  `is_sticky_global` tinyint(1) DEFAULT 0,
  `sticky_order` int(11) DEFAULT 0,
  `sticky_section_id` int(11) DEFAULT 0,
  `sticky_until` datetime DEFAULT NULL,
  `post_uid` varchar(36) DEFAULT '',
  `summary` varchar(200) DEFAULT '',
  `sort_weight` decimal(10,2) DEFAULT 0.00,
  `scheduled_time` datetime DEFAULT NULL,
  `auto_hide_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `reported` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_community_posts_section_id` (`section_id`),
  KEY `idx_community_posts_user_id` (`user_id`),
  KEY `idx_community_posts_status` (`status`),
  KEY `idx_community_posts_is_pinned` (`is_pinned`),
  KEY `idx_community_posts_is_essence` (`is_essence`),
  KEY `idx_community_posts_is_hot` (`is_hot`),
  KEY `idx_posts_section_status_create` (`section_id`,`status`,`create_time`),
  KEY `idx_posts_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_posts`
--

LOCK TABLES `community_posts` WRITE;
/*!40000 ALTER TABLE `community_posts` DISABLE KEYS */;
INSERT INTO `community_posts` VALUES
(24,1,19,'Alex Morgan','','【会员专属】黄金会员专属福利 - 设计素材大礼包','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"本贴为黄金会员专属内容，包含高质量设计素材下载链接和使用教程。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"素材包内包含：矢量图标库、渐变配色方案、UI组件模板等。\"}]},{\"type\":\"memberUnlock\",\"attrs\":{\"levelId\":2,\"levelName\":\"黄金会员\"}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"会员专属素材下载\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接一：完整矢量图标库 (1200+ icons)\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接二：百套渐变配色方案\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"链接三：Figma UI组件模板合集\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"marks\":[{\"type\":\"textColor\",\"attrs\":{\"color\":\"#d48806\"}}],\"text\":\"感谢您的会员支持，更多福利持续更新中！\"}]}]}','','[\"会员专属\",\"设计素材\"]','[]','[]',0,'','',0,'free','','public',0,1,0,0,0,'','published',0,0,0,0,12,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-15 18:07:20','2026-07-21 04:55:11',0),
(25,1,19,'Alex Morgan','','【等级限制】Lv.2 经验等级专属 - 进阶设计技巧分享','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"本文分享一些进阶设计技巧，需要经验等级达到 Lv.2 才能查看全部内容。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"以下是部分预览：字体排印的技巧与艺术是UI设计中最重要的基础之一。\"}]},{\"type\":\"experienceUnlock\",\"attrs\":{\"level\":2,\"levelName\":\"Lv.2\"}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"进阶技巧一：微交互设计\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"微交互是用户与界面之间最小的交互单元，优秀的微交互能极大提升用户体验。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"关键要素：触发器、规则、反馈、循环与模式。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"进阶技巧二：响应式断点策略\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"合理设置响应式断点是跨设备适配的核心，推荐使用移动优先策略。\"}]}]}','','[\"进阶技巧\",\"等级限制\",\"微交互\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,10,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-15 18:07:46','2026-07-21 18:43:30',0),
(26,1,19,'Alex Morgan','','【登录可见】社区新人必读 - 发帖规范与积分规则详解','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"欢迎来到设计社区！本贴详细介绍了社区的发帖规范和积分获取规则。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"登录后即可查看完整的社区指南，帮助你快速上手。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"发帖规范\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"1. 帖子标题应简洁明了，准确描述内容主题。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"2. 内容需原创或有授权转载，禁止搬运他人作品。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"3. 禁止发布广告、色情、暴力等违规内容。\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"积分获取规则\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"每日签到：+5积分\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"发布帖子：+10积分\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"优质回复：+3积分\"}]}]}','','[\"社区指南\",\"新人必读\",\"登录可见\"]','[]','[]',0,'','',0,'free','','public',0,1,0,0,0,'','published',0,0,0,0,10,0,0,'login',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-15 18:07:46','2026-07-21 18:07:47',0),
(27,1,19,'Alex Morgan','','【评论解锁】隐藏的设计资源链接 - 评论即可查看','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"我整理了一份超实用的设计资源清单，包含免费工具、灵感网站和学习平台。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"只需要在下方评论区留言，即可解锁查看全部资源链接！\"}]},{\"type\":\"commentUnlock\",\"attrs\":{\"minCommentCount\":1}},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"设计工具推荐\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Figma - 在线协作设计工具，免费版功能强大\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Blender - 开源3D建模软件，社区活跃\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Procreate - iPad绘画神器，笔刷丰富\"}]},{\"type\":\"heading\",\"attrs\":{\"level\":2},\"content\":[{\"type\":\"text\",\"text\":\"灵感网站推荐\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Dribbble - 全球设计师作品展示平台\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Behance - Adobe旗下创意作品社区\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Awwwards - 优秀网站设计评选与展示\"}]}]}','','[\"设计资源\",\"评论解锁\",\"免费工具\"]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,1,0,21,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-15 18:07:46','2026-07-21 18:08:25',0),
(28,1,19,'alexmorgan','','【测试】称号解锁功能 - 设计达人专属内容','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"这是一段所有人可见的公开内容，欢迎来到称号解锁测试帖！\"}]},{\"type\":\"titleUnlock\",\"attrs\":{\"titleId\":1,\"titleName\":\"设计达人\"}},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"恭喜！你拥有设计达人称号，成功看到了这段隐藏内容。\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"这段内容只有被授予了设计达人称号的用户才能查看。\"}]}]}','','[]','[]','[]',0,'','',0,'free','','public',0,1,1,0,0,'不知道','published',0,0,0,0,285,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-15 20:05:26','2026-07-21 06:00:14',0),
(30,1,19,'Alex Morgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','29922929','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"66666\"}]}]}','mobile','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','scheduled',0,0,0,0,4,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,'2027-07-18 07:59:00',NULL,'2026-07-17 23:59:49','2026-07-18 00:45:16',0),
(31,1,19,'Alex Morgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','888','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"66666\"}]}]}','mobile','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,2,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,'2026-07-19 08:03:00',NULL,'2026-07-18 00:03:51','2026-07-19 00:08:00',0),
(32,1,19,'Alex Morgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','99999','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"66666\"}]}]}','mobile','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,3,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved','2026-07-18 14:05:38','19',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-18 00:07:32','2026-07-18 14:05:38',0),
(33,1,19,'Alex Morgan','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','定时','{\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":null},\"content\":[{\"type\":\"text\",\"text\":\"65929923\"}]}]}','mobile','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,1,'','published',0,0,1,0,28,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,'2026-07-18 11:10:00','2026-08-18 12:38:00','2026-07-18 00:10:39','2026-07-21 04:03:17',0),
(34,1,10017,'user_10017','','Test Post Title','Hello world','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,2,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-19 00:52:10','2026-07-19 06:23:44',0),
(37,1,1,'bob123','','权限测试帖','测试发帖权限','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-20 07:15:01','2026-07-20 07:15:01',0),
(38,1,1,'bob123','','新结构测试','测试','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-20 07:36:20','2026-07-20 07:36:20',0),
(39,1,1,'bob123','','测试审核管线帖子','这是一篇测试帖子，用于验证审核管线四关是否正常工作。内容质量评估、经验等级矩阵应该动态从数据库读取。','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,1,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-20 20:37:11','2026-07-21 04:54:45',0),
(44,1,2,'lisa123','','Lisa管线测试帖','Lisa通过管线测试的内容','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:12:43','2026-07-21 00:12:43',0),
(45,1,2,'lisa_chen','','Lisa待审核测试帖','这条帖子需要审核','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:11','2026-07-21 00:13:11',0),
(46,1,2,'lisa_chen','','Lisa驳回测试帖','这条帖子被驳回','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:11','2026-07-21 00:13:11',0),
(47,1,2,'lisa_chen','','Lisa批量帖1','批量测试帖1','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:11','2026-07-21 00:13:11',0),
(48,1,2,'lisa_chen','','Lisa批量帖2','批量测试帖2','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:11','2026-07-21 00:13:11',0),
(49,1,2,'lisa_chen','','Lisa批测帖1','批测1','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,1,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:21','2026-07-21 00:13:21',0),
(50,1,2,'lisa_chen','','Lisa待审帖A','内容A','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','pending',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:38','2026-07-21 00:13:38',0),
(51,1,2,'lisa_chen','','Lisa待审帖B','内容B','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','rejected',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved','2026-07-21 00:13:38','1',NULL,'测试驳回原因',0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:38','2026-07-21 00:13:38',0),
(52,1,2,'lisa_chen','','Lisa待审帖C','内容C','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:13:38','2026-07-21 00:13:38',0),
(53,1,2,'lisa_chen','','Lisa单帖通过','内容','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved','2026-07-21 00:14:02','1',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:14:02','2026-07-21 00:14:02',0),
(54,1,2,'lisa_chen','','Lisa单帖驳回','内容','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','rejected',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved','2026-07-21 00:14:02','1',NULL,'测试单帖驳回',0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:14:02','2026-07-21 00:14:02',0),
(55,1,3,'tech123','','管线测试帖-Tech','管线测试内容-pending-test','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,2,0,33,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved','2026-07-21 00:14:46','1',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:14:32','2026-07-21 05:01:20',0),
(56,1,3,'tech123','','敏感帖子','这是一个包含fakespamtest的帖子','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,5,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:15:02','2026-07-21 04:55:08',0),
(57,1,3,'tech123','','管线reject保留测试','这包含testblockword2026敏感词','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,1,0,0,'public',0.00,'balance','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:22:23','2026-07-21 04:54:43',0),
(58,1,3,'tech_guru','','管线拒绝测试帖','这条被管线拒绝了','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','rejected',0,0,0,0,0,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,'内容包含违规信息，无法发布',0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:22:39','2026-07-21 00:22:39',0),
(59,1,19,'alexmorgan','','Alex的未通过帖','内容不符合规范','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','rejected',0,0,0,0,1,0,0,'public',0.00,'free','','','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,'内容包含违规信息',0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 00:25:52','2026-07-21 00:30:47',0),
(60,1,1,'bobwang','','hashed密码测试帖','test','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'password',0.00,'free','$2b$10$R31egYAJ3x6Kuj8SBD8gGemHQ3Jq6.xKMNb.rxGaM6o7/Vfj9mThu','提示: test123','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 16:15:21','2026-07-21 16:15:21',0),
(61,1,1,'bobwang','','旧明文密码测试帖','test','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'password',0.00,'free','oldplain','旧密码','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 16:15:21','2026-07-21 16:15:21',0),
(62,1,1,'bob123','','新帖bcrypt测试','test','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'password',0.00,'balance','$2b$10$lnV6hts7su4ZwG4G5tpGO.MNISmyVBtJk3zDSvpCP0bZ4V1cv/TG.','强密码','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 16:15:35','2026-07-21 16:15:35',0),
(63,1,1,'bob123','','新帖bcrypt测试','test','','[]','[]','[]',0,'','',0,'free','','public',0,0,0,0,0,'','published',0,0,0,0,0,0,0,'password',0.00,'balance','$2b$10$uK5vttTr16T3K1a7UfDtQeZ4qfEebxAL8l1jFoaXt0E45W6jmeW9W','强密码','',0,0,NULL,'','',0,0,NULL,1,0,'','','approved',NULL,'',NULL,NULL,0,0,NULL,0,'',0,'text',NULL,NULL,NULL,0,500,0,0,0,0.00,'','',0,0,0,'',NULL,0,0,0,NULL,'','',0.00,NULL,NULL,'2026-07-21 16:15:44','2026-07-21 16:15:44',0);
/*!40000 ALTER TABLE `community_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_ratings`
--

DROP TABLE IF EXISTS `community_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `target_type` varchar(50) NOT NULL DEFAULT 'collection',
  `target_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_target` (`user_id`,`target_type`,`target_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_ratings`
--

LOCK TABLES `community_ratings` WRITE;
/*!40000 ALTER TABLE `community_ratings` DISABLE KEYS */;
INSERT INTO `community_ratings` VALUES
(1,1,'collection',1,5,'2026-07-16 19:29:20');
/*!40000 ALTER TABLE `community_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_reports`
--

DROP TABLE IF EXISTS `community_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) NOT NULL,
  `reporter_name` varchar(100) DEFAULT '',
  `target_type` varchar(20) NOT NULL,
  `target_id` int(11) NOT NULL,
  `report_reason` varchar(100) DEFAULT '其他',
  `category` varchar(50) DEFAULT 'other',
  `report_detail` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `handled_by` int(11) DEFAULT 0,
  `handled_at` datetime DEFAULT NULL,
  `handle_result` varchar(50) DEFAULT '',
  `appeal_reason` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_reports_reporter` (`reporter_id`),
  KEY `idx_community_reports_target` (`target_type`,`target_id`),
  KEY `idx_community_reports_status` (`status`),
  KEY `idx_community_reports_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_reports`
--

LOCK TABLES `community_reports` WRITE;
/*!40000 ALTER TABLE `community_reports` DISABLE KEYS */;
INSERT INTO `community_reports` VALUES
(9,19,'alexmorgan','comment',2,'垃圾广告','other','评论','ignored',0,NULL,'','','2026-07-11 11:36:59'),
(10,19,'alexmorgan','app_comment',13,'6','other','','pending',0,NULL,'','','2026-07-11 11:51:00'),
(11,19,'alexmorgan','comment',46,'色情低俗','other','66','pending',0,NULL,'','','2026-07-15 15:37:37'),
(12,19,'alexmorgan','comment',45,'垃圾广告','other','','pending',0,NULL,'','','2026-07-15 15:59:52');
/*!40000 ALTER TABLE `community_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sections`
--

DROP TABLE IF EXISTS `community_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `icon_bg_color` varchar(20) DEFAULT '#00BFA5',
  `description` text DEFAULT '',
  `today_heat` int(11) DEFAULT 0,
  `total_heat` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'active',
  `visibility` varchar(20) DEFAULT 'public',
  `post_permission` varchar(20) DEFAULT 'all',
  `view_permission` varchar(20) DEFAULT 'all',
  `view_level_required` int(11) DEFAULT 0,
  `hot_threshold` int(11) DEFAULT 100 COMMENT '热帖热度阈值',
  `view_cooldown` int(11) DEFAULT 30 COMMENT '浏览计数冷却时间(秒)',
  `announcement` text DEFAULT '',
  `rules` text DEFAULT '',
  `banner_url` varchar(500) DEFAULT '',
  `review_required` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `comment_review_required` tinyint(4) DEFAULT 0,
  `is_deleted` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sections`
--

LOCK TABLES `community_sections` WRITE;
/*!40000 ALTER TABLE `community_sections` DISABLE KEYS */;
INSERT INTO `community_sections` VALUES
(1,'综合讨论','','#00BFA5','综合讨论版块',0,0,31,0,1,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(2,'技术交流','','#00BFA5','技术交流版块',0,0,5,0,2,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(3,'设计创作','','#00BFA5','设计创作版块',0,0,5,0,3,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(4,'资源分享','','#00BFA5','资源分享版块',0,0,5,0,4,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(5,'反馈建议','','#00BFA5','反馈建议版块',0,0,5,0,5,'active','public','all','all',0,100,30,'','','',0,'2026-07-10 22:39:49',0,0),
(6,'6666','','#6366F1','',0,0,0,0,0,'active','public','all','all',0,100,30,'','','',0,'2026-07-20 20:26:55',0,0),
(7,'测试','','#6366F1','',0,0,0,0,0,'active','public','all','all',0,100,30,'','','',0,'2026-07-20 20:27:19',0,0);
/*!40000 ALTER TABLE `community_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_sensitive_words`
--

DROP TABLE IF EXISTS `community_sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `replacement` varchar(100) DEFAULT '',
  `category` varchar(50) DEFAULT '',
  `level` varchar(20) DEFAULT 'block',
  `status` tinyint(4) DEFAULT 1,
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_word` (`word`),
  KEY `idx_level_status` (`level`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_sensitive_words`
--

LOCK TABLES `community_sensitive_words` WRITE;
/*!40000 ALTER TABLE `community_sensitive_words` DISABLE KEYS */;
INSERT INTO `community_sensitive_words` VALUES
(13,'赌博','***','','block',1,1,'2026-07-20 19:13:08'),
(14,'赌场','***','','block',1,1,'2026-07-20 19:13:08'),
(15,'色情','***','','block',1,1,'2026-07-20 19:13:08'),
(16,'黄色','***','','block',1,1,'2026-07-20 19:13:08'),
(17,'毒品','***','','block',1,1,'2026-07-20 19:13:08'),
(18,'大麻','***','','block',1,1,'2026-07-20 19:13:08'),
(19,'冰毒','***','','block',1,1,'2026-07-20 19:13:08'),
(20,'诈骗','***','','block',1,1,'2026-07-20 19:13:08'),
(21,'骗子','***','','block',1,1,'2026-07-20 19:13:08'),
(22,'传销','***','','block',1,1,'2026-07-20 19:13:08'),
(23,'高利贷','***','','block',1,1,'2026-07-20 19:13:08'),
(24,'枪支','***','','block',1,1,'2026-07-20 19:13:08'),
(25,'迷药','***','','block',1,1,'2026-07-20 19:13:08'),
(26,'微信','','','review',1,1,'2026-07-20 19:13:08'),
(27,'微信号','','','review',1,1,'2026-07-20 19:13:08'),
(28,'加微信','','','review',1,1,'2026-07-20 19:13:08'),
(29,'QQ','','','review',1,1,'2026-07-20 19:13:08'),
(30,'QQ群','','','review',1,1,'2026-07-20 19:13:08'),
(31,'手机号','','','review',1,1,'2026-07-20 19:13:08'),
(32,'私聊','','','review',1,1,'2026-07-20 19:13:08'),
(33,'+V','','','review',1,1,'2026-07-20 19:13:08'),
(34,'广告','','','review',1,1,'2026-07-20 19:13:08'),
(35,'推广','','','review',1,1,'2026-07-20 19:13:08'),
(36,'代购','','','review',1,1,'2026-07-20 19:13:08'),
(37,'兼职','','','review',1,1,'2026-07-20 19:13:08'),
(38,'刷单','','','review',1,1,'2026-07-20 19:13:08'),
(39,'sb','**','','warn',1,1,'2026-07-20 19:13:08'),
(40,'傻逼','**','','warn',1,1,'2026-07-20 19:13:08'),
(41,'fuck','****','','warn',1,1,'2026-07-20 19:13:08'),
(42,'shit','****','','warn',1,1,'2026-07-20 19:13:08'),
(43,'妈的','**','','warn',1,1,'2026-07-20 19:13:08'),
(44,'tmd','***','','warn',1,1,'2026-07-20 19:13:08'),
(45,'靠','*','','warn',1,1,'2026-07-20 19:13:08'),
(46,'卧槽','**','','warn',1,1,'2026-07-20 19:13:08'),
(47,'尼玛','**','','warn',1,1,'2026-07-20 19:13:08'),
(48,'草泥马','***','','warn',1,1,'2026-07-20 19:13:08');
/*!40000 ALTER TABLE `community_sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_settings`
--

DROP TABLE IF EXISTS `community_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_settings`
--

LOCK TABLES `community_settings` WRITE;
/*!40000 ALTER TABLE `community_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_tags`
--

DROP TABLE IF EXISTS `community_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `normalized_name` varchar(50) NOT NULL,
  `post_count` int(11) DEFAULT 0,
  `section_id` int(11) DEFAULT 0,
  `status` tinyint(4) DEFAULT 1 COMMENT '1=active 0=hidden',
  `is_official` tinyint(4) DEFAULT 0 COMMENT '1=official_tag',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_normalized` (`normalized_name`),
  KEY `idx_post_count` (`post_count`),
  KEY `idx_section` (`section_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_tags`
--

LOCK TABLES `community_tags` WRITE;
/*!40000 ALTER TABLE `community_tags` DISABLE KEYS */;
INSERT INTO `community_tags` VALUES
(1,'vue3','vue3',1,0,1,0,'2026-07-16 19:44:26'),
(2,'express','express',1,0,1,0,'2026-07-16 19:44:26'),
(3,'全栈项目','全栈项目',1,0,1,0,'2026-07-16 19:44:26'),
(4,'博客开发','博客开发',1,0,1,0,'2026-07-16 19:44:26'),
(5,'设计资源','设计资源',1,0,1,0,'2026-07-16 19:44:26'),
(6,'ui组件库','ui组件库',1,0,1,0,'2026-07-16 19:44:26'),
(7,'字体包','字体包',1,0,1,0,'2026-07-16 19:44:26'),
(8,'插画素材','插画素材',1,0,1,0,'2026-07-16 19:44:26'),
(9,'测试标签','测试标签',1,0,1,0,'2026-07-16 19:44:26'),
(10,'编辑功能','编辑功能',1,0,1,0,'2026-07-16 19:44:26'),
(11,'前端','前端',1,0,1,0,'2026-07-16 19:44:26'),
(12,'设计教程','设计教程',1,0,1,0,'2026-07-16 19:44:26'),
(13,'ui设计','ui设计',1,0,1,0,'2026-07-16 19:44:26'),
(14,'付费内容','付费内容',1,0,1,0,'2026-07-16 19:44:26'),
(15,'会员专属','会员专属',1,0,1,0,'2026-07-16 19:44:26'),
(16,'设计素材','设计素材',1,0,1,0,'2026-07-16 19:44:26'),
(17,'进阶技巧','进阶技巧',1,0,1,0,'2026-07-16 19:44:26'),
(18,'等级限制','等级限制',1,0,1,0,'2026-07-16 19:44:26'),
(19,'微交互','微交互',1,0,1,0,'2026-07-16 19:44:26'),
(20,'社区指南','社区指南',1,0,1,0,'2026-07-16 19:44:26'),
(21,'新人必读','新人必读',1,0,1,0,'2026-07-16 19:44:26'),
(22,'登录可见','登录可见',1,0,1,0,'2026-07-16 19:44:26'),
(23,'评论解锁','评论解锁',1,0,1,0,'2026-07-16 19:44:26'),
(24,'免费工具','免费工具',1,0,1,0,'2026-07-16 19:44:26');
/*!40000 ALTER TABLE `community_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_topics`
--

DROP TABLE IF EXISTS `community_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `description` text DEFAULT '',
  `creator_id` int(11) DEFAULT 0,
  `creator_name` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `post_count` int(11) DEFAULT 0,
  `view_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_topics_status` (`status`),
  KEY `idx_community_topics_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_topics`
--

LOCK TABLES `community_topics` WRITE;
/*!40000 ALTER TABLE `community_topics` DISABLE KEYS */;
INSERT INTO `community_topics` VALUES
(1,'AI绘画','','AI绘画相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(2,'前端开发','','前端开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(3,'设计灵感','','设计灵感相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(4,'独立开发','','独立开发相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(5,'UI/UX','','UI/UX相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(6,'科技资讯','','科技资讯相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(7,'摄影分享','','摄影分享相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(8,'生活记录','','生活记录相关话题讨论区',0,'',0,0,0,'1','2026-07-10 22:39:49'),
(9,'test_bob_1783772379','','',1,'bobwang',0,0,0,'1','2026-07-11 20:19:39'),
(10,'test_tech_1783772379','','',3,'tech_guru',0,0,0,'1','2026-07-11 20:19:39');
/*!40000 ALTER TABLE `community_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_trust_levels`
--

DROP TABLE IF EXISTS `community_trust_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_trust_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level` tinyint(4) DEFAULT 0 COMMENT '0=新手 1=成员 2=活跃 3=资深',
  `post_count` int(11) DEFAULT 0,
  `comment_count` int(11) DEFAULT 0,
  `like_received` int(11) DEFAULT 0,
  `report_count` int(11) DEFAULT 0 COMMENT '被举报次数',
  `ban_count` int(11) DEFAULT 0,
  `score` int(11) DEFAULT 0,
  `last_calculated` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_trust_levels`
--

LOCK TABLES `community_trust_levels` WRITE;
/*!40000 ALTER TABLE `community_trust_levels` DISABLE KEYS */;
INSERT INTO `community_trust_levels` VALUES
(1,19,0,4,0,3,0,0,0,NULL,'2026-07-17 02:15:18','2026-07-18 00:10:39'),
(2,10004,0,0,6,0,0,0,0,NULL,'2026-07-17 02:15:18','2026-07-17 02:20:34'),
(14,10017,0,1,0,0,0,0,0,NULL,'2026-07-19 00:52:10','2026-07-19 00:52:10'),
(15,10018,0,1,0,0,0,0,0,NULL,'2026-07-19 00:52:47','2026-07-19 00:52:47'),
(16,10019,0,1,0,0,0,0,0,NULL,'2026-07-19 01:04:36','2026-07-19 01:04:36'),
(17,1,0,5,0,0,0,0,0,NULL,'2026-07-20 07:15:01','2026-07-21 16:15:44'),
(20,2,0,4,1,0,0,0,0,NULL,'2026-07-20 20:39:31','2026-07-21 00:12:43'),
(23,10020,0,1,0,0,0,0,0,NULL,'2026-07-20 20:48:18','2026-07-20 20:48:18'),
(26,3,0,3,0,0,0,0,0,NULL,'2026-07-21 00:14:32','2026-07-21 00:22:23');
/*!40000 ALTER TABLE `community_trust_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_unlock_requests`
--

DROP TABLE IF EXISTS `community_unlock_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_unlock_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_reply` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_community_unlock_requests_post` (`post_id`),
  KEY `idx_community_unlock_requests_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_unlock_requests`
--

LOCK TABLES `community_unlock_requests` WRITE;
/*!40000 ALTER TABLE `community_unlock_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_unlock_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_vote_records`
--

DROP TABLE IF EXISTS `community_vote_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_vote_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `option_index` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vote_user_option` (`vote_id`,`user_id`,`option_index`),
  KEY `idx_vote_id` (`vote_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_vote_records`
--

LOCK TABLES `community_vote_records` WRITE;
/*!40000 ALTER TABLE `community_vote_records` DISABLE KEYS */;
INSERT INTO `community_vote_records` VALUES
(1,1,1,0,'2026-07-15 04:33:28'),
(2,1,1,1,'2026-07-15 04:33:37'),
(3,2,19,0,'2026-07-15 06:25:35'),
(4,1,10001,0,'2026-07-16 00:18:11'),
(5,2,10001,0,'2026-07-16 18:59:52');
/*!40000 ALTER TABLE `community_vote_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_votes`
--

DROP TABLE IF EXISTS `community_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL DEFAULT '',
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`options`)),
  `max_select` int(11) NOT NULL DEFAULT 1,
  `total_votes` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_votes`
--

LOCK TABLES `community_votes` WRITE;
/*!40000 ALTER TABLE `community_votes` DISABLE KEYS */;
INSERT INTO `community_votes` VALUES
(1,20,'你最喜欢哪个编辑器功能？','[\"文字格式排版\",\"多媒体嵌入\",\"付费内容设置\",\"互动解锁模块\",\"等级权益卡片\"]',2,3,1,'2026-07-15 04:33:28'),
(2,22,'我是想象问题','[\"你检查什么\",\"我不知道\"]',1,2,1,'2026-07-15 06:25:35');
/*!40000 ALTER TABLE `community_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_access_passwords`
--

DROP TABLE IF EXISTS `content_access_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_access_passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tips` varchar(200) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_access_passwords_content` (`content_type`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_access_passwords`
--

LOCK TABLES `content_access_passwords` WRITE;
/*!40000 ALTER TABLE `content_access_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_access_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_purchases`
--

DROP TABLE IF EXISTS `content_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `content_type` varchar(20) DEFAULT 'post',
  `content_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT 0,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `commission_amount` decimal(10,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `block_index` int(11) DEFAULT -1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_purchases_user` (`user_id`),
  KEY `idx_content_purchases_content` (`content_type`,`content_id`),
  KEY `idx_content_purchases_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_purchases`
--

LOCK TABLES `content_purchases` WRITE;
/*!40000 ALTER TABLE `content_purchases` DISABLE KEYS */;
INSERT INTO `content_purchases` VALUES
(1,14,'app',2,0,17.20,'balance',0.00,0.00,-1,'2026-07-03 22:39:54'),
(2,5,'app',2,0,20.34,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(3,5,'app',10,0,15.60,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(4,8,'app',6,0,20.23,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(5,9,'app',2,0,15.88,'balance',0.00,0.00,-1,'2026-06-16 22:39:54'),
(6,10,'app',2,0,50.01,'balance',0.00,0.00,-1,'2026-06-25 22:39:54'),
(7,13,'app',8,0,36.22,'balance',0.00,0.00,-1,'2026-06-26 22:39:54'),
(8,13,'app',9,0,11.34,'balance',0.00,0.00,-1,'2026-06-25 22:39:54');
/*!40000 ALTER TABLE `content_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cookie_consents`
--

DROP TABLE IF EXISTS `cookie_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cookie_consents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `session_id` varchar(100) DEFAULT '',
  `ip` varchar(45) DEFAULT '',
  `accepted_categories` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`accepted_categories`)),
  `accepted_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cookie_consents_user` (`user_id`),
  KEY `idx_cookie_consents_session` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cookie_consents`
--

LOCK TABLES `cookie_consents` WRITE;
/*!40000 ALTER TABLE `cookie_consents` DISABLE KEYS */;
INSERT INTO `cookie_consents` VALUES
(1,0,'','::ffff:127.0.0.1','[\"necessary\",\"analytics\"]','2026-07-21 15:44:29'),
(2,0,'','::ffff:127.0.0.1','[\"necessary\"]','2026-07-21 15:47:50'),
(3,0,'','::ffff:127.0.0.1','[\"necessary\",\"analytics\"]','2026-07-21 15:48:57');
/*!40000 ALTER TABLE `cookie_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usage_logs`
--

DROP TABLE IF EXISTS `coupon_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `coupon_id` int(11) NOT NULL,
  `coupon_name` varchar(200) DEFAULT '',
  `use_scene` varchar(50) DEFAULT '',
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `before_remaining` decimal(10,2) DEFAULT NULL,
  `after_remaining` decimal(10,2) DEFAULT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `use_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coupon_usage_logs_user` (`user_id`),
  KEY `idx_coupon_usage_logs_coupon` (`coupon_id`),
  KEY `idx_coupon_usage_logs_uc` (`user_coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usage_logs`
--

LOCK TABLES `coupon_usage_logs` WRITE;
/*!40000 ALTER TABLE `coupon_usage_logs` DISABLE KEYS */;
INSERT INTO `coupon_usage_logs` VALUES
(1,38,19,'alexmorgan',1,'新人专享券','membership_buy',5.00,NULL,NULL,'购买 1个月 原价¥15.00 余额减¥5.00','2026-07-12 08:11:10');
/*!40000 ALTER TABLE `coupon_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'fixed',
  `value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_order` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(10,2) DEFAULT 0.00,
  `scope` varchar(20) NOT NULL DEFAULT 'all',
  `target_ids` text DEFAULT '',
  `target_names` text DEFAULT '',
  `total_count` int(11) DEFAULT 0,
  `claimed_count` int(11) NOT NULL DEFAULT 0,
  `per_user_limit` int(11) NOT NULL DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `valid_days` int(11) DEFAULT 0,
  `category` varchar(20) DEFAULT 'general',
  `is_recommend` tinyint(1) DEFAULT 0,
  `is_new_user` tinyint(1) DEFAULT 0,
  `is_rush` tinyint(1) DEFAULT 0,
  `required_level_ids` text DEFAULT '',
  `required_level_names` text DEFAULT '',
  `is_multi_use` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_coupons_status` (`status`),
  KEY `idx_coupons_scope` (`scope`),
  KEY `idx_coupons_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES
(1,'新人专享券','','fixed',5.00,10.00,100.00,'all','','',100,22,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(2,'满减优惠券','','fixed',10.00,50.00,200.00,'all','','',100,21,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(3,'VIP折扣券','','percentage',15.00,0.00,0.00,'all','','',100,8,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(4,'节日特惠券','','fixed',20.00,30.00,500.00,'all','','',100,29,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(5,'限时体验券','','percentage',8.00,0.00,0.00,'all','','',100,23,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-10 22:39:53'),
(6,'黄金会员','','percent',10.00,1.00,10.00,'all','','',99,1,1,'2026-07-12 04:42:00','2030-07-12 04:42:00',30,'general',0,0,0,'2','',0,5,'1','2026-07-11 20:42:43'),
(7,'test_coupon','','fixed',10.00,0.00,0.00,'all','','',0,0,1,NULL,NULL,0,'general',0,0,0,'','',0,0,'1','2026-07-21 06:59:53');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_tasks`
--

DROP TABLE IF EXISTS `custom_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `task_type` varchar(30) NOT NULL DEFAULT 'daily',
  `action_type` varchar(30) NOT NULL DEFAULT 'post',
  `target_count` int(11) DEFAULT 1,
  `section_id` int(11) DEFAULT 0,
  `section_limit` int(11) DEFAULT 0,
  `points_reward` int(11) DEFAULT 0,
  `exp_reward` int(11) DEFAULT 0,
  `balance_reward` decimal(10,2) DEFAULT 0.00,
  `card_key_type` varchar(20) DEFAULT '',
  `card_key_value` int(11) DEFAULT 0,
  `card_key_duration` int(11) DEFAULT 0,
  `title_id` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `sort_order` int(11) DEFAULT 0,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `direction` varchar(10) DEFAULT 'earn' COMMENT 'earn=正向奖励 spend=惩罚扣分',
  `penalty_config` text DEFAULT NULL COMMENT '惩罚配置JSON',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_tasks`
--

LOCK TABLES `custom_tasks` WRITE;
/*!40000 ALTER TABLE `custom_tasks` DISABLE KEYS */;
INSERT INTO `custom_tasks` VALUES
(1,'每日签到','','','daily','checkin',1,0,0,10,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53','earn',NULL),
(2,'发帖奖励','','','daily','post',1,0,0,20,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53','earn',NULL),
(3,'评论互动','','','daily','comment',1,0,0,5,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:53','earn',NULL),
(4,'邀请好友','','','daily','invite',1,0,0,50,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:54','earn',NULL),
(5,'完善资料','','','daily','profile',1,0,0,30,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-10 22:39:54','earn',NULL),
(6,'帖子被驳回','帖子被审核驳回时扣除经验','','once','post_rejected',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 16:52:05','spend','{\"step_multiplier\":0.5,\"max_multiplier\":5.0,\"additional_actions\":[{\"trigger_count\":3,\"action\":\"mute_post\",\"duration_minutes\":120}]}'),
(7,'帖子被删除','管理员删除用户帖子','','daily','post_deleted',1,0,0,0,50,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:16','spend','{}'),
(8,'管理员封禁','管理员封禁用户','','daily','admin_banned',1,0,0,0,0,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:16','spend','{\"duration_bands\":[{\"min_days\":1,\"max_days\":3,\"amount\":200},{\"min_days\":4,\"max_days\":7,\"amount\":500},{\"min_days\":8,\"max_days\":30,\"amount\":1000}],\"step_multiplier\":0.5,\"max_multiplier\":5.0}'),
(9,'举报核实违规','举报经核实确实违规','','daily','report_verified',1,0,0,0,40,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:16','spend','{\"step_multiplier\":0.5,\"max_multiplier\":5.0}'),
(10,'聊天室踢出','被管理员踢出聊天室','','daily','chat_kicked',1,0,0,0,20,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:16','spend','{\"step_multiplier\":0.5,\"max_multiplier\":5.0}'),
(11,'帖子被锁定','帖子被管理员锁定','','daily','post_locked',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(12,'评论被删除','评论被管理员删除','','daily','comment_deleted',1,0,0,0,20,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(13,'敏感词违规','触发敏感词拦截','','daily','block_word_triggered',1,0,0,0,20,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(14,'滥用举报','滥用举报功能','','daily','report_abuse',1,0,0,0,40,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{\"step_multiplier\":0.5,\"max_multiplier\":3.0}'),
(15,'申诉驳回','申诉被管理员驳回','','daily','appeal_rejected',1,0,0,0,50,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(16,'自动封禁','系统自动封禁','','daily','auto_banned',1,0,0,0,100,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(17,'聊天室禁言','聊天室被禁言','','daily','chat_banned',1,0,0,0,20,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(18,'私信骚扰','发送骚扰私信','','daily','dm_harassment',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(19,'头像昵称违规','头像或昵称违规','','daily','profile_violation',1,0,0,0,20,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(20,'恶意差评','发布恶意差评','','daily','review_malicious',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(21,'虚假商品','发布虚假商品','','daily','product_fraud',1,0,0,0,50,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(22,'恶意退款','恶意申请退款','','daily','refund_abuse',1,0,0,0,40,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(23,'应用驳回','应用审核被驳回','','daily','app_rejected',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(24,'应用下架','应用因违规被下架','','daily','app_takedown',1,0,0,0,50,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(25,'应用删除','应用因违规被删除','','daily','app_deleted',1,0,0,0,60,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(26,'投票作弊','投票存在作弊行为','','daily','vote_cheat',1,0,0,0,30,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}'),
(27,'活动作弊','活动存在作弊行为','','daily','campaign_cheat',1,0,0,0,40,0.00,'',0,0,0,'1',0,NULL,NULL,'2026-07-20 17:26:59','spend','{}');
/*!40000 ALTER TABLE `custom_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_titles`
--

DROP TABLE IF EXISTS `custom_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(500) DEFAULT '',
  `color` varchar(20) DEFAULT '#409EFF',
  `bg_color` varchar(20) DEFAULT '#ecf5ff',
  `description` varchar(500) DEFAULT '',
  `condition_type` varchar(20) DEFAULT 'manual',
  `condition_value` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `category` varchar(20) DEFAULT '',
  `expire_days` int(11) DEFAULT 0,
  `upgrade_to_id` int(11) DEFAULT 0,
  `keep_previous` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_titles`
--

LOCK TABLES `custom_titles` WRITE;
/*!40000 ALTER TABLE `custom_titles` DISABLE KEYS */;
INSERT INTO `custom_titles` VALUES
(1,'设计达人','ri:palette-line','#FF4757','#ecf5ff','','manual','',0,'1','成就',0,0,0,'2026-07-10 22:39:54'),
(2,'技术大牛','ri:code-box-line','#0984E3','#ecf5ff','','manual','',0,'1','成就',0,0,0,'2026-07-10 22:39:54'),
(3,'社区之星','ri:star-line','#FDCB6E','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(4,'创作先锋','ri:quill-pen-line','#00B894','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(5,'活跃分子','ri:flashlight-line','#6C5CE7','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(6,'分享达人','ri:share-line','#E17055','#ecf5ff','','manual','',0,'1','社交',0,0,0,'2026-07-10 22:39:54'),
(7,'至尊会员','','#FFD700','#FFF8E1','会员专属称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(8,'铂金达人','','#E5E4E2','#F5F5F5','高级会员称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(9,'钻石王者','','#00CED1','#E0FFFF','顶级会员称号','manual','',0,'1','消费',0,0,0,'2026-07-11 21:07:13'),
(10,'蓝V官方认证','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987369006-697144065.png','#409EFF','#ffffff','','manual','',0,'1','管理员',0,0,0,'2026-07-13 21:52:48'),
(11,'官方认证','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783981009908-814127258.png','#409EFF','#ecf5ff','','manual','',0,'1','管理员',0,0,0,'2026-07-13 22:16:52'),
(12,'发帖达人','icon-post-master','#409EFF','#ecf5ff','累计发布帖子数达到50篇','post_count','50',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(13,'百赞之星','icon-like-star','#409EFF','#ecf5ff','累计获得点赞数达到100次','like_received','100',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(14,'评论大师','icon-comment-master','#409EFF','#ecf5ff','累计发表评论数达到200条','comment_count','200',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(15,'签到狂魔','icon-checkin-king','#409EFF','#ecf5ff','累计签到天数达到30天','checkin_days','30',1,'1','成就',0,0,0,'2026-07-16 22:23:25'),
(16,'万元户','icon-coin-rich','#409EFF','#ecf5ff','累计收到金币数达到10000','coin_received','10000',1,'1','消费',0,0,0,'2026-07-16 22:23:25'),
(19,'实名认证','','#409EFF','#ecf5ff','通过实名认证','verified','1',1,'1','社交',0,0,0,'2026-07-16 22:35:01'),
(20,'管理员','','#409EFF','#ecf5ff','拥有管理员角色 (条件值=R_ADMIN)','has_role','R_ADMIN',1,'1','管理员',0,0,0,'2026-07-16 22:35:01'),
(21,'超级管理员','','#409EFF','#ecf5ff','拥有超级管理员角色 (条件值=R_SUPER)','has_role','R_SUPER',1,'1','管理员',0,0,0,'2026-07-16 22:37:15'),
(22,'社区版主','','#409EFF','#ecf5ff','拥有版主角色的精英用户 (条件值=R_MODERATOR)','has_role','R_MODERATOR',1,'1','管理员',0,0,0,'2026-07-16 22:37:15'),
(23,'审核员','','#409EFF','#ecf5ff','拥有审核员角色 (条件值=R_REVIEWER)','has_role','R_REVIEWER',1,'1','管理员',0,0,0,'2026-07-16 22:37:15');
/*!40000 ALTER TABLE `custom_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_config`
--

DROP TABLE IF EXISTS `email_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(200) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT 465,
  `secure` tinyint(1) DEFAULT 1,
  `user` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) NOT NULL DEFAULT '',
  `from_name` varchar(100) DEFAULT '',
  `from_address` varchar(200) DEFAULT '',
  `test_address` varchar(200) DEFAULT '',
  `register_verify` tinyint(1) DEFAULT 0,
  `enabled` tinyint(1) DEFAULT 1,
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_config`
--

LOCK TABLES `email_config` WRITE;
/*!40000 ALTER TABLE `email_config` DISABLE KEYS */;
INSERT INTO `email_config` VALUES
(1,'smtp.qq.com',465,1,'3020451981@qq.com','leqrhfulklqtdhdc','ArtDesignPro','3020451981@qq.com','844991059@qq.com',0,1,'2026-07-11 16:04:44');
/*!40000 ALTER TABLE `email_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_push_config`
--

DROP TABLE IF EXISTS `email_push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_push_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT '',
  `name` varchar(100) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `template` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `user_group` varchar(20) DEFAULT 'all',
  `level_ids` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `description` varchar(500) DEFAULT '',
  `target` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_push_config`
--

LOCK TABLES `email_push_config` WRITE;
/*!40000 ALTER TABLE `email_push_config` DISABLE KEYS */;
INSERT INTO `email_push_config` VALUES
(1,'user_register','用户注册','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-13 13:35:10','',''),
(2,'order_create','订单创建','',NULL,1,'all',NULL,0,'2026-07-10 22:39:54','2026-07-13 13:35:10','',''),
(3,'new_submission','链接提交邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','前台有新的链接提交向管理员发送邮件','admin'),
(4,'new_order','新订单邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向管理员发送邮件','admin'),
(5,'withdraw_request','提现邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户申请提现向管理员发送邮件','admin'),
(6,'submission_review','投稿待审核通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户投稿待审核时向管理员发送邮件','admin'),
(7,'post_review','帖子待审核通知邮件(管理员)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户发帖待审核时向管理员发送邮件','admin'),
(8,'post_review_moderator','帖子待审核通知邮件(版主)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户发帖待审核时向版主发送邮件','moderator'),
(9,'identity_verify','身份认证通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户申请身份认证向管理员发送邮件','admin'),
(10,'account_appeal','帐号申诉通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','有用户帐号禁封申诉向管理员发送邮件','admin'),
(11,'report_notify','举报通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','收到举报信息向管理员发送邮件','admin'),
(12,'moderator_apply','版主申请通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]有用户申请版主向管理员和超级版主发送邮件','admin'),
(13,'order_paid_user','新订单邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向用户发送邮件','user'),
(14,'withdraw_result','提现通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户提现申请后向用户发送邮件','user'),
(15,'order_paid_referrer','佣金通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后向推荐人发送邮件','user'),
(16,'revenue_split','分成通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户支付订单后有创作分成时向分成作者发送邮件','user'),
(17,'comment_approved','评论审核邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','评论通过审核后向用户发送邮件','user'),
(18,'comment_reply','评论回复通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','评论有新的回复向用户发送邮件','user'),
(19,'content_approved','内容审核邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','投稿、发帖通过审核后向用户发送邮件','user'),
(20,'phone_changed','手机号修改通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户修改绑定手机号向用户发送邮件','user'),
(21,'identity_result','身份认证通知邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户身份认证申请后向用户发送邮件','user'),
(22,'account_ban_user','帐号禁封通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','用户帐号禁封、解封向用户发送邮件','user'),
(23,'report_result','举报反馈邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','处理用户举报后向用户发送邮件','user'),
(24,'moderator_apply_result','版主申请通知邮件(用户)','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]处理用户版主申请后向用户发送邮件','user'),
(25,'moderator_removed','版主移出通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]将用户版主身份移出后向用户发送邮件','user'),
(26,'answer_accepted','回答被采纳','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','[论坛]回答被采纳后向用户发送邮件','user'),
(27,'private_message','私信通知邮件','',NULL,1,'all',NULL,0,'2026-07-13 12:30:41','2026-07-13 13:35:10','收到私信后向收信用户发送邮件','user');
/*!40000 ALTER TABLE `email_push_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `code` varchar(50) DEFAULT '',
  `subject` varchar(200) DEFAULT '',
  `html_content` text DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
(1,'注册验证','register_verify','注册验证邮件','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">您的注册验证码：{{code}}</div>\n      \n      <div>欢迎您的注册！</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',0,'1','2026-07-10 22:39:54','2026-07-21 02:25:24'),
(2,'密码重置','password_reset','密码重置邮件','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">您的验证码：{{code}}</div>\n      \n      <div>{{content}}</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',1,'1','2026-07-10 22:39:54','2026-07-13 12:53:10'),
(5,'通用邮箱模板','all','','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">验证码：{{code}}</div>\n      \n      <div>{{message}}</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',0,'1','2026-07-13 13:08:08','2026-07-13 13:10:02'),
(6,'链接提交邮件','new_submission','网站链接提交通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(7,'新订单邮件','new_order','订单支付通知管理员','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(8,'提现邮件','withdraw_request','提现申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(9,'投稿待审核通知邮件','submission_review','投稿待审核通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(10,'帖子待审核通知邮件(管理员)','post_review','帖子待审核通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(11,'帖子待审核通知邮件(版主)','post_review_moderator','帖子待审核通知版主','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(12,'身份认证通知邮件','identity_verify','身份认证申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(13,'帐号申诉通知邮件','account_appeal','帐号禁封申诉通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(14,'举报通知邮件','report_notify','举报信息通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(15,'版主申请通知邮件','moderator_apply','版主申请通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(16,'新订单邮件(用户)','order_paid_user','订单支付成功通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(17,'提现通知邮件','withdraw_result','提现处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(18,'佣金通知邮件','order_paid_referrer','推荐佣金通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(19,'分成通知邮件','revenue_split','创作分成通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(20,'评论审核邮件','comment_approved','评论审核通过通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(21,'评论回复通知邮件','comment_reply','评论回复通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(22,'内容审核邮件','content_approved','内容审核通过通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(23,'手机号修改通知邮件','phone_changed','手机号修改通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(24,'身份认证通知邮件(用户)','identity_result','身份认证处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(25,'帐号禁封通知邮件','account_ban_user','帐号禁封/解封通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(26,'举报反馈邮件','report_result','举报处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(27,'版主申请通知邮件(用户)','moderator_apply_result','版主申请处理结果通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(28,'版主移出通知邮件','moderator_removed','版主身份移出通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(29,'回答被采纳','answer_accepted','回答被采纳通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(30,'私信通知邮件','private_message','私信通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(31,'订单创建邮件','order_create','订单创建通知','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(32,'用户注册邮件','user_register','用户注册欢迎通知','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">欢迎你的注册，感谢你的使用！</div>\n      \n      <div>欢迎您的注册！</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','',0,'1','2026-07-13 13:38:35','2026-07-21 02:48:15'),
(33,'修改邮箱验证码','change_email','修改邮箱验证码','<div style=\"max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif\"><div style=\"background:linear-gradient(135deg,#667eea,#764ba2);padding:30px;border-radius:12px 12px 0 0;text-align:center\"><h1 style=\"color:#fff;margin:0;font-size:22px\">{{site_name}}</h1></div><div style=\"padding:30px 20px;background:#fff;border:1px solid #eee;border-top:none;border-radius:0 0 12px 12px\"><h2 style=\"color:#333;margin-top:0\">{{subject}}</h2><div style=\"color:#555;font-size:15px;line-height:1.8;margin:20px 0\">{{content}}</div><p style=\"color:#888;font-size:13px\">{{message}}</p></div></div>','',0,'1','2026-07-13 13:38:35','2026-07-13 13:38:35'),
(34,'登录验证','login_verify','邮箱登录验证码','<div style=\"max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative;\">\n  \n  <div style=\"display:flex;height:22px;\">\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n    <div style=\"flex:1;background:#e03030;\"></div>\n    <div style=\"flex:1;background:#3378d8;\"></div>\n  </div>\n\n  <div style=\"padding:24px 26px;position:relative;\">\n    <div style=\"position:absolute;right:16px;top:26px;width:130px;height:130px;opacity:0.12;pointer-events:none;\">\n      <div style=\"width:100%;height:100%;border:2px solid #666;border-radius:50%;position:relative;\">\n        <div style=\"position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:12px;letter-spacing:1px;color:#666;\">NEWSLETTER</div>\n        <svg viewBox=\"0 0 100 100\" fill=\"#666\" style=\"position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:46px;height:46px;\">\n          <path d=\"M90 10 L10 45 L40 55 L60 90 L90 10 Z M42 53 L78 22 L62 76 L42 53 Z\"></path>\n        </svg>\n        <div style=\"position:absolute;bottom:6px;left:50%;transform:translateX(-50%) rotate(180deg);font-size:12px;letter-spacing:1px;color:#666;\">SUBSCRIBE</div>\n      </div>\n      <svg viewBox=\"0 0 180 220\" style=\"position:absolute;right:-30px;top:10px;width:90px;height:110px;opacity:0.12;\">\n        <path d=\"M0,20 Q90,0 180,20 M0,60 Q90,40 180,60 M0,100 Q90,80 180,100\" stroke=\"#666\" fill=\"none\" stroke-width=\"1.5\"/>\n      </svg>\n    </div>\n\n    <h1 style=\"color:#333333;margin:0 0 14px;font-size:26px;font-weight:normal;\">{{subject}}</h1>\n    <div style=\"width:100%;height:1px;background:#cccccc;margin-bottom:20px;\"></div>\n\n    <div style=\"font-size:17px;color:#333333;line-height:1.6;\">\n      <div style=\"margin-bottom:10px;\">您的登录验证码：{{code}}</div>\n      \n      <div>欢迎您的登录！</div>\n    </div>\n  </div>\n\n  <div style=\"padding:16px 26px;background:#eeeeee;font-size:15px;color:#666666;\">\n    <p style=\"margin:0;\">本邮件由系统发送，请勿回复！感谢您的关注</p>\n  </div>\n</div>\n','用户邮箱登录时发送的验证码模板',2,'1','2026-07-21 02:14:04','2026-07-21 02:25:44');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email_verifications_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
INSERT INTO `email_verifications` VALUES
(1,'844991059@qq.com','914984','register',1,'2026-07-12 19:27:30','2026-07-12 19:17:30'),
(2,'844991059@qq.com','267026','register',0,'2026-07-13 13:01:07','2026-07-13 12:51:07'),
(3,'844991059@qq.com','426298','password_reset',0,'2026-07-13 13:06:37','2026-07-13 12:56:37'),
(4,'844991059@qq.com','165745','password_reset',0,'2026-07-13 13:07:56','2026-07-13 12:57:56'),
(5,'844991059@qq.com','391456','password_reset',1,'2026-07-13 13:08:57','2026-07-13 12:58:57'),
(6,'844991059@qq.com','154171','change_email',0,'2026-07-13 13:19:16','2026-07-13 13:09:16'),
(7,'844991059@qq.com','424783','register',0,'2026-07-17 21:51:44','2026-07-17 21:41:44'),
(8,'844991059@qq.com','705124','login',0,'2026-07-21 01:52:59','2026-07-21 01:42:59'),
(10,'844991059@qq.com','149101','password_reset',0,'2026-07-21 02:00:26','2026-07-21 01:50:26'),
(11,'844991059@qq.com','640697','password_reset',0,'2026-07-21 02:05:46','2026-07-21 01:55:46'),
(12,'844991059@qq.com','259911','login',0,'2026-07-21 02:18:38','2026-07-21 02:08:38'),
(13,'844991059@qq.com','184557','login',1,'2026-07-21 02:26:17','2026-07-21 02:16:17'),
(14,'844991059@qq.com','531007','login',0,'2026-07-21 02:27:52','2026-07-21 02:17:52'),
(15,'844991059@qq.com','322945','login',0,'2026-07-21 02:35:56','2026-07-21 02:25:56'),
(17,'disabled_test@art.com','123456','password_reset',0,'2026-07-21 16:47:54','2026-07-21 16:37:54'),
(18,'lisa@example.com','654321','password_reset',0,'2026-07-21 16:48:33','2026-07-21 16:38:33'),
(19,'lisa@test.com','abc123','password_reset',1,'2026-07-21 16:48:42','2026-07-21 16:38:42');
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_level_permissions`
--

DROP TABLE IF EXISTS `experience_level_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_level_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL COMMENT '经验等级 0-7',
  `module` varchar(30) NOT NULL COMMENT '模块: appstore/mall/community/social/monetize/invite/avatar/function',
  `permission_key` varchar(50) NOT NULL COMMENT '权限标识: A1/B1/C1 等',
  `permission_name` varchar(100) DEFAULT NULL,
  `value` text DEFAULT NULL COMMENT '权限值: boolean/number',
  `default_value` text DEFAULT NULL COMMENT '代码默认值',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_level_perm` (`level`,`module`,`permission_key`),
  KEY `idx_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=3104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_level_permissions`
--

LOCK TABLES `experience_level_permissions` WRITE;
/*!40000 ALTER TABLE `experience_level_permissions` DISABLE KEYS */;
INSERT INTO `experience_level_permissions` VALUES
(2294,1,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2295,1,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2296,1,'appstore','A3','应用提交数量上限','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2297,1,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2298,1,'appstore','A6','评论置顶数量','0','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2299,1,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2300,1,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2301,1,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2302,1,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2303,1,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2304,1,'community','C1','发帖免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2305,1,'community','C2','评论免审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2306,1,'community','C3','发帖频率(篇/日)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2307,1,'community','C4','评论频率(条/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2308,1,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2309,1,'community','C9','单帖图片数量','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2310,1,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2311,1,'community','C15','发起投票','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2312,1,'community','C16','投票选项上限','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2313,1,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2314,1,'social','D1','关注总上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2315,1,'social','D2','每日关注上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2316,1,'social','D3','创建合集数量','0','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2317,1,'social','D4','私信权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2318,1,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2319,1,'social','D13','创建话题','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2320,1,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2321,1,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2322,1,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2323,1,'function','H1','签到额外经验加成倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2324,1,'function','H2','任务系统经验奖励倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2325,1,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2326,2,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2327,2,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2328,2,'appstore','A3','应用提交数量上限','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2329,2,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2330,2,'appstore','A6','评论置顶数量','0','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2331,2,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2332,2,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2333,2,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2334,2,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2335,2,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2336,2,'community','C1','发帖免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2337,2,'community','C2','评论免审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2338,2,'community','C3','发帖频率(篇/日)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2339,2,'community','C4','评论频率(条/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2340,2,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2341,2,'community','C9','单帖图片数量','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2342,2,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2343,2,'community','C15','发起投票','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2344,2,'community','C16','投票选项上限','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2345,2,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2346,2,'social','D1','关注总上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2347,2,'social','D2','每日关注上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2348,2,'social','D3','创建合集数量','0','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2349,2,'social','D4','私信权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2350,2,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2351,2,'social','D13','创建话题','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2352,2,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2353,2,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2354,2,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2355,2,'function','H1','签到额外经验加成倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2356,2,'function','H2','任务系统经验奖励倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2357,2,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2358,3,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2359,3,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2360,3,'appstore','A3','应用提交数量上限','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2361,3,'appstore','A4','应用定价上限(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2362,3,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2363,3,'appstore','A6','评论置顶数量','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2364,3,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2365,3,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2366,3,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2367,3,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2368,3,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2369,3,'community','C1','发帖免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2370,3,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2371,3,'community','C3','发帖频率(篇/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2372,3,'community','C4','评论频率(条/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2373,3,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2374,3,'community','C9','单帖图片数量','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2375,3,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2376,3,'community','C15','发起投票','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2377,3,'community','C16','投票选项上限','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2378,3,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2379,3,'social','D1','关注总上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2380,3,'social','D2','每日关注上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2381,3,'social','D3','创建合集数量','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2382,3,'social','D4','私信权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2383,3,'social','D6','消息撤回时长(分钟)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2384,3,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2385,3,'social','D12','聊天室文件上传(MB)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2386,3,'social','D13','创建话题','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2387,3,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2388,3,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2389,3,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2390,3,'function','H1','签到额外经验加成倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2391,3,'function','H2','任务系统经验奖励倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2392,3,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2393,4,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2394,4,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2395,4,'appstore','A3','应用提交数量上限','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2396,4,'appstore','A4','应用定价上限(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2397,4,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2398,4,'appstore','A6','评论置顶数量','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2399,4,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2400,4,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2401,4,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2402,4,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2403,4,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2404,4,'community','C1','发帖免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2405,4,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2406,4,'community','C3','发帖频率(篇/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2407,4,'community','C4','评论频率(条/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2408,4,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2409,4,'community','C9','单帖图片数量','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2410,4,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2411,4,'community','C15','发起投票','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2412,4,'community','C16','投票选项上限','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2413,4,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2414,4,'social','D1','关注总上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2415,4,'social','D2','每日关注上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2416,4,'social','D3','创建合集数量','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2417,4,'social','D4','私信权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2418,4,'social','D6','消息撤回时长(分钟)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2419,4,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2420,4,'social','D12','聊天室文件上传(MB)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2421,4,'social','D13','创建话题','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2422,4,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2423,4,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2424,4,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2425,4,'function','H1','签到额外经验加成倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2426,4,'function','H2','任务系统经验奖励倍率','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2427,4,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2428,5,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2429,5,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2430,5,'appstore','A3','应用提交数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2431,5,'appstore','A4','应用定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2432,5,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2433,5,'appstore','A6','评论置顶数量','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2434,5,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2435,5,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2436,5,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2437,5,'mall','B2','上架商品数量上限','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2438,5,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2439,5,'mall','B4','商品定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2440,5,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2441,5,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2442,5,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2443,5,'community','C3','发帖频率(篇/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2444,5,'community','C4','评论频率(条/日)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2445,5,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2446,5,'community','C6','内容定价上限(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2447,5,'community','C9','单帖图片数量','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2448,5,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2449,5,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2450,5,'community','C16','投票选项上限','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2451,5,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2452,5,'social','D1','关注总上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2453,5,'social','D2','每日关注上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2454,5,'social','D3','创建合集数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2455,5,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2456,5,'social','D6','消息撤回时长(分钟)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2457,5,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2458,5,'social','D11','聊天室成员上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2459,5,'social','D12','聊天室文件上传(MB)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2460,5,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2461,5,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2462,5,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2463,5,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2464,5,'function','H1','签到额外经验加成倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2465,5,'function','H2','任务系统经验奖励倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2466,5,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2467,6,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2468,6,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2469,6,'appstore','A3','应用提交数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2470,6,'appstore','A4','应用定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2471,6,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2472,6,'appstore','A6','评论置顶数量','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2473,6,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2474,6,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2475,6,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2476,6,'mall','B2','上架商品数量上限','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2477,6,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2478,6,'mall','B4','商品定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2479,6,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2480,6,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2481,6,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2482,6,'community','C3','发帖频率(篇/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2483,6,'community','C4','评论频率(条/日)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2484,6,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2485,6,'community','C6','内容定价上限(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2486,6,'community','C9','单帖图片数量','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2487,6,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2488,6,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2489,6,'community','C16','投票选项上限','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2490,6,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2491,6,'social','D1','关注总上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2492,6,'social','D2','每日关注上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2493,6,'social','D3','创建合集数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2494,6,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2495,6,'social','D6','消息撤回时长(分钟)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2496,6,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2497,6,'social','D11','聊天室成员上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2498,6,'social','D12','聊天室文件上传(MB)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2499,6,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2500,6,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2501,6,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2502,6,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2503,6,'function','H1','签到额外经验加成倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2504,6,'function','H2','任务系统经验奖励倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2505,6,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2506,7,'appstore','A1','应用提交免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2507,7,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2508,7,'appstore','A3','应用提交数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2509,7,'appstore','A4','应用定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2510,7,'appstore','A5','可创建付费应用','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2511,7,'appstore','A6','评论置顶数量','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2512,7,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2513,7,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2514,7,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2515,7,'mall','B2','上架商品数量上限','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2516,7,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2517,7,'mall','B4','商品定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2518,7,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2519,7,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2520,7,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2521,7,'community','C3','发帖频率(篇/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2522,7,'community','C4','评论频率(条/日)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2523,7,'community','C5','可发布付费内容','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2524,7,'community','C6','内容定价上限(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2525,7,'community','C9','单帖图片数量','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2526,7,'community','C14','定时发布','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2527,7,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2528,7,'community','C16','投票选项上限','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2529,7,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2530,7,'social','D1','关注总上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2531,7,'social','D2','每日关注上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2532,7,'social','D3','创建合集数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2533,7,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2534,7,'social','D6','消息撤回时长(分钟)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2535,7,'social','D10','创建聊天室','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2536,7,'social','D11','聊天室成员上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2537,7,'social','D12','聊天室文件上传(MB)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2538,7,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2539,7,'monetize','E1','提现权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2540,7,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2541,7,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2542,7,'function','H1','签到额外经验加成倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2543,7,'function','H2','任务系统经验奖励倍率','1.1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2544,7,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2545,8,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2546,8,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2547,8,'appstore','A3','应用提交数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2548,8,'appstore','A4','应用定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2549,8,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2550,8,'appstore','A6','评论置顶数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2551,8,'appstore','A7','应用下载免购买(次/日)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2552,8,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2553,8,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2554,8,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2555,8,'mall','B2','上架商品数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2556,8,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2557,8,'mall','B4','商品定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2558,8,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2559,8,'mall','B6','追加评价(次/订单)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2560,8,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2561,8,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2562,8,'community','C3','发帖频率(篇/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2563,8,'community','C4','评论频率(条/日)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2564,8,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2565,8,'community','C6','内容定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2566,8,'community','C9','单帖图片数量','9','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2567,8,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2568,8,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2569,8,'community','C16','投票选项上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2570,8,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2571,8,'social','D1','关注总上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2572,8,'social','D2','每日关注上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2573,8,'social','D3','创建合集数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2574,8,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2575,8,'social','D6','消息撤回时长(分钟)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2576,8,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2577,8,'social','D11','聊天室成员上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2578,8,'social','D12','聊天室文件上传(MB)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2579,8,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2580,8,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2581,8,'monetize','E2','最低提现金额(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2582,8,'invite','F2','邀请码生成数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2583,8,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2584,8,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2585,8,'function','H1','签到额外经验加成倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2586,8,'function','H2','任务系统经验奖励倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2587,8,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2588,9,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2589,9,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2590,9,'appstore','A3','应用提交数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2591,9,'appstore','A4','应用定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2592,9,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2593,9,'appstore','A6','评论置顶数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2594,9,'appstore','A7','应用下载免购买(次/日)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2595,9,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2596,9,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2597,9,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2598,9,'mall','B2','上架商品数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2599,9,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2600,9,'mall','B4','商品定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2601,9,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2602,9,'mall','B6','追加评价(次/订单)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2603,9,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2604,9,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2605,9,'community','C3','发帖频率(篇/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2606,9,'community','C4','评论频率(条/日)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2607,9,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2608,9,'community','C6','内容定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2609,9,'community','C9','单帖图片数量','9','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2610,9,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2611,9,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2612,9,'community','C16','投票选项上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2613,9,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2614,9,'social','D1','关注总上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2615,9,'social','D2','每日关注上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2616,9,'social','D3','创建合集数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2617,9,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2618,9,'social','D6','消息撤回时长(分钟)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2619,9,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2620,9,'social','D11','聊天室成员上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2621,9,'social','D12','聊天室文件上传(MB)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2622,9,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2623,9,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2624,9,'monetize','E2','最低提现金额(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2625,9,'invite','F2','邀请码生成数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2626,9,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2627,9,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2628,9,'function','H1','签到额外经验加成倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2629,9,'function','H2','任务系统经验奖励倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2630,9,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2631,10,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2632,10,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2633,10,'appstore','A3','应用提交数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2634,10,'appstore','A4','应用定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2635,10,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2636,10,'appstore','A6','评论置顶数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2637,10,'appstore','A7','应用下载免购买(次/日)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2638,10,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2639,10,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2640,10,'mall','B1','开店权限','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2641,10,'mall','B2','上架商品数量上限','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2642,10,'mall','B3','商品免审核','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2643,10,'mall','B4','商品定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2644,10,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2645,10,'mall','B6','追加评价(次/订单)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2646,10,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2647,10,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2648,10,'community','C3','发帖频率(篇/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2649,10,'community','C4','评论频率(条/日)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2650,10,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2651,10,'community','C6','内容定价上限(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2652,10,'community','C9','单帖图片数量','9','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2653,10,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2654,10,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2655,10,'community','C16','投票选项上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2656,10,'community','C17','版块权限覆盖','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2657,10,'social','D1','关注总上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2658,10,'social','D2','每日关注上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2659,10,'social','D3','创建合集数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2660,10,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2661,10,'social','D6','消息撤回时长(分钟)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2662,10,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2663,10,'social','D11','聊天室成员上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2664,10,'social','D12','聊天室文件上传(MB)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2665,10,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2666,10,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2667,10,'monetize','E2','最低提现金额(元)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2668,10,'invite','F2','邀请码生成数量','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2669,10,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2670,10,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2671,10,'function','H1','签到额外经验加成倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2672,10,'function','H2','任务系统经验奖励倍率','1.2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2673,10,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2674,11,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2675,11,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2676,11,'appstore','A3','应用提交数量上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2677,11,'appstore','A4','应用定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2678,11,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2679,11,'appstore','A6','评论置顶数量','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2680,11,'appstore','A7','应用下载免购买(次/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2681,11,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2682,11,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2683,11,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2684,11,'mall','B2','上架商品数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2685,11,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2686,11,'mall','B4','商品定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2687,11,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2688,11,'mall','B6','追加评价(次/订单)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2689,11,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2690,11,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2691,11,'community','C3','发帖频率(篇/日)','15','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2692,11,'community','C4','评论频率(条/日)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2693,11,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2694,11,'community','C6','内容定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2695,11,'community','C9','单帖图片数量','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2696,11,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2697,11,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2698,11,'community','C16','投票选项上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2699,11,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2700,11,'social','D1','关注总上限','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2701,11,'social','D2','每日关注上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2702,11,'social','D3','创建合集数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2703,11,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2704,11,'social','D6','消息撤回时长(分钟)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2705,11,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2706,11,'social','D11','聊天室成员上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2707,11,'social','D12','聊天室文件上传(MB)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2708,11,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2709,11,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2710,11,'monetize','E2','最低提现金额(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2711,11,'invite','F2','邀请码生成数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2712,11,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2713,11,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2714,11,'function','H1','签到额外经验加成倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2715,11,'function','H2','任务系统经验奖励倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2716,11,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2717,12,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2718,12,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2719,12,'appstore','A3','应用提交数量上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2720,12,'appstore','A4','应用定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2721,12,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2722,12,'appstore','A6','评论置顶数量','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2723,12,'appstore','A7','应用下载免购买(次/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2724,12,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2725,12,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2726,12,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2727,12,'mall','B2','上架商品数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2728,12,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2729,12,'mall','B4','商品定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2730,12,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2731,12,'mall','B6','追加评价(次/订单)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2732,12,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2733,12,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2734,12,'community','C3','发帖频率(篇/日)','15','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2735,12,'community','C4','评论频率(条/日)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2736,12,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2737,12,'community','C6','内容定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2738,12,'community','C9','单帖图片数量','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2739,12,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2740,12,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2741,12,'community','C16','投票选项上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2742,12,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2743,12,'social','D1','关注总上限','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2744,12,'social','D2','每日关注上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2745,12,'social','D3','创建合集数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2746,12,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2747,12,'social','D6','消息撤回时长(分钟)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2748,12,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2749,12,'social','D11','聊天室成员上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2750,12,'social','D12','聊天室文件上传(MB)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2751,12,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2752,12,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2753,12,'monetize','E2','最低提现金额(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2754,12,'invite','F2','邀请码生成数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2755,12,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2756,12,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2757,12,'function','H1','签到额外经验加成倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2758,12,'function','H2','任务系统经验奖励倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2759,12,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2760,13,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2761,13,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2762,13,'appstore','A3','应用提交数量上限','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2763,13,'appstore','A4','应用定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2764,13,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2765,13,'appstore','A6','评论置顶数量','4','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2766,13,'appstore','A7','应用下载免购买(次/日)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2767,13,'appstore','A9','应用被推荐位加权','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2768,13,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2769,13,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2770,13,'mall','B2','上架商品数量上限','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2771,13,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2772,13,'mall','B4','商品定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2773,13,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2774,13,'mall','B6','追加评价(次/订单)','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2775,13,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2776,13,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2777,13,'community','C3','发帖频率(篇/日)','15','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2778,13,'community','C4','评论频率(条/日)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2779,13,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2780,13,'community','C6','内容定价上限(元)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2781,13,'community','C9','单帖图片数量','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2782,13,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2783,13,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2784,13,'community','C16','投票选项上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2785,13,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2786,13,'social','D1','关注总上限','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2787,13,'social','D2','每日关注上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2788,13,'social','D3','创建合集数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2789,13,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2790,13,'social','D6','消息撤回时长(分钟)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2791,13,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2792,13,'social','D11','聊天室成员上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2793,13,'social','D12','聊天室文件上传(MB)','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2794,13,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2795,13,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2796,13,'monetize','E2','最低提现金额(元)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2797,13,'invite','F2','邀请码生成数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2798,13,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2799,13,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2800,13,'function','H1','签到额外经验加成倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2801,13,'function','H2','任务系统经验奖励倍率','1.3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2802,13,'function','H3','数据导出','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2803,14,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2804,14,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2805,14,'appstore','A3','应用提交数量上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2806,14,'appstore','A4','应用定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2807,14,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2808,14,'appstore','A6','评论置顶数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2809,14,'appstore','A7','应用下载免购买(次/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2810,14,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2811,14,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2812,14,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2813,14,'mall','B2','上架商品数量上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2814,14,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2815,14,'mall','B4','商品定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2816,14,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2817,14,'mall','B6','追加评价(次/订单)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2818,14,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2819,14,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2820,14,'community','C3','发帖频率(篇/日)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2821,14,'community','C4','评论频率(条/日)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2822,14,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2823,14,'community','C6','内容定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2824,14,'community','C9','单帖图片数量','16','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2825,14,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2826,14,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2827,14,'community','C16','投票选项上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2828,14,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2829,14,'social','D1','关注总上限','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2830,14,'social','D2','每日关注上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2831,14,'social','D3','创建合集数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2832,14,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2833,14,'social','D6','消息撤回时长(分钟)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2834,14,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2835,14,'social','D11','聊天室成员上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2836,14,'social','D12','聊天室文件上传(MB)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2837,14,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2838,14,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2839,14,'monetize','E2','最低提现金额(元)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2840,14,'invite','F2','邀请码生成数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2841,14,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2842,14,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2843,14,'function','H1','签到额外经验加成倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2844,14,'function','H2','任务系统经验奖励倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2845,14,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2846,15,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2847,15,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2848,15,'appstore','A3','应用提交数量上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2849,15,'appstore','A4','应用定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2850,15,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2851,15,'appstore','A6','评论置顶数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2852,15,'appstore','A7','应用下载免购买(次/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2853,15,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2854,15,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2855,15,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2856,15,'mall','B2','上架商品数量上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2857,15,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2858,15,'mall','B4','商品定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2859,15,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2860,15,'mall','B6','追加评价(次/订单)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2861,15,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2862,15,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2863,15,'community','C3','发帖频率(篇/日)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2864,15,'community','C4','评论频率(条/日)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2865,15,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2866,15,'community','C6','内容定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2867,15,'community','C9','单帖图片数量','16','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2868,15,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2869,15,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2870,15,'community','C16','投票选项上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2871,15,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2872,15,'social','D1','关注总上限','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2873,15,'social','D2','每日关注上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2874,15,'social','D3','创建合集数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2875,15,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2876,15,'social','D6','消息撤回时长(分钟)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2877,15,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2878,15,'social','D11','聊天室成员上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2879,15,'social','D12','聊天室文件上传(MB)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2880,15,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2881,15,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2882,15,'monetize','E2','最低提现金额(元)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2883,15,'invite','F2','邀请码生成数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2884,15,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:54:01'),
(2885,15,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:54:01'),
(2886,15,'function','H1','签到额外经验加成倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2887,15,'function','H2','任务系统经验奖励倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2888,15,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2889,16,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2890,16,'appstore','A2','编辑后免重审','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2891,16,'appstore','A3','应用提交数量上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2892,16,'appstore','A4','应用定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2893,16,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2894,16,'appstore','A6','评论置顶数量','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2895,16,'appstore','A7','应用下载免购买(次/日)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2896,16,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2897,16,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2898,16,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2899,16,'mall','B2','上架商品数量上限','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2900,16,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2901,16,'mall','B4','商品定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2902,16,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2903,16,'mall','B6','追加评价(次/订单)','3','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2904,16,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2905,16,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2906,16,'community','C3','发帖频率(篇/日)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2907,16,'community','C4','评论频率(条/日)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2908,16,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2909,16,'community','C6','内容定价上限(元)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2910,16,'community','C9','单帖图片数量','16','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2911,16,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2912,16,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2913,16,'community','C16','投票选项上限','12','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2914,16,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2915,16,'social','D1','关注总上限','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2916,16,'social','D2','每日关注上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2917,16,'social','D3','创建合集数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2918,16,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2919,16,'social','D6','消息撤回时长(分钟)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2920,16,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2921,16,'social','D11','聊天室成员上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2922,16,'social','D12','聊天室文件上传(MB)','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2923,16,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2924,16,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2925,16,'monetize','E2','最低提现金额(元)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2926,16,'invite','F2','邀请码生成数量','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2927,16,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2928,16,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2929,16,'function','H1','签到额外经验加成倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2930,16,'function','H2','任务系统经验奖励倍率','1.5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2931,16,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2932,17,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2933,17,'appstore','A2','编辑后免重审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2934,17,'appstore','A3','应用提交数量上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2935,17,'appstore','A4','应用定价上限(元)','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2936,17,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2937,17,'appstore','A6','评论置顶数量','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2938,17,'appstore','A7','应用下载免购买(次/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2939,17,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2940,17,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2941,17,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2942,17,'mall','B2','上架商品数量上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2943,17,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2944,17,'mall','B4','商品定价上限(元)','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2945,17,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2946,17,'mall','B6','追加评价(次/订单)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2947,17,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2948,17,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2949,17,'community','C3','发帖频率(篇/日)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2950,17,'community','C4','评论频率(条/日)','300','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2951,17,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2952,17,'community','C6','内容定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2953,17,'community','C9','单帖图片数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2954,17,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2955,17,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2956,17,'community','C16','投票选项上限','15','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2957,17,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2958,17,'social','D1','关注总上限','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2959,17,'social','D2','每日关注上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2960,17,'social','D3','创建合集数量','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2961,17,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2962,17,'social','D6','消息撤回时长(分钟)','60','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2963,17,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2964,17,'social','D11','聊天室成员上限','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2965,17,'social','D12','聊天室文件上传(MB)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2966,17,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2967,17,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2968,17,'monetize','E2','最低提现金额(元)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2969,17,'invite','F2','邀请码生成数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2970,17,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2971,17,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(2972,17,'function','H1','签到额外经验加成倍率','1.8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2973,17,'function','H2','任务系统经验奖励倍率','1.8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2974,17,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2975,18,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2976,18,'appstore','A2','编辑后免重审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2977,18,'appstore','A3','应用提交数量上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2978,18,'appstore','A4','应用定价上限(元)','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2979,18,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2980,18,'appstore','A6','评论置顶数量','6','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2981,18,'appstore','A7','应用下载免购买(次/日)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2982,18,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2983,18,'appstore','A10','合集/捆绑包创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2984,18,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2985,18,'mall','B2','上架商品数量上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2986,18,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2987,18,'mall','B4','商品定价上限(元)','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2988,18,'mall','B5','促销活动创建','false','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2989,18,'mall','B6','追加评价(次/订单)','5','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2990,18,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2991,18,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2992,18,'community','C3','发帖频率(篇/日)','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2993,18,'community','C4','评论频率(条/日)','300','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2994,18,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2995,18,'community','C6','内容定价上限(元)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2996,18,'community','C9','单帖图片数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2997,18,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2998,18,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(2999,18,'community','C16','投票选项上限','15','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3000,18,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3001,18,'social','D1','关注总上限','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3002,18,'social','D2','每日关注上限','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3003,18,'social','D3','创建合集数量','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3004,18,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3005,18,'social','D6','消息撤回时长(分钟)','60','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3006,18,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3007,18,'social','D11','聊天室成员上限','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3008,18,'social','D12','聊天室文件上传(MB)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3009,18,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3010,18,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3011,18,'monetize','E2','最低提现金额(元)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3012,18,'invite','F2','邀请码生成数量','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3013,18,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3014,18,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3015,18,'function','H1','签到额外经验加成倍率','1.8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3016,18,'function','H2','任务系统经验奖励倍率','1.8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3017,18,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3018,19,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3019,19,'appstore','A2','编辑后免重审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3020,19,'appstore','A3','应用提交数量上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3021,19,'appstore','A4','应用定价上限(元)','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3022,19,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3023,19,'appstore','A6','评论置顶数量','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3024,19,'appstore','A7','应用下载免购买(次/日)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3025,19,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3026,19,'appstore','A10','合集/捆绑包创建','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3027,19,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3028,19,'mall','B2','上架商品数量上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3029,19,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3030,19,'mall','B4','商品定价上限(元)','10000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3031,19,'mall','B5','促销活动创建','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3032,19,'mall','B6','追加评价(次/订单)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3033,19,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3034,19,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3035,19,'community','C3','发帖频率(篇/日)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3036,19,'community','C4','评论频率(条/日)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3037,19,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3038,19,'community','C6','内容定价上限(元)','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3039,19,'community','C9','单帖图片数量','25','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3040,19,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3041,19,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3042,19,'community','C16','投票选项上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3043,19,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3044,19,'social','D1','关注总上限','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3045,19,'social','D2','每日关注上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3046,19,'social','D3','创建合集数量','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3047,19,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3048,19,'social','D6','消息撤回时长(分钟)','120','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3049,19,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3050,19,'social','D11','聊天室成员上限','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3051,19,'social','D12','聊天室文件上传(MB)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3052,19,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3053,19,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3054,19,'monetize','E2','最低提现金额(元)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3055,19,'invite','F2','邀请码生成数量','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3056,19,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3057,19,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3058,19,'function','H1','签到额外经验加成倍率','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3059,19,'function','H2','任务系统经验奖励倍率','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3060,19,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3061,20,'appstore','A1','应用提交免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3062,20,'appstore','A2','编辑后免重审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3063,20,'appstore','A3','应用提交数量上限','30','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3064,20,'appstore','A4','应用定价上限(元)','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3065,20,'appstore','A5','可创建付费应用','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3066,20,'appstore','A6','评论置顶数量','8','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3067,20,'appstore','A7','应用下载免购买(次/日)','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3068,20,'appstore','A9','应用被推荐位加权','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3069,20,'appstore','A10','合集/捆绑包创建','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3070,20,'mall','B1','开店权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3071,20,'mall','B2','上架商品数量上限','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3072,20,'mall','B3','商品免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3073,20,'mall','B4','商品定价上限(元)','10000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3074,20,'mall','B5','促销活动创建','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3075,20,'mall','B6','追加评价(次/订单)','10','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3076,20,'community','C1','发帖免审核','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3077,20,'community','C2','评论免审','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3078,20,'community','C3','发帖频率(篇/日)','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3079,20,'community','C4','评论频率(条/日)','500','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3080,20,'community','C5','可发布付费内容','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3081,20,'community','C6','内容定价上限(元)','2000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3082,20,'community','C9','单帖图片数量','25','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3083,20,'community','C14','定时发布','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3084,20,'community','C15','发起投票','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3085,20,'community','C16','投票选项上限','20','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3086,20,'community','C17','版块权限覆盖','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3087,20,'social','D1','关注总上限','5000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3088,20,'social','D2','每日关注上限','200','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3089,20,'social','D3','创建合集数量','100','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3090,20,'social','D4','私信权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3091,20,'social','D6','消息撤回时长(分钟)','120','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3092,20,'social','D10','创建聊天室','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3093,20,'social','D11','聊天室成员上限','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3094,20,'social','D12','聊天室文件上传(MB)','1000','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3095,20,'social','D13','创建话题','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3096,20,'monetize','E1','提现权限','true','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3097,20,'monetize','E2','最低提现金额(元)','1','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3098,20,'invite','F2','邀请码生成数量','50','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3099,20,'avatar','G1','头像框获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3100,20,'avatar','G2','称号获取','','','2026-07-20 06:51:26','2026-07-20 06:51:32'),
(3101,20,'function','H1','签到额外经验加成倍率','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3102,20,'function','H2','任务系统经验奖励倍率','2','','2026-07-20 06:51:26','2026-07-20 06:51:26'),
(3103,20,'function','H3','数据导出','true','','2026-07-20 06:51:26','2026-07-20 06:51:26');
/*!40000 ALTER TABLE `experience_level_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_levels`
--

DROP TABLE IF EXISTS `experience_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `exp_required` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#00BFA5',
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_experience_levels_exp_status` (`exp_required`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_levels`
--

LOCK TABLES `experience_levels` WRITE;
/*!40000 ALTER TABLE `experience_levels` DISABLE KEYS */;
INSERT INTO `experience_levels` VALUES
(1,'Lv.1',1,0,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982350949.png','#00BFA5','#FFFFFF','#508DFF','每日发1帖/评3条/关注3人 | 单帖2图 | 投票2选项','1','2026-07-10 22:42:45'),
(2,'Lv.2',2,100,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982360639.png','#42A5F5','#FFFFFF','#508DFF','每日发1帖/评3条/关注3人 | 单帖2图 | 投票2选项','1','2026-07-10 22:42:45'),
(3,'Lv.3',3,180,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982426213.png','#7C4DFF','#FFFFFF','#508DFF','每日发3帖/评10条/关注5人 | 单帖4图 | 评论免审 | 投票4选项 | 定价50元 | 创建合集','1','2026-07-10 22:42:45'),
(4,'Lv.4',4,300,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982437138.png','#FFB74D','#FFFFFF','#508DFF','每日发3帖/评10条/关注5人 | 单帖4图 | 评论免审 | 投票4选项 | 定价50元 | 创建合集','1','2026-07-10 22:42:45'),
(5,'Lv.5',5,500,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982444873.png','#FF6B6B','#FFFFFF','#508DFF','每日发5帖/评30条/关注10人 | 单帖6图 | 发帖评论免审 | 投票6选项 | 私信 | 定价100元 | 发起投票 | 创建话题','1','2026-07-10 22:42:45'),
(6,'Lv.6',6,800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982453777.png','#FFD700','#FFFFFF','#508DFF','每日发5帖/评30条/关注10人 | 单帖6图 | 发帖评论免审 | 投票6选项 | 私信 | 定价100元 | 发起投票 | 创建话题','1','2026-07-10 22:42:45'),
(7,'Lv.7',7,1600,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982462674.png','#FF4081','#FFFFFF','#508DFF','每日发5帖/评30条/关注10人 | 单帖6图 | 发帖评论免审 | 投票6选项 | 私信 | 定价100元 | 发起投票 | 创建话题','1','2026-07-10 22:42:45'),
(8,'LV.8',8,2400,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982470785.png','#00BFA5','#FFFFFF','#508DFF','每日发10帖/评50条/关注20人 | 单帖9图 | 定时发布 | 付费内容 | 可提现 | 聊天室 | 评论置顶(3) | 定价200元','1','2026-07-13 19:17:12'),
(9,'LV.9',9,3800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982478996.png','#00BFA5','#FFFFFF','#508DFF','每日发10帖/评50条/关注20人 | 单帖9图 | 定时发布 | 付费内容 | 可提现 | 聊天室 | 评论置顶(3) | 定价200元','1','2026-07-13 19:17:49'),
(10,'LV.10',10,5200,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982490516.png','#00BFA5','#FFFFFF','#508DFF','每日发10帖/评50条/关注20人 | 单帖9图 | 定时发布 | 付费内容 | 可提现 | 聊天室 | 评论置顶(3) | 定价200元','1','2026-07-13 22:41:32'),
(11,'LV.11',11,6800,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982513242.png','#00BFA5','#FFFFFF','#508DFF','每日发15帖/评100条/关注30人 | 单帖12图 | 开店(5商品) | 商品/应用免审核 | 头像框 | 评论置顶(4) | 定价500元 | 最低提现50元','1','2026-07-13 22:41:54'),
(12,'LV.12',12,12000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982529934.png','#00BFA5','#FFFFFF','#508DFF','每日发15帖/评100条/关注30人 | 单帖12图 | 开店(5商品) | 商品/应用免审核 | 头像框 | 评论置顶(4) | 定价500元 | 最低提现50元','1','2026-07-13 22:42:10'),
(13,'LV.13',13,18000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982541798.png','#00BFA5','#FFFFFF','#508DFF','每日发15帖/评100条/关注30人 | 单帖12图 | 开店(5商品) | 商品/应用免审核 | 头像框 | 评论置顶(4) | 定价500元 | 最低提现50元','1','2026-07-13 22:42:22'),
(14,'LV.14',14,23000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982552450.png','#00BFA5','#FFFFFF','#508DFF','每日发20帖/评200条/关注50人 | 单帖16图 | 开店(10商品) | 推荐加权 | 数据导出 | 评论置顶(5) | 定价1000元 | 最低提现30元','1','2026-07-13 22:42:33'),
(15,'LV.15',15,28000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982561799.png','#00BFA5','#FFFFFF','#508DFF','每日发20帖/评200条/关注50人 | 单帖16图 | 开店(10商品) | 推荐加权 | 数据导出 | 评论置顶(5) | 定价1000元 | 最低提现30元','1','2026-07-13 22:42:42'),
(16,'LV.16',16,32000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982572800.png','#00BFA5','#FFFFFF','#508DFF','每日发20帖/评200条/关注50人 | 单帖16图 | 开店(10商品) | 推荐加权 | 数据导出 | 评论置顶(5) | 定价1000元 | 最低提现30元','1','2026-07-13 22:42:53'),
(17,'LV.17',17,38000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982585818.png','#00BFA5','#FFFFFF','#508DFF','每日发30帖/评300条/关注100人 | 单帖20图 | 开店(20商品) | 编辑免重审 | 评论置顶(6) | 定价2000元 | 最低提现10元','1','2026-07-13 22:43:06'),
(18,'LV.18',18,50000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982597739.png','#00BFA5','#FFFFFF','#508DFF','每日发30帖/评300条/关注100人 | 单帖20图 | 开店(20商品) | 编辑免重审 | 评论置顶(6) | 定价2000元 | 最低提现10元','1','2026-07-13 22:43:18'),
(19,'LV.19',19,75000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982608548.png','#00BFA5','#FFFFFF','#508DFF','每日发50帖/评500条/关注200人 | 单帖25图 | 开店(50商品) | 合集创建 | 促销活动 | 评论置顶(8) | 定价5000元 | 最低提现1元 | 全部权益','1','2026-07-13 22:43:29'),
(20,'LV.20',20,100000,'http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982626576.png','#00BFA5','#FFFFFF','#508DFF','每日发50帖/评500条/关注200人 | 单帖25图 | 开店(50商品) | 合集创建 | 促销活动 | 评论置顶(8) | 定价5000元 | 最低提现1元 | 全部权益','1','2026-07-13 22:43:47');
/*!40000 ALTER TABLE `experience_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_permission_config`
--

DROP TABLE IF EXISTS `experience_permission_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_permission_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `permission_key` varchar(50) NOT NULL,
  `permission_name` varchar(100) NOT NULL,
  `level_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`level_values`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_module_key` (`module`,`permission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_permission_config`
--

LOCK TABLES `experience_permission_config` WRITE;
/*!40000 ALTER TABLE `experience_permission_config` DISABLE KEYS */;
INSERT INTO `experience_permission_config` VALUES
(1,'appstore','A1','应用提交免审核','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(2,'appstore','A10','合集/捆绑包创建','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"false\", \"12\": \"false\", \"13\": \"false\", \"14\": \"false\", \"15\": \"false\", \"16\": \"false\", \"17\": \"false\", \"18\": \"false\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(3,'appstore','A2','编辑后免重审','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"false\", \"12\": \"false\", \"13\": \"false\", \"14\": \"false\", \"15\": \"false\", \"16\": \"false\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(4,'appstore','A3','应用提交数量上限','{\"1\": \"1\", \"2\": \"1\", \"3\": \"2\", \"4\": \"2\", \"5\": \"3\", \"6\": \"3\", \"7\": \"3\", \"8\": \"5\", \"9\": \"5\", \"10\": \"5\", \"11\": \"8\", \"12\": \"8\", \"13\": \"8\", \"14\": \"12\", \"15\": \"12\", \"16\": \"12\", \"17\": \"20\", \"18\": \"20\", \"19\": \"30\", \"20\": \"30\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(5,'appstore','A4','应用定价上限(元)','{\"3\": \"50\", \"4\": \"50\", \"5\": \"100\", \"6\": \"100\", \"7\": \"100\", \"8\": \"200\", \"9\": \"200\", \"10\": \"200\", \"11\": \"500\", \"12\": \"500\", \"13\": \"500\", \"14\": \"1000\", \"15\": \"1000\", \"16\": \"1000\", \"17\": \"2000\", \"18\": \"2000\", \"19\": \"5000\", \"20\": \"5000\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(6,'appstore','A5','可创建付费应用','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(7,'appstore','A6','评论置顶数量','{\"1\": \"0\", \"2\": \"0\", \"3\": \"1\", \"4\": \"1\", \"5\": \"2\", \"6\": \"2\", \"7\": \"2\", \"8\": \"3\", \"9\": \"3\", \"10\": \"3\", \"11\": \"4\", \"12\": \"4\", \"13\": \"4\", \"14\": \"5\", \"15\": \"5\", \"16\": \"5\", \"17\": \"6\", \"18\": \"6\", \"19\": \"8\", \"20\": \"8\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(8,'appstore','A7','应用下载免购买(次/日)','{\"8\": \"1\", \"9\": \"1\", \"10\": \"1\", \"11\": \"3\", \"12\": \"3\", \"13\": \"3\", \"14\": \"5\", \"15\": \"5\", \"16\": \"5\", \"17\": \"10\", \"18\": \"10\", \"19\": \"20\", \"20\": \"20\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(9,'appstore','A9','应用被推荐位加权','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"false\", \"12\": \"false\", \"13\": \"false\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(10,'avatar','G1','头像框获取','{\"1\": \"\", \"2\": \"\", \"3\": \"\", \"4\": \"\", \"5\": \"\", \"6\": \"\", \"7\": \"\", \"8\": \"\", \"9\": \"\", \"10\": \"\", \"11\": \"\", \"12\": \"\", \"13\": \"\", \"14\": \"\", \"15\": \"\", \"16\": \"\", \"17\": \"\", \"18\": \"\", \"19\": \"\", \"20\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(11,'avatar','G2','称号获取','{\"1\": \"\", \"2\": \"\", \"3\": \"\", \"4\": \"\", \"5\": \"\", \"6\": \"\", \"7\": \"\", \"8\": \"\", \"9\": \"\", \"10\": \"\", \"11\": \"\", \"12\": \"\", \"13\": \"\", \"14\": \"\", \"15\": \"\", \"16\": \"\", \"17\": \"\", \"18\": \"\", \"19\": \"\", \"20\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(12,'community','C1','发帖免审核','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"true\", \"6\": \"true\", \"7\": \"true\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(13,'community','C14','定时发布','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(14,'community','C15','发起投票','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"true\", \"6\": \"true\", \"7\": \"true\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(15,'community','C16','投票选项上限','{\"1\": \"2\", \"2\": \"2\", \"3\": \"4\", \"4\": \"4\", \"5\": \"6\", \"6\": \"6\", \"7\": \"6\", \"8\": \"8\", \"9\": \"8\", \"10\": \"8\", \"11\": \"10\", \"12\": \"10\", \"13\": \"10\", \"14\": \"12\", \"15\": \"12\", \"16\": \"12\", \"17\": \"15\", \"18\": \"15\", \"19\": \"20\", \"20\": \"20\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(16,'community','C17','版块权限覆盖','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(17,'community','C2','评论免审','{\"1\": \"false\", \"2\": \"false\", \"3\": \"true\", \"4\": \"true\", \"5\": \"true\", \"6\": \"true\", \"7\": \"true\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(18,'community','C3','发帖频率(篇/日)','{\"1\": \"2\", \"2\": \"1\", \"3\": \"3\", \"4\": \"3\", \"5\": \"5\", \"6\": \"5\", \"7\": \"5\", \"8\": \"10\", \"9\": \"10\", \"10\": \"10\", \"11\": \"15\", \"12\": \"15\", \"13\": \"15\", \"14\": \"20\", \"15\": \"20\", \"16\": \"20\", \"17\": \"30\", \"18\": \"30\", \"19\": \"50\", \"20\": \"50\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(19,'community','C4','评论频率(条/日)','{\"1\": \"3\", \"2\": \"3\", \"3\": \"10\", \"4\": \"10\", \"5\": \"30\", \"6\": \"30\", \"7\": \"30\", \"8\": \"50\", \"9\": \"50\", \"10\": \"50\", \"11\": \"100\", \"12\": \"100\", \"13\": \"100\", \"14\": \"200\", \"15\": \"200\", \"16\": \"200\", \"17\": \"300\", \"18\": \"300\", \"19\": \"500\", \"20\": \"500\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(20,'community','C5','可发布付费内容','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(21,'community','C6','内容定价上限(元)','{\"5\": \"50\", \"6\": \"50\", \"7\": \"50\", \"8\": \"100\", \"9\": \"100\", \"10\": \"100\", \"11\": \"200\", \"12\": \"200\", \"13\": \"200\", \"14\": \"500\", \"15\": \"500\", \"16\": \"500\", \"17\": \"1000\", \"18\": \"1000\", \"19\": \"2000\", \"20\": \"2000\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(22,'community','C9','单帖图片数量','{\"1\": \"2\", \"2\": \"2\", \"3\": \"4\", \"4\": \"4\", \"5\": \"6\", \"6\": \"6\", \"7\": \"6\", \"8\": \"9\", \"9\": \"9\", \"10\": \"9\", \"11\": \"12\", \"12\": \"12\", \"13\": \"12\", \"14\": \"16\", \"15\": \"16\", \"16\": \"16\", \"17\": \"20\", \"18\": \"20\", \"19\": \"25\", \"20\": \"25\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(23,'function','H1','签到额外经验加成倍率','{\"1\": \"1\", \"2\": \"1\", \"3\": \"1\", \"4\": \"1\", \"5\": \"1.1\", \"6\": \"1.1\", \"7\": \"1.1\", \"8\": \"1.2\", \"9\": \"1.2\", \"10\": \"1.2\", \"11\": \"1.3\", \"12\": \"1.3\", \"13\": \"1.3\", \"14\": \"1.5\", \"15\": \"1.5\", \"16\": \"1.5\", \"17\": \"1.8\", \"18\": \"1.8\", \"19\": \"2\", \"20\": \"2\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(24,'function','H2','任务系统经验奖励倍率','{\"1\": \"1\", \"2\": \"1\", \"3\": \"1\", \"4\": \"1\", \"5\": \"1.1\", \"6\": \"1.1\", \"7\": \"1.1\", \"8\": \"1.2\", \"9\": \"1.2\", \"10\": \"1.2\", \"11\": \"1.3\", \"12\": \"1.3\", \"13\": \"1.3\", \"14\": \"1.5\", \"15\": \"1.5\", \"16\": \"1.5\", \"17\": \"1.8\", \"18\": \"1.8\", \"19\": \"2\", \"20\": \"2\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(25,'function','H3','数据导出','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"false\", \"12\": \"false\", \"13\": \"false\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(26,'invite','F2','邀请码生成数量','{\"8\": \"3\", \"9\": \"3\", \"10\": \"3\", \"11\": \"5\", \"12\": \"5\", \"13\": \"5\", \"14\": \"10\", \"15\": \"10\", \"16\": \"10\", \"17\": \"20\", \"18\": \"20\", \"19\": \"50\", \"20\": \"50\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(27,'mall','B1','开店权限','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(28,'mall','B2','上架商品数量上限','{\"5\": \"1\", \"6\": \"1\", \"7\": \"1\", \"8\": \"3\", \"9\": \"3\", \"10\": \"3\", \"11\": \"5\", \"12\": \"5\", \"13\": \"5\", \"14\": \"10\", \"15\": \"10\", \"16\": \"10\", \"17\": \"20\", \"18\": \"20\", \"19\": \"50\", \"20\": \"50\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(29,'mall','B3','商品免审核','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(30,'mall','B4','商品定价上限(元)','{\"5\": \"100\", \"6\": \"100\", \"7\": \"100\", \"8\": \"200\", \"9\": \"200\", \"10\": \"200\", \"11\": \"500\", \"12\": \"500\", \"13\": \"500\", \"14\": \"1000\", \"15\": \"1000\", \"16\": \"1000\", \"17\": \"5000\", \"18\": \"5000\", \"19\": \"10000\", \"20\": \"10000\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(31,'mall','B5','促销活动创建','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"false\", \"9\": \"false\", \"10\": \"false\", \"11\": \"false\", \"12\": \"false\", \"13\": \"false\", \"14\": \"false\", \"15\": \"false\", \"16\": \"false\", \"17\": \"false\", \"18\": \"false\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(32,'mall','B6','追加评价(次/订单)','{\"8\": \"1\", \"9\": \"1\", \"10\": \"1\", \"11\": \"2\", \"12\": \"2\", \"13\": \"2\", \"14\": \"3\", \"15\": \"3\", \"16\": \"3\", \"17\": \"5\", \"18\": \"5\", \"19\": \"10\", \"20\": \"10\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(33,'monetize','E1','提现权限','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(34,'monetize','E2','最低提现金额(元)','{\"8\": \"100\", \"9\": \"100\", \"10\": \"100\", \"11\": \"50\", \"12\": \"50\", \"13\": \"50\", \"14\": \"30\", \"15\": \"30\", \"16\": \"30\", \"17\": \"10\", \"18\": \"10\", \"19\": \"1\", \"20\": \"1\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(35,'social','D1','关注总上限','{\"1\": \"10\", \"2\": \"10\", \"3\": \"30\", \"4\": \"30\", \"5\": \"100\", \"6\": \"100\", \"7\": \"100\", \"8\": \"200\", \"9\": \"200\", \"10\": \"200\", \"11\": \"500\", \"12\": \"500\", \"13\": \"500\", \"14\": \"1000\", \"15\": \"1000\", \"16\": \"1000\", \"17\": \"2000\", \"18\": \"2000\", \"19\": \"5000\", \"20\": \"5000\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(36,'social','D10','创建聊天室','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"false\", \"6\": \"false\", \"7\": \"false\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(37,'social','D11','聊天室成员上限','{\"5\": \"30\", \"6\": \"30\", \"7\": \"30\", \"8\": \"50\", \"9\": \"50\", \"10\": \"50\", \"11\": \"100\", \"12\": \"100\", \"13\": \"100\", \"14\": \"200\", \"15\": \"200\", \"16\": \"200\", \"17\": \"500\", \"18\": \"500\", \"19\": \"1000\", \"20\": \"1000\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(38,'social','D12','聊天室文件上传(MB)','{\"3\": \"5\", \"4\": \"5\", \"5\": \"20\", \"6\": \"20\", \"7\": \"20\", \"8\": \"50\", \"9\": \"50\", \"10\": \"50\", \"11\": \"100\", \"12\": \"100\", \"13\": \"100\", \"14\": \"200\", \"15\": \"200\", \"16\": \"200\", \"17\": \"500\", \"18\": \"500\", \"19\": \"1000\", \"20\": \"1000\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(39,'social','D13','创建话题','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"true\", \"6\": \"true\", \"7\": \"true\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(40,'social','D2','每日关注上限','{\"1\": \"3\", \"2\": \"3\", \"3\": \"5\", \"4\": \"5\", \"5\": \"10\", \"6\": \"10\", \"7\": \"10\", \"8\": \"20\", \"9\": \"20\", \"10\": \"20\", \"11\": \"30\", \"12\": \"30\", \"13\": \"30\", \"14\": \"50\", \"15\": \"50\", \"16\": \"50\", \"17\": \"100\", \"18\": \"100\", \"19\": \"200\", \"20\": \"200\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(41,'social','D3','创建合集数量','{\"1\": \"0\", \"2\": \"0\", \"3\": \"1\", \"4\": \"1\", \"5\": \"3\", \"6\": \"3\", \"7\": \"3\", \"8\": \"5\", \"9\": \"5\", \"10\": \"5\", \"11\": \"10\", \"12\": \"10\", \"13\": \"10\", \"14\": \"20\", \"15\": \"20\", \"16\": \"20\", \"17\": \"50\", \"18\": \"50\", \"19\": \"100\", \"20\": \"100\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(42,'social','D4','私信权限','{\"1\": \"false\", \"2\": \"false\", \"3\": \"false\", \"4\": \"false\", \"5\": \"true\", \"6\": \"true\", \"7\": \"true\", \"8\": \"true\", \"9\": \"true\", \"10\": \"true\", \"11\": \"true\", \"12\": \"true\", \"13\": \"true\", \"14\": \"true\", \"15\": \"true\", \"16\": \"true\", \"17\": \"true\", \"18\": \"true\", \"19\": \"true\", \"20\": \"true\"}','2026-07-20 07:32:28','2026-07-20 07:55:01'),
(43,'social','D6','消息撤回时长(分钟)','{\"3\": \"1\", \"4\": \"1\", \"5\": \"2\", \"6\": \"2\", \"7\": \"2\", \"8\": \"5\", \"9\": \"5\", \"10\": \"5\", \"11\": \"10\", \"12\": \"10\", \"13\": \"10\", \"14\": \"30\", \"15\": \"30\", \"16\": \"30\", \"17\": \"60\", \"18\": \"60\", \"19\": \"120\", \"20\": \"120\", \"1\": \"\"}','2026-07-20 07:32:28','2026-07-20 07:55:01');
/*!40000 ALTER TABLE `experience_permission_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience_records`
--

DROP TABLE IF EXISTS `experience_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `source` varchar(100) DEFAULT '',
  `description` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `type` varchar(10) DEFAULT 'earn' COMMENT 'earn=获得 expense=扣除',
  `task_id` int(11) DEFAULT 0 COMMENT '关联惩罚规则ID',
  PRIMARY KEY (`id`),
  KEY `idx_experience_records_user_id` (`user_id`),
  KEY `idx_experience_records_user_time` (`user_id`,`create_time`),
  KEY `idx_experience_records_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience_records`
--

LOCK TABLES `experience_records` WRITE;
/*!40000 ALTER TABLE `experience_records` DISABLE KEYS */;
INSERT INTO `experience_records` VALUES
(1,7,'',70,'daily','经验值增加','2026-06-16 22:39:54','earn',0),
(2,12,'',14,'post','经验值增加','2026-07-03 22:39:54','earn',0),
(3,12,'',37,'comment','经验值增加','2026-07-06 22:39:54','earn',0),
(4,10,'',10,'checkin','经验值增加','2026-06-12 22:39:54','earn',0),
(5,3,'',100,'daily','经验值增加','2026-06-11 22:39:54','earn',0),
(6,9,'',107,'post','经验值增加','2026-06-16 22:39:54','earn',0),
(7,4,'',40,'comment','经验值增加','2026-07-05 22:39:54','earn',0),
(8,10,'',73,'checkin','经验值增加','2026-06-12 22:39:54','earn',0),
(9,7,'',94,'daily','经验值增加','2026-06-19 22:39:54','earn',0),
(10,8,'',19,'post','经验值增加','2026-07-02 22:39:54','earn',0),
(11,14,'',107,'comment','经验值增加','2026-06-18 22:39:54','earn',0),
(12,12,'',43,'checkin','经验值增加','2026-06-22 22:39:54','earn',0),
(13,2,'',74,'daily','经验值增加','2026-07-08 22:39:54','earn',0),
(14,4,'',87,'post','经验值增加','2026-07-08 22:39:54','earn',0),
(15,12,'',51,'comment','经验值增加','2026-06-30 22:39:54','earn',0),
(16,5,'',52,'checkin','经验值增加','2026-06-26 22:39:54','earn',0),
(17,6,'',97,'daily','经验值增加','2026-07-10 22:39:54','earn',0),
(18,4,'',96,'post','经验值增加','2026-06-15 22:39:54','earn',0),
(19,3,'',99,'comment','经验值增加','2026-07-07 22:39:54','earn',0),
(20,5,'',31,'checkin','经验值增加','2026-07-10 22:39:54','earn',0),
(21,19,'alexmorgan',2000,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得2000经验值','2026-07-11 08:41:23','earn',0),
(22,10001,'35735712',5000,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 额外获得5000经验值','2026-07-16 00:16:12','earn',0),
(23,5,'code_ninja',30,'管理员手动扣分','测试手动扣分','2026-07-20 16:52:11','expense',0),
(24,2,'lisa_chen',30,'帖子被驳回','帖子被驳回','2026-07-20 17:27:38','expense',6),
(25,2,'lisa_chen',50,'帖子被删除','帖子被删除','2026-07-20 17:27:38','expense',7),
(26,2,'lisa_chen',30,'帖子被锁定','帖子被锁定','2026-07-20 17:27:38','expense',11),
(27,2,'lisa_chen',20,'评论被删除','评论被删除','2026-07-20 17:27:38','expense',12),
(28,2,'lisa_chen',20,'敏感词违规','敏感词违规','2026-07-20 17:27:38','expense',13),
(29,2,'lisa_chen',40,'举报核实违规','举报核实违规','2026-07-20 17:27:38','expense',9),
(30,2,'lisa_chen',40,'滥用举报','滥用举报','2026-07-20 17:27:38','expense',14),
(31,2,'lisa_chen',50,'申诉驳回','申诉驳回','2026-07-20 17:27:38','expense',15),
(32,2,'lisa_chen',500,'管理员封禁','管理员封禁','2026-07-20 17:27:38','expense',8),
(33,2,'lisa_chen',100,'自动封禁','自动封禁','2026-07-20 17:27:38','expense',16),
(34,2,'lisa_chen',20,'聊天室踢出','聊天室踢出','2026-07-20 17:27:38','expense',10),
(35,2,'lisa_chen',20,'聊天室禁言','聊天室禁言','2026-07-20 17:27:38','expense',17),
(36,2,'lisa_chen',30,'私信骚扰','私信骚扰','2026-07-20 17:27:39','expense',18),
(37,2,'lisa_chen',20,'头像昵称违规','头像昵称违规','2026-07-20 17:27:39','expense',19),
(38,2,'lisa_chen',30,'恶意差评','恶意差评','2026-07-20 17:27:39','expense',20),
(39,2,'lisa_chen',50,'虚假商品','虚假商品','2026-07-20 17:27:39','expense',21),
(40,2,'lisa_chen',40,'恶意退款','恶意退款','2026-07-20 17:27:39','expense',22),
(41,2,'lisa_chen',30,'应用驳回','应用驳回','2026-07-20 17:27:39','expense',23),
(42,2,'lisa_chen',50,'应用下架','应用下架','2026-07-20 17:27:39','expense',24),
(43,2,'lisa_chen',60,'应用删除','应用删除','2026-07-20 17:27:39','expense',25),
(44,2,'lisa_chen',30,'投票作弊','投票作弊','2026-07-20 17:27:39','expense',26),
(45,2,'lisa_chen',40,'活动作弊','活动作弊','2026-07-20 17:27:39','expense',27),
(46,2,'lisa_chen',75,'帖子被删除','帖子被删除（第2次，x1.5加成）','2026-07-20 17:36:18','expense',7),
(47,2,'lisa_chen',100,'帖子被删除','帖子被删除（第3次，x2.0加成）','2026-07-20 17:42:00','expense',7),
(48,2,'',200,'附加惩罚','累计违规 3 次触发附加扣除经验','2026-07-20 17:42:00','expense',7),
(49,2,'lisa_chen',125,'帖子被删除','帖子被删除（第4次，x2.5加成）','2026-07-20 17:42:17','expense',7),
(50,2,'',200,'附加惩罚','累计违规 4 次触发附加扣除经验','2026-07-20 17:42:17','expense',7),
(51,2,'lisa_chen',50,'帖子被删除','帖子被删除（第5次，x3.0加成）','2026-07-20 17:48:36','expense',7),
(52,2,'',200,'附加惩罚','累计违规 5 次触发附加扣除经验','2026-07-20 17:48:36','expense',7),
(53,2,'',45,'帖子被驳回','帖子被驳回（第2次，x1.5加成）','2026-07-21 00:13:38','expense',6),
(54,2,'',60,'帖子被驳回','帖子被驳回（第3次，x2.0加成）','2026-07-21 00:14:02','expense',6);
/*!40000 ALTER TABLE `experience_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_group_follows`
--

DROP TABLE IF EXISTS `favorite_group_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_group_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_follower` (`group_id`,`follower_id`),
  KEY `idx_group` (`group_id`),
  KEY `idx_follower` (`follower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_group_follows`
--

LOCK TABLES `favorite_group_follows` WRITE;
/*!40000 ALTER TABLE `favorite_group_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_group_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_policies`
--

DROP TABLE IF EXISTS `file_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `user_level_id` int(11) DEFAULT 0,
  `user_level_name` varchar(100) DEFAULT '',
  `role_code` varchar(100) DEFAULT '',
  `user_id` int(11) DEFAULT 0,
  `max_file_size_mb` int(11) DEFAULT 10,
  `allowed_types` text DEFAULT '',
  `banned_types` text DEFAULT '',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `image_compress_enabled` tinyint(1) DEFAULT 0,
  `image_max_width` int(11) DEFAULT 1200,
  `image_max_height` int(11) DEFAULT 0,
  `image_quality` decimal(3,1) DEFAULT 0.8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_policies`
--

LOCK TABLES `file_policies` WRITE;
/*!40000 ALTER TABLE `file_policies` DISABLE KEYS */;
INSERT INTO `file_policies` VALUES
(1,'默认策略',0,'','',0,10,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-10 22:39:54',1,1200,0,0.8),
(2,'图片策略',0,'','',0,5,'jpg,png,gif,webp','','1','2026-07-10 22:39:54',0,1200,0,0.8),
(3,'会员用户其他',0,'','*',0,35,'jpg,png,gif,pdf,zip,apk,APK','','1','2026-07-12 00:50:07',0,1200,0,0.8);
/*!40000 ALTER TABLE `file_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_repository`
--

DROP TABLE IF EXISTS `file_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_repository` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT '',
  `file_name` varchar(500) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `file_type` varchar(100) DEFAULT '',
  `mime_type` varchar(200) DEFAULT '',
  `category` varchar(50) DEFAULT 'other',
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  `description` varchar(500) DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_file_repository_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_repository`
--

LOCK TABLES `file_repository` WRITE;
/*!40000 ALTER TABLE `file_repository` DISABLE KEYS */;
INSERT INTO `file_repository` VALUES
(1,9,'','avatar1.png','uploads/avatar1.png',102400,'avatar','image/png','other',0,'',NULL,'2026-07-10 22:39:53'),
(2,6,'','design.psd','uploads/design.psd',2048000,'design','application/psd','other',0,'',NULL,'2026-07-10 22:39:53'),
(3,13,'','report.pdf','uploads/report.pdf',512000,'document','application/pdf','other',0,'',NULL,'2026-07-10 22:39:53'),
(4,12,'','video.mp4','uploads/video.mp4',10485760,'video','video/mp4','other',0,'',NULL,'2026-07-10 22:39:53'),
(5,9,'','config.json','uploads/config.json',2048,'data','application/json','other',0,'',NULL,'2026-07-10 22:39:53'),
(6,3,'','image1.jpg','uploads/image1.jpg',307200,'image','image/jpeg','other',0,'',NULL,'2026-07-10 22:39:53'),
(7,13,'','icon.svg','uploads/icon.svg',8192,'icon','image/svg+xml','other',0,'',NULL,'2026-07-10 22:39:53'),
(11,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816158227-389590747.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:30:00'),
(12,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816251341-825401419.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:31:33'),
(13,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816652499-733720586.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:37:33'),
(14,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816659877-185207292.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:37:40'),
(15,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816771159-579246254.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:32'),
(16,0,'','MTç®¡çå¨_2.26.6.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816711324-481531705.apk',31414066,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:37'),
(17,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816784424-968471270.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:39:45'),
(18,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816799301-792055094.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:40:41'),
(19,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816970054-799912081.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:42:51'),
(20,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816976685-749847013.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:42:57'),
(21,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783816985168-866030178.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:43:06'),
(22,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817033491-439544914.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:44:35'),
(23,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817269817-937137091.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:32'),
(24,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817314376-129449829.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:35'),
(25,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817319693-373748131.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:40'),
(26,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817326869-670938906.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:48:48'),
(28,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817455681-789179466.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:51:38'),
(29,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817623730-286001040.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:53:45'),
(30,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817660872-274220246.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:55:03'),
(31,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783817740986-155422684.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 00:56:23'),
(32,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818420129-251029883.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:07:01'),
(34,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818537796-569073154.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:08:59'),
(35,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818543195-841509947.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:09:04'),
(36,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818558713-835884504.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:09:20'),
(37,0,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818705199-567193380.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:11:46'),
(39,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783818935431-807162032.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:16:18'),
(42,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820609464-226654906.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:43:30'),
(43,0,'','å¾å½¢å¢å¼ºæå¡_16.1.24.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783820663960-40996847.apk',8632,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:44:24'),
(44,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821050883-644610594.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:51:33'),
(45,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821067093-396406745.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:51:49'),
(46,0,'','ç¾åå¼æ_13.7.07.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/user/apk-1783821246989-906727894.apk',20441606,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-12 01:54:49'),
(49,1,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/zip/1783825047961-519417035.zip',4096,'.zip','application/octet-stream','general',0,'',NULL,'2026-07-12 02:57:28'),
(51,2,'','test_data.zip','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/2/zip/1783825048216-30936901.zip',4096,'.zip','application/octet-stream','general',0,'',NULL,'2026-07-12 02:57:28'),
(52,1,'','test_pic.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825238553-78505961.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:00:38'),
(53,1,'','a.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/img/1783825451126-852761551.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:04:11'),
(54,1,'','u.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/1/img/1783825518358-740133764.png',2048,'.png','image/png','general',0,'',NULL,'2026-07-12 03:05:18'),
(57,0,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826122044-556763102.jpg',168623,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:22'),
(58,0,'','4502.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123131-672728729.jpg',536774,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:23'),
(59,0,'','4498.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826123510-169510965.jpg',112423,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:23'),
(60,0,'','4500.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826124195-863883180.jpg',1008134,'.jpg','image/jpeg','avatar',0,'',NULL,'2026-07-12 03:15:25'),
(61,0,'','u2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/1783826182866-214372467.png',2048,'.png','image/png','avatar',0,'',NULL,'2026-07-12 03:16:23'),
(66,19,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783858197612_3872.jpg',168623,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:09:58'),
(67,19,'','4498.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783858258905_8390.jpg',112423,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:10:59'),
(68,19,'','4503.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783859261750_1377.jpg',168623,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:27:42'),
(69,19,'','4497.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/chat_1783860297159_7139.jpg',394290,'jpg','image/jpeg','chat_image',0,'','聊天图片','2026-07-12 12:44:57'),
(90,19,'','exp_icon_1783971471182.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971471182.png',1860,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:37:51'),
(91,19,'','exp_icon_1783971498625.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971498625.png',2099,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:18'),
(92,19,'','exp_icon_1783971508679.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971508679.png',2104,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:28'),
(93,19,'','exp_icon_1783971532684.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971532684.png',2178,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:38:52'),
(94,19,'','exp_icon_1783971558823.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971558823.png',2098,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:19'),
(95,19,'','exp_icon_1783971588947.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971588947.png',2086,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:49'),
(96,19,'','exp_icon_1783971599337.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971599337.png',2040,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:39:59'),
(97,19,'','exp_icon_1783971609738.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971609738.png',1998,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:40:09'),
(98,19,'','exp_icon_1783971622186.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783971622186.png',2078,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 19:40:22'),
(102,19,'','mb_icon_1783978168089.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1783978168089.gif',1584108,'gif','image/gif','membership_icon',0,'membership','membership_icon','2026-07-13 21:29:28'),
(103,19,'','aw_1783978337263.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg',166541,'jpg','image/jpeg','avatar',19,'user','用户#19的用户头像','2026-07-13 21:32:17'),
(104,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783979565742-697628372.png',489216,'png','image/png','general',0,'','通用文件','2026-07-13 21:52:46'),
(105,19,'','4539.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783980997613-49864119.png',532360,'png','image/png','general',0,'','通用文件','2026-07-13 22:16:38'),
(106,19,'','4539.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783981009908-814127258.png',532360,'png','image/png','general',0,'','通用文件','2026-07-13 22:16:50'),
(107,19,'','exp_icon_1783981510656.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783981510656.png',1610,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:25:10'),
(108,19,'','exp_icon_1783982350949.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982350949.png',19043,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:39:11'),
(109,19,'','exp_icon_1783982360639.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982360639.png',20997,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:39:20'),
(110,19,'','exp_icon_1783982426213.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982426213.png',20990,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:26'),
(111,19,'','exp_icon_1783982437138.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982437138.png',19351,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:37'),
(112,19,'','exp_icon_1783982444873.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982444873.png',19555,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:44'),
(113,19,'','exp_icon_1783982453777.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982453777.png',19701,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:40:53'),
(114,19,'','exp_icon_1783982462674.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982462674.png',19652,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:02'),
(115,19,'','exp_icon_1783982470785.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982470785.png',22759,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:10'),
(116,19,'','exp_icon_1783982478996.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982478996.png',22559,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:19'),
(117,19,'','exp_icon_1783982490516.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982490516.png',22042,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:30'),
(118,19,'','exp_icon_1783982513242.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982513242.png',23850,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:41:53'),
(119,19,'','exp_icon_1783982529934.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982529934.png',23222,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:10'),
(120,19,'','exp_icon_1783982541798.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982541798.png',24614,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:21'),
(121,19,'','exp_icon_1783982552450.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982552450.png',24721,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:32'),
(122,19,'','exp_icon_1783982561799.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982561799.png',24211,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:41'),
(123,19,'','exp_icon_1783982572800.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982572800.png',24949,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:42:52'),
(124,19,'','exp_icon_1783982585818.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982585818.png',25533,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:05'),
(125,19,'','exp_icon_1783982597739.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982597739.png',25493,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:17'),
(126,19,'','exp_icon_1783982608548.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982608548.png',27454,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:28'),
(127,19,'','exp_icon_1783982626576.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/experience_icon/exp_icon_1783982626576.png',25053,'png','image/png','experience_icon',0,'experience','experience_icon','2026-07-13 22:43:46'),
(128,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783984434038-674480173.png',489216,'png','image/png','general',0,'','通用文件','2026-07-13 23:13:54'),
(129,19,'','4564.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783985386117-824716520.png',400574,'png','image/png','general',0,'','通用文件','2026-07-13 23:29:46'),
(130,19,'','4564.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783985399134-484017465.png',400574,'png','image/png','general',0,'','通用文件','2026-07-13 23:29:59'),
(131,19,'','4565.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987059150-560229395.png',1088831,'png','image/png','general',0,'','通用文件','2026-07-13 23:57:41'),
(132,19,'','4567.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987132246-181511316.png',1088831,'png','image/png','general',0,'','通用文件','2026-07-13 23:58:53'),
(133,19,'','4569.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987284290-565362119.png',519518,'png','image/png','general',0,'','通用文件','2026-07-14 00:01:24'),
(134,19,'','4569.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987337398-396129353.png',519518,'png','image/png','general',0,'','通用文件','2026-07-14 00:02:17'),
(135,19,'','4570.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1783987369006-697144065.png',457796,'png','image/png','general',0,'','通用文件','2026-07-14 00:02:49'),
(136,0,'','test-img.png','/uploads/community_1784024726849_ske8kx.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:25:27'),
(137,0,'','test-img2.png','/uploads/community_1784025089956_zkomd1.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:31:30'),
(138,0,'','test-img3.png','/uploads/community_1784025131095_q5whgp.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:32:11'),
(139,0,'','test-img4.png','/uploads/community_1784025268395_9frmn0.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:34:28'),
(140,0,'','test-img5.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025301063_kg5n85.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:35:01'),
(141,19,'','test-alex.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784025358286_ratwk9.png',2048,'png','image/png','community_image',0,'','community_image','2026-07-14 10:35:58'),
(142,0,'','test-del.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025595176_v9sryq.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:39:55'),
(143,0,'','test-del2.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025619899_6i9nhv.png',1024,'png','image/png','community_image',0,'','community_image','2026-07-14 10:40:20'),
(144,0,'','test-quota.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784025959936_tthkw0.png',5120,'png','image/png','community_image',0,'','community_image','2026-07-14 10:46:00'),
(146,0,'','migrate_16_1784026548678_mld4.jpeg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784026550127_as2zmr.jpeg',795023,'jpeg','image/jpeg','community_image',0,'','community_image','2026-07-14 10:55:50'),
(147,0,'','migrate_16_1784026550450_28pm.jpeg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784026550470_q9nikx.jpeg',677674,'jpeg','image/jpeg','community_image',0,'','community_image','2026-07-14 10:55:50'),
(149,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784031764362_w7b1xn.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 12:22:45'),
(150,19,'','4522.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784031772804_48egzb.jpg',677674,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 12:22:53'),
(151,19,'','4190.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/frame-1784063200439-382993529.gif',942747,'gif','image/gif','avatar_frame',0,'','头像框图片','2026-07-14 21:06:42'),
(152,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784070665897_pvqsjf.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 23:11:07'),
(153,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784070676176_iezhy3.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-14 23:11:16'),
(154,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076703399_djixc1.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:51:44'),
(155,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076711453_zm3whr.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:51:51'),
(156,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784076984621_vm5uze.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:56:25'),
(157,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077097095_p240s2.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:17'),
(158,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077131092_b8uc6x.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:51'),
(159,0,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077132069_jg82mp.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:58:52'),
(160,0,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077186617_m2j829.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:59:47'),
(161,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077188028_ls5yjo.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 00:59:48'),
(162,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077223022_g2qynx.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 01:00:23'),
(163,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784077259732_4cvboz.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 01:01:00'),
(164,0,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784086099787_qlcjmt.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 03:28:24'),
(165,0,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784086186333_8p850z.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 03:29:46'),
(166,19,'','4541.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784097351442_kssori.jpg',40178,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 06:35:51'),
(167,19,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784097744372_ojsxzj.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 06:42:29'),
(168,0,'','4542.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784098071767_ufnouc.png',2701312,'png','image/png','community_image',0,'','community_image','2026-07-15 06:47:56'),
(169,19,'','4501.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784098128256_hvv3gt.png',2342912,'png','image/png','community_image',0,'','community_image','2026-07-15 06:48:52'),
(170,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111253765_jce1r2.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:34'),
(171,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111255056_20o4up.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:35'),
(172,19,'','4511.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784111255931_3tl31a.jpg',166541,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:27:36'),
(173,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784112470446_3i37oc.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:47:51'),
(174,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784112500785_u85ie0.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:48:21'),
(175,19,'','4541.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113044692_qw3se8.jpg',40178,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:24'),
(176,19,'','4530.gif','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113058114_902pxy.gif',1584108,'gif','image/gif','community_image',0,'','community_image','2026-07-15 10:57:40'),
(177,19,'','4502.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113061397_y68d2p.jpg',536774,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:41'),
(178,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784113071582_cgnhsi.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 10:57:51'),
(179,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114251731_ebb403.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:32'),
(180,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114260961_nil3ss.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:41'),
(181,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114262066_dd5886.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:17:42'),
(182,19,'','4566.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114292133_hvrs4h.png',488392,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:12'),
(183,19,'','4567.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114293498_do8udo.png',1088831,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:14'),
(184,19,'','4568.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114296300_c32nth.png',1759232,'png','image/png','community_image',0,'','community_image','2026-07-15 11:18:18'),
(185,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114298469_l9bat4.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:19'),
(186,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114299493_gwjc28.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:19'),
(187,19,'','4510.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114311026_aa75uy.jpg',145172,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:31'),
(188,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114325363_6e1e9y.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:45'),
(189,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114326424_9d12oc.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:18:46'),
(190,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114346637_q3czno.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:19:07'),
(191,0,'','favicon.ico','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/community_1784114377190_9uqjod.ico',4286,'ico','application/octet-stream','community_image',0,'','community_image','2026-07-15 11:19:37'),
(192,19,'','4534.png','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114704166_vgx4uh.png',489216,'png','image/png','community_image',0,'','community_image','2026-07-15 11:25:04'),
(193,19,'','4606.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784114711414_skogwy.jpg',361639,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:25:11'),
(194,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784115427495_t7n1zf.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:37:08'),
(195,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784115428991_wkn3gl.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:37:09'),
(196,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116261658_8ksfkz.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:51:02'),
(197,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116263039_we3v6h.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:51:03'),
(198,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116619006_30qob8.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:56:59'),
(199,19,'','4631.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116628325_ktxh9v.jpg',461362,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:57:08'),
(200,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784116628981_c17j00.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 11:57:09'),
(201,19,'','4632.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784117092234_otmvjg.jpg',624912,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 12:04:52'),
(202,19,'','4572.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/community_1784117093715_b2ss9r.jpg',795023,'jpg','image/jpeg','community_image',0,'','community_image','2026-07-15 12:04:54'),
(203,19,'','reply_image.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1784131092996-429930264.jpg',624912,'jpg','image/jpeg','general',0,'','通用文件','2026-07-15 15:58:13'),
(204,19,'','reply_image.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/img/1784131096207-908380383.jpg',624912,'jpg','image/jpeg','general',0,'','通用文件','2026-07-15 15:58:16'),
(205,19,'','icon-1784459379521-284748443.png','/uploads/icon-1784459379521-284748443.png',9159,'png','image/png','apk_icon',0,'','','2026-07-19 11:09:39'),
(207,19,'','icon-1784462813909-354136982.png','/uploads/icon-1784462813909-354136982.png',9159,'png','image/png','apk_icon',0,'','','2026-07-19 12:06:53'),
(208,19,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/apk/apk-1784462812954-251622320.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-19 12:06:54'),
(209,19,'','mb_icon_1784462835968.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462835968.jpg',929673,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:07:16'),
(210,19,'','mb_icon_1784462837341.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462837341.jpg',675153,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:07:17'),
(211,19,'','mb_icon_1784462844065.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462844065.jpg',929673,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:07:24'),
(212,19,'','mb_icon_1784462845270.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462845270.jpg',675153,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:07:25'),
(213,19,'','icon-1784462912249-380199123.png','/uploads/icon-1784462912249-380199123.png',9159,'png','image/png','apk_icon',0,'','','2026-07-19 12:08:32'),
(214,19,'','Native Test ++_Mean Minotaur.apk','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/apk/apk-1784462911326-204029218.apk',1017527,'.apk','application/vnd.android.package-archive','apk',0,'',NULL,'2026-07-19 12:08:32'),
(215,19,'','mb_icon_1784462929151.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462929151.jpg',304359,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:08:49'),
(216,19,'','mb_icon_1784462929855.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1784462929855.jpg',181639,'jpg','image/jpeg','membership_icon',0,'membership','membership_icon','2026-07-19 12:08:49');
/*!40000 ALTER TABLE `file_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_configs`
--

DROP TABLE IF EXISTS `game_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_type` varchar(30) NOT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`config_data`)),
  `enabled` tinyint(4) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_type` (`game_type`),
  KEY `idx_game_configs_type` (`game_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_configs`
--

LOCK TABLES `game_configs` WRITE;
/*!40000 ALTER TABLE `game_configs` DISABLE KEYS */;
INSERT INTO `game_configs` VALUES
(1,'card_guess','{\"costPerFlip\":10,\"pityCount\":10,\"winMultiplier\":2,\"cards\":[{\"name\":\"A\",\"label\":\"奖\",\"isWin\":true,\"probability\":30},{\"name\":\"B\",\"label\":\"空\",\"isWin\":false,\"probability\":35},{\"name\":\"C\",\"label\":\"空\",\"isWin\":false,\"probability\":35}],\"memberDiscounts\":[]}',1,'2026-07-11 09:42:54','2026-07-11 11:23:53'),
(2,'dice','{\"costPerBet\":10,\"maxNumber\":6,\"threshold\":4,\"winMultiplier\":2,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:31','2026-07-11 11:23:53'),
(3,'rps','{\"costPerPlay\":10,\"winMultiplier\":2,\"drawRefund\":true,\"memberDiscounts\":[]}',1,'2026-07-11 09:43:43','2026-07-11 11:23:54'),
(4,'lottery','{\"costPerDraw\":10,\"costPerDraw10\":100,\"pityCount\":0,\"pityGridIndex\":0,\"grids\":[{\"index\":0,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":1,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":2,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":3,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":4,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":5,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":6,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":7,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11},{\"index\":8,\"name\":\"\",\"type\":\"points\",\"value\":10,\"probability\":11}],\"memberDiscounts\":[]}',1,'2026-07-11 09:45:49','2026-07-11 11:23:53'),
(5,'slot','{\"grids\":[]}',1,'2026-07-21 16:48:18','2026-07-21 16:48:18');
/*!40000 ALTER TABLE `game_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_records`
--

DROP TABLE IF EXISTS `game_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `game_type` varchar(30) NOT NULL,
  `result` varchar(20) NOT NULL,
  `points_spent` int(11) DEFAULT 0,
  `points_won` int(11) DEFAULT 0,
  `detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detail`)),
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_game_records_user` (`user_id`),
  KEY `idx_game_records_type` (`game_type`),
  KEY `idx_game_records_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_records`
--

LOCK TABLES `game_records` WRITE;
/*!40000 ALTER TABLE `game_records` DISABLE KEYS */;
INSERT INTO `game_records` VALUES
(1,1,'card_guess','lose',10,0,'{\"chosenIndex\":0,\"cardName\":\"C\",\"cardLabel\":\"空\",\"isWin\":false}','2026-07-21 17:10:51');
/*!40000 ALTER TABLE `game_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_conversations`
--

DROP TABLE IF EXISTS `hidden_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hidden_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`partner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_conversations`
--

LOCK TABLES `hidden_conversations` WRITE;
/*!40000 ALTER TABLE `hidden_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite_codes`
--

DROP TABLE IF EXISTS `invite_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invite_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `used_by` int(11) DEFAULT 0,
  `used_by_name` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 1,
  `use_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT 'one_time',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` int(11) DEFAULT 0,
  `reward_duration` int(11) DEFAULT 0,
  `reward_duration_unit` varchar(10) DEFAULT 'day',
  `reward_target_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_invite_codes_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite_codes`
--

LOCK TABLES `invite_codes` WRITE;
/*!40000 ALTER TABLE `invite_codes` DISABLE KEYS */;
INSERT INTO `invite_codes` VALUES
(1,'INV-3MYOYW',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(2,'INV-TKFVLJ',1,'',0,'',10,0,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(3,'INV-DZQ79K',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(4,'INV-UAZKH9',1,'',0,'',10,1,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(5,'INV-P3V7UN',1,'',0,'',10,2,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(6,'INV-5LP1N0',1,'',0,'',10,4,'1',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(7,'INV-NL5F3Y',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(8,'INV-GL49GY',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(9,'INV-XBL1IK',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0),
(10,'INV-HZYLX9',1,'',0,'',10,10,'0',NULL,NULL,'2026-07-10 22:39:54',0,'admin','',0,0,'day',0);
/*!40000 ALTER TABLE `invite_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level_matrix`
--

DROP TABLE IF EXISTS `level_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `level_matrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_type` varchar(20) NOT NULL,
  `levels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '[verdict_lv0, verdict_lv1, verdict_lv2, verdict_lv3, verdict_lv4]' CHECK (json_valid(`levels`)),
  `night_level_penalty` int(11) NOT NULL DEFAULT 1 COMMENT '夜间降级数',
  `night_start_hour` int(11) NOT NULL DEFAULT 0,
  `night_end_hour` int(11) NOT NULL DEFAULT 8,
  `review_word_verdict` varchar(20) NOT NULL DEFAULT 'pending' COMMENT '命中review级敏感词时的裁定',
  PRIMARY KEY (`id`),
  UNIQUE KEY `target_type` (`target_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level_matrix`
--

LOCK TABLES `level_matrix` WRITE;
/*!40000 ALTER TABLE `level_matrix` DISABLE KEYS */;
INSERT INTO `level_matrix` VALUES
(1,'post','[\"pending\",\"pending\",\"published\",\"published\",\"published\"]',1,0,8,'pending'),
(2,'comment','[\"pending\",\"published\",\"published\",\"published\",\"published\"]',1,0,8,'pending'),
(3,'edit','[\"pending\",\"pending\",\"published\",\"published\",\"published\"]',1,0,8,'pending'),
(4,'app','[\"pending\",\"pending\",\"pending\",\"pending\",\"published\"]',1,0,8,'pending'),
(5,'product','[\"draft\",\"draft\",\"pending_review\",\"published\",\"published\"]',1,0,8,'pending');
/*!40000 ALTER TABLE `level_matrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ip` varchar(50) DEFAULT '',
  `user_agent` text DEFAULT '',
  `device_type` varchar(20) DEFAULT '',
  `os` varchar(50) DEFAULT '',
  `browser` varchar(50) DEFAULT '',
  `ip_country` varchar(100) DEFAULT '',
  `ip_province` varchar(100) DEFAULT '',
  `ip_city` varchar(100) DEFAULT '',
  `ip_isp` varchar(100) DEFAULT '',
  `is_new_device` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_login_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
INSERT INTO `login_history` VALUES
(1,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-18 03:48:36'),
(2,19,'223.160.209.103','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','浙江','嘉兴','China Mobile Communications Corporation',1,'2026-07-18 03:49:31'),
(3,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-18 03:51:53'),
(4,19,'223.160.213.162','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-18 09:56:54'),
(5,19,'223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-19 03:48:40'),
(6,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-19 04:02:49'),
(7,19,'223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-19 06:13:55'),
(8,19,'223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-19 06:14:20'),
(9,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 14:00:21'),
(10,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:05:01'),
(11,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:05:30'),
(12,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:06:23'),
(13,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:06:37'),
(14,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:06:46'),
(15,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:12:59'),
(16,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:12:59'),
(17,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:13:12'),
(18,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:13:31'),
(19,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:13:36'),
(20,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:14:23'),
(21,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:14:23'),
(22,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:14:57'),
(23,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:14:57'),
(24,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:25:44'),
(25,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:26:18'),
(26,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:26:31'),
(27,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:27:05'),
(28,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:27:21'),
(29,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:27:26'),
(30,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:27:36'),
(31,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-19 15:28:35'),
(32,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 03:29:43'),
(33,19,'112.17.241.171','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','浙江','Xiasha','China Mobile communications corporation',1,'2026-07-20 04:17:22'),
(34,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 05:44:01'),
(35,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 05:44:11'),
(36,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 05:44:21'),
(37,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 06:11:58'),
(38,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 06:19:55'),
(39,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:14:29'),
(40,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:15:02'),
(41,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:15:16'),
(42,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:22:42'),
(43,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:22:56'),
(44,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:23:52'),
(45,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:23:52'),
(46,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:24:15'),
(47,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:24:22'),
(48,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:24:37'),
(49,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:24:50'),
(50,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 07:36:20'),
(51,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 08:09:54'),
(52,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 08:09:54'),
(53,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 08:11:04'),
(54,19,'223.160.209.100','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124','PC','','','中国','浙江','嘉兴','China Mobile Communications Corporation',0,'2026-07-20 15:53:59'),
(55,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 20:36:58'),
(56,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-20 20:39:31'),
(57,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 20:46:04'),
(58,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 20:47:49'),
(59,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 20:47:49'),
(60,10020,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-20 20:48:18'),
(61,10020,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 21:24:58'),
(62,10020,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-20 21:25:02'),
(63,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:09:02'),
(64,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:09:06'),
(65,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:09:25'),
(66,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:09:33'),
(67,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:09:59'),
(68,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:10:38'),
(69,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:10:44'),
(70,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:10:50'),
(71,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:11:37'),
(72,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:02'),
(73,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:02'),
(74,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:08'),
(75,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:19'),
(76,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:43'),
(77,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:12:43'),
(78,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:13:11'),
(79,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:13:11'),
(80,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:13:38'),
(81,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:13:38'),
(82,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:02'),
(83,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:02'),
(84,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:19'),
(85,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:19'),
(86,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:32'),
(87,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:46'),
(88,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:14:46'),
(89,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:15:02'),
(90,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:15:02'),
(91,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:22:23'),
(92,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:22:23'),
(93,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:22:39'),
(94,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:25:29'),
(95,3,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:25:29'),
(96,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:25:53'),
(97,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:26:02'),
(98,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:27:03'),
(99,19,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:29:06'),
(100,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:36:47'),
(101,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:37:13'),
(102,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:37:23'),
(103,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:37:24'),
(104,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:38:43'),
(105,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:39:42'),
(106,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:42:02'),
(107,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:42:12'),
(108,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:42:23'),
(109,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:42:24'),
(110,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:44:04'),
(111,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:44:04'),
(112,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 00:44:30'),
(113,19,'117.136.111.25','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','Hezhuang','China Mobile communications corporation',1,'2026-07-21 02:09:24'),
(114,19,'223.160.212.130','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','古城','China Mobile Communications Corporation',0,'2026-07-21 02:40:42'),
(115,19,'223.160.212.130','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','古城','China Mobile Communications Corporation',0,'2026-07-21 03:17:41'),
(116,19,'39.144.124.46','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','Hezhuang','China Mobile Communications Corporation',1,'2026-07-21 05:15:00'),
(117,19,'39.144.124.46','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','Hezhuang','China Mobile Communications Corporation',0,'2026-07-21 05:21:35'),
(118,19,'223.160.215.32','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-21 05:26:26'),
(119,19,'223.160.215.32','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','北京市','西城区','China Mobile Communications Corporation',0,'2026-07-21 05:26:41'),
(120,19,'223.160.209.213','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36','Mobile','Android 16','Chrome 138.0.7204.179','中国','浙江','嘉兴','China Mobile Communications Corporation',0,'2026-07-21 06:50:23'),
(121,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-21 06:56:21'),
(122,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 06:56:29'),
(123,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 06:56:36'),
(124,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 06:58:22'),
(125,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 06:59:53'),
(126,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 06:59:59'),
(127,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:02:08'),
(128,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:06:18'),
(129,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:06:25'),
(130,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:08:15'),
(131,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:10:20'),
(132,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:13:51'),
(133,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:15:44'),
(134,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:16:32'),
(135,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 07:19:38'),
(136,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:13:28'),
(137,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:14:44'),
(138,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:17:43'),
(139,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:17:47'),
(140,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:18:51'),
(141,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:20:38'),
(142,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:23:22'),
(143,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',1,'2026-07-21 15:24:06'),
(144,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:25:35'),
(145,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:25:35'),
(146,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:25:41'),
(147,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:27:51'),
(148,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:27:51'),
(149,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:27:56'),
(150,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:28:58'),
(151,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:31:48'),
(152,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:31:55'),
(153,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:32:05'),
(154,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:35:04'),
(155,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:35:04'),
(156,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:35:09'),
(157,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:37:31'),
(158,10004,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:37:31'),
(159,10002,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:37:31'),
(160,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:44:14'),
(161,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:44:22'),
(162,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:47:44'),
(163,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:47:44'),
(164,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:48:50'),
(165,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:48:50'),
(166,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:50:16'),
(167,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:50:16'),
(168,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:52:55'),
(169,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 15:52:55'),
(170,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:01:07'),
(171,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:01:07'),
(172,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:05:29'),
(173,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:05:29'),
(174,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:05:39'),
(175,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:05:39'),
(176,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:06:58'),
(177,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:06:58'),
(178,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:15:35'),
(179,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:15:44'),
(180,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:25:16'),
(181,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:31:25'),
(182,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:31:25'),
(183,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:32:57'),
(184,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:32:57'),
(185,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:34:45'),
(186,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:34:45'),
(187,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:39:49'),
(188,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:39:54'),
(189,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:40:14'),
(190,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:40:21'),
(191,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:40:26'),
(192,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:40:31'),
(193,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:47:29'),
(194,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:48:11'),
(195,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:48:18'),
(196,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:48:18'),
(197,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:50:22'),
(198,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 16:50:22'),
(199,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:01:44'),
(200,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:05:43'),
(201,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:10:01'),
(202,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:10:12'),
(203,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:10:51'),
(204,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:15:32'),
(205,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:15:53'),
(206,2,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:15:53'),
(207,1,'::ffff:127.0.0.1','curl/7.88.1','PC','','','','','','',0,'2026-07-21 17:25:47');
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logistics_config`
--

DROP TABLE IF EXISTS `logistics_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logistics_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) NOT NULL DEFAULT 'kdniao',
  `e_business_id` varchar(100) NOT NULL DEFAULT '',
  `api_key_encrypted` varchar(500) NOT NULL DEFAULT '',
  `customer_id` varchar(100) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `callback_url` varchar(500) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logistics_config_provider` (`provider`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logistics_config`
--

LOCK TABLES `logistics_config` WRITE;
/*!40000 ALTER TABLE `logistics_config` DISABLE KEYS */;
INSERT INTO `logistics_config` VALUES
(2,'kdniao','EB123456','5d714b45ae1b17f1ddb47925f02f4a5c02012287852e549bca04f510b586531a','',1,'','2026-07-17 15:30:27','2026-07-17 15:30:27');
/*!40000 ALTER TABLE `logistics_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_after_sales`
--

DROP TABLE IF EXISTS `mall_after_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_after_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_item_id` int(11) DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'refund',
  `reason` text DEFAULT '',
  `description` text DEFAULT '',
  `images` text DEFAULT '[]',
  `amount` double DEFAULT 0,
  `status` varchar(20) DEFAULT 'pending',
  `seller_reply` text DEFAULT '',
  `seller_reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_after_sales_order` (`order_id`),
  KEY `idx_mall_after_sales_user` (`user_id`),
  KEY `idx_mall_after_sales_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_after_sales`
--

LOCK TABLES `mall_after_sales` WRITE;
/*!40000 ALTER TABLE `mall_after_sales` DISABLE KEYS */;
INSERT INTO `mall_after_sales` VALUES
(1,1,0,1,'return','test','test','[]',0,'pending','',NULL,'2026-07-16 19:28:14','2026-07-16 19:28:14');
/*!40000 ALTER TABLE `mall_after_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_cart_items`
--

DROP TABLE IF EXISTS `mall_cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`,`option_id`),
  KEY `idx_mall_cart_items_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_cart_items`
--

LOCK TABLES `mall_cart_items` WRITE;
/*!40000 ALTER TABLE `mall_cart_items` DISABLE KEYS */;
INSERT INTO `mall_cart_items` VALUES
(2,19,8,1,2,'2026-07-17 15:14:26');
/*!40000 ALTER TABLE `mall_cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_categories`
--

DROP TABLE IF EXISTS `mall_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `icon` varchar(200) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_categories`
--

LOCK TABLES `mall_categories` WRITE;
/*!40000 ALTER TABLE `mall_categories` DISABLE KEYS */;
INSERT INTO `mall_categories` VALUES
(1,0,'education','',1,'1','2026-07-10 22:39:53'),
(2,0,'design','',2,'1','2026-07-10 22:39:53'),
(3,0,'dev','',3,'1','2026-07-10 22:39:53'),
(4,0,'service','',4,'1','2026-07-10 22:39:53'),
(5,0,'电子产品','',5,'1','2026-07-17 15:50:59');
/*!40000 ALTER TABLE `mall_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_favorites`
--

DROP TABLE IF EXISTS `mall_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_product` (`user_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_favorites`
--

LOCK TABLES `mall_favorites` WRITE;
/*!40000 ALTER TABLE `mall_favorites` DISABLE KEYS */;
INSERT INTO `mall_favorites` VALUES
(1,1,1,'2026-07-16 19:47:09'),
(3,19,8,'2026-07-16 21:58:19'),
(4,3,1,'2026-07-17 15:03:57');
/*!40000 ALTER TABLE `mall_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_items`
--

DROP TABLE IF EXISTS `mall_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT 0,
  `product_name` varchar(200) DEFAULT '',
  `option_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `quantity` int(11) DEFAULT 1,
  `image` varchar(500) DEFAULT '',
  `virtual_content` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_items_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_items`
--

LOCK TABLES `mall_order_items` WRITE;
/*!40000 ALTER TABLE `mall_order_items` DISABLE KEYS */;
INSERT INTO `mall_order_items` VALUES
(1,16,8,1,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(2,17,8,1,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(3,18,1,0,'AI绘画大师课程','',199,1,'',''),
(4,19,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(5,20,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(6,21,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(7,22,9,3,'手机 (曜石黑)','曜石黑',2999,1,'',''),
(8,23,9,3,'手机','曜石黑',2999,1,'',''),
(16,31,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(17,32,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(18,33,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(19,34,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(20,35,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(21,36,8,2,'移动端组件库','10元',10,1,'','赠送 ¥10 余额'),
(22,37,9,3,'手机','曜石黑',2999,1,'','');
/*!40000 ALTER TABLE `mall_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_logistics`
--

DROP TABLE IF EXISTS `mall_order_logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_logistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `company` varchar(100) DEFAULT '',
  `tracking_no` varchar(100) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `details` text DEFAULT '[]',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mall_order_logistics_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_logistics`
--

LOCK TABLES `mall_order_logistics` WRITE;
/*!40000 ALTER TABLE `mall_order_logistics` DISABLE KEYS */;
INSERT INTO `mall_order_logistics` VALUES
(1,22,'顺丰速运','SF1234567890','picked','【深圳市】顺丰速运 南山科技园营业点已揽收','2026-07-18 08:30:00'),
(2,22,'顺丰速运','SF1234567890','transit','【深圳市】快件已到达 深圳宝安中转场','2026-07-18 12:00:00'),
(3,22,'顺丰速运','SF1234567890','transit','【广州市】快件已到达 广州白云中转场','2026-07-18 18:30:00'),
(4,22,'顺丰速运','SF1234567890','delivering','【广州市】快件由 天河区营业点 派送中，快递员：张师傅 13800138001','2026-07-19 09:15:00'),
(5,22,'顺丰速运','SF1234567890','delivered','【广州市】已签收，签收人：本人签收','2026-07-19 11:30:00'),
(6,23,'中通快递','ZTO87654321','shipped','[]','2026-07-17 16:36:31'),
(7,23,'中通快递','ZTO87654321','picked','【深圳市】中通快递 南山营业厅已揽收','2026-07-20 09:00:00'),
(8,23,'中通快递','ZTO87654321','transit','【深圳市】快件到达 深圳分拨中心','2026-07-20 11:30:00'),
(9,23,'中通快递','ZTO87654321','delivering','【深圳市】快件由 南山区网点 派送中，快递员：李师傅 13900139000','2026-07-20 14:00:00');
/*!40000 ALTER TABLE `mall_order_logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_orders`
--

DROP TABLE IF EXISTS `mall_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `total_amount` double DEFAULT 0,
  `discount_amount` double DEFAULT 0,
  `freight` double DEFAULT 0,
  `payment_method` varchar(20) DEFAULT '',
  `payment_time` datetime DEFAULT NULL,
  `receiver_name` varchar(100) DEFAULT '',
  `receiver_phone` varchar(20) DEFAULT '',
  `receiver_address` varchar(500) DEFAULT '',
  `logistics_company` varchar(100) DEFAULT '',
  `logistics_no` varchar(100) DEFAULT '',
  `user_custom_fields` text DEFAULT '{}',
  `remark` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_mall_orders_status` (`status`),
  KEY `idx_mall_orders_user` (`user_id`),
  KEY `idx_mall_orders_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_orders`
--

LOCK TABLES `mall_orders` WRITE;
/*!40000 ALTER TABLE `mall_orders` DISABLE KEYS */;
INSERT INTO `mall_orders` VALUES
(1,'MAL17837231930',2,'paid',417,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(2,'MAL17837231931',11,'paid',465,0,0,'alipay',NULL,'','','','','','{}','','2026-07-08 22:39:53','2026-07-10 22:39:53'),
(3,'MAL17837231932',10,'paid',169,0,0,'wechat',NULL,'','','','','','{}','','2026-06-21 22:39:53','2026-07-10 22:39:53'),
(4,'MAL17837231933',2,'shipped',141,0,0,'alipay',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(5,'MAL17837231934',9,'completed',194,0,0,'wechat',NULL,'','','','','','{}','','2026-07-09 22:39:53','2026-07-10 22:39:53'),
(6,'MAL17837231935',6,'cancelled',110,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(7,'MAL17837231936',5,'paid',175,0,0,'wechat',NULL,'','','','','','{}','','2026-06-17 22:39:53','2026-07-10 22:39:53'),
(8,'MAL17837231937',2,'paid',429,0,0,'alipay',NULL,'','','','','','{}','','2026-06-14 22:39:53','2026-07-10 22:39:53'),
(9,'MAL17837231938',14,'paid',440,0,0,'wechat',NULL,'','','','','','{}','','2026-06-25 22:39:53','2026-07-10 22:39:53'),
(10,'MAL17837231939',11,'shipped',329,0,0,'alipay',NULL,'','','','','','{}','','2026-07-10 22:39:53','2026-07-10 22:39:53'),
(11,'MAL178372319310',13,'completed',333,0,0,'wechat',NULL,'','','','','','{}','','2026-07-07 22:39:53','2026-07-10 22:39:53'),
(12,'MAL178372319311',2,'cancelled',396,0,0,'alipay',NULL,'','','','','','{}','','2026-07-01 22:39:53','2026-07-10 22:39:53'),
(13,'MAL178372319312',15,'paid',23,0,0,'wechat',NULL,'','','','','','{}','','2026-06-13 22:39:53','2026-07-10 22:39:53'),
(14,'MAL178372319313',11,'paid',496,0,0,'alipay',NULL,'','','','','','{}','','2026-06-12 22:39:53','2026-07-10 22:39:53'),
(15,'MAL178372319314',7,'paid',375,0,0,'wechat',NULL,'','','','','','{}','','2026-06-28 22:39:53','2026-07-10 22:39:53'),
(16,'260716034221QGNCVX',19,'paid',10,1,0,'balance','2026-07-16 19:42:21','','','','','','{}','','2026-07-16 19:42:21','2026-07-16 19:42:21'),
(17,'2607160342282DOSP7',19,'paid',10,0.8,0,'balance','2026-07-16 19:42:28','','','','','','{}','','2026-07-16 19:42:28','2026-07-16 19:42:28'),
(18,'260717230559J8E8H0',3,'paid',199,0,0,'balance','2026-07-17 15:05:59','','','','','','{}','','2026-07-17 15:05:59','2026-07-17 15:05:59'),
(19,'260717233747CR6KVK',19,'paid',980,0,0,'points','2026-07-17 15:37:47','','','','','','{}','','2026-07-17 15:37:47','2026-07-17 15:37:47'),
(20,'2607172339562YJQI0',19,'paid',9.8,0,0,'balance','2026-07-17 15:39:56','','','','','','{}','','2026-07-17 15:39:56','2026-07-17 15:39:56'),
(21,'260717234124R4L57T',19,'paid',9.8,0,0,'balance','2026-07-17 15:41:24','','','','','','{}','','2026-07-17 15:41:24','2026-07-17 15:41:24'),
(22,'260717235258KLLS3D',19,'shipped',2999,0,0,'balance','2026-07-17 15:52:58','Alex Morgan','13800138000','广东省深圳市南山区科技园路1号创新大厦1208','顺丰速运','SF1234567890','{}','请放快递柜','2026-07-17 15:52:58','2026-07-17 15:53:36'),
(23,'260717003531G4MCIF',19,'shipped',2939.02,0,0,'balance','2026-07-17 16:35:31','Alex Morgan','13800138000','广东省深圳市南山区科技园路1号创新大厦1208','中通快递','ZTO87654321','{}','','2026-07-17 16:35:31','2026-07-17 16:38:19'),
(31,'2607170239281O5ABD',10011,'paid',9.8,0,0,'balance','2026-07-17 18:39:28','','','','','','{}','','2026-07-17 18:39:28','2026-07-17 18:39:28'),
(32,'2607170239281ZDA42',10011,'paid',980,0,0,'points','2026-07-17 18:39:28','','','','','','{}','','2026-07-17 18:39:28','2026-07-17 18:39:28'),
(33,'260717023950U8ZRAT',10011,'paid',980,0,0,'points','2026-07-17 18:39:50','','','','','','{}','','2026-07-17 18:39:50','2026-07-17 18:39:50'),
(34,'260717024255BC1QWU',10011,'paid',980,0,0,'points','2026-07-17 18:42:55','','','','','','{}','','2026-07-17 18:42:55','2026-07-17 18:42:55'),
(35,'2607170247267BC3O2',10011,'paid',980,0,0,'points','2026-07-17 18:47:26','','','','','','{}','','2026-07-17 18:47:26','2026-07-17 18:47:26'),
(36,'260717024759FQENHY',10011,'paid',980,0,0,'points','2026-07-17 18:47:59','','','','','','{}','','2026-07-17 18:47:59','2026-07-17 18:47:59'),
(37,'260717075836FC7HM7',19,'paid',2939.02,0,0,'balance','2026-07-17 23:58:36','Alex Morgan','13800138000','广东省深圳市南山区科技园路1号创新大厦1208','','','{}','','2026-07-17 23:58:36','2026-07-17 23:58:36');
/*!40000 ALTER TABLE `mall_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_images`
--

DROP TABLE IF EXISTS `mall_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_images_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_images`
--

LOCK TABLES `mall_product_images` WRITE;
/*!40000 ALTER TABLE `mall_product_images` DISABLE KEYS */;
INSERT INTO `mall_product_images` VALUES
(1,9,'https://via.placeholder.com/800x800/333/fff?text=Phone',1);
/*!40000 ALTER TABLE `mall_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_product_options`
--

DROP TABLE IF EXISTS `mall_product_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `spec_name` varchar(200) DEFAULT '',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `points_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `image` varchar(500) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `card_config` text DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_mall_product_options_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_product_options`
--

LOCK TABLES `mall_product_options` WRITE;
/*!40000 ALTER TABLE `mall_product_options` DISABLE KEYS */;
INSERT INTO `mall_product_options` VALUES
(2,8,'10元','10元',10,0,1000,90,'',0,'{\"enabled\":true,\"type\":\"auto_recharge\",\"cardType\":\"balance\",\"targetId\":0,\"targetName\":\"\",\"value\":10,\"durationUnit\":\"day\",\"extraPoints\":0,\"extraBalance\":0,\"extraExperience\":0,\"rewardType\":\"membership\",\"rewardValue\":30,\"rewardDurationUnit\":\"day\",\"inviteCodeCount\":1,\"maxUses\":1,\"customCards\":[]}'),
(3,9,'曜石黑','颜色',2999,0,0,47,'',1,'{}'),
(4,9,'星云蓝','颜色',2999,0,0,30,'',2,'{}'),
(5,9,'樱花粉','颜色',3099,0,0,20,'',3,'{}');
/*!40000 ALTER TABLE `mall_product_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_products`
--

DROP TABLE IF EXISTS `mall_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT 0,
  `name` varchar(200) NOT NULL,
  `subtitle` varchar(200) DEFAULT '',
  `description` text DEFAULT '',
  `cover_image` varchar(500) DEFAULT '',
  `cover_video` varchar(500) DEFAULT '',
  `price_type` varchar(20) DEFAULT 'balance',
  `price` double DEFAULT 0,
  `original_price` double DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `product_type` varchar(20) DEFAULT 'virtual_auto',
  `virtual_content` text DEFAULT '',
  `status` varchar(20) DEFAULT 'draft',
  `sales_count` int(11) DEFAULT 0,
  `is_recommended` int(11) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `freight` double DEFAULT 0,
  `services` text DEFAULT '[]',
  `purchase_limit_config` text DEFAULT '[]',
  `commission_config` text DEFAULT '[]',
  `custom_fields` text DEFAULT '[]',
  `after_sales_config` text DEFAULT '{}',
  `tags` text DEFAULT '[]',
  `product_params` text DEFAULT '[]',
  `payment_methods` text DEFAULT '["balance"]',
  `sale_end_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT 0,
  `created_by_name` varchar(100) DEFAULT '',
  `product_subtype` varchar(50) DEFAULT '',
  `preview_images` text DEFAULT NULL,
  `source_file_url` varchar(500) DEFAULT NULL,
  `avg_rating` double DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_products_category` (`category_id`),
  KEY `idx_mall_products_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_products`
--

LOCK TABLES `mall_products` WRITE;
/*!40000 ALTER TABLE `mall_products` DISABLE KEYS */;
INSERT INTO `mall_products` VALUES
(1,1,'AI绘画大师课程','高级','','','','balance',199,299,99,'virtual_auto','','1',69,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(2,1,'Vue3实战视频教程','中级','','','','balance',79,99,0,'virtual_auto','','1',74,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(3,2,'设计素材大礼包','基础','','','','balance',39,49,0,'virtual_auto','','1',50,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(4,4,'代码审查服务','高级','','','','balance',149,199,0,'virtual_auto','','1',30,0,0,0,'[]','[]','[]','[]','{}','[\"热门\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(5,2,'UI Kit Pro','中级','','','','balance',99,129,0,'virtual_auto','','1',87,0,0,0,'[]','[]','[]','[]','{}','[\"推荐\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(6,2,'图标合集 5000+','基础','','','','balance',19,29,0,'virtual_auto','','1',75,0,0,0,'[]','[]','[]','[]','{}','[\"新品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(7,3,'API接口开放平台','高级','','','','balance',799,999,0,'virtual_auto','','1',42,0,0,0,'[]','[]','[]','[]','{}','[\"精品\"]','[]','[\"balance\"]',NULL,'2026-07-10 22:39:53','2026-07-10 22:39:53',0,'','',NULL,NULL,0),
(8,3,'移动端组件库','中级','','','','balance',149,199,0,'virtual_auto','','published',65,0,0,0,'[]','[]','[]','[]','{\"enableRefund\":false,\"enableReturn\":false,\"enablePrice\":false,\"validDays\":7}','[\"推荐\"]','[]','[\"balance\",\"points\"]',NULL,'2026-07-10 22:39:53','2026-07-17 15:36:40',0,'','',NULL,NULL,0),
(9,5,'手机','旗舰款','','','','balance',2999,3599,92,'physical','','published',10,0,0,0,'[\"7天无理由\",\"官方正品\",\"全国联保\"]','[]','[]','[]','{\"enableRefund\":true,\"enableReturn\":true,\"enablePrice\":true,\"validDays\":15}','[]','[]','[\"balance\"]',NULL,'2026-07-17 15:50:59','2026-07-17 15:52:12',10004,'admin','',NULL,NULL,0);
/*!40000 ALTER TABLE `mall_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_gifts`
--

DROP TABLE IF EXISTS `mall_promotion_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `gift_type` varchar(20) DEFAULT 'points',
  `gift_value` double DEFAULT 0,
  `gift_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '{}' CHECK (json_valid(`gift_detail`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_gifts`
--

LOCK TABLES `mall_promotion_gifts` WRITE;
/*!40000 ALTER TABLE `mall_promotion_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotion_products`
--

DROP TABLE IF EXISTS `mall_promotion_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotion_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_id` (`promotion_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotion_products`
--

LOCK TABLES `mall_promotion_products` WRITE;
/*!40000 ALTER TABLE `mall_promotion_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_promotion_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_promotions`
--

DROP TABLE IF EXISTS `mall_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_promotions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) DEFAULT 'discount',
  `discount_value` double DEFAULT 0,
  `min_amount` double DEFAULT 0,
  `user_types` text DEFAULT '[]',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_promotions`
--

LOCK TABLES `mall_promotions` WRITE;
/*!40000 ALTER TABLE `mall_promotions` DISABLE KEYS */;
INSERT INTO `mall_promotions` VALUES
(1,'666','discount',2,10,'[]','2026-07-12 00:42:00','2026-08-12 00:42:00','1','2026-07-11 16:42:26');
/*!40000 ALTER TABLE `mall_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_review_likes`
--

DROP TABLE IF EXISTS `mall_review_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_review_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `review_id` (`review_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_review_likes`
--

LOCK TABLES `mall_review_likes` WRITE;
/*!40000 ALTER TABLE `mall_review_likes` DISABLE KEYS */;
INSERT INTO `mall_review_likes` VALUES
(1,11,19,'2026-07-17 22:46:43');
/*!40000 ALTER TABLE `mall_review_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_reviews`
--

DROP TABLE IF EXISTS `mall_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT 5,
  `content` text DEFAULT '',
  `images` text DEFAULT '[]',
  `reply` text DEFAULT '',
  `reply_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `dim_product_rating` decimal(2,1) DEFAULT 0.0,
  `dim_service_rating` decimal(2,1) DEFAULT 0.0,
  `dim_logistics_rating` decimal(2,1) DEFAULT 0.0,
  `rating_desc` tinyint(4) DEFAULT 5,
  `rating_logistics` tinyint(4) DEFAULT 5,
  `rating_value` tinyint(4) DEFAULT 5,
  `like_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_mall_reviews_product` (`product_id`),
  KEY `idx_mall_reviews_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_reviews`
--

LOCK TABLES `mall_reviews` WRITE;
/*!40000 ALTER TABLE `mall_reviews` DISABLE KEYS */;
INSERT INTO `mall_reviews` VALUES
(1,6,4,1,5,'质量不错，第1次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,1),
(2,2,8,2,4,'质量不错，第2次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(3,8,8,3,4,'质量不错，第3次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(4,7,10,4,5,'质量不错，第4次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(5,4,2,5,5,'质量不错，第5次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(6,5,12,6,5,'质量不错，第6次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(7,7,6,7,5,'质量不错，第7次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(8,6,3,8,5,'质量不错，第8次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(9,2,8,9,5,'质量不错，第9次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(10,2,5,10,5,'质量不错，第10次购买了！','[]','',NULL,'2026-07-10 22:39:53',0.0,0.0,0.0,5,5,5,0),
(11,9,19,22,5,'666','[]','',NULL,'2026-07-17 22:46:41',5.0,5.0,5.0,5,5,5,1);
/*!40000 ALTER TABLE `mall_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_levels`
--

DROP TABLE IF EXISTS `membership_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `tier` int(11) DEFAULT 1,
  `parent_level_id` int(11) DEFAULT 0,
  `price` decimal(10,2) DEFAULT 0.00,
  `points_required` int(11) DEFAULT 0,
  `discount_rate` decimal(3,1) DEFAULT 1.0,
  `points_multiplier` decimal(3,1) DEFAULT 1.0,
  `points_discount_rate` decimal(3,1) DEFAULT 1.0,
  `text_color` varchar(20) DEFAULT '#FFFFFF',
  `bg_color` varchar(20) DEFAULT '#508DFF',
  `benefits` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT '',
  `icon_color` varchar(20) DEFAULT '#909399',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `data_limit_mb` int(11) DEFAULT 0,
  `file_limit_mb` int(11) DEFAULT 0,
  `file_policy_ids` text DEFAULT NULL,
  `recycle_retention_days` int(11) DEFAULT 0,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `perks` text DEFAULT NULL,
  `title_id` int(11) DEFAULT 0,
  `frame_id` int(11) DEFAULT 0,
  `daily_gift_enabled` tinyint(1) DEFAULT 0,
  `daily_gift_interval_days` int(11) DEFAULT 1,
  `daily_gift_points` int(11) DEFAULT 0,
  `daily_gift_balance` decimal(10,2) DEFAULT 0.00,
  `daily_gift_experience` int(11) DEFAULT 0,
  `daily_gift_coupon_ids` text DEFAULT NULL,
  `birthday_gift_points` int(11) DEFAULT 0,
  `birthday_gift_balance` decimal(10,2) DEFAULT 0.00,
  `birthday_gift_experience` int(11) DEFAULT 0,
  `birthday_gift_coupon_ids` text DEFAULT NULL,
  `commission_rule_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_levels`
--

LOCK TABLES `membership_levels` WRITE;
/*!40000 ALTER TABLE `membership_levels` DISABLE KEYS */;
INSERT INTO `membership_levels` VALUES
(1,'普通会员',0,1,0,0.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','基础权益','ri:user-line','#909399','1','2026-07-10 22:42:45',50,100,'1',0,0,0.00,0,NULL,NULL,0,0,0,1,0,0.00,0,NULL,0,0.00,0,NULL,0),
(2,'黄金会员',1,1,0,299.00,0,0.9,1.5,1.0,'#FFFFFF','#000000','9折优惠,1.5倍积分,专属客服','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783977599947.gif','','1','2026-07-10 22:42:45',50,50,'1',15,100,5.00,200,'[{\"name\":\"黄金专享券\",\"type\":\"fixed\",\"value\":20,\"minOrder\":30,\"maxDiscount\":0,\"scope\":\"membership\",\"category\":\"member\",\"validDays\":30}]','生日礼包|年度礼包',1,1,1,1,10,1.00,50,'[{\"name\":\"每日签到券\",\"type\":\"percent\",\"value\":5,\"minOrder\":0,\"maxDiscount\":20,\"scope\":\"all\",\"category\":\"general\",\"validDays\":7}]',500,50.00,1000,'[{\"name\":\"生日专属券\",\"type\":\"fixed\",\"value\":100,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"category\":\"member\",\"validDays\":30}]',3),
(3,'钻石会员',2,1,0,599.00,0,1.0,1.0,1.0,'#FFFFFF','#508DFF','8折优惠,2倍积分,专属客服,优先发货,生日礼包','ri:vip-diamond-line','','1','2026-07-10 22:42:45',500,10000,'',20,0,0.00,0,'[]','',0,0,0,1,0,0.00,0,'[]',0,0.00,0,'[]',0),
(4,'至尊会员',3,1,0,999.00,0,0.7,3.0,3.0,'#FFFFFF','#508DFF','7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品','http://appiapp.oss-cn-hongkong.aliyuncs.com/admin/membership_icon/mb_icon_1783978168089.gif','#ff6b6b','1','2026-07-10 22:42:45',200,20000,'3',30,200,0.00,200,'[]','',1,1,1,7,50,0.00,50,'[]',500,0.00,500,'[]',0),
(5,'测试会员',5,5,0,10.00,0,6.0,5.0,5.0,'#FFFFFF','#508DFF','','','','0','2026-07-11 22:39:44',500,500,'2,1',0,500,5.00,500,'[]','',1,1,1,3,10,0.00,30,'[]',500,0.00,500,'[]',0);
/*!40000 ALTER TABLE `membership_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_products`
--

DROP TABLE IF EXISTS `membership_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) DEFAULT '',
  `price` decimal(10,2) DEFAULT 0.00,
  `original_price` decimal(10,2) DEFAULT 0.00,
  `points_price` decimal(10,2) DEFAULT 0.00,
  `points_original_price` decimal(10,2) DEFAULT 0.00,
  `duration_days` int(11) DEFAULT 30,
  `is_promo` tinyint(1) DEFAULT 0,
  `promo_end_time` datetime DEFAULT NULL,
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_ids` text DEFAULT NULL,
  `gift_data_limit_mb` int(11) DEFAULT 0,
  `gift_file_limit_mb` int(11) DEFAULT 0,
  `purchase_limit` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_products`
--

LOCK TABLES `membership_products` WRITE;
/*!40000 ALTER TABLE `membership_products` DISABLE KEYS */;
INSERT INTO `membership_products` VALUES
(7,5,'30天会员',30.00,35.00,3500.00,3600.00,30,1,NULL,100,0.00,200,'[]',10,10,0,'1','2026-07-11 23:02:32'),
(24,2,'1个月',10.00,12.00,1300.00,0.00,31,1,NULL,50,3.00,100,'[{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"category\":\"general\",\"validDays\":14}]',10,10,3,'1','2026-07-18 02:58:00'),
(25,3,'月度会员',15.00,18.00,1800.00,2000.00,31,1,NULL,100,0.00,100,'[]',0,0,0,'1','2026-07-18 02:58:05'),
(26,4,'月度会员',20.00,25.00,2500.00,3000.00,31,1,NULL,0,0.00,500,'[]',10,10,0,'1','2026-07-18 02:58:10'),
(27,4,'季度会员',48.00,60.00,5800.00,6000.00,96,1,NULL,120,0.00,2000,'[]',20,20,0,'1','2026-07-18 02:58:10');
/*!40000 ALTER TABLE `membership_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_purchases`
--

DROP TABLE IF EXISTS `membership_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `purchase_type` varchar(20) DEFAULT 'buy',
  `duration_days` int(11) DEFAULT 0,
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `gift_points` int(11) DEFAULT 0,
  `gift_balance` decimal(10,2) DEFAULT 0.00,
  `gift_experience` int(11) DEFAULT 0,
  `gift_coupon_count` int(11) DEFAULT 0,
  `gift_data_mb` int(11) DEFAULT 0,
  `gift_file_mb` int(11) DEFAULT 0,
  `lower_extended_ids` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_membership_purchases_user` (`user_id`),
  KEY `idx_membership_purchases_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_purchases`
--

LOCK TABLES `membership_purchases` WRITE;
/*!40000 ALTER TABLE `membership_purchases` DISABLE KEYS */;
INSERT INTO `membership_purchases` VALUES
(1,14,0,2,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-23 22:39:54',0,0.00,0,0,0,0,NULL),
(2,14,0,3,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54',0,0.00,0,0,0,0,NULL),
(3,4,0,2,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-28 22:39:54',0,0.00,0,0,0,0,NULL),
(4,11,0,4,'黄金会员',299.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-29 22:39:54',0,0.00,0,0,0,0,NULL),
(5,11,0,4,'钻石会员',599.00,'balance','buy',0,'2027-07-10 22:39:54','2026-05-19 22:39:54',0,0.00,0,0,0,0,NULL),
(6,7,0,4,'至尊会员',999.00,'balance','buy',0,'2027-07-10 22:39:54','2026-06-16 22:39:54',0,0.00,0,0,0,0,NULL),
(7,19,1,2,'黄金会员',1300.00,'points','buy',31,'2026-08-11 09:08:18','2026-07-11 09:08:18',0,0.00,0,0,0,0,NULL),
(8,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-09-11 01:08:18','2026-07-11 09:14:35',0,0.00,0,0,0,0,NULL),
(9,19,1,2,'黄金会员',10.00,'balance','renew',31,'2026-10-11 17:08:18','2026-07-11 09:14:38',0,0.00,0,0,0,0,NULL),
(10,1,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:37:08','2026-07-11 20:37:08',0,0.00,0,0,0,0,NULL),
(11,4,3,2,'黄金会员',10.00,'balance','buy',31,'2026-08-11 20:38:36','2026-07-11 20:38:36',0,0.00,0,0,0,0,NULL),
(18,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-11-11 09:08:18','2026-07-12 00:11:10',0,0.00,0,0,0,0,NULL),
(19,19,9,4,'至尊会员',48.00,'balance','buy',96,'2027-02-15 01:08:18','2026-07-12 10:34:02',0,0.00,0,0,0,0,NULL),
(20,19,9,4,'至尊会员',48.00,'balance','renew',96,'2027-05-21 17:08:18','2026-07-12 10:34:26',0,0.00,0,0,0,0,NULL),
(21,19,8,4,'至尊会员',20.00,'balance','renew',31,'2027-06-21 09:08:18','2026-07-12 10:35:24',0,0.00,0,0,0,0,NULL),
(22,19,9,4,'至尊会员',48.00,'balance','renew',96,'2027-09-25 01:08:18','2026-07-12 10:35:40',0,0.00,0,0,0,0,NULL),
(23,19,5,2,'黄金会员',10.00,'balance','buy',31,'2027-10-25 17:08:18','2026-07-12 10:37:22',0,0.00,0,0,0,0,NULL),
(24,19,8,4,'至尊会员',20.00,'balance','buy',31,'2027-11-25 09:08:18','2026-07-12 10:37:35',0,0.00,0,0,0,0,NULL),
(25,19,5,2,'黄金会员',10.00,'balance','buy',31,'2027-12-26 01:08:18','2026-07-12 10:37:47',0,0.00,0,0,0,0,NULL),
(26,19,8,4,'至尊会员',20.00,'balance','buy',31,'2028-01-25 17:08:18','2026-07-12 10:37:54',0,0.00,0,0,0,0,NULL),
(27,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:12:49','2026-07-12 11:12:50',0,0.00,0,0,0,0,NULL),
(28,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:12:58','2026-07-12 11:12:58',0,0.00,0,0,0,0,NULL),
(29,19,5,2,'黄金会员',10.00,'balance','buy',31,'2026-08-12 11:13:05','2026-07-12 11:13:05',0,0.00,0,0,0,0,NULL),
(30,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-02-25 09:08:18','2026-07-12 11:13:08',0,0.00,0,0,0,0,NULL),
(31,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-03-27 01:08:18','2026-07-12 11:13:13',0,0.00,0,0,0,0,NULL),
(32,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-04-26 17:08:18','2026-07-12 11:15:35',0,0.00,0,0,0,0,NULL),
(33,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-09-12 03:13:05','2026-07-12 11:15:38',0,0.00,0,0,0,0,NULL),
(34,19,5,2,'黄金会员',10.00,'balance','renew',31,'2026-10-12 19:13:05','2026-07-12 11:15:40',0,0.00,0,0,0,0,NULL),
(35,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-05-27 09:08:18','2026-07-12 11:17:36',0,0.00,0,0,0,0,NULL),
(36,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-06-27 01:08:18','2026-07-12 11:17:38',0,0.00,0,0,0,0,NULL),
(37,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-07-27 17:08:18','2026-07-12 11:17:40',0,0.00,0,0,0,0,NULL),
(38,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-08-27 09:08:18','2026-07-12 11:17:44',0,0.00,0,0,0,0,NULL),
(39,19,8,4,'至尊会员',20.00,'balance','renew',31,'2028-09-27 01:08:18','2026-07-12 11:17:47',0,0.00,0,0,0,0,NULL),
(40,19,9,4,'至尊会员',5800.00,'points','renew',96,'2028-12-31 17:08:18','2026-07-12 11:21:02',0,0.00,0,0,0,0,NULL),
(41,19,9,4,'至尊会员',5800.00,'points','renew',96,'2029-04-06 09:08:18','2026-07-12 11:21:07',0,0.00,0,0,0,0,NULL),
(42,19,9,4,'至尊会员',5800.00,'points','renew',96,'2029-07-11 01:08:18','2026-07-12 11:21:13',0,0.00,0,0,0,0,NULL),
(43,19,9,4,'至尊会员',48.00,'balance','renew',96,'2029-10-14 17:08:18','2026-07-12 11:21:15',0,0.00,0,0,0,0,NULL),
(44,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-05-01 11:13:05','2026-07-12 16:49:54',0,0.00,0,0,0,0,'[\"3:4:2029-10-14T09:08:18.000Z\"]'),
(45,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-06-01 03:13:05','2026-07-12 16:50:03',0,0.00,0,0,0,0,'[\"3:4:2029-11-14T01:08:18.000Z\"]'),
(46,19,5,2,'黄金会员',10.00,'balance','renew',31,'2028-07-01 19:13:05','2026-07-12 16:50:07',0,0.00,0,0,0,0,'[\"3:4:2029-12-14T17:08:18.000Z\"]'),
(47,19,5,2,'黄金会员',1300.00,'points','renew',31,'2028-08-01 11:13:05','2026-07-12 16:50:10',0,0.00,0,0,0,0,'[\"3:4:2030-01-14T09:08:18.000Z\"]'),
(48,19,5,2,'黄金会员',1300.00,'points','renew',31,'2028-09-01 03:13:05','2026-07-12 16:50:15',0,0.00,0,0,0,0,'[\"3:4:2030-02-14T01:08:18.000Z\"]'),
(49,19,9,4,'至尊会员',48.00,'balance','renew',96,'2030-06-20 17:08:18','2026-07-12 16:50:19',120,0.00,2000,0,20,20,'[\"6:2:2028-08-31T19:13:05.000Z\"]'),
(50,19,9,4,'至尊会员',48.00,'balance','renew',96,'2030-09-24 09:08:18','2026-07-12 16:50:22',120,0.00,2000,0,20,20,'[\"6:2:2028-12-05T11:13:05.000Z\"]'),
(51,19,9,4,'至尊会员',5800.00,'points','renew',96,'2030-12-29 01:08:18','2026-07-12 16:50:25',120,0.00,2000,0,20,20,'[\"6:2:2029-03-11T03:13:05.000Z\"]'),
(52,19,9,4,'至尊会员',5800.00,'points','renew',96,'2031-04-03 17:08:18','2026-07-12 16:50:28',120,0.00,2000,0,20,20,'[\"6:2:2029-06-14T19:13:05.000Z\"]'),
(53,19,9,4,'至尊会员',48.00,'balance','renew',96,'2031-07-08 09:08:18','2026-07-12 16:50:30',120,0.00,2000,0,20,20,'[\"6:2:2029-09-18T11:13:05.000Z\"]'),
(54,19,11,4,'至尊会员',48.00,'balance','renew',96,'2031-10-12 01:08:18','2026-07-12 16:51:41',120,0.00,2000,0,20,20,'[\"6:2:2029-12-23T03:13:05.000Z\"]'),
(55,19,11,4,'至尊会员',48.00,'balance','renew',96,'2032-01-15 17:08:18','2026-07-12 16:52:12',120,0.00,2000,0,20,20,'[\"6:2:2030-03-28T19:13:05.000Z\"]'),
(56,19,13,3,'钻石会员',15.00,'balance','buy',31,'2026-08-12 20:36:22','2026-07-12 20:36:22',100,0.00,100,0,0,0,'[\"3:4:2032-01-15T09:08:18.000Z\",\"6:2:2030-07-02T11:13:05.000Z\"]'),
(57,19,10,4,'至尊会员',20.00,'balance','renew',31,'2032-03-17 01:08:18','2026-07-12 20:36:40',0,0.00,500,0,10,10,'[\"6:2:2030-08-02T03:13:05.000Z\",\"7:3:2026-08-12T12:36:22.000Z\"]'),
(58,19,13,3,'钻石会员',15.00,'balance','renew',31,'2026-10-13 04:36:22','2026-07-12 20:36:48',100,0.00,100,0,0,0,'[\"3:4:2032-03-16T17:08:18.000Z\",\"6:2:2030-09-01T19:13:05.000Z\"]'),
(59,19,11,4,'至尊会员',48.00,'balance','renew',96,'2032-07-21 09:08:18','2026-07-12 20:46:00',120,0.00,2000,0,20,20,'[\"6:2:2030-10-02T11:13:05.000Z\",\"7:3:2026-10-12T20:36:22.000Z\"]'),
(60,19,11,4,'至尊会员',5800.00,'points','renew',96,'2032-10-25 01:08:18','2026-07-12 20:48:02',120,0.00,2000,0,20,20,'[\"6:2:2031-01-06T03:13:05.000Z\",\"7:3:2027-01-16T12:36:22.000Z\"]'),
(61,19,10,4,'至尊会员',20.00,'balance','renew',31,'2032-11-24 17:08:18','2026-07-12 22:19:55',0,0.00,500,0,10,10,'[\"6:2:2031-04-11T19:13:05.000Z\",\"7:3:2027-04-22T04:36:22.000Z\"]'),
(62,19,5,2,'黄金会员',10.00,'balance','renew',31,'2031-06-12 11:13:05','2026-07-12 23:00:31',0,0.00,0,0,0,0,'[\"3:4:2032-11-24T09:08:18.000Z\",\"7:3:2027-05-22T20:36:22.000Z\"]'),
(63,19,11,4,'至尊会员',48.00,'balance','renew',96,'2033-03-31 01:08:18','2026-07-12 23:01:02',120,0.00,2000,0,20,20,'[\"6:2:2031-06-12T03:13:05.000Z\",\"7:3:2027-06-22T12:36:22.000Z\"]'),
(64,19,18,4,'至尊会员',48.00,'balance','renew',96,'2033-07-04 17:08:18','2026-07-17 19:37:43',120,0.00,2000,0,20,20,'[\"6:2:2031-09-15T19:13:05.000Z\",\"7:3:2027-09-26T04:36:22.000Z\"]'),
(65,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-01-30 20:36:22','2026-07-17 19:37:46',100,0.00,100,0,0,0,'[\"3:4:2033-07-04T09:08:18.000Z\",\"6:2:2031-12-20T11:13:05.000Z\"]'),
(66,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-03-01 12:36:22','2026-07-17 19:37:50',100,0.00,100,0,0,0,'[\"3:4:2033-08-04T01:08:18.000Z\",\"6:2:2032-01-20T03:13:05.000Z\"]'),
(67,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-04-01 04:36:22','2026-07-17 19:37:57',100,0.00,100,0,0,0,'[\"3:4:2033-09-03T17:08:18.000Z\",\"6:2:2032-02-19T19:13:05.000Z\"]'),
(68,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-04-21 11:13:05','2026-07-17 19:38:02',50,3.00,100,1,10,10,'[\"3:4:2033-10-04T09:08:18.000Z\",\"7:3:2028-03-31T20:36:22.000Z\"]'),
(69,19,18,4,'至尊会员',48.00,'balance','renew',96,'2034-02-08 01:08:18','2026-07-17 19:38:04',120,0.00,2000,0,20,20,'[\"6:2:2032-04-21T03:13:05.000Z\",\"7:3:2028-05-01T12:36:22.000Z\"]'),
(70,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-08-25 19:13:05','2026-07-17 19:43:09',50,3.00,100,1,10,10,NULL),
(71,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-09-25 11:13:05','2026-07-17 19:43:15',50,3.00,100,1,10,10,NULL),
(72,19,19,2,'黄金会员',10.00,'balance','renew',31,'2032-10-26 03:13:05','2026-07-17 19:43:19',0,0.00,0,0,0,0,NULL),
(73,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-09-05 04:36:22','2026-07-17 19:43:23',100,0.00,100,0,0,0,NULL),
(74,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-10-05 20:36:22','2026-07-17 19:43:27',100,0.00,100,0,0,0,NULL),
(75,19,13,3,'钻石会员',15.00,'balance','renew',31,'2028-11-05 12:36:22','2026-07-17 19:43:32',100,0.00,100,0,0,0,NULL),
(76,19,24,2,'黄金会员',10.00,'balance','renew',31,'2032-11-25 19:13:05','2026-07-19 04:10:29',50,3.00,100,1,10,10,NULL),
(77,19,24,2,'黄金会员',10.00,'balance','renew',31,'2032-12-26 11:13:05','2026-07-21 00:23:38',50,3.00,100,1,10,10,NULL);
/*!40000 ALTER TABLE `membership_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL DEFAULT '',
  `component` varchar(200) DEFAULT '',
  `redirect` varchar(200) DEFAULT '',
  `title` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `is_hidden` tinyint(1) DEFAULT 0,
  `is_full_page` tinyint(1) DEFAULT 0,
  `is_keep_alive` tinyint(1) DEFAULT 1,
  `is_fixed_tab` tinyint(1) DEFAULT 0,
  `auth_list` text DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `mobile_path` varchar(200) DEFAULT '',
  `icon_bg` varchar(20) DEFAULT '#4ECDC4',
  `icon_svg` text DEFAULT NULL,
  `category` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,0,'Dashboard','/dashboard','/index/index','/dashboard/console','仪表盘','ri:pie-chart-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:31:19'),
(2,0,'Operation','/operation','/index/index','','运营管理','ri:settings-3-line',3,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:19'),
(3,0,'System','/system','/index/index','','系统管理','ri:user-3-line',2,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:15'),
(4,0,'Result','/result','/index/index','','结果页面','ri:checkbox-circle-line',6,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:30'),
(5,0,'Exception','/exception','/index/index','','异常页面','ri:error-warning-line',7,0,0,0,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-11 16:09:36'),
(6,0,'AppStore','/appstore','/index/index','','审核中心','ri:apps-2-line',1,0,0,0,0,NULL,'[\"R_SUPER\",\"R_ADMIN\",\"R_USER\"]',1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:31:00'),
(7,1,'Console','console','/dashboard/console','','工作台','',1,0,0,1,1,NULL,NULL,1,'/appstore/mobile-console','#F472B6','M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(8,2,'CardKey','cardkey','/operation/cardkey/index','','卡密管理','',1,0,0,1,0,'[{\"title\":\"生成\",\"authMark\":\"add\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"导入\",\"authMark\":\"import\"}]',NULL,1,'/appstore/cardkey-manage','#C4B5FD','M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(9,2,'Membership','membership','/operation/membership/index','','会员管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/operation/membership','#86EFAC','M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(10,2,'Coupon','coupon','/operation/coupon/index','','优惠券管理','',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/coupon','#FF6B81','M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-6 4h2v-2h-2v2zm-4 0h2v-2h-2v2zm0-4h2v-2h-2v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(11,2,'Points','points','/operation/points/index','','积分管理','',4,0,0,1,0,'[{\"title\":\"调整\",\"authMark\":\"adjust\"},{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/points','#D946EF','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(12,2,'ExperienceLevel','experience','/operation/experience/index','','经验等级','',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/experience-manage','#14B8A6','M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(13,2,'Plugins','plugins','/operation/plugins/index','','插件管理','',6,0,0,1,0,'[{\"title\":\"上传\",\"authMark\":\"upload\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"配置\",\"authMark\":\"config\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/plugin-manage','#FF6B81','M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-2 .9-2 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7s2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(14,2,'TitleManage','title','/operation/title/index','','称号管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/title-manage','#6366F1','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(15,2,'CommissionManage','commission','/operation/commission/index','','推广返佣','',8,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"配置\",\"authMark\":\"config\"}]',NULL,1,'/appstore/commission-manage','#14B8A6','M20 7h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-6 0h-4V4h4v3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(16,54,'文件上传策略','filepolicy','/operation/filepolicy/index','','文件上传策略','',9,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-policy-manage','#A3E635','M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12','','2026-07-10 22:42:45','2026-07-12 16:09:37'),
(17,2,'Settlement','settlement','/operation/settlement/index','','结算规则','ri:exchange-funds-line',10,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/settlement','#C4B5FD','M21 3H3v18h18V3zm-2 16H5V5h14v14zM17 7h-4v4h4V7zm-6 0H7v4h4V7zm6 6h-4v4h4v-4zm-6 0H7v4h4v-4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(18,2,'MembershipProducts','membership-products','/operation/membership-products/index','','会员商品','',11,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/operation/membership-products','#EC4899','M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-5 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 14H4v-2h16v2zm0-5H4V8h16v5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(19,2,'MembershipPurchases','membership-purchases','/operation/membership-purchases/index','','购买记录','',12,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/purchase-records','#F59E0B','M11 17h2v-1h1c.55 0 1-.45 1-1v-3c0-.55-.45-1-1-1h-3v-1h4V8h-2V7h-2v1h-1c-.55 0-1 .45-1 1v3c0 .55.45 1 1 1h3v1H9v2h2v1zm9-13H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(20,2,'ContentPurchases','content-purchases','/operation/content-purchases/index','','付费内容订单','',13,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"}]',NULL,1,'/appstore/operation/content-purchases','#8B5CF6','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(21,3,'User','user','/system/user','','用户管理','',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"重置密码\",\"authMark\":\"reset\"}]',NULL,1,'/appstore/user-manage','#0EA5E9','M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(22,3,'Role','role','/system/role','','角色管理','',2,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/role-manage','#5352ED','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(23,3,'UserCenter','user-center','/system/user-center','','个人中心','',3,1,0,1,1,NULL,NULL,1,'','#10B981',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(24,3,'Menus','menu','/system/menu','','菜单管理','',4,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/menu-manage','#0EA5E9','M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(25,3,'DeleteReview','delete-review','/system/user/delete-review','','提现注销审核','',6,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'/appstore/delete-review','#70A1FF','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-12 23:50:44'),
(26,3,'Verification','verification','/system/verification/index','','蓝V认证审核','',5,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"}]',NULL,1,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:50:44'),
(27,3,'InviteManage','invite','/system/invite/index','','邀请码管理','',7,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"生成\",\"authMark\":\"generate\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/invite-manage','#FB923C','M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(28,70,'EmailConfig','email','','','邮件配置','ri:mail-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-config','#FDBA74','M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(29,54,'文件仓库','filerepo','/system/filerepo/index','','文件仓库','',8,0,0,1,0,'[{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/file-repo-manage','#14B8A6','M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z','','2026-07-10 22:42:45','2026-07-12 16:09:29'),
(30,3,'RecycleBin','recycle','/system/recycle/index','','回收站','',10,0,0,1,0,'[{\"title\":\"恢复\",\"authMark\":\"restore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/recycle','#FF4757','M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(31,3,'SystemLog','syslog','/system/syslog/index','','系统日志','',11,0,0,1,0,'[{\"title\":\"导出\",\"authMark\":\"export\"},{\"title\":\"清空\",\"authMark\":\"clear\"}]',NULL,1,'/appstore/syslog','#84CC16','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(32,70,'SysConfig','sysconfig','','','系统配置','ri:settings-3-line',1,0,0,0,0,NULL,NULL,0,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-12 23:39:02'),
(33,3,'CustomTask','task','/system/task/index','','任务管理','',13,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/task-manage','#A78BFA','M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(34,70,'EmailTemplates','email-templates','','','邮件卡片','ri:mail-settings-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-templates','#FF6B81','M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(35,70,'EmailPush','email-push','','','邮件推送','ri:send-plane-line',0,0,0,0,0,NULL,NULL,1,'/appstore/email-push','#FCA5A5','M3.4 20.4l17.45-7.48c1.1-.47 1.1-1.97 0-2.44L3.4 3.6c-1.1-.47-2.2.63-1.73 1.73L7 12l-5.33 6.67c-.47 1.1.63 2.2 1.73 1.73z','','2026-07-10 22:42:45','2026-07-12 19:36:15'),
(36,54,'对象存储','storage-config','/appstore/storage-config','','对象存储','',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/storage-config','#5EEAD4','M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z','','2026-07-10 22:42:45','2026-07-12 16:24:10'),
(37,6,'AppStoreList','list','/appstore/list','','应用管理','',1,0,0,1,0,'[{\"title\":\"通过\",\"authMark\":\"approve\"},{\"title\":\"拒绝\",\"authMark\":\"reject\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]',NULL,1,'/appstore/list','#6366F1','M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(38,6,'AppStoreDetail','detail/:id','/appstore/detail','','应用详情','',2,1,0,0,0,NULL,NULL,1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(39,6,'AppCategory','category-manage','/appstore/category','','应用分类','ri:apps-2-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/category-manage','#818CF8','M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(40,6,'AppReports','reports','/appstore/reports','','举报列表','ri:apps-2-line',4,0,0,1,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/reports','#5352ED','M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(44,6,'OfficialTags','official-tags','/appstore/official-tags','','官方标签','',8,0,0,1,0,NULL,'[\"R_SUPER\",\"R_ADMIN\"]',0,'','#4ECDC4','','','2026-07-10 22:42:45','2026-07-13 15:04:21'),
(45,6,'SectionManage','section-manage','','','板块管理','',9,1,0,0,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"管理版主\",\"authMark\":\"moderate\"},{\"title\":\"启停\",\"authMark\":\"toggle\"},{\"title\":\"处理解锁\",\"authMark\":\"unlock\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/section-manage','#818CF8','M3 15h8v-2H3v2zm0 4h8v-2H3v2zm0-8h8V9H3v2zm0-6v2h8V5H3zm10 0h8v14h-8V5z','','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(46,6,'CommunityPostManage','community-posts','','','帖子管理','',10,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"加精\",\"authMark\":\"essence\"},{\"title\":\"热帖\",\"authMark\":\"boost\"},{\"title\":\"锁定\",\"authMark\":\"lock\"},{\"title\":\"审核\",\"authMark\":\"approve\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(47,6,'CommunityReportManage','community-reports','','','举报管理','',11,1,0,0,0,'[{\"title\":\"处理\",\"authMark\":\"handle\"},{\"title\":\"忽略\",\"authMark\":\"ignore\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(48,6,'CommunityCommentManage','community-comments','','','评论管理','',12,1,0,0,0,'[{\"title\":\"置顶\",\"authMark\":\"pin\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'','#EC4899',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(49,4,'Success','success','/result/success/index','','成功页','',1,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(50,4,'Fail','fail','/result/fail/index','','失败页','',2,0,1,0,0,NULL,NULL,1,'','#EF4444',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(51,5,'Exception403','403','/exception/403/index','','403','',1,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(52,5,'Exception404','404','/exception/404/index','','404','',2,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(53,5,'Exception500','500','/exception/500/index','','500','',3,0,1,0,0,NULL,NULL,1,'','#8B5CF6',NULL,'','2026-07-10 22:42:45','2026-07-10 22:42:45'),
(54,0,'文件管理','/awsdb','/index/index','','文件管理','',4,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-10 23:24:00','2026-07-12 17:15:51'),
(55,2,'GameCenter','/operation/game-center','','','游戏中心','ri:gamepad-line',19,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/game-center','#22C55E','M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v2H6v-2H4v-2h2V9h2v2h3v2zm7 0h-3v2h-2v-2h-3V9h3V7h2v2h3v2z','','2026-07-11 09:41:21','2026-07-11 09:41:21'),
(56,0,'商城管理','/etnfd','','','商城管理','',5,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-11 16:08:50','2026-07-11 16:09:24'),
(57,56,'商品管理','/appstore/mall-manage','/appstore/admin/mall/mall-manage','','商品管理','ri:shopping-bag-3-line',1,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-manage','#FDBA74','M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4','','2026-07-11 16:15:17','2026-07-12 16:10:51'),
(58,56,'订单管理','/appstore/mall-orders','/appstore/admin/mall/mall-orders','','订单管理','ri:file-list-3-line',2,0,0,1,0,'[{\"title\":\"查看\",\"authMark\":\"view\"},{\"title\":\"处理\",\"authMark\":\"handle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-orders','#10B981','M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01','','2026-07-11 16:15:17','2026-07-12 16:08:51'),
(59,56,'分类管理','/appstore/mall-categories','/appstore/admin/mall/mall-categories','','分类管理','ri:price-tag-3-line',3,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-categories','#26DE81','M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z','','2026-07-11 16:15:17','2026-07-12 16:08:58'),
(60,56,'售后服务','/appstore/mall-after-sales','/appstore/admin/mall/mall-after-sales','','售后服务','ri:customer-service-2-line',4,0,0,1,0,'[{\"title\":\"查看\",\"authMark\":\"view\"},{\"title\":\"处理\",\"authMark\":\"handle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-after-sales','#A3E635','M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z','','2026-07-11 16:15:17','2026-07-12 16:09:06'),
(61,56,'优惠活动','/appstore/mall-promotions','/appstore/admin/mall/mall-promotions','','优惠活动','ri:gift-line',5,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/mall-promotions','#EF4444','M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7','','2026-07-11 16:15:17','2026-07-12 16:09:13'),
(62,2,'CheckinManage','/operation/checkin','/operation/checkin/index','','签到管理','ri:calendar-check-line',21,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"启停\",\"authMark\":\"toggle\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/checkin','#A855F7','M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-6.67 11.93l-3.89 3.89-2.11-2.11 1.41-1.41 1.12 1.12 2.47-2.47 1.51 1.41.04.04z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(63,70,'LayoutThemesManage','layout-themes','','','布局主题','ri:layout-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/layout-themes','#0EA5E9','M3 21h18v-2H3v2zm0-4h12v-2H3v2zm0-4h18v-2H3v2zm0-4h12V7H3v2zm0-6v2h18V3H3z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(64,2,'AvatarFrameManage','/operation/avatar-frame','/operation/avatar-frame/index','','头像框管理','ri:user-smile-line',23,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/operation/avatar-frame','#FFA502','M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(65,70,'PaymentConfig','/operation/payment-config','','','支付配置','ri:bank-card-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/payment-config','#7BED9F','M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(66,70,'RechargeAmounts','/operation/recharge-amounts','','','充值金额配置','ri:money-cny-circle-line',0,0,0,0,0,NULL,NULL,1,'/appstore/operation/recharge-amounts','#FF6348','M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z','','2026-07-11 16:19:02','2026-07-12 19:36:15'),
(67,6,'SubmissionReview','/appstore/review','/appstore/review','','投稿审核','ri:audit-line',7,0,0,1,0,'[{\"title\":\"审核\",\"authMark\":\"edit\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/review-mobile','#FACC15','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z','','2026-07-11 16:19:02','2026-07-11 16:19:02'),
(68,54,'存储文件','/system/storage-files','/system/storage-files','','存储文件','ri:hard-drive-3-line',4,0,0,1,0,'[{\"title\":\"删除\",\"authMark\":\"delete\"},{\"title\":\"下载\",\"authMark\":\"download\"}]','[\"R_SUPER\",\"R_ADMIN\"]',1,'/appstore/storage-files','#818CF8','M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z','','2026-07-11 17:31:24','2026-07-12 16:09:23'),
(69,6,'TopicManage','/appstore/topic-manage','','','话题管理','',11,0,0,1,0,'[{\"title\":\"新增\",\"authMark\":\"add\"},{\"title\":\"编辑\",\"authMark\":\"edit\"},{\"title\":\"删除\",\"authMark\":\"delete\"}]',NULL,1,'/appstore/topic-manage','#F472B6','M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7V9zm8 0h2v2h-2V9zm-4 0h2v2h-2V9z','','2026-07-12 15:58:19','2026-07-12 15:58:19'),
(70,0,'配置管理','/arccg','','','配置管理','',4,0,0,1,0,NULL,NULL,1,'','#4ECDC4','','','2026-07-12 19:26:16','2026-07-12 19:33:09'),
(72,70,'SmsConfig','/appstore/sms-config','','','短信配置','ri:message-2-line',2,0,0,0,0,NULL,NULL,1,'/appstore/sms-config','#FDBA74','M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7V9zm4 0h2v2h-2V9zm4 0h2v2h-2V9z','','2026-07-12 19:45:16','2026-07-12 19:45:16'),
(73,70,'SiteConfig','/appstore/site-config','','','站点配置','ri:global-line',1,0,0,0,0,NULL,NULL,1,'/appstore/site-config','#D946EF','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z','','2026-07-12 19:47:09','2026-07-12 19:47:09'),
(74,6,'PostReview','/appstore/post-review','/appstore/admin/post-review','','帖子审核','',13,0,0,1,0,NULL,'R_SUPER,R_ADMIN',1,'/appstore/post-review','#4ECDC4',NULL,'','2026-07-13 12:03:04','2026-07-13 12:03:04'),
(75,6,'TagManage','/appstore/tag-manage','','','标签管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/tag-manage','#8B5CF6','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z\"/></svg>','社区管理','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(76,1,'AnalyticsDashboard','/appstore/analytics-dashboard','','','数据分析','',0,0,0,1,0,NULL,NULL,1,'/appstore/analytics-dashboard','#10B981','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z\"/></svg>','仪表盘','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(77,6,'ModeratorApplications','/appstore/moderator-applications','','','版主申请审核','',0,0,0,1,0,NULL,NULL,1,'/appstore/moderator-applications','#F59E0B','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(78,6,'AppealManage','/appstore/appeal-manage','','','举报申诉处理','',0,0,0,1,0,NULL,NULL,1,'/appstore/appeal-manage','#5352ED','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(79,6,'SensitiveWords','/appstore/sensitive-words','','','敏感词管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/sensitive-words','#FACC15','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(80,6,'UnlockRequests','/appstore/unlock-requests','','','解锁申请管理','',0,0,0,1,0,NULL,NULL,1,'/appstore/unlock-requests','#4ECDC4','<svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2z\"/></svg>','审核中心','2026-07-16 19:39:03','2026-07-16 19:39:03'),
(82,70,'OauthConfig','/appstore/oauth-config','','','OAuth登录配置','oauth',9,0,0,1,0,NULL,NULL,1,'/appstore/oauth-config','#9C27B0','<svg width=\"22\" height=\"22\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"white\" stroke-width=\"2\"><path d=\"M15 7h2a5 5 0 010 10h-2m-6 0H7A5 5 0 017 7h2\"/></svg>','auth','2026-07-16 23:35:47','2026-07-16 23:35:47'),
(83,56,'物流配置','','','','物流配置','',11,0,0,1,0,NULL,NULL,1,'/appstore/logistics-config','#FF5722',NULL,'','2026-07-17 15:43:45','2026-07-17 15:43:45'),
(84,70,'IpServiceConfig','','','','IP定位配置','',10,0,0,1,0,NULL,NULL,1,'/appstore/ip-service-config','#4ECDC4','M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z','','2026-07-18 03:40:34','2026-07-18 03:40:34'),
(85,2,'ComplianceSettings','compliance','/appstore/compliance-settings','','合规设置','',16,0,0,1,0,'[{\"title\":\"编辑\",\"authMark\":\"edit\"}]',NULL,1,'/appstore/compliance-settings','#10B981','M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z','','2026-07-19 03:34:19','2026-07-19 03:34:19'),
(86,6,'合集管理','/appstore/admin/collections','','','应用合集管理','/appstore/admin/collections',45,0,0,1,0,NULL,NULL,1,'/appstore/admin/collections','#F59E0B',NULL,'应用管理','2026-07-19 14:37:47','2026-07-19 14:37:47');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moderation_log`
--

DROP TABLE IF EXISTS `moderation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moderation_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_type` varchar(20) NOT NULL COMMENT 'post/comment/app/product',
  `target_id` int(11) NOT NULL DEFAULT 0,
  `action` varchar(20) NOT NULL COMMENT 'auto_approve/auto_reject/auto_pending/auto_hide/auto_warn/manual_approve/manual_reject',
  `reason` text DEFAULT NULL,
  `rule_name` varchar(100) DEFAULT NULL,
  `moderator_type` varchar(50) DEFAULT NULL COMMENT 'sensitive_word/rule_engine/quality_score/level_check/report_threshold',
  `old_status` varchar(50) DEFAULT '',
  `new_status` varchar(50) DEFAULT '',
  `details` text DEFAULT NULL COMMENT 'JSON扩展信息',
  `operator_id` int(11) DEFAULT NULL COMMENT 'NULL=自动审核,>0=人工操作',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_target` (`target_type`,`target_id`),
  KEY `idx_time` (`create_time`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moderation_log`
--

LOCK TABLES `moderation_log` WRITE;
/*!40000 ALTER TABLE `moderation_log` DISABLE KEYS */;
INSERT INTO `moderation_log` VALUES
(1,'post',0,'auto_pending','用户等级Lv.1，内容需人工审核','level_threshold','level_check','','pending','{\"userLevel\":1,\"targetType\":\"post\"}',NULL,'2026-07-20 20:39:31'),
(2,'post',0,'auto_pending','用户等级Lv.1，内容需人工审核','level_threshold','level_check','','pending','{\"userLevel\":1,\"targetType\":\"post\"}',NULL,'2026-07-20 20:46:04'),
(3,'post',0,'auto_reject','内容不符合社区规范','内容包含短链接: bit.ly','rule_engine','','blocked','{\"passed\":false,\"blocked\":true,\"results\":[{\"name\":\"short_url_block\",\"reason\":\"内容包含短链接: bit.ly\",\"action\":\"block\"}],\"reason\":\"内容包含短链接: bit.ly\"}',NULL,'2026-07-20 20:48:18'),
(4,'post',0,'auto_pending','用户等级Lv.1，内容需人工审核','level_threshold','level_check','','pending','{\"userLevel\":1,\"targetType\":\"post\"}',NULL,'2026-07-20 20:48:18'),
(5,'post',51,'manual_reject','测试驳回原因','manual_review','manual','pending','rejected',NULL,1,'2026-07-21 00:13:38'),
(6,'post',53,'manual_approve','审核通过','manual_review','manual','pending','published',NULL,1,'2026-07-21 00:14:02'),
(7,'post',54,'manual_reject','测试单帖驳回','manual_review','manual','pending','rejected',NULL,1,'2026-07-21 00:14:02'),
(8,'post',0,'auto_pending','内容质量评分23/75，低于标准','quality_threshold','quality_score','','pending','{\"totalScore\":23,\"maxScore\":75,\"rate\":0.30666666666666664,\"verdict\":\"pending\",\"label\":\"较差\",\"details\":{\"textLength\":{\"score\":0,\"max\":20},\"images\":{\"score\":0,\"max\":15},\"layout\":{\"score\":5,\"max\":15},\"links\":{\"score\":5,\"max\":5},\"title\":{\"score\":10,\"max\":10},\"level\":{\"score\":3,\"max\":10}}}',NULL,'2026-07-21 00:14:32'),
(9,'post',55,'manual_approve','审核通过','manual_review','manual','pending','published',NULL,1,'2026-07-21 00:14:46');
/*!40000 ALTER TABLE `moderation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moderation_rules`
--

DROP TABLE IF EXISTS `moderation_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moderation_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `target_type` varchar(20) NOT NULL DEFAULT 'post' COMMENT 'post/comment/app/product',
  `action` varchar(20) NOT NULL DEFAULT 'pending' COMMENT 'block/pending/warn',
  `config` text DEFAULT NULL COMMENT 'JSON参数配置',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `priority` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moderation_rules`
--

LOCK TABLES `moderation_rules` WRITE;
/*!40000 ALTER TABLE `moderation_rules` DISABLE KEYS */;
INSERT INTO `moderation_rules` VALUES
(28,'post_rate_limit','发帖频率限制','post','pending','{\"maxCount\":5,\"windowMinutes\":5}',1,1,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(29,'comment_rate_limit','评论频率限制','comment','pending','{\"maxCount\":10,\"windowMinutes\":1}',1,2,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(30,'new_user_daily_limit','新用户发帖上限','post','pending','{\"maxCount\":5}',1,3,'2026-07-20 18:52:22','2026-07-20 19:13:15'),
(31,'short_url_block','短链接检测','post','block','{}',1,4,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(32,'short_url_comment','短链接检测','comment','block','{}',1,5,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(33,'external_links_max','外链数量上限','post','pending','{\"maxLinks\":2}',1,6,'2026-07-20 18:52:22','2026-07-20 19:13:15'),
(34,'repetitive_chars','重复字符刷屏','post','block','{\"minLength\":10}',1,7,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(35,'repetitive_comment','重复字符刷屏','comment','block','{\"minLength\":10}',1,8,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(36,'phone_qq_pattern','联系方式检测','post','pending','{}',1,9,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(37,'phone_qq_comment','联系方式检测','comment','pending','{}',1,10,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(38,'emoji_bombing','表情刷屏检测','post','pending','{\"maxEmoji\":15}',1,11,'2026-07-20 18:52:22','2026-07-20 19:13:15'),
(39,'emoji_comment','表情刷屏检测','comment','pending','{\"maxEmoji\":10}',1,12,'2026-07-20 18:52:22','2026-07-20 19:13:15'),
(40,'min_content_length','最小内容长度','post','pending','{\"minLength\":10}',1,13,'2026-07-20 18:52:22','2026-07-20 19:13:15'),
(41,'min_comment_length','最小内容长度','comment','pending','{\"minLength\":2}',1,14,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(42,'content_similarity','内容相似度检测','post','pending','{\"threshold\":0.85}',1,15,'2026-07-20 18:52:22','2026-07-20 18:52:22'),
(43,'sockpuppet_detection','马甲号检测','post','pending','{\"maxAccounts\":2}',1,16,'2026-07-20 18:52:22','2026-07-20 19:13:15');
/*!40000 ALTER TABLE `moderation_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moderator_applications`
--

DROP TABLE IF EXISTS `moderator_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moderator_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `user_avatar` varchar(500) DEFAULT '',
  `reason` text DEFAULT '',
  `desired_role` varchar(50) DEFAULT '版主',
  `status` varchar(20) DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `review_comment` text DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moderator_applications`
--

LOCK TABLES `moderator_applications` WRITE;
/*!40000 ALTER TABLE `moderator_applications` DISABLE KEYS */;
INSERT INTO `moderator_applications` VALUES
(7,1,1,'bobwang','','我热爱综合讨论板块','版主','pending',0,'','','2026-07-14 14:00:13',NULL),
(8,3,1,'bobwang','','我是设计师','版主','pending',0,'','','2026-07-14 14:00:13',NULL),
(9,1,2,'lisa_chen','','常年在综合讨论活跃','版主','approved',19,'alexmorgan','','2026-07-14 14:00:20','2026-07-15 19:31:36'),
(10,3,2,'lisa_chen','','从事设计工作多年','审核员','pending',0,'','','2026-07-14 14:00:20',NULL),
(11,1,10001,'35735712','','6666','版主','approved',19,'alexmorgan','','2026-07-16 17:06:35','2026-07-16 17:07:01');
/*!40000 ALTER TABLE `moderator_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_accounts`
--

DROP TABLE IF EXISTS `oauth_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `provider_user_id` varchar(200) NOT NULL,
  `access_token` text DEFAULT NULL,
  `refresh_token` varchar(500) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_user` (`provider`,`provider_user_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_accounts`
--

LOCK TABLES `oauth_accounts` WRITE;
/*!40000 ALTER TABLE `oauth_accounts` DISABLE KEYS */;
INSERT INTO `oauth_accounts` VALUES
(1,10002,'github','mock-github-1784229998022','mock_token_1784229998102',NULL,NULL,'2026-07-16 19:26:38'),
(2,1,'github','mock-github-bind-1784230207655','mock_token_1784230207656',NULL,NULL,'2026-07-16 19:30:07');
/*!40000 ALTER TABLE `oauth_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(100) DEFAULT '',
  `seller_id` int(11) DEFAULT 0,
  `seller_name` varchar(100) DEFAULT '',
  `order_type` varchar(30) NOT NULL,
  `order_desc` varchar(500) DEFAULT '',
  `ref_id` int(11) DEFAULT 0,
  `ref_table` varchar(50) DEFAULT '',
  `pay_type` varchar(20) DEFAULT 'balance',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `coupon_id` int(11) DEFAULT 0,
  `coupon_discount` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) DEFAULT 'shipped',
  `confirm_days` int(11) DEFAULT 7,
  `confirm_deadline` datetime DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `refund_reason` varchar(500) DEFAULT '',
  `refund_requested_at` datetime DEFAULT NULL,
  `refund_responded_at` datetime DEFAULT NULL,
  `refund_reviewed_by` int(11) DEFAULT 0,
  `refund_reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_orders_buyer` (`buyer_id`),
  KEY `idx_orders_seller` (`seller_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_no` (`order_no`),
  KEY `idx_orders_ctime` (`create_time`),
  KEY `idx_orders_buyer_time` (`buyer_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,'ORD17837231940',2,'',0,'','purchase','',0,'','balance',92.69,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-02 22:39:54'),
(2,'ORD17837231941',2,'',0,'','purchase','',0,'','balance',191.11,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-24 22:39:54'),
(3,'ORD17837231942',11,'',0,'','purchase','',0,'','balance',112.15,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-17 22:39:54'),
(4,'ORD17837231943',10,'',0,'','purchase','',0,'','balance',210.01,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(5,'ORD17837231944',7,'',0,'','purchase','',0,'','balance',213.23,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-27 22:39:54'),
(6,'ORD17837231945',4,'',0,'','purchase','',0,'','balance',84.35,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-10 22:39:54'),
(7,'ORD17837231946',11,'',0,'','purchase','',0,'','balance',20.66,0,0.00,0.00,'completed',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-28 22:39:54'),
(8,'ORD17837231947',4,'',0,'','purchase','',0,'','balance',88.74,0,0.00,0.00,'cancelled',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-07-05 22:39:54'),
(9,'ORD17837231948',7,'',0,'','purchase','',0,'','balance',137.37,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-29 22:39:54'),
(10,'ORD17837231949',13,'',0,'','purchase','',0,'','balance',125.98,0,0.00,0.00,'paid',7,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,'2026-06-13 22:39:54'),
(11,'MOMRG56M0YZHEW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-18 09:08:18','2026-07-11 09:08:18','2026-07-11 09:15:07','',NULL,NULL,0,'',NULL,'2026-07-11 09:08:18'),
(12,'MOMRG5EOSU5FWW',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:35','2026-07-11 09:14:35','2026-07-11 09:15:06','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:35'),
(13,'MOMRG5ER54XYLJ',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 09:14:38','2026-07-11 09:14:38','2026-07-11 09:15:03','',NULL,NULL,0,'',NULL,'2026-07-11 09:14:38'),
(14,'MOMRGTSGBB9TLF',1,'bobwang',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:37:08','2026-07-11 20:37:08','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:37:08'),
(15,'MOMRGTUCDK3DNE',4,'design_master',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:38:36','2026-07-11 20:38:36','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:38:36'),
(16,'MOMRGTUU7OFOKT',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:38:59','2026-07-11 20:38:59','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:38:59'),
(17,'MOMRGTV0LR3ZZX',20,'testgift',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:39:07','2026-07-11 20:39:07','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:39:07'),
(18,'MOMRGU8MPOFVJ9',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:49:43','2026-07-11 20:49:43','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:49:43'),
(19,'MOMRGU8UU8DEZE',21,'testcoupon',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 20:49:53','2026-07-11 20:49:53','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 20:49:53'),
(20,'MOMRGUVIXAUQ35',22,'titletest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 21:07:31','2026-07-11 21:07:31','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 21:07:31'),
(21,'MOMRGUWL8VTG0N',23,'birthdaytest',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-18 21:08:21','2026-07-11 21:08:21','2026-07-18 21:19:01','',NULL,NULL,0,'',NULL,'2026-07-11 21:08:21'),
(22,'MOMRH1FPH8CYRU',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,5.00,'completed',7,'2026-07-19 00:11:10','2026-07-12 00:11:10','2026-07-19 00:12:00','',NULL,NULL,0,'',NULL,'2026-07-12 00:11:10'),
(23,'MOMRHNOPT1BP3Y',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 10:34:02','2026-07-12 10:34:02','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:34:02'),
(24,'MOMRHNP8O871VF',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 10:34:26','2026-07-12 10:34:26','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:34:26'),
(25,'MOMRHNQHBI7TA1',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 10:35:24','2026-07-12 10:35:24','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:35:24'),
(26,'MOMRHNQTEIBRRW',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 10:35:40','2026-07-12 10:35:40','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:35:40'),
(27,'MOMRHNSZUORY40',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 10:37:22','2026-07-12 10:37:22','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:37:22'),
(28,'MOMRHNTAEM554M',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 10:37:35','2026-07-12 10:37:35','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:37:35'),
(29,'MOMRHNTJQ5PTC0',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 10:37:47','2026-07-12 10:37:47','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:37:47'),
(30,'MOMRHNTOL2KPIM',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 10:37:54','2026-07-12 10:37:54','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 10:37:54'),
(31,'MOMRHP2LPAVFWE',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 11:12:50','2026-07-12 11:12:50','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:12:50'),
(32,'MOMRHP2S49AVSK',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 11:12:58','2026-07-12 11:12:58','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:12:58'),
(33,'MOMRHP2XIQK75T',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 11:13:05','2026-07-12 11:13:05','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:13:05'),
(34,'MOMRHP302FHLAF',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:13:08','2026-07-12 11:13:08','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:13:08'),
(35,'MOMRHP33KY17I4',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:13:13','2026-07-12 11:13:13','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:13:13'),
(36,'MOMRHP65DTVO12',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:15:35','2026-07-12 11:15:35','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:15:35'),
(37,'MOMRHP67OWPQL2',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 11:15:38','2026-07-12 11:15:38','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:15:38'),
(38,'MOMRHP69HOG7MF',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 11:15:40','2026-07-12 11:15:40','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:15:40'),
(39,'MOMRHP8QGMVXWY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:17:36','2026-07-12 11:17:36','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:17:36'),
(40,'MOMRHP8S58R2CJ',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:17:38','2026-07-12 11:17:38','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:17:38'),
(41,'MOMRHP8TR60BFI',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:17:40','2026-07-12 11:17:40','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:17:40'),
(42,'MOMRHP8X9W5EWQ',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:17:44','2026-07-12 11:17:44','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:17:44'),
(43,'MOMRHP8Z17FW6R',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 11:17:47','2026-07-12 11:17:47','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:17:47'),
(44,'MOMRHPD5JRIXA8',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 11:21:02','2026-07-12 11:21:02','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:21:02'),
(45,'MOMRHPD9MV9MBY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 11:21:07','2026-07-12 11:21:07','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:21:07'),
(46,'MOMRHPDDTLU8TH',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 11:21:13','2026-07-12 11:21:13','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:21:13'),
(47,'MOMRHPDFZDSAY5',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 11:21:15','2026-07-12 11:21:15','2026-07-20 14:56:45','',NULL,NULL,0,'',NULL,'2026-07-12 11:21:15'),
(48,'MOMRI143C113BA',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:49:54','2026-07-12 16:49:54','2026-07-12 23:02:42','',NULL,NULL,0,'',NULL,'2026-07-12 16:49:54'),
(49,'MOMRI14A59QD2E',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:50:03','2026-07-12 16:50:03','2026-07-12 23:03:13','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:03'),
(50,'MOMRI14D3E5D8T',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 16:50:07','2026-07-12 16:50:07','2026-07-12 23:03:12','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:07'),
(51,'MOMRI14FOWY5S0',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-19 16:50:10','2026-07-12 16:50:10','2026-07-12 23:03:11','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:10'),
(52,'MOMRI14IZ91WT3',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','points',1300.00,0,0.00,1300.00,'completed',7,'2026-07-19 16:50:15','2026-07-12 16:50:15','2026-07-12 23:03:09','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:15'),
(53,'MOMRI14MMP09TW',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:19','2026-07-12 16:50:19','2026-07-12 23:03:07','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:19'),
(54,'MOMRI14OMHNEKT',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:22','2026-07-12 16:50:22','2026-07-12 23:03:06','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:22'),
(55,'MOMRI14QW812AM',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 16:50:25','2026-07-12 16:50:25','2026-07-12 23:03:05','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:25'),
(56,'MOMRI14T94C1GY',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 16:50:28','2026-07-12 16:50:28','2026-07-12 23:03:04','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:28'),
(57,'MOMRI14UR0XW2W',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:50:30','2026-07-12 16:50:30','2026-07-12 23:03:03','',NULL,NULL,0,'',NULL,'2026-07-12 16:50:30'),
(58,'MOMRI16D90DUTD',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:51:41','2026-07-12 16:51:41','2026-07-12 23:03:01','',NULL,NULL,0,'',NULL,'2026-07-12 16:51:41'),
(59,'MOMRI171K2B8KL',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 16:52:12','2026-07-12 16:52:12','2026-07-12 23:03:00','',NULL,NULL,0,'',NULL,'2026-07-12 16:52:12'),
(60,'MOMRI97BPRB96F',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'completed',7,'2026-07-19 20:36:22','2026-07-12 20:36:22','2026-07-12 23:02:58','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:22'),
(61,'MOMRI97PMMFRT5',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 20:36:40','2026-07-12 20:36:40','2026-07-12 23:02:57','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:40'),
(62,'MOMRI97VVZ1PWE',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'completed',7,'2026-07-19 20:36:48','2026-07-12 20:36:48','2026-07-12 23:02:55','',NULL,NULL,0,'',NULL,'2026-07-12 20:36:48'),
(63,'MOMRI9JPVJM0UU',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 20:46:00','2026-07-12 20:46:00','2026-07-12 23:02:53','',NULL,NULL,0,'',NULL,'2026-07-12 20:46:00'),
(64,'MOMRI9MBX4B32A',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','points',5800.00,0,0.00,5800.00,'completed',7,'2026-07-19 20:48:02','2026-07-12 20:48:02','2026-07-12 23:02:52','',NULL,NULL,0,'',NULL,'2026-07-12 20:48:02'),
(65,'MOMRICWHA7TE0E',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',20.00,0,0.00,20.00,'completed',7,'2026-07-19 22:19:55','2026-07-12 22:19:55','2026-07-12 23:02:50','',NULL,NULL,0,'',NULL,'2026-07-12 22:19:55'),
(66,'MOMRIECPK672BU',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'completed',7,'2026-07-19 23:00:31','2026-07-12 23:00:31','2026-07-12 23:02:47','',NULL,NULL,0,'',NULL,'2026-07-12 23:00:31'),
(67,'MOMRIEDD7NKYBL',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'completed',7,'2026-07-19 23:01:02','2026-07-12 23:01:02','2026-07-12 23:02:46','',NULL,NULL,0,'',NULL,'2026-07-12 23:01:02'),
(68,'COMRLKODKV6MAT',1,'bobwang',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','balance',5.00,0,0.00,4.50,'shipped',7,'2026-07-22 04:20:52','2026-07-15 04:20:52',NULL,'',NULL,NULL,0,'',NULL,'2026-07-15 04:20:52'),
(69,'COMRLKOLQLDJCU',1,'bobwang',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','points',100.00,0,0.00,100.00,'shipped',7,'2026-07-22 04:21:03','2026-07-15 04:21:03',NULL,'',NULL,NULL,0,'',NULL,'2026-07-15 04:21:03'),
(70,'COMRMREE3QBMMQ',10001,'35735712',19,'','content_purchase','购买应用《666》',22,'post','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-23 00:16:50','2026-07-16 00:16:50',NULL,'',NULL,NULL,0,'',NULL,'2026-07-16 00:16:50'),
(71,'COMRMRFDXBU556',10001,'35735712',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','points',100.00,0,0.00,100.00,'completed',7,'2026-07-23 00:17:36','2026-07-16 00:17:36','2026-07-16 00:19:39','',NULL,NULL,0,'',NULL,'2026-07-16 00:17:36'),
(72,'COMRMRFKWLZFRF',10001,'35735712',19,'','content_purchase','购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》',21,'post','balance',5.00,0,0.00,5.00,'completed',7,'2026-07-23 00:17:45','2026-07-16 00:17:45','2026-07-16 00:19:36','',NULL,NULL,0,'',NULL,'2026-07-16 00:17:45'),
(73,'COMRNOILPE4LIR',10001,'35735712',19,'','content_purchase','购买应用《【付费解锁测试】精品设计教程 - 从入门到精通》',23,'post','balance',8.88,0,0.00,8.88,'shipped',7,'2026-07-23 15:43:53','2026-07-16 15:43:53',NULL,'',NULL,NULL,0,'',NULL,'2026-07-16 15:43:53'),
(74,'MOMRPCB5D7VXKP',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-24 19:37:43','2026-07-17 19:37:43',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:43'),
(75,'MOMRPCB7YPX1WG',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:46','2026-07-17 19:37:46',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:46'),
(76,'MOMRPCBB0LHJZM',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:50','2026-07-17 19:37:50',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:50'),
(77,'MOMRPCBGC7PQYJ',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:37:57','2026-07-17 19:37:57',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:37:57'),
(78,'MOMRPCBKJ1PIW6',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:38:02','2026-07-17 19:38:02',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:38:02'),
(79,'MOMRPCBM80JQSG',19,'alexmorgan',0,'','membership','购买至尊会员',0,'','balance',48.00,0,0.00,48.00,'shipped',7,'2026-07-24 19:38:04','2026-07-17 19:38:04',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:38:04'),
(80,'MOMRPCI5IP95BS',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:09','2026-07-17 19:43:09',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:09'),
(81,'MOMRPCIA5NJQBB',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:15','2026-07-17 19:43:15',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:15'),
(82,'MOMRPCICWFJUQO',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-24 19:43:19','2026-07-17 19:43:19',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:19'),
(83,'MOMRPCIFZIUACF',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:23','2026-07-17 19:43:23',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:23'),
(84,'MOMRPCIIRCZ46L',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:27','2026-07-17 19:43:27',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:27'),
(85,'MOMRPCIN6G5QO3',19,'alexmorgan',0,'','membership','购买钻石会员',0,'','balance',15.00,0,0.00,15.00,'shipped',7,'2026-07-24 19:43:32','2026-07-17 19:43:32',NULL,'',NULL,NULL,0,'',NULL,'2026-07-17 19:43:32'),
(86,'MOMRRA2FDE8IKS',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-26 04:10:29','2026-07-19 04:10:29',NULL,'',NULL,NULL,0,'',NULL,'2026-07-19 04:10:29'),
(87,'MOMRTWUEVR3PHQ',19,'alexmorgan',0,'','membership','购买黄金会员',0,'','balance',10.00,0,0.00,10.00,'shipped',7,'2026-07-28 00:23:38','2026-07-21 00:23:38',NULL,'',NULL,NULL,0,'',NULL,'2026-07-21 00:23:38'),
(88,'TR1EA0588ADF368C5BF2237AC6C6B0CABF',1,'bobwang',2,'lisa_chen','transfer_points','积分测试',0,'','points',100.00,0,0.00,100.00,'shipped',7,'2026-07-28 16:06:58','2026-07-21 16:06:58',NULL,'',NULL,NULL,0,'',NULL,'2026-07-21 16:06:58'),
(89,'TR070FAC4A127428A0D4ADBA8E7C0375E2',2,'lisa_chen',1,'bobwang','transfer_balance','余额转账',0,'','balance',50.00,0,0.00,50.00,'shipped',7,'2026-07-28 16:06:58','2026-07-21 16:06:58',NULL,'',NULL,NULL,0,'',NULL,'2026-07-21 16:06:58');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `version` varchar(50) DEFAULT '1.0.0',
  `author` varchar(100) DEFAULT '',
  `icon` varchar(500) DEFAULT '',
  `entry_url` varchar(500) DEFAULT '',
  `component_name` varchar(200) DEFAULT '',
  `plugin_dir` varchar(100) DEFAULT '',
  `manifest` text DEFAULT NULL,
  `enabled` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `points_name` varchar(20) DEFAULT '金币',
  `tags` text DEFAULT NULL,
  `format` varchar(20) DEFAULT 'package',
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES
(1,'SEO优化','内置SEO优化工具','1.0.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(2,'数据统计','网站数据统计分析','1.2.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(3,'广告管理','广告位管理插件','0.9.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(4,'第三方登录','支持微信/QQ/微博登录','2.0.1','','','','','',NULL,0,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(5,'地图组件','集成高德地图组件','1.1.0','','','','','',NULL,1,0,0,'金币',NULL,'package','1','2026-07-10 22:39:54'),
(6,'feature-panel','应用商店浏览页功能入口面板','1.0.0','Admin','','','','feature-panel','{\"name\":\"feature-panel\",\"version\":\"1.0.0\",\"description\":\"应用商店浏览页功能入口面板\",\"author\":\"Admin\",\"styles\":[\"styles/panel.css\"],\"scripts\":[\"scripts/panel.js\"],\"config\":{\"cardShow\":true,\"items\":[{\"label\":\"签到\",\"icon\":\"checkin\",\"color\":\"#FF6B35\",\"url\":\"/app/checkin\",\"show\":true},{\"label\":\"投稿\",\"icon\":\"submit\",\"color\":\"#3B82F6\",\"url\":\"/appstore/submissions\",\"show\":true},{\"label\":\"收藏\",\"icon\":\"fav\",\"color\":\"#EF4444\",\"url\":\"/appstore/favorites\",\"show\":true},{\"label\":\"排行\",\"icon\":\"rank\",\"color\":\"#EC4899\",\"url\":\"/appstore/category\",\"show\":true},{\"label\":\"交流群\",\"icon\":\"group\",\"color\":\"#22C55E\",\"url\":\"/community\",\"show\":true}],\"links\":[{\"label\":\"新贴\",\"url\":\"/community\",\"show\":true},{\"label\":\"发帖子\",\"url\":\"/community/create\",\"show\":true},{\"label\":\"热门话题\",\"url\":\"/community/hot\",\"show\":true}],\"banner\":{\"show\":true,\"text\":\"新手必看教程——发帖指引之基础篇\",\"url\":\"/help/guide\",\"closable\":true},\"mineBanner\":{\"show\":true,\"text\":\"全站规则，快来看看，不然就亏大了\",\"url\":\"https://monkeycode-ai.com/?ic=019f2c74-4064-7d7c-9003-743ce2df5af9\",\"closable\":false}},\"configMeta\":{\"cardShow\":{\"label\":\"图标卡片显示\"},\"items\":{\"label\":\"图标按钮\",\"itemMeta\":{\"label\":{\"label\":\"名称\"},\"icon\":{\"label\":\"图标\"},\"color\":{\"label\":\"颜色\"},\"url\":{\"label\":\"链接\"},\"show\":{\"label\":\"显示\"}}},\"links\":{\"label\":\"底部链接\",\"itemMeta\":{\"label\":{\"label\":\"文字\"},\"url\":{\"label\":\"链接\"},\"show\":{\"label\":\"显示\"}}},\"banner\":{\"label\":\"公告横幅\",\"childrenMeta\":{\"show\":{\"label\":\"显示\"},\"text\":{\"label\":\"文案\"},\"url\":{\"label\":\"链接\"},\"closable\":{\"label\":\"可关闭\"}}}}}',1,0,0,'金币',NULL,'package','1','2026-07-12 14:52:09');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_records`
--

DROP TABLE IF EXISTS `points_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'earn',
  `points` int(11) NOT NULL DEFAULT 0,
  `balance` int(11) DEFAULT 0,
  `source` varchar(200) DEFAULT '',
  `description` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `ref_id` int(11) DEFAULT 0,
  `ref_type` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_points_records_user_id` (`user_id`),
  KEY `idx_points_records_type` (`type`),
  KEY `idx_points_records_ctime` (`create_time`),
  KEY `idx_points_records_user_time` (`user_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_records`
--

LOCK TABLES `points_records` WRITE;
/*!40000 ALTER TABLE `points_records` DISABLE KEYS */;
INSERT INTO `points_records` VALUES
(1,13,'','checkin',53,0,'','获得积分 +53','2026-06-22 22:39:54',0,''),
(2,5,'','post',14,0,'','获得积分 +14','2026-06-11 22:39:54',0,''),
(3,13,'','comment',43,0,'','获得积分 +43','2026-07-08 22:39:54',0,''),
(4,8,'','invite',11,0,'','获得积分 +11','2026-07-08 22:39:54',0,''),
(5,15,'','purchase',21,0,'','获得积分 +21','2026-06-21 22:39:54',0,''),
(6,12,'','checkin',55,0,'','获得积分 +55','2026-06-11 22:39:54',0,''),
(7,15,'','post',11,0,'','获得积分 +11','2026-06-29 22:39:54',0,''),
(8,2,'','comment',19,0,'','获得积分 +19','2026-07-05 22:39:54',0,''),
(9,15,'','invite',23,0,'','获得积分 +23','2026-06-22 22:39:54',0,''),
(10,10,'','purchase',55,0,'','获得积分 +55','2026-07-10 22:39:54',0,''),
(11,15,'','checkin',34,0,'','获得积分 +34','2026-06-28 22:39:54',0,''),
(12,5,'','post',55,0,'','获得积分 +55','2026-06-12 22:39:54',0,''),
(13,5,'','comment',43,0,'','获得积分 +43','2026-06-13 22:39:54',0,''),
(14,10,'','invite',14,0,'','获得积分 +14','2026-06-19 22:39:54',0,''),
(15,11,'','purchase',47,0,'','获得积分 +47','2026-06-13 22:39:54',0,''),
(16,7,'','checkin',34,0,'','获得积分 +34','2026-06-23 22:39:54',0,''),
(17,2,'','post',22,0,'','获得积分 +22','2026-06-19 22:39:54',0,''),
(18,6,'','comment',11,0,'','获得积分 +11','2026-06-24 22:39:54',0,''),
(19,15,'','invite',12,0,'','获得积分 +12','2026-06-25 22:39:54',0,''),
(20,14,'','purchase',23,0,'','获得积分 +23','2026-06-26 22:39:54',0,''),
(21,3,'','checkin',15,0,'','获得积分 +15','2026-06-16 22:39:54',0,''),
(22,8,'','post',24,0,'','获得积分 +24','2026-06-14 22:39:54',0,''),
(23,6,'','comment',13,0,'','获得积分 +13','2026-06-19 22:39:54',0,''),
(24,13,'','invite',13,0,'','获得积分 +13','2026-07-01 22:39:54',0,''),
(25,4,'','purchase',19,0,'','获得积分 +19','2026-06-18 22:39:54',0,''),
(26,5,'','checkin',22,0,'','获得积分 +22','2026-07-04 22:39:54',0,''),
(27,12,'','post',44,0,'','获得积分 +44','2026-06-17 22:39:54',0,''),
(28,13,'','comment',44,0,'','获得积分 +44','2026-07-01 22:39:54',0,''),
(29,4,'','invite',53,0,'','获得积分 +53','2026-07-01 22:39:54',0,''),
(30,15,'','purchase',27,0,'','获得积分 +27','2026-06-22 22:39:54',0,''),
(31,19,'alexmorgan','earn',99999,99999,'卡密兑换','使用卡密 CDKEY-MRG47L1VS1EE 额外获得99999积分','2026-07-11 08:41:23',0,''),
(32,19,'alexmorgan','expense',1300,98699,'会员购买','购买黄金会员','2026-07-11 09:04:46',0,''),
(33,19,'alexmorgan','expense',1300,97399,'会员购买','购买黄金会员','2026-07-11 09:08:18',0,''),
(34,1,'bobwang','earn',50,1550,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:37:08',0,''),
(35,4,'design_master','earn',50,350,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:38:36',0,''),
(38,21,'testcoupon','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:43',0,''),
(39,21,'testcoupon','earn',50,700,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 20:49:53',0,''),
(40,22,'titletest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:07:31',0,''),
(41,23,'birthdaytest','earn',150,650,'会员开通赠送','开通黄金会员赠送积分','2026-07-11 21:08:20',0,''),
(42,19,'alexmorgan','earn',50,96819,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 00:11:10',0,''),
(43,19,'alexmorgan','earn',320,97139,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:34:02',0,''),
(44,19,'alexmorgan','earn',120,97259,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:34:26',0,''),
(45,19,'alexmorgan','earn',120,97379,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 10:35:40',0,''),
(46,19,'alexmorgan','earn',50,97429,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 10:37:22',0,''),
(47,19,'alexmorgan','earn',50,97479,'会员开通赠送','开通黄金会员赠送积分','2026-07-12 10:37:47',0,''),
(48,19,'alexmorgan','earn',10,97489,'每日签到','连续签到第1天','2026-07-12 11:19:10',0,''),
(49,19,'alexmorgan','expense',5800,91689,'会员购买','购买至尊会员','2026-07-12 11:21:02',0,''),
(50,19,'alexmorgan','earn',120,97609,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:02',0,''),
(51,19,'alexmorgan','expense',5800,86009,'会员购买','购买至尊会员','2026-07-12 11:21:07',0,''),
(52,19,'alexmorgan','earn',120,91929,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:07',0,''),
(53,19,'alexmorgan','expense',5800,80329,'会员购买','购买至尊会员','2026-07-12 11:21:13',0,''),
(54,19,'alexmorgan','earn',120,86249,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:13',0,''),
(55,19,'alexmorgan','earn',120,80569,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 11:21:15',0,''),
(56,1,'bobwang','earn',10,1560,'每日签到','连续签到第1天','2026-07-12 13:51:30',0,''),
(57,1,'bobwang','earn',10,1570,'每日签到','完成任务: 每日签到','2026-07-12 13:51:30',0,''),
(58,19,'alexmorgan','expense',1300,79269,'会员购买','购买黄金会员','2026-07-12 16:50:10',0,''),
(59,19,'alexmorgan','expense',1300,77969,'会员购买','购买黄金会员','2026-07-12 16:50:15',0,''),
(60,19,'alexmorgan','earn',120,78089,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:19',0,''),
(61,19,'alexmorgan','earn',120,78209,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:22',0,''),
(62,19,'alexmorgan','expense',5800,72409,'会员购买','购买至尊会员','2026-07-12 16:50:25',0,''),
(63,19,'alexmorgan','earn',120,78329,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:25',0,''),
(64,19,'alexmorgan','expense',5800,66729,'会员购买','购买至尊会员','2026-07-12 16:50:28',0,''),
(65,19,'alexmorgan','earn',120,72649,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:28',0,''),
(66,19,'alexmorgan','earn',120,66969,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:50:30',0,''),
(67,19,'alexmorgan','earn',120,67089,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:51:41',0,''),
(68,19,'alexmorgan','earn',120,67209,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 16:52:12',0,''),
(69,19,'','earn',30,67239,'完善资料','完成任务: 完善资料','2026-07-12 20:31:51',0,''),
(70,19,'alexmorgan','earn',100,67339,'会员开通赠送','开通钻石会员赠送积分','2026-07-12 20:36:22',0,''),
(71,19,'alexmorgan','earn',100,67439,'会员开通赠送','开通钻石会员赠送积分','2026-07-12 20:36:48',0,''),
(72,19,'alexmorgan','earn',120,67559,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 20:46:00',0,''),
(73,19,'alexmorgan','expense',5800,61759,'会员购买','购买至尊会员','2026-07-12 20:48:02',0,''),
(74,19,'alexmorgan','earn',120,67679,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 20:48:02',0,''),
(75,19,'alexmorgan','earn',5,61884,'评论互动','完成任务: 评论互动','2026-07-12 21:51:42',0,''),
(76,19,'alexmorgan','earn',120,62054,'会员开通赠送','开通至尊会员赠送积分','2026-07-12 23:01:02',0,''),
(77,19,'Alex Morgan','earn',20,63174,'发帖奖励','完成任务: 发帖奖励','2026-07-13 18:34:40',0,''),
(78,19,'','earn',30,63204,'完善资料','完成任务: 完善资料','2026-07-13 19:42:23',0,''),
(79,19,'Alex Morgan','earn',20,63224,'发帖奖励','完成任务: 发帖奖励','2026-07-15 04:17:41',0,''),
(80,1,'bobwang','expense',100,1450,'内容购买','购买帖子 #21','2026-07-15 04:21:03',0,''),
(81,19,'Alex Morgan','earn',5,63229,'评论互动','完成任务: 评论互动','2026-07-15 04:26:15',0,''),
(82,10001,'35735712','earn',10000,10000,'卡密兑换','使用卡密 CDKEY-MRMRD84EXRNR 额外获得10000积分','2026-07-16 00:16:12',0,''),
(83,10001,'user_10001','earn',5,10005,'评论互动','完成任务: 评论互动','2026-07-16 00:17:34',0,''),
(84,10001,'35735712','expense',100,9905,'内容购买','购买帖子 #21','2026-07-16 00:17:36',0,''),
(85,19,'alexmorgan','earn',300,63529,'content_purchase','订单结算(3.0倍积分): 购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》','2026-07-16 00:19:39',71,'order_settle'),
(86,19,'Alex Morgan','earn',20,63549,'发帖奖励','完成任务: 发帖奖励','2026-07-16 16:40:43',0,''),
(87,10004,'管理员','earn',5,5,'评论互动','完成任务: 评论互动','2026-07-17 02:15:18',0,''),
(88,19,'alexmorgan','expense',980,62569,'商城购物','购买商品《移动端组件库》','2026-07-17 15:37:47',0,''),
(92,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:39:28',0,''),
(93,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:39:50',0,''),
(94,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:42:55',0,''),
(95,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:47:26',0,''),
(96,10011,'promo_dual','expense',980,4020,'商城购物','购买商品《移动端组件库》','2026-07-17 18:47:59',0,''),
(97,19,'alexmorgan','earn',49,62530,'推广返佣','mall #36 返佣','2026-07-17 18:47:59',0,''),
(98,19,'alexmorgan','earn',120,62650,'会员开通赠送','开通至尊会员赠送积分','2026-07-17 19:37:43',0,''),
(99,19,'alexmorgan','earn',100,62750,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:46',0,''),
(100,19,'alexmorgan','earn',100,62850,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:50',0,''),
(101,19,'alexmorgan','earn',100,62950,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:37:57',0,''),
(102,19,'alexmorgan','earn',50,63000,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:38:02',0,''),
(103,19,'alexmorgan','earn',120,63120,'会员开通赠送','开通至尊会员赠送积分','2026-07-17 19:38:04',0,''),
(104,19,'alexmorgan','earn',50,63170,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:43:09',0,''),
(105,19,'alexmorgan','earn',50,63220,'会员开通赠送','开通黄金会员赠送积分','2026-07-17 19:43:15',0,''),
(106,19,'alexmorgan','earn',100,63320,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:23',0,''),
(107,19,'alexmorgan','earn',100,63420,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:27',0,''),
(108,19,'alexmorgan','earn',100,63520,'会员开通赠送','开通钻石会员赠送积分','2026-07-17 19:43:32',0,''),
(109,19,'alexmorgan','earn',10,63530,'每日签到','连续签到第1天','2026-07-17 23:39:01',0,''),
(110,19,'alexmorgan','earn',10,63540,'每日签到','完成任务: 每日签到','2026-07-17 23:39:01',0,''),
(111,19,'Alex Morgan','earn',20,63560,'发帖奖励','完成任务: 发帖奖励','2026-07-17 23:59:49',0,''),
(112,10017,'user_10017','earn',20,20,'发帖奖励','完成任务: 发帖奖励','2026-07-19 00:52:10',0,''),
(113,10018,'user_10018','earn',20,20,'发帖奖励','完成任务: 发帖奖励','2026-07-19 00:52:47',0,''),
(114,10019,'user_10019','earn',20,20,'发帖奖励','完成任务: 发帖奖励','2026-07-19 01:04:36',0,''),
(115,19,'alexmorgan','earn',50,63660,'会员开通赠送','开通黄金会员赠送积分','2026-07-19 04:10:29',0,''),
(116,1,'bob123','earn',24,1474,'发帖奖励','完成任务: 发帖奖励','2026-07-20 07:15:01',0,''),
(117,1,'bob123','earn',24,1498,'发帖奖励','完成任务: 发帖奖励','2026-07-20 20:37:11',0,''),
(118,2,'lisa123','earn',20,820,'发帖奖励','完成任务: 发帖奖励','2026-07-20 20:39:31',0,''),
(119,10020,'测试用户','earn',20,20,'发帖奖励','完成任务: 发帖奖励','2026-07-20 20:48:18',0,''),
(120,2,'','earn',33,853,'完善资料','完成任务: 完善资料','2026-07-21 00:12:43',0,''),
(121,2,'Lisa管线昵称','earn',6,859,'评论互动','完成任务: 评论互动','2026-07-21 00:12:43',0,''),
(122,3,'tech123','earn',20,5020,'发帖奖励','完成任务: 发帖奖励','2026-07-21 00:14:32',0,''),
(123,19,'alexmorgan','earn',50,63710,'会员开通赠送','开通黄金会员赠送积分','2026-07-21 00:23:38',0,''),
(124,10004,'','earn',30,35,'完善资料','完成任务: 完善资料','2026-07-21 06:56:20',0,''),
(125,1,'bob123','earn',24,924,'发帖奖励','完成任务: 发帖奖励','2026-07-21 16:15:35',0,''),
(126,2,'Lisa管线昵称','expense',200,900,'合集购买','购买合集《社区功能测试合集》','2026-07-21 16:50:22',0,''),
(127,19,'alexmorgan','income',200,63910,'合集销售收入','合集《社区功能测试合集》销售','2026-07-21 16:50:22',0,''),
(128,1,'','game',-10,0,'','卡片竞猜消耗','2026-07-21 17:10:51',0,'');
/*!40000 ALTER TABLE `points_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_transfer_records`
--

DROP TABLE IF EXISTS `points_transfer_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_transfer_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `to_user_id` int(11) NOT NULL,
  `to_user_name` varchar(100) DEFAULT '',
  `amount` int(11) NOT NULL DEFAULT 0,
  `fee` int(11) DEFAULT 0,
  `remark` varchar(300) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_transfer_records`
--

LOCK TABLES `points_transfer_records` WRITE;
/*!40000 ALTER TABLE `points_transfer_records` DISABLE KEYS */;
INSERT INTO `points_transfer_records` VALUES
(1,1,'bobwang',2,'lisa_chen',100,0,'积分测试','2026-07-21 16:06:58');
/*!40000 ALTER TABLE `points_transfer_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policy_versions`
--

DROP TABLE IF EXISTS `policy_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `policy_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `title` varchar(200) DEFAULT '',
  `content` text DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `status` varchar(10) DEFAULT 'draft',
  `published_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_policy_versions_type_status` (`type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policy_versions`
--

LOCK TABLES `policy_versions` WRITE;
/*!40000 ALTER TABLE `policy_versions` DISABLE KEYS */;
INSERT INTO `policy_versions` VALUES
(4,'privacy','测试隐私政策','这是测试内容',4,'archived','2026-07-19 04:03:37',0,'2026-07-19 04:02:53','2026-07-19 04:02:53'),
(6,'agreement','ztbbttb2','5959',1,'draft',NULL,0,'2026-07-19 04:08:49','2026-07-19 04:09:47'),
(7,'privacy','测试','测试内容',5,'published','2026-07-21 15:49:26',0,'2026-07-21 15:49:20','2026-07-21 15:49:20');
/*!40000 ALTER TABLE `policy_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_favorites`
--

DROP TABLE IF EXISTS `post_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`post_id`),
  KEY `idx_post_favorites_user` (`user_id`),
  KEY `idx_post_favorites_post` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_favorites`
--

LOCK TABLES `post_favorites` WRITE;
/*!40000 ALTER TABLE `post_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `private_messages`
--

DROP TABLE IF EXISTS `private_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(500) DEFAULT '#448AFF',
  `to_user_id` int(11) NOT NULL,
  `content` text DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `image_url` varchar(500) DEFAULT '',
  `message_type` varchar(20) DEFAULT 'text',
  `order_card` text DEFAULT NULL,
  `is_recalled` tinyint(1) DEFAULT 0,
  `report_status` varchar(20) DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `idx_private_messages_from` (`from_user_id`),
  KEY `idx_private_messages_to` (`to_user_id`),
  KEY `idx_private_messages_conversation` (`from_user_id`,`to_user_id`),
  KEY `idx_private_messages_ctime` (`create_time`),
  KEY `idx_private_messages_to_time` (`to_user_id`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `private_messages`
--

LOCK TABLES `private_messages` WRITE;
/*!40000 ALTER TABLE `private_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `private_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion_materials`
--

DROP TABLE IF EXISTS `promotion_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `type` varchar(50) DEFAULT 'poster',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_materials`
--

LOCK TABLES `promotion_materials` WRITE;
/*!40000 ALTER TABLE `promotion_materials` DISABLE KEYS */;
INSERT INTO `promotion_materials` VALUES
(1,'618年中大促','https://via.placeholder.com/800x400/FF6B35/fff?text=618','邀请好友注册即送100积分','poster','2026-07-17 17:39:08');
/*!40000 ALTER TABLE `promotion_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notifications`
--

DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'system',
  `target_type` varchar(50) DEFAULT 'all',
  `target_ids` text DEFAULT NULL,
  `target_count` int(11) DEFAULT 0,
  `title` varchar(500) DEFAULT '',
  `content` text DEFAULT NULL,
  `link` varchar(500) DEFAULT '',
  `channels` varchar(500) DEFAULT '["app"]',
  `membership_level` varchar(20) DEFAULT '',
  `status` varchar(20) DEFAULT 'draft',
  `read_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_push_notifications_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notifications`
--

LOCK TABLES `push_notifications` WRITE;
/*!40000 ALTER TABLE `push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_score_config`
--

DROP TABLE IF EXISTS `quality_score_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quality_score_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(40) NOT NULL,
  `config_value` varchar(40) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_score_config`
--

LOCK TABLES `quality_score_config` WRITE;
/*!40000 ALTER TABLE `quality_score_config` DISABLE KEYS */;
INSERT INTO `quality_score_config` VALUES
(1,'threshold_high','0.7','高分阈值(>=此值为优质)'),
(2,'threshold_low','0.4','低分阈值(>=此值为一般，<为较差)');
/*!40000 ALTER TABLE `quality_score_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_score_dims`
--

DROP TABLE IF EXISTS `quality_score_dims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quality_score_dims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_type` varchar(20) NOT NULL COMMENT 'post/app/product',
  `dim_key` varchar(40) NOT NULL,
  `display_name` varchar(40) NOT NULL,
  `max_score` int(11) NOT NULL DEFAULT 10,
  `rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Scoring rules as JSON array' CHECK (json_valid(`rules`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `enabled` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_key` (`target_type`,`dim_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_score_dims`
--

LOCK TABLES `quality_score_dims` WRITE;
/*!40000 ALTER TABLE `quality_score_dims` DISABLE KEYS */;
INSERT INTO `quality_score_dims` VALUES
(1,'post','textLength','内容长度',20,'[{\"cond\":\"ge\",\"field\":\"textLen\",\"val\":1000,\"score\":20},{\"cond\":\"ge\",\"field\":\"textLen\",\"val\":200,\"score\":15},{\"cond\":\"ge\",\"field\":\"textLen\",\"val\":50,\"score\":10}]',1,1),
(2,'post','images','图片数量',15,'[{\"cond\":\"ge\",\"field\":\"imgCount\",\"val\":4,\"score\":15},{\"cond\":\"ge\",\"field\":\"imgCount\",\"val\":2,\"score\":12},{\"cond\":\"ge\",\"field\":\"imgCount\",\"val\":1,\"score\":8}]',2,1),
(3,'post','layout','排版结构',15,'[{\"cond\":\"flag\",\"field\":\"hasTitle\",\"score\":5},{\"cond\":\"flag\",\"field\":\"hasParagraphs\",\"score\":5},{\"cond\":\"flag\",\"field\":\"hasList\",\"score\":5}]',3,1),
(4,'post','links','外链控制',5,'[{\"cond\":\"eq\",\"field\":\"urlCount\",\"val\":0,\"score\":5},{\"cond\":\"le\",\"field\":\"urlCount\",\"val\":3,\"score\":2}]',4,1),
(5,'post','title','标题质量',10,'[{\"cond\":\"range\",\"field\":\"titleLen\",\"min\":5,\"max\":20,\"score\":10},{\"cond\":\"range\",\"field\":\"titleLen\",\"min\":2,\"max\":30,\"score\":5}]',5,1),
(6,'post','level','经验等级',10,'[{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":4,\"score\":10},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":2,\"score\":6},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":1,\"score\":3}]',6,1),
(7,'app','name','名称',10,'[{\"cond\":\"ge\",\"field\":\"nameLen\",\"val\":3,\"score\":10}]',1,1),
(8,'app','description','描述',15,'[{\"cond\":\"ge\",\"field\":\"descLen\",\"val\":20,\"score\":15},{\"cond\":\"ge\",\"field\":\"descLen\",\"val\":10,\"score\":8}]',2,1),
(9,'app','screenshots','截图',30,'[{\"cond\":\"per\",\"field\":\"scrCount\",\"val\":10,\"cap\":30}]',3,1),
(10,'app','level','经验等级',15,'[{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":3,\"score\":15},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":2,\"score\":10},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":1,\"score\":5}]',4,1),
(11,'product','name','名称',8,'[{\"cond\":\"ge\",\"field\":\"nameLen\",\"val\":3,\"score\":8}]',1,1),
(12,'product','description','描述',15,'[{\"cond\":\"ge\",\"field\":\"descLen\",\"val\":30,\"score\":15},{\"cond\":\"ge\",\"field\":\"descLen\",\"val\":10,\"score\":7}]',2,1),
(13,'product','image','主图',12,'[{\"cond\":\"flag\",\"field\":\"hasImage\",\"score\":12}]',3,1),
(14,'product','price','定价',10,'[{\"cond\":\"range\",\"field\":\"price\",\"min\":0.01,\"max\":100000,\"score\":10}]',4,1),
(15,'product','level','经验等级',12,'[{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":3,\"score\":12},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":2,\"score\":8},{\"cond\":\"ge\",\"field\":\"userLevel\",\"val\":1,\"score\":5}]',5,1);
/*!40000 ALTER TABLE `quality_score_dims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranking_cache`
--

DROP TABLE IF EXISTS `ranking_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ranking_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `period` varchar(10) NOT NULL DEFAULT 'all',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_period` (`type`,`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking_cache`
--

LOCK TABLES `ranking_cache` WRITE;
/*!40000 ALTER TABLE `ranking_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranking_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_amounts`
--

DROP TABLE IF EXISTS `recharge_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_amounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `label` varchar(100) DEFAULT '',
  `discount` varchar(100) DEFAULT '',
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_amounts`
--

LOCK TABLES `recharge_amounts` WRITE;
/*!40000 ALTER TABLE `recharge_amounts` DISABLE KEYS */;
INSERT INTO `recharge_amounts` VALUES
(5,10.00,'CRUD Test 10','',1,'2026-07-10 20:17:40');
/*!40000 ALTER TABLE `recharge_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_orders`
--

DROP TABLE IF EXISTS `recharge_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pay_method` varchar(20) DEFAULT 'epay',
  `status` varchar(20) DEFAULT 'pending',
  `trade_no` varchar(100) DEFAULT '',
  `paid_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recharge_orders_user` (`user_id`),
  KEY `idx_recharge_orders_order_no` (`order_no`),
  KEY `idx_recharge_orders_status` (`status`),
  KEY `idx_recharge_orders_ctime` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_orders`
--

LOCK TABLES `recharge_orders` WRITE;
/*!40000 ALTER TABLE `recharge_orders` DISABLE KEYS */;
INSERT INTO `recharge_orders` VALUES
(1,'RCH17837231939640',9,10.00,'epay','paid','','2026-07-09 22:39:53','2026-06-13 22:39:53'),
(2,'RCH17837231939651',5,30.00,'epay','paid','','2026-07-02 22:39:53','2026-06-21 22:39:53'),
(3,'RCH17837231939652',2,50.00,'epay','paid','','2026-07-09 22:39:53','2026-06-16 22:39:53'),
(4,'RCH17837231939663',6,98.00,'epay','paid','','2026-06-20 22:39:53','2026-06-26 22:39:53'),
(5,'RCH17837231939664',15,198.00,'epay','paid','','2026-07-06 22:39:53','2026-06-27 22:39:53'),
(6,'RCH17837231939665',8,298.00,'epay','paid','','2026-07-03 22:39:53','2026-07-04 22:39:53'),
(7,'RCH17837231939676',9,10.00,'epay','paid','','2026-06-24 22:39:53','2026-07-07 22:39:53'),
(8,'RCH17837231939677',6,30.00,'epay','paid','','2026-06-20 22:39:53','2026-06-14 22:39:53'),
(9,'RCH17837231939678',14,50.00,'epay','paid','','2026-07-06 22:39:53','2026-06-28 22:39:53'),
(10,'RCH17837231939689',15,98.00,'epay','pending','',NULL,'2026-06-24 22:39:53'),
(11,'RCH178372319396810',14,198.00,'epay','pending','',NULL,'2026-07-04 22:39:53'),
(12,'RCH178372319396911',4,298.00,'epay','pending','',NULL,'2026-06-21 22:39:53'),
(13,'RC1784648104227sgo67m',10004,10.00,'alipay','pending','',NULL,'2026-07-21 15:35:04'),
(14,'RC17846481042615f6ylc',10002,10.00,'alipay','pending','',NULL,'2026-07-21 15:35:04'),
(15,'RC178464810904885s8su',10002,10.00,'alipay','pending','',NULL,'2026-07-21 15:35:09'),
(16,'TEST_TXN_001',1,100.00,'epay','paid','GATEWAY_TXN_001','2026-07-21 16:12:14','2026-07-21 16:09:45'),
(17,'TEST_TXN_002',2,50.00,'epay','paid','GATEWAY_TXN_002','2026-07-21 16:12:14','2026-07-21 16:09:45');
/*!40000 ALTER TABLE `recharge_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recycle_bin`
--

DROP TABLE IF EXISTS `recycle_bin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycle_bin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_table` varchar(100) NOT NULL,
  `original_id` int(11) NOT NULL,
  `data_json` text NOT NULL,
  `deleted_by` int(11) DEFAULT 0,
  `deleted_by_name` varchar(100) DEFAULT '',
  `user_level_id` int(11) DEFAULT 0,
  `delete_reason` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recycle_bin_table` (`original_table`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recycle_bin`
--

LOCK TABLES `recycle_bin` WRITE;
/*!40000 ALTER TABLE `recycle_bin` DISABLE KEYS */;
INSERT INTO `recycle_bin` VALUES
(1,'community_posts',1,'{\"title\":\"测试帖子A\"}',1,'管理员',1,'违规内容','2026-07-19 04:14:13'),
(2,'community_posts',2,'{\"title\":\"测试帖子B\"}',1,'管理员',2,'重复发布','2026-07-19 04:14:13'),
(3,'app_store',5,'{\"name\":\"测试应用X\"}',1,'管理员',3,'已下架','2026-07-19 04:14:13'),
(4,'app_comments',3,'{\"content\":\"垃圾评论\"}',1,'管理员',4,'不当言论','2026-07-19 04:14:13');
/*!40000 ALTER TABLE `recycle_bin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_links`
--

DROP TABLE IF EXISTS `referral_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `mode` varchar(20) DEFAULT 'purchase',
  `discount` decimal(5,2) DEFAULT 0.00,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `purchase_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_referral_links_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_links`
--

LOCK TABLES `referral_links` WRITE;
/*!40000 ALTER TABLE `referral_links` DISABLE KEYS */;
INSERT INTO `referral_links` VALUES
(1,4,'REF-965vi41','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(2,9,'REF-t0omukq','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(4,14,'REF-rnrw7sk','purchase',0.00,0,0,0,'2026-07-10 22:39:54'),
(5,15,'REF-bjco7s0','purchase',0.00,0,0,0,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `referral_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `auth_mark` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_auth` (`role_id`,`menu_id`,`auth_mark`)
) ENGINE=InnoDB AUTO_INCREMENT=1414 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1196,20,1,NULL),
(1197,20,2,NULL),
(1198,20,3,NULL),
(1199,20,4,NULL),
(1200,20,5,NULL),
(1201,20,6,NULL),
(1202,20,7,NULL),
(1203,20,8,NULL),
(1204,20,8,'add'),
(1205,20,8,'delete'),
(1206,20,8,'import'),
(1207,20,9,NULL),
(1208,20,9,'add'),
(1209,20,9,'delete'),
(1210,20,9,'edit'),
(1211,20,10,NULL),
(1212,20,10,'add'),
(1213,20,10,'delete'),
(1214,20,10,'edit'),
(1215,20,10,'toggle'),
(1216,20,11,NULL),
(1217,20,11,'adjust'),
(1218,20,11,'export'),
(1219,20,12,NULL),
(1220,20,12,'add'),
(1221,20,12,'delete'),
(1222,20,12,'edit'),
(1223,20,13,NULL),
(1224,20,13,'config'),
(1225,20,13,'delete'),
(1226,20,13,'toggle'),
(1227,20,13,'upload'),
(1228,20,14,NULL),
(1229,20,14,'add'),
(1230,20,14,'delete'),
(1231,20,14,'edit'),
(1232,20,15,NULL),
(1233,20,15,'add'),
(1234,20,15,'config'),
(1235,20,15,'delete'),
(1236,20,15,'edit'),
(1237,20,16,NULL),
(1238,20,16,'add'),
(1239,20,16,'delete'),
(1240,20,16,'edit'),
(1241,20,17,NULL),
(1242,20,17,'add'),
(1243,20,17,'delete'),
(1244,20,17,'edit'),
(1245,20,17,'toggle'),
(1246,20,18,NULL),
(1247,20,18,'add'),
(1248,20,18,'delete'),
(1249,20,18,'edit'),
(1250,20,18,'toggle'),
(1251,20,19,NULL),
(1252,20,19,'export'),
(1253,20,20,NULL),
(1254,20,20,'export'),
(1255,20,21,NULL),
(1256,20,21,'add'),
(1257,20,21,'delete'),
(1258,20,21,'edit'),
(1259,20,21,'reset'),
(1260,20,21,'toggle'),
(1261,20,22,NULL),
(1262,20,22,'add'),
(1263,20,22,'delete'),
(1264,20,22,'edit'),
(1265,20,23,NULL),
(1266,20,24,NULL),
(1267,20,24,'add'),
(1268,20,24,'delete'),
(1269,20,24,'edit'),
(1270,20,25,NULL),
(1271,20,25,'approve'),
(1272,20,25,'reject'),
(1273,20,26,NULL),
(1274,20,26,'approve'),
(1275,20,26,'reject'),
(1276,20,27,NULL),
(1277,20,27,'add'),
(1278,20,27,'delete'),
(1279,20,27,'generate'),
(1280,20,28,NULL),
(1281,20,28,'edit'),
(1282,20,28,'test'),
(1283,20,29,NULL),
(1284,20,29,'delete'),
(1285,20,30,NULL),
(1286,20,30,'delete'),
(1287,20,30,'restore'),
(1288,20,31,NULL),
(1289,20,31,'clear'),
(1290,20,31,'export'),
(1291,20,32,NULL),
(1292,20,32,'edit'),
(1293,20,33,NULL),
(1294,20,33,'add'),
(1295,20,33,'delete'),
(1296,20,33,'edit'),
(1297,20,33,'toggle'),
(1298,20,34,NULL),
(1299,20,34,'add'),
(1300,20,34,'delete'),
(1301,20,34,'edit'),
(1302,20,34,'toggle'),
(1303,20,35,NULL),
(1304,20,35,'edit'),
(1305,20,35,'toggle'),
(1306,20,36,NULL),
(1307,20,36,'add'),
(1308,20,36,'delete'),
(1309,20,36,'edit'),
(1310,20,37,NULL),
(1311,20,37,'approve'),
(1312,20,37,'delete'),
(1313,20,37,'edit'),
(1314,20,37,'reject'),
(1315,20,37,'toggle'),
(1316,20,38,NULL),
(1317,20,39,NULL),
(1318,20,39,'add'),
(1319,20,39,'delete'),
(1320,20,39,'edit'),
(1321,20,40,NULL),
(1322,20,40,'delete'),
(1323,20,40,'handle'),
(1324,20,40,'ignore'),
(1325,20,44,NULL),
(1326,20,44,'add'),
(1327,20,44,'delete'),
(1328,20,44,'edit'),
(1329,20,45,NULL),
(1330,20,45,'add'),
(1331,20,45,'delete'),
(1332,20,45,'edit'),
(1333,20,45,'moderate'),
(1334,20,45,'toggle'),
(1335,20,45,'unlock'),
(1336,20,46,NULL),
(1337,20,46,'approve'),
(1338,20,46,'boost'),
(1339,20,46,'delete'),
(1340,20,46,'edit'),
(1341,20,46,'essence'),
(1342,20,46,'lock'),
(1343,20,46,'pin'),
(1344,20,47,NULL),
(1345,20,47,'delete'),
(1346,20,47,'handle'),
(1347,20,47,'ignore'),
(1348,20,48,NULL),
(1349,20,48,'delete'),
(1350,20,48,'pin'),
(1351,20,49,NULL),
(1352,20,50,NULL),
(1353,20,51,NULL),
(1354,20,52,NULL),
(1355,20,53,NULL),
(1356,20,54,NULL),
(1357,20,54,'delete'),
(1358,20,54,'download'),
(1359,20,54,'upload'),
(1360,20,55,NULL),
(1361,20,55,'add'),
(1362,20,55,'delete'),
(1363,20,55,'edit'),
(1364,20,57,NULL),
(1365,20,57,'add'),
(1366,20,57,'delete'),
(1367,20,57,'edit'),
(1368,20,57,'toggle'),
(1369,20,58,NULL),
(1370,20,58,'edit'),
(1371,20,58,'export'),
(1372,20,58,'handle'),
(1373,20,58,'view'),
(1374,20,59,NULL),
(1375,20,59,'add'),
(1376,20,59,'delete'),
(1377,20,59,'edit'),
(1378,20,60,NULL),
(1379,20,60,'edit'),
(1380,20,60,'handle'),
(1381,20,60,'view'),
(1382,20,61,NULL),
(1383,20,61,'add'),
(1384,20,61,'delete'),
(1385,20,61,'edit'),
(1386,20,61,'toggle'),
(1387,20,62,NULL),
(1388,20,62,'add'),
(1389,20,62,'delete'),
(1390,20,62,'edit'),
(1391,20,62,'toggle'),
(1392,20,63,NULL),
(1393,20,63,'add'),
(1394,20,63,'delete'),
(1395,20,63,'edit'),
(1396,20,64,NULL),
(1397,20,64,'add'),
(1398,20,64,'delete'),
(1399,20,64,'edit'),
(1400,20,65,NULL),
(1401,20,65,'edit'),
(1402,20,66,NULL),
(1403,20,66,'add'),
(1404,20,66,'delete'),
(1405,20,66,'edit'),
(1406,20,67,NULL),
(1407,20,67,'edit'),
(1408,20,68,NULL),
(1409,20,68,'add'),
(1410,20,68,'delete'),
(1411,20,69,'add'),
(1412,20,69,'delete'),
(1413,20,69,'edit'),
(984,22,1,NULL),
(985,22,2,NULL),
(986,22,3,NULL),
(987,22,4,NULL),
(988,22,5,NULL),
(989,22,6,NULL),
(990,22,7,NULL),
(991,22,8,NULL),
(992,22,8,'add'),
(993,22,8,'delete'),
(994,22,8,'import'),
(995,22,9,NULL),
(996,22,9,'add'),
(998,22,9,'delete'),
(997,22,9,'edit'),
(999,22,10,NULL),
(1000,22,10,'add'),
(1002,22,10,'delete'),
(1001,22,10,'edit'),
(1003,22,10,'toggle'),
(1004,22,11,NULL),
(1005,22,11,'adjust'),
(1006,22,11,'export'),
(1007,22,12,NULL),
(1008,22,12,'add'),
(1010,22,12,'delete'),
(1009,22,12,'edit'),
(1011,22,13,NULL),
(1014,22,13,'config'),
(1015,22,13,'delete'),
(1013,22,13,'toggle'),
(1012,22,13,'upload'),
(1016,22,14,NULL),
(1017,22,14,'add'),
(1019,22,14,'delete'),
(1018,22,14,'edit'),
(1020,22,15,NULL),
(1021,22,15,'add'),
(1024,22,15,'config'),
(1023,22,15,'delete'),
(1022,22,15,'edit'),
(1025,22,16,NULL),
(1026,22,16,'add'),
(1028,22,16,'delete'),
(1027,22,16,'edit'),
(1029,22,17,NULL),
(1030,22,17,'add'),
(1032,22,17,'delete'),
(1031,22,17,'edit'),
(1033,22,17,'toggle'),
(1034,22,18,NULL),
(1035,22,18,'add'),
(1037,22,18,'delete'),
(1036,22,18,'edit'),
(1038,22,18,'toggle'),
(1039,22,19,NULL),
(1040,22,19,'export'),
(1041,22,20,NULL),
(1042,22,20,'export'),
(1043,22,21,NULL),
(1044,22,21,'add'),
(1046,22,21,'delete'),
(1045,22,21,'edit'),
(1048,22,21,'reset'),
(1047,22,21,'toggle'),
(1049,22,22,NULL),
(1050,22,22,'add'),
(1052,22,22,'delete'),
(1051,22,22,'edit'),
(1053,22,23,NULL),
(1054,22,24,NULL),
(1055,22,24,'add'),
(1057,22,24,'delete'),
(1056,22,24,'edit'),
(1058,22,25,NULL),
(1059,22,25,'approve'),
(1060,22,25,'reject'),
(1061,22,26,NULL),
(1062,22,26,'approve'),
(1063,22,26,'reject'),
(1064,22,27,NULL),
(1065,22,27,'add'),
(1067,22,27,'delete'),
(1066,22,27,'generate'),
(1068,22,28,NULL),
(1069,22,28,'edit'),
(1070,22,28,'test'),
(1071,22,29,NULL),
(1072,22,29,'delete'),
(1073,22,30,NULL),
(1075,22,30,'delete'),
(1074,22,30,'restore'),
(1076,22,31,NULL),
(1078,22,31,'clear'),
(1077,22,31,'export'),
(1079,22,32,NULL),
(1080,22,32,'edit'),
(1081,22,33,NULL),
(1082,22,33,'add'),
(1084,22,33,'delete'),
(1083,22,33,'edit'),
(1085,22,33,'toggle'),
(1086,22,34,NULL),
(1087,22,34,'add'),
(1089,22,34,'delete'),
(1088,22,34,'edit'),
(1090,22,34,'toggle'),
(1091,22,35,NULL),
(1092,22,35,'edit'),
(1093,22,35,'toggle'),
(1094,22,36,NULL),
(1095,22,36,'add'),
(1097,22,36,'delete'),
(1096,22,36,'edit'),
(1098,22,37,NULL),
(1099,22,37,'approve'),
(1102,22,37,'delete'),
(1101,22,37,'edit'),
(1100,22,37,'reject'),
(1103,22,37,'toggle'),
(1104,22,38,NULL),
(1105,22,39,NULL),
(1106,22,39,'add'),
(1108,22,39,'delete'),
(1107,22,39,'edit'),
(1109,22,40,NULL),
(1112,22,40,'delete'),
(1110,22,40,'handle'),
(1111,22,40,'ignore'),
(1113,22,44,NULL),
(1114,22,44,'add'),
(1116,22,44,'delete'),
(1115,22,44,'edit'),
(1117,22,45,NULL),
(1118,22,45,'add'),
(1120,22,45,'delete'),
(1119,22,45,'edit'),
(1121,22,45,'moderate'),
(1122,22,45,'toggle'),
(1123,22,45,'unlock'),
(1124,22,46,NULL),
(1129,22,46,'approve'),
(1127,22,46,'boost'),
(1131,22,46,'delete'),
(1130,22,46,'edit'),
(1126,22,46,'essence'),
(1128,22,46,'lock'),
(1125,22,46,'pin'),
(1132,22,47,NULL),
(1135,22,47,'delete'),
(1133,22,47,'handle'),
(1134,22,47,'ignore'),
(1136,22,48,NULL),
(1138,22,48,'delete'),
(1137,22,48,'pin'),
(1139,22,49,NULL),
(1140,22,50,NULL),
(1141,22,51,NULL),
(1142,22,52,NULL),
(1143,22,53,NULL),
(1144,22,54,NULL),
(1145,22,55,NULL),
(1146,22,55,'add'),
(1148,22,55,'delete'),
(1147,22,55,'edit'),
(1149,22,56,NULL),
(1150,22,57,NULL),
(1151,22,57,'add'),
(1153,22,57,'delete'),
(1152,22,57,'edit'),
(1154,22,58,NULL),
(1156,22,58,'handle'),
(1155,22,58,'view'),
(1157,22,59,NULL),
(1158,22,59,'add'),
(1160,22,59,'delete'),
(1159,22,59,'edit'),
(1161,22,60,NULL),
(1163,22,60,'handle'),
(1162,22,60,'view'),
(1164,22,61,NULL),
(1165,22,61,'add'),
(1167,22,61,'delete'),
(1166,22,61,'edit'),
(1168,22,62,NULL),
(1169,22,62,'add'),
(1171,22,62,'delete'),
(1170,22,62,'edit'),
(1172,22,62,'toggle'),
(1173,22,63,NULL),
(1174,22,63,'add'),
(1176,22,63,'delete'),
(1175,22,63,'edit'),
(1177,22,64,NULL),
(1178,22,64,'add'),
(1180,22,64,'delete'),
(1179,22,64,'edit'),
(1181,22,65,NULL),
(1182,22,65,'edit'),
(1183,22,66,NULL),
(1184,22,66,'add'),
(1186,22,66,'delete'),
(1185,22,66,'edit'),
(1187,22,67,NULL),
(1188,22,67,'edit'),
(1189,22,68,NULL),
(1190,22,68,'delete'),
(1191,22,68,'download'),
(1192,22,69,NULL),
(1193,22,69,'add'),
(1195,22,69,'delete'),
(1194,22,69,'edit');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_code` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT '',
  `enabled` tinyint(1) DEFAULT 1,
  `community_moderator` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(20,'管理员','R_ADMIN','系统管理员',1,1,'2026-07-10 22:42:45'),
(21,'普通用户','R_USER','普通用户',1,0,'2026-07-10 22:42:45'),
(22,'系统超级管理员','R_SUPER','系统超级管理员',1,1,'2026-07-11 12:47:10'),
(23,'版主','R_MODERATOR','社区版主',1,1,'2026-07-16 17:22:00'),
(24,'审核员','R_REVIEWER','社区审核员',1,1,'2026-07-16 17:22:00');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_moderators`
--

DROP TABLE IF EXISTS `section_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_id` (`section_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_moderators`
--

LOCK TABLES `section_moderators` WRITE;
/*!40000 ALTER TABLE `section_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_moderators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_words`
--

DROP TABLE IF EXISTS `sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `category` varchar(20) DEFAULT 'general',
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_words`
--

LOCK TABLES `sensitive_words` WRITE;
/*!40000 ALTER TABLE `sensitive_words` DISABLE KEYS */;
INSERT INTO `sensitive_words` VALUES
(1,'广告推广','text',1,'2026-07-10 22:39:54'),
(2,'虚假信息','text',1,'2026-07-10 22:39:54'),
(3,'恶意攻击','text',1,'2026-07-10 22:39:54'),
(4,'非法内容','text',1,'2026-07-10 22:39:54'),
(5,'侵权内容','text',1,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `token` varchar(100) NOT NULL,
  `refresh_token` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `roles` text DEFAULT '[]',
  `created_at` bigint(20) NOT NULL,
  `device_id` varchar(32) DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `user_agent` text DEFAULT '',
  PRIMARY KEY (`token`),
  KEY `idx_sessions_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('1eafc80cd6ec418cafae742421a36155',NULL,1,'bobwang','[\"R_USER\"]',1784034714473,'','',''),
('2fa-7e94907119056adfbb4908716e7972450e98ac2915d307b518fd268da53ca231',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784346508138,'','',''),
('2fa-7f32fdacb79e01307badcb6164446ea06e8c1c1a376ada89c1b7f258935bc35c',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784433703994,'','',''),
('2fa-8835d54d94df6ee0a73bfa0e62ec8ae2996ec1f25d4e4e3729e3c9db9a06f4d2',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784433723895,'','',''),
('2fa-9949e8945731bbed58b1cd5e8a20a43d2898244903be41d4b563c3ba0c995a80',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784433718091,'','',''),
('2fa-bec3a0a8d36e5ae7ed44be8aed298ec7a02ae9b6ef6c903db8d5a18292c9e922',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784389225443,'','',''),
('2fa-c51dfb0cc4a5d0dcfae5614bc90922ef3fd1d12c114bd77a42ac665b15df7d0b',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784389969559,'','',''),
('2fa-c5dc286c1d17eb5a0f9a029c6349423836bed87847f3299620672045a712b53a',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784433732320,'','',''),
('2fa-eb89b0ca3ff126a50fc942613ed714a6f4171d4262b6bb822c3b642397170547',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784388784195,'','',''),
('2fa-mrob0dzv-1c6hqp5n',NULL,1,'bobwang','[\"R_USER\"]',1784254415323,'','',''),
('2fa-mrob0jrm-sdk1dqvg',NULL,1,'bobwang','[\"R_USER\"]',1784254422802,'','',''),
('2fa-mrp2icve-r5szenut',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784300603307,'','',''),
('2fa-mrp2iga8-pcx8b10z',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784300607728,'','',''),
('7df985d62c184b888ce2b999161e8ecd',NULL,2,'lisa_chen','[\"R_USER\"]',1784037620908,'','',''),
('cb92d37541894f06b5fdbb021a0288a4',NULL,2,'lisa_chen','[\"R_USER\"]',1784037423584,'','',''),
('d99d5735ccb74f7b814567a96478b91c',NULL,2,'lisa_chen','[\"R_USER\"]',1784039037495,'','',''),
('dc68e2b1688c495c8ff6eb31c9486856',NULL,2,'lisa_chen','[\"R_USER\"]',1784034885371,'','',''),
('e6e1e86d04a84429a1e1fb4af45eb471',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784034714473,'','',''),
('tk-007ee041c50d30a5836077b44bf60f37716597c117478c1b90565d6a956f4217','rt-2333e003940a30952976236df9802af39ceba6e3c0dc597136a217fd04c91a3f',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592763107,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-01a5007c3de528783b87fa67669005389dd68c87af35ff56afe5dafbabad9b02','rt-53004987b3385e930acb5481411ae9f88a19dca472421e64cec7094e71bc5f10',10004,'admin','[\"R_SUPER\"]',1784617577896,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-043916558a0216920a5feb3cd7051455b1b6ac9e29cf57d42587811108ead00d','rt-9406f338de2853bece1cff2fa4bb51508482b571049e7ebbf2676e1548e444b7',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652014468,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-04a97faedece6dd20b104802b15a0cfaea2f7e7a7ac79e9b519f5f5021368b64','rt-9a1d45f9e2344b3e12bb9dd848ea91726b9a5cdad126805a22b717d80a99bbd2',10002,'github_user_mrnwh1hi','[]',1784648250857,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-04e1ad40b5801d10124eb507c4f5549f658bf50a3ad072e43a9034a8a290cd97','rt-084a8f32b11b47d4b84f0e04de173a759e8be7f5752fb20afdefa5a84c831acf',2,'lisa_chen','[\"R_USER\"]',1784594243967,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-04f2b9177e130b0e04aec8e7a9b1a7849d321e2586585c7de310c2320c353530','rt-9a0a37bd7eb8318934e0d41c586b039cfa93d2492e9523f68791ea2fe1a90bad',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473992157,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-062f928d5fd96f8ba7a6903195bd5bbb6a4e4858a288709e8ebf5b5343c87357','rt-914a913d0523ca6541aa34a201525fccc1fe23cb29a5f601bff2d20a04539098',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473979091,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-063864b21df309074b7fc25fefcde041c4f9d360beb40b62b289967aa54c4b05','rt-f62124b37f153c05fc4e1dee4d74c648ae23bdc3e30cc64289e6301065a6e554',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784654132696,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-0731e07d1f50d52830474977d9cd784c5a4f4cd6657aa5017577e54ebc5a6f69',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784433768992,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-08b6d7b4cd1b742a251820e62fa9a49fa3f4e0e900e4c4ee11042aa6cb3b77de',NULL,10016,'tst__dbgmrr2z5qq','[]',1784422320034,'ab54a5cf','::ffff:127.0.0.1',''),
('tk-093608239c507bf5f03f04f6e68d4651cf2d94e5e44f8dd906a32ff69c52436b','rt-8db17667b352b11896df73f8b86c6ea79cba554b603aac4e66b5b67c0f70c41f',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784528395128,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-0cdc012284f21c3d8e9787d64ce152dd80ee5093d76df92c2a9048d95c7d3920','rt-3c1c2dcfbcf39c86e7258780a76445dd0b73853fef169d883b95c7522918cbf8',10004,'admin','[\"R_SUPER\"]',1784617199682,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-0f75b3919853f85e3ec1ffa52b74f0f97f4576a3ba475120b357c3d2e8fc46c2','rt-57392fcab111814d502fe42f0b869abc62a9013c1120df793d5c4810646681f3',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592902492,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-0fe02109ead09829ea8e8f9c1e706e7bbea8f03bcaedd67fc90f46309ef5821c','rt-5ce7f5f14209c597afcaf813e451aaabb02eb1feab8c117ea1d874ac9bdc45ef',2,'lisa_chen','[\"R_USER\"]',1784648662290,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-120e97e9b3f86e07bcbeb3084334985bd32eea70ba2b5550bb38d8a54a7afeec','rt-9a14223b8f71f4f918ed7af1d8c8f8d27be850b03306837c12888f2c20a7ba40',19,'alexmorgan','[\"R_SUPER\"]',1784611586355,'f6992517','223.160.215.32','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-14d949b08d74f1e1bfec0abc631e5df625d58ab217b48d339c8a7465829e2650','rt-2e7b719e4809d627612d8fd45871c4977edd56da4632ab53d2aeb1bde1d20ed6',2,'lisa_chen','[\"R_USER\"]',1784596391128,'','',''),
('tk-14d952ac55e934725c672b8ceb3cc935fac6899f6e64546e557b225f969dec48',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784346713113,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-16cc2757318205222d58fafa8ca39c4d2fb9c7cd496e95accfa07f40dbe409a1','rt-3f35ea09736564c4bd1991e609aac0a70c9e6d44cc2ea485c4a35ae1d10d816c',2,'lisa_chen','[\"R_USER\"]',1784592818435,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-17a78481d42a9e8607d0570a745bb7e55dc141de7bb1f789741d70f6a0eb5681','rt-6fbca5a06a4bd9aabb70981e2ffbfe0baec9c54ae1f384ff2e40948f946c857c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652622498,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-1842bc91df665923a595d0375b4ed6fe6d82b3aa5624efd6496d088927c5845f','rt-7f5f506ae5b3bc8bbf1bacd184429f37435a910afd807f1d10b39f3b83300c9f',2,'lisa_chen','[\"R_USER\"]',1784650018322,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-1a8a8b3e2e83049c2033196d5d78cb745902b10026df3022a4c7f8106b6fc047','rt-e9d4f8e340bbc3d2e539c539e631d9dd3b82126a510e49d25870121814eaef38',19,'alexmorgan','[\"R_SUPER\"]',1784601641697,'b4f33e7b','223.160.212.130','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-204bfe8364f87e504f58e2ac26001a593939dcfd8336e626e27515116c135d55','rt-7b7dc5d9d68c7398a15da81facddd6730a0ee1697a618ea8cdf54da0dbbfdf33',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652498672,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-22a4ded795168bcb564b64e48844c0090693114b9b9bf25b6497e02c716d1e6a','rt-dd2c697cd993efd6feb360be240954416e7d3c9235f1fb48dfdf2741c56091f6',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532176009,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-22c09e2c2110093a012f553bae491df9ee847c93b46cdaf4d20b9216c648c993','rt-16f0289e0ac76c402a7a8407b0f8ef43e98d203d7ea0838963b3ae89e15bbb3e',19,'alexmorgan','[\"R_SUPER\"]',1784603861427,'b4f33e7b','223.160.212.130','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-23f6365c13b0b1ca0d45b9d1bc23b078ae31f7e0b14d519a4ecd2d31fa054d95','rt-80065c590b207f27160a50003be99999f392b6efd93b7ee3dae9d68cb068366a',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784650018221,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-245a1edadf409b32775248ac063917b6f736902f38716cd3496805fe2b4e296c','rt-883ea509422dffc31bfee92b0e10b85165b9873ea5f0168240e281ff46e5e040',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592739639,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-24efa175c7afd4d9e5676a2ffcaa092bdab04c439abc2d7dcb1704caba729333','rt-c390389ca1bf296dbc37c419d8be624b380034c902962cabb0041212489e9ec9',2,'lisa_chen','[\"R_USER\"]',1784651684790,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2589e47c27aaa7c95f899010fe55d07d2bf4207b2cf0f44f11705857065246c0',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473530289,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-25a41d68eaffa3f2a80c1803e9abb7cb7a5e1add749b782ed4c9ca09b7f811e0','rt-54e764169556b40f7f1195547777b67f7ad08fbfc30e7f9768ce8d44e9a91ae0',10020,'testuser','[\"R_USER\"]',1784582702793,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-27c0037667a323195fa95b0ee639d2f6a6365ceecc09ffe939b55528fa999ea9','rt-37cf48e03df4e1ef190ee2c2c306200d90b83d7d1cedd35c419a774fb5c5eeea',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592542470,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-297145144f96f16fa1f8e605035cefc1655d561684a40c036069dfacab6eab6e','rt-0ac2ff24e202fa73a07da065a7fa7f6a52338b02da3c9cb258868bf9829ce54f',2,'lisa_chen','[\"R_USER\"]',1784594322734,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2be89019623dce8fa78b8ec05dc3292385a0b1b4b5380dc6e66f83a9b910f000','rt-d154eb2792803d5202d37c5551ed2d82a7174455cb47403dc65778d1094b7660',10004,'admin','[\"R_SUPER\"]',1784647067705,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2e01c89e68c6a50cf2f53ecaee739d92a552d8b5ff0bfa5f6eaf11721cc22848','rt-cdbeed0401eee4aa4b8549cfeef42e18639d8106c75d58407650c4769384e5e4',10004,'admin','[\"R_SUPER\"]',1784647130829,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2e7958f432ca6de1731aae5dc83fe01760ba2f7fdc81eae88891cba380f1decb',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784337706003,'','',''),
('tk-2e8a664f717e0c01d870c74c2f6c1fa78d9ca58c6c8424970944ae4bb66450f4','rt-3e7b8424cf5093b21880df35e7791ca8f8e13bb10c2d258f725894fa82b37b57',2,'lisa_chen','[\"R_USER\"]',1784592859580,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2ed72cab21eadbb2b9eeb67609bced0f1d6e4265446556f793f38d85a3a4d4a9','rt-685f1ea50bbf96fbb72895d9495f6cb7a01576aa27279839db674d843e3c070b',19,'alexmorgan','[\"R_SUPER\"]',1784611601221,'f6992517','223.160.215.32','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-2f9cbb1b8ab99b94a81dc6f4ab614e7ac8123af434de16302d1a01e369e4fafb','rt-892340748eadb5b07ea8025281972f07d387ba7224705eebc2e496c25f17494b',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592650381,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-2fcb756243020d533bef4fa1554313d23927179f22bc44e51cc6e84ee27ab3c3',NULL,3,'tech_guru','[\"R_USER\"]',1784346516392,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-30c0367ddc13e08ba2c40cf0692e1d4b0d72c0703cb647a157a8ead92b7bafb5','rt-84856fe081c60d25e20de8c17fb0afa245be86e9922e15f13c9f75d0fe711ec0',2,'lisa_chen','[\"R_USER\"]',1784594532292,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-317244a5269202f3b1c1f1f2769e47ac34223f03f9f190be841d22cfc15b56db','rt-349a3478e8bcbf8ceb86b6652dc25a6c3c98296452aee191b9f992eb4914ed6e',10004,'admin','[\"R_SUPER\"]',1784646884462,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3195a0cbf9e28d0a8a9572182a34798884003dd6bade70983196392e73da5d19','rt-bacdf1cf1a46961c3b955e7da43a6786a58aa1c9ccb9c567010987f441f81f44',19,'alexmorgan','[\"R_SUPER\"]',1784610899899,'30fbcf68','39.144.124.46','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-33baf2bdc1c10ab28efd6f97d9e2d603f806d7d7f5949493af890c2e78c9b4a4',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473583153,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3432c54f6acd4f1f9fcf7761ef78dfa1e658fc964fdd8148124e7fad97dd09b9','rt-5b84d459c3334456752e0d24900f907b1aee38b108aa133a0b19526450134a88',10004,'admin','[\"R_SUPER\"]',1784616995790,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-35a19e8d48009b2f49ed112cfd6cf32e5aae66ea517e2f981f1cdbe5d09f9c87','rt-f20596a4642ecec18212e76432acd2590070576a3a8d6815f09491a34987ff8c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532980573,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-35fee5ae313ca3e4f7c87dbd63df5bb0dda39cfe217b5f7049d590144f7c0d8d','rt-ce8b29697f4d690403dc97ecdab32c1e1182daffe69f78eb8d6905d2fe868056',10002,'github_user_mrnwh1hi','[]',1784647676215,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-38ba09d78ad50dfac66b747d889cb2ac95c70c5b0e7e7e36711f6a4c274dd00a','rt-d946f06c879c8a652fe8e533acc8359dd2f0456f6467526b0f8a6c6fceb0ad90',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784648929962,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-38fa980a48f7b029f52bf6c0661f206f149dca8ebfbb0fb43f0371bce2294d97','rt-28f1c26483d257953a22c6de5cc9b0c8cdbd087cd6327055ce8dd196ace3e4e3',19,'alexmorgan','[\"R_SUPER\"]',1784521042642,'83f038de','112.17.241.171','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-3935becac4af39fc34ce4850f2f26480b0a21fbd7bb1887aa69b0a931949f82a','rt-1ff40ae15cb88ab90efc95e741a719fa52822fb5208759b9c5755dec1d001cc2',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651577357,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3936de2191f11a8a2d17ea442ed5104b72f80399b8fc979a31b7243b8efa7312','rt-6bb8374e8ed364c4e470b2737433170e881a715236d9fd8cc449e326bfa0351d',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784527917757,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-399636ffef0b3624b4fa2d4de6d8e4c187ad4dc6a35909115e92af841f74b39a','rt-72fe4f7f377117f1cd5ebd68f474ae7a1be69bbcab80e21b24954e6ad407e6ad',10002,'github_user_mrnwh1hi','[]',1784647671480,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-39feae83343f0bf56000a4d0967904a4d386b3c6638efa53b1e95abfcfdacd27','rt-68d89019161cd438bfa36e81c780e80ef2b4ccd8942f38f5eb7aa97cef757a57',2,'lisa_chen','[\"R_USER\"]',1784649175669,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3b32bb6806b0700ca3331f7684b4f6e9e95fd8a73e55f2e398cc7b2ceb19e503','rt-835ea521de510bb96d45ac7022abb738d77554385ae1b0d6565b5a649a75dcbb',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649667454,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3e5f937a8e3404ebf66cac2f9731aa7a70138f234fb9e206d9e05c1d3ca0b0d6','rt-126ca2edb6e24f89820e4cbe4decb75593da18b62a609ced591ebc749a2f2861',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474841705,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-3fa29fc1078a1b01175da2dd717279323fb54846e5ead2fe02f43371148ca10a','rt-c6cf24aaab6173dae42bf56acc6ad55033bc7c5b86a4344467cd6e01a7b778cb',10004,'admin','[\"R_SUPER\"]',1784647402260,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4062944f728fc2a5ff291babb0dfecb8fc1e08eeb76b1ccd64e6726d9f41acb7','rt-b7665d427b8f29940b388b999103c3d5dbe63459b25b18fdd072b7b46c99db15',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474743899,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-412b8fd863867db990ce9cd2844058aeefdf54bf273c353cc922923527fb6445','rt-0e5ff2f0595c04586ee395a5525754e109dd76362c6f9cab209f53013c5151d4',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592565458,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-423249607492a668074942f06dccedb6b45a3fae45051753a80e78f43b4902df','rt-56cf4189088f8a34fa68859f0d7f04cbee98332ccd117f8e0b4f18c6368a0945',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474016473,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-434d344d26bb6e49e9500ea3f7731ecb3af9811076dcb64a33bcfbcdfc259483','rt-26431e6b25b1243bcb131cab5323b4cd3dfc22ad90be375620694bb18753eb34',10004,'admin','[\"R_SUPER\"]',1784617585568,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-45454d5e5bd902bfe03a624e3f940176b887b5387ebec3d10cd839fab25a49f8','rt-d220ab5f1de5e9692fbc90f1de6e5b6525d482aafe506f506b23a1e7ac9a78be',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649175560,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-458125796b60f8fd565d06090281853457017f17dc0d4d98db07da4dea66a21c','rt-e03cedb0c5106c870f66e03a1c9f5449bfadc729674ddf0b100944853c89a1dd',3,'tech_guru','[\"R_USER\"]',1784592902275,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-468cace79065473275f1fc530dfff5927052945535bb27334c52a06380e28d33','rt-8f3af3720d1d03b65f6f359774a6c64fb75db531225f059c2a84fba1fef77d9c',19,'alexmorgan','[\"R_SUPER\"]',1784593623339,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-46ad70acbc9ebffa7ec6dc07d5e438b8c9e82bdcd178e3c01db57d6d330d7ac4','rt-53c5d2b917cc35566580be1bb74c490a98607d6945f39731989198ba50e38edc',2,'lisa_chen','[\"R_USER\"]',1784594543072,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-471b9ed22216d0ec5d2a81bde17e5db235d617eb559b0de25969d07536c66a72','rt-e2b7aa77f6a8185601e1d69b3fec08f43176342a56f7a6e28e942d7ecc2fc240',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649939299,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4841068aabd612340c75520273b6737a993cffc02993bf8ec5995757fa20540f','rt-889e9560f529d5f541f994ddba1227f70f6c45c434d3696d836c7e3d6db25741',2,'lisa_chen','[\"R_USER\"]',1784592728516,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-48832eefbe26f3b0dd477e737f2825a7bc92cbbe9b0fa1e5b399347ea38ba119','rt-412134b06d81424c36e4ea54a9cf9b062af139a4144ef4a00229560a30521547',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474778314,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4ac3f919655d671b6c0a863651d06d74a8c588b570cf8f1c59b6a8167a1643cd',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473498898,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4b6182e3280f550f48158fcb17a15f0ac66bd7a04c096a37b27848366863a76f','rt-e094b0c5aafdeaa8ef50137afc09f116c3f5bb48f66f73bc217e272e9fc49d6f',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474096946,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4de0b888843f3763f364052a36445aa2f5593514ab8c7b8cf586ec4af168c21d','rt-151c5f5728847050a0b9d668c00ac1a7797fc960e725ecffa7bfb29da497779b',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592644060,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-4f1fa61761cae4c80278cc5aaea77e92ba893e8cd098f7b62406cca236c8fa34','rt-19b39381b4a402acbb9aa25a0458f8be3a81fc24998ea14918e4caf8a2c687ff',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784650543951,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5117f3ee734889a1be972b5141c81f7de35165fce93cb0ca02436c922d87ac23','rt-f4d92e65175a152ea490a035d75a497687124f69cd0c91cafd3becdf349b9806',2,'lisa_chen','[\"R_USER\"]',1784592697599,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-51609444ae0e29a876a5c6d1c76972015b7e90bb65de79c9ae1693d5a6e8ffe0','rt-620fef6ec867c7fb3db97da79e871ec5e9b1f6adc3d07316b305519e545baa0e',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784653851018,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-51835124253538186f6057cd093bb363b9c46b6baa51d6e0838631b73f23a56d','rt-5c91dccb06707666d03a7e536b1ced630c02fe2ebd9f736c3693b5343f467070',2,'lisa_chen','[\"R_USER\"]',1784652622594,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-54268cf533ac5530a3a4e18ec82b6203d034c2466b0c7acf98a39bb48ce86ff3','rt-b2bba67a19a1ade0b0373196104b161365f59a5716a11df9d971b00f79bfcc2c',19,'alexmorgan','[\"R_SUPER\"]',1784611295763,'30fbcf68','39.144.124.46','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-564e112f6f3097a1818ea776561ad558d5182bc0df62591dc83f024c571013a2','rt-0e0c47a552b64d7e6c39bf704732d24683da73e110e8bc5f2dab2df9aeed1368',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784654747410,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-56c774e0b8360e7fe7a08d9bf0552946019acf8563ee1a6d11cfe681b0a5637e','rt-4d081e9a7acdfb4317d5b28d93c0a27480bd9371a71d02bc1ed19f69aa6c7023',10004,'admin','[\"R_SUPER\"]',1784618377761,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-57110c581a0c87361c275b9ae445d920bef2d43f36302212944929fc5fa6fdfc','rt-483434664abf059528842083b4d28ec135d34290b8bcc86481c7db47194cee65',2,'lisa_chen','[\"R_USER\"]',1784649939389,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-574d4415e2bb759b6725d824a2fb050ed123d2fbbf46695450ec04a440d23da5','rt-7be916ab1832f995742958a50ea726e00077e29c5bc2fb1b190f3c15dbdbdb29',10002,'github_user_mrnwh1hi','[]',1784647908511,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5910efb3e02f92506afd40c1eae2da4cfc3d8035ea8836baef16eebba0b2c72e','rt-e1d1168054369d776d1e637885234c6497287b67dee4d28716f98cf975828e6c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532232153,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5b3d1889d505c9b8d24b8e962d0e945f7a14c10c064546d55b58f30abc9a0b48',NULL,10019,'tst__iumrr3fd0n','[]',1784423076715,'ab54a5cf','::ffff:127.0.0.1',''),
('tk-5d755d2f2d1e41c7fb174d2b5ddb47ccc2eddc1e7370f9ab1eaaa6efabf74ce9','rt-1cd028d1ba0cf0c924b81721e8d01e6f876c5bad2d6760bb6aac61196ab35868',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649929212,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5de74a0cc574f0c8fb0902bfb95dd1682b8069df3b3419609a4dcff45e4fba8e','rt-86f7a99e6137d05bb3cd74d8d29d37c0eac8b215c36b21e773e685de068c027c',2,'lisa_chen','[\"R_USER\"]',1784648864327,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5e487daa274d0b8a7785481d4639da93e17a1eb36ae72b0dc56ead896daab347','rt-5cfd15181bfa0f7feb495ab43422abe71349b18c415ec7a1065b92dafb4666b1',2,'lisa_chen','[\"R_USER\"]',1784594233707,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5e9eecbb8d873e4cc8c119e4ca4511aa5ac76f09e5a24d92e249a0e7199be959','rt-bddce6890ca974a0fbccb0747f246d11ae05f74838225fba3c4cd8fe42f0313e',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784526241075,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5fc9a81fad86303316bd36ad6681c48a04df9fc9b0413f6bee67ca6cf8f81204','rt-c3da7a8b22bb3057f2b3084b9e93fcbd2e6bdcb68f300fa314a6d3c248ee3c5c',2,'lisa_chen','[\"R_USER\"]',1784580363635,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-5fe562d1870214efe74d1f5fee171e0b520a22c71648774c957d8a88bf5d865a','rt-fcd2e430bacb33e6b71739ff5294325dbf93d4915bd5fb1862b6a281f8d3b79e',10004,'admin','[\"R_SUPER\"]',1784616980821,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-61fefa5a2d38e7b72da600672bee7ca3cfbd9ca5bd6ada7f9a9ef3538b95b8ad','rt-74a54c3b74395b9d84de72406c4ff2cba959d9eb2abfbd728fd6ad5461ecdf01',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651989111,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-66027120d5dd0c5d404bde29af275fb8215ef005eff4a788bc0e34d529a4f61a','rt-c3c71b5552ea123dfc747357565351edf54307bd683a51f2167b1c95e63db567',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474097158,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-66114fafcd0e8de2148bfaebe6a1525bb61830874207d86fddf75d364f431828','rt-9c560ea0e6a281a331352d522f6829c43112350fcdd5fed5fd84f66100ea6002',2,'lisa_chen','[\"R_USER\"]',1784592763003,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-67d3c383ff568fcdb5f2a90a013548059eff0d8d3bf32218a04ed496da696ff3','rt-df56dcb633d9ea80d1c2c2dda8153e4899c0ae52bfe6f58eee632af7824137af',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532162281,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6a118e13a5474189c3b96bed0d1ea83390242b3f9051ff76801bed0425321b47','rt-07843827cc5ad3a22d3d3c1e310a98642090ee246acc1c73cf0fd2115c4a4d73',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784526260931,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6c07f648fa0cd1532756536c99c004d4647aea0a04a4a150062af691483eed39','rt-1a1cb820d8081b770ba8de07a7adcee32056df10fd19da61fa34608e03b233b1',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474824997,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6e203cabec8eb2190b2c06a96577d8355ddb9a2b311673138c7d9b4c7e32a5f5','rt-e0478f0ade4181660bbd87e25d19f82bd812c35daa19981bf0035d9c7969a2b8',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784531669022,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6e51488438a25c910cefb15795db761ed59d53aca6d81ef41ab5079b1c75803d','rt-f8b9b5d92c536ecd4cca46ca7cdf7082682bcb9a128cfbf46f698504b2132ace',2,'lisa_chen','[\"R_USER\"]',1784580469348,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6ed1b210a9056773d94b338d19aad0742c6fac46c6fd395b356f8c6dcbe85fad',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473597310,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-6f12d4804f60809252dacd71735d8d981147504b5ee3640d437fdbe2221e54b8',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784346571409,'c67df243','223.160.209.103','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-6f541bf7917b72bbd0055af78ab34f125acdf89f8802a78a0751fa61251f4145',NULL,10004,'admin','[\"R_SUPER\"]',1784324984077,'','',''),
('tk-71015abc08bf50839472a9b3c05873ac879cf4d849c17c92b65230250a31c856','rt-ae8853e20c6564ee1ce7efee87de5ea046589c8ac23a5c270eacc7d75263386d',2,'lisa_chen','[\"R_USER\"]',1784594544292,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-71191811b15282d209f1c4c2484950d3b381391fd542c8f901ffe909cfebf468','rt-cd6cdd2eabdb7ff8cab65339d0a856adafee41a0114c674e8b37695218df34bf',10020,'testuser','[\"R_USER\"]',1784580498064,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7147146083ad6d38d0709688b10a91f8a3b9e7e0fe2553b0a0e932bbab88ced7','rt-9bce0ffb027528ba1e7062e6f05b0392960a59ce31db80d985b40fbdae93e8a1',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651684688,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-71a9573f1593825cf89d775da97ebcd141a5d18ef732aa989ff101d20ca5f794','rt-761fc7f0fe3ef5b9de40b98a254fcd9eefa8ee2e71333d4bbe8cde63fa0255ef',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784648864233,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-71c9b7b3ad28cd8094b690df6b40451a2e759384b45234707d947e399668898c',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784473606441,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-726b328fba20b7ebbc41e0d51de857ad761baa8cf2c59f26463653c241725691','rt-8317dfc179c40ed3bc1c759370ab1290a9148d692d985fa6f03ba0b2fe2f405c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532262230,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-757c05745031953777a26c6780137a907172738749b70f6ba23e8c11b70f6727',NULL,10004,'admin','[\"R_SUPER\"]',1784324932513,'','',''),
('tk-75b98e6d11d471646dde61d79193f4c8bb25b0dd84936caf508d35e33b7de855',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784441660462,'e78d5111','223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-76f0778bf480f84c196248913a1e371b2e96ef85ccd1a1c166dbefdabc93015c','rt-dde162b2bd8b394f6a3cad7486e7b2c95eec967b782ec11c796962aabcb46289',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592638150,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-78593ef942b16d61efe04ef12ea08a83b9b0bffd05a587ad5963d0eeedac13bd','rt-1179da921e2090e8598f4c216af898eac15eefff08bd6eddc33be0640de8f921',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592791359,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7be1eb73e9084e173f3a1f6d201fac4321983257363f7b09d9591387cfbd9bf0','rt-5fbeab21338367da3d31dab6ad27d8134fda67d2651961c75dec329e5fb2db6c',2,'lisa_chen','[\"R_USER\"]',1784654153207,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7e2629c778d42e8d0ca17aec9434804dc7d93c718eeb871a324e7012c7b1f303','rt-94dd0f2e247b24665fe278e3f76c07e64dffaa651ff9b8591ebf2385b3cdfc70',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784531715909,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7ee6118cb9866d97eb6a69a0e49a7ad10ffa878358633860f6af7481d99f9efa','rt-95ddfa1eaadc00cd025339abd156315d523ab6de7063b0ef9ecf847f4c564055',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652030969,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7f56a93df4460369e2a9b5e5d443f4dee9be428dba64f2ee8f131d4ce1c2628b','rt-3bc1dc2215bb63c07258c876c84ec4aec709d44957a1e47685522c648fcac4d4',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651116240,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7fd650a6c4f09fe3c4788f9c45bff0dd7c7d2aa453c9d25baf2e3026347dfcb6','rt-b85188a0eec6072cc7c73c04958aa36a5d2bce1f20f1bd26fba7db482612fb06',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592722846,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-7ffd9d998b63de9f61b4aee41391a9ceb9b9c9b0c7f5dd5503578b8512331f99',NULL,10004,'admin','[\"R_SUPER\"]',1784324871035,'','',''),
('tk-806cfdc96723f3c666d6feeb7071b4faf19f145eca6ed81dd18550bf2b870e7c','rt-d67f3454feacdf2ad32e34e585b7c01793b9a983fb67680af95e9540172f546c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784534993991,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-83b6db9a1e087a3a0b9709068b279f8dc78e79021faacf09a0dfddd471d332d6','rt-9957a456e3520842d1320440706258fedf5a5a740884db2e1ccad0368e23ba47',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649957189,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-85c11347a89437209472440243a04e8a969e51d29c05c6949cdb30aa246c9ba3',NULL,10001,'35735712','[]',1784325327974,'','',''),
('tk-86d5e26b4183d83c598c168ee5c75b8964026e65e83b08a51b395f41c9a85b2e','rt-907650f1e9bde58d23c4630670da83910ef27e7d65140fed0371dbe81da4ce94',2,'lisa_chen','[\"R_USER\"]',1784592722717,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-880568e0de4025b6c8b13df15a77844122e1d2b5677d223f0c0bf94d3a6167ba','rt-e6f908246253cb7ee10d035636722cb326ae73e368782233f0cc2c88eae6b5bc',2,'lisa_chen','[\"R_USER\"]',1784652498763,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-88a770e098d573190997bd2a1761c92c472cc1660a134ce2f7e2d2e9f30b69c2','rt-4d356f85e71703fa9c2738fd5769e7812abe1c3b8fa5681d55e3af8f7768ea6b',10004,'admin','[\"R_SUPER\"]',1784647063224,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8912413650ee7792eb140ed4d464124b404f2771909c60ed549d579a1859a8c8','rt-910a5214bf1e8e0db46784fda049ee3f3a97fb6be48d5e86cb1ea8c61a4d3484',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474011241,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8914a8b476914c464ec4a56dc4a0e7320f89ba2be2edc8363e0ca31a6fbebfbc','rt-49efdb0187ab32e8ac45c05ac516c5a3cea6a0a26a2ec89aa622db425eb1f7dd',10004,'admin','[\"R_SUPER\"]',1784647671383,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8cbad2f72e745f2ad62ea1ae2f96c12d70470a2814e138c45364c13d1f2a6aba','rt-95193c60aa961f225131ecceeddd3bbcfbe190ea12b0e3890c059e2df772966d',2,'lisa_chen','[\"R_USER\"]',1784592791471,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8d21d33afba55faa810e154b0a9a895e7fb75141566d78fa109be984397989a7','rt-a614b97b72f079aed43ccf397baf4ebe2a2b0b68e50a050cb80f60502f8c6be2',10004,'admin','[\"R_SUPER\"]',1784647237972,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8dd7f38ff9b7f1236a2b7766715907667fe8df9b39b856d12196f31dcf1fa8d5','rt-2df42a797093b95fa20d30922f05b0a8008f9be28deacd544ebe7caab41053f7',10004,'admin','[\"R_SUPER\"]',1784647535399,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8f918f29984c4498e9d9a0f1bb3f2c6a4ca6f25b90c3220ab9aaab98aa8ce035','rt-a0c34a8377cdef9e5eaa2344ea1703a4776691058fb065d716aa12eac8956f3f',10004,'admin','[\"R_SUPER\"]',1784617820508,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-8fac0f5c542f1eaee3b76e985052635b77cd84ad29a6c4373fb4c597a2ae2ed7','rt-ef64d3152a787803ac6a384a14a63d4bc63833ffe5eef35d6b515c044e97a918',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784653812666,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-908e7cbde9ed3ad760612157a48c9b0bc88953085603ae326b863337210d0824','rt-083da18536ffd921eb2a1862af0e8b4d59c2baaa51942b4d63bb250bee972500',10002,'github_user_mrnwh1hi','[]',1784648104212,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-91e4d0d6c20ddd510acea10f93275fd7e8e14d9bc32f35d132991495b25df0b3','rt-5d90ae380ce48ce3aebe5e2fc3243b53416fbfadd5490a73fc80bc26141f5f10',3,'tech_guru','[\"R_USER\"]',1784593359211,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-9237ec0139611358e6d88001fe6ee38b28d468981d7cbdbe03c41c8c13cdfafe',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784340529972,'','',''),
('tk-944c03df20270027b30d61bd910f5d663739f4b42b1bd5535312a2ccdcc4c0f4','rt-7bbf1b39edbf66d898c7a015217617410d20ac371da4adf81c2d4f5f6642b86d',2,'lisa_chen','[\"R_USER\"]',1784651577472,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-9829ef8bd84b9ae0e5d1f6d4938df2df0c19da0e306224ea488911759eb8cb4c','rt-b0c13f21bd3a9e535844106681651694970d6ca3a099a11f5119d8a0da85756e',10004,'admin','[\"R_SUPER\"]',1784618143831,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-98ab1b306536c68f0eef45a76952501fba00deaa4184d02759ec7d37bae00f13','rt-fe78c106026bbaf8dfcb0aa1c6157c1cc9392c5fa5c05e3ce7c390f9e8c6e98d',19,'alexmorgan','[\"R_SUPER\"]',1784593746305,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-995aa47a31e7f9bd5e13582a6e437227af68be3324a285dd92b9291b1f33a264','rt-76aa660c11b8bb8f265167305f831558855da14d0aedac1f12543d2d6c9b92fe',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784653801164,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-996f3f5b7855cb5ae4c3d0cc646d5f237dba7f9a1a8ab29b3d2e8b83d4bce264','rt-ba1e202314cf81243f28ea6a52f619523c1e4d49e1fe676109cae8c1f60384cf',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592859692,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-999d546183b5c52f96e2b93d3a067687b4a84977f14111dad30e353e44668185','rt-c7bf06d4e6ed35d59d4422bae9681c9762ad7ade4eb31336fcb4492717080e5d',10020,'testuser','[\"R_USER\"]',1784582698622,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-99bd5f5f806da059bea4039a3e6f20393819d24fcc7f8eab3acb096e2cb213a1','rt-595edcbdc72e6a196193a205624a2d593cea0f1766d2099ab278023e6709a5a2',19,'alexmorgan','[\"R_SUPER\"]',1784593529079,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-9a6968ac1fe4243221f06037791d5d3b4a9dbda59e0dc6464643e0710a03c129','rt-5bcfb8bbfccafb9084b793ff32d04339abe16fb9c7e861e134a028291406c5b0',2,'lisa_chen','[\"R_USER\"]',1784652491145,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-9b2045df5e132e1f5d78c50c0a5775056f4e22e59f189b410bf7ffdea5e9fce4','rt-651baea1ba3c32886e7a6d4219373dfddc018bd378d4f543c2fb48074c7ae2b0',10004,'admin','[\"R_SUPER\"]',1784617193759,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-9b5f676bef7651b81d409a2d7e282992d7a9180776b1e7cc5eb123b23047878c','rt-f753dc3d716ff7f64a268e62ddcbb00f25251814c3f1c54dbe6ef42c5c093db3',2,'lisa_chen','[\"R_USER\"]',1784649957280,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a0aea41c1ea67856d0b9c2a9b76e96390fce1e16a14844c8b7b3018ee0a6af4a','rt-73c92a14aace98b761f55688de91df8538e5a281985d3c69d813c32a04b14112',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592886144,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a2cb32e25014fa5dfc06f4d849fd62f6ff887263bcb0faac2a43437937d5a574','rt-9e658be22be5a4b92987c167f7c9f1e1fc2e546d7a3e6883e92f97907773bfb8',10004,'admin','[\"R_SUPER\"]',1784617695441,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a6579158571c6acbe8539fabf690f93151aab773006e777f414d5fe1f2b3549c',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784432920122,'e78d5111','223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-a71d8e0d381e23b1eb0ab524cac0af2841d72eefcf3762b56011760eac3c693f','rt-c333fb1e8726804d3899f13260fa23586c9f7f66bf076ac945de2ede76700bfb',2,'lisa_chen','[\"R_USER\"]',1784594207137,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a7af7d35fbef01ab6db83d01e623001816136019e9b12f938e65eb0b45b9d6b2','rt-7dfe7f5227129eee7b1ca686727d7c62ab56187b5d341eed39b672cbb15e9d17',2,'lisa_chen','[\"R_USER\"]',1784649667571,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a7e40956373cb97332947044b4d6b5260adba30d2c7de05888e7fd55e3d65573','rt-27bee1897bb9247c950b50535d116e4e8aad4949a52d9587cdc3d85a832f470c',10004,'admin','[\"R_SUPER\"]',1784618031412,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a871a887394fe187a19241b82a3fe835b0534564ca4005c73a3fbd84be30cc21','rt-8e002498c504d8faa2285f07b7af459fe05028346804300a6be358c081682a53',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592818325,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a909a2d02fa1b88171cc47997aab35c7095c5707e5de47e40def80c8dc9fae2e','rt-d9dfbc963d84973c07848c1a0baa01ad61803f82c2510a6e4f0f50e2d2b199cd',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784653304246,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-a959894a18a8e8fa3f6e6404c1ba4de26a28b9d57b381b730b8b363307d7f509','rt-d7cf9ca1545aa0f6b8e4fd9191a3776773aed6899516662a70d8a7d401786bfb',19,'alexmorgan','[\"R_SUPER\"]',1784616623043,'eecf6a97','223.160.209.213','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-aac584def53596713ac4fc63337c006be1b136a2e8e61c5a5e08753ab4619381','rt-dc88503552a1a98c74edd1f6e25ea3a68e3a030f08490b6d3bbb2593d0a9f89f',10002,'github_user_mrnwh1hi','[]',1784648251048,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-aba29a0ad22241b35d51375eee6cb558e0c09f95c1e92c451406f1a108c02e40','rt-d9cb1cf2c88054a1d33ce14150f7315c266c396fe5e1ad6a45f733a145af2c0f',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532290277,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ac400ac80914cdf5fefb7fc649894d1c63ca8c63fae777581c4fa76e7c28739a','rt-8d638944dd6b47ca07275f03e6ff9b003e9d6b5994797675eb3acb78b75e7cae',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592546260,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ac486afac8ff2955209aaee9be8e030f478ccd3a9adf2727351377bd1d593926','rt-54c5e0bcc2b4f5257316a635499ac6510ed05652dbf7de7233e35d1ecd3a145c',19,'alexmorgan','[\"R_SUPER\"]',1784599764289,'ec9d5575','117.136.111.25','Mozilla/5.0 (Linux; Android 16; PMB110 Build/BP2A.250605.015) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36'),
('tk-ac5b9ac0eeeb2e59eb25fa07532733f8bffca0393c0733c4f71c094a6f7257aa','rt-69a47e6b1acbb82fe3bbf1cf1756c50732ad7834894c17dc9a808748c367d034',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784649016537,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ae0a585ac9c5a8ec368aa162d05e383f0a69961943d7e01c89c1d4b78d82dc7e','rt-d6672243ec6953c51ee63a870e990a29a62e72a30707764e1ff8724d7d02db53',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784654153111,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ae92a3e7b63e65644812b01a8420ab50f876b55d2b3acada237d50bf7155903b','rt-73de3f6a83e183b7d7e8e4c50bb466979fc71146533815fe0a140a57e049d800',2,'lisa_chen','[\"R_USER\"]',1784580469001,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b0c056f6a5bb070232b469582097adcafad08aa19644753769b24fe87dc6bf58','rt-7839a88c8d78ef57b6d24653334e540cc7839c533218c97ccd2c9c97e0cc5134',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474846125,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b2273b893cc75ea67771336314f69c1b0a6c1d665796897073ddc09e8adf556b',NULL,10017,'tst__dbgmrr2zdy7','[]',1784422330653,'ab54a5cf','::ffff:127.0.0.1',''),
('tk-b22ff147cb5a46ab88bb5d84634506ce80155d847ee7a2e05b4a2c143a68c5d9',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784344965767,'','',''),
('tk-b61487be88b6006ada350320060dd62f853673b565ca26d60691ac2ebfcaf8cd','rt-50f17ce3ec841963166dc344b71b2d557502944bc7dc8d04bf1a466ff550805d',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784534993365,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b7021f02aeffca06ee5f00c1438bc67d4a643994c0a271c695a22e0e580c4310','rt-b1d0bb164bcfc57cbd196a1e15cb85248f2a714f77a0dc35172cfabde9efe144',10002,'github_user_mrnwh1hi','[]',1784647541157,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b78e5f35cc987eb5ba41f3966c17ae15d5a3834ac35ff3630bc1214aa1fb4a2d','rt-a9b789568c661e88d20f20015663c11c27f8758d6ef0090678958e3fb8b71807',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592842614,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b813b020d59d1615459ce5979b49592e71889a8249f40b07ae05a73a14b28188','rt-a32d8afa0444188109771b972864965b8a61148c6da8e0805d488da63d1f1630',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784650535319,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b8730c9f2fc36b7ec652b4428ad7ba607246e1d278d35026aa5f0084de3e0438','rt-d17815c3a457219548498f4e591f97946e393ef4367893658be0789e3258c80a',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474791682,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-b87fdae5b36497b41abb803e40e50276ed900ce4c62029c226f65751a2370ff4','rt-f9091d975a51281256b4e236444a29de07623db8ebce65307633ef17afb5ff09',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651485051,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ba6a4f37a97aec9229b3b0e8aa816d09f4eea9a91b26143f72fbf998e73ed5ad','rt-7aa5ec24cf5c9461f51ae695c2cabde73c2e93524114ac19aef709bfe09b2f7b',19,'alexmorgan','[\"R_SUPER\"]',1784600200123,'','',''),
('tk-bb87765749f38975a36380164f173aec9b4fc0ec81b04336bc43163ee160c391','rt-39ac347393bd15d3f46bb7f55b1585bfae8536b8af5aef3936ae2fbf54aa86ba',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784653543347,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-bf54a584adef8cb24310a47cf45fc5353587720fe251ba7dccccd8ef846e9ee7','rt-8a2d4d462bff4898c91f99a87e62767cc6a0ad29414d2bcc143f770da1e8d323',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784648653795,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c177aee6b43d52fb313cc0667f7989d41ef0b2417b7d8c2a4b509398149bdf23','rt-d338ceb97e265b38427c15940ea99b2ecc591b601d3b8567ad769ee1dc14e4e7',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532277311,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c199e4b9ad777691509cdf75aa438809d6663f421d4b2034e7444f0cb523611e','rt-c32560a1715c0178baca78c35b7ee9df31f73f2f77f19bebb05b1c12f7962d9c',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592573238,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c1cf29f423f80ea87c9228e8a3a1b50787530c6da649a39df7a5b2b68ee046c7',NULL,10004,'admin','[\"R_SUPER\"]',1784324857092,'','',''),
('tk-c2297dbed16ecba5fc23fd306ef9b7b4c17144979a69eeaa7cdc41df42bf991a','rt-2f0d1ae7ee5dce8c9d40997f2a6a7a241b516de901a2cef9036f7ef5571277a6',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784535063752,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c26a193d20e2c5b989ea0709df37fb6c21a3d6ad399127545f87031908769ff6',NULL,10004,'admin','[\"R_SUPER\"]',1784324848790,'','',''),
('tk-c2a86341a2edf68030034a8c0c48312c451eacfbfb9ae86539204ea6b709b828','rt-3157fb0eedc065ee99431d2d83d090c6bc0b5fa743d76244a6e6c58ff22dc808',19,'alexmorgan','[\"R_SUPER\"]',1784593552821,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c3db57bea7a1fd4400798fb646fdafb06c7e4a15b53bbb8345ed0b0361157d5e','rt-f095ffa43e5165ae21fbe60a8c28ad3edb7fbf882a5231f4c12441a2aa5fc07e',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652026109,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c582e4f660618fd66133156438aa444eee3259a80844c02b48549b0cf6c955e8','rt-5915670b4faca0a704569dd31a660b3465dbeedd0c82b6195070d2eecd8df9a4',2,'lisa_chen','[\"R_USER\"]',1784649016629,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c5aa529c684bfe645d13b85e8a2b655b9410d4d901981594c4b54793a3b8a2f3','rt-8c0d81a0fc2f607addb510d70608a6728d674f3fec6238663b2f9e6824f5e8d2',10002,'github_user_mrnwh1hi','[]',1784647925054,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c7bb78fda0d3ab67f71d7f112426597ae103a51e2939839c586d9aebbaaabce3','rt-6cc18ddea9281ef01ec70ccf99a6eb00172040b9a27c05ee7d8c4fbdf4356940',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474915424,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c8c9b3f40f0b48e08df6c52fc94dd342699e96c3ba79c39fce31fa442136114f',NULL,10004,'admin','[\"R_SUPER\"]',1784344830146,'','',''),
('tk-c91f1582c3197b78743a6afecc530fcc1a61eb715f3781825db7f663cc72dbe7','rt-046f6a4e4523d46466d3be8a37b59706168b99efd30383978b7e927e669070e7',2,'lisa_chen','[\"R_USER\"]',1784594644334,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-c986885ce14c93c47e8e1dbac5af4c038fd784c1bb0576cbe8845535547fff57','rt-9e6983df46f53b9619e5934b9850eedfee8bfe8d2f2bdc717dccb14ee25a860e',10004,'admin','[\"R_SUPER\"]',1784617102589,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ce461f8d7b92df95e630b2b7af0e9f255f62e6c4e9bb59fffbded521e3f310e4','rt-8d11fcc37156c45c6cdc672695cb8d068120cb3c38f8ca5edcd5056c6bf6d325',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532232352,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d1f80e7e895cec9b907d534efb925b04836d57f3473ce1be21c7ecd1d4ab6e47','rt-2bee2501ed38bacc84604646ca666d84cebf5feb6447c94f747d0c26e2523b90',10004,'admin','[\"R_SUPER\"]',1784617327845,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d38052207a48bfc33e1ef7fc81d43710c35b098dc5196050af9f28938455d59f','rt-b927f4995ec719b6b5b0fc9e7235ed55834e4ba712eb6fcd7d2408a57bf32df9',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784532254774,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d3a59a476dafaa17a29699ba5df2c7f29d5428aee90f3b20d823e5d02c8a6dfa','rt-02f8750fd2da43d2c3385b40b1d2827c22357661e5ded8490a79ce5f5c1d6b24',2,'lisa_chen','[\"R_USER\"]',1784594522405,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d3be44b0db4b9ae267f0aee817b647203f4b1abcc4911c4aad7fd25b9cec743e',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784329528110,'','',''),
('tk-d42202c9e574739f2ee21323deabb2b203a34f81115760589c6dea0978290c2c','rt-2e688e0c4f2a600b7912bb1a7194b415fc37aec92b9fde2a7ef3d4c559bf066a',10004,'admin','[\"R_SUPER\"]',1784618191822,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d58847e282944e0bc4b6d59d90bdb14fde3838d7ea26ae342cb32ac28f6e47d6','rt-aee73c90c7865714631e4fca163647db1711bb827317d04dd83ed8413dc202d7',3,'tech_guru','[\"R_USER\"]',1784593343597,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d639ed27e55f924d2d3e407d0f3bf26af5bfb6e2958aa8194c8576bda92c61a9',NULL,10015,'tst__iumrr2ybls','[]',1784422281296,'ab54a5cf','::ffff:127.0.0.1',''),
('tk-d68153d4ac1cbaca1acb74b66521a6dac2c39f3d078c2aa3f223e68afa6cf326','rt-c2ba5b7d1e816f7764baa76f51f40b610183cc4e6beac92c7a7db438dcbbfc78',2,'lisa_chen','[\"R_USER\"]',1784648930058,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d7531c3df24848442f6224818ba6f7890ee69b1677f4bc7263e9272750d066a2','rt-4fc19414b8de2b8c48a69b46c4d6dde5bf52a4fe4eb73c48dddd0bf6657c3dec',2,'lisa_chen','[\"R_USER\"]',1784579970998,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d77e827a94144515c7686ff36089d1ee4bfa7ba73e112022a94b35ac78657803','rt-8f5638028b864be8325a740adaa81a9ef49b160b21b6b7c7325e6e0a84e83656',3,'tech_guru','[\"R_USER\"]',1784592886034,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d785b550dd927538de0e1109b93dde8050d7f58100325fe16e5a75d2ce5b91f6','rt-e19730f2c767d4accbccb4abb94fd9cd3e495819f84d182d009f43fc8e17dfd1',10002,'github_user_mrnwh1hi','[]',1784647738421,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d7adb4671ac41d91d21c5f05b1a82a21be84840c16d4d2c241d1fafe82dd4c19','rt-41dfe7c3adda9e151e80afa141c265fe87ef639f17fb8d3d8effa453de5222b1',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784592598621,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d9ab9703d650ba18e2a43d17cc4cb19f6f0fb83de952d07710e72be5ca6a074f','rt-1ecfe5cf06d7e968ecaa3552d7f4f28d828530f897eb2b0a51c586b33d4375d6',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652020830,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-d9ecef906e1e8ecd924307b5fb07471b06b2394f069afbe423d15cc7a61cec26','rt-276a9b964a4614b6a6b16290dd5fdc20e6afd9928746e268514af1d4a219c814',10002,'github_user_mrnwh1hi','[]',1784647445936,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-dccc09ce6072cfba4f15ac232b9c9667251a6b63a6059e429db524cffff2541b','rt-a344f562c6d5da1a039dfa9f2dceedf516e12af1f7b2c786d5c76a4007c730af',19,'alexmorgan','[\"R_SUPER\"]',1784562839397,'a49bbdcb','223.160.209.100','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-dfd40c18c8ee6841d979e73a1873adae33f658e6e9e00a85407fd1e0db325277',NULL,1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784469621107,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e1522c28722b5561485bf944e95f04cbe3f55c8f33a0aea87b63c0151288c5fc','rt-0ecc898dd7b17cc9db5a054944fe46bf65b68a267276240be89f91914f216a59',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474856370,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e190eb781a8ee4095aaebbf7cb956efcdb5f16eeda2c749aa47002c891a46cbb','rt-b90827f990b11a0235be615926d7ee2f4ea5923c1cdf0990c67f9e579f99909a',10004,'admin','[\"R_SUPER\"]',1784616989269,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e31c1eb6711b8b33384fad20a137c643df0113be6b7dc205d0571d9d6fe03250','rt-5c5659a8dc1eb3cbb9a063f2edfad7ff8886aa72cdbb30714bef86b19d837745',10002,'github_user_mrnwh1hi','[]',1784647915176,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e38a8cd66c7555ecf8e517c0c3d10c6c3bbcdf642b6ea03d5d0e624e7b6ba165','rt-82bb610ff126a3067a195a48b65bbb8ff45a312138e76d98b80206458c570a4c',10004,'admin','[\"R_SUPER\"]',1784648104119,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e449867ab797b6d29421d405aaadfc6bddd08781c18a618cd85b099a694f84c2',NULL,10004,'admin','[\"R_SUPER\"]',1784324944006,'','',''),
('tk-e5fc3cfaa9fa6538fc68bb24e1b818f4c451db8f0884eb77462aed009dcec96a','rt-9ec094f0a6e8d8209c52f2ac927cc791b6241b526c85c1fabd6bc57c15023170',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784518183056,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e6d76a16410eb5d037a38e7e79eb07daf4760ae0d2550dfb0ff262a209b48236','rt-37921ae2fa036f9995a654b7085f6422514126a218ed7b3c325da88be7eb9d59',2,'lisa_chen','[\"R_USER\"]',1784594643968,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e7384f8e226ffea767fdc27c62e3e9e03d1a934daae9d57d0ee3afe52154f315','rt-2f5437f5a352b34336fbe02fff1cbaf946b34411e1425e6a7986354ccc29af27',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784652449228,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e76298d8c795f5e97644d71b66fca5b4ee050850223fb9ef827e23685b11c705',NULL,10018,'tst__iumrr3064n','[]',1784422367474,'ab54a5cf','::ffff:127.0.0.1',''),
('tk-e78539dfc3f543bb4d424a2e15de2531cf2fc9853f4155a30b042ab14a416ed7','rt-9d18283766f86ee6be29b7a1091174caf624d506613d28419fe03aa5eacd08fe',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784651994131,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-e8342d0d4518d273efbbe79a3693aaf67b5723143d55afb6de3bb8829d2bd8a2','rt-21cd75f1cdcdd79790f54af98cc249f5d328a1c38763f0ddc4edf5de72a62844',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474063705,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-eb08df50fa1a7fe5adaf4dd1584b9445e8a1f491e05269ddc6109cbf1f9abb7e','rt-e8a474c755833aa723d9faf89b6ef6ab87e0556c4debc57aaf290a4f59918f03',3,'tech_guru','[\"R_USER\"]',1784592872209,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ecdfad743caaa8f074ff9a912141c4333af9a3c1f7ee31998341fc480708f4a8','rt-9875f709681dc796d28e3acfe4106bdfca3c61caa0daee7669dd5443ae142426',2,'lisa_chen','[\"R_USER\"]',1784651485154,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ed172e0df9cb8e1fe9e6c0c3c777a02480145f587d756fc35bc74d6b4258d3fb','rt-4656fe9646cb4948b56d6fa8c0d1eb0b266e2dccaa3628636e8abbe79aa30726',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784579817969,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-edbad59765e946a2bc61bd9563b68c72125d8d3316ee5c390879fcf8c151490b','rt-09908682fac60c914eef8e5a001a0012e0cfede0204aaaf2361163106ade151f',2,'lisa_chen','[\"R_USER\"]',1784649929311,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ef03536c2a77972181f70fb1bc425c119a295c052d5c2ce15c823a0350721309','rt-9ef044c3fd2370e9a276e7b49e875b16f2e766c8d4620102ffab33a44f4c69e0',19,'alexmorgan','[\"R_SUPER\"]',1784593562124,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f17d5ac010a4f8692169bf9b8d588d402108ea4d35f26cc17d99190fc7cff6d6','rt-4c865bf9d8b093e6423633eeef35fc7785236a1bab1154da291543180fcc6dd2',2,'lisa_chen','[\"R_USER\"]',1784594243612,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f270450a5fcb8d2f79c5ffe43a4f58d7c348a3dec649cd8b401143816da96678','rt-cad492d4c268a6d6b4711d91b1e1c91f42e612890919df51fb0831427fe66c2e',10002,'github_user_mrnwh1hi','[]',1784648109036,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f2fc5489179951204a52a02ce3be419cf943e07e906e1ce2e6a95383cca310e7','rt-c70e50866b22a30eb2b0d00cb3380369ed149cbd9d7814b39a4d982b6efec85e',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784531701748,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f32ddf5fb63cf5686c64c87cd99c04cea9625a1e40e581202b35a865a753bf3e','rt-c81801865aa04f2e60c04cd1b14f797c3db58144f247fd2dabea7d8a51d9ab8a',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784526251654,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f3af485244d5ef6f8b4b7109fdf340b3112105d145bd28857fba8cfe7cfad9ba','rt-dade76c87a21e1566dbbd854316877b5e69e4c2ba8cf7dc6a1d4bd2b886960a7',3,'tech_guru','[\"R_USER\"]',1784593529221,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f3f0486f0f142cc79769aa34e1a187fb8f19c4adf9668e9d5094de6e12e4348a',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784368613717,'ea1ce342','223.160.213.162','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-f7287667e2b724df3334223ce2ca6a08a72fa55c4b276748d3602c410b1ceab5','rt-59ad6be13933baa3be7dd3fcc9fb7db88ae351c2dffc373b281a2057fd5a63a1',10002,'github_user_mrnwh1hi','[]',1784647535497,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f7528dd9e63fe579ff14821eea06ccae51c10091e018b0fb3d057e802924114b','rt-1ebdfcd90265de0b1e88e3b0f234dda3adfc5e1e24a6b453240361a8bd842c4a',1,'bobwang','[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]',1784474063642,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-f86fd77f71ea2d5b77ffe21f20c5ccdf85c4b42f43ded183afe4da3f07793c9c','rt-26d8b57294d79d4c15b32aa9c6c34a735ba488b61088ca47453dfb0f8bbce45a',19,'alexmorgan','[\"R_SUPER\"]',1784593343738,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-fb1251cad8f0c6e5d7bbdb104fec160c4b7f722bb0925955a80a6b3a1f8e6fed','rt-73f3d43c8d655dc1e8600b4b6b06a2bcbaebe9b2b9d5bde1339cb1e96bd59692',10004,'admin','[\"R_SUPER\"]',1784648250953,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-fb3503aec577c8dfac41391a499bcddd9307166ca2251f81ac87ae1149e9bd7c','rt-77770d831e267bb95752c0813372fafbe2c3594d2fe3575b83f4b92bf5215477',2,'lisa_chen','[\"R_USER\"]',1784592842717,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-fc38c4e7f9ec1907ef27532af3ea57cc1f24140591365064292d1c5f78541368',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784441634544,'e78d5111','223.160.208.104','Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 NokiaN97-1/20.0.019; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebKit/525 (KHTML, like Gecko) BrowserNG/7.1.18124'),
('tk-fcd716b6e896f4fbb45d2a47e8a7db3adcebbf7089884af69fc38ec5e39e2838','rt-eb67eaf7bc1410aef69773efa8984593f75d505212bd7149857ad3779f541498',2,'lisa_chen','[\"R_USER\"]',1784594670197,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-fe30c092b360077209898d7732941bd5d1d2d57145c04bd46defd29c8a681419','rt-32676b2c66a899ebd7cfac93039fd68b7a358c461fdb54a868f00214b1ec16d7',10004,'admin','[\"R_SUPER\"]',1784646807693,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-ffa8fa407a344500541f8a50006b95d99bd9606967c0b703dfc1984b12b6a249','rt-fa592c2d2901ed578492f738c1a5c1715abe559d6892b8efd98ec44250040b3d',2,'lisa_chen','[\"R_USER\"]',1784594382414,'47a61619','::ffff:127.0.0.1','curl/7.88.1'),
('tk-mrfk5okg-129851np',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783725583264,'','',''),
('tk-mrg46qdb-szhx7sqc',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783759224575,'','',''),
('tk-mrgad3qw-rnrp4va8',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783769599544,'','',''),
('tk-mrgc0orx-p0nsa89s',NULL,1,'bobwang','[\"R_USER\"]',1783772379501,'','',''),
('tk-mrgc0ow4-uotcfq2l',NULL,3,'tech_guru','[\"R_USER\"]',1783772379652,'','',''),
('tk-mrgc0p08-pqa1qoo4',NULL,4,'design_master','[\"R_USER\"]',1783772379800,'','',''),
('tk-mrgchwgo-dz58oa1n',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773182616,'','',''),
('tk-mrgcjyhh-sja3mo7z',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773278549,'','',''),
('tk-mrgcnsb3-t3h6lw3t',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773457167,'','',''),
('tk-mrgcpony-68g949q2',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773545758,'','',''),
('tk-mrgcpzf7-n662s75k',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773559699,'','',''),
('tk-mrgcq6mv-8z38m2ei',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773569047,'','',''),
('tk-mrgcsjbk-m4hsv33u',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783773678800,'','',''),
('tk-mrgd3k5l-hmyipn7o',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783774193097,'','',''),
('tk-mrgd6163-xfdq1u97',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783774308459,'','',''),
('tk-mrgjd87i-58ot74sd',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783784721870,'','',''),
('tk-mrgjdea1-cpg9s9kk',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783784729737,'','',''),
('tk-mrgje0bo-4vdtv9wd',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783784758308,'','',''),
('tk-mrgskq3c-h4w2r8p4',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783800188184,'','',''),
('tk-mrgstn55-tt0eerxs',NULL,1,'bobwang','[\"R_USER\"]',1783800604265,'','',''),
('tk-mrgsvtp9-tgtvzqn3',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783800706077,'','',''),
('tk-mrgtrv11-a5zppgie',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783802200789,'','',''),
('tk-mrgts99p-vma1ciui',NULL,1,'bobwang','[\"R_USER\"]',1783802219245,'','',''),
('tk-mrgtucc7-1xz6xtv9',NULL,4,'design_master','[\"R_USER\"]',1783802316535,'','',''),
('tk-mrgtuu63-8c5iku9t',NULL,20,'testgift','[]',1783802339643,'','',''),
('tk-mrgu69ep-98uq3tzm',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783802872609,'','',''),
('tk-mrgu6lr1-5roepkbp',NULL,21,'testcoupon','[]',1783802888605,'','',''),
('tk-mrgu6xgw-746zygcl',NULL,21,'testcoupon','[]',1783802903792,'','',''),
('tk-mrgu8mog-a4nbvjy0',NULL,21,'testcoupon','[]',1783802983120,'','',''),
('tk-mrgu8usw-rh8mlgoa',NULL,21,'testcoupon','[]',1783802993648,'','',''),
('tk-mrguv54m-whr72x3e',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783804033462,'','',''),
('tk-mrguvbql-q0tsuz5j',NULL,22,'titletest','[]',1783804042029,'','',''),
('tk-mrguvivz-6iwhngeh',NULL,22,'titletest','[]',1783804051295,'','',''),
('tk-mrguwd7a-9ktuzfyp',NULL,22,'titletest','[]',1783804090582,'','',''),
('tk-mrguwl7b-gv9tg7jt',NULL,23,'birthdaytest','[]',1783804100951,'','',''),
('tk-mrguzcqy-esg4s3id',NULL,23,'birthdaytest','[]',1783804229962,'','',''),
('tk-mrgvakky-j0i1gyj2',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783804753330,'','',''),
('tk-mrgwwogp-n5paqkpk',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783807464409,'','',''),
('tk-mrh16338-qbd0g9g6',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783814621732,'','',''),
('tk-mrh185ch-oayzmdi1',NULL,1,'bobwang','[\"R_USER\"]',1783814717969,'','',''),
('tk-mrh23uv4-5cohapg8',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783816197377,'','',''),
('tk-mrh711lj-pz1iqkbe',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783824464215,'','',''),
('tk-mrh7czzy-rykk5w4b',NULL,1,'bobwang','[\"R_USER\"]',1783825022014,'','',''),
('tk-mrh7d98a-t5h0d143',NULL,1,'bobwang','[\"R_USER\"]',1783825033978,'','',''),
('tk-mrh7d9bd-a1u7de3u',NULL,2,'lisa_chen','[\"R_USER\"]',1783825034089,'','',''),
('tk-mrh7hn20-d0hoxp4d',NULL,1,'bobwang','[\"R_USER\"]',1783825238520,'','',''),
('tk-mrh7m729-gnizj7pl',NULL,1,'bobwang','[\"R_USER\"]',1783825451073,'','',''),
('tk-mrh7nmyb-y8xdvqbk',NULL,1,'bobwang','[\"R_USER\"]',1783825518323,'','',''),
('tk-mrh81vp3-hkvdsmuj',NULL,1,'bobwang','[\"R_USER\"]',1783826182839,'','',''),
('tk-mrh86kp3-8v7j3txx',NULL,1,'bobwang','[\"R_USER\"]',1783826401863,'','',''),
('tk-mrhijcil-ua6l9ulj',NULL,1,'bobwang','[\"R_USER\"]',1783843793949,'','',''),
('tk-mrhjkkut-2b2wzuzy',NULL,1,'bobwang','[\"R_USER\"]',1783845531029,'','',''),
('tk-mrhjkvhl-7ckkrp8w',NULL,1,'bobwang','[\"R_USER\"]',1783845544809,'','',''),
('tk-mrhjl91d-2fa2mclr',NULL,1,'bobwang','[\"R_USER\"]',1783845562369,'','',''),
('tk-mrhjll17-b1rzt2b3',NULL,1,'bobwang','[\"R_USER\"]',1783845577915,'','',''),
('tk-mrhjm8qq-zhs97kcl',NULL,1,'bobwang','[\"R_USER\"]',1783845608642,'','',''),
('tk-mrhjmi96-gldyh1nq',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783845620970,'','',''),
('tk-mrhjn32t-x8vws6e5',NULL,1,'bobwang','[\"R_USER\"]',1783845647957,'','',''),
('tk-mrhjnc9f-i0w4l3on',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783845659859,'','',''),
('tk-mrhjncgs-n2b1u8aw',NULL,1,'bobwang','[\"R_USER\"]',1783845660124,'','',''),
('tk-mrhjnp9e-w0v3odoc',NULL,1,'bobwang','[\"R_USER\"]',1783845676706,'','',''),
('tk-mrhjnzbq-9uzv4am0',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783845689750,'','',''),
('tk-mrhjohmz-7trp2ig3',NULL,1,'bobwang','[\"R_USER\"]',1783845713484,'','',''),
('tk-mrhjvyfw-j46vyzta',NULL,1,'bobwang','[\"R_USER\"]',1783846061852,'','',''),
('tk-mrhjwobr-j7t1d8xm',NULL,1,'bobwang','[\"R_USER\"]',1783846095399,'','',''),
('tk-mrhjxgkd-42cd76pv',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783846131997,'','',''),
('tk-mrhkhy5x-j74hcico',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783847087926,'','',''),
('tk-mrhl4ytd-kysze6m0',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783848161857,'','',''),
('tk-mrhlcr0g-xbd37u6h',NULL,1,'bobwang','[\"R_USER\"]',1783848524992,'','',''),
('tk-mrhlcw6m-3ifo1fpb',NULL,1,'bobwang','[\"R_USER\"]',1783848531694,'','',''),
('tk-mrhle08a-h6w4ypnt',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783848583594,'','',''),
('tk-mrhm0w7y-5ncf7md0',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783849651487,'','',''),
('tk-mrhmw6sd-8elu4ucx',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783851111517,'','',''),
('tk-mrhnh13n-zemoxe5n',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783852083923,'','',''),
('tk-mrhq4dux-eduq76id',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783856532777,'','',''),
('tk-mrhsctj4-vx2j9fzc',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783860285569,'','',''),
('tk-mrhuhqgm-zsfy5s04',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783863874103,'','',''),
('tk-mrhuqnf2-cjn6s466',NULL,1,'bobwang','[\"R_USER\"]',1783864290062,'','',''),
('tk-mrhvnwr3-9sig8nc2',NULL,1,'bobwang','[\"R_USER\"]',1783865841807,'','',''),
('tk-mrhvp7b4-tv8tfvif',NULL,1,'bobwang','[\"R_USER\"]',1783865902144,'','',''),
('tk-mrhvpczq-0u6bg3e4',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783865909510,'','',''),
('tk-mrhx7vjt-70ca5jwe',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783868452985,'','',''),
('tk-mrhxxaub-ta0denlp',NULL,1,'bobwang','[\"R_USER\"]',1783869639203,'','',''),
('tk-mrhy3qnp-jtycgwtv',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783869939637,'','',''),
('tk-mrhz260i-40bk7jpu',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783871545842,'','',''),
('tk-mri4jl5b-cy2duf71',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783880756687,'','',''),
('tk-mri720d1-619pfy5e',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783884975445,'','',''),
('tk-mri727dn-y4aritup',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783884984539,'','',''),
('tk-mri7dlny-1jn4jtj7',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783885516270,'','',''),
('tk-mri7dq6x-070gypr1',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783885522137,'','',''),
('tk-mri7g0t2-5kiu1mnb',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783885629206,'','',''),
('tk-mri7nu0a-wp8mt16y',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783885993642,'','',''),
('tk-mri7odht-0butrf8q',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783886018897,'','',''),
('tk-mri7rjoy-98ke205m',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783886166898,'','',''),
('tk-mri8738l-euqhq0j4',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783886892069,'','',''),
('tk-mri87y40-8jmqxye9',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783886932081,'','',''),
('tk-mri882fr-b78mncwj',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783886937687,'','',''),
('tk-mri8u3j5-1tt037i7',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783887965537,'','',''),
('tk-mri90fgb-myg3qoio',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888260923,'','',''),
('tk-mri90jnn-mf30kpla',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888266371,'','',''),
('tk-mri915np-gn3hjlro',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888294885,'','',''),
('tk-mri919el-gh0zbeqo',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888299741,'','',''),
('tk-mri91edh-mu75r9hs',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888306181,'','',''),
('tk-mri91hs8-uyl7mvrs',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888310600,'','',''),
('tk-mri937n5-7dblabg9',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888390769,'','',''),
('tk-mri9935f-n673updo',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888664883,'','',''),
('tk-mri9dw48-jwp1824g',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888889048,'','',''),
('tk-mri9fzos-iho4d0t2',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783888986989,'','',''),
('tk-mri9hzb2-hjhnkhfx',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783889079806,'','',''),
('tk-mria1k2h-8v7zzplt',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783889993177,'','',''),
('tk-mriad2ud-6obqaxnv',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783890530725,'','',''),
('tk-mriamxtl-grjxq8wc',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783890990777,'','',''),
('tk-mrifoelr-xekdhe7e',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783899457263,'','',''),
('tk-mrj2pat9-xnsc3zrb',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783938130173,'','',''),
('tk-mrj4jfk1-2vwncww6',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783941215617,'','',''),
('tk-mrj5buxe-0s2s0v5w',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783942541906,'','',''),
('tk-mrj85jzg-g1f0j2jj',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783947286636,'','',''),
('tk-mrj8blxu-5ko5dlpx',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783947569106,'','',''),
('tk-mrjatbmf-84kdx4ok',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783951754775,'','',''),
('tk-mrjb92l1-iexgoei6',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783952489557,'','',''),
('tk-mrjg62ra-inq40n5m',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783960747895,'','',''),
('tk-mrjk5fmr-2yrjaba6',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783967436387,'','',''),
('tk-mrjlb37x-dwbkgwu9',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783969379853,'','',''),
('tk-mrjmjo9d-ity5y86v',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783971459985,'','',''),
('tk-mrjpnqcc-n17i9ewv',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783976688156,'','',''),
('tk-mrjr29iu-e0ou3lm8',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783979045815,'','',''),
('tk-mrjr2g2l-boeund8b',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783979054301,'','',''),
('tk-mrjvnfyn-whodqxd0',NULL,19,'alexmorgan','[\"R_SUPER\"]',1783986752399,'','',''),
('tk-mrkgttmx-by5fo0d2',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784022321993,'','',''),
('tk-mrkimsyl-zeq9mtwf',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784025353757,'','',''),
('tk-mrkmfqeo-yfh0xbzq',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784031742320,'','',''),
('tk-mrknrkgz-5u8gl1xx',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784033974115,'','',''),
('tk-mrkprjs1-z1vj79iv',NULL,1,'bobwang','[\"R_USER\"]',1784037332449,'','',''),
('tk-mrkpxk9v-n8qetfpd',NULL,1,'bobwang','[\"R_USER\"]',1784037613027,'','',''),
('tk-mrkqs3as-kxlv22mx',NULL,1,'bobwang','[\"R_USER\"]',1784039037364,'','',''),
('tk-mrksniad-764y70v3',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784042182741,'','',''),
('tk-mrktbu91-s0n4568q',NULL,10001,'35735712','[]',1784043317989,'','',''),
('tk-mrktcj1t-4xsbah46',NULL,10001,'35735712','[]',1784043350129,'','',''),
('tk-mrlbw0p0-iw0xcyzm',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784074492548,'','',''),
('tk-mrlbw4ra-e02jw8fk',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784074497814,'','',''),
('tk-mrlk7jh7-j15wlw80',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784088467035,'','',''),
('tk-mrlkgbdc-qvpi062t',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784088876432,'','',''),
('tk-mrlkik53-ziw6js2x',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784088981111,'','',''),
('tk-mrlkoaqv-amck7yfp',NULL,1,'bobwang','[\"R_USER\"]',1784089248872,'','',''),
('tk-mrll4kt2-xz29xbtr',NULL,1,'bobwang','[\"R_USER\"]',1784090008407,'','',''),
('tk-mrll4rrx-efl4t1oz',NULL,1,'bobwang','[\"R_USER\"]',1784090017437,'','',''),
('tk-mrllkxd3-1bn7yuas',NULL,10001,'35735712','[]',1784090771175,'','',''),
('tk-mrlnfi5y-1m2rmua3',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784093877431,'','',''),
('tk-mrlq6b02-5c6xtvto',NULL,10001,'35735712','[]',1784098487090,'','',''),
('tk-mrlyh912-s82xze3n',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784112434678,'','',''),
('tk-mrm3egmo-x0d5heyl',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784120702641,'','',''),
('tk-mrmbh8zt-38uqtjtr',NULL,10001,'35735712','[]',1784134269641,'','',''),
('tk-mrmfckdi-2jhxj5rl',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784140769574,'','',''),
('tk-mrmq7uo2-mc9mge1i',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784159025410,'','',''),
('tk-mrmq8w5h-4r2shda1',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784159073989,'','',''),
('tk-mrmrb46m-m1z5h1di',NULL,10001,'35735712','[]',1784160857326,'','',''),
('tk-mrmrgqlo-fr6dj25l',NULL,10001,'35735712','[]',1784161119660,'','',''),
('tk-mrmrhh2i-edev3lqg',NULL,10001,'35735712','[]',1784161153962,'','',''),
('tk-mrmsgel9-6rjp0h5p',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784162783709,'','',''),
('tk-mrmtbpjx-gp4txmuk',NULL,1,'bobwang','[\"R_USER\"]',1784164244253,'','',''),
('tk-mrmtbpmk-ecwqa1un',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784164244348,'','',''),
('tk-mrmtbs4z-nkk9pmk8',NULL,1,'bobwang','[\"R_USER\"]',1784164247603,'','',''),
('tk-mrmtbvd3-sxc5k8rk',NULL,1,'bobwang','[\"R_USER\"]',1784164251783,'','',''),
('tk-mrmtbvfv-e9kzxixe',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784164251883,'','',''),
('tk-mrmtdn2r-lr2jca7a',NULL,1,'bobwang','[\"R_USER\"]',1784164334355,'','',''),
('tk-mrmtdn5h-lgd6oc0v',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784164334453,'','',''),
('tk-mrmtx0kv-qgiupvv5',NULL,1,'bobwang','[\"R_USER\"]',1784165238319,'','',''),
('tk-mrmtx0o5-xhi1qnd0',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784165238437,'','',''),
('tk-mrmtxtw6-duh63vr0',NULL,1,'bobwang','[\"R_USER\"]',1784165276310,'','',''),
('tk-mrmzknax-gtsjfnc8',NULL,1,'bobwang','[\"R_USER\"]',1784174738937,'','',''),
('tk-mrndwb59-amk3hdtu',NULL,1,'bobwang','[\"R_USER\"]',1784198797677,'','',''),
('tk-mrndxtcl-y2sa7dnc',NULL,1,'bobwang','[\"R_USER\"]',1784198867925,'','',''),
('tk-mrndxyco-89r09qco',NULL,1,'bobwang','[\"R_USER\"]',1784198874408,'','',''),
('tk-mrndyre2-a1z07tam',NULL,1,'bobwang','[\"R_USER\"]',1784198912042,'','',''),
('tk-mrndztat-49abbm2t',NULL,1,'bobwang','[\"R_USER\"]',1784198961173,'','',''),
('tk-mrnkl587-i08tq07g',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784210034103,'','',''),
('tk-mrnkl8x8-n2syep1z',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784210038892,'','',''),
('tk-mrnkqch2-d71vw4xp',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784210276774,'','',''),
('tk-mrnnp7lb-0xit735o',NULL,10001,'35735712','[]',1784215262640,'','',''),
('tk-mrnqbzvp-6vjqe0iz',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784219684966,'','',''),
('tk-mrnwfc6h-q40c0rsw',NULL,1,'bobwang','[\"R_USER\"]',1784229918569,'','',''),
('tk-mrnwh1jr-64n4bq8c',NULL,10002,'github_user_mrnwh1hi','[]',1784229998103,'','',''),
('tk-mrnwxgk4-cwyijhk6',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784230764052,'','',''),
('tk-mrnyyin9-2w7go05n',NULL,1,'bobwang','[\"R_USER\"]',1784234172645,'','',''),
('tk-mrnyz855-f0a5erqf',NULL,1,'bobwang','[\"R_USER\"]',1784234205690,'','',''),
('tk-mrnz3u8r-7272idz4',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234420955,'','',''),
('tk-mrnz4wz1-qmaa1k45',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234471149,'','',''),
('tk-mrnz51mj-c9p6r4lq',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234477179,'','',''),
('tk-mrnz6kxo-i9y17dk1',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234548860,'','',''),
('tk-mrnzdb8m-9r8k4q7r',NULL,10003,'test_joiner','[]',1784234862886,'','',''),
('tk-mrnzeitl-iygedzjd',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234919369,'','',''),
('tk-mrnzenni-i1kyz0kf',NULL,10003,'test_joiner','[]',1784234925630,'','',''),
('tk-mrnzg6y6-2xhb7eus',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784234997294,'','',''),
('tk-mrnzg70q-rjsvzksz',NULL,10003,'test_joiner','[]',1784234997386,'','',''),
('tk-mrnzlgqm-hqe0meqj',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784235243262,'','',''),
('tk-mrnzo2j8-4yce8eej',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784235364820,'','',''),
('tk-mrnzqa54-vc4rbqg2',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784235467992,'','',''),
('tk-mrnzr9yy-4xlzlcg7',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784235514426,'','',''),
('tk-mro16tw8-fq4526tn',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784237919704,'','',''),
('tk-mro1iom6-zpufixjl',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784238472734,'','',''),
('tk-mro1itp1-it74neri',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784238479317,'','',''),
('tk-mroakatb-9xcirjdg',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784253664703,'','',''),
('tk-mroalnuu-zguki6oq',NULL,10004,'admin','[\"R_SUPER\"]',1784253728262,'','',''),
('tk-mroazw7o-gvekaibe',NULL,10004,'admin','[\"R_SUPER\"]',1784254392276,'','',''),
('tk-mrob0o3n-3ugtdepg',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784254428419,'','',''),
('tk-mrob2lf3-bej4zl37',NULL,10004,'admin','[\"R_SUPER\"]',1784254518255,'','',''),
('tk-mrob2pj3-e0ubps65',NULL,10004,'admin','[\"R_SUPER\"]',1784254523583,'','',''),
('tk-mrob2vk9-envntdyt',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784254531401,'','',''),
('tk-mrob33l4-bj2cvg8e',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784254541800,'','',''),
('tk-mrob7yc6-antg78e8',NULL,10004,'admin','[\"R_SUPER\"]',1784254768278,'','',''),
('tk-mrob8304-1l0e1wrf',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784254774324,'','',''),
('tk-mrob9di6-m3abg131',NULL,10004,'admin','[\"R_SUPER\"]',1784254834590,'','',''),
('tk-mrob9ipr-cncokou3',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784254841343,'','',''),
('tk-mroccoxj-v1zwb4mk',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784256668983,'','',''),
('tk-mroifkse-upf3r6ax',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784266881279,'','',''),
('tk-mrp1iwzd-414cddbt',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784298949753,'','',''),
('tk-mrp2ikof-wokecd9w',NULL,3,'tech_guru','[\"R_USER\"]',1784300613423,'','',''),
('tk-mrp2km8p-t25w0gfe',NULL,3,'tech_guru','[\"R_USER\"]',1784300708761,'','',''),
('tk-mrp2l961-nc7qam3y',NULL,3,'tech_guru','[\"R_USER\"]',1784300738474,'','',''),
('tk-mrp2lf9e-2meqtti1',NULL,3,'tech_guru','[\"R_USER\"]',1784300746370,'','',''),
('tk-mrp2loze-hsyoo757',NULL,3,'tech_guru','[\"R_USER\"]',1784300758970,'','',''),
('tk-mrp3fvep-6tl5ttt6',NULL,3,'tech_guru','[\"R_USER\"]',1784302166977,'','',''),
('tk-mrp3fylu-93y6qxe9',NULL,3,'tech_guru','[\"R_USER\"]',1784302171122,'','',''),
('tk-mrp3g22s-3j6t7532',NULL,3,'tech_guru','[\"R_USER\"]',1784302175620,'','',''),
('tk-mrp3gra7-xdubwph6',NULL,10004,'admin','[\"R_SUPER\"]',1784302208287,'','',''),
('tk-mrp3gw5m-87l511wa',NULL,10004,'admin','[\"R_SUPER\"]',1784302214602,'','',''),
('tk-mrp3h1f9-otfn1f00',NULL,10004,'admin','[\"R_SUPER\"]',1784302221429,'','',''),
('tk-mrp3h5ut-j9deivhh',NULL,10004,'admin','[\"R_SUPER\"]',1784302227173,'','',''),
('tk-mrp47kck-bdo7j7t4',NULL,10004,'admin','[\"R_SUPER\"]',1784303459012,'','',''),
('tk-mrp47ql0-59qpw5qi',NULL,10004,'admin','[\"R_SUPER\"]',1784303467092,'','',''),
('tk-mrp494tw-pll69iog',NULL,10004,'admin','[\"R_SUPER\"]',1784303532212,'','',''),
('tk-mrp49a5y-hgnaaq4a',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784303539126,'','',''),
('tk-mrp4axx3-n1vewq6v',NULL,10004,'admin','[\"R_SUPER\"]',1784303616567,'','',''),
('tk-mrp4qhmq-gb0g8z5l',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784304341954,'','',''),
('tk-mrp5u4cm-4zj9jaru',NULL,10004,'admin','[\"R_SUPER\"]',1784306190982,'','',''),
('tk-mrp6z7ug-ydc0qgnd',NULL,3,'tech_guru','[\"R_USER\"]',1784308108408,'','',''),
('tk-mrp6zawm-ta1e31ed',NULL,3,'tech_guru','[\"R_USER\"]',1784308112374,'','',''),
('tk-mrp6zf9s-6q4ibw6k',NULL,3,'tech_guru','[\"R_USER\"]',1784308118032,'','',''),
('tk-mrp6zjxa-6yud0xwo',NULL,3,'tech_guru','[\"R_USER\"]',1784308124062,'','',''),
('tk-mrp6zoub-zleynq9o',NULL,3,'tech_guru','[\"R_USER\"]',1784308130435,'','',''),
('tk-mrp73t3b-ype7x6kj',NULL,3,'tech_guru','[\"R_USER\"]',1784308322567,'','',''),
('tk-mrp741gr-iwf43l6z',NULL,3,'tech_guru','[\"R_USER\"]',1784308333419,'','',''),
('tk-mrp78j3x-vgbimddz',NULL,3,'tech_guru','[\"R_USER\"]',1784308542909,'','',''),
('tk-mrp78qlm-4q7xmil8',NULL,3,'tech_guru','[\"R_USER\"]',1784308552618,'','',''),
('tk-mrp7dy9z-m42d3zck',NULL,3,'tech_guru','[\"R_USER\"]',1784308795847,'','',''),
('tk-mrp7dyd5-5rh2mo73',NULL,3,'tech_guru','[\"R_USER\"]',1784308795961,'','',''),
('tk-mrp7e26u-bjg5urn5',NULL,3,'tech_guru','[\"R_USER\"]',1784308800918,'','',''),
('tk-mrp7e2a1-2orbinbq',NULL,3,'tech_guru','[\"R_USER\"]',1784308801033,'','',''),
('tk-mrp7e6cf-tbu628gi',NULL,3,'tech_guru','[\"R_USER\"]',1784308806303,'','',''),
('tk-mrp7ea1j-yi574c7r',NULL,3,'tech_guru','[\"R_USER\"]',1784308811095,'','',''),
('tk-mrp7endp-wygjfyxl',NULL,3,'tech_guru','[\"R_USER\"]',1784308828381,'','',''),
('tk-mrp7euqd-7ce2i1qe',NULL,3,'tech_guru','[\"R_USER\"]',1784308837909,'','',''),
('tk-mrp7i3rd-4e1bvs72',NULL,3,'tech_guru','[\"R_USER\"]',1784308989577,'','',''),
('tk-mrp7i90i-7ppuj0yi',NULL,3,'tech_guru','[\"R_USER\"]',1784308996386,'','',''),
('tk-mrp7p3hq-vlplbbvq',NULL,3,'tech_guru','[\"R_USER\"]',1784309315822,'','',''),
('tk-mrp82nfl-anya4srx',NULL,10004,'admin','[\"R_SUPER\"]',1784309948193,'','',''),
('tk-mrp85505-vlclnpgv',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310064277,'','',''),
('tk-mrp85feu-mmve4p80',NULL,10005,'promo_test1','[]',1784310077766,'','',''),
('tk-mrp878rg-d9fe9j8b',NULL,10006,'promo_buyer','[]',1784310162460,'','',''),
('tk-mrp878xh-ldre7nqa',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310162677,'','',''),
('tk-mrp8a1ei-3twanj58',NULL,10007,'promo_test2','[]',1784310292890,'','',''),
('tk-mrp8frma-612yn9os',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310560146,'','',''),
('tk-mrp8jbr8-m2z38745',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310726212,'','',''),
('tk-mrp8jfup-17zc4wzf',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310731521,'','',''),
('tk-mrp8k12f-nsouex7z',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784310759015,'','',''),
('tk-mrp8v5gp-nemodlrf',NULL,10008,'promo_pts','[]',1784311277930,'','',''),
('tk-mrp8w3tt-m7114pyf',NULL,10009,'promo_pts2','[]',1784311322465,'','',''),
('tk-mrp8xtzh-raorb9ri',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784311403021,'','',''),
('tk-mrp8y50f-lul93yux',NULL,10009,'promo_pts2','[]',1784311417311,'','',''),
('tk-mrp8yarn-6he2g3kw',NULL,10009,'promo_pts2','[]',1784311424771,'','',''),
('tk-mrp8zxex-co8shokl',NULL,10010,'promo_dbg','[]',1784311500777,'','',''),
('tk-mrpa8953-xwbp8w1g',NULL,10011,'promo_dual','[]',1784313568839,'','',''),
('tk-mrpa8ptw-5kp7plf0',NULL,10011,'promo_dual','[]',1784313590468,'','',''),
('tk-mrpacogd-r2fw7g6p',NULL,10011,'promo_dual','[]',1784313775309,'','',''),
('tk-mrpaihu3-ir8wut5q',NULL,10011,'promo_dual','[]',1784314046667,'','',''),
('tk-mrpaj701-bv02hen7',NULL,10011,'promo_dual','[]',1784314079281,'','',''),
('tk-mrpe7dda-ba2im1r4',NULL,19,'alexmorgan','[\"R_SUPER\"]',1784320246126,'','',''),
('tk-mrpek76x-taw3d7dp',NULL,10004,'admin','[\"R_SUPER\"]',1784320844649,'','','');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settlement_config`
--

DROP TABLE IF EXISTS `settlement_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settlement_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通用户',
  `confirm_days` int(11) DEFAULT 7,
  `enabled` int(11) DEFAULT 1,
  `balance_transfer_enabled` int(11) DEFAULT 1,
  `points_transfer_enabled` int(11) DEFAULT 1,
  `single_min_balance` decimal(10,2) DEFAULT 0.00,
  `single_max_balance` decimal(10,2) DEFAULT 0.00,
  `single_min_points` int(11) DEFAULT 0,
  `single_max_points` int(11) DEFAULT 0,
  `daily_limit_balance_amount` decimal(10,2) DEFAULT 0.00,
  `daily_limit_points_amount` int(11) DEFAULT 0,
  `daily_limit_times` int(11) DEFAULT 0,
  `weekly_limit_times` int(11) DEFAULT 0,
  `yearly_limit_times` int(11) DEFAULT 0,
  `balance_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `points_transfer_fee` decimal(5,2) DEFAULT 0.00,
  `balance_to_points_rate` decimal(10,2) DEFAULT 1.00,
  `points_to_balance_rate` decimal(10,2) DEFAULT 1.00,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settlement_config`
--

LOCK TABLES `settlement_config` WRITE;
/*!40000 ALTER TABLE `settlement_config` DISABLE KEYS */;
INSERT INTO `settlement_config` VALUES
(1,0,'默认结算',7,1,1,1,0.00,0.00,0,0,0.00,0,0,0,0,0.00,0.00,1.00,1.00,'2026-07-10 22:39:54');
/*!40000 ALTER TABLE `settlement_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '配置名称',
  `provider` varchar(50) NOT NULL COMMENT '短信服务商',
  `config_json` text DEFAULT '{}' COMMENT '服务商配置JSON',
  `sign_name` varchar(100) DEFAULT '' COMMENT '短信签名',
  `template_code` varchar(50) DEFAULT '' COMMENT '短信模板代码',
  `enabled` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES
(1,'云片验证码','yunpian','{\"apiKey\":\"test-key-xxx\"}','ArtDesign','TPL_001',1,0,'2026-07-12 19:45:22','2026-07-12 19:45:22'),
(2,'阿里云测试','aliyun','{\"accessKeyId\":\"LTAI5t6oq445VTWdqXpkw1ud\",\"accessKeySecret\":\"26V7K8ml5mSSsOR7FDy31LrOCqlG4M\"}','恒创联众','10001',1,1,'2026-07-12 19:53:38','2026-07-12 20:01:46'),
(3,'腾讯云测试','tencent','{\"secretId\":\"AKID123456\",\"secretKey\":\"myTencentSecret\",\"appId\":\"1400123456\"}','ArtPro','12345',1,0,'2026-07-12 19:56:06','2026-07-12 19:56:06'),
(4,'华为云测试','huawei','{\"appKey\":\"530b0c2ec52ce142fc62c9af58f21e9b\",\"appSecret\":\"452a129430748e3082afcc027f0d7fc7\",\"sender\":\"8823122800000\"}','ArtPro','T001',1,0,'2026-07-12 20:08:52','2026-07-12 20:08:52');
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_verifications`
--

DROP TABLE IF EXISTS `sms_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `type` varchar(20) DEFAULT 'register',
  `used` tinyint(1) DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_verifications`
--

LOCK TABLES `sms_verifications` WRITE;
/*!40000 ALTER TABLE `sms_verifications` DISABLE KEYS */;
INSERT INTO `sms_verifications` VALUES
(1,'18367164190','315567','register',0,'2026-07-12 19:34:22','2026-07-12 19:24:22'),
(2,'13900000001','821080','register',0,'2026-07-12 20:03:04','2026-07-12 19:53:04'),
(3,'18367164190','553902','register',0,'2026-07-12 20:12:13','2026-07-12 20:02:13'),
(4,'18367164190','834844','register',0,'2026-07-12 20:16:09','2026-07-12 20:06:09'),
(5,'18367164190','755818','register',0,'2026-07-12 20:20:42','2026-07-12 20:10:42'),
(6,'18367164190','670608','register',0,'2026-07-12 20:24:42','2026-07-12 20:14:42'),
(7,'13800138002','234001','login',1,'2026-07-21 01:23:10','2026-07-21 01:13:10'),
(8,'844991059@q','100704','login',0,'2026-07-21 01:43:14','2026-07-21 01:33:14'),
(9,'13800138002','178769','login',0,'2026-07-21 02:07:40','2026-07-21 01:57:40');
/*!40000 ALTER TABLE `sms_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standalone_vote_records`
--

DROP TABLE IF EXISTS `standalone_vote_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standalone_vote_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `option_index` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vote_user_option` (`vote_id`,`user_id`,`option_index`),
  KEY `idx_vote_id` (`vote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standalone_vote_records`
--

LOCK TABLES `standalone_vote_records` WRITE;
/*!40000 ALTER TABLE `standalone_vote_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `standalone_vote_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standalone_votes`
--

DROP TABLE IF EXISTS `standalone_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `standalone_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `options` text NOT NULL,
  `max_select` int(11) DEFAULT 1,
  `end_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `total_votes` int(11) DEFAULT 0,
  `create_by` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standalone_votes`
--

LOCK TABLES `standalone_votes` WRITE;
/*!40000 ALTER TABLE `standalone_votes` DISABLE KEYS */;
INSERT INTO `standalone_votes` VALUES
(1,'test vote','[\"a\",\"b\"]',1,NULL,'closed',0,1,'2026-07-16 19:29:20'),
(2,'test vote','[\"a\",\"b\"]',1,'2026-08-01 00:00:00','active',0,1,'2026-07-16 19:30:07');
/*!40000 ALTER TABLE `standalone_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_configs`
--

DROP TABLE IF EXISTS `storage_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'local',
  `name` varchar(100) DEFAULT '',
  `config` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `endpoint` varchar(500) DEFAULT '',
  `region` varchar(100) DEFAULT '',
  `bucket` varchar(200) DEFAULT '',
  `access_key` varchar(500) DEFAULT '',
  `secret_key` varchar(500) DEFAULT '',
  `local_dir` varchar(500) DEFAULT '',
  `remote_dir` varchar(500) DEFAULT '',
  `expiry_seconds` int(11) DEFAULT 0,
  `base_url` varchar(500) DEFAULT '',
  `applicable_roles` text DEFAULT NULL,
  `applicable_levels` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_configs`
--

LOCK TABLES `storage_configs` WRITE;
/*!40000 ALTER TABLE `storage_configs` DISABLE KEYS */;
INSERT INTO `storage_configs` VALUES
(2,'oss','用户-阿里云OSS',NULL,1,'1','2026-07-11 17:38:58','2026-07-12 03:08:16','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','ba007200b77fcd4ae08d875790878c2eba6a579b0226b7000934ced17e5c453a','b418356110428dac2a4860e8c45a9cc359e7584fad13dc57ca523d9c2088c0a0','','user/{userId}',3600,'','','all'),
(3,'oss','后台-阿里云OSS',NULL,0,'1','2026-07-11 17:40:44','2026-07-13 19:20:43','oss-cn-hongkong.aliyuncs.com','cn-hongkong','appiapp','ba007200b77fcd4ae08d875790878c2eba6a579b0226b7000934ced17e5c453a','b418356110428dac2a4860e8c45a9cc359e7584fad13dc57ca523d9c2088c0a0','','admin',0,'','','backend');
/*!40000 ALTER TABLE `storage_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` text DEFAULT '',
  `description` varchar(200) DEFAULT '',
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=374 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES
(1,'system_log_enabled','true','系统日志总开关','2026-07-10 22:42:45'),
(2,'log_enabled_login','true','登录日志开关','2026-07-10 22:42:45'),
(3,'log_enabled_user','true','用户操作日志开关','2026-07-10 22:42:45'),
(4,'log_enabled_operation','true','运营管理日志开关','2026-07-10 22:42:45'),
(5,'log_enabled_content','true','内容管理日志开关','2026-07-10 22:42:45'),
(6,'log_enabled_system','true','系统配置日志开关','2026-07-10 22:42:45'),
(7,'invite_user_enabled','false','用户生成邀请码开关','2026-07-10 22:42:45'),
(8,'invite_user_max','5','用户最大可生成邀请码数','2026-07-10 22:42:45'),
(9,'register_invite_required','false','注册必须邀请码','2026-07-10 22:42:45'),
(10,'commission_enabled','false','推广返佣开关','2026-07-10 22:42:45'),
(11,'commission_mode','purchase','返佣模式','2026-07-10 22:42:45'),
(12,'points_transfer_enabled','true','积分转账开关','2026-07-10 22:42:45'),
(13,'points_transfer_fee','0','积分转账手续费比例%','2026-07-10 22:42:45'),
(14,'balance_transfer_enabled','true','余额转账开关','2026-07-10 22:42:45'),
(15,'balance_transfer_fee','0','余额转账手续费比例%','2026-07-10 22:42:45'),
(16,'points_purchase_enabled','false','积分购买开关','2026-07-10 22:42:45'),
(17,'points_purchase_rate','1','1元等于多少积分','2026-07-10 22:42:45'),
(18,'content_split_enabled','true','创作分成开关','2026-07-10 22:42:45'),
(19,'content_split_global_rate','70','创作分成全局比例%','2026-07-10 22:42:45'),
(20,'checkin_enabled','true','签到功能开关','2026-07-10 22:42:45'),
(21,'topic_create_min_exp_level','3','话题创建最低经验等级','2026-07-11 12:17:24'),
(22,'topic_create_allowed_levels','2,3','允许创建话题的会员等级ID列表','2026-07-11 12:17:24'),
(23,'payment_epay_pid','','','2026-07-11 16:28:08'),
(24,'payment_epay_key','','','2026-07-11 16:28:08'),
(25,'payment_epay_api_url','','','2026-07-11 16:28:08'),
(26,'payment_epay_notify_url','','','2026-07-11 16:28:08'),
(27,'payment_epay_enabled','true','','2026-07-11 16:28:08'),
(28,'payment_alipay_app_id','','','2026-07-11 16:28:08'),
(29,'payment_alipay_private_key','','','2026-07-11 16:28:08'),
(30,'payment_alipay_public_key','','','2026-07-11 16:28:08'),
(31,'payment_alipay_enabled','false','','2026-07-11 16:28:08'),
(32,'payment_wechat_app_id','','','2026-07-11 16:28:08'),
(33,'payment_wechat_mch_id','','','2026-07-11 16:28:08'),
(34,'payment_wechat_api_key','','','2026-07-11 16:28:08'),
(35,'payment_wechat_enabled','false','','2026-07-11 16:28:08'),
(36,'active_pc_layout','pc','激活的PC布局主题ID','2026-07-12 14:18:29'),
(37,'site_theme_mode','auto','主题显示模式','2026-07-20 23:41:54'),
(38,'site_show_theme_switch','false','前端显示主题切换按钮','2026-07-20 23:41:54'),
(39,'site_name','','网站名称','2026-07-20 23:41:54'),
(40,'site_subtitle','','网站副标题','2026-07-20 23:41:54'),
(41,'site_domain','','网站域名','2026-07-20 23:41:54'),
(42,'site_admin_path','/admin','后台入口地址','2026-07-20 23:41:54'),
(43,'site_favicon','','网站favicon','2026-07-20 23:41:54'),
(44,'site_logo_pc','','PC端LOGO','2026-07-20 23:41:54'),
(45,'site_logo_mobile','','移动端LOGO','2026-07-20 23:41:54'),
(46,'site_copyright','','底部版权信息','2026-07-20 23:41:54'),
(47,'site_icp','','ICP备案号','2026-07-20 23:41:54'),
(48,'login_captcha_enabled','true','后台登录验证码','2026-07-20 23:41:54'),
(49,'login_max_errors','5','连续登录错误次数','2026-07-20 23:41:54'),
(50,'login_lock_minutes','15','封号时长(分钟)','2026-07-20 23:41:54'),
(51,'ip_blacklist','','IP黑名单','2026-07-20 23:41:54'),
(52,'api_sign_enabled','true','API请求签名验证','2026-07-20 23:41:54'),
(53,'api_rate_limit','60','接口请求频率限制','2026-07-20 23:41:54'),
(54,'register_enabled','true','开启用户注册','2026-07-20 23:41:54'),
(55,'register_verify_type','email','注册验证方式','2026-07-20 23:41:54'),
(56,'register_default_group','21','新用户默认分组','2026-07-20 23:41:54'),
(57,'password_rule','alphanumeric','密码规则','2026-07-20 23:41:54'),
(58,'site_maintenance_enabled','false','网站维护开关','2026-07-20 23:41:54'),
(59,'site_maintenance_msg','','维护提示文案','2026-07-20 23:41:54'),
(60,'register_email_config_id','1','注册验证邮箱配置ID','2026-07-20 23:41:54'),
(61,'register_default_level','1','新用户默认会员等级','2026-07-20 23:41:54'),
(62,'register_start_id','10001','用户ID起始编号','2026-07-20 23:41:54'),
(63,'register_username_min','8','用户名最小长度','2026-07-20 23:41:54'),
(64,'register_password_min','6','密码最小长度','2026-07-20 23:41:54'),
(65,'sms_channel_enabled','true','短信发送通道开关','2026-07-20 23:41:54'),
(66,'site_auto_refresh','false','自动刷新页面内容','2026-07-20 23:41:54'),
(67,'push_subscription_1','{}','Web Push Subscription for user 1','2026-07-16 19:26:30'),
(69,'title_scan_last','2026-07-21 17:25:36','称号最后扫描时间','2026-07-16 22:45:04'),
(70,'title_scan_interval','1400','称号自动扫描间隔(分钟)','2026-07-16 22:45:26'),
(120,'invite_user_cost_config','{\"enabled\":true,\"pointsPricing\":[{\"maxAmount\":100,\"totalCost\":1,\"quantity\":100},{\"maxAmount\":500,\"totalCost\":4,\"quantity\":400}],\"balancePricing\":[{\"maxAmount\":10,\"totalCost\":5,\"quantity\":10}],\"expPricing\":[{\"maxAmount\":100,\"totalCost\":2,\"quantity\":100}],\"membershipPricing\":{\"30\":10,\"90\":25,\"365\":80},\"vipDiscount\":{\"enabled\":true,\"levelId\":3}}','','2026-07-17 17:20:22'),
(122,'invite_user_max_uses','10','','2026-07-17 17:27:25'),
(142,'site_help_url','','帮助与反馈链接','2026-07-20 23:41:54'),
(143,'site_agreement_url','','用户协议链接','2026-07-20 23:41:54'),
(144,'site_privacy_url','','隐私政策链接','2026-07-20 23:41:54'),
(145,'site_security_url','','安全条款链接','2026-07-20 23:41:54'),
(146,'site_about_url','','关于页链接','2026-07-20 23:41:54'),
(147,'site_community_url','123456','交流群组链接','2026-07-20 23:41:54'),
(148,'site_contact_url','123456','联系我们链接','2026-07-20 23:41:54'),
(149,'site_community_content','123456','交流群组弹窗内容','2026-07-20 23:41:54'),
(150,'site_contact_content','123456','联系我们弹窗内容','2026-07-20 23:41:54'),
(171,'ip_geo_provider','free','IP地理位置服务商: free/tencent/aliyun','2026-07-18 03:53:54'),
(172,'ip_geo_api_key','','IP地理位置API密钥','2026-07-18 03:53:54'),
(173,'ip_geo_api_secret','','IP地理位置API密钥(部分服务商需要)','2026-07-18 03:53:54'),
(174,'ip_geo_enabled','1','是否启用IP地理位置解析','2026-07-18 03:53:54'),
(227,'cookie_consent_enabled','true','Cookie 同意弹窗开关','2026-07-19 03:59:16'),
(228,'cookie_consent_title','Cookie 声明','Cookie 弹窗标题','2026-07-19 03:56:04'),
(229,'cookie_consent_content','本站使用 Cookie 来改善您的浏览体验、分析网站流量并提供个性化内容。继续使用本站即表示您同意我们使用 Cookie。','Cookie 弹窗内容','2026-07-19 03:56:04'),
(230,'cookie_consent_agree_text','同意全部','同意按钮文字','2026-07-19 03:56:04'),
(231,'cookie_consent_decline_text','仅必要','拒绝按钮文字','2026-07-19 03:56:04'),
(233,'site_privacy_version','5','privacy latest version','2026-07-21 15:49:26'),
(281,'system_operator_id','19','系统通知操作者','2026-07-20 23:41:54'),
(282,'chat_room_create_condition','{\"enabled\":false,\"min_experience_level\":2,\"min_membership_level\":1,\"min_post_count\":10,\"min_points\":100}','聊天室创建权限','2026-07-20 23:41:54');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notifications`
--

DROP TABLE IF EXISTS `sys_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT '',
  `type` varchar(50) DEFAULT 'system',
  `target_url` varchar(500) DEFAULT '',
  `target_user_id` int(11) DEFAULT 0,
  `from_user_id` int(11) DEFAULT 0,
  `from_user_name` varchar(100) DEFAULT '',
  `from_user_avatar` varchar(200) DEFAULT '',
  `is_read` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sys_notifications_target_user` (`target_user_id`),
  KEY `idx_notifications_target_read_id` (`target_user_id`,`is_read`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notifications`
--

LOCK TABLES `sys_notifications` WRITE;
/*!40000 ALTER TABLE `sys_notifications` DISABLE KEYS */;
INSERT INTO `sys_notifications` VALUES
(1,'系统通知 #1','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-07-01 22:39:54'),
(2,'系统通知 #2','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-07-06 22:39:54'),
(3,'系统通知 #3','这是一条重要的系统通知内容。','update','',0,0,'','',1,'2026-07-08 22:39:54'),
(4,'系统通知 #4','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-06-29 22:39:54'),
(5,'系统通知 #5','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-06-29 22:39:54'),
(6,'系统通知 #6','这是一条重要的系统通知内容。','update','',0,0,'','',1,'2026-07-08 22:39:54'),
(7,'系统通知 #7','这是一条重要的系统通知内容。','system','',0,0,'','',1,'2026-06-27 22:39:54'),
(8,'系统通知 #8','这是一条重要的系统通知内容。','announcement','',0,0,'','',1,'2026-07-09 22:39:54'),
(9,'卡密兑换成功','您使用卡密 CDKEY-MRG47L1VS1EE 兑换成功，获得：5000元余额、额外99999积分、额外2000经验值','system','',19,0,'管理员','',1,'2026-07-11 08:41:23'),
(10,'打赏通知','Alex Morgan 打赏了您的帖子「开源项目推荐合集」1余额','system','',7,19,'Alex Morgan','',0,'2026-07-11 11:39:17'),
(11,'打赏成功','您成功打赏了 用户 的帖子「开源项目推荐合集」1余额','system','',19,0,'管理员','',1,'2026-07-11 11:39:17'),
(12,'新粉丝','Alex Morgan 关注了您','system','',7,19,'Alex Morgan','',0,'2026-07-11 11:39:21'),
(13,'帖子被加精','您的帖子《开源项目推荐合集》已被管理员设为精华','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:23'),
(14,'帖子被设为热帖','您的帖子《开源项目推荐合集》已被管理员设为热帖','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:24'),
(15,'帖子被锁定','您的帖子《开源项目推荐合集》已被管理员锁定','system','',7,19,'alexmorgan','',0,'2026-07-11 11:39:26'),
(16,'帖子已解锁','您的帖子《开源项目推荐合集》已被管理员解除锁定','system','',7,19,'alexmorgan','',0,'2026-07-11 11:40:52'),
(17,'新粉丝','Alex Morgan 关注了您','system','',12,19,'Alex Morgan','',0,'2026-07-11 11:46:49'),
(18,'应用审核通过','您的应用《百变引擎》已通过审核，现在可以在应用商店中查看了','system','',19,0,'alexmorgan','',1,'2026-07-11 11:50:41'),
(19,'任务完成','恭喜完成\"每日签到\"任务！获得: 10积分','system','',1,0,'管理员','',0,'2026-07-12 13:51:30'),
(20,'任务完成','恭喜完成\"完善资料\"任务！获得: 30积分','system','',19,0,'管理员','',1,'2026-07-12 20:31:51'),
(21,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',19,0,'管理员','',1,'2026-07-12 21:51:42'),
(22,'帖子审核未通过','您的帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》未通过审核，原因：6666','system','',19,19,'alexmorgan','',1,'2026-07-13 12:17:13'),
(23,'新的账号申诉','用户 alexmorgan 提交了账号申诉，申诉理由：我冤枉的，请解封','system','',19,0,'管理员','',1,'2026-07-13 14:21:20'),
(24,'新的账号申诉','用户 alexmorgan 提交了账号申诉，申诉理由：666','system','',19,0,'管理员','',1,'2026-07-13 16:21:15'),
(25,'帖子被编辑','管理员编辑了您的帖子《设计师如何提升审美》','system','',14,19,'alexmorgan','',0,'2026-07-13 18:32:31'),
(26,'帖子被删除','您的帖子《React 19 新特性解读》已被管理员删除','system','',5,19,'alexmorgan','',0,'2026-07-13 18:33:51'),
(27,'帖子被删除','您的帖子《Cloud Native架构实践》已被管理员删除','system','',10,19,'alexmorgan','',0,'2026-07-13 18:33:54'),
(28,'帖子被删除','您的帖子《像素艺术创作技巧》已被管理员删除','system','',6,19,'alexmorgan','',0,'2026-07-13 18:33:57'),
(29,'帖子被删除','您的帖子《独立游戏开发日记》已被管理员删除','system','',9,19,'alexmorgan','',0,'2026-07-13 18:34:00'),
(30,'帖子被删除','您的帖子《设计师如何提升审美》已被管理员删除','system','',14,19,'alexmorgan','',0,'2026-07-13 18:34:03'),
(31,'帖子被删除','您的帖子《分享我的设计作品集》已被管理员删除','system','',2,19,'alexmorgan','',0,'2026-07-13 18:34:06'),
(32,'帖子被删除','您的帖子《AI绘画入门指南》已被管理员删除','system','',3,19,'alexmorgan','',0,'2026-07-13 18:34:10'),
(33,'帖子被删除','您的帖子《Vue3 + TypeScript 实战》已被管理员删除','system','',8,19,'alexmorgan','',0,'2026-07-13 18:34:18'),
(34,'帖子被删除','您的帖子《我的应用开发历程》已被管理员删除','system','',2,19,'alexmorgan','',0,'2026-07-13 18:34:22'),
(35,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-13 18:34:40'),
(36,'任务完成','恭喜完成\"完善资料\"任务！获得: 30积分','system','',19,0,'管理员','',1,'2026-07-13 19:42:23'),
(37,'认证申请已提交','您的蓝V认证申请已提交，请耐心等待管理员审核','verification','',19,0,'系统','',1,'2026-07-13 21:47:11'),
(38,'新的认证申请','1 提交了蓝V认证申请，请及时审核','verification','',19,19,'alexmorgan','',1,'2026-07-13 21:47:11'),
(39,'认证申请通过','恭喜，您的蓝V认证申请已通过审核！','system','',19,0,'管理员','',1,'2026-07-13 21:47:29'),
(40,'帖子被删除','您的帖子《面试经历分享》已被管理员删除','system','',3,19,'alexmorgan','',0,'2026-07-14 12:01:39'),
(41,'新粉丝','Alex Morgan 关注了您','system','',13,19,'Alex Morgan','',0,'2026-07-14 12:01:47'),
(42,'新粉丝','Alex Morgan 关注了您','system','',13,19,'Alex Morgan','',0,'2026-07-14 12:01:50'),
(43,'帖子被删除','您的帖子《移动开发趋势2026》已被管理员删除','system','',13,19,'alexmorgan','',0,'2026-07-14 12:01:54'),
(44,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:12:32'),
(45,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「版主」。','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:14:30'),
(46,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:14:50'),
(47,'版主申请未通过','很遗憾，您的版主申请未被通过。原因: 申请理由不够充分','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-14 13:14:55'),
(48,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:55:32'),
(49,'新版主申请','bobwang 申请成为「设计创作」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 13:55:32'),
(50,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「审核员」。','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:56:06'),
(51,'版主申请未通过','很遗憾，您的版主申请未被通过。原因: 666','moderator_apply_result','',1,19,'alexmorgan','',0,'2026-07-14 13:56:11'),
(52,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:57:03'),
(53,'新版主申请','lisa_chen 申请成为「设计创作」板块的 审核员','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 13:57:03'),
(54,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「版主」。','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-14 13:57:25'),
(55,'新版主申请','bobwang 申请成为「综合讨论」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 14:00:13'),
(56,'新版主申请','bobwang 申请成为「设计创作」板块的 版主','moderator_apply','',19,1,'bobwang','',1,'2026-07-14 14:00:13'),
(57,'新版主申请','lisa_chen 申请成为「综合讨论」板块的 版主','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 14:00:20'),
(58,'新版主申请','lisa_chen 申请成为「设计创作」板块的 审核员','moderator_apply','',19,2,'lisa_chen','',1,'2026-07-14 14:00:20'),
(59,'新的账号申诉','用户 35735712 提交了账号申诉，申诉理由：66','system','',19,0,'管理员','',1,'2026-07-14 15:25:58'),
(60,'新的账号申诉','用户 35735712 提交了账号申诉，申诉理由：test appeal','system','',19,0,'管理员','',1,'2026-07-14 15:30:56'),
(61,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-15 04:17:41'),
(62,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',19,0,'管理员','',1,'2026-07-15 04:26:15'),
(63,'新粉丝','35735712 关注了您','system','',19,10001,'35735712','',1,'2026-07-15 10:21:50'),
(64,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「审核员」。','moderator_apply_result','',2,19,'alexmorgan','',0,'2026-07-15 19:31:36'),
(65,'卡密兑换成功','您使用卡密 CDKEY-MRMRD84EXRNR 兑换成功，获得：2000元余额、额外10000积分、额外5000经验值','system','',10001,0,'管理员','',1,'2026-07-16 00:16:12'),
(66,'新粉丝','35735712 关注了您','system','',19,10001,'35735712','',1,'2026-07-16 00:16:45'),
(67,'任务完成','恭喜完成\"评论互动\"任务！获得: 5积分','system','',10001,0,'管理员','',1,'2026-07-16 00:17:34'),
(68,'买家已确认收货','35735712已确认收货「购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》」，资金已到账。','system','',19,0,'','',1,'2026-07-16 00:19:36'),
(69,'买家已确认收货','35735712已确认收货「购买应用《付费内容与权限解锁功能全套测试 - 会员权益篇》」，资金已到账。','system','',19,0,'','',1,'2026-07-16 00:19:39'),
(70,'合集购买通知','用户 bob123 购买了你的合集《社区功能测试合集》','collection_purchase','',19,1,'bob123','',1,'2026-07-16 01:12:14'),
(71,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',1,'2026-07-16 16:40:43'),
(72,'新版主申请','35735712 申请成为「综合讨论」板块的 版主','moderator_apply','',19,10001,'35735712','',1,'2026-07-16 17:06:35'),
(73,'版主申请已通过','恭喜，您的版主申请已通过审核，您已被任命为「管理员」。','moderator_apply_result','',10001,19,'alexmorgan','',0,'2026-07-16 17:07:01'),
(87,'新粉丝','管理员 关注了您','follow','/appstore/profile/10004',19,10004,'管理员','',1,'2026-07-17 02:20:34'),
(92,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:37:47'),
(93,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:39:56'),
(94,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',19,1,'管理员','',0,'2026-07-17 15:41:24'),
(95,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',19,1,'管理员','',1,'2026-07-17 16:35:31'),
(96,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10005,1,'管理员','',0,'2026-07-17 17:41:17'),
(97,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10006,1,'管理员','',0,'2026-07-17 17:42:42'),
(98,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10007,1,'管理员','',0,'2026-07-17 17:44:52'),
(99,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10008,1,'管理员','',0,'2026-07-17 18:01:18'),
(100,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10009,1,'管理员','',0,'2026-07-17 18:02:02'),
(101,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10009,1,'管理员','',0,'2026-07-17 18:03:44'),
(102,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',10010,1,'管理员','',0,'2026-07-17 18:05:00'),
(103,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 9.8元\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:28'),
(104,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:28'),
(105,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:39:50'),
(106,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:42:55'),
(107,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:47:26'),
(108,'购买商品《移动端组件库》','您已成功购买《移动端组件库》，支付 980积分\n发货内容：赠送 ¥10 余额','system','',10011,1,'管理员','',0,'2026-07-17 18:47:59'),
(109,'任务完成','恭喜完成\"每日签到\"任务！获得: 10积分','system','',19,0,'管理员','',0,'2026-07-17 23:39:01'),
(110,'购买商品《手机》','您已成功购买《手机》，支付 2939.02元','system','',19,1,'管理员','',0,'2026-07-17 23:58:36'),
(111,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',19,0,'管理员','',0,'2026-07-17 23:59:49'),
(112,'新粉丝','Alex Morgan 关注了您','follow','/appstore/profile/19',14,19,'Alex Morgan','',0,'2026-07-18 01:40:00'),
(113,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/18 11:48:36','login_alert','/appstore/login-history',3,0,'系统','',0,'2026-07-18 03:48:36'),
(114,'异地登录提醒','检测到首次登录：中国 浙江 嘉兴，设备：未知设备，时间：2026/7/18 11:49:31','login_alert','/appstore/login-history',19,0,'系统','',0,'2026-07-18 03:49:31'),
(115,'异地登录提醒','检测到异地登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/18 11:51:53','login_alert','/appstore/login-history',19,0,'系统','',0,'2026-07-18 03:51:53'),
(116,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',10017,0,'管理员','',0,'2026-07-19 00:52:10'),
(117,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',10018,0,'管理员','',0,'2026-07-19 00:52:47'),
(118,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',10019,0,'管理员','',0,'2026-07-19 01:04:36'),
(119,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/19 12:02:49','login_alert','/appstore/login-history',1,0,'系统','',0,'2026-07-19 04:02:49'),
(120,'异地登录提醒','检测到异地登录：中国 浙江 Xiasha，设备：未知设备，时间：2026/7/20 12:17:22','login_alert','/appstore/login-history',19,0,'系统','',0,'2026-07-20 04:17:22'),
(121,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 24积分','system','',1,0,'管理员','',0,'2026-07-20 07:15:01'),
(122,'经验扣除通知','管理员扣除了 30 经验值。原因：测试手动扣分','system','',5,0,'管理员','',0,'2026-07-20 16:52:11'),
(123,'经验扣除通知','因\"帖子被驳回\"，扣除 30 经验值。原因：测试: post_rejected','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(124,'经验扣除通知','因\"帖子被删除\"，扣除 50 经验值。原因：测试: post_deleted','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(125,'经验扣除通知','因\"帖子被锁定\"，扣除 30 经验值。原因：测试: post_locked','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(126,'经验扣除通知','因\"评论被删除\"，扣除 20 经验值。原因：测试: comment_deleted','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(127,'经验扣除通知','因\"敏感词违规\"，扣除 20 经验值。原因：测试: block_word_triggered','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(128,'经验扣除通知','因\"举报核实违规\"，扣除 40 经验值。原因：测试: report_verified','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(129,'经验扣除通知','因\"滥用举报\"，扣除 40 经验值。原因：测试: report_abuse','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(130,'经验扣除通知','因\"申诉驳回\"，扣除 50 经验值。原因：测试: appeal_rejected','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(131,'经验扣除通知','因\"管理员封禁\"，扣除 500 经验值。原因：测试封禁','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(132,'经验下降过快提醒','你的经验值今日下降过快，请注意遵守社区规范。如有疑问可联系管理员申诉。','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(133,'经验扣除通知','因\"自动封禁\"，扣除 100 经验值。原因：测试: auto_banned','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(134,'经验扣除通知','因\"聊天室踢出\"，扣除 20 经验值。原因：测试: chat_kicked','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(135,'经验扣除通知','因\"聊天室禁言\"，扣除 20 经验值。原因：测试: chat_banned','system','',2,0,'管理员','',0,'2026-07-20 17:27:38'),
(136,'经验扣除通知','因\"私信骚扰\"，扣除 30 经验值。原因：测试: dm_harassment','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(137,'经验扣除通知','因\"头像昵称违规\"，扣除 20 经验值。原因：测试: profile_violation','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(138,'经验扣除通知','因\"恶意差评\"，扣除 30 经验值。原因：测试: review_malicious','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(139,'经验扣除通知','因\"虚假商品\"，扣除 50 经验值。原因：测试: product_fraud','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(140,'经验扣除通知','因\"恶意退款\"，扣除 40 经验值。原因：测试: refund_abuse','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(141,'经验扣除通知','因\"应用驳回\"，扣除 30 经验值。原因：测试: app_rejected','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(142,'经验扣除通知','因\"应用下架\"，扣除 50 经验值。原因：测试: app_takedown','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(143,'经验扣除通知','因\"应用删除\"，扣除 60 经验值。原因：测试: app_deleted','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(144,'经验扣除通知','因\"投票作弊\"，扣除 30 经验值。原因：测试: vote_cheat','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(145,'经验扣除通知','因\"活动作弊\"，扣除 40 经验值。原因：测试: campaign_cheat','system','',2,0,'管理员','',0,'2026-07-20 17:27:39'),
(146,'经验扣除通知','因\"帖子被删除\"，扣除 75 经验值。原因：测试附加惩罚','system','',2,0,'管理员','',0,'2026-07-20 17:36:18'),
(147,'经验扣除通知','因\"帖子被删除\"，扣除 125 经验值。原因：测试附加扣分','system','',2,0,'管理员','',0,'2026-07-20 17:42:17'),
(148,'经验扣除通知','因\"帖子被删除\"，扣除 50 经验值。原因：6种附加惩罚测试','system','',2,0,'管理员','',0,'2026-07-20 17:48:36'),
(149,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 24积分','system','',1,0,'管理员','',0,'2026-07-20 20:37:11'),
(150,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',2,0,'管理员','',0,'2026-07-20 20:39:31'),
(151,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/21 04:39:31','login_alert','/appstore/login-history',2,0,'系统','',0,'2026-07-20 20:39:31'),
(152,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',10020,0,'管理员','',0,'2026-07-20 20:48:18'),
(153,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/21 04:48:18','login_alert','/appstore/login-history',10020,0,'系统','',0,'2026-07-20 20:48:18'),
(154,'任务完成','恭喜完成\"完善资料\"任务！获得: 33积分','system','',2,0,'alexmorgan','',0,'2026-07-21 00:12:43'),
(155,'个人资料更新成功','您的个人资料已更新并通过审核','profile_approved','',2,19,'alexmorgan','',0,'2026-07-21 00:12:43'),
(156,'新的评论','Lisa管线昵称: 管线通知测试评论','comment','/community/post/33',19,2,'Lisa管线昵称','',0,'2026-07-21 00:12:43'),
(157,'任务完成','恭喜完成\"评论互动\"任务！获得: 6积分','system','',2,0,'alexmorgan','',0,'2026-07-21 00:12:43'),
(158,'帖子审核未通过','您的帖子《Lisa待审帖B》未通过审核，原因：测试驳回原因','post_rejected','',2,1,'bobwang','',0,'2026-07-21 00:13:38'),
(159,'经验扣除通知','因\"帖子被驳回\"，扣除 45 经验值。原因：测试驳回原因','system','',2,0,'alexmorgan','',0,'2026-07-21 00:13:38'),
(160,'帖子审核通过','您的帖子《Lisa待审帖C》已通过审核并发布','post_approved','',2,19,'alexmorgan','',0,'2026-07-21 00:13:38'),
(161,'评论审核未通过','您的评论未通过审核，原因：测试评论驳回','comment_rejected','',2,19,'alexmorgan','',0,'2026-07-21 00:13:38'),
(162,'帖子审核通过','您的帖子《Lisa单帖通过》已通过审核并发布','post_approved','',2,1,'bobwang','',0,'2026-07-21 00:14:02'),
(163,'帖子审核未通过','您的帖子《Lisa单帖驳回》未通过审核，原因：测试单帖驳回','post_rejected','',2,1,'bobwang','',0,'2026-07-21 00:14:02'),
(164,'经验扣除通知','因\"帖子被驳回\"，扣除 60 经验值。原因：测试单帖驳回','system','',2,0,'alexmorgan','',0,'2026-07-21 00:14:02'),
(165,'评论审核通过','您的评论已通过审核并发布','comment_approved','',2,19,'alexmorgan','',0,'2026-07-21 00:14:02'),
(166,'评论审核未通过','您的评论未通过审核，原因：测试单评论驳回','comment_rejected','',2,19,'alexmorgan','',0,'2026-07-21 00:14:02'),
(167,'帖子已提交审核','您的帖子《管线测试帖-Tech》已提交自动审核，请耐心等待','post_pending','',3,19,'alexmorgan','',0,'2026-07-21 00:14:32'),
(168,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 20积分','system','',3,0,'alexmorgan','',0,'2026-07-21 00:14:32'),
(169,'帖子审核通过','您的帖子《管线测试帖-Tech》已通过审核并发布','post_approved','',3,1,'bobwang','',0,'2026-07-21 00:14:46'),
(170,'评论审核通过','您的评论已通过审核并发布','comment_approved','',3,19,'alexmorgan','',0,'2026-07-21 00:14:46'),
(171,'评论审核通过','您的评论已通过审核并发布','comment_approved','',3,19,'alexmorgan','',0,'2026-07-21 00:14:46'),
(172,'个人资料审核未通过','您的个人资料修改未通过审核：包含违规信息','profile_rejected','',3,19,'alexmorgan','',0,'2026-07-21 00:15:02'),
(173,'异地登录提醒','检测到异地登录：中国 浙江 Hezhuang，设备：Android 16 Chrome 138.0.7204.179，时间：2026/7/21 10:09:24','login_alert','/appstore/login-history',19,0,'系统','',0,'2026-07-21 02:09:25'),
(174,'异地登录提醒','检测到异地登录：中国 浙江 Hezhuang，设备：Android 16 Chrome 138.0.7204.179，时间：2026/7/21 13:15:00','login_alert','/appstore/login-history',19,0,'系统','',0,'2026-07-21 05:15:00'),
(175,'任务完成','恭喜完成\"完善资料\"任务！获得: 30积分','system','',10004,0,'alexmorgan','',0,'2026-07-21 06:56:20'),
(176,'个人资料更新成功','您的个人资料已更新并通过审核','profile_approved','',10004,19,'alexmorgan','',0,'2026-07-21 06:56:20'),
(177,'个人资料更新成功','您的个人资料已更新并通过审核','profile_approved','',10004,19,'alexmorgan','',0,'2026-07-21 06:56:20'),
(178,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/21 14:56:21','login_alert','/appstore/login-history',10004,0,'系统','',0,'2026-07-21 06:56:21'),
(179,'个人资料更新成功','您的个人资料已更新并通过审核','profile_approved','',10004,19,'alexmorgan','',0,'2026-07-21 06:56:29'),
(180,'个人资料更新成功','您的个人资料已更新并通过审核','profile_approved','',10004,19,'alexmorgan','',0,'2026-07-21 06:56:35'),
(181,'异地登录提醒','检测到首次登录：::ffff:127.0.0.1，设备：未知设备，时间：2026/7/21 23:24:06','login_alert','/appstore/login-history',10002,0,'系统','',0,'2026-07-21 15:24:06'),
(182,'任务完成','恭喜完成\"发帖奖励\"任务！获得: 24积分','system','',1,0,'alexmorgan','',0,'2026-07-21 16:15:35'),
(183,'合集购买通知','用户 Lisa管线昵称 购买了你的合集《社区功能测试合集》','collection_purchase','',19,2,'Lisa管线昵称','',0,'2026-07-21 16:50:22'),
(184,'订单已创建','您的订单「正常订单」已创建，将在7天后自动确认收货。','system','',1,0,'','',0,'2026-07-21 17:15:53'),
(185,'新订单','买家购买了「正常订单」，金额5，将在7天后自动结算。','system','',2,1,'bobwang','',0,'2026-07-21 17:15:53');
/*!40000 ALTER TABLE `sys_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT 0,
  `user_name` varchar(100) DEFAULT 'system',
  `type` varchar(30) NOT NULL,
  `target_type` varchar(50) DEFAULT '',
  `target_id` int(11) DEFAULT 0,
  `detail` text DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_system_logs_user` (`user_id`),
  KEY `idx_system_logs_type` (`type`),
  KEY `idx_system_logs_create` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1237 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES
(254,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:45:06'),
(255,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:45:13'),
(256,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:10'),
(257,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 22:51:38'),
(258,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.169','2026-07-10 22:57:02'),
(259,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.169','2026-07-10 23:19:43'),
(260,0,'admin','create','menu',54,'新建菜单\"文件管理\"，路径:','223.160.209.169','2026-07-10 23:24:00'),
(261,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-repo-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(262,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":3,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.169','2026-07-10 23:24:27'),
(263,0,'admin','update','menu',16,'更新菜单\"文件上传策略\"。旧数据:{\"id\":16,\"parent_id\":2,\"name\":\"FilePolicyManage\",\"path\":\"filepolicy\",\"component\":\"/operation/filepolicy/index\",\"redirect\":\"\",\"title\":\"文件上传策略\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-policy-manage\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:26:58'),
(264,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":3,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:24:27.000Z\"}','223.160.208.169','2026-07-10 23:27:10'),
(265,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":3,\"name\":\"StorageConfig\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/storage-config\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:27:43'),
(266,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:24:00.000Z\"}','223.160.208.169','2026-07-10 23:28:21'),
(267,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":2,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.169','2026-07-10 23:28:46'),
(268,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"/a\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:28:21.000Z\"}','223.160.208.169','2026-07-10 23:29:37'),
(269,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.198','2026-07-11 08:40:24'),
(270,19,'alexmorgan','create','cardkey',21,'生成1张卡密(5000元余额)','223.160.215.198','2026-07-11 08:41:04'),
(271,19,'alexmorgan','redeem','cardkey',21,'兑换卡密 CDKEY-MRG47L1VS1EE: 5000元余额、额外99999积分、额外2000经验值','','2026-07-11 08:41:23'),
(272,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.198','2026-07-11 08:42:32'),
(273,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.229','2026-07-11 11:33:19'),
(274,19,'alexmorgan','set_badge','post',12,'设置自定义徽章《开源项目推荐合集》：#','','2026-07-11 11:35:23'),
(275,19,'alexmorgan','essence','post',12,'设为精华帖子《开源项目推荐合集》','','2026-07-11 11:39:23'),
(276,19,'alexmorgan','hot','post',12,'设为热帖帖子《开源项目推荐合集》','','2026-07-11 11:39:24'),
(277,19,'alexmorgan','lock','post',12,'锁定帖子《开源项目推荐合集》','','2026-07-11 11:39:26'),
(278,19,'alexmorgan','unlock','post',12,'解锁帖子《开源项目推荐合集》','','2026-07-11 11:40:52'),
(279,0,'anonymous','update','app',8,'置顶应用ID:8','223.160.213.229','2026-07-11 11:42:47'),
(280,0,'anonymous','update','app',8,'官方认证应用ID:8','223.160.213.229','2026-07-11 11:42:48'),
(281,0,'anonymous','update','app',8,'精品推荐应用ID:8','223.160.213.229','2026-07-11 11:42:49'),
(282,0,'anonymous','delete','app',8,'删除应用ID:8','223.160.213.229','2026-07-11 11:42:53'),
(283,0,'anonymous','delete','app',6,'删除应用ID:6','223.160.213.229','2026-07-11 11:43:05'),
(284,0,'anonymous','delete','app',9,'删除应用ID:9','223.160.213.229','2026-07-11 11:43:27'),
(285,0,'anonymous','update','submission',8,'审核投稿ID:8 通过','223.160.213.229','2026-07-11 11:50:41'),
(286,0,'anonymous','report','app_comment',13,'用户举报评论ID:13, 原因:6','223.160.213.229','2026-07-11 11:51:00'),
(287,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(288,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(289,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 12:19:39'),
(290,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:33:02'),
(291,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:34:38'),
(292,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:37:37'),
(293,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:05'),
(294,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:39:19'),
(295,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:39:29'),
(296,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.145','2026-07-11 12:41:18'),
(297,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:26'),
(298,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:30'),
(299,0,'anonymous','update','role_permission',19,'更新角色权限','117.136.111.145','2026-07-11 12:46:33'),
(300,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:46:49'),
(301,0,'anonymous','delete','role',19,'删除角色\"超级管理员\"','117.136.111.145','2026-07-11 12:47:04'),
(302,0,'anonymous','create','role',22,'新建角色\"系统超级管理员\"','117.136.111.145','2026-07-11 12:47:10'),
(303,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:15'),
(304,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:40'),
(305,0,'anonymous','update','role_permission',22,'更新角色权限','117.136.111.145','2026-07-11 12:47:55'),
(306,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:21'),
(307,0,'anonymous','update','role_permission',20,'更新角色权限','117.136.111.145','2026-07-11 12:48:26'),
(308,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:49:53'),
(309,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(310,0,'anonymous','update','role_permission',22,'更新角色权限','::ffff:127.0.0.1','2026-07-11 12:51:48'),
(311,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:21'),
(312,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:29'),
(313,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 15:45:58'),
(314,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:08'),
(315,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:24'),
(316,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:45'),
(317,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 15:55:56'),
(318,0,'anonymous','update','custom_task',4,'更新自定义任务\"邀请好友\"','117.136.111.145','2026-07-11 16:02:03'),
(319,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:35'),
(320,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:03:49'),
(321,19,'alexmorgan','config','email',0,'更新邮件服务配置','117.136.111.145','2026-07-11 16:04:44'),
(322,0,'admin','delete','menu',42,'删除菜单\"投稿审核\"。被删除数据:{\"id\":42,\"parent_id\":6,\"name\":\"SubmissionReview\",\"path\":\"review\",\"component\":\"/appstore/review\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:06:23'),
(323,0,'admin','create','menu',56,'新建菜单\"商城管理\"，路径:/etnfd','117.136.111.145','2026-07-11 16:08:50'),
(324,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:50.000Z\"}','117.136.111.145','2026-07-11 16:08:57'),
(325,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:08:57.000Z\"}','117.136.111.145','2026-07-11 16:09:04'),
(326,0,'admin','update','menu',3,'更新菜单\"系统管理\"。旧数据:{\"id\":3,\"parent_id\":0,\"name\":\"System\",\"path\":\"/system\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"系统管理\",\"icon\":\"ri:user-3-line\",\"sort_order\":3,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:15'),
(327,0,'admin','update','menu',2,'更新菜单\"运营管理\"。旧数据:{\"id\":2,\"parent_id\":0,\"name\":\"Operation\",\"path\":\"/operation\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"运营管理\",\"icon\":\"ri:settings-3-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:28:46.000Z\"}','117.136.111.145','2026-07-11 16:09:19'),
(328,0,'admin','update','menu',56,'更新菜单\"商城管理\"。旧数据:{\"id\":56,\"parent_id\":0,\"name\":\"商城管理\",\"path\":\"/etnfd\",\"component\":\"\",\"redirect\":\"\",\"title\":\"商城管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:08:50.000Z\",\"update_time\":\"2026-07-11T08:09:04.000Z\"}','117.136.111.145','2026-07-11 16:09:24'),
(329,0,'admin','update','menu',4,'更新菜单\"结果页面\"。旧数据:{\"id\":4,\"parent_id\":0,\"name\":\"Result\",\"path\":\"/result\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"结果页面\",\"icon\":\"ri:checkbox-circle-line\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:30'),
(330,0,'admin','update','menu',5,'更新菜单\"异常页面\"。旧数据:{\"id\":5,\"parent_id\":0,\"name\":\"Exception\",\"path\":\"/exception\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"异常页面\",\"icon\":\"ri:error-warning-line\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.145','2026-07-11 16:09:36'),
(331,19,'alexmorgan','update','avatar_frame',2,'更新头像框\"炫彩边框\"','117.136.111.145','2026-07-11 16:28:24'),
(332,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(333,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:20'),
(334,19,'alexmorgan','create','checkin_group',2,'新建签到规则《》','','2026-07-11 16:43:20'),
(335,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(336,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:43:21'),
(337,19,'alexmorgan','delete','checkin_group',2,'删除签到规则《2》','','2026-07-11 16:43:35'),
(338,0,'system','create','checkin_milestone',1,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(339,0,'system','create','checkin_milestone',2,'新增阶梯奖励(第7天)','','2026-07-11 16:47:34'),
(340,0,'system','create','checkin_milestone',3,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(341,0,'system','create','checkin_milestone',4,'新增阶梯奖励(第7天)','','2026-07-11 16:47:35'),
(342,0,'system','create','checkin_milestone',5,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(343,0,'system','create','checkin_milestone',6,'新增阶梯奖励(第7天)','','2026-07-11 16:47:36'),
(344,0,'system','create','checkin_milestone',7,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(345,0,'system','create','checkin_milestone',8,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(346,0,'system','create','checkin_milestone',9,'新增阶梯奖励(第7天)','','2026-07-11 16:47:38'),
(347,0,'system','create','checkin_milestone',10,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(348,0,'system','create','checkin_milestone',11,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(349,0,'system','create','checkin_milestone',12,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(350,0,'system','create','checkin_milestone',13,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(351,0,'system','create','checkin_milestone',14,'新增阶梯奖励(第7天)','','2026-07-11 16:47:39'),
(352,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(第7天)','','2026-07-11 16:47:45'),
(353,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:47'),
(354,0,'system','delete','checkin_milestone',14,'删除阶梯奖励(id=14)','','2026-07-11 16:47:49'),
(355,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(第7天)','','2026-07-11 16:47:52'),
(356,0,'system','delete','checkin_milestone',5,'删除阶梯奖励(id=5)','','2026-07-11 16:47:53'),
(357,0,'system','delete','checkin_milestone',1,'删除阶梯奖励(第7天)','','2026-07-11 16:47:55'),
(358,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(第7天)','','2026-07-11 16:53:24'),
(359,0,'system','delete','checkin_milestone',13,'删除阶梯奖励(id=13)','','2026-07-11 16:53:28'),
(360,0,'system','update','checkin_milestone',6,'更新阶梯奖励(第7天)','','2026-07-11 16:53:31'),
(361,0,'system','delete','checkin_milestone',6,'删除阶梯奖励(第7天)','','2026-07-11 16:53:32'),
(362,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:35'),
(363,0,'system','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 16:53:36'),
(364,0,'system','create','checkin_group',3,'新建签到规则《test》','','2026-07-11 16:54:50'),
(365,0,'system','create','checkin_milestone',15,'新增阶梯奖励(第30天)','','2026-07-11 16:55:50'),
(366,0,'system','delete','checkin_group',3,'删除签到规则《test》','','2026-07-11 16:58:46'),
(367,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 16:58:49'),
(368,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(第30天)','','2026-07-11 16:58:54'),
(369,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:56'),
(370,0,'system','delete','checkin_milestone',15,'删除阶梯奖励(id=15)','','2026-07-11 16:58:58'),
(371,0,'system','delete','checkin_milestone',12,'删除阶梯奖励(第7天)','','2026-07-11 17:02:13'),
(372,0,'system','delete','checkin_milestone',11,'删除阶梯奖励(第7天)','','2026-07-11 17:06:04'),
(373,0,'system','delete','checkin_milestone',10,'删除阶梯奖励(第7天)','','2026-07-11 17:06:12'),
(374,0,'system','delete','checkin_milestone',9,'删除阶梯奖励(第7天)','','2026-07-11 17:06:14'),
(375,0,'system','delete','checkin_milestone',8,'删除阶梯奖励(第7天)','','2026-07-11 17:06:16'),
(376,0,'system','delete','checkin_group',3,'删除签到规则《3》','','2026-07-11 17:07:01'),
(377,19,'alexmorgan','delete','checkin_milestone',4,'删除阶梯奖励(第7天)','','2026-07-11 17:12:00'),
(378,19,'alexmorgan','create','checkin_group',4,'新建签到规则《666》','','2026-07-11 17:12:09'),
(379,19,'alexmorgan','delete','checkin_group',4,'删除签到规则《666》','','2026-07-11 17:12:29'),
(380,19,'alexmorgan','delete','checkin_milestone',7,'删除阶梯奖励(第7天)','','2026-07-11 17:17:38'),
(381,19,'alexmorgan','update','checkin_group',1,'更新签到规则《默认分组》','','2026-07-11 17:17:44'),
(382,19,'alexmorgan','delete','checkin_milestone',3,'删除阶梯奖励(第7天)','','2026-07-11 17:30:18'),
(383,19,'alexmorgan','delete','checkin_milestone',2,'删除阶梯奖励(第7天)','','2026-07-11 17:30:35'),
(384,19,'alexmorgan','create','checkin_group',5,'新建签到规则《》','','2026-07-11 17:30:39'),
(385,19,'alexmorgan','delete','checkin_group',5,'删除签到规则《5》','','2026-07-11 17:30:42'),
(386,0,'admin','delete','menu',43,'删除菜单\"投稿审核\"。被删除数据:{\"id\":43,\"parent_id\":6,\"name\":\"SubmissionReviewMobile\",\"path\":\"review-mobile\",\"component\":\"/appstore/review/mobile\",\"redirect\":\"\",\"title\":\"投稿审核\",\"icon\":\"\",\"sort_order\":7,\"is_hidden\":1,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/review-mobile\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:41:55'),
(387,0,'anonymous','delete','comment',13,'管理员删除评论ID:13','223.160.208.192','2026-07-11 17:53:17'),
(388,0,'anonymous','update','category',7,'更新分类\"社交\"','223.160.208.192','2026-07-11 17:53:34'),
(389,0,'anonymous','update','official_tag',1,'更新官方标签\"热门\"','223.160.208.192','2026-07-11 17:53:46'),
(390,0,'admin','delete','menu',41,'删除菜单\"我的投稿\"。被删除数据:{\"id\":41,\"parent_id\":6,\"name\":\"MySubmissions\",\"path\":\"my-submissions\",\"component\":\"/appstore/submissions\",\"redirect\":\"\",\"title\":\"我的投稿\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/my-submissions\",\"icon_bg\":\"#EC4899\",\"icon_svg\":\"M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.208.192','2026-07-11 17:54:35'),
(391,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:31'),
(392,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(393,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:43:35'),
(394,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:43:37'),
(395,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:48:40'),
(396,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:48:42'),
(397,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:13'),
(398,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:15'),
(399,0,'anonymous','update','app',12,'置顶应用ID:12','223.160.208.192','2026-07-11 18:49:17'),
(400,0,'anonymous','update','app',12,'取消置顶应用ID:12','223.160.208.192','2026-07-11 18:49:18'),
(401,0,'anonymous','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 19:50:04'),
(402,0,'anonymous','update','membership',2,'更新会员等级\"黄金会员\"','223.160.215.167','2026-07-11 19:55:16'),
(403,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.167','2026-07-11 20:03:08'),
(404,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:10:04'),
(405,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:11:46'),
(406,19,'alexmorgan','update','membership',1,'更新会员等级\"普通会员\"','223.160.215.167','2026-07-11 20:15:21'),
(407,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(408,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:36:40'),
(409,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-11 20:36:59'),
(410,0,'anonymous','login','user',4,'用户 design_master 登录','::ffff:127.0.0.1','2026-07-11 20:38:36'),
(411,0,'anonymous','login','user',20,'用户 testgift 登录','::ffff:127.0.0.1','2026-07-11 20:38:59'),
(412,0,'anonymous','create','coupon',6,'创建优惠券:黄金会员','223.160.215.167','2026-07-11 20:42:43'),
(413,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(414,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 20:47:52'),
(415,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:08'),
(416,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:48:23'),
(417,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:43'),
(418,0,'anonymous','login','user',21,'用户 testcoupon 登录','::ffff:127.0.0.1','2026-07-11 20:49:53'),
(419,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(420,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','::ffff:127.0.0.1','2026-07-11 21:07:13'),
(421,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:22'),
(422,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:07:31'),
(423,0,'anonymous','login','user',22,'用户 titletest 登录','::ffff:127.0.0.1','2026-07-11 21:08:10'),
(424,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:08:20'),
(425,0,'anonymous','login','user',23,'用户 birthdaytest 登录','::ffff:127.0.0.1','2026-07-11 21:10:29'),
(426,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-11 21:19:13'),
(427,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.211.247','2026-07-11 22:04:24'),
(428,19,'alexmorgan','create','membership',5,'新增会员等级\"测试会员\"','223.160.211.247','2026-07-11 22:39:44'),
(429,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:15'),
(430,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','39.144.124.125','2026-07-11 23:02:27'),
(431,19,'alexmorgan','update','membership',5,'更新会员等级\"测试会员\"','39.144.124.125','2026-07-11 23:02:32'),
(432,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','39.144.124.125','2026-07-11 23:07:22'),
(433,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:03:41'),
(434,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 00:05:17'),
(435,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-12 00:29:57'),
(436,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 02:47:44'),
(437,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:02'),
(438,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 02:57:13'),
(439,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-12 02:57:14'),
(440,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:00:38'),
(441,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:04:11'),
(442,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:05:18'),
(443,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:16:22'),
(444,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 03:20:01'),
(445,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:09:53'),
(446,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:38:51'),
(447,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:04'),
(448,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:22'),
(449,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:39:37'),
(450,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:08'),
(451,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:20'),
(452,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:40:47'),
(453,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:40:59'),
(454,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:00'),
(455,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:16'),
(456,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:41:29'),
(457,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:41:53'),
(458,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:47:41'),
(459,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 08:48:15'),
(460,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.162','2026-07-12 08:48:52'),
(461,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.171','2026-07-12 09:04:47'),
(462,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.212.78','2026-07-12 09:22:41'),
(463,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 09:28:44'),
(464,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 09:28:51'),
(465,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.78','2026-07-12 09:29:43'),
(466,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.241','2026-07-12 09:47:31'),
(467,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.146','2026-07-12 10:11:51'),
(468,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.146','2026-07-12 10:28:03'),
(469,0,'anonymous','update','app',12,'置顶应用ID:12','39.144.124.146','2026-07-12 11:30:53'),
(470,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.245','2026-07-12 11:42:12'),
(471,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.245','2026-07-12 12:44:45'),
(472,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.81','2026-07-12 13:44:34'),
(473,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 13:51:30'),
(474,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 14:17:21'),
(475,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 14:18:22'),
(476,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 14:18:29'),
(477,0,'anonymous','update','sys_config',0,'切换PC布局主题: pc','::ffff:127.0.0.1','2026-07-12 14:18:29'),
(478,19,'alexmorgan','update','plugin',5,'禁用插件「地图组件」','117.136.111.47','2026-07-12 14:47:30'),
(479,19,'alexmorgan','update','plugin',5,'启用插件「地图组件」','117.136.111.47','2026-07-12 14:47:31'),
(480,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:00:52'),
(481,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-12 15:20:39'),
(482,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:25:39'),
(483,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.47','2026-07-12 15:52:25'),
(484,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"MallManage\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"上下架\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-manage\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-8 4c0 .55-.45 1-1 1s-1-.45-1-1V8h2v2zm4-1c.55 0 1-.45 1-1V8h-2v2c0 .55.45 1 1 1z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:43'),
(485,0,'admin','update','menu',58,'更新菜单\"订单管理\"。旧数据:{\"id\":58,\"parent_id\":56,\"name\":\"MallOrders\",\"path\":\"/appstore/mall-orders\",\"component\":\"/appstore/admin/mall/mall-orders\",\"redirect\":\"\",\"title\":\"订单管理\",\"icon\":\"ri:file-list-3-line\",\"sort_order\":2,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"处理\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"导出\\\",\\\"authMark\\\":\\\"export\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-orders\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:51'),
(486,0,'admin','update','menu',59,'更新菜单\"分类管理\"。旧数据:{\"id\":59,\"parent_id\":56,\"name\":\"MallCategories\",\"path\":\"/appstore/mall-categories\",\"component\":\"/appstore/admin/mall/mall-categories\",\"redirect\":\"\",\"title\":\"分类管理\",\"icon\":\"ri:price-tag-3-line\",\"sort_order\":3,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-categories\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.22-1.05-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:08:58'),
(487,0,'admin','update','menu',60,'更新菜单\"售后服务\"。旧数据:{\"id\":60,\"parent_id\":56,\"name\":\"MallAfterSales\",\"path\":\"/appstore/mall-after-sales\",\"component\":\"/appstore/admin/mall/mall-after-sales\",\"redirect\":\"\",\"title\":\"售后服务\",\"icon\":\"ri:customer-service-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"处理\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-after-sales\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12c0 5.32 3.36 9.82 8.03 11.49.63.23 1.29.4 1.97.52.68.12 1.34.12 2.03 0 .68-.12 1.34-.29 1.97-.52C20.64 21.82 24 17.32 24 12 24 6.48 19.52 2 14 2zm-2 15h4v2h-4v-2zm4-4H8c0-3.31 2.69-6 6-6s6 2.69 6 6h-4z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:09:06'),
(488,0,'admin','update','menu',61,'更新菜单\"优惠活动\"。旧数据:{\"id\":61,\"parent_id\":56,\"name\":\"MallPromotions\",\"path\":\"/appstore/mall-promotions\",\"component\":\"/appstore/admin/mall/mall-promotions\",\"redirect\":\"\",\"title\":\"优惠活动\",\"icon\":\"ri:gift-line\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/mall-promotions\",\"icon_bg\":\"#8B5CF6\",\"icon_svg\":\"M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-4-4h-2V6h-2v2h-2v2h2v2h2v-2h2V8z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-11T08:15:17.000Z\"}','117.136.111.47','2026-07-12 16:09:13'),
(489,0,'admin','update','menu',68,'更新菜单\"存储文件\"。旧数据:{\"id\":68,\"parent_id\":54,\"name\":\"StorageFiles\",\"path\":\"/system/storage-files\",\"component\":\"/system/storage-files\",\"redirect\":\"\",\"title\":\"存储文件\",\"icon\":\"ri:hard-drive-3-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"上传\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/storage-files\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM7 13h10v2H7v-2zm0 4h7v2H7v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T09:31:24.000Z\",\"update_time\":\"2026-07-11T09:31:24.000Z\"}','117.136.111.47','2026-07-12 16:09:23'),
(490,0,'admin','update','menu',29,'更新菜单\"文件仓库\"。旧数据:{\"id\":29,\"parent_id\":54,\"name\":\"FileRepository\",\"path\":\"filerepo\",\"component\":\"/system/filerepo/index\",\"redirect\":\"\",\"title\":\"文件仓库\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-repo-manage\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:27:10.000Z\"}','117.136.111.47','2026-07-12 16:09:29'),
(491,0,'admin','update','menu',16,'更新菜单\"文件上传策略\"。旧数据:{\"id\":16,\"parent_id\":54,\"name\":\"FilePolicyManage\",\"path\":\"filepolicy\",\"component\":\"/operation/filepolicy/index\",\"redirect\":\"\",\"title\":\"文件上传策略\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/file-policy-manage\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:26:58.000Z\"}','117.136.111.47','2026-07-12 16:09:37'),
(492,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":54,\"name\":\"StorageConfig\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/storage-config\",\"icon_bg\":\"#3B82F6\",\"icon_svg\":\"M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13zM6 20V4h5v7h7v9H6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:27:43.000Z\"}','117.136.111.47','2026-07-12 16:09:44'),
(493,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"商品管理\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-12T08:08:43.000Z\"}','117.136.111.47','2026-07-12 16:10:39'),
(494,0,'admin','update','menu',57,'更新菜单\"商品管理\"。旧数据:{\"id\":57,\"parent_id\":56,\"name\":\"MallAfterSales\",\"path\":\"/appstore/mall-manage\",\"component\":\"/appstore/admin/mall/mall-manage\",\"redirect\":\"\",\"title\":\"商品管理\",\"icon\":\"ri:shopping-bag-3-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:15:17.000Z\",\"update_time\":\"2026-07-12T08:10:39.000Z\"}','117.136.111.47','2026-07-12 16:10:51'),
(495,0,'admin','update','menu',36,'更新菜单\"对象存储\"。旧数据:{\"id\":36,\"parent_id\":54,\"name\":\"对象存储\",\"path\":\"storage-config\",\"component\":\"/appstore/storage-config\",\"redirect\":\"\",\"title\":\"对象存储\",\"icon\":\"\",\"sort_order\":16,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T08:09:44.000Z\"}','117.136.111.47','2026-07-12 16:24:10'),
(496,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','117.136.111.47','2026-07-12 16:51:24'),
(497,0,'admin','update','menu',54,'更新菜单\"文件管理\"。旧数据:{\"id\":54,\"parent_id\":0,\"name\":\"文件管理\",\"path\":\"/awsdb\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"文件管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"上传\\\",\\\"authMark\\\":\\\"upload\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"下载\\\",\\\"authMark\\\":\\\"download\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T15:24:00.000Z\",\"update_time\":\"2026-07-10T15:29:37.000Z\"}','223.160.214.185','2026-07-12 17:15:51'),
(498,0,'anonymous','update','role_permission',22,'更新角色权限','223.160.214.185','2026-07-12 17:16:41'),
(499,0,'anonymous','update','role_permission',20,'更新角色权限','223.160.214.185','2026-07-12 17:16:45'),
(500,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.111','2026-07-12 18:25:56'),
(501,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_default_group, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 18:48:43'),
(502,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_default_group, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 18:49:07'),
(503,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:08:48'),
(504,0,'anonymous','update','membership',3,'更新会员等级\"钻石会员\"','::ffff:127.0.0.1','2026-07-12 19:13:46'),
(505,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:16:39'),
(506,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:17:09'),
(507,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:17:11'),
(508,0,'35735712','create','user',10001,'用户注册','','2026-07-12 19:18:20'),
(509,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, site_maintenance_enabled, site_maintenance_msg','223.160.209.111','2026-07-12 19:24:11'),
(510,0,'admin','create','menu',70,'新建菜单\"awdtc\"，路径:','223.160.209.111','2026-07-12 19:26:16'),
(511,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"awdtc\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:16.000Z\"}','223.160.209.111','2026-07-12 19:26:27'),
(512,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:27.000Z\"}','223.160.209.111','2026-07-12 19:26:32'),
(513,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:32.000Z\"}','223.160.209.111','2026-07-12 19:26:36'),
(514,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":3,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"/system/sysconfig/index\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"\",\"sort_order\":12,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M19.14 12.94c.04-.3.06-.61.06-.94 0-.33-.02-.64-.06-.94l2.02-1.58c.18-.14.23-.38.12-.56l-1.89-3.28c-.12-.19-.36-.26-.56-.18l-2.38.96c-.5-.38-1.06-.68-1.66-.88L14.45 3.5c-.04-.2-.2-.34-.4-.34h-3.78c-.2 0-.36.14-.4.34l-.3 2.52c-.6.2-1.16.5-1.66.88l-2.38-.96c-.2-.08-.44-.01-.56.18L3.28 9.52c-.12.19-.06.42.12.56l2.02 1.58c-.04.3-.06.61-.06.94s.02.64.06.94l-2.02 1.58c-.18.14-.23.38-.12.56l1.89 3.28c.12.19.36.26.56.18l2.38-.96c.5.38 1.06.68 1.66.88l.3 2.52c.04.2.2.34.4.34h3.78c.2 0 .36-.14.4-.34l.3-2.52c.6-.2 1.16-.5 1.66-.88l2.38.96c.2.08.44.01.56-.18l1.89-3.28c.12-.19.06-.42-.12-.56l-2.02-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:29:28'),
(515,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":3,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-config\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T15:24:27.000Z\"}','223.160.209.111','2026-07-12 19:29:42'),
(516,0,'admin','update','menu',34,'更新菜单\"邮件卡片\"。旧数据:{\"id\":34,\"parent_id\":3,\"name\":\"EmailTemplates\",\"path\":\"email-templates\",\"component\":\"/appstore/email-templates\",\"redirect\":\"\",\"title\":\"邮件卡片\",\"icon\":\"\",\"sort_order\":14,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-templates\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:29:55'),
(517,0,'admin','update','menu',35,'更新菜单\"邮件推送\"。旧数据:{\"id\":35,\"parent_id\":3,\"name\":\"EmailPush\",\"path\":\"email-push\",\"component\":\"/appstore/email-push\",\"redirect\":\"\",\"title\":\"邮件推送\",\"icon\":\"\",\"sort_order\":15,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/email-push\",\"icon_bg\":\"#10B981\",\"icon_svg\":\"M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.209.111','2026-07-12 19:30:13'),
(518,0,'admin','update','menu',65,'更新菜单\"支付配置\"。旧数据:{\"id\":65,\"parent_id\":2,\"name\":\"PaymentConfig\",\"path\":\"/operation/payment-config\",\"component\":\"/operation/payment-config/index\",\"redirect\":\"\",\"title\":\"支付配置\",\"icon\":\"ri:bank-card-line\",\"sort_order\":24,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/payment-config\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4H4V6h16v2zm-8 4H7v2h5v-2zm3 0h2v2h-2v-2z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:30:32'),
(519,0,'admin','update','menu',66,'更新菜单\"充值金额配置\"。旧数据:{\"id\":66,\"parent_id\":2,\"name\":\"RechargeAmounts\",\"path\":\"/operation/recharge-amounts\",\"component\":\"/operation/recharge-amounts/index\",\"redirect\":\"\",\"title\":\"充值金额配置\",\"icon\":\"ri:money-cny-circle-line\",\"sort_order\":25,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/recharge-amounts\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:30:42'),
(520,0,'admin','update','menu',63,'更新菜单\"布局主题\"。旧数据:{\"id\":63,\"parent_id\":2,\"name\":\"LayoutThemesManage\",\"path\":\"/operation/layout-themes\",\"component\":\"/operation/themes/index\",\"redirect\":\"\",\"title\":\"布局主题\",\"icon\":\"ri:palette-line\",\"sort_order\":22,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/operation/layout-themes\",\"icon_bg\":\"#F59E0B\",\"icon_svg\":\"M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-4.5 8c-.83 0-1.5-.67-1.5-1.5S6.67 8 7.5 8 9 8.67 9 9.5 8.33 11 7.5 11zm9 0c-.83 0-1.5-.67-1.5-1.5S15.67 8 16.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-11T08:19:02.000Z\"}','223.160.209.111','2026-07-12 19:31:19'),
(521,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"\",\"component\":\"\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:26:36.000Z\"}','223.160.209.111','2026-07-12 19:32:11'),
(522,0,'admin','update','menu',70,'更新菜单\"配置管理\"。旧数据:{\"id\":70,\"parent_id\":0,\"name\":\"配置管理\",\"path\":\"/arccg\",\"component\":\"/sfccg\",\"redirect\":\"\",\"title\":\"配置管理\",\"icon\":\"\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-12T11:26:16.000Z\",\"update_time\":\"2026-07-12T11:32:11.000Z\"}','223.160.209.111','2026-07-12 19:33:09'),
(523,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(524,0,'admin','update','menu',28,'更新菜单\"邮件配置\"。旧数据:{\"id\":28,\"parent_id\":70,\"name\":\"EmailConfig\",\"path\":\"email\",\"component\":\"/system/email/index\",\"redirect\":\"\",\"title\":\"邮件配置\",\"icon\":\"\",\"sort_order\":9,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"测试\\\",\\\"authMark\\\":\\\"test\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:41.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(525,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":70,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"/system/sysconfig/index\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"\",\"sort_order\":12,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:28.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(526,0,'admin','update','menu',34,'更新菜单\"邮件卡片\"。旧数据:{\"id\":34,\"parent_id\":70,\"name\":\"EmailTemplates\",\"path\":\"email-templates\",\"component\":\"/appstore/email-templates\",\"redirect\":\"\",\"title\":\"邮件卡片\",\"icon\":\"\",\"sort_order\":14,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:29:55.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(527,0,'admin','update','menu',35,'更新菜单\"邮件推送\"。旧数据:{\"id\":35,\"parent_id\":70,\"name\":\"EmailPush\",\"path\":\"email-push\",\"component\":\"/appstore/email-push\",\"redirect\":\"\",\"title\":\"邮件推送\",\"icon\":\"\",\"sort_order\":15,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"启停\\\",\\\"authMark\\\":\\\"toggle\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:30:13.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(528,0,'admin','update','menu',63,'更新菜单\"布局主题\"。旧数据:{\"id\":63,\"parent_id\":70,\"name\":\"LayoutThemesManage\",\"path\":\"/operation/layout-themes\",\"component\":\"/operation/themes/index\",\"redirect\":\"\",\"title\":\"布局主题\",\"icon\":\"ri:palette-line\",\"sort_order\":22,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:31:19.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(529,0,'admin','update','menu',65,'更新菜单\"支付配置\"。旧数据:{\"id\":65,\"parent_id\":70,\"name\":\"PaymentConfig\",\"path\":\"/operation/payment-config\",\"component\":\"/operation/payment-config/index\",\"redirect\":\"\",\"title\":\"支付配置\",\"icon\":\"ri:bank-card-line\",\"sort_order\":24,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:30:32.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(530,0,'admin','update','menu',66,'更新菜单\"充值金额配置\"。旧数据:{\"id\":66,\"parent_id\":70,\"name\":\"RechargeAmounts\",\"path\":\"/operation/recharge-amounts\",\"component\":\"/operation/recharge-amounts/index\",\"redirect\":\"\",\"title\":\"充值金额配置\",\"icon\":\"ri:money-cny-circle-line\",\"sort_order\":25,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-11T08:19:02.000Z\",\"update_time\":\"2026-07-12T11:30:42.000Z\"}','::ffff:127.0.0.1','2026-07-12 19:36:15'),
(531,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:36:24'),
(532,0,'admin','create','menu',71,'新建菜单\"站点配置\"，路径:/appstore/site-config','::ffff:127.0.0.1','2026-07-12 19:36:24'),
(533,0,'admin','delete','menu',71,'删除菜单\"站点配置\"。被删除数据:{\"id\":71,\"parent_id\":70,\"name\":\"SiteConfig\",\"path\":\"/appstore/site-config\",\"component\":\"\",\"redirect\":\"\",\"title\":\"站点配置\",\"icon\":\"ri:global-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#FF4757\",\"icon_svg\":\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z\",\"category\":\"\",\"create_time\":\"2026-07-12T11:36:24.000Z\",\"update_time\":\"2026-07-12T11:36:24.000Z\"}','223.160.209.111','2026-07-12 19:38:19'),
(534,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:45:16'),
(535,0,'admin','create','menu',72,'新建菜单\"短信配置\"，路径:/appstore/sms-config','::ffff:127.0.0.1','2026-07-12 19:45:16'),
(536,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:45:22'),
(537,19,'alexmorgan','add','sms_config',1,'添加短信配置: yunpian','::ffff:127.0.0.1','2026-07-12 19:45:22'),
(538,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:47:09'),
(539,0,'admin','create','menu',73,'新建菜单\"站点配置\"，路径:/appstore/site-config','::ffff:127.0.0.1','2026-07-12 19:47:09'),
(540,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:53:13'),
(541,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:53:38'),
(542,19,'alexmorgan','add','sms_config',2,'添加短信配置: aliyun','::ffff:127.0.0.1','2026-07-12 19:53:38'),
(543,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 19:56:06'),
(544,19,'alexmorgan','add','sms_config',3,'添加短信配置: tencent','::ffff:127.0.0.1','2026-07-12 19:56:06'),
(545,19,'alexmorgan','edit','sms_config',2,'更新短信配置: aliyun','223.160.209.111','2026-07-12 20:01:46'),
(546,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:12'),
(547,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:52'),
(548,19,'alexmorgan','add','sms_config',4,'添加短信配置: huawei','::ffff:127.0.0.1','2026-07-12 20:08:52'),
(549,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:08:57'),
(550,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:26:05'),
(551,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:00'),
(552,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:06'),
(553,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:34'),
(554,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:39'),
(555,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:46'),
(556,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:31:50'),
(557,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:33:10'),
(558,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','223.160.208.247','2026-07-12 20:35:45'),
(559,19,'alexmorgan','update','membership',3,'更新会员等级\"钻石会员\"','223.160.208.247','2026-07-12 20:36:06'),
(560,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:37:44'),
(561,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 20:41:29'),
(562,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 20:43:06'),
(563,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-12 20:44:39'),
(564,19,'alexmorgan','update','user',10001,'更新用户信息','','2026-07-12 20:44:39'),
(565,19,'alexmorgan','update','user',19,'更新用户信息','','2026-07-12 20:45:27'),
(566,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.247','2026-07-12 20:59:53'),
(567,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 21:08:50'),
(568,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.247','2026-07-12 21:16:30'),
(569,0,'anonymous','update','app',12,'精品推荐应用ID:12','223.160.209.247','2026-07-12 21:51:59'),
(570,0,'admin','update','menu',6,'更新菜单\"审核中心\"。旧数据:{\"id\":6,\"parent_id\":0,\"name\":\"AppStore\",\"path\":\"/appstore\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"应用商店\",\"icon\":\"ri:apps-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:30:54'),
(571,0,'admin','update','menu',6,'更新菜单\"审核中心\"。旧数据:{\"id\":6,\"parent_id\":0,\"name\":\"AppStore\",\"path\":\"/appstore\",\"component\":\"/index/index\",\"redirect\":\"\",\"title\":\"审核中心\",\"icon\":\"ri:apps-2-line\",\"sort_order\":4,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\",\\\"R_USER\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T15:30:54.000Z\"}','223.160.211.115','2026-07-12 23:31:00'),
(572,0,'admin','update','menu',1,'更新菜单\"仪表盘\"。旧数据:{\"id\":1,\"parent_id\":0,\"name\":\"Dashboard\",\"path\":\"/dashboard\",\"component\":\"/index/index\",\"redirect\":\"/dashboard/console\",\"title\":\"仪表盘\",\"icon\":\"ri:pie-chart-line\",\"sort_order\":1,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":null,\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:31:19'),
(573,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.211.115','2026-07-12 23:37:37'),
(574,0,'admin','update','menu',32,'更新菜单\"系统配置\"。旧数据:{\"id\":32,\"parent_id\":70,\"name\":\"SysConfig\",\"path\":\"sysconfig\",\"component\":\"\",\"redirect\":\"\",\"title\":\"系统配置\",\"icon\":\"ri:settings-3-line\",\"sort_order\":0,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":0,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/site-config\",\"icon_bg\":\"#2ED573\",\"icon_svg\":\"M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94L14.4 2.81c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41L9.25 5.35c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T11:36:15.000Z\"}','223.160.211.115','2026-07-12 23:39:02'),
(575,0,'anonymous','update','withdraw',4,'审核提现ID:4 拒绝','223.160.211.115','2026-07-12 23:39:30'),
(576,0,'anonymous','update','withdraw',7,'审核提现ID:7 拒绝(666)','223.160.211.115','2026-07-12 23:45:35'),
(577,0,'admin','update','menu',25,'更新菜单\"提现注销审核\"。旧数据:{\"id\":25,\"parent_id\":3,\"name\":\"DeleteReview\",\"path\":\"delete-review\",\"component\":\"/system/user/delete-review\",\"redirect\":\"\",\"title\":\"注销审核\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/delete-review\",\"icon_bg\":\"#70A1FF\",\"icon_svg\":\"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:50:18'),
(578,0,'admin','update','menu',25,'更新菜单\"提现注销审核\"。旧数据:{\"id\":25,\"parent_id\":3,\"name\":\"DeleteReview\",\"path\":\"delete-review\",\"component\":\"/system/user/delete-review\",\"redirect\":\"\",\"title\":\"提现注销审核\",\"icon\":\"\",\"sort_order\":5,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":null,\"roles\":null,\"enabled\":1,\"mobile_path\":\"\",\"icon_bg\":\"#4ECDC4\",\"icon_svg\":\"\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-12T15:50:18.000Z\"}','223.160.211.115','2026-07-12 23:50:44'),
(579,0,'admin','update','menu',26,'更新菜单\"蓝V认证审核\"。旧数据:{\"id\":26,\"parent_id\":3,\"name\":\"Verification\",\"path\":\"verification\",\"component\":\"/system/verification/index\",\"redirect\":\"\",\"title\":\"蓝V认证审核\",\"icon\":\"\",\"sort_order\":6,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"通过\\\",\\\"authMark\\\":\\\"approve\\\"},{\\\"title\\\":\\\"拒绝\\\",\\\"authMark\\\":\\\"reject\\\"}]\",\"roles\":null,\"enabled\":1,\"mobile_path\":\"/appstore/verification-manage\",\"icon_bg\":\"#FB923C\",\"icon_svg\":\"M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','223.160.211.115','2026-07-12 23:50:44'),
(580,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 10:22:10'),
(581,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 11:13:35'),
(582,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','39.144.124.108','2026-07-13 11:13:48'),
(583,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','39.144.124.108','2026-07-13 11:13:53'),
(584,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.108','2026-07-13 11:35:41'),
(585,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','39.144.124.108','2026-07-13 11:35:52'),
(586,19,'alexmorgan','approve','post',14,'审核通过帖子《2026最新设计资源合集：UI组件库、插画素材、字体包一次性打包》','','2026-07-13 12:17:06'),
(587,19,'alexmorgan','reject','post',13,'驳回帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》，原因：6666','','2026-07-13 12:17:13'),
(588,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:19:02'),
(589,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:20:45'),
(590,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:08'),
(591,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:25'),
(592,19,'alexmorgan','essence','post',13,'设为精华帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:33'),
(593,19,'alexmorgan','pin','post',13,'版块置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:36'),
(594,19,'alexmorgan','pin','post',13,'全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:37'),
(595,19,'alexmorgan','unpin','post',13,'取消全站置顶帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:39'),
(596,19,'alexmorgan','hot','post',13,'设为热帖帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:42'),
(597,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:44'),
(598,19,'alexmorgan','unlock','post',13,'解锁帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:46'),
(599,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:49'),
(600,19,'alexmorgan','unlock','post',13,'解锁帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:53'),
(601,19,'alexmorgan','lock','post',13,'锁定帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 12:26:55'),
(602,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.208.183','2026-07-13 12:50:55'),
(603,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.183','2026-07-13 12:54:46'),
(604,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.183','2026-07-13 12:59:29'),
(605,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.40','2026-07-13 14:09:14'),
(606,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-13 14:21:29'),
(607,0,'anonymous','update','withdraw',1,'审核提现ID:1 通过','223.160.208.40','2026-07-13 14:24:49'),
(608,0,'anonymous','update','withdraw',1,'审核提现ID:1 通过','223.160.208.40','2026-07-13 14:24:49'),
(609,0,'anonymous','update','withdraw',9,'审核提现ID:9 通过','223.160.208.40','2026-07-13 14:24:58'),
(610,0,'anonymous','update','withdraw',9,'审核提现ID:9 通过','223.160.208.40','2026-07-13 14:24:58'),
(611,0,'anonymous','update','withdraw',9,'审核提现ID:9 拒绝','223.160.208.40','2026-07-13 14:24:58'),
(612,0,'anonymous','update','withdraw',9,'审核提现ID:9 拒绝','223.160.208.40','2026-07-13 14:24:58'),
(613,0,'admin','update','menu',44,'更新菜单\"官方标签\"。旧数据:{\"id\":44,\"parent_id\":6,\"name\":\"OfficialTags\",\"path\":\"official-tags\",\"component\":\"/appstore/official-tags\",\"redirect\":\"\",\"title\":\"官方标签\",\"icon\":\"\",\"sort_order\":8,\"is_hidden\":0,\"is_full_page\":0,\"is_keep_alive\":1,\"is_fixed_tab\":0,\"auth_list\":\"[{\\\"title\\\":\\\"新增\\\",\\\"authMark\\\":\\\"add\\\"},{\\\"title\\\":\\\"编辑\\\",\\\"authMark\\\":\\\"edit\\\"},{\\\"title\\\":\\\"删除\\\",\\\"authMark\\\":\\\"delete\\\"}]\",\"roles\":\"[\\\"R_SUPER\\\",\\\"R_ADMIN\\\"]\",\"enabled\":1,\"mobile_path\":\"/appstore/official-tags\",\"icon_bg\":\"#FCA5A5\",\"icon_svg\":\"M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42z\",\"category\":\"\",\"create_time\":\"2026-07-10T14:42:45.000Z\",\"update_time\":\"2026-07-10T14:42:45.000Z\"}','117.136.111.6','2026-07-13 15:04:21'),
(614,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.72','2026-07-13 16:39:07'),
(615,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 18:30:36'),
(616,19,'alexmorgan','unpin','post',6,'取消全站置顶帖子《设计师如何提升审美》','','2026-07-13 18:32:35'),
(617,19,'system','delete','post',15,'作者删除帖子《测试编辑帖子6》','','2026-07-13 18:33:17'),
(618,19,'system','delete','post',14,'作者删除帖子《2026最新设计资源合集：UI组件库、插画素材、字体包一次性打包》','','2026-07-13 18:33:30'),
(619,19,'system','delete','post',13,'作者删除帖子《从零搭建个人博客全栈项目：Vue3 + Express + MySQL 完整指南》','','2026-07-13 18:33:45'),
(620,19,'system','delete','post',3,'管理员删除帖子《React 19 新特性解读》','','2026-07-13 18:33:51'),
(621,19,'system','delete','post',7,'管理员删除帖子《Cloud Native架构实践》','','2026-07-13 18:33:54'),
(622,19,'system','delete','post',9,'管理员删除帖子《像素艺术创作技巧》','','2026-07-13 18:33:57'),
(623,19,'system','delete','post',11,'管理员删除帖子《独立游戏开发日记》','','2026-07-13 18:34:00'),
(624,19,'system','delete','post',6,'管理员删除帖子《设计师如何提升审美》','','2026-07-13 18:34:03'),
(625,19,'system','delete','post',1,'管理员删除帖子《分享我的设计作品集》','','2026-07-13 18:34:06'),
(626,19,'system','delete','post',2,'管理员删除帖子《AI绘画入门指南》','','2026-07-13 18:34:10'),
(627,19,'system','delete','post',5,'管理员删除帖子《Vue3 + TypeScript 实战》','','2026-07-13 18:34:18'),
(628,19,'system','delete','post',4,'管理员删除帖子《我的应用开发历程》','','2026-07-13 18:34:22'),
(629,19,'alexmorgan','approve','post',16,'审核通过帖子《666》','','2026-07-13 18:58:52'),
(630,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 19:02:59'),
(631,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:08:04'),
(632,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:14:08'),
(633,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.209.36','2026-07-13 19:14:37'),
(634,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.209.36','2026-07-13 19:14:59'),
(635,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.209.36','2026-07-13 19:15:11'),
(636,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:15:24'),
(637,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.209.36','2026-07-13 19:15:42'),
(638,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:15:56'),
(639,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:16:34'),
(640,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:16:43'),
(641,19,'alexmorgan','create','experience',8,'新增经验等级\"LV.8\"','223.160.209.36','2026-07-13 19:17:12'),
(642,19,'alexmorgan','create','experience',9,'新增经验等级\"LV.9\"','223.160.209.36','2026-07-13 19:17:49'),
(643,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:19:36'),
(644,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:21:19'),
(645,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:22:24'),
(646,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.209.36','2026-07-13 19:22:46'),
(647,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 19:37:39'),
(648,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.208.36','2026-07-13 19:37:53'),
(649,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.208.36','2026-07-13 19:38:22'),
(650,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.208.36','2026-07-13 19:38:34'),
(651,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:38:54'),
(652,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.209.36','2026-07-13 19:39:00'),
(653,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.209.36','2026-07-13 19:39:21'),
(654,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:39:29'),
(655,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.209.36','2026-07-13 19:39:50'),
(656,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.209.36','2026-07-13 19:40:01'),
(657,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.209.36','2026-07-13 19:40:14'),
(658,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.209.36','2026-07-13 19:40:23'),
(659,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 19:41:18'),
(660,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:03:58'),
(661,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:11'),
(662,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:28'),
(663,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.209.36','2026-07-13 20:04:39'),
(664,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','223.160.208.36','2026-07-13 20:19:12'),
(665,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.36','2026-07-13 21:04:48'),
(666,19,'alexmorgan','pin','post',16,'版块置顶帖子《666》','','2026-07-13 21:04:54'),
(667,19,'alexmorgan','unpin','post',16,'取消版块置顶帖子《666》','','2026-07-13 21:04:56'),
(668,19,'alexmorgan','essence','post',16,'设为精华帖子《666》','','2026-07-13 21:04:57'),
(669,19,'alexmorgan','hot','post',16,'设为热帖帖子《666》','','2026-07-13 21:04:58'),
(670,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:13:19'),
(671,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:13:39'),
(672,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.208.36','2026-07-13 21:20:01'),
(673,19,'alexmorgan','approve','post',17,'审核通过帖子《8888888888》','','2026-07-13 21:21:18'),
(674,19,'alexmorgan','set_badge','post',16,'设置自定义徽章《666》：8888','','2026-07-13 21:24:09'),
(675,19,'alexmorgan','lock','post',16,'锁定帖子《666》','','2026-07-13 21:24:12'),
(676,19,'alexmorgan','update','membership',4,'更新会员等级\"至尊会员\"','223.160.209.36','2026-07-13 21:29:31'),
(677,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 21:44:05'),
(678,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.36','2026-07-13 21:44:14'),
(679,19,'alexmorgan','create','title',10,'新增称号\"蓝V官方认证\"','223.160.209.36','2026-07-13 21:52:48'),
(680,19,'alexmorgan','update','title',10,'授予用户19称号ID:10','223.160.209.36','2026-07-13 21:52:57'),
(681,19,'alexmorgan','create','title',11,'新增称号\"官方认证\"','223.160.209.249','2026-07-13 22:16:52'),
(682,19,'alexmorgan','update','title',11,'授予用户19称号ID:11','223.160.209.249','2026-07-13 22:17:04'),
(683,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:25:11'),
(684,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.214.60','2026-07-13 22:39:12'),
(685,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.214.60','2026-07-13 22:39:21'),
(686,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.214.60','2026-07-13 22:40:28'),
(687,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:40:37'),
(688,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:40:45'),
(689,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:40:54'),
(690,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:41:03'),
(691,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:41:11'),
(692,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:41:19'),
(693,19,'alexmorgan','create','experience',10,'新增经验等级\"10\"','223.160.214.60','2026-07-13 22:41:32'),
(694,19,'alexmorgan','create','experience',11,'新增经验等级\"11\"','223.160.214.60','2026-07-13 22:41:54'),
(695,19,'alexmorgan','create','experience',12,'新增经验等级\"12\"','223.160.214.60','2026-07-13 22:42:10'),
(696,19,'alexmorgan','create','experience',13,'新增经验等级\"13\"','223.160.214.60','2026-07-13 22:42:22'),
(697,19,'alexmorgan','create','experience',14,'新增经验等级\"14\"','223.160.214.60','2026-07-13 22:42:33'),
(698,19,'alexmorgan','create','experience',15,'新增经验等级\"15\"','223.160.214.60','2026-07-13 22:42:42'),
(699,19,'alexmorgan','create','experience',16,'新增经验等级\"16\"','223.160.214.60','2026-07-13 22:42:53'),
(700,19,'alexmorgan','create','experience',17,'新增经验等级\"17\"','223.160.214.60','2026-07-13 22:43:06'),
(701,19,'alexmorgan','create','experience',18,'新增经验等级\"18\"','223.160.214.60','2026-07-13 22:43:18'),
(702,19,'alexmorgan','create','experience',19,'新增经验等级\"19\"','223.160.214.60','2026-07-13 22:43:29'),
(703,19,'alexmorgan','create','experience',20,'新增经验等级\"20\"','223.160.214.60','2026-07-13 22:43:47'),
(704,19,'alexmorgan','update','experience',2,'更新经验等级\"Lv.2\"','223.160.214.60','2026-07-13 22:44:26'),
(705,19,'alexmorgan','update','experience',3,'更新经验等级\"Lv.3\"','223.160.214.60','2026-07-13 22:44:31'),
(706,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:44:36'),
(707,19,'alexmorgan','update','experience',4,'更新经验等级\"Lv.4\"','223.160.214.60','2026-07-13 22:44:39'),
(708,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:44:43'),
(709,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:44:47'),
(710,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:44:57'),
(711,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:45:03'),
(712,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:45:13'),
(713,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:45:21'),
(714,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:45:38'),
(715,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:45:45'),
(716,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:45:53'),
(717,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:46:02'),
(718,19,'alexmorgan','update','experience',13,'更新经验等级\"13\"','223.160.214.60','2026-07-13 22:46:13'),
(719,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:46:27'),
(720,19,'alexmorgan','update','experience',5,'更新经验等级\"Lv.5\"','223.160.214.60','2026-07-13 22:46:55'),
(721,19,'alexmorgan','update','experience',6,'更新经验等级\"Lv.6\"','223.160.214.60','2026-07-13 22:46:59'),
(722,19,'alexmorgan','update','experience',7,'更新经验等级\"Lv.7\"','223.160.214.60','2026-07-13 22:47:20'),
(723,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:47:26'),
(724,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:47:32'),
(725,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:47:41'),
(726,19,'alexmorgan','update','experience',8,'更新经验等级\"LV.8\"','223.160.214.60','2026-07-13 22:48:00'),
(727,19,'alexmorgan','update','experience',9,'更新经验等级\"LV.9\"','223.160.214.60','2026-07-13 22:48:07'),
(728,19,'alexmorgan','update','experience',10,'更新经验等级\"10\"','223.160.214.60','2026-07-13 22:48:17'),
(729,19,'alexmorgan','update','experience',11,'更新经验等级\"11\"','223.160.214.60','2026-07-13 22:48:25'),
(730,19,'alexmorgan','update','experience',12,'更新经验等级\"12\"','223.160.214.60','2026-07-13 22:48:33'),
(731,19,'alexmorgan','update','experience',13,'更新经验等级\"13\"','223.160.214.60','2026-07-13 22:48:42'),
(732,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:48:55'),
(733,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:49:06'),
(734,19,'alexmorgan','update','experience',14,'更新经验等级\"14\"','223.160.214.60','2026-07-13 22:49:20'),
(735,19,'alexmorgan','update','experience',15,'更新经验等级\"15\"','223.160.214.60','2026-07-13 22:49:26'),
(736,19,'alexmorgan','update','experience',16,'更新经验等级\"16\"','223.160.214.60','2026-07-13 22:49:30'),
(737,19,'alexmorgan','update','experience',17,'更新经验等级\"17\"','223.160.214.60','2026-07-13 22:49:36'),
(738,19,'alexmorgan','update','experience',18,'更新经验等级\"18\"','223.160.214.60','2026-07-13 22:49:43'),
(739,19,'alexmorgan','update','experience',19,'更新经验等级\"19\"','223.160.214.60','2026-07-13 22:49:53'),
(740,19,'alexmorgan','update','experience',20,'更新经验等级\"20\"','223.160.214.60','2026-07-13 22:50:07'),
(741,19,'alexmorgan','update','experience',10,'更新经验等级\"LV.10\"','223.160.214.60','2026-07-13 22:50:39'),
(742,19,'alexmorgan','update','experience',11,'更新经验等级\"LV.11\"','223.160.214.60','2026-07-13 22:50:49'),
(743,19,'alexmorgan','update','experience',20,'更新经验等级\"LV.20\"','223.160.214.60','2026-07-13 22:50:55'),
(744,19,'alexmorgan','update','experience',19,'更新经验等级\"LV.19\"','223.160.214.60','2026-07-13 22:51:01'),
(745,19,'alexmorgan','update','experience',18,'更新经验等级\"LV.18\"','223.160.214.60','2026-07-13 22:51:07'),
(746,19,'alexmorgan','update','experience',17,'更新经验等级\"LV.17\"','223.160.214.60','2026-07-13 22:51:12'),
(747,19,'alexmorgan','update','experience',16,'更新经验等级\"LV.16\"','223.160.214.60','2026-07-13 22:51:18'),
(748,19,'alexmorgan','update','experience',15,'更新经验等级\"LV.15\"','223.160.214.60','2026-07-13 22:51:22'),
(749,19,'alexmorgan','update','experience',14,'更新经验等级\"LV.14\"','223.160.214.60','2026-07-13 22:51:30'),
(750,19,'alexmorgan','update','experience',13,'更新经验等级\"LV.13\"','223.160.214.60','2026-07-13 22:51:36'),
(751,19,'alexmorgan','update','experience',12,'更新经验等级\"LV.12\"','223.160.214.60','2026-07-13 22:51:42'),
(752,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','223.160.213.155','2026-07-13 23:13:56'),
(753,19,'alexmorgan','delete','title',10,'撤销用户19称号ID:10','223.160.213.155','2026-07-13 23:15:03'),
(754,19,'alexmorgan','update','title',10,'授予用户19称号ID:10','223.160.213.155','2026-07-13 23:15:06'),
(755,19,'alexmorgan','update','title',9,'授予用户19称号ID:9','223.160.213.155','2026-07-13 23:15:11'),
(756,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','223.160.213.155','2026-07-13 23:30:00'),
(757,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-13 23:52:32'),
(758,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:57:42'),
(759,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:58:46'),
(760,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-13 23:58:55'),
(761,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:01:26'),
(762,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:02:22'),
(763,19,'alexmorgan','update','title',10,'更新称号\"蓝V官方认证\"','117.136.111.23','2026-07-14 00:02:51'),
(764,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 09:45:21'),
(765,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg','117.136.111.23','2026-07-14 10:07:29'),
(766,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-14 10:35:53'),
(767,19,'system','delete','post',16,'作者删除帖子《666》','','2026-07-14 11:43:44'),
(768,19,'system','delete','post',17,'作者删除帖子《8888888888》','','2026-07-14 12:01:29'),
(769,19,'system','delete','post',10,'管理员删除帖子《面试经历分享》','','2026-07-14 12:01:39'),
(770,19,'system','delete','post',8,'管理员删除帖子《移动开发趋势2026》','','2026-07-14 12:01:54'),
(771,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 12:22:22'),
(772,19,'alexmorgan','approve','post',18,'审核通过帖子《66666》','','2026-07-14 12:23:02'),
(773,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.23','2026-07-14 12:59:34'),
(774,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 13:55:32'),
(775,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 14:00:13'),
(776,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-14 14:23:57'),
(777,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.63','2026-07-14 15:16:22'),
(778,19,'alexmorgan','update','user',10001,'更新用户信息','','2026-07-14 15:17:21'),
(779,0,'anonymous','login','user',10001,'用户 35735712 登录','39.144.124.34','2026-07-14 15:35:17'),
(780,0,'anonymous','login','user',10001,'用户 35735712 登录','39.144.124.34','2026-07-14 15:35:50'),
(781,19,'alexmorgan','update','avatar_frame',1,'更新头像框\"金色边框\"','117.136.111.67','2026-07-14 21:06:43'),
(782,19,'alexmorgan','update','avatar_frame',1,'授予用户19头像框ID:1','117.136.111.67','2026-07-14 21:06:48'),
(783,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.67','2026-07-15 00:14:52'),
(784,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.67','2026-07-15 00:14:57'),
(785,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.62','2026-07-15 04:07:47'),
(786,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 04:14:36'),
(787,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 04:16:21'),
(788,19,'alexmorgan','approve','post',19,'审核通过帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 04:19:28'),
(789,19,'alexmorgan','approve','post',20,'审核通过帖子《社区卡片与多媒体模块功能测试 - 互动组件篇》','','2026-07-15 04:19:29'),
(790,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:20:48'),
(791,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:33:28'),
(792,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-15 04:33:37'),
(793,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.213.200','2026-07-15 04:46:11'),
(794,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.210.82','2026-07-15 05:37:57'),
(795,19,'alexmorgan','approve','post',22,'审核通过帖子《666》','','2026-07-15 05:45:13'),
(796,19,'alexmorgan','pin','post',22,'版块置顶帖子《666》','','2026-07-15 06:11:11'),
(797,19,'alexmorgan','unpin','post',22,'取消版块置顶帖子《666》','','2026-07-15 06:11:13'),
(798,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.210.82','2026-07-15 06:54:47'),
(799,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-15 10:47:14'),
(800,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.64','2026-07-15 13:05:02'),
(801,19,'alexmorgan','lock','post',22,'锁定帖子《666》','','2026-07-15 16:03:35'),
(802,19,'alexmorgan','unlock','post',22,'解锁帖子《666》','','2026-07-15 16:03:37'),
(803,19,'alexmorgan','hot','post',22,'设为热帖帖子《666》','','2026-07-15 16:03:38'),
(804,19,'alexmorgan','essence','post',22,'设为精华帖子《666》','','2026-07-15 16:03:40'),
(805,19,'alexmorgan','pin','post',22,'版块置顶帖子《666》','','2026-07-15 16:03:42'),
(806,19,'alexmorgan','pin','post',22,'全站置顶帖子《666》','','2026-07-15 16:03:43'),
(807,19,'alexmorgan','unpin','post',22,'取消全站置顶帖子《666》','','2026-07-15 16:03:45'),
(808,19,'alexmorgan','unpin','post',22,'取消版块置顶帖子《666》','','2026-07-15 16:03:47'),
(809,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.215.186','2026-07-15 16:51:09'),
(810,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.86','2026-07-15 18:39:29'),
(811,19,'alexmorgan','pin','post',19,'版块置顶帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 22:37:01'),
(812,19,'alexmorgan','unpin','post',19,'取消版块置顶帖子《编辑器文字格式功能全面测试 - 基础排版篇》','','2026-07-15 22:37:03'),
(813,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 23:43:45'),
(814,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-15 23:44:33'),
(815,19,'alexmorgan','essence','post',28,'设为精华帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-16 00:12:54'),
(816,19,'alexmorgan','hot','post',28,'设为热帖帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-16 00:13:01'),
(817,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:14:17'),
(818,19,'alexmorgan','create','cardkey',22,'生成1张卡密(2000元余额)','117.136.111.31','2026-07-16 00:15:55'),
(819,10001,'35735712','redeem','cardkey',22,'兑换卡密 CDKEY-MRMRD84EXRNR: 2000元余额、额外10000积分、额外5000经验值','','2026-07-16 00:16:12'),
(820,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:18:39'),
(821,0,'anonymous','login','user',10001,'用户 35735712 登录','117.136.111.31','2026-07-16 00:19:13'),
(822,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 00:46:23'),
(823,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:44'),
(824,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:10:44'),
(825,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:47'),
(826,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:10:51'),
(827,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:10:51'),
(828,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:12:14'),
(829,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:12:14'),
(830,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:27:18'),
(831,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 01:27:18'),
(832,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 01:27:56'),
(833,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 04:05:38'),
(834,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:46:37'),
(835,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:47:47'),
(836,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:47:54'),
(837,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:48:32'),
(838,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 10:49:21'),
(839,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:53:54'),
(840,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:53:58'),
(841,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.214.225','2026-07-16 13:57:56'),
(842,0,'anonymous','login','user',10001,'用户 35735712 登录','112.17.241.147','2026-07-16 15:21:02'),
(843,0,'anonymous','login','user',19,'用户 alexmorgan 登录','112.17.241.147','2026-07-16 16:34:44'),
(844,19,'alexmorgan','approve','post',29,'审核通过帖子《666》','','2026-07-16 16:41:04'),
(845,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 19:25:18'),
(846,0,'anonymous','login','user',10002,'新用户 github_user_mrnwh1hi 通过 github OAuth注册登录','::ffff:127.0.0.1','2026-07-16 19:26:38'),
(847,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.178','2026-07-16 19:39:24'),
(848,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 20:36:12'),
(849,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-16 20:36:45'),
(850,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:40:20'),
(851,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:41:11'),
(852,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:41:17'),
(853,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:42:28'),
(854,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:47:42'),
(855,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:48:39'),
(856,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:48:45'),
(857,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:49:57'),
(858,0,'anonymous','login','user',10003,'用户 test_joiner 登录','::ffff:127.0.0.1','2026-07-16 20:49:57'),
(859,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:54:03'),
(860,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:56:04'),
(861,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:57:47'),
(862,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 20:58:34'),
(863,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-16 21:38:39'),
(864,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.70','2026-07-16 21:47:52'),
(865,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.70','2026-07-16 21:47:59'),
(866,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.9','2026-07-17 02:01:04'),
(867,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:02:08'),
(868,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:13:12'),
(869,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:13:48'),
(870,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:15:18'),
(871,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:15:23'),
(872,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:15:31'),
(873,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:15:41'),
(874,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:19:28'),
(875,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:19:34'),
(876,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 02:20:34'),
(877,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 02:20:41'),
(878,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.237','2026-07-17 02:51:08'),
(879,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.237','2026-07-17 05:41:21'),
(880,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.241','2026-07-17 14:35:49'),
(881,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:03:33'),
(882,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:08'),
(883,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:38'),
(884,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:46'),
(885,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:05:58'),
(886,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:26'),
(887,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:31'),
(888,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 15:29:35'),
(889,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:08'),
(890,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:14'),
(891,10004,'admin','add','logistics_config',1,'添加物流配置','::ffff:127.0.0.1','2026-07-17 15:30:14'),
(892,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:21'),
(893,10004,'admin','delete','logistics_config',0,'删除物流配置','::ffff:127.0.0.1','2026-07-17 15:30:21'),
(894,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:30:27'),
(895,10004,'admin','add','logistics_config',2,'添加物流配置','::ffff:127.0.0.1','2026-07-17 15:30:27'),
(896,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:50:59'),
(897,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:51:07'),
(898,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:52:12'),
(899,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 15:52:19'),
(900,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 15:53:36'),
(901,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.160','2026-07-17 16:05:41'),
(902,19,'alexmorgan','update','user',19,'更新用户信息','','2026-07-17 16:30:04'),
(903,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 16:36:30'),
(904,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:28'),
(905,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:32'),
(906,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:38'),
(907,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:44'),
(908,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:08:50'),
(909,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:12:02'),
(910,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:12:13'),
(911,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:15:42'),
(912,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:15:52'),
(913,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:19:55'),
(914,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:19:55'),
(915,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:00'),
(916,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:01'),
(917,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:06'),
(918,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:11'),
(919,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:28'),
(920,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:20:37'),
(921,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:23:09'),
(922,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:23:16'),
(923,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-17 17:28:35'),
(924,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 17:39:08'),
(925,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:41:04'),
(926,0,'anonymous','login','user',10005,'用户 promo_test1 登录','::ffff:127.0.0.1','2026-07-17 17:41:17'),
(927,0,'anonymous','login','user',10006,'用户 promo_buyer 登录','::ffff:127.0.0.1','2026-07-17 17:42:42'),
(928,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:42:42'),
(929,0,'anonymous','login','user',10007,'用户 promo_test2 登录','::ffff:127.0.0.1','2026-07-17 17:44:52'),
(930,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:49:20'),
(931,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:06'),
(932,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:11'),
(933,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 17:52:39'),
(934,0,'anonymous','login','user',10008,'用户 promo_pts 登录','::ffff:127.0.0.1','2026-07-17 18:01:17'),
(935,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:02:02'),
(936,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-17 18:03:23'),
(937,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:03:37'),
(938,0,'anonymous','login','user',10009,'用户 promo_pts2 登录','::ffff:127.0.0.1','2026-07-17 18:03:44'),
(939,0,'anonymous','login','user',10010,'用户 promo_dbg 登录','::ffff:127.0.0.1','2026-07-17 18:05:00'),
(940,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:39:28'),
(941,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:39:50'),
(942,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:42:55'),
(943,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:47:26'),
(944,0,'anonymous','login','user',10011,'用户 promo_dual 登录','::ffff:127.0.0.1','2026-07-17 18:47:59'),
(945,19,'alexmorgan','update','membership',2,'更新会员等级\"黄金会员\"','223.160.214.97','2026-07-17 19:22:54'),
(946,0,'anonymous','update','commission_rule',3,'更新返佣规则\"默认返佣(全局)\"','223.160.214.97','2026-07-17 19:24:41'),
(947,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url','223.160.214.97','2026-07-17 20:04:43'),
(948,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content','223.160.214.97','2026-07-17 20:13:04'),
(949,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.45','2026-07-17 20:30:46'),
(950,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 20:40:44'),
(951,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:47:28'),
(952,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:47:37'),
(953,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:47:51'),
(954,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:48:52'),
(955,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:49:04'),
(956,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-17 21:49:44'),
(957,0,'anonymous','login','user',10001,'用户 35735712 登录','223.160.208.221','2026-07-17 21:55:27'),
(958,19,'alexmorgan','pin','post',24,'版块置顶帖子《【会员专属】黄金会员专属福利 - 设计素材大礼包》','','2026-07-17 23:04:09'),
(959,19,'alexmorgan','pin','post',28,'版块置顶帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-17 23:04:25'),
(960,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.221','2026-07-17 23:05:28'),
(961,19,'alexmorgan','pin','post',33,'版块置顶帖子《定时》','','2026-07-18 00:28:35'),
(962,19,'alexmorgan','pin','post',33,'全站置顶帖子《定时》','','2026-07-18 00:28:49'),
(963,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.76','2026-07-18 01:21:46'),
(964,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.76','2026-07-18 02:08:49'),
(965,19,'system','update','membership',2,'更新会员等级\"黄金会员\"','117.136.111.76','2026-07-18 02:36:17'),
(966,19,'system','update','membership',4,'更新会员等级\"至尊会员\"','117.136.111.76','2026-07-18 02:36:24'),
(967,19,'system','update','membership',2,'更新会员等级\"黄金会员\"','117.136.111.76','2026-07-18 02:38:49'),
(968,19,'system','update','membership',2,'更新会员等级\"黄金会员\"','117.136.111.76','2026-07-18 02:58:00'),
(969,19,'system','update','membership',3,'更新会员等级\"钻石会员\"','117.136.111.76','2026-07-18 02:58:05'),
(970,19,'system','update','membership',4,'更新会员等级\"至尊会员\"','117.136.111.76','2026-07-18 02:58:10'),
(971,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-18 03:20:30'),
(972,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.76','2026-07-18 03:22:45'),
(973,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-18 03:48:36'),
(974,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.103','2026-07-18 03:49:31'),
(975,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-18 03:51:53'),
(976,0,'anonymous','config','sys_config',0,'更新系统配置: ip_geo_provider, ip_geo_api_key, ip_geo_api_secret, ip_geo_enabled','223.160.208.103','2026-07-18 03:53:54'),
(977,19,'alexmorgan','unpin','post',28,'取消版块置顶帖子《【测试】称号解锁功能 - 设计达人专属内容》','','2026-07-18 04:13:20'),
(978,19,'alexmorgan','unpin','post',24,'取消版块置顶帖子《【会员专属】黄金会员专属福利 - 设计素材大礼包》','','2026-07-18 04:13:25'),
(979,19,'alexmorgan','unpin','post',33,'取消版块置顶帖子《定时》','','2026-07-18 04:13:29'),
(980,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.213.162','2026-07-18 09:56:53'),
(981,19,'alexmorgan','essence','post',24,'设为精华帖子《【会员专属】黄金会员专属福利 - 设计素材大礼包》','','2026-07-18 12:55:40'),
(982,19,'alexmorgan','approve','post',32,'审核通过帖子《99999》','','2026-07-18 14:05:38'),
(983,0,'tst__iumrr2xo8n','create','user',10013,'用户注册','','2026-07-19 00:50:50'),
(984,0,'tst__tst__iumrr2xo8n','create','user',10014,'用户注册','','2026-07-19 00:50:51'),
(985,0,'tst__iumrr2ybls','create','user',10015,'用户注册','','2026-07-19 00:51:21'),
(986,0,'anonymous','login','user',10015,'用户 tst__iumrr2ybls 登录','::ffff:127.0.0.1','2026-07-19 00:51:21'),
(987,0,'tst__dbgmrr2z5qq','create','user',10016,'用户注册','','2026-07-19 00:51:59'),
(988,0,'anonymous','login','user',10016,'用户 tst__dbgmrr2z5qq 登录','::ffff:127.0.0.1','2026-07-19 00:52:00'),
(989,0,'tst__dbgmrr2zdy7','create','user',10017,'用户注册','','2026-07-19 00:52:10'),
(990,0,'anonymous','login','user',10017,'用户 tst__dbgmrr2zdy7 登录','::ffff:127.0.0.1','2026-07-19 00:52:10'),
(991,0,'tst__iumrr3064n','create','user',10018,'用户注册','','2026-07-19 00:52:47'),
(992,0,'anonymous','login','user',10018,'用户 tst__iumrr3064n 登录','::ffff:127.0.0.1','2026-07-19 00:52:47'),
(993,0,'tst__iumrr3fd0n','create','user',10019,'用户注册','','2026-07-19 01:04:36'),
(994,0,'anonymous','login','user',10019,'用户 tst__iumrr3fd0n 登录','::ffff:127.0.0.1','2026-07-19 01:04:36'),
(995,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.104','2026-07-19 03:48:40'),
(996,0,'anonymous','config','sys_config',0,'更新系统配置: cookie_consent_enabled, cookie_consent_title, cookie_consent_content, cookie_consent_agree_text, cookie_consent_decline_text','223.160.208.104','2026-07-19 03:56:04'),
(997,0,'anonymous','config','sys_config',0,'更新系统配置: cookie_consent_enabled','::ffff:127.0.0.1','2026-07-19 03:57:40'),
(998,0,'anonymous','config','sys_config',0,'更新系统配置: cookie_consent_enabled','::ffff:127.0.0.1','2026-07-19 03:59:16'),
(999,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 04:02:48'),
(1000,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.104','2026-07-19 06:13:54'),
(1001,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.208.104','2026-07-19 06:14:20'),
(1002,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 14:00:21'),
(1003,1,'bobwang','create','app_collection',1,'创建应用合集\"开发者必备工具\"','::ffff:127.0.0.1','2026-07-19 14:00:28'),
(1004,1,'bobwang','create','app_collection',2,'创建应用合集\"影音娱乐精选\"','::ffff:127.0.0.1','2026-07-19 14:00:28'),
(1005,1,'bobwang','create','app_collection',3,'创建应用合集\"开学季必备\"','::ffff:127.0.0.1','2026-07-19 14:00:28'),
(1006,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:04:58'),
(1007,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:05:30'),
(1008,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:06:23'),
(1009,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:06:37'),
(1010,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:06:46'),
(1011,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:12:58'),
(1012,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:12:59'),
(1013,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:13:12'),
(1014,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:13:31'),
(1015,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:13:36'),
(1016,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:14:23'),
(1017,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:14:23'),
(1018,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:14:56'),
(1019,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:14:57'),
(1020,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:25:43'),
(1021,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:26:18'),
(1022,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:26:31'),
(1023,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:27:05'),
(1024,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:27:21'),
(1025,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:27:26'),
(1026,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:27:36'),
(1027,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-19 15:28:35'),
(1028,19,'alexmorgan','create','app_collection',4,'创建应用合集\"666\"','39.144.124.19','2026-07-19 15:31:05'),
(1029,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 03:29:43'),
(1030,0,'anonymous','login','user',19,'用户 alexmorgan 登录','112.17.241.171','2026-07-20 04:17:22'),
(1031,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 05:44:01'),
(1032,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 05:44:11'),
(1033,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 05:44:20'),
(1034,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 06:11:57'),
(1035,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 06:19:55'),
(1036,0,'anonymous','update','permissions',8,'更新等级8的1条权限','::ffff:127.0.0.1','2026-07-20 06:33:22'),
(1037,0,'anonymous','create','permissions',621,'等级20新增权限testKey','::ffff:127.0.0.1','2026-07-20 06:38:45'),
(1038,0,'anonymous','delete','permissions',621,'删除等级20的权限testKey','::ffff:127.0.0.1','2026-07-20 06:38:51'),
(1039,19,'alexmorgan','create','permissions',622,'等级1新增权限G2','223.160.213.228','2026-07-20 06:43:54'),
(1040,19,'alexmorgan','create','permissions',623,'等级1新增权限G1','223.160.213.228','2026-07-20 06:44:17'),
(1041,0,'anonymous','update','permissions',15,'更新等级15的2条权限','::ffff:127.0.0.1','2026-07-20 06:53:56'),
(1042,0,'anonymous','update','permissions',15,'更新等级15的2条权限','::ffff:127.0.0.1','2026-07-20 06:54:01'),
(1043,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:14:29'),
(1044,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:15:01'),
(1045,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:15:15'),
(1046,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:22:42'),
(1047,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:22:56'),
(1048,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:23:52'),
(1049,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:23:52'),
(1050,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:24:14'),
(1051,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:24:22'),
(1052,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:24:37'),
(1053,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:24:50'),
(1054,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 07:36:20'),
(1055,0,'anonymous','update','permissions',8,'更新等级8的2条权限','::ffff:127.0.0.1','2026-07-20 07:36:20'),
(1056,0,'anonymous','update','permissions',8,'更新等级8的2条权限','::ffff:127.0.0.1','2026-07-20 07:36:20'),
(1057,19,'alexmorgan','update','experience',1,'更新经验等级\"Lv.1\"','223.160.214.255','2026-07-20 07:55:01'),
(1058,19,'alexmorgan','update','permissions',1,'更新等级1的43条权限','223.160.214.255','2026-07-20 07:55:01'),
(1059,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 08:09:53'),
(1060,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 08:09:53'),
(1061,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 08:11:03'),
(1062,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.100','2026-07-20 15:53:59'),
(1063,0,'anonymous','create','custom_task',6,'新增惩罚规则\"帖子被驳回\"','::ffff:127.0.0.1','2026-07-20 16:52:06'),
(1064,0,'anonymous','penalty','manual',5,'手动扣除用户code_ninja经验30','::ffff:127.0.0.1','2026-07-20 16:52:11'),
(1065,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-20 20:36:57'),
(1066,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-20 20:39:31'),
(1067,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-20 20:46:03'),
(1068,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-20 20:47:49'),
(1069,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-20 20:47:49'),
(1070,0,'anonymous','login','user',10020,'用户 testuser 登录','::ffff:127.0.0.1','2026-07-20 20:48:18'),
(1071,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content','223.160.208.110','2026-07-20 21:20:39'),
(1072,0,'anonymous','config','sys_config',0,'更新系统配置: system_operator_id, chat_room_create_condition','::ffff:127.0.0.1','2026-07-20 21:24:53'),
(1073,0,'anonymous','login','user',10020,'用户 testuser 登录','::ffff:127.0.0.1','2026-07-20 21:24:58'),
(1074,0,'anonymous','login','user',10020,'用户 testuser 登录','::ffff:127.0.0.1','2026-07-20 21:25:02'),
(1075,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content, system_operator_id, chat_room_create_condition','223.160.208.110','2026-07-20 22:21:54'),
(1076,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content, system_operator_id, chat_room_create_condition','223.160.208.110','2026-07-20 23:38:14'),
(1077,0,'anonymous','config','sys_config',0,'更新系统配置: site_theme_mode, site_show_theme_switch, site_auto_refresh, site_name, site_subtitle, site_domain, site_admin_path, site_favicon, site_logo_pc, site_logo_mobile, site_copyright, site_icp, login_captcha_enabled, login_max_errors, login_lock_minutes, ip_blacklist, api_sign_enabled, api_rate_limit, register_enabled, register_verify_type, register_email_config_id, register_default_group, register_default_level, register_start_id, register_username_min, register_password_min, password_rule, sms_channel_enabled, site_maintenance_enabled, site_maintenance_msg, site_help_url, site_agreement_url, site_privacy_url, site_security_url, site_about_url, site_community_url, site_contact_url, site_community_content, site_contact_content, system_operator_id, chat_room_create_condition','223.160.208.110','2026-07-20 23:41:54'),
(1078,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:09:02'),
(1079,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:09:06'),
(1080,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:09:25'),
(1081,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:09:33'),
(1082,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:09:58'),
(1083,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:10:38'),
(1084,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:10:44'),
(1085,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:10:50'),
(1086,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:11:37'),
(1087,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:12:02'),
(1088,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:12:02'),
(1089,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:12:08'),
(1090,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:12:19'),
(1091,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:12:43'),
(1092,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:12:43'),
(1093,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:13:11'),
(1094,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:13:11'),
(1095,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:13:38'),
(1096,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:13:38'),
(1097,1,'bobwang','reject','post',51,'驳回帖子《Lisa待审帖B》，原因：测试驳回原因','','2026-07-21 00:13:38'),
(1098,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:14:02'),
(1099,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:14:02'),
(1100,1,'bobwang','approve','post',53,'审核通过帖子《Lisa单帖通过》','','2026-07-21 00:14:02'),
(1101,1,'bobwang','reject','post',54,'驳回帖子《Lisa单帖驳回》，原因：测试单帖驳回','','2026-07-21 00:14:02'),
(1102,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:14:19'),
(1103,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:14:19'),
(1104,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:14:32'),
(1105,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:14:46'),
(1106,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:14:46'),
(1107,1,'bobwang','approve','post',55,'审核通过帖子《管线测试帖-Tech》','','2026-07-21 00:14:46'),
(1108,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:15:02'),
(1109,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 00:15:02'),
(1110,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:22:23'),
(1111,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:22:23'),
(1112,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:22:39'),
(1113,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:25:29'),
(1114,0,'anonymous','login','user',3,'用户 tech_guru 登录','::ffff:127.0.0.1','2026-07-21 00:25:29'),
(1115,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:25:52'),
(1116,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:26:02'),
(1117,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:27:03'),
(1118,0,'anonymous','login','user',19,'用户 alexmorgan 登录','::ffff:127.0.0.1','2026-07-21 00:29:06'),
(1119,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:36:47'),
(1120,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:37:13'),
(1121,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:37:23'),
(1122,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:37:23'),
(1123,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:38:42'),
(1124,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:39:42'),
(1125,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:42:02'),
(1126,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:42:12'),
(1127,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:42:23'),
(1128,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:42:24'),
(1129,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:44:03'),
(1130,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:44:04'),
(1131,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 00:44:30'),
(1132,0,'anonymous','login','user',2,'用户 lisa_chen 短信验证码登录','::ffff:127.0.0.1','2026-07-21 01:13:11'),
(1133,0,'anonymous','login','user',19,'用户 alexmorgan 登录','117.136.111.25','2026-07-21 02:09:24'),
(1134,0,'anonymous','login','user',19,'用户 alexmorgan 邮箱验证码登录','117.136.111.25','2026-07-21 02:16:40'),
(1135,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.212.130','2026-07-21 02:40:41'),
(1136,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.212.130','2026-07-21 03:17:41'),
(1137,19,'alexmorgan','set_badge','post',28,'设置自定义徽章《【测试】称号解锁功能 - 设计达人专属内容》：不知道','','2026-07-21 03:37:42'),
(1138,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.46','2026-07-21 05:14:59'),
(1139,0,'anonymous','login','user',19,'用户 alexmorgan 登录','39.144.124.46','2026-07-21 05:21:35'),
(1140,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.32','2026-07-21 05:26:26'),
(1141,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.215.32','2026-07-21 05:26:41'),
(1142,0,'anonymous','login','user',19,'用户 alexmorgan 登录','223.160.209.213','2026-07-21 06:50:23'),
(1143,19,'alexmorgan','essence','post',26,'设为精华帖子《【登录可见】社区新人必读 - 发帖规范与积分规则详解》','','2026-07-21 06:51:02'),
(1144,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:56:20'),
(1145,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:56:29'),
(1146,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:56:35'),
(1147,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:58:22'),
(1148,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:59:53'),
(1149,10004,'admin','create','coupon',7,'创建优惠券:test_coupon','::ffff:127.0.0.1','2026-07-21 06:59:53'),
(1150,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 06:59:59'),
(1151,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:02:07'),
(1152,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:06:17'),
(1153,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:06:25'),
(1154,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:08:15'),
(1155,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:10:20'),
(1156,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:13:51'),
(1157,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:15:43'),
(1158,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:16:31'),
(1159,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 07:19:37'),
(1160,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:13:27'),
(1161,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:14:44'),
(1162,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:17:43'),
(1163,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:17:47'),
(1164,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:18:50'),
(1165,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:20:37'),
(1166,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:23:22'),
(1167,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:24:05'),
(1168,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:25:35'),
(1169,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:25:35'),
(1170,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:25:41'),
(1171,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:27:51'),
(1172,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:27:51'),
(1173,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:27:56'),
(1174,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:28:58'),
(1175,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:31:48'),
(1176,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:31:55'),
(1177,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:32:05'),
(1178,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:35:04'),
(1179,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:35:04'),
(1180,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:35:09'),
(1181,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:37:30'),
(1182,0,'anonymous','login','user',10004,'用户 admin 登录','::ffff:127.0.0.1','2026-07-21 15:37:30'),
(1183,0,'anonymous','login','user',10002,'用户 github_user_mrnwh1hi 登录','::ffff:127.0.0.1','2026-07-21 15:37:31'),
(1184,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 15:44:13'),
(1185,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 15:44:22'),
(1186,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 15:47:44'),
(1187,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 15:47:44'),
(1188,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 15:48:49'),
(1189,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 15:48:50'),
(1190,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 15:50:16'),
(1191,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 15:50:16'),
(1192,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 15:52:55'),
(1193,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 15:52:55'),
(1194,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:01:07'),
(1195,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:01:07'),
(1196,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:05:29'),
(1197,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:05:29'),
(1198,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:05:39'),
(1199,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:05:39'),
(1200,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:05:57'),
(1201,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:05:57'),
(1202,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:06:58'),
(1203,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:06:58'),
(1204,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:15:35'),
(1205,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:15:43'),
(1206,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:25:16'),
(1207,0,'invok_t2','create','user',10021,'用户注册','','2026-07-21 16:30:43'),
(1208,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:31:25'),
(1209,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:31:25'),
(1210,0,'admin','delete','menu',999,'删除菜单\"999\"。被删除数据:{}','::ffff:127.0.0.1','2026-07-21 16:31:25'),
(1211,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:32:57'),
(1212,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:32:57'),
(1213,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:34:44'),
(1214,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:34:44'),
(1215,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:39:49'),
(1216,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:39:54'),
(1217,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:40:14'),
(1218,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:40:20'),
(1219,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:40:26'),
(1220,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:40:30'),
(1221,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:47:29'),
(1222,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:48:11'),
(1223,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:48:18'),
(1224,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:48:18'),
(1225,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 16:50:22'),
(1226,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 16:50:22'),
(1227,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:01:44'),
(1228,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:05:43'),
(1229,0,'ok_reg01','create','user',10023,'用户注册','','2026-07-21 17:05:55'),
(1230,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:10:01'),
(1231,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:10:12'),
(1232,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:10:51'),
(1233,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:15:32'),
(1234,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:15:53'),
(1235,0,'anonymous','login','user',2,'用户 lisa_chen 登录','::ffff:127.0.0.1','2026-07-21 17:15:53'),
(1236,0,'anonymous','login','user',1,'用户 bobwang 登录','::ffff:127.0.0.1','2026-07-21 17:25:47');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_records`
--

DROP TABLE IF EXISTS `task_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `task_id` int(11) NOT NULL,
  `task_name` varchar(200) DEFAULT '',
  `progress` int(11) DEFAULT 0,
  `target_count` int(11) DEFAULT 1,
  `status` varchar(20) DEFAULT 'pending',
  `completed_at` datetime DEFAULT NULL,
  `period_key` varchar(20) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_records_user` (`user_id`),
  KEY `idx_task_records_period` (`period_key`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_records`
--

LOCK TABLES `task_records` WRITE;
/*!40000 ALTER TABLE `task_records` DISABLE KEYS */;
INSERT INTO `task_records` VALUES
(1,7,'',1,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(2,5,'',4,'',0,1,'pending',NULL,'','2026-07-06 22:39:54'),
(3,3,'',3,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(4,7,'',5,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(5,2,'',3,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(6,5,'',4,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(7,4,'',2,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(8,3,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(9,7,'',2,'',0,1,'pending',NULL,'','2026-07-01 22:39:54'),
(10,12,'',5,'',0,1,'pending',NULL,'','2026-06-30 22:39:54'),
(11,6,'',3,'',0,1,'pending',NULL,'','2026-06-28 22:39:54'),
(12,8,'',5,'',0,1,'pending',NULL,'','2026-07-09 22:39:54'),
(13,9,'',3,'',0,1,'pending',NULL,'','2026-06-29 22:39:54'),
(14,10,'',3,'',0,1,'pending',NULL,'','2026-07-05 22:39:54'),
(15,5,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(16,11,'',3,'',0,1,'pending',NULL,'','2026-07-10 22:39:54'),
(17,5,'',4,'',0,1,'pending',NULL,'','2026-07-04 22:39:54'),
(18,8,'',5,'',0,1,'pending',NULL,'','2026-07-08 22:39:54'),
(19,2,'',5,'',0,1,'pending',NULL,'','2026-06-27 22:39:54'),
(20,15,'',2,'',0,1,'pending',NULL,'','2026-07-07 22:39:54'),
(22,19,'',5,'完善资料',1,1,'completed','2026-07-13 04:31:51','2026-07-13','2026-07-12 20:31:51'),
(23,19,'alexmorgan',3,'评论互动',1,1,'completed','2026-07-13 05:51:42','2026-07-13','2026-07-12 21:51:42'),
(24,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-14 02:34:40','2026-07-14','2026-07-13 18:34:40'),
(25,19,'',5,'完善资料',1,1,'completed','2026-07-14 03:42:23','2026-07-14','2026-07-13 19:42:23'),
(26,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-15 12:17:41','2026-07-15','2026-07-15 04:17:41'),
(27,19,'Alex Morgan',3,'评论互动',1,1,'completed','2026-07-15 12:26:15','2026-07-15','2026-07-15 04:26:15'),
(28,10001,'user_10001',3,'评论互动',1,1,'completed','2026-07-16 08:17:34','2026-07-16','2026-07-16 00:17:34'),
(29,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-17 00:40:43','2026-07-17','2026-07-16 16:40:43'),
(30,10004,'管理员',3,'评论互动',1,1,'completed','2026-07-17 10:15:18','2026-07-17','2026-07-17 02:15:18'),
(31,19,'alexmorgan',1,'每日签到',1,1,'completed','2026-07-18 07:39:01','2026-07-18','2026-07-17 23:39:01'),
(32,19,'Alex Morgan',2,'发帖奖励',1,1,'completed','2026-07-18 07:59:49','2026-07-18','2026-07-17 23:59:49'),
(33,10017,'user_10017',2,'发帖奖励',1,1,'completed','2026-07-19 08:52:10','2026-07-19','2026-07-19 00:52:10'),
(34,10018,'user_10018',2,'发帖奖励',1,1,'completed','2026-07-19 00:52:47','2026-07-19','2026-07-19 00:52:47'),
(35,10019,'user_10019',2,'发帖奖励',1,1,'completed','2026-07-19 01:04:36','2026-07-19','2026-07-19 01:04:36'),
(36,1,'bob123',2,'发帖奖励',1,1,'completed','2026-07-20 15:15:01','2026-07-20','2026-07-20 07:15:01'),
(37,1,'bob123',2,'发帖奖励',1,1,'completed','2026-07-21 04:37:11','2026-07-21','2026-07-20 20:37:11'),
(38,2,'lisa123',2,'发帖奖励',1,1,'completed','2026-07-21 04:39:31','2026-07-21','2026-07-20 20:39:31'),
(39,10020,'测试用户',2,'发帖奖励',1,1,'completed','2026-07-21 04:48:18','2026-07-21','2026-07-20 20:48:18'),
(40,2,'',5,'完善资料',1,1,'completed','2026-07-21 08:12:43','2026-07-21','2026-07-21 00:12:43'),
(41,2,'Lisa管线昵称',3,'评论互动',1,1,'completed','2026-07-21 08:12:43','2026-07-21','2026-07-21 00:12:43'),
(42,3,'tech123',2,'发帖奖励',1,1,'completed','2026-07-21 08:14:32','2026-07-21','2026-07-21 00:14:32'),
(43,10004,'',5,'完善资料',1,1,'completed','2026-07-21 14:56:20','2026-07-21','2026-07-21 06:56:20'),
(44,1,'bob123',2,'发帖奖励',1,1,'completed','2026-07-22 00:15:35','2026-07-22','2026-07-21 16:15:35');
/*!40000 ALTER TABLE `task_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_follows`
--

DROP TABLE IF EXISTS `topic_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_id` (`topic_id`,`user_id`),
  KEY `idx_topic_follows_topic` (`topic_id`),
  KEY `idx_topic_follows_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_follows`
--

LOCK TABLES `topic_follows` WRITE;
/*!40000 ALTER TABLE `topic_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_addresses`
--

DROP TABLE IF EXISTS `user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `is_default` tinyint(4) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_addresses`
--

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;
INSERT INTO `user_addresses` VALUES
(2,1,'测试地址','13800000000','广东','深圳','南山','科技园',0,'2026-07-16 19:41:50'),
(3,19,'123','1347943258','66','77','88','8888',0,'2026-07-16 21:54:36'),
(4,3,'张三','13800138000','广东省','深圳市','南山区','科技园路1号',0,'2026-07-17 15:03:57'),
(5,19,'Alex Morgan','13800138000','广东省','深圳市','南山区','科技园路1号创新大厦1208',1,'2026-07-17 15:52:31');
/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_appeals`
--

DROP TABLE IF EXISTS `user_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_appeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `reason` text DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `create_time` datetime DEFAULT current_timestamp(),
  `review_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_appeals`
--

LOCK TABLES `user_appeals` WRITE;
/*!40000 ALTER TABLE `user_appeals` DISABLE KEYS */;
INSERT INTO `user_appeals` VALUES
(1,19,'alexmorgan','我冤枉的，请解封','2026-07-20 14:27:10','approved',0,'','2026-07-13 14:21:20','2026-07-13 14:21:24'),
(2,19,'alexmorgan','666','2026-07-20 14:27:10','rejected',0,'no','2026-07-13 16:21:15','2026-07-16 19:30:07'),
(4,10001,'35735712','test appeal','2027-07-14 23:17:00','approved',0,'','2026-07-14 15:30:56','2026-07-14 15:34:39'),
(5,1,'bobwang','[post#1] test bug fix',NULL,'approved',0,'test approval','2026-07-16 19:29:02','2026-07-16 19:29:02'),
(6,1,'bobwang','我的账号被误封了','2099-12-31 23:59:59','approved',19,'已核实，同意解封','2026-07-16 20:36:51','2026-07-16 20:41:17');
/*!40000 ALTER TABLE `user_appeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_avatar_frames`
--

DROP TABLE IF EXISTS `user_avatar_frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_avatar_frames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `frame_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `obtain_type` varchar(20) DEFAULT 'manual',
  `obtain_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`frame_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_avatar_frames`
--

LOCK TABLES `user_avatar_frames` WRITE;
/*!40000 ALTER TABLE `user_avatar_frames` DISABLE KEYS */;
INSERT INTO `user_avatar_frames` VALUES
(1,8,1,0,'manual','2026-07-10 22:39:54'),
(2,8,3,0,'manual','2026-07-10 22:39:54'),
(3,2,1,0,'manual','2026-07-10 22:39:54'),
(4,9,4,0,'manual','2026-07-10 22:39:54'),
(5,9,2,0,'manual','2026-07-10 22:39:54'),
(8,19,1,1,'membership','2026-07-12 00:11:10'),
(53,1,1,1,'manual','2026-07-17 13:04:14'),
(54,1,2,0,'manual','2026-07-17 13:04:14'),
(55,1,3,0,'manual','2026-07-17 13:04:14');
/*!40000 ALTER TABLE `user_avatar_frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocker_id` int(11) NOT NULL,
  `blocked_id` int(11) NOT NULL,
  `reason` text DEFAULT '',
  `status` varchar(20) DEFAULT 'active',
  `reviewed` tinyint(1) DEFAULT 0,
  `review_notes` text DEFAULT '',
  `reviewer_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `blocker_id` (`blocker_id`,`blocked_id`),
  KEY `idx_user_blocks_blocker` (`blocker_id`),
  KEY `idx_user_blocks_blocked` (`blocked_id`),
  KEY `idx_user_blocks_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
INSERT INTO `user_blocks` VALUES
(1,2,10,'','active',0,'',0,'2026-07-10 22:39:53'),
(2,3,11,'','active',0,'',0,'2026-07-10 22:39:53'),
(3,4,12,'','active',0,'',0,'2026-07-10 22:39:53'),
(4,5,13,'','active',0,'',0,'2026-07-10 22:39:53'),
(5,6,14,'','active',0,'',0,'2026-07-10 22:39:53'),
(6,19,12,'666','cancelled',0,'',0,'2026-07-11 11:46:43');
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_codes`
--

DROP TABLE IF EXISTS `user_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `label` varchar(100) DEFAULT '',
  `max_uses` int(11) DEFAULT 0,
  `used_count` int(11) DEFAULT 0,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `auto_generated` tinyint(1) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `reward_type` varchar(50) DEFAULT '',
  `reward_value` varchar(100) DEFAULT '',
  `reward_duration` int(11) DEFAULT 0,
  `reward_target_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_codes`
--

LOCK TABLES `user_codes` WRITE;
/*!40000 ALTER TABLE `user_codes` DISABLE KEYS */;
INSERT INTO `user_codes` VALUES
(1,4,'REF-965vi41','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(2,9,'REF-t0omukq','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(3,14,'REF-rnrw7sk','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(4,15,'REF-bjco7s0','默认推广码',0,0,0,0,1,'1','','',0,0,'2026-07-10 22:39:54'),
(8,3,'4DD7C002','默认推广码',0,0,1,0,1,'1','','',0,0,'2026-07-17 17:08:38'),
(9,3,'D7180E11','朋友圈活动',10,1,1,1,0,'1','','',0,0,'2026-07-17 17:08:38'),
(10,19,'DEA1DB95','默认推广码',0,1,3,1,1,'1','','',0,0,'2026-07-17 17:12:40'),
(11,19,'4B8CE830','123',1,0,3,0,0,'1','','',0,0,'2026-07-17 17:15:01'),
(12,3,'E537EE57','测试奖励码',5,0,0,0,0,'3','points,balance','100,5',0,0,'2026-07-17 17:20:01'),
(13,3,'EB571FEE','带定价测试',3,0,0,0,0,'3','points,balance','200,5',0,0,'2026-07-17 17:20:28'),
(14,3,'EDE71968','超限测试1',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(15,3,'758D27BC','超限测试2',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(16,3,'56F88295','超限测试3',10,0,0,0,0,'3','','',0,0,'2026-07-17 17:23:09'),
(17,19,'7F86DA39','',1,0,3,0,0,'3','membership','36500',36500,0,'2026-07-17 17:30:58');
/*!40000 ALTER TABLE `user_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coupons`
--

DROP TABLE IF EXISTS `user_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'unused',
  `coupon_data` text NOT NULL,
  `expire_time` datetime NOT NULL,
  `use_time` datetime DEFAULT NULL,
  `use_scene` varchar(50) DEFAULT '',
  `use_order_id` int(11) DEFAULT 0,
  `use_amount` decimal(10,2) DEFAULT 0.00,
  `remaining_value` decimal(10,2) DEFAULT NULL,
  `receive_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_coupons_user` (`user_id`),
  KEY `idx_user_coupons_status` (`status`),
  KEY `idx_user_coupons_coupon` (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coupons`
--

LOCK TABLES `user_coupons` WRITE;
/*!40000 ALTER TABLE `user_coupons` DISABLE KEYS */;
INSERT INTO `user_coupons` VALUES
(1,12,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(2,10,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(3,6,3,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(4,6,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(5,2,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(6,9,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(7,2,5,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(8,12,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(9,11,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(10,4,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(11,10,4,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(12,5,5,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(13,14,4,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(14,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(15,10,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(16,9,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(17,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(18,15,1,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(19,12,2,'used','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(20,7,2,'unused','{}','2026-08-09 22:39:53',NULL,'',0,0.00,NULL,'2026-07-10 22:39:53'),
(21,19,5,'used','{\"name\":\"限时体验券\",\"type\":\"percentage\",\"value\":8,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 19:49:32','2026-07-16 19:42:28','mall',0,0.80,NULL,'2026-07-11 11:49:32'),
(22,1,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:37:08',NULL,'',0,0.00,NULL,'2026-07-11 20:37:08'),
(23,4,3,'unused','{\"name\":\"VIP折扣券\",\"type\":\"percentage\",\"value\":15,\"minOrder\":0,\"maxDiscount\":0,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-10 20:38:36',NULL,'',0,0.00,NULL,'2026-07-11 20:38:36'),
(37,19,6,'used','{\"name\":\"黄金会员\",\"type\":\"percent\",\"value\":10,\"minOrder\":1,\"maxDiscount\":10,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2030-07-12 04:42:00','2026-07-16 19:42:21','mall',0,1.00,NULL,'2026-07-11 23:42:22'),
(38,19,1,'used','{\"name\":\"新人专享券\",\"type\":\"fixed\",\"value\":5,\"minOrder\":10,\"maxDiscount\":100,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-11 07:51:45','2026-07-12 08:11:10','membership_buy',0,5.00,NULL,'2026-07-11 23:51:45'),
(39,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 00:11:10',NULL,'',0,0.00,NULL,'2026-07-12 00:11:10'),
(40,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 10:37:22',NULL,'',0,0.00,NULL,'2026-07-12 10:37:22'),
(41,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-26 10:37:47',NULL,'',0,0.00,NULL,'2026-07-12 10:37:47'),
(42,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:38:02',NULL,'',0,0.00,NULL,'2026-07-17 19:38:02'),
(43,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:43:09',NULL,'',0,0.00,NULL,'2026-07-17 19:43:09'),
(44,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-07-31 19:43:15',NULL,'',0,0.00,NULL,'2026-07-17 19:43:15'),
(45,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-02 04:10:29',NULL,'',0,0.00,NULL,'2026-07-19 04:10:29'),
(46,19,0,'unused','{\"name\":\"月度续费券\",\"type\":\"percent\",\"value\":10,\"minOrder\":0,\"maxDiscount\":50,\"scope\":\"all\",\"targetIds\":\"\",\"category\":\"general\"}','2026-08-04 00:23:38',NULL,'',0,0.00,NULL,'2026-07-21 00:23:38');
/*!40000 ALTER TABLE `user_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data_exports`
--

DROP TABLE IF EXISTS `user_data_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data_exports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `file_path` varchar(500) DEFAULT '',
  `file_size` int(11) DEFAULT 0,
  `requested_at` datetime DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_data_exports_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data_exports`
--

LOCK TABLES `user_data_exports` WRITE;
/*!40000 ALTER TABLE `user_data_exports` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data_exports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_delete_requests`
--

DROP TABLE IF EXISTS `user_delete_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_delete_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT '',
  `admin_id` int(11) DEFAULT 0,
  `admin_note` varchar(500) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_delete_requests`
--

LOCK TABLES `user_delete_requests` WRITE;
/*!40000 ALTER TABLE `user_delete_requests` DISABLE KEYS */;
INSERT INTO `user_delete_requests` VALUES
(1,13,'',10004,'test','rejected','2026-07-09 22:39:54'),
(2,7,'',0,'隐私原因','approved','2026-07-02 22:39:54'),
(3,7,'',0,'账号太多','rejected','2026-07-10 22:39:54');
/*!40000 ALTER TABLE `user_delete_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) NOT NULL,
  `following_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `follower_id` (`follower_id`,`following_id`),
  KEY `idx_user_follows_follower` (`follower_id`),
  KEY `idx_user_follows_following` (`following_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES
(1,7,8,'2026-07-10 22:39:53'),
(2,12,2,'2026-07-10 22:39:53'),
(3,7,14,'2026-07-10 22:39:53'),
(4,4,15,'2026-07-10 22:39:53'),
(5,12,10,'2026-07-10 22:39:53'),
(6,8,9,'2026-07-10 22:39:53'),
(7,10,14,'2026-07-10 22:39:53'),
(8,10,6,'2026-07-10 22:39:53'),
(9,3,7,'2026-07-10 22:39:53'),
(10,2,14,'2026-07-10 22:39:53'),
(11,7,5,'2026-07-10 22:39:53'),
(12,11,8,'2026-07-10 22:39:53'),
(13,15,4,'2026-07-10 22:39:53'),
(14,16,6,'2026-07-10 22:39:53'),
(15,5,15,'2026-07-10 22:39:53'),
(16,5,7,'2026-07-10 22:39:53'),
(17,13,15,'2026-07-10 22:39:53'),
(18,2,11,'2026-07-10 22:39:53'),
(19,9,7,'2026-07-10 22:39:53'),
(20,6,13,'2026-07-10 22:39:53'),
(21,14,5,'2026-07-10 22:39:53'),
(22,3,14,'2026-07-10 22:39:53'),
(23,16,5,'2026-07-10 22:39:53'),
(24,2,3,'2026-07-10 22:39:53'),
(25,7,13,'2026-07-10 22:39:53'),
(26,19,7,'2026-07-11 11:39:21'),
(27,19,12,'2026-07-11 11:46:49'),
(31,10001,19,'2026-07-16 00:16:45'),
(34,10004,19,'2026-07-17 02:20:34'),
(35,19,14,'2026-07-18 01:40:00');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_gift_claims`
--

DROP TABLE IF EXISTS `user_gift_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_gift_claims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `gift_type` varchar(20) NOT NULL,
  `claim_date` date NOT NULL,
  `claim_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uix_user_level_type_date` (`user_id`,`level_id`,`gift_type`,`claim_date`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_gift_claims`
--

LOCK TABLES `user_gift_claims` WRITE;
/*!40000 ALTER TABLE `user_gift_claims` DISABLE KEYS */;
INSERT INTO `user_gift_claims` VALUES
(6,19,4,'birthday','2026-07-12','2026-07-12 23:26:00'),
(7,19,4,'daily','2026-07-12','2026-07-12 23:27:10'),
(8,19,4,'daily','2026-07-19','2026-07-19 04:10:15');
/*!40000 ALTER TABLE `user_gift_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_memberships`
--

DROP TABLE IF EXISTS `user_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `level_id` int(11) NOT NULL DEFAULT 0,
  `level_name` varchar(100) DEFAULT '',
  `expire_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_um_user` (`user_id`),
  KEY `idx_um_expire` (`expire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_memberships`
--

LOCK TABLES `user_memberships` WRITE;
/*!40000 ALTER TABLE `user_memberships` DISABLE KEYS */;
INSERT INTO `user_memberships` VALUES
(1,1,2,'黄金会员','2026-08-11 20:37:08','2026-07-12 10:45:54'),
(2,4,2,'黄金会员','2026-08-11 20:38:36','2026-07-12 10:45:54'),
(3,19,4,'至尊会员','2034-02-08 01:08:18','2026-07-12 10:45:54'),
(6,19,2,'黄金会员','2032-12-26 11:13:05','2026-07-12 11:13:05'),
(7,19,3,'钻石会员','2028-11-05 12:36:22','2026-07-12 20:36:22');
/*!40000 ALTER TABLE `user_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification_settings`
--

DROP TABLE IF EXISTS `user_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notification_settings` (
  `user_id` int(11) NOT NULL,
  `notification_type` varchar(50) NOT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  UNIQUE KEY `uk_user_type` (`user_id`,`notification_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification_settings`
--

LOCK TABLES `user_notification_settings` WRITE;
/*!40000 ALTER TABLE `user_notification_settings` DISABLE KEYS */;
INSERT INTO `user_notification_settings` VALUES
(1,'comment',1,'2026-07-16 19:29:20'),
(19,'comment',1,'2026-07-17 00:22:47'),
(19,'follow',1,'2026-07-17 00:22:47'),
(19,'like',1,'2026-07-17 00:22:47'),
(19,'mention',1,'2026-07-17 00:22:47'),
(19,'message',1,'2026-07-17 00:22:47'),
(19,'system',1,'2026-07-17 00:22:47');
/*!40000 ALTER TABLE `user_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_paid_collections`
--

DROP TABLE IF EXISTS `user_paid_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_paid_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `pay_type` varchar(20) DEFAULT 'balance',
  `pay_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`collection_id`),
  KEY `idx_user_paid_collections_collection` (`collection_id`),
  KEY `idx_user_paid_collections_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_paid_collections`
--

LOCK TABLES `user_paid_collections` WRITE;
/*!40000 ALTER TABLE `user_paid_collections` DISABLE KEYS */;
INSERT INTO `user_paid_collections` VALUES
(1,1,1,20.00,'balance','2026-07-16 01:12:14'),
(2,2,1,200.00,'points','2026-07-21 16:50:22');
/*!40000 ALTER TABLE `user_paid_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_policy_consents`
--

DROP TABLE IF EXISTS `user_policy_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_policy_consents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `policy_type` varchar(20) NOT NULL,
  `policy_version_id` int(11) NOT NULL,
  `policy_version` int(11) DEFAULT 1,
  `ip` varchar(45) DEFAULT '',
  `consented_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_policy_consents_user` (`user_id`),
  KEY `idx_user_policy_consents_user_type` (`user_id`,`policy_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_policy_consents`
--

LOCK TABLES `user_policy_consents` WRITE;
/*!40000 ALTER TABLE `user_policy_consents` DISABLE KEYS */;
INSERT INTO `user_policy_consents` VALUES
(1,1,'privacy',7,5,'::ffff:127.0.0.1','2026-07-21 15:50:16'),
(2,2,'privacy',7,5,'::ffff:127.0.0.1','2026-07-21 15:50:16');
/*!40000 ALTER TABLE `user_policy_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_risks`
--

DROP TABLE IF EXISTS `user_risks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_risks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `risk_type` varchar(30) NOT NULL,
  `risk_level` int(11) DEFAULT 1,
  `evidence` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`evidence`)),
  `status` varchar(20) DEFAULT 'active',
  `detected_at` datetime DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by` int(11) DEFAULT 0,
  `resolve_note` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_user_risks_user` (`user_id`),
  KEY `idx_user_risks_type_status` (`risk_type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_risks`
--

LOCK TABLES `user_risks` WRITE;
/*!40000 ALTER TABLE `user_risks` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_risks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_titles`
--

DROP TABLE IF EXISTS `user_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `grant_by` varchar(100) DEFAULT '',
  `grant_time` datetime DEFAULT current_timestamp(),
  `expire_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`title_id`),
  KEY `idx_user_titles_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_titles`
--

LOCK TABLES `user_titles` WRITE;
/*!40000 ALTER TABLE `user_titles` DISABLE KEYS */;
INSERT INTO `user_titles` VALUES
(1,13,3,1,'','2026-07-10 22:39:54',NULL),
(2,7,3,1,'','2026-07-10 22:39:54',NULL),
(3,3,4,1,'','2026-07-10 22:39:54',NULL),
(4,12,1,1,'','2026-07-10 22:39:54',NULL),
(5,6,4,1,'','2026-07-10 22:39:54',NULL),
(6,15,2,1,'','2026-07-10 22:39:54',NULL),
(7,13,4,1,'','2026-07-10 22:39:54',NULL),
(8,7,1,1,'','2026-07-10 22:39:54',NULL),
(11,19,1,1,'membership','2026-07-12 00:11:10',NULL),
(56,19,11,1,'管理员','2026-07-13 22:17:04',NULL),
(57,19,10,1,'管理员','2026-07-13 23:15:06',NULL),
(58,19,9,1,'管理员','2026-07-13 23:15:11',NULL),
(64,3,19,1,'auto','2026-07-16 22:45:04',NULL),
(65,4,19,1,'auto','2026-07-16 22:45:04',NULL),
(66,19,19,1,'auto','2026-07-16 22:45:04',NULL),
(67,19,21,1,'auto','2026-07-16 22:45:04',NULL),
(68,10004,21,1,'auto','2026-07-17 02:13:00',NULL),
(69,1,1,1,'admin','2026-07-17 05:39:33',NULL),
(70,1,4,1,'admin','2026-07-17 05:39:33',NULL),
(71,1,7,1,'admin','2026-07-17 05:39:33',NULL),
(72,1,10,1,'admin','2026-07-17 05:39:33',NULL),
(73,1,12,1,'admin','2026-07-17 05:39:33',NULL),
(74,1,20,1,'auto','2026-07-17 13:51:17',NULL),
(75,1,21,1,'auto','2026-07-17 13:51:17',NULL),
(76,1,22,1,'auto','2026-07-17 13:51:17',NULL),
(77,1,23,1,'auto','2026-07-17 13:51:17',NULL),
(78,19,16,1,'auto','2026-07-17 17:39:00',NULL);
/*!40000 ALTER TABLE `user_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_violation_counts`
--

DROP TABLE IF EXISTS `user_violation_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_violation_counts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `count` int(11) DEFAULT 0,
  `last_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_task` (`user_id`,`task_id`),
  KEY `idx_user_violation_counts_user` (`user_id`),
  KEY `idx_user_violation_counts_task` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_violation_counts`
--

LOCK TABLES `user_violation_counts` WRITE;
/*!40000 ALTER TABLE `user_violation_counts` DISABLE KEYS */;
INSERT INTO `user_violation_counts` VALUES
(1,2,6,3,'2026-07-21 00:14:02'),
(2,2,7,5,'2026-07-20 17:48:36'),
(3,2,11,1,'2026-07-20 17:27:38'),
(4,2,12,1,'2026-07-20 17:27:38'),
(5,2,13,1,'2026-07-20 17:27:38'),
(6,2,9,1,'2026-07-20 17:27:38'),
(7,2,14,1,'2026-07-20 17:27:38'),
(8,2,15,1,'2026-07-20 17:27:38'),
(9,2,8,1,'2026-07-20 17:27:38'),
(10,2,16,1,'2026-07-20 17:27:38'),
(11,2,10,1,'2026-07-20 17:27:38'),
(12,2,17,1,'2026-07-20 17:27:38'),
(13,2,18,1,'2026-07-20 17:27:39'),
(14,2,19,1,'2026-07-20 17:27:39'),
(15,2,20,1,'2026-07-20 17:27:39'),
(16,2,21,1,'2026-07-20 17:27:39'),
(17,2,22,1,'2026-07-20 17:27:39'),
(18,2,23,1,'2026-07-20 17:27:39'),
(19,2,24,1,'2026-07-20 17:27:39'),
(20,2,25,1,'2026-07-20 17:27:39'),
(21,2,26,1,'2026-07-20 17:27:39'),
(22,2,27,1,'2026-07-20 17:27:39');
/*!40000 ALTER TABLE `user_violation_counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL DEFAULT '123456',
  `password_hash` varchar(200) DEFAULT '',
  `password_updated_at` bigint(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `nickname` varchar(100) DEFAULT '',
  `bio` text DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `experience` int(11) DEFAULT 0,
  `gender` varchar(10) DEFAULT '男',
  `avatar` varchar(500) DEFAULT '',
  `bg_url` varchar(500) DEFAULT '',
  `signature` varchar(300) DEFAULT '',
  `qq` varchar(20) DEFAULT '',
  `show_coin` int(11) DEFAULT 1,
  `follow_count` int(11) DEFAULT 0,
  `fans_count` int(11) DEFAULT 0,
  `status` varchar(2) DEFAULT '1',
  `points` int(11) DEFAULT 0,
  `level_id` int(11) DEFAULT 0,
  `level_name` varchar(100) DEFAULT '普通会员',
  `expire_time` datetime DEFAULT NULL,
  `ban_until` datetime DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_org` varchar(200) DEFAULT '',
  `active_title_id` int(11) DEFAULT 0,
  `active_title_name` varchar(100) DEFAULT '',
  `active_title_id2` int(11) DEFAULT 0,
  `active_title_name2` varchar(100) DEFAULT '',
  `active_title_id3` int(11) DEFAULT 0,
  `active_title_name3` varchar(100) DEFAULT '',
  `last_checkin_date` date DEFAULT NULL,
  `consecutive_checkins` int(11) DEFAULT 0,
  `referrer_id` int(11) DEFAULT 0,
  `referrer_code` varchar(32) DEFAULT '',
  `age` int(11) DEFAULT 0,
  `birthday` date DEFAULT NULL,
  `hide_birthday` tinyint(1) DEFAULT 0,
  `hide_qq` tinyint(1) DEFAULT 0,
  `hide_email` tinyint(1) DEFAULT 0,
  `hide_address` tinyint(1) DEFAULT 0,
  `register_address` varchar(200) DEFAULT '',
  `deleted_at` datetime DEFAULT NULL,
  `roles` text DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  `active_frame_id` int(11) DEFAULT 0,
  `active_frame_url` varchar(500) DEFAULT '',
  `used_bytes` bigint(20) DEFAULT 0,
  `bonus_data_limit_mb` int(11) DEFAULT 0,
  `bonus_file_limit_mb` int(11) DEFAULT 0,
  `referrer_id_2` int(11) DEFAULT 0,
  `twofa_secret` varchar(100) DEFAULT NULL,
  `twofa_enabled` tinyint(4) DEFAULT 0,
  `two_factor_enabled` tinyint(4) DEFAULT 0,
  `two_factor_secret` varchar(64) DEFAULT NULL,
  `reg_ip` varchar(45) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10024 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'bobwang','bob123','$2b$10$R31egYAJ3x6Kuj8SBD8gGemHQ3Jq6.xKMNb.rxGaM6o7/Vfj9mThu',1784648650783,'13800138001','bob@test.com','bob123',NULL,645.00,3300,'1','','','','',1,0,0,'1',914,2,'黄金会员','2026-08-11 20:37:08',NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,'1998-03-15',0,0,0,0,'',NULL,'[\"R_ADMIN\",\"R_SUPER\",\"R_MODERATOR\",\"R_REVIEWER\",\"R_USER\"]','2026-06-09 22:39:49','2026-07-11 21:29:49',1,'',13312,10,10,0,NULL,0,0,NULL,''),
(2,'lisa_chen','admin123','$2b$10$Yv6FofXiNWKNlXTO9x.KfegjZwZj3WbHxpEwiGUndoL5sy4Z31OwO',1784652491045,'13800138002','lisa@test.com','Lisa管线昵称',NULL,500.00,1000,'0','','','管线测试签名','',1,0,0,'1',900,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-09 22:39:49','2026-07-21 00:12:43',0,'',4096,0,0,0,NULL,0,0,NULL,''),
(3,'tech_guru','123456','$2b$10$Pwqe0YzDpjkHifXelvKZe./7iPqyG9r7P0.Jok4ndbgjkjZwSVhGi',NULL,'13800138003','tech@test.com','tech123',NULL,406.50,500,'1','','','','',1,0,0,'1',5020,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-05 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(4,'design_master','123456','$2b$10$8r/5zSf2iGxjGVCZNA8N4.6jerTYYcrIggzbgTkXGn7zyuanlN9rm',NULL,'13800138004','dm@test.com','dm123',NULL,3.00,700,'0','','','','',1,0,0,'1',350,2,'黄金会员','2026-08-11 20:38:36',NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-18 22:39:49','2026-07-10 22:39:49',0,'',0,10,10,0,NULL,0,0,NULL,''),
(5,'code_ninja','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138005','code@test.com','cn123',NULL,150.00,4470,'1','','','','',1,0,0,'1',2200,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-03 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(6,'pixel_art','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138006','pixel@test.com','pa123',NULL,30.00,900,'0','','','','',1,0,0,'1',450,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-26 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(7,'ui_lover','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138007','ui@test.com','ui123',NULL,500.00,12000,'0','','','','',1,0,1,'1',12000,4,'至尊会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(8,'frontend_dev','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138008','fd@test.com','fd123',NULL,180.00,6000,'1','','','','',1,0,0,'1',6000,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-12 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(9,'backend_guru','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138009','bg@test.com','bg123',NULL,95.00,3500,'1','','','','',1,0,0,'1',3500,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10,'data_wizard','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138010','dw@test.com','dw123',NULL,42.00,780,'1','','','','',1,0,0,'1',780,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(11,'mobile_dev','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138011','md@test.com','md123',NULL,5.00,200,'1','','','','',1,0,0,'1',200,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-27 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(12,'cloud_arch','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138012','ca@test.com','ca123',NULL,350.00,9500,'1','','','','',1,0,1,'1',9500,3,'钻石会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-07 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(13,'ai_explorer','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138013','ai@test.com','ai123',NULL,120.00,3000,'0','','','','',1,0,2,'1',3000,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-05-16 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(14,'game_dev','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138014','gd@test.com','gd123',NULL,66.00,1800,'1','','','','',1,0,1,'1',1800,1,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-22 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(15,'security_pro','','$2b$10$aFA/Waln/adFPLLhhPjbbOGMjYf3WFy6oYqr29gI2mWTLScsizKga',NULL,'13800138015','sp@test.com','sp123',NULL,155.00,4200,'1','','','','',1,0,0,'1',4200,2,'黄金会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-07-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(16,'deleted1','x','x',NULL,'','','Deleted1',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-10 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(17,'deleted2','x','x',NULL,'','','Deleted2',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-20 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(18,'deleted3','x','x',NULL,'','','Deleted3',NULL,0.00,0,'男','','','','',1,0,0,'4',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_USER\"]','2026-06-30 22:39:49','2026-07-10 22:39:49',0,'',0,0,0,0,NULL,0,0,NULL,''),
(19,'alexmorgan','123456','$2b$10$.RF5QlwtIqe4No0Vf3QFsuZFN.dLr9mh5zxjv8ene9pMD/a4oDtvS',1784594701897,'18670001591','844991059@qq.com','Alex Morgan','',20197.29,49504,'男','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/avatar/aw_1783978337263.jpg','http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/background/bg.png','','',1,5,5,'1',63910,4,'至尊会员','2034-02-08 01:08:18',NULL,1,'',10,'蓝V官方认证',11,'官方认证',9,'钻石王者','2026-07-17',1,3,'D7180E11',0,NULL,1,1,1,1,'',NULL,'[\"R_SUPER\"]','2026-07-10 22:44:56','2026-07-17 16:30:04',1,'',43364564,590,430160,0,'FFQUOQBEMRBGCJTQGBSTG3DUKJFXE3BY',0,0,NULL,''),
(10001,'35735712','123456','$2b$10$owIwm3i7VF8hBU462BbVu..NTBUNb1EhfarBwJcIE42QrTLVOkmPu',NULL,'','844991059@qq.com','','测试',1964.12,5000,'男','','','','',1,2,0,'3',9905,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[]','2026-07-12 19:18:20','2026-07-16 00:16:12',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10002,'github_user_mrnwh1hi','','$2b$10$n819KN8/XmQ/yYCkuROVVeOUcWl2.f9oo8ZRE/FZYjrYrnXZf6jni',1784647438003,'','','OAuth用户h1jp',NULL,0.00,0,'男','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-16 19:26:38','2026-07-16 19:26:38',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10004,'admin','123456','$2b$10$YyvMNoCKGaopknTd5WcCmOszzied3WveFIT7zPUQUIVLMg2Wf2ylG',NULL,'','','admin',NULL,0.00,0,'男','','','','',1,3,0,'1',25,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,0,'',0,NULL,0,0,0,0,'',NULL,'[\"R_SUPER\"]','2026-07-17 02:02:05','2026-07-21 06:56:35',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10009,'promo_pts2','','$2b$10$Acvt1W8Pdb59hFdKJcZOsOdejoLn/X.LZADZ48QtAKREObG1AwzsS',NULL,'','','',NULL,10000.00,0,'男','','','','',1,0,0,'1',5000,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:02:02','2026-07-17 18:02:02',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10010,'promo_dbg','','$2b$10$Acvt1W8Pdb59hFdKJcZOsOdejoLn/X.LZADZ48QtAKREObG1AwzsS',NULL,'','','',NULL,2060.98,0,'男','','','','',1,0,0,'1',0,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:05:00','2026-07-17 18:05:00',0,'',0,0,0,0,NULL,0,0,NULL,''),
(10011,'promo_dual','','$2b$10$Acvt1W8Pdb59hFdKJcZOsOdejoLn/X.LZADZ48QtAKREObG1AwzsS',NULL,'','','',NULL,5010.00,0,'男','','','','',1,0,0,'1',4020,0,'普通会员',NULL,NULL,0,'',0,'',0,'',0,'',NULL,0,19,'DEA1DB95',0,NULL,0,0,0,0,'',NULL,NULL,'2026-07-17 18:39:28','2026-07-17 18:39:28',0,'',0,0,0,0,NULL,0,0,NULL,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`artpro`@`localhost`*/ /*!50003 TRIGGER trg_users_pwd_updated
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
  IF NEW.password_hash IS NOT NULL
     AND (OLD.password_hash IS NULL OR NEW.password_hash != OLD.password_hash) THEN
    SET NEW.password_updated_at = ROUND(UNIX_TIMESTAMP(NOW(6)) * 1000);
  END IF;
END 
*/;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `verification_config`
--

DROP TABLE IF EXISTS `verification_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `condition_type` varchar(50) NOT NULL,
  `threshold` int(11) DEFAULT 0,
  `is_active` int(11) DEFAULT 0,
  `logic_type` varchar(20) DEFAULT 'any',
  `logic_count` int(11) DEFAULT 1,
  `create_time` datetime DEFAULT current_timestamp(),
  `update_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_config`
--

LOCK TABLES `verification_config` WRITE;
/*!40000 ALTER TABLE `verification_config` DISABLE KEYS */;
INSERT INTO `verification_config` VALUES
(4,'follower_count',100,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(5,'app_count',1,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(6,'app_developer',0,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37'),
(7,'post_count',1,1,'any',4,'2026-07-13 21:44:37','2026-07-13 21:44:37');
/*!40000 ALTER TABLE `verification_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_requests`
--

DROP TABLE IF EXISTS `verification_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `real_name` varchar(100) DEFAULT '',
  `id_card` varchar(50) DEFAULT '',
  `organization` varchar(200) DEFAULT '',
  `reason` text DEFAULT NULL,
  `proof_urls` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `review_comment` text DEFAULT NULL,
  `review_by` varchar(100) DEFAULT '',
  `review_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  `selected_condition` varchar(50) DEFAULT '',
  `selected_app_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_verification_requests_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_requests`
--

LOCK TABLES `verification_requests` WRITE;
/*!40000 ALTER TABLE `verification_requests` DISABLE KEYS */;
INSERT INTO `verification_requests` VALUES
(1,2,'','用户1','440137500550','科技有限公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-07-06 22:39:54','',0),
(2,3,'','用户2','440126591708','网络科技公司','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-09 22:39:54','',0),
(3,4,'','用户3','440134963635','设计工作室','申请蓝V认证',NULL,'approved',NULL,'',NULL,'2026-07-05 22:39:54','',0),
(4,5,'','用户4','440147897279','科技有限公司','申请蓝V认证',NULL,'rejected',NULL,'',NULL,'2026-07-08 22:39:54','',0),
(5,6,'','用户5','440183856527','网络科技公司','申请蓝V认证',NULL,'pending',NULL,'',NULL,'2026-06-21 22:39:54','',0),
(6,19,'alexmorgan','1','','','开发者','[]','approved','','','2026-07-13 21:47:29','2026-07-13 21:47:11','post_count',0);
/*!40000 ALTER TABLE `verification_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_records`
--

DROP TABLE IF EXISTS `withdraw_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT '',
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(30) DEFAULT 'alipay',
  `account` varchar(200) DEFAULT '',
  `real_name` varchar(50) DEFAULT '',
  `status` varchar(20) DEFAULT 'pending',
  `remark` text DEFAULT '',
  `reviewed_by` int(11) DEFAULT 0,
  `reviewed_by_name` varchar(100) DEFAULT '',
  `reviewed_at` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_withdraw_records_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_records`
--

LOCK TABLES `withdraw_records` WRITE;
/*!40000 ALTER TABLE `withdraw_records` DISABLE KEYS */;
INSERT INTO `withdraw_records` VALUES
(1,5,'user5',12.64,'alipay','','','completed','',19,'alexmorgan','2026-07-13 14:24:49','2026-07-10 22:39:54'),
(2,5,'user5',96.40,'wechat','','','completed','',0,'',NULL,'2026-06-26 22:39:54'),
(3,4,'user4',90.32,'alipay','','','rejected','',0,'',NULL,'2026-06-30 22:39:54'),
(4,7,'user7',87.49,'wechat','','','rejected','',19,'alexmorgan','2026-07-12 23:39:30','2026-06-30 22:39:54'),
(5,8,'user8',15.46,'alipay','','','completed','',0,'',NULL,'2026-06-25 22:39:54'),
(6,9,'user9',32.49,'wechat','','','rejected','',0,'',NULL,'2026-06-28 22:39:54'),
(7,8,'user8',84.19,'alipay','','','rejected','666',19,'alexmorgan','2026-07-12 23:45:35','2026-07-07 22:39:54'),
(8,8,'user8',38.85,'wechat','','','completed','',0,'',NULL,'2026-06-23 22:39:54'),
(9,19,'alexmorgan',500.00,'alipay','123456','1','rejected','',19,'alexmorgan','2026-07-13 14:24:58','2026-07-12 23:39:43'),
(10,10001,'35735712',12.00,'alipay','122','','pending','',0,'',NULL,'2026-07-16 00:20:17');
/*!40000 ALTER TABLE `withdraw_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'art_design_pro'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-21 18:44:21
