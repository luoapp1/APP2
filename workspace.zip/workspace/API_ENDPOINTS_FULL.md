# 完整 API 端点定义

## 模块: system.cjs (systemRoutes)
**文件**: `server/routes/system.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/auth/login` | 无 | **Body**: `userName`/`username`, `password` | `{code, msg, data: {token, refreshToken}}` 2FA时返回 `{need2FA:true, tempToken}` |
| POST | `/api/auth/login/2fa` | 无 | **Body**: `tempToken`, `code` (6位数字) | `{code, msg, data: {token, refreshToken}}` |
| GET | `/api/auth/oauth/providers` | 无 | 无 | `{code, data: [provider_name, ...]}` |
| POST | `/api/auth/oauth/login` | 无 | **Body**: `provider`, `code`, `redirectUri` | `{code, msg}` (开发中返回501) |
| POST | `/api/auth/oauth/bind` | `authRequired` | **Body**: `provider`, `code` | `{code, msg}` (开发中返回501) |
| GET | `/api/user/oauth-accounts` | `authRequired` | 无 | `{code, data: [{id, provider, provider_user_id, create_time}]}` |
| DELETE | `/api/user/oauth-accounts/:id` | `authRequired` | **Path**: `id` | `{code, msg: '解绑成功'}` |
| GET | `/api/admin/oauth-configs` | 无 | 无 | `{code, data: [{provider, enabled, clientId, redirectUri}]}` |
| POST | `/api/admin/oauth-configs` | 无 | **Body**: `configs` (Array of `{config_key, config_value, description}`) | `{code, msg: '保存成功'}` |
| GET | `/api/search` | 无 | **Query**: `q`, `type` (all/post/app/product), `page`, `pageSize` | `{code, data: {list, total}}` 跨模块搜索 |
| GET | `/api/user/info` | `authRequired` | 无 (从token获取) | `{code, data: {buttons, roles, userId, userName, email, avatar, phone, gender, nickname, bio, points, balance, experience, levelId, levelName, expireTime, discountRate, ...}}` |
| GET | `/api/role/list` | 无 | **Query**: `current`, `size` | `{code, data: {records: [{roleId, roleName, roleCode, description, enabled, createTime}], size, current, total}}` |
| POST | `/api/role/save` | 无 | **Body**: `roleId`(更新时), `roleName`, `roleCode`, `description`, `enabled` | `{code, msg, data: {roleId}}` |
| DELETE | `/api/role/:id` | 无 | **Path**: `id` | `{code, msg: '删除成功'}` |
| GET | `/api/role/:id/permissions` | 无 | **Path**: `roleId` | `{code, data: [{menuId, authMark}]}` R_SUPER返回所有 |
| POST | `/api/role/:id/permissions` | 无 | **Body**: `permissions` (Array of `{menuId, authMark}`) | `{code, msg: '保存成功'}` |
| GET | `/api/dashboard/stats` | 无 | 无 | `{code, data: {userCount, onlineCount, totalPoints, cardCount, todayNewCount}}` |
| GET | `/api/admin/console-stats` | 无 | 无 | `{code, data: {user, membership, cardKey, coupon, points, experience, plugin, appStore, community, mall, chat, social, ...}}` 综合统计 |
| GET | `/api/v3/system/menus/simple` | `optionalAuth`(session) | 无 | `{code, data: [{id, parentId, name, path, component, redirect, meta: {title, icon, isHide, ...}, children}]}` 树形菜单 |

---

## 模块: user.cjs (userRoutes)
**文件**: `server/routes/user.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/auth/register` | 无 | **Body**: `username`, `password`, `inviteCode`, `email`, `emailCode`, `phone`, `smsCode` | `{code, msg, data: {userId}}` |
| GET | `/api/user/membership-purchases/:userId` | `adminRequired` | **Path**: `userId` | `{code, data: [{id, levelId, levelName, amount, payType, purchaseType, durationDays, expireTime, createTime}]}` |
| GET | `/api/user/list` | `adminRequired` | **Query**: `current`, `size`, `userName`, `userPhone`, `userEmail`, `qq`, `status`, `sortField`, `sortOrder` | `{code, data: {records, current, size, total}}` 含roles、balance、postCount等 |
| POST | `/api/user/update` | `adminRequired` + `requirePermission('edit')` | **Body**: `id`(必填), `username`, `phone`, `gender`, `role`, `points`, `level_id`, `expireTime`, `password`, `nickname`, `bio`, `balance`, `email`, `experience`, `avatar`, `qq`, `signature`, `bg_url`, `register_address`, `age`, `birthday`, `ban_until`, `status`, `member_purchases`(数组) | `{code, msg: '更新成功'}` |
| POST | `/api/user/create` | `adminRequired` + `requirePermission('add')` | **Body**: `username`(必填), `phone`, `gender`, `role`, `points`, `level_id`, `expireTime`, `nickname`, `bio`, `balance`, `email`, `experience` | `{code, msg: '添加成功', data: {id}}` |
| DELETE | `/api/user/:id` | `adminRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg: '注销成功'}` 软删除(设置status=4) |
| GET | `/api/user/profile` | 无 | **Query**: `userId` | `{code, data: {id, username, nickname, avatar, bgUrl, signature, bio, gender, phone, qq, email, balance, points, experience, levelId, levelName, showCoin, followCount, fansCount, activeTitleId/Name/Id2/Name2/Id3/Name3, birthday, age, registerAddress, status, banUntil, hideBirthday/qq/email/address, createTime, roles}}` |
| PUT | `/api/user/profile` | 无 | **Body**: `userId`(必填), `nickname`, `bio`, `avatar`, `bgUrl`, `gender`, `signature`, `qq`, `phone`, `email`, `age`, `birthday`, `registerAddress`, `hideBirthday`, `hideQq`, `hideEmail`, `hideAddress` | `{code, msg: '更新成功'}` |
| POST | `/api/user/change-email` | 无 | **Body**: `userId`, `email`, `emailCode`, `password` (验证码校验) | `{code, msg}` |
| GET | `/api/user/comments` | 无 | **Query**: `userId`, `page`, `pageSize` | 用户的应用商店评论列表 |
| GET | `/api/user/community-comments` | 无 | **Query**: `userId`, `page`, `pageSize` | 用户的社区评论列表 |
| POST | `/api/auth/change-pwd` | 无 | **Body**: `userId`, `oldPassword`, `newPassword` | `{code, msg}` |
| GET | `/api/user/apps` | 无 | **Query**: `userId`, `page`, `pageSize`, `keyword`, `status` | 用户上传的应用列表 |
| POST | `/api/user/delete-request` | 无 | **Body**: `userId`, `reason` | `{code, msg}` 注销申请 |
| GET | `/api/user/delete-requests` | 无 | **Query**: `page`, `pageSize` | 注销申请列表 |
| POST | `/api/user/delete-request/:id/review` | 无 | **Path**: `id`, **Body**: `action`(approve/reject), `reason` | `{code, msg}` |
| POST | `/api/user/appeal` | 无 | **Body**: `userId`, `reason`, `type` | `{code, msg}` 申诉提交 |
| GET | `/api/user/appeals` | 无 | **Query**: `page`, `pageSize`, `status` | 申诉列表 |
| POST | `/api/user/appeal/:id/review` | 无 | **Path**: `id`, **Body**: `action`(approve/reject), `reply` | `{code, msg}` |
| GET | `/api/user/balance-records` | 无 | **Query**: `userId`, `page`, `pageSize` | 余额变动记录 |
| GET | `/api/user/experience-records` | 无 | **Query**: `userId`, `page`, `pageSize` | 经验变动记录 |
| GET | `/api/user/membership-records` | 无 | **Query**: `userId`, `page`, `pageSize` | 会员购买记录 |
| GET | `/api/user/2fa/status` | `authRequired` | 无 | `{code, data: {enabled}}` 2FA状态 |
| POST | `/api/user/2fa/setup` | `authRequired` | **Body**: `password` | `{code, data: {secret, qrcode}}` |
| POST | `/api/user/2fa/verify` | `authRequired` | **Body**: `code` (6位数字) | `{code, msg}` 验证并启用2FA |
| POST | `/api/user/2fa/disable` | `authRequired` | **Body**: `password`, `code` | `{code, msg}` |
| GET | `/api/user/dashboard/stats` | `authRequired` | 无 | 用户仪表盘统计(帖子数、评论数等) |
| GET | `/api/user/privacy-settings` | `authRequired` | 无 | 隐私设置 |
| PUT | `/api/user/privacy-settings` | `authRequired` | **Body**: 隐私设置字段 | `{code, msg}` |
| GET | `/api/user/:id` | 无 | **Path**: `id` | 用户信息公开信息 |
| GET | `/api/user/search` | 无 | **Query**: `keyword` | `{code, data: [{id, username, nickname, avatar}]}` |
| GET | `/api/user/by-username/:username` | 无 | **Path**: `username` | 按用户名查找用户 |

---

## 模块: appstore.cjs (appStoreRoutes)
**文件**: `server/routes/appstore.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/app/list` | `optionalAuth`(token) | **Query**: `keyword`, `category`, `status`, `page`, `pageSize` | `{code, data: {list, total, page, pageSize}}` 含拉黑过滤 |
| GET | `/api/app/hot-today` | 无 | **Query**: `limit`(默认5) | `{code, data: {list}}` 按今日点击量降序 |
| GET | `/api/app/trending-week` | 无 | **Query**: `limit`(默认9) | `{code, data: {list}}` 按本周点击量降序 |
| POST | `/api/app/save` | `authRequired` + `requirePermission('approve')` | **Body**: `id`(更新时), `name`, `packageName`, `version`, `versionCode`, `icon`, `iconBgColor`, `sizeMb`, `downloadUrl`, `downloads`, `rating`, `description`, `updateContent`, `screenshots`, `tags`, `officialTags`, `hasAds`, `requiresNetwork`, `hasPaidContent`, `isFree`, `price_type`, `price_amount`, `coinCount`, `coinPeople`, `developer`, `category`, `categoryId`, `categories`, `isPinned`, `status`, `userId`, `contentPermission`, `contentPrice`, `contentPriceType`, `accessPassword`, `accessPasswordTips` | `{code, msg, data: {id}}` 作者编辑后需重新审核 |
| DELETE | `/api/app/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg: '删除成功'}` 同时删除评论、版本、打赏 |
| GET | `/api/app/:id/detail` | 无 | **Path**: `id`, **Query**: `userId`(可选,查点赞状态) | `{code, data: {app, comments, versions, tips, ratingStats}}` 含评论回复树 |
| POST | `/api/app/:id/comment` | 无 | **Body**: `userId`, `userName`, `device`, `version`, `content`, `rating` | `{code, msg}` 30秒限流、每用户每应用仅评分一次 |
| POST | `/api/app/:id/comment/:cid/like` | 无 | **Body**: `userId` | `{code, msg, data: {liked}}` 点赞/取消 |
| DELETE | `/api/app/:id/comment/:cid` | 无 | **Query**: `userId` | `{code, msg}` 仅自己的评论可删 |
| POST | `/api/app/:id/comment/:cid/reply` | 无 | **Body**: `userId`, `userName`, `content` | `{code, msg}` |
| POST | `/api/app/:id/comment/:cid/pin` | 无 | **Body**: `userId` | `{code, msg, data: {pinned}}` 最多3条置顶 |
| GET | `/api/app/:id/versions` | 无 | **Path**: `id` | `{code, data: [{id, appId, version, versionCode, sizeMb, downloads, rating, updateContent, tags, ...}]}` |
| POST | `/api/app/version/save` | 无 | **Body**: `id`(更新时), `appId`, `version`, `versionCode`, `sizeMb`, `downloadUrl`, `updateContent`, `tags`, `officialTags`, `hasAds`, `requiresNetwork`, `hasPaidContent`, `isFree`, `isCurrent`, `userId`, `userName` | `{code, msg, data: {id}}` |
| DELETE | `/api/app/version/:id` | 无 | **Path**: `id` | `{code, msg}` |
| POST | `/api/app/upload` | 无 | multipart/form-data: `file` (APK) | `{code, msg, data: {url, name, size}}` |
| GET | `/api/app/uploads` | 无 | 无 | 上传记录列表 |
| GET | `/api/app/recommend` | 无 | 无 | `{code, data: {list}}` 推荐应用 |
| GET | `/api/category/list` | 无 | 无 | `{code, data: [{id, name, icon, sortOrder}]}` |
| POST | `/api/category/save` | `authRequired` + `requirePermission('add')` | **Body**: `id`(更新时), `name`, `icon`, `sortOrder`, `status` | `{code, msg, data: {id}}` |
| DELETE | `/api/category/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg}` |
| POST | `/api/app/:id/tip` | 无 | **Body**: `userId`, `userName`, `amount`, `tipType`, `message` | `{code, msg}` 打赏应用 |
| POST | `/api/app/:id/purchase` | 无 | **Body**: `userId`, `priceType` | 购买/支付应用 |
| GET | `/api/app/:id/purchase-status` | 无 | **Path**: `id`, **Query**: `userId` | 检查购买状态 |
| GET | `/api/app/:id/purchasers` | 无 | **Path**: `id` | 购买者列表 |
| GET | `/api/app/:id/tips` | 无 | **Path**: `id` | 打赏记录列表 |
| DELETE | `/api/app/comment/:id` | 无 | **Path**: `id` | 管理员删除评论 |
| GET | `/api/app/reports` | 无 | 举报列表 |
| POST | `/api/app/comment/:id/ignore` | 无 | **Path**: `id` | 忽略举报 |
| POST | `/api/app/:id/pin` | 无 | **Path**: `id`, **Body**: `isPinned` | 置顶应用 |
| POST | `/api/app/:id/official` | 无 | **Path**: `id`, **Body**: `isOfficial` | 设为官方 |
| POST | `/api/app/:id/featured` | 无 | **Path**: `id`, **Body**: `isFeatured` | 设为精选 |
| POST | `/api/app/:appId/comment/:cid/report` | 无 | **Body**: `userId`, `reason` | 举报应用评论 |
| GET | `/api/appstore/collections` | 无 | **Query**: `page`, `pageSize` | `{code, data: {list, total}}` 合集列表 |
| GET | `/api/appstore/collections/:id` | 无 | **Path**: `id` | 合集详情含应用列表 |
| POST | `/api/appstore/collections` | `authRequired` + `requirePermission('approve')` | **Body**: `name`, `description`, `cover`, `apps` 等 | `{code, msg, data: {id}}` |
| PUT | `/api/appstore/collections/:id` | `authRequired` + `requirePermission('approve')` | **Path**: `id` | 更新合集 |
| DELETE | `/api/appstore/collections/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | 删除合集 |
| POST | `/api/appstore/collections/:id/apps` | `authRequired` + `requirePermission('approve')` | **Body**: `appIds` 数组 | 向合集添加应用 |
| DELETE | `/api/appstore/collections/:id/apps/:appId` | `authRequired` + `requirePermission('delete')` | **Path**: `id`, `appId` | 从合集移除应用 |
| GET | `/api/app/:id/changelog` | 无 | **Path**: `id` | 更新日志 |
| GET | `/api/appstore/bundles` | 无 | 应用套包列表 |
| POST | `/api/appstore/bundles` | `authRequired` | **Body**: bundle数据 | 创建套包 |
| PUT | `/api/appstore/bundles/:id` | `authRequired` | **Path**: `id` | 更新套包 |
| DELETE | `/api/appstore/bundles/:id` | `authRequired` | **Path**: `id` | 删除套包 |
| POST | `/api/appstore/bundles/:id/apps` | `authRequired` | **Body**: `appIds` 数组 | 向套包添加应用 |
| DELETE | `/api/appstore/bundles/:id/apps/:appId` | `authRequired` | **Path**: `id`, `appId` | 从套包移除应用 |
| POST | `/api/app/:id/beta-users` | 无 | **Body**: `userId`, `email` 等 | 注册内测 |
| GET | `/api/app/:id/beta` | 无 | **Path**: `id` | 获取内测信息 |
| GET | `/api/app/:id/related` | 无 | **Path**: `id` | 关联应用推荐 |
| POST | `/api/appeal/submit` | `authRequired` | **Body**: 申诉信息 | 提交应用下架申诉 |
| GET | `/api/admin/appeals` | `authRequired` | 申诉列表 |
| PUT | `/api/admin/appeals/:id` | `authRequired` | **Path**: `id`, **Body**: `action` | 处理申诉 |
| POST | `/api/appstore/:id/favorite` | `authRequired` | **Path**: `id` | 收藏/取消应用 |
| GET | `/api/appstore/favorites` | `authRequired` | 我的收藏列表 |
| GET | `/api/app/:id/analytics` | 无 | **Path**: `id` | 应用数据统计 |
| GET | `/api/appstore/developer/analytics` | 无 | 开发者数据统计 |
| GET | `/api/appstore/:id/ratings` | 无 | **Path**: `id` | 应用评分详情 |
| GET | `/api/analytics/funnel` | 无 | 漏斗分析数据 |
| GET | `/api/appstore/dev/analytics/:id` | 无 | **Path**: `id` | 开发者单个应用分析 |

---

## 模块: mall.cjs (mallRoutes)
**文件**: `server/routes/mall.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/mall/categories/all` | 无 | 无 | `{code, data: [{id, parentId, name, icon, sortOrder, status}]}` 所有分类 |
| GET | `/api/mall/categories` | 无 | 无 | `{code, data: [...]}` 仅顶级分类(parent_id=0) |
| POST | `/api/mall/categories` | `authRequired` + `requirePermission('add')` | **Body**: `name`(必填), `parentId`, `icon`, `sortOrder` | `{code, msg, data: {id}}` |
| PUT | `/api/mall/categories/:id` | `authRequired` + `requirePermission('edit')` | **Path**: `id`, **Body**: `name`, `parentId`, `icon`, `sortOrder`, `status` | `{code, msg: '更新成功'}` |
| DELETE | `/api/mall/categories/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg}` 有子分类或商品则无法删除 |
| GET | `/api/mall/cart` | `authRequired` | 无 | `{code, data: [{id, userId, productId, optionId, quantity, productName, coverImage, price, ...}]}` |
| POST | `/api/mall/cart` | `authRequired` | **Body**: `productId`(必填), `optionId`, `quantity`(默认1) | `{code, msg}` |
| PUT | `/api/mall/cart/:id` | `authRequired` | **Path**: `id`, **Body**: `quantity`(必填,>=1) | `{code, msg: '已更新'}` |
| DELETE | `/api/mall/cart/:id` | `authRequired` | **Path**: `id` | `{code, msg: '已移除'}` |
| POST | `/api/mall/cart/clear` | `authRequired` | **Body**: `ids`(数组,可选,批量删除指定项; 为空则清空) | `{code, msg: '已清空'}` |
| POST | `/api/mall/cart/checkout` | `authRequired` | **Body**: `cartIds`(必填,数组), `addressId`, `remark`, `userCouponId` | `{code, msg, data: {orderIds, totalAmount, couponDiscount, orderId, deliveryItems}}` 创建订单+扣款+发货 |
| GET | `/api/mall/products` | 无 | **Query**: `categoryId`, `status`, `productType`, `priceType`, `isRecommended`, `admin`, `userId`, `minPrice`, `maxPrice`, `sortBy`(sales/price/newest/rating), `sortOrder`, `page`, `pageSize` | `{code, data: {list, total, page, pageSize}}` |
| GET | `/api/mall/products/:id` | 无 | **Path**: `id` | `{code, data: {product + options + images}}` |
| POST | `/api/mall/products` | `authRequired` + `requirePermission('add')` | **Body**: `categoryId`, `name`, `subtitle`, `description`, `coverImage`, `coverVideo`, `priceType`, `price`, `originalPrice`, `stock`, `productType`, `virtualContent`, `status`, `isRecommended`, `sortOrder`, `freight`, `services`, `purchaseLimitConfig`, `commissionConfig`, `customFields`, `afterSalesConfig`, `tags`, `productParams`, `paymentMethods`, `saleEndTime`, `options`(数组), `images`(数组) | `{code, msg, data: {id}}` |
| PUT | `/api/mall/products/:id` | `authRequired` + `requirePermission('edit')` | **Path**: `id`, **Body**: 同POST | `{code, msg: '更新成功'}` |
| DELETE | `/api/mall/products/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg: '删除成功'}` |
| POST | `/api/mall/orders` | `authRequired` | **Body**: 直接下单参数(productId, quantity, optionId, addressId等) | `{code, msg, data: {orderId}}` |
| POST | `/api/mall/orders/:id/pay` | `authRequired` | **Path**: `id`, **Body**: `paymentMethod`, `couponId` 等 | `{code, msg}` |
| GET | `/api/mall/orders` | 无 | **Query**: 管理筛选条件 | 所有订单(管理员) |
| GET | `/api/mall/orders/my` | 无 | **Query**: `userId`, `status`, `page`, `pageSize` | 我的订单 |
| GET | `/api/mall/orders/:id` | 无 | **Path**: `id` | 订单详情 |
| GET | `/api/mall/orders/:id/tracking` | 无 | **Path**: `id` | 物流追踪 |
| PUT | `/api/mall/orders/:id/status` | `authRequired` + `requirePermission('handle')` | **Path**: `id`, **Body**: `status`, `expressCompany`, `expressNo` 等 | `{code, msg}` |
| GET | `/api/mall/after-sales` | 无 | 售后列表 |
| PUT | `/api/mall/after-sales/:id` | `authRequired` + `requirePermission('handle')` | **Path**: `id`, **Body**: `status`, `reply` | 处理售后 |
| POST | `/api/mall/after-sales` | `authRequired` | **Body**: `orderId`, `reason`, `type`, `refundAmount`, `description`, `images` | `{code, msg}` |
| GET | `/api/mall/promotions` | 无 | 促销活动列表 |
| POST | `/api/mall/promotions` | `authRequired` + `requirePermission('add')` | **Body**: 促销活动数据 | `{code, msg, data: {id}}` |
| PUT | `/api/mall/promotions/:id` | `authRequired` + `requirePermission('edit')` | **Path**: `id` | 更新促销 |
| DELETE | `/api/mall/promotions/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | 删除促销 |
| GET | `/api/mall/reviews` | `optionalAuth` | **Query**: `productId`, `page`, `pageSize` | `{code, data: {list, total}}` 商品评价 |
| GET | `/api/mall/reviews/check` | `authRequired` | **Query**: `productId` | 检查购买后是否已评价 |
| POST | `/api/mall/reviews` | `authRequired` | **Body**: `productId`(必填), `orderId`, `rating`, `content`, `images` | `{code, msg, data: {id}}` |
| PUT | `/api/mall/reviews/:id` | `authRequired` | **Path**: `id`, **Body**: `content`, `rating` | `{code, msg: '更新成功'}` |
| PUT | `/api/mall/reviews/:id/like` | `authRequired` | **Path**: `id` | 评价点赞/取消 |
| PUT | `/api/mall/reviews/:id/reply` | 无 | **Path**: `id`, **Body**: `reply` | 商家回复评价 |
| GET | `/api/user/addresses` | `authRequired` | 无 | 我的地址列表 |
| POST | `/api/user/addresses` | `authRequired` | **Body**: `name`, `phone`, `province`, `city`, `district`, `detail`, `isDefault` | 添加地址 |
| PUT | `/api/user/addresses/:id` | `authRequired` | **Path**: `id` | 更新地址 |
| DELETE | `/api/user/addresses/:id` | `authRequired` | **Path**: `id` | 删除地址 |
| PUT | `/api/user/addresses/:id/default` | `authRequired` | **Path**: `id` | 设为默认地址 |
| POST | `/api/mall/favorites/:productId` | `authRequired` | **Path**: `productId` | 收藏/取消商品 |
| GET | `/api/mall/favorites` | `authRequired` | 收藏列表 |

---

## 模块: community-posts.cjs
**文件**: `server/routes/community/community-posts.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/community/posts` | `optionalAuth`(token) | **Query**: `sectionId`, `sort`(latest/recent_reply/most_likes/most_favorites/essence/hot/trending/views/pinned), `page`, `pageSize`, `keyword`, `tags`, `userId`, `viewerId`, `status`, `isHidden`, `followed`, `startDate`, `endDate` | `{code, data: {list, total, page, pageSize}}` 含拉黑过滤、付费内容过滤 |
| GET | `/api/community/post/:id` | `optionalAuth`(token) | **Path**: `id`, **Query**: `userId` | `{code, data: {post含评论回复树}}` 浏览量+1, 含付费内容block过滤 |
| POST | `/api/community/post` | `authRequired`(getUserId) | **Body**: `sectionId`, `title`, `content`, `device`, `tags`, `officialTags`, `images`, `hasResource`, `resourceType`, `resourceUrl`, `resourcePrice`, `resourcePriceType`, `extractCode`, `permission`, `scheduledTime`, `draftId`, `contentPermission`, `contentPrice`, `contentPriceType`, `accessPassword`, `accessPasswordTips`, `topicId`, `topicIds`, `coverImage`, `autoHideAt` | `{code, msg, data: {id}}` 检查板块发帖权限、审核模式、敏感词 |
| PUT | `/api/community/post/:id` | `authRequired`(getUserId) | **Path**: `id`, **Body**: 同POST(帖主可编辑) | `{code, msg}` 生成版本记录 |
| DELETE | `/api/community/post/:id` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg}` 软删除(作者) |
| POST | `/api/community/post/:id/restore` | `authRequired` | **Path**: `id` | `{code, msg}` 恢复已删除帖子 |
| DELETE | `/api/community/post/:id/permanent` | `authRequired` | **Path**: `id` | `{code, msg}` 永久删除(管理员) |
| GET | `/api/community/admin/posts/pending` | `authRequired`(getUserId) | 待审核帖子列表 |
| POST | `/api/community/admin/post/:id/approve` | `authRequired` | **Path**: `id` | `{code, msg}` 审核通过 |
| POST | `/api/community/admin/post/:id/reject` | `authRequired` | **Path**: `id`, **Body**: `reason` | `{code, msg}` 审核驳回 |
| GET | `/api/community/admin/posts` | `authRequired` | 管理员帖子管理列表 |
| PUT | `/api/community/admin/post/:id/status` | `authRequired` | **Path**: `id`, **Body**: `status` | 修改帖子状态 |
| GET | `/api/community/post/:id/revisions` | `authRequired` | **Path**: `id` | 帖子修改历史 |
| GET | `/api/community/post/:id/revisions/:revId` | `authRequired` | **Path**: `id`, `revId` | 历史版本详情 |
| POST | `/api/community/post/:id/revisions/:revId/restore` | `authRequired` | **Path**: `id`, `revId` | 恢复到历史版本 |

---

## 模块: community-admin.cjs
**文件**: `server/routes/community/community-admin.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/community/admin/ban` | `authRequired`(getUserId) | **Body**: `userId`, `reason`, `duration`(小时,可选) | `{code, msg: '用户已被禁言'}` |
| POST | `/api/community/admin/unban` | `authRequired`(getUserId) | **Body**: `userId` | `{code, msg: '已解除禁言'}` |
| GET | `/api/community/admin/banned` | `authRequired`(getUserId) | 无 | `{code, data: [{id, userId, userName, reason, bannedUntil, createTime}]}` |
| GET | `/api/community/user/search` | `authRequired`(getUserId) | **Query**: `keyword`(>=1字符) | `{code, data: [{id, username, nickname, avatar}]}` |
| GET | `/api/community/user/:userId/stats` | 无 | **Path**: `userId` | `{code, data: {postCount, commentCount, likeReceived, coinReceived, collectionCount, followerCount, followingCount, moderatorSections, trustLevel}}` |
| GET | `/api/community/user/:userId/recent-posts` | 无 | **Path**: `userId` | `{code, data: [{id, title, sectionId, createTime, likeCount, commentCount, viewCount}]}` 最近5篇 |
| GET | `/api/community/user/:userId/recent-comments` | 无 | **Path**: `userId` | `{code, data: [{id, content, postId, createTime, postTitle}]}` 最近5条 |
| POST | `/api/community/post/:id/report` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reportReason`, `reportDetail` | `{code, msg: '举报成功'}` 自动封禁检测 |
| POST | `/api/community/comment/:id/report` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reportReason`, `reportDetail` | `{code, msg: '举报成功'}` |
| GET | `/api/community/admin/reports` | `authRequired`(getUserId) | 无 | `{code, data: [enriched reports with target info]}` 管理员/版主看 |
| POST | `/api/community/admin/report/ignore/:id` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg: '已忽略'}` 标记不予处理 |
| POST | `/api/community/post/:id/request-unlock` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason` | `{code, msg}` 作者申请解锁 |
| GET | `/api/community/admin/unlock-requests` | `authRequired`(getUserId) | 无 | `{code, data: [{id, postId, userId, userName, reason, status, adminReply, postTitle}]}` |
| POST | `/api/community/admin/unlock-request/:id/handle` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `action`(approve/reject), `reply` | `{code, msg}` |
| DELETE | `/api/community/admin/report/post/:id` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg: '已下架'}` 下架被举报帖子 |
| DELETE | `/api/community/admin/report/comment/:id` | `authRequired`(getUserId+isAdmin) | **Path**: `id` | `{code, msg: '已删除'}` 删除被举报评论 |
| POST | `/api/community/report/:id/appeal` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason` | `{code, msg: '申诉已提交'}` 举报人申诉 |
| GET | `/api/community/moderator/appeals` | `authRequired`(getUserId+isAdmin) | 无 | `{code, data: [{id, reporterId, reporterName, targetType, reportReason, appealReason}]}` |
| POST | `/api/community/moderator/appeal/:id/handle` | `authRequired`(getUserId+isAdmin) | **Path**: `id`, **Body**: `action`(accept/reject) | `{code, msg}` |
| GET | `/api/community/tags` | 无 | **Query**: `keyword`, `sort`(post_count/name), `status`, `section_id`, `limit`(默认50) | `{code, data: [{id, name, normalizedName, postCount, sectionId, status, isOfficial, createTime}]}` |
| POST | `/api/community/tags` | `authRequired`(getUserId+isAdmin) | **Body**: `id`(更新时), `name`(必填), `status`, `isOfficial` | `{code, msg}` |
| DELETE | `/api/community/tags/:id` | `authRequired`(getUserId+isAdmin) | **Path**: `id` | `{code, msg: '已删除'}` |
| POST | `/api/community/tags/merge` | `authRequired`(getUserId+isAdmin) | **Body**: `sourceId`, `targetId` | `{code, msg}` 合并标签 |
| POST | `/api/community/tags/sync` | `authRequired`(getUserId+isAdmin) | **Body**: `sectionId` | `{code, msg}` 同步标签计数 |
| GET | `/api/community/tags/cloud` | 无 | 标签云 |
| GET | `/api/community/tags/hot` | 无 | 热门标签 |
| GET | `/api/community/sensitive-words` | 无 | 敏感词列表 |
| POST | `/api/community/sensitive-words` | `authRequired`(getUserId+isAdmin) | **Body**: `word`, `type` | `{code, msg}` |
| DELETE | `/api/community/sensitive-words/:id` | `authRequired`(getUserId+isAdmin) | **Path**: `id` | `{code, msg}` |
| GET | `/api/community/analytics/overview` | 无 | 社区概况统计 |
| GET | `/api/community/analytics/trends` | 无 | **Query**: `period`(week/month) | 趋势数据 |
| GET | `/api/community/analytics/sections` | 无 | 板块统计 |
| GET | `/api/community/analytics/collections` | 无 | 合集统计 |
| GET | `/api/community/analytics/user-ranking` | 无 | **Query**: `type`(posts/comments/likes/coins) | 用户排名 |
| GET | `/api/community/analytics/quality-scores` | 无 | 质量评分统计 |
| GET | `/api/community/notifications/unread-count` | `authRequired`(getUserId) | 无 | `{code, data: {count}}` |
| GET | `/api/community/admin/collections` | `authRequired`(getUserId) | 合集管理列表(管理员) |
| POST | `/api/community/admin/collection/:id/status` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `status` | 修改合集状态 |
| POST | `/api/community/admin/collection/:id/feature` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `isFeatured` | 精选合集 |
| GET | `/api/community/admin/collection-stats` | `authRequired`(getUserId) | 合集统计数据 |
| GET | `/api/community/admin/images` | `authRequired`(getUserId) | 社区图片管理 |
| POST | `/api/community/admin/images/batch-delete` | `authRequired`(getUserId) | **Body**: `ids` | 批量删除图片 |
| GET | `/api/community/admin/image-stats` | `authRequired`(getUserId) | 图片统计 |
| GET | `/api/community/admin/export/posts` | `authRequired`(getUserId) | 导出帖子 |
| GET | `/api/community/admin/export/reports` | `authRequired`(getUserId) | 导出举报 |
| GET | `/api/community/admin/export/users` | `authRequired`(getUserId) | 导出用户 |
| GET | `/api/community/rankings/essence` | 无 | 精华排行 |
| GET | `/api/community/rankings/donations` | 无 | 捐赠排行 |
| GET | `/api/community/rankings/sections-active` | 无 | 活跃板块排行 |
| GET | `/api/community/rankings/daily` | 无 | 每日排行 |
| POST | `/api/community/upload-image` | 无 | multipart: `file` (communityImageUpload) | `{code, data: {url}}` |
| POST | `/api/community/delete-image` | 无 | **Body**: `url` | `{code, msg}` |
| GET | `/api/community/user/:userId/trust-level` | 无 | **Path**: `userId` | `{code, data: {level, score}}` 信用等级 |
| GET | `/api/community/user/:userId/community-profile` | 无 | **Path**: `userId` | 用户社区档案(含徽章、等级、统计) |
| POST | `/api/community/admin/trust-levels/calculate` | `authRequired`(getUserId) | 重新计算所有用户信用等级 |
| GET | `/api/community/admin/auto-ban-settings` | `authRequired`(getUserId) | 自动封禁设置 |
| POST | `/api/community/admin/auto-ban-settings` | `authRequired`(getUserId) | **Body**: 设置数据 | 保存自动封禁设置 |

---

## 模块: community-moderator.cjs
**文件**: `server/routes/community/community-moderator.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/community/moderator/stats` | `authRequired`(getUserId) | 无 | `{code, data: {pendingPosts, pendingComments, todayActions}}` |
| GET | `/api/community/moderator/logs` | `authRequired`(getUserId) | **Query**: `page`, `pageSize` | `{code, data: [{id, sectionId, sectionName, moderatorId, moderatorName, action, targetType, targetId, detail, createTime}], total, page, pageSize}` |
| GET | `/api/community/moderator/my-sections` | `authRequired`(getUserId) | 无 | `{code, data: [{id, name, description, icon, iconBgColor, reviewRequired, sortOrder, role, modSortOrder, postCount, moderatorCount}]}` |
| POST | `/api/community/moderator/posts/batch-approve` | `authRequired`(getUserId) | **Body**: `ids`(数组) | `{code, msg, data: {approved}}` |
| POST | `/api/community/moderator/posts/batch-reject` | `authRequired`(getUserId) | **Body**: `ids`(数组), `reason` | `{code, msg, data: {rejected}}` |
| POST | `/api/community/moderator/posts/batch-delete` | `authRequired`(getUserId) | **Body**: `ids`(数组), `reason` | `{code, msg, data: {deleted}}` |
| POST | `/api/community/moderator/posts/batch-move` | `authRequired`(getUserId) | **Body**: `ids`(数组), `targetSectionId` | `{code, msg, data: {moved}}` |
| POST | `/api/community/moderator/posts/batch-essence` | `authRequired`(getUserId) | **Body**: `ids`(数组), `isEssence` | `{code, msg, data: {count}}` |
| POST | `/api/community/moderator/posts/batch-pin` | `authRequired`(getUserId) | **Body**: `ids`(数组), `isPinned` | `{code, msg, data: {count}}` |
| POST | `/api/community/moderator/posts/batch-lock` | `authRequired`(getUserId) | **Body**: `ids`(数组), `isLocked` | `{code, msg, data: {count}}` |
| POST | `/api/community/moderator/comments/batch-delete` | `authRequired`(getUserId) | **Body**: `ids`(数组), `reason` | `{code, msg, data: {deleted}}` |
| DELETE | `/api/community/moderator/comment/:id` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg: '删除成功'}` 单个删除评论 |
| POST | `/api/community/moderator/post/:id/move` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `targetSectionId` | `{code, msg: '移动成功'}` 移动帖子 |
| POST | `/api/community/moderator/post/:id/edit` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `title`, `content`, `tags`, `editSummary` | `{code, msg: '编辑成功'}` 版主编辑帖子 |
| POST | `/api/community/moderator/section/:sectionId/ban` | `authRequired`(getUserId) | **Path**: `sectionId`, **Body**: `userId`, `reason`, `duration`(小时) | `{code, msg: '封禁成功'}` 板块内封禁用户 |
| DELETE | `/api/community/moderator/section/:sectionId/ban/:bannedUserId` | `authRequired`(getUserId) | **Path**: `sectionId`, `bannedUserId` | `{code, msg: '已解除封禁'}` |
| GET | `/api/community/moderator/section/:sectionId/bans` | `authRequired`(getUserId) | **Path**: `sectionId` | 封禁列表 |
| POST | `/api/community/moderator/resign/:sectionId` | `authRequired`(getUserId) | **Path**: `sectionId` | `{code, msg}` 辞职版主 |
| GET | `/api/community/report-categories` | 无 | 无 | 举报分类列表 |
| GET | `/api/community/moderator/enhanced-stats` | `authRequired`(getUserId) | 增强版统计数据 |
| POST | `/api/community/moderator/collection/:id/remove` | `authRequired`(getUserId) | **Path**: `id` | 移除合集 |

---

## 模块: community-sections.cjs
**文件**: `server/routes/community/community-sections.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/community/sections` | 无 | 无 | `{code, data: [{id, name, description, icon, iconBgColor, postCount, isDeleted, ...}]}` 板块列表 |
| GET | `/api/community/section/:id/moderators` | 无 | **Path**: `id` | 板块版主列表 |
| POST | `/api/community/section/:id/moderator` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `userId`, `role` | 添加/更新版主 |
| DELETE | `/api/community/section/:id/moderator/:userId` | `authRequired`(getUserId) | **Path**: `id`, `userId` | 移除版主 |
| GET | `/api/community/user/:userId/moderator-sections` | 无 | **Path**: `userId` | 用户管理的板块 |
| POST | `/api/community/section/:id/apply` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason`, `experience` 等 | `{code, msg}` 申请版主 |
| GET | `/api/community/section/:id/applications` | `authRequired`(getUserId) | **Path**: `id` | 板块申请列表 |
| GET | `/api/community/applications` | `authRequired`(getUserId) | 所有申请列表 |
| POST | `/api/community/application/:id/approve` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `role` | 通过申请 |
| POST | `/api/community/application/:id/reject` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason` | 拒绝申请 |
| GET | `/api/community/section/:id/my-application` | `authRequired`(getUserId) | **Path**: `id` | 我的申请状态 |
| GET | `/api/community/section/:id` | 无 | **Path**: `id` | 板块详情 |
| POST | `/api/community/section` | `authRequired`(getUserId+isAdmin) | **Body**: `name`, `description`, `icon`, `iconBgColor`, `sortOrder`, `visibility`, `postPermission`, `reviewRequired` | 创建板块 |
| DELETE | `/api/community/section/:id` | `authRequired`(getUserId+isAdmin) | **Path**: `id` | 删除板块 |
| GET | `/api/community/section/:id/info` | 无 | **Path**: `id` | 板块基本信息 |
| POST | `/api/community/moderator/section/:id/update-info` | `authRequired`(getUserId) | **Path**: `id`, **Body**: 板块更新信息 | 版主更新板块信息 |

---

## 模块: community-interactions.cjs
**文件**: `server/routes/community/community-interactions.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/community/post/:id/like` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg, data: {liked}}` 点赞/取消帖子 |
| POST | `/api/community/comment/:id/like` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg, data: {liked}}` 点赞/取消评论 |
| POST | `/api/community/post/:id/favorite` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg, data: {favorited}}` 收藏/取消帖子 |
| GET | `/api/community/user/favorites` | `authRequired`(getUserId) | **Query**: `page`, `pageSize`, `type` | 我的收藏列表 |
| POST | `/api/community/post/:id/pin` | `authRequired`(getUserId+版主/管理员) | **Path**: `id`, **Body**: `isPinned` | `{code, msg}` 板块内置顶 |
| POST | `/api/community/post/:id/global-pin` | `authRequired`(getUserId+isAdmin) | **Path**: `id`, **Body**: `isGlobalPinned` | `{code, msg}` 全局置顶 |
| POST | `/api/community/post/:id/custom-badge` | `authRequired`(getUserId+isAdmin) | **Path**: `id`, **Body**: `customBadge` | 设定自定义徽章 |
| POST | `/api/community/post/:id/essence` | `authRequired`(getUserId+版主/管理员) | **Path**: `id`, **Body**: `isEssence` | `{code, msg}` 设精/取消 |
| POST | `/api/community/post/:id/hot` | `authRequired`(getUserId+版主/管理员) | **Path**: `id`, **Body**: `isHot` | `{code, msg}` 设为热门 |
| POST | `/api/community/post/:id/lock` | `authRequired`(getUserId+版主/管理员) | **Path**: `id`, **Body**: `isLocked` | `{code, msg}` 锁定/解锁 |
| POST | `/api/community/post/:id/coin` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `amount` | `{code, msg}` 投币打赏 |
| GET | `/api/community/post/:id/coin-logs` | 无 | **Path**: `id` | 投币记录 |
| POST | `/api/community/attach/purchase` | `authRequired`(getUserId) | **Body**: `postId`, `resourceType`, `resourcePrice` 等 | 购买附件/资源 |
| GET | `/api/community/attach/purchased` | `authRequired`(getUserId) | 已购买附件列表 |
| GET | `/api/community/post/:id/comments` | 无 | **Path**: `id`, **Query**: `page`, `pageSize`, `sort` | `{code, data: {list, total}}` |
| POST | `/api/community/post/:id/comment` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `content`, `parentId`(回复时), `images` | `{code, msg, data: {id}}` 含敏感词检测、Mention通知 |
| DELETE | `/api/community/comment/:id` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg}` 软删除评论(作者或管理员) |
| POST | `/api/community/comment/:id/pin` | `authRequired`(getUserId+版主/管理员) | **Path**: `id` | 置顶评论 |
| GET | `/api/community/moderator/comments/pending` | `authRequired`(getUserId) | 待审核评论列表 |
| POST | `/api/community/moderator/comment/:id/approve` | `authRequired`(getUserId) | **Path**: `id` | 审核通过评论 |
| POST | `/api/community/moderator/comment/:id/reject` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason` | 审核驳回评论 |
| POST | `/api/community/moderator/comments/batch-approve` | `authRequired`(getUserId) | **Body**: `ids`(数组) | 批量通过 |
| POST | `/api/community/moderator/comments/batch-reject` | `authRequired`(getUserId) | **Body**: `ids`(数组), `reason` | 批量驳回 |
| GET | `/api/community/drafts` | `authRequired`(getUserId) | 我的草稿列表 |
| POST | `/api/community/draft` | `authRequired`(getUserId) | **Body**: 同帖子 | 保存草稿 |
| DELETE | `/api/community/draft/:id` | `authRequired`(getUserId) | **Path**: `id` | 删除草稿 |
| POST | `/api/community/post/:id/vote` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `voteData` | 创建投票 |
| POST | `/api/community/vote/:voteId/cast` | `authRequired`(getUserId) | **Path**: `voteId`, **Body**: `optionIndex` | 投票 |
| GET | `/api/community/post/:id/votes` | 无 | **Path**: `id` | 获取投票数据 |
| POST | `/api/community/vote/:voteId/close` | `authRequired`(getUserId) | **Path**: `voteId` | 关闭投票 |

---

## 模块: chat-room.cjs
**文件**: `server/routes/chat-room.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/chat-rooms` | `optionalAuth`(getUserId) | **Query**: `page`, `pageSize`, `keyword`, `category`, `sort` | `{code, data: {list, total}}` 聊天室列表 |
| GET | `/api/chat-rooms/my` | `authRequired`(getUserId) | 我加入的聊天室 |
| GET | `/api/chat-rooms/limit-upgrades` | `authRequired`(getUserId) | 人数上限升级申请 |
| PUT | `/api/chat-rooms/limit-upgrades/:upgradeId` | `authRequired`(getUserId) | **Path**: `upgradeId`, **Body**: `status` | 处理升级申请 |
| GET | `/api/chat-rooms/can-create` | `authRequired`(getUserId) | 是否有权限创建 |
| GET | `/api/chat-rooms/:roomId` | `optionalAuth`(getUserId) | **Path**: `roomId` | `{code, data: room}` 聊天室详情 |
| POST | `/api/chat-rooms` | `authRequired`(getUserId) | **Body**: `name`, `description`, `avatar`, `maxMembers`, `isPrivate`, `password` 等 | `{code, msg, data: {id}}` |
| PUT | `/api/chat-rooms/:roomId` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `name`, `description`, `avatar`, `notice` 等 | `{code, msg}` 更新(群主/管理员) |
| DELETE | `/api/chat-rooms/:roomId` | `authRequired`(getUserId) | **Path**: `roomId` | `{code, msg}` 删除(群主) |
| POST | `/api/chat-rooms/:roomId/join` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `password`(私密房间) | `{code, msg}` 加入聊天室 |
| POST | `/api/chat-rooms/:roomId/leave` | `authRequired`(getUserId) | **Path**: `roomId` | `{code, msg}` 退出聊天室 |
| GET | `/api/chat-rooms/:roomId/members` | `optionalAuth`(getUserId) | **Path**: `roomId`, **Query**: `page`, `pageSize` | `{code, data: {list, total}}` |
| PUT | `/api/chat-rooms/:roomId/mute/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId`, **Body**: `duration`(分钟) | `{code, msg}` 禁言(群主/管理员) |
| PUT | `/api/chat-rooms/:roomId/unmute/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId` | `{code, msg}` 解除禁言 |
| POST | `/api/chat-rooms/:roomId/kick/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId` | `{code, msg}` 踢出(群主/管理员) |
| GET | `/api/chat-rooms/:roomId/messages` | `optionalAuth`(getUserId) | **Path**: `roomId`, **Query**: `page`, `pageSize`, `beforeId` | `{code, data: {list, total}}` |
| POST | `/api/chat-rooms/:roomId/messages` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `content`, `type`(text/image/file), `replyTo` 等 | `{code, data: message}` |
| PUT | `/api/chat-rooms/:roomId/messages/:msgId/recall` | `authRequired`(getUserId) | **Path**: `roomId`, `msgId` | `{code, msg}` 撤回消息 |
| POST | `/api/chat-rooms/:roomId/messages/:msgId/report` | `authRequired`(getUserId) | **Path**: `roomId`, `msgId`, **Body**: `reason` | `{code, msg}` 举报消息 |
| GET | `/api/chat-rooms/:roomId/admin-logs` | `authRequired`(getUserId) | **Path**: `roomId` | 管理日志 |
| PUT | `/api/chat-rooms/:roomId/set-admin/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId` | `{code, msg}` 设为管理员(群主) |
| POST | `/api/chat-rooms/:roomId/transfer/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId` | `{code, msg}` 转让群主 |
| DELETE | `/api/chat-rooms/:roomId/dissolve` | `authRequired`(getUserId) | **Path**: `roomId` | `{code, msg}` 解散聊天室(群主) |
| POST | `/api/chat-rooms/:roomId/ban/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId`, **Body**: `duration` | 拉黑用户 |
| DELETE | `/api/chat-rooms/:roomId/ban/:userId` | `authRequired`(getUserId) | **Path**: `roomId`, `userId` | 解除拉黑 |
| GET | `/api/chat-rooms/:roomId/stats` | 无 | **Path**: `roomId` | 聊天室统计 |
| POST | `/api/chat-rooms/:roomId/avatar` | `authRequired`(getUserId) | multipart: `file` (groupFileUpload) | 上传头像 |
| GET | `/api/chat-rooms/:roomId/files` | `authRequired`(getUserId) | **Path**: `roomId` | 群文件列表 |
| POST | `/api/chat-rooms/:roomId/files` | `authRequired`(getUserId) | multipart: `file` | 上传群文件 |
| DELETE | `/api/chat-rooms/:roomId/files/:fileId` | `authRequired`(getUserId) | **Path**: `roomId`, `fileId` | 删除群文件 |
| POST | `/api/chat-rooms/:roomId/invite` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `userIds`(数组) | 邀请用户 |
| GET | `/api/chat-rooms/:roomId/messages/search` | `authRequired`(getUserId) | **Path**: `roomId`, **Query**: `keyword`, `userId`, `startDate`, `endDate` | 搜索消息 |
| GET | `/api/chat-rooms/:roomId/gifts` | 无 | **Path**: `roomId` | 礼物列表 |
| POST | `/api/chat-rooms/:roomId/gift/send` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `giftId`, `targetUserId`, `quantity` | 送礼物 |
| GET | `/api/chat-rooms/:roomId/pins` | `optionalAuth`(getUserId) | **Path**: `roomId` | 置顶消息列表 |
| POST | `/api/chat-rooms/:roomId/pins` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `messageId` | 置顶消息(群主/管理员) |
| DELETE | `/api/chat-rooms/:roomId/pins/:messageId` | `authRequired`(getUserId) | **Path**: `roomId`, `messageId` | 取消置顶 |
| POST | `/api/chat-rooms/:roomId/limit-upgrade` | `authRequired`(getUserId) | **Path**: `roomId`, **Body**: `targetLimit` 等 | 申请扩容 |

---

## 模块: collection.cjs
**文件**: `server/routes/collection.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/community/collection` | `authRequired`(getUserId) | **Body**: `title`, `description`, `cover`, `status`(serializing/finished), `price`, `priceType`, `sections`(章节数组) | `{code, msg, data: {id}}` |
| POST | `/api/community/collection/:id/posts` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `postIds`(数组) | 向合集添加帖子 |
| POST | `/api/community/collection/:id/buy` | `authRequired`(getUserId) | **Path**: `id` | 购买合集 |
| GET | `/api/community/collection/mine` | `authRequired`(getUserId) | 我的合集列表 |
| GET | `/api/community/collection/user/:userId` | 无 | **Path**: `userId`, **Query**: `page`, `pageSize` | 用户的合集列表 |
| GET | `/api/community/collection/paid` | `authRequired`(getUserId) | 已购买合集列表 |
| GET | `/api/community/collections/featured` | 无 | 精选合集 |
| GET | `/api/community/post/:id/collection` | 无 | **Path**: `id` | 帖子所在合集 |
| GET | `/api/community/collection/:id` | `optionalAuth`(getUserId) | **Path**: `id` | 合集详情含章节内容 |
| GET | `/api/community/collection/:id/check-paid` | `authRequired`(getUserId) | **Path**: `id` | 检查是否已购买 |
| GET | `/api/community/collection/:id/post/:postId` | 无 | **Path**: `id`, `postId` | 合集内单帖详情 |
| PUT | `/api/community/collection/:id` | `authRequired`(getUserId) | **Path**: `id` | 更新合集 |
| PUT | `/api/community/collection/:id/posts/sort` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `postIds`(排序数组) | 排序合集内帖子 |
| PUT | `/api/community/collection/:id/posts/:postId/preview` | `authRequired`(getUserId) | **Path**: `id`, `postId`, **Body**: `previewLength` | 设置预览长度 |
| DELETE | `/api/community/collection/:id` | `authRequired`(getUserId) | **Path**: `id` | 删除合集 |
| DELETE | `/api/community/collection/:id/posts` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `postIds`(数组) | 从合集移除帖子 |
| POST | `/api/community/favorite/groups` | `authRequired`(getUserId) | **Body**: `name`, `description`, `visibility` | 创建收藏夹 |
| PUT | `/api/community/favorite/groups/:id` | `authRequired`(getUserId) | **Path**: `id` | 更新收藏夹 |
| DELETE | `/api/community/favorite/groups/:id` | `authRequired`(getUserId) | **Path**: `id` | 删除收藏夹 |
| POST | `/api/community/favorite/groups/reorder` | `authRequired`(getUserId) | **Body**: `ids`(排序数组) | 排序收藏夹 |
| PUT | `/api/community/favorite/groups/:id/visibility` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `visibility` | 修改可见性 |
| POST | `/api/community/favorite/groups/:id/follow` | `authRequired`(getUserId) | **Path**: `id` | 关注收藏夹 |
| DELETE | `/api/community/favorite/groups/:id/follow` | `authRequired`(getUserId) | **Path**: `id` | 取消关注 |
| GET | `/api/community/favorite/groups/following` | `authRequired`(getUserId) | 关注的收藏夹 |
| GET | `/api/community/favorite/groups/user/:uid` | 无 | **Path**: `uid` | 用户的收藏夹 |
| GET | `/api/community/favorite/collections` | `authRequired`(getUserId) | 收藏夹内容 |
| POST | `/api/community/favorite/move` | `authRequired`(getUserId) | **Body**: `itemId`, `fromGroupId`, `toGroupId`, `itemType` | 移动收藏到其他收藏夹 |
| POST | `/api/community/collection/:id/favorite` | `authRequired`(getUserId) | **Path**: `id` | 收藏合集 |
| DELETE | `/api/community/collection/:id/favorite` | `authRequired`(getUserId) | **Path**: `id` | 取消收藏合集 |
| GET | `/api/community/collection/:id/favorite/check` | `authRequired`(getUserId) | **Path**: `id` | 检查合集收藏状态 |
| DELETE | `/api/community/post/:id/favorite` | `authRequired`(getUserId) | **Path**: `id` | 取消收藏帖子 |
| GET | `/api/community/post/:id/favorite/check` | `authRequired`(getUserId) | **Path**: `id` | 检查帖子收藏状态 |
| GET | `/api/community/favorite/items` | `authRequired`(getUserId) | **Query**: `page`, `pageSize`, `groupId` | 收藏列表 |
| GET | `/api/community/favorite/items/user/:uid` | 无 | **Path**: `uid` | 用户公开收藏列表 |
| POST | `/api/community/collection/:id/progress` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `postId` | 更新阅读进度 |
| GET | `/api/community/collection/:id/progress` | `authRequired`(getUserId) | **Path**: `id` | 获取阅读进度 |
| POST | `/api/community/collection/:id/comment` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `content` | 合集评论 |
| GET | `/api/community/collection/:id/comments` | 无 | **Path**: `id` | 合集评论列表 |
| POST | `/api/community/collection/:id/rate` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `rating`(1-5) | 合集评分 |
| GET | `/api/community/collection/:id/rating` | 无 | **Path**: `id` | 合集评分统计 |
| PUT | `/api/community/collection/:id/posts/batch-sort` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `sections`(数组) | 批量调整章节和帖子排序 |
| POST | `/api/community/collection/:id/share` | `authRequired`(getUserId) | **Path**: `id` | 分享合集(记录分享) |
| GET | `/api/community/collection/:id/share-stats` | 无 | **Path**: `id` | 分享统计 |
| GET | `/api/community/favorite/groups` | `authRequired`(getUserId) | 收藏夹列表 |

---

## 模块: notification.cjs
**文件**: `server/routes/notification.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/notifications` | `optionalAuth`(getUserId) | **Query**: `page`, `pageSize`, `type` | `{code, data: {list, total, unreadCount}}` |
| POST | `/api/notifications/read-all` | `authRequired`(getUserId) | 无 | `{code, msg}` 全部已读 |
| POST | `/api/notifications/:id/read` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg}` 标记单条已读 |
| GET | `/api/messages/conversations` | `authRequired`(getUserId) | 私信会话列表 |
| GET | `/api/messages/orders` | `authRequired`(getUserId) | 订单消息 |
| GET | `/api/messages/:targetUserId` | `authRequired`(getUserId) | **Path**: `targetUserId`, **Query**: `page`, `pageSize` | 与某用户的私信记录 |
| POST | `/api/messages/upload-image` | `authRequired`(getUserId) | multipart: `file` (chatImageUpload) | 上传私信图片 |
| POST | `/api/messages/:targetUserId` | `authRequired`(getUserId) | **Path**: `targetUserId`, **Body**: `content`, `type`(text/image), `imageUrl` | `{code, msg, data: message}` |
| PUT | `/api/messages/:id/recall` | `authRequired`(getUserId) | **Path**: `id` | `{code, msg}` 撤回消息 |
| POST | `/api/messages/:id/report` | `authRequired`(getUserId) | **Path**: `id`, **Body**: `reason` | `{code, msg}` 举报私信 |
| GET | `/api/messages/search` | `authRequired`(getUserId) | **Query**: `keyword`, `targetUserId` | 搜索私信 |
| DELETE | `/api/messages/conversations/:partnerId` | `authRequired`(getUserId) | **Path**: `partnerId` | 删除对话 |
| GET | `/api/admin/sensitive-words` | 无 | 敏感词列表(管理员) |
| POST | `/api/admin/sensitive-words` | 无 | **Body**: `word`, `type`, `replacement` | 添加敏感词 |
| PUT | `/api/admin/sensitive-words/:id` | 无 | **Path**: `id` | 更新敏感词 |
| DELETE | `/api/admin/sensitive-words/:id` | 无 | **Path**: `id` | 删除敏感词 |
| GET | `/api/notifications/types` | 无 | 通知类型列表 |
| POST | `/api/notifications/push/register` | `authRequired`(getUserId) | **Body**: `deviceToken`, `platform` | 注册推送设备 |
| GET | `/api/user/notification-settings` | `authRequired`(getUserId) | 通知设置 |
| PUT | `/api/user/notification-settings` | `authRequired`(getUserId) | **Body**: `notificationSettings` | 更新通知设置 |
| GET | `/api/admin/chat-reports` | 无 | 聊天举报管理 |
| PUT | `/api/admin/chat-reports/:id` | 无 | **Path**: `id`, **Body**: `status` | 处理聊天举报 |

---

## 模块: upload.cjs
**文件**: `server/routes/upload.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/upload/avatar` | 无 | multipart: `file` (imageUpload) | `{code, data: {url}}` |
| POST | `/api/upload/background` | 无 | multipart: `file` (imageUpload) | `{code, data: {url}}` |
| POST | `/api/upload/experience-icon` | 无 | multipart: `file` (imageUpload) | `{code, data: {url}}` |
| POST | `/api/upload/membership-icon` | 无 | multipart: `file` (imageUpload) | `{code, data: {url}}` |
| POST | `/api/upload/apk` | 无 | multipart: `file` (apkUpload) | `{code, data: {url, name, size}}` |
| POST | `/api/upload/file` | `authRequired`(getUserId) | multipart/form-data: `file` | `{code, data: {url, name, size, id}}` 通用文件上传 |
| GET | `/api/upload/storage-quota` | `authRequired`(getUserId) | Quota计算 |
| GET | `/api/upload/quota` | `authRequired`(getUserId) | 存储配额信息 |
| POST | `/api/upload/parse-download-url` | 无 | **Body**: `url` | `{code, data: {directUrl}}` 解析下载链接 |
| POST | `/api/upload/batch-temp` | `authRequired`(getUserId) | multipart: `files`(最多20) (imageUpload.array) | `{code, data: [{tempId, url}]}` 批量临时上传 |
| POST | `/api/upload/batch-commit` | `authRequired`(getUserId) | **Body**: `tempIds`(数组), `refType`, `refId` | `{code, msg}` 批量提交上传 |
| POST | `/api/upload/delete-uploaded` | `authRequired`(getUserId) | **Body**: `urls`(数组) | `{code, msg}` 删除已上传文件 |

---

## 模块: email.cjs
**文件**: `server/routes/email.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/email/configs` | 无 | 邮件配置清单 |
| GET | `/api/email/templates` | 无 | 邮件模板列表 |
| GET | `/api/email/config` | `authRequired` | 邮件SMTP配置详情 |
| POST | `/api/email/config` | `authRequired` + `requirePermission('edit')` | **Body**: SMTP配置 | `{code, msg}` |
| POST | `/api/email/test` | `authRequired` + `requirePermission('test')` | **Body**: `email` | `{code, msg}` 发送测试邮件 |
| POST | `/api/email/send-code` | 无 | **Body**: `email`, `type`(register/reset_password/change_email等) | `{code, msg}` 发送邮箱验证码 |
| POST | `/api/email/test-notify` | 无 | **Body**: `email` | 测试通知邮件 |
| POST | `/api/email/test-notify-all` | 无 | 测试所有管理员通知 |
| POST | `/api/email/verify-code` | 无 | **Body**: `email`, `code`, `type` | `{code, data: {valid}}` 验证邮箱验证码 |
| POST | `/api/auth/reset-password` | 无 | **Body**: `email`, `code`, `password` | `{code, msg}` 通过邮箱重置密码 |
| POST | `/api/sms/send-code` | 无 | **Body**: `phone`, `type` | `{code, msg}` 发送短信验证码 |
| POST | `/api/sms/verify-code` | 无 | **Body**: `phone`, `code`, `type` | `{code, data: {valid}}` 验证短信验证码 |

---

## 模块: search.cjs
**文件**: `server/routes/search.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/search` | 无 | **Query**: `q`, `type`(all/post/app/product), `page`, `pageSize` | `{code, data: {list, total}}` 跨模块全文搜索 |

---

## 模块: operation.cjs
**文件**: `server/routes/operation.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/operation/cardkey/list` | 无 | **Query**: `page`, `pageSize`, `keyword`, `status` | `{code, data: {list, total}}` 卡密列表 |
| POST | `/api/operation/cardkey/create` | 无 | **Body**: `type`, `targetId`, `targetName`, `value`, `count`, `expireDays` 等 | `{code, msg}` 生成卡密 |
| DELETE | `/api/operation/cardkey/:id` | 无 | **Path**: `id` | 删除卡密 |
| POST | `/api/operation/cardkey/import` | 无 | **Body**: `cards`(数组) | 导入卡密 |
| POST | `/api/cardkey/redeem` | 无 | **Body**: `cardNo`, `password`, `userId` | `{code, msg}` 兑换卡密 |
| GET | `/api/membership/levels` | 无 | 会员等级列表 |
| GET | `/api/operation/commission-rules/list` | 无 | 佣金规则列表 |
| GET | `/api/operation/membership-level/list` | 无 | 会员等级列表(管理) |
| POST | `/api/operation/membership-level/save` | 无 | **Body**: `id`(更新时), `name`, `icon`, `discountRate`, `pointsDiscountRate`, `textColor`, `bgColor`, `sortOrder`, `description`, `permissions` 等 | `{code, msg, data: {id}}` |
| DELETE | `/api/operation/membership-level/:id` | 无 | **Path**: `id` | 删除会员等级 |
| GET | `/api/operation/member/list` | 无 | 会员管理列表 |
| POST | `/api/operation/member/update-level` | 无 | **Body**: `userId`, `levelId`, `durationDays` | 手动设置会员等级 |
| GET | `/api/operation/points-record/list` | 无 | 积分记录列表 |
| POST | `/api/operation/points-record/adjust` | 无 | **Body**: `userId`, `points`, `type`(earn/spend), `description` | 手动调整积分 |
| GET | `/api/operation/experience-level/list` | 无 | 经验等级列表 |
| POST | `/api/operation/experience-level/save` | 无 | **Body**: `id`(更新时), `name`, `level`, `expRequired`, `icon`, `textColor`, `bgColor`, `permissions` | `{code, msg, data: {id}}` |
| DELETE | `/api/operation/experience-level/:id` | 无 | **Path**: `id` | 删除经验等级 |

---

## 模块: two-factor.cjs
**文件**: `server/routes/two-factor.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/two-factor/status/:userId` | 无 | **Path**: `userId` | `{code, data: {enabled}}` |
| POST | `/api/two-factor/verify` | 无 | **Body**: `userId`, `code` | `{code, data: {valid}}` |
| POST | `/api/two-factor/setup` | `authRequired` | **Body**: `password` | `{code, data: {secret, qrcode}}` 生成密钥和二维码 |
| POST | `/api/two-factor/enable` | `authRequired` | **Body**: `code`, `secret` | `{code, msg}` 验证并启用 |
| POST | `/api/two-factor/disable` | `authRequired` | **Body**: `password`, `code` | `{code, msg}` |
| GET | `/api/two-factor/my-status` | `authRequired` | 无 | `{code, data: {enabled}}` |

---

## 模块: settlement.cjs
**文件**: `server/routes/settlement.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| POST | `/api/settlement/create-order` | `authRequired`(getUserId) | **Body**: 结算订单创建参数 | `{code, data: {orderId}}` |
| POST | `/api/settlement/confirm` | `authRequired`(getUserId) | **Body**: `orderId` 等 | 确认结算 |
| POST | `/api/settlement/request-refund` | `authRequired`(getUserId) | **Body**: `orderId`, `reason` | 申请退款 |
| POST | `/api/settlement/respond-refund` | `authRequired`(getUserId) | **Body**: `refundId`, `action`(accept/reject) | 处理退款 |
| POST | `/api/settlement/report-to-admin` | `authRequired`(getUserId) | **Body**: `orderId`, `reason` | 向管理员举报 |
| GET | `/api/settlement/admin-reports` | `authRequired`(getUserId) | 管理员举报列表 |
| POST | `/api/settlement/admin-refund` | `authRequired`(getUserId) | **Body**: 管理员退款参数 | |
| GET | `/api/settlement/orders` | `authRequired`(getUserId) | 结算订单列表 |
| GET | `/api/settlement/pending-stats` | `authRequired`(getUserId) | 待处理统计 |
| GET | `/api/settlement/config` | 无 | 结算配置列表 |
| POST | `/api/settlement/config` | 无 | **Body**: 配置数据 | 创建结算配置 |
| PUT | `/api/settlement/config/:id` | 无 | **Path**: `id` | 更新结算配置 |
| GET | `/api/settlement/user-config` | `authRequired`(getUserId) | 用户结算配置 |
| POST | `/api/settlement/validate-transfer` | `authRequired`(getUserId) | **Body**: 转账验证参数 | |
| DELETE | `/api/settlement/config/:id` | 无 | **Path**: `id` | 删除结算配置 |

---

## 模块: plugins.cjs
**文件**: `server/routes/plugins.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/plugins/list` | 无 | 插件列表(含安装状态) |
| POST | `/api/plugins/upload` | `authRequired` + `requirePermission('upload')` | multipart: `file` (upload) | `{code, msg}` 安装插件 |
| PUT | `/api/plugins/:id/toggle` | `authRequired` + `requirePermission('toggle')` | **Path**: `id` | `{code, msg}` 启用/禁用插件 |
| DELETE | `/api/plugins/:id` | `authRequired` + `requirePermission('delete')` | **Path**: `id` | `{code, msg}` 卸载插件 |
| POST | `/api/plugins/:id/upgrade` | `authRequired` | multipart: `file` | `{code, msg}` 升级插件 |
| PUT | `/api/plugins/:name/config` | `authRequired` + `requirePermission('config')` | **Path**: `name`, **Body**: config JSON | 更新插件配置 |
| GET | `/api/plugins/inject` | 无 | 获取所有已启用插件的注入代码(frontend hooks) |
| GET | `/api/plugins/:id/detail` | `authRequired` | **Path**: `id` | 插件详情 |
| GET | `/api/plugins/extensions/state` | `authRequired` | 插件扩展状态 |

---

## 模块: recommend.cjs
**文件**: `server/routes/recommend.cjs`

| HTTP | 路径 | 认证 | 请求参数 | 响应格式 |
|------|------|------|---------|---------|
| GET | `/api/appstore/recommend` | `optionalAuth`(getUserId) | 应用商店个性化推荐 |
| GET | `/api/recommend/for-you` | `optionalAuth`(getUserId) | 为你推荐(基于行为和偏好) |
| GET | `/api/recommend/hot-tags` | 无 | 热门标签 |

---

## 认证中间件说明

| 中间件 | 来源 | 说明 |
|--------|------|------|
| `authRequired` | system.cjs | 强制认证, 验证 Bearer Token 从 sessions Map 或数据库 |
| `optionalAuth` | system.cjs | 可选认证, 有token时设置 req.user |
| `requirePermission(authMark)` | system.cjs | R_SUPER直接通过, 否则查role_permissions表 |
| `adminRequired` | user.cjs | 管理员认证 (R_SUPER 或 R_ADMIN) |
| `getUserId` | community-utils.cjs | 从token获取userId, 社区模块专用 |
| `isAdmin` / `isAdminById` | community-utils.cjs | 检查是否为社区管理员 |
| `canManageModAction` / `canReviewModAction` | community-utils.cjs | 版主操作权限检查 |
| `isModeratorOfSection` | community-utils.cjs | 检查是否为板块版主 |
| `chrisAdminRequired` / `chrisAuthRequired` | settlement.cjs | 结算模块自定义认证 |

---

**生成时间**: 2026-07-18
**源文件路径**: `当前工作区/workspace/server/routes/`
