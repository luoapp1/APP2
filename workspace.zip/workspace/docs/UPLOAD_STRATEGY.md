# 文件上传策略

## 概述

系统采用三层架构管理文件上传：**存储配置层**（决定文件存哪里）、**文件策略层**（限制单文件大小和类型）、**存储配额层**（限制用户总用量）。三层独立运作，互不干扰。

---

## 一、数据库表结构

### 1.1 storage_configs（存储配置表）

```sql
CREATE TABLE storage_configs (
  id              INTEGER PRIMARY KEY AUTO_INCREMENT,
  type            VARCHAR(50)  DEFAULT 'local',   -- 存储类型: local/oss/cos/minio/s3/qiniu/huawei
  name            VARCHAR(100) DEFAULT '',         -- 配置名称
  config          TEXT,                             -- JSON扩展配置
  endpoint        VARCHAR(500) DEFAULT '',          -- 服务端点
  region          VARCHAR(100) DEFAULT '',          -- 区域
  bucket          VARCHAR(200) DEFAULT '',          -- 存储桶
  access_key      VARCHAR(500) DEFAULT '',          -- 访问密钥（加密存储）
  secret_key      VARCHAR(500) DEFAULT '',          -- 秘密密钥（加密存储）
  local_dir       VARCHAR(500) DEFAULT '',          -- 本地存储子目录
  remote_dir      VARCHAR(500) DEFAULT '',          -- 云存储远程目录模板
  base_url        VARCHAR(500) DEFAULT '',          -- 自定义访问域名
  applicable_roles    TEXT,                         -- 适用角色（逗号分隔）
  applicable_levels   TEXT,                         -- 适用等级（逗号分隔，特殊值 'backend'）
  is_default      TINYINT(1) DEFAULT 0,            -- 是否默认配置
  status          VARCHAR(2)  DEFAULT '1',          -- 状态
  create_time     DATETIME DEFAULT NOW(),
  update_time     DATETIME DEFAULT NOW()
)
```

**当前配置**：

| ID | name | type | bucket | region | is_default | applicable_roles | applicable_levels |
|----|------|------|--------|--------|------------|------------------|-------------------|
| 2 | 用户-阿里云OSS | oss | appiapp | cn-hongkong | 1 | 所有会员 | all |
| 3 | 后台-阿里云OSS | oss | appiapp | cn-hongkong | 0 | - | backend |

### 1.2 file_policies（文件策略表）

```sql
CREATE TABLE file_policies (
  id               INTEGER PRIMARY KEY AUTO_INCREMENT,
  name             VARCHAR(100) DEFAULT '',  -- 策略名称
  user_level_id    INTEGER DEFAULT 0,        -- 适用等级 ID
  user_level_name  VARCHAR(100) DEFAULT '',  -- 等级名称
  role_code        VARCHAR(100) DEFAULT '',  -- 适用角色代码（'*' 通配）
  user_id          INTEGER DEFAULT 0,        -- 适用特定用户
  max_file_size_mb INTEGER DEFAULT 10,       -- 单文件最大 MB
  allowed_types    TEXT DEFAULT '',           -- 允许的扩展名（逗号分隔）
  banned_types     TEXT DEFAULT '',           -- 禁止的扩展名（逗号分隔）
  status           VARCHAR(2) DEFAULT '1',
  create_time      DATETIME DEFAULT NOW()
)
```

### 1.3 file_repository（文件仓库表）

```sql
CREATE TABLE file_repository (
  id          INTEGER PRIMARY KEY AUTO_INCREMENT,
  user_id     INTEGER DEFAULT 0,           -- 上传用户
  user_name   VARCHAR(100) DEFAULT '',
  file_name   VARCHAR(500) NOT NULL,       -- 原始文件名
  file_path   VARCHAR(500) NOT NULL,       -- 访问 URL 或本地路径
  file_size   BIGINT DEFAULT 0,            -- 文件大小（字节）
  file_type   VARCHAR(100) DEFAULT '',     -- 扩展名
  mime_type   VARCHAR(200) DEFAULT '',     -- MIME 类型
  category    VARCHAR(50) DEFAULT 'other', -- 分类（如 community_image）
  ref_id      INTEGER DEFAULT 0,           -- 关联业务 ID
  ref_type    VARCHAR(50) DEFAULT '',      -- 关联业务类型（如 community_post）
  create_time DATETIME DEFAULT NOW()
)
```

### 1.4 users 表相关字段

```
users.used_bytes  BIGINT  -- 用户已用存储空间，由 updateUserUsedBytes 从 file_repository 汇总计算
users.level_id    INTEGER -- 用户等级，关联 membership_products.level_id
```

---

## 二、存储选取逻辑

### 2.1 入口函数

```js
// storage-config.cjs:498
getDefaultStorage(userCtx)
```

### 2.2 决策树

```
查询所有 status='1' 的 storage_configs，按 is_default DESC, id 排序
  │
  ├── userCtx 为空 → 返回第一条（配置2）
  │
  ├── userCtx.backend === true && userCtx.roles 包含 R_SUPER 或 R_ADMIN
  │   └── 查找 applicable_levels === 'backend' 的配置 → 配置3（后台-阿里云OSS）
  │
  └── 否则（前台用户或非管理员）
      └── 遍历配置，过滤 applicable_levels === 'backend' 的项
          └── 匹配 applicable_roles（',' split）与用户 roles
          └── 匹配 applicable_levels（',' split）与用户 levelId
          └── 第一个全匹配 → 返回该配置
          └── 无匹配 → 兜底返回第一条（配置2）
```

### 2.3 关键区分：后台 vs 前台

存储选取依据**请求来源（isBackend 参数）**而非用户角色。

| 请求来源 | isBackend | 用户角色 | 匹配结果 |
|----------|-----------|----------|----------|
| 后台管理面板 | `true` | 管理员 | 配置3（后台-阿里云OSS） |
| 后台管理面板 | `true` | 普通用户 | 走前台逻辑（通常不可达） |
| 前台社区页面 | `false` | 管理员 | 配置2（用户-阿里云OSS） |
| 前台社区页面 | `false` | 普通用户 | 配置2（用户-阿里云OSS） |

管理员在前台发帖上传图片 → `isBackend=false` → 跳过 `backend && isAdmin` 分支 → 匹配配置2（用户-阿里云OSS）。

### 2.4 applicable_levels 特殊值

| 值 | 含义 |
|----|------|
| `''` | 不限制等级 |
| `'all'` | 匹配所有用户（用于前台通用配置） |
| `'backend'` | 仅后台管理员使用 |
| `'1,2,3'` | 仅匹配 level_id 为 1、2、3 的用户 |

---

## 三、文件策略选取

### 3.1 入口函数

```js
// upload.cjs:25
getUserPolicy(userId, roles)
```

### 3.2 优先级链（从高到低）

| 优先级 | 查询条件 | 说明 |
|--------|----------|------|
| 1 | `role_code = '*'` | 匹配所有角色的通配策略 |
| 2 | `role_code IN (用户角色列表)` | 按角色匹配 |
| 3 | `role_code = '' AND user_level_id = 用户等级` | 按等级匹配 |
| 4 | `role_code = '' AND user_level_id = 0` | 默认兜底策略 |

找到第一个即返回，不继续往下找。

### 3.3 策略内容

```
max_file_size_mb  ─→ 单文件上传大小上限（MB）
allowed_types     ─→ 允许的文件扩展名（如 'jpg,png,gif'）
banned_types      ─→ 禁止的文件扩展名（如 'exe,sh'）
```

---

## 四、存储配额检查

### 4.1 入口函数

```js
// upload.cjs:58
checkStorageQuota(userId, newFileSize, fileCategory)
```

### 4.2 检查逻辑

```
1. 获取用户等级对应的 membership_products 记录
2. 如果未购买会员:
    └── 从 app_settings 读取 user_quota_mb（默认用户配额 MB）
3. 如果购买了会员（有 level_id）:
    └── 使用 membership_products 中的 storage_limit_mb
4. 检查: (users.used_bytes + newFileSize) <= quota_bytes
    ├── 通过 → 返回 { ok: true }
    └── 不通过 → 返回 { ok: false, msg: '存储空间不足' }
```

### 4.3 used_bytes 的计算

```
updateUserUsedBytes(userId):
  SELECT COALESCE(SUM(file_size), 0) FROM file_repository WHERE user_id = userId
  → UPDATE users SET used_bytes = 汇总值 WHERE id = userId
```

---

## 五、完整上传流程

### 5.1 resolveUploadPath（核心上传路径解析）

```js
// upload.cjs:876
async function resolveUploadPath(file, req, isBackend)
```

```
1. multer 已将文件写入 /server/uploads/[filename]
2. 解析用户身份 → userId, roles, levelId
3. 构建 userCtx = { userId, roles, levelId, backend: isBackend }
4. 调用 getDefaultStorage(userCtx) 获取存储配置
   └── storage 为 null → 返回 /uploads/[filename]（本地兜底）

5. 分支:
   │
   ├── storage.type === 'local'
   │   ├── 有 local_dir → 移动到 /server/uploads/[local_dir]/[filename]
   │   │                  返回 /uploads/[local_dir]/[filename]
   │   └── 无 local_dir → 返回 /uploads/[filename]（原地保留）
   │
   └── storage.type !== 'local'（OSS/COS/MinIO/S3）
       ├── 构建 remoteKey = [baseDir]/[fileType]/[filename]
       │   例如: user/19/img/community_1784025301063_kg5n85.png
       ├── 调用 uploadToCloud(storage, localPath, remoteKey)
       │   ├── 成功 → 返回云 URL（如 http://appiapp.oss-cn-hongkong.aliyuncs.com/user/19/img/xxx.png）
       │   └── 失败 → console.error 日志，返回 null
       ├── fs.unlinkSync(localPath)  ← 删除本地临时文件
       ├── 上传成功 → 返回云 URL
       └── 上传失败 → 返回 /uploads/[filename]（注意：本地文件已被删除，此 URL 指向不存在的文件）
```

### 5.2 uploadToCloud（云上传实现）

```js
// storage-config.cjs:52
async function uploadToCloud(config, localFilePath, remoteKey)
```

支持的云平台:

| type | SDK | 上传方式 |
|------|-----|----------|
| `oss` | ali-oss | `client.put(remoteKey, localFilePath)` |
| `cos` | cos-nodejs-sdk-v5 | `cos.putObject({ Bucket, Region, Key, Body: fileStream })` |
| `minio` | minio | `minioClient.putObject(bucket, remoteKey, fileStream, stat.size)` |
| `s3` | @aws-sdk/client-s3 | `s3.send(new PutObjectCommand({...}))` |

### 5.3 deleteFromCloud（云删除实现）

```js
// upload.cjs:780
async function deleteFromCloud(storage, key)
```

支持的云平台: 同 uploadToCloud（oss/cos/minio/s3），调用各自的 `delete` / `deleteObject` / `removeObject` 方法。

---

## 六、社区图片上传接口

### 6.1 上传

**POST `/api/community/upload-image`**

```
请求: multipart/form-data, 字段名 'file'
处理:
  1. multer 接收文件 → /server/uploads/community_[timestamp]_[random].ext
  2. resolveUploadPath(req.file, req, isBackend=false)  → 上传到 OSS
  3. checkStorageQuota(userId, fileSize, 'community_image')  → 配额检查
  4. recordFileUpload(...)  → 写入 file_repository
  5. updateUserUsedBytes(userId)  → 重算 users.used_bytes
响应: { code: 200, msg: '上传成功', data: { url: 'http://...' } }
```

### 6.2 删除

**POST `/api/community/delete-image`**

```
请求: { url: 'http://appiapp.oss-cn-hongkong.aliyuncs.com/user/0/img/xxx.png' }
处理:
  1. 从 URL 提取 key: user/0/img/xxx.png
  2. deleteFromCloud(storage, key)  → 从 OSS 删除文件
  3. DELETE FROM file_repository WHERE file_path = url  → 删除记录
  4. updateUserUsedBytes(userId)  → 重算配额（回退已用空间）
响应: { code: 200, msg: '删除成功' }
```

---

## 七、前端编辑器图片管理

以社区帖子编辑器（`post-edit.vue`）为例:

```
变量:
  uploadedImageUrls: ref<string[]>()  -- 本次编辑会话中已上传的 OSS URL 集合
  published: boolean                   -- 是否已成功发布

选图:
  handleBlockImageUpload / handleGlobalImageUpload
  → uploadCommunityImage(file) → POST /api/community/upload-image
  → 返回 OSS URL → 推入 contentBlocks + uploadedImageUrls

删图（点 X）:
  removeBlockImage
  → deleteCommunityImage(url) → POST /api/community/delete-image
  → OSS 删除 + DB 记录删除 + 配额回退
  → 从 contentBlocks + uploadedImageUrls 中移除

发布:
  handlePublish → buildPayload → createCommunityPost/updateCommunityPost
  → published = true → router.back()

离开页面未发布:
  onBeforeUnmount
  → if (!published && uploadedImageUrls.length > 0)
  → 遍历 uploadedImageUrls，逐个调 deleteCommunityImage
  → 清理所有孤儿文件
```

---

## 八、关键代码位置

| 功能 | 文件 | 行号 |
|------|------|------|
| getDefaultStorage | server/routes/storage-config.cjs | 498 |
| uploadToCloud | server/routes/storage-config.cjs | 52 |
| deleteFromCloud | server/routes/upload.cjs | 780 |
| resolveUploadPath | server/routes/upload.cjs | 876 |
| getUserPolicy | server/routes/upload.cjs | 25 |
| checkStorageQuota | server/routes/upload.cjs | 58 |
| recordFileUpload | server/routes/upload.cjs | 120 |
| updateUserUsedBytes | server/utils/file-helper.cjs | 83 |
| deleteFileFromStorage | server/utils/file-helper.cjs | 65 |
| 上传接口 | server/routes/community.cjs | 2307 |
| 删除接口 | server/routes/community.cjs | 2333 |
| file_repository 表 | server/database.cjs | 864 |
| file_policies 表 | server/database.cjs | 1054 |
| storage_configs 表 | server/database.cjs | 1711 |
| 上传 API 函数 | src/api/community.ts | 131 |
| 删除 API 函数 | src/api/community.ts | 136 |
| 编辑器图片逻辑 | src/themes/mobile/default/views/appstore/community/post-edit.vue | 461-462, 698-733, 860-882 |
