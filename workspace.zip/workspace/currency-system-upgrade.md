# 货币体系全面升级方案

> 版本: v1.0 | 日期: 2026-07-25
> 影响范围: 数据库（新表 + 旧表修改）、后端 API（新增 + 改造）、前端（1222+ 处引用，~100 个文件）

---

## 现状

| 项目 | 问题 |
|------|------|
| 货币类型 | 仅 `balance`(余额) 和 `points`(积分)，硬编码在代码中，名称不可配 |
| 流水表 | `balance_records` 和 `points_records` 两张独立表，无法交叉对账 |
| 用户余额 | 存在 `users` 表的 `balance` 和 `points` 两个字段，无冻结机制 |
| 支付 | 订单创建即 `paid`，无 pending/refund 状态，无并发锁 |
| 退款 | 不存在 |
| 第三方支付 | 不存在 |
| 前端文本 | 1222+ 处硬编码"余额""积分"，分布在 ~100 个文件中 |
| 通知 | 购买/收款通知文案硬编码货币名，无法适配 |

---

## 升级路线图

```
Phase 0 ──→ Phase 1 ──→ Phase 2 ──→ Phase 3
(货币基础)   (支付基础)   (通知改造)   (全站集成)

Phase 0: 货币名称可配的基石
Phase 1: 支付流程完善（订单状态机/退款/并发锁/混合支付）
Phase 2: 所有通知模板改造成货币感知
Phase 3: 全站 1222+ 处硬编码替换 + 各模块逐个对接新货币体系
```

---

# Phase 0：货币基础设施

## 0.1 新增表 `currency_settings`

每行定义一个货币类型，管理员可随时修改名称/图标。

```sql
CREATE TABLE IF NOT EXISTS currency_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  currency_key VARCHAR(30) NOT NULL UNIQUE,    -- 'balance' | 'points' | 'coin' | 'experience' | 自定义
  display_name VARCHAR(30) NOT NULL DEFAULT '', -- 前台显示名称，如 "钻石" "金币"
  display_icon VARCHAR(500) DEFAULT '',         -- 图标 URL 或 SVG
  display_symbol VARCHAR(10) DEFAULT '',        -- 符号，如 "￥" "🪙" ""
  decimal_places TINYINT DEFAULT 2,             -- 小数位数（余额=2，积分/金币=0）
  sort_order INT DEFAULT 0,                     -- 排序
  is_visible TINYINT(1) DEFAULT 1,              -- 前台是否可见
  is_exchangeable TINYINT(1) DEFAULT 0,         -- 是否可兑换为其他货币
  description VARCHAR(500) DEFAULT '',           -- 后台备注
  extra JSON,                                   -- 预留扩展字段
  create_time DATETIME DEFAULT NOW(),
  update_time DATETIME DEFAULT NOW() ON UPDATE NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 种子数据
INSERT INTO currency_settings (currency_key, display_name, display_symbol, decimal_places, sort_order, is_visible, is_exchangeable) VALUES
('balance',    '余额', '￥', 2, 1, 1, 0),
('points',     '积分', '',   0, 2, 1, 1),
('experience', '经验', 'EXP', 0, 3, 1, 0);
```

**字段说明**：
- `currency_key`: 代码内部标识，不可变。`balance` / `points` 是系统保留，必须存在
- `display_name`: 管理员在后台随时改名，全站即时生效
- `display_icon` / `display_symbol`: 前端展示用
- `decimal_places`: 余额 2 位小数，积分/经验 0 位
- `is_exchangeable`: 是否允许兑换为其他货币

---

## 0.2 统一交易流水表 `currency_transactions`

替代现有的 `balance_records` 和 `points_records` 两张表。**不删除旧表**（保留历史数据），新流水统一写入新表。

```sql
CREATE TABLE IF NOT EXISTS currency_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  user_name VARCHAR(100) DEFAULT '',
  currency_key VARCHAR(30) NOT NULL,            -- 'balance' / 'points' / 'coin' ...
  tx_type ENUM('earn','spend','freeze','unfreeze','refund','exchange','admin_adjust') NOT NULL,
  amount DECIMAL(15,2) NOT NULL,                -- 变动金额（正数）
  balance_before DECIMAL(15,2) DEFAULT 0,       -- 操作前余额
  balance_after DECIMAL(15,2) DEFAULT 0,        -- 操作后余额
  source_type VARCHAR(30) DEFAULT '',            -- mall_order / checkin / invite / post / comment / tip / transfer / task / admin / game / cardkey / membership / refund / exchange
  source_id VARCHAR(50) DEFAULT '',             -- 关联订单号/记录ID
  description VARCHAR(500) DEFAULT '',           -- 人类可读描述
  extra JSON,                                    -- 预留扩展
  create_time DATETIME DEFAULT NOW(),
  INDEX idx_user_currency_time (user_id, currency_key, create_time),
  INDEX idx_user_type (user_id, tx_type),
  INDEX idx_source (source_type, source_id),
  INDEX idx_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

**tx_type 枚举说明**：

| tx_type | 说明 | 触发场景 |
|---------|------|----------|
| earn | 收入 | 签到/发帖奖励/邀请奖励/任务奖励/打赏被赠/活动发放 |
| spend | 支出 | 商城购买/打赏他人/发布付费帖/发送礼物/竞猜下注 |
| freeze | 冻结 | 发布悬赏帖/竞拍出价/下单未付 |
| unfreeze | 解冻 | 冻结返回可用余额 |
| refund | 退款 | 订单退款/悬赏退回 |
| exchange | 兑换 | 积分兑余额/不同货币间兑换 |
| admin_adjust | 后台调整 | 管理员手动增/减余额 |

---

## 0.3 `users` 表新增冻结字段

```sql
ALTER TABLE users
  ADD COLUMN balance_frozen DECIMAL(10,2) DEFAULT 0 AFTER balance,
  ADD COLUMN points_frozen INT DEFAULT 0 AFTER points;
```

冻结逻辑：
- **可用余额** = `balance - balance_frozen`
- **可用积分** = `points - points_frozen`
- 所有消费校验改为 `WHERE balance - balance_frozen >= ？`

---

## 0.4 后端 API：货币配置 CRUD

```
GET    /api/admin/currency-settings          → 取所有货币配置列表
PUT    /api/admin/currency-settings/:key     → 修改某个货币的 display_name / icon / symbol 等
GET    /api/currency-settings                → 前台接口，返回所有 is_visible=1 的货币配置（公开调用）
```

**前台接口响应示例**：

```json
{
  "code": 0,
  "data": [
    { "currency_key": "balance",    "display_name": "余额",   "display_symbol": "￥", "decimal_places": 2 },
    { "currency_key": "points",     "display_name": "金币",   "display_symbol": "",   "decimal_places": 0 },
    { "currency_key": "experience", "display_name": "经验值", "display_symbol": "EXP", "decimal_places": 0 }
  ]
}
```

实现位置：`server/routes/currency.cjs`（新建）

---

## 0.5 后端 API：用户货币查询

```
GET /api/user/balance    → 返回用户所有货币余额（含冻结）
```

**响应示例**：

```json
{
  "code": 0,
  "data": {
    "balance": 150.00,
    "balance_frozen": 0,
    "points": 2300,
    "points_frozen": 0,
    "experience": 850,
    "currencies": [
      { "key": "balance",    "name": "余额",   "available": 150.00, "frozen": 0,     "total": 150.00, "symbol": "￥" },
      { "key": "points",     "name": "金币",   "available": 2300,   "frozen": 0,     "total": 2300,   "symbol": "" },
      { "key": "experience", "name": "经验值", "available": 850,    "frozen": 0,     "total": 850,    "symbol": "EXP" }
    ]
  }
}
```

---

## 0.6 后端 API：用户交易流水

```
GET /api/user/currency-transactions?currency_key=balance&page=1&pageSize=20
```

**响应示例**：

```json
{
  "code": 0,
  "data": {
    "list": [
      {
        "id": 10563,
        "currency_key": "balance",
        "currency_name": "余额",
        "tx_type": "earn",
        "amount": 50.00,
        "balance_after": 200.00,
        "source_type": "tip",
        "source_id": "1032",
        "description": "收到用户「小明」打赏 ￥50.00",
        "create_time": "2026-07-25 15:30:00"
      }
    ],
    "total": 156
  }
}
```

---

## 0.7 后端改造 `account-utils.cjs`

新建 `server/routes/account-utils.cjs`，提供统一货币操作函数（替换现有的 `deductBalance` / `deductPoints`）：

```javascript
// 扣款（带乐观锁）
async function deductCurrency(userId, currencyKey, amount, sourceType, sourceId, description) {
  const col = currencyKey === 'balance' ? 'balance' : currencyKey
  const result = await query(
    `UPDATE users SET ${col} = ${col} - ?, update_time = NOW() WHERE id = ? AND ${col} - IFNULL(${col}_frozen,0) >= ?`,
    [amount, userId, amount]
  )
  if (result.affectedRows === 0) throw new Error('INSUFFICIENT_BALANCE')
  // 写流水
  const user = await query('SELECT username, balance, balance_frozen, points, points_frozen FROM users WHERE id=?', [userId])
  await writeTransaction(userId, user[0], currencyKey, 'spend', amount, sourceType, sourceId, description)
  return true
}

// 入账
async function earnCurrency(userId, currencyKey, amount, sourceType, sourceId, description) { ... }

// 冻结
async function freezeCurrency(userId, currencyKey, amount, sourceType, sourceId, description) { ... }

// 解冻
async function unfreezeCurrency(userId, currencyKey, amount, sourceType, sourceId, description) { ... }

// 退款（解冻+退款 or 直接入账）
async function refundCurrency(userId, currencyKey, amount, sourceType, sourceId, description) { ... }

// 写统一流水
async function writeTransaction(userId, user, currencyKey, txType, amount, sourceType, sourceId, description) {
  const balKey = currencyKey === 'points' ? 'points' : 'balance'
  const before = txType === 'earn' ? user[balKey] : user[balKey] + amount
  const after = txType === 'earn' ? user[balKey] + amount : user[balKey]
  return query(
    `INSERT INTO currency_transactions (user_id,user_name,currency_key,tx_type,amount,balance_before,balance_after,source_type,source_id,description)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [userId, user.username, currencyKey, txType, amount, before, after, sourceType, sourceId, description]
  )
}

module.exports = { deductCurrency, earnCurrency, freezeCurrency, unfreezeCurrency, refundCurrency, writeTransaction }
```

---

## 0.8 前端全局 composable `useCurrency`

新建 `src/composables/useCurrency.ts`：

```typescript
// 全局响应式货币配置，页面启动时调用 /api/currency-settings 获取
import { ref, computed } from 'vue'

interface CurrencyConfig {
  currency_key: string
  display_name: string
  display_symbol: string
  decimal_places: number
}

const currencyMap = ref<Record<string, CurrencyConfig>>({})
let loaded = false

export function useCurrency() {
  async function load() {
    if (loaded) return
    const res = await fetch('/api/currency-settings')
    const data = await res.json()
    if (data.code === 0) {
      for (const c of data.data) {
        currencyMap.value[c.currency_key] = c
      }
      loaded = true
    }
  }

  function name(key: string): string {
    return currencyMap.value[key]?.display_name ?? key
  }

  function symbol(key: string): string {
    return currencyMap.value[key]?.display_symbol ?? ''
  }

  function format(key: string, amount: number): string {
    const cfg = currencyMap.value[key]
    if (!cfg) return String(amount)
    return `${cfg.display_symbol ?? ''}${Number(amount).toFixed(cfg.decimal_places)} ${cfg.display_name}`
  }

  function cfg(key: string): CurrencyConfig | undefined {
    return currencyMap.value[key]
  }

  return { load, name, symbol, format, cfg }
}
```

**用法**：在任何 Vue 组件中 `const { name, format } = useCurrency()`，然后用 `name('balance')` 取货币名，用 `format('balance', 50)` 输出 "￥50.00 余额"。

```
改造前: <span>余额 ￥{{ user.balance }}</span>
改造后: <span>{{ format('balance', user.balance) }}</span>
```

---

# Phase 1：支付基础设施

## 1.1 支付状态机

当前 `mall_orders.status` 只有 `'paid'`、`'shipped'`、`'cancelled'`。需要增加。

### 改造 `mall_orders` 表

```sql
ALTER TABLE mall_orders
  MODIFY COLUMN status ENUM(
    'pending',     -- 待支付（第三方支付场景）
    'paid',        -- 已支付
    'shipped',     -- 已发货（虚拟商品自动置为此状态）
    'completed',   -- 已完成（用户确认收货）
    'refunding',   -- 退款中
    'refunded',    -- 已退款
    'cancelled'    -- 已取消
  ) DEFAULT 'pending',
  ADD COLUMN refund_amount DECIMAL(10,2) DEFAULT 0 COMMENT '退款金额',
  ADD COLUMN refund_time DATETIME NULL COMMENT '退款时间',
  ADD COLUMN refund_reason VARCHAR(500) DEFAULT '' COMMENT '退款原因',
  ADD COLUMN refund_by INT DEFAULT 0 COMMENT '退款操作人',
  ADD COLUMN paid_at DATETIME NULL COMMENT '支付时间',
  ADD COLUMN completed_at DATETIME NULL COMMENT '完成时间';
```

### 订单生命周期

```
用户下单 → pending
  扣款成功 → paid (同时写入 paid_at)
    发货完成 → shipped
      用户确认 → completed

  pending + 超时30分钟 → cancelled（自动）

  paid/shipped + 申请退款 → refunding
    审核通过 → refunded（金钱退回 + 虚拟物品收回）
    审核拒绝 → 退回 paid/shipped
```

### 自动取消 pending 订单

后端定时任务（`server/cron.cjs`，用 `setInterval` 每 5 分钟执行）：

```sql
UPDATE mall_orders SET status='cancelled' WHERE status='pending' AND TIMESTAMPDIFF(MINUTE, create_time, NOW()) >= 30
```

---

## 1.2 支付并发锁

将所有 `deductBalance` / `deductPoints` 替换为新函数 `deductCurrency`（见 0.7 节），内置乐观锁：

```sql
UPDATE users SET balance = balance - ? WHERE id = ? AND balance - IFNULL(balance_frozen,0) >= ?
```

`affectedRows = 0` 表示余额不足或并发冲突，直接拒绝，不继续扣款。

**同时改造**所有现有的余额/积分消费点：
- `server/routes/mall.cjs` L302、L821、L830
- `server/routes/transfer.cjs` 整文件
- `server/routes/game-*.cjs`（游戏下注）

---

## 1.3 退款流程

### 退款 API

```
POST /api/mall/refund/apply       → 用户申请退款 { orderId, reason }
GET  /api/admin/mall/refunds      → 管理员查看退款列表
POST /api/admin/mall/refund/:id   → 管理员处理 { action: 'approve'|'reject', remark }
```

### 退款逻辑

```javascript
async function processRefund(orderId, approved, remark) {
  const conn = await pool.getConnection()
  await conn.beginTransaction()
  try {
    const [order] = await conn.query('SELECT * FROM mall_orders WHERE id=?', [orderId])
    if (!order || !['paid','shipped'].includes(order.status)) {
      throw new Error('订单状态不可退款')
    }

    if (approved) {
      // 1. 原路退回
      await earnCurrency(order.user_id, order.payment_method, order.total_amount - (order.refund_amount||0),
        'refund', `mall_order:${orderId}`, `退款-订单#${order.order_no}: ${remark || ''}`, conn)

      // 2. 修改订单状态
      await conn.query(
        `UPDATE mall_orders SET status='refunded', refund_amount=?, refund_time=NOW(), refund_reason=?, refund_by=? WHERE id=?`,
        [order.total_amount, remark, ctx.userId, orderId]
      )

      // 3. 虚拟商品收回（如果有 user_virtual_items 表）
      await conn.query(
        `UPDATE user_virtual_items SET is_recycled=1, recycled_at=NOW() WHERE user_id=? AND source_type='mall_order' AND source_id=?`,
        [order.user_id, order.order_no]
      )
    } else {
      await conn.query(`UPDATE mall_orders SET status='paid', refund_reason=? WHERE id=?`, [remark, orderId])
    }
    await conn.commit()
  } catch (e) {
    await conn.rollback()
    throw e
  } finally { conn.release() }
}
```

### 退款规则配置

| 商品类型 | 退款策略 |
|---------|---------|
| 虚拟装扮（未穿戴） | 购买后 24h 内可退 |
| 虚拟装扮（已穿戴） | 不可退 |
| 盲盒/抽奖商品 | 不可退 |
| 会员 | 不可退（或按剩余天数比例退） |
| 实物商品 | 按物流状态决定 |

在 `mall_products` 表新增 `refund_policy VARCHAR(20)` 字段（`none`/`24h`/`always`）。

---

## 1.4 混合支付

### 前端支付选择器

在 `BuyDialog.vue` 中增加"混合支付" tab：

```
[ 余额支付 ] [ 积分支付 ] [ 混合支付 ]

混合支付：
  余额支付: [____]  (可用: ￥150.00)
  积分抵扣: [____]  (可用: 2300 积分, 汇率 10:1)
  还需支付: ￥50.00
```

### 后端混合支付路由

```javascript
// POST /api/mall/buy → body.paymentMethod = 'mixed'
// body.mixedPayments = { balance: 30.00, points: 200 }

async function mixedDeduct(userId, username, totalAmount, mixedPayments, description) {
  const conn = await pool.getConnection()
  await conn.beginTransaction()
  try {
    const deductor = { balance: deductCurrency, points: deductCurrency }
    const txId = uuid()

    for (const [currencyKey, amount] of Object.entries(mixedPayments)) {
      if (amount <= 0) continue
      const col = currencyKey
      const result = await conn.query(
        `UPDATE users SET ${col} = ${col} - ? WHERE id = ? AND ${col} - IFNULL(${col}_frozen,0) >= ?`,
        [amount, userId, amount]
      )
      if (result.affectedRows === 0) throw new Error(`${currencyKey} 余额不足`)

      await conn.query(
        `INSERT INTO currency_transactions (...) VALUES (...)` ,
        [userId, username, currencyKey, 'spend', amount, 'mall_order', txId, description]
      )
    }

    await conn.commit()
  } catch (e) {
    await conn.rollback()
    throw e
  } finally { conn.release() }
}
```

---

## 1.5 第三方支付抽象层

### 架构

```
server/
  routes/
    payment-gateway.cjs          ← 统一入口
    gateways/
      alipay.cjs                  ← 支付宝
      wechat.cjs                  ← 微信支付
      apple.cjs                   ← Apple Pay
```

### 统一支付创建接口

```
POST /api/payment/create
{
  gateway: 'alipay',
  amount: 30.00,
  currency: 'balance',            // 充值到哪种货币
  return_url: 'https://xxx/pay/result'
}
→ { code: 0, data: { qrCodeUrl: 'https://...', payUrl: 'alipay://...', orderNo: 'PAY20260725...' } }
```

### 支付回调

```
POST /api/payment/notify/:gateway   ← 第三方 POST 回调
→ 验证签名 → 更新订单 → 入账 → 通知用户
```

### 支付结果轮询

```
GET /api/payment/status/:orderNo   ← 前端轮询
→ { code: 0, data: { status: 'paid' } }
```

### 先在 `payment-config.vue` 中增加配置

```
支付网关管理:
  [支付宝]  已启用  APP ID: [___]  私钥: [___]  回调URL: [___]
  [微信支付] 已关闭  [启用]
```

---


# Phase 2：通知系统改造

## 2.1 现状

所有通知文案硬编码货币名，例如：
- "收到用户「小明」打赏 ￥10.00"
- "签到获得 50 积分"
- "购买商品扣减 ￥5.00"

如果管理员将"积分"改名为"金币"，这些通知文案不变。

## 2.2 改造方案

### 后端通知模板变量

统一通知发送函数 `server/routes/notification.cjs`（新建或扩展现有 `server/routes/email-push.cjs`）：

```javascript
async function sendCurrencyNotification(userId, template, params) {
  // params 中所有金额字段附带货币 key
  // 模板变量： {{amount}} → {{currency_symbol}}{{amount}} {{currency_name}}
  const currencies = await getCurrencyMap()
  const msg = renderTemplate(template, { ...params, currencies })
  // 站内通知 + 推送 + 邮件（可选）
  await insertNotification(userId, msg)
  await pushNotification(userId, msg)
}
```

### 所有通知模板及改造点

| 通知场景 | 原文案 | 改造后文案 |
|---------|-------|-----------|
| 商城购买 | "购买《星空夜幕》，支付 ￥5.00" | "购买《星空夜幕》，支付 {{balance_sym}}5.00 {{balance_name}}" |
| 积分购买 | "购买《xxx》，支付 50 积分" | "购买《xxx》，支付 {{points_sym}}50 {{points_name}}" |
| 打赏被赠 | "收到「小明」打赏 ￥10.00" | "收到「小明」打赏 {{balance_sym}}10.00 {{balance_name}}" |
| 签到 | "签到成功，获得 50 积分" | "签到成功，获得 {{points_sym}}50 {{points_name}}" |
| 邀请 | "邀请好友，获得 100 积分" | "邀请好友，获得 {{points_sym}}100 {{points_name}}" |
| 任务 | "完成任务，获得 200 积分 + ￥5.00" | "完成任务，获得 {{points_sym}}200 {{points_name}} + {{balance_sym}}5.00 {{balance_name}}" |
| 卡密激活 | "激活成功，获得 500 积分" | "激活成功，获得 {{points_sym}}500 {{points_name}}" |
| 退款到账 | "退款 ￥5.00 已到账" | "退款 {{balance_sym}}5.00 {{balance_name}} 已到账" |
| 游戏赢 | "恭喜赢得 50 积分" | "恭喜赢得 {{points_sym}}50 {{points_name}}" |
| 分成到账 | "分成 ¥30.00 已到账" | "分成 {{balance_sym}}30.00 {{balance_name}} 已到账" |
| 会员到期提醒 | "您的会员即将到期" | 不变（无货币信息） |

### 实施

1. 找到所有通知发送点
2. 将占位符改为变量
3. 前端详情页货币余额显示改为 `useCurrency().format()` 动态渲染

---

# Phase 3：全站集成

## 3.1 改造原则

- 只改前端**显示层**：`{{ amount }}元` → `{{ format('balance', amount) }}`
- 不改数据库字段名（`balance`/`points` 保留）
- 不改内部传输变量名
- 后端 API 返回中增加 `currency_name` 字段（由 middleware 自动注入）

### 新增后端 middleware

```javascript
// server/middleware/currency-context.cjs
// 在 app.use 中注册，自动注入所有接口响应
// 所有包含 balance/points 的接口自动附带 currency_name
app.use('/api', async (req, res, next) => {
  // 劫持 res.json，在返回前注入 currency 名称
  const original = res.json.bind(res)
  res.json = function(body) {
    if (body && body.data && !res.locals._currencyInjected) {
      injectCurrencyNames(body, req.app.locals.currencyMap)
      res.locals._currencyInjected = true
    }
    return original(body)
  }
  next()
})
```

也可以用更简单的方式：前端全局 `useCurrency` 方案（0.8 节），不依赖后端改造即可完成所有显示层的替换。

---

## 3.2 前端改造文件清单（按优先级）

### P0 - 全局组件（改动后全局生效）

| 文件 | 改造内容 |
|------|---------|
| `src/composables/useCurrency.ts` | **新建**，全局货币 composable |
| `src/App.vue` 或 `router` beforeEnter | 首次加载时调用 `useCurrency().load()` |

### P1 - 用户信息展示区域

| 文件 | 改造点 |
|------|-------|
| `browse/mine.vue` | 顶部余额/积分显示 |
| `browse/profile.vue` | 他人主页的货币显示 |
| `browse/index.vue` | 首页货币信息 |
| `browse/ranking.vue` | 排行榜货币单位 |
| `components/FeedPostCard.vue` | 帖子卡片的打赏/购买按钮 |
| `admin/user-manage.vue` | 用户表格货币列 |
| `dashboard/console/modules/card-list.vue` | 控制台货币卡片 |
| `views/system/user/index.vue` | PC 后台用户管理 |
| `views/system/user/modules/user-dialog.vue` | 用户编辑弹窗 |
| `admin/mobile-console.vue` | 移动端控制台 |

### P2 - 购买支付流程

| 文件 | 改造点 |
|------|-------|
| `browse/components/BuyDialog.vue` | 购买弹窗 + 混合支付选择器 |
| `browse/components/TipDialog.vue` | 打赏弹窗 |
| `mall/detail.vue` | 商城详情购买按钮 |
| `mall/digital-assets.vue` | 装扮资产页价格 |
| `browse/detail.vue` | App 详情页购买 |
| `browse/purchases.vue` | 购买记录 |
| `browse/records.vue` | 收支记录 |
| `admin/purchase-records.vue` | 后台购买记录 |
| `admin/content-purchases.vue` | 内容购买管理 |

### P3 - 运营模块

| 文件 | 改造点 |
|------|-------|
| `browse/checkin.vue` | 签到奖励显示 |
| `admin/checkin-manage.vue` | 签到管理 |
| `browse/invite.vue` | 邀请奖励显示 |
| `admin/invite-manage.vue` | 邀请管理 |
| `browse/task.vue` | 任务奖励显示 |
| `admin/task-manage.vue` | 任务管理 |
| `admin/cardkey-manage.vue` | 卡密管理 |
| `admin/coupon-manage.vue` | 优惠券管理 |
| `browse/coupon.vue` | 优惠券页面 |
| `browse/membership.vue` | 会员购买 |
| `admin/membership-manage.vue` | 会员管理 |

### P4 - 游戏 & 社区

| 文件 | 改造点 |
|------|-------|
| `community/game-hall.vue` | 游戏大厅 |
| `community/game-dice.vue` | 骰子游戏 |
| `community/game-rps.vue` | 石头剪刀布 |
| `community/game-lottery.vue` | 抽奖游戏 |
| `community/game-card-guess.vue` | 猜牌游戏 |
| `admin/game-center-manage.vue` | 游戏管理 |
| `community/post-detail.vue` | 帖子详情（打赏/付费） |
| `community/post-edit.vue` | 帖子编辑 |
| `browse/components/CommentSection.vue` | 评论区送礼/打赏 |

### P5 - 后台管理

| 文件 | 改造点 |
|------|-------|
| `admin/commission-manage.vue` | 分润管理 |
| `admin/settlement.vue` | 结算管理 |
| `admin/points-manage.vue` | 积分管理 |
| `admin/experience-manage.vue` | 经验管理 |
| `admin/site-config.vue` | 站点配置（新增货币名称字段） |
| `admin/role-manage.vue` | 角色管理 |
| `admin/mall/mall-manage.vue` | 商城管理 |
| `admin/mall/mall-product-create.vue` | 商品创建 |
| `admin/review-mobile.vue` | 审核页面 |
| `admin/post-review.vue` | 帖子审核 |
| `admin/title-manage.vue` | 称号管理 |

### P6 - PC 端主题

| 文件 | 改造点 |
|------|-------|
| `pc/default/views/appstore/mine.vue` | PC 版我的页面 |
| `pc/default/views/appstore/profile.vue` | PC 版个人主页 |
| `pc/default/views/appstore/ranking.vue` | PC 版排行榜 |
| `pc/default/views/appstore/records.vue` | PC 版记录页 |
| `pc/default/views/appstore/membership.vue` | PC 版会员 |
| `pc/default/views/appstore/assets.vue` | PC 版资产 |
| `pc/default/views/appstore/community/post-detail.vue` | PC 版帖子 |
| `pc/default/views/appstore/community/post-edit.vue` | PC 版编辑 |
| `pc/default/views/appstore/community/post-create.vue` | PC 版创建 |
| `pc/default/views/appstore/my-collections-list.vue` | PC 版合集 |

---

## 3.3 后端 API 改造清单

| API | 改造内容 |
|-----|---------|
| `GET /api/user/info` | 返回 `balance/points/experience` 的同时附带 `currency_names` |
| `POST /api/checkin` | 签到调用 `earnCurrency` 替代直接 UPDATE |
| `POST /api/invite/reward` | 邀请调用 `earnCurrency` |
| `POST /api/task/complete` | 任务完成调用 `earnCurrency` |
| `POST /api/cardkey/redeem` | 卡密激活调用 `earnCurrency` |
| `POST /api/mall/buy` | 购买调用 `deductCurrency` |
| `POST /api/tip` | 打赏调用 `deductCurrency` + `earnCurrency` |
| `POST /api/transfer` | 转账调用 `deductCurrency` + `earnCurrency` |
| `POST /api/game/*` | 游戏下注/结算调用 currency 函数 |
| `POST /api/membership/buy` | 会员购买调用 `deductCurrency` |
| `POST /api/admin/user/adjust` | 管理员调整余额调用 `adminAdjustCurrency` |
| `GET /api/user/balance-records` | 改为读 `currency_transactions` 表 |
| `GET /api/user/points-records` | 改为读 `currency_transactions` 表 |

---

## 3.4 实施顺序总结

```
Phase 0: 货币基础设施 (估时 8h)
  0.1  建表 currency_settings (15min)
  0.2  建表 currency_transactions (15min)
  0.3  users 表加冻结字段 (5min)
  0.4  后端 CRUD API (3h)
  0.5  后端用户余额 API (1h)
  0.6  后端交易流水 API (1h)
  0.7  后端 account-utils 改造 (2h)
  0.8  前端 useCurrency composable (1h)

Phase 1: 支付基础设施 (估时 6h)
  1.1  支付状态机 (2h)
  1.2  支付并发锁 (1h)
  1.3  退款流程 (3h)
  1.4  混合支付 (2h - 可延后)
  1.5  第三方支付 (4h - 可延后)

Phase 2: 通知系统改造 (估时 3h)
  2.1  通知模板变量化 (2h)
  2.2  所有通知发送点改造 (1h)

Phase 3: 全站集成 (估时 16h)
  每个文件约 10-30min，~100 个文件
  P0-P6 按优先级逐批改造

总计估时: 33h（不含延后排期项）
```

---

## 附录 A：完整建表 SQL

```sql
-- ==========================================
-- currency_settings: 货币类型配置表
-- ==========================================
CREATE TABLE IF NOT EXISTS currency_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  currency_key VARCHAR(30) NOT NULL UNIQUE,
  display_name VARCHAR(30) NOT NULL DEFAULT '',
  display_icon VARCHAR(500) DEFAULT '',
  display_symbol VARCHAR(10) DEFAULT '',
  decimal_places TINYINT DEFAULT 2,
  sort_order INT DEFAULT 0,
  is_visible TINYINT(1) DEFAULT 1,
  is_exchangeable TINYINT(1) DEFAULT 0,
  description VARCHAR(500) DEFAULT '',
  extra JSON,
  create_time DATETIME DEFAULT NOW(),
  update_time DATETIME DEFAULT NOW() ON UPDATE NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================
-- currency_transactions: 统一交易流水表
-- ==========================================
CREATE TABLE IF NOT EXISTS currency_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  user_name VARCHAR(100) DEFAULT '',
  currency_key VARCHAR(30) NOT NULL,
  tx_type ENUM('earn','spend','freeze','unfreeze','refund','exchange','admin_adjust') NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  balance_before DECIMAL(15,2) DEFAULT 0,
  balance_after DECIMAL(15,2) DEFAULT 0,
  source_type VARCHAR(30) DEFAULT '',
  source_id VARCHAR(50) DEFAULT '',
  description VARCHAR(500) DEFAULT '',
  extra JSON,
  create_time DATETIME DEFAULT NOW(),
  INDEX idx_user_currency_time (user_id, currency_key, create_time),
  INDEX idx_user_type (user_id, tx_type),
  INDEX idx_source (source_type, source_id),
  INDEX idx_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================
-- users 表新增字段
-- ==========================================
ALTER TABLE users
  ADD COLUMN balance_frozen DECIMAL(10,2) DEFAULT 0 AFTER balance,
  ADD COLUMN points_frozen INT DEFAULT 0 AFTER points;

-- ==========================================
-- mall_orders 表改造
-- ==========================================
ALTER TABLE mall_orders
  MODIFY COLUMN status ENUM(
    'pending','paid','shipped','completed','refunding','refunded','cancelled'
  ) DEFAULT 'pending',
  ADD COLUMN refund_amount DECIMAL(10,2) DEFAULT 0,
  ADD COLUMN refund_time DATETIME NULL,
  ADD COLUMN refund_reason VARCHAR(500) DEFAULT '',
  ADD COLUMN refund_by INT DEFAULT 0,
  ADD COLUMN paid_at DATETIME NULL,
  ADD COLUMN completed_at DATETIME NULL;

-- ==========================================
-- 种子数据
-- ==========================================
INSERT INTO currency_settings (currency_key, display_name, display_symbol, decimal_places, sort_order, is_visible) VALUES
('balance',    '余额', '￥', 2, 1, 1),
('points',     '积分', '',   0, 2, 1),
('experience', '经验', 'EXP', 0, 3, 1)
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name);
```

---

## 附录 B：路由注册

```javascript
// server/index.cjs 中新增
app.use('/api/admin/currency-settings', require('./routes/currency.cjs'))    // 管理端 CRUD
app.use('/api/currency-settings', require('./routes/currency.cjs'))           // 前台查询
app.use('/api/user/balance', require('./routes/currency.cjs'))                // 用户余额
app.use('/api/user/currency-transactions', require('./routes/currency.cjs'))  // 交易流水
app.use('/api/payment', require('./routes/payment-gateway.cjs'))              // 第三方支付
app.use('/api/admin/mall/refunds', require('./routes/mall.cjs'))              // 退款管理

// 改造现有路由文件
// mall.cjs: 所有 deductBalance/deductPoints → deductCurrency
// game-*.cjs: 所有下注/结算 → deductCurrency/earnCurrency
// transfer.cjs: 转账 → deductCurrency/earnCurrency
// checkin.cjs: 签到 → earnCurrency
// invite.cjs: 邀请 → earnCurrency
// task.cjs: 任务 → earnCurrency
// cardkey.cjs: 卡密 → earnCurrency
// tip.cjs: 打赏 → deductCurrency/earnCurrency
// membership.cjs: 会员 → deductCurrency
```

---

## 附录 C：改造前后端文件对照

```
√ 新增文件:
  server/routes/currency.cjs            (货币设置 CRUD + 用户余额/流水)
  server/routes/account-utils.cjs       (统一货币操作函数)
  server/routes/payment-gateway.cjs     (第三方支付)
  server/gateways/alipay.cjs            (支付宝)
  server/gateways/wechat.cjs            (微信支付)
  server/cron.cjs                       (定时取消超时订单)
  src/composables/useCurrency.ts        (前端全局货币 composable)

√ 修改文件:
  server/database.cjs                   (建表)
  server/index.cjs                      (路由注册 + middleware)
  server/routes/mall.cjs                (订单流程)
  server/routes/transfer.cjs            (转账流程)
  server/routes/game-*.cjs              (游戏下注/结算)
  server/routes/checkin.cjs             (签到)
  server/routes/invite.cjs              (邀请)
  server/routes/task.cjs                (任务)
  server/routes/cardkey.cjs             (卡密)
  server/routes/tip.cjs                 (打赏)
  server/routes/membership.cjs          (会员)
  server/routes/notification.cjs        (通知模板)
  ~100 个前端 Vue 文件                  (货币名显示替换)
```
