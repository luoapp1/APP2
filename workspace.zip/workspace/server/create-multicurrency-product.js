const mysql = require('mysql2/promise');
(async () => {
  const pool = mysql.createPool({ host:'localhost', user:'artpro', password:'artpro2026', database:'art_design_pro' });
  const uid = 19;
  
  const [result] = await pool.query(
    `INSERT INTO mall_products (category_id,name,price_type,price,original_price,currency_prices,stock,product_type,status,payment_methods,created_by,created_by_name,create_time,update_time)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())`,
    [0, '多币种测试商品', 'balance', 10, 20, 
     JSON.stringify({balance:10, points:100, experience:50, qedxtc:200}), 
     100, 'virtual_manual', 'published',
     JSON.stringify(['balance','points','experience','qedxtc']),
     uid, 'alexmorgan']
  );
  const pid = result.insertId;
  console.log('Product created, id=' + pid);
  
  await pool.query(
    `INSERT INTO mall_product_options (product_id,name,spec_name,price,original_price,points_price,currency_prices,stock,sort_order,card_config,purchase_limit)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [pid, '基础套餐', '', 10, 0, 100, JSON.stringify({balance:8, points:80, experience:40, qedxtc:160}), 50, 0, '{}', 0]
  );
  await pool.query(
    `INSERT INTO mall_product_options (product_id,name,spec_name,price,original_price,points_price,currency_prices,stock,sort_order,card_config,purchase_limit)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [pid, '豪华套餐', '', 30, 0, 300, JSON.stringify({balance:28, points:280, experience:140, qedxtc:560}), 50, 1, '{}', 0]
  );
  
  const [prod] = await pool.query('SELECT * FROM mall_products WHERE id=?', [pid]);
  const [opts] = await pool.query('SELECT * FROM mall_product_options WHERE product_id=? ORDER BY sort_order', [pid]);
  console.log('Product cp:', prod[0].currency_prices);
  console.log('Options:');
  for (const o of opts) {
    console.log(`  id=${o.id} name=${o.name} price=${o.price} points_price=${o.points_price} cp=${o.currency_prices}`);
  }
  
  await pool.end();
})();
