const { query } = require('./database.cjs')

async function cleanDuplicatePaywalls() {
  console.log('=== 开始清理重复 paywall 节点 ===')

  const rows = await query(
    "SELECT id, content FROM community_posts WHERE content IS NOT NULL AND content != '' AND is_deleted = 0"
  )

  let totalPosts = rows.length
  let fixedCount = 0
  let errorCount = 0

  for (const row of rows) {
    try {
      let doc
      try {
        doc = JSON.parse(row.content)
      } catch {
        // Simple string content, skip
        continue
      }

      if (!doc || doc.type !== 'doc' || !Array.isArray(doc.content)) {
        continue
      }

      const paywallIndices = []
      for (let i = 0; i < doc.content.length; i++) {
        if (doc.content[i] && doc.content[i].type === 'paywall') {
          paywallIndices.push(i)
        }
      }

      if (paywallIndices.length <= 1) continue

      // Keep only the first paywall, remove all others
      for (let i = paywallIndices.length - 1; i >= 1; i--) {
        doc.content.splice(paywallIndices[i], 1)
      }

      const newContent = JSON.stringify(doc)
      await query('UPDATE community_posts SET content = ? WHERE id = ?', [newContent, row.id])
      fixedCount++
      console.log(`  [修复] post #${row.id}: ${paywallIndices.length} 个 paywall → 保留 1 个`)
    } catch (err) {
      errorCount++
      console.error(`  [错误] post #${row.id}:`, err.message)
    }
  }

  // Also clean community_drafts
  const draftRows = await query(
    "SELECT id, content FROM community_drafts WHERE content IS NOT NULL AND content != ''"
  )

  let draftFixedCount = 0
  for (const row of draftRows) {
    try {
      let doc
      try {
        doc = JSON.parse(row.content)
      } catch {
        continue
      }

      if (!doc || doc.type !== 'doc' || !Array.isArray(doc.content)) {
        continue
      }

      const paywallIndices = []
      for (let i = 0; i < doc.content.length; i++) {
        if (doc.content[i] && doc.content[i].type === 'paywall') {
          paywallIndices.push(i)
        }
      }

      if (paywallIndices.length <= 1) continue

      for (let i = paywallIndices.length - 1; i >= 1; i--) {
        doc.content.splice(paywallIndices[i], 1)
      }

      const newContent = JSON.stringify(doc)
      await query('UPDATE community_drafts SET content = ? WHERE id = ?', [newContent, row.id])
      draftFixedCount++
      console.log(`  [草稿修复] draft #${row.id}: ${paywallIndices.length} 个 paywall → 保留 1 个`)
    } catch (err) {
      errorCount++
      console.error(`  [错误] draft #${row.id}:`, err.message)
    }
  }

  console.log('=== 清理完成 ===')
  console.log(`总帖子数: ${totalPosts}`)
  console.log(`修复帖子: ${fixedCount}`)
  console.log(`修复草稿: ${draftFixedCount}`)
  console.log(`错误数: ${errorCount}`)
}

cleanDuplicatePaywalls()
  .then(() => {
    console.log('迁移脚本执行完毕')
    process.exit(0)
  })
  .catch((err) => {
    console.error('迁移脚本执行失败:', err)
    process.exit(1)
  })
