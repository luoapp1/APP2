const { query } = require('./database.cjs')
const path = require('path')
const fs = require('fs')
const { execSync } = require('child_process')

const UPLOAD_DIR = path.join(__dirname, 'uploads')

async function main() {
  for (const postId of [16, 17]) {
    const rows = await query('SELECT id, content FROM community_posts WHERE id=?', [postId])
    if (!rows.length) { console.log(`Post ${postId} not found`); continue }
    
    let content
    try { content = JSON.parse(rows[0].content) } catch { console.log(`Post ${postId}: invalid JSON`); continue }
    if (!Array.isArray(content)) continue
    
    let modified = false
    for (const block of content) {
      if (block.type !== 'image' || !Array.isArray(block.images)) continue
      const newImages = []
      for (const img of block.images) {
        if (img.startsWith('data:image/') && img.includes(';base64,')) {
          const [header, b64] = img.split(';base64,')
          const ext = header.split('/')[1] || 'png'
          const tmpName = `migrate_${postId}_${Date.now()}_${Math.random().toString(36).slice(2,6)}.${ext}`
          const tmpPath = path.join(UPLOAD_DIR, tmpName)
          fs.writeFileSync(tmpPath, Buffer.from(b64, 'base64'))
          
          try {
            const result = execSync(
              `curl -s -X POST http://localhost:3001/api/community/upload-image -F "file=@${tmpPath}"`,
              { timeout: 30000, encoding: 'utf8' }
            )
            const resp = JSON.parse(result)
            if (resp.code === 200 && resp.data?.url) {
              console.log(`Post ${postId}: uploaded ${tmpName} -> ${resp.data.url}`)
              newImages.push(resp.data.url)
              modified = true
            } else {
              console.error(`Post ${postId}: upload failed for ${tmpName}: ${result}`)
              newImages.push(img) // keep original
            }
          } catch (e) {
            console.error(`Post ${postId}: upload error: ${e.message}`)
            newImages.push(img)
          }
          try { fs.unlinkSync(tmpPath) } catch {}
        } else {
          newImages.push(img)
        }
      }
      block.images = newImages
    }
    
    if (modified) {
      const newContent = JSON.stringify(content)
      await query('UPDATE community_posts SET content=? WHERE id=?', [newContent, postId])
      const oldLen = rows[0].content.length
      const newLen = newContent.length
      console.log(`Post ${postId} UPDATED: ${oldLen} -> ${newLen} chars (saved ${((1 - newLen/oldLen)*100).toFixed(1)}%)`)
    } else {
      console.log(`Post ${postId}: no base64 images found`)
    }
  }
  process.exit(0)
}

main().catch(e => { console.error(e); process.exit(1) })
