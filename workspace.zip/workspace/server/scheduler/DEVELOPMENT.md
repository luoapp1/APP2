# 定时任务调度系统 — 开发文档

## 一、架构概述

本系统实现"一套业务逻辑，两套执行入口"的统一任务调度方案，消除重复代码，避免维护两份定时业务逻辑导致的 bug。

```
                    ┌──────────────────────────────┐
                    │   server/scheduler/tasks.cjs   │  ← 所有任务函数的唯一定义点
                    │   (6 个任务，单一数据源)        │
                    └──────────┬───────────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            ▼                                     ▼
    ┌───────────────┐                    ┌───────────────┐
    │  开发模式     │                    │  生产模式     │
    │  setInterval  │                    │  宝塔 Cron    │
    └───────┬───────┘                    └───────┬───────┘
            │                                     │
    index.cjs 启动时                     ┌────────┴────────┐
    自动注册所有任务                    ▼                  ▼
                                  HTTP API           Shell 脚本
                              (密钥鉴权)       node run-task.js
```

**核心原则**：所有定时业务逻辑只写在 `server/scheduler/tasks.cjs` 一个文件中。开发模式和宝塔模式调用同一套函数，不做二次实现。

---

## 二、文件结构

```
server/
├── scheduler/
│   ├── tasks.cjs       # 所有任务函数的唯一定义（核心）
│   ├── index.cjs       # 调度器：启动/停止/执行单个任务
│   ├── run-task.js     # 宝塔 Cron 独立 Node 脚本入口
│   └── baota.sh        # 宝塔 Shell 脚本（备选方案）
├── routes/
│   └── task-api.cjs    # 宝塔 HTTP API 路由（密钥鉴权）
└── .env                # 环境变量配置
```

---

## 三、环境变量配置

编辑 `server/.env`：

```env
# ========== 定时任务总开关 ==========
# true = 本地开发，启用代码内置 setInterval
# false = 线上生产，关闭内置定时，全部交给宝塔计划任务
ENABLE_INTERNAL_TASK=false

# ========== 宝塔定时接口安全密钥 ==========
# 线上环境请替换为 32 位以上随机字符串
TASK_SECRET=your-random-task-secret-here
```

**启动日志判断**：
- `ENABLE_INTERNAL_TASK=true`：启动时看到 `[Scheduler] 注册任务: xxx (每 Ns)`
- `ENABLE_INTERNAL_TASK=false`：启动时看到 `ENABLE_INTERNAL_TASK=false，内置定时器未启动（宝塔模式）`

---

## 四、任务清单

| 任务名称 | 周期 | 数据库查询 | 描述 |
|---------|------|-----------|------|
| `session-cleanup` | 5 分钟 | 否 | 清理过期内存会话 |
| `two-factor-cleanup` | 5 分钟 | 否 | 清理 2FA 临时会话 |
| `rate-limit-cleanup` | 5 分钟 | 否 | 清理 fallback 限流 Map |
| `ip-cache-cleanup` | 10 分钟 | 否 | 清理 IP 定位缓存 |
| `scheduled-post-publish` | 1 分钟 | 是 | 发布定时帖子 + 自动隐藏 |
| `auto-confirm-orders` | 1 分钟 | 是 | 过期订单自动确认 + 卖家结算 |

---

## 五、如何添加新任务

只需编辑 `server/scheduler/tasks.cjs` 一个文件：

### Step 1：编写任务函数

```javascript
// server/scheduler/tasks.cjs

async function myNewTask({ log }) {
  try {
    // 任务逻辑
    const result = await query('SELECT ...')
    log(`处理了 ${result.length} 条记录`)
  } catch (e) {
    log(`任务异常: ${e.message}`)
  }
}
```

**约定**：
- `{ log }` 参数提供日志输出函数
- 必须内部捕获异常，不应抛出
- 任务必须幂等（可安全重复执行）
- 函数名以动词开头，语义清晰

### Step 2：注册到 TASK_REGISTRY

```javascript
const TASK_REGISTRY = {
  // ... 已有任务 ...

  'my-new-task': {
    handler: myNewTask,
    intervalMs: 5 * 60 * 1000,    // 内置模式下的执行间隔
    description: '我的新任务描述',
  },
}
```

### Step 3：导出函数（如需外部引用）

```javascript
module.exports = {
  // ... 已有导出 ...
  myNewTask,
}
```

**完成！** 不需要修改任何其他文件。开发模式下自动生效，生产模式下宝塔可通过 `my-new-task` 名称调用。

---

## 六、宝塔面板配置指南

宝塔面板有两种调用方式，任选其一。

### 方式一：Shell 脚本（推荐）

1. 宝塔面板 → 计划任务 → 添加计划任务
2. 任务类型：**Shell 脚本**
3. 脚本内容（示例）：

```bash
# 每 1 分钟 — 定时发布帖子
bash /www/wwwroot/your-project/server/scheduler/baota.sh scheduled-post-publish

# 每 1 分钟 — 自动确认订单
bash /www/wwwroot/your-project/server/scheduler/baota.sh auto-confirm-orders

# 每 5 分钟 — 清理过期会话
bash /www/wwwroot/your-project/server/scheduler/baota.sh session-cleanup

# 每 5 分钟 — 清理 2FA 临时会话
bash /www/wwwroot/your-project/server/scheduler/baota.sh two-factor-cleanup

# 每 5 分钟 — 清理限流条目（需要时）
bash /www/wwwroot/your-project/server/scheduler/baota.sh rate-limit-cleanup

# 每 10 分钟 — 清理 IP 定位缓存
bash /www/wwwroot/your-project/server/scheduler/baota.sh ip-cache-cleanup
```

### 方式二：HTTP API

1. 宝塔面板 → 计划任务 → 添加计划任务
2. 任务类型：**Shell 脚本**

```bash
# 单任务执行
curl -s -X POST "https://your-domain.com/api/scheduler/run/scheduled-post-publish?secret=YOUR_TASK_SECRET"

# 全任务执行（不推荐，建议分拆为单任务以便独立控制间隔）
curl -s -X POST "https://your-domain.com/api/scheduler/run-all?secret=YOUR_TASK_SECRET"
```

### API 接口文档

| 方法 | 路径 | 鉴权 | 描述 |
|-----|------|------|------|
| GET | `/api/scheduler/tasks` | `?secret=` 或 Header `x-task-secret` | 列出所有任务 |
| POST | `/api/scheduler/run/:taskName` | 同上 | 执行单个任务 |
| POST | `/api/scheduler/run-all` | 同上 | 执行全部任务 |

**鉴权方式**（二选一）：
- 查询参数：`?secret=YOUR_TASK_SECRET`
- 请求头：`x-task-secret: YOUR_TASK_SECRET`

鉴权失败返回 `{ code: 403, msg: '鉴权失败' }`。

注意：调度器 API 已自动跳过 CSRF 中间件校验，因此直接 curl 调用即可。

---

## 七、开发环境调试

本地开发设置 `ENABLE_INTERNAL_TASK=true`，启动后观察日志：

```
[Scheduler] ENABLE_INTERNAL_TASK=true，启动内置定时器
[Scheduler] 注册任务: scheduled-post-publish (每 60s)
[Task:scheduled-post-publish] 2026-07-18T16:17:48 无待发布帖子
```

**手动触发单个任务**（无需重启服务）：

```bash
# 通过 HTTP API 手动触发
curl -X POST "http://localhost:3001/api/scheduler/run/scheduled-post-publish?secret=abc123456789tasksecret2026"
```

**模拟宝塔脚本执行**：

```bash
cd server && node scheduler/run-task.js scheduled-post-publish
```

---

## 八、原理说明

### 内存跨模块引用注入

4 个无 DB 查询的任务需要访问其他模块的内存数据结构（Map），通过引用注入解决模块隔离问题：

```javascript
// server/index.cjs 启动时
const twoFactorMod = require('./routes/two-factor.cjs')
taskDefs.setTempSessionsRef(twoFactorMod.tempSessions)

const { cleanupCache } = require('./utils/ip-geo.cjs')
taskDefs.setIPCacheRef(null, cleanupCache)
```

### 幂等性保证

所有任务设计为可安全重复执行：
- 清理类任务：遍历 Map 删除过期条目，重复执行无副作用
- 发布类任务：`WHERE status='scheduled' AND scheduled_time <= NOW()` — 发布后 status 已变更，不会重复发布
- 确认类任务：`WHERE status='shipped' AND confirm_deadline <= NOW()` — 确认后 status 已变更

### 与旧调度器的关系

| 调度器 | 位置 | 引擎 | 职责 |
|--------|------|------|------|
| Cron 调度器 | `server/scheduler.cjs` | node-cron | 每日清理优惠券/DB会话、每小时关闭投票、称号扫描 |
| 统一任务调度器 | `server/scheduler/` | ENABLE_INTERNAL_TASK | 高频内存清理、定时发帖、自动确认订单 |
| 插件调度器 | `server/plugins/scheduler.cjs` | node-cron fallback | 插件模块的 Cron 任务 |

三者互补，互不冲突。`publish-scheduled-posts` 从 Cron 调度器的每小时任务中移除，改为统一调度器每 60 秒执行。

---

## 九、前端内存泄漏修复

本次同时修复了 3 个前端内存泄漏：

| # | 位置 | 问题 | 修复 |
|---|------|------|------|
| 17 | `art-drag-verify/index.vue` | 模块层 + onMounted 重复添加 document 监听器 | 删除模块层监听器，仅保留 onMounted 中的注册 |
| 18 | `profile-edit.vue` | emailTimer 仅在关闭弹窗时清理，离开页面残留 | 添加 `onBeforeUnmount` 清理 |
| 19 | `forget-password/index.vue` | 倒计时期间浏览器后退，定时器泄漏 | 添加 `onBeforeUnmount` 清理 |

---

## 十、常见问题

**Q：宝塔任务显示执行成功但实际未生效？**

确保 `server/.env` 中 `TASK_SECRET` 与 API 调用中的 secret 一致。检查后端日志是否有 `鉴权失败` 记录。

**Q：开发环境下任务执行间隔和注册表中的不一致？**

内置模式下使用 `intervalMs` 作为 `setInterval` 间隔。如需调整，修改 `TASK_REGISTRY` 中对应任务的 `intervalMs` 值。

**Q：如何在服务器上验证 Node 脚本可独立运行？**

```bash
cd /www/wwwroot/your-project/server
node scheduler/run-task.js scheduled-post-publish
# 输出：[Task:scheduled-post-publish] ...完成
```

确保 `.env` 中数据库配置正确，因为 `run-task.js` 会加载 `.env` 并连接数据库。

**Q：添加新任务后需要重启服务吗？**

- 开发模式：需要重启（`setInterval` 在启动时注册）
- 生产模式：不需要（宝塔 Cron 每次调用独立进程）
