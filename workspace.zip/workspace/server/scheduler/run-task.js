#!/usr/bin/env node
'use strict'

/**
 * 宝塔计划任务 — 独立 Node 脚本入口
 *
 * 宝塔 Cron 配置示例：
 *   cd /www/wwwroot/your-project/server && node scheduler/run-task.js scheduled-post-publish
 *   cd /www/wwwroot/your-project/server && node scheduler/run-task.js auto-confirm-orders
 *   cd /www/wwwroot/your-project/server && node scheduler/run-task.js --all
 *
 * 宝塔可配置每 N 分钟执行一次，替代 Node 自带 setInterval
 */

const path = require('path')

// 手动加载 .env（不依赖 dotenv 包）
function loadEnv() {
  const envPath = path.join(__dirname, '..', '.env')
  const fs = require('fs')
  try {
    const content = fs.readFileSync(envPath, 'utf-8')
    for (const line of content.split('\n')) {
      const trimmed = line.trim()
      if (!trimmed || trimmed.startsWith('#')) continue
      const eqIdx = trimmed.indexOf('=')
      if (eqIdx === -1) continue
      const key = trimmed.slice(0, eqIdx).trim()
      const val = trimmed.slice(eqIdx + 1).trim()
      if (key && !process.env[key]) {
        process.env[key] = val
      }
    }
  } catch (_) { /* .env not found */ }
}

loadEnv()

const taskName = process.argv[2]
const { runTask, getAllTaskNames } = require('./index.cjs')

async function main() {
  if (!taskName || taskName === '--all') {
    const names = getAllTaskNames()
    for (const name of names) {
      console.log(`--- 执行任务: ${name} ---`)
      await runTask(name)
    }
    console.log('--- 全部完成 ---')
    return
  }

  await runTask(taskName)
  console.log(`[${taskName}] 完成`)
}

main().catch(e => {
  console.error('任务执行失败:', e.message)
  process.exit(1)
})
