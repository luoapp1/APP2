'use strict'

/**
 * 统一任务注册中心 — 所有定时业务逻辑的单一定义点
 *
 * 每项任务的 handler 函数接受 { log } 参数：
 *   - log(msg)  输出日志
 *
 * 约定：
 *   - handler 必须是幂等的（可安全重复执行）
 *   - handler 内部自行处理异常，不应抛出
 *   - 任务无返回值
 */

const { query } = require('../database.cjs')
const { addPoints, addBalance } = require('../routes/account-utils.cjs')
const systemRoutes = require('../routes/system.cjs')
const sessions = systemRoutes.sessions
const SESSION_TTL = 24 * 60 * 60 * 1000

// ============================================================
// 1. 清理过期会话 (5 min)
// ============================================================
async function cleanupSessions({ log }) {
  const now = Date.now()
  let count = 0
  for (const [token, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      count++
    }
  }
  log(`清理 ${count} 个过期会话`)
}

// ============================================================
// 2. 清理 2FA 临时会话 (5 min)
// ============================================================
let _tempSessionsRef = null
function setTempSessionsRef(ref) { _tempSessionsRef = ref }

async function cleanupTwoFactorSessions({ log }) {
  if (!_tempSessionsRef) return log('2FA会话引用未注入，跳过')
  const now = Date.now()
  let count = 0
  for (const [key, val] of _tempSessionsRef) {
    if (now - val.createdAt > 5 * 60 * 1000) {
      _tempSessionsRef.delete(key)
      count++
    }
  }
  log(`清理 ${count} 个2FA临时会话`)
}

// ============================================================
// 3. 清理速率限制条目 (5 min)
// ============================================================
let _rateLimitMapRef = null
function setRateLimitMapRef(ref) { _rateLimitMapRef = ref }

async function cleanupRateLimitEntries({ log }) {
  if (!_rateLimitMapRef) return log('限流Map引用未注入，跳过')
  const now = Date.now()
  let count = 0
  for (const [ip, entry] of _rateLimitMapRef) {
    if (now > entry.resetAt) {
      _rateLimitMapRef.delete(ip)
      count++
    }
  }
  log(`清理 ${count} 个限流条目`)
}

// ============================================================
// 4. 清理 IP 定位缓存 (10 min)
// ============================================================
let _ipCacheRef = null
let _ipCleanupFn = null
function setIPCacheRef(ref, cleanupFn) { _ipCacheRef = ref; _ipCleanupFn = cleanupFn }

async function cleanupIPCache({ log }) {
  if (_ipCleanupFn) {
    _ipCleanupFn()
    log('IP定位缓存已清理')
  } else {
    log('IP缓存清理函数未注入，跳过')
  }
}

// ============================================================
// 5. 社区定时发帖与自动隐藏 (60 s) — 含 DB 查询
// ============================================================
async function publishScheduledPosts({ log }) {
  try {
    const now = new Date()

    // 发布定时帖子
    const scheduledPosts = await query(
      `SELECT id, user_id, user_name, user_avatar, section_id, title FROM community_posts
       WHERE status='scheduled' AND scheduled_time IS NOT NULL AND scheduled_time <= ?`,
      [now]
    )
    for (const post of scheduledPosts) {
      const sec = await query('SELECT review_required FROM community_sections WHERE id=? AND is_deleted=0', [post.section_id])
      const reviewRequired = sec.length > 0 && sec[0].review_required === 1
      const newStatus = reviewRequired ? 'pending' : 'published'
      await query('UPDATE community_posts SET status=?, update_time=NOW() WHERE id=?', [newStatus, post.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post.section_id])
      const msg = reviewRequired
        ? `您的帖子「${post.title}」已由系统自动提交，正在等待审核。`
        : `您的帖子「${post.title}」已按预定时间自动发布。`
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
        ['帖子发布提醒', msg, 'post_scheduled', 'post', post.id, post.user_id]
      )
      log(`发布帖子 #${post.id}《${post.title}》→ ${newStatus}`)
    }
    if (!scheduledPosts.length) log('无待发布帖子')

    // 自动隐藏到期帖子
    const hidePosts = await query(
      `SELECT id, user_id, title FROM community_posts
       WHERE auto_hide_at IS NOT NULL AND auto_hide_at <= ? AND is_hidden=0`,
      [now]
    )
    for (const post of hidePosts) {
      await query('UPDATE community_posts SET is_hidden=1, update_time=NOW() WHERE id=?', [post.id])
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
        ['帖子隐藏提醒', `您的帖子「${post.title}」已按预定时间自动隐藏。`, 'post_hidden', 'post', post.id, post.user_id]
      )
      log(`隐藏帖子 #${post.id}《${post.title}》`)
    }
  } catch (e) {
    log(`社区发帖任务异常: ${e.message}`)
  }
}

// ============================================================
// 6. 自动确认过期订单 (60 s) — 含 DB 查询与卖家结算
// ============================================================
async function autoConfirmExpiredOrders({ log }) {
  try {
    const expired = await query(
      `SELECT id FROM orders WHERE status='shipped' AND confirm_deadline IS NOT NULL AND confirm_deadline <= NOW()`
    )
    if (!expired.length) return log('无待自动确认订单')

    for (const o of expired) {
      try {
        const orders = await query('SELECT * FROM orders WHERE id=?', [o.id])
        if (!orders.length) continue
        const order = orders[0]
        await query('UPDATE orders SET status=?, confirmed_at=NOW() WHERE id=?', ['completed', o.id])

        if (order.seller_id > 0) {
          // 获取卖家积分倍数
          let multiplier = 1.0
          try {
            const mlRows = await query(
              `SELECT ml.points_multiplier FROM user_memberships um
               JOIN membership_levels ml ON um.level_id = ml.id
               WHERE um.user_id=? AND um.status='active' AND ml.status='1'
               ORDER BY ml.tier ASC LIMIT 1`,
              [order.seller_id]
            )
            multiplier = mlRows.length > 0 ? (Number(mlRows[0].points_multiplier) || 1.0) : 1.0
          } catch {}

          const [seller] = await query('SELECT username FROM users WHERE id=?', [order.seller_id])
          const sellerName = seller ? seller.username : `user${order.seller_id}`

          if (order.pay_type === 'points') {
            const totalPoints = Math.round(Number(order.total_amount || order.paid_amount) * multiplier)
            await addPoints(order.seller_id, sellerName, totalPoints,
              `订单自动确认: ${order.order_desc || order.order_no}`,
              `订单完成积分`)
          } else {
            await addBalance(order.seller_id, sellerName, Number(order.paid_amount),
              `订单自动确认: ${order.order_desc || order.order_no}`,
              `订单完成余额`)
          }
        }
        log(`自动确认订单 #${o.id}`)
      } catch {}
    }
  } catch (e) {
    log(`自动确认订单任务异常: ${e.message}`)
  }
}

// ============================================================
// 7. 清理过期回收站条目 (1 hour) — 基于会员等级的保留天数
// ============================================================
async function cleanupExpiredRecycleBin({ log }) {
  try {
    const result = await query(
      `DELETE rb FROM recycle_bin rb
       LEFT JOIN membership_levels ml ON ml.id = rb.user_level_id
       WHERE ml.recycle_retention_days > 0
         AND rb.create_time < DATE_SUB(NOW(), INTERVAL ml.recycle_retention_days DAY)`
    )
    const count = result.affectedRows || 0
    if (count > 0) log(`清理 ${count} 条过期回收站记录`)
    else log('无过期回收站记录')
  } catch (e) {
    log(`回收站清理任务异常: ${e.message}`)
  }
}

// ============================================================
// 引用注入
// ============================================================
let _titleCheckerRef = null
function setTitleCheckerRef(fn) { _titleCheckerRef = fn }

// ============================================================
// 8. 称号自动扫描 (60 min)
// ============================================================
async function scanAndGrantTitles({ log }) {
  if (!_titleCheckerRef) return log('称号扫描器未注入，跳过')
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_interval'")
    const intervalMin = rows.length > 0 ? Math.max(1, Math.min(1440, parseInt(rows[0].config_value) || 60)) : 60
    let offset = 0
    const checkpoint = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_offset'")
    if (checkpoint && checkpoint.length > 0) {
      offset = parseInt(checkpoint[0].config_value) || 0
      log(`从断点恢复 offset=${offset}`)
    }
    const pageSize = 100
    const scanTimeout = 30 * 60 * 1000
    const startTime = Date.now()
    let scanned = 0
    while (true) {
      if (Date.now() - startTime > scanTimeout) {
        log(`扫描超时，记录断点 offset=${offset}`)
        await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_offset',?, '称号扫描断点') ON DUPLICATE KEY UPDATE config_value=?", [String(offset), String(offset)])
        break
      }
      const users = await query('SELECT id FROM users ORDER BY id LIMIT ? OFFSET ?', [pageSize, offset])
      if (!users.length) break
      await concurrencyLimit(10, users, u => _titleCheckerRef(u.id))
      scanned += users.length
      offset += pageSize
    }
    if (Date.now() - startTime <= scanTimeout) {
      await query("DELETE FROM sys_config WHERE config_key='title_scan_offset'")
    }
    await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_last',NOW(),'称号最后扫描时间') ON DUPLICATE KEY UPDATE config_value=NOW()")
    log(`扫描完成，共处理 ${scanned} 个用户，间隔 ${intervalMin} 分钟`)
  } catch (e) {
    log(`扫描出错: ${e.message}`)
  }
}

// ============================================================
// 9. 会员自动签到 (60 s)
// ============================================================
async function autoCheckinMembers({ log }) {
  try {
    const now = new Date()
    const hh = String(now.getHours()).padStart(2, '0')
    const mm = String(now.getMinutes()).padStart(2, '0')
    const currentTime = hh + ':' + mm
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`

    const levels = await query(
      'SELECT id, name, auto_checkin_time FROM membership_levels WHERE auto_checkin=1 AND status=?',
      ['1']
    )
    if (!levels.length) return log('无启用自动签到的会员等级')

    let totalChecked = 0
    for (const lv of levels) {
      if (lv.auto_checkin_time !== currentTime) continue

      const users = await query(
        `SELECT u.id FROM users u
         WHERE u.level_id > 0
         AND (u.expire_time IS NULL OR u.expire_time > NOW())
         AND u.level_id = ?
         AND u.id NOT IN (SELECT user_id FROM checkin_records WHERE checkin_date = ?)`,
        [lv.id, today]
      )
      if (!users.length) continue

      const checkinModule = require('../routes/checkin.cjs')
      for (const u of users) {
        try {
          const result = await checkinModule.performAutoCheckin(u.id)
          if (result.success) totalChecked++
        } catch (e) {
          log(`自动签到用户#${u.id} 失败: ${e.message}`)
        }
      }
    }

    if (totalChecked > 0) log(`自动签到完成，共处理 ${totalChecked} 人`)
    else log('无待自动签到用户')
  } catch (e) {
    log(`自动签到任务异常: ${e.message}`)
  }
}

// ============================================================
// 10. 会员自动领取礼包 (60 s)
// ============================================================
async function autoClaimMemberGifts({ log }) {
  try {
    const { performAutoClaimGifts } = require('../routes/content.cjs')

    const users = await query(
      `SELECT u.id, u.username FROM users u
       WHERE u.level_id > 0
       AND (u.expire_time IS NULL OR u.expire_time > NOW())`
    )
    if (!users.length) return log('无活跃会员用户')

    let totalDaily = 0
    let totalBirthday = 0
    for (const u of users) {
      try {
        const result = await performAutoClaimGifts(u.id)
        if (result.daily) totalDaily++
        if (result.birthday) totalBirthday++
      } catch (e) {
        log(`自动领取礼包用户#${u.id} 失败: ${e.message}`)
      }
    }

    if (totalDaily > 0 || totalBirthday > 0) {
      log(`自动领取完成: 定时礼包 ${totalDaily} 人, 生日礼包 ${totalBirthday} 人`)
    }
  } catch (e) {
    log(`自动礼包任务异常: ${e.message}`)
  }
}

// ============================================================
// 任务注册表 — 对外统一的配置入口
// ============================================================

const TASK_REGISTRY = {
  'session-cleanup':         { handler: cleanupSessions,          intervalMs: 5 * 60 * 1000, description: '清理过期会话' },
  'two-factor-cleanup':      { handler: cleanupTwoFactorSessions,  intervalMs: 5 * 60 * 1000, description: '清理2FA临时会话' },
  'rate-limit-cleanup':      { handler: cleanupRateLimitEntries,   intervalMs: 5 * 60 * 1000, description: '清理速率限制条目' },
  'ip-cache-cleanup':        { handler: cleanupIPCache,            intervalMs: 10 * 60 * 1000, description: '清理IP定位缓存' },
  'scheduled-post-publish':  { handler: publishScheduledPosts,     intervalMs: 60 * 1000, description: '定时发布社区帖子' },
  'auto-confirm-orders':     { handler: autoConfirmExpiredOrders,  intervalMs: 60 * 1000, description: '自动确认过期订单' },
  'recycle-cleanup':         { handler: cleanupExpiredRecycleBin,   intervalMs: 60 * 60 * 1000, description: '清理过期回收站条目' },
  'title-scan':              { handler: scanAndGrantTitles,         intervalMs: 60 * 60 * 1000, description: '扫描用户自动授予称号' },
  'auto-checkin':            { handler: autoCheckinMembers,        intervalMs: 60 * 1000,     description: '会员自动签到' },
  'auto-claim-gifts':         { handler: autoClaimMemberGifts,      intervalMs: 2 * 60 * 60 * 1000, description: '会员自动领取礼包' },
}

/**
 * 获取所有任务名称
 */
function getAllTaskNames() {
  return Object.keys(TASK_REGISTRY)
}

/**
 * 获取任务配置
 */
function getTaskConfig(name) {
  return TASK_REGISTRY[name] || null
}

module.exports = {
  // 引用注入（用于跨模块共享内存数据结构）
  setTempSessionsRef,
  setRateLimitMapRef,
  setIPCacheRef,
  setTitleCheckerRef,

  // 任务注册表
  TASK_REGISTRY,
  getAllTaskNames,
  getTaskConfig,

  // 直接导出任务函数（供 CLI / HTTP 调用）
  cleanupSessions,
  cleanupTwoFactorSessions,
  cleanupRateLimitEntries,
  cleanupIPCache,
  publishScheduledPosts,
  autoConfirmExpiredOrders,
  cleanupExpiredRecycleBin,
  autoCheckinMembers,
  autoClaimMemberGifts,
}
