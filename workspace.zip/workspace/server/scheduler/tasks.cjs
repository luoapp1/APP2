'use strict'

/**
 * 统一任务注册中心 — 所有定时业务逻辑的单一定义点
 *
 * 每项任务的 handler 函数接受 { log } 参数：
 *   - log(msg)  输出日志
 *
 * 约定：
 *   - handler 必须是幂等的（可安全重复执行）
 *   - handler 内部自行处理异常，不应抛出
 *   - 任务无返回值
 */

const { query } = require('../database.cjs')
const systemRoutes = require('../routes/system.cjs')
const sessions = systemRoutes.sessions
const SESSION_TTL = 24 * 60 * 60 * 1000

// ============================================================
// 1. 清理过期会话 (5 min)
// ============================================================
async function cleanupSessions({ log }) {
  const now = Date.now()
  let count = 0
  for (const [token, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      count++
    }
  }
  log(`清理 ${count} 个过期会话`)
}

// ============================================================
// 2. 清理 2FA 临时会话 (5 min)
// ============================================================
let _tempSessionsRef = null
function setTempSessionsRef(ref) { _tempSessionsRef = ref }

async function cleanupTwoFactorSessions({ log }) {
  if (!_tempSessionsRef) return log('2FA会话引用未注入，跳过')
  const now = Date.now()
  let count = 0
  for (const [key, val] of _tempSessionsRef) {
    if (now - val.createdAt > 5 * 60 * 1000) {
      _tempSessionsRef.delete(key)
      count++
    }
  }
  log(`清理 ${count} 个2FA临时会话`)
}

// ============================================================
// 3. 清理速率限制条目 (5 min)
// ============================================================
let _rateLimitMapRef = null
function setRateLimitMapRef(ref) { _rateLimitMapRef = ref }

async function cleanupRateLimitEntries({ log }) {
  if (!_rateLimitMapRef) return log('限流Map引用未注入，跳过')
  const now = Date.now()
  let count = 0
  for (const [ip, entry] of _rateLimitMapRef) {
    if (now > entry.resetAt) {
      _rateLimitMapRef.delete(ip)
      count++
    }
  }
  log(`清理 ${count} 个限流条目`)
}

// ============================================================
// 4. 清理 IP 定位缓存 (10 min)
// ============================================================
let _ipCacheRef = null
let _ipCleanupFn = null
function setIPCacheRef(ref, cleanupFn) { _ipCacheRef = ref; _ipCleanupFn = cleanupFn }

async function cleanupIPCache({ log }) {
  if (_ipCleanupFn) {
    _ipCleanupFn()
    log('IP定位缓存已清理')
  } else {
    log('IP缓存清理函数未注入，跳过')
  }
}

// ============================================================
// 5. 社区定时发帖与自动隐藏 (60 s) — 含 DB 查询
// ============================================================
async function publishScheduledPosts({ log }) {
  try {
    const now = new Date()

    // 发布定时帖子
    const scheduledPosts = await query(
      `SELECT id, user_id, user_name, user_avatar, section_id, title FROM community_posts
       WHERE status='scheduled' AND scheduled_time IS NOT NULL AND scheduled_time <= ?`,
      [now]
    )
    for (const post of scheduledPosts) {
      const sec = await query('SELECT review_required FROM community_sections WHERE id=? AND is_deleted=0', [post.section_id])
      const reviewRequired = sec.length > 0 && sec[0].review_required === 1
      const newStatus = reviewRequired ? 'pending' : 'published'
      await query('UPDATE community_posts SET status=?, update_time=NOW() WHERE id=?', [newStatus, post.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post.section_id])
      const msg = reviewRequired
        ? `您的帖子「${post.title}」已由系统自动提交，正在等待审核。`
        : `您的帖子「${post.title}」已按预定时间自动发布。`
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
        ['帖子发布提醒', msg, 'post_scheduled', 'post', post.id, post.user_id]
      )
      log(`发布帖子 #${post.id}《${post.title}》→ ${newStatus}`)
    }
    if (!scheduledPosts.length) log('无待发布帖子')

    // 自动隐藏到期帖子
    const hidePosts = await query(
      `SELECT id, user_id, title FROM community_posts
       WHERE auto_hide_at IS NOT NULL AND auto_hide_at <= ? AND is_hidden=0`,
      [now]
    )
    for (const post of hidePosts) {
      await query('UPDATE community_posts SET is_hidden=1, update_time=NOW() WHERE id=?', [post.id])
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
        ['帖子隐藏提醒', `您的帖子「${post.title}」已按预定时间自动隐藏。`, 'post_hidden', 'post', post.id, post.user_id]
      )
      log(`隐藏帖子 #${post.id}《${post.title}》`)
    }
  } catch (e) {
    log(`社区发帖任务异常: ${e.message}`)
  }
}

// ============================================================
// 6. 自动确认过期订单 (60 s) — 含 DB 查询与卖家结算
// ============================================================
async function autoConfirmExpiredOrders({ log }) {
  try {
    const expired = await query(
      `SELECT id FROM orders WHERE status='shipped' AND confirm_deadline IS NOT NULL AND confirm_deadline <= NOW()`
    )
    if (!expired.length) return log('无待自动确认订单')

    for (const o of expired) {
      try {
        const orders = await query('SELECT * FROM orders WHERE id=?', [o.id])
        if (!orders.length) continue
        const order = orders[0]
        await query('UPDATE orders SET status=?, confirmed_at=NOW() WHERE id=?', ['completed', o.id])

        if (order.seller_id > 0) {
          // 获取卖家积分倍数
          let multiplier = 1.0
          try {
            const mlRows = await query(
              `SELECT ml.points_multiplier FROM user_memberships um
               JOIN membership_levels ml ON um.level_id = ml.id
               WHERE um.user_id=? AND um.status='active' AND ml.status='1'
               ORDER BY ml.tier ASC LIMIT 1`,
              [order.seller_id]
            )
            multiplier = mlRows.length > 0 ? (Number(mlRows[0].points_multiplier) || 1.0) : 1.0
          } catch {}

          if (order.pay_type === 'points') {
            const totalPoints = Math.round(Number(order.total_amount || order.paid_amount) * multiplier)
            await query('UPDATE users SET points = points + ? WHERE id=?', [totalPoints, order.seller_id])
            await query(
              `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
               VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
              [order.seller_id, order.seller_id, totalPoints, order.seller_id, order.order_type,
               `自动结算${multiplier !== 1 ? '(' + multiplier.toFixed(1) + '倍积分)' : ''}: ${order.order_desc || order.order_no}`, o.id, 'auto_settle']
            )
          } else {
            await query('UPDATE users SET balance = balance + ? WHERE id=?', [order.paid_amount, order.seller_id])
            await query(
              `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
               VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
              [order.seller_id, order.seller_id, order.paid_amount, order.seller_id, order.order_type,
               `自动结算: ${order.order_desc || order.order_no}`, o.id, 'auto_settle']
            )
          }
        }
        log(`自动确认订单 #${o.id}`)
      } catch {}
    }
  } catch (e) {
    log(`自动确认订单任务异常: ${e.message}`)
  }
}

// ============================================================
// 任务注册表 — 对外统一的配置入口
// ============================================================

const TASK_REGISTRY = {
  'session-cleanup':         { handler: cleanupSessions,          intervalMs: 5 * 60 * 1000, description: '清理过期会话' },
  'two-factor-cleanup':      { handler: cleanupTwoFactorSessions,  intervalMs: 5 * 60 * 1000, description: '清理2FA临时会话' },
  'rate-limit-cleanup':      { handler: cleanupRateLimitEntries,   intervalMs: 5 * 60 * 1000, description: '清理速率限制条目' },
  'ip-cache-cleanup':        { handler: cleanupIPCache,            intervalMs: 10 * 60 * 1000, description: '清理IP定位缓存' },
  'scheduled-post-publish':  { handler: publishScheduledPosts,     intervalMs: 60 * 1000, description: '定时发布社区帖子' },
  'auto-confirm-orders':     { handler: autoConfirmExpiredOrders,  intervalMs: 60 * 1000, description: '自动确认过期订单' },
}

/**
 * 获取所有任务名称
 */
function getAllTaskNames() {
  return Object.keys(TASK_REGISTRY)
}

/**
 * 获取任务配置
 */
function getTaskConfig(name) {
  return TASK_REGISTRY[name] || null
}

module.exports = {
  // 引用注入（用于跨模块共享内存数据结构）
  setTempSessionsRef,
  setRateLimitMapRef,
  setIPCacheRef,

  // 任务注册表
  TASK_REGISTRY,
  getAllTaskNames,
  getTaskConfig,

  // 直接导出任务函数（供 CLI / HTTP 调用）
  cleanupSessions,
  cleanupTwoFactorSessions,
  cleanupRateLimitEntries,
  cleanupIPCache,
  publishScheduledPosts,
  autoConfirmExpiredOrders,
}
