#!/bin/bash
# ============================================================
# 宝塔计划任务 Shell 脚本示例
#
# 在宝塔面板"计划任务"中添加，选择"Shell脚本"类型
# 推荐配置：
#
#   任务名称                 执行周期      脚本内容
#   ─────────────────────   ──────────    ──────────────────────────────────
#   定时发布社区帖子         每 1 分钟     bash /www/wwwroot/your-project/server/scheduler/baota.sh scheduled-post-publish
#   自动确认过期订单         每 1 分钟     bash /www/wwwroot/your-project/server/scheduler/baota.sh auto-confirm-orders
#   清理过期会话             每 5 分钟     bash /www/wwwroot/your-project/server/scheduler/baota.sh session-cleanup
#   清理2FA临时会话          每 5 分钟     bash /www/wwwroot/your-project/server/scheduler/baota.sh two-factor-cleanup
#   清理速率限制条目         每 5 分钟     bash /www/wwwroot/your-project/server/scheduler/baota.sh rate-limit-cleanup
#   清理IP定位缓存           每 10 分钟    bash /www/wwwroot/your-project/server/scheduler/baota.sh ip-cache-cleanup
#
# ============================================================

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TASK_NAME="${1:---all}"

cd "$PROJECT_DIR" || exit 1
node scheduler/run-task.js "$TASK_NAME"
