'use strict'

/**
 * 统一任务调度器 — 根据环境变量自动选择运行模式
 *
 * 模式一（本地开发）：ENABLE_INTERNAL_TASK=true → 启动内置 setInterval
 * 模式二（线上生产）：ENABLE_INTERNAL_TASK=false → 仅导出任务，宝塔 Cron 调用
 *
 * 用法：
 *   const scheduler = require('./scheduler')
 *
 *   // 注入跨模块引用（在 require 后、app 启动前调用）
 *   scheduler.injectRefs({ tempSessions, rateLimitMap, ipCache })
 *
 *   // 启动内置定时器（仅开发环境）
 *   scheduler.start()
 */

const { TASK_REGISTRY, getAllTaskNames } = require('./tasks.cjs')

// ============================================================
// 定时器管理
// ============================================================
const _timers = []
let _started = false

/**
 * 启动内置定时器模式（ENABLE_INTERNAL_TASK=true 时调用）
 */
function start() {
  if (_started) return
  const enabled = (process.env.ENABLE_INTERNAL_TASK || 'false').toLowerCase() === 'true'

  if (!enabled) {
    console.log('[Scheduler] ENABLE_INTERNAL_TASK=false，内置定时器未启动（宝塔模式）')
    return
  }

  console.log('[Scheduler] ENABLE_INTERNAL_TASK=true，启动内置定时器')

  let idx = 0
  for (const [name, config] of Object.entries(TASK_REGISTRY)) {
    const log = (msg) => console.log(`[Task:${name}] ${new Date().toISOString().slice(0, 19)} ${msg}`)
    const timer = setInterval(() => {
      config.handler({ log })
    }, config.intervalMs)
    _timers.push({ name, timer })

    const delayMs = Math.min(idx * 5000, 60000)
    setTimeout(() => config.handler({ log }), delayMs)
    idx++

    console.log(`[Scheduler] 注册任务: ${name} (每 ${config.intervalMs / 1000}s, 首次延迟 ${delayMs / 1000}s)`)
  }

  _started = true
}

/**
 * 停止所有内置定时器
 */
function stop() {
  for (const { name, timer } of _timers) {
    clearInterval(timer)
    console.log(`[Scheduler] 停止任务: ${name}`)
  }
  _timers.length = 0
  _started = false
}

/**
 * 执行指定任务（供 HTTP / CLI 调用）
 */
async function runTask(name) {
  const config = TASK_REGISTRY[name]
  if (!config) throw new Error(`未知任务: ${name}`)

  const log = (msg) => console.log(`[Task:${name}] ${msg}`)
  await config.handler({ log })
}

module.exports = { start, stop, runTask, getAllTaskNames, TASK_REGISTRY }
