const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return
  const lines = fs.readFileSync(filePath, 'utf-8').split('\n')
  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const eqIdx = trimmed.indexOf('=')
    if (eqIdx === -1) continue
    const key = trimmed.slice(0, eqIdx).trim()
    const val = trimmed.slice(eqIdx + 1).trim()
    if (key && !process.env[key]) {
      process.env[key] = val
    }
  }
}

loadEnvFile(path.join(__dirname, '.env'))

module.exports = {
  mysql: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    user: process.env.DB_USER || 'artpro',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'art_design_pro'
  },
  get encryptionKey() {
    if (process.env.STORAGE_ENCRYPTION_KEY) return process.env.STORAGE_ENCRYPTION_KEY
    const generated = crypto.randomBytes(32).toString('hex')
    process.env.STORAGE_ENCRYPTION_KEY = generated
    console.warn('[config] STORAGE_ENCRYPTION_KEY 未设置，已自动生成临时密钥：', generated.slice(0, 8) + '...')
    return generated
  }
}
