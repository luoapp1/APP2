/**
 * 数据库配置文件 (MySQL)
 * 所有敏感信息均从环境变量读取，无默认值则需要手动设置
 */

module.exports = {
  /** MySQL 数据库连接配置 */
  mysql: {
    /** 数据库主机地址，默认 127.0.0.1 (本地) */
    host: process.env.DB_HOST || '127.0.0.1',
    /** 数据库端口号，默认 3306 (MySQL 标准端口) */
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    /** 数据库用户名 */
    user: process.env.DB_USER || 'artpro',
    /** 数据库密码 */
    password: process.env.DB_PASSWORD || 'artpro2026',
    /** 数据库名称 */
    database: process.env.DB_NAME || 'art_design_pro'
  },
  /** 存储加密密钥 (至少 32 位，用于加密云存储 OSS/COS 凭据) */
  encryptionKey: process.env.STORAGE_ENCRYPTION_KEY || 'art-design-pro-enc-key-2026!@#SECURE'
}
