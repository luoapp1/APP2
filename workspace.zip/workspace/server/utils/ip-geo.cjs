const https = require('https')
const http = require('http')
const crypto = require('crypto')
const { query } = require('../database.cjs')

const cache = new Map()
const CACHE_TTL = 3600000
const pendingRequests = new Map()

async function getConfig() {
  const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'ip_geo_%'")
  const config = {}
  for (const r of rows) {
    config[r.config_key] = r.config_value
  }
  return {
    provider: config.ip_geo_provider || 'free',
    apiKey: config.ip_geo_api_key || '',
    apiSecret: config.ip_geo_api_secret || '',
    enabled: config.ip_geo_enabled !== '0'
  }
}

function httpGet(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http
    mod.get(url, { timeout: 5000 }, (res) => {
      let data = ''
      res.on('data', (chunk) => { data += chunk })
      res.on('end', () => {
        try {
          resolve(JSON.parse(data))
        } catch {
          resolve(null)
        }
      })
    }).on('error', () => resolve(null)).on('timeout', function () { this.destroy(); resolve(null) })
  })
}

async function queryFreeApi(ip) {
  const result = await httpGet(`http://ip-api.com/json/${ip}?lang=zh-CN&fields=status,country,regionName,city,isp`)
  if (!result || result.status !== 'success') return null
  return {
    country: result.country || '',
    province: result.regionName || '',
    city: result.city || '',
    isp: result.isp || ''
  }
}

function sha256HMAC(message, secret) {
  return crypto.createHmac('sha256', secret).update(message).digest('hex')
}

function sha256Hex(message) {
  return crypto.createHash('sha256').update(message).digest('hex')
}

async function queryTencentApi(ip, apiKey, apiSecret) {
  const service = 'ip'
  const host = 'ip.tencentcloudapi.com'
  const version = '2021-04-27'
  const action = 'DescribeIPLocation'
  const timestamp = Math.floor(Date.now() / 1000)
  const date = new Date(timestamp * 1000).toISOString().split('T')[0]
  const payload = JSON.stringify({ Ip: ip })

  const algorithm = 'TC3-HMAC-SHA256'
  const canonicalHeaders = `content-type:application/json\nhost:${host}\n`
  const signedHeaders = 'content-type;host'
  const hashedPayload = sha256Hex(payload)
  const httpRequestMethod = 'POST'
  const canonicalUri = '/'
  const canonicalQuerystring = ''
  const canonicalRequest = `${httpRequestMethod}\n${canonicalUri}\n${canonicalQuerystring}\n${canonicalHeaders}\n${signedHeaders}\n${hashedPayload}`
  const credentialScope = `${date}/${service}/tc3_request`
  const hashedCanonicalRequest = sha256Hex(canonicalRequest)
  const stringToSign = `${algorithm}\n${timestamp}\n${credentialScope}\n${hashedCanonicalRequest}`

  const secretDate = sha256HMAC(date, `TC3${apiSecret}`)
  const secretService = sha256HMAC(service, secretDate)
  const secretSigning = sha256HMAC('tc3_request', secretService)
  const signature = sha256HMAC(stringToSign, secretSigning)

  const authorization = `${algorithm} Credential=${apiKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`

  return new Promise((resolve) => {
    const req = https.request({
      hostname: host,
      port: 443,
      path: '/',
      method: 'POST',
      timeout: 5000,
      headers: {
        'Content-Type': 'application/json',
        'Host': host,
        'X-TC-Action': action,
        'X-TC-Version': version,
        'X-TC-Timestamp': timestamp.toString(),
        'Authorization': authorization
      }
    }, (res) => {
      let data = ''
      res.on('data', (chunk) => { data += chunk })
      res.on('end', () => {
        try {
          const result = JSON.parse(data)
          if (result.Response && result.Response.IP) {
            const ipInfo = result.Response.IP
            resolve({
              country: ipInfo.Nation || '',
              province: ipInfo.Province || '',
              city: ipInfo.City || '',
              isp: ipInfo.ISP || ''
            })
          } else {
            resolve(null)
          }
        } catch {
          resolve(null)
        }
      })
    })
    req.on('error', () => resolve(null))
    req.on('timeout', () => { req.destroy(); resolve(null) })
    req.write(payload)
    req.end()
  })
}

async function queryAliyunApi(ip) {
  const result = await httpGet(`http://ip.taobao.com/outGetIpInfo?ip=${ip}&accessKey=alibaba-inc`)
  if (!result || result.code !== 0 || !result.data) return null
  return {
    country: result.data.country || '',
    province: result.data.region || '',
    city: result.data.city || '',
    isp: result.data.isp || ''
  }
}

function parseUA(userAgent) {
  if (!userAgent) return { deviceType: '', os: '', browser: '' }

  const ua = userAgent.toLowerCase()

  let deviceType = 'PC'
  if (/mobile|android|iphone|ipod|blackberry|iemobile|opera mini/i.test(ua)) {
    deviceType = 'Mobile'
  } else if (/ipad|tablet|playbook|silk/i.test(ua)) {
    deviceType = 'Tablet'
  }

  let os = ''
  if (/windows nt 10/i.test(ua)) os = 'Windows 10/11'
  else if (/windows nt 6\.3/i.test(ua)) os = 'Windows 8.1'
  else if (/windows nt 6\.2/i.test(ua)) os = 'Windows 8'
  else if (/windows nt 6\.1/i.test(ua)) os = 'Windows 7'
  else if (/windows nt/i.test(ua)) os = 'Windows'
  else if (/mac os x (\d+[._]\d+)/i.test(ua)) os = 'macOS ' + RegExp.$1.replace('_', '.')
  else if (/mac os x/i.test(ua)) os = 'macOS'
  else if (/android (\d+[.\d]*)/i.test(ua)) os = 'Android ' + RegExp.$1
  else if (/android/i.test(ua)) os = 'Android'
  else if (/iphone os (\d+[_\d]*)/i.test(ua)) os = 'iOS ' + RegExp.$1.replace(/_/g, '.')
  else if (/iphone/i.test(ua)) os = 'iOS'
  else if (/ipad/i.test(ua)) os = 'iPadOS'
  else if (/linux/i.test(ua)) os = 'Linux'

  let browser = ''
  if (/edg\/([\d.]+)/i.test(ua)) browser = 'Edge ' + RegExp.$1
  else if (/chrome\/([\d.]+)/i.test(ua) && !/edg/i.test(ua)) browser = 'Chrome ' + RegExp.$1
  else if (/firefox\/([\d.]+)/i.test(ua)) browser = 'Firefox ' + RegExp.$1
  else if (/safari\/([\d.]+)/i.test(ua) && !/chrome/i.test(ua)) browser = 'Safari ' + RegExp.$1
  else if (/msie ([\d.]+)/i.test(ua)) browser = 'IE ' + RegExp.$1
  else if (/trident.*rv:([\d.]+)/i.test(ua)) browser = 'IE ' + RegExp.$1

  return { deviceType, os, browser }
}

function isSuspiciousLogin(ip, newDeviceInfo, historyRecords) {
  if (!historyRecords || historyRecords.length === 0) return { suspicious: true, reason: '首次登录' }

  const prevIPs = historyRecords.map(r => r.ip).filter(Boolean)
  const prevDevices = historyRecords.map(r => ({
    deviceType: r.device_type,
    os: r.os,
    browser: r.browser
  }))

  const ipPrefix = ip.split('.').slice(0, 2).join('.')
  const sameIPNetwork = prevIPs.some(p => p.split('.').slice(0, 2).join('.') === ipPrefix)
  if (!sameIPNetwork) return { suspicious: true, reason: '异地登录' }

  if (newDeviceInfo.deviceType) {
    const sameDevice = prevDevices.some(d =>
      d.deviceType === newDeviceInfo.deviceType && d.os === newDeviceInfo.os
    )
    if (!sameDevice && prevDevices.length > 0) return { suspicious: true, reason: '新设备登录' }
  }

  return { suspicious: false, reason: '' }
}

async function getIPLocation(ip) {
  if (!ip || ip === '127.0.0.1' || ip === '::1' || ip === 'localhost' || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
    return null
  }

  const cached = cache.get(ip)
  if (cached && Date.now() - cached.time < CACHE_TTL) {
    return cached.data
  }

  if (pendingRequests.has(ip)) {
    return pendingRequests.get(ip)
  }

  const promise = (async () => {
    try {
      const config = await getConfig()
      if (!config.enabled) return null

      let result = null
      switch (config.provider) {
        case 'tencent':
          if (config.apiKey && config.apiSecret) {
            result = await queryTencentApi(ip, config.apiKey, config.apiSecret)
          }
          break
        case 'aliyun':
          result = await queryAliyunApi(ip)
          break
        case 'free':
        default:
          result = await queryFreeApi(ip)
          break
      }

      if (result) {
        cache.set(ip, { data: result, time: Date.now() })
      }
      return result
    } catch {
      return null
    } finally {
      pendingRequests.delete(ip)
    }
  })()

  pendingRequests.set(ip, promise)
  return promise
}

function cleanupCache() {
  const now = Date.now()
  for (const [key, val] of cache) {
    if (now - val.time > CACHE_TTL) {
      cache.delete(key)
    }
  }
}

setInterval(cleanupCache, 600000)

module.exports = { parseUA, isSuspiciousLogin, getIPLocation, queryFreeApi, queryTencentApi, queryAliyunApi }
