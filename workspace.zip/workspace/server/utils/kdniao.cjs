const crypto = require('crypto')

const API_URL = 'https://api.kdniao.com/Ebusiness/EbusinessOrderHandle.aspx'

function sign(data, apiKey) {
  const md5 = crypto.createHash('md5').update(data + apiKey, 'utf8').digest('hex')
  return Buffer.from(md5).toString('base64')
}

function urlEncode(str) {
  return encodeURIComponent(str)
    .replace(/!/g, '%21')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
    .replace(/\*/g, '%2A')
}

async function requestKdniao(ebusinessId, apiKey, requestType, requestData) {
  const dataStr = typeof requestData === 'string' ? requestData : JSON.stringify(requestData)
  const dataSign = urlEncode(sign(dataStr, apiKey))
  const formData = `RequestData=${urlEncode(dataStr)}&EBusinessID=${ebusinessId}&RequestType=${requestType}&DataSign=${dataSign}&DataType=2`

  const http = require('http')
  const https = require('https')
  const url = new URL(API_URL)
  const mod = url.protocol === 'https:' ? https : http

  return new Promise((resolve, reject) => {
    const req = mod.request({
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(formData)
      },
      timeout: 10000
    }, (res) => {
      let body = ''
      res.on('data', chunk => { body += chunk })
      res.on('end', () => {
        try { resolve(JSON.parse(body)) } catch { resolve({ Success: false, Reason: body }) }
      })
    })
    req.on('error', reject)
    req.on('timeout', () => { req.destroy(); reject(new Error('快递鸟API超时')) })
    req.write(formData)
    req.end()
  })
}

async function subscribeTracking(ebusinessId, apiKey, logisticCode, shipperCode, orderCode) {
  const requestData = JSON.stringify({
    OrderCode: String(orderCode || ''),
    ShipperCode: String(shipperCode || ''),
    LogisticCode: String(logisticCode || '')
  })
  return requestKdniao(ebusinessId, apiKey, '1008', requestData)
}

async function queryTracking(ebusinessId, apiKey, logisticCode, shipperCode) {
  const requestData = JSON.stringify({
    ShipperCode: String(shipperCode || ''),
    LogisticCode: String(logisticCode || '')
  })
  return requestKdniao(ebusinessId, apiKey, '1002', requestData)
}

async function autoDetectShipper(ebusinessId, apiKey, logisticCode) {
  const requestData = JSON.stringify({ LogisticCode: String(logisticCode || '') })
  return requestKdniao(ebusinessId, apiKey, '2002', requestData)
}

const SHIPPER_MAP = {
  'SF': '顺丰速运', 'YTO': '圆通速递', 'ZTO': '中通快递', 'STO': '申通快递',
  'YD': '韵达速递', 'HTKY': '百世快递', 'JD': '京东物流', 'DBL': '德邦快递',
  'EMS': 'EMS', 'YZPY': '邮政快递包裹', 'UC': '优速快递', 'HHTT': '天天快递',
  'JST': '极兔速递', 'ZJS': '宅急送', 'QFKD': '全峰快递', 'GTO': '国通快递'
}

function shipperName(code) {
  return SHIPPER_MAP[code] || code
}

module.exports = {
  subscribeTracking,
  queryTracking,
  autoDetectShipper,
  shipperName,
  SHIPPER_MAP
}
