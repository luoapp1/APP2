let redis = null
let redisAvailable = false

function getClient() {
  if (redis !== null) return redisAvailable ? redis : null
  try {
    const Redis = require('ioredis')
    const config = require('../config.cjs')
    const { host, port, password } = config.redis || {}
    if (!host) {
      redis = null
      redisAvailable = false
      return null
    }
    redis = new Redis({
      host,
      port: port || 6379,
      password: password || undefined,
      retryStrategy(times) {
        if (times > 3) {
          redisAvailable = false
          return null
        }
        return Math.min(times * 200, 2000)
      },
      maxRetriesPerRequest: 3,
      enableOfflineQueue: false,
      lazyConnect: true
    })
    redis.on('connect', () => { redisAvailable = true })
    redis.on('error', () => { redisAvailable = false })
    redis.on('close', () => { redisAvailable = false })
    redis.connect().catch(() => {})
  } catch {
    redisAvailable = false
    redis = null
  }
  return redisAvailable ? redis : null
}

async function cacheGet(key) {
  const client = getClient()
  if (!client) return null
  try {
    const val = await client.get(key)
    return val ? JSON.parse(val) : null
  } catch { return null }
}

async function cacheSet(key, value, ttlSeconds = 300) {
  const client = getClient()
  if (!client) return
  try {
    const serialized = JSON.stringify(value)
    if (ttlSeconds > 0) {
      await client.setex(key, ttlSeconds, serialized)
    } else {
      await client.set(key, serialized)
    }
  } catch {}
}

async function cacheDel(pattern) {
  const client = getClient()
  if (!client) return
  try {
    if (pattern.includes('*')) {
      const keys = await client.keys(pattern)
      if (keys.length > 0) await client.del(...keys)
    } else {
      await client.del(pattern)
    }
  } catch {}
}

async function cacheGetOrSet(key, ttlSeconds, fetchFn) {
  const cached = await cacheGet(key)
  if (cached !== null) return cached
  const fresh = await fetchFn()
  if (fresh !== null && fresh !== undefined) {
    await cacheSet(key, fresh, ttlSeconds)
  }
  return fresh
}

const CACHE_KEY = {
  sections: 'cache:sections',
  hotPosts: 'cache:hot_posts',
  userInfo: (id) => `cache:user:${id}`,
  sysConfig: 'cache:sys_config'
}

module.exports = {
  getClient,
  cacheGet,
  cacheSet,
  cacheDel,
  cacheGetOrSet,
  CACHE_KEY
}
