/**
 * 安全错误处理工具函数
 * 防止敏感信息泄露，只向客户端返回通用错误消息
 */

function safeError(res, e, context = '') {
  // 服务端记录完整错误信息，用于调试
  console.error(`[ERROR${context ? ': ' + context : ''}]`, e)
  // 向客户端返回通用错误消息
  res.json({ code: 500, msg: '服务器内部错误，请稍后重试' })
}

module.exports = { safeError }
