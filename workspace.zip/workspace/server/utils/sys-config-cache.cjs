const { query } = require('../database.cjs')
const { cacheGet, cacheSet, cacheDel } = require('../utils/redis.cjs')

const CONFIG_CACHE_KEY = 'cache:sys_config_all'
const CONFIG_LIST_CACHE_KEY = 'cache:sys_config_list'
const CONFIG_CACHE_TTL = 600

let memoryCache = {}
let memoryCacheTime = 0
const MEMORY_TTL = 600000

async function getMemoryConfig() {
  if (Date.now() - memoryCacheTime < MEMORY_TTL && Object.keys(memoryCache).length > 0) {
    return memoryCache
  }
  const rows = await query('SELECT config_key, config_value FROM sys_config')
  memoryCache = {}
  for (const row of rows) {
    memoryCache[row.config_key] = row.config_value
  }
  memoryCacheTime = Date.now()
  return memoryCache
}

async function getSysConfigRows() {
  const cached = await cacheGet(CONFIG_LIST_CACHE_KEY)
  if (cached) return cached

  const rows = await query('SELECT * FROM sys_config ORDER BY id')
  await cacheSet(CONFIG_LIST_CACHE_KEY, rows, CONFIG_CACHE_TTL)

  return rows
}

async function getSysConfig(key) {
  const cached = await cacheGet(CONFIG_CACHE_KEY)
  if (cached) {
    if (cached[key] !== undefined) return cached[key]
  }

  const memCfg = await getMemoryConfig()
  await cacheSet(CONFIG_CACHE_KEY, memCfg, CONFIG_CACHE_TTL)

  return memCfg[key] !== undefined ? memCfg[key] : null
}

async function getSysConfigs(keys) {
  const cached = await cacheGet(CONFIG_CACHE_KEY)
  if (cached) {
    const result = {}
    let allHit = true
    for (const key of keys) {
      if (cached[key] !== undefined) {
        result[key] = cached[key]
      } else {
        allHit = false
      }
    }
    if (allHit) return result
  }

  const memCfg = await getMemoryConfig()
  await cacheSet(CONFIG_CACHE_KEY, memCfg, CONFIG_CACHE_TTL)

  const result = {}
  for (const key of keys) {
    result[key] = memCfg[key] !== undefined ? memCfg[key] : null
  }
  return result
}

async function invalidateSysConfig() {
  memoryCacheTime = 0
  await cacheDel(CONFIG_CACHE_KEY)
  await cacheDel(CONFIG_LIST_CACHE_KEY)
}

module.exports = {
  getSysConfig,
  getSysConfigs,
  getSysConfigRows,
  invalidateSysConfig
}
