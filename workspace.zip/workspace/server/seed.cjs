const { query } = require('./database.cjs')
const bcrypt = require('bcryptjs')

async function seed() {
  try {
    const roles = await query('SELECT COUNT(*) as cnt FROM roles')
    if (roles && roles.length > 0 && roles[0].cnt > 0) {
      console.log('数据库已有角色数据，跳过种子数据')
      return
    }
  } catch (e) {
    console.log('检查现有数据失败，继续播种:', e.message)
  }

  console.log('初始化种子数据到 MySQL...')

  // ===== 角色 =====
  console.log('创建角色...')
  const roleData = [
    ['超级管理员', 'R_SUPER', '系统超级管理员', 1],
    ['管理员', 'R_ADMIN', '系统管理员', 1],
    ['普通用户', 'R_USER', '普通用户', 1]
  ]
  for (const r of roleData) {
    await query(
      `INSERT INTO roles (role_name, role_code, description, enabled) VALUES (?, ?, ?, ?)`, r
    )
  }

  // ===== 菜单 =====
  console.log('创建菜单...')
  const menuCnt = await query('SELECT COUNT(*) as cnt FROM menus')
  if (!menuCnt[0].cnt) {
    const INSERT_MENU = `INSERT INTO menus
      (parent_id, name, path, component, redirect, title, icon,
       sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab,
       auth_list, roles, enabled, mobile_path, icon_bg, icon_svg, category)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`

    const sa = JSON.stringify

    // 一级菜单
    const parents = [
      [0, 'Dashboard', '/dashboard', '/index/index', '/dashboard/console', '仪表盘', 'ri:pie-chart-line', 1, 0, 0, 0, 0, null, sa(['R_SUPER','R_ADMIN']), 1, '', '#4ECDC4', '', ''],
      [0, 'System', '/system', '/index/index', '', '系统管理', 'ri:user-3-line', 2, 0, 0, 0, 0, null, sa(['R_SUPER','R_ADMIN']), 1, '', '#4ECDC4', '', ''],
      [0, 'Operation', '/operation', '/index/index', '', '运营管理', 'ri:settings-3-line', 3, 0, 0, 0, 0, null, sa(['R_SUPER','R_ADMIN']), 1, '', '#4ECDC4', '', ''],
      [0, 'AppStore', '/appstore', '/index/index', '', '应用商店', 'ri:apps-2-line', 4, 0, 0, 0, 0, null, sa(['R_SUPER','R_ADMIN','R_USER']), 1, '', '#4ECDC4', '', ''],
      [0, '文件管理', '/awsdb', '/index/index', '', '文件管理', '', 5, 0, 0, 1, 0, null, null, 1, '', '#4ECDC4', '', ''],
      [0, '商城管理', '/etnfd', '', '', '商城管理', '', 6, 0, 0, 1, 0, null, null, 1, '', '#4ECDC4', '', ''],
      [0, 'Result', '/result', '/index/index', '', '结果页面', 'ri:checkbox-circle-line', 7, 0, 0, 0, 0, null, null, 1, '', '#4ECDC4', '', ''],
      [0, 'Exception', '/exception', '/index/index', '', '异常页面', 'ri:error-warning-line', 8, 0, 0, 0, 0, null, null, 1, '', '#4ECDC4', '', ''],
    ]

    // Dashboard (parent_id=1)
    const dashboardMenus = [
      [1, 'Console', 'console', '/dashboard/console', '', '工作台', '', 1, 0, 0, 1, 1, null, null, 1, '/appstore/mobile-console', '#6366F1', 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z', ''],
    ]

    // System (parent_id=2)
    const systemMenus = [
      [2, 'User', 'user', '/system/user', '', '用户管理', '', 1, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'},{title:'重置密码',authMark:'reset'}]), null, 1, '/appstore/user-manage', '#10B981', 'M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z', ''],
      [2, 'Role', 'role', '/system/role', '', '角色管理', '', 2, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/role-manage', '#10B981', 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z', ''],
      [2, 'UserCenter', 'user-center', '/system/user-center', '', '个人中心', '', 3, 1, 0, 1, 1, null, null, 1, '', '#10B981', '', ''],
      [2, 'Menus', 'menu', '/system/menu', '', '菜单管理', '', 4, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/menu-manage', '#10B981', 'M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z', ''],
      [2, 'DeleteReview', 'delete-review', '/system/user/delete-review', '', '注销审核', '', 5, 0, 0, 1, 0, sa([{title:'通过',authMark:'approve'},{title:'拒绝',authMark:'reject'}]), null, 1, '/appstore/delete-review', '#10B981', 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z', ''],
      [2, 'Verification', 'verification', '/system/verification/index', '', '蓝V认证审核', '', 6, 0, 0, 1, 0, sa([{title:'通过',authMark:'approve'},{title:'拒绝',authMark:'reject'}]), null, 1, '/appstore/verification-manage', '#10B981', 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z', ''],
      [2, 'InviteManage', 'invite', '/system/invite/index', '', '邀请码管理', '', 7, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'生成',authMark:'generate'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/invite-manage', '#10B981', 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z', ''],
      [2, 'EmailConfig', 'email', '/system/email/index', '', '邮件配置', '', 9, 0, 0, 1, 0, sa([{title:'编辑',authMark:'edit'},{title:'测试',authMark:'test'}]), null, 1, '/appstore/email-config', '#10B981', 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z', ''],
      [2, 'RecycleBin', 'recycle', '/system/recycle/index', '', '回收站', '', 10, 0, 0, 1, 0, sa([{title:'恢复',authMark:'restore'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/recycle', '#10B981', 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z', ''],
      [2, 'SystemLog', 'syslog', '/system/syslog/index', '', '系统日志', '', 11, 0, 0, 1, 0, sa([{title:'导出',authMark:'export'},{title:'清空',authMark:'clear'}]), null, 1, '/appstore/syslog', '#10B981', 'M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z', ''],
      [2, 'SysConfig', 'sysconfig', '/system/sysconfig/index', '', '系统配置', '', 12, 0, 0, 1, 0, sa([{title:'编辑',authMark:'edit'}]), null, 1, '/appstore/site-config', '#10B981', 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.33-.02-.64-.06-.94l2.02-1.58c.18-.14.23-.38.12-.56l-1.89-3.28c-.12-.19-.36-.26-.56-.18l-2.38.96c-.5-.38-1.06-.68-1.66-.88L14.45 3.5c-.04-.2-.2-.34-.4-.34h-3.78c-.2 0-.36.14-.4.34l-.3 2.52c-.6.2-1.16.5-1.66.88l-2.38-.96c-.2-.08-.44-.01-.56.18L3.28 9.52c-.12.19-.06.42.12.56l2.02 1.58c-.04.3-.06.61-.06.94s.02.64.06.94l-2.02 1.58c-.18.14-.23.38-.12.56l1.89 3.28c.12.19.36.26.56.18l2.38-.96c.5.38 1.06.68 1.66.88l.3 2.52c.04.2.2.34.4.34h3.78c.2 0 .36-.14.4-.34l.3-2.52c.6-.2 1.16-.5 1.66-.88l2.38.96c.2.08.44.01.56-.18l1.89-3.28c.12-.19.06-.42-.12-.56l-2.02-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z', ''],
      [2, 'CustomTask', 'task', '/system/task/index', '', '任务管理', '', 13, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/task-manage', '#10B981', 'M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z', ''],
      [2, 'EmailTemplates', 'email-templates', '/appstore/email-templates', '', '邮件卡片', '', 14, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/email-templates', '#10B981', 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z', ''],
      [2, 'EmailPush', 'email-push', '/appstore/email-push', '', '邮件推送', '', 15, 0, 0, 1, 0, sa([{title:'编辑',authMark:'edit'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/email-push', '#10B981', 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z', ''],
      [2, 'ComplianceSettings', 'compliance', '/appstore/compliance-settings', '', '合规设置', '', 16, 0, 0, 1, 0, sa([{title:'编辑',authMark:'edit'}]), null, 1, '/appstore/compliance-settings', '#10B981', 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z', ''],
    ]

    // Operation (parent_id=3)
    const operationMenus = [
      [3, 'CardKey', 'cardkey', '/operation/cardkey/index', '', '卡密管理', '', 1, 0, 0, 1, 0, sa([{title:'生成',authMark:'add'},{title:'删除',authMark:'delete'},{title:'导入',authMark:'import'}]), null, 1, '/appstore/cardkey-manage', '#F59E0B', 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z', ''],
      [3, 'Membership', 'membership', '/operation/membership/index', '', '会员管理', '', 2, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/operation/membership', '#F59E0B', 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z', ''],
      [3, 'Coupon', 'coupon', '/operation/coupon/index', '', '优惠券管理', '', 3, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/operation/coupon', '#F59E0B', 'M20 12v6H4v-6c1.1 0 2-.9 2-2s-.9-2-2-2V4h16v4c-1.1 0-2 .9-2 2s.9 2 2 2zm-6 4h2v-2h-2v2zm-4 0h2v-2h-2v2zm0-4h2v-2h-2v2z', ''],
      [3, 'Points', 'points', '/operation/points/index', '', '积分管理', '', 4, 0, 0, 1, 0, sa([{title:'调整',authMark:'adjust'},{title:'导出',authMark:'export'}]), null, 1, '/appstore/operation/points', '#F59E0B', 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z', ''],
      [3, 'ExperienceLevel', 'experience', '/operation/experience/index', '', '经验等级', '', 5, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/experience-manage', '#F59E0B', 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z', ''],
      [3, 'Plugins', 'plugins', '/operation/plugins/index', '', '插件管理', '', 6, 0, 0, 1, 0, sa([{title:'上传',authMark:'upload'},{title:'启停',authMark:'toggle'},{title:'配置',authMark:'config'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/plugin-manage', '#F59E0B', 'M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-2 .9-2 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7s2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z', ''],
      [3, 'TitleManage', 'title', '/operation/title/index', '', '称号管理', '', 7, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/title-manage', '#F59E0B', 'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z', ''],
      [3, 'CommissionManage', 'commission', '/operation/commission/index', '', '推广返佣', '', 8, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'配置',authMark:'config'}]), null, 1, '/appstore/commission-manage', '#F59E0B', 'M20 7h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v3H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-6 0h-4V4h4v3z', ''],
      [3, 'Settlement', 'settlement', '/operation/settlement/index', '', '结算规则', 'ri:exchange-funds-line', 10, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/operation/settlement', '#F59E0B', 'M21 3H3v18h18V3zm-2 16H5V5h14v14zM17 7h-4v4h4V7zm-6 0H7v4h4V7zm6 6h-4v4h4v-4zm-6 0H7v4h4v-4z', ''],
      [3, 'MembershipProducts', 'membership-products', '/operation/membership-products/index', '', '会员商品', '', 11, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/operation/membership-products', '#F59E0B', 'M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-5 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 14H4v-2h16v2zm0-5H4V8h16v5z', ''],
      [3, 'MembershipPurchases', 'membership-purchases', '/operation/membership-purchases/index', '', '购买记录', '', 12, 0, 0, 1, 0, sa([{title:'导出',authMark:'export'}]), null, 1, '/appstore/operation/purchase-records', '#F59E0B', 'M11 17h2v-1h1c.55 0 1-.45 1-1v-3c0-.55-.45-1-1-1h-3v-1h4V8h-2V7h-2v1h-1c-.55 0-1 .45-1 1v3c0 .55.45 1 1 1h3v1H9v2h2v1zm9-13H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z', ''],
      [3, 'ContentPurchases', 'content-purchases', '/operation/content-purchases/index', '', '付费内容订单', '', 13, 0, 0, 1, 0, sa([{title:'导出',authMark:'export'}]), null, 1, '/appstore/operation/content-purchases', '#F59E0B', 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l6.59-6.59L19 9l-8 8z', ''],
      [3, 'GameCenter', '/operation/game-center', '', '', '游戏中心', 'ri:gamepad-line', 19, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/game-center', '#F59E0B', 'M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v2H6v-2H4v-2h2V9h2v2h3v2zm7 0h-3v2h-2v-2h-3V9h3V7h2v2h3v2z', ''],
      [3, 'CheckinManage', '/operation/checkin', '/operation/checkin/index', '', '签到管理', 'ri:calendar-check-line', 21, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/checkin', '#F59E0B', 'M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-6.67 11.93l-3.89 3.89-2.11-2.11 1.41-1.41 1.12 1.12 2.47-2.47 1.51 1.41.04.04z', ''],
      [3, 'LayoutThemesManage', '/operation/layout-themes', '/operation/themes/index', '', '布局主题', 'ri:palette-line', 22, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/layout-themes', '#F59E0B', 'M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-4.5 8c-.83 0-1.5-.67-1.5-1.5S6.67 8 7.5 8 9 8.67 9 9.5 8.33 11 7.5 11zm9 0c-.83 0-1.5-.67-1.5-1.5S15.67 8 16.5 8s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z', ''],
      [3, 'AvatarFrameManage', '/operation/avatar-frame', '/operation/avatar-frame/index', '', '头像框管理', 'ri:user-smile-line', 23, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/avatar-frame', '#F59E0B', 'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z', ''],
      [3, 'PaymentConfig', '/operation/payment-config', '/operation/payment-config/index', '', '支付配置', 'ri:bank-card-line', 24, 0, 0, 1, 0, sa([{title:'编辑',authMark:'edit'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/payment-config', '#F59E0B', 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4H4V6h16v2zm-8 4H7v2h5v-2zm3 0h2v2h-2v-2z', ''],
      [3, 'RechargeAmounts', '/operation/recharge-amounts', '/operation/recharge-amounts/index', '', '充值金额配置', 'ri:money-cny-circle-line', 25, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/operation/recharge-amounts', '#F59E0B', 'M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z', ''],
    ]

    // AppStore (parent_id=4)
    const appstoreMenus = [
      [4, 'AppStoreList', 'list', '/appstore/list', '', '应用管理', '', 1, 0, 0, 1, 0, sa([{title:'通过',authMark:'approve'},{title:'拒绝',authMark:'reject'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'启停',authMark:'toggle'}]), null, 1, '/appstore/list', '#EC4899', 'M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z', ''],
      [4, 'AppStoreDetail', 'detail/:id', '/appstore/detail', '', '应用详情', '', 2, 1, 0, 0, 0, null, null, 1, '', '#EC4899', '', ''],
      [4, 'AppCategory', 'category-manage', '/appstore/category', '', '应用分类', 'ri:apps-2-line', 3, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/category-manage', '#EC4899', 'M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z', ''],
      [4, 'AppReports', 'reports', '/appstore/reports', '', '举报列表', 'ri:apps-2-line', 4, 0, 0, 1, 0, sa([{title:'处理',authMark:'handle'},{title:'忽略',authMark:'ignore'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/reports', '#EC4899', 'M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3s.58-1.3 1.3-1.3 1.3.58 1.3 1.3-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z', ''],
      [4, 'SubmissionReview', '/appstore/review', '/appstore/review', '', '投稿审核', 'ri:audit-line', 7, 0, 0, 1, 0, sa([{title:'审核',authMark:'edit'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/review-mobile', '#EC4899', 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z', ''],
      [4, 'OfficialTags', 'official-tags', '/appstore/official-tags', '', '官方标签', '', 8, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/official-tags', '#EC4899', 'M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42z', ''],
      [4, 'SectionManage', 'section-manage', '', '', '板块管理', '', 9, 1, 0, 0, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'},{title:'管理版主',authMark:'moderate'},{title:'启停',authMark:'toggle'},{title:'处理解锁',authMark:'unlock'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/section-manage', '#EC4899', 'M3 15h8v-2H3v2zm0 4h8v-2H3v2zm0-8h8V9H3v2zm0-6v2h8V5H3zm10 0h8v14h-8V5z', ''],
      [4, 'CommunityPostManage', 'community-posts', '', '', '帖子管理', '', 10, 1, 0, 0, 0, sa([{title:'置顶',authMark:'pin'},{title:'加精',authMark:'essence'},{title:'热帖',authMark:'boost'},{title:'锁定',authMark:'lock'},{title:'审核',authMark:'approve'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '', '#EC4899', '', ''],
      [4, 'CommunityReportManage', 'community-reports', '', '', '举报管理', '', 11, 1, 0, 0, 0, sa([{title:'处理',authMark:'handle'},{title:'忽略',authMark:'ignore'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '', '#EC4899', '', ''],
      [4, 'TopicManage', '/appstore/topic-manage', '', '', '话题管理', '', 11, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/topic-manage', '#EC4899', 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12zM7 9h2v2H7V9zm8 0h2v2h-2V9zm-4 0h2v2h-2V9z', ''],
      [4, 'CommunityCommentManage', 'community-comments', '', '', '评论管理', '', 12, 1, 0, 0, 0, sa([{title:'置顶',authMark:'pin'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '', '#EC4899', '', ''],
    ]

    // 文件管理 (parent_id=5)
    const fileMenus = [
      [5, '存储文件', '/system/storage-files', '/system/storage-files', '', '存储文件', 'ri:hard-drive-3-line', 4, 0, 0, 1, 0, sa([{title:'删除',authMark:'delete'},{title:'下载',authMark:'download'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/storage-files', '#10B981', 'M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z', ''],
      [5, '对象存储', 'storage-config', '/appstore/storage-config', '', '对象存储', '', 5, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/storage-config', '#06B6D4', 'M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z', ''],
      [5, '文件仓库', 'filerepo', '/system/filerepo/index', '', '文件仓库', '', 8, 0, 0, 1, 0, sa([{title:'删除',authMark:'delete'}]), null, 1, '/appstore/file-repo-manage', '#8B5CF6', 'M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z', ''],
      [5, '文件上传策略', 'filepolicy', '/operation/filepolicy/index', '', '文件上传策略', '', 9, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), null, 1, '/appstore/file-policy-manage', '#3B82F6', 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12', ''],
    ]

    // 商城管理 (parent_id=6)
    const mallMenus = [
      [6, '商品管理', '/appstore/mall-manage', '/appstore/admin/mall/mall-manage', '', '商品管理', 'ri:shopping-bag-3-line', 1, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/mall-manage', '#F59E0B', 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4', ''],
      [6, '订单管理', '/appstore/mall-orders', '/appstore/admin/mall/mall-orders', '', '订单管理', 'ri:file-list-3-line', 2, 0, 0, 1, 0, sa([{title:'查看',authMark:'view'},{title:'处理',authMark:'handle'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/mall-orders', '#6366F1', 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01', ''],
      [6, '分类管理', '/appstore/mall-categories', '/appstore/admin/mall/mall-categories', '', '分类管理', 'ri:price-tag-3-line', 3, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/mall-categories', '#14B8A6', 'M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z', ''],
      [6, '售后服务', '/appstore/mall-after-sales', '/appstore/admin/mall/mall-after-sales', '', '售后服务', 'ri:customer-service-2-line', 4, 0, 0, 1, 0, sa([{title:'查看',authMark:'view'},{title:'处理',authMark:'handle'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/mall-after-sales', '#EF4444', 'M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z', ''],
      [6, '优惠活动', '/appstore/mall-promotions', '/appstore/admin/mall/mall-promotions', '', '优惠活动', 'ri:gift-line', 5, 0, 0, 1, 0, sa([{title:'新增',authMark:'add'},{title:'编辑',authMark:'edit'},{title:'删除',authMark:'delete'}]), sa(['R_SUPER','R_ADMIN']), 1, '/appstore/mall-promotions', '#F97316', 'M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7', ''],
    ]

    // Result (parent_id=7)
    const resultMenus = [
      [7, 'Success', 'success', '/result/success/index', '', '成功页', '', 1, 0, 1, 0, 0, null, null, 1, '', '#EF4444', '', ''],
      [7, 'Fail', 'fail', '/result/fail/index', '', '失败页', '', 2, 0, 1, 0, 0, null, null, 1, '', '#EF4444', '', ''],
    ]

    // Exception (parent_id=8)
    const exceptionMenus = [
      [8, 'Exception403', '403', '/exception/403/index', '', '403', '', 1, 0, 1, 0, 0, null, null, 1, '', '#8B5CF6', '', ''],
      [8, 'Exception404', '404', '/exception/404/index', '', '404', '', 2, 0, 1, 0, 0, null, null, 1, '', '#8B5CF6', '', ''],
      [8, 'Exception500', '500', '/exception/500/index', '', '500', '', 3, 0, 1, 0, 0, null, null, 1, '', '#8B5CF6', '', ''],
    ]

    const allMenus = [].concat(parents, dashboardMenus, systemMenus, operationMenus, appstoreMenus, fileMenus, mallMenus, resultMenus, exceptionMenus)

    for (const m of allMenus) {
      await query(INSERT_MENU, m)
    }
  }

  // ===== 角色权限 =====
  console.log('创建角色权限...')
  const permCnt = await query('SELECT COUNT(*) as cnt FROM role_permissions')
  if (!permCnt[0].cnt) {
    const allMenus = await query('SELECT id FROM menus')
    const superRole = await query("SELECT id FROM roles WHERE role_code='R_SUPER'")
    const adminRole = await query("SELECT id FROM roles WHERE role_code='R_ADMIN'")

    if (superRole.length > 0) {
      for (const m of allMenus) {
        await query('INSERT IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [superRole[0].id, m.id])
      }
    }
    if (adminRole.length > 0) {
      for (const m of allMenus) {
        await query('INSERT IGNORE INTO role_permissions (role_id, menu_id) VALUES (?, ?)', [adminRole[0].id, m.id])
      }
    }
  }

  // ===== 会员等级 =====
  console.log('创建会员等级...')
  const lvCnt = await query('SELECT COUNT(*) as cnt FROM membership_levels')
  if (!lvCnt[0].cnt) {
    const lvs = [
      ['普通会员', 0, 0, 0, 1.0, 1.0, '#FFFFFF', '#508DFF', '基础权益', 'ri:user-line', '#909399', '1'],
      ['黄金会员', 1, 299, 3000, 0.9, 1.5, '#FFFFFF', '#508DFF', '9折优惠,1.5倍积分,专属客服', 'ri:vip-crown-line', '#ffb100', '1'],
      ['钻石会员', 2, 599, 6000, 0.8, 2.0, '#FFFFFF', '#508DFF', '8折优惠,2倍积分,专属客服,优先发货,生日礼包', 'ri:vip-diamond-line', '#377dff', '1'],
      ['至尊会员', 3, 999, 10000, 0.7, 3.0, '#FFFFFF', '#508DFF', '7折优惠,3倍积分,专属客服,优先发货,生日礼包,年度礼品', 'ri:star-line', '#ff6b6b', '1']
    ]
    for (const l of lvs) {
      await query(
        `INSERT INTO membership_levels (name, level, price, points_required, discount_rate, points_multiplier, text_color, bg_color, benefits, icon, icon_color, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, l
      )
    }
  }

  // ===== 经验等级 =====
  console.log('创建经验等级...')
  const expCnt = await query('SELECT COUNT(*) as cnt FROM experience_levels')
  if (!expCnt[0].cnt) {
    const expLevels = [
      ['Lv.1', 1, 0, 'ri:star-line', '#00BFA5', '#FFFFFF', '#508DFF', '基础等级', '1'],
      ['Lv.2', 2, 100, 'ri:star-line', '#42A5F5', '#FFFFFF', '#508DFF', '解锁评论功能', '1'],
      ['Lv.3', 3, 500, 'ri:star-half-line', '#7C4DFF', '#FFFFFF', '#508DFF', '解锁发帖功能', '1'],
      ['Lv.4', 4, 1000, 'ri:star-half-fill', '#FFB74D', '#FFFFFF', '#508DFF', '解锁自定义头像', '1'],
      ['Lv.5', 5, 2000, 'ri:star-fill', '#FF6B6B', '#FFFFFF', '#508DFF', '解锁高级搜索', '1'],
      ['Lv.6', 6, 5000, 'ri:vip-crown-line', '#FFD700', '#FFFFFF', '#508DFF', '专属标识,优先客服', '1'],
      ['Lv.7', 7, 10000, 'ri:vip-crown-fill', '#FF4081', '#FFFFFF', '#508DFF', '全部权益,年度礼品', '1']
    ]
    for (const e of expLevels) {
      await query(
        `INSERT INTO experience_levels (name, level, exp_required, icon, icon_color, text_color, bg_color, benefits, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, e
      )
    }
  }

  // ===== 系统配置 =====
  console.log('创建系统配置...')
  const cfgCnt = await query('SELECT COUNT(*) as cnt FROM sys_config')
  if (!cfgCnt[0].cnt) {
    const configs = [
      ['system_log_enabled', 'true', '系统日志总开关'],
      ['log_enabled_login', 'true', '登录日志开关'],
      ['log_enabled_user', 'true', '用户操作日志开关'],
      ['log_enabled_operation', 'true', '运营管理日志开关'],
      ['log_enabled_content', 'true', '内容管理日志开关'],
      ['log_enabled_system', 'true', '系统配置日志开关'],
      ['invite_user_enabled', 'false', '用户生成邀请码开关'],
      ['invite_user_max', '5', '用户最大可生成邀请码数'],
      ['register_invite_required', 'false', '注册必须邀请码'],
      ['commission_enabled', 'false', '推广返佣开关'],
      ['commission_mode', 'purchase', '返佣模式'],
      ['points_transfer_enabled', 'false', '积分转账开关'],
      ['points_transfer_fee', '0', '积分转账手续费比例%'],
      ['balance_transfer_enabled', 'false', '余额转账开关'],
      ['balance_transfer_fee', '0', '余额转账手续费比例%'],
      ['points_purchase_enabled', 'false', '积分购买开关'],
      ['points_purchase_rate', '1', '1元等于多少积分'],
      ['content_split_enabled', 'true', '创作分成开关'],
      ['content_split_global_rate', '70', '创作分成全局比例%'],
      ['checkin_enabled', 'true', '签到功能开关'],
      ['register_enabled', 'true', '注册功能开关'],
      ['register_verify_type', 'none', '注册验证方式'],
      ['register_email_config_id', '', '注册验证邮件模板ID'],
      ['register_default_group', '', '新用户默认分组'],
      ['register_default_level', '', '新用户默认会员等级ID'],
      ['register_start_id', '0', '用户ID起始编号'],
      ['register_username_min', '3', '用户名最小长度'],
      ['register_password_min', '6', '密码最小长度'],
      ['password_rule', 'alphanumeric', '密码规则'],
      ['sms_channel_enabled', 'true', '短信通道开关']
    ]
    for (const c of configs) {
      await query(
        `INSERT INTO sys_config (config_key, config_value, description) VALUES (?, ?, ?)`, c
      )
    }
  } else {
    // 增量添加新配置
    const newConfigs = [
      ['register_enabled', 'true', '注册功能开关'],
      ['register_verify_type', 'none', '注册验证方式'],
      ['register_email_config_id', '', '注册验证邮件模板ID'],
      ['register_default_group', '', '新用户默认分组'],
      ['register_default_level', '', '新用户默认会员等级ID'],
      ['register_start_id', '0', '用户ID起始编号'],
      ['register_username_min', '3', '用户名最小长度'],
      ['register_password_min', '6', '密码最小长度'],
      ['password_rule', 'alphanumeric', '密码规则'],
      ['sms_channel_enabled', 'true', '短信通道开关']
    ]
    for (const c of newConfigs) {
      const existing = await query('SELECT id FROM sys_config WHERE config_key=?', [c[0]])
      if (!existing.length) {
        await query(
          `INSERT INTO sys_config (config_key, config_value, description) VALUES (?, ?, ?)`, c
        )
      }
    }
  }

  // ===== 超级管理员账号 (仅一个) =====
  console.log('创建超级管理员账号...')


  // ===== 邮箱配置 (示例) =====
  const emailCfgCnt = await query('SELECT COUNT(*) as cnt FROM email_config')
  if (!emailCfgCnt[0].cnt) {
    await query(`INSERT INTO email_config (host, port, secure, user, password, from_name, from_address, enabled) VALUES (?,?,?,?,?,?,?,?)`,
      ['smtp.qq.com', 465, 1, 'noreply@qq.com', '', 'ArtDesignPro', 'noreply@qq.com', 1])
  }

  const userCnt = await query('SELECT COUNT(*) as cnt FROM users')
  if (!userCnt[0].cnt) {
    const hash = bcrypt.hashSync('123456', 10)
    await query(
      `INSERT INTO users (username, password, password_hash, nickname, phone, email, gender, avatar, points, balance, experience, level_id, level_name, roles, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ['alexmorgan', '', hash, 'Alex Morgan', '18670001591', 'alexmorgan@company.com', '男', '', 0, 0, 0, 0, '普通会员', sa('R_SUPER'), '1']
    )
  }

  console.log('种子数据初始化完成')
  console.log('  3 角色 (超级管理员, 管理员, 普通用户)')
  console.log('  ' + (allMenus ? allMenus.length : '全部') + ' 菜单 (含移动端路径和权限配置)')
  console.log('  角色权限 (R_SUPER + R_ADMIN 所有菜单)')
  console.log('  4 会员等级')
  console.log('  7 经验等级')
  console.log('  ' + 30 + ' 系统配置项')
  console.log('  1 邮箱配置 (示例)')
  console.log('  1 超级管理员账号 (alexmorgan / 123456)')
}

seed().catch(e => { console.error('种子数据错误:', e.message); process.exit(1) })
