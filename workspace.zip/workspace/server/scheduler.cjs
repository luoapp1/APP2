const { query } = require('./database.cjs')
let _checkAndGrantAutoTitles = null
let _titleScanTimer = null

function setTitleChecker(fn) { _checkAndGrantAutoTitles = fn }

async function getTitleScanInterval() {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_interval'")
    return rows.length > 0 ? Math.max(1, Math.min(1440, parseInt(rows[0].config_value) || 60)) : 60
  } catch { return 60 }
}

async function titleScanTask() {
  if (_titleScanTimer) { clearTimeout(_titleScanTimer); _titleScanTimer = null }
  try {
    if (!_checkAndGrantAutoTitles) return
    const users = await query('SELECT id FROM users ORDER BY id')
    for (const u of users) {
      await _checkAndGrantAutoTitles(u.id)
    }
    await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_last',NOW(),'称号最后扫描时间') ON DUPLICATE KEY UPDATE config_value=NOW()")
    console.log('[Scheduler] 称号扫描完成')
  } catch (e) { console.error('[Scheduler] 称号扫描出错:', e.message) }

  const interval = await getTitleScanInterval()
  _titleScanTimer = setTimeout(titleScanTask, interval * 60 * 1000)
}

function startScheduledTasks(app) {
  let cron
  try { cron = require('node-cron') } catch { cron = null }

  const runTask = (name, fn) => {
    try { fn() } catch (e) { console.error(`[Scheduler] ${name} error:`, e.message) }
  }

  const dailyTask = () => {
    runTask('clean-expired-coupons', async () => {
      await query("UPDATE coupons SET status='0' WHERE status='1' AND expire_time < NOW()")
    })
  }

  const hourlyTask = () => {
    runTask('close-expired-votes', async () => {
      await query("UPDATE standalone_votes SET status='closed' WHERE status='active' AND end_time IS NOT NULL AND end_time < NOW()")
      await query("UPDATE community_votes SET is_active=0 WHERE is_active=1 AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)")
    })
  }

  // Every 15 minutes: update rankings cache
  const rankingsTask = () => {
    runTask('update-rankings-cache', async () => {
      // Rankings are computed on-the-fly, no cache needed
    })
  }

  if (cron) {
    cron.schedule('0 0 * * *', dailyTask, { timezone: 'Asia/Shanghai' })
    cron.schedule('0 * * * *', hourlyTask, { timezone: 'Asia/Shanghai' })
    cron.schedule('*/15 * * * *', rankingsTask, { timezone: 'Asia/Shanghai' })
  } else {
    const dailyMs = 24 * 60 * 60 * 1000
    const hourlyMs = 60 * 60 * 1000
    const fifteenMinMs = 15 * 60 * 1000
    setInterval(dailyTask, dailyMs)
    setInterval(hourlyTask, hourlyMs)
    setInterval(rankingsTask, fifteenMinMs)
    dailyTask()
    hourlyTask()
  }

  // 称号扫描：独立于 cron，按配置间隔动态运行
  titleScanTask()

  console.log('[Scheduler] Cron tasks initialized')
}

module.exports = { startScheduledTasks, setTitleChecker }
