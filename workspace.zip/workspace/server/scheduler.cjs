const { query } = require('./database.cjs')
let _checkAndGrantAutoTitles = null
let _titleScanTimer = null

function setTitleChecker(fn) { _checkAndGrantAutoTitles = fn }

async function getTitleScanInterval() {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_interval'")
    return rows.length > 0 ? Math.max(1, Math.min(1440, parseInt(rows[0].config_value) || 60)) : 60
  } catch { return 60 }
}

async function titleScanTask() {
  if (_titleScanTimer) { clearTimeout(_titleScanTimer); _titleScanTimer = null }
  try {
    if (!_checkAndGrantAutoTitles) return
    const users = await query('SELECT id FROM users ORDER BY id')
    for (const u of users) {
      await _checkAndGrantAutoTitles(u.id)
    }
    await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_last',NOW(),'称号最后扫描时间') ON DUPLICATE KEY UPDATE config_value=NOW()")
    console.log('[Scheduler] 称号扫描完成')
  } catch (e) { console.error('[Scheduler] 称号扫描出错:', e.message) }

  const interval = await getTitleScanInterval()
  _titleScanTimer = setTimeout(titleScanTask, interval * 60 * 1000)
}

function startScheduledTasks(app) {
  let cron
  try { cron = require('node-cron') } catch { cron = null }

  const runTask = (name, fn) => {
    try { fn() } catch (e) { console.error(`[Scheduler] ${name} error:`, e.message) }
  }

  const dailyTask = () => {
    runTask('clean-expired-coupons', async () => {
      await query("UPDATE coupons SET status='0' WHERE status='1' AND expire_time < NOW()")
    })
    runTask('clean-expired-sessions', async () => {
      await query("DELETE FROM sessions WHERE created_at < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY))")
    })
  }

  const hourlyTask = () => {
    runTask('close-expired-votes', async () => {
      await query("UPDATE standalone_votes SET status='closed' WHERE status='active' AND end_time IS NOT NULL AND end_time < NOW()")
      await query("UPDATE community_votes SET is_active=0 WHERE is_active=1 AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)")
    })
    runTask('publish-scheduled-posts', async () => {
      const scheduledPosts = await query(
        "SELECT id, user_id, title FROM community_posts WHERE status='scheduled' AND scheduled_time IS NOT NULL AND scheduled_time <= NOW()"
      )
      for (const post of scheduledPosts) {
        try {
          await query("UPDATE community_posts SET status='published', update_time=NOW() WHERE id=?", [post.id])
          await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?) AND is_deleted=0', [post.id])
          try {
            await query(
              "INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)",
              ['帖子发布提醒', `您设置的定时发布帖子「${post.title}」已自动发布`, 'post_scheduled', post.user_id, 0, '系统']
            )
          } catch {}
          console.log(`[Scheduler] 定时发布帖子: ${post.id} - ${post.title}`)
        } catch (e) { console.error(`[Scheduler] 定时发布帖子 ${post.id} 失败:`, e.message) }
      }
    })
  }

  // 称号扫描：独立于 cron，按配置间隔动态运行
  titleScanTask()

  // Schedule cron tasks
  if (cron) {
    cron.schedule('0 0 * * *', dailyTask)
    cron.schedule('0 * * * *', hourlyTask)
  }
  // Also run hourly task immediately on startup
  setTimeout(hourlyTask, 5000)

  console.log('[Scheduler] Cron tasks initialized')
}

module.exports = { startScheduledTasks, setTitleChecker }
