const { query } = require('./database.cjs')
let _checkAndGrantAutoTitles = null
let _titleScanTimer = null

function setTitleChecker(fn) { _checkAndGrantAutoTitles = fn }

function concurrencyLimit(limit, items, fn) {
  const results = new Array(items.length)
  let i = 0
  async function worker() {
    while (i < items.length) {
      const idx = i++
      results[idx] = await fn(items[idx], idx)
    }
  }
  return Promise.all(Array.from({ length: limit }, () => worker())).then(() => results)
}

async function getTitleScanInterval() {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_interval'")
    return rows.length > 0 ? Math.max(1, Math.min(1440, parseInt(rows[0].config_value) || 60)) : 60
  } catch { return 60 }
}

async function titleScanTask() {
  if (_titleScanTimer) { clearTimeout(_titleScanTimer); _titleScanTimer = null }
  try {
    if (!_checkAndGrantAutoTitles) return
    let offset = 0
    const checkpoint = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_offset'")
    if (checkpoint && checkpoint.length > 0) {
      offset = parseInt(checkpoint[0].config_value) || 0
      console.log('[Scheduler] 称号扫描从断点恢复 offset=', offset)
    }
    const pageSize = 100
    const scanTimeout = 30 * 60 * 1000
    const startTime = Date.now()
    while (true) {
      if (Date.now() - startTime > scanTimeout) {
        console.log('[Scheduler] 称号扫描超时，记录断点 offset=', offset)
        await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_offset',?, '称号扫描断点') ON DUPLICATE KEY UPDATE config_value=?", [String(offset), String(offset)])
        break
      }
      const users = await query('SELECT id FROM users ORDER BY id LIMIT ? OFFSET ?', [pageSize, offset])
      if (!users.length) break
      await concurrencyLimit(10, users, u => _checkAndGrantAutoTitles(u.id))
      offset += pageSize
    }
    if (Date.now() - startTime <= scanTimeout) {
      await query("DELETE FROM sys_config WHERE config_key='title_scan_offset'")
    }
    await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_last',NOW(),'称号最后扫描时间') ON DUPLICATE KEY UPDATE config_value=NOW()")
    console.log('[Scheduler] 称号扫描完成')
  } catch (e) { console.error('[Scheduler] 称号扫描出错:', e.message) }

  const interval = await getTitleScanInterval()
  _titleScanTimer = setTimeout(titleScanTask, interval * 60 * 1000)
}

function startScheduledTasks(app) {
  let cron
  try { cron = require('node-cron') } catch { cron = null }

  const runTask = (name, fn) => {
    Promise.resolve(fn()).catch(e => console.error(`[Scheduler] ${name} error:`, e.message))
  }

  const dailyTask = () => {
    runTask('clean-expired-coupons', async () => {
      await query("UPDATE coupons SET status='0' WHERE status='1' AND expire_time < NOW()")
    })
    runTask('clean-expired-sessions', async () => {
      await query("DELETE FROM sessions WHERE created_at < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY)) LIMIT 10000")
    })
  }

  const hourlyTask = () => {
    runTask('close-expired-votes', async () => {
      await query("UPDATE standalone_votes SET status='closed' WHERE status='active' AND end_time IS NOT NULL AND end_time < NOW()")
      await query("UPDATE community_votes SET is_active=0 WHERE is_active=1 AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)")
    })
    // publish-scheduled-posts 已迁移至统一调度器 server/scheduler/tasks.cjs (每60s执行)
    runTask('cleanup-overdue-pending', async () => {
      const result = await query(
        "UPDATE community_posts SET status='rejected' WHERE status='pending' AND is_deleted=0 AND create_time < DATE_SUB(NOW(), INTERVAL 72 HOUR)"
      )
      if (result && result.affectedRows > 0) {
        console.log(`[Scheduler] auto-cleanup: ${result.affectedRows} overdue pending posts rejected`)
      }
    })
  }

  // 称号扫描：独立于 cron，按配置间隔动态运行
  // 当 ENABLE_INTERNAL_TASK=false 时由宝塔 Cron 通过统一任务调度器驱动
  const enableInternal = (process.env.ENABLE_INTERNAL_TASK || 'false').toLowerCase() === 'true'
  if (enableInternal) {
    titleScanTask()
  } else {
    console.log('[Scheduler] 宝塔模式 — 称号扫描由统一任务调度器 title-scan 任务驱动')
  }

  // Schedule cron tasks
  if (cron) {
    cron.schedule('0 0 * * *', dailyTask)
    cron.schedule('0 * * * *', hourlyTask)
  }
  // Also run hourly task immediately on startup
  setTimeout(hourlyTask, 5000)

  console.log('[Scheduler] Cron tasks initialized')
}

module.exports = { startScheduledTasks, setTitleChecker }
