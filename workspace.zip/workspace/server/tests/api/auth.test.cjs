const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testRefreshToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let realUsername = ''
let realUserId = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Registration', () => {
  test('POST /api/auth/register should create a new user', async () => {
    const { response, username, userId } = await createTestUser(testUsernameBase, testPassword)
    realUsername = username
    realUserId = userId
    expect(response.body.code).toBe(200)
    expect(response.body.data).toBeDefined()
    expect(response.body.data.userId).toBeGreaterThan(0)
  })

  test('POST /api/auth/register should reject duplicate username', async () => {
    const { response } = await createTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(400)
  })
})

describe('Login', () => {
  test('POST /api/auth/login should return token and refreshToken', async () => {
    const { response, token } = await loginTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(200)
    expect(token).toBeTruthy()
    testToken = token
    testRefreshToken = response.body.data.refreshToken
  })

  test('POST /api/auth/login should reject wrong password', async () => {
    const res = await request
      .post('/api/auth/login')
      .send({ username: realUsername, password: 'WrongPassword123' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/auth/login should reject empty credentials', async () => {
    const res = await request
      .post('/api/auth/login')
      .send({ username: '', password: '' })
    expect(res.body.code).toBe(400)
  })
})

describe('Token Refresh', () => {
  test('POST /api/auth/refresh should return new tokens', async () => {
    const res = await request
      .post('/api/auth/refresh')
      .send({ refreshToken: testRefreshToken })
    expect(res.body.code).toBe(200)
    expect(res.body.data.token).toBeTruthy()
    testToken = res.body.data.token
    testRefreshToken = res.body.data.refreshToken
  })

  test('POST /api/auth/refresh should reject missing refreshToken', async () => {
    const res = await request
      .post('/api/auth/refresh')
      .send({})
    expect(res.body.code).toBe(400)
  })

  test('POST /api/auth/refresh should reject invalid refreshToken', async () => {
    const res = await request
      .post('/api/auth/refresh')
      .send({ refreshToken: 'invalid-refresh-token' })
    expect(res.body.code).toBe(401)
  })
})

describe('OAuth Providers', () => {
  test('GET /api/auth/oauth/providers should return providers list', async () => {
    const res = await request.get('/api/auth/oauth/providers')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('Change Password', () => {
  test('POST /api/auth/change-pwd should change password', async () => {
    const newPassword = 'NewTest1234'
    const res = await request
      .post('/api/auth/change-pwd')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ oldPwd: testPassword, newPwd: newPassword })
    expect(res.body.code).toBe(200)
    testPassword = newPassword
  })

  test('POST /api/auth/change-pwd should reject wrong old password', async () => {
    const res = await request
      .post('/api/auth/change-pwd')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ oldPwd: 'WrongOldPassword', newPwd: 'Whatever123' })
    expect([400, 401]).toContain(res.body.code)
  })

  test('POST /api/auth/login should work with new password', async () => {
    const { response, token } = await loginTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(200)
    expect(token).toBeTruthy()
    testToken = token
  })
})

describe('Reset Password', () => {
  test('POST /api/auth/reset-password should reject without valid code', async () => {
    const res = await request
      .post('/api/auth/reset-password')
      .send({ email: 'test@example.com', code: '000000', password: 'ResetPass123' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/auth/reset-password should reject missing fields', async () => {
    const res = await request
      .post('/api/auth/reset-password')
      .send({ email: '', code: '', password: '' })
    expect(res.body.code).toBe(400)
  })
})

describe('SMS Login', () => {
  test('POST /api/auth/sms-login should reject without valid code', async () => {
    const res = await request
      .post('/api/auth/sms-login')
      .send({ phone: '13800138000', code: '000000' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/auth/sms-login should reject empty fields', async () => {
    const res = await request
      .post('/api/auth/sms-login')
      .send({ phone: '', code: '' })
    expect(res.body.code).toBe(400)
  })
})

describe('Email Login', () => {
  test('POST /api/auth/email-login should reject without valid code', async () => {
    const res = await request
      .post('/api/auth/email-login')
      .send({ email: 'test@example.com', code: '000000' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/auth/email-login should reject empty fields', async () => {
    const res = await request
      .post('/api/auth/email-login')
      .send({ email: '', code: '' })
    expect(res.body.code).toBe(400)
  })
})

describe('User Info', () => {
  test('GET /api/user/info should return user info with auth', async () => {
    const res = await request
      .get('/api/user/info')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data.userId).toBeDefined()
    expect(res.body.data.userName).toBeTruthy()
  })

  test('GET /api/user/info should reject without auth', async () => {
    const res = await request.get('/api/user/info')
    expect(res.body.code).toBe(401)
  })
})

describe('Logout', () => {
  test('POST /api/auth/logout should logout successfully', async () => {
    const res = await request
      .post('/api/auth/logout')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('GET /api/user/info should fail after logout', async () => {
    const res = await request
      .get('/api/user/info')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })
})

describe('Logout All', () => {
  test('POST /api/auth/logout-all should logout all sessions', async () => {
    // Re-login first to get a fresh token
    const { response, token } = await loginTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(200)
    const freshToken = token

    const res = await request
      .post('/api/auth/logout-all')
      .set('Authorization', `Bearer ${freshToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })
})
