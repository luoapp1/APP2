const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testUserId = 0
let testPassword = 'Test123456'
const testUsernameBase = 'ad' + Date.now().toString(36)

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: regRes, userId } = await createTestUser(testUsernameBase, testPassword)
  testUserId = userId || 0

  const { response: loginRes, token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token || ''
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Roles & Permissions', () => {
  test('GET /api/role/list should return role list with auth', async () => {
    const res = await request
      .get('/api/role/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/role/:id/permissions should return role permissions with auth', async () => {
    const res = await request
      .get('/api/role/1/permissions')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Dashboard/Stats', () => {
  test('GET /api/dashboard/stats should return dashboard stats with auth', async () => {
    const res = await request
      .get('/api/dashboard/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/stats should require admin role', async () => {
    const res = await request
      .get('/api/admin/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/console-stats should require admin role', async () => {
    const res = await request
      .get('/api/admin/console-stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Sys Config', () => {
  test('GET /api/sys-config/list should require admin role', async () => {
    const res = await request
      .get('/api/sys-config/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/sys-config/public/:key should return public config for site_name', async () => {
    const res = await request.get('/api/sys-config/public/site_name')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/sys-config/public/:key should return public config for register_verify_type', async () => {
    const res = await request.get('/api/sys-config/public/register_verify_type')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('System Logs', () => {
  test('GET /api/system-log/stats should require admin role', async () => {
    const res = await request
      .get('/api/system-log/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/system-log/:id should require admin role', async () => {
    const res = await request
      .get('/api/system-log/1')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Menu (Public)', () => {
  test('GET /api/menu/list should return menu list', async () => {
    const res = await request.get('/api/menu/list')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Email Config', () => {
  test('GET /api/email/configs should return email configs', async () => {
    const res = await request.get('/api/email/configs')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/email/templates should return email templates', async () => {
    const res = await request.get('/api/email/templates')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/email/config should return email config with auth', async () => {
    const res = await request
      .get('/api/email/config')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Email Templates', () => {
  test('GET /api/email-templates should return templates with auth', async () => {
    const res = await request
      .get('/api/email-templates')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/email-templates-code/:code should return template by code', async () => {
    const res = await request.get('/api/email-templates-code/register')
    expect([200, 400, 401, 403, 404]).toContain(res.body.code)
  })
})

describe('Email Push', () => {
  test('GET /api/email-push/configs should return push configs with auth', async () => {
    const res = await request
      .get('/api/email-push/configs')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/email-push/init should return push init with auth', async () => {
    const res = await request
      .get('/api/email-push/init')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('SMS', () => {
  test('GET /api/sms/configs should return SMS configs with auth', async () => {
    const res = await request
      .get('/api/sms/configs')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Upload', () => {
  test('GET /api/upload/storage-quota should return storage quota', async () => {
    const res = await request.get('/api/upload/storage-quota')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/upload/quota should return upload quota', async () => {
    const res = await request.get('/api/upload/quota')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('File Policy', () => {
  test('GET /api/file-policy/list should require admin role', async () => {
    const res = await request
      .get('/api/file-policy/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/file-policy/check should return policy check', async () => {
    const res = await request.get('/api/file-policy/check')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('OAuth Admin', () => {
  test('GET /api/admin/oauth-configs should require admin role', async () => {
    const res = await request
      .get('/api/admin/oauth-configs')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Storage Config', () => {
  test('GET /api/storage-config/list should require admin role', async () => {
    const res = await request
      .get('/api/storage-config/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/storage-config/types should return config types with auth', async () => {
    const res = await request
      .get('/api/storage-config/types')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/storage-config/audiences should return audiences with auth', async () => {
    const res = await request
      .get('/api/storage-config/audiences')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/storage/sign-url should return sign url', async () => {
    const res = await request.get('/api/storage/sign-url')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Login History', () => {
  test('GET /api/login-history should return login history with auth', async () => {
    const res = await request
      .get('/api/login-history')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Plugins', () => {
  test('GET /api/plugins/list should return plugin list', async () => {
    const res = await request.get('/api/plugins/list')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/plugins/inject should return plugin inject', async () => {
    const res = await request.get('/api/plugins/inject')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Policies', () => {
  test('GET /api/admin/policies should require admin role', async () => {
    const res = await request
      .get('/api/admin/policies')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/policy/current should return current policy', async () => {
    const res = await request.get('/api/policy/current')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/policy/check-consent should check consent with auth', async () => {
    const res = await request
      .get('/api/policy/check-consent')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Cookie Consent Admin', () => {
  test('GET /api/admin/cookie-consent/stats should require admin role', async () => {
    const res = await request
      .get('/api/admin/cookie-consent/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Abuse Admin', () => {
  test('GET /api/admin/abuse/risks should require admin role', async () => {
    const res = await request
      .get('/api/admin/abuse/risks')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/abuse/thresholds should require admin role', async () => {
    const res = await request
      .get('/api/admin/abuse/thresholds')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/abuse/stats should require admin role', async () => {
    const res = await request
      .get('/api/admin/abuse/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('A/B Test', () => {
  test('GET /api/ab-test/list should return AB test list with auth', async () => {
    const res = await request
      .get('/api/ab-test/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Moderation Queue', () => {
  test('GET /api/admin/moderation/queue should require admin role', async () => {
    const res = await request
      .get('/api/admin/moderation/queue')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/moderation/queue/stats should require admin role', async () => {
    const res = await request
      .get('/api/admin/moderation/queue/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Task Scheduler', () => {
  test('GET /api/scheduler/tasks should require admin role', async () => {
    const res = await request
      .get('/api/scheduler/tasks')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Official Tags', () => {
  test('GET /api/official-tags/list should require admin role', async () => {
    const res = await request
      .get('/api/official-tags/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Logistics Config', () => {
  test('GET /api/admin/logistics-config should require admin role', async () => {
    const res = await request
      .get('/api/admin/logistics-config')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('System Menus', () => {
  test('GET /api/v3/system/menus/simple should return system menus with auth', async () => {
    const res = await request
      .get('/api/v3/system/menus/simple')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403, 500]).toContain(res.body.code)
  })
})

describe('User Admin', () => {
  test('GET /api/user/list should require admin role', async () => {
    const res = await request
      .get('/api/user/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Content Admin', () => {
  test('GET /api/admin/content/purchases should require admin role', async () => {
    const res = await request
      .get('/api/admin/content/purchases')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Coupon Admin', () => {
  test('GET /api/coupon/claims should require admin role', async () => {
    const res = await request
      .get('/api/coupon/claims')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/coupon/usage/all should require admin role', async () => {
    const res = await request
      .get('/api/coupon/usage/all')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Membership Admin', () => {
  test('GET /api/admin/membership/purchases should require admin role', async () => {
    const res = await request
      .get('/api/admin/membership/purchases')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('User Block Admin', () => {
  test('GET /api/admin/user-blocks should require admin role', async () => {
    const res = await request
      .get('/api/admin/user-blocks')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Commission', () => {
  test('GET /api/commission/rules should return commission rules', async () => {
    const res = await request.get('/api/commission/rules')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Collection Admin', () => {
  test('GET /api/community/admin/collections should return collections', async () => {
    const res = await request.get('/api/community/admin/collections')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/community/admin/collection-stats should return collection stats', async () => {
    const res = await request.get('/api/community/admin/collection-stats')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Admin Images', () => {
  test('GET /api/community/admin/images should return images', async () => {
    const res = await request.get('/api/community/admin/images')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/community/admin/image-stats should return image stats', async () => {
    const res = await request.get('/api/community/admin/image-stats')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Penalty Logs', () => {
  test('GET /api/operation/penalty/logs should require admin role', async () => {
    const res = await request
      .get('/api/operation/penalty/logs')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/operation/penalty/stats should require admin role', async () => {
    const res = await request
      .get('/api/operation/penalty/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Custom Tasks Admin', () => {
  test('GET /api/custom-task/list should require admin role', async () => {
    const res = await request
      .get('/api/custom-task/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('IP Geo', () => {
  test('GET /api/ip-geo/test should return ip geo test with auth', async () => {
    const res = await request
      .get('/api/ip-geo/test')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('User Delete Requests', () => {
  test('GET /api/user/delete-requests should require admin role', async () => {
    const res = await request
      .get('/api/user/delete-requests')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('User Appeals Admin', () => {
  test('GET /api/user/appeals should require admin role', async () => {
    const res = await request
      .get('/api/user/appeals')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Admin Appeals', () => {
  test('GET /api/admin/appeals should require admin role', async () => {
    const res = await request
      .get('/api/admin/appeals')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Appstore Collections Admin', () => {
  test('GET /api/appstore/collections/review/list should require admin role', async () => {
    const res = await request
      .get('/api/appstore/collections/review/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Recharge Admin', () => {
  test('GET /api/admin/recharge/orders should require admin role', async () => {
    const res = await request
      .get('/api/admin/recharge/orders')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/admin/payment-config should require admin role', async () => {
    const res = await request
      .get('/api/admin/payment-config')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Game Config', () => {
  test('GET /api/game/config/:gameType should return game config', async () => {
    const res = await request.get('/api/game/config/lottery')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Membership Level', () => {
  test('GET /api/operation/membership-level/list should return list', async () => {
    const res = await request.get('/api/operation/membership-level/list')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Checkin Milestone Admin', () => {
  test('GET /api/operation/checkin-milestone/list should require admin role', async () => {
    const res = await request
      .get('/api/operation/checkin-milestone/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Verification Admin', () => {
  test('GET /api/verification/list should require admin role', async () => {
    const res = await request
      .get('/api/verification/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})

describe('Title Admin', () => {
  test('GET /api/admin/titles/scan-config should return scan config with auth', async () => {
    const res = await request
      .get('/api/admin/titles/scan-config')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Appstore Developer Analytics', () => {
  test('GET /api/appstore/dev/analytics/:id should return dev analytics', async () => {
    const res = await request.get('/api/appstore/dev/analytics/1')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Funnel Analytics', () => {
  test('GET /api/analytics/funnel should return analytics funnel', async () => {
    const res = await request.get('/api/analytics/funnel')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Experience Permissions Compare', () => {
  test('GET /api/operation/experience-level/permission-templates should return templates', async () => {
    const res = await request.get('/api/operation/experience-level/permission-templates')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/operation/experience-level/permissions-compare should return compare', async () => {
    const res = await request.get('/api/operation/experience-level/permissions-compare')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Auto Ban Settings', () => {
  test('GET /api/community/admin/auto-ban-settings should return auto ban', async () => {
    const res = await request.get('/api/community/admin/auto-ban-settings')
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})

describe('Trust Level', () => {
  test('GET /api/community/user/:userId/trust-level should return trust level', async () => {
    if (!testUserId) return
    const res = await request.get(`/api/community/user/${testUserId}/trust-level`)
    expect([200, 400, 401, 403]).toContain(res.body.code)
  })
})
