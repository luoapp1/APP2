const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost
} = require('../helpers/test-utils.cjs')

let request
let sectionId = 0
let topicId = 0
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let realUsername = ''
let realUserId = 0
let createdPostId = 0
let createdCommentId = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: r1, username: uname1, userId: uid1 } = await createTestUser(testUsernameBase, testPassword)
  realUsername = uname1
  realUserId = uid1

  const { response: lr1, token: t1 } = await loginTestUser(testUsernameBase, testPassword)
  testToken = t1

  const sectionsRes = await request.get('/api/community/sections')
  if (sectionsRes.body.code === 200 && sectionsRes.body.data?.length > 0) {
    sectionId = sectionsRes.body.data[0].id
  }

  const topicsRes = await request.get('/api/community/topics')
  if (topicsRes.body.code === 200 && topicsRes.body.data?.list?.length > 0) {
    topicId = topicsRes.body.data.list[0].id
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Sections', () => {
  test('GET /api/community/sections should return sections list', async () => {
    const res = await request.get('/api/community/sections')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/community/section/:id should return section detail', async () => {
    if (!sectionId) return
    const res = await request.get(`/api/community/section/${sectionId}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    expect(res.body.data.name).toBeTruthy()
  })

  test('GET /api/community/section/:id should return 404 for invalid id', async () => {
    const res = await request.get('/api/community/section/99999999')
    expect(res.body.code).toBe(404)
  })
})

describe('Posts', () => {
  test('GET /api/community/posts should return paginated posts', async () => {
    const res = await request.get('/api/community/posts').query({ page: 1, pageSize: 5 })
    expect(res.body.code).toBe(200)
    const payload = res.body.data
    if (payload.list) {
      expect(Array.isArray(payload.list)).toBe(true)
      expect(payload).toHaveProperty('total')
      expect(payload).toHaveProperty('page')
    } else {
      expect(Array.isArray(payload)).toBe(true)
    }
  })

  test('POST /api/community/post should require auth', async () => {
    const res = await request
      .post('/api/community/post')
      .send({ sectionId: 1, title: 'No auth test' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post should create post with auth', async () => {
    if (!sectionId) return
    const { response, postId } = await createTestPost(
      testToken,
      sectionId,
      'post_' + Date.now(),
      'Test content for community core test'
    )
    expect(response.body.code).toBe(200)
    expect(postId).toBeGreaterThan(0)
    createdPostId = postId
  })

  test('GET /api/community/post/:id should return post detail', async () => {
    if (!createdPostId) return
    const res = await request.get(`/api/community/post/${createdPostId}`)
    expect([200, 404]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toBeDefined()
      expect(res.body.data.id).toBe(createdPostId)
    }
  })

  test('GET /api/community/post/:id should return 404 for invalid id', async () => {
    const res = await request.get('/api/community/post/99999999')
    expect(res.body.code).toBe(404)
  })

  test('PUT /api/community/post/:id should require auth', async () => {
    if (!createdPostId) return
    const res = await request
      .put(`/api/community/post/${createdPostId}`)
      .send({ title: 'Updated without auth' })
    expect(res.body.code).toBe(401)
  })

  test('PUT /api/community/post/:id should update post with auth', async () => {
    if (!createdPostId) return
    const res = await request
      .put(`/api/community/post/${createdPostId}`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ title: 'Updated post title' })
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('DELETE /api/community/post/:id should require auth', async () => {
    if (!createdPostId) return
    const deletePost = await createTestPost(testToken, sectionId, 'delpost_' + Date.now(), 'To be deleted')
    if (deletePost.response.body.code !== 200) return
    const pid = deletePost.postId
    const res = await request.delete(`/api/community/post/${pid}`)
    expect([401, 403]).toContain(res.body.code)
    const resDel = await request
      .delete(`/api/community/post/${pid}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(resDel.body.code)
  })

  test('DELETE /api/community/post/:id should delete post with auth', async () => {
    if (!sectionId) return
    const { response, postId } = await createTestPost(testToken, sectionId, 'tmpdel_' + Date.now(), 'Temporary post')
    if (response.body.code !== 200) return
    const res = await request
      .delete(`/api/community/post/${postId}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Comments', () => {
  let commentPostId = 0

  beforeAll(async () => {
    if (!sectionId) return
    const { response, postId } = await createTestPost(testToken, sectionId, 'cmtpost_' + Date.now(), 'Post for comment tests')
    if (response.body.code === 200) commentPostId = postId
  })

  test('GET /api/community/post/:id/comments should return comments', async () => {
    if (!commentPostId) return
    const res = await request.get(`/api/community/post/${commentPostId}/comments`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
    expect(Array.isArray(res.body.data.list)).toBe(true)
  })

  test('POST /api/community/post/:id/comment should require auth', async () => {
    if (!commentPostId) return
    const res = await request
      .post(`/api/community/post/${commentPostId}/comment`)
      .send({ content: 'No auth comment' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post/:id/comment should create comment with auth', async () => {
    if (!commentPostId) return
    const res = await request
      .post(`/api/community/post/${commentPostId}/comment`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ content: 'Test comment content' })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    if (res.body.data.id) createdCommentId = res.body.data.id
  })

  test('DELETE /api/community/comment/:id should require auth', async () => {
    if (!createdCommentId) return
    const res = await request.delete(`/api/community/comment/${createdCommentId}`)
    expect(res.body.code).toBe(401)
  })

  test('DELETE /api/community/comment/:id should delete comment with auth', async () => {
    if (!commentPostId) return
    const cmtRes = await request
      .post(`/api/community/post/${commentPostId}/comment`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ content: 'Comment to delete' })
    if (cmtRes.body.code !== 200) return
    const cid = cmtRes.body.data.id
    const res = await request
      .delete(`/api/community/comment/${cid}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Interactions', () => {
  let interactPostId = 0

  beforeAll(async () => {
    if (!sectionId) return
    const { response, postId } = await createTestPost(testToken, sectionId, 'likeFav_' + Date.now(), 'Post for like/fav tests')
    if (response.body.code === 200) interactPostId = postId
  })

  test('POST /api/community/post/:id/like should require auth', async () => {
    if (!interactPostId) return
    const res = await request.post(`/api/community/post/${interactPostId}/like`)
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post/:id/like should toggle like', async () => {
    if (!interactPostId) return
    const res = await request
      .post(`/api/community/post/${interactPostId}/like`)
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('isLiked')
  })

  test('POST /api/community/post/:id/favorite should require auth', async () => {
    if (!interactPostId) return
    const res = await request.post(`/api/community/post/${interactPostId}/favorite`)
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post/:id/favorite should toggle favorite', async () => {
    if (!interactPostId) return
    const res = await request
      .post(`/api/community/post/${interactPostId}/favorite`)
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('isFavorited')
  })

  test('GET /api/community/user/favorites should require auth', async () => {
    const res = await request.get('/api/community/user/favorites')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/community/user/favorites should return favorites with auth', async () => {
    const res = await request
      .get('/api/community/user/favorites')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
    expect(Array.isArray(res.body.data.list)).toBe(true)
  })
})

describe('Drafts', () => {
  test('GET /api/community/drafts should require userId', async () => {
    const res = await request.get('/api/community/drafts')
    expect(res.body.code).toBe(400)
  })

  test('GET /api/community/drafts should return drafts for user', async () => {
    if (!realUserId) return
    const res = await request.get('/api/community/drafts').query({ userId: realUserId })
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('POST /api/community/draft should require auth', async () => {
    const res = await request
      .post('/api/community/draft')
      .send({ sectionId: sectionId || 1, title: 'Draft without auth' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/draft should create draft with auth', async () => {
    if (!sectionId) return
    const res = await request
      .post('/api/community/draft')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ sectionId, title: 'Test draft title', content: 'Test draft content' })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })
})

describe('Topics', () => {
  test('GET /api/community/topics should return topics list', async () => {
    const res = await request.get('/api/community/topics')
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
    expect(Array.isArray(res.body.data.list)).toBe(true)
  })

  test('GET /api/community/topics/:id should return topic detail', async () => {
    if (!topicId) return
    const res = await request.get(`/api/community/topics/${topicId}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    expect(res.body.data.name).toBeTruthy()
  })

  test('GET /api/community/topics/:id should return 404 for invalid id', async () => {
    const res = await request.get('/api/community/topics/99999999')
    expect(res.body.code).toBe(404)
  })
})

describe('Tags', () => {
  test('GET /api/community/tags should return tags list', async () => {
    const res = await request.get('/api/community/tags')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/community/tags/hot should return hot tags', async () => {
    const res = await request.get('/api/community/tags/hot')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/community/tags/cloud should return tag cloud', async () => {
    const res = await request.get('/api/community/tags/cloud')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('Rankings', () => {
  test('GET /api/ranking/essence should reject unsupported type', async () => {
    const res = await request.get('/api/ranking/essence')
    if (res.body.code === 400) {
      expect(res.body.msg).toBeTruthy()
    } else {
      expect(res.body.code).toBe(200)
    }
  })

  test('GET /api/ranking/posts should return posts ranking', async () => {
    const res = await request.get('/api/ranking/posts')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/ranking/experience should return experience ranking', async () => {
    const res = await request.get('/api/ranking/experience')
    expect(res.body.code).toBe(200)
  })
})

describe('Search', () => {
  test('GET /api/search should return empty result for empty query', async () => {
    const res = await request.get('/api/search').query({ q: '' })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('posts')
  })

  test('GET /api/search should reject short keyword', async () => {
    const res = await request.get('/api/search').query({ q: 'a' })
    expect(res.body.code).toBe(400)
  })

  test('GET /api/search should return search results', async () => {
    const res = await request.get('/api/search').query({ q: 'test' })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('posts')
  })
})

describe('Browse History', () => {
  test('POST /api/browse-history/add should require auth', async () => {
    const res = await request
      .post('/api/browse-history/add')
      .send({ itemType: 'post', itemId: 1, itemTitle: 'Test' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/browse-history/add should add browse history with auth', async () => {
    if (!createdPostId) return
    const res = await request
      .post('/api/browse-history/add')
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        itemType: 'post',
        itemId: createdPostId,
        itemTitle: 'Test browse post',
        itemCover: '',
        itemUrl: `/community/post/${createdPostId}`
      })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/browse-history/list should require auth', async () => {
    const res = await request.get('/api/browse-history/list')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/browse-history/list should return history with auth', async () => {
    const res = await request
      .get('/api/browse-history/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})
