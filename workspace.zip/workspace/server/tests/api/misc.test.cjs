const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testUserId = 0
let testUsername = ''
let testPassword = 'Test123456'
const testUsernameBase = 'ms' + Date.now().toString(36)

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: regRes, userId } = await createTestUser(testUsernameBase, testPassword)
  testUserId = userId || 0
  testUsername = regRes?.body?.data?.username || ''

  const { response: loginRes, token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token || ''
})

afterAll(async () => {
  await cleanupTestData()
})

describe('File Repo', () => {
  test('GET /api/file-repo/my-files should return my files', async () => {
    const res = await request.get('/api/file-repo/my-files')
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/files/my should return my upload files with auth', async () => {
    const res = await request
      .get('/api/files/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Recycle Bin', () => {
  test('GET /api/recycle/list should return recycle list with auth', async () => {
    const res = await request
      .get('/api/recycle/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Chat Rooms', () => {
  test('GET /api/chat-rooms should return room list', async () => {
    const res = await request.get('/api/chat-rooms')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/chat-rooms/my should return my rooms', async () => {
    const res = await request.get('/api/chat-rooms/my')
    expect([200, 400]).toContain(res.body.code)
  })
})

describe('Settlement', () => {
  test('GET /api/settlement/orders should return settlement orders', async () => {
    const res = await request.get('/api/settlement/orders')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/settlement/config should require admin role', async () => {
    const res = await request.get('/api/settlement/config')
    expect([400, 401]).toContain(res.body.code)
  })

  test('GET /api/settlement/user-config should return user config', async () => {
    const res = await request.get('/api/settlement/user-config')
    expect([200, 400]).toContain(res.body.code)
  })

  test('GET /api/settlement/pending-stats should return pending stats', async () => {
    const res = await request.get('/api/settlement/pending-stats')
    expect([200, 400]).toContain(res.body.code)
  })
})

describe('Campaigns', () => {
  test('GET /api/campaign/list should return campaign list', async () => {
    const res = await request.get('/api/campaign/list')
    expect(res.body.code).toBe(200)
  })
})

describe('Collection Posts / Post Favorites', () => {
  test('GET /api/post-favorite/list should return favorite list with auth', async () => {
    const res = await request
      .get('/api/post-favorite/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('POST /api/post-favorite/check should check favorite with auth', async () => {
    const res = await request
      .post('/api/post-favorite/check')
      .set('Authorization', `Bearer ${testToken}`)
      .query({ postId: 1 })
    expect([200, 403]).toContain(res.body.code)
  })

  test('GET /api/community/collection/paid should return paid collections', async () => {
    const res = await request.get('/api/community/collection/paid')
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('GET /api/community/collections/featured should return featured collections', async () => {
    const res = await request.get('/api/community/collections/featured')
    expect(res.body.code).toBe(200)
  })
})

describe('Recommendations', () => {
  test('GET /api/appstore/recommend should return appstore recommends', async () => {
    const res = await request.get('/api/appstore/recommend')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/recommend/for-you should return for you recommendations', async () => {
    const res = await request.get('/api/recommend/for-you')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/recommend/hot-tags should return hot tags', async () => {
    const res = await request.get('/api/recommend/hot-tags')
    expect(res.body.code).toBe(200)
  })
})

describe('Layout Themes', () => {
  test('GET /api/layout-themes should return layout themes', async () => {
    const res = await request.get('/api/layout-themes')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/layout-themes/active should return active theme', async () => {
    const res = await request.get('/api/layout-themes/active')
    expect(res.body.code).toBe(200)
  })
})

describe('Users', () => {
  test('GET /api/user/:id should return user by id', async () => {
    if (!testUserId) return
    const res = await request.get(`/api/user/${testUserId}`)
    expect([200, 400, 401, undefined]).toContain(res.body.code)
  })

  test('GET /api/user/by-username/:username', async () => {
    const res = await request.get(`/api/user/by-username/${testUsername}`)
    expect([200, 400, 401, undefined]).toContain(res.body.code)
  })
})

describe('Favorites', () => {
  test('GET /api/app-favorite/groups should return favorite groups with auth', async () => {
    const res = await request
      .get('/api/app-favorite/groups')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Custom Tasks', () => {
  test('GET /api/custom-task/my should return my custom tasks with auth', async () => {
    const res = await request
      .get('/api/custom-task/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Cookie Consent', () => {
  test('GET /api/cookie-consent/config should return cookie config', async () => {
    const res = await request.get('/api/cookie-consent/config')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/cookie-consent/status should return cookie status', async () => {
    const res = await request.get('/api/cookie-consent/status')
    expect(res.body.code).toBe(200)
  })
})

describe('Submission', () => {
  test('GET /api/submission/list should return submission list', async () => {
    const res = await request.get('/api/submission/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/submission/stats should return submission stats', async () => {
    const res = await request.get('/api/submission/stats')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/submission/drafts should return drafts', async () => {
    const res = await request.get('/api/submission/drafts')
    expect(res.body.code).toBe(200)
  })
})

describe('Menu', () => {
  test('GET /api/menu/list should return menu list', async () => {
    const res = await request.get('/api/menu/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/menu/admin-center-cards should return admin center cards', async () => {
    const res = await request.get('/api/menu/admin-center-cards')
    expect(res.body.code).toBe(200)
  })
})

describe('Vote', () => {
  test('GET /api/votes should list votes', async () => {
    const res = await request.get('/api/votes')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/votes/:id should get vote by id', async () => {
    const res = await request.get('/api/votes/1')
    expect(res.body.code).toBe(200)
  })
})
