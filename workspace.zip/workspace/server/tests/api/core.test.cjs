const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost
} = require('../helpers/test-utils.cjs')

let request
let sectionId = 0
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let realUsername = ''

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const sectionsRes = await request.get('/api/community/sections')
  if (sectionsRes.body?.data?.length > 0) {
    sectionId = sectionsRes.body.data[0].id
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('User Auth APIs', () => {
  test('POST /api/auth/register should create a new user', async () => {
    const { response, username, userId } = await createTestUser(testUsernameBase, testPassword)
    realUsername = username
    expect(response.body.code).toBe(200)
    expect(response.body.data).toBeDefined()
    expect(response.body.data.userId).toBeGreaterThan(0)
  })

  test('POST /api/auth/login should return token', async () => {
    const { response, token } = await loginTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(200)
    expect(token).toBeTruthy()
    testToken = token
  })

  test('POST /api/auth/register should reject duplicate username', async () => {
    const { response } = await createTestUser(testUsernameBase, testPassword)
    expect(response.body.code).toBe(400)
  })

  test('POST /api/auth/login should reject wrong password', async () => {
    const res = await request
      .post('/api/auth/login')
      .send({ username: realUsername, password: 'WrongPassword123' })
    expect(res.body.code).toBe(400)
  })
})

describe('Community APIs', () => {
  test('GET /api/community/sections should return sections list', async () => {
    const res = await request.get('/api/community/sections')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('POST /api/community/post should require auth', async () => {
    const res = await request
      .post('/api/community/post')
      .send({ sectionId: 1, title: 'No auth test' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post should create post with auth', async () => {
    if (!sectionId) return
    const { response, postId } = await createTestPost(testToken, sectionId, 'post_' + Date.now(), 'Test content')
    expect(response.body.code).toBe(200)
    expect(postId).toBeGreaterThan(0)
  })

  test('GET /api/community/posts should return paginated posts', async () => {
    const res = await request.get('/api/community/posts').query({ page: 1, pageSize: 5 })
    expect(res.body.code).toBe(200)
    const payload = res.body.data
    if (payload.list) {
      expect(Array.isArray(payload.list)).toBe(true)
    } else {
      expect(Array.isArray(payload)).toBe(true)
    }
  })
})

describe('Mall APIs', () => {
  test('GET /api/mall/products should return products list', async () => {
    const res = await request.get('/api/mall/products')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/mall/categories should return categories', async () => {
    const res = await request.get('/api/mall/categories')
    expect(res.body.code).toBe(200)
  })
})
