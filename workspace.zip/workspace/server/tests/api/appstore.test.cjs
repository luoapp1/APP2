const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost,
  testUserName
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testUserId = 0
let testPassword = 'Test123456'
const testUsernameBase = 'as' + Date.now().toString(36)
let appIdForTests = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: regRes, userId } = await createTestUser(testUsernameBase, testPassword)
  testUserId = userId || 0

  const { response: loginRes, token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token || ''

  const appsRes = await request.get('/api/app/list').query({ pageSize: 5 })
  if (appsRes.body.code === 200 && appsRes.body.data && appsRes.body.data.list && appsRes.body.data.list.length > 0) {
    appIdForTests = appsRes.body.data.list[0].id
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('App Listings', () => {
  test('GET /api/app/list should return paginated apps list', async () => {
    const res = await request.get('/api/app/list').query({ pageSize: 5 })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    if (res.body.data.list) {
      expect(Array.isArray(res.body.data.list)).toBe(true)
    }
  })

  test('GET /api/app/list should support keyword search', async () => {
    const res = await request.get('/api/app/list').query({ keyword: 'test', pageSize: 5 })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })

  test('GET /api/app/hot-today should return hot apps', async () => {
    const res = await request.get('/api/app/hot-today')
    expect(res.body.code).toBe(200)
    if (res.body.data && res.body.data.list) {
      expect(Array.isArray(res.body.data.list)).toBe(true)
    }
  })

  test('GET /api/app/hot-today should respect limit param', async () => {
    const res = await request.get('/api/app/hot-today').query({ limit: 3 })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/app/trending-week should return trending apps', async () => {
    const res = await request.get('/api/app/trending-week')
    expect(res.body.code).toBe(200)
    if (res.body.data && res.body.data.list) {
      expect(Array.isArray(res.body.data.list)).toBe(true)
    }
  })

  test('GET /api/app/recommend should return recommended apps', async () => {
    const res = await request.get('/api/app/recommend')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('App Details', () => {
  test('GET /api/app/:id/detail should return app detail', async () => {
    if (!appIdForTests) return
    const res = await request.get(`/api/app/${appIdForTests}/detail`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    expect(res.body.data.app).toBeDefined()
  })

  test('GET /api/app/:id/detail should return 404 for non-existent app', async () => {
    const res = await request.get('/api/app/99999/detail')
    expect(res.body.code).toBe(404)
  })

  test('GET /api/app/:id/detail should return 400 for invalid id', async () => {
    const res = await request.get('/api/app/abc/detail')
    expect(res.body.code).toBe(400)
  })
})

describe('App Categories', () => {
  test('GET /api/category/list should return categories', async () => {
    const res = await request.get('/api/category/list')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('Appstore Collections', () => {
  test('GET /api/appstore/collections should list collections', async () => {
    const res = await request.get('/api/appstore/collections')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/appstore/collections/ranking should return ranking', async () => {
    const res = await request.get('/api/appstore/collections/ranking')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/appstore/collections/ranking should support type param', async () => {
    const res = await request.get('/api/appstore/collections/ranking').query({ type: 'new' })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/appstore/collections/featured should return featured', async () => {
    const res = await request.get('/api/appstore/collections/featured')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/appstore/collections/search should handle search', async () => {
    const res = await request.get('/api/appstore/collections/search').query({ keyword: 'test' })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/appstore/collections/search should return empty without keyword', async () => {
    const res = await request.get('/api/appstore/collections/search')
    expect(res.body.code).toBe(200)
  })
})

describe('Appstore Bundles', () => {
  test('GET /api/appstore/bundles should list bundles', async () => {
    const res = await request.get('/api/appstore/bundles')
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })
})

describe('Appstore Favorites (Auth)', () => {
  test('GET /api/appstore/favorites should require auth', async () => {
    const res = await request.get('/api/appstore/favorites')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/appstore/favorites should list favorites with auth', async () => {
    const res = await request
      .get('/api/appstore/favorites')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/app-favorite/list should require auth', async () => {
    const res = await request.get('/api/app-favorite/list')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/app-favorite/list should list with auth', async () => {
    const res = await request
      .get('/api/app-favorite/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/app-favorite/check should require auth', async () => {
    const res = await request.get('/api/app-favorite/check').query({ appId: 1 })
    expect(res.body.code).toBe(401)
  })

  test('GET /api/app-favorite/check should check with auth', async () => {
    const checkId = appIdForTests || 1
    const res = await request
      .get('/api/app-favorite/check')
      .set('Authorization', `Bearer ${testToken}`)
      .query({ appId: checkId })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })
})

describe('App Changelog & Purchase', () => {
  test('GET /api/app/:id/changelog should return changelog', async () => {
    const appId = appIdForTests || 1
    const res = await request.get(`/api/app/${appId}/changelog`)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/app/:id/purchase-status should return false without userId', async () => {
    const appId = appIdForTests || 1
    const res = await request.get(`/api/app/${appId}/purchase-status`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })

  test('GET /api/app/:id/purchase-status should return purchase status with userId', async () => {
    const appId = appIdForTests || 1
    const res = await request.get(`/api/app/${appId}/purchase-status`).query({ userId: testUserId || 1 })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })
})

describe('Appstore Analytics & Ratings', () => {
  test('GET /api/appstore/developer/analytics should require auth', async () => {
    const res = await request.get('/api/appstore/developer/analytics')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/appstore/developer/analytics should return with auth', async () => {
    const res = await request
      .get('/api/appstore/developer/analytics')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
  })

  test('GET /api/appstore/:id/ratings should return ratings', async () => {
    const appId = appIdForTests || 1
    const res = await request.get(`/api/appstore/${appId}/ratings`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/appstore/:id/ratings should return 404 for non-existent app', async () => {
    const res = await request.get('/api/appstore/99999/ratings')
    expect(res.body.code).toBe(404)
  })
})
