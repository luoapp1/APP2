const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  await createTestUser(testUsernameBase, testPassword)
  const { token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Check-in', () => {
  test('GET /api/checkin/status should return checkin status', async () => {
    const res = await request
      .get('/api/checkin/status')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/checkin/status should reject without auth', async () => {
    const res = await request.get('/api/checkin/status')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/checkin/history should return checkin history', async () => {
    const res = await request
      .get('/api/checkin/history')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/checkin/ranking should return checkin ranking', async () => {
    const res = await request.get('/api/checkin/ranking')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/checkin/enabled-status should return enabled status', async () => {
    const res = await request.get('/api/checkin/enabled-status')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/checkin/calendar should return calendar data', async () => {
    const res = await request
      .get('/api/checkin/calendar')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/checkin/calendar/stats should return calendar stats', async () => {
    const res = await request
      .get('/api/checkin/calendar/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('POST /api/checkin should do checkin', async () => {
    const res = await request
      .post('/api/checkin')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('POST /api/checkin should reject without auth', async () => {
    const res = await request.post('/api/checkin')
    expect([401, 403]).toContain(res.body.code)
  })
})

describe('Invite Codes', () => {
  test('GET /api/invite/my should return my invites', async () => {
    const res = await request
      .get('/api/invite/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/invite/ranking should return invite ranking', async () => {
    const res = await request.get('/api/invite/ranking')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/invite/required should return required status', async () => {
    const res = await request.get('/api/invite/required')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/invite/config should return invite config', async () => {
    const res = await request.get('/api/invite/config')
    expect(res.body.code).toBe(200)
  })

  test('POST /api/invite/generate-user should generate invite code', async () => {
    const res = await request
      .post('/api/invite/generate-user')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('POST /api/invite/generate-user should reject without auth', async () => {
    const res = await request.post('/api/invite/generate-user')
    expect([401, 403]).toContain(res.body.code)
  })
})

describe('Coupons', () => {
  test('GET /api/coupon/list should return coupon list', async () => {
    const res = await request.get('/api/coupon/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/coupon/available should return available coupons', async () => {
    const res = await request.get('/api/coupon/available')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/coupon/my should return my coupons', async () => {
    const res = await request
      .get('/api/coupon/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 500]).toContain(res.body.code)
  })

  test('GET /api/coupon/usable should return usable coupons', async () => {
    const res = await request.get('/api/coupon/usable')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/coupon/history should return coupon history', async () => {
    const res = await request.get('/api/coupon/history')
    expect([200, 400, 401]).toContain(res.body.code)
  })
})

describe('Commission / Referral', () => {
  test('GET /api/commission/rules should return commission rules', async () => {
    const res = await request.get('/api/commission/rules')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/commission/records should return commission records', async () => {
    const res = await request.get('/api/commission/records')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/commission/referral should return referral info', async () => {
    const res = await request.get('/api/commission/referral')
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('GET /api/commission/stats/dashboard should return dashboard', async () => {
    const res = await request.get('/api/commission/stats/dashboard')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/commission/withdraw/list should return withdrawal list', async () => {
    const res = await request.get('/api/commission/withdraw/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/commission/materials should return materials', async () => {
    const res = await request.get('/api/commission/materials')
    expect(res.body.code).toBe(200)
  })
})

describe('Titles', () => {
  test('GET /api/title/list should return title list', async () => {
    const res = await request.get('/api/title/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/title/all should return all titles', async () => {
    const res = await request
      .get('/api/title/all')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('GET /api/title/categories should return title categories', async () => {
    const res = await request.get('/api/title/categories')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/user/active-titles should return active titles', async () => {
    const res = await request
      .get('/api/user/active-titles')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/user/titles should return user titles', async () => {
    const res = await request
      .get('/api/user/titles')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Avatar Frames', () => {
  test('GET /api/avatar-frame/list should return frame list', async () => {
    const res = await request.get('/api/avatar-frame/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/avatar-frame/all should return all frames', async () => {
    const res = await request
      .get('/api/avatar-frame/all')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('GET /api/user/avatar-frames should return user frames', async () => {
    const res = await request
      .get('/api/user/avatar-frames')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('User Codes', () => {
  test('GET /api/user-codes should return user codes', async () => {
    const res = await request
      .get('/api/user-codes')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Transfer', () => {
  test('GET /api/transfer/config should return transfer config', async () => {
    const res = await request.get('/api/transfer/config')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/transfer/records should return transfer records', async () => {
    const res = await request.get('/api/transfer/records')
    expect(res.body.code).toBe(200)
  })
})

describe('Verification', () => {
  test('GET /api/verification/client-config should return client config', async () => {
    const res = await request.get('/api/verification/client-config')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/verification/status should return verification status', async () => {
    const res = await request
      .get('/api/verification/status')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/verification/user-apps should return user apps', async () => {
    const res = await request
      .get('/api/verification/user-apps')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('Game', () => {
  test('GET /api/game/list should return game list', async () => {
    const res = await request.get('/api/game/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/game/records should return game records', async () => {
    const res = await request.get('/api/game/records')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/game/stats should return game stats', async () => {
    const res = await request.get('/api/game/stats')
    expect(res.body.code).toBe(200)
  })
})

describe('Checkin Groups (Admin)', () => {
  test('GET /api/operation/checkin-group/list should reject non-admin', async () => {
    const res = await request
      .get('/api/operation/checkin-group/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})
