const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost
} = require('../helpers/test-utils.cjs')

let request
let sectionId = 0
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let testPostId = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: r1 } = await createTestUser(testUsernameBase, testPassword)
  const { response: lr1, token: t1 } = await loginTestUser(testUsernameBase, testPassword)
  testToken = t1

  const sectionsRes = await request.get('/api/community/sections')
  if (sectionsRes.body.code === 200 && sectionsRes.body.data?.length > 0) {
    sectionId = sectionsRes.body.data[0].id
  }

  if (sectionId) {
    const { response: pr, postId: pid } = await createTestPost(
      testToken, sectionId, 'content_test_' + Date.now(), 'Content visibility test'
    )
    testPostId = pid
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Content Visibility', () => {
  test('GET /api/content/visibility/:type/:id should check post visibility', async () => {
    const res = await request
      .get(`/api/content/visibility/post/${testPostId}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 404]).toContain(res.body.code)
  })

  test('GET /api/content/visibility/:type/:id should reject without auth', async () => {
    const res = await request.get(`/api/content/visibility/post/${testPostId}`)
    expect([200, 401, 404]).toContain(res.body.code)
  })

  test('GET /api/content/visibility/:type/:id should handle nonexistent content', async () => {
    const res = await request
      .get('/api/content/visibility/post/999999')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 404]).toContain(res.body.code)
  })

  test('GET /api/content/purchases/my should return my purchases', async () => {
    const res = await request
      .get('/api/content/purchases/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/content/purchases/my should reject without auth', async () => {
    const res = await request.get('/api/content/purchases/my')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/content/earnings/my should return my earnings', async () => {
    const res = await request
      .get('/api/content/earnings/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/content/earnings/my should reject without auth', async () => {
    const res = await request.get('/api/content/earnings/my')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/content/config should return content config', async () => {
    const res = await request.get('/api/content/config')
    expect(res.body.code === 200 || res.body.code === 400).toBe(true)
  })
})

describe('Membership', () => {
  test('GET /api/membership/products should return products list', async () => {
    const res = await request.get('/api/membership/products')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/membership/my-memberships should return my memberships', async () => {
    const res = await request
      .get('/api/membership/my-memberships')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/membership/my-memberships should reject without auth', async () => {
    const res = await request.get('/api/membership/my-memberships')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/membership/my-current-level should return current level', async () => {
    const res = await request
      .get('/api/membership/my-current-level')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/membership/daily-gift-status should return daily gift status', async () => {
    const res = await request
      .get('/api/membership/daily-gift-status')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('GET /api/membership/levels should return levels list', async () => {
    const res = await request.get('/api/membership/levels')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/membership/purchases/my should return membership purchases', async () => {
    const res = await request
      .get('/api/membership/purchases/my')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/membership/purchases/my should reject without auth', async () => {
    const res = await request.get('/api/membership/purchases/my')
    expect(res.body.code).toBe(401)
  })
})

describe('Experience Levels', () => {
  test('GET /api/operation/experience-level/list should return levels list', async () => {
    const res = await request.get('/api/operation/experience-level/list')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/operation/experience-level/permissions/:level should return permissions for level 1', async () => {
    const res = await request.get('/api/operation/experience-level/permissions/1')
    expect(res.body.code).toBe(200)
  })
})

describe('Points', () => {
  test('GET /api/operation/points-record/list should return points records', async () => {
    const res = await request
      .get('/api/operation/points-record/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/operation/points-record/list should reject without auth', async () => {
    const res = await request.get('/api/operation/points-record/list')
    expect([200, 401]).toContain(res.body.code)
  })
})

describe('Cardkey', () => {
  test('GET /api/operation/cardkey/list should reject non-admin', async () => {
    const res = await request
      .get('/api/operation/cardkey/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/operation/cardkey/list should reject without auth', async () => {
    const res = await request.get('/api/operation/cardkey/list')
    expect(res.body.code).toBe(401)
  })

  test('POST /api/cardkey/redeem should reject without valid code', async () => {
    const res = await request
      .post('/api/cardkey/redeem')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ code: '' })
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('POST /api/cardkey/redeem should reject without auth', async () => {
    const res = await request
      .post('/api/cardkey/redeem')
      .send({ code: 'SOME-CODE' })
    expect(res.body.code).toBe(401)
  })
})

describe('Member List', () => {
  test('GET /api/operation/member/list should return member list', async () => {
    const res = await request.get('/api/operation/member/list')
    expect(res.body.code).toBe(200)
  })
})

describe('Commission Rules', () => {
  test('GET /api/operation/commission-rules/list should return rules list', async () => {
    const res = await request.get('/api/operation/commission-rules/list')
    expect(res.body.code).toBe(200)
  })
})
