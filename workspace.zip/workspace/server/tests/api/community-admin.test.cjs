const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost
} = require('../helpers/test-utils.cjs')

let request
let sectionId = 0
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let realUsername = ''
let testPostId = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: r1, username: uname1 } = await createTestUser(testUsernameBase, testPassword)
  realUsername = uname1

  const { response: lr1, token: t1 } = await loginTestUser(testUsernameBase, testPassword)
  testToken = t1

  const sectionsRes = await request.get('/api/community/sections')
  if (sectionsRes.body.code === 200 && sectionsRes.body.data?.length > 0) {
    sectionId = sectionsRes.body.data[0].id
  }

  if (sectionId) {
    const { response: pr, postId: pid } = await createTestPost(
      testToken, sectionId, 'report_post_' + Date.now(), 'Report test content'
    )
    testPostId = pid
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Reports', () => {
  test('POST /api/community/post/:id/report should report a post', async () => {
    const res = await request
      .post(`/api/community/post/${testPostId}/report`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'Spam', description: 'This post is spam' })
    expect([200, 403]).toContain(res.body.code)
  })

  test('POST /api/community/post/:id/report should reject without auth', async () => {
    const res = await request
      .post(`/api/community/post/${testPostId}/report`)
      .send({ reason: 'Spam', description: 'No auth' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/comment/:id/report should reject nonexistent comment', async () => {
    const res = await request
      .post('/api/community/comment/999999/report')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'Abuse', description: 'Fake comment' })
    expect([400, 401, 403, 500]).toContain(res.body.code)
  })

  test('POST /api/community/comment/:id/report should reject without auth', async () => {
    const res = await request
      .post('/api/community/comment/1/report')
      .send({ reason: 'Abuse', description: 'No auth' })
    expect(res.body.code).toBe(401)
  })

  test('GET /api/community/admin/reports should reject non-admin', async () => {
    const res = await request
      .get('/api/community/admin/reports')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/community/admin/reports should reject without auth', async () => {
    const res = await request.get('/api/community/admin/reports')
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/report/:id/appeal should appeal a report', async () => {
    const res = await request
      .post('/api/community/report/1/appeal')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'I disagree with this report' })
    expect([200, 400, 401, 403, 404]).toContain(res.body.code)
  })

  test('POST /api/community/report/:id/appeal should reject without auth', async () => {
    const res = await request
      .post('/api/community/report/1/appeal')
      .send({ reason: 'No auth appeal' })
    expect(res.body.code).toBe(401)
  })
})

describe('Bans', () => {
  test('GET /api/community/admin/banned should reject non-admin', async () => {
    const res = await request
      .get('/api/community/admin/banned')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403, 500]).toContain(res.body.code)
  })

  test('GET /api/community/admin/banned should reject without auth', async () => {
    const res = await request.get('/api/community/admin/banned')
    expect(res.body.code).toBe(401)
  })
})

describe('Moderation Rules', () => {
  test('GET /api/community/moderation-rules should return rules list', async () => {
    const res = await request.get('/api/community/moderation-rules')
    expect([200, 403]).toContain(res.body.code)
  })

  test('GET /api/community/moderation-logs should return logs', async () => {
    const res = await request.get('/api/community/moderation-logs')
    expect([200, 403]).toContain(res.body.code)
  })
})

describe('Quality & Analytics', () => {
  test('GET /api/community/analytics/overview should return overview', async () => {
    const res = await request.get('/api/community/analytics/overview')
    expect([200, 403]).toContain(res.body.code)
  })

  test('GET /api/community/rankings/essence should return essence rankings', async () => {
    const res = await request.get('/api/community/rankings/essence')
    expect([200, 403]).toContain(res.body.code)
  })
})

describe('Moderator', () => {
  test('GET /api/community/moderator/stats should return moderator stats', async () => {
    const res = await request.get('/api/community/moderator/stats')
    expect([200, 401]).toContain(res.body.code)
  })

  test('GET /api/community/moderator/my-sections should return my sections', async () => {
    const res = await request.get('/api/community/moderator/my-sections')
    expect([200, 401]).toContain(res.body.code)
  })
})

describe('Community User Profile', () => {
  test('GET /api/community/user/search should return search results', async () => {
    const res = await request.get('/api/community/user/search').query({ keyword: 'tst__' })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/community/user/:userId/community-profile should return profile', async () => {
    const res = await request.get('/api/community/user/1/community-profile')
    expect(res.body.code).toBe(200)
  })
})

describe('Report Categories', () => {
  test('GET /api/community/report-categories should return categories', async () => {
    const res = await request.get('/api/community/report-categories')
    expect(res.body.code).toBe(200)
  })
})

describe('Unlock Requests', () => {
  test('POST /api/community/post/:id/request-unlock should reject without auth', async () => {
    const res = await request
      .post(`/api/community/post/${testPostId}/request-unlock`)
      .send({ reason: 'Please unlock this post' })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/community/post/:id/request-unlock should require auth', async () => {
    const res = await request
      .post(`/api/community/post/${testPostId}/request-unlock`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'Please unlock this post' })
    expect(res.body.code === 200 || res.body.code === 400).toBe(true)
  })
})

describe('Sensitive Words', () => {
  test('GET /api/community/sensitive-words should return list', async () => {
    const res = await request.get('/api/community/sensitive-words')
    expect([200, 403]).toContain(res.body.code)
  })
})

describe('Level Matrix', () => {
  test('GET /api/community/level-matrix should return level matrix', async () => {
    const res = await request.get('/api/community/level-matrix')
    expect([200, 403]).toContain(res.body.code)
  })
})
