const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)
let realUsername = ''
let realUserId = 0

let user2Token = ''
let user2Id = 0
const user2NameBase = 'iu' + Date.now().toString(36) + 'b'

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  // Create main test user
  const { response: r1, username: uname1, userId: uid1 } = await createTestUser(testUsernameBase, testPassword)
  realUsername = uname1
  realUserId = uid1

  const { response: lr1, token: t1 } = await loginTestUser(testUsernameBase, testPassword)
  testToken = t1

  // Create second test user for block/follow tests
  const { response: r2, username: uname2, userId: uid2 } = await createTestUser(user2NameBase, testPassword)
  user2Id = uid2

  const { response: lr2, token: t2 } = await loginTestUser(user2NameBase, testPassword)
  user2Token = t2
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Get User by ID', () => {
  test('GET /api/user/:id should return user object', async () => {
    const res = await request.get(`/api/user/${realUserId}`)
    expect([200, 400, 401, 403, 404]).toContain(res.body.code !== undefined ? res.body.code : res.status)
    if (res.body.code === 200) {
      expect(res.body.username).toBeTruthy()
    }
  })

  test('GET /api/user/:id should return 404 for non-existent user', async () => {
    const res = await request.get('/api/user/99999999')
    expect(res.body.code).toBe(404)
  })
})

describe('Get User by Username', () => {
  test('GET /api/user/by-username/:username should return user data', async () => {
    const res = await request.get(`/api/user/by-username/${realUsername}`)
    expect([200, 404]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data.username).toBe(realUsername)
    }
  })

  test('GET /api/user/by-username/:username should return 404 for unknown user', async () => {
    const res = await request.get('/api/user/by-username/nonexistent_user_xyz')
    expect(res.body.code).toBe(404)
  })
})

describe('Search Users', () => {
  test('GET /api/user/search should return matching users', async () => {
    const res = await request.get('/api/user/search').query({ keyword: 'tst__' })
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/user/search should return empty for no match', async () => {
    const res = await request.get('/api/user/search').query({ keyword: 'zzznoonewouldusethis' })
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/user/search should reject empty keyword', async () => {
    const res = await request.get('/api/user/search').query({ keyword: '' })
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('User Profile', () => {
  test('GET /api/user/profile should return profile data', async () => {
    const res = await request.get('/api/user/profile').query({ userId: realUserId })
    expect([200, 400]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data.username).toBe(realUsername)
    }
  })

  test('GET /api/user/profile should reject without userId', async () => {
    const res = await request.get('/api/user/profile')
    expect(res.body.code).toBe(400)
  })

  test('PUT /api/user/profile should update profile', async () => {
    const res = await request
      .put('/api/user/profile')
      .set('Authorization', `Bearer ${testToken}`)
      .query({ userId: realUserId })
      .send({ nickname: 'TestNick', bio: 'Test bio content' })
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('PUT /api/user/profile should reject without auth', async () => {
    const res = await request
      .put('/api/user/profile')
      .query({ userId: realUserId })
      .send({ nickname: 'NoAuth' })
    expect(res.body.code).toBe(401)
  })
})

describe('Privacy Settings', () => {
  test('GET /api/user/privacy-settings should return settings', async () => {
    const res = await request
      .get('/api/user/privacy-settings')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toHaveProperty('hideBirthday')
      expect(res.body.data).toHaveProperty('hideQq')
      expect(res.body.data).toHaveProperty('hideEmail')
      expect(res.body.data).toHaveProperty('hideAddress')
    }
  })

  test('PUT /api/user/privacy-settings should update settings', async () => {
    const res = await request
      .put('/api/user/privacy-settings')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ hideBirthday: true, hideQq: true, hideEmail: false, hideAddress: false })
    expect([200, 401]).toContain(res.body.code)
    const res2 = await request
      .get('/api/user/privacy-settings')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 401]).toContain(res2.body.code)
  })
})

describe('Block User', () => {
  test('POST /api/user/:id/block should block a user', async () => {
    const res = await request
      .post(`/api/user/${user2Id}/block`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'Test block' })
    expect([200, 401]).toContain(res.body.code)
  })

  test('POST /api/user/:id/block should reject duplicate block', async () => {
    const res = await request
      .post(`/api/user/${user2Id}/block`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ reason: 'Test block again' })
    expect([400, 401]).toContain(res.body.code)
  })

  test('POST /api/user/:id/block should reject self-block', async () => {
    const res = await request
      .post(`/api/user/${realUserId}/block`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 403]).toContain(res.body.code)
  })

  test('GET /api/user/blocked should return blocked list', async () => {
    const res = await request
      .get('/api/user/blocked')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toHaveProperty('list')
      expect(res.body.data.list.length).toBeGreaterThan(0)
    }
  })

  test('GET /api/user/block-status/:id should return isBlocked true', async () => {
    const res = await request
      .get(`/api/user/block-status/${user2Id}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data.isBlocked).toBe(true)
    }
  })

  test('GET /api/user/block-status/:id should return isBlocked false', async () => {
    const res = await request
      .get(`/api/user/block-status/999999`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data.isBlocked).toBe(false)
    }
  })

  test('DELETE /api/user/:id/block should unblock a user', async () => {
    const res = await request
      .delete(`/api/user/${user2Id}/block`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('DELETE /api/user/:id/block should work even if not blocked', async () => {
    const res = await request
      .delete(`/api/user/${user2Id}/block`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('GET /api/user/blocked should require auth', async () => {
    const res = await request.get('/api/user/blocked')
    expect(res.body.code).toBe(401)
  })
})

describe('Follow User', () => {
  test('POST /api/user/:id/follow should follow a user', async () => {
    const res = await request
      .post(`/api/user/${user2Id}/follow`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('POST /api/user/:id/follow should reject duplicate follow', async () => {
    const res = await request
      .post(`/api/user/${user2Id}/follow`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 403]).toContain(res.body.code)
  })

  test('POST /api/user/:id/follow should reject self-follow', async () => {
    const res = await request
      .post(`/api/user/${realUserId}/follow`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 403]).toContain(res.body.code)
  })

  test('GET /api/user/:id/follow-status should return isFollowing true', async () => {
    const res = await request
      .get(`/api/user/${user2Id}/follow-status`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(typeof res.body.data.isFollowing).toBe('boolean')
    }
  })

  test('GET /api/user/:id/following should return following list', async () => {
    const res = await request.get(`/api/user/${realUserId}/following`)
    expect([200, 500]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toHaveProperty('list')
    }
  })

  test('GET /api/user/:id/followers should return followers list', async () => {
    const res = await request.get(`/api/user/${user2Id}/followers`)
    expect([200, 500]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toHaveProperty('list')
    }
  })

  test('DELETE /api/user/:id/follow should unfollow', async () => {
    const res = await request
      .delete(`/api/user/${user2Id}/follow`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('DELETE /api/user/:id/follow should work even if not following', async () => {
    const res = await request
      .delete(`/api/user/${user2Id}/follow`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('POST /api/user/:id/follow should reject without auth', async () => {
    const res = await request.post(`/api/user/${user2Id}/follow`)
    expect([401, 403]).toContain(res.body.code)
  })
})

describe('User Comments', () => {
  test('GET /api/user/comments should return comments', async () => {
    const res = await request.get('/api/user/comments').query({ userId: realUserId })
    expect([200, 400]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toHaveProperty('list')
      expect(res.body.data).toHaveProperty('total')
    }
  })

  test('GET /api/user/comments should reject without userId', async () => {
    const res = await request.get('/api/user/comments')
    expect(res.body.code).toBe(400)
  })
})

describe('User Apps', () => {
  test('GET /api/user/apps should return apps list', async () => {
    const res = await request.get('/api/user/apps').query({ userId: realUserId })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(Array.isArray(res.body.data.list)).toBe(true)
  })
})

describe('User Addresses', () => {
  let addressId = 0

  test('GET /api/user/addresses should return address list', async () => {
    const res = await request
      .get('/api/user/addresses')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(Array.isArray(res.body.data)).toBe(true)
    }
  })

  test('POST /api/user/addresses should create an address', async () => {
    const res = await request
      .post('/api/user/addresses')
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        name: 'Test User',
        phone: '13800138000',
        province: 'Beijing',
        city: 'Beijing',
        district: 'Haidian',
        detail: 'No.1 Test Street',
        isDefault: 1
      })
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toBeDefined()
      addressId = res.body.data.id
    }
  })

  test('DELETE /api/user/addresses/:id should delete an address', async () => {
    if (!addressId) return
    const res = await request
      .delete(`/api/user/addresses/${addressId}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('DELETE /api/user/addresses/:id should fail for non-existent address', async () => {
    const res = await request
      .delete('/api/user/addresses/999999')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })

  test('GET /api/user/addresses should reject without auth', async () => {
    const res = await request.get('/api/user/addresses')
    expect(res.body.code).toBe(401)
  })
})

describe('Dashboard Stats', () => {
  test('GET /api/user/dashboard/stats should return stats', async () => {
    const res = await request
      .get('/api/user/dashboard/stats')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('totalPosts')
    expect(res.body.data).toHaveProperty('currentLevel')
  })

  test('GET /api/user/dashboard/stats should reject without auth', async () => {
    const res = await request.get('/api/user/dashboard/stats')
    expect(res.body.code).toBe(401)
  })
})

describe('Balance Records', () => {
  test('GET /api/user/balance-records should return records', async () => {
    const res = await request.get('/api/user/balance-records').query({ userId: realUserId })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
  })

  test('GET /api/user/balance-records should reject without userId', async () => {
    const res = await request.get('/api/user/balance-records')
    expect(res.body.code).toBe(400)
  })
})

describe('Experience Records', () => {
  test('GET /api/user/experience-records should return records', async () => {
    const res = await request.get('/api/user/experience-records').query({ userId: realUserId })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
  })

  test('GET /api/user/experience-records should reject without userId', async () => {
    const res = await request.get('/api/user/experience-records')
    expect(res.body.code).toBe(400)
  })
})

describe('Membership Records', () => {
  test('GET /api/user/membership-records should return records', async () => {
    const res = await request.get('/api/user/membership-records').query({ userId: realUserId })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toHaveProperty('list')
    expect(res.body.data).toHaveProperty('total')
  })

  test('GET /api/user/membership-records should reject without userId', async () => {
    const res = await request.get('/api/user/membership-records')
    expect(res.body.code).toBe(400)
  })
})

describe('Delete Request', () => {
  test('POST /api/user/delete-request should submit delete request', async () => {
    const res = await request
      .post('/api/user/delete-request')
      .send({ userId: realUserId })
    expect(res.body.code).toBe(200)
  })

  test('POST /api/user/delete-request should reject without userId', async () => {
    const res = await request
      .post('/api/user/delete-request')
      .send({})
    expect(res.body.code).toBe(400)
  })
})

describe('Appeal', () => {
  test('POST /api/user/appeal should reject without ban', async () => {
    const res = await request
      .post('/api/user/appeal')
      .send({ userId: realUserId, reason: 'My account was banned unfairly' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/user/appeal should reject without userId', async () => {
    const res = await request
      .post('/api/user/appeal')
      .send({ reason: 'Test appeal' })
    expect(res.body.code).toBe(400)
  })

  test('POST /api/user/appeal should reject without reason', async () => {
    const res = await request
      .post('/api/user/appeal')
      .send({ userId: realUserId })
    expect(res.body.code).toBe(400)
  })
})
