const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testPassword = 'Test123456'
const testUsernameBase = 'iu' + Date.now().toString(36)

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  await createTestUser(testUsernameBase, testPassword)
  const { token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Notifications', () => {
  test('GET /api/notifications should list notifications for authenticated user', async () => {
    const res = await request
      .get('/api/notifications')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/notifications should reject without auth', async () => {
    const res = await request.get('/api/notifications')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/notifications/unread-count should return unread count', async () => {
    const res = await request
      .get('/api/notifications/unread-count')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/notifications/unread-count should reject without auth', async () => {
    const res = await request.get('/api/notifications/unread-count')
    expect(res.body.code).toBe(401)
  })

  test('POST /api/notifications/read-all should mark all as read', async () => {
    const res = await request
      .post('/api/notifications/read-all')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
  })

  test('POST /api/notifications/read-all should reject without auth', async () => {
    const res = await request.post('/api/notifications/read-all')
    expect([401, 403]).toContain(res.body.code)
  })

  test('GET /api/notifications/types should return notification types', async () => {
    const res = await request.get('/api/notifications/types')
    expect(res.body.code).toBe(200)
  })
})

describe('Push Notifications', () => {
  test('POST /api/push-notification/send should attempt push send with auth', async () => {
    const res = await request
      .post('/api/push-notification/send')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ title: 'Test push', content: 'Test content' })
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('POST /api/push-notification/send should reject without auth', async () => {
    const res = await request
      .post('/api/push-notification/send')
      .send({ title: 'Test', content: 'Test' })
    expect(res.body.code).toBe(401)
  })

  test('GET /api/push-notification/history should return push history', async () => {
    const res = await request.get('/api/push-notification/history')
    expect(res.body.code).toBe(200)
  })

  test('GET /api/notification/history should return notification history', async () => {
    const res = await request.get('/api/notification/history')
    expect(res.body.code).toBe(200)
  })
})

describe('Messages', () => {
  test('GET /api/messages/conversations should list conversations', async () => {
    const res = await request
      .get('/api/messages/conversations')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })

  test('GET /api/messages/search should search messages', async () => {
    const res = await request
      .get('/api/messages/search')
      .set('Authorization', `Bearer ${testToken}`)
      .query({ query: 'test' })
    expect([200, 400]).toContain(res.body.code)
  })

  test('GET /api/messages/orders should return message orders', async () => {
    const res = await request
      .get('/api/messages/orders')
      .set('Authorization', `Bearer ${testToken}`)
    expect(res.body.code).toBe(200)
  })
})

describe('System Logs', () => {
  test('GET /api/system-log/categories should reject non-admin', async () => {
    const res = await request
      .get('/api/system-log/categories')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })

  test('GET /api/system-log/list should reject non-admin', async () => {
    const res = await request
      .get('/api/system-log/list')
      .set('Authorization', `Bearer ${testToken}`)
    expect([400, 401, 403]).toContain(res.body.code)
  })
})
