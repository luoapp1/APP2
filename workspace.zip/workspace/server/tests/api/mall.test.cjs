const {
  getApp,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost,
  testUserName
} = require('../helpers/test-utils.cjs')

let request
let testToken = ''
let testUserId = 0
let testPassword = 'Test123456'
const testUsernameBase = 'ml' + Date.now().toString(36)
let productIdForTests = 0

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  const { response: regRes, userId } = await createTestUser(testUsernameBase, testPassword)
  testUserId = userId || 0

  const { response: loginRes, token } = await loginTestUser(testUsernameBase, testPassword)
  testToken = token || ''

  const productsRes = await request.get('/api/mall/products').query({ pageSize: 5 })
  if (productsRes.body.code === 200 && productsRes.body.data && productsRes.body.data.list && productsRes.body.data.list.length > 0) {
    productIdForTests = productsRes.body.data.list[0].id
  }
})

afterAll(async () => {
  await cleanupTestData()
})

describe('Mall Categories', () => {
  test('GET /api/mall/categories should return categories', async () => {
    const res = await request.get('/api/mall/categories')
    expect(res.status).toBe(200)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/mall/categories/all should return all categories', async () => {
    const res = await request.get('/api/mall/categories/all')
    expect(res.status).toBe(200)
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('Mall Products', () => {
  test('GET /api/mall/products should return paginated products list', async () => {
    const res = await request.get('/api/mall/products').query({ page: 1, pageSize: 5 })
    expect(res.body.code).toBe(200)
    expect(res.body.data).toBeDefined()
    if (res.body.data.list) {
      expect(Array.isArray(res.body.data.list)).toBe(true)
    }
  })

  test('GET /api/mall/products should support category filter', async () => {
    const res = await request.get('/api/mall/products').query({ categoryId: 1, pageSize: 5 })
    expect(res.body.code).toBe(200)
  })

  test('GET /api/mall/products/:id should return product detail', async () => {
    if (!productIdForTests) return
    const res = await request.get(`/api/mall/products/${productIdForTests}`)
    expect([200, 500]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toBeDefined()
      expect(res.body.data.id).toBe(productIdForTests)
    }
  })

  test('GET /api/mall/products/:id should return 404 for non-existent product', async () => {
    const res = await request.get('/api/mall/products/99999')
    expect([404, 500]).toContain(res.body.code)
  })

  test('GET /api/mall/cart should require auth', async () => {
    const res = await request.get('/api/mall/cart')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/mall/cart should return cart with auth', async () => {
    const res = await request
      .get('/api/mall/cart')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })

  test('POST /api/mall/cart should require auth', async () => {
    const res = await request
      .post('/api/mall/cart')
      .send({ productId: 1, quantity: 1 })
    expect(res.body.code).toBe(401)
  })

  test('POST /api/mall/cart should reject missing productId', async () => {
    const res = await request
      .post('/api/mall/cart')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ quantity: 1 })
    expect([400, 401]).toContain(res.body.code)
  })

  test('POST /api/mall/cart should add product to cart', async () => {
    if (!productIdForTests) return
    const res = await request
      .post('/api/mall/cart')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ productId: productIdForTests, quantity: 1 })
    expect([200, 400, 401]).toContain(res.body.code)
  })

  test('POST /api/mall/cart should handle non-existent product gracefully', async () => {
    const res = await request
      .post('/api/mall/cart')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ productId: 99999, quantity: 1 })
    expect([400, 401, 404]).toContain(res.body.code)
  })

  test('POST /api/mall/cart/clear should clear cart', async () => {
    const res = await request
      .post('/api/mall/cart/clear')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 400, 403]).toContain(res.body.code)
  })
})

describe('Mall Favorites', () => {
  test('GET /api/mall/favorites should require auth', async () => {
    const res = await request.get('/api/mall/favorites')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/mall/favorites should list favorites with auth', async () => {
    const res = await request
      .get('/api/mall/favorites')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(Array.isArray(res.body.data)).toBe(true)
    }
  })

  test('POST /api/mall/favorites/:productId should require auth', async () => {
    const res = await request.post('/api/mall/favorites/1')
    expect([401, 403]).toContain(res.body.code)
  })

  test('POST /api/mall/favorites/:productId should toggle favorite', async () => {
    if (!productIdForTests) return
    const res = await request
      .post(`/api/mall/favorites/${productIdForTests}`)
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 403]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(res.body.data).toBeDefined()
    }
  })
})

describe('User Addresses', () => {
  test('GET /api/user/addresses should require auth', async () => {
    const res = await request.get('/api/user/addresses')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/user/addresses should list addresses with auth', async () => {
    const res = await request
      .get('/api/user/addresses')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
    if (res.body.code === 200) {
      expect(Array.isArray(res.body.data)).toBe(true)
    }
  })

  test('GET /api/mall/orders should handle request', async () => {
    const res = await request.get('/api/mall/orders')
    expect([200, 400, 401, 404]).toContain(res.body.code || res.status)
  })
})

describe('Recharge', () => {
  test('GET /api/recharge/amounts should return amounts', async () => {
    const res = await request.get('/api/recharge/amounts')
    expect(res.body.code).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  test('GET /api/recharge/orders should require auth', async () => {
    const res = await request.get('/api/recharge/orders')
    expect(res.body.code).toBe(401)
  })

  test('GET /api/recharge/orders should list orders with auth', async () => {
    const res = await request
      .get('/api/recharge/orders')
      .set('Authorization', `Bearer ${testToken}`)
    expect([200, 401]).toContain(res.body.code)
  })
})
