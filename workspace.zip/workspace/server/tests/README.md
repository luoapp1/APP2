# API 集成测试

## 快速开始

```bash
# 确保 MySQL 已启动且 art_design_pro 数据库已配置
npm run test:api          # 运行全部测试
npm run test:api:watch    # 持续监听模式（文件变更自动重跑）
```

> 测试约耗时 1~2 秒，依赖生产数据库，通过 `tst__` 前缀隔离测试数据。

---

## 前置条件

| 条件 | 说明 |
|------|------|
| MySQL 运行中 | 测试直接读写 `art_design_pro` 数据库 |
| `server/.env` 已配置 | `DB_*` 变量指向可用的数据库 |
| Jest + Supertest 全局安装 | `npm run test:api` 通过 `NODE_PATH=/usr/local/lib/node_modules` 加载 |
| 板块数据存在 | `core.test.cjs` 中发帖测试依赖 `GET /api/community/sections` 返回至少一个板块 |

---

## 目录结构

```
<项目根>/
├── jest.config.cjs                       # Jest 配置文件
└── server/tests/
    ├── README.md                         # 本文档
    ├── helpers/
    │   ├── global-setup.cjs              # 前置任务：关闭邮箱验证、关闭 ID 起始编号
    │   ├── global-teardown.cjs           # 后置任务：恢复配置、关闭数据库连接池
    │   └── test-utils.cjs                # 测试工具集（用户/帖子/评论创建、数据清理）
    └── api/
        └── core.test.cjs                 # 核心 API 测试用例（10 条）
```

> 不存在 `.env.test` 文件。环境变量由 `server/.env` 提供，`global-setup.cjs` 通过 `INSERT ... ON DUPLICATE KEY UPDATE` 覆盖 `sys_config` 中的 URL 验证相关配置。

---

## 架构设计

### 请求链路

```
Jest → Supertest(server/index.cjs 导出的 app)
    → CORS / CSRF / Rate Limit 中间件
    → 路由 → 业务逻辑 → SQL
    → 真实数据库（art_design_pro）
    → JSON 响应
```

- **不 Mock 任何环节**：请求经过完整的中间件链，包括 CORS、CSRF 校验、限流。
- **不启动 HTTP 端口**：`server/index.cjs` 中 `require.main === module` 判定为 `false` 时只导出 `app`，不调用 `app.listen()`。
- **懒加载 + 单例**：`getApp()` 首次调用时 `require` 并缓存，后续复用同一个 `app` 实例。

### 数据隔离策略

| 维度 | 方式 |
|------|------|
| 测试数据标识 | 全部测试用户/帖子/评论以 `tst__` 为前缀 |
| 清理时机 | 每个 `describe` 的 `beforeAll` + `afterAll` 各执行一次 `cleanupTestData()` |
| 清理范围 | `DELETE FROM users/community_posts/community_comments WHERE ... LIKE 'tst__%'` |
| 配置回滚 | `global-teardown` 恢复 `register_verify_type` 和 `register_start_id` |

### 全局生命周期

```
global-setup.cjs
  ├── 设置 NODE_ENV=test
  ├── 加载 .env.test（如有，当前不存在则跳过）
  ├── 关闭 register_verify_type → none
  └── 关闭 register_start_id → 0
       ↓
  测试文件执行
  beforeAll → 测试用例 → afterAll
       ↓
global-teardown.cjs
  ├── 恢复 register_verify_type → email
  ├── 恢复 register_start_id → 10001
  └── pool.end() 关闭连接池
```

---

## 当前覆盖（10 条）

| 模块 | 测试用例 | 端点 | 验证点 |
|------|---------|------|--------|
| Auth | 注册成功 | `POST /api/auth/register` | `code=200`, `userId > 0` |
| Auth | 重复注册拒绝 | `POST /api/auth/register` | `code=400` |
| Auth | 登录成功 | `POST /api/auth/login` | `code=200`, 返回 `token` |
| Auth | 错误密码拒绝 | `POST /api/auth/login` | `code=400` |
| Community | 板块列表 | `GET /api/community/sections` | `code=200`, 数组返回 |
| Community | 无鉴权发帖被拒 | `POST /api/community/post` | `code=401` |
| Community | 鉴权后发帖成功 | `POST /api/community/post` | `code=200`, `postId > 0` |
| Community | 帖子列表分页 | `GET /api/community/posts` | `code=200`, 有 list 数组 |
| Mall | 商品列表 | `GET /api/mall/products` | `code=200` |
| Mall | 分类列表 | `GET /api/mall/categories` | `code=200` |

---

## 工具函数

`server/tests/helpers/test-utils.cjs` 导出以下函数和常量：

### 核心工具

| 函数 | 签名 | 返回值 | 说明 |
|------|------|--------|------|
| `getApp()` | `() → { app, request }` | Express app + Supertest 实例 | 懒加载，全局单例 |
| `cleanupTestData()` | `() → Promise<void>` | 无 | 清空所有 `tst__` 前缀数据 |
| `getPool()` | `() → Pool` | mysql2 连接池 | 直接访问数据库 |
| `query(sql, params)` | `(string, any[]) → Promise` | 查询结果 | 同 `database.cjs` 的 `query` |

### 测试数据创建

| 函数 | 签名 | 返回值 | 说明 |
|------|------|--------|------|
| `createTestUser(name, password)` | `(string, string) → { response, username, userId }` | 注册结果 | 自动加 `tst__` 前缀 |
| `loginTestUser(name, password)` | `(string, string) → { response, token }` | 登录结果 | 自动加 `tst__` 前缀 |
| `createTestPost(token, sectionId, title, content)` | `(string, number, string, string) → { response, postId }` | 发帖结果 | `content` 可选，默认 `'Test content'` |
| `createTestComment(token, postId, parentId, content)` | `(string, number, number, string) → { response, commentId }` | 评论结果 | `parentId` 默认 `0`（一级评论） |

### 前缀工具

| 常量/函数 | 说明 |
|-----------|------|
| `TEST_PREFIX` | 固定为 `'tst__'` |
| `testUserName(name)` | 返回 `'tst__' + name` |
| `testPostTitle(name)` | 返回 `'tst__' + name` |
| `testCommentContent(name)` | 返回 `'tst__' + name` |

---

## 添加新测试

### 新建测试文件

在 `server/tests/api/` 下创建 `xxx.test.cjs`，Jest 会自动发现 `**/*.test.cjs`：

```js
const {
  getApp,
  createTestUser,
  loginTestUser,
  createTestPost,
  createTestComment,
  cleanupTestData
} = require('../helpers/test-utils.cjs')

let request, token, postId

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()

  // 注册并登录
  const { response: regRes } = await createTestUser('testuser', 'Pass123456')
  expect(regRes.body.code).toBe(200)

  const { token: t } = await loginTestUser('testuser', 'Pass123456')
  token = t

  // 创建测试帖子
  const sectionsRes = await request.get('/api/community/sections')
  if (sectionsRes.body?.data?.length > 0) {
    const sectionId = sectionsRes.body.data[0].id
    const { postId: pid } = await createTestPost(token, sectionId, 'test_post', 'content')
    postId = pid
  }
})

afterAll(async () => {
  await cleanupTestData()
})

// 正常路径
test('GET /api/xxx returns 200', async () => {
  const res = await request.get('/api/xxx')
  expect(res.body.code).toBe(200)
})

// 鉴权异常
test('POST /api/xxx requires auth', async () => {
  const res = await request.post('/api/xxx').send({ key: 'value' })
  expect(res.body.code).toBe(401)
})

// 鉴权正常
test('POST /api/xxx with token succeeds', async () => {
  const res = await request
    .post('/api/xxx')
    .set('Authorization', `Bearer ${token}`)
    .send({ key: 'value' })
  expect(res.body.code).toBe(200)
})
```

### 推荐测试分组

按功能模块拆分为独立文件：

```
api/
├── core.test.cjs          # Auth + Community + Mall（已有）
├── user.test.cjs          # 用户资料 / 关注 / 拉黑
├── points.test.cjs        # 积分 / 余额 / 转账
├── membership.test.cjs    # 会员购买 / 卡密兑换
├── notification.test.cjs  # 系统通知 / 私信
├── moderation.test.cjs    # 举报 / 审核 / 封禁
└── search.test.cjs        # 全文搜索
```

---

## 编写规范

### 基本要求

1. **测试数据用工具函数创建**：`createTestUser`、`createTestPost`、`createTestComment` 自动加 `tst__` 前缀
2. **必须清理**：`beforeAll` 开头 + `afterAll` 结尾都调用 `cleanupTestData()`
3. **正常 + 异常双路径**：每条 API 至少覆盖成功和失败两种情况
4. **鉴权格式**：`Authorization: Bearer <token>`，token 从 `loginTestUser` 获取
5. **不测试管理端**：管理端 API 需要 `R_ADMIN` / `R_SUPER` 角色，测试用户默认无权限

### 测试用例命名

```js
test('METHOD /api/path should describe expected behavior', async () => { ... })
```

示例：
- `test('POST /api/user/update should update nickname', ...)`
- `test('POST /api/user/update should reject without auth', ...)`
- `test('POST /api/user/update should reject empty nickname', ...)`

### 常用断言模式

```js
// 状态码
expect(res.body.code).toBe(200)

// 空参数兜底
expect(res.body.code).toBe(400)

// 鉴权缺失
expect(res.body.code).toBe(401)

// 分页结构
expect(res.body.data).toHaveProperty('list')
expect(res.body.data).toHaveProperty('total')

// ID 有效性
expect(res.body.data.userId).toBeGreaterThan(0)

// 数组返回
expect(Array.isArray(res.body.data)).toBe(true)
```

### 数据依赖处理

当测试用例有执行顺序依赖时，用 `describe` 内的 `test` 顺序保证（Jest 默认按声明顺序串行）：

```js
describe('Post lifecycle', () => {
  let postId

  test('STEP 1: create post', async () => {
    const { postId: pid } = await createTestPost(token, sectionId, 'title', 'body')
    postId = pid
    expect(postId).toBeGreaterThan(0)
  })

  test('STEP 2: edit post', async () => {
    const res = await request
      .put(`/api/community/post/${postId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'updated' })
    expect(res.body.code).toBe(200)
  })

  test('STEP 3: delete post', async () => {
    const res = await request
      .delete(`/api/community/post/${postId}`)
      .set('Authorization', `Bearer ${token}`)
    expect(res.body.code).toBe(200)
  })
})
```

---

## 调试

### 运行单个文件

```bash
npm run test:api -- server/tests/api/core.test.cjs
```

### 运行单个 describe / test

```js
// 仅运行 User Auth 分组
test.only('...', async () => { ... })
// 或
describe.only('User Auth APIs', () => { ... })
```

### 查看 SQL 日志

在 `test-utils.cjs` 中开启调试：

```js
const { query } = require('../database.cjs')
// 临时加一行
console.log('SQL:', sql, params)
```

### 手动清理测试数据

```bash
mysql -u artpro -partpro2026 art_design_pro \
  -e "DELETE FROM community_comments WHERE content LIKE 'tst__%';
      DELETE FROM community_posts WHERE title LIKE 'tst__%';
      DELETE FROM users WHERE username LIKE 'tst__%';"
```

---

## 已知限制

| 限制 | 影响 | 缓解措施 |
|------|------|----------|
| 共享生产数据库 | 测试数据可能被手工操作干扰 | `tst__` 前缀 + `cleanupTestData()` 隔离 |
| 依赖全局 npm 模块 | 需要预先安装 Jest/Supertest | `NODE_PATH=/usr/local/lib/node_modules` |
| 不覆盖管理端 API | 无法测试管理员功能 | 可在测试前手动提升用户角色 |
| 不覆盖文件上传 | 图片/附件上传未测试 | 依赖 multer 的中间件链验证 |
| 不覆盖 WebSocket | 聊天 / 推送未测试 | 需引入 ws 客户端库 |
| 板块数据依赖 | `core.test.cjs` 发帖测试要求至少存在一个板块 | 可通过 `global-setup` 确保种子数据存在 |

---

## 常见问题

### Q: 测试报 `ECONNREFUSED` 怎么办？

确认 MySQL 已启动，`server/.env` 中 `DB_HOST`、`DB_PORT` 配置正确：

```bash
mysql -u artpro -partpro2026 -e "SELECT 1"
```

### Q: 测试报 `ER_NO_SUCH_TABLE` 怎么办？

确认数据库已导入 SQL：

```bash
mysql -u artpro -partpro2026 art_design_pro -e "SHOW TABLES" | wc -l
```

### Q: 发帖测试提示 `code=500, msg='板块不存在'`？

测试需要至少一个已启用的板块。先访问 `/s/1` 确认板块存在，或在 `global-setup.cjs` 中插入种子板块数据。

### Q: 如何测试需要特定角色/会员等级的接口？

在 `beforeAll` 中通过 `query()` 直接修改用户字段：

```js
const { query } = require('../helpers/test-utils.cjs')
await query("UPDATE users SET roles='[\"R_ADMIN\"]', level_id=2 WHERE username=?", [testUsername])
```
