# API 集成测试

## 快速开始

```bash
npm run test:api          # 运行全部测试（约 1.2 秒）
npm run test:api:watch    # 持续监听模式
```

## 目录结构

```
server/tests/
├── .env.test                # 测试环境变量
├── jest.config.cjs          # Jest 配置
├── helpers/
│   ├── global-setup.cjs     # 前置：关闭邮箱验证、关闭 ID 起始编号
│   ├── global-teardown.cjs  # 后置：恢复配置、关闭连接池
│   └── test-utils.cjs       # 注册/登录/发帖工具 + 数据清理
└── api/
    └── core.test.cjs        # 核心 API 测试用例
```

## 架构

- **测试框架**: Jest + Supertest
- **数据隔离**: 测试用户/帖子以 `tst__` 前缀命名，每次运行 `beforeAll` 统一清理
- **配置切换**: `global-setup` 关闭邮箱验证，`global-teardown` 恢复，不影响手工环境
- **真实环境**: 请求经过完整中间件链 → 路由 → SQL → 响应，不做任何 mock
- **启动方式**: `server/index.cjs` 通过 `require.main === module` 判断，测试时只导出 `app` 不调用 `listen()`

## 当前覆盖（10 条）

| 模块 | 用例 | 说明 |
|------|------|------|
| Auth | 注册成功 | 返回 userId |
| Auth | 重复注册拒绝 | code 400 |
| Auth | 登录成功 | 返回 token |
| Auth | 错误密码拒绝 | code 400 |
| Community | 板块列表 | 数组返回 |
| Community | 无 auth 发帖被拒 | code 401 |
| Community | 有 auth 发帖成功 | 返回 postId |
| Community | 帖子列表分页 | list + total |
| Mall | 商品列表 | code 200 |
| Mall | 分类列表 | code 200 |

## 添加新测试

在 `server/tests/api/` 新建 `xxx.test.cjs`:

```js
const { getApp, createTestUser, loginTestUser, cleanupTestData } = require('../helpers/test-utils.cjs')

let request, token

beforeAll(async () => {
  ({ request } = getApp())
  await cleanupTestData()
  const { response: regRes } = await createTestUser('testuser', 'Pass123456')
  expect(regRes.body.code).toBe(200)
  const { token: t } = await loginTestUser('testuser', 'Pass123456')
  token = t
})

afterAll(async () => {
  await cleanupTestData()
})

test('GET /api/xxx should return 200', async () => {
  const res = await request.get('/api/xxx')
  expect(res.body.code).toBe(200)
})

test('POST /api/xxx should require auth', async () => {
  const res = await request.post('/api/xxx').send({ key: 'value' })
  expect(res.body.code).toBe(401)
})

test('POST /api/xxx with token should succeed', async () => {
  const res = await request
    .post('/api/xxx')
    .set('Authorization', `Bearer ${token}`)
    .send({ key: 'value' })
  expect(res.body.code).toBe(200)
})
```

## 工具函数

| 函数 | 说明 |
|------|------|
| `createTestUser(name, password)` | 注册用户（自动加 `tst__` 前缀），返回 `{ response, username, userId }` |
| `loginTestUser(name, password)` | 登录（自动加前缀），返回 `{ response, token }` |
| `createTestPost(token, sectionId, title, content)` | 发帖（自动加前缀），返回 `{ response, postId }` |
| `cleanupTestData()` | 删除所有 `tst__` 前缀的用户、帖子、评论 |
| `getApp()` | 返回 `{ app, request }`（懒加载 + 单例） |

## 编写规范

1. 测试数据用 `test-utils` 工具函数创建，自动带 `tst__` 前缀
2. `beforeAll` 中 `cleanupTestData()`，`afterAll` 中同样调用
3. 同时测试**正常路径**和**异常路径**（缺 auth、缺参数、无效输入）
4. 鉴权用 `Bearer TOKEN` 格式，从 `loginTestUser` 获取
5. 不测试管理端 Auth（管理端需要 `isAdmin` 权限，测试用户默认无）

## 已知限制

- 共享生产数据库，通过前缀隔离，不创建独立测试库
- 依赖 Jest 和 Supertest 全局安装在 `/usr/local/lib/node_modules`
- 未覆盖管理端 API（需要管理员角色）
- 未覆盖文件上传类 API
