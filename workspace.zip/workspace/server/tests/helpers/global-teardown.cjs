const path = require('path')

module.exports = async () => {
  try {
    const { query, getPool } = require(path.join(__dirname, '..', '..', 'database.cjs'))
    await query("UPDATE sys_config SET config_value='email' WHERE config_key='register_verify_type'")
    await query("UPDATE sys_config SET config_value='10001' WHERE config_key='register_start_id'")
    const pool = getPool()
    if (pool) {
      await pool.end()
    }
  } catch (e) {
    // 忽略关闭错误
  }
  console.log('[Test Teardown] Done')
}
