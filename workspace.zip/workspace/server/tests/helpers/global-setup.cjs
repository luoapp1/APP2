const path = require('path')
const fs = require('fs')

function loadEnv(filePath) {
  if (!fs.existsSync(filePath)) return
  const lines = fs.readFileSync(filePath, 'utf-8').split('\n')
  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const eqIdx = trimmed.indexOf('=')
    if (eqIdx === -1) continue
    const key = trimmed.slice(0, eqIdx).trim()
    const val = trimmed.slice(eqIdx + 1).trim()
    if (key && !process.env[key]) {
      process.env[key] = val
    }
  }
}

module.exports = async () => {
  process.env.NODE_ENV = 'test'
  loadEnv(path.join(__dirname, '..', '.env.test'))
  console.log('[Test Setup] DB:', process.env.DB_NAME, 'Host:', process.env.DB_HOST)

  try {
    const { query } = require(path.join(__dirname, '..', '..', 'database.cjs'))
    await query("INSERT INTO sys_config (config_key, config_value) VALUES ('register_verify_type', 'none') ON DUPLICATE KEY UPDATE config_value='none'")
    await query("INSERT INTO sys_config (config_key, config_value) VALUES ('register_start_id', '0') ON DUPLICATE KEY UPDATE config_value='0'")
    console.log('[Test Setup] Disabled email verification for tests')
  } catch (e) {
    console.warn('[Test Setup] Failed to configure test settings:', e.message)
  }
}
