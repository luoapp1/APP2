const path = require('path')
const supertest = require('supertest')
const { query, getPool } = require(path.join(__dirname, '..', '..', 'database.cjs'))

let _app = null
let _request = null

function getApp() {
  if (!_app) {
    _app = require(path.join(__dirname, '..', '..', 'index.cjs'))
    _request = supertest(_app)
  }
  return { app: _app, request: _request }
}

const TEST_PREFIX = 'tst__'

function testUserName(name) { return TEST_PREFIX + name }
function testPostTitle(name) { return TEST_PREFIX + name }
function testCommentContent(name) { return TEST_PREFIX + name }

async function cleanupTestData() {
  try {
    await query(`DELETE FROM community_comments WHERE content LIKE ?`, [TEST_PREFIX + '%'])
    await query(`DELETE FROM community_posts WHERE title LIKE ?`, [TEST_PREFIX + '%'])
    await query(`DELETE FROM users WHERE username LIKE ?`, [TEST_PREFIX + '%'])
  } catch (e) {
    // 表可能不存在，忽略
  }
}

async function createTestUser(username, password) {
  const name = testUserName(username)
  const { request } = getApp()
  const res = await request
    .post('/api/auth/register')
    .send({ username: name, password, confirmPassword: password })
  return { response: res, username: name, userId: res.body?.data?.userId }
}

async function loginTestUser(username, password) {
  const { request } = getApp()
  const res = await request
    .post('/api/auth/login')
    .send({ username: testUserName(username), password })
  return { response: res, token: res.body?.data?.token }
}

async function createTestPost(token, sectionId, title, content) {
  const { request } = getApp()
  const res = await request
    .post('/api/community/post')
    .set('Authorization', `Bearer ${token}`)
    .send({ sectionId, title: testPostTitle(title), content: content || 'Test content' })
  return { response: res, postId: res.body?.data?.id }
}

async function createTestComment(token, postId, parentId, content) {
  const { request } = getApp()
  const res = await request
    .post('/api/community/comment/create')
    .set('Authorization', `Bearer ${token}`)
    .send({ postId, parentId: parentId || 0, content: testCommentContent(content) })
  return { response: res, commentId: res.body?.data?.id }
}

module.exports = {
  getApp,
  query,
  getPool,
  cleanupTestData,
  createTestUser,
  loginTestUser,
  createTestPost,
  createTestComment,
  TEST_PREFIX,
  testUserName,
  testPostTitle,
  testCommentContent
}
