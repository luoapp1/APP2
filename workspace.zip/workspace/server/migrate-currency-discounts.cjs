const { query } = require('./database.cjs')

async function migrateCurrencyDiscounts() {
  console.log('=== 开始迁移 currency_discounts ===')

  const rows = await query('SELECT id, name, discount_rate, points_discount_rate FROM membership_levels')

  let updated = 0
  for (const row of rows) {
    const discounts = {}
    const dr = Number(row.discount_rate || 1)
    const pdr = Number(row.points_discount_rate || 1)

    if (dr < 1) discounts.balance = dr
    if (pdr < 1) discounts.points = pdr

    const json = Object.keys(discounts).length > 0 ? JSON.stringify(discounts) : null
    await query('UPDATE membership_levels SET currency_discounts = ? WHERE id = ?', [json, row.id])
    updated++
    console.log(`  [${row.name}] discount_rate=${dr} points_discount_rate=${pdr} → currency_discounts=${json}`)
  }

  console.log('=== 迁移完成 ===')
  console.log(`更新: ${updated} 条记录`)
}

migrateCurrencyDiscounts()
  .then(() => process.exit(0))
  .catch((err) => { console.error(err); process.exit(1) })
