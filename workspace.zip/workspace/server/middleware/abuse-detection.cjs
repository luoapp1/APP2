const { query } = require('../database.cjs')

const DEFAULT_THRESHOLDS = {
  spam_post_count: 10,       // 短时发帖数阈值
  spam_post_minutes: 5,       // 检测窗口(分钟)
  spam_post_level: 2,         // 风险等级
  batch_register_count: 5,    // 同 IP 24h 注册数阈值
  batch_register_level: 3,    // 风险等级
  follow_bomb_count: 100,     // 1h 关注数阈值
  follow_bomb_level: 2,       // 风险等级
}

let _thresholds = null
let _thresholdsTime = 0
const THRESHOLD_CACHE_TTL = 300000

async function getThresholds() {
  if (_thresholds && (Date.now() - _thresholdsTime) < THRESHOLD_CACHE_TTL) return _thresholds
  try {
    const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'abuse_%'")
    const result = { ...DEFAULT_THRESHOLDS }
    for (const r of rows) {
      const key = r.config_key.replace('abuse_', '')
      const val = parseInt(r.config_value)
      if (!isNaN(val) && key in result) result[key] = val
    }
    _thresholds = result
    _thresholdsTime = Date.now()
    return result
  } catch {
    return DEFAULT_THRESHOLDS
  }
}

function clearThresholdCache() {
  _thresholds = null
  _thresholdsTime = 0
}

async function checkPostSpam(userId) {
  if (!userId) return
  try {
    const t = await getThresholds()
    const [row] = await query(
      'SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND create_time > DATE_SUB(NOW(), INTERVAL ? MINUTE)',
      [userId, t.spam_post_minutes]
    )
    if (row && row.cnt >= t.spam_post_count) {
      await recordRisk(userId, 'spam_post', t.spam_post_level, {
        count: row.cnt,
        window: t.spam_post_minutes + 'min',
        threshold: t.spam_post_count
      })
    }
  } catch (e) { console.error('[abuse] checkPostSpam error:', e.message) }
}

async function checkBatchRegister(ip, userId) {
  if (!ip || !userId) return
  try {
    const t = await getThresholds()
    const [row] = await query(
      'SELECT COUNT(*) as cnt FROM users WHERE reg_ip=? AND create_time > DATE_SUB(NOW(), INTERVAL 24 HOUR)',
      [ip]
    )
    if (row && row.cnt >= t.batch_register_count) {
      await recordRisk(userId, 'batch_register', t.batch_register_level, {
        ip,
        count: row.cnt,
        threshold: t.batch_register_count
      })
    }
  } catch (e) { console.error('[abuse] checkBatchRegister error:', e.message) }
}

async function checkFollowBomb(followerId) {
  if (!followerId) return
  try {
    const t = await getThresholds()
    const [row] = await query(
      'SELECT COUNT(*) as cnt FROM user_follows WHERE follower_id=? AND create_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
      [followerId]
    )
    if (row && row.cnt >= t.follow_bomb_count) {
      await recordRisk(followerId, 'follow_bomb', t.follow_bomb_level, {
        count: row.cnt,
        threshold: t.follow_bomb_count
      })
    }
  } catch (e) { console.error('[abuse] checkFollowBomb error:', e.message) }
}

async function recordRisk(userId, riskType, riskLevel, evidence) {
  try {
    const existing = await query(
      "SELECT id FROM user_risks WHERE user_id=? AND risk_type=? AND status='active'",
      [userId, riskType]
    )
    if (existing.length) {
      await query(
        'UPDATE user_risks SET risk_level=?, evidence=?, detected_at=NOW() WHERE id=?',
        [riskLevel, JSON.stringify(evidence), existing[0].id]
      )
    } else {
      await query(
        'INSERT INTO user_risks (user_id, risk_type, risk_level, evidence) VALUES (?,?,?,?)',
        [userId, riskType, riskLevel, JSON.stringify(evidence)]
      )
    }
    if (riskLevel >= 3) {
      await query("UPDATE users SET status='0' WHERE id=?", [userId])
    }
  } catch (e) { console.error('[abuse] recordRisk error:', e.message) }
}

module.exports = {
  checkPostSpam,
  checkBatchRegister,
  checkFollowBomb,
  getThresholds,
  clearThresholdCache,
}
