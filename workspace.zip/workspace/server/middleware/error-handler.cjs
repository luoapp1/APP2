/**
 * 统一错误处理中间件
 *
 * 捕获所有未处理的错误，返回统一的 JSON 响应格式。
 * 必须注册为最后一个中间件（在路由之后），才能捕获路由中抛出的错误。
 *
 * 功能：
 * - 捕获同步和异步错误
 * - 格式化错误消息
 * - 记录错误日志（开发环境）
 * - 区分已知错误和未知错误
 *
 * @module middleware/error-handler
 */

class AppError extends Error {
  constructor(message, statusCode = 500, code) {
    super(message)
    this.name = 'AppError'
    this.statusCode = statusCode
    this.code = code || statusCode
  }
}

function errorHandler(err, req, res, _next) {
  const statusCode = err.statusCode || err.status || 500
  const code = err.code || statusCode
  const message = statusCode === 500 ? '服务器内部错误' : err.message

  if (statusCode === 500) {
    console.error(`[Error] ${req.method} ${req.originalUrl}:`, err.stack || err.message)
  }

  res.status(statusCode).json({
    code,
    msg: message
  })
}

function serverError(res, e) {
  console.error('[ServerError]', e.stack || e.message || String(e))
  res.json({ code: 500, msg: '服务器内部错误' })
}

module.exports = { errorHandler, AppError, serverError }
