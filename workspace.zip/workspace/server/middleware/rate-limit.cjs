module.exports = function rateLimitMiddleware() {
  let rateLimit
  try {
    rateLimit = require('express-rate-limit')
  } catch (e) {
    // Fallback simple in-memory rate limiter
    const ipCounts = new Map()
    const WINDOW_MS = 60000

    // Clean expired entries every 5 minutes to prevent memory leak
    setInterval(() => {
      const now = Date.now()
      for (const [ip, entry] of ipCounts) {
        if (now > entry.resetAt) {
          ipCounts.delete(ip)
        }
      }
    }, 5 * 60 * 1000)

    return {
      general: (req, res, next) => {
        const ip = req.ip || req.connection.remoteAddress || 'unknown'
        const now = Date.now()
        const entry = ipCounts.get(ip) || { count: 0, resetAt: now + WINDOW_MS }
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + WINDOW_MS }
        entry.count++
        ipCounts.set(ip, entry)
        if (entry.count > 100) return res.status(429).json({ code: 429, msg: '请求过于频繁，请稍后再试' })
        next()
      },
      strict: (req, res, next) => {
        const ip = req.ip || req.connection.remoteAddress || 'unknown'
        const now = Date.now()
        const entry = ipCounts.get(ip) || { count: 0, resetAt: now + WINDOW_MS }
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + WINDOW_MS }
        entry.count++
        ipCounts.set(ip, entry)
        if (entry.count > 10) return res.status(429).json({ code: 429, msg: '请求过于频繁，请稍后再试' })
        next()
      }
    }
  }

  const generalLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 100,
    message: { code: 429, msg: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
  })

  const strictLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    message: { code: 429, msg: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
  })

  return { general: generalLimiter, strict: strictLimiter }
}
