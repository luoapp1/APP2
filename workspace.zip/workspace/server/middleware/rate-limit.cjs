module.exports = function rateLimitMiddleware() {
  let rateLimit
  let _fallbackIpCounts = null

  try {
    rateLimit = require('express-rate-limit')
  } catch (e) {
    // Fallback simple in-memory rate limiter
    const ipCounts = new Map()
    const WINDOW_MS = 60000
    _fallbackIpCounts = ipCounts

    // fallback map 清理已迁移至统一调度器 server/scheduler/tasks.cjs

    return {
      polling: (req, res, next) => {
        const ip = req.ip || req.connection.remoteAddress || 'unknown'
        const now = Date.now()
        const entry = ipCounts.get(ip) || { count: 0, resetAt: now + WINDOW_MS }
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + WINDOW_MS }
        entry.count++
        ipCounts.set(ip, entry)
        if (entry.count > 300) return res.status(429).json({ code: 429, msg: '请求过于频繁，请稍后再试' })
        next()
      },
      general: (req, res, next) => {
        const ip = req.ip || req.connection.remoteAddress || 'unknown'
        const now = Date.now()
        const entry = ipCounts.get(ip) || { count: 0, resetAt: now + WINDOW_MS }
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + WINDOW_MS }
        entry.count++
        ipCounts.set(ip, entry)
        if (entry.count > 100) return res.status(429).json({ code: 429, msg: '请求过于频繁，请稍后再试' })
        next()
      },
      strict: (req, res, next) => {
        const ip = req.ip || req.connection.remoteAddress || 'unknown'
        const now = Date.now()
        const entry = ipCounts.get(ip) || { count: 0, resetAt: now + WINDOW_MS }
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + WINDOW_MS }
        entry.count++
        ipCounts.set(ip, entry)
        if (entry.count > 10) return res.status(429).json({ code: 429, msg: '请求过于频繁，请稍后再试' })
        next()
      }
    }
  }

  const pollingLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 300,
    message: { code: 429, msg: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
  })

  const generalLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 100,
    message: { code: 429, msg: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
  })

  const strictLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    message: { code: 429, msg: '请求过于频繁，请稍后再试' },
    standardHeaders: true,
    legacyHeaders: false
  })

  return { polling: pollingLimiter, general: generalLimiter, strict: strictLimiter, _fallbackIpCounts }
}
