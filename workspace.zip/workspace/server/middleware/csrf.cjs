/**
 * CSRF 保护中间件
 * 对 POST/PUT/DELETE/PATCH 请求验证 Origin/Referer 头
 */
const ALLOWED_ORIGINS = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(s => s.trim())
  : []

function normalizeOrigin(origin) {
  if (!origin) return ''
  try {
    const u = new URL(origin)
    return u.origin
  } catch {
    return ''
  }
}

function getRequestOrigin(req) {
  const origin = req.headers['origin'] || ''
  const referer = req.headers['referer'] || ''
  return normalizeOrigin(origin) || normalizeOrigin(referer)
}

function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next()
  }

  // 调度器 API 使用密钥鉴权，跳过 CSRF
  if (req.path.startsWith('/api/scheduler/')) {
    return next()
  }

  const origin = getRequestOrigin(req)

  if (!origin) {
    const xRequestedWith = req.headers['x-requested-with']
    if (xRequestedWith) return next()

    const contentType = (req.headers['content-type'] || '').toLowerCase()
    if (contentType.includes('application/json') ||
        contentType.includes('multipart/form-data')) {
      return next()
    }

    return res.status(403).json({ code: 403, msg: '跨站请求伪造检测：缺少 Origin/Referer 头' })
  }

  if (ALLOWED_ORIGINS.length > 0) {
    const isAllowed = ALLOWED_ORIGINS.some(allowed => {
      if (allowed === '*') return true
      return origin === normalizeOrigin(allowed)
    })
    if (!isAllowed) {
      return res.status(403).json({ code: 403, msg: '跨站请求伪造检测：来源不被允许' })
    }
  }

  return next()
}

function corsOptions() {
  if (ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes('*')) {
    return { origin: '*', credentials: false }
  }
  return {
    origin: (origin, callback) => {
      if (!origin || ALLOWED_ORIGINS.includes(normalizeOrigin(origin))) {
        callback(null, true)
      } else {
        callback(null, false)
      }
    },
    credentials: true
  }
}

module.exports = { csrfProtection, corsOptions }
