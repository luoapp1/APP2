/**
 * 经验等级权限中间件
 * 基于 experience_permission_config 表（43行永久结构）
 * 每行一个权限，level_values 列存 JSON：{"1":"3","2":"3",...,"20":"8"}
 */

const { query } = require('../database.cjs')

/** 缓存权限配置（5分钟TTL） */
let _configCache = null
let _configCacheTime = 0
const CACHE_TTL = 5 * 60 * 1000

/** 加载全部43行权限配置，返回 { "module.key": {1: "val", 2: "val", ...} } */
async function loadPermissionConfig() {
  if (_configCache && (Date.now() - _configCacheTime) < CACHE_TTL) return _configCache
  const rows = await query('SELECT module, permission_key, permission_name, level_values FROM experience_permission_config')
  const map = {}
  for (const r of rows) {
    const fullKey = `${r.module}.${r.permission_key}`
    const raw = typeof r.level_values === 'string' ? JSON.parse(r.level_values) : r.level_values
    // 统一 key 为数字
    const values = {}
    for (const [k, v] of Object.entries(raw)) {
      values[Number(k)] = String(v)
    }
    map[fullKey] = values
  }
  _configCache = map
  _configCacheTime = Date.now()
  return map
}

/** 获取用户当前经验等级 */
async function getUserLevel(userId) {
  try {
    if (!userId) return 0
    const balRows = await query('SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=\'experience\'', [userId])
    const [user] = balRows.length > 0 ? [{ experience: Number(balRows[0].available || 0) }] : [{ experience: 0 }]
    if (!user) return 0
    const [lv] = await query(
      'SELECT level FROM experience_levels WHERE exp_required <= ? AND status="1" ORDER BY exp_required DESC LIMIT 1',
      [user.experience || 0]
    )
    return lv ? lv.level : 1
  } catch { return 1 }
}

/** 获取用户所有权限 { level, permissions: { "module.key": value_string } } */
async function getUserPermissions(userId) {
  const level = await getUserLevel(userId)
  const config = await loadPermissionConfig()
  const userPerms = {}
  for (const [fullKey, values] of Object.entries(config)) {
    const val = values[level]
    if (val !== undefined && val !== '') {
      userPerms[fullKey] = val
    }
  }
  return { level, permissions: userPerms }
}

/** 检查用户是否有特定权限（布尔型） */
async function hasPermission(userId, module, key) {
  const level = await getUserLevel(userId)
  const config = await loadPermissionConfig()
  const fullKey = `${module}.${key}`
  const values = config[fullKey]
  if (!values) return false
  const val = values[level]
  if (val === undefined || val === '') return false
  if (key === 'G1' || key === 'G2') return val !== 'false'
  return val === 'true'
}

/** 获取用户某个权限的数字值 */
async function getPermissionValue(userId, module, key) {
  const level = await getUserLevel(userId)
  const config = await loadPermissionConfig()
  const fullKey = `${module}.${key}`
  const values = config[fullKey]
  if (!values) return null
  const val = values[level]
  if (val === undefined || val === '') return null
  return Number(val)
}

/** 生成 Express 中间件：检查某些权限 */
function requireLevelPermission(module, key) {
  return async (req, res, next) => {
    try {
      const userId = req.user?.userId || (req.userId || 0)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const allowed = await hasPermission(userId, module, key)
      if (!allowed) return res.json({ code: 403, msg: '权限不足：当前等级不支持此操作' })
      next()
    } catch (e) {
      console.error(`[permission] ${module}.${key} check failed:`, e.message)
      next()
    }
  }
}

/** 获取用户某个权限的数组值（G1头像框/G2称号ID列表） */
async function getPermissionArray(userId, module, key) {
  const level = await getUserLevel(userId)
  const config = await loadPermissionConfig()
  const fullKey = `${module}.${key}`
  const values = config[fullKey]
  if (!values) return []
  const val = values[level]
  return (val || '').split(',').filter(Boolean).map(Number)
}

module.exports = {
  getUserLevel,
  getUserPermissions,
  hasPermission,
  getPermissionValue,
  getPermissionArray,
  requireLevelPermission,
  loadPermissionConfig
}
