process.env.TZ = 'Asia/Shanghai'
const express = require('express')
const cors = require('cors')
const path = require('path')
const { query } = require('./database.cjs')
const userRoutes = require('./routes/user.cjs')
const operationRoutes = require('./routes/operation.cjs')
const systemRoutes = require('./routes/system.cjs')
const menuRoutes = require('./routes/menu.cjs')
const appStoreRoutes = require('./routes/appstore.cjs')
const submissionRoutes = require('./routes/submission.cjs')
const officialTagRoutes = require('./routes/official-tags.cjs')
const uploadRoutes = require('./routes/upload.cjs')
const notificationRoutes = require('./routes/notification.cjs')
const notificationsRoutes = require('./routes/notifications.cjs')
const communityRoutes = require('./routes/community.cjs')
const communityTopicRoutes = require('./routes/community-topics.cjs')
const followRoutes = require('./routes/follow.cjs')
const titleRoutes = require('./routes/title.cjs')
const verificationRoutes = require('./routes/verification.cjs')
const emailRoutes = require('./routes/email.cjs')
const inviteRoutes = require('./routes/invite.cjs')
const fileRepoRoutes = require('./routes/file-repo.cjs')
const recycleRoutes = require('./routes/recycle.cjs')
const systemLogRoutes = require('./routes/system-log.cjs')
const sysConfigRoutes = require('./routes/sys-config.cjs')
const customTaskRoutes = require('./routes/custom-task.cjs')
const appFavoriteRoutes = require('./routes/app-favorite.cjs')
const postFavoriteRoutes = require('./routes/post-favorite.cjs')
const commissionRoutes = require('./routes/commission.cjs')
const transferRoutes = require('./routes/transfer.cjs')
const filePolicyRoutes = require('./routes/file-policy.cjs')
const checkinRoutes = require('./routes/checkin.cjs')
const checkinGroupRoutes = require('./routes/checkin-group.cjs')
const browseHistoryRoutes = require('./routes/browse-history.cjs')
const couponRoutes = require('./routes/coupon.cjs')
const { contentRoutes } = require('./routes/content.cjs')
const pluginsRoutes = require('./routes/plugins.cjs')
const settlementRoutes = require('./routes/settlement.cjs')
const layoutThemeRoutes = require('./routes/layout-themes.cjs')
const rankingRoutes = require('./routes/ranking.cjs')
const avatarFrameRoutes = require('./routes/avatar-frame.cjs')
const chatRoomRoutes = require('./routes/chat-room.cjs')
const chatRoomAdminRoutes = require('./routes/chat-room-admin.cjs')
const { rechargeRoutes } = require('./routes/recharge.cjs')
const { userBlockRoutes, getBlockedUserIds, getBlockerUserIds } = require('./routes/user-block.cjs')
const mallRoutes = require('./routes/mall.cjs')
const emailTemplatesRoutes = require('./routes/email-templates.cjs')
const emailPushRoutes = require('./routes/email-push.cjs')
const storageConfigRoutes = require('./routes/storage-config.cjs')
const gameRoutes = require('./routes/game.cjs')
const voteRoutes = require('./routes/vote.cjs')
const collectionRoutes = require('./routes/collection.cjs')
const appealsRoutes = require('./routes/appeals.cjs')
const smsConfigRoutes = require('./routes/sms-config.cjs')
const oauthRoutes = require('./routes/oauth.cjs')
const twoFactorRoutes = require('./routes/two-factor.cjs')
const logisticsConfigRoutes = require('./routes/logistics-config.cjs')
const userCodesRoutes = require('./routes/user-codes.cjs')
const searchRoutes = require('./routes/search.cjs')
const { eventBus } = require('./plugins/event-bus.cjs')
const { scheduler } = require('./plugins/scheduler.cjs')
const rateLimitMiddleware = require('./middleware/rate-limit.cjs')
const { systemLog, logFromReq, sanitizeBody } = require('./middleware/security.cjs')
const { errorHandler } = require('./middleware/error-handler.cjs')
const { startScheduledTasks, setTitleChecker } = require('./scheduler.cjs')
const { recommendRoutes } = require('./routes/recommend.cjs')
const pushNotificationRoutes = require('./routes/push-notification.cjs')
const abTestRoutes = require('./routes/ab-test.cjs')
const campaignRoutes = require('./routes/campaign.cjs')
const loginHistoryRoutes = require('./routes/login-history.cjs')
require('./seed.cjs')

const app = express()
app.set('trust proxy', 1)
const PORT = process.env.API_PORT || 3001

app.use(cors())
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ extended: true, limit: '50mb' }))
app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

// Rate limiting
const rateLimiters = rateLimitMiddleware()
app.use('/api/auth/login', rateLimiters.strict)
app.use('/api/auth/register', rateLimiters.strict)
app.use('/api/', rateLimiters.general)

app.use(sanitizeBody)

userRoutes(app)
operationRoutes(app)
searchRoutes(app)
systemRoutes(app, { query })
menuRoutes(app)
appStoreRoutes(app)
submissionRoutes(app)
officialTagRoutes(app)
uploadRoutes(app)
notificationsRoutes(app)
notificationRoutes(app)
communityRoutes(app)
communityTopicRoutes(app)
followRoutes(app)
titleRoutes(app)
setTitleChecker(require('./routes/title.cjs').checkAndGrantAutoTitles)
verificationRoutes(app)
  emailRoutes(app)
  emailTemplatesRoutes(app)
  emailPushRoutes(app)
  storageConfigRoutes(app)
  smsConfigRoutes(app)
  logisticsConfigRoutes(app)
  userCodesRoutes(app)
  inviteRoutes(app)
fileRepoRoutes(app)
recycleRoutes(app)
systemLogRoutes(app)
sysConfigRoutes(app)
customTaskRoutes(app)
appFavoriteRoutes(app)
postFavoriteRoutes(app)
commissionRoutes(app)
transferRoutes(app)
filePolicyRoutes(app)
checkinRoutes(app)
checkinGroupRoutes(app)
browseHistoryRoutes(app)
couponRoutes(app)
contentRoutes(app)
pluginsRoutes(app, app)  // 传入 app 实例用于插件注册路由
  settlementRoutes(app)
  layoutThemeRoutes(app)
  rankingRoutes(app)
  avatarFrameRoutes(app)
  chatRoomRoutes(app)
  chatRoomAdminRoutes(app)
  userBlockRoutes(app)
  mallRoutes(app)
  rechargeRoutes(app)
  gameRoutes(app)
  voteRoutes(app)
  collectionRoutes(app)
  appealsRoutes(app)

  // 新功能路由
  oauthRoutes(app)
  twoFactorRoutes(app)
  recommendRoutes(app)
  pushNotificationRoutes(app)
  abTestRoutes(app)
  campaignRoutes(app)
  loginHistoryRoutes(app)

  app.get('/api/ip-geo/test', systemRoutes.authRequired, async (req, res) => {
    try {
      const { queryFreeApi, queryTencentApi, queryAliyunApi } = require('./utils/ip-geo.cjs')
      const { provider, apiKey, apiSecret } = req.query
      let result = null
      if (provider === 'tencent' && apiKey && apiSecret) {
        result = await queryTencentApi('8.8.8.8', apiKey, apiSecret)
      } else if (provider === 'aliyun') {
        result = await queryAliyunApi('8.8.8.8')
      } else {
        result = await queryFreeApi('8.8.8.8')
      }
      if (result) {
        res.json({ code: 200, msg: '连接成功', data: { location: [result.country, result.province, result.city].filter(Boolean).join(' ') || '定位成功' } })
      } else {
        res.json({ code: 500, msg: '无法获取位置信息' })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 管理员中心统计
  app.get('/api/admin/stats', systemRoutes.authRequired, async (_req, res) => {
    try {
      const { query } = require('./database.cjs')
      const [posts, comments, products, users] = await Promise.all([
        query("SELECT COUNT(*) as cnt FROM community_posts WHERE status IN ('published','reviewed')"),
        query("SELECT COUNT(*) as cnt FROM community_comments"),
        query("SELECT COUNT(*) as cnt FROM app_store WHERE status='1'"),
        query("SELECT COUNT(*) as cnt FROM users WHERE status='1'")
      ])
      res.json({
        code: 200,
        data: {
          posts: posts[0]?.cnt || 0,
          comments: comments[0]?.cnt || 0,
          products: products[0]?.cnt || 0,
          users: users[0]?.cnt || 0
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 统一错误处理中间件（必须注册在路由之后）
  app.use(errorHandler)

app.listen(PORT, () => {
  console.log(`数据库后端服务已启动: http://localhost:${PORT}`)

  // 启动插件调度器
  scheduler.start()

  // 启动系统定时任务
  startScheduledTasks(app)

  // 发射系统启动事件
  eventBus.emit('system:boot', { port: PORT, startTime: new Date().toISOString() })
})

// 优雅关闭
process.on('SIGTERM', () => {
  eventBus.emit('system:beforeShutdown', { signal: 'SIGTERM' })
  scheduler.stop()
})
process.on('SIGINT', () => {
  eventBus.emit('system:beforeShutdown', { signal: 'SIGINT' })
  scheduler.stop()
})

// 导出 app 供插件使用
module.exports = { app }
