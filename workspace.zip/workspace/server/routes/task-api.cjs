'use strict'

/**
 * 宝塔定时任务 HTTP 接口
 *
 * 宝塔 Cron 通过以下方式触发：
 *   GET  /api/scheduler/tasks              — 列出所有任务
 *   POST /api/scheduler/run/:taskName       — 执行指定任务
 *   POST /api/scheduler/run-all             — 执行所有任务
 *
 * 鉴权方式：TASK_SECRET（优先） 或 管理员 token
 */

const { runTask, getAllTaskNames, TASK_REGISTRY } = require('../scheduler/index.cjs')
const { authRequired } = require('./system.cjs')

function checkTaskSecret(req) {
  const secret = process.env.TASK_SECRET
  if (!secret) return false
  const provided = req.headers['x-task-secret'] || req.query.secret || ''
  return provided === secret
}

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function taskAuthMiddleware(req, res, next) {
  if (checkTaskSecret(req)) return next()
  authRequired(req, res, () => {
    adminRequired(req, res, next)
  })
}

module.exports = function (app) {
  app.get('/api/scheduler/tasks', taskAuthMiddleware, (req, res) => {
    const tasks = getAllTaskNames().map(name => ({
      name,
      intervalMs: TASK_REGISTRY[name].intervalMs,
      interval: `${TASK_REGISTRY[name].intervalMs / 1000}s`,
      description: TASK_REGISTRY[name].description,
    }))
    res.json({ code: 200, data: { tasks } })
  })

  app.post('/api/scheduler/run/:taskName', taskAuthMiddleware, async (req, res) => {
    const { taskName } = req.params
    try {
      await runTask(taskName)
      res.json({ code: 200, msg: `任务 ${taskName} 执行完成` })
    } catch (e) {
      res.json({ code: 500, msg: `任务 ${taskName} 执行失败: ${e.message}` })
    }
  })

  app.post('/api/scheduler/run-all', taskAuthMiddleware, async (req, res) => {
    const results = []
    for (const name of getAllTaskNames()) {
      try {
        await runTask(name)
        results.push({ name, status: 'ok' })
      } catch (e) {
        results.push({ name, status: 'error', message: e.message })
      }
    }
    res.json({ code: 200, msg: '所有任务执行完成', data: { results } })
  })
}
