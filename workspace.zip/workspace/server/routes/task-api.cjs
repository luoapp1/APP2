'use strict'

/**
 * 宝塔定时任务 HTTP 接口
 *
 * 宝塔 Cron 通过以下方式触发：
 *   GET  /api/scheduler/tasks              — 列出所有任务
 *   POST /api/scheduler/run/:taskName       — 执行指定任务
 *   POST /api/scheduler/run-all             — 执行所有任务
 *
 * 鉴权方式：请求头 X-Task-Secret 或查询参数 secret 必须匹配 TASK_SECRET 环境变量
 */

const { runTask, getAllTaskNames, TASK_REGISTRY } = require('../scheduler/index.cjs')

function authTaskRequest(req, res) {
  const secret = process.env.TASK_SECRET
  if (!secret) {
    res.status(500).json({ code: 500, msg: 'TASK_SECRET 未配置' })
    return false
  }
  const provided = req.headers['x-task-secret'] || req.query.secret || ''
  if (provided !== secret) {
    res.status(403).json({ code: 403, msg: '鉴权失败' })
    return false
  }
  return true
}

module.exports = function (app) {
  // 列出所有任务
  app.get('/api/scheduler/tasks', (req, res) => {
    if (!authTaskRequest(req, res)) return

    const tasks = getAllTaskNames().map(name => ({
      name,
      intervalMs: TASK_REGISTRY[name].intervalMs,
      interval: `${TASK_REGISTRY[name].intervalMs / 1000}s`,
      description: TASK_REGISTRY[name].description,
    }))
    res.json({ code: 200, data: { tasks } })
  })

  // 执行单个任务
  app.post('/api/scheduler/run/:taskName', async (req, res) => {
    if (!authTaskRequest(req, res)) return

    const { taskName } = req.params
    try {
      await runTask(taskName)
      res.json({ code: 200, msg: `任务 ${taskName} 执行完成` })
    } catch (e) {
      res.json({ code: 500, msg: `任务 ${taskName} 执行失败: ${e.message}` })
    }
  })

  // 执行所有任务
  app.post('/api/scheduler/run-all', async (req, res) => {
    if (!authTaskRequest(req, res)) return

    const results = []
    for (const name of getAllTaskNames()) {
      try {
        await runTask(name)
        results.push({ name, status: 'ok' })
      } catch (e) {
        results.push({ name, status: 'error', message: e.message })
      }
    }
    res.json({ code: 200, msg: '所有任务执行完成', data: { results } })
  })
}
