const { query, getSystemOperator } = require('../database.cjs')
const { systemLog, logFromReq } = require('../middleware/security.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}
const nowExpr = 'NOW()'

function getUserFromReq(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token) return { userId: 0, userName: 'anonymous' }
  const { sessions } = require('./system.cjs')
  const session = sessions.get(token)
  if (session) return { userId: session.userId, userName: session.userName }
  return { userId: 0, userName: 'anonymous' }
}

function opLog(req, type, targetType, targetId, detail) {
  const { userId, userName } = getUserFromReq(req)
  systemLog(type, userId, userName, targetType, targetId, detail, req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '')
}

function operationRoutes(router) {
  // ==================== 卡密管理 ====================

  router.get('/api/operation/cardkey/list', authRequired, adminRequired, async (req, res) => {
    try {
      const { current = 1, size = 20, cardNo, type, status } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (cardNo) { where.push('card_no LIKE ?'); params.push(`%${cardNo}%`) }
      if (type) { where.push('type = ?'); params.push(type) }
      if (status) { where.push('status = ?'); params.push(status) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM card_keys WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id, card_no as cardNo, password, type, target_id as targetId, target_name as targetName,
                value, extra_points as extraPoints, extra_experience as extraExperience,
                duration, duration_unit as durationUnit, status, create_by as createBy,
                create_time as createTime, redeem_by as redeemBy, redeem_time as redeemTime
         FROM card_keys WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      // 脱敏密码
      const maskedRecords = records.map(r => ({
        ...r,
        password: r.password ? r.password.slice(0, 4) + '****' : ''
      }))

      res.json({ code: 200, msg: 'success', data: { records: maskedRecords, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('卡密列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  // 管理员查看完整密码
  router.get('/api/operation/cardkey/:id/password', authRequired, adminRequired, async (req, res) => {
    try {
      const { id } = req.params
      const rows = await query('SELECT password FROM card_keys WHERE id=?', [id])
      if (!rows.length) return res.json({ code: 404, msg: '卡密不存在' })
      res.json({ code: 200, data: { password: rows[0].password } })
    } catch (e) {
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/cardkey/create', async (req, res) => {
    try {
      const { type, targetId, value, count = 1, duration = 0, durationUnit = '', prefix = '', extraPoints = 0, extraExperience = 0 } = req.body
      const ids = []
      let targetName = ''

      if (type === 'membership' && targetId) {
        const lvs = await query('SELECT name FROM membership_levels WHERE id = ?', [Number(targetId)])
        targetName = lvs && lvs.length > 0 ? lvs[0].name : ''
      } else if (type === 'points') {
        targetName = `${value || 0}积分`
      } else if (type === 'experience') {
        targetName = `${value || 0}经验值`
      } else if (type === 'balance') {
        targetName = `${value || 0}元余额`
      }

      for (let i = 0; i < Number(count); i++) {
        const ts = Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
        const cardNo = prefix ? `${prefix}-${ts}` : `CDKEY-${ts}`
        const pwd = Math.random().toString(36).substring(2, 10).toUpperCase()
        const result = await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, duration, duration_unit)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [cardNo, pwd, type || 'membership', Number(targetId) || 0, targetName, Number(value) || 0, Number(extraPoints) || 0, Number(extraExperience) || 0, Number(duration) || 0, durationUnit || '']
        )
        ids.push(result.insertId)
      }

      opLog(req, 'create', 'cardkey', ids.join(','), `生成${count}张卡密(${targetName})`)
      res.json({ code: 200, msg: `成功生成 ${count} 张卡密`, data: { ids } })
    } catch (e) {
      console.error('生成卡密失败:', e.message)
      res.json({ code: 500, msg: '生成失败' })
    }
  })

  router.delete('/api/operation/cardkey/:id', async (req, res) => {
    try {
      const id = Number(req.params.id)
      const before = await query('SELECT card_no FROM card_keys WHERE id=?', [id])
      const cardNo = before[0]?.card_no || id
      await query('DELETE FROM card_keys WHERE id = ?', [id])
      opLog(req, 'delete', 'cardkey', id, `删除卡密 ${cardNo}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除卡密失败:', e.message)
      res.json({ code: 500, msg: '删除失败' })
    }
  })

  // 批量导入卡密
  router.post('/api/operation/cardkey/import', async (req, res) => {
    try {
      const { items } = req.body
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.json({ code: 400, msg: '请提供有效的卡密数据' })
      }
      const now = new Date().toISOString().replace('T', ' ').slice(0, 19)
      const createBy = req.body.createBy || '管理员'
      let count = 0
      const created = []
      for (const item of items) {
        if (!item.cardNo || !item.password) continue
        const existing = await query('SELECT id FROM card_keys WHERE card_no=?', [item.cardNo])
        if (existing && existing.length > 0) continue
        const result = await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, extra_balance, duration, duration_unit, create_by, create_time)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [item.cardNo, item.password, item.type || 'membership', item.targetId || 0, item.targetName || '',
           item.value || 0, item.extraPoints || 0, item.extraExperience || 0, item.extraBalance || 0,
           item.duration || 0, item.durationUnit || '', createBy, now]
        )
        created.push({ id: result.insertId, cardNo: item.cardNo })
        count++
      }
      opLog(req, 'create', 'cardkey', created.map(c => c.id).join(','), `批量导入${count}张卡密`)
      res.json({ code: 200, msg: `成功导入 ${count} 张卡密`, data: { count, created } })
    } catch (e) {
      console.error('导入卡密失败:', e.message)
      res.json({ code: 500, msg: '导入失败: ' })
    }
  })

  router.post('/api/cardkey/redeem', authRequired, async (req, res) => {
    try {
      const { cardNo, password } = req.body
      const userId = Number(req.user.userId) || 0
      const userName = req.user.userName || ''
      if (!cardNo || !password) return res.json({ code: 400, msg: '请输入卡号和密码' })

      const cards = await query(
        `SELECT id, card_no as cardNo, type, target_id as targetId, target_name as targetName,
                value, extra_points as extraPoints, extra_experience as extraExperience,
                duration, duration_unit as durationUnit, status
         FROM card_keys WHERE card_no=? AND password=?`,
        [cardNo, password]
      )
      if (!cards || cards.length === 0) return res.json({ code: 404, msg: '卡密不存在或密码错误' })

      const card = cards[0]
      if (card.status === '1') return res.json({ code: 400, msg: '该卡密已被使用' })

      const rewards = []
      if (card.type === 'membership' && card.targetId) {
        const lvs = await query('SELECT id, name, tier FROM membership_levels WHERE id=?', [card.targetId])
        if (lvs && lvs.length > 0) {
          const cardTier = lvs[0].tier || 1
          const expireTime = new Date()
          if (card.duration && card.durationUnit) {
            const unitMap = { day: 'd', week: 'w', month: 'M', year: 'y', 天: 'd', 周: 'w', 月: 'M', 年: 'y' }
            const u = unitMap[card.durationUnit] || 'M'
            if (u === 'd') expireTime.setDate(expireTime.getDate() + card.duration)
            else if (u === 'w') expireTime.setDate(expireTime.getDate() + card.duration * 7)
            else if (u === 'M') expireTime.setMonth(expireTime.getMonth() + card.duration)
            else if (u === 'y') expireTime.setFullYear(expireTime.getFullYear() + card.duration)
          }
          const expireTimeStr = expireTime.toISOString().slice(0, 19).replace('T', ' ')
          const existingUm = await query(
            'SELECT id, expire_time FROM user_memberships WHERE user_id=? AND level_id=? ORDER BY expire_time DESC LIMIT 1',
            [Number(userId), card.targetId]
          )
          if (existingUm.length && new Date(existingUm[0].expire_time) > new Date()) {
            const curExp = new Date(existingUm[0].expire_time)
            curExp.setMonth(curExp.getMonth() + (card.duration || 1))
            const extendedStr = curExp.toISOString().slice(0, 19).replace('T', ' ')
            await query('UPDATE user_memberships SET expire_time=? WHERE id=?', [extendedStr, existingUm[0].id])
          } else {
            await query(
              'INSERT INTO user_memberships (user_id, level_id, level_name, expire_time) VALUES (?,?,?,?)',
              [Number(userId), card.targetId, lvs[0].name, expireTimeStr]
            )
          }

          // 延期所有低于卡密等级的有效会员
          const lowerMemberships = await query(
            `SELECT um.id, um.level_id, um.level_name, um.expire_time, ml.tier
             FROM user_memberships um
             JOIN membership_levels ml ON um.level_id = ml.id
             WHERE um.user_id = ? AND um.expire_time > NOW() AND um.level_id != ? AND ml.tier < ?`,
            [Number(userId), card.targetId, cardTier]
          )
          for (const lm of lowerMemberships) {
            const curExp = new Date(lm.expire_time)
            if (card.duration && card.durationUnit) {
              const unitMap = { day: 'd', week: 'w', month: 'M', year: 'y', 天: 'd', 周: 'w', 月: 'M', 年: 'y' }
              const u = unitMap[card.durationUnit] || 'M'
              if (u === 'd') curExp.setDate(curExp.getDate() + card.duration)
              else if (u === 'w') curExp.setDate(curExp.getDate() + card.duration * 7)
              else if (u === 'M') curExp.setMonth(curExp.getMonth() + card.duration)
              else if (u === 'y') curExp.setFullYear(curExp.getFullYear() + card.duration)
            }
            const extendedStr = curExp.toISOString().slice(0, 19).replace('T', ' ')
            await query('UPDATE user_memberships SET expire_time=? WHERE id=?', [extendedStr, lm.id])
            rewards.push(`${lm.level_name}延期`)
          }

          const { recalcUserMembership } = require('./content.cjs')
          await recalcUserMembership(Number(userId))
          rewards.push(`会员等级升级为${lvs[0].name}`)
          await query(
            `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
             VALUES (?, ?, ?, 0, 'cardkey', 'cardkey', ?, ?)`,
            [Number(userId), card.targetId, lvs[0].name, card.duration || 30, expireTimeStr]
          )
        }
      } else if (card.type === 'points') {
        await query(`UPDATE users SET points = points + ?, update_time=${nowExpr} WHERE id=?`, [card.value || 0, Number(userId)])
        const updated = await query('SELECT points FROM users WHERE id=?', [Number(userId)])
        const newPoints = updated[0]?.points || 0
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
           VALUES (?, ?, 'earn', ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.value || 0, newPoints, `使用卡密 ${cardNo} 获得${card.value}积分`]
        )
        rewards.push(`${card.value}积分`)
      } else if (card.type === 'experience') {
        const currentExp = await query('SELECT experience FROM users WHERE id=?', [Number(userId)])
        const newExp = (currentExp[0]?.experience || 0) + (card.value || 0)
        await query(`UPDATE users SET experience=?, update_time=${nowExpr} WHERE id=?`, [newExp, Number(userId)])
        await query(
          `INSERT INTO experience_records (user_id, user_name, amount, source, description)
           VALUES (?, ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.value || 0, `使用卡密 ${cardNo} 获得${card.value}经验值`]
        )
        rewards.push(`${card.value}经验值`)
      } else if (card.type === 'balance') {
        await query(`UPDATE users SET balance = balance + ?, update_time=${nowExpr} WHERE id=?`, [card.value || 0, Number(userId)])
        const updated = await query('SELECT balance FROM users WHERE id=?', [Number(userId)])
        const newBal = Number(updated[0]?.balance || 0)
        await query(
          `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description)
           VALUES (?, ?, 'earn', ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.value || 0, newBal, `使用卡密 ${cardNo} 获得${card.value}元余额`]
        )
        rewards.push(`${card.value}元余额`)
      }

      if (card.extraPoints) {
        const p = await query('SELECT points FROM users WHERE id=?', [Number(userId)])
        const np = (p[0]?.points || 0) + card.extraPoints
        await query(`UPDATE users SET points=?, update_time=${nowExpr} WHERE id=?`, [np, Number(userId)])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
           VALUES (?, ?, 'earn', ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.extraPoints, np, `使用卡密 ${cardNo} 额外获得${card.extraPoints}积分`]
        )
        rewards.push(`额外${card.extraPoints}积分`)
      }
      if (card.extraExperience) {
        const e = await query('SELECT experience FROM users WHERE id=?', [Number(userId)])
        const ne = (e[0]?.experience || 0) + card.extraExperience
        await query(`UPDATE users SET experience=?, update_time=${nowExpr} WHERE id=?`, [ne, Number(userId)])
        await query(
          `INSERT INTO experience_records (user_id, user_name, amount, source, description)
           VALUES (?, ?, ?, '卡密兑换', ?)`,
          [Number(userId), userName || '', card.extraExperience, `使用卡密 ${cardNo} 额外获得${card.extraExperience}经验值`]
        )
        rewards.push(`额外${card.extraExperience}经验值`)
      }

      await query(
        `UPDATE card_keys SET status='1', redeem_by=?, redeem_time=${nowExpr} WHERE id=?`,
        [userName || '', card.id]
      )

      if (userId && rewards.length > 0) {
        const sysOpName = (await getSystemOperator())?.username || '管理员'
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
           VALUES (?, ?, 'system', ?, 0, ?, '')`,
          ['卡密兑换成功', `您使用卡密 ${cardNo} 兑换成功，获得：${rewards.join('、')}`, Number(userId), sysOpName]
        )
      }

      systemLog('redeem', Number(userId) || 0, userName || 'anonymous', 'cardkey', card.id, `兑换卡密 ${cardNo}: ${rewards.join('、')}`)
      res.json({ code: 200, msg: '兑换成功', data: { rewards, cardNo } })
    } catch (e) {
      console.error('兑换卡密失败:', e.message)
      res.json({ code: 500, msg: '兑换失败: ' })
    }
  })

  // ==================== 会员等级管理 ====================

  // ==================== 会员等级管理 ====================

  // 公开接口：启用的会员等级列表（用于注册配置等公开场景）
  router.get('/api/membership/levels', async (req, res) => {
    try {
      const rows = await query("SELECT id, name, level, tier, discount_rate, points_multiplier FROM membership_levels WHERE status='1' ORDER BY tier ASC")
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 返佣规则列表（供管理后台选择）
  router.get('/api/operation/commission-rules/list', async (req, res) => {
    try {
      const rows = await query("SELECT id, name, rate, points_rate, user_level_id, level, status FROM commission_rules ORDER BY id ASC")
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  router.get('/api/operation/membership-level/list', async (req, res) => {
    try {
      const records = await query(
         `SELECT l.id, l.name, l.level, l.tier, l.parent_level_id as parentLevelId, l.price, l.discount_rate as discountRate,
                 l.points_multiplier as pointsMultiplier, l.points_discount_rate as pointsDiscountRate,
                 l.text_color as textColor, l.bg_color as bgColor,
                 l.benefits, l.icon, l.icon_color as iconColor,
                 l.data_limit_mb as dataLimitMb, l.file_limit_mb as fileLimitMb, l.file_policy_ids as filePolicyIds,
                 l.recycle_retention_days as recycleRetentionDays,
                 l.gift_points as giftPoints, l.gift_balance as giftBalance, l.gift_experience as giftExperience,
                 l.gift_coupon_ids as giftCouponIds, l.gift_makeup_count as giftMakeupCount, l.perks,
                 l.title_id as titleId, l.frame_id as frameId,
                 l.daily_gift_enabled as dailyGiftEnabled, l.daily_gift_interval_days as dailyGiftIntervalDays,
                 l.daily_gift_points as dailyGiftPoints, l.daily_gift_balance as dailyGiftBalance,
                 l.daily_gift_experience as dailyGiftExperience, l.daily_gift_coupon_ids as dailyGiftCouponIds,
                 l.daily_gift_makeup_count as dailyGiftMakeupCount,
                 l.birthday_gift_points as birthdayGiftPoints, l.birthday_gift_balance as birthdayGiftBalance,
                 l.birthday_gift_experience as birthdayGiftExperience, l.birthday_gift_coupon_ids as birthdayGiftCouponIds,
                 l.birthday_gift_makeup_count as birthdayGiftMakeupCount,
                 l.commission_rule_id as commissionRuleId,
                 l.status, l.create_time as createTime,
                 t.name as titleName, af.name as frameName,
                 cr.name as commissionRuleName, cr.rate as commissionRate, cr.points_rate as commissionPointsRate
          FROM membership_levels l
          LEFT JOIN custom_titles t ON l.title_id=t.id
          LEFT JOIN avatar_frames af ON l.frame_id=af.id
          LEFT JOIN commission_rules cr ON l.commission_rule_id=cr.id
          ORDER BY l.level ASC`
      )

      // Attach pricing plans for each level
      for (const rec of records) {
        const products = await query(
          `SELECT id, name, price, original_price as originalPrice, points_price as pointsPrice,
                  points_original_price as pointsOriginalPrice, duration_days as durationDays, is_promo as isPromo,
                  gift_points as giftPoints, gift_balance as giftBalance, gift_experience as giftExperience,
                  gift_coupon_ids as giftCouponIds, gift_data_limit_mb as giftDataLimitMb,
                  gift_file_limit_mb as giftFileLimitMb, purchase_limit as purchaseLimit
           FROM membership_products WHERE level_id=? AND status='1' ORDER BY duration_days ASC`,
          [rec.id]
        )
        rec.pricingPlans = products
      }

      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('会员等级查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/membership-level/save', async (req, res) => {
    try {
      const { id, name, level, tier, parentLevelId, price, pointsRequired, discountRate, pointsMultiplier, pointsDiscountRate, textColor, bgColor, benefits, icon, iconColor, dataLimitMb, fileLimitMb, filePolicyIds, recycleRetentionDays, giftPoints, giftBalance, giftExperience, giftCouponIds, giftMakeupCount, perks, titleId, frameId, dailyGiftEnabled, dailyGiftIntervalDays, dailyGiftPoints, dailyGiftBalance, dailyGiftExperience, dailyGiftCouponIds, dailyGiftMakeupCount, birthdayGiftPoints, birthdayGiftBalance, birthdayGiftExperience, birthdayGiftCouponIds, birthdayGiftMakeupCount, commissionRuleId, status, pricingPlans } = req.body

      let levelId

      if (id) {
        await query(
          `UPDATE membership_levels SET name=?, level=?, tier=?, parent_level_id=?, price=?, points_required=?, discount_rate=?, points_multiplier=?, points_discount_rate=?, text_color=?, bg_color=?, benefits=?, icon=?, icon_color=?, data_limit_mb=?, file_limit_mb=?, file_policy_ids=?, recycle_retention_days=?, gift_points=?, gift_balance=?, gift_experience=?, gift_coupon_ids=?, gift_makeup_count=?, perks=?, title_id=?, frame_id=?, daily_gift_enabled=?, daily_gift_interval_days=?, daily_gift_points=?, daily_gift_balance=?, daily_gift_experience=?, daily_gift_coupon_ids=?, daily_gift_makeup_count=?, birthday_gift_points=?, birthday_gift_balance=?, birthday_gift_experience=?, birthday_gift_coupon_ids=?, birthday_gift_makeup_count=?, commission_rule_id=?, status=? WHERE id=?`,
          [name, Number(level) || 0, Number(tier) || 1, Number(parentLevelId) || 0, Number(price) || 0, Number(pointsRequired) || 0, Number(discountRate) || 1, Number(pointsMultiplier) || 1, Number(pointsDiscountRate) || 1, textColor || '#FFFFFF', bgColor || '#508DFF', benefits || '', icon || '', iconColor || '', Number(dataLimitMb) || 0, Number(fileLimitMb) || 0, filePolicyIds || '', Number(recycleRetentionDays) || 0, Number(giftPoints) || 0, Number(giftBalance) || 0, Number(giftExperience) || 0, giftCouponIds || '', Number(giftMakeupCount) || 0, perks || '', Number(titleId) || 0, Number(frameId) || 0, dailyGiftEnabled ? 1 : 0, Number(dailyGiftIntervalDays) || 1, Number(dailyGiftPoints) || 0, Number(dailyGiftBalance) || 0, Number(dailyGiftExperience) || 0, dailyGiftCouponIds || '', Number(dailyGiftMakeupCount) || 0, Number(birthdayGiftPoints) || 0, Number(birthdayGiftBalance) || 0, Number(birthdayGiftExperience) || 0, birthdayGiftCouponIds || '', Number(birthdayGiftMakeupCount) || 0, Number(commissionRuleId) || 0, status || '1', Number(id)]
        )
        levelId = Number(id)
        opLog(req, 'update', 'membership', id, `更新会员等级"${name}"`)
      } else {
        const result = await query(
          `INSERT INTO membership_levels (name, level, tier, parent_level_id, price, points_required, discount_rate, points_multiplier, points_discount_rate, text_color, bg_color, benefits, icon, icon_color, data_limit_mb, file_limit_mb, file_policy_ids, recycle_retention_days, gift_points, gift_balance, gift_experience, gift_coupon_ids, gift_makeup_count, perks, title_id, frame_id, daily_gift_enabled, daily_gift_interval_days, daily_gift_points, daily_gift_balance, daily_gift_experience, daily_gift_coupon_ids, daily_gift_makeup_count, birthday_gift_points, birthday_gift_balance, birthday_gift_experience, birthday_gift_coupon_ids, birthday_gift_makeup_count, commission_rule_id, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, Number(level) || 0, Number(tier) || 1, Number(parentLevelId) || 0, Number(price) || 0, Number(pointsRequired) || 0, Number(discountRate) || 1, Number(pointsMultiplier) || 1, Number(pointsDiscountRate) || 1, textColor || '#FFFFFF', bgColor || '#508DFF', benefits || '', icon || '', iconColor || '', Number(dataLimitMb) || 0, Number(fileLimitMb) || 0, filePolicyIds || '', Number(recycleRetentionDays) || 0, Number(giftPoints) || 0, Number(giftBalance) || 0, Number(giftExperience) || 0, giftCouponIds || '', Number(giftMakeupCount) || 0, perks || '', Number(titleId) || 0, Number(frameId) || 0, dailyGiftEnabled ? 1 : 0, Number(dailyGiftIntervalDays) || 1, Number(dailyGiftPoints) || 0, Number(dailyGiftBalance) || 0, Number(dailyGiftExperience) || 0, dailyGiftCouponIds || '', Number(dailyGiftMakeupCount) || 0, Number(birthdayGiftPoints) || 0, Number(birthdayGiftBalance) || 0, Number(birthdayGiftExperience) || 0, birthdayGiftCouponIds || '', Number(birthdayGiftMakeupCount) || 0, Number(commissionRuleId) || 0, status || '1']
        )
        levelId = result.insertId
        opLog(req, 'create', 'membership', levelId, `新增会员等级"${name}"`)
      }

      // Sync membership products from pricing plans
      if (pricingPlans && Array.isArray(pricingPlans) && pricingPlans.length > 0) {
        // Delete existing products for this level
        await query('DELETE FROM membership_products WHERE level_id=?', [levelId])
        // Insert new products
        for (const plan of pricingPlans) {
          if ((plan.durationDays || plan.durationDays === 0) && (Number(plan.price) > 0 || Number(plan.pointsPrice) > 0)) {
            await query(
              `INSERT INTO membership_products (level_id, name, price, original_price, points_price, points_original_price, duration_days, is_promo, gift_points, gift_balance, gift_experience, gift_coupon_ids, gift_data_limit_mb, gift_file_limit_mb, purchase_limit, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '1')`,
              [levelId, plan.name || name, Number(plan.price) || 0, Number(plan.originalPrice) || 0, Number(plan.pointsPrice) || 0, Number(plan.pointsOriginalPrice) || 0, plan.durationDays != null ? Number(plan.durationDays) : 30, (Number(plan.originalPrice) > 0 || Number(plan.pointsOriginalPrice) > 0) ? 1 : 0, Number(plan.giftPoints) || 0, Number(plan.giftBalance) || 0, Number(plan.giftExperience) || 0, plan.giftCouponIds || '', Number(plan.giftDataLimitMb) || 0, Number(plan.giftFileLimitMb) || 0, Number(plan.purchaseLimit) || 0]
            )
          }
        }
      }

      const msg = id ? '更新成功' : '添加成功'
      res.json({ code: 200, msg, data: { id: levelId } })
    } catch (e) {
      console.error('保存会员等级失败:', e.message)
      res.json({ code: 500, msg: '保存失败' })
    }
  })

  router.delete('/api/operation/membership-level/:id', async (req, res) => {
    try {
      const id = Number(req.params.id)
      const before = await query('SELECT name FROM membership_levels WHERE id=?', [id])
      const lvName = before[0]?.name || id
      await query('DELETE FROM membership_levels WHERE id = ?', [id])
      opLog(req, 'delete', 'membership', id, `删除会员等级"${lvName}"`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除会员等级失败:', e.message)
      res.json({ code: 500, msg: '删除失败' })
    }
  })

  // ==================== 会员列表 ====================

  router.get('/api/operation/member/list', async (req, res) => {
    try {
      const { current = 1, size = 20, userName, level } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('username LIKE ?'); params.push(`%${userName}%`) }
      if (level !== undefined && level !== '') { where.push('level_id = ?'); params.push(Number(level)) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM users WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id as userId, username as userName, level_id as level, level_name as levelName,
                points, points as totalPoints, expire_time as expireTime,
                create_time as createTime, update_time as updateTime
         FROM users WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      res.json({ code: 200, msg: 'success', data: { records, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('会员列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/member/update-level', async (req, res) => {
    try {
      const { userId, level } = req.body
      const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level)])
      const lv = lvs && lvs.length > 0 ? lvs[0] : null
      await query(`UPDATE users SET level_id = ?, level_name = ?, update_time = ${nowExpr} WHERE id = ?`, [
        Number(level), lv ? lv.name : '普通会员', Number(userId)
      ])
      opLog(req, 'update', 'member', userId, `更新会员等级为"${lv ? lv.name : '普通会员'}"`)
      res.json({ code: 200, msg: '更新成功', data: { success: true } })
    } catch (e) {
      console.error('更新会员等级失败:', e.message)
      res.json({ code: 500, msg: '更新失败' })
    }
  })

  // ==================== 积分记录 ====================

  router.get('/api/operation/points-record/list', async (req, res) => {
    try {
      const { current = 1, size = 20, userName, type } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('user_name LIKE ?'); params.push(`%${userName}%`) }
      if (type) { where.push('type = ?'); params.push(type) }

      const whereClause = where.join(' AND ')
      const totalRow = await query(`SELECT COUNT(*) as cnt FROM points_records WHERE ${whereClause}`, params)
      const total = totalRow[0].cnt

      const records = await query(
        `SELECT id, user_id as userId, user_name as userName, type, points, balance,
                source, description, create_time as createTime
         FROM points_records WHERE ${whereClause} ORDER BY id DESC LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      res.json({ code: 200, msg: 'success', data: { records, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('积分记录查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/points-record/adjust', async (req, res) => {
    try {
      const { userId, points, description } = req.body
      const users = await query('SELECT id, username, points FROM users WHERE id = ?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      const user = users[0]
      const newBalance = user.points + Number(points)

      await query(`UPDATE users SET points = ?, update_time = ${nowExpr} WHERE id = ?`, [newBalance, Number(userId)])
      await query(
        `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
         VALUES (?, ?, 'adjust', ?, ?, '管理员调整', ?)`,
        [Number(userId), user.username, Number(points), newBalance, description || '']
      )

      opLog(req, 'update', 'points', userId, `调整用户"${user.username}"积分 ${points > 0 ? '+' : ''}${points}(${description || ''})`)
      res.json({ code: 200, msg: '调整成功', data: { success: true } })
    } catch (e) {
      console.error('调整积分失败:', e.message)
      res.json({ code: 500, msg: '调整失败: ' })
    }
  })

  // ==================== 经验等级管理 ====================

  router.get('/api/operation/experience-level/list', async (req, res) => {
    try {
      const records = await query(
        `SELECT id, name, level, exp_required as expRequired, icon, icon_color as iconColor,
                text_color as textColor, bg_color as bgColor,
                benefits, status, create_time as createTime,
                daily_gift_enabled as dailyGiftEnabled, daily_gift_interval_days as dailyGiftIntervalDays,
                daily_gift_points as dailyGiftPoints, daily_gift_balance as dailyGiftBalance,
                daily_gift_experience as dailyGiftExperience, daily_gift_coupon_ids as dailyGiftCouponIds,
                daily_gift_makeup_count as dailyGiftMakeupCount,
                first_gift_points as firstGiftPoints, first_gift_balance as firstGiftBalance,
                first_gift_experience as firstGiftExperience, first_gift_coupon_ids as firstGiftCouponIds,
                first_gift_makeup_count as firstGiftMakeupCount
         FROM experience_levels ORDER BY level ASC`
      )
      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('经验等级查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/experience-level/save', async (req, res) => {
    try {
      const { id, name, level, expRequired, icon, iconColor, textColor, bgColor, benefits, status,
              dailyGiftEnabled, dailyGiftIntervalDays, dailyGiftPoints, dailyGiftBalance, dailyGiftExperience, dailyGiftCouponIds, dailyGiftMakeupCount,
              firstGiftPoints, firstGiftBalance, firstGiftExperience, firstGiftCouponIds, firstGiftMakeupCount } = req.body

      if (id) {
        await query(
          `UPDATE experience_levels SET name=?, level=?, exp_required=?, icon=?, icon_color=?, text_color=?, bg_color=?, benefits=?, status=?,
           daily_gift_enabled=?, daily_gift_interval_days=?, daily_gift_points=?, daily_gift_balance=?, daily_gift_experience=?, daily_gift_coupon_ids=?, daily_gift_makeup_count=?,
           first_gift_points=?, first_gift_balance=?, first_gift_experience=?, first_gift_coupon_ids=?, first_gift_makeup_count=?
           WHERE id=?`,
          [name, Number(level) || 0, Number(expRequired) || 0, icon || '', iconColor || '', textColor || '#FFFFFF', bgColor || '#508DFF', benefits || '', status || '1',
           dailyGiftEnabled ? 1 : 0, Number(dailyGiftIntervalDays) || 1, Number(dailyGiftPoints) || 0, Number(dailyGiftBalance) || 0, Number(dailyGiftExperience) || 0, dailyGiftCouponIds || '', Number(dailyGiftMakeupCount) || 0,
           Number(firstGiftPoints) || 0, Number(firstGiftBalance) || 0, Number(firstGiftExperience) || 0, firstGiftCouponIds || '', Number(firstGiftMakeupCount) || 0,
           Number(id)]
        )
        opLog(req, 'update', 'experience', id, `更新经验等级"${name}"`)
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO experience_levels (name, level, exp_required, icon, icon_color, text_color, bg_color, benefits, status,
           daily_gift_enabled, daily_gift_interval_days, daily_gift_points, daily_gift_balance, daily_gift_experience, daily_gift_coupon_ids, daily_gift_makeup_count,
           first_gift_points, first_gift_balance, first_gift_experience, first_gift_coupon_ids, first_gift_makeup_count)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, Number(level) || 0, Number(expRequired) || 0, icon || '', iconColor || '', textColor || '#FFFFFF', bgColor || '#508DFF', benefits || '', status || '1',
           dailyGiftEnabled ? 1 : 0, Number(dailyGiftIntervalDays) || 1, Number(dailyGiftPoints) || 0, Number(dailyGiftBalance) || 0, Number(dailyGiftExperience) || 0, dailyGiftCouponIds || '', Number(dailyGiftMakeupCount) || 0,
           Number(firstGiftPoints) || 0, Number(firstGiftBalance) || 0, Number(firstGiftExperience) || 0, firstGiftCouponIds || '', Number(firstGiftMakeupCount) || 0]
        )
        const newId = result.insertId
        opLog(req, 'create', 'experience', newId, `新增经验等级"${name}"`)
        res.json({ code: 200, msg: '添加成功', data: { id: newId } })
      }
    } catch (e) {
      console.error('保存经验等级失败:', e.message)
      res.json({ code: 500, msg: '保存失败' })
    }
  })

  router.delete('/api/operation/experience-level/:id', async (req, res) => {
    try {
      const id = Number(req.params.id)
      const before = await query('SELECT name FROM experience_levels WHERE id=?', [id])
      const lvName = before[0]?.name || id
      await query('DELETE FROM experience_levels WHERE id = ?', [id])
      opLog(req, 'delete', 'experience', id, `删除经验等级"${lvName}"`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除经验等级失败:', e.message)
      res.json({ code: 500, msg: '删除失败' })
    }
  })

  router.get('/api/operation/experience-level/permission-templates', async (req, res) => {
    try {
      const keys = await query(
        `SELECT module, permission_key as permissionKey, permission_name as permissionName
         FROM experience_permission_config
         ORDER BY module, permission_key`
      )
      res.json({ code: 200, msg: 'success', data: keys })
    } catch (e) {
      console.error('查询权限模板失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  // 权益对比：返回所有权限配置 + 所有等级信息 + 当前用户等级
  router.get('/api/operation/experience-level/permissions-compare', async (req, res) => {
    try {
      let userLevel = 0
      const token = (req.headers.authorization || req.headers.token || '').replace(/^Bearer\s+/i, '').trim()
      if (token) {
        const { sessions } = require('./system.cjs')
        const session = sessions?.get(token)
        if (session) {
          const { getUserLevel } = require('../middleware/level-permissions.cjs')
          userLevel = await getUserLevel(session.userId)
        }
      }
      const [levels, perms] = await Promise.all([
        query(`SELECT id, name, level, exp_required as expRequired, icon, icon_color as iconColor,
                text_color as textColor, bg_color as bgColor, benefits, status,
                first_gift_points as firstGiftPoints, first_gift_balance as firstGiftBalance,
                first_gift_experience as firstGiftExperience, first_gift_makeup_count as firstGiftMakeupCount,
                daily_gift_enabled as dailyGiftEnabled, daily_gift_interval_days as dailyGiftIntervalDays,
                daily_gift_points as dailyGiftPoints, daily_gift_balance as dailyGiftBalance,
                daily_gift_experience as dailyGiftExperience, daily_gift_makeup_count as dailyGiftMakeupCount
               FROM experience_levels WHERE status='1' ORDER BY level ASC`),
        query(`SELECT module, permission_key as permissionKey, permission_name as permissionName,
                level_values as levelValues
               FROM experience_permission_config ORDER BY module, permission_key`)
      ])
      const permissions = perms.map(p => {
        const vals = typeof p.levelValues === 'string' ? JSON.parse(p.levelValues) : (p.levelValues || {})
        return { module: p.module, permissionKey: p.permissionKey, permissionName: p.permissionName, levelValues: vals }
      })
      res.json({ code: 200, msg: 'success', data: { levels, permissions, userLevel } })
    } catch (e) {
      console.error('查询权限对比失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.get('/api/operation/experience-level/permissions/:level', async (req, res) => {
    try {
      const level = Number(req.params.level)
      const rows = await query(
        `SELECT id, module, permission_key as permissionKey, permission_name as permissionName,
                level_values as levelValues
         FROM experience_permission_config
         ORDER BY module, permission_key`
      )
      const perms = rows.map(r => {
        const vals = typeof r.levelValues === 'string' ? JSON.parse(r.levelValues) : r.levelValues || {}
        return {
          id: r.id,
          module: r.module,
          permissionKey: r.permissionKey,
          permissionName: r.permissionName,
          value: vals[level] !== undefined ? String(vals[level]) : '',
        }
      })
      res.json({ code: 200, msg: 'success', data: perms })
    } catch (e) {
      console.error('查询权限失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.put('/api/operation/experience-level/permissions/:level', async (req, res) => {
    try {
      const level = Number(req.params.level)
      const { permissions } = req.body
      if (!Array.isArray(permissions) || permissions.length === 0) {
        return res.json({ code: 400, msg: '权限数据不能为空' })
      }
      for (const p of permissions) {
        if (!p.permissionKey) continue
        const jsonPath = `$."${level}"`
        await query(
          `UPDATE experience_permission_config SET level_values = JSON_SET(COALESCE(level_values,'{}'), ?, ?) WHERE module=? AND permission_key=?`,
          [jsonPath, String(p.value ?? ''), p.module || '', p.permissionKey]
        )
      }
      opLog(req, 'update', 'permissions', level, `更新等级${level}的${permissions.length}条权限`)
      res.json({ code: 200, msg: '更新成功', data: { level, count: permissions.length } })
    } catch (e) {
      console.error('保存权限失败:', e.message)
      res.json({ code: 500, msg: '保存失败' })
    }
  })

}

module.exports = operationRoutes
