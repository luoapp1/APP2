const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { encrypt, decrypt, maskKey } = require('../utils/crypto.cjs')
const kdniao = require('../utils/kdniao.cjs')

function loadConfig() {
  return query('SELECT * FROM logistics_config WHERE enabled=1 ORDER BY id DESC LIMIT 1')
}

function sanitizeConfig(cfg) {
  if (!cfg) return cfg
  const cp = { ...cfg }
  if (cp.api_key_encrypted) {
    try {
      const dec = decrypt(cp.api_key_encrypted)
      cp.api_key_encrypted = maskKey(dec)
    } catch { cp.api_key_encrypted = '***' }
  }
  return cp
}

function isMasked(val) {
  return !val || /^\*{2,}$/.test(val)
}

module.exports = function logisticsConfigRoutes(app) {
  app.get('/api/admin/logistics-config', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const rows = await query('SELECT * FROM logistics_config ORDER BY id DESC LIMIT 1')
      if (rows.length === 0) {
        return res.json({ code: 200, data: { provider: 'kdniao', e_business_id: '', api_key_encrypted: '', enabled: 1 } })
      }
      res.json({ code: 200, data: sanitizeConfig(rows[0]) })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.put('/api/admin/logistics-config', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const { provider, e_business_id, api_key_encrypted, enabled } = req.body

      const existing = await query('SELECT id, api_key_encrypted FROM logistics_config ORDER BY id DESC LIMIT 1')

      let finalKey
      if (api_key_encrypted && !isMasked(api_key_encrypted)) {
        finalKey = encrypt(api_key_encrypted)
      } else if (existing.length > 0) {
        finalKey = existing[0].api_key_encrypted
      } else {
        finalKey = ''
      }

      if (existing.length > 0) {
        await query(
          'UPDATE logistics_config SET provider=?, e_business_id=?, api_key_encrypted=?, enabled=?, update_time=NOW() WHERE id=?',
          [provider || 'kdniao', e_business_id || '', finalKey, enabled !== false ? 1 : 0, existing[0].id]
        )
        logFromReq(req, 'edit', 'logistics_config', existing[0].id, '更新物流配置')
      } else {
        const result = await query(
          'INSERT INTO logistics_config (provider, e_business_id, api_key_encrypted, enabled) VALUES (?,?,?,?)',
          [provider || 'kdniao', e_business_id || '', finalKey, enabled !== false ? 1 : 0]
        )
        logFromReq(req, 'add', 'logistics_config', result.insertId, '添加物流配置')
      }

      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/admin/logistics-config', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      await query('DELETE FROM logistics_config')
      logFromReq(req, 'delete', 'logistics_config', 0, '删除物流配置')
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/webhook/logistics/track', async (req, res) => {
    try {
      const body = req.body
      const logisticCode = body.LogisticCode || body.logisticCode || ''
      const shipperCode = body.ShipperCode || body.shipperCode || ''
      const state = body.State || body.state || ''
      const traces = body.Traces || body.traces || []

      if (!logisticCode) return res.json({ code: 400, msg: '缺少快递单号' })

      const orders = await query(
        'SELECT id FROM mall_orders WHERE logistics_no=?',
        [logisticCode]
      )

      if (orders.length === 0) {
        return res.json({ code: 200, msg: '无匹配订单', EBusinessID: body.EBusinessID, UpdateTime: '', Success: true, EstimatedDeliveryTime: '' })
      }

      const statusMap = { '0': 'pending', '1': 'picked_up', '2': 'in_transit', '3': 'delivered', '4': 'failed', '5': 'returned' }
      const mappedStatus = statusMap[state] || 'in_transit'

      for (const order of orders) {
        const existingRecords = await query(
          'SELECT id FROM mall_order_logistics WHERE order_id=? AND tracking_no=?',
          [order.id, logisticCode]
        )
        if (existingRecords.length > 0) {
          await query(
            'UPDATE mall_order_logistics SET status=?, details=?, update_time=NOW() WHERE order_id=? AND tracking_no=?',
            [mappedStatus, JSON.stringify(traces), order.id, logisticCode]
          )
        } else {
          await query(
            'INSERT INTO mall_order_logistics (order_id, company, tracking_no, status, details) VALUES (?,?,?,?,?)',
            [order.id, kdniao.shipperName(shipperCode) || '', logisticCode, mappedStatus, JSON.stringify(traces)]
          )
        }

        if (mappedStatus === 'delivered') {
          await query(`UPDATE mall_orders SET status='completed', update_time=NOW() WHERE id=?`, [order.id])
        }
      }

      res.json({ EBusinessID: body.EBusinessID || '', UpdateTime: new Date().toISOString(), Success: true, EstimatedDeliveryTime: '' })
    } catch (e) {
      console.error('物流回调处理失败:', e)
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports.loadConfig = loadConfig
