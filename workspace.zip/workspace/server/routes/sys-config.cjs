const { query } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { getSysConfig, getSysConfigRows, invalidateSysConfig } = require('../utils/sys-config-cache.cjs')

function sysConfigRoutes(router) {
  router.get('/api/sys-config/list', async (req, res) => {
    try {
      const list = await getSysConfigRows()
      res.json({ code: 200, data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/sys-config/:key', async (req, res) => {
    try {
      const val = await getSysConfig(req.params.key)
      res.json({ code: 200, data: val })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/sys-config/save', async (req, res) => {
    try {
      const { configs } = req.body
      if (!Array.isArray(configs) || !configs.length) {
        return res.json({ code: 400, msg: '缺少配置数据' })
      }
      for (const cfg of configs) {
        const existing = await query('SELECT id FROM sys_config WHERE config_key=?', [cfg.config_key])
        if (existing && existing.length > 0) {
          await query('UPDATE sys_config SET config_value=?, update_time=NOW() WHERE config_key=?',
            [cfg.config_value, cfg.config_key])
        } else {
          await query('INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?)',
            [cfg.config_key, cfg.config_value, cfg.description || ''])
        }
      }
      invalidateSysConfig()
      logFromReq(req, 'config', 'sys_config', 0, `更新系统配置: ${configs.map(c => c.config_key).join(', ')}`)
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/sys-config/public/:key', async (req, res) => {
    try {
      const val = await getSysConfig(req.params.key)
      res.json({ code: 200, data: val || '' })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = sysConfigRoutes
