const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function deliveryLogRoutes(router) {
  const prefix = '/api/admin/delivery-logs'

  router.get(prefix, authRequired, adminRequired, async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1
      const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100)
      const offset = (page - 1) * pageSize
      const userId = req.query.userId ? parseInt(req.query.userId) : 0
      const productId = req.query.productId ? parseInt(req.query.productId) : 0
      const orderId = req.query.orderId ? parseInt(req.query.orderId) : 0
      const cardType = req.query.cardType || ''
      const keyword = req.query.keyword || ''

      let where = 'WHERE 1=1'
      const params = []
      if (userId) { where += ' AND user_id = ?'; params.push(userId) }
      if (productId) { where += ' AND product_id = ?'; params.push(productId) }
      if (orderId) { where += ' AND order_id = ?'; params.push(orderId) }
      if (cardType) { where += ' AND card_type = ?'; params.push(cardType) }
      if (keyword) { where += ' AND (delivery_info LIKE ? OR card_number LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }

      const countResult = await query(`SELECT COUNT(*) as total FROM delivery_logs ${where}`, params)
      const total = (countResult && countResult[0]) ? countResult[0].total : 0

      const rows = await query(
        `SELECT * FROM delivery_logs ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, pageSize, offset]
      )

      res.json({ code: 200, data: { list: rows || [], total, page, pageSize } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  router.get(`${prefix}/stats`, authRequired, adminRequired, async (req, res) => {
    try {
      const rows = await query(
        `SELECT card_type, COUNT(*) as cnt FROM delivery_logs WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY card_type`
      )
      res.json({ code: 200, data: rows || [] })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  router.get(`${prefix}/expiring`, authRequired, adminRequired, async (req, res) => {
    try {
      const days = parseInt(req.query.days) || 7
      const items = []

      const decs = await query(
        `SELECT ud.id, ud.user_id, ud.decoration_id, d.name as dec_name, ud.expire_time
         FROM user_decorations ud
         INNER JOIN decorations d ON d.id = ud.decoration_id
         WHERE ud.expire_time IS NOT NULL
           AND ud.expire_time > NOW()
           AND ud.expire_time <= DATE_ADD(NOW(), INTERVAL ? DAY)
         ORDER BY ud.expire_time ASC
         LIMIT 50`,
        [days]
      )
      if (Array.isArray(decs)) {
        for (const r of decs) {
          items.push({ type: 'decoration', id: r.id, userId: r.user_id, name: r.dec_name, expireTime: r.expire_time })
        }
      }

      const pools = await query('SELECT id, name, cards_data, expiry_days FROM card_pools WHERE expiry_days > 0 AND status="active"')
      if (Array.isArray(pools)) {
        for (const p of pools) {
          let cards = []
          try { cards = JSON.parse(p.cards_data) } catch {}
          const threshold = new Date(Date.now() - (p.expiry_days - days) * 86400000).toISOString()
          const expiringCards = cards.filter((c) => c.created_at && c.created_at < threshold)
          if (expiringCards.length) {
            items.push({ type: 'card_pool', poolId: p.id, name: p.name, expiringCount: expiringCards.length, total: cards.length })
          }
        }
      }

      res.json({ code: 200, data: { days, total: items.length, items } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })
}

module.exports = deliveryLogRoutes
