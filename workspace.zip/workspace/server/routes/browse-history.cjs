const { query } = require('../database.cjs')

function browseHistoryRoutes(router) {
  router.post('/api/browse-history/add', async (req, res) => {
    try {
      const { userId, itemType, itemId, itemTitle, itemCover, itemUrl } = req.body
      if (!userId || !itemType || !itemId) return res.json({ code: 400, msg: '参数不完整' })

      const existing = await query(
        'SELECT id FROM browse_history WHERE user_id=? AND item_type=? AND item_id=?',
        [Number(userId), itemType, Number(itemId)]
      )
      if (existing && existing.length > 0) {
        await query('DELETE FROM browse_history WHERE id=?', [existing[0].id])
      }

      await query(
        'INSERT INTO browse_history (user_id, item_type, item_id, item_title, item_cover, item_url) VALUES (?,?,?,?,?,?)',
        [Number(userId), itemType, Number(itemId), itemTitle || '', itemCover || '', itemUrl || '']
      )

      const countRow = await query(
        'SELECT COUNT(*) as cnt FROM browse_history WHERE user_id=? AND item_type=?',
        [Number(userId), itemType]
      )
      const cnt = countRow && countRow[0] ? countRow[0].cnt : 0
      if (cnt > 30) {
        const toDelete = cnt - 30
        const oldIds = await query(
          'SELECT id FROM browse_history WHERE user_id=? AND item_type=? ORDER BY create_time ASC LIMIT ?',
          [Number(userId), itemType, toDelete]
        )
        if (oldIds && oldIds.length > 0) {
          const placeholders = oldIds.map(() => '?').join(',')
          await query(`DELETE FROM browse_history WHERE id IN (${placeholders})`, oldIds.map(r => r.id))
        }
      }

      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/browse-history/list', async (req, res) => {
    try {
      const { userId, itemType } = req.query
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      let sql = 'SELECT * FROM browse_history WHERE user_id=?'
      const params = [Number(userId)]
      if (itemType) {
        sql += ' AND item_type=?'
        params.push(itemType)
      }
      sql += ' ORDER BY create_time DESC LIMIT 60'

      const rows = await query(sql, params)
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = browseHistoryRoutes
