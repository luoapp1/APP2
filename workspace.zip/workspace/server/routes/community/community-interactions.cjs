'use strict';
const { getPermissionValue, hasPermission } = require('../../middleware/level-permissions.cjs')
const { query, getSystemOperator, getPool, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community-utils.cjs');
const { addBalance, addPoints, deductBalance, deductPoints } = require('../account-utils.cjs')
const { executePenalty } = require('../custom-task.cjs')
module.exports = function(app) {
  app.post('/api/community/post/:id/like', async (req, res) => {
    let conn
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      conn = await getPool().promise().getConnection()
      await conn.beginTransaction()

      const existing = await conn.query('SELECT id FROM community_likes WHERE post_id=? AND user_id=? FOR UPDATE', [postId, userId])

      if (existing[0] && existing[0].length > 0) {
        await conn.query('DELETE FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])
        await conn.query('UPDATE community_posts SET like_count = GREATEST(0, like_count - 1) WHERE id=?', [postId])
        await conn.commit()
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: false })
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: post[0]?.likeCount || 0 } })
      } else {
        await conn.query('INSERT INTO community_likes (post_id, user_id) VALUES (?,?)', [postId, userId])
        await conn.query('UPDATE community_posts SET like_count = like_count + 1 WHERE id=?', [postId])
        await conn.commit()
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        await progressTasksByAction(userId, '', 'like')
        await incrementLikeReceived(postId)
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: true })

        const postAuthor = await query('SELECT user_id, title FROM community_posts WHERE id=?', [postId])
        if (postAuthor.length > 0 && postAuthor[0].user_id !== userId) {
          const likerInfo = await query('SELECT nickname, username, avatar FROM users WHERE id=?', [userId])
          const likerName = likerInfo.length > 0 ? (likerInfo[0].nickname || likerInfo[0].username) : ''
          const likerAvatar = likerInfo.length > 0 ? (likerInfo[0].avatar || '') : ''
          await query(
            `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
             VALUES ('新的点赞', ?,'like', ?, ?, ?, ?, ?)`,
            [`${likerName} 点赞了您的帖子《${postAuthor[0].title}》`, `/community/post/${postId}`, postAuthor[0].user_id, userId, likerName, likerAvatar]
          )
        }

        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: post[0]?.likeCount || 0 } })
      }
    } catch (e) {
      if (conn) await conn.rollback().catch(() => {})
      res.serverError(e)
    } finally {
      if (conn) conn.release()
    }
  })

  app.post('/api/community/comment/:id/like', async (req, res) => {
    let conn
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const commentId = Number(req.params.id)

      conn = await getPool().promise().getConnection()
      await conn.beginTransaction()

      const existing = await conn.query('SELECT id FROM comment_likes WHERE comment_id=? AND user_id=? FOR UPDATE', [commentId, userId])
      if (existing[0] && existing[0].length > 0) {
        await conn.query('DELETE FROM comment_likes WHERE comment_id=? AND user_id=?', [commentId, userId])
        await conn.query('UPDATE community_comments SET like_count = GREATEST(0, like_count - 1) WHERE id=?', [commentId])
        await conn.commit()
        const c = await query('SELECT like_count as likeCount FROM community_comments WHERE id=?', [commentId])
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: c[0]?.likeCount || 0 } })
      } else {
        await conn.query('INSERT INTO comment_likes (comment_id, user_id) VALUES (?,?)', [commentId, userId])
        await conn.query('UPDATE community_comments SET like_count = like_count + 1 WHERE id=?', [commentId])
        await conn.commit()
        const c = await query('SELECT like_count as likeCount FROM community_comments WHERE id=?', [commentId])
        await progressTasksByAction(userId, '', 'like')
        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: c[0]?.likeCount || 0 } })
      }
    } catch (e) {
      if (conn) await conn.rollback().catch(() => {})
      res.serverError(e)
    } finally {
      if (conn) conn.release()
    }
  })

  app.post('/api/community/post/:id/favorite', async (req, res) => {
    let conn
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const groupId = req.body?.groupId ? Number(req.body.groupId) : 0

      // 新分组收藏系统
      if (groupId > 0) {
        const defaultRows = await query('SELECT id FROM collection_favorite_groups WHERE user_id=?', [userId])
        if (!defaultRows.length) {
          await query("INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,'默认收藏夹',0)", [userId])
        }
        const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [groupId, userId])
        if (!g.length) return res.json({ code: 400, msg: '分组不存在' })

        await query(
          'INSERT INTO post_favorites (user_id, post_id, group_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE group_id=VALUES(group_id)',
          [userId, postId, groupId]
        )
        await query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=? AND favorite_count = (SELECT cnt FROM (SELECT COUNT(*) as cnt FROM post_favorites WHERE post_id=?) t)', [postId, postId])
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: true })
        return res.json({ code: 200, msg: '收藏成功' })
      }

      // 旧toggle逻辑（事务保护避免竞态条件）
      conn = await getPool().promise().getConnection()
      await conn.beginTransaction()

      const existing = await conn.query('SELECT id FROM community_favorites WHERE post_id=? AND user_id=? FOR UPDATE', [postId, userId])

      if (existing[0] && existing[0].length > 0) {
        await conn.query('DELETE FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])
        await conn.query('UPDATE community_posts SET favorite_count = GREATEST(0, favorite_count - 1) WHERE id=?', [postId])
        await conn.commit()
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: false })
        res.json({ code: 200, msg: '已取消收藏', data: { isFavorited: false } })
      } else {
        await conn.query('INSERT INTO community_favorites (post_id, user_id) VALUES (?,?)', [postId, userId])
        await conn.query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=?', [postId])
        await conn.commit()
        await progressTasksByAction(userId, '', 'favorite')
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: true })
        res.json({ code: 200, msg: '已收藏', data: { isFavorited: true } })
      }
    } catch (e) {
      if (conn) await conn.rollback().catch(() => {})
      res.serverError(e)
    } finally {
      if (conn) conn.release()
    }
  })

  app.get('/api/community/user/favorites', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize

      const totalRow = await query(
        `SELECT COUNT(*) as total FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id WHERE f.user_id=? AND p.status='published'`,
        [userId]
      )
      const total = totalRow[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as postUserId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar,
                p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status,
                p.like_count as likeCount, p.comment_count as commentCount,
                p.view_count as viewCount, p.favorite_count as favoriteCount,
                p.is_global_pinned as isGlobalPinned,
                p.custom_badge as customBadge,
                p.content_permission as contentPermission, p.content_price as contentPrice, p.content_price_type as contentPriceType,
                p.create_time as createTime, p.update_time as updateTime,
                u.level_name as userLevelName, u.is_verified as userIsVerified,
                 COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                 (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                 COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                 COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                 COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                 COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                 ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                 ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                 (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                 f.create_time as favTime
         FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id
         LEFT JOIN users u ON p.user_id = u.id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         WHERE f.user_id=? AND p.status='published'
         ORDER BY f.create_time DESC
         LIMIT ${pageSize} OFFSET ${offset}`,
        [userId]
      )

      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
      }

      // 过滤付费内容
      if (list.length > 0) {
        try {
          const paidPosts = list.filter(p => p.contentPermission === 'paid')
          if (paidPosts.length > 0) {
            const paidIds = paidPosts.map(p => p.id)
            const paidSet = new Set()
            const purchases = await query(
              `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${paidIds.map(() => '?').join(',')})`,
              [userId, ...paidIds]
            )
            purchases.forEach(p => paidSet.add(p.content_id))
            const isAdmin = await isAdminById(userId)
            for (const item of paidPosts) {
              if (item.postUserId === userId || isAdmin) continue
              if (paidSet.has(item.id)) continue
              item.content = '部分内容付费 - 需购买后查看'
              item.contentFiltered = true
              try { item.images = [] } catch {}
            }
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page, pageSize } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.PINNED, { postId: Number(req.params.id), userId, isPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNamePin = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被置顶', `您的帖子《${post[0].title}》已被管理员置顶`, 'post_pinned', post[0].user_id, userId, adminNamePin || '管理员']
        )
      }

      const adminName = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '版块置顶' : '取消版块置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已置顶' : '已取消置顶', data: { isPinned: !!newVal } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/global-pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_global_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_global_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_global_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.GLOBAL_PINNED, { postId: Number(req.params.id), userId, isGlobalPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameGp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被全站置顶', `您的帖子《${post[0].title}》已被管理员全站置顶`, 'post_pinned', post[0].user_id, userId, adminNameGp || '管理员']
        )
      }

      const adminName2 = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName2, 'post', Number(req.params.id),
        `${newVal ? '全站置顶' : '取消全站置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已全站置顶' : '已取消全站置顶', data: { isGlobalPinned: !!newVal } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 自定义徽章
  app.post('/api/community/post/:id/custom-badge', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { badge } = req.body || {}
      const post = await query('SELECT id, title, custom_badge FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const val = badge ? String(badge).trim().slice(0, 10) : ''
      await query('UPDATE community_posts SET custom_badge=? WHERE id=?', [val, req.params.id])

      emitSafe(POST_EVENTS.BADGE_CHANGED, { postId: Number(req.params.id), userId, badge: val || null, title: post[0].title })

      const adminNameCB = await getAdminUserName(req)
      systemLog(val ? 'set_badge' : 'clear_badge', userId, adminNameCB, 'post', Number(req.params.id),
        `${val ? '设置自定义徽章' : '清除自定义徽章'}《${post[0].title}》${val ? '：' + val : ''}`)

      res.json({ code: 200, msg: val ? '自定义徽章已设置' : '自定义徽章已清除', data: { customBadge: val } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_essence FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_essence ? 0 : 1
      await query('UPDATE community_posts SET is_essence=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.ESSENCED, { postId: Number(req.params.id), userId, isEssence: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameEss = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被加精', `您的帖子《${post[0].title}》已被管理员设为精华`, 'post_essence', post[0].user_id, userId, adminNameEss || '管理员']
        )
      }

      const adminName = await getAdminUserName(req) // needed for systemLog below
      systemLog(newVal ? 'essence' : 'unessence', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '设为精华' : '取消精华'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已加精' : '已取消加精', data: { isEssence: !!newVal } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/hot', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_hot FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_hot ? 0 : 1
      // 手动取消热帖后禁止自动升级；手动设为热帖则重置
      const disabled = newVal ? 0 : 1
      await query('UPDATE community_posts SET is_hot=?, hot_manually_disabled=? WHERE id=?', [newVal, disabled, req.params.id])
      emitSafe(POST_EVENTS.HOT_TOGGLED, { postId: Number(req.params.id), userId, isHot: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameHot = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被设为热帖', `您的帖子《${post[0].title}》已被管理员设为热帖`, 'system', post[0].user_id, userId, adminNameHot || '管理员']
        )
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      } else {
        const adminNameHot = await getAdminUserName(req)
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      }
      res.json({ code: 200, msg: newVal ? '已设为热帖' : '已取消热帖', data: { isHot: !!newVal } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_locked ? 0 : 1
      await query('UPDATE community_posts SET is_locked=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.LOCKED, { postId: Number(req.params.id), userId, isLocked: !!newVal, title: post[0].title })

      const adminNameLock = await getAdminUserName(req)
      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被锁定', `您的帖子《${post[0].title}》已被管理员锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
        if (post[0].user_id) executePenalty(post[0].user_id, '', 'post_locked', { reason: req.body?.reason || '管理员锁定' })
      }
      if (!newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子已解锁', `您的帖子《${post[0].title}》已被管理员解除锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
      }

      systemLog(newVal ? 'lock' : 'unlock', userId, adminNameLock, 'post', Number(req.params.id),
        `${newVal ? '锁定' : '解锁'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已锁定' : '已解锁', data: { isLocked: !!newVal } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/coin', async (req, res) => {
    let conn
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再打赏' })

      const { amount = 1, coinType = 'coin' } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '投币数量必须大于0' })

      const post = await query('SELECT id, title, user_id, user_name, coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (userId === post[0].user_id) return res.json({ code: 400, msg: '不能打赏自己的帖子' })

      const field = coinType === 'points' ? 'points' : 'balance'

      conn = await getPool().promise().getConnection()
      await conn.beginTransaction()

      const [userRows] = await conn.query(`SELECT nickname, username, avatar FROM users WHERE id=? FOR UPDATE`, [userId])
      if (!userRows || userRows.length === 0) {
        await conn.rollback()
        return res.json({ code: 404, msg: '用户不存在' })
      }

      const [balRows] = await conn.query(`SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=? FOR UPDATE`, [userId, field])
      const currentBalance = balRows && balRows.length > 0 ? Number(balRows[0].available) : 0
      if (currentBalance < coinAmount) {
        await conn.rollback()
        return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })
      }

      const unitLabel = coinType === 'points' ? '积分' : '余额'
      const fromName = userRows[0].nickname || userRows[0].username || ('user_' + userId)

      const postTitle = post[0].title || ''

      if (coinType === 'points') {
        await deductPoints(userId, fromName, coinAmount, '帖子打赏', `打赏帖子「${postTitle}」`, conn)
      } else {
        await deductBalance(userId, fromName, coinAmount, '帖子打赏', `打赏帖子「${postTitle}」`, conn)
      }

      await conn.query('UPDATE community_posts SET coin_count = coin_count + ? WHERE id=?', [coinAmount, req.params.id])
      const fromAvatar = userRows[0].avatar || ''
      await conn.query(
        'INSERT INTO community_coin_logs (post_id, from_user_id, from_user_name, from_user_avatar, to_user_id, amount, coin_type) VALUES (?,?,?,?,?,?,?)',
        [req.params.id, userId, fromName, fromAvatar, post[0].user_id, coinAmount, coinType]
      )

      const postAuthorId = post[0].user_id

      await conn.query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, ?, ?, '')`,
        ['打赏通知', `${fromName} 打赏了您的帖子「${postTitle}」${coinAmount}${unitLabel}`, postAuthorId, userId, fromName]
      )

      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await conn.query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, 0, ?, '')`,
        ['打赏成功', `您成功打赏了 ${post[0].user_name || '用户'} 的帖子「${postTitle}」${coinAmount}${unitLabel}`, userId, sysOpName]
      )

      await conn.commit()

      const updated = await query('SELECT coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '打赏成功', data: { coinCount: updated[0]?.coinCount || 0 } })
    } catch (e) {
      if (conn) await conn.rollback().catch(() => {})
      res.serverError(e)
    } finally {
      if (conn) conn.release()
    }
  })

  // 打赏记录
  app.get('/api/community/post/:id/coin-logs', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const logs = await query(
        `SELECT cl.id, cl.from_user_id as fromUserId, cl.from_user_name as fromUserName,
                cl.from_user_avatar as fromUserAvatar, cl.amount, cl.coin_type as coinType,
                cl.create_time as createTime,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id
                 WHERE uaf.user_id = cl.from_user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id
                 AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect
         FROM community_coin_logs cl
         LEFT JOIN users u ON u.id = cl.from_user_id
         WHERE cl.post_id=? ORDER BY cl.create_time DESC LIMIT ? OFFSET ?`,
        [req.params.id, parseInt(pageSize), offset]
      )
      const count = await query('SELECT COUNT(*) as total FROM community_coin_logs WHERE post_id=?', [req.params.id])
      res.json({ code: 200, msg: 'success', data: { list: logs, total: count[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 附件购买
  app.post('/api/community/attach/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再下载' })

      const { postId, attachUrl, coinType = 'coin', amount = 0 } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '金额有误' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const bought = await conn.query(
          'SELECT id FROM community_attach_purchases WHERE post_id=? AND user_id=? AND attach_url=? FOR UPDATE',
          [postId || 0, userId, attachUrl || '']
        )
        if (bought[0] && bought[0].length > 0) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 200, msg: '已购买过，无需重复购买' })
        }

        const field = coinType === 'points' ? 'points' : 'balance'
        const user = await query(`SELECT ${field}, username FROM users WHERE id=?`, [userId])
        if (!user || user.length === 0) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 404, msg: '用户不存在' })
        }
        if (Number(user[0][field]) < coinAmount) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })
        }

        if (coinType === 'points') {
          await deductPoints(userId, user[0].username || '', coinAmount, '附件购买', `购买帖子附件 #${postId || 0}`, conn)
        } else {
          await deductBalance(userId, user[0].username || '', coinAmount, '附件购买', `购买帖子附件 #${postId || 0}`, conn)
        }
        await conn.query(
          'INSERT INTO community_attach_purchases (post_id, user_id, attach_url, coin_type, coin_amount) VALUES (?,?,?,?,?)',
          [postId || 0, userId, attachUrl || '', coinType, coinAmount]
        )

        await conn.commit()
        conn.release()
      } catch (e) {
        try { await conn.rollback() } catch {}
        conn.release()
        throw e
      }

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 附件购买状态查询
  app.get('/api/community/attach/purchased', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { urls: [] } })

      const rows = await query(
        'SELECT attach_url FROM community_attach_purchases WHERE post_id=? AND user_id=?',
        [req.query.postId || 0, userId]
      )
      res.json({ code: 200, data: { urls: (rows || []).map(r => r.attach_url) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Comment APIs ====================

  // ==================== Comment APIs ====================

  app.get('/api/community/post/:id/comments', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, sortBy = 'default' } = req.query
      const postId = Number(req.params.id)

      const currentUserId = await getUserId(req)
      const isAdminUser = await isAdmin(req)
      let statusFilter = "AND c.status='published'"
      if (currentUserId > 0) {
        const postOwner = await query('SELECT user_id FROM community_posts WHERE id=?', [postId])
        const isPostOwner = postOwner.length > 0 && postOwner[0].user_id === currentUserId
        if (isAdminUser || isPostOwner) {
          statusFilter = ''
        } else {
          statusFilter = `AND (c.status='published' OR (c.status='pending' AND c.user_id=${currentUserId}) OR (c.status='rejected' AND c.user_id=${currentUserId}))`
        }
      }

      const countResult = await query(
        `SELECT COUNT(*) as total FROM community_comments c WHERE c.post_id=? AND c.parent_id=0 AND c.is_deleted=0 ${statusFilter}`, [postId]
      )
      const total = countResult[0]?.total || 0

      const allCountResult = await query(
        `SELECT COUNT(*) as total FROM community_comments c WHERE c.post_id=? AND c.is_deleted=0 ${statusFilter}`, [postId]
      )
      const commentCount = allCountResult[0]?.total || 0
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const orderClause = sortBy === 'hot'
        ? 'ORDER BY c.is_pinned DESC, (c.like_count + c.reply_count) DESC, c.create_time DESC'
        : 'ORDER BY c.is_pinned DESC, c.create_time DESC'

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                c.content, c.images,
                c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                 c.create_time as createTime,
                 u.is_verified as userIsVerified,
                 COALESCE(el.name, 'Lv.1') as userExpLevelName,
                 el.icon as userExpLevelIcon,
                 COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                 COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                 u.active_title_name as userTitleName,
                 ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                 ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                   ut_all.allIcons as userAllTitleIcons,
                   ut_all.allNames as userAllTitleNames,
                   (SELECT GROUP_CONCAT(ct3.name SEPARATOR '|||') FROM user_titles ut3 JOIN custom_titles ct3 ON ut3.title_id = ct3.id WHERE ut3.user_id = c.user_id AND ct3.status = '1' AND ut3.title_id IN (u.active_title_id, u.active_title_id2, u.active_title_id3)) as userActiveTitleNames,
                   (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                    (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect,
                    (SELECT JSON_OBJECT('image_url', d2.image_url, 'config_json', d2.config_json, 'css_class', d2.css_class) FROM decorations d2 WHERE d2.id = u.active_comment_background_id AND d2.type = 'comment_background' AND d2.status = '1') as userCommentBackground
             FROM community_comments c
           LEFT JOIN users u ON c.user_id = u.id
           LEFT JOIN experience_levels el ON el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status = '1'
             AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el2.status = '1' AND el2.exp_required > el.exp_required)
           LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
           LEFT JOIN membership_levels ml ON ml.id = u.level_id
           LEFT JOIN (
             SELECT ut2.user_id,
               GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
               GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
             FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
             WHERE ct2.status = '1' GROUP BY ut2.user_id
           ) ut_all ON u.id = ut_all.user_id
             WHERE c.post_id=? AND c.parent_id=0 AND c.is_deleted=0 ${statusFilter}
           ${orderClause} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
         [postId]
      )

      let allReplies = []
      if (comments.length > 0) {
        const commentIds = comments.map(c => c.id)
        allReplies = await query(
          `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                  c.content, c.images,
                  c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                  c.create_time as createTime,
                  u.is_verified as userIsVerified,
                  COALESCE(el.name, 'Lv.1') as userExpLevelName,
                  el.icon as userExpLevelIcon,
                  COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                  COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                   u.active_title_name as userTitleName,
                   ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                   ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                   ut_all.allIcons as userAllTitleIcons,
                   ut_all.allNames as userAllTitleNames,
                   (SELECT GROUP_CONCAT(ct3.name SEPARATOR '|||') FROM user_titles ut3 JOIN custom_titles ct3 ON ut3.title_id = ct3.id WHERE ut3.user_id = c.user_id AND ct3.status = '1' AND ut3.title_id IN (u.active_title_id, u.active_title_id2, u.active_title_id3)) as userActiveTitleNames,
                   (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                   (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect,
                   (SELECT JSON_OBJECT('image_url', d2.image_url, 'config_json', d2.config_json, 'css_class', d2.css_class) FROM decorations d2 WHERE d2.id = u.active_comment_background_id AND d2.type = 'comment_background' AND d2.status = '1') as userCommentBackground
            FROM community_comments c
            LEFT JOIN users u ON c.user_id = u.id
            LEFT JOIN experience_levels el ON el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status = '1'
              AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el2.status = '1' AND el2.exp_required > el.exp_required)
            LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
            LEFT JOIN membership_levels ml ON ml.id = u.level_id
            LEFT JOIN (
              SELECT ut2.user_id,
                GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
                GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
              FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
              WHERE ct2.status = '1' GROUP BY ut2.user_id
            ) ut_all ON u.id = ut_all.user_id
            WHERE c.post_id=? AND c.is_deleted=0 AND c.parent_id IN (${commentIds.map(() => '?').join(',')})
           ORDER BY c.create_time ASC`,
          [postId, ...commentIds]
        )
        const replyMap = {}
        for (const r of allReplies) {
          if (!replyMap[r.parentId]) replyMap[r.parentId] = []
          replyMap[r.parentId].push(r)
        }
        for (const c of comments) {
          c.replies = replyMap[c.id] || []
          try { c.images = c.images ? JSON.parse(c.images) : [] } catch { c.images = [] }
          for (const r of (c.replies || [])) {
            try { r.images = r.images ? JSON.parse(r.images) : [] } catch { r.images = [] }
          }
        }
      }

      if (currentUserId > 0 && comments.length > 0) {
        const allIds = [...comments.map(c => c.id), ...allReplies.map(r => r.id)]
        if (allIds.length > 0) {
          const likedRows = await query(
            `SELECT comment_id FROM comment_likes WHERE comment_id IN (${allIds.map(() => '?').join(',')}) AND user_id=?`,
            [...allIds, currentUserId]
          )
          const likedSet = new Set(likedRows.map(r => r.comment_id))
          for (const c of comments) c.isLiked = likedSet.has(c.id) ? 1 : 0
          for (const r of allReplies) r.isLiked = likedSet.has(r.id) ? 1 : 0
        }
      }

      res.json({ code: 200, msg: 'success', data: { list: comments, total, commentCount, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { content: rawContent, parent_id: parentId = 0, images } = req.body
      const content = sanitizeCommunityContent(rawContent)
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      // C4: 评论频率限制(条/日)
      const maxCmtsPerDay = parseInt(await getPermissionValue(userId, 'community', 'C4') || '999')
      const todayCmt = new Date().toISOString().substring(0, 10)
      const dailyCmtCount = await query(
        "SELECT COUNT(*) as cnt FROM community_comments WHERE user_id=? AND DATE(create_time)=? AND is_deleted=0",
        [userId, todayCmt]
      )
      if (dailyCmtCount[0]?.cnt >= maxCmtsPerDay) {
        return res.json({ code: 400, msg: `当前等级每日最多评论${maxCmtsPerDay}条` })
      }

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''
      const imgStr = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      const postRow = await query('SELECT section_id FROM community_posts WHERE id=?', [Number(req.params.id)])
      let commentStatus = 'published'
      if (postRow.length > 0) {
        const secRow = await query('SELECT comment_review_required FROM community_sections WHERE id=? AND is_deleted=0', [postRow[0].section_id])
        if (secRow.length > 0 && secRow[0].comment_review_required === 1) {
          commentStatus = 'pending'
        }
      }

      // C2: 评论免审核 — 跳过管线直接发布
      const commentSkipReview = await hasPermission(userId, 'community', 'C2')
      if (commentSkipReview) {
        commentStatus = 'published'
      } else {
      // 自动审核管线
      try {
        const mp = require('./moderation-pipeline.cjs')
        const pipelineResult = await mp.moderationPipeline(userId, {
          text: content || '',
          title: '',
          content: content || ''
        }, 'comment')
        if (pipelineResult.action === 'reject') {
          commentStatus = 'rejected'
        }
        if (pipelineResult.action === 'pending') {
          commentStatus = 'pending'
        }
      } catch (e) { console.error('[comment] moderation pipeline error:', e.message) }
      }

      const result = await query(
        `INSERT INTO community_comments (post_id, parent_id, user_id, user_name, user_avatar, content, images, status)
         VALUES (?,?,?,?,?,?,?,?)`,
        [Number(req.params.id), Number(parentId), userId, userName, userAvatar, content.trim(), imgStr, commentStatus]
      )
      const commentId = result.insertId

      if (Number(parentId) > 0) {
        await query('UPDATE community_comments SET reply_count = reply_count + 1 WHERE id=?', [Number(parentId)])
      }
      if (commentStatus !== 'rejected') {
        await query('UPDATE community_posts SET comment_count = comment_count + 1, update_time=' + nowExpr + ' WHERE id=?', [req.params.id])
        await progressTasksByAction(userId, userName, 'comment')
        await incrementCommentCount(userId)
      }

      // 评论回复通知 (only for non-rejected)
      if (commentStatus !== 'rejected') {
        const postInfo = await query('SELECT user_id, title FROM community_posts WHERE id=?', [Number(req.params.id)])
        if (postInfo.length > 0) {
          if (Number(parentId) > 0) {
            const parentInfo = await query('SELECT user_id, user_name FROM community_comments WHERE id=? AND is_deleted=0', [Number(parentId)])
            if (parentInfo.length > 0 && parentInfo[0].user_id !== userId) {
              const commentPreview = content.trim().length > 80 ? content.trim().substring(0, 80) + '...' : content.trim()
              await query(
                `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
                 VALUES ('评论回复', ?,'comment', ?, ?, ?, ?, ?)`,
                [`${userName}: ${commentPreview}`, `/community/post/${Number(req.params.id)}`, parentInfo[0].user_id, userId, userName, userAvatar]
              )
              const targetEmail = await getUserEmail(parentInfo[0].user_id)
              if (targetEmail) {
                sendNotificationEmail('comment_reply', targetEmail, {
                  username: parentInfo[0].user_name,
                  subject: '评论收到新回复',
                  content: `用户 ${userName} 回复了您在《${postInfo[0].title}》中的评论。`
                })
              }
            }
          } else {
            if (postInfo[0].user_id !== userId) {
              const commentPreview = content.trim().length > 80 ? content.trim().substring(0, 80) + '...' : content.trim()
              await query(
                `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
                 VALUES ('新的评论', ?,'comment', ?, ?, ?, ?, ?)`,
                [`${userName}: ${commentPreview}`, `/community/post/${Number(req.params.id)}`, postInfo[0].user_id, userId, userName, userAvatar]
              )
              const targetEmail = await getUserEmail(postInfo[0].user_id)
              if (targetEmail) {
                sendNotificationEmail('comment_reply', targetEmail, {
                  username: '',
                  subject: '帖子收到新评论',
                  content: `用户 ${userName} 评论了您的帖子《${postInfo[0].title}》。`
                })
              }
            }
          }
        }

        createMentionNotifications(content.trim(), userId, userName, userAvatar, 'comment', Number(req.params.id))
      }

      emitSafe(COMMENT_EVENTS.CREATED, { commentId, postId: Number(req.params.id), userId, userName, parentId: Number(parentId), status: commentStatus })

      const msgMap = { rejected: '评论未通过自动审核，请修改后重新发布', pending: '评论已提交，等待审核' }
      const msg = msgMap[commentStatus] || '评论成功'
      res.json({ code: 200, msg, data: { id: commentId, status: commentStatus } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      let postOwnerId = null
      let isCollection = false
      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (post && post.length > 0) {
        postOwnerId = post[0].user_id
      } else {
        const coll = await query('SELECT user_id FROM community_collections WHERE id=? AND is_deleted=0', [c.post_id])
        if (coll && coll.length > 0) {
          postOwnerId = coll[0].user_id
          isCollection = true
        } else {
          return res.json({ code: 404, msg: '内容不存在' })
        }
      }

      const isCommentOwner = c.user_id === userId
      const isPostOwner = postOwnerId === userId
      const isAdminUser = await isAdmin(req)

      if (!isCommentOwner && !isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权删除此评论' })
      }

      const isReply = Number(c.parent_id) > 0
      if (isReply) {
        const isReplyR = await query('SELECT parent_id FROM community_comments WHERE id=?', [req.params.id])
        if (isReplyR.length && Number(isReplyR[0].parent_id) > 0) {
          await query('UPDATE community_comments SET reply_count = GREATEST(0, reply_count - 1) WHERE id=?', [isReplyR[0].parent_id])
        }
        await query('UPDATE community_comments SET is_deleted=1 WHERE id=?', [req.params.id])
        if (!isCollection) await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id=?', [c.post_id])
      } else {
        const replyIds = await query('SELECT id FROM community_comments WHERE parent_id=?', [req.params.id])
        for (const r of replyIds) {
          deleteFileRecordsByRef(r.id, 'comment').catch(() => {})
        }
        await query('UPDATE community_comments SET is_deleted=1 WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
        const replyCount = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE parent_id=?', [req.params.id])
        const deletedReplies = replyCount[0]?.cnt || 0
        if (!isCollection) await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - ' + (1 + deletedReplies) + ') WHERE id=?', [c.post_id])
      }

      deleteFileRecordsByRef(req.params.id, 'comment').catch(() => {})

      emitSafe(COMMENT_EVENTS.DELETED, { commentId: Number(req.params.id), postId: c.post_id, userId })

      if (c.user_id) executePenalty(c.user_id, '', 'comment_deleted', {})

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/comment/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      if (Number(c.parent_id) > 0) return res.json({ code: 400, msg: '不能置顶回复' })

      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权置顶此评论' })
      }

      const current = await query('SELECT is_pinned FROM community_comments WHERE id=?', [req.params.id])
      const newPinned = current[0]?.is_pinned ? 0 : 1
      await query('UPDATE community_comments SET is_pinned=? WHERE id=?', [newPinned, req.params.id])

      res.json({ code: 200, msg: newPinned ? '置顶成功' : '取消置顶成功', data: { isPinned: !!newPinned } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Comment Moderation APIs ====================

  app.get('/api/community/moderator/comments/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      if (!isAdminUser) {
        const sectionIds = await getModeratorSectionIds(userId)
        if (sectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })
      }

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      let whereClause = "WHERE cc.status='pending'"
      if (!isAdminUser) {
        const sectionIds = await getModeratorSectionIds(userId)
        // 需要通过 post 关联 section
        whereClause += ` AND cp.section_id IN (${sectionIds.map(() => '?').join(',')})`
      }

      const countResult = await query(
        `SELECT COUNT(*) as total FROM community_comments cc
         JOIN community_posts cp ON cc.post_id = cp.id
         ${whereClause}`,
        isAdminUser ? [] : (await getModeratorSectionIds(userId))
      )
      const total = countResult[0]?.total || 0

      const params = isAdminUser ? [] : (await getModeratorSectionIds(userId))
      const list = await query(
        `SELECT cc.id, cc.post_id as postId, cc.parent_id as parentId, cc.user_id as userId,
                cc.user_name as userName, cc.content, cc.images, cc.status,
                cc.like_count as likeCount, cc.reply_count as replyCount,
                cc.create_time as createTime,
                cp.title as postTitle, cp.section_id as sectionId,
                cs.name as sectionName
         FROM community_comments cc
         JOIN community_posts cp ON cc.post_id = cp.id
         JOIN community_sections cs ON cp.section_id = cs.id
         ${whereClause}
         ORDER BY cc.create_time ASC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        params
      )
      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/moderator/comment/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      const c = comment[0]

      if (!(await canAccessSection(userId, c.section_id))) return res.json({ code: 403, msg: '无权限' })

      await query("UPDATE community_comments SET status='published' WHERE id=?", [req.params.id])
      await query('UPDATE community_posts SET comment_count = comment_count + 1 WHERE id=?', [c.post_id])

      const targetEmail = await getUserEmail(c.user_id)
      if (targetEmail) {
        sendNotificationEmail('comment_approved', targetEmail, {
          username: c.user_name,
          subject: '评论已通过审核',
          content: '您的评论已通过审核并发布。'
        })
      }
      const sysOp = await getSystemOperator()
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
        ['评论审核通过', '您的评论已通过审核并发布', 'comment_approved', c.user_id, sysOp ? sysOp.id : 0, sysOp ? (sysOp.username || '系统') : '系统']
      )

      res.json({ code: 200, msg: '审核通过' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/moderator/comment/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { reason } = req.body
      const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      const c = comment[0]

      if (!(await canAccessSection(userId, c.section_id))) return res.json({ code: 403, msg: '无权限' })

      await query("UPDATE community_comments SET status='rejected' WHERE id=?", [req.params.id])

      const targetEmail = await getUserEmail(c.user_id)
      if (targetEmail) {
        const reasonText = reason ? ` 原因：${reason}` : ''
        sendNotificationEmail('comment_rejected', targetEmail, {
          username: c.user_name,
          subject: '评论未通过审核',
          content: `您的评论未通过审核。${reasonText}`
        })
      }
      const sysOpRj = await getSystemOperator()
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
        ['评论审核未通过', `您的评论未通过审核${reason ? `，原因：${reason}` : ''}`, 'comment_rejected', c.user_id, sysOpRj ? sysOpRj.id : 0, sysOpRj ? (sysOpRj.username || '系统') : '系统']
      )

      res.json({ code: 200, msg: '已拒绝' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/moderator/comments/batch-approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { ids } = req.body
      if (!ids || !Array.isArray(ids) || ids.length === 0) return res.json({ code: 400, msg: '缺少评论ID列表' })

      let approved = 0
      for (const commentId of ids) {
        const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=? AND cc.status=?', [commentId, 'pending'])
        if (comment.length === 0) continue
        const c = comment[0]
        if (!(await canAccessSection(userId, c.section_id))) continue

        await query("UPDATE community_comments SET status='published' WHERE id=?", [commentId])
        await query('UPDATE community_posts SET comment_count = comment_count + 1 WHERE id=?', [c.post_id])
        approved++

        const targetEmail = await getUserEmail(c.user_id)
        if (targetEmail) {
          sendNotificationEmail('comment_approved', targetEmail, {
            username: c.user_name,
            subject: '评论已通过审核',
            content: '您的评论已通过审核并发布。'
          })
        }
        const sysOp = await getSystemOperator()
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
          ['评论审核通过', '您的评论已通过审核并发布', 'comment_approved', c.user_id, sysOp ? sysOp.id : 0, sysOp ? (sysOp.username || '系统') : '系统']
        ).catch(() => {})
      }

      res.json({ code: 200, msg: `已通过 ${approved} 条评论` })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/moderator/comments/batch-reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { ids, reason } = req.body
      if (!ids || !Array.isArray(ids) || ids.length === 0) return res.json({ code: 400, msg: '缺少评论ID列表' })

      const isAdminUser = await isAdminById(userId)
      const commentRows = await query(
        'SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id IN (?) AND cc.status=?',
        [ids, 'pending']
      )
      const uniqueSections = [...new Set(commentRows.map(c => c.section_id))]
      const sectionAccess = {}
      if (isAdminUser) {
        for (const sid of uniqueSections) sectionAccess[sid] = true
      } else {
        const results = await Promise.all(uniqueSections.map(sid => canAccessSection(userId, sid)))
        uniqueSections.forEach((sid, i) => { sectionAccess[sid] = results[i] })
      }
      const validComments = commentRows.filter(c => sectionAccess[c.section_id])
      if (!validComments.length) return res.json({ code: 200, msg: '没有可驳回的评论' })

      const validIds = validComments.map(c => c.id)
      await query('UPDATE community_comments SET status=? WHERE id IN (?)', ['rejected', validIds])

      for (const c of validComments) {
        const targetEmail = await getUserEmail(c.user_id)
        if (targetEmail) {
          const reasonText = reason ? ` 原因：${reason}` : ''
          sendNotificationEmail('comment_rejected', targetEmail, {
            username: c.user_name,
            subject: '评论未通过审核',
            content: `您的评论未通过审核。${reasonText}`
          })
        }
        const sysOp = await getSystemOperator()
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
          ['评论审核未通过', `您的评论未通过审核${reason ? `，原因：${reason}` : ''}`, 'comment_rejected', c.user_id, sysOp ? sysOp.id : 0, sysOp ? (sysOp.username || '系统') : '系统']
        ).catch(() => {})
      }

      res.json({ code: 200, msg: `已拒绝 ${validComments.length} 条评论` })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Draft APIs ====================

  app.get('/api/community/drafts', async (req, res) => {
    try {
      const { userId } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId参数' })

      const drafts = await query(
        `SELECT id, user_id as userId, section_id as sectionId, title, content,
                images, tags, official_tags as officialTags, has_resource as hasResource,
                resource_type as resourceType, resource_url as resourceUrl,
                resource_price as resourcePrice, resource_price_type as resourcePriceType,
                extract_code as extractCode, permission,
                create_time as createTime, update_time as updateTime
         FROM community_drafts WHERE user_id=? ORDER BY update_time DESC`, [Number(userId)]
      )
      for (const d of drafts) {
        try { d.tags = d.tags ? JSON.parse(d.tags) : [] } catch { d.tags = [] }
        try { d.officialTags = d.officialTags ? JSON.parse(d.officialTags) : [] } catch { d.officialTags = [] }
        try { d.images = d.images ? JSON.parse(d.images) : [] } catch { d.images = [] }
        d.hasResource = !!d.hasResource
      }

      res.json({ code: 200, msg: 'success', data: drafts })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/draft', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        id, sectionId, title, content: rawContent, images, tags, officialTags,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission
      } = req.body
      const content = sanitizeCommunityContent(rawContent)

      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'
      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'

      if (id) {
        await query(
          `UPDATE community_drafts SET section_id=?, title=?, content=?, images=?, tags=?, official_tags=?,
           has_resource=?, resource_type=?, resource_url=?, resource_price=?, resource_price_type=?,
           extract_code=?, permission=?, update_time=${nowExpr}
           WHERE id=? AND user_id=?`,
          [sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public', id, userId]
        )
        res.json({ code: 200, msg: '草稿已更新', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_drafts (user_id, section_id, title, content, images, tags, official_tags,
            has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [userId, sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public']
        )
        res.json({ code: 200, msg: '草稿已保存', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/draft/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [req.params.id, userId])
      res.json({ code: 200, msg: '草稿已删除' })
    } catch (e) {
      res.serverError(e)
    }
  })
  // ==================== Voting APIs ====================

  app.post('/api/community/post/:id/vote', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const { question, options, maxSelect, endTime } = req.body
      if (!question || !question.trim()) return res.json({ code: 400, msg: '请输入投票问题' })
      if (!options || !Array.isArray(options) || options.length < 2) return res.json({ code: 400, msg: '至少需要2个选项' })

      // C15: 发起投票
      const canCreateVote = await hasPermission(userId, 'community', 'C15')
      if (!canCreateVote) return res.json({ code: 403, msg: '当前等级不支持发起投票' })

      // C16: 投票选项上限
      const maxVoteOptions = parseInt(await getPermissionValue(userId, 'community', 'C16') || '999')
      if (options.length > maxVoteOptions) {
        return res.json({ code: 400, msg: `当前等级投票选项上限为${maxVoteOptions}个` })
      }

      const postRow = await query('SELECT user_id, section_id FROM community_posts WHERE id=?', [postId])
      if (!postRow || postRow.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (postRow[0].user_id !== userId && !(await canAccessSection(userId, postRow[0].section_id))) {
        return res.json({ code: 403, msg: '无权限创建投票' })
      }

      const result = await query(
        `INSERT INTO community_votes (post_id, question, options, max_select, end_time, create_time)
         VALUES (?,?,?,?,?,NOW())`,
        [postId, question.trim(), JSON.stringify(options), maxSelect || 1, endTime || null]
      )

      res.json({ code: 200, msg: '投票创建成功', data: { id: result.insertId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/vote/:voteId/cast', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { optionIndexes } = req.body
      if (!optionIndexes || !Array.isArray(optionIndexes) || optionIndexes.length === 0) {
        return res.json({ code: 400, msg: '请选择投票选项' })
      }

      const voteId = Number(req.params.voteId)

      const voteRow = await query('SELECT id, post_id, options, max_select, end_time, closed FROM community_votes WHERE id=?', [voteId])
      if (!voteRow || voteRow.length === 0) return res.json({ code: 404, msg: '投票不存在' })
      const v = voteRow[0]

      if (v.closed === 1) return res.json({ code: 400, msg: '投票已关闭' })
      if (v.end_time && new Date(v.end_time) < new Date()) return res.json({ code: 400, msg: '投票已结束' })

      const opts = JSON.parse(v.options || '[]')
      const maxSelect = v.max_select || 1
      if (optionIndexes.length > maxSelect) return res.json({ code: 400, msg: `最多选择 ${maxSelect} 项` })
      for (const idx of optionIndexes) {
        if (idx < 0 || idx >= opts.length) return res.json({ code: 400, msg: '无效的选项' })
      }

      const existing = await query('SELECT id FROM community_vote_records WHERE vote_id=? AND user_id=?', [voteId, userId])
      if (existing && existing.length > 0) return res.json({ code: 400, msg: '您已经投过票了' })

      for (const idx of optionIndexes) {
        await query(
          'INSERT INTO community_vote_records (vote_id, user_id, option_index, create_time) VALUES (?,?,?,NOW())',
          [voteId, userId, idx]
        )
      }

      const countRows = await query(
        `SELECT option_index, COUNT(*) as cnt FROM community_vote_records WHERE vote_id=? GROUP BY option_index`,
        [voteId]
      )
      const counts = {}
      for (const r of countRows) {
        counts[r.option_index] = r.cnt
      }

      res.json({ code: 200, msg: '投票成功', data: { counts } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/post/:id/votes', async (req, res) => {
    try {
      const postId = Number(req.params.id)
      const currentUserId = await getUserId(req)

      const votes = await query(
        `SELECT id, post_id as postId, question, options, max_select as maxSelect, end_time as endTime, create_time as createTime, closed
         FROM community_votes WHERE post_id=? ORDER BY create_time DESC`,
        [postId]
      )

      for (const vote of votes) {
        try { vote.options = vote.options ? JSON.parse(vote.options) : [] } catch { vote.options = [] }

        const countRows = await query(
          `SELECT option_index, COUNT(*) as cnt FROM community_vote_records WHERE vote_id=? GROUP BY option_index`,
          [vote.id]
        )
        vote.optionCounts = {}
        for (const r of countRows) {
          vote.optionCounts[r.option_index] = r.cnt
        }

        vote.userVoted = false
        if (currentUserId > 0) {
          const userRecord = await query('SELECT id FROM community_vote_records WHERE vote_id=? AND user_id=? LIMIT 1', [vote.id, currentUserId])
          vote.userVoted = userRecord && userRecord.length > 0
        }
      }

      res.json({ code: 200, msg: 'success', data: votes })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/vote/:voteId/close', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const voteId = Number(req.params.voteId)
      const voteRow = await query('SELECT id, post_id FROM community_votes WHERE id=?', [voteId])
      if (!voteRow || voteRow.length === 0) return res.json({ code: 404, msg: '投票不存在' })

      const postRow = await query('SELECT user_id, section_id FROM community_posts WHERE id=?', [voteRow[0].post_id])
      if (!postRow || postRow.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (postRow[0].user_id !== userId && !(await canAccessSection(userId, postRow[0].section_id))) {
        return res.json({ code: 403, msg: '无权限关闭投票' })
      }

      await query('UPDATE community_votes SET closed=1 WHERE id=?', [voteId])

      res.json({ code: 200, msg: '投票已关闭' })
    } catch (e) {
      res.serverError(e)
    }
  })

};
