const { query, getSystemOperator } = require('../../database.cjs')
const { sessions, SESSION_TTL } = require('../system.cjs')
const nowExpr = 'NOW()'
const { progressTasksByAction, executePenalty } = require('../custom-task.cjs')
const { systemLog, sanitizeCommunityContent } = require('../../middleware/security.cjs')
const { emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS } = require('../../plugins/events.cjs')
const { deleteFileRecordsByRef, deleteFileRecordsByIds } = require('../../utils/file-helper.cjs')
const { sendNotificationEmail, getAdminEmails } = require('../email.cjs')
const multer = require('multer')
const path = require('path')
const communityUploadDir = path.join(__dirname, '..', '..', 'uploads')

const communityImageUpload = multer({
  storage: multer.diskStorage({
    destination: communityUploadDir,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg'
      cb(null, 'community_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + ext)
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 }
})

;(async () => {
  try {
    const cols = await query("SHOW COLUMNS FROM community_comments LIKE 'status'")
    if (!cols || cols.length === 0) {
      await query("ALTER TABLE community_comments ADD COLUMN status VARCHAR(20) DEFAULT 'published'")
      console.log('[Community] Added status column to community_comments')
    }
    const rcols = await query("SHOW COLUMNS FROM community_sections LIKE 'comment_review_required'")
    if (!rcols || rcols.length === 0) {
      await query("ALTER TABLE community_sections ADD COLUMN comment_review_required TINYINT DEFAULT 0")
      console.log('[Community] Added comment_review_required column to community_sections')
    }
    const sdcols = await query("SHOW COLUMNS FROM community_sections LIKE 'is_deleted'")
    if (!sdcols || sdcols.length === 0) {
      await query("ALTER TABLE community_sections ADD COLUMN is_deleted TINYINT DEFAULT 0")
      console.log('[Community] Added is_deleted column to community_sections')
    }
    const ccols = await query("SHOW COLUMNS FROM community_comments LIKE 'is_deleted'")
    if (!ccols || ccols.length === 0) {
      await query("ALTER TABLE community_comments ADD COLUMN is_deleted TINYINT DEFAULT 0")
      console.log('[Community] Added is_deleted column to community_comments')
    }
    const bacols = await query("SHOW COLUMNS FROM community_banned_users LIKE 'is_active'")
    if (!bacols || bacols.length === 0) {
      await query("ALTER TABLE community_banned_users ADD COLUMN is_active TINYINT DEFAULT 1")
      console.log('[Community] Added is_active column to community_banned_users')
    }
  } catch (e) { console.error('[Community] Migration error:', e.message) }
})()

async function getModeratorEmails(sectionId) {
  try {
    const mods = await query('SELECT u.email FROM community_moderators cm JOIN users u ON cm.user_id=u.id WHERE cm.section_id=? AND u.email IS NOT NULL AND u.email != \'\'', [sectionId])
    return mods.map(m => m.email)
  } catch { return [] }
}

async function getUserEmail(userId) {
  try {
    const rows = await query('SELECT email FROM users WHERE id=?', [userId])
    return rows.length > 0 ? rows[0].email : ''
  } catch { return '' }
}

async function createMentionNotifications(content, fromUserId, fromUserName, fromUserAvatar, refType, refId) {
  if (!content || !fromUserId) return
  const mentionRegex = /@(\S{1,30})/g
  const mentioned = new Set()
  let match
  while ((match = mentionRegex.exec(content)) !== null) {
    const name = match[1].replace(/[，。！？、；：""''）】》\s]+$/, '')
    if (name && name.length >= 2 && name.length <= 20) mentioned.add(name)
  }
  if (mentioned.size === 0) return
  for (const name of mentioned) {
    try {
      const users = await query('SELECT id, nickname, username FROM users WHERE username=? OR nickname=?', [name, name])
      if (users.length === 0) continue
      const target = users[0]
      if (target.id === fromUserId) continue
      const title = refType === 'post' ? '在帖子中@了你' : '在评论中@了你'
      const contentPreview = content.length > 80 ? content.substring(0, 80) + '...' : content
      const targetUrl = refType === 'post' ? `/community/post/${refId}` : `/community/post/${refId}`
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'mention', ?, ?, ?, ?, ?)`,
        [title, `${fromUserName}: ${contentPreview}`, targetUrl, target.id, fromUserId, fromUserName, fromUserAvatar || '']
      )
    } catch (e) { console.error('[community] mention notify failed:', e.message) }
  }
}

async function getAdminUserName(req) {
  try {
    const raw = req.headers.authorization || req.headers.token || req.query.token || ''
    const token = raw.replace(/^Bearer\s+/i, '')
    const session = sessions.get(token)
    if (session && session.userName) return session.userName
    const rows = await query('SELECT username FROM users WHERE id=(SELECT user_id FROM sessions WHERE token=?)', [token])
    return rows.length > 0 ? rows[0].username : 'unknown'
  } catch (e) { console.error('[community] getAdminUserName failed:', e.message) }
  return 'unknown'
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }

  // 后端重启后内存 session 丢失，从数据库恢复
  try {
    const rows = await query('SELECT user_id, user_name, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt })
      return Number(row.user_id) || 0
    }
  } catch {}

  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function isAdminOrModerator(req) {
  const userId = await getUserId(req)
  if (!userId) return false
  if (await isAdminById(userId)) return true
  const modSections = await getModeratorSectionIds(userId)
  return modSections && modSections.length > 0
}

let _adminCache = new Map()
let _adminCacheTime = 0
const ADMIN_CACHE_TTL = 60000

async function isAdminById(userId) {
  if (!userId) return false
  if (Date.now() - _adminCacheTime < ADMIN_CACHE_TTL) {
    const cached = _adminCache.get(userId)
    if (cached !== undefined) return cached
  } else {
    _adminCache = new Map()
    _adminCacheTime = Date.now()
  }
  try {
    const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
    let result = false
    if (rows && rows.length > 0) {
      try {
        const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
        result = roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      } catch {}
    }
    _adminCache.set(userId, result)
    return result
  } catch {}
  return false
}

async function canAccessSection(userId, sectionId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
    return rows.length > 0
  } catch { return false }
}

async function initTrustLevel(userId) {
  try {
    await query(
      'INSERT IGNORE INTO community_trust_levels (user_id, level, post_count, comment_count, like_received, report_count, ban_count, score) VALUES (?, 0, 0, 0, 0, 0, 0, 0)',
      [userId]
    )
  } catch {}
}

function calcTrustScore(postCount, commentCount, likeReceived, reportCount, banCount) {
  return (postCount || 0) * 2 + (commentCount || 0) * 1 + (likeReceived || 0) * 3 - (reportCount || 0) * 5 - (banCount || 0) * 10
}

function getTrustLevelByScore(score) {
  if (score >= 200) return 3
  if (score >= 50) return 2
  if (score >= 10) return 1
  return 0
}

async function incrementPostCount(userId) {
  try {
    await initTrustLevel(userId)
    await query('UPDATE community_trust_levels SET post_count = post_count + 1 WHERE user_id=?', [userId])
  } catch {}
}

async function incrementCommentCount(userId) {
  try {
    await initTrustLevel(userId)
    await query('UPDATE community_trust_levels SET comment_count = comment_count + 1 WHERE user_id=?', [userId])
  } catch {}
}

async function incrementLikeReceived(postId) {
  try {
    const post = await query('SELECT user_id FROM community_posts WHERE id=?', [postId])
    if (post.length > 0) {
      const authorId = post[0].user_id
      await initTrustLevel(authorId)
      await query('UPDATE community_trust_levels SET like_received = like_received + 1 WHERE user_id=?', [authorId])
    }
  } catch {}
}

async function getAutoBanSettings() {
  try {
    const rows = await query('SELECT setting_key, setting_value FROM community_settings WHERE setting_key IN (?,?)', ['auto_ban_threshold', 'auto_ban_duration_hours'])
    const cfg = { threshold: 3, durationHours: 24 }
    for (const r of rows) {
      const v = Number(r.setting_value)
      if (r.setting_key === 'auto_ban_threshold' && v > 0) cfg.threshold = v
      if (r.setting_key === 'auto_ban_duration_hours' && v > 0) cfg.durationHours = v
    }
    return cfg
  } catch { return { threshold: 3, durationHours: 24 } }
}

async function checkAutoBan(targetUserId) {
  try {
    const cfg = await getAutoBanSettings()
    const pendingCount = await query(
      "SELECT COUNT(*) as cnt FROM community_reports WHERE target_id IN (SELECT id FROM community_posts WHERE user_id=?) AND target_type='post' AND status='pending'",
      [targetUserId]
    )
    const pendingCommentCount = await query(
      "SELECT COUNT(*) as cnt FROM community_reports WHERE target_id IN (SELECT id FROM community_comments WHERE user_id=? AND is_deleted=0) AND target_type='comment' AND status='pending'",
      [targetUserId]
    )
    const totalPending = (pendingCount.length > 0 ? pendingCount[0].cnt : 0) + (pendingCommentCount.length > 0 ? pendingCommentCount[0].cnt : 0)

    if (totalPending >= cfg.threshold) {
      const banUntil = new Date(Date.now() + cfg.durationHours * 3600000)
      await query(
        'INSERT INTO community_moderator_bans (section_id, user_id, banned_user_id, banned_user_name, reason, ban_until, is_active) VALUES (?,?,?,?,?,?,?)',
        [0, 0, targetUserId, '', '系统自动封禁：累计被举报' + totalPending + '次', banUntil, 1]
      )
      await query(
        'INSERT INTO community_auto_bans (user_id, report_count, banned_until) VALUES (?,?,?)',
        [targetUserId, totalPending, banUntil]
      )
      executePenalty(targetUserId, '', 'auto_banned', {})
      try {
        const targetUser = await query('SELECT username FROM users WHERE id=?', [targetUserId])
        const targetName = targetUser.length > 0 ? targetUser[0].username : ''
        await query(
          "INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)",
          ['您已被系统自动封禁', `由于累计被举报${totalPending}次，您的发言权限已被自动限制${cfg.durationHours}小时`, 'user_banned', targetUserId, 0, '系统']
        )
      } catch {}
    }
  } catch {}
}

async function savePostRevision(postId, editorId, title, content, tags, editSummary) {
  try {
    const latest = await query(
      'SELECT COALESCE(MAX(version), 0) as maxVer FROM community_post_revisions WHERE post_id=?',
      [postId]
    )
    const nextVer = (latest.length > 0 ? latest[0].maxVer : 0) + 1
    await query(
      'INSERT INTO community_post_revisions (post_id, editor_id, title, content, tags, edit_summary, version) VALUES (?,?,?,?,?,?,?)',
      [postId, editorId, title || '', content || '', tags || '[]', editSummary || '', nextVer]
    )
  } catch {}
}


// ==================== Moderator helper functions ====================

async function getModeratorRoles() {
  try {
    const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
    return rows.map(r => r.role_name)
  } catch { return ['版主', '审核员'] }
}

async function getModeratorRoleCodes() {
  try {
    const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
    return rows
  } catch { return [{ role_name: '版主', role_code: 'R_MODERATOR' }, { role_name: '审核员', role_code: 'R_REVIEWER' }] }
}

async function getAvailableRoles(userRoles) {
  const allRoles = await getModeratorRoles()
  if (userRoles.some(r => r === 'R_SUPER')) return allRoles
  const roleCodes = await getModeratorRoleCodes()
  const adminAllowed = roleCodes.filter(rc => rc.role_code !== 'R_SUPER').map(rc => rc.role_name)
  if (userRoles.some(r => r === 'R_ADMIN')) return adminAllowed
  return []
}

async function getHighestRoleIndex(roles, allRoles) {
  let idx = -1
  for (const r of roles) {
    const i = allRoles.indexOf(r)
    if (i > idx) idx = i
  }
  return idx
}

async function isModeratorOfSection(userId, sectionId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
    return rows.length > 0
  } catch { return false }
}

async function isModeratorOfPost(userId, postId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query(
      'SELECT cm.id FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
      [postId, userId]
    )
    return rows.length > 0
  } catch { return false }
}

async function getModeratorSectionIds(userId) {
  try {
    const rows = await query('SELECT section_id FROM community_moderators WHERE user_id=? ORDER BY section_id', [userId])
    return rows.map(r => r.section_id)
  } catch { return [] }
}

const REVIEWER_ONLY_ROLES = ['审核员']

async function getModeratorRoleForPost(userId, postId) {
  try {
    const rows = await query(
      'SELECT cm.role FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
      [postId, userId]
    )
    return rows.length > 0 ? rows[0].role : null
  } catch { return null }
}

async function canReviewModAction(userId, postId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  const role = await getModeratorRoleForPost(userId, postId)
  return !!role
}

async function canManageModAction(userId, postId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  const role = await getModeratorRoleForPost(userId, postId)
  return role && !REVIEWER_ONLY_ROLES.includes(role)
}

async function logModeratorAction(sectionId, userId, userName, action, targetType, targetId, detail) {
  try {
    await query(
      'INSERT INTO community_moderator_logs (section_id, moderator_id, moderator_name, action, target_type, target_id, detail) VALUES (?,?,?,?,?,?,?)',
      [sectionId || 0, userId, userName || '', action, targetType || '', targetId || 0, detail || '']
    )
  } catch {}
}

function cleanupPostContentImages(contentStr, postId) {
  if (!contentStr) return
  try {
    const blocks = JSON.parse(contentStr)
    if (!Array.isArray(blocks)) return
    const urls = []
    for (const block of blocks) {
      if (block.type === 'image' && Array.isArray(block.images)) {
        for (const img of block.images) {
          if (typeof img === 'string' && img.startsWith('http')) urls.push(img)
        }
      }
    }
    if (!urls.length) return
    const { getDefaultStorage } = require('../storage-config.cjs')
    const { deleteFromCloud } = require('../upload.cjs')
    const { updateUserUsedBytes } = require('../utils/file-helper.cjs')
    getDefaultStorage({ userId: 0, roles: [], levelId: 0, backend: false }).then(storage => {
      if (!storage) return
      for (const url of urls) {
        try {
          const key = new URL(url).pathname.replace(/^\//, '')
          deleteFromCloud(storage, key).catch(() => {})
        } catch (e) { console.error('Cleanup error:', e.message) }
      }
    }).catch(() => {})
    for (const url of urls) {
      query('SELECT user_id FROM file_repository WHERE file_path=?', [url]).then(rows => {
        if (rows.length) {
          const uid = rows[0].user_id
          query('DELETE FROM file_repository WHERE file_path=?', [url]).then(() => {
            if (uid) updateUserUsedBytes(uid)
          }).catch(() => {})
        }
      }).catch(() => {})
    }
    console.log('[community] Cleanup ' + urls.length + ' images from post #' + postId)
  } catch {}
}

async function checkSensitiveWords(text) {
  if (!text) return { blocked: false, level: 'pass', words: [] }
  try {
    const words = await query('SELECT word, replacement, level FROM community_sensitive_words WHERE status=1')
    const matches = []
    let maxLevel = 'pass'
    for (const w of words) {
      if (text.includes(w.word)) {
        matches.push({ word: w.word, replacement: w.replacement || '', level: w.level || 'block' })
        if (w.level === 'block') maxLevel = 'block'
        else if (w.level === 'review' && maxLevel !== 'block') maxLevel = 'review'
        else if (w.level === 'warn' && maxLevel === 'pass') maxLevel = 'warn'
      }
    }
    if (maxLevel === 'pass') return { blocked: false, level: 'pass', words: [] }
    return { blocked: maxLevel === 'block', level: maxLevel, words: matches }
  } catch {}
  return { blocked: false, level: 'pass', words: [] }
}

module.exports = {
  query, getSystemOperator, sessions, SESSION_TTL, nowExpr,
  progressTasksByAction, systemLog, sanitizeCommunityContent,
  emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS,
  deleteFileRecordsByRef, deleteFileRecordsByIds,
  sendNotificationEmail, getAdminEmails,
  multer, path, communityUploadDir, communityImageUpload,
  getModeratorEmails, getUserEmail, createMentionNotifications,
  getAdminUserName, getUserId, getUserRoles,
  isAdmin, isAdminOrModerator, isAdminById, canAccessSection,
  initTrustLevel, calcTrustScore, getTrustLevelByScore,
  incrementPostCount, incrementCommentCount, incrementLikeReceived,
  getAutoBanSettings, checkAutoBan, savePostRevision,
  getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex,
  isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds,
  REVIEWER_ONLY_ROLES, getModeratorRoleForPost,
  canReviewModAction, canManageModAction, logModeratorAction,
  cleanupPostContentImages, checkSensitiveWords
}
