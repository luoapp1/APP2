'use strict';
const { query, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community-utils.cjs');
module.exports = function(app) {
  // ==================== Moderator Center APIs ====================

  app.get('/api/community/moderator/stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const admin = await isAdminById(userId)
      let sectionIds = []
      if (!admin) {
        sectionIds = await getModeratorSectionIds(userId)
        if (!sectionIds.length) return res.json({ code: 403, msg: '您不是任何板块的版主' })
      }
      const sectionCondition = admin ? '' : `AND section_id IN (${sectionIds.join(',')})`
      const [pendingPosts] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE status='pending' AND is_deleted=0 ${sectionCondition}`)
      const [pendingComments] = await query(`SELECT COUNT(*) as cnt FROM community_comments WHERE status='pending' AND is_deleted=0 ${sectionCondition}`)
      const [todayActions] = await query(`SELECT COUNT(*) as cnt FROM community_moderator_logs WHERE DATE(create_time)=CURDATE() ${sectionCondition.replace(/section_id/g, 'l.section_id').replace(/l\./g, '')}`)
      res.json({ code: 200, msg: 'success', data: {
        pendingPosts: pendingPosts.cnt || 0,
        pendingComments: pendingComments.cnt || 0,
        todayActions: todayActions.cnt || 0
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/moderator/logs', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const admin = await isAdminById(userId)
      let sectionIds = []
      if (!admin) {
        sectionIds = await getModeratorSectionIds(userId)
        if (!sectionIds.length) return res.json({ code: 403, msg: '您不是任何板块的版主' })
      }
      const page = Math.max(Number(req.query.page) || 1, 1)
      const pageSize = Math.min(Math.max(Number(req.query.pageSize) || 20, 1), 100)
      const offset = (page - 1) * pageSize
      const sectionCondition = admin ? '' : `AND l.section_id IN (${sectionIds.join(',')})`
      const logs = await query(
        `SELECT l.id, l.section_id as sectionId, COALESCE(NULLIF(s.name,''), '全域') as sectionName, l.moderator_id as moderatorId,
                l.moderator_name as moderatorName, l.action, l.target_type as targetType, l.target_id as targetId, l.detail, l.create_time as createTime
         FROM community_moderator_logs l LEFT JOIN community_sections s ON l.section_id=s.id
         WHERE 1=1 ${sectionCondition} ORDER BY l.create_time DESC LIMIT ${pageSize} OFFSET ${offset}`
      )
      const [countResult] = await query(
        `SELECT COUNT(*) as total FROM community_moderator_logs l WHERE 1=1 ${sectionCondition}`
      )
      res.json({ code: 200, msg: 'success', data: logs, total: countResult.total || 0, page, pageSize })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/moderator/my-sections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sections = await query(
        `SELECT s.id, s.name, s.description, s.icon, s.icon_bg_color as iconBgColor, s.review_required as reviewRequired,
                s.sort_order as sortOrder, m.role, m.sort_order as modSortOrder,
                (SELECT COUNT(*) FROM community_posts p WHERE p.section_id=s.id AND p.status='published' AND p.is_deleted=0) as postCount,
                (SELECT COUNT(*) FROM community_moderators cm WHERE cm.section_id=s.id) as moderatorCount
         FROM community_moderators m JOIN community_sections s ON m.section_id=s.id
         WHERE m.user_id=? AND s.is_deleted=0 ORDER BY m.sort_order ASC, s.sort_order ASC`,
        [userId]
      )
      res.json({ code: 200, msg: 'success', data: sections })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Batch Operations ====================

  app.post('/api/community/moderator/posts/batch-approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择要审核的帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      let approved = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, user_id, title FROM community_posts WHERE id=? AND status=?', [postId, 'pending'])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET status=?, update_time=NOW() WHERE id=?', ['published', postId])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post[0].section_id])
        await logModeratorAction(post[0].section_id, userId, userName, 'batch_approve', 'post', postId, `批量审核通过帖子「${post[0].title}」`)
        emitSafe(POST_EVENTS.APPROVED, { postId, sectionId: post[0].section_id, userId: post[0].user_id })
        approved++
      }
      res.json({ code: 200, msg: `已审核通过 ${approved} 个帖子`, data: { approved } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, reason } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择要驳回的帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      let rejected = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, user_id, title FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET status=?, review_reason=?, update_time=NOW() WHERE id=?', ['rejected', reason || '', postId])
        await logModeratorAction(post[0].section_id, userId, userName, 'batch_reject', 'post', postId, `批量驳回帖子「${post[0].title}」: ${reason || ''}`)
        emitSafe(POST_EVENTS.REJECTED, { postId, sectionId: post[0].section_id, userId: post[0].user_id })
        rejected++
      }
      res.json({ code: 200, msg: `已驳回 ${rejected} 个帖子`, data: { rejected } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, reason } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择要删除的帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      let deleted = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, user_id, title, content FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET is_deleted=1, update_time=NOW() WHERE id=?', [postId])
        await logModeratorAction(post[0].section_id, userId, userName, 'batch_delete', 'post', postId, `批量删除帖子「${post[0].title}」: ${reason || ''}`)
        emitSafe(POST_EVENTS.DELETED, { postId, sectionId: post[0].section_id, userId: post[0].user_id })
        deleted++
      }
      res.json({ code: 200, msg: `已删除 ${deleted} 个帖子`, data: { deleted } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, targetSectionId } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择要移动的帖子' })
      if (!targetSectionId) return res.json({ code: 400, msg: '请选择目标板块' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      const targetMod = await isModeratorOfSection(userId, targetSectionId)
      if (!targetMod && !(await isAdminById(userId))) return res.json({ code: 403, msg: '您不是目标板块的版主' })
      let moved = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, user_id, title FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_sections SET post_count = GREATEST(post_count - 1, 0) WHERE id=? AND is_deleted=0', [post[0].section_id])
        await query('UPDATE community_posts SET section_id=?, update_time=NOW() WHERE id=?', [targetSectionId, postId])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [targetSectionId])
        await logModeratorAction(post[0].section_id, userId, userName, 'batch_move', 'post', postId, `批量移动帖子「${post[0].title}」到板块${targetSectionId}`)
        emitSafe(POST_EVENTS.MOVED, { postId, fromSectionId: post[0].section_id, toSectionId: targetSectionId, userId: post[0].user_id })
        moved++
      }
      res.json({ code: 200, msg: `已移动 ${moved} 个帖子`, data: { moved } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, isEssence } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      const target = isEssence !== false ? 1 : 0
      const action = target ? 'set_essence' : 'remove_essence'
      let count = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET is_essence=?, update_time=NOW() WHERE id=?', [target, postId])
        await logModeratorAction(post[0].section_id, userId, userName, action, 'post', postId, `批量${target ? '加精' : '取消加精'}帖子「${post[0].title}」`)
        count++
      }
      res.json({ code: 200, msg: 'success', data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, isPinned } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      const target = isPinned !== false ? 1 : 0
      const action = target ? 'pin' : 'unpin'
      let count = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET is_pinned=?, update_time=NOW() WHERE id=?', [target, postId])
        await logModeratorAction(post[0].section_id, userId, userName, action, 'post', postId, `批量${target ? '置顶' : '取消置顶'}帖子「${post[0].title}」`)
        count++
      }
      res.json({ code: 200, msg: 'success', data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, isLocked } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      const target = isLocked !== false ? 1 : 0
      const action = target ? 'lock' : 'unlock'
      let count = 0
      for (const postId of ids) {
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=?', [postId])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_posts SET is_locked=?, update_time=NOW() WHERE id=?', [target, postId])
        await logModeratorAction(post[0].section_id, userId, userName, action, 'post', postId, `批量${target ? '锁定' : '解锁'}帖子「${post[0].title}」`)
        count++
      }
      res.json({ code: 200, msg: 'success', data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Comment Moderation ====================

  app.post('/api/community/moderator/comments/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids, reason } = req.body
      if (!ids || !ids.length) return res.json({ code: 400, msg: '请选择要删除的评论' })
      const userName = await getAdminUserName(req)
      const sectionIds = await getModeratorSectionIds(userId)
      if (!sectionIds.length && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权限' })
      let deleted = 0
      for (const commentId of ids) {
        const comment = await query('SELECT id, post_id, user_id, content FROM community_comments WHERE id=?', [commentId])
        if (!comment.length) continue
        const post = await query('SELECT section_id FROM community_posts WHERE id=?', [comment[0].post_id])
        if (!post.length) continue
        if (!(await isAdminById(userId)) && !sectionIds.includes(post[0].section_id)) continue
        await query('UPDATE community_comments SET is_deleted=1 WHERE id=?', [commentId])
        await logModeratorAction(post[0].section_id, userId, userName, 'batch_delete_comment', 'comment', commentId, `批量删除评论: ${reason || ''}`)
        deleted++
      }
      res.json({ code: 200, msg: `已删除 ${deleted} 条评论`, data: { deleted } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/community/moderator/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const comment = await query('SELECT id, post_id, user_id, content FROM community_comments WHERE id=?', [req.params.id])
      if (!comment.length) return res.json({ code: 404, msg: '评论不存在' })
      const post = await query('SELECT section_id FROM community_posts WHERE id=?', [comment[0].post_id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, post[0].section_id))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      await query('UPDATE community_comments SET is_deleted=1 WHERE id=?', [req.params.id])
      const userName = await getAdminUserName(req)
      await logModeratorAction(post[0].section_id, userId, userName, 'delete_comment', 'comment', req.params.id, '删除评论')
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Post Management ====================

  app.post('/api/community/moderator/post/:id/move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { targetSectionId } = req.body
      if (!targetSectionId) return res.json({ code: 400, msg: '请选择目标板块' })
      const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, post[0].section_id))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, targetSectionId))) {
        return res.json({ code: 403, msg: '您不是目标板块的版主' })
      }
      await query('UPDATE community_sections SET post_count = GREATEST(post_count - 1, 0) WHERE id=? AND is_deleted=0', [post[0].section_id])
      await query('UPDATE community_posts SET section_id=?, update_time=NOW() WHERE id=?', [targetSectionId, req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [targetSectionId])
      const userName = await getAdminUserName(req)
      await logModeratorAction(post[0].section_id, userId, userName, 'move_post', 'post', req.params.id, `移动帖子「${post[0].title}」到板块${targetSectionId}`)
      res.json({ code: 200, msg: '移动成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/post/:id/edit', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { title, content, tags, editSummary } = req.body
      const post = await query('SELECT id, section_id, user_id, title as oldTitle, content as oldContent FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, post[0].section_id))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      const newTitle = title || post[0].oldTitle
      const newContent = content || post[0].oldContent
      const safeTitle = sanitizeCommunityContent(newTitle)
      const safeContent = sanitizeCommunityContent(newContent)
      await query('UPDATE community_posts SET title=?, content=?, tags=?, update_time=NOW() WHERE id=?',
        [safeTitle, safeContent, tags || '[]', req.params.id])
      await savePostRevision(req.params.id, userId, safeTitle, safeContent, tags || '[]', editSummary || '')
      const userName = await getAdminUserName(req)
      await logModeratorAction(post[0].section_id, userId, userName, 'edit_post', 'post', req.params.id, `编辑帖子「${newTitle}」`)
      emitSafe(POST_EVENTS.UPDATED, { postId: req.params.id, sectionId: post[0].section_id, userId: post[0].user_id })
      res.json({ code: 200, msg: '编辑成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== User Ban / Blacklist ====================

  app.post('/api/community/moderator/section/:sectionId/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { userId: targetUserId, reason, duration } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })
      const sectionId = Number(req.params.sectionId) || 0
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, sectionId))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      let banUntil = null
      if (duration) {
        const hours = Number(duration)
        banUntil = `DATE_ADD(NOW(), INTERVAL ${hours} HOUR)`
      }
      const targetInfo = await query('SELECT nickname FROM users WHERE id=?', [targetUserId])
      const targetName = targetInfo[0]?.nickname || ''
      const existing = await query('SELECT id FROM community_moderator_bans WHERE section_id=? AND banned_user_id=? AND is_active=1',
        [sectionId, targetUserId])
      if (existing.length > 0) {
        if (banUntil) {
          await query(`UPDATE community_moderator_bans SET reason=?, ban_until=${banUntil} WHERE section_id=? AND banned_user_id=?`,
            [reason || '', sectionId, targetUserId])
        } else {
          await query('UPDATE community_moderator_bans SET reason=?, ban_until=NULL WHERE section_id=? AND banned_user_id=?',
            [reason || '', sectionId, targetUserId])
        }
      } else {
        const sql = banUntil
          ? `INSERT INTO community_moderator_bans (section_id, user_id, banned_user_id, banned_user_name, reason, ban_until, is_active) VALUES (?,?,?,?,?,${banUntil},1)`
          : 'INSERT INTO community_moderator_bans (section_id, user_id, banned_user_id, banned_user_name, reason, ban_until, is_active) VALUES (?,?,?,?,?,NULL,1)'
        await query(sql, [sectionId, userId, targetUserId, targetName, reason || ''])
      }
      const userName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, userName, 'ban_user', 'user', targetUserId, `封禁用户${targetName}: ${reason || ''}`)
      res.json({ code: 200, msg: '封禁成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/community/moderator/section/:sectionId/ban/:bannedUserId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId) || 0
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, sectionId))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      await query('UPDATE community_moderator_bans SET is_active=0 WHERE section_id=? AND banned_user_id=?',
        [sectionId, req.params.bannedUserId])
      const userName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, userName, 'unban_user', 'user', req.params.bannedUserId, '解除封禁')
      res.json({ code: 200, msg: '已解除封禁' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/moderator/section/:sectionId/bans', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId) || 0
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, sectionId))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      const bans = await query(
        `SELECT id, section_id as sectionId, user_id as moderatorId, banned_user_id as bannedUserId, banned_user_name as bannedUserName,
                reason, ban_until as banUntil, is_active as isActive, create_time as createTime
         FROM community_moderator_bans WHERE section_id=? ORDER BY create_time DESC`,
        [sectionId]
      )
      res.json({ code: 200, msg: 'success', data: bans })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/resign/:sectionId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId) || 0
      const mod = await query('SELECT id, role FROM community_moderators WHERE section_id=? AND user_id=?',
        [sectionId, userId])
      if (!mod.length) return res.json({ code: 404, msg: '您不是该板块的版主' })
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
      const userName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, userName, 'resign', 'section', sectionId, `辞去版主职务`)
      res.json({ code: 200, msg: '您已辞去版主职务' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Report Category ====================

  app.get('/api/community/report-categories', async (_req, res) => {
    try {
      const categories = [
        { id: 1, name: '垃圾广告', icon: '' },
        { id: 2, name: '色情低俗', icon: '' },
        { id: 3, name: '不友善言论', icon: '' },
        { id: 4, name: '违法违规', icon: '' },
        { id: 5, name: '抄袭/侵权', icon: '' },
        { id: 6, name: '灌水/无意义内容', icon: '' },
        { id: 7, name: '骚扰/骚扰信息', icon: '' },
        { id: 8, name: '虚假信息', icon: '' },
        { id: 9, name: '其他', icon: '' }
      ]
      res.json({ code: 200, msg: 'success', data: categories })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Enhanced Stats ====================

  app.get('/api/community/moderator/enhanced-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const admin = await isAdminById(userId)
      let sectionIds = []
      if (!admin) {
        sectionIds = await getModeratorSectionIds(userId)
        if (!sectionIds.length) return res.json({ code: 403, msg: '您不是任何板块的版主' })
      }
      const sectionCondition = admin ? '' : `AND section_id IN (${sectionIds.join(',')})`
      const today = new Date().toISOString().split('T')[0]
      const [totalPosts] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0 ${sectionCondition}`)
      const [todayPosts] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0 AND DATE(create_time)=? ${sectionCondition}`, [today])
      const [totalComments] = await query(`SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0`)
      const [todayComments] = await query(`SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0 AND DATE(create_time)=?`, [today])
      const [totalLikes] = await query(`SELECT COUNT(*) as cnt FROM community_likes`)
      const [todayLikes] = await query(`SELECT COUNT(*) as cnt FROM community_likes WHERE DATE(create_time)=?`, [today])
      const [pendingReports] = await query(`SELECT COUNT(*) as cnt FROM community_reports WHERE status='pending'`)
      const banCondition = sectionIds.length && !admin ? `AND section_id IN (${sectionIds.join(',')})` : ''
      const [activeBans] = await query(`SELECT COUNT(*) as cnt FROM community_moderator_bans WHERE is_active=1 AND (ban_until IS NULL OR ban_until > NOW()) ${banCondition}`)
      res.json({ code: 200, msg: 'success', data: {
        totalPosts: totalPosts.cnt || 0,
        todayPosts: todayPosts.cnt || 0,
        totalComments: totalComments.cnt || 0,
        todayComments: todayComments.cnt || 0,
        totalLikes: totalLikes.cnt || 0,
        todayLikes: todayLikes.cnt || 0,
        pendingReports: pendingReports.cnt || 0,
        activeBans: activeBans.cnt || 0
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Collection Moderation ====================

  app.post('/api/community/moderator/collection/:id/remove', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const collection = await query('SELECT id, title, section_id FROM community_collections WHERE id=?', [req.params.id])
      if (!collection.length) return res.json({ code: 404, msg: '专题不存在' })
      if (!(await isAdminById(userId)) && !(await isModeratorOfSection(userId, collection[0].section_id))) {
        return res.json({ code: 403, msg: '无权限' })
      }
      await query('UPDATE community_collections SET is_deleted=1 WHERE id=?', [req.params.id])
      const userName = await getAdminUserName(req)
      await logModeratorAction(collection[0].section_id, userId, userName, 'remove_collection', 'collection', req.params.id, `删除专题「${collection[0].title}」`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
};
