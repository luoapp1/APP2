'use strict';
const { query, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community-utils.cjs');
module.exports = function(app) {
  app.post('/api/community/admin/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(userId))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { userId: targetUserId, reason, duration } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      let bannedUntilHours = null
      if (duration) {
        bannedUntilHours = Number(duration)
        if (!Number.isFinite(bannedUntilHours) || bannedUntilHours <= 0) {
          return res.json({ code: 400, msg: '封禁时长无效' })
        }
      }

      const userInfo = await query('SELECT nickname FROM users WHERE id=?', [targetUserId])
      const userName = userInfo[0]?.nickname || ''

      const existing = await query('SELECT id FROM community_banned_users WHERE user_id=?', [targetUserId])
      if (existing.length > 0) {
        if (bannedUntilHours) {
          await query('UPDATE community_banned_users SET reason=?, banned_until=DATE_ADD(NOW(), INTERVAL ? HOUR), is_active=1 WHERE user_id=?',
            [reason || '', bannedUntilHours, targetUserId])
        } else {
          await query('UPDATE community_banned_users SET reason=?, banned_until=NULL, is_active=1 WHERE user_id=?',
            [reason || '', targetUserId])
        }
      } else {
        if (bannedUntilHours) {
          await query('INSERT INTO community_banned_users (user_id, user_name, reason, banned_until) VALUES (?,?,?,DATE_ADD(NOW(), INTERVAL ? HOUR))',
            [targetUserId, userName, reason || '', bannedUntilHours])
        } else {
          await query('INSERT INTO community_banned_users (user_id, user_name, reason) VALUES (?,?,?)',
            [targetUserId, userName, reason || ''])
        }
      }

      res.json({ code: 200, msg: '用户已被禁言' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/unban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(userId))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { userId: targetUserId } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      await query('UPDATE community_banned_users SET is_active=0 WHERE user_id=?', [targetUserId])
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/banned', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(userId))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, reason, banned_until as bannedUntil, create_time as createTime
         FROM community_banned_users ORDER BY create_time DESC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== User Search API ====================

  app.get('/api/community/user/search', async (req, res) => {
    try {
      const { keyword } = req.query
      if (!keyword || keyword.length < 1) return res.json({ code: 400, msg: '请输入搜索关键词' })
      const rows = await query(
        `SELECT id, username, nickname, avatar FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 10`,
        [`%${keyword}%`, `%${keyword}%`]
      )
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== User Community Stats ====================

  app.get('/api/community/user/:userId/stats', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })

      const [postCountRow] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [commentCountRow] = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [likeReceivedRow] = await query('SELECT IFNULL(SUM(like_count), 0) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [coinReceivedRow] = await query('SELECT IFNULL(SUM(coin_count), 0) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [favoriteRow] = await query('SELECT COUNT(*) as cnt FROM community_favorites WHERE user_id=?', [userId])
      const [followerRow] = await query('SELECT COUNT(*) as cnt FROM user_follows WHERE following_id=?', [userId])
      const [followingRow] = await query('SELECT COUNT(*) as cnt FROM user_follows WHERE follower_id=?', [userId])

      const moderatorSections = await query(
        `SELECT cm.section_id as sectionId, cs.name as sectionName, cm.role
         FROM community_moderators cm
         JOIN community_sections cs ON cm.section_id=cs.id AND cs.is_deleted=0
         WHERE cm.user_id=?`, [userId]
      )

      res.json({ code: 200, msg: 'success', data: {
        postCount: postCountRow?.cnt || 0,
        commentCount: commentCountRow?.cnt || 0,
        likeReceived: likeReceivedRow?.cnt || 0,
        coinReceived: coinReceivedRow?.cnt || 0,
        collectionCount: favoriteRow?.cnt || 0,
        followerCount: followerRow?.cnt || 0,
        followingCount: followingRow?.cnt || 0,
        moderatorSections,
        trustLevel: 0
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/user/:userId/recent-posts', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      const posts = await query(
        `SELECT id, title, section_id as sectionId, create_time as createTime,
                like_count as likeCount, comment_count as commentCount, view_count as viewCount
         FROM community_posts
         WHERE user_id=? AND status='published' AND is_deleted=0
         ORDER BY create_time DESC LIMIT 5`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: posts })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/user/:userId/recent-comments', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      const comments = await query(
        `SELECT cc.id, cc.content, cc.post_id as postId, cc.create_time as createTime,
                p.title as postTitle
         FROM community_comments cc
         LEFT JOIN community_posts p ON cc.post_id=p.id
         WHERE cc.user_id=? AND cc.status='published' AND cc.is_deleted=0
         ORDER BY cc.create_time DESC LIMIT 5`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: comments })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Report APIs ====================
  app.post('/api/community/post/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      // Store detailed report record
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'post', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      // Also increment the old counter for backward compatibility
      await query('UPDATE community_posts SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const postTitle = await query('SELECT title FROM community_posts WHERE id=?', [Number(req.params.id)])
      const adminEmailsRp = await getAdminEmails()
      for (const adminEmail of adminEmailsRp) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到帖子举报',
          content: `用户 ${user[0]?.username || ''} 举报了帖子《${postTitle[0]?.title || ''}》，原因：${reportReason || '其他'}。`
        })
      }

      // 自动封禁检测
      const targetPost = await query('SELECT user_id FROM community_posts WHERE id=?', [Number(req.params.id)])
      if (targetPost.length > 0) {
        await checkAutoBan(targetPost[0].user_id)
      }

      // 举报自动升级：检查帖子累计举报数
      const postId = Number(req.params.id)
      const [reportCounts] = await query(
        `SELECT target_type, COUNT(*) as cnt FROM community_reports 
         WHERE target_id=? AND target_type='post' AND status='pending'`,
        [postId]
      )
      const pendingReportCount = reportCounts ? reportCounts.cnt : 0
      if (pendingReportCount >= 5) {
        await query('UPDATE community_posts SET status=? WHERE id=?', ['deleted', postId])
        const adminEmailsAu = await getAdminEmails()
        for (const email of adminEmailsAu) {
          sendNotificationEmail('auto_delete', email, {
            username: '管理员', subject: '帖子自动删除通知',
            content: `帖子 ID=${postId} 累计被举报${pendingReportCount}次，已自动删除，请复核。`
          })
        }
      } else if (pendingReportCount >= 3) {
        await query('UPDATE community_posts SET is_hidden=1 WHERE id=?', [postId])
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/comment/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'comment', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      await query('UPDATE community_comments SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const adminEmailsCr = await getAdminEmails()
      for (const adminEmail of adminEmailsCr) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到评论举报',
          content: `用户 ${user[0]?.username || ''} 举报了一条评论，原因：${reportReason || '其他'}。`
        })
      }

      // 自动封禁检测
      const targetComment = await query('SELECT user_id FROM community_comments WHERE id=?', [Number(req.params.id)])
      if (targetComment.length > 0) {
        await checkAutoBan(targetComment[0].user_id)
      }

      // 举报自动升级：检查评论累计举报数
      const commentId = Number(req.params.id)
      const [commentReportCounts] = await query(
        `SELECT COUNT(*) as cnt FROM community_reports 
         WHERE target_id=? AND target_type='comment' AND status='pending'`,
        [commentId]
      )
      if (commentReportCounts && commentReportCounts.cnt >= 3) {
        await query('UPDATE community_comments SET is_hidden=1 WHERE id=?', [commentId])
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let whereClause = "r.status = 'pending'"
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        whereClause += ` AND (r.target_type='post' AND p.section_id IN (${modSectionIds.map(() => '?').join(',')}) OR r.target_type='comment' AND cp.section_id IN (${modSectionIds.map(() => '?').join(',')}))`
        params.push(...modSectionIds, ...modSectionIds)
      }

      const page = Math.max(Number(req.query.page) || 1, 1)
      const pageSize = Math.min(Math.max(Number(req.query.pageSize) || 20, 1), 200)
      const offset = (page - 1) * pageSize

      const [reports, totalResult] = await Promise.all([
        query(
          `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName,
                  r.target_type as targetType, r.target_id as targetId, r.report_reason as reportReason,
                  r.report_detail as reportDetail, r.status, r.create_time as createTime
           FROM community_reports r
           LEFT JOIN community_posts p ON r.target_type='post' AND r.target_id = p.id
           LEFT JOIN community_comments cc ON r.target_type='comment' AND r.target_id = cc.id
           LEFT JOIN community_posts cp ON r.target_type='comment' AND cc.post_id = cp.id
           WHERE ${whereClause} ORDER BY r.create_time DESC LIMIT ? OFFSET ?`,
           [...params, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as total FROM community_reports r
           LEFT JOIN community_posts p ON r.target_type='post' AND r.target_id = p.id
           LEFT JOIN community_comments cc ON r.target_type='comment' AND r.target_id = cc.id
           LEFT JOIN community_posts cp ON r.target_type='comment' AND cc.post_id = cp.id
           WHERE ${whereClause}`,
          params
        )
      ])

      // Enrich with target info
      const enriched = []
      for (const r of reports) {
        const item = { ...r }
        if (r.targetType === 'post') {
          const post = await query('SELECT id, title, user_id as userId, user_name as userName, status FROM community_posts WHERE id=?', [r.targetId])
          if (post.length > 0) {
            item.targetTitle = post[0].title
            item.targetUserId = post[0].userId
            item.targetUserName = post[0].userName
            item.targetStatus = post[0].status
          }
        } else {
          const comment = await query('SELECT id, content, user_id as userId, user_name as userName, post_id as postId FROM community_comments WHERE id=?', [r.targetId])
          if (comment.length > 0) {
            item.targetTitle = (comment[0].content || '').substring(0, 50)
            item.targetUserId = comment[0].userId
            item.targetUserName = comment[0].userName
            item.postId = comment[0].postId
          }
        }
        enriched.push(item)
      }

      res.json({ code: 200, msg: 'success', data: { list: enriched, total: totalResult[0]?.total || 0, page, pageSize } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/report/ignore/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      if (!isAdminUser) {
        const report = await query('SELECT target_type, target_id FROM community_reports WHERE id=?', [Number(req.params.id)])
        if (report.length === 0) return res.json({ code: 404, msg: '举报不存在' })
        const { target_type, target_id } = report[0]
        if (target_type === 'post') {
          if (!(await canReviewModAction(userId, target_id))) return res.json({ code: 403, msg: '无权限' })
        } else if (target_type === 'comment') {
          const comment = await query('SELECT post_id FROM community_comments WHERE id=?', [target_id])
          if (comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
          if (!(await canReviewModAction(userId, comment[0].post_id))) return res.json({ code: 403, msg: '无权限' })
        } else {
          return res.json({ code: 403, msg: '无权限' })
        }
      }
      const operatorName = await getAdminUserName(req)
      await query('UPDATE community_reports SET status=?, handled_by=?, handled_at=NOW(), handle_result=? WHERE id=?', ['ignored', userId, 'ignored', Number(req.params.id)])
      // 通知举报人
      try {
        const report = await query('SELECT reporter_id FROM community_reports WHERE id=?', [Number(req.params.id)])
        if (report.length > 0) {
          const reporter = await query('SELECT username, email FROM users WHERE id=?', [report[0].reporter_id])
          if (reporter.length > 0 && reporter[0].email) {
            sendNotificationEmail('report_result', reporter[0].email, {
              username: reporter[0].username || '',
              subject: '举报处理结果',
              content: '您提交的举报已被管理员审核，处理结果为：不予处理。'
            })
          }
        }
      } catch {}
      res.json({ code: 200, msg: '已忽略' })
    } catch (e) {
      res.serverError(e)
    }
  })
  // ==================== Unlock Request APIs ====================
  app.post('/api/community/post/:id/request-unlock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}

      const post = await query('SELECT id, user_id, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!post[0].is_locked) return res.json({ code: 400, msg: '该帖子未被锁定' })
      if (post[0].user_id !== userId) return res.json({ code: 403, msg: '只有帖子作者可以申请解锁' })

      // Check if already has a pending request
      const existing = await query(
        'SELECT id FROM community_unlock_requests WHERE post_id=? AND user_id=? AND status=?',
        [req.params.id, userId, 'pending']
      )
      if (existing.length > 0) return res.json({ code: 400, msg: '已有待处理的解锁申请' })

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_unlock_requests (post_id, user_id, user_name, reason) VALUES (?,?,?,?)`,
        [Number(req.params.id), userId, user[0]?.username || '', reason || '']
      )
      res.json({ code: 200, msg: '解锁申请已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/unlock-requests', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let whereClause = '1=1'
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        whereClause += ` AND p.section_id IN (${modSectionIds.map(() => '?').join(',')})`
        params.push(...modSectionIds)
      }

      const page = Math.max(Number(req.query.page) || 1, 1)
      const pageSize = Math.min(Math.max(Number(req.query.pageSize) || 20, 1), 200)
      const offset = (page - 1) * pageSize

      const [requests, totalResult] = await Promise.all([
        query(
          `SELECT r.id, r.post_id as postId, r.user_id as userId, r.user_name as userName,
                  r.reason, r.status, r.admin_reply as adminReply, r.create_time as createTime,
                  p.title as postTitle
           FROM community_unlock_requests r
           LEFT JOIN community_posts p ON r.post_id = p.id
           WHERE ${whereClause}
           ORDER BY r.status ASC, r.create_time DESC LIMIT ? OFFSET ?`,
          [...params, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as total FROM community_unlock_requests r
           LEFT JOIN community_posts p ON r.post_id = p.id
           WHERE ${whereClause}`,
          params
        )
      ])
      res.json({ code: 200, msg: 'success', data: { list: requests, total: totalResult[0]?.total || 0, page, pageSize } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/unlock-request/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const ur = await query('SELECT * FROM community_unlock_requests WHERE id=?', [req.params.id])
      if (!ur.length) return res.json({ code: 404, msg: '申请不存在' })
      if (ur[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })
      if (!(await canManageModAction(userId, ur[0].post_id))) return res.json({ code: 403, msg: '无权限' })
      const { action, reply } = req.body || {}

      if (action === 'approve') {
        await query('UPDATE community_posts SET is_locked=0 WHERE id=?', [ur[0].post_id])
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['approved', reply || '', req.params.id])
        const adminNameUr = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请已通过', `您的解锁申请已通过`, 'unlock_resolved', ur[0].user_id, userId, adminNameUr || '管理人员']
        )
        systemLog('unlock_approve', userId, adminNameUr, 'post', ur[0].post_id, `通过解锁申请`)
        res.json({ code: 200, msg: '已通过解锁申请' })
      } else {
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['rejected', reply || '', req.params.id])
        const adminNameUr = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请被拒绝', reply ? `拒绝原因: ${reply}` : '您的解锁申请被拒绝', 'unlock_resolved', ur[0].user_id, userId, adminNameUr || '管理人员']
        )
        res.json({ code: 200, msg: '已拒绝解锁申请' })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/admin/report/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT section_id, user_id, title, content FROM community_posts WHERE id=?', [req.params.id])
        if (post.length) {
        await query("UPDATE community_posts SET status='deleted', update_time=" + nowExpr + " WHERE id=?", [req.params.id])
        await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [post[0].section_id])
        deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})
        cleanupPostContentImages(post[0].content, req.params.id)
        const adminNameRp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被下架', `您的帖子《${post[0].title}》因被举报已被管理员下架`, 'report_resolved', post[0].user_id, userId, adminNameRp || '管理员']
        )
        // 通知所有举报人
        try {
          const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
          for (const r of reporters) {
            const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
            if (ru.length > 0 && ru[0].email) {
              sendNotificationEmail('report_result', ru[0].email, {
                username: ru[0].username || '',
                subject: '举报处理结果',
                content: `您举报的帖子《${post[0].title}》已被管理员下架处理。`
              })
            }
          }
          // 标记相关举报为已处理
          await query("UPDATE community_reports SET status='resolved' WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
        } catch {}
      }
      res.json({ code: 200, msg: '已下架' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/admin/report/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      await query('UPDATE community_comments SET is_deleted=1 WHERE id=?', [req.params.id])
      // 通知所有举报人并标记已处理
      try {
        const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
        for (const r of reporters) {
          const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
          if (ru.length > 0 && ru[0].email) {
            sendNotificationEmail('report_result', ru[0].email, {
              username: ru[0].username || '',
              subject: '举报处理结果',
              content: '您举报的评论已被管理员删除处理。'
            })
          }
        }
        await query("UPDATE community_reports SET status='resolved' WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
      } catch {}
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.serverError(e)
    }
  })
  // ==================== Report Appeal ====================
  app.post('/api/community/report/:id/appeal', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}
      const report = await query('SELECT id, status FROM community_reports WHERE id=? AND reporter_id=?', [req.params.id, userId])
      if (!report.length) return res.json({ code: 404, msg: '举报不存在或不属于您' })
      if (!['ignored', 'resolved'].includes(report[0].status)) return res.json({ code: 400, msg: '该举报不支持申诉' })
      await query('UPDATE community_reports SET status=?, appeal_reason=? WHERE id=?', ['appealed', reason || '', req.params.id])
      res.json({ code: 200, msg: '申诉已提交' })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/moderator/appeals', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const list = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName, r.target_type as targetType,
                r.report_reason as reportReason, r.category, r.appeal_reason as appealReason, r.create_time as createTime
         FROM community_reports r WHERE r.status='appealed' ORDER BY r.create_time DESC LIMIT 50`
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/moderator/appeal/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { action } = req.body || {}
      if (action === 'accept') {
        await query('UPDATE community_reports SET status=? WHERE id=?', ['resolved', req.params.id])
        res.json({ code: 200, msg: '已采纳申诉' })
      } else {
        await query('UPDATE community_reports SET status=? WHERE id=?', ['ignored', req.params.id])
        res.json({ code: 200, msg: '已驳回申诉' })
      }
    } catch (e) { res.serverError(e) }
  })
  // ==================== Tag Management ====================
  app.get('/api/community/tags', async (req, res) => {
    try {
      const { keyword, sort = 'post_count', status, section_id, limit = 50 } = req.query
      let sql = `SELECT id, name, normalized_name as normalizedName, post_count as postCount, section_id as sectionId, status, is_official as isOfficial, create_time as createTime FROM community_tags`
      const conditions = []
      const params = []
      if (keyword) { conditions.push('name LIKE ?'); params.push(`%${keyword}%`) }
      if (status !== undefined) { conditions.push('status=?'); params.push(Number(status)) }
      if (section_id) { conditions.push('section_id=?'); params.push(Number(section_id)) }
      if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ')
      const ALLOWED_SORTS = { name: 'normalized_name ASC', post_count: 'post_count DESC' }
      const orderBy = ALLOWED_SORTS[sort] || ALLOWED_SORTS.post_count
      sql += ' ORDER BY ' + orderBy + ' LIMIT ?'
      params.push(Math.min(Number(limit) || 50, 200))
      const tags = await query(sql, params)
      res.json({ code: 200, data: tags })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/tags', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { id, name, status, isOfficial } = req.body || {}
      if (!name) return res.json({ code: 400, msg: '标签名不能为空' })
      const normalized = name.trim().toLowerCase()
      if (id) {
        await query('UPDATE community_tags SET name=?, normalized_name=?, status=?, is_official=? WHERE id=?',
          [name.trim(), normalized, status ?? 1, isOfficial ?? 0, id])
        res.json({ code: 200, msg: '更新成功' })
      } else {
        await query('INSERT IGNORE INTO community_tags (name, normalized_name, status, is_official) VALUES (?,?,?,?)',
          [name.trim(), normalized, status ?? 1, isOfficial ?? 0])
        res.json({ code: 200, msg: '创建成功' })
      }
      await systemLog(userId, 'manage_tag', 'community', `${id ? '更新' : '创建'}标签「${name}」`, req => ({}))
    } catch (e) { res.serverError(e) }
  })

  app.delete('/api/community/tags/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      await query('DELETE FROM community_tags WHERE id=?', [req.params.id])
      await systemLog(userId, 'delete_tag', 'community', `删除标签ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/tags/merge', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { sourceId, targetId } = req.body || {}
      if (!sourceId || !targetId) return res.json({ code: 400, msg: '请选择源和目标标签' })
      const [source] = await query('SELECT id, name FROM community_tags WHERE id=?', [sourceId])
      const [target] = await query('SELECT id, name FROM community_tags WHERE id=?', [targetId])
      if (!source || !target) return res.json({ code: 404, msg: '标签不存在' })
      await query('UPDATE community_tags SET post_count = post_count + (SELECT post_count FROM (SELECT post_count FROM community_tags WHERE id=?) as t) WHERE id=?', [sourceId, targetId])
      await query('DELETE FROM community_tags WHERE id=?', [sourceId])
      await query(
        `UPDATE community_posts SET tags = JSON_REPLACE(JSON_SET(tags, '$', JSON_ARRAY(?)), '$', JSON_ARRAY(?)) WHERE JSON_CONTAINS(tags, JSON_QUOTE(?))`,
        [target.name, target.name, source.name]
      )
      await systemLog(userId, 'merge_tags', 'community', `合并标签「${source.name}」到「${target.name}」`, req => ({}))
      res.json({ code: 200, msg: '合并成功' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/tags/sync', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const posts = await query(
        `SELECT id, tags FROM community_posts WHERE is_deleted=0 AND tags IS NOT NULL AND tags != '' AND tags != '[]'`
      )
      const tagCounts = {}
      for (const post of posts) {
        try {
          const ts = JSON.parse(post.tags)
          if (Array.isArray(ts)) {
            for (const t of ts) {
              const n = (t && typeof t === 'string' ? t.trim() : '').toLowerCase()
              if (n) tagCounts[n] = (tagCounts[n] || 0) + 1
            }
          }
        } catch {}
      }
      for (const [name, count] of Object.entries(tagCounts)) {
        await query(
          'INSERT INTO community_tags (name, normalized_name, post_count) VALUES (?,?,?) ON DUPLICATE KEY UPDATE post_count=?',
          [name, name.toLowerCase(), count, count]
        )
      }
      await systemLog(userId, 'sync_tags', 'community', `同步标签，共${Object.keys(tagCounts).length}个`, req => ({}))
      res.json({ code: 200, msg: `已同步 ${Object.keys(tagCounts).length} 个标签` })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/tags/cloud', async (req, res) => {
    try {
      const { limit = 50 } = req.query
      const tags = await query(
        `SELECT DISTINCT name, post_count as postCount FROM community_tags WHERE status=1 ORDER BY post_count DESC LIMIT ?`,
        [Math.min(Number(limit) || 50, 100)]
      )
      const maxCount = tags.length > 0 ? tags[0].postCount : 1
      const cloud = tags.map(t => ({ name: t.name, count: t.postCount, weight: Math.max(1, Math.ceil((t.postCount / maxCount) * 5)) }))
      res.json({ code: 200, data: cloud })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/tags/hot', async (req, res) => {
    try {
      const { limit = 20 } = req.query
      const tags = await query(
        `SELECT name, post_count as count FROM community_tags WHERE status=1 ORDER BY post_count DESC LIMIT ?`,
        [Math.min(Number(limit) || 20, 50)]
      )
      res.json({ code: 200, data: tags })
    } catch (e) { res.serverError(e) }
  })

  // ==================== Sensitive Words Management ====================
  app.get('/api/community/sensitive-words', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const words = await query('SELECT id, word, replacement, category, status, create_time as createTime FROM community_sensitive_words ORDER BY id DESC')
      res.json({ code: 200, data: words })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/sensitive-words', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { id, word, replacement, category } = req.body || {}
      if (!word) return res.json({ code: 400, msg: '敏感词不能为空' })
      if (word.length > 100) return res.json({ code: 400, msg: '敏感词不能超过 100 字符' })
      if (id) {
        await query('UPDATE community_sensitive_words SET word=?, replacement=?, category=? WHERE id=?', [word.trim(), replacement || '', category || '', id])
        res.json({ code: 200, msg: '更新成功' })
      } else {
        await query('INSERT INTO community_sensitive_words (word, replacement, category) VALUES (?,?,?)', [word.trim(), replacement || '', category || ''])
        res.json({ code: 200, msg: '添加成功' })
      }
      await systemLog(userId, 'manage_sensitive_word', 'community', `${id ? '更新' : '添加'}敏感词「${word}」`, req => ({}))
    } catch (e) { res.serverError(e) }
  })

  app.delete('/api/community/sensitive-words/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      await query('DELETE FROM community_sensitive_words WHERE id=?', [req.params.id])
      await systemLog(userId, 'delete_sensitive_word', 'community', `删除敏感词ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.serverError(e) }
  })

  // ==================== Community Analytics ====================
  app.get('/api/community/analytics/overview', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const [totalPosts] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0')
      const [totalComments] = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0')
      const [totalSections] = await query('SELECT COUNT(*) as cnt FROM community_sections WHERE is_deleted=0')
      const [todayPosts] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0 AND DATE(create_time)=CURDATE()`)
      const [todayComments] = await query(`SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0 AND DATE(create_time)=CURDATE()`)
      const [pendingCount] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE status='pending' AND is_deleted=0`)
      const [reportCount] = await query(`SELECT COUNT(*) as cnt FROM community_reports WHERE status='pending'`)
      const [todayActiveUsers] = await query(
        `SELECT COUNT(DISTINCT COALESCE(p.user_id, c.user_id)) as cnt
         FROM (SELECT user_id FROM community_posts WHERE DATE(create_time)=CURDATE() AND is_deleted=0 UNION SELECT user_id FROM community_comments WHERE DATE(create_time)=CURDATE() AND is_deleted=0) t
         JOIN community_posts p ON p.user_id=t.user_id JOIN community_comments c ON c.user_id=t.user_id LIMIT 1`,
      )
      const d = await query(
        `SELECT COUNT(DISTINCT user_id) as cnt FROM (
           SELECT user_id FROM community_posts WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
           UNION SELECT user_id FROM community_comments WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
         ) t`
      )
      const weeklyActive = d[0]?.cnt || 0
      const m = await query(
        `SELECT COUNT(DISTINCT user_id) as cnt FROM (
           SELECT user_id FROM community_posts WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           UNION SELECT user_id FROM community_comments WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
         ) t`
      )
      const monthlyActive = m[0]?.cnt || 0
      const [totalCollections] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE status != \'removed\'')
      const [totalBans] = await query('SELECT COUNT(*) as cnt FROM community_moderator_bans WHERE is_active=1')
      const [essenceCount] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE is_essence=1 AND is_deleted=0')

      res.json({ code: 200, data: {
        totalPosts: totalPosts.cnt, totalComments: totalComments.cnt, totalSections: totalSections.cnt,
        todayPosts: todayPosts.cnt, todayComments: todayComments.cnt, pendingCount: pendingCount.cnt,
        reportCount: reportCount.cnt, todayActiveUsers: todayActiveUsers?.cnt || 0,
        weeklyActive, monthlyActive, totalCollections: totalCollections.cnt,
        totalBans: totalBans.cnt, essenceCount: essenceCount.cnt
      }})
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/analytics/trends', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { days = 30 } = req.query
      const limit = Math.min(Number(days) || 30, 90)

      const posts = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM community_posts
         WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      const comments = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM community_comments
         WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      const users = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM users
         WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      res.json({ code: 200, data: { posts, comments, users } })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/analytics/sections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const sections = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor,
                COUNT(p.id) as postCount,
                COALESCE(SUM(p.view_count), 0) as totalViews,
                COALESCE(SUM(p.comment_count), 0) as totalComments,
                COALESCE(SUM(p.like_count), 0) as totalLikes,
                COALESCE(SUM(CASE WHEN p.create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END), 0) as recentPosts,
                COUNT(DISTINCT cm.user_id) as moderatorCount
         FROM community_sections cs
         LEFT JOIN community_posts p ON p.section_id=cs.id AND p.is_deleted=0
         LEFT JOIN community_moderators cm ON cm.section_id=cs.id
         WHERE cs.is_deleted=0
         GROUP BY cs.id ORDER BY postCount DESC`
      )
      res.json({ code: 200, data: sections })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/analytics/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const [totalPaid] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE is_paid=1 AND status != \'removed\'')
      const [totalRevenue] = await query(
        `SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp
         JOIN community_collections cc ON cp.content_id=cc.id WHERE cp.content_type='collection'`
      )
      const top = await query(
        `SELECT cc.id, cc.title, COUNT(cp.id) as subscribeCount, cc.is_paid as isPaid, cc.price_balance as priceBalance
         FROM community_collections cc
         LEFT JOIN content_purchases cp ON cp.content_id=cc.id AND cp.content_type='collection'
         WHERE cc.status != 'removed'
         GROUP BY cc.id ORDER BY subscribeCount DESC LIMIT 20`
      )
      res.json({ code: 200, data: { totalPaid: totalPaid.cnt, totalRevenue: totalRevenue.total, top } })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/analytics/user-ranking', async (req, res) => {
    try {
      const { type = 'posts', limit = 20 } = req.query
      let data = []
      const lim = Math.min(Number(limit) || 20, 100)
      if (type === 'posts') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COUNT(p.id) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0 AND p.status='published'
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      } else if (type === 'likes') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COALESCE(SUM(p.like_count), 0) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      } else if (type === 'coins') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COALESCE(SUM(p.coin_count), 0) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      }
      res.json({ code: 200, data })
    } catch (e) { res.serverError(e) }
  })

  // ==================== Notifications ====================
  app.get('/api/community/notifications/unread-count', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query('SELECT COUNT(*) as cnt FROM sys_notifications WHERE target_user_id=? AND is_read=0', [userId])
      res.json({ code: 200, data: { count: rows[0]?.cnt || 0 } })
    } catch (e) { res.serverError(e) }
  })
  // ==================== Collection Admin ====================
  app.get('/api/community/admin/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { keyword, status } = req.query
      const conditions = []
      const params = []

      if (keyword) {
        conditions.push('(cc.title LIKE ? OR u.username LIKE ? OR u.nickname LIKE ?)')
        params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`)
      }
      if (status) {
        conditions.push('cc.status = ?')
        params.push(status)
      }

      const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : ''

      const list = await query(
        `SELECT cc.id, cc.title, cc.user_id as userId,
                COALESCE(NULLIF(u.nickname,''), u.username) as userName,
                cc.is_paid as isPaid, cc.price_balance as priceBalance,
                cc.status, cc.section_id as sectionId,
                cc.post_count as postCount,
                (SELECT COUNT(*) FROM content_purchases cp WHERE cp.content_id=cc.id AND cp.content_type='collection') as subscribeCount,
                cc.create_time as createTime
         FROM community_collections cc
         LEFT JOIN users u ON cc.user_id = u.id
         ${where}
         ORDER BY cc.create_time DESC`,
        params
      )

      res.json({ code: 200, data: list })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/admin/collection/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { status } = req.body || {}
      if (!['active', 'suspended', 'removed'].includes(status)) return res.json({ code: 400, msg: '无效的状态' })

      const col = await query('SELECT id, name FROM community_collections WHERE id=?', [req.params.id])
      if (!col.length) return res.json({ code: 404, msg: '合集不存在' })

      await query('UPDATE community_collections SET status=? WHERE id=?', [status, req.params.id])

      const operatorName = await getAdminUserName(req)
      systemLog('update_collection_status', userId, operatorName, 'collection', Number(req.params.id),
        `将合集《${col[0].name}》状态更改为${status}`)

      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/admin/collection/:id/feature', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { featured } = req.body || {}
      if (featured === undefined) return res.json({ code: 400, msg: '请指定featured值' })

      try {
        const cols = await query("SHOW COLUMNS FROM community_collections LIKE 'is_featured'")
        if (!cols || cols.length === 0) {
          await query('ALTER TABLE community_collections ADD COLUMN is_featured TINYINT DEFAULT 0')
        }
      } catch (e) { /* column may already exist */ }

      const col = await query('SELECT id, name FROM community_collections WHERE id=?', [req.params.id])
      if (!col.length) return res.json({ code: 404, msg: '合集不存在' })

      await query('UPDATE community_collections SET is_featured=? WHERE id=?', [featured ? 1 : 0, req.params.id])

      const operatorName = await getAdminUserName(req)
      systemLog(featured ? 'feature_collection' : 'unfeature_collection', userId, operatorName, 'collection', Number(req.params.id),
        `${featured ? '推荐' : '取消推荐'}合集《${col[0].name}》`)

      res.json({ code: 200, msg: featured ? '已推荐' : '已取消推荐' })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/community/admin/collection-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const [totalRow] = await query('SELECT COUNT(*) as cnt FROM community_collections')
      const [activeRow] = await query("SELECT COUNT(*) as cnt FROM community_collections WHERE status='active'")
      const [paidRow] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE is_paid=1')
      const [totalRevenueRow] = await query(
        "SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp WHERE cp.content_type='collection'"
      )
      const [todayRevenueRow] = await query(
        "SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp WHERE cp.content_type='collection' AND DATE(cp.create_time)=CURDATE()"
      )

      res.json({ code: 200, data: {
        totalCollections: totalRow.cnt,
        activeCollections: activeRow.cnt,
        paidCollections: paidRow.cnt,
        totalRevenue: totalRevenueRow.total,
        todayRevenue: todayRevenueRow.total
      }})
    } catch (e) { res.serverError(e) }
  })

  // ==================== Image Management ====================
  app.get('/api/community/admin/images', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { page = 1, pageSize = 20, keyword, userId: filterUserId, dateFrom, dateTo } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      const limit = Number(pageSize)

      let where = "WHERE f.category='community_image'"
      const params = []

      if (keyword) {
        where += ' AND f.file_name LIKE ?'
        params.push(`%${keyword}%`)
      }
      if (filterUserId) {
        where += ' AND f.user_id=?'
        params.push(Number(filterUserId))
      }
      if (dateFrom) {
        where += ' AND f.create_time >= ?'
        params.push(dateFrom)
      }
      if (dateTo) {
        where += ' AND f.create_time <= ?'
        params.push(dateTo + ' 23:59:59')
      }

      const countResult = await query(`SELECT COUNT(*) as total FROM file_repository f ${where}`, params)
      const total = countResult[0]?.total || 0

      const images = await query(
        `SELECT f.id, f.file_name, f.file_path AS url, f.file_size, f.user_id,
                u.nickname AS uploader_name, f.create_time, f.ref_type
         FROM file_repository f
         LEFT JOIN users u ON f.user_id = u.id
         ${where}
         ORDER BY f.create_time DESC
         LIMIT ? OFFSET ?`,
        [...params, limit, offset]
      )

      res.json({ code: 200, msg: 'success', data: { list: images, total, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/images/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { ids } = req.body || {}
      if (!ids || !Array.isArray(ids) || !ids.length) return res.json({ code: 400, msg: '缺少图片ID列表' })

      const filteredIds = ids.filter(Number).map(Number)
      await deleteFileRecordsByIds(filteredIds)

      await systemLog(userId, 'batch_delete_images', 'community', `批量删除${filteredIds.length}张社区图片`, req => ({}))
      res.json({ code: 200, msg: '删除成功', data: { count: filteredIds.length } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/image-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const [totalRow, sizeRow, todayRow] = await Promise.all([
        query("SELECT COUNT(*) as cnt FROM file_repository WHERE category='community_image'"),
        query("SELECT COALESCE(SUM(file_size), 0) as total_size FROM file_repository WHERE category='community_image'"),
        query("SELECT COUNT(*) as cnt FROM file_repository WHERE category='community_image' AND DATE(create_time)=CURDATE()")
      ])

      res.json({
        code: 200,
        data: {
          totalImages: totalRow[0]?.cnt || 0,
          totalSize: sizeRow[0]?.total_size || 0,
          todayUploaded: todayRow[0]?.cnt || 0
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Data Export (admin) ====================
  app.get('/api/community/admin/export/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { sectionId, startDate, endDate, status } = req.query
      let sql = `SELECT p.id, p.title, p.user_name as author,
                 (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0) as sectionName,
                 p.status, p.view_count as viewCount, p.like_count as likeCount,
                 p.comment_count as commentCount, p.create_time as createTime
                 FROM community_posts p WHERE 1=1`
      const params = []
      if (sectionId) { sql += ' AND p.section_id=?'; params.push(sectionId) }
      if (startDate) { sql += ' AND p.create_time >= ?'; params.push(startDate) }
      if (endDate) { sql += ' AND p.create_time <= ?'; params.push(endDate + ' 23:59:59') }
      if (status) { sql += ' AND p.status=?'; params.push(status) }
      sql += ' ORDER BY p.id DESC'

      const rows = await query(sql, params)

      const csvHeader = 'ID,标题,作者,板块,状态,浏览,点赞,评论,创建时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.title || '').replace(/"/g, '""')}","${(r.author || '').replace(/"/g, '""')}","${(r.sectionName || '').replace(/"/g, '""')}","${r.status}","${r.viewCount}","${r.likeCount}","${r.commentCount}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=posts_export.csv')
      res.send(csv)
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/export/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const rows = await query(
        `SELECT r.id, r.reporter_name as reporterName, r.target_type as targetType,
                r.target_id as targetId, r.report_reason as reportReason,
                r.report_detail as reportDetail, r.status, r.create_time as createTime
         FROM community_reports r ORDER BY r.id DESC`
      )

      const csvHeader = 'ID,举报人,目标类型,目标ID,举报原因,详情,状态,创建时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.reporterName || '').replace(/"/g, '""')}","${r.targetType}","${r.targetId}","${(r.reportReason || '').replace(/"/g, '""')}","${(r.reportDetail || '').replace(/"/g, '""')}","${r.status}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=reports_export.csv')
      res.send(csv)
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/admin/export/users', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const rows = await query(
        `SELECT u.id, COALESCE(NULLIF(u.nickname,''), u.username) as nickname, u.email,
                (SELECT COUNT(*) FROM community_posts WHERE user_id=u.id AND status='published') as postCount,
                (SELECT COUNT(*) FROM community_comments WHERE user_id=u.id AND is_deleted=0) as commentCount,
                u.create_time as createTime
         FROM users u WHERE u.status='1' ORDER BY postCount DESC`
      )

      const csvHeader = '用户ID,昵称,邮箱,帖子数,评论数,注册时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.nickname || '').replace(/"/g, '""')}","${(r.email || '').replace(/"/g, '""')}","${r.postCount}","${r.commentCount}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=users_export.csv')
      res.send(csv)
    } catch (e) {
      res.serverError(e)
    }
  })
  // ==================== 社区排行榜增强 ====================
  app.get('/api/community/rankings/essence', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.title, p.is_essence as isEssence, p.view_count as viewCount,
                p.like_count as likeCount, p.comment_count as commentCount,
                p.create_time as createTime
         FROM community_posts p
         WHERE p.is_essence=1 AND p.status='published' AND p.is_deleted=0
         ORDER BY p.view_count DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/rankings/donations', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT u.id, COALESCE(NULLIF(u.nickname,''), u.username) as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(u.avatar, '') END as userAvatar,
                COALESCE(SUM(cl.amount), 0) as totalDonated
         FROM community_coin_logs cl
         JOIN users u ON u.id = cl.to_user_id
         GROUP BY u.id ORDER BY totalDonated DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/rankings/sections-active', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor,
                COUNT(p.id) as postCount,
                COALESCE(SUM(p.view_count), 0) as totalViewCount,
                COALESCE(SUM(p.comment_count), 0) as totalCommentCount
         FROM community_sections cs
         LEFT JOIN community_posts p ON p.section_id=cs.id AND p.is_deleted=0 AND p.status='published' AND p.create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         WHERE cs.status='active' AND cs.is_deleted=0
         GROUP BY cs.id ORDER BY postCount DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/rankings/daily', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.title, p.view_count as viewCount, p.like_count as likeCount,
                p.comment_count as commentCount, p.create_time as createTime
         FROM community_posts p
         WHERE p.status='published' AND p.is_deleted=0 AND DATE(p.create_time)=CURDATE()
         ORDER BY p.view_count DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Image Upload ====================
  app.post('/api/community/upload-image', communityImageUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择图片' })
      const { resolveUploadPath, recordFileUpload, getUserId, checkStorageQuota, updateUserUsedBytes, buildFileDesc } = require('../upload.cjs')
      const url = await resolveUploadPath(req.file, req, false)
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}
      const quota = await checkStorageQuota(userId, req.file.size || 0, 'community_image')
      if (!quota.ok) return res.json({ code: 400, msg: quota.msg })
      await recordFileUpload({
        userId,
        fileName: req.file.originalname,
        fileUrl: url,
        fileSize: req.file.size || 0,
        fileType: path.extname(req.file.originalname),
        mimeType: req.file.mimetype || '',
        category: 'community_image',
        description: buildFileDesc ? buildFileDesc({ category: 'community_image', refType: 'community_post' }) : ''
      })
      await updateUserUsedBytes(userId)
      res.json({ code: 200, msg: '上传成功', data: { url } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/delete-image', async (req, res) => {
    try {
      const { url } = req.body || {}
      if (!url) return res.json({ code: 400, msg: '缺少图片URL' })
      const { getDefaultStorage } = require('../storage-config.cjs')
      const { deleteFromCloud, getUserId } = require('../upload.cjs')
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}
      const userCtx = { userId, roles: [], levelId: 0, backend: false }
      const storage = await getDefaultStorage(userCtx)
      if (!storage) return res.json({ code: 500, msg: '未找到存储配置' })
      const key = new URL(url).pathname.replace(/^\//, '')
      await deleteFromCloud(storage, key)
      await query('DELETE FROM file_repository WHERE file_path=?', [url])
      if (userId) {
        const { updateUserUsedBytes } = require('../../utils/file-helper.cjs')
        await updateUserUsedBytes(userId)
      }
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Community] delete-image:', e.message)
      res.serverError(e)
    }
  })

  // ==================== Trust Level APIs ====================
  app.get('/api/community/user/:userId/trust-level', async (req, res) => {
    try {
      const userId = Number(req.params.userId)
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      let row = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      if (row.length === 0) {
        await initTrustLevel(userId)
        row = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      }
      if (row.length === 0) return res.json({ code: 404, msg: '用户信任等级未找到' })
      const data = row[0]
      const score = calcTrustScore(data.post_count, data.comment_count, data.like_received, data.report_count, data.ban_count)
      const level = getTrustLevelByScore(score)
      const levelNames = ['新手', '成员', '活跃', '资深']
      res.json({ code: 200, msg: 'success', data: {
        ...data,
        score,
        level,
        levelName: levelNames[level] || '新手'
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/trust-levels/calculate', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const users = await query(
        `SELECT u.id as userId,
                COALESCE(pc.cnt, 0) as postCount,
                COALESCE(cc.cnt, 0) as commentCount,
                COALESCE(lr.cnt, 0) as likeReceived,
                COALESCE(rp.cnt, 0) as reportCount,
                COALESCE(bc.cnt, 0) as banCount
         FROM users u
         LEFT JOIN (SELECT user_id, COUNT(*) as cnt FROM community_posts WHERE status='published' AND is_deleted=0 GROUP BY user_id) pc ON u.id=pc.user_id
         LEFT JOIN (SELECT user_id, COUNT(*) as cnt FROM community_comments WHERE status='published' AND is_deleted=0 GROUP BY user_id) cc ON u.id=cc.user_id
         LEFT JOIN (SELECT p.user_id, COUNT(*) as cnt FROM community_likes l JOIN community_posts p ON l.post_id=p.id WHERE p.status='published' AND p.is_deleted=0 GROUP BY p.user_id) lr ON u.id=lr.user_id
         LEFT JOIN (SELECT target_id as user_id, COUNT(*) as cnt FROM community_reports WHERE target_type='post' AND status='pending' GROUP BY target_id) rp ON u.id=rp.user_id
         LEFT JOIN (SELECT banned_user_id, COUNT(*) as cnt FROM community_moderator_bans WHERE is_active=1 GROUP BY banned_user_id) bc ON u.id=bc.banned_user_id
         ORDER BY u.id`
      )

      let updated = 0
      const BATCH_SIZE = 500
      const scored = users.map(u => {
        const s = calcTrustScore(u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount)
        return { ...u, score: s, level: getTrustLevelByScore(s) }
      })
      for (let i = 0; i < scored.length; i += BATCH_SIZE) {
        const batch = scored.slice(i, i + BATCH_SIZE)
        const placeholders = batch.map(() => '(?,?,?,?,?,?,?,?,NOW())').join(',')
        const values = []
        for (const u of batch) {
          values.push(u.userId, u.level, u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount, u.score)
          values.push(u.level, u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount, u.score)
        }
        await query(
          `INSERT INTO community_trust_levels (user_id, level, post_count, comment_count, like_received, report_count, ban_count, score, last_calculated)
           VALUES ${placeholders}
           ON DUPLICATE KEY UPDATE level=VALUES(level), post_count=VALUES(post_count), comment_count=VALUES(comment_count), like_received=VALUES(like_received), report_count=VALUES(report_count), ban_count=VALUES(ban_count), score=VALUES(score), last_calculated=NOW()`,
          values
        )
        updated += batch.length
      }

      res.json({ code: 200, msg: '已重新计算所有信任等级', data: { total: updated } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Content Quality Score ====================

  app.get('/api/community/analytics/quality-scores', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { limit = 50 } = req.query
      const posts = await query(
        `SELECT p.id, p.title, p.user_name as userName, p.section_id as sectionId,
                p.view_count as viewCount, p.like_count as likeCount,
                p.comment_count as commentCount, p.favorite_count as favoriteCount,
                p.coin_count as coinCount, p.is_essence as isEssence,
                p.create_time as createTime,
                (p.view_count * 0.1 + p.like_count * 3 + p.comment_count * 2 +
                 p.favorite_count * 5 + p.coin_count * 4 + IF(p.is_essence, 10, 0) +
                 GREATEST(0, 30 - DATEDIFF(NOW(), p.create_time)) * 0.5) as qualityScore
         FROM community_posts p
         WHERE p.is_deleted=0 AND p.status='published'
         ORDER BY qualityScore DESC LIMIT ?`,
        [Math.min(Number(limit) || 50, 100)]
      )
      const top = posts.slice(0, 10).map(p => ({
        ...p, qualityScore: Math.round(p.qualityScore * 10) / 10
      }))
      const avgScore = posts.length > 0
        ? Math.round(posts.reduce((s, p) => s + p.qualityScore, 0) / posts.length * 10) / 10
        : 0
      res.json({ code: 200, data: { top, avgScore, total: posts.length } })
    } catch (e) { res.serverError(e) }
  })

  // ==================== Community Profile API ====================

  app.get('/api/community/user/:userId/community-profile', async (req, res) => {
    try {
      const userId = Number(req.params.userId)
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })

      const trustRow = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      let trustLevel = 0, postCount = 0, commentCount = 0, reportCount = 0
      if (trustRow.length > 0) {
        const d = trustRow[0]
        trustLevel = d.level
        postCount = d.post_count
        commentCount = d.comment_count
        reportCount = d.report_count
      }

      const modSections = await query(
        `SELECT cm.section_id as sectionId, cm.role, cs.name as sectionName, cs.icon_bg_color as iconBgColor
         FROM community_moderators cm
         LEFT JOIN community_sections cs ON cm.section_id = cs.id
         WHERE cm.user_id=?`,
        [userId]
      )

      const bans = await query(
        "SELECT section_id as sectionId, reason, ban_until as banUntil, is_active as isActive FROM community_moderator_bans WHERE banned_user_id=? AND is_active=1 AND (ban_until IS NULL OR ban_until > NOW())",
        [userId]
      )

      const levelNames = ['新手', '成员', '活跃', '资深']

      res.json({ code: 200, msg: 'success', data: {
        trustLevel,
        trustLevelName: levelNames[trustLevel] || '新手',
        moderatorSections: modSections,
        banStatus: bans.length > 0 ? { banned: true, bans } : { banned: false, bans: [] },
        postCount,
        commentCount,
        reportCount
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Auto-Ban Settings APIs ====================

  app.get('/api/community/admin/auto-ban-settings', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const cfg = await getAutoBanSettings()
      res.json({ code: 200, msg: 'success', data: cfg })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/auto-ban-settings', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { threshold, durationHours } = req.body || {}
      if (threshold !== undefined && threshold > 0) {
        await query(
          'INSERT INTO community_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?',
          ['auto_ban_threshold', String(threshold), String(threshold)]
        )
      }
      if (durationHours !== undefined && durationHours > 0) {
        await query(
          'INSERT INTO community_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?',
          ['auto_ban_duration_hours', String(durationHours), String(durationHours)]
        )
      }
      const cfg = await getAutoBanSettings()
      res.json({ code: 200, msg: '设置已更新', data: cfg })
    } catch (e) {
      res.serverError(e)
    }
  })

};
