const query = require('../../database.cjs').query
const { authRequired } = require('../system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

module.exports = function(app) {
  app.get('/api/admin/moderation/queue', authRequired, adminRequired, async (req, res) => {
    try {
      const { page = 1, limit = 20, type } = req.query
      const offset = (Number(page) - 1) * Number(limit)
      
      let posts = await query(
        `SELECT id, user_id as userId, user_name as userName, title, 
                substr(content,1,100) as preview, status, is_hidden as isHidden,
                section_id as sectionId, create_time as createTime,
                TIMESTAMPDIFF(HOUR, create_time, NOW()) as waitHours,
                (SELECT level FROM community_trust_levels WHERE user_id=p.user_id LIMIT 1) as trustLevel,
                (SELECT COUNT(*) FROM community_reports WHERE target_type='post' AND target_id=p.id AND status='pending') as pendingReports
         FROM community_posts p 
         WHERE p.status='pending' AND p.is_deleted=0
         ORDER BY 
           CASE WHEN (SELECT COUNT(*) FROM community_reports WHERE target_type='post' AND target_id=p.id AND status='pending') >= 3 THEN 100 ELSE 0 END DESC,
           TIMESTAMPDIFF(HOUR, create_time, NOW()) * 10 DESC,
           COALESCE((SELECT level FROM community_trust_levels WHERE user_id=p.user_id), 3) ASC
         LIMIT ? OFFSET ?`,
        [Number(limit), offset]
      )

      const [{total}] = await query(
        `SELECT COUNT(*) as total FROM community_posts WHERE status='pending' AND is_deleted=0`
      )

      const queue = posts.map(p => ({
        id: p.id,
        userId: p.userId,
        userName: p.userName,
        title: p.title,
        preview: p.preview,
        status: p.status,
        trustLevel: p.trustLevel || 0,
        reportCount: p.pendingReports || 0,
        pendingReports: p.pendingReports || 0,
        waitHours: p.waitHours || 0,
        priority: (p.pendingReports >= 3 ? 100 : 0) + (p.waitHours || 0) * 10,
        createTime: p.createTime
      }))

      res.json({ code: 200, data: { list: queue, total, page: Number(page), limit: Number(limit) } })
    } catch (e) {
      console.error('[moderation-queue] error:', e.message)
      res.json({ code: 500, msg: '获取审核队列失败' })
    }
  })

  app.get('/api/admin/moderation/queue/stats', authRequired, adminRequired, async (req, res) => {
    try {
      const [postCount] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE status=\'pending\' AND is_deleted=0')
      const [commentCount] = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE status=\'pending\' AND is_deleted=0')
      const [appCount] = await query('SELECT COUNT(*) as cnt FROM app_store WHERE status=\'0\'')
      const [overdueCount] = await query(
        'SELECT COUNT(*) as cnt FROM community_posts WHERE status=\'pending\' AND is_deleted=0 AND create_time < DATE_SUB(NOW(), INTERVAL 72 HOUR)'
      )
      res.json({ code: 200, data: {
        pendingPosts: postCount.cnt || 0,
        pendingComments: commentCount.cnt || 0,
        pendingApps: appCount.cnt || 0,
        overdueItems: overdueCount.cnt || 0,
        total: (postCount.cnt || 0) + (commentCount.cnt || 0) + (appCount.cnt || 0)
      }})
    } catch (e) {
      console.error('[moderation-stats] error:', e.message)
      res.json({ code: 500, msg: '获取统计失败' })
    }
  })
}
