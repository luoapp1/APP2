'use strict';
const { query, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminOrModerator, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community-utils.cjs');
const { cacheGetOrSet, cacheDel, CACHE_KEY } = require('../../utils/redis.cjs');
module.exports = function(app) {

  function invalidateSectionCache() {
    cacheDel(CACHE_KEY.sections)
  }

  // ==================== Section APIs ====================

  app.get('/api/community/sections', async (req, res) => {
    try {
      const showAll = req.query.all === 'true' && (await isAdmin(req))
      const allSections = await cacheGetOrSet(CACHE_KEY.sections, 300, () =>
        query(
          `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor, cs.description,
                  (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published') as postCount,
                  (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published') as totalViewCount,
                  (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published' AND DATE(create_time)=CURDATE()) as todayHeat,
                  cs.sort_order as sortOrder, cs.status, cs.visibility,
                  cs.post_permission as postPermission, cs.view_permission as viewPermission,
                  cs.view_level_required as viewLevelRequired, cs.hot_threshold as hotThreshold,
                  cs.view_cooldown as viewCooldown, cs.create_time as createTime
           FROM community_sections cs WHERE cs.is_deleted=0 ORDER BY cs.sort_order ASC`
        )
      )
      const sections = showAll ? allSections : allSections.filter(s => s.status === 'active')
      const userId = await getUserId(req)
      const userRoles = await getUserRoles(req)
      const isUserAdminDB = userRoles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      const user = userId ? (await query('SELECT level_name, level_id, is_verified FROM users WHERE id=?', [userId]))[0] : null
      const filtered = []
      for (const s of sections) {
        if (s.visibility === 'restricted' && !(await canAccessSection(userId, s.id))) continue
        if (!isUserAdminDB) {
          const vp = s.viewPermission || 'all'
          if (vp === 'moderator_only') {
            if (!userId || !(await canAccessSection(userId, s.id))) continue
          } else if (vp === 'admin_only') {
            continue
          } else if (vp === 'vip_only') {
            if (!user || !user.level_name || !user.level_name.includes('VIP')) continue
          } else if (vp === 'member_only') {
            if (!user || !user.level_id) continue
          } else if (vp === 'verified_only') {
            if (!user || !user.is_verified) continue
          }
          if (s.viewLevelRequired && s.viewLevelRequired > 0) {
            if (!user || !user.level_id || user.level_id < s.viewLevelRequired) continue
          }
        }
        filtered.push(s)
      }
      res.json({ code: 200, msg: 'success', data: filtered })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 版主管理 API ====================

  app.get('/api/community/section/:id/moderators', async (req, res) => {
    try {
      const list = await query(
        `SELECT cm.id, cm.section_id as sectionId, cm.user_id as userId,
                COALESCE(NULLIF(u.nickname,''), u.username, cm.user_name) as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), cm.user_avatar, '') END as userAvatar,
                cm.role, cm.sort_order as sortOrder, cm.create_time as createTime
         FROM community_moderators cm LEFT JOIN users u ON cm.user_id = u.id WHERE cm.section_id=? ORDER BY cm.sort_order ASC, cm.create_time ASC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/section/:id/moderator', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const adminUserId = await getUserId(req)
      const { userId, userName, userAvatar, role } = req.body
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const userRoles = await getUserRoles(req)
      const availableRoles = await getAvailableRoles(userRoles)
      if (!availableRoles.includes(role)) {
        return res.json({ code: 400, msg: `角色无效，可选：${availableRoles.join('、')}` })
      }
      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, userId]
      )
      if (existing.length) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [userName||'', userAvatar||'', role||'版主', req.params.id, userId]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [req.params.id, userId, userName||'', userAvatar||'', role||'版主']
        )
      }
      // 通知用户已成为版主
      try {
        const modUser = await query('SELECT username, email FROM users WHERE id=?', [userId])
        if (modUser.length > 0 && modUser[0].email) {
          sendNotificationEmail('moderator_apply_result', modUser[0].email, {
            username: modUser[0].username || '',
            subject: '版主申请通过',
            content: `恭喜，您已被任命为板块版主（${role || '版主'}）。`
          })
        }
      } catch {}
      systemLog(adminUserId, 'assign_moderator', 'community', `任命用户${userId}为板块${req.params.id}版主`, req => ({}))
      res.json({ code: 200, msg: 'success' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/section/:id/moderator/:userId', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const adminUserId = await getUserId(req)
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, req.params.userId])
      // 通知用户版主身份已被移除
      try {
        const removedMod = await query('SELECT username, email FROM users WHERE id=?', [req.params.userId])
        if (removedMod.length > 0 && removedMod[0].email) {
          sendNotificationEmail('moderator_removed', removedMod[0].email, {
            username: removedMod[0].username || '',
            subject: '版主身份已移除',
            content: '您的版主身份已被管理员移除。'
          })
        }
      } catch {}
      systemLog(adminUserId, 'remove_moderator', 'community', `移除板块${req.params.id}版主用户${req.params.userId}`, req => ({}))
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 查询用户担任版主的所有板块
  app.get('/api/community/user/:userId/moderator-sections', async (req, res) => {
    try {
      const list = await query(
        `SELECT m.section_id as sectionId, m.role, s.name as sectionName, s.icon_bg_color as iconBgColor
         FROM community_moderators m
         LEFT JOIN community_sections s ON m.section_id = s.id
         WHERE m.user_id=?`,
        [req.params.userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 版主申请 API ====================

  async function getModeratorRoles() {
    try {
      const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
      return rows.map(r => r.role_name)
    } catch { return ['版主', '审核员'] }
  }

  async function getModeratorRoleCodes() {
    try {
      const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
      return rows
    } catch { return [{ role_name: '版主', role_code: 'R_MODERATOR' }, { role_name: '审核员', role_code: 'R_REVIEWER' }] }
  }

  async function getAvailableRoles(userRoles) {
    const allRoles = await getModeratorRoles()
    if (userRoles.some(r => r === 'R_SUPER')) return allRoles
    const roleCodes = await getModeratorRoleCodes()
    const adminAllowed = roleCodes.filter(rc => rc.role_code !== 'R_SUPER').map(rc => rc.role_name)
    if (userRoles.some(r => r === 'R_ADMIN')) return adminAllowed
    return []
  }

  async function getHighestRoleIndex(roles, allRoles) {
    let idx = -1
    for (const r of roles) {
      const i = allRoles.indexOf(r)
      if (i > idx) idx = i
    }
    return idx
  }

  async function isModeratorOfSection(userId, sectionId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    try {
      const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
      return rows.length > 0
    } catch { return false }
  }

  async function isModeratorOfPost(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    try {
      const rows = await query(
        'SELECT cm.id FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
        [postId, userId]
      )
      return rows.length > 0
    } catch { return false }
  }

  async function getModeratorSectionIds(userId) {
    try {
      const rows = await query('SELECT section_id FROM community_moderators WHERE user_id=? ORDER BY section_id', [userId])
      return rows.map(r => r.section_id)
    } catch { return [] }
  }

  const REVIEWER_ONLY_ROLES = ['审核员']

  async function getModeratorRoleForPost(userId, postId) {
    try {
      const rows = await query(
        'SELECT cm.role FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
        [postId, userId]
      )
      return rows.length > 0 ? rows[0].role : null
    } catch { return null }
  }

  async function canReviewModAction(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    const role = await getModeratorRoleForPost(userId, postId)
    return !!role
  }

  async function canManageModAction(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    const role = await getModeratorRoleForPost(userId, postId)
    return role && !REVIEWER_ONLY_ROLES.includes(role)
  }

  async function logModeratorAction(sectionId, userId, userName, action, targetType, targetId, detail) {
    try {
      await query(
        'INSERT INTO community_moderator_logs (section_id, moderator_id, moderator_name, action, target_type, target_id, detail) VALUES (?,?,?,?,?,?,?)',
        [sectionId || 0, userId, userName || '', action, targetType || '', targetId || 0, detail || '']
      )
    } catch {}
  }

  app.post('/api/community/section/:id/apply', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason, desiredRole } = req.body
      const sectionId = Number(req.params.id)

      const existing = await query(
        'SELECT id, status FROM moderator_applications WHERE section_id=? AND user_id=? AND status=?',
        [sectionId, userId, 'pending']
      )
      if (existing.length > 0) {
        return res.json({ code: 400, msg: '您已有待审核的申请' })
      }

      const isMod = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [sectionId, userId]
      )
      if (isMod.length > 0) {
        return res.json({ code: 400, msg: '您已是该板块的版主' })
      }

      const user = await query('SELECT username, avatar FROM users WHERE id=?', [userId])
      const userName = user.length > 0 ? (user[0].username || '') : ''
      const userAvatar = user.length > 0 && user[0].avatar && !user[0].avatar.startsWith('avatar:') ? user[0].avatar : ''

      await query(
        'INSERT INTO moderator_applications (section_id, user_id, user_name, user_avatar, reason, desired_role) VALUES (?,?,?,?,?,?)',
        [sectionId, userId, userName, userAvatar, reason || '', desiredRole || '版主']
      )

      try {
        const section = await query('SELECT name FROM community_sections WHERE id=? AND is_deleted=0', [sectionId])
        const sectionName = section.length > 0 ? section[0].name : '未知板块'

        const adminEmails = await getAdminEmails()
        if (adminEmails.length > 0) {
          for (const recipient of adminEmails) {
            sendNotificationEmail('moderator_apply', recipient, {
              username: recipient.split('@')[0] || '管理员',
              subject: '新版主申请通知',
              content: `${userName} 申请成为「${sectionName}」板块的 ${desiredRole || '版主'}，请前往管理后台审核。`
            })
          }
        }

        const admins = await query("SELECT id, roles FROM users WHERE roles LIKE '%R_SUPER%' OR roles LIKE '%R_ADMIN%'")
        for (const admin of admins) {
          await query(
            'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
            ['新版主申请', `${userName} 申请成为「${sectionName}」板块的 ${desiredRole || '版主'}`, 'moderator_apply', admin.id, userId, userName, userAvatar]
          )
        }
      } catch {}

      res.json({ code: 200, msg: '申请已提交，请等待管理员审核' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/section/:id/applications', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const list = await query(
        `SELECT a.id, a.section_id as sectionId, a.user_id as userId, a.user_name as userName,
                a.user_avatar as userAvatar, a.reason, a.desired_role as desiredRole,
                a.status, a.reviewed_by as reviewedBy, a.reviewed_by_name as reviewedByName,
                a.review_comment as reviewComment, a.create_time as createTime,
                a.review_time as reviewTime,
                cs.name as sectionName
         FROM moderator_applications a
         LEFT JOIN community_sections cs ON a.section_id = cs.id
         WHERE a.section_id=? ORDER BY a.create_time DESC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/applications', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const list = await query(
        `SELECT a.id, a.section_id as sectionId, a.user_id as userId, a.user_name as userName,
                a.user_avatar as userAvatar, a.reason, a.desired_role as desiredRole,
                a.status, a.reviewed_by as reviewedBy, a.reviewed_by_name as reviewedByName,
                a.review_comment as reviewComment, a.create_time as createTime,
                a.review_time as reviewTime,
                cs.name as sectionName
         FROM moderator_applications a
         LEFT JOIN community_sections cs ON a.section_id = cs.id
         ORDER BY a.status ASC, a.create_time DESC`,
        []
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/application/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const { role } = req.body
      const appRows = await query('SELECT * FROM moderator_applications WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (appRows.length === 0) return res.json({ code: 404, msg: '申请不存在或已处理' })

      const app = appRows[0]
      const availableRoles = await getAvailableRoles(roles)
      const assignedRole = role || app.desired_role || '版主'

      if (!availableRoles.includes(assignedRole)) {
        return res.json({ code: 403, msg: `您只能设置以下角色: ${availableRoles.join('、')}` })
      }

      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [app.section_id, app.user_id]
      )

      const reviewer = await query('SELECT username FROM users WHERE id=?', [userId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : '管理员'

      if (existing.length > 0) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [app.user_name, app.user_avatar || '', assignedRole, app.section_id, app.user_id]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [app.section_id, app.user_id, app.user_name, app.user_avatar || '', assignedRole]
        )
      }

      await query(
        'UPDATE moderator_applications SET status=?, reviewed_by=?, reviewed_by_name=?, review_time=NOW() WHERE id=?',
        ['approved', userId, reviewerName, req.params.id]
      )

      try {
        const applyUser = await query('SELECT email, username FROM users WHERE id=?', [app.user_id])
        if (applyUser.length > 0 && applyUser[0].email) {
          sendNotificationEmail('moderator_apply_result', applyUser[0].email, {
            username: applyUser[0].username || '',
            subject: '版主申请已通过',
            content: `恭喜，您的版主申请已通过审核，您已被任命为板块的「${assignedRole}」。`
          })
        }
        await query(
          'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
          ['版主申请已通过', `恭喜，您的版主申请已通过审核，您已被任命为「${assignedRole}」。`, 'moderator_apply_result', app.user_id, userId, reviewerName, '']
        )
      } catch (e) { console.error('审批通知发送失败:', e.message) }

      res.json({ code: 200, msg: '已通过申请' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/application/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const { reason } = req.body
      const appRows = await query('SELECT * FROM moderator_applications WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (appRows.length === 0) return res.json({ code: 404, msg: '申请不存在或已处理' })

      const app = appRows[0]
      const reviewer = await query('SELECT username FROM users WHERE id=?', [userId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : '管理员'

      await query(
        'UPDATE moderator_applications SET status=?, reviewed_by=?, reviewed_by_name=?, review_comment=?, review_time=NOW() WHERE id=?',
        ['rejected', userId, reviewerName, reason || '', req.params.id]
      )

      try {
        const applyUser = await query('SELECT email, username FROM users WHERE id=?', [app.user_id])
        if (applyUser.length > 0 && applyUser[0].email) {
          sendNotificationEmail('moderator_apply_result', applyUser[0].email, {
            username: applyUser[0].username || '',
            subject: '版主申请未通过',
            content: `很遗憾，您的版主申请未被通过。${reason ? '原因: ' + reason : ''}`
          })
        }
        await query(
          'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
          ['版主申请未通过', `很遗憾，您的版主申请未被通过。${reason ? '原因: ' + reason : ''}`, 'moderator_apply_result', app.user_id, userId, reviewerName, '']
        )
      } catch (e) { console.error('拒绝通知发送失败:', e.message) }

      res.json({ code: 200, msg: '已拒绝申请' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/section/:id/my-application', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        'SELECT id, status, desired_role as desiredRole, reason, review_comment as reviewComment, create_time as createTime FROM moderator_applications WHERE section_id=? AND user_id=? ORDER BY create_time DESC LIMIT 1',
        [req.params.id, userId]
      )
      res.json({ code: 200, msg: 'success', data: rows.length > 0 ? rows[0] : null })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/section/:id', async (req, res) => {
    try {
      const section = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor, cs.description,
                cs.today_heat as todayHeat, cs.total_heat as totalHeat,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published') as postCount,
                (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published') as totalViewCount,
                (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published' AND DATE(update_time)=CURDATE()) as todayViewCount,
                cs.sort_order as sortOrder, cs.status, cs.visibility,
                cs.post_permission as postPermission, cs.view_permission as viewPermission,
                cs.view_level_required as viewLevelRequired,
                cs.hot_threshold as hotThreshold, cs.view_cooldown as viewCooldown,
                cs.create_time as createTime
         FROM community_sections cs WHERE cs.id=? AND cs.is_deleted=0`, [req.params.id]
      )
      if (!section || section.length === 0) {
        return res.json({ code: 404, msg: '板块不存在' })
      }
      const s = section[0]
      if (s.visibility === 'restricted') {
        const userId = await getUserId(req)
        if (!(await canAccessSection(userId, s.id))) {
          return res.json({ code: 403, msg: '无权限访问此板块' })
        }
      }
      res.json({ code: 200, msg: 'success', data: s })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/section', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdminOrModerator(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { id, name, icon, iconBgColor, description, todayHeat, totalHeat, postCount, viewCount, sortOrder, status, visibility, postPermission, viewPermission, viewLevelRequired, hotThreshold, viewCooldown } = req.body

      if (id) {
        await query(
          `UPDATE community_sections SET name=?, icon=?, icon_bg_color=?, description=?,
           today_heat=?, total_heat=?, post_count=?, view_count=?, sort_order=?, status=?, visibility=?,
           post_permission=?, view_permission=?, view_level_required=?, hot_threshold=?, view_cooldown=?
           WHERE id=?`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0,
           hotThreshold ?? 100, viewCooldown ?? 30, id]
        )
        invalidateSectionCache()
        emitSafe(SECTION_EVENTS.UPDATED, { sectionId: id, name })
        systemLog(userId, 'update_section', 'community', `更新板块「${name}」`, req => ({}))
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_sections (name, icon, icon_bg_color, description, today_heat, total_heat, post_count, view_count, sort_order, status, visibility, post_permission, view_permission, view_level_required, hot_threshold, view_cooldown)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0,
           hotThreshold ?? 100, viewCooldown ?? 30]
        )
        const sectionId = result.insertId
        invalidateSectionCache()
        emitSafe(SECTION_EVENTS.CREATED, { sectionId, name })
        systemLog(userId, 'create_section', 'community', `创建板块「${name}」`, req => ({}))
        res.json({ code: 200, msg: '创建成功', data: { id: sectionId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/section/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdminOrModerator(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      await query('UPDATE community_sections SET is_deleted=1 WHERE id=?', [req.params.id])
      emitSafe(SECTION_EVENTS.DELETED, { sectionId: Number(req.params.id) })
      systemLog(userId, 'delete_section', 'community', `删除板块ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
  // ==================== Section Info (announcement/rules) ====================

  app.get('/api/community/section/:id/info', async (req, res) => {
    try {
      const rows = await query(
        'SELECT id, name, announcement, rules, banner_url as bannerUrl FROM community_sections WHERE id=? AND is_deleted=0',
        [req.params.id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '板块不存在' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/community/moderator/section/:id/update-info', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isModeratorOfSection(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })
      const { announcement, rules, bannerUrl } = req.body || {}
      const sets = []; const vals = []
      if (announcement !== undefined) { sets.push('announcement=?'); vals.push(announcement) }
      if (rules !== undefined) { sets.push('rules=?'); vals.push(rules) }
      if (bannerUrl !== undefined) { sets.push('banner_url=?'); vals.push(bannerUrl) }
      if (!sets.length) return res.json({ code: 400, msg: '无修改内容' })
      vals.push(req.params.id)
      await query(`UPDATE community_sections SET ${sets.join(',')} WHERE id=? AND is_deleted=0`, vals)
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(req.params.id, userId, operatorName, 'update_section', 'section', req.params.id, '更新板块信息')
      systemLog(userId, 'update_section_info', 'community', `更新板块${req.params.id}公告/规则`, req => ({}))
      res.json({ code: 200, msg: '已更新' })
    } catch (e) { res.serverError(e) }
  })

};
