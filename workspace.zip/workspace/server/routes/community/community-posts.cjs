'use strict';
const { getPermissionValue, hasPermission } = require('../../middleware/level-permissions.cjs')
const { checkPostSpam } = require('../../middleware/abuse-detection.cjs')
const { moderationPipeline, checkSensitiveWords: csCheck } = require('./moderation-pipeline.cjs');
const { query, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community-utils.cjs');
const { executePenalty } = require('../custom-task.cjs')
const userBlock = require('../user-block.cjs');
module.exports = function(app) {
  // ==================== Post APIs ====================

  app.get('/api/community/posts', async (req, res) => {
    try {
      const { sectionId, sort = 'latest', page = 1, pageSize = 20, keyword, tags, userId, viewerId, status: statusFilter, isHidden, followed, startDate, endDate } = req.query
      const queryUserId = Number(userId) || 0
      const queryViewerId = Number(viewerId) || 0
      const authUserId = await getUserId(req)
      const effectiveViewerId = queryViewerId || queryUserId
      const blockViewerId = queryViewerId || authUserId
      const isAdminUser = authUserId ? await isAdminById(authUserId) : false

      let followedUserIds = null
      if (followed) {
        const authUserId = await getUserId(req)
        if (authUserId) {
          const follows = await query('SELECT following_id FROM user_follows WHERE follower_id=?', [authUserId])
          if (follows.length > 0) {
            followedUserIds = follows.map(f => f.following_id)
          }
        }
      }

      let sql = `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                  CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                  p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                  p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                  p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                  p.content_permission as contentPermission, p.content_price as contentPrice,
                  p.content_price_type as contentPriceType,
                  p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status, p.like_count as likeCount,
                  p.comment_count as commentCount, p.coin_count as coinCount,
                  p.view_count as viewCount, p.favorite_count as favoriteCount,
                  p.is_global_pinned as isGlobalPinned,
                p.custom_badge as customBadge,
                p.cover_url as coverUrl,
                  p.reject_reason as rejectReason,
                  p.create_time as createTime, p.update_time as updateTime,
                  p.scheduled_time as scheduledTime,
                  p.auto_hide_at as autoHideAt,
                  p.is_hidden as isHidden,
                   u.level_name as userLevelName, u.is_verified as userIsVerified,
                    COALESCE(el.name, 'Lv.1') as userExpLevelName,
                    el.icon as userExpLevelIcon,
                    COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                    COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                  COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                  COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                  ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                   ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                    tp.name as topicName,
                    cs.name as sectionName,
                    ccp.collection_id as collectionId,
                    col.title as collectionTitle
                  FROM community_posts p
                  LEFT JOIN users u ON p.user_id = u.id
                  LEFT JOIN experience_levels el ON el.exp_required <= u.experience AND el.status = '1'
                    AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= u.experience AND el2.status = '1' AND el2.exp_required > el.exp_required)
                  LEFT JOIN membership_levels ml ON ml.id = u.level_id
                  LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
                  LEFT JOIN community_topics tp ON p.topic_id = tp.id
                  LEFT JOIN community_sections cs ON p.section_id = cs.id
                  LEFT JOIN community_collection_posts ccp ON p.id = ccp.post_id
                  LEFT JOIN community_collections col ON ccp.collection_id = col.id AND col.is_deleted = 0 AND col.status IN ('serializing','finished')
                  WHERE `
      const params = []

      if (statusFilter) {
        sql += 'p.status=?'
        params.push(statusFilter)
      } else if (queryUserId) {
        if (authUserId === queryUserId) {
          sql += "(p.status='published' OR (p.user_id=? AND p.status!='deleted'))"
          params.push(queryUserId)
        } else {
          sql += "p.status='published' AND p.user_id=? AND p.is_hidden=0"
          params.push(queryUserId)
        }
      } else {
        sql += "p.status='published' AND p.is_hidden=0"
      }

      if (!statusFilter && queryUserId && authUserId === queryUserId && isHidden === undefined) {
        sql += ' AND (p.is_hidden=0 OR p.user_id=?)'
        params.push(queryUserId)
      }

      if (isHidden !== undefined) {
        sql += ' AND p.is_hidden=?'
        params.push(isHidden === '1' ? 1 : 0)
      }

      if (sectionId) { sql += ' AND (p.section_id=? OR p.is_global_pinned=1)'; params.push(sectionId) }
      if (queryUserId) { sql += ' AND p.user_id=?'; params.push(queryUserId) }
      if (keyword) { sql += ' AND (p.title LIKE ? OR p.content LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      if (tags) {
        const tagList = tags.split(',')
        for (const t of tagList) {
          sql += ' AND p.tags LIKE ?'
          params.push(`%${t.trim()}%`)
        }
      }

      if (startDate) { sql += ' AND p.create_time >= ?'; params.push(startDate) }
      if (endDate) { sql += ' AND p.create_time <= ?'; params.push(endDate + ' 23:59:59') }

      // 过滤受限板块的帖子
      if (!isAdminUser) {
        const restrictedSections = await query('SELECT id FROM community_sections WHERE visibility=? AND is_deleted=0', ['restricted'])
        if (restrictedSections.length > 0) {
          const restrictedIds = restrictedSections.map(s => s.id)
          let accessibleIds = []
          if (queryUserId) {
            const modRows = await query(
              `SELECT section_id FROM community_moderators WHERE user_id=? AND section_id IN (${restrictedIds.map(() => '?').join(',')})`,
              [queryUserId, ...restrictedIds]
            )
            accessibleIds = modRows.map(r => r.section_id)
          }
          const inaccessibleIds = restrictedIds.filter(id => !accessibleIds.includes(id))
          if (inaccessibleIds.length > 0) {
            sql += ` AND p.section_id NOT IN (${inaccessibleIds.map(() => '?').join(',')})`
            params.push(...inaccessibleIds)
          }
        }
      }

      // 关注筛选：仅显示关注用户的帖子
      if (followed) {
        if (followedUserIds && followedUserIds.length > 0) {
          sql += ` AND p.user_id IN (${followedUserIds.map(() => '?').join(',')})`
          params.push(...followedUserIds)
        } else {
          sql += ' AND 1=0'
        }
      }

      // 拉黑过滤：当前用户不看到拉黑自己的人的内容，也不看到被自己拉黑的人的内容
      if (blockViewerId && blockViewerId > 0) {
        const { getBlockedUserIds, getBlockerUserIds } = require('../user-block.cjs')
        const blockedIds = await getBlockedUserIds(blockViewerId)
        const blockerIds = await getBlockerUserIds(blockViewerId)
        const excludeIds = [...new Set([...blockedIds, ...blockerIds])]
        if (excludeIds.length > 0) {
          sql += ` AND p.user_id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }
      }

      // trending 排序：仅统计最近7天的帖子
      if (sort === 'trending') {
        sql += ' AND p.create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)'
      }

      let orderBy = ''
      switch (sort) {
        case 'recent_reply': orderBy = 'p.is_global_pinned DESC, p.update_time DESC'; break
        case 'most_likes': orderBy = 'p.is_global_pinned DESC, p.like_count DESC'; break
        case 'most_favorites': orderBy = 'p.is_global_pinned DESC, p.favorite_count DESC'; break
        case 'essence': orderBy = 'p.is_global_pinned DESC, p.is_essence DESC, p.id DESC'; break
        case 'hot': orderBy = 'p.is_global_pinned DESC, p.like_count DESC'; break
        case 'trending': orderBy = 'p.is_global_pinned DESC, p.comment_count DESC'; break
        case 'views': orderBy = 'p.is_global_pinned DESC, p.view_count DESC'; break
        case 'pinned': orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'; break
        default: orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY ${orderBy} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
      }

      if (list.length > 0) {
        const postIds = list.map(p => p.id)
        const userIds = [...new Set(list.map(p => p.userId).filter(Boolean))]
        const [titleRows, topicRows] = await Promise.all([
          userIds.length > 0
            ? query(
                `SELECT ut.user_id, GROUP_CONCAT(CASE WHEN ct.icon IS NOT NULL AND ct.icon != '' THEN ct.icon END SEPARATOR '|||') as allIcons,
                        GROUP_CONCAT(ct.name SEPARATOR '|||') as allNames
                 FROM user_titles ut JOIN custom_titles ct ON ut.title_id = ct.id
                 WHERE ct.status = '1' AND ut.user_id IN (${userIds.map(() => '?').join(',')})
                 GROUP BY ut.user_id`,
                userIds
              )
            : Promise.resolve([]),
          query(
            `SELECT pt.post_id, GROUP_CONCAT(pt.topic_id) as tids,
                    GROUP_CONCAT(t.name SEPARATOR '|||') as tnames
             FROM community_post_topics pt JOIN community_topics t ON pt.topic_id = t.id
             WHERE pt.post_id IN (${postIds.map(() => '?').join(',')})
             GROUP BY pt.post_id`,
            postIds
          )
        ])
        const titleMap = {}
        for (const r of titleRows) {
          titleMap[r.user_id] = { allIcons: r.allIcons, allNames: r.allNames }
        }
        const topicMap = {}
        for (const r of topicRows) {
          topicMap[r.post_id] = { tids: r.tids, tnames: r.tnames }
        }
        for (const item of list) {
          const ti = titleMap[item.userId]
          item.userAllTitleIcons = ti?.allIcons || ''
          item.userAllTitleNames = ti?.allNames || ''
          const tp = topicMap[item.id]
          item.topicIds = tp?.tids ? tp.tids.split(',').map(Number) : []
          item.topicNames = tp?.tnames ? tp.tnames.split('|||').filter(Boolean) : []
        }
      }

      if (Number(userId) && list.length > 0) {
        try {
          const postIds = list.map(p => p.id)
          const likedRows = await query(
            `SELECT post_id FROM community_likes WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const favoritedRows = await query(
            `SELECT post_id FROM community_favorites WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const likedSet = new Set(likedRows.map(r => r.post_id))
          const favSet = new Set(favoritedRows.map(r => r.post_id))
          for (const item of list) {
            item.isLiked = likedSet.has(item.id)
            item.isFavorited = favSet.has(item.id)
          }
        } catch {}
      }

      // 过滤付费内容：非作者/非管理员/未购买的用户，隐藏付费帖子的内容
      if (list.length > 0) {
        try {
          const allIds = list.map(p => p.id)
          const paidSet = new Set()
          if (effectiveViewerId) {
            const purchases = await query(
              `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${allIds.map(() => '?').join(',')})`,
              [effectiveViewerId, ...allIds]
            )
            purchases.forEach(p => paidSet.add(p.content_id))
          }
          const isViewerAdmin = effectiveViewerId ? await isAdminById(effectiveViewerId) : false
          const restrictedPosts = list.filter(p => ['paid', 'login', 'mixed'].includes(p.contentPermission))
          for (const item of restrictedPosts) {
            if (effectiveViewerId && (item.userId === effectiveViewerId || isViewerAdmin)) continue
            if (paidSet.has(item.id)) continue
            const perm = item.contentPermission || 'paid'
            const hints = {
              paid: '部分内容付费 - 需购买后查看',
              comment: '评论后可见',
              level: '需达到一定等级后查看',
              password: '需密码查看',
              login: '登录后可查看完整内容',
              mixed: '部分内容付费 - 需购买后查看'
            }
            item.content = hints[perm] || hints.paid
            item.contentFiltered = true
            try { item.images = [] } catch {}
          }
          for (const item of list) {
            item.hasPurchased = paidSet.has(item.id) || (effectiveViewerId && item.userId === effectiveViewerId)
          }
          if (effectiveViewerId && allIds.length > 0) {
            const commentedSet = new Set()
            const comments = await query(
              `SELECT DISTINCT post_id FROM community_comments WHERE post_id IN (${allIds.map(() => '?').join(',')}) AND user_id = ? AND is_deleted=0`,
              [...allIds, effectiveViewerId]
            )
            comments.forEach(c => commentedSet.add(c.post_id))
            for (const item of list) {
              item.hasCommented = commentedSet.has(item.id)
            }
          }
          if (effectiveViewerId) {
            const [viewerRow] = await query(`SELECT level_id as viewerLevelId FROM users WHERE id = ?`, [effectiveViewerId])
            const titleRows = await query(`SELECT title_id FROM user_titles WHERE user_id = ? AND is_active = 1`, [effectiveViewerId])
            const viewerTitleIds = titleRows.map(r => r.title_id)
            const viewerFollowers = await query(`SELECT following_id FROM user_follows WHERE follower_id = ?`, [effectiveViewerId])
            const viewerFollowingIds = viewerFollowers.map(r => r.following_id)
            for (const item of list) {
              item.viewerLevelId = (viewerRow && viewerRow.viewerLevelId) || 0
              item.viewerTitleIds = viewerTitleIds
              item.viewerFollowing = viewerFollowingIds.includes(item.userId)
            }
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/post/:id', async (req, res) => {
    try {
      const { userId } = req.query
      const queryUserId = Number(userId) || 0
      const post = await query(
        `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.custom_badge as customBadge,
                p.cover_url as coverUrl,
                p.is_pinned as isPinned, p.is_essence as isEssence, p.is_hot as isHot,
                p.is_locked as isLocked, p.is_global_pinned as isGlobalPinned,
                p.is_deleted as isDeleted, p.deleted_at as deletedAt,
                p.like_count as likeCount, p.favorite_count as favoriteCount,
                p.view_count as viewCount, p.comment_count as commentCount,
                p.create_time as createTime, p.update_time as updateTime,
                p.status, p.scheduled_time as scheduledTime,
                p.auto_hide_at as autoHideAt, p.is_hidden as isHidden,
                u.level_name as userLevelName, u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                u.active_title_name as userTitleName,
                cti.icon as userTitleIcon, cti.color as userTitleColor, cti.bg_color as userTitleBgColor,
                (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                tp.name as topicName,
                (SELECT COUNT(*) FROM content_purchases WHERE content_type='post' AND content_id=p.id) as soldCount,
                (SELECT GROUP_CONCAT(pt.topic_id) FROM community_post_topics pt WHERE pt.post_id = p.id) as topicIds,
                cs.name as sectionName,
                (SELECT COUNT(*) FROM community_moderators WHERE section_id=p.section_id AND user_id=p.user_id) as authorIsModerator,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = p.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                ccp2.collection_id as collectionId,
                col2.title as collectionTitle
         FROM community_posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN membership_levels ml ON ml.id = u.level_id LEFT JOIN custom_titles cti ON cti.id = u.active_title_id LEFT JOIN community_topics tp ON p.topic_id = tp.id LEFT JOIN community_sections cs ON p.section_id = cs.id LEFT JOIN community_collection_posts ccp2 ON p.id = ccp2.post_id LEFT JOIN community_collections col2 ON ccp2.collection_id = col2.id AND col2.is_deleted = 0 WHERE p.id=?`, [req.params.id]
      )
      if (!post || post.length === 0) {
        return res.json({ code: 404, msg: '帖子不存在' })
      }
      const item = post[0]
      if (item.status === 'deleted' || item.isDeleted) {
        const isOwner = item.userId === queryUserId
        const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子已被删除' })
        }
      }
      // 隐藏帖仅对作者和管理员可见
      if (item.isHidden) {
        const isOwner = item.userId === queryUserId
        const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        const authUserId = await getUserId(req)
        const isOwnerByAuth = item.userId === authUserId
        const isAdminByAuth = authUserId ? await isAdminById(authUserId) : false
        if (!isOwner && !isAdminUser && !isOwnerByAuth && !isAdminByAuth) {
          return res.json({ code: 404, msg: '帖子已隐藏' })
        }
      }

      // 检查板块可见性
      const secRows = await query('SELECT visibility FROM community_sections WHERE id=? AND is_deleted=0', [item.sectionId])
      if (secRows.length > 0 && secRows[0].visibility === 'restricted') {
        if (!(await canAccessSection(queryUserId, item.sectionId))) {
          return res.json({ code: 403, msg: '无权限访问此帖子' })
        }
      }

      if (item.status === 'pending' || item.status === 'rejected' || item.status === 'scheduled') {
        const isOwner = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子不存在' })
        }
      }
      try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      item.isPinned = !!item.isPinned
      item.isEssence = !!item.isEssence
      item.isHot = !!item.isHot
      item.isGlobalPinned = !!item.isGlobalPinned
      item.topicIds = item.topicIds ? item.topicIds.split(',').map(Number) : []
      item.authorIsModerator = item.authorIsModerator > 0
      item.userAllTitleNames = item.userAllTitleNames ? item.userAllTitleNames.split('|||') : []
      item.userAllTitleIcons = item.userAllTitleIcons ? item.userAllTitleIcons.split('|||') : []

      // 浏览数+1，同时检查是否达到15000自动设为热帖（未被管理员手动禁用的）
      await query(
        `UPDATE community_posts SET view_count = view_count + 1, update_time = NOW(),
         is_hot = CASE WHEN view_count + 1 >= 15000 AND hot_manually_disabled = 0 THEN 1 ELSE is_hot END
         WHERE id=?`,
        [Number(req.params.id)]
      )

      {
        const updated = await query('SELECT is_hot, view_count FROM community_posts WHERE id=?', [Number(req.params.id)])
        if (updated.length > 0) {
          item.isHot = !!updated[0].is_hot
          item.viewCount = updated[0].view_count
        }
      }

      if (queryUserId > 0) await progressTasksByAction(queryUserId, '', 'view_post')

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE(el.name, 'Lv.1') as userExpLevelName,
                el.icon as userExpLevelIcon,
                COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                ut_all.allIcons as userAllTitleIcons,
                ut_all.allNames as userAllTitleNames,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
         FROM community_comments c
         LEFT JOIN users u ON c.user_id = u.id
         LEFT JOIN experience_levels el ON el.exp_required <= u.experience AND el.status = '1'
           AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= u.experience AND el2.status = '1' AND el2.exp_required > el.exp_required)
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN (
           SELECT ut2.user_id,
             GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
             GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
           FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
           WHERE ct2.status = '1' GROUP BY ut2.user_id
         ) ut_all ON u.id = ut_all.user_id
         WHERE c.post_id=? AND c.parent_id=0 AND c.is_deleted=0 ORDER BY c.create_time DESC`,
        [req.params.id]
      )
      const allReplies = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE(el.name, 'Lv.1') as userExpLevelName,
                el.icon as userExpLevelIcon,
                COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                ut_all.allIcons as userAllTitleIcons,
                ut_all.allNames as userAllTitleNames,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
         FROM community_comments c
         LEFT JOIN users u ON c.user_id = u.id
         LEFT JOIN experience_levels el ON el.exp_required <= u.experience AND el.status = '1'
           AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= u.experience AND el2.status = '1' AND el2.exp_required > el.exp_required)
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN (
           SELECT ut2.user_id,
             GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
             GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
           FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
           WHERE ct2.status = '1' GROUP BY ut2.user_id
         ) ut_all ON u.id = ut_all.user_id
         WHERE c.post_id=? AND c.is_deleted=0 AND c.parent_id>0 ORDER BY c.create_time ASC`,
        [req.params.id]
      )
      const replyMap = {}
      for (const r of allReplies) {
        if (!replyMap[r.parentId]) replyMap[r.parentId] = []
        replyMap[r.parentId].push(r)
      }
      for (const c of comments) {
        c.replies = replyMap[c.id] || []
      }
      item.comments = comments

      if (Number(userId)) {
        try {
          const liked = await query(
            'SELECT id FROM community_likes WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isLiked = liked.length > 0
          const faved = await query(
            'SELECT id FROM community_favorites WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isFavorited = faved.length > 0
        } catch {}
      }

      // 内容块过滤：非作者/非管理员，根据 visibility 剥离受限内容
      const isAuthor = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
      if (!isAuthor && !isAdminUser && item.content) {
        try {
          let blocks = typeof item.content === 'string' ? JSON.parse(item.content) : item.content
          if (Array.isArray(blocks) && blocks.length > 0) {
            // 查询已购买的 block 索引
            let purchasedBlocks = new Set()
            if (queryUserId > 0) {
              const purchases = await query(
                'SELECT block_index FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index>=0',
                ['post', Number(req.params.id), queryUserId]
              )
              purchases.forEach(p => purchasedBlocks.add(p.block_index))
              // 全帖购买 (content_permission='paid' 且购买了)
              const fullPurchase = await query(
                'SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index<0',
                ['post', Number(req.params.id), queryUserId]
              )
              if (fullPurchase.length > 0) purchasedBlocks = new Set([-1]) // mark as full purchase
            }

            // 查询用户是否评论过
            let userCommented = false
            if (queryUserId > 0) {
              const cmtCheck = await query(
                'SELECT id FROM community_comments WHERE post_id=? AND user_id=? AND is_deleted=0',
                [Number(req.params.id), queryUserId]
              )
              userCommented = cmtCheck.length > 0
            }

            // 查询用户等级 tier
            let userLevelTier = 0
            if (queryUserId > 0) {
              const ul = await query('SELECT COALESCE(ml.tier, 0) as tier FROM users u LEFT JOIN membership_levels ml ON ml.id = u.level_id WHERE u.id=?', [queryUserId])
              if (ul.length > 0) userLevelTier = ul[0].tier || 0
            }

            // 创建占位块替换被过滤的内容，保留所有 metadata（价格、等级等）
            const placeholder = (b, vis) => ({
              ...b,
              value: '',
              images: undefined,
              url: undefined,
              visibility: vis !== undefined ? vis : (b.visibility || 'public'),
              _filtered: true
            })

            const filtered = blocks.map(b => {
              const vis = (b.visibility || item.contentPermission || 'public').toString()
              if (!vis || vis === 'public') return b

              // 全帖已购买 → 所有块可见
              if (purchasedBlocks.has(-1)) return b

              if (vis === 'paid') {
                // 检查是否购买了该 block
                const blockIdx = blocks.indexOf(b)
                if (purchasedBlocks.has(blockIdx)) return b
                return placeholder(b, 'paid')
              }

              if (vis === 'comment') {
                if (userCommented) return b
                return placeholder(b, 'comment')
              }

              if (vis === 'level') {
                const required = b.visibilityLevel !== undefined ? Number(b.visibilityLevel) : 1
                if (userLevelTier >= required) return b
                return placeholder(b, 'level')
              }

              if (vis === 'level1') {
                if (userLevelTier >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelTier >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'level3') {
                if (userLevelTier >= 3) return b
                return placeholder(b, 'level3')
              }
              if (vis === 'level4') {
                if (userLevelTier >= 4) return b
                return placeholder(b, 'level4')
              }
              if (vis === 'level5') {
                if (userLevelTier >= 5) return b
                return placeholder(b, 'level5')
              }

              if (vis === 'level1') {
                if (userLevelId >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelId >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'password') {
                // 密码验证由前端处理，后端保留但加标记
                return b
              }

              // 未登录用户且 visibility 不是 public/login → 替换
              if (!queryUserId) return placeholder(b, vis)

              return b
            })

            item.content = JSON.stringify(filtered)
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: item })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        sectionId, title, content: rawContent, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, scheduledTime, draftId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds, coverImage, autoHideAt
      } = req.body
      const content = sanitizeCommunityContent(rawContent)

      // C9: 单帖图片数量
      const maxImages = parseInt(await getPermissionValue(userId, 'community', 'C9') || '999')
      const imageCount = Array.isArray(images) ? images.length : (images ? JSON.parse(typeof images === 'string' ? images : '[]').length : 0)
      if (imageCount > maxImages) {
        return res.json({ code: 400, msg: `当前等级每帖最多上传${maxImages}张图片` })
      }

      // 检查板块发帖权限
      if (sectionId) {
        const section = await query('SELECT post_permission FROM community_sections WHERE id=? AND is_deleted=0', [Number(sectionId)])
        if (section.length) {
          const perm = section[0].post_permission || 'all'
          if (perm !== 'all') {
            const isUserAdmin = await isAdmin(req)

            if (perm === 'admin_only' && !isUserAdmin) {
              return res.json({ code: 403, msg: '此板块仅管理员可发帖' })
            }
            if (perm === 'moderator_only') {
              if (!isUserAdmin) {
                const mods = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [Number(sectionId), userId])
                if (!mods.length) return res.json({ code: 403, msg: '此板块仅版主可发帖' })
              }
            }
            if (perm === 'member_only') {
              const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_id) {
                return res.json({ code: 403, msg: '此板块仅会员可发帖' })
              }
            }
            if (perm === 'vip_only') {
              const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_name || !user[0].level_name.includes('VIP')) {
                return res.json({ code: 403, msg: '此板块仅VIP会员可发帖' })
              }
            }
            if (perm === 'verified_only') {
              const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].is_verified) {
                return res.json({ code: 403, msg: '此板块仅认证用户可发帖' })
              }
            }
          }
        }
      }

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      // C3: 发帖频率限制(篇/日)
      const maxPostsPerDay = parseInt(await getPermissionValue(userId, 'community', 'C3') || '999')
      const today = new Date().toISOString().substring(0, 10)
      const dailyPostCount = await query(
        "SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND DATE(create_time)=? AND is_deleted=0",
        [userId, today]
      )
      if (dailyPostCount[0]?.cnt >= maxPostsPerDay) {
        return res.json({ code: 400, msg: `当前等级每日最多发布${maxPostsPerDay}篇帖子` })
      }

      // C5: 付费内容检查
      if (contentPermission === 'paid' && contentPrice > 0) {
        const canPostPaid = await hasPermission(userId, 'community', 'C5')
        if (!canPostPaid) return res.json({ code: 403, msg: '当前等级不支持发布付费内容' })
        // C6: 内容定价上限
        const maxContentPrice = parseInt(await getPermissionValue(userId, 'community', 'C6') || '0')
        if (maxContentPrice > 0 && Number(contentPrice) > maxContentPrice) {
          return res.json({ code: 400, msg: `当前等级内容定价上限为${maxContentPrice}元` })
        }
      }

      // C14: 定时发布
      if (scheduledTime) {
        const canSchedule = await hasPermission(userId, 'community', 'C14')
        if (!canSchedule) return res.json({ code: 403, msg: '当前等级不支持定时发布' })
      }

      // C1: 发帖免审核 — 设为published后跳过管线
      const skipReview = await hasPermission(userId, 'community', 'C1')

      // 自动审核管线
      let finalStatus = scheduledTime ? 'scheduled' : 'pending'
      let moderationLogs = []
      let pipelineRejectReason = ''
      // C1: 免审核跳过管线
      if (skipReview && !scheduledTime) {
        finalStatus = 'published'
      } else if (!scheduledTime) {
        try {
          const pipelineResult = await moderationPipeline(userId, {
            text: (title || '') + ' ' + (content || ''),
            title: title || '',
            content: content || '',
            images: images || []
          }, 'post')
          if (pipelineResult.action === 'reject') {
            finalStatus = 'rejected'
            pipelineRejectReason = pipelineResult.reason || '内容不符合社区规范'
          }
          if (pipelineResult.action === 'publish') {
            finalStatus = 'published'
          }
          moderationLogs = pipelineResult.logs || []
        } catch (e) {
          console.error('[post] moderation pipeline error:', e.message)
          // fail-open: 管审失败回退为 pending
        }
      }

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''

      const cover = coverImage || ''
      const result = await query(
        `INSERT INTO community_posts (section_id, user_id, user_name, user_avatar, title, content, device, tags, official_tags, images,
          has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission, status, scheduled_time,
           content_permission, content_price, content_price_type, access_password, access_password_tips, topic_id, cover_url, auto_hide_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [sectionId || 0, userId, userName, userAvatar, title || '', content || '', device || '', tg, ot, imgs,
         hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
         extractCode || '', permission || 'public', finalStatus, scheduledTime || null,
         contentPermission || 'public', contentPrice || 0, contentPriceType || 'balance', accessPassword || '', accessPasswordTips || '',
         topicId || 0, cover, autoHideAt || null]
      )
      const postId = result.insertId

      if (finalStatus === 'rejected') {
        await query('UPDATE community_posts SET reject_reason=? WHERE id=?', [pipelineRejectReason || '', postId])
      }

      // 处理多话题关联
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId ? [Number(topicId)] : [])
      if (finalTopicIds.length > 0) {
        for (const tid of finalTopicIds) {
          try { await query('INSERT IGNORE INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [postId, Number(tid)]) } catch (e) { console.error('[community] topic link failed on create:', postId, tid, e.message) }
        }
      }

      if (finalStatus !== 'rejected') {
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [sectionId || 0])
      }

      checkPostSpam(userId, postId, title || '', content || '')

      if (draftId) {
        await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [draftId, userId])
      }

      await progressTasksByAction(userId, userName, 'post')
      await incrementPostCount(userId)

      if (finalStatus === 'rejected') {
        res.json({ code: 200, msg: '内容未通过自动审核，请修改后重新发布', data: { id: postId, status: 'rejected' } })
        return
      }

      // 待审核帖子通知管理员和版主
      if (finalStatus === 'pending') {
        const sectionName = sectionId ? ((await query('SELECT name FROM community_sections WHERE id=? AND is_deleted=0', [sectionId]))[0]?.name || '') : ''
        const adminEmails = await getAdminEmails()
        for (const adminEmail of adminEmails) {
          sendNotificationEmail('post_review', adminEmail, {
            username: '管理员',
            subject: '帖子待审核通知',
            content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
          })
        }
        const modEmails = await getModeratorEmails(sectionId)
        for (const modEmail of modEmails) {
          if (!adminEmails.includes(modEmail)) {
            sendNotificationEmail('post_review_moderator', modEmail, {
              username: '版主',
              subject: '帖子待审核通知',
              content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
            })
          }
        }
      }

      emitSafe(POST_EVENTS.CREATED, { postId, userId, userName, sectionId: sectionId || 0, title })

      createMentionNotifications(content, userId, userName, userAvatar, 'post', postId)

      res.json({ code: 200, msg: '发布成功', data: { id: postId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.put('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, content, tags FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })
      if (existing[0].user_id !== userId && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权编辑' })

      const {
        title, content: rawContent, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, sectionId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds, coverImage, editSummary, scheduledTime, autoHideAt
      } = req.body
      const content = rawContent !== undefined ? sanitizeCommunityContent(rawContent) : undefined

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : undefined
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : undefined
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : undefined

      await savePostRevision(existing[0].id || req.params.id, userId, existing[0].title, existing[0].content, existing[0].tags, editSummary || '用户编辑')

      const sets = []
      const params = []
      if (title !== undefined) { sets.push('title=?'); params.push(title) }
      if (content !== undefined) { sets.push('content=?'); params.push(content) }
      if (device !== undefined) { sets.push('device=?'); params.push(device) }
      if (tg !== undefined) { sets.push('tags=?'); params.push(tg) }
      if (ot !== undefined) { sets.push('official_tags=?'); params.push(ot) }
      if (imgs !== undefined) { sets.push('images=?'); params.push(imgs) }
      if (hasResource !== undefined) { sets.push('has_resource=?'); params.push(hasResource ? 1 : 0) }
      if (resourceType !== undefined) { sets.push('resource_type=?'); params.push(resourceType) }
      if (resourceUrl !== undefined) { sets.push('resource_url=?'); params.push(resourceUrl) }
      if (resourcePrice !== undefined) { sets.push('resource_price=?'); params.push(resourcePrice) }
      if (resourcePriceType !== undefined) { sets.push('resource_price_type=?'); params.push(resourcePriceType) }
      if (extractCode !== undefined) { sets.push('extract_code=?'); params.push(extractCode) }
      if (permission !== undefined) { sets.push('permission=?'); params.push(permission) }
      if (sectionId !== undefined) { sets.push('section_id=?'); params.push(sectionId) }
      if (contentPermission !== undefined) { sets.push('content_permission=?'); params.push(contentPermission) }
      if (contentPrice !== undefined) { sets.push('content_price=?'); params.push(contentPrice) }
      if (contentPriceType !== undefined) { sets.push('content_price_type=?'); params.push(contentPriceType) }
      if (accessPassword !== undefined) { sets.push('access_password=?'); params.push(accessPassword) }
      if (accessPasswordTips !== undefined) { sets.push('access_password_tips=?'); params.push(accessPasswordTips) }
      if (topicId !== undefined) { sets.push('topic_id=?'); params.push(topicId) }
      if (coverImage !== undefined) { sets.push('cover_url=?'); params.push(coverImage) }
      if (scheduledTime !== undefined) { sets.push('scheduled_time=?'); params.push(scheduledTime || null) }
      if (autoHideAt !== undefined) { sets.push('auto_hide_at=?'); params.push(autoHideAt || null) }
      sets.push(`update_time=${nowExpr}`)
      params.push(req.params.id)

      await query(`UPDATE community_posts SET ${sets.join(',')} WHERE id=?`, params)

      // 处理多话题关联更新
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId !== undefined ? [Number(topicId)] : undefined)
      if (finalTopicIds !== undefined) {
        await query('DELETE FROM community_post_topics WHERE post_id=?', [req.params.id])
        if (finalTopicIds.length > 0) {
          for (const tid of finalTopicIds) {
            try { await query('INSERT INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [req.params.id, Number(tid)]) } catch (e) { console.error('[community] topic link failed on edit:', req.params.id, tid, e.message) }
          }
        }
      }

      emitSafe(POST_EVENTS.UPDATED, { postId: Number(req.params.id), userId, fields: Object.keys(req.body).filter(k => k !== 'id') })

      // Notify author when admin edits their post
      if (existing[0].user_id !== userId) {
        const adminNameEdit = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被编辑', `管理员编辑了您的帖子《${title || existing[0].title}》`, 'system', existing[0].user_id, userId, adminNameEdit || '管理员']
        )
      }

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  function cleanupPostContentImages(contentStr, postId) {
    if (!contentStr) return
    try {
      const blocks = JSON.parse(contentStr)
      if (!Array.isArray(blocks)) return
      const urls = []
      for (const block of blocks) {
        if (block.type === 'image' && Array.isArray(block.images)) {
          for (const img of block.images) {
            if (typeof img === 'string' && img.startsWith('http')) urls.push(img)
          }
        }
      }
      if (!urls.length) return
      const { getDefaultStorage } = require('../storage-config.cjs')
      const { deleteFromCloud } = require('../upload.cjs')
      const { updateUserUsedBytes } = require('../../utils/file-helper.cjs')
      getDefaultStorage({ userId: 0, roles: [], levelId: 0, backend: false }).then(storage => {
        if (!storage) return
        for (const url of urls) {
          try {
            const key = new URL(url).pathname.replace(/^\//, '')
            deleteFromCloud(storage, key).catch(() => {})
      } catch (e) { console.error('申请通知发送失败:', e.message) }
        }
      }).catch(() => {})
      for (const url of urls) {
        query('SELECT user_id FROM file_repository WHERE file_path=?', [url]).then(rows => {
          if (rows.length) {
            const uid = rows[0].user_id
            query('DELETE FROM file_repository WHERE file_path=?', [url]).then(() => {
              if (uid) updateUserUsedBytes(uid)
            }).catch(() => {})
          }
        }).catch(() => {})
      }
      console.log(`[community] Cleanup ${urls.length} images from post #${postId}`)
    } catch (e) { console.error('[community] image cleanup failed:', postId, e.message) }
  }

  app.delete('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, section_id, title, content FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = existing[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) return res.json({ code: 403, msg: '无权删除' })

      await query(`UPDATE community_posts SET status='deleted', is_deleted=1, deleted_at=NOW(), update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [existing[0].section_id])

      deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})
      // Also clean up images embedded in post content (uploaded before post creation, ref_id=0)
      cleanupPostContentImages(existing[0].content, req.params.id)

      systemLog('delete', userId, '', 'post', Number(req.params.id),
        `${isPostOwner ? '作者' : '管理员'}删除帖子《${existing[0].title}》`)

      // Notify author when admin deletes their post
      if (!isPostOwner) {
        const adminNameDel = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被删除', `您的帖子《${existing[0].title}》已被管理员删除`, 'post_deleted', existing[0].user_id, userId, adminNameDel || '管理员']
        )
      }

      emitSafe(POST_EVENTS.DELETED, { postId: Number(req.params.id), userId, title: existing[0].title, sectionId: existing[0].section_id })

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/restore', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, is_deleted FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (existing[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可恢复帖子' })

      await query(`UPDATE community_posts SET is_deleted=0, deleted_at=NULL, update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?) AND is_deleted=0', [req.params.id])

      systemLog('restore', userId, '', 'post', Number(req.params.id),
        `恢复帖子《${existing[0].title}》`)

      res.json({ code: 200, msg: '恢复成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.delete('/api/community/post/:id/permanent', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, is_deleted FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isUserAdmin = await isAdmin(userId)
      if (existing[0].user_id !== userId && !isUserAdmin) return res.json({ code: 403, msg: '仅作者或管理员可永久删除帖子' })

      const deleteCondition = isUserAdmin && existing[0].user_id !== userId
        ? 'id=?' : 'id=? AND user_id=?'
      const deleteParams = isUserAdmin && existing[0].user_id !== userId
        ? [req.params.id] : [req.params.id, userId]

      await query(`DELETE FROM community_posts WHERE ${deleteCondition}`, deleteParams)
      await query('DELETE FROM community_likes WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_favorites WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_comments WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_post_topics WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_collection_posts WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_coin_logs WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_unlock_requests WHERE post_id=?', [req.params.id])

      systemLog('permanent_delete', userId, '', 'post', Number(req.params.id),
        `永久删除帖子《${existing[0].title}》`)

      res.json({ code: 200, msg: '永久删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Post Review APIs ====================

  app.get('/api/community/admin/posts/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSections = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSections.length === 0) return res.json({ code: 403, msg: '无权限' })

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      let whereClause = "p.status='pending'"
      const params = []
      if (!isAdminUser && modSections.length > 0) {
        whereClause += ` AND p.section_id IN (${modSections.map(() => '?').join(',')})`
        params.push(...modSections)
      }

      const countResult = await query(`SELECT COUNT(*) as total FROM community_posts p WHERE ${whereClause}`, params)
      const total = countResult[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                CASE WHEN p.user_avatar LIKE 'avatar:%' THEN '' ELSE p.user_avatar END as userAvatar, p.title, p.content, p.images,
                p.has_resource as hasResource, p.resource_type as resourceType,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType, p.hidden_content as hiddenContent,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.extract_code as extractCode, p.free_read as freeRead, p.free_count as freeCount,
                p.create_time as createTime, p.scheduled_time as scheduledTime,
                p.auto_hide_at as autoHideAt,
                TIMESTAMPDIFF(HOUR, p.create_time, NOW()) as waitHours,
                COALESCE((SELECT level FROM community_trust_levels WHERE user_id=p.user_id LIMIT 1), 0) as trustLevel,
                (SELECT COUNT(*) FROM community_reports WHERE target_type='post' AND target_id=p.id AND status='pending') as pendingReports
         FROM community_posts p WHERE ${whereClause}
         ORDER BY 
           CASE WHEN (SELECT COUNT(*) FROM community_reports WHERE target_type='post' AND target_id=p.id AND status='pending') >= 3 THEN 100 ELSE 0 END DESC,
           TIMESTAMPDIFF(HOUR, p.create_time, NOW()) * 10 DESC,
           COALESCE((SELECT level FROM community_trust_levels WHERE user_id=p.user_id), 3) ASC
         LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        params
      )

      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/post/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canReviewModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      const operatorName = await getAdminUserName(req)
      await query(`UPDATE community_posts SET status='published', update_time=${nowExpr}, reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [userId, req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?) AND is_deleted=0', [req.params.id])

      const adminNameAp = await getAdminUserName(req)
      if (post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子审核通过', `您的帖子《${post[0].title}》已通过审核并发布`, 'post_approved', post[0].user_id, userId, adminNameAp || '管理员']
        )
      }
      systemLog('approve', userId, adminNameAp, 'post', Number(req.params.id), `审核通过帖子《${post[0].title}》`)
      await logModeratorAction(0, userId, operatorName, 'approve', 'post', Number(req.params.id), `审核通过《${post[0].title}》`)
      try { await query(
        `INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, operator_id, create_time)
         VALUES ('post',?,'manual_approve','审核通过','manual_review','manual','pending','published',?,NOW())`,
        [req.params.id, userId]
      ) } catch {} 

      res.json({ code: 200, msg: '已通过审核' })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/admin/post/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canReviewModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const { reason = '内容不符合规范' } = req.body
      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      const operatorName = await getAdminUserName(req)
      await query(`UPDATE community_posts SET status='rejected', reject_reason=?, update_time=${nowExpr}, reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [reason, userId, req.params.id])

      const adminNameRj = await getAdminUserName(req)
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
        ['帖子审核未通过', `您的帖子《${post[0].title}》未通过审核，原因：${reason}`, 'post_rejected', post[0].user_id, userId, adminNameRj || '管理员']
      )
      systemLog('reject', userId, adminNameRj, 'post', Number(req.params.id), `驳回帖子《${post[0].title}》，原因：${reason}`)
      await logModeratorAction(0, userId, operatorName, 'reject', 'post', Number(req.params.id), `驳回《${post[0].title}》`)
      try { await query(
        `INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, operator_id, create_time)
         VALUES ('post',?,'manual_reject',?,'manual_review','manual','pending','rejected',?,NOW())`,
        [req.params.id, reason, userId]
      ) } catch {} 

      executePenalty(post[0].user_id, '', 'post_rejected', { reason: reason || '内容违规被驳回' })

      res.json({ code: 200, msg: '已驳回' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Admin APIs ====================

  app.get('/api/community/admin/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  p.title, p.status, p.is_pinned as isPinned, p.is_global_pinned as isGlobalPinned,
                  p.is_essence as isEssence, p.is_hot as isHot, p.custom_badge as customBadge,
                  p.like_count as likeCount, p.comment_count as commentCount,
                  p.view_count as viewCount, p.create_time as createTime
                FROM community_posts p WHERE 1=1`
      const params = []

      if (status) { sql += ' AND p.status=?'; params.push(status) }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY p.id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.put('/api/community/admin/post/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status } = req.body
      if (!status) return res.json({ code: 400, msg: '缺少status参数' })

      await query('UPDATE community_posts SET status=?, update_time=' + nowExpr + ' WHERE id=?', [status, req.params.id])
      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== Post Revision APIs ====================
  app.get('/api/community/post/:id/revisions', async (req, res) => {
    try {
      const postId = Number(req.params.id)
      const revisions = await query(
        `SELECT pr.id, pr.editor_id as editorId, COALESCE(NULLIF(u.nickname,''), u.username, '') as editorName,
                pr.edit_summary as editSummary, pr.version, pr.create_time as createTime
         FROM community_post_revisions pr
         LEFT JOIN users u ON pr.editor_id = u.id
         WHERE pr.post_id=?
         ORDER BY pr.version DESC`,
        [postId]
      )
      res.json({ code: 200, msg: 'success', data: revisions })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/community/post/:id/revisions/:revId', async (req, res) => {
    try {
      const rev = await query(
        'SELECT * FROM community_post_revisions WHERE id=? AND post_id=?',
        [Number(req.params.revId), Number(req.params.id)]
      )
      if (!rev.length) return res.json({ code: 404, msg: '版本不存在' })
      res.json({ code: 200, msg: 'success', data: rev[0] })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/community/post/:id/revisions/:revId/restore', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const postId = Number(req.params.id)
      const post = await query('SELECT id, user_id, title, content, tags FROM community_posts WHERE id=?', [postId])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })

      if (post[0].user_id !== userId && !(await canAccessSection(userId, post[0].section_id)) && !(await isAdminById(userId))) {
        return res.json({ code: 403, msg: '无权恢复版本' })
      }

      const rev = await query(
        'SELECT * FROM community_post_revisions WHERE id=? AND post_id=?',
        [Number(req.params.revId), postId]
      )
      if (!rev.length) return res.json({ code: 404, msg: '版本不存在' })

      // Save current as revision before restoring
      await savePostRevision(postId, userId, post[0].title, post[0].content, post[0].tags, '恢复版本前自动保存')

      await query(
        'UPDATE community_posts SET title=?, content=?, tags=?, update_time=NOW() WHERE id=?',
        [rev[0].title, rev[0].content, rev[0].tags, postId]
      )

      res.json({ code: 200, msg: '已恢复到版本 #' + rev[0].version })
    } catch (e) {
      res.serverError(e)
    }
  })
};

async function cleanupOverduePending() {
  try {
    const result = await query(
      `UPDATE community_posts SET status='rejected' 
       WHERE status='pending' AND is_deleted=0 AND create_time < DATE_SUB(NOW(), INTERVAL 72 HOUR)`
    )
    if (result.affectedRows > 0) {
      console.log(`[moderation] auto-cleanup: ${result.affectedRows} overdue pending posts rejected`)
    }
  } catch (e) {
    console.error('[moderation] cleanup error:', e.message)
        }
      }

module.exports.cleanupOverduePending = cleanupOverduePending
