/**
 * 自动审核管线主控制器
 * 串联四关：敏感词 → 规则引擎 → 内容质量评分 → 经验等级判断
 */

const { query, checkSensitiveWords, getSystemOperator } = require('./community-utils.cjs')
const { executePenalty } = require('../custom-task.cjs')

const CONTENT_TYPE_LABELS = { post: '帖子', comment: '评论', product: '商品' }

function getContentTypeLabel(type) {
  return CONTENT_TYPE_LABELS[type] || type
}

function buildContentDesc(content, contentType) {
  const title = content.title || content.name || ''
  if (title) return `《${title}》`
  const text = content.text || content.content || ''
  if (text) return `「${text.replace(/<[^>]+>/g, '').substring(0, 30)}${text.length > 30 ? '...' : ''}」`
  return ''
}

async function sendModerationNotification(userId, contentType, action, content) {
  try {
    const desc = buildContentDesc(content, contentType)
    const label = getContentTypeLabel(contentType)
    let title, contentText
    if (action === 'rejected') {
      title = `${label}自动审核未通过`
      contentText = `您的${label}${desc}未通过自动审核：内容不符合社区规范`
    } else if (action === 'pending') {
      title = `${label}已提交审核`
      contentText = `您的${label}${desc}已提交自动审核，请耐心等待`
    } else {
      title = `${label}审核通过`
      contentText = `您的${label}${desc}已通过自动审核并发布`
    }
    const typeMap = {
      rejected: `${contentType}_rejected`,
      pending: `${contentType}_pending`,
      published: `${contentType}_approved`
    }
    const sysOp = await getSystemOperator()
    const fromId = sysOp ? sysOp.id : 0
    const fromName = sysOp ? (sysOp.username || '系统') : '系统'
    await query(
      `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
      [title, contentText, typeMap[action], userId, fromId, fromName]
    )
  } catch (e) {
    console.error('[moderation] notification send failed:', e.message)
  }
}

/** 获取用户经验等级 */
async function getUserLevel(userId) {
  try {
    const [row] = await query('SELECT experience FROM users WHERE id=?', [userId])
    if (!row) return 0
    const [lv] = await query(
      'SELECT level FROM experience_levels WHERE exp_required <= ? ORDER BY exp_required DESC LIMIT 1',
      [row.experience || 0]
    )
    return lv ? lv.level : 0
  } catch { return 0 }
}

/** 第二关：规则审核器 */
async function runRuleEngine(userId, content, targetType) {
  try {
    const rules = await query(
      "SELECT name, config, action FROM moderation_rules WHERE enabled=1 AND target_type=?", [targetType]
    )
    if (!rules.length) return { passed: true, blocked: false, results: [] }

    const violations = []
    for (const rule of rules) {
      let config
      try { config = typeof rule.config === 'string' ? JSON.parse(rule.config) : rule.config } catch { continue }
      const result = await checkRule(rule.name, userId, content, config, targetType)
      if (result) {
        const action = rule.action || 'pending'
        violations.push({ name: rule.name, reason: result.reason, action })
      }
    }

    if (violations.length > 0) {
      const hasBlock = violations.some(v => v.action === 'block')
      return { passed: false, blocked: hasBlock, results: violations, reason: violations[0].reason }
    }

    return { passed: true, blocked: false, results: [] }
  } catch (e) {
    console.error('[moderation] rule engine error:', e.message)
    return { passed: true, blocked: false, results: [] }
  }
}

/** 单条规则检查 */
async function checkRule(name, userId, content, config, targetType) {
  const now = new Date()
  const text = typeof content === 'string' ? content : (content.text || content.content || content.title || content.description || '')
  switch (name) {
    case 'post_rate_limit':
      return await checkRateLimit(userId, 'post', config.maxCount || 5, config.windowMinutes || 5, now)
    case 'comment_rate_limit':
      return await checkRateLimit(userId, 'comment', config.maxCount || 10, config.windowMinutes || 1, now)
    case 'new_user_daily_limit':
      return await checkNewUserLimit(userId, config.maxCount || 10, now)
    case 'short_url_block':
    case 'short_url_comment':
      return checkShortUrl(text)
    case 'external_links_max':
      return checkExternalLinks(text, config.maxLinks || 5)
    case 'repetitive_chars':
    case 'repetitive_comment':
      return checkRepetitiveChars(text, config.minLength || 10)
    case 'phone_qq_pattern':
    case 'phone_qq_comment':
      return checkPhoneQQ(text)
    case 'emoji_bombing':
    case 'emoji_comment':
      return checkEmojiBombing(text, config.maxEmoji || 20)
    case 'min_content_length':
    case 'min_comment_length':
      return checkMinLength(text, config.minLength || 5)
    case 'content_similarity':
      return await checkSimilarity(userId, text, config.threshold || 0.85, now)
    case 'sockpuppet_detection':
      return await checkSockpuppet(userId, config.maxAccounts || 3, now)
    case 'attachment_scan':
      return null
    default:
      return null
  }
}

/** 频率限制检查 */
async function checkRateLimit(userId, type, maxCount, windowMinutes, now) {
  const table = type === 'post' ? 'community_posts' : 'community_comments'
  const [row] = await query(
    `SELECT COUNT(*) as cnt FROM ${table} WHERE user_id=? AND create_time >= DATE_SUB(?, INTERVAL ? MINUTE)`,
    [userId, now, windowMinutes]
  )
  if (row && row.cnt >= maxCount) {
    return { name: `${type}_rate_limit`, reason: `${windowMinutes}分钟内${type === 'post' ? '发帖' : '评论'}${row.cnt}次，超过上限${maxCount}次`, action: 'pending' }
  }
  return null
}

/** 新用户日限制 */
async function checkNewUserLimit(userId, maxCount, now) {
  const [user] = await query('SELECT create_time FROM users WHERE id=?', [userId])
  if (!user) return null
  const hoursSinceRegister = (now - new Date(user.create_time)) / 3600000
  if (hoursSinceRegister >= 24) return null
  const [row] = await query(
    'SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND create_time >= CURDATE()', [userId]
  )
  if (row && row.cnt >= maxCount) {
    return { name: 'new_user_daily_limit', reason: `新用户当日发帖${row.cnt}篇，超过上限${maxCount}篇`, action: 'pending' }
  }
  return null
}

/** 短链接检测 */
function checkShortUrl(text) {
  const patterns = ['bit.ly', 't.cn', 'dwz.cn', 'suo.im', 'shorturl.at', 'tinyurl.com', 'is.gd', 'ow.ly', 'buff.ly']
  for (const p of patterns) {
    if (text.toLowerCase().includes(p)) {
      return { name: 'short_url_block', reason: `内容包含短链接: ${p}`, action: 'block' }
    }
  }
  return null
}

/** 外链数量检测 */
function checkExternalLinks(text, maxLinks) {
  const urlPattern = /https?:\/\/[^\s]{3,}/gi
  const matches = text.match(urlPattern) || []
  // 排除以下白名单域名
  const whitelist = ['monkeycode-ai.online', 'localhost']
  const external = matches.filter(u => !whitelist.some(d => u.includes(d)))
  if (external.length > maxLinks) {
    return { name: 'external_links_max', reason: `内容包含${external.length}个外链，超过上限${maxLinks}个`, action: 'pending' }
  }
  return null
}

/** 连续重复字符检测 */
function checkRepetitiveChars(text, minLength) {
  const match = text.match(/(.)\1{9,}/)
  if (match && match[0].length >= minLength) {
    return { name: 'repetitive_chars', reason: `内容包含连续重复字符超过${minLength}个`, action: 'pending' }
  }
  return null
}

/** 手机号/QQ号检测 */
function checkPhoneQQ(text) {
  const phonePattern = /1[3-9]\d{9}/
  const qqPattern = /[Qq]{2}[:：]?\s*\d{5,12}/
  if (phonePattern.test(text)) {
    return { name: 'phone_qq_pattern', reason: '内容疑似包含手机号', action: 'pending' }
  }
  if (qqPattern.test(text)) {
    return { name: 'phone_qq_pattern', reason: '内容疑似包含QQ号', action: 'pending' }
  }
  return null
}

/** Emoji刷屏检测 */
function checkEmojiBombing(text, maxEmoji) {
  const emojiPattern = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu
  const matches = text.match(emojiPattern) || []
  if (matches.length > maxEmoji) {
    return { name: 'emoji_bombing', reason: `内容包含${matches.length}个emoji，超过上限${maxEmoji}个`, action: 'pending' }
  }
  return null
}

/** 最小内容长度 */
function checkMinLength(text, minLength) {
  const cleaned = text.replace(/\s+/g, '').replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, '')
  if (cleaned.length < minLength) {
    return { name: 'min_content_length', reason: `有效内容长度${cleaned.length}，低于${minLength}字符`, action: 'pending' }
  }
  return null
}

/** Jaccard相似度检测 */
async function checkSimilarity(userId, text, threshold, now) {
  try {
    const recent = await query(
      'SELECT title, content FROM community_posts WHERE user_id=? ORDER BY create_time DESC LIMIT 3',
      [userId]
    )
    if (!recent.length) return null

    const currentWords = new Set(text.replace(/<[^>]+>/g, '').split(/[\s,，。；;.!！?？、]+/).filter(w => w.length > 0))
    for (const r of recent) {
      const existingText = (r.title || '') + ' ' + (r.content || '')
      const existingWords = new Set(existingText.replace(/<[^>]+>/g, '').split(/[\s,，。；;.!！?？、]+/).filter(w => w.length > 0))
      const intersection = [...currentWords].filter(w => existingWords.has(w)).length
      const union = new Set([...currentWords, ...existingWords]).size
      const similarity = union > 0 ? intersection / union : 0
      if (similarity >= threshold) {
        return { name: 'content_similarity', reason: `内容与历史帖子相似度${(similarity*100).toFixed(0)}%，超过${(threshold*100).toFixed(0)}%`, action: 'pending' }
      }
    }
  } catch {}
  return null
}

/** 马甲号检测 */
async function checkSockpuppet(userId, maxAccounts, now) {
  try {
    const [user] = await query('SELECT register_ip FROM users WHERE id=?', [userId])
    if (!user || !user.register_ip) return null
    const [row] = await query(
      'SELECT COUNT(*) as cnt FROM users WHERE register_ip=? AND create_time >= DATE_SUB(?, INTERVAL 24 HOUR)',
      [user.register_ip, now]
    )
    if (row && row.cnt >= maxAccounts) {
      return { name: 'sockpuppet_detection', reason: `同IP 24小时内注册${row.cnt}个账号`, action: 'pending' }
    }
  } catch {}
  return null
}

/** 第三关：内容质量评分（从 DB 动态读取维度配置） */
async function scoreContent(content, targetType, userLevel) {
  const dims = await query('SELECT * FROM quality_score_dims WHERE target_type=? AND enabled=1 ORDER BY sort_order', [targetType])
  const thresholdRows = await query('SELECT config_key, config_value FROM quality_score_config')

  const thresholdMap = {}
  if (thresholdRows && Array.isArray(thresholdRows)) {
    thresholdRows.forEach(t => { thresholdMap[t.config_key] = parseFloat(t.config_value) })
  }

  let totalScore = 0
  let maxScore = 0
  const details = {}

  for (const dim of dims) {
    const rules = (() => { try { return typeof dim.rules === 'string' ? JSON.parse(dim.rules) : (dim.rules || []) } catch { return [] } })()
    let dimScore = 0
    const ext = { textLen: 0, imgCount: 0, urlCount: 0, titleLen: 0, userLevel, hasTitle: false, hasParagraphs: false, hasList: false, nameLen: 0, descLen: 0, scrCount: 0, hasImage: false, price: 0 }

    // 预计算通用字段
    if (dim.dim_key === 'textLength') {
      ext.textLen = (content.content || '').replace(/<[^>]+>/g, '').replace(/\s+/g, '').length
    } else if (dim.dim_key === 'images') {
      ext.imgCount = (content.images || content.imageUrls || []).length
    } else if (dim.dim_key === 'layout') {
      ext.hasTitle = !!(content.title && content.title.length >= 2)
      ext.hasParagraphs = (content.content || '').split(/\n{2,}/).length >= 3
      ext.hasList = /^[\-\*\d]+[\.\、]/.test(content.content || '')
    } else if (dim.dim_key === 'links') {
      ext.urlCount = (content.content || '').match(/https?:\/\/[^\s]{3,}/gi)?.length || 0
    } else if (dim.dim_key === 'title') {
      ext.titleLen = (content.title || '').length
    } else if (dim.dim_key === 'level') {
      ext.userLevel = userLevel
    } else if (dim.dim_key === 'name') {
      ext.nameLen = (content.name || '').length
    } else if (dim.dim_key === 'description') {
      ext.descLen = (content.description || '').length
    } else if (dim.dim_key === 'screenshots') {
      ext.scrCount = (content.screenshots || []).length
    } else if (dim.dim_key === 'image') {
      ext.hasImage = !!(content.images && content.images.length > 0)
    } else if (dim.dim_key === 'price') {
      ext.price = Number(content.price) || 0
    }

    for (const rule of rules) {
      const val = ext[rule.field]
      if (val == null) continue
      let matched = false
      if (rule.cond === 'ge') matched = val >= rule.val
      else if (rule.cond === 'le') matched = val <= rule.val
      else if (rule.cond === 'eq') matched = val === rule.val
      else if (rule.cond === 'flag') matched = !!val
      else if (rule.cond === 'range') matched = val >= (rule.min || -Infinity) && val <= (rule.max || Infinity)
      else if (rule.cond === 'per') { dimScore = Math.min(val * rule.val, rule.cap || dim.max_score || 999); break }
      if (matched) { dimScore = rule.score; break }
    }

    totalScore += Math.min(dimScore, dim.max_score || 0)
    maxScore += dim.max_score || 0
    details[dim.dim_key] = { score: Math.min(dimScore, dim.max_score || 0), max: dim.max_score || 0 }
  }

  const rate = maxScore > 0 ? totalScore / maxScore : 0
  const thresholdHigh = thresholdMap.threshold_high != null ? thresholdMap.threshold_high : 0.7
  const thresholdLow = thresholdMap.threshold_low != null ? thresholdMap.threshold_low : 0.4
  let verdict = 'pending'
  let label = '较差'
  if (rate >= thresholdHigh) { verdict = 'pass'; label = '优质' }
  else if (rate >= thresholdLow) { verdict = 'flag'; label = '一般' }

  return { totalScore, maxScore, rate, verdict, label, details }
}

/** 第四关：经验等级判断（从 DB 动态读取矩阵） */
async function getLevelVerdict(userLevel, targetType, hasReviewWord) {
  const [row] = await query('SELECT * FROM level_matrix WHERE target_type=?', [targetType])

  const nightPenalty = row ? row.night_level_penalty : 1
  const nightStart = row ? row.night_start_hour : 0
  const nightEnd = row ? row.night_end_hour : 8
  const reviewVerdict = row ? row.review_word_verdict : 'pending'

  if (hasReviewWord) return reviewVerdict

  const hour = new Date().getHours()
  const isNight = hour >= nightStart && hour < nightEnd
  let effectiveLevel = isNight ? Math.max(0, userLevel - nightPenalty) : userLevel

  let levels = row ? (typeof row.levels === 'string' ? JSON.parse(row.levels) : row.levels) : null
  if (!levels || !Array.isArray(levels)) levels = ['pending','pending','published','published','published']

  const idx = Math.min(effectiveLevel, levels.length - 1)
  return levels[idx] || 'pending'
}

/** 异步写入审核日志 */
async function logModeration(params) {
  try {
    await query(
      `INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,?,?,?,?,?,?,?,?,NULL,NOW())`,
      [params.targetType, params.targetId, params.action, params.reason, params.ruleName,
       params.moderatorType, params.oldStatus || '', params.newStatus || '', params.details || '']
    )
  } catch (e) {
    console.error('[moderation] log write failed:', e.message)
  }
}

/** 主审核管线 */
async function moderationPipeline(userId, content, targetType, extra = {}) {
  const logs = []
  let finalStatus = null
  let finalReason = null

  try {
    // 第一关：敏感词过滤器
    const sensitiveResult = await checkSensitiveWords(content.text || content.content || content.title || content.description || '')
    if (sensitiveResult.level === 'block') {
      finalStatus = 'blocked'
      finalReason = '内容包含违规信息，无法发布'
      const details = JSON.stringify({ matchedWords: sensitiveResult.words.map(w => w.word) })
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_reject',?,?,?,?,'','blocked',?,NULL,NOW())`,
       [targetType, finalReason, 'sensitive_word', 'sensitive_word', '', details])
        .catch(() => {})
      executePenalty(userId, '', 'block_word_triggered', {})
      sendModerationNotification(userId, targetType, 'rejected', content)
      return { action: 'reject', status: 'blocked', reason: finalReason, logs: [{ level: 'block', stage: 'sensitive_word', detail: sensitiveResult.words[0].word }] }
    }

    if (sensitiveResult.level === 'review') {
      logs.push({ level: 'review', stage: 'sensitive_word', detail: sensitiveResult.words.map(w => w.word).join(', ') })
    } else if (sensitiveResult.level === 'warn') {
      logs.push({ level: 'warn', stage: 'sensitive_word', detail: sensitiveResult.words.map(w => w.word).join(', ') })
    } else {
      logs.push({ level: 'pass', stage: 'sensitive_word' })
    }

    // 第二关：规则审核器
    const ruleResult = await runRuleEngine(userId, content, targetType)
    if (ruleResult && !ruleResult.passed) {
      if (ruleResult.blocked) {
        finalStatus = 'blocked'
        finalReason = '内容不符合社区规范'
        query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
         VALUES (?,0,'auto_reject',?,?,?,'','blocked',?,NULL,NOW())`,
          [targetType, finalReason, ruleResult.reason || '', 'rule_engine', JSON.stringify(ruleResult)])
          .catch(() => {})
        sendModerationNotification(userId, targetType, 'rejected', content)
        return { action: 'reject', status: 'blocked', reason: finalReason, logs: [...logs, { level: 'block', stage: 'rule_engine', detail: ruleResult.reason }] }
      } else {
        logs.push({ level: 'pending', stage: 'rule_engine', detail: ruleResult.reason })
        finalStatus = 'pending'
        finalReason = ruleResult.reason || '规则审核待处理'
      }
    } else {
      logs.push({ level: 'pass', stage: 'rule_engine' })
    }

    // 如果规则引擎已经标记 pending 且质量评分也低，直接返回
    if (finalStatus === 'pending' && ruleResult && !ruleResult.passed && !ruleResult.blocked) {
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_pending',?,?,?,'','pending',?,NULL,NOW())`,
        [targetType, finalReason, 'rule_engine', 'rule_engine', JSON.stringify(ruleResult)])
         .catch(() => {})
      sendModerationNotification(userId, targetType, 'pending', content)
      return { action: 'pending', status: 'pending', reason: finalReason, logs }
    }

    // 第三关：内容质量评分
    const userLevel = await getUserLevel(userId)
    const scoreResult = await scoreContent(content, targetType, userLevel)
    let qualityStatus = scoreResult.verdict
    if (qualityStatus === 'pending') {
      logs.push({ level: 'pending', stage: 'quality_score', detail: `${scoreResult.totalScore}/${scoreResult.maxScore}分(${scoreResult.label})` })
      // 强制待审
      finalStatus = 'pending'
      finalReason = `内容质量评分${scoreResult.totalScore}/${scoreResult.maxScore}，低于标准`
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_pending',?,?,?,'','pending',?,NULL,NOW())`,
       [targetType, finalReason, 'quality_threshold', 'quality_score', JSON.stringify(scoreResult)])
         .catch(() => {})
      sendModerationNotification(userId, targetType, 'pending', content)
      return { action: 'pending', status: 'pending', reason: finalReason, score: scoreResult, logs }
    }
    logs.push({ level: scoreResult.verdict === 'pass' ? 'pass' : 'flag', stage: 'quality_score',
      detail: `${scoreResult.totalScore}/${scoreResult.maxScore}分(${scoreResult.label})` })

    // 第四关：经验等级判断
    const hasReviewWord = sensitiveResult.level === 'review'
    const levelVerdict = await getLevelVerdict(userLevel, targetType, hasReviewWord)
    finalStatus = levelVerdict
    finalReason = levelVerdict === 'published' ? null : `用户等级Lv.${userLevel}，内容需人工审核`

    logs.push({ level: levelVerdict === 'published' ? 'pass' : 'pending', stage: 'level_check',
      detail: `Lv.${userLevel} → ${levelVerdict}` })

    if (finalStatus === 'published') {
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_approve','自动审核通过','level_pass','level_check','pending','published',?,NULL,NOW())`,
       [targetType, JSON.stringify({ userLevel, score: scoreResult })])
        .catch(() => {})
      sendModerationNotification(userId, targetType, 'published', content)
      return { action: 'publish', status: 'published', score: scoreResult, logs }
    }

    query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_pending',?,?,'level_check','','pending',?,NULL,NOW())`,
       [targetType, finalReason, 'level_threshold', JSON.stringify({ userLevel, targetType })])
        .catch(() => {})

    sendModerationNotification(userId, targetType, 'pending', content)
    return { action: 'pending', status: 'pending', reason: finalReason, score: scoreResult, logs }
  } catch (e) {
    console.error('[moderation] pipeline error:', e.message)
    sendModerationNotification(userId, targetType, 'pending', content)
    return { action: 'pending', status: 'pending', reason: '审核系统异常，转人工审核', error: e.message }
  }
}

module.exports = {
  moderationPipeline,
  getUserLevel,
  scoreContent,
  getLevelVerdict,
  logModeration,
  checkSensitiveWords
}
