/**
 * 自动审核管线主控制器
 * 串联四关：敏感词 → 规则引擎 → 内容质量评分 → 经验等级判断
 */

const { query, checkSensitiveWords } = require('./community-utils.cjs')

/** 获取用户经验等级 */
async function getUserLevel(userId) {
  try {
    const [row] = await query('SELECT experience FROM users WHERE id=?', [userId])
    if (!row) return 0
    const [lv] = await query(
      'SELECT level FROM experience_levels WHERE exp_required <= ? ORDER BY exp_required DESC LIMIT 1',
      [row.experience || 0]
    )
    return lv ? lv.level : 0
  } catch { return 0 }
}

/** 第二关：规则审核器 */
async function runRuleEngine(userId, content, targetType) {
  try {
    const rules = await query(
      "SELECT name, config, action FROM moderation_rules WHERE enabled=1 AND target_type=?", [targetType]
    )
    if (!rules.length) return { passed: true }

    for (const rule of rules) {
      let config
      try { config = typeof rule.config === 'string' ? JSON.parse(rule.config) : rule.config } catch { continue }
      const result = await checkRule(rule.name, userId, content, config, targetType)
      if (result) {
        const action = rule.action || 'pending'
        handleRuleBlock(result.name, result.reason, action)
      }
    }

    return { passed: true }
  } catch (e) {
    console.error('[moderation] rule engine error:', e.message)
    return { passed: true } // fail-open
  }
}

/** 单条规则检查 */
async function checkRule(name, userId, content, config, targetType) {
  const now = new Date()
  switch (name) {
    case 'post_rate_limit':
      return await checkRateLimit(userId, 'post', config.maxCount || 5, config.windowMinutes || 5, now)
    case 'comment_rate_limit':
      return await checkRateLimit(userId, 'comment', config.maxCount || 10, config.windowMinutes || 1, now)
    case 'new_user_daily_limit':
      return await checkNewUserLimit(userId, config.maxCount || 10, now)
    case 'short_url_block':
      return checkShortUrl(content)
    case 'external_links_max':
      return checkExternalLinks(content, config.maxLinks || 5)
    case 'repetitive_chars':
      return checkRepetitiveChars(content, config.minLength || 10)
    case 'phone_qq_pattern':
      return checkPhoneQQ(content)
    case 'emoji_bombing':
      return checkEmojiBombing(content, config.maxEmoji || 20)
    case 'min_content_length':
      return checkMinLength(content, config.minLength || 5)
    case 'content_similarity':
      return await checkSimilarity(userId, content, config.threshold || 0.85, now)
    case 'sockpuppet_detection':
      return await checkSockpuppet(userId, config.maxAccounts || 3, now)
    default:
      return null
  }
}

/** 频率限制检查 */
async function checkRateLimit(userId, type, maxCount, windowMinutes, now) {
  const table = type === 'post' ? 'community_posts' : 'community_comments'
  const [row] = await query(
    `SELECT COUNT(*) as cnt FROM ${table} WHERE user_id=? AND create_time >= DATE_SUB(?, INTERVAL ? MINUTE)`,
    [userId, now, windowMinutes]
  )
  if (row && row.cnt >= maxCount) {
    return { name: `${type}_rate_limit`, reason: `${windowMinutes}分钟内${type === 'post' ? '发帖' : '评论'}${row.cnt}次，超过上限${maxCount}次`, action: 'pending' }
  }
  return null
}

/** 新用户日限制 */
async function checkNewUserLimit(userId, maxCount, now) {
  const [user] = await query('SELECT create_time FROM users WHERE id=?', [userId])
  if (!user) return null
  const hoursSinceRegister = (now - new Date(user.create_time)) / 3600000
  if (hoursSinceRegister >= 24) return null
  const [row] = await query(
    'SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND create_time >= CURDATE()', [userId]
  )
  if (row && row.cnt >= maxCount) {
    return { name: 'new_user_daily_limit', reason: `新用户当日发帖${row.cnt}篇，超过上限${maxCount}篇`, action: 'pending' }
  }
  return null
}

/** 短链接检测 */
function checkShortUrl(text) {
  const patterns = ['bit.ly', 't.cn', 'dwz.cn', 'suo.im', 'shorturl.at', 'tinyurl.com', 'is.gd', 'ow.ly', 'buff.ly']
  for (const p of patterns) {
    if (text.toLowerCase().includes(p)) {
      return { name: 'short_url_block', reason: `内容包含短链接: ${p}`, action: 'block' }
    }
  }
  return null
}

/** 外链数量检测 */
function checkExternalLinks(text, maxLinks) {
  const urlPattern = /https?:\/\/[^\s]{3,}/gi
  const matches = text.match(urlPattern) || []
  // 排除以下白名单域名
  const whitelist = ['monkeycode-ai.online', 'localhost']
  const external = matches.filter(u => !whitelist.some(d => u.includes(d)))
  if (external.length > maxLinks) {
    return { name: 'external_links_max', reason: `内容包含${external.length}个外链，超过上限${maxLinks}个`, action: 'pending' }
  }
  return null
}

/** 连续重复字符检测 */
function checkRepetitiveChars(text, minLength) {
  const match = text.match(/(.)\1{9,}/)
  if (match && match[0].length >= minLength) {
    return { name: 'repetitive_chars', reason: `内容包含连续重复字符超过${minLength}个`, action: 'pending' }
  }
  return null
}

/** 手机号/QQ号检测 */
function checkPhoneQQ(text) {
  const phonePattern = /1[3-9]\d{9}/
  const qqPattern = /[Qq]{2}[:：]?\s*\d{5,12}/
  if (phonePattern.test(text)) {
    return { name: 'phone_qq_pattern', reason: '内容疑似包含手机号', action: 'pending' }
  }
  if (qqPattern.test(text)) {
    return { name: 'phone_qq_pattern', reason: '内容疑似包含QQ号', action: 'pending' }
  }
  return null
}

/** Emoji刷屏检测 */
function checkEmojiBombing(text, maxEmoji) {
  const emojiPattern = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu
  const matches = text.match(emojiPattern) || []
  if (matches.length > maxEmoji) {
    return { name: 'emoji_bombing', reason: `内容包含${matches.length}个emoji，超过上限${maxEmoji}个`, action: 'pending' }
  }
  return null
}

/** 最小内容长度 */
function checkMinLength(text, minLength) {
  const cleaned = text.replace(/\s+/g, '').replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, '')
  if (cleaned.length < minLength) {
    return { name: 'min_content_length', reason: `有效内容长度${cleaned.length}，低于${minLength}字符`, action: 'pending' }
  }
  return null
}

/** Jaccard相似度检测 */
async function checkSimilarity(userId, text, threshold, now) {
  try {
    const recent = await query(
      'SELECT title, content FROM community_posts WHERE user_id=? ORDER BY create_time DESC LIMIT 3',
      [userId]
    )
    if (!recent.length) return null

    const currentWords = new Set(text.replace(/<[^>]+>/g, '').split(/[\s,，。；;.!！?？、]+/).filter(w => w.length > 0))
    for (const r of recent) {
      const existingText = (r.title || '') + ' ' + (r.content || '')
      const existingWords = new Set(existingText.replace(/<[^>]+>/g, '').split(/[\s,，。；;.!！?？、]+/).filter(w => w.length > 0))
      const intersection = [...currentWords].filter(w => existingWords.has(w)).length
      const union = new Set([...currentWords, ...existingWords]).size
      const similarity = union > 0 ? intersection / union : 0
      if (similarity >= threshold) {
        return { name: 'content_similarity', reason: `内容与历史帖子相似度${(similarity*100).toFixed(0)}%，超过${(threshold*100).toFixed(0)}%`, action: 'pending' }
      }
    }
  } catch {}
  return null
}

/** 马甲号检测 */
async function checkSockpuppet(userId, maxAccounts, now) {
  try {
    const [user] = await query('SELECT register_ip FROM users WHERE id=?', [userId])
    if (!user || !user.register_ip) return null
    const [row] = await query(
      'SELECT COUNT(*) as cnt FROM users WHERE register_ip=? AND create_time >= DATE_SUB(?, INTERVAL 24 HOUR)',
      [user.register_ip, now]
    )
    if (row && row.cnt >= maxAccounts) {
      return { name: 'sockpuppet_detection', reason: `同IP 24小时内注册${row.cnt}个账号`, action: 'pending' }
    }
  } catch {}
  return null
}

/** 第三关：内容质量评分 */
function scoreContent(content, targetType, userLevel) {
  let totalScore = 0
  let maxScore = 0
  const details = {}

  if (targetType === 'post') {
    maxScore = 100

    // 内容长度
    const textLen = (content.content || '').replace(/<[^>]+>/g, '').replace(/\s+/g, '').length
    if (textLen >= 1000) totalScore += 20
    else if (textLen >= 200) totalScore += 15
    else if (textLen >= 50) totalScore += 10
    details.textLength = { score: textLen >= 50 ? (textLen >= 1000 ? 20 : textLen >= 200 ? 15 : 10) : 0, max: 20 }

    // 图片数量
    const imgCount = (content.images || content.imageUrls || []).length
    if (imgCount >= 4) totalScore += 15
    else if (imgCount >= 2) totalScore += 12
    else if (imgCount >= 1) totalScore += 8
    details.images = { score: imgCount >= 4 ? 15 : imgCount >= 2 ? 12 : imgCount >= 1 ? 8 : 0, max: 15 }

    // 排版结构
    const hasTitle = content.title && content.title.length >= 2
    const hasParagraphs = (content.content || '').split(/\n{2,}/).length >= 3
    const hasList = /^[\-\*\d]+[\.\、]/.test(content.content || '')
    let layoutScore = 0
    if (hasTitle) layoutScore += 5
    if (hasParagraphs) layoutScore += 5
    if (hasList) layoutScore += 5
    totalScore += layoutScore
    details.layout = { score: layoutScore, max: 15 }

    // 外链控制
    const urlCount = (content.content || '').match(/https?:\/\/[^\s]{3,}/gi)?.length || 0
    const linkScore = urlCount === 0 ? 5 : urlCount <= 3 ? 2 : 0
    totalScore += linkScore
    details.links = { score: linkScore, max: 5 }

    // 标题质量
    const titleLen = (content.title || '').length
    const titleScore = titleLen >= 5 && titleLen <= 20 ? 10 : (titleLen < 2 || titleLen > 30) ? 0 : 5
    totalScore += titleScore
    details.title = { score: titleScore, max: 10 }

    // 经验等级
    const levelScore = userLevel >= 4 ? 10 : userLevel >= 2 ? 6 : userLevel >= 1 ? 3 : 0
    totalScore += levelScore
    details.level = { score: levelScore, max: 10 }

  } else if (targetType === 'app') {
    maxScore = 55

    // 名称
    const nameLen = (content.name || '').length
    const nameScore = nameLen >= 3 ? 10 : 0
    totalScore += nameScore
    details.name = { score: nameScore, max: 10 }

    // 描述
    const descLen = (content.description || '').length
    const descScore = descLen >= 20 ? 15 : descLen >= 10 ? 8 : 0
    totalScore += descScore
    details.description = { score: descScore, max: 15 }

    // 截图
    const scrCount = (content.screenshots || []).length
    const scrScore = Math.min(scrCount * 10, 30)
    totalScore += scrScore
    details.screenshots = { score: scrScore, max: 30 }

    // 经验等级
    const levelScore = userLevel >= 3 ? 15 : userLevel >= 2 ? 10 : userLevel >= 1 ? 5 : 0
    totalScore += levelScore
    details.level = { score: levelScore, max: 15 }

  } else if (targetType === 'product') {
    maxScore = 55

    // 名称
    const nameLen = (content.name || '').length
    const nameScore = nameLen >= 3 ? 8 : 0
    totalScore += nameScore
    details.name = { score: nameScore, max: 8 }

    // 描述
    const descLen = (content.description || '').length
    const descScore = descLen >= 30 ? 15 : descLen >= 10 ? 7 : 0
    totalScore += descScore
    details.description = { score: descScore, max: 15 }

    // 主图
    const hasImage = !!(content.images && content.images.length > 0)
    const imgScore = hasImage ? 12 : 0
    totalScore += imgScore
    details.image = { score: imgScore, max: 12 }

    // 定价
    const price = Number(content.price) || 0
    const priceScore = price > 0 && price <= 100000 ? 10 : 0
    totalScore += priceScore
    details.price = { score: priceScore, max: 10 }

    // 经验等级
    const levelScore = userLevel >= 3 ? 12 : userLevel >= 2 ? 8 : userLevel >= 1 ? 5 : 0
    totalScore += levelScore
    details.level = { score: levelScore, max: 12 }
  }

  const rate = maxScore > 0 ? totalScore / maxScore : 0
  let verdict = 'pending'
  let label = '较差'
  if (rate >= 0.7) { verdict = 'pass'; label = '优质' }
  else if (rate >= 0.4) { verdict = 'flag'; label = '一般' }

  return { totalScore, maxScore, rate, verdict, label, details }
}

/** 第四关：经验等级判断 */
function getLevelVerdict(userLevel, targetType, hasReviewWord) {
  if (hasReviewWord) return 'pending'

  const isNight = (() => {
    const hour = new Date().getHours()
    return hour >= 0 && hour < 8
  })()
  let effectiveLevel = isNight ? Math.max(0, userLevel - 1) : userLevel

  const matrix = {
    post:     [ 'pending', 'pending',  'published', 'published', 'published' ],
    comment:  [ 'pending', 'published','published', 'published', 'published' ],
    edit:     [ 'pending', 'pending',  'published', 'published', 'published' ],
    app:      [ 'pending', 'pending',  'pending',   'pending',   'published' ],
    product:  [ 'draft',   'draft',    'pending_review', 'published', 'published' ],
  }

  const typeMatrix = matrix[targetType]
  if (!typeMatrix) return 'pending'

  const idx = Math.min(effectiveLevel, typeMatrix.length - 1)
  return typeMatrix[idx]
}

/** 异步写入审核日志 */
async function logModeration(params) {
  try {
    await query(
      `INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,?,?,?,?,?,?,?,?,NULL,NOW())`,
      [params.targetType, params.targetId, params.action, params.reason, params.ruleName,
       params.moderatorType, params.oldStatus || '', params.newStatus || '', params.details || '']
    )
  } catch (e) {
    console.error('[moderation] log write failed:', e.message)
  }
}

/** 主审核管线 */
async function moderationPipeline(userId, content, targetType, extra = {}) {
  const logs = []
  let finalStatus = null
  let finalReason = null

  try {
    // 第一关：敏感词过滤器
    const sensitiveResult = await checkSensitiveWords(content.text || content.content || content.title || content.description || '')
    if (sensitiveResult.level === 'block') {
      finalStatus = 'blocked'
      finalReason = '内容包含违规信息，无法发布'
      const details = JSON.stringify({ matchedWords: sensitiveResult.words.map(w => w.word) })
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_reject',?,?,?,?,'','blocked',?,NULL,NOW())`,
       [targetType, finalReason, 'sensitive_word', 'sensitive_word', '', details])
        .catch(() => {})
      return { action: 'reject', status: 'blocked', reason: finalReason, logs: [{ level: 'block', stage: 'sensitive_word', detail: sensitiveResult.words[0].word }] }
    }

    if (sensitiveResult.level === 'review') {
      logs.push({ level: 'review', stage: 'sensitive_word', detail: sensitiveResult.words.map(w => w.word).join(', ') })
    } else if (sensitiveResult.level === 'warn') {
      logs.push({ level: 'warn', stage: 'sensitive_word', detail: sensitiveResult.words.map(w => w.word).join(', ') })
    } else {
      logs.push({ level: 'pass', stage: 'sensitive_word' })
    }

    // 第二关：规则审核器
    const ruleResult = await runRuleEngine(userId, content, targetType)
    if (ruleResult && ruleResult.blocked) {
      finalStatus = 'blocked'
      finalReason = '内容不符合社区规范'
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_reject',?,?,?,'','blocked',?,NULL,NOW())`,
       [targetType, finalReason, ruleResult.reason || '', 'rule_engine', JSON.stringify(ruleResult)])
        .catch(() => {})
      return { action: 'reject', status: 'blocked', reason: finalReason, logs: [...logs, { level: 'block', stage: 'rule_engine', detail: ruleResult.reason }] }
    }
    logs.push({ level: 'pass', stage: 'rule_engine' })

    // 第三关：内容质量评分
    const userLevel = await getUserLevel(userId)
    const scoreResult = scoreContent(content, targetType, userLevel)
    let qualityStatus = scoreResult.verdict
    if (qualityStatus === 'pending') {
      logs.push({ level: 'pending', stage: 'quality_score', detail: `${scoreResult.totalScore}/${scoreResult.maxScore}分(${scoreResult.label})` })
      // 强制待审
      finalStatus = 'pending'
      finalReason = `内容质量评分${scoreResult.totalScore}/${scoreResult.maxScore}，低于标准`
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_pending',?,?,?,'','pending',?,NULL,NOW())`,
       [targetType, finalReason, 'quality_threshold', 'quality_score', JSON.stringify(scoreResult)])
        .catch(() => {})
      return { action: 'pending', status: 'pending', reason: finalReason, score: scoreResult, logs }
    }
    logs.push({ level: scoreResult.verdict === 'pass' ? 'pass' : 'flag', stage: 'quality_score',
      detail: `${scoreResult.totalScore}/${scoreResult.maxScore}分(${scoreResult.label})` })

    // 第四关：经验等级判断
    const hasReviewWord = sensitiveResult.level === 'review'
    const levelVerdict = getLevelVerdict(userLevel, targetType, hasReviewWord)
    finalStatus = levelVerdict
    finalReason = levelVerdict === 'published' ? null : `用户等级Lv.${userLevel}，内容需人工审核`

    logs.push({ level: levelVerdict === 'published' ? 'pass' : 'pending', stage: 'level_check',
      detail: `Lv.${userLevel} → ${levelVerdict}` })

    if (finalStatus === 'published') {
      query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_approve','自动审核通过','level_pass','level_check','pending','published',?,NULL,NOW())`,
       [targetType, JSON.stringify({ userLevel, score: scoreResult })])
        .catch(() => {})
      return { action: 'publish', status: 'published', score: scoreResult, logs }
    }

    query(`INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, details, operator_id, create_time)
       VALUES (?,0,'auto_pending',?,?,'level_check','','pending',?,NULL,NOW())`,
       [targetType, finalReason, 'level_threshold', JSON.stringify({ userLevel, targetType })])
        .catch(() => {})

    return { action: 'pending', status: 'pending', reason: finalReason, score: scoreResult, logs }
  } catch (e) {
    console.error('[moderation] pipeline error:', e.message)
    // fail-open: 异常时回退为人工审核
    return { action: 'pending', status: 'pending', reason: '审核系统异常，转人工审核', error: e.message }
  }
}

module.exports = {
  moderationPipeline,
  getUserLevel,
  scoreContent,
  getLevelVerdict,
  logModeration,
  checkSensitiveWords
}
