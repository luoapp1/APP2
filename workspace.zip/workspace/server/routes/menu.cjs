const { query } = require('../database.cjs')
const nowExpr = 'NOW()'
const { systemLog } = require('../middleware/security.cjs')
const { authRequired, requirePermission } = require('./system.cjs')

function getUserInfo(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  return { userId: 0, userName: token ? 'admin' : 'system' }
}

async function logAction(req, type, targetType, targetId, detail) {
  const { userId, userName } = getUserInfo(req)
  const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
  await systemLog(type, userId, userName, targetType, targetId, detail, ip)
}

function menuRoutes(router) {
  // GET /api/menu/list — flat list
  router.get('/api/menu/list', async (req, res) => {
    try {
      const rows = await query(
        `SELECT id, parent_id as parentId, name, path, component, redirect, title, icon,
                sort_order as sortOrder, is_hidden as isHidden, is_full_page as isFullPage,
                is_keep_alive as isKeepAlive, is_fixed_tab as isFixedTab, auth_list as authList,
                roles, enabled, mobile_path as mobilePath, icon_bg as iconBg, icon_svg as iconSvg,
                category, create_time as createTime, update_time as updateTime
         FROM menus ORDER BY sort_order, id`
      )
      const list = rows.map(r => {
        try { r.authList = r.authList ? JSON.parse(r.authList) : null } catch { r.authList = null }
        try { r.roles = r.roles ? JSON.parse(r.roles) : null } catch { r.roles = null }
        return r
      })
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/menu/save
  router.post('/api/menu/save', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const { id, parentId, name, path, component, redirect, title, icon, sortOrder,
              isHidden, isFullPage, isKeepAlive, isFixedTab, authList, roles, enabled,
              mobilePath, iconBg, iconSvg, category } = req.body

      if (parentId && Number(parentId) === Number(id)) {
        return res.json({ code: 400, msg: '不能将菜单设置为自己的子菜单' })
      }

      if (id) {
        const oldRows = await query('SELECT * FROM menus WHERE id=?', [id])
        const oldData = oldRows.length ? JSON.stringify(oldRows[0]) : '{}'

        await query(
          `UPDATE menus SET parent_id=?, name=?, path=?, component=?, redirect=?, title=?, icon=?,
           sort_order=?, is_hidden=?, is_full_page=?, is_keep_alive=?, is_fixed_tab=?,
           auth_list=?, roles=?, enabled=?, mobile_path=?, icon_bg=?, icon_svg=?, category=?,
           update_time=${nowExpr} WHERE id=?`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0,
           mobilePath || '', iconBg || '#4ECDC4', iconSvg || '', category || '', id]
        )
        await logAction(req, 'update', 'menu', id,
          `更新菜单"${title || name}"。旧数据:${oldData}`)
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO menus (parent_id, name, path, component, redirect, title, icon,
           sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled,
           mobile_path, icon_bg, icon_svg, category)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [parentId || 0, name, path, component || '', redirect || '', title, icon || '',
           sortOrder || 0, isHidden ? 1 : 0, isFullPage ? 1 : 0, isKeepAlive ? 1 : 0,
           isFixedTab ? 1 : 0, authList ? JSON.stringify(authList) : null,
           roles ? JSON.stringify(roles) : null, enabled !== false ? 1 : 0,
           mobilePath || '', iconBg || '#4ECDC4', iconSvg || '', category || '']
        )
        const newId = result.insertId
        await logAction(req, 'create', 'menu', newId,
          `新建菜单"${title || name}"，路径:${path}`)
        res.json({ code: 200, msg: '新增成功', data: { id: newId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/menu/:id
  router.delete('/api/menu/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const oldRows = await query('SELECT * FROM menus WHERE id=?', [req.params.id])
      const oldData = oldRows.length ? JSON.stringify(oldRows[0]) : '{}'
      const menuName = oldRows.length ? (oldRows[0].title || oldRows[0].name) : String(req.params.id)

      await query('DELETE FROM menus WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
      await query('DELETE FROM role_permissions WHERE menu_id=?', [req.params.id])
      await logAction(req, 'delete', 'menu', Number(req.params.id),
        `删除菜单"${menuName}"。被删除数据:${oldData}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/menu/restore/:logId — 从日志恢复菜单
  router.post('/api/menu/restore/:logId', async (req, res) => {
    try {
      const logRows = await query('SELECT * FROM system_logs WHERE id=?', [Number(req.params.logId)])
      if (!logRows.length) return res.json({ code: 404, msg: '日志记录不存在' })

      const log = logRows[0]
      if (log.target_type !== 'menu') return res.json({ code: 400, msg: '该日志不是菜单操作' })

      const detail = log.detail || ''

      if (log.type === 'update' || log.type === 'delete') {
        const oldMatch = detail.match(/旧数据[：:]\s*(\{[\s\S]*\})/)
        const deletedMatch = detail.match(/被删除数据[：:]\s*(\{[\s\S]*\})/)
        const jsonStr = (oldMatch ? oldMatch[1] : deletedMatch ? deletedMatch[1] : null)
        if (!jsonStr) return res.json({ code: 400, msg: '无法从日志中提取旧数据' })

        const old = JSON.parse(jsonStr)
        const restoreId = old.id

        const existing = await query('SELECT id FROM menus WHERE id=?', [restoreId])
        if (existing.length) {
          await query(
            `UPDATE menus SET parent_id=?, name=?, path=?, component=?, redirect=?, title=?, icon=?,
             sort_order=?, is_hidden=?, is_full_page=?, is_keep_alive=?, is_fixed_tab=?,
             auth_list=?, roles=?, enabled=?, mobile_path=?, icon_bg=?, icon_svg=?, category=?,
             update_time=${nowExpr} WHERE id=?`,
            [old.parent_id || 0, old.name, old.path || '', old.component || '', old.redirect || '',
             old.title, old.icon || '', old.sort_order || 0, old.is_hidden || 0, old.is_full_page || 0,
             old.is_keep_alive !== 0 ? 1 : 0, old.is_fixed_tab || 0, old.auth_list || null,
             old.roles || null, old.enabled !== 0 ? 1 : 0,
             old.mobile_path || '', old.icon_bg || '#4ECDC4', old.icon_svg || '', old.category || '',
             restoreId]
          )
          await logAction(req, 'restore', 'menu', restoreId,
            `通过日志#${log.id}恢复菜单"${old.title || old.name}"`)
          return res.json({ code: 200, msg: '已恢复（更新）', data: { id: restoreId } })
        } else {
          await query(
            `INSERT INTO menus (id, parent_id, name, path, component, redirect, title, icon,
             sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled,
             mobile_path, icon_bg, icon_svg, category, create_time, update_time)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [restoreId, old.parent_id || 0, old.name, old.path || '', old.component || '',
             old.redirect || '', old.title, old.icon || '', old.sort_order || 0, old.is_hidden || 0,
             old.is_full_page || 0, old.is_keep_alive !== 0 ? 1 : 0, old.is_fixed_tab || 0,
             old.auth_list || null, old.roles || null, old.enabled !== 0 ? 1 : 0,
             old.mobile_path || '', old.icon_bg || '#4ECDC4', old.icon_svg || '', old.category || '',
             old.create_time || nowExpr, nowExpr]
          )
          await logAction(req, 'restore', 'menu', restoreId,
            `通过日志#${log.id}恢复已删除菜单"${old.title || old.name}"`)
          return res.json({ code: 200, msg: '已恢复（重建）', data: { id: restoreId } })
        }
      }

      if (log.type === 'create') {
        return res.json({ code: 400, msg: '新建操作无需恢复，如需撤销请删除该菜单' })
      }

      res.json({ code: 400, msg: `不支持的操作类型: ${log.type}` })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/menu/admin-center-cards — 管理员中心卡片数据
  router.get('/api/menu/admin-center-cards', async (_req, res) => {
    try {
      const grouped = {}
      const COLOR_PALETTE = [
        '#FF4757', '#FF6348', '#FF6B81', '#FFA502', '#FFC048',
        '#2ED573', '#7BED9F', '#26DE81', '#1E90FF', '#70A1FF',
        '#5352ED', '#6366F1', '#8B5CF6', '#A855F7', '#C084FC',
        '#EC4899', '#F472B6', '#F43F5E', '#E11D48', '#EF4444',
        '#F97316', '#FB923C', '#F59E0B', '#EAB308', '#84CC16',
        '#22C55E', '#10B981', '#14B8A6', '#06B6D4', '#0EA5E9',
        '#3B82F6', '#6366F1', '#8B5CF6', '#D946EF', '#EC4899',
        '#38BDF8', '#818CF8', '#34D399', '#A3E635', '#FACC15',
        '#FB923C', '#F87171', '#FBBF24', '#A78BFA', '#5EEAD4',
        '#FDBA74', '#93C5FD', '#C4B5FD', '#FCA5A5', '#86EFAC'
      ]

      const parents = await query(
        `SELECT id, name, title FROM menus WHERE parent_id = 0 AND enabled = 1 ORDER BY sort_order, id`
      )
      for (const p of parents) {
        const children = await query(
          `SELECT id, name, title, icon_bg as iconBg, icon_svg as iconSvg,
                  mobile_path as mobilePath, path
           FROM menus WHERE parent_id = ? AND enabled = 1 ORDER BY sort_order, id`,
          [p.id]
        )
        if (children.length > 0) {
          const validChildren = children.filter(c => c.mobilePath)
          if (validChildren.length === 0) continue
          const groupTitle = (p.title && !p.title.startsWith('menus.')) ? p.title : p.name
          grouped[groupTitle] = validChildren.map(c => {
            let label = c.title || c.name
            if (label.startsWith('menus.')) label = c.name
            const hash = (c.id * 31 + (c.name || '').length * 7) % COLOR_PALETTE.length
            return {
              id: c.id,
              label,
              bg: c.iconBg || COLOR_PALETTE[Math.abs(hash)],
              icon: c.iconSvg || '',
              path: c.mobilePath || c.path || ''
            }
          })
        }
      }

      res.json({ code: 200, msg: 'success', data: grouped })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = menuRoutes
