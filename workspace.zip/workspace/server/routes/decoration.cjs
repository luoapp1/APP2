const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('./system.cjs')

const multer = require('multer')
const path = require('path')
const fs = require('fs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

function createDecorUpload(policy) {
  const maxSize = (policy && policy.max_file_size_mb ? policy.max_file_size_mb : 10) * 1024 * 1024
  const allowedTypes = policy ? (policy.allowed_types || '') : ''
  const bannedTypes = policy ? (policy.banned_types || '') : ''

  const { createFileFilter } = require('./upload.cjs')

  return multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, uploadDir),
      filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname) || '.png'
        cb(null, 'decoration-' + Date.now() + '-' + Math.round(Math.random() * 1e9) + ext)
      }
    }),
    limits: { fileSize: maxSize },
    fileFilter: createFileFilter(
      allowedTypes || 'png,jpg,jpeg,webp,gif,svg,json,zip,lottie',
      bannedTypes
    )
  })
}

function init(app) {
  app.get('/api/decoration/list', (req, res) => {
    const type = req.query.type || ''
    if (!type) return res.json({ code: 400, message: '缺少 type 参数' })
    query('SELECT * FROM decorations WHERE type=? AND status="1" ORDER BY sort_order ASC, id DESC', [type])
      .then(rows => res.json({ code: 200, data: rows }))
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  app.get('/api/decoration/all', authRequired, requirePermission('operation:read'), (req, res) => {
    const type = req.query.type || ''
    if (!type) return res.json({ code: 400, message: '缺少 type 参数' })
    query('SELECT d.*, (SELECT COUNT(*) FROM user_decorations ud WHERE ud.decoration_id=d.id) AS user_count FROM decorations d WHERE d.type=? ORDER BY d.sort_order ASC, d.id DESC', [type])
      .then(rows => res.json({ code: 200, data: rows }))
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  app.post('/api/decoration/save', authRequired, requirePermission('operation:write'), (req, res) => {
    const { id, type, name, image_url, preview_url, config_json, css_class, description, duration_days, sort_order, status } = req.body
    if (!type || !name) return res.json({ code: 400, message: 'type 和 name 为必填' })

    const saveData = [
      type, name,
      image_url || '', preview_url || '',
      typeof config_json === 'string' ? config_json : JSON.stringify(config_json || {}),
      css_class || '', description || '',
      duration_days || 0, sort_order || 0,
      status !== undefined ? status : '1'
    ]

    if (id) {
      query(
        'UPDATE decorations SET type=?, name=?, image_url=?, preview_url=?, config_json=?, css_class=?, description=?, duration_days=?, sort_order=?, status=? WHERE id=?',
        [...saveData, id]
      )
        .then(() => res.json({ code: 200, message: '更新成功' }))
        .catch(err => res.json({ code: 500, message: err.message }))
    } else {
      query(
        'INSERT INTO decorations (type, name, image_url, preview_url, config_json, css_class, description, duration_days, sort_order, status) VALUES (?,?,?,?,?,?,?,?,?,?)',
        saveData
      )
        .then(r => res.json({ code: 200, message: '创建成功', data: { id: r.insertId } }))
        .catch(err => res.json({ code: 500, message: err.message }))
    }
  })

  app.delete('/api/decoration/:id', authRequired, requirePermission('operation:write'), (req, res) => {
    const { id } = req.params
    query('SELECT COUNT(*) AS cnt FROM user_decorations WHERE decoration_id=?', [id])
      .then(([row]) => {
        if (row && row.cnt > 0) {
          return res.json({ code: 400, message: `该装饰品已被 ${row.cnt} 个用户购买，无法删除。请先禁用` })
        }
        query('DELETE FROM decorations WHERE id=?', [id])
          .then(() => res.json({ code: 200, message: '删除成功' }))
          .catch(err => res.json({ code: 500, message: err.message }))
      })
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  app.post('/api/decoration/upload', authRequired, requirePermission('upload'), async (req, res, next) => {
    try {
      const { getUserPolicy, getUserId } = require('./upload.cjs')
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}

      const policy = await getUserPolicy(userId, [])
      const upload = createDecorUpload(policy)
      upload.single('file')(req, res, async (err) => {
        if (err) {
          return res.json({ code: 400, message: '上传失败: ' + (err.message || String(err)) })
        }
        try {
          if (!req.file) return res.json({ code: 400, message: '请选择文件' })
          const { resolveUploadPath, recordFileUpload, checkStorageQuota, buildFileDesc, updateUserUsedBytes } = require('./upload.cjs')
          const url = await resolveUploadPath(req.file, req, true)
          const quota = await checkStorageQuota(userId, req.file.size || 0, 'decoration')
          if (!quota.ok) return res.json({ code: 400, message: quota.msg })
          await recordFileUpload({
            userId,
            fileName: req.file.originalname,
            fileUrl: url,
            fileSize: req.file.size || 0,
            fileType: path.extname(req.file.originalname),
            mimeType: req.file.mimetype || '',
            category: 'decoration',
            description: buildFileDesc({ category: 'decoration', refType: 'system' })
          })
          await updateUserUsedBytes(userId, req.file.size || 0)
          res.json({ code: 200, data: { url } })
        } catch (e) {
          res.json({ code: 500, message: '上传失败: ' + (e.message || String(e)) })
        }
      })
    } catch (e) {
      res.json({ code: 500, message: '上传失败: ' + (e.message || String(e)) })
    }
  })

  app.post('/api/decoration/upload-image', authRequired, requirePermission('upload'), async (req, res, next) => {
    try {
      const { getUserPolicy, getUserId } = require('./upload.cjs')
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}

      const policy = await getUserPolicy(userId, [])
      const upload = createDecorUpload(policy)
      upload.single('file')(req, res, async (err) => {
        if (err) {
          return res.json({ code: 400, message: '上传失败: ' + (err.message || String(err)) })
        }
        try {
          if (!req.file) return res.json({ code: 400, message: '请选择文件' })
          const { resolveUploadPath } = require('./upload.cjs')
          const url = await resolveUploadPath(req.file, req, true)
          res.json({ code: 200, data: { url } })
        } catch (e) {
          res.json({ code: 500, message: '上传失败: ' + (e.message || String(e)) })
        }
      })
    } catch (e) {
      res.json({ code: 500, message: '上传失败: ' + (e.message || String(e)) })
    }
  })
}

module.exports = { init }
