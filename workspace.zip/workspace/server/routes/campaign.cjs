const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')
const { executePenalty } = require('./custom-task.cjs')

function campaignRoutes(router) {

  router.get('/api/campaign/list', async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 10
      const offset = (page - 1) * pageSize

      const list = await query(
        `SELECT id, name, type, status, start_time as startTime, end_time as endTime,
                cover_url as coverUrl, description, max_participants as maxParticipants,
                participant_count as participantCount, create_time as createTime
         FROM campaigns ORDER BY id DESC LIMIT ? OFFSET ?`,
        [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM campaigns')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/campaign/:id', async (req, res) => {
    try {
      const campaign = await query(
        `SELECT id, name, type, status, start_time as startTime, end_time as endTime,
                cover_url as coverUrl, description, page_title as pageTitle,
                page_content as pageContent, rules, rewards,
                max_participants as maxParticipants, participant_count as participantCount,
                create_time as createTime
         FROM campaigns WHERE id=?`, [Number(req.params.id)]
      )
      if (!campaign || campaign.length === 0) {
        return res.json({ code: 404, msg: '活动不存在' })
      }
      res.json({ code: 200, msg: 'success', data: campaign[0] })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/campaign/save', authRequired, async (req, res) => {
    try {
      const { id, name, type, startTime, endTime, coverUrl, description, pageTitle, pageContent, rules, rewards, maxParticipants } = req.body
      if (!name) return res.json({ code: 400, msg: '名称不能为空' })

      const rewardsStr = typeof rewards === 'string' ? rewards : JSON.stringify(rewards || {})

      if (id) {
        await query(
          `UPDATE campaigns SET name=?, type=?, start_time=?, end_time=?, cover_url=?, description=?,
           page_title=?, page_content=?, rules=?, rewards=?, max_participants=?, update_time=NOW()
           WHERE id=?`,
          [name, type || 'discount', startTime || null, endTime || null, coverUrl || '',
           description || '', pageTitle || '', pageContent || '', rules || '', rewardsStr,
           Number(maxParticipants) || 0, Number(id)]
        )
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO campaigns (name, type, status, start_time, end_time, cover_url, description,
           page_title, page_content, rules, rewards, max_participants)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [name, type || 'discount', 'draft', startTime || null, endTime || null, coverUrl || '',
           description || '', pageTitle || '', pageContent || '', rules || '', rewardsStr,
           Number(maxParticipants) || 0]
        )
        res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/campaign/:id/publish', authRequired, async (req, res) => {
    try {
      await query('UPDATE campaigns SET status=\'active\', update_time=NOW() WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '活动已发布' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/campaign/:id/offline', authRequired, async (req, res) => {
    try {
      const campaign = await query('SELECT name FROM campaigns WHERE id=?', [Number(req.params.id)])
      if (campaign && campaign.length > 0) {
        executePenalty(req.userId, '', 'campaign_cheat', {})
      }
      await query('UPDATE campaigns SET status=\'offline\', update_time=NOW() WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '活动已下线' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/campaign/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM campaigns WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = campaignRoutes
