const { query, getSystemOperator } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const nowExpr = 'NOW()'
const { progressTasksByAction } = require('./custom-task.cjs')
const { systemLog, sanitizeCommunityContent } = require('../middleware/security.cjs')
const { emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS } = require('../plugins/events.cjs')
const { deleteFileRecordsByRef, deleteFileRecordsByIds } = require('../utils/file-helper.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')
const multer = require('multer')
const path = require('path')
const communityUploadDir = path.join(__dirname, '..', 'uploads')

const communityImageUpload = multer({
  storage: multer.diskStorage({
    destination: communityUploadDir,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg'
      cb(null, 'community_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + ext)
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 }
})

;(async () => {
  try {
    const cols = await query("SHOW COLUMNS FROM community_comments LIKE 'status'")
    if (!cols || cols.length === 0) {
      await query("ALTER TABLE community_comments ADD COLUMN status VARCHAR(20) DEFAULT 'published'")
      console.log('[Community] Added status column to community_comments')
    }
    const rcols = await query("SHOW COLUMNS FROM community_sections LIKE 'comment_review_required'")
    if (!rcols || rcols.length === 0) {
      await query("ALTER TABLE community_sections ADD COLUMN comment_review_required TINYINT DEFAULT 0")
      console.log('[Community] Added comment_review_required column to community_sections')
    }
    const sdcols = await query("SHOW COLUMNS FROM community_sections LIKE 'is_deleted'")
    if (!sdcols || sdcols.length === 0) {
      await query("ALTER TABLE community_sections ADD COLUMN is_deleted TINYINT DEFAULT 0")
      console.log('[Community] Added is_deleted column to community_sections')
    }
  } catch (e) { console.error('[Community] Migration error:', e.message) }
})()

async function getModeratorEmails(sectionId) {
  try {
    const mods = await query('SELECT u.email FROM community_moderators cm JOIN users u ON cm.user_id=u.id WHERE cm.section_id=? AND u.email IS NOT NULL AND u.email != \'\'', [sectionId])
    return mods.map(m => m.email)
  } catch { return [] }
}

async function getUserEmail(userId) {
  try {
    const rows = await query('SELECT email FROM users WHERE id=?', [userId])
    return rows.length > 0 ? rows[0].email : ''
  } catch { return '' }
}

async function createMentionNotifications(content, fromUserId, fromUserName, fromUserAvatar, refType, refId) {
  if (!content || !fromUserId) return
  const mentionRegex = /@(\S{1,30})/g
  const mentioned = new Set()
  let match
  while ((match = mentionRegex.exec(content)) !== null) {
    const name = match[1].replace(/[，。！？、；：""''）】》\s]+$/, '')
    if (name && name.length >= 2 && name.length <= 20) mentioned.add(name)
  }
  if (mentioned.size === 0) return
  for (const name of mentioned) {
    try {
      const users = await query('SELECT id, nickname, username FROM users WHERE username=? OR nickname=?', [name, name])
      if (users.length === 0) continue
      const target = users[0]
      if (target.id === fromUserId) continue
      const title = refType === 'post' ? '在帖子中@了你' : '在评论中@了你'
      const contentPreview = content.length > 80 ? content.substring(0, 80) + '...' : content
      const targetUrl = refType === 'post' ? `/community/post/${refId}` : `/community/post/${refId}`
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'mention', ?, ?, ?, ?, ?)`,
        [title, `${fromUserName}: ${contentPreview}`, targetUrl, target.id, fromUserId, fromUserName, fromUserAvatar || '']
      )
    } catch {}
  }
}

async function getAdminUserName(req) {
  try {
    const raw = req.headers.authorization || req.headers.token || req.query.token || ''
    const token = raw.replace(/^Bearer\s+/i, '')
    const session = sessions.get(token)
    if (session && session.userName) return session.userName
    const rows = await query('SELECT username FROM users WHERE id=(SELECT user_id FROM sessions WHERE token=?)', [token])
    return rows.length > 0 ? rows[0].username : 'unknown'
  } catch {}
  return 'unknown'
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }

  // 后端重启后内存 session 丢失，从数据库恢复
  try {
    const rows = await query('SELECT user_id, user_name, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, userName: row.user_name, roles: JSON.parse(row.roles || '[]'), createdAt })
      return Number(row.user_id) || 0
    }
  } catch {}

  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function isAdminById(userId) {
  if (!userId) return false
  try {
    const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
    if (rows && rows.length > 0) {
      try {
        const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
        return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      } catch { return false }
    }
  } catch {}
  return false
}

async function canAccessSection(userId, sectionId) {
  if (!userId) return false
  if (await isAdminById(userId)) return true
  try {
    const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
    return rows.length > 0
  } catch { return false }
}

async function initTrustLevel(userId) {
  try {
    await query(
      'INSERT IGNORE INTO community_trust_levels (user_id, level, post_count, comment_count, like_received, report_count, ban_count, score) VALUES (?, 0, 0, 0, 0, 0, 0, 0)',
      [userId]
    )
  } catch {}
}

function calcTrustScore(postCount, commentCount, likeReceived, reportCount, banCount) {
  return (postCount || 0) * 2 + (commentCount || 0) * 1 + (likeReceived || 0) * 3 - (reportCount || 0) * 5 - (banCount || 0) * 10
}

function getTrustLevelByScore(score) {
  if (score >= 200) return 3
  if (score >= 50) return 2
  if (score >= 10) return 1
  return 0
}

async function incrementPostCount(userId) {
  try {
    await initTrustLevel(userId)
    await query('UPDATE community_trust_levels SET post_count = post_count + 1 WHERE user_id=?', [userId])
  } catch {}
}

async function incrementCommentCount(userId) {
  try {
    await initTrustLevel(userId)
    await query('UPDATE community_trust_levels SET comment_count = comment_count + 1 WHERE user_id=?', [userId])
  } catch {}
}

async function incrementLikeReceived(postId) {
  try {
    const post = await query('SELECT user_id FROM community_posts WHERE id=?', [postId])
    if (post.length > 0) {
      const authorId = post[0].user_id
      await initTrustLevel(authorId)
      await query('UPDATE community_trust_levels SET like_received = like_received + 1 WHERE user_id=?', [authorId])
    }
  } catch {}
}

async function getAutoBanSettings() {
  try {
    const rows = await query('SELECT setting_key, setting_value FROM community_settings WHERE setting_key IN (?,?)', ['auto_ban_threshold', 'auto_ban_duration_hours'])
    const cfg = { threshold: 3, durationHours: 24 }
    for (const r of rows) {
      const v = Number(r.setting_value)
      if (r.setting_key === 'auto_ban_threshold' && v > 0) cfg.threshold = v
      if (r.setting_key === 'auto_ban_duration_hours' && v > 0) cfg.durationHours = v
    }
    return cfg
  } catch { return { threshold: 3, durationHours: 24 } }
}

async function checkAutoBan(targetUserId) {
  try {
    const cfg = await getAutoBanSettings()
    const pendingCount = await query(
      "SELECT COUNT(*) as cnt FROM community_reports WHERE target_id IN (SELECT id FROM community_posts WHERE user_id=?) AND target_type='post' AND status='pending'",
      [targetUserId]
    )
    const pendingCommentCount = await query(
      "SELECT COUNT(*) as cnt FROM community_reports WHERE target_id IN (SELECT id FROM community_comments WHERE user_id=?) AND target_type='comment' AND status='pending'",
      [targetUserId]
    )
    const totalPending = (pendingCount.length > 0 ? pendingCount[0].cnt : 0) + (pendingCommentCount.length > 0 ? pendingCommentCount[0].cnt : 0)

    if (totalPending >= cfg.threshold) {
      const banUntil = new Date(Date.now() + cfg.durationHours * 3600000)
      await query(
        'INSERT INTO community_moderator_bans (section_id, user_id, banned_user_id, banned_user_name, reason, ban_until, is_active) VALUES (?,?,?,?,?,?,?)',
        [0, 0, targetUserId, '', '系统自动封禁：累计被举报' + totalPending + '次', banUntil, 1]
      )
      await query(
        'INSERT INTO community_auto_bans (user_id, report_count, banned_until) VALUES (?,?,?)',
        [targetUserId, totalPending, banUntil]
      )
      try {
        const targetUser = await query('SELECT username FROM users WHERE id=?', [targetUserId])
        const targetName = targetUser.length > 0 ? targetUser[0].username : ''
        await query(
          "INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)",
          ['您已被系统自动封禁', `由于累计被举报${totalPending}次，您的发言权限已被自动限制${cfg.durationHours}小时`, 'user_banned', targetUserId, 0, '系统']
        )
      } catch {}
    }
  } catch {}
}

async function savePostRevision(postId, editorId, title, content, tags, editSummary) {
  try {
    const latest = await query(
      'SELECT COALESCE(MAX(version), 0) as maxVer FROM community_post_revisions WHERE post_id=?',
      [postId]
    )
    const nextVer = (latest.length > 0 ? latest[0].maxVer : 0) + 1
    await query(
      'INSERT INTO community_post_revisions (post_id, editor_id, title, content, tags, edit_summary, version) VALUES (?,?,?,?,?,?,?)',
      [postId, editorId, title || '', content || '', tags || '[]', editSummary || '', nextVer]
    )
  } catch {}
}

function communityRoutes(app) {

  // ==================== Section APIs ====================

  app.get('/api/community/sections', async (req, res) => {
    try {
      const showAll = req.query.all === 'true' && (await isAdmin(req))
      const whereClause = showAll ? 'WHERE cs.is_deleted=0' : "WHERE status='active' AND cs.is_deleted=0"
      const sections = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor, cs.description,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published') as postCount,
                (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published') as totalViewCount,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published' AND DATE(create_time)=CURDATE()) as todayHeat,
                cs.sort_order as sortOrder, cs.status, cs.visibility,
                cs.post_permission as postPermission, cs.view_permission as viewPermission,
                cs.view_level_required as viewLevelRequired, cs.hot_threshold as hotThreshold,
                cs.view_cooldown as viewCooldown, cs.create_time as createTime
         FROM community_sections cs ${whereClause} ORDER BY cs.sort_order ASC`
      )
      const userId = await getUserId(req)
      const userRoles = await getUserRoles(req)
      const isUserAdminDB = userRoles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      const user = userId ? (await query('SELECT level_name, level_id, is_verified FROM users WHERE id=?', [userId]))[0] : null
      const filtered = []
      for (const s of sections) {
        if (s.visibility === 'restricted' && !(await canAccessSection(userId, s.id))) continue
        if (!isUserAdminDB) {
          const vp = s.viewPermission || 'all'
          if (vp === 'moderator_only') {
            if (!userId || !(await canAccessSection(userId, s.id))) continue
          } else if (vp === 'admin_only') {
            continue
          } else if (vp === 'vip_only') {
            if (!user || !user.level_name || !user.level_name.includes('VIP')) continue
          } else if (vp === 'member_only') {
            if (!user || !user.level_id) continue
          } else if (vp === 'verified_only') {
            if (!user || !user.is_verified) continue
          }
          if (s.viewLevelRequired && s.viewLevelRequired > 0) {
            if (!user || !user.level_id || user.level_id < s.viewLevelRequired) continue
          }
        }
        filtered.push(s)
      }
      res.json({ code: 200, msg: 'success', data: filtered })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== 版主管理 API ====================

  app.get('/api/community/section/:id/moderators', async (req, res) => {
    try {
      const list = await query(
        `SELECT cm.id, cm.section_id as sectionId, cm.user_id as userId,
                COALESCE(NULLIF(u.nickname,''), u.username, cm.user_name) as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), cm.user_avatar, '') END as userAvatar,
                cm.role, cm.sort_order as sortOrder, cm.create_time as createTime
         FROM community_moderators cm LEFT JOIN users u ON cm.user_id = u.id WHERE cm.section_id=? ORDER BY cm.sort_order ASC, cm.create_time ASC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section/:id/moderator', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const adminUserId = await getUserId(req)
      const { userId, userName, userAvatar, role } = req.body
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const userRoles = await getUserRoles(req)
      const availableRoles = await getAvailableRoles(userRoles)
      if (!availableRoles.includes(role)) {
        return res.json({ code: 400, msg: `角色无效，可选：${availableRoles.join('、')}` })
      }
      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, userId]
      )
      if (existing.length) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [userName||'', userAvatar||'', role||'版主', req.params.id, userId]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [req.params.id, userId, userName||'', userAvatar||'', role||'版主']
        )
      }
      // 通知用户已成为版主
      try {
        const modUser = await query('SELECT username, email FROM users WHERE id=?', [userId])
        if (modUser.length > 0 && modUser[0].email) {
          sendNotificationEmail('moderator_apply_result', modUser[0].email, {
            username: modUser[0].username || '',
            subject: '版主申请通过',
            content: `恭喜，您已被任命为板块版主（${role || '版主'}）。`
          })
        }
      } catch {}
      systemLog(adminUserId, 'assign_moderator', 'community', `任命用户${userId}为板块${req.params.id}版主`, req => ({}))
      res.json({ code: 200, msg: 'success' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id/moderator/:userId', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const adminUserId = await getUserId(req)
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?',
        [req.params.id, req.params.userId])
      // 通知用户版主身份已被移除
      try {
        const removedMod = await query('SELECT username, email FROM users WHERE id=?', [req.params.userId])
        if (removedMod.length > 0 && removedMod[0].email) {
          sendNotificationEmail('moderator_removed', removedMod[0].email, {
            username: removedMod[0].username || '',
            subject: '版主身份已移除',
            content: '您的版主身份已被管理员移除。'
          })
        }
      } catch {}
      systemLog(adminUserId, 'remove_moderator', 'community', `移除板块${req.params.id}版主用户${req.params.userId}`, req => ({}))
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 查询用户担任版主的所有板块
  app.get('/api/community/user/:userId/moderator-sections', async (req, res) => {
    try {
      const list = await query(
        `SELECT m.section_id as sectionId, m.role, s.name as sectionName, s.icon_bg_color as iconBgColor
         FROM community_moderators m
         LEFT JOIN community_sections s ON m.section_id = s.id
         WHERE m.user_id=?`,
        [req.params.userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== 版主申请 API ====================

  async function getModeratorRoles() {
    try {
      const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
      return rows.map(r => r.role_name)
    } catch { return ['版主', '审核员'] }
  }

  async function getModeratorRoleCodes() {
    try {
      const rows = await query('SELECT role_name, role_code FROM roles WHERE community_moderator=1 AND enabled=1 ORDER BY id ASC')
      return rows
    } catch { return [{ role_name: '版主', role_code: 'R_MODERATOR' }, { role_name: '审核员', role_code: 'R_REVIEWER' }] }
  }

  async function getAvailableRoles(userRoles) {
    const allRoles = await getModeratorRoles()
    if (userRoles.some(r => r === 'R_SUPER')) return allRoles
    const roleCodes = await getModeratorRoleCodes()
    const adminAllowed = roleCodes.filter(rc => rc.role_code !== 'R_SUPER').map(rc => rc.role_name)
    if (userRoles.some(r => r === 'R_ADMIN')) return adminAllowed
    return []
  }

  async function getHighestRoleIndex(roles, allRoles) {
    let idx = -1
    for (const r of roles) {
      const i = allRoles.indexOf(r)
      if (i > idx) idx = i
    }
    return idx
  }

  async function isModeratorOfSection(userId, sectionId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    try {
      const rows = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
      return rows.length > 0
    } catch { return false }
  }

  async function isModeratorOfPost(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    try {
      const rows = await query(
        'SELECT cm.id FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
        [postId, userId]
      )
      return rows.length > 0
    } catch { return false }
  }

  async function getModeratorSectionIds(userId) {
    try {
      const rows = await query('SELECT section_id FROM community_moderators WHERE user_id=? ORDER BY section_id', [userId])
      return rows.map(r => r.section_id)
    } catch { return [] }
  }

  const REVIEWER_ONLY_ROLES = ['审核员']

  async function getModeratorRoleForPost(userId, postId) {
    try {
      const rows = await query(
        'SELECT cm.role FROM community_moderators cm JOIN community_posts cp ON cm.section_id=cp.section_id WHERE cp.id=? AND cm.user_id=?',
        [postId, userId]
      )
      return rows.length > 0 ? rows[0].role : null
    } catch { return null }
  }

  async function canReviewModAction(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    const role = await getModeratorRoleForPost(userId, postId)
    return !!role
  }

  async function canManageModAction(userId, postId) {
    if (!userId) return false
    if (await isAdminById(userId)) return true
    const role = await getModeratorRoleForPost(userId, postId)
    return role && !REVIEWER_ONLY_ROLES.includes(role)
  }

  async function logModeratorAction(sectionId, userId, userName, action, targetType, targetId, detail) {
    try {
      await query(
        'INSERT INTO community_moderator_logs (section_id, moderator_id, moderator_name, action, target_type, target_id, detail) VALUES (?,?,?,?,?,?,?)',
        [sectionId || 0, userId, userName || '', action, targetType || '', targetId || 0, detail || '']
      )
    } catch {}
  }

  app.post('/api/community/section/:id/apply', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason, desiredRole } = req.body
      const sectionId = Number(req.params.id)

      const existing = await query(
        'SELECT id, status FROM moderator_applications WHERE section_id=? AND user_id=? AND status=?',
        [sectionId, userId, 'pending']
      )
      if (existing.length > 0) {
        return res.json({ code: 400, msg: '您已有待审核的申请' })
      }

      const isMod = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [sectionId, userId]
      )
      if (isMod.length > 0) {
        return res.json({ code: 400, msg: '您已是该板块的版主' })
      }

      const user = await query('SELECT username, avatar FROM users WHERE id=?', [userId])
      const userName = user.length > 0 ? (user[0].username || '') : ''
      const userAvatar = user.length > 0 && user[0].avatar && !user[0].avatar.startsWith('avatar:') ? user[0].avatar : ''

      await query(
        'INSERT INTO moderator_applications (section_id, user_id, user_name, user_avatar, reason, desired_role) VALUES (?,?,?,?,?,?)',
        [sectionId, userId, userName, userAvatar, reason || '', desiredRole || '版主']
      )

      try {
        const section = await query('SELECT name FROM community_sections WHERE id=? AND is_deleted=0', [sectionId])
        const sectionName = section.length > 0 ? section[0].name : '未知板块'

        const adminEmails = await getAdminEmails()
        if (adminEmails.length > 0) {
          for (const recipient of adminEmails) {
            sendNotificationEmail('moderator_apply', recipient, {
              username: recipient.split('@')[0] || '管理员',
              subject: '新版主申请通知',
              content: `${userName} 申请成为「${sectionName}」板块的 ${desiredRole || '版主'}，请前往管理后台审核。`
            })
          }
        }

        const admins = await query("SELECT id, roles FROM users WHERE roles LIKE '%R_SUPER%' OR roles LIKE '%R_ADMIN%'")
        for (const admin of admins) {
          await query(
            'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
            ['新版主申请', `${userName} 申请成为「${sectionName}」板块的 ${desiredRole || '版主'}`, 'moderator_apply', admin.id, userId, userName, userAvatar]
          )
        }
      } catch {}

      res.json({ code: 200, msg: '申请已提交，请等待管理员审核' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/section/:id/applications', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const list = await query(
        `SELECT a.id, a.section_id as sectionId, a.user_id as userId, a.user_name as userName,
                a.user_avatar as userAvatar, a.reason, a.desired_role as desiredRole,
                a.status, a.reviewed_by as reviewedBy, a.reviewed_by_name as reviewedByName,
                a.review_comment as reviewComment, a.create_time as createTime,
                a.review_time as reviewTime,
                cs.name as sectionName
         FROM moderator_applications a
         LEFT JOIN community_sections cs ON a.section_id = cs.id
         WHERE a.section_id=? ORDER BY a.create_time DESC`,
        [req.params.id]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/applications', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const list = await query(
        `SELECT a.id, a.section_id as sectionId, a.user_id as userId, a.user_name as userName,
                a.user_avatar as userAvatar, a.reason, a.desired_role as desiredRole,
                a.status, a.reviewed_by as reviewedBy, a.reviewed_by_name as reviewedByName,
                a.review_comment as reviewComment, a.create_time as createTime,
                a.review_time as reviewTime,
                cs.name as sectionName
         FROM moderator_applications a
         LEFT JOIN community_sections cs ON a.section_id = cs.id
         ORDER BY a.status ASC, a.create_time DESC`,
        []
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/application/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const { role } = req.body
      const appRows = await query('SELECT * FROM moderator_applications WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (appRows.length === 0) return res.json({ code: 404, msg: '申请不存在或已处理' })

      const app = appRows[0]
      const availableRoles = await getAvailableRoles(roles)
      const assignedRole = role || app.desired_role || '版主'

      if (!availableRoles.includes(assignedRole)) {
        return res.json({ code: 403, msg: `您只能设置以下角色: ${availableRoles.join('、')}` })
      }

      const existing = await query(
        'SELECT id FROM community_moderators WHERE section_id=? AND user_id=?',
        [app.section_id, app.user_id]
      )

      const reviewer = await query('SELECT username FROM users WHERE id=?', [userId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : '管理员'

      if (existing.length > 0) {
        await query(
          'UPDATE community_moderators SET user_name=?, user_avatar=?, role=? WHERE section_id=? AND user_id=?',
          [app.user_name, app.user_avatar || '', assignedRole, app.section_id, app.user_id]
        )
      } else {
        await query(
          'INSERT INTO community_moderators (section_id, user_id, user_name, user_avatar, role) VALUES (?,?,?,?,?)',
          [app.section_id, app.user_id, app.user_name, app.user_avatar || '', assignedRole]
        )
      }

      await query(
        'UPDATE moderator_applications SET status=?, reviewed_by=?, reviewed_by_name=?, review_time=NOW() WHERE id=?',
        ['approved', userId, reviewerName, req.params.id]
      )

      try {
        const applyUser = await query('SELECT email, username FROM users WHERE id=?', [app.user_id])
        if (applyUser.length > 0 && applyUser[0].email) {
          sendNotificationEmail('moderator_apply_result', applyUser[0].email, {
            username: applyUser[0].username || '',
            subject: '版主申请已通过',
            content: `恭喜，您的版主申请已通过审核，您已被任命为板块的「${assignedRole}」。`
          })
        }
        await query(
          'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
          ['版主申请已通过', `恭喜，您的版主申请已通过审核，您已被任命为「${assignedRole}」。`, 'moderator_apply_result', app.user_id, userId, reviewerName, '']
        )
      } catch (e) { console.error('审批通知发送失败:', e.message) }

      res.json({ code: 200, msg: '已通过申请' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/application/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const roles = await getUserRoles(req)
      if (!roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')) return res.json({ code: 403, msg: '无权限' })

      const { reason } = req.body
      const appRows = await query('SELECT * FROM moderator_applications WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (appRows.length === 0) return res.json({ code: 404, msg: '申请不存在或已处理' })

      const app = appRows[0]
      const reviewer = await query('SELECT username FROM users WHERE id=?', [userId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : '管理员'

      await query(
        'UPDATE moderator_applications SET status=?, reviewed_by=?, reviewed_by_name=?, review_comment=?, review_time=NOW() WHERE id=?',
        ['rejected', userId, reviewerName, reason || '', req.params.id]
      )

      try {
        const applyUser = await query('SELECT email, username FROM users WHERE id=?', [app.user_id])
        if (applyUser.length > 0 && applyUser[0].email) {
          sendNotificationEmail('moderator_apply_result', applyUser[0].email, {
            username: applyUser[0].username || '',
            subject: '版主申请未通过',
            content: `很遗憾，您的版主申请未被通过。${reason ? '原因: ' + reason : ''}`
          })
        }
        await query(
          'INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,?)',
          ['版主申请未通过', `很遗憾，您的版主申请未被通过。${reason ? '原因: ' + reason : ''}`, 'moderator_apply_result', app.user_id, userId, reviewerName, '']
        )
      } catch (e) { console.error('拒绝通知发送失败:', e.message) }

      res.json({ code: 200, msg: '已拒绝申请' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/section/:id/my-application', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        'SELECT id, status, desired_role as desiredRole, reason, review_comment as reviewComment, create_time as createTime FROM moderator_applications WHERE section_id=? AND user_id=? ORDER BY create_time DESC LIMIT 1',
        [req.params.id, userId]
      )
      res.json({ code: 200, msg: 'success', data: rows.length > 0 ? rows[0] : null })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/section/:id', async (req, res) => {
    try {
      const section = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor, cs.description,
                cs.today_heat as todayHeat, cs.total_heat as totalHeat,
                (SELECT COUNT(*) FROM community_posts WHERE section_id=cs.id AND status='published') as postCount,
                (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published') as totalViewCount,
                (SELECT IFNULL(SUM(view_count), 0) FROM community_posts WHERE section_id=cs.id AND status='published' AND DATE(update_time)=CURDATE()) as todayViewCount,
                cs.sort_order as sortOrder, cs.status, cs.visibility,
                cs.post_permission as postPermission, cs.view_permission as viewPermission,
                cs.view_level_required as viewLevelRequired,
                cs.hot_threshold as hotThreshold, cs.view_cooldown as viewCooldown,
                cs.create_time as createTime
         FROM community_sections cs WHERE cs.id=? AND cs.is_deleted=0`, [req.params.id]
      )
      if (!section || section.length === 0) {
        return res.json({ code: 404, msg: '板块不存在' })
      }
      const s = section[0]
      if (s.visibility === 'restricted') {
        const userId = await getUserId(req)
        if (!(await canAccessSection(userId, s.id))) {
          return res.json({ code: 403, msg: '无权限访问此板块' })
        }
      }
      res.json({ code: 200, msg: 'success', data: s })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/section', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { id, name, icon, iconBgColor, description, todayHeat, totalHeat, postCount, viewCount, sortOrder, status, visibility, postPermission, viewPermission, viewLevelRequired, hotThreshold, viewCooldown } = req.body

      if (id) {
        await query(
          `UPDATE community_sections SET name=?, icon=?, icon_bg_color=?, description=?,
           today_heat=?, total_heat=?, post_count=?, view_count=?, sort_order=?, status=?, visibility=?,
           post_permission=?, view_permission=?, view_level_required=?, hot_threshold=?, view_cooldown=?
           WHERE id=?`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0,
           hotThreshold ?? 100, viewCooldown ?? 30, id]
        )
        emitSafe(SECTION_EVENTS.UPDATED, { sectionId: id, name })
        systemLog(userId, 'update_section', 'community', `更新板块「${name}」`, req => ({}))
        res.json({ code: 200, msg: '更新成功', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_sections (name, icon, icon_bg_color, description, today_heat, total_heat, post_count, view_count, sort_order, status, visibility, post_permission, view_permission, view_level_required, hot_threshold, view_cooldown)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', iconBgColor || '#00BFA5', description || '',
           todayHeat || 0, totalHeat || 0, postCount || 0, viewCount || 0,
           sortOrder || 0, status || 'active', visibility || 'public',
           postPermission || 'all', viewPermission || 'all', viewLevelRequired || 0,
           hotThreshold ?? 100, viewCooldown ?? 30]
        )
        const sectionId = result.insertId
        emitSafe(SECTION_EVENTS.CREATED, { sectionId, name })
        systemLog(userId, 'create_section', 'community', `创建板块「${name}」`, req => ({}))
        res.json({ code: 200, msg: '创建成功', data: { id: sectionId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/section/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      await query('UPDATE community_sections SET is_deleted=1 WHERE id=?', [req.params.id])
      emitSafe(SECTION_EVENTS.DELETED, { sectionId: Number(req.params.id) })
      systemLog(userId, 'delete_section', 'community', `删除板块ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post APIs ====================

  app.get('/api/community/posts', async (req, res) => {
    try {
      const { sectionId, sort = 'latest', page = 1, pageSize = 20, keyword, tags, userId, viewerId, status: statusFilter, isHidden, followed, startDate, endDate } = req.query
      const queryUserId = Number(userId) || 0
      const queryViewerId = Number(viewerId) || 0
      const authUserId = await getUserId(req)
      const effectiveViewerId = queryViewerId || queryUserId
      const blockViewerId = queryViewerId || authUserId
      const isAdminUser = authUserId ? await isAdminById(authUserId) : false

      let followedUserIds = null
      if (followed) {
        const authUserId = await getUserId(req)
        if (authUserId) {
          const follows = await query('SELECT following_id FROM user_follows WHERE follower_id=?', [authUserId])
          if (follows.length > 0) {
            followedUserIds = follows.map(f => f.following_id)
          }
        }
      }

      let sql = `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                  CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                  p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                  p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                  p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                  p.content_permission as contentPermission, p.content_price as contentPrice,
                  p.content_price_type as contentPriceType,
                  p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status, p.like_count as likeCount,
                  p.comment_count as commentCount, p.coin_count as coinCount,
                  p.view_count as viewCount, p.favorite_count as favoriteCount,
                  p.is_global_pinned as isGlobalPinned,
                p.custom_badge as customBadge,
                p.cover_url as coverUrl,
                  p.reject_reason as rejectReason,
                  p.create_time as createTime, p.update_time as updateTime,
                  p.scheduled_time as scheduledTime,
                  p.auto_hide_at as autoHideAt,
                  p.is_hidden as isHidden,
                   u.level_name as userLevelName, u.is_verified as userIsVerified,
                   COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                   (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                   COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                   COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                  COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                  COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                  ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                   ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                   tp.name as topicName,
                   cs.name as sectionName,
                   (SELECT GROUP_CONCAT(pt.topic_id) FROM community_post_topics pt WHERE pt.post_id = p.id) as topicIds,
                    (SELECT GROUP_CONCAT(t.name SEPARATOR '|||') FROM community_post_topics pt JOIN community_topics t ON pt.topic_id = t.id WHERE pt.post_id = p.id) as topicNames,
                    ccp.collection_id as collectionId,
                    col.title as collectionTitle
                  FROM community_posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN membership_levels ml ON ml.id = u.level_id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id LEFT JOIN community_topics tp ON p.topic_id = tp.id LEFT JOIN community_sections cs ON p.section_id = cs.id LEFT JOIN community_collection_posts ccp ON p.id = ccp.post_id LEFT JOIN community_collections col ON ccp.collection_id = col.id AND col.is_deleted = 0 AND col.status IN ('serializing','finished') WHERE `
      const params = []

      if (statusFilter) {
        sql += 'p.status=?'
        params.push(statusFilter)
      } else if (queryUserId) {
        if (authUserId === queryUserId) {
          sql += "(p.status='published' OR (p.user_id=? AND p.status!='deleted'))"
          params.push(queryUserId)
        } else {
          sql += "p.status='published' AND p.user_id=? AND p.is_hidden=0"
          params.push(queryUserId)
        }
      } else {
        sql += "p.status='published' AND p.is_hidden=0"
      }

      if (!statusFilter && queryUserId && authUserId === queryUserId && isHidden === undefined) {
        sql += ' AND (p.is_hidden=0 OR p.user_id=?)'
        params.push(queryUserId)
      }

      if (isHidden !== undefined) {
        sql += ' AND p.is_hidden=?'
        params.push(isHidden === '1' ? 1 : 0)
      }

      if (sectionId) { sql += ' AND (p.section_id=? OR p.is_global_pinned=1)'; params.push(sectionId) }
      if (queryUserId) { sql += ' AND p.user_id=?'; params.push(queryUserId) }
      if (keyword) { sql += ' AND (p.title LIKE ? OR p.content LIKE ?)'; params.push(`%${keyword}%`, `%${keyword}%`) }
      if (tags) {
        const tagList = tags.split(',')
        for (const t of tagList) {
          sql += ' AND p.tags LIKE ?'
          params.push(`%${t.trim()}%`)
        }
      }

      if (startDate) { sql += ' AND p.create_time >= ?'; params.push(startDate) }
      if (endDate) { sql += ' AND p.create_time <= ?'; params.push(endDate + ' 23:59:59') }

      // 过滤受限板块的帖子
      if (!isAdminUser) {
        const restrictedSections = await query('SELECT id FROM community_sections WHERE visibility=? AND is_deleted=0', ['restricted'])
        if (restrictedSections.length > 0) {
          const restrictedIds = restrictedSections.map(s => s.id)
          let accessibleIds = []
          if (queryUserId) {
            const modRows = await query(
              `SELECT section_id FROM community_moderators WHERE user_id=? AND section_id IN (${restrictedIds.map(() => '?').join(',')})`,
              [queryUserId, ...restrictedIds]
            )
            accessibleIds = modRows.map(r => r.section_id)
          }
          const inaccessibleIds = restrictedIds.filter(id => !accessibleIds.includes(id))
          if (inaccessibleIds.length > 0) {
            sql += ` AND p.section_id NOT IN (${inaccessibleIds.map(() => '?').join(',')})`
            params.push(...inaccessibleIds)
          }
        }
      }

      // 关注筛选：仅显示关注用户的帖子
      if (followed) {
        if (followedUserIds && followedUserIds.length > 0) {
          sql += ` AND p.user_id IN (${followedUserIds.map(() => '?').join(',')})`
          params.push(...followedUserIds)
        } else {
          sql += ' AND 1=0'
        }
      }

      // 拉黑过滤：当前用户不看到拉黑自己的人的内容，也不看到被自己拉黑的人的内容
      if (blockViewerId && blockViewerId > 0) {
        const { getBlockedUserIds, getBlockerUserIds } = require('./user-block.cjs')
        const blockedIds = await getBlockedUserIds(blockViewerId)
        const blockerIds = await getBlockerUserIds(blockViewerId)
        const excludeIds = [...new Set([...blockedIds, ...blockerIds])]
        if (excludeIds.length > 0) {
          sql += ` AND p.user_id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }
      }

      // trending 排序：仅统计最近7天的帖子
      if (sort === 'trending') {
        sql += ' AND p.create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)'
      }

      let orderBy = ''
      switch (sort) {
        case 'recent_reply': orderBy = 'p.is_global_pinned DESC, p.update_time DESC'; break
        case 'most_likes': orderBy = 'p.is_global_pinned DESC, p.like_count DESC'; break
        case 'most_favorites': orderBy = 'p.is_global_pinned DESC, p.favorite_count DESC'; break
        case 'essence': orderBy = 'p.is_global_pinned DESC, p.is_essence DESC, p.id DESC'; break
        case 'hot': orderBy = 'p.is_global_pinned DESC, p.like_count DESC'; break
        case 'trending': orderBy = 'p.is_global_pinned DESC, p.comment_count DESC'; break
        case 'views': orderBy = 'p.is_global_pinned DESC, p.view_count DESC'; break
        case 'pinned': orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'; break
        default: orderBy = 'p.is_global_pinned DESC, p.is_pinned DESC, p.id DESC'
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY ${orderBy} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
        // 解析多话题ID和名称
      item.topicIds = item.topicIds ? item.topicIds.split(',').map(Number) : []
      item.topicNames = item.topicNames ? item.topicNames.split('|||').filter(Boolean) : []
      }

      if (Number(userId) && list.length > 0) {
        try {
          const postIds = list.map(p => p.id)
          const likedRows = await query(
            `SELECT post_id FROM community_likes WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const favoritedRows = await query(
            `SELECT post_id FROM community_favorites WHERE user_id=? AND post_id IN (${postIds.map(() => '?').join(',')})`,
            [Number(userId), ...postIds]
          )
          const likedSet = new Set(likedRows.map(r => r.post_id))
          const favSet = new Set(favoritedRows.map(r => r.post_id))
          for (const item of list) {
            item.isLiked = likedSet.has(item.id)
            item.isFavorited = favSet.has(item.id)
          }
        } catch {}
      }

      // 过滤付费内容：非作者/非管理员/未购买的用户，隐藏付费帖子的内容
      if (list.length > 0) {
        try {
          const allIds = list.map(p => p.id)
          const paidSet = new Set()
          if (effectiveViewerId) {
            const purchases = await query(
              `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${allIds.map(() => '?').join(',')})`,
              [effectiveViewerId, ...allIds]
            )
            purchases.forEach(p => paidSet.add(p.content_id))
          }
          const isViewerAdmin = effectiveViewerId ? await isAdminById(effectiveViewerId) : false
          const restrictedPosts = list.filter(p => ['paid', 'login', 'mixed'].includes(p.contentPermission))
          for (const item of restrictedPosts) {
            if (effectiveViewerId && (item.userId === effectiveViewerId || isViewerAdmin)) continue
            if (paidSet.has(item.id)) continue
            const perm = item.contentPermission || 'paid'
            const hints = {
              paid: '部分内容付费 - 需购买后查看',
              comment: '评论后可见',
              level: '需达到一定等级后查看',
              password: '需密码查看',
              login: '登录后可查看完整内容',
              mixed: '部分内容付费 - 需购买后查看'
            }
            item.content = hints[perm] || hints.paid
            item.contentFiltered = true
            try { item.images = [] } catch {}
          }
          for (const item of list) {
            item.hasPurchased = paidSet.has(item.id) || (effectiveViewerId && item.userId === effectiveViewerId)
          }
          if (effectiveViewerId && allIds.length > 0) {
            const commentedSet = new Set()
            const comments = await query(
              `SELECT DISTINCT post_id FROM community_comments WHERE post_id IN (${allIds.map(() => '?').join(',')}) AND user_id = ?`,
              [...allIds, effectiveViewerId]
            )
            comments.forEach(c => commentedSet.add(c.post_id))
            for (const item of list) {
              item.hasCommented = commentedSet.has(item.id)
            }
          }
          if (effectiveViewerId) {
            const [viewerRow] = await query(`SELECT level_id as viewerLevelId FROM users WHERE id = ?`, [effectiveViewerId])
            const titleRows = await query(`SELECT title_id FROM user_titles WHERE user_id = ? AND is_active = 1`, [effectiveViewerId])
            const viewerTitleIds = titleRows.map(r => r.title_id)
            const viewerFollowers = await query(`SELECT following_id FROM user_follows WHERE follower_id = ?`, [effectiveViewerId])
            const viewerFollowingIds = viewerFollowers.map(r => r.following_id)
            for (const item of list) {
              item.viewerLevelId = (viewerRow && viewerRow.viewerLevelId) || 0
              item.viewerTitleIds = viewerTitleIds
              item.viewerFollowing = viewerFollowingIds.includes(item.userId)
            }
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/post/:id', async (req, res) => {
    try {
      const { userId } = req.query
      const queryUserId = Number(userId) || 0
      const post = await query(
        `SELECT p.id, p.section_id as sectionId, p.topic_id as topicId, p.user_id as userId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_url as resourceUrl, p.resource_price as resourcePrice,
                p.resource_price_type as resourcePriceType, p.extract_code as extractCode,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.custom_badge as customBadge,
                p.cover_url as coverUrl,
                p.is_pinned as isPinned, p.is_essence as isEssence, p.is_hot as isHot,
                p.is_locked as isLocked, p.is_global_pinned as isGlobalPinned,
                p.is_deleted as isDeleted, p.deleted_at as deletedAt,
                p.like_count as likeCount, p.favorite_count as favoriteCount,
                p.view_count as viewCount, p.comment_count as commentCount,
                p.create_time as createTime, p.update_time as updateTime,
                p.status, p.scheduled_time as scheduledTime,
                p.auto_hide_at as autoHideAt, p.is_hidden as isHidden,
                u.level_name as userLevelName, u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                u.active_title_name as userTitleName,
                cti.icon as userTitleIcon, cti.color as userTitleColor, cti.bg_color as userTitleBgColor,
                (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                tp.name as topicName,
                (SELECT COUNT(*) FROM content_purchases WHERE content_type='post' AND content_id=p.id) as soldCount,
                (SELECT GROUP_CONCAT(pt.topic_id) FROM community_post_topics pt WHERE pt.post_id = p.id) as topicIds,
                cs.name as sectionName,
                (SELECT COUNT(*) FROM community_moderators WHERE section_id=p.section_id AND user_id=p.user_id) as authorIsModerator,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = p.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                ccp2.collection_id as collectionId,
                col2.title as collectionTitle
         FROM community_posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN membership_levels ml ON ml.id = u.level_id LEFT JOIN custom_titles cti ON cti.id = u.active_title_id LEFT JOIN community_topics tp ON p.topic_id = tp.id LEFT JOIN community_sections cs ON p.section_id = cs.id LEFT JOIN community_collection_posts ccp2 ON p.id = ccp2.post_id LEFT JOIN community_collections col2 ON ccp2.collection_id = col2.id AND col2.is_deleted = 0 WHERE p.id=?`, [req.params.id]
      )
      if (!post || post.length === 0) {
        return res.json({ code: 404, msg: '帖子不存在' })
      }
      const item = post[0]
      if (item.status === 'deleted' || item.isDeleted) {
        const isOwner = item.userId === queryUserId
        const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子已被删除' })
        }
      }
      // 隐藏帖仅对作者和管理员可见
      if (item.isHidden) {
        const isOwner = item.userId === queryUserId
        const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        const authUserId = await getUserId(req)
        const isOwnerByAuth = item.userId === authUserId
        const isAdminByAuth = authUserId ? await isAdminById(authUserId) : false
        if (!isOwner && !isAdminUser && !isOwnerByAuth && !isAdminByAuth) {
          return res.json({ code: 404, msg: '帖子已隐藏' })
        }
      }

      // 检查板块可见性
      const secRows = await query('SELECT visibility FROM community_sections WHERE id=? AND is_deleted=0', [item.sectionId])
      if (secRows.length > 0 && secRows[0].visibility === 'restricted') {
        if (!(await canAccessSection(queryUserId, item.sectionId))) {
          return res.json({ code: 403, msg: '无权限访问此帖子' })
        }
      }

      if (item.status === 'pending' || item.status === 'rejected' || item.status === 'scheduled') {
        const isOwner = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
        if (!isOwner && !isAdminUser) {
          return res.json({ code: 404, msg: '帖子不存在' })
        }
      }
      try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      item.isPinned = !!item.isPinned
      item.isEssence = !!item.isEssence
      item.isHot = !!item.isHot
      item.isGlobalPinned = !!item.isGlobalPinned
      item.topicIds = item.topicIds ? item.topicIds.split(',').map(Number) : []
      item.authorIsModerator = item.authorIsModerator > 0
      item.userAllTitleNames = item.userAllTitleNames ? item.userAllTitleNames.split('|||') : []
      item.userAllTitleIcons = item.userAllTitleIcons ? item.userAllTitleIcons.split('|||') : []

      // 浏览数+1，同时检查是否达到15000自动设为热帖（未被管理员手动禁用的）
      await query(
        `UPDATE community_posts SET view_count = view_count + 1, update_time = NOW(),
         is_hot = CASE WHEN view_count + 1 >= 15000 AND hot_manually_disabled = 0 THEN 1 ELSE is_hot END
         WHERE id=?`,
        [Number(req.params.id)]
      )

      {
        const updated = await query('SELECT is_hot, view_count FROM community_posts WHERE id=?', [Number(req.params.id)])
        if (updated.length > 0) {
          item.isHot = !!updated[0].is_hot
          item.viewCount = updated[0].view_count
        }
      }

      if (queryUserId > 0) await progressTasksByAction(queryUserId, '', 'view_post')

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
         FROM community_comments c LEFT JOIN users u ON c.user_id = u.id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id LEFT JOIN membership_levels ml ON ml.id = u.level_id WHERE c.post_id=? AND c.parent_id=0 ORDER BY c.create_time DESC`,
        [req.params.id]
      )
      const allReplies = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar, c.content,
                c.like_count as likeCount, c.reply_count as replyCount, c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
         FROM community_comments c LEFT JOIN users u ON c.user_id = u.id LEFT JOIN custom_titles ct ON ct.id = u.active_title_id LEFT JOIN membership_levels ml ON ml.id = u.level_id WHERE c.post_id=? AND c.parent_id>0 ORDER BY c.create_time ASC`,
        [req.params.id]
      )
      const replyMap = {}
      for (const r of allReplies) {
        if (!replyMap[r.parentId]) replyMap[r.parentId] = []
        replyMap[r.parentId].push(r)
      }
      for (const c of comments) {
        c.replies = replyMap[c.id] || []
      }
      item.comments = comments

      if (Number(userId)) {
        try {
          const liked = await query(
            'SELECT id FROM community_likes WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isLiked = liked.length > 0
          const faved = await query(
            'SELECT id FROM community_favorites WHERE post_id=? AND user_id=?',
            [req.params.id, Number(userId)]
          )
          item.isFavorited = faved.length > 0
        } catch {}
      }

      // 内容块过滤：非作者/非管理员，根据 visibility 剥离受限内容
      const isAuthor = item.userId === queryUserId
      const isAdminUser = queryUserId ? await isAdminById(queryUserId) : false
      if (!isAuthor && !isAdminUser && item.content) {
        try {
          let blocks = typeof item.content === 'string' ? JSON.parse(item.content) : item.content
          if (Array.isArray(blocks) && blocks.length > 0) {
            // 查询已购买的 block 索引
            let purchasedBlocks = new Set()
            if (queryUserId > 0) {
              const purchases = await query(
                'SELECT block_index FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index>=0',
                ['post', Number(req.params.id), queryUserId]
              )
              purchases.forEach(p => purchasedBlocks.add(p.block_index))
              // 全帖购买 (content_permission='paid' 且购买了)
              const fullPurchase = await query(
                'SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=? AND block_index<0',
                ['post', Number(req.params.id), queryUserId]
              )
              if (fullPurchase.length > 0) purchasedBlocks = new Set([-1]) // mark as full purchase
            }

            // 查询用户是否评论过
            let userCommented = false
            if (queryUserId > 0) {
              const cmtCheck = await query(
                'SELECT id FROM community_comments WHERE post_id=? AND user_id=?',
                [Number(req.params.id), queryUserId]
              )
              userCommented = cmtCheck.length > 0
            }

            // 查询用户等级 tier
            let userLevelTier = 0
            if (queryUserId > 0) {
              const ul = await query('SELECT COALESCE(ml.tier, 0) as tier FROM users u LEFT JOIN membership_levels ml ON ml.id = u.level_id WHERE u.id=?', [queryUserId])
              if (ul.length > 0) userLevelTier = ul[0].tier || 0
            }

            // 创建占位块替换被过滤的内容，保留所有 metadata（价格、等级等）
            const placeholder = (b, vis) => ({
              ...b,
              value: '',
              images: undefined,
              url: undefined,
              visibility: vis !== undefined ? vis : (b.visibility || 'public'),
              _filtered: true
            })

            const filtered = blocks.map(b => {
              const vis = (b.visibility || item.contentPermission || 'public').toString()
              if (!vis || vis === 'public') return b

              // 全帖已购买 → 所有块可见
              if (purchasedBlocks.has(-1)) return b

              if (vis === 'paid') {
                // 检查是否购买了该 block
                const blockIdx = blocks.indexOf(b)
                if (purchasedBlocks.has(blockIdx)) return b
                return placeholder(b, 'paid')
              }

              if (vis === 'comment') {
                if (userCommented) return b
                return placeholder(b, 'comment')
              }

              if (vis === 'level') {
                const required = b.visibilityLevel !== undefined ? Number(b.visibilityLevel) : 1
                if (userLevelTier >= required) return b
                return placeholder(b, 'level')
              }

              if (vis === 'level1') {
                if (userLevelTier >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelTier >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'level3') {
                if (userLevelTier >= 3) return b
                return placeholder(b, 'level3')
              }
              if (vis === 'level4') {
                if (userLevelTier >= 4) return b
                return placeholder(b, 'level4')
              }
              if (vis === 'level5') {
                if (userLevelTier >= 5) return b
                return placeholder(b, 'level5')
              }

              if (vis === 'level1') {
                if (userLevelId >= 1) return b
                return placeholder(b, 'level1')
              }
              if (vis === 'level2') {
                if (userLevelId >= 2) return b
                return placeholder(b, 'level2')
              }
              if (vis === 'password') {
                // 密码验证由前端处理，后端保留但加标记
                return b
              }

              // 未登录用户且 visibility 不是 public/login → 替换
              if (!queryUserId) return placeholder(b, vis)

              return b
            })

            item.content = JSON.stringify(filtered)
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: item })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        sectionId, title, content: rawContent, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, scheduledTime, draftId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds, coverImage, autoHideAt
      } = req.body
      const content = sanitizeCommunityContent(rawContent)

      // 检查板块发帖权限
      if (sectionId) {
        const section = await query('SELECT post_permission FROM community_sections WHERE id=? AND is_deleted=0', [Number(sectionId)])
        if (section.length) {
          const perm = section[0].post_permission || 'all'
          if (perm !== 'all') {
            const isUserAdmin = await isAdmin(req)

            if (perm === 'admin_only' && !isUserAdmin) {
              return res.json({ code: 403, msg: '此板块仅管理员可发帖' })
            }
            if (perm === 'moderator_only') {
              if (!isUserAdmin) {
                const mods = await query('SELECT id FROM community_moderators WHERE section_id=? AND user_id=?', [Number(sectionId), userId])
                if (!mods.length) return res.json({ code: 403, msg: '此板块仅版主可发帖' })
              }
            }
            if (perm === 'member_only') {
              const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_id) {
                return res.json({ code: 403, msg: '此板块仅会员可发帖' })
              }
            }
            if (perm === 'vip_only') {
              const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].level_name || !user[0].level_name.includes('VIP')) {
                return res.json({ code: 403, msg: '此板块仅VIP会员可发帖' })
              }
            }
            if (perm === 'verified_only') {
              const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
              if (!user.length || !user[0].is_verified) {
                return res.json({ code: 403, msg: '此板块仅认证用户可发帖' })
              }
            }
          }
        }
      }

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      let finalStatus = scheduledTime ? 'scheduled' : 'pending'

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''

      const cover = coverImage || ''
      const result = await query(
        `INSERT INTO community_posts (section_id, user_id, user_name, user_avatar, title, content, device, tags, official_tags, images,
          has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission, status, scheduled_time,
           content_permission, content_price, content_price_type, access_password, access_password_tips, topic_id, cover_url, auto_hide_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [sectionId || 0, userId, userName, userAvatar, title || '', content || '', device || '', tg, ot, imgs,
         hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
         extractCode || '', permission || 'public', finalStatus, scheduledTime || null,
         contentPermission || 'public', contentPrice || 0, contentPriceType || 'balance', accessPassword || '', accessPasswordTips || '',
         topicId || 0, cover, autoHideAt || null]
      )
      const postId = result.insertId

      // 处理多话题关联
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId ? [Number(topicId)] : [])
      if (finalTopicIds.length > 0) {
        for (const tid of finalTopicIds) {
          try { await query('INSERT IGNORE INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [postId, Number(tid)]) } catch {}
        }
      }

      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [sectionId || 0])

      if (draftId) {
        await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [draftId, userId])
      }

      await progressTasksByAction(userId, userName, 'post')
      await incrementPostCount(userId)

      // 待审核帖子通知管理员和版主
      if (finalStatus === 'pending') {
        const sectionName = sectionId ? ((await query('SELECT name FROM community_sections WHERE id=? AND is_deleted=0', [sectionId]))[0]?.name || '') : ''
        const adminEmails = await getAdminEmails()
        for (const adminEmail of adminEmails) {
          sendNotificationEmail('post_review', adminEmail, {
            username: '管理员',
            subject: '帖子待审核通知',
            content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
          })
        }
        const modEmails = await getModeratorEmails(sectionId)
        for (const modEmail of modEmails) {
          if (!adminEmails.includes(modEmail)) {
            sendNotificationEmail('post_review_moderator', modEmail, {
              username: '版主',
              subject: '帖子待审核通知',
              content: `用户 ${userName} 在板块「${sectionName}」发布了帖子《${title}》，请尽快审核。`
            })
          }
        }
      }

      emitSafe(POST_EVENTS.CREATED, { postId, userId, userName, sectionId: sectionId || 0, title })

      createMentionNotifications(content, userId, userName, userAvatar, 'post', postId)

      res.json({ code: 200, msg: '发布成功', data: { id: postId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, content, tags FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })
      if (existing[0].user_id !== userId && !(await isAdminById(userId))) return res.json({ code: 403, msg: '无权编辑' })

      const {
        title, content: rawContent, device, tags, officialTags, images,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission, sectionId,
        contentPermission, contentPrice, contentPriceType, accessPassword, accessPasswordTips,
        topicId, topicIds, coverImage, editSummary, scheduledTime, autoHideAt
      } = req.body
      const content = rawContent !== undefined ? sanitizeCommunityContent(rawContent) : undefined

      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : undefined
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : undefined
      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : undefined

      await savePostRevision(existing[0].id || req.params.id, userId, existing[0].title, existing[0].content, existing[0].tags, editSummary || '用户编辑')

      const sets = []
      const params = []
      if (title !== undefined) { sets.push('title=?'); params.push(title) }
      if (content !== undefined) { sets.push('content=?'); params.push(content) }
      if (device !== undefined) { sets.push('device=?'); params.push(device) }
      if (tg !== undefined) { sets.push('tags=?'); params.push(tg) }
      if (ot !== undefined) { sets.push('official_tags=?'); params.push(ot) }
      if (imgs !== undefined) { sets.push('images=?'); params.push(imgs) }
      if (hasResource !== undefined) { sets.push('has_resource=?'); params.push(hasResource ? 1 : 0) }
      if (resourceType !== undefined) { sets.push('resource_type=?'); params.push(resourceType) }
      if (resourceUrl !== undefined) { sets.push('resource_url=?'); params.push(resourceUrl) }
      if (resourcePrice !== undefined) { sets.push('resource_price=?'); params.push(resourcePrice) }
      if (resourcePriceType !== undefined) { sets.push('resource_price_type=?'); params.push(resourcePriceType) }
      if (extractCode !== undefined) { sets.push('extract_code=?'); params.push(extractCode) }
      if (permission !== undefined) { sets.push('permission=?'); params.push(permission) }
      if (sectionId !== undefined) { sets.push('section_id=?'); params.push(sectionId) }
      if (contentPermission !== undefined) { sets.push('content_permission=?'); params.push(contentPermission) }
      if (contentPrice !== undefined) { sets.push('content_price=?'); params.push(contentPrice) }
      if (contentPriceType !== undefined) { sets.push('content_price_type=?'); params.push(contentPriceType) }
      if (accessPassword !== undefined) { sets.push('access_password=?'); params.push(accessPassword) }
      if (accessPasswordTips !== undefined) { sets.push('access_password_tips=?'); params.push(accessPasswordTips) }
      if (topicId !== undefined) { sets.push('topic_id=?'); params.push(topicId) }
      if (coverImage !== undefined) { sets.push('cover_url=?'); params.push(coverImage) }
      if (scheduledTime !== undefined) { sets.push('scheduled_time=?'); params.push(scheduledTime || null) }
      if (autoHideAt !== undefined) { sets.push('auto_hide_at=?'); params.push(autoHideAt || null) }
      sets.push(`update_time=${nowExpr}`)
      params.push(req.params.id)

      await query(`UPDATE community_posts SET ${sets.join(',')} WHERE id=?`, params)

      // 处理多话题关联更新
      const finalTopicIds = (Array.isArray(topicIds) && topicIds.length > 0)
        ? topicIds
        : (topicId !== undefined ? [Number(topicId)] : undefined)
      if (finalTopicIds !== undefined) {
        await query('DELETE FROM community_post_topics WHERE post_id=?', [req.params.id])
        if (finalTopicIds.length > 0) {
          for (const tid of finalTopicIds) {
            try { await query('INSERT INTO community_post_topics (post_id, topic_id) VALUES (?, ?)', [req.params.id, Number(tid)]) } catch {}
          }
        }
      }

      emitSafe(POST_EVENTS.UPDATED, { postId: Number(req.params.id), userId, fields: Object.keys(req.body).filter(k => k !== 'id') })

      // Notify author when admin edits their post
      if (existing[0].user_id !== userId) {
        const adminNameEdit = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被编辑', `管理员编辑了您的帖子《${title || existing[0].title}》`, 'system', existing[0].user_id, userId, adminNameEdit || '管理员']
        )
      }

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  function cleanupPostContentImages(contentStr, postId) {
    if (!contentStr) return
    try {
      const blocks = JSON.parse(contentStr)
      if (!Array.isArray(blocks)) return
      const urls = []
      for (const block of blocks) {
        if (block.type === 'image' && Array.isArray(block.images)) {
          for (const img of block.images) {
            if (typeof img === 'string' && img.startsWith('http')) urls.push(img)
          }
        }
      }
      if (!urls.length) return
      const { getDefaultStorage } = require('./storage-config.cjs')
      const { deleteFromCloud } = require('./upload.cjs')
      const { updateUserUsedBytes } = require('../utils/file-helper.cjs')
      getDefaultStorage({ userId: 0, roles: [], levelId: 0, backend: false }).then(storage => {
        if (!storage) return
        for (const url of urls) {
          try {
            const key = new URL(url).pathname.replace(/^\//, '')
            deleteFromCloud(storage, key).catch(() => {})
      } catch (e) { console.error('申请通知发送失败:', e.message) }
        }
      }).catch(() => {})
      for (const url of urls) {
        query('SELECT user_id FROM file_repository WHERE file_path=?', [url]).then(rows => {
          if (rows.length) {
            const uid = rows[0].user_id
            query('DELETE FROM file_repository WHERE file_path=?', [url]).then(() => {
              if (uid) updateUserUsedBytes(uid)
            }).catch(() => {})
          }
        }).catch(() => {})
      }
      console.log(`[community] Cleanup ${urls.length} images from post #${postId}`)
    } catch {}
  }

  app.delete('/api/community/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, section_id, title, content FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = existing[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) return res.json({ code: 403, msg: '无权删除' })

      await query(`UPDATE community_posts SET status='deleted', is_deleted=1, deleted_at=NOW(), update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [existing[0].section_id])

      deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})
      // Also clean up images embedded in post content (uploaded before post creation, ref_id=0)
      cleanupPostContentImages(existing[0].content, req.params.id)

      systemLog('delete', userId, '', 'post', Number(req.params.id),
        `${isPostOwner ? '作者' : '管理员'}删除帖子《${existing[0].title}》`)

      // Notify author when admin deletes their post
      if (!isPostOwner) {
        const adminNameDel = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被删除', `您的帖子《${existing[0].title}》已被管理员删除`, 'post_deleted', existing[0].user_id, userId, adminNameDel || '管理员']
        )
      }

      emitSafe(POST_EVENTS.DELETED, { postId: Number(req.params.id), userId, title: existing[0].title, sectionId: existing[0].section_id })

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/restore', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, is_deleted FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (existing[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可恢复帖子' })

      await query(`UPDATE community_posts SET is_deleted=0, deleted_at=NULL, update_time=${nowExpr} WHERE id=?`, [req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?) AND is_deleted=0', [req.params.id])

      systemLog('restore', userId, '', 'post', Number(req.params.id),
        `恢复帖子《${existing[0].title}》`)

      res.json({ code: 200, msg: '恢复成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/post/:id/permanent', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT user_id, title, is_deleted FROM community_posts WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (existing[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可永久删除帖子' })

      await query('DELETE FROM community_posts WHERE id=? AND user_id=?', [req.params.id, userId])
      await query('DELETE FROM community_likes WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_favorites WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_comments WHERE post_id=?', [req.params.id])
      await query('DELETE FROM community_post_topics WHERE post_id=?', [req.params.id])

      systemLog('permanent_delete', userId, '', 'post', Number(req.params.id),
        `永久删除帖子《${existing[0].title}》`)

      res.json({ code: 200, msg: '永久删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post Review APIs ====================

  app.get('/api/community/admin/posts/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSections = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSections.length === 0) return res.json({ code: 403, msg: '无权限' })

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      let whereClause = "p.status='pending'"
      const params = []
      if (!isAdminUser && modSections.length > 0) {
        whereClause += ` AND p.section_id IN (${modSections.map(() => '?').join(',')})`
        params.push(...modSections)
      }

      const countResult = await query(`SELECT COUNT(*) as total FROM community_posts p WHERE ${whereClause}`, params)
      const total = countResult[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                CASE WHEN p.user_avatar LIKE 'avatar:%' THEN '' ELSE p.user_avatar END as userAvatar, p.title, p.content, p.images,
                p.has_resource as hasResource, p.resource_type as resourceType,
                p.content_permission as contentPermission, p.content_price as contentPrice,
                p.content_price_type as contentPriceType, p.hidden_content as hiddenContent,
                p.access_password as accessPassword, p.access_password_tips as accessPasswordTips,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.extract_code as extractCode, p.free_read as freeRead, p.free_count as freeCount,
                p.create_time as createTime, p.scheduled_time as scheduledTime,
                p.auto_hide_at as autoHideAt
         FROM community_posts p WHERE ${whereClause}
         ORDER BY p.create_time ASC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        params
      )

      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canReviewModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      const operatorName = await getAdminUserName(req)
      await query(`UPDATE community_posts SET status='published', update_time=${nowExpr}, reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [userId, req.params.id])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=(SELECT section_id FROM community_posts WHERE id=?) AND is_deleted=0', [req.params.id])

      const adminNameAp = await getAdminUserName(req)
      if (post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子审核通过', `您的帖子《${post[0].title}》已通过审核并发布`, 'post_approved', post[0].user_id, userId, adminNameAp || '管理员']
        )
      }
      systemLog('approve', userId, adminNameAp, 'post', Number(req.params.id), `审核通过帖子《${post[0].title}》`)
      await logModeratorAction(0, userId, operatorName, 'approve', 'post', Number(req.params.id), `审核通过《${post[0].title}》`)

      res.json({ code: 200, msg: '已通过审核' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/post/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canReviewModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const { reason = '内容不符合规范' } = req.body
      const post = await query('SELECT id, user_id, title FROM community_posts WHERE id=? AND status=?', [req.params.id, 'pending'])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在或已处理' })

      const operatorName = await getAdminUserName(req)
      await query(`UPDATE community_posts SET status='rejected', reject_reason=?, update_time=${nowExpr}, reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [reason, userId, req.params.id])

      const adminNameRj = await getAdminUserName(req)
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
        ['帖子审核未通过', `您的帖子《${post[0].title}》未通过审核，原因：${reason}`, 'post_rejected', post[0].user_id, userId, adminNameRj || '管理员']
      )
      systemLog('reject', userId, adminNameRj, 'post', Number(req.params.id), `驳回帖子《${post[0].title}》，原因：${reason}`)
      await logModeratorAction(0, userId, operatorName, 'reject', 'post', Number(req.params.id), `驳回《${post[0].title}》`)

      res.json({ code: 200, msg: '已驳回' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const existing = await query('SELECT id FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_likes WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET like_count = GREATEST(0, like_count - 1) WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: false })
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: post[0]?.likeCount || 0 } })
      } else {
        await query('INSERT INTO community_likes (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET like_count = like_count + 1 WHERE id=?', [postId])
        const post = await query('SELECT like_count as likeCount FROM community_posts WHERE id=?', [postId])
        await progressTasksByAction(userId, '', 'like')
        await incrementLikeReceived(postId)
        emitSafe(POST_EVENTS.LIKE_TOGGLED, { postId, userId, isLiked: true })

        // 点赞通知：通知帖子作者
        const postAuthor = await query('SELECT user_id, title FROM community_posts WHERE id=?', [postId])
        if (postAuthor.length > 0 && postAuthor[0].user_id !== userId) {
          const likerInfo = await query('SELECT nickname, username, avatar FROM users WHERE id=?', [userId])
          const likerName = likerInfo.length > 0 ? (likerInfo[0].nickname || likerInfo[0].username) : ''
          const likerAvatar = likerInfo.length > 0 ? (likerInfo[0].avatar || '') : ''
          await query(
            `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
             VALUES ('新的点赞', ?,'like', ?, ?, ?, ?, ?)`,
            [`${likerName} 点赞了您的帖子《${postAuthor[0].title}》`, `/community/post/${postId}`, postAuthor[0].user_id, userId, likerName, likerAvatar]
          )
        }

        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: post[0]?.likeCount || 0 } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const commentId = Number(req.params.id)
      const existing = await query('SELECT id FROM comment_likes WHERE comment_id=? AND user_id=?', [commentId, userId])
      if (existing.length > 0) {
        await query('DELETE FROM comment_likes WHERE comment_id=? AND user_id=?', [commentId, userId])
        await query('UPDATE community_comments SET like_count = GREATEST(0, like_count - 1) WHERE id=?', [commentId])
        const c = await query('SELECT like_count as likeCount FROM community_comments WHERE id=?', [commentId])
        res.json({ code: 200, msg: '已取消点赞', data: { isLiked: false, likeCount: c[0]?.likeCount || 0 } })
      } else {
        await query('INSERT INTO comment_likes (comment_id, user_id) VALUES (?,?)', [commentId, userId])
        await query('UPDATE community_comments SET like_count = like_count + 1 WHERE id=?', [commentId])
        const c = await query('SELECT like_count as likeCount FROM community_comments WHERE id=?', [commentId])
        await progressTasksByAction(userId, '', 'like')
        res.json({ code: 200, msg: '已点赞', data: { isLiked: true, likeCount: c[0]?.likeCount || 0 } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const groupId = req.body?.groupId ? Number(req.body.groupId) : 0

      // 新分组收藏系统
      if (groupId > 0) {
        const defaultRows = await query('SELECT id FROM collection_favorite_groups WHERE user_id=?', [userId])
        if (!defaultRows.length) {
          await query("INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,'默认收藏夹',0)", [userId])
        }
        const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [groupId, userId])
        if (!g.length) return res.json({ code: 400, msg: '分组不存在' })

        await query(
          'INSERT INTO post_favorites (user_id, post_id, group_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE group_id=VALUES(group_id)',
          [userId, postId, groupId]
        )
        await query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=? AND favorite_count = (SELECT cnt FROM (SELECT COUNT(*) as cnt FROM post_favorites WHERE post_id=?) t)', [postId, postId])
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: true })
        return res.json({ code: 200, msg: '收藏成功' })
      }

      // 旧toggle逻辑
      const existing = await query('SELECT id FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])

      if (existing.length > 0) {
        await query('DELETE FROM community_favorites WHERE post_id=? AND user_id=?', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = GREATEST(0, favorite_count - 1) WHERE id=?', [postId])
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: false })
        res.json({ code: 200, msg: '已取消收藏', data: { isFavorited: false } })
      } else {
        await query('INSERT INTO community_favorites (post_id, user_id) VALUES (?,?)', [postId, userId])
        await query('UPDATE community_posts SET favorite_count = favorite_count + 1 WHERE id=?', [postId])
        await progressTasksByAction(userId, '', 'favorite')
        emitSafe(POST_EVENTS.FAVORITE_TOGGLED, { postId, userId, isFavorited: true })
        res.json({ code: 200, msg: '已收藏', data: { isFavorited: true } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/user/favorites', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize

      const totalRow = await query(
        `SELECT COUNT(*) as total FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id WHERE f.user_id=? AND p.status='published'`,
        [userId]
      )
      const total = totalRow[0]?.total || 0

      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as postUserId, p.user_name as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar,
                p.title, p.content, p.device, p.tags, p.official_tags as officialTags,
                p.images, p.has_resource as hasResource, p.resource_type as resourceType,
                p.resource_price as resourcePrice, p.resource_price_type as resourcePriceType,
                p.permission, p.is_pinned as isPinned, p.is_essence as isEssence,
                p.is_hot as isHot, p.is_locked as isLocked, p.status,
                p.like_count as likeCount, p.comment_count as commentCount,
                p.view_count as viewCount, p.favorite_count as favoriteCount,
                p.is_global_pinned as isGlobalPinned,
                p.custom_badge as customBadge,
                p.content_permission as contentPermission, p.content_price as contentPrice, p.content_price_type as contentPriceType,
                p.create_time as createTime, p.update_time as updateTime,
                u.level_name as userLevelName, u.is_verified as userIsVerified,
                 COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                 (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                 COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                 COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                 COALESCE(ml.text_color, '#508DFF') as userLevelTextColor,
                 COALESCE(ml.bg_color, '#508DFF') as userLevelBgColor,
                 ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 u.active_title_name as userTitleName,
                 ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                 (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                 f.create_time as favTime
         FROM community_favorites f
         INNER JOIN community_posts p ON f.post_id = p.id
         LEFT JOIN users u ON p.user_id = u.id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         WHERE f.user_id=? AND p.status='published'
         ORDER BY f.create_time DESC
         LIMIT ${pageSize} OFFSET ${offset}`,
        [userId]
      )

      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
        item.isPinned = !!item.isPinned
        item.isEssence = !!item.isEssence
        item.isHot = !!item.isHot
        item.isGlobalPinned = !!item.isGlobalPinned
      }

      // 过滤付费内容
      if (list.length > 0) {
        try {
          const paidPosts = list.filter(p => p.contentPermission === 'paid')
          if (paidPosts.length > 0) {
            const paidIds = paidPosts.map(p => p.id)
            const paidSet = new Set()
            const purchases = await query(
              `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${paidIds.map(() => '?').join(',')})`,
              [userId, ...paidIds]
            )
            purchases.forEach(p => paidSet.add(p.content_id))
            const isAdmin = await isAdminById(userId)
            for (const item of paidPosts) {
              if (item.postUserId === userId || isAdmin) continue
              if (paidSet.has(item.id)) continue
              item.content = '部分内容付费 - 需购买后查看'
              item.contentFiltered = true
              try { item.images = [] } catch {}
            }
          }
        } catch {}
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page, pageSize } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.PINNED, { postId: Number(req.params.id), userId, isPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNamePin = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被置顶', `您的帖子《${post[0].title}》已被管理员置顶`, 'post_pinned', post[0].user_id, userId, adminNamePin || '管理员']
        )
      }

      const adminName = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '版块置顶' : '取消版块置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已置顶' : '已取消置顶', data: { isPinned: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/global-pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const post = await query('SELECT user_id, title, is_global_pinned FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_global_pinned ? 0 : 1
      await query('UPDATE community_posts SET is_global_pinned=? WHERE id=?', [newVal, req.params.id])

      emitSafe(POST_EVENTS.GLOBAL_PINNED, { postId: Number(req.params.id), userId, isGlobalPinned: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameGp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被全站置顶', `您的帖子《${post[0].title}》已被管理员全站置顶`, 'post_pinned', post[0].user_id, userId, adminNameGp || '管理员']
        )
      }

      const adminName2 = await getAdminUserName(req)
      systemLog(newVal ? 'pin' : 'unpin', userId, adminName2, 'post', Number(req.params.id),
        `${newVal ? '全站置顶' : '取消全站置顶'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已全站置顶' : '已取消全站置顶', data: { isGlobalPinned: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 自定义徽章
  app.post('/api/community/post/:id/custom-badge', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { badge } = req.body || {}
      const post = await query('SELECT id, title, custom_badge FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const val = badge ? String(badge).trim().slice(0, 10) : ''
      await query('UPDATE community_posts SET custom_badge=? WHERE id=?', [val, req.params.id])

      emitSafe(POST_EVENTS.BADGE_CHANGED, { postId: Number(req.params.id), userId, badge: val || null, title: post[0].title })

      const adminNameCB = await getAdminUserName(req)
      systemLog(val ? 'set_badge' : 'clear_badge', userId, adminNameCB, 'post', Number(req.params.id),
        `${val ? '设置自定义徽章' : '清除自定义徽章'}《${post[0].title}》${val ? '：' + val : ''}`)

      res.json({ code: 200, msg: val ? '自定义徽章已设置' : '自定义徽章已清除', data: { customBadge: val } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_essence FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_essence ? 0 : 1
      await query('UPDATE community_posts SET is_essence=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.ESSENCED, { postId: Number(req.params.id), userId, isEssence: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameEss = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被加精', `您的帖子《${post[0].title}》已被管理员设为精华`, 'post_essence', post[0].user_id, userId, adminNameEss || '管理员']
        )
      }

      const adminName = await getAdminUserName(req) // needed for systemLog below
      systemLog(newVal ? 'essence' : 'unessence', userId, adminName, 'post', Number(req.params.id),
        `${newVal ? '设为精华' : '取消精华'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已加精' : '已取消加精', data: { isEssence: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/hot', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_hot FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_hot ? 0 : 1
      // 手动取消热帖后禁止自动升级；手动设为热帖则重置
      const disabled = newVal ? 0 : 1
      await query('UPDATE community_posts SET is_hot=?, hot_manually_disabled=? WHERE id=?', [newVal, disabled, req.params.id])
      emitSafe(POST_EVENTS.HOT_TOGGLED, { postId: Number(req.params.id), userId, isHot: !!newVal, title: post[0].title })

      if (newVal && post[0].user_id !== userId) {
        const adminNameHot = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被设为热帖', `您的帖子《${post[0].title}》已被管理员设为热帖`, 'system', post[0].user_id, userId, adminNameHot || '管理员']
        )
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      } else {
        const adminNameHot = await getAdminUserName(req)
        systemLog(newVal ? 'hot' : 'unhot', userId, adminNameHot, 'post', Number(req.params.id),
          `${newVal ? '设为热帖' : '取消热帖'}帖子《${post[0].title}》`)
      }
      res.json({ code: 200, msg: newVal ? '已设为热帖' : '已取消热帖', data: { isHot: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT user_id, title, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const newVal = post[0].is_locked ? 0 : 1
      await query('UPDATE community_posts SET is_locked=? WHERE id=?', [newVal, req.params.id])
      emitSafe(POST_EVENTS.LOCKED, { postId: Number(req.params.id), userId, isLocked: !!newVal, title: post[0].title })

      const adminNameLock = await getAdminUserName(req)
      if (newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被锁定', `您的帖子《${post[0].title}》已被管理员锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
      }
      if (!newVal && post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子已解锁', `您的帖子《${post[0].title}》已被管理员解除锁定`, 'system', post[0].user_id, userId, adminNameLock || '管理员']
        )
      }

      systemLog(newVal ? 'lock' : 'unlock', userId, adminNameLock, 'post', Number(req.params.id),
        `${newVal ? '锁定' : '解锁'}帖子《${post[0].title}》`)
      res.json({ code: 200, msg: newVal ? '已锁定' : '已解锁', data: { isLocked: !!newVal } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/coin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再打赏' })

      const { amount = 1, coinType = 'coin' } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '投币数量必须大于0' })

      const post = await query('SELECT id, title, user_id, user_name, coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (userId === post[0].user_id) return res.json({ code: 400, msg: '不能打赏自己的帖子' })

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field}, nickname, avatar FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])

      const unitLabel = coinType === 'points' ? '积分' : '余额'
      const fromName = user[0].nickname || ('user_' + userId)

      const postTitle = post[0].title || ''

      if (coinType === 'points') {
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '帖子打赏', ?)`,
          [userId, fromName, coinAmount, userId, `打赏帖子「${postTitle}」`])
      } else {
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '帖子打赏', ?)`,
          [userId, fromName, coinAmount, userId, `打赏帖子「${postTitle}」`])
      }

      await query('UPDATE community_posts SET coin_count = coin_count + ? WHERE id=?', [coinAmount, req.params.id])
      const fromAvatar = user[0].avatar || ''
      await query(
        'INSERT INTO community_coin_logs (post_id, from_user_id, from_user_name, from_user_avatar, to_user_id, amount, coin_type) VALUES (?,?,?,?,?,?,?)',
        [req.params.id, userId, fromName, fromAvatar, post[0].user_id, coinAmount, coinType]
      )

      const postAuthorId = post[0].user_id

      // 通知帖子作者收到打赏
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, ?, ?, '')`,
        ['打赏通知', `${fromName} 打赏了您的帖子「${postTitle}」${coinAmount}${unitLabel}`, postAuthorId, userId, fromName]
      )

      // 通知打赏者打赏成功
      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?, ?, 'system', ?, 0, ?, '')`,
        ['打赏成功', `您成功打赏了 ${post[0].user_name || '用户'} 的帖子「${postTitle}」${coinAmount}${unitLabel}`, userId, sysOpName]
      )

      const updated = await query('SELECT coin_count as coinCount FROM community_posts WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '打赏成功', data: { coinCount: updated[0]?.coinCount || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 打赏记录
  app.get('/api/community/post/:id/coin-logs', async (req, res) => {
    try {
      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const logs = await query(
        'SELECT id, from_user_id as fromUserId, from_user_name as fromUserName, from_user_avatar as fromUserAvatar, amount, coin_type as coinType, create_time as createTime FROM community_coin_logs WHERE post_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
        [req.params.id, parseInt(pageSize), offset]
      )
      const count = await query('SELECT COUNT(*) as total FROM community_coin_logs WHERE post_id=?', [req.params.id])
      res.json({ code: 200, msg: 'success', data: { list: logs, total: count[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买
  app.post('/api/community/attach/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 400, msg: '请先登录后再下载' })

      const { postId, attachUrl, coinType = 'coin', amount = 0 } = req.body
      const coinAmount = Number(amount)
      if (coinAmount <= 0) return res.json({ code: 400, msg: '金额有误' })

      // 查是否已购买
      const bought = await query(
        'SELECT id FROM community_attach_purchases WHERE post_id=? AND user_id=? AND attach_url=?',
        [postId || 0, userId, attachUrl || '']
      )
      if (bought && bought.length > 0) {
        return res.json({ code: 200, msg: '已购买过，无需重复购买' })
      }

      const field = coinType === 'points' ? 'points' : 'balance'
      const user = await query(`SELECT ${field}, username FROM users WHERE id=?`, [userId])
      if (!user || user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (Number(user[0][field]) < coinAmount) return res.json({ code: 400, msg: (coinType === 'points' ? '积分' : '余额') + '不足' })

      await query(`UPDATE users SET ${field} = ${field} - ? WHERE id=?`, [coinAmount, userId])
      if (coinType === 'points') {
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '附件购买', ?)`,
          [userId, user[0].username || '', coinAmount, userId, `购买帖子附件 #${postId || 0}`])
      } else {
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '附件购买', ?)`,
          [userId, user[0].username || '', coinAmount, userId, `购买帖子附件 #${postId || 0}`])
      }
      await query(
        'INSERT INTO community_attach_purchases (post_id, user_id, attach_url, coin_type, coin_amount) VALUES (?,?,?,?,?)',
        [postId || 0, userId, attachUrl || '', coinType, coinAmount]
      )

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // 附件购买状态查询
  app.get('/api/community/attach/purchased', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { urls: [] } })

      const rows = await query(
        'SELECT attach_url FROM community_attach_purchases WHERE post_id=? AND user_id=?',
        [req.query.postId || 0, userId]
      )
      res.json({ code: 200, data: { urls: (rows || []).map(r => r.attach_url) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Comment APIs ====================

  app.get('/api/community/post/:id/comments', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, sortBy = 'default' } = req.query
      const postId = Number(req.params.id)

      const currentUserId = await getUserId(req)
      const isAdminUser = await isAdmin(req)
      let statusFilter = "AND c.status='published'"
      if (currentUserId > 0) {
        const postOwner = await query('SELECT user_id FROM community_posts WHERE id=?', [postId])
        const isPostOwner = postOwner.length > 0 && postOwner[0].user_id === currentUserId
        if (isAdminUser || isPostOwner) {
          statusFilter = ''
        } else {
          statusFilter = `AND (c.status='published' OR (c.status='pending' AND c.user_id=${currentUserId}) OR (c.status='rejected' AND c.user_id=${currentUserId}))`
        }
      }

      const countResult = await query(
        `SELECT COUNT(*) as total FROM community_comments c WHERE c.post_id=? AND c.parent_id=0 ${statusFilter}`, [postId]
      )
      const total = countResult[0]?.total || 0
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      const orderClause = sortBy === 'hot'
        ? 'ORDER BY c.is_pinned DESC, (c.like_count + c.reply_count) DESC, c.create_time DESC'
        : 'ORDER BY c.is_pinned DESC, c.create_time DESC'

      const comments = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                c.content, c.images,
                c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                c.create_time as createTime,
                u.is_verified as userIsVerified,
                  COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                  (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                  COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                 u.active_title_name as userTitleName,
                 ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                 ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                 (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                 (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                 (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
           FROM community_comments c
          LEFT JOIN users u ON c.user_id = u.id
          LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
          LEFT JOIN membership_levels ml ON ml.id = u.level_id
           WHERE c.post_id=? AND c.parent_id=0 ${statusFilter}
          ${orderClause} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        [postId]
      )

      let allReplies = []
      if (comments.length > 0) {
        const commentIds = comments.map(c => c.id)
        allReplies = await query(
          `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                  c.content, c.images,
                  c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                  c.create_time as createTime,
                  u.is_verified as userIsVerified,
                  COALESCE((SELECT el.name FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), 'Lv.1') as userExpLevelName,
                  (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                  COALESCE((SELECT el.text_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#FFFFFF') as userExpLevelTextColor,
                  COALESCE((SELECT el.bg_color FROM experience_levels el WHERE el.exp_required <= u.experience AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1), '#508DFF') as userExpLevelBgColor,
                   u.active_title_name as userTitleName,
                   ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                   ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                   (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                   (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userAllTitleNames,
                   (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame
            FROM community_comments c
            LEFT JOIN users u ON c.user_id = u.id
            LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
            LEFT JOIN membership_levels ml ON ml.id = u.level_id
            WHERE c.post_id=? AND c.parent_id IN (${commentIds.map(() => '?').join(',')})
           ORDER BY c.create_time ASC`,
          [postId, ...commentIds]
        )
        const replyMap = {}
        for (const r of allReplies) {
          if (!replyMap[r.parentId]) replyMap[r.parentId] = []
          replyMap[r.parentId].push(r)
        }
        for (const c of comments) {
          c.replies = replyMap[c.id] || []
          try { c.images = c.images ? JSON.parse(c.images) : [] } catch { c.images = [] }
          for (const r of (c.replies || [])) {
            try { r.images = r.images ? JSON.parse(r.images) : [] } catch { r.images = [] }
          }
        }
      }

      if (currentUserId > 0 && comments.length > 0) {
        const allIds = [...comments.map(c => c.id), ...allReplies.map(r => r.id)]
        if (allIds.length > 0) {
          const likedRows = await query(
            `SELECT comment_id FROM comment_likes WHERE comment_id IN (${allIds.map(() => '?').join(',')}) AND user_id=?`,
            [...allIds, currentUserId]
          )
          const likedSet = new Set(likedRows.map(r => r.comment_id))
          for (const c of comments) c.isLiked = likedSet.has(c.id) ? 1 : 0
          for (const r of allReplies) r.isLiked = likedSet.has(r.id) ? 1 : 0
        }
      }

      res.json({ code: 200, msg: 'success', data: { list: comments, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { content: rawContent, parent_id: parentId = 0, images } = req.body
      const content = sanitizeCommunityContent(rawContent)
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''
      const imgStr = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      const postRow = await query('SELECT section_id FROM community_posts WHERE id=?', [Number(req.params.id)])
      let commentStatus = 'published'
      if (postRow.length > 0) {
        const secRow = await query('SELECT comment_review_required FROM community_sections WHERE id=? AND is_deleted=0', [postRow[0].section_id])
        if (secRow.length > 0 && secRow[0].comment_review_required === 1) {
          commentStatus = 'pending'
        }
      }

      const result = await query(
        `INSERT INTO community_comments (post_id, parent_id, user_id, user_name, user_avatar, content, images, status)
         VALUES (?,?,?,?,?,?,?,?)`,
        [Number(req.params.id), Number(parentId), userId, userName, userAvatar, content.trim(), imgStr, commentStatus]
      )
      const commentId = result.insertId

      if (Number(parentId) > 0) {
        await query('UPDATE community_comments SET reply_count = reply_count + 1 WHERE id=?', [Number(parentId)])
      }
      if (commentStatus === 'published') {
        await query('UPDATE community_posts SET comment_count = comment_count + 1, update_time=' + nowExpr + ' WHERE id=?', [req.params.id])
      }

      await progressTasksByAction(userId, userName, 'comment')
      await incrementCommentCount(userId)

      // 评论回复通知
      const postInfo = await query('SELECT user_id, title FROM community_posts WHERE id=?', [Number(req.params.id)])
      if (postInfo.length > 0) {
        if (Number(parentId) > 0) {
          const parentInfo = await query('SELECT user_id, user_name FROM community_comments WHERE id=?', [Number(parentId)])
          if (parentInfo.length > 0 && parentInfo[0].user_id !== userId) {
            const commentPreview = content.trim().length > 80 ? content.trim().substring(0, 80) + '...' : content.trim()
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES ('评论回复', ?,'comment', ?, ?, ?, ?, ?)`,
              [`${userName}: ${commentPreview}`, `/community/post/${Number(req.params.id)}`, parentInfo[0].user_id, userId, userName, userAvatar]
            )
            const targetEmail = await getUserEmail(parentInfo[0].user_id)
            if (targetEmail) {
              sendNotificationEmail('comment_reply', targetEmail, {
                username: parentInfo[0].user_name,
                subject: '评论收到新回复',
                content: `用户 ${userName} 回复了您在《${postInfo[0].title}》中的评论。`
              })
            }
          }
        } else {
          if (postInfo[0].user_id !== userId) {
            const commentPreview = content.trim().length > 80 ? content.trim().substring(0, 80) + '...' : content.trim()
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES ('新的评论', ?,'comment', ?, ?, ?, ?, ?)`,
              [`${userName}: ${commentPreview}`, `/community/post/${Number(req.params.id)}`, postInfo[0].user_id, userId, userName, userAvatar]
            )
            const targetEmail = await getUserEmail(postInfo[0].user_id)
            if (targetEmail) {
              sendNotificationEmail('comment_reply', targetEmail, {
                username: '',
                subject: '帖子收到新评论',
                content: `用户 ${userName} 评论了您的帖子《${postInfo[0].title}》。`
              })
            }
          }
        }
      }

      createMentionNotifications(content.trim(), userId, userName, userAvatar, 'comment', Number(req.params.id))

      emitSafe(COMMENT_EVENTS.CREATED, { commentId, postId: Number(req.params.id), userId, userName, parentId: Number(parentId) })

      const msg = commentStatus === 'pending' ? '评论已提交，等待审核' : '评论成功'
      res.json({ code: 200, msg, data: { id: commentId, status: commentStatus } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isCommentOwner = c.user_id === userId
      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)

      if (!isCommentOwner && !isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权删除此评论' })
      }

      const isReply = Number(c.parent_id) > 0
      if (isReply) {
        const isReplyR = await query('SELECT parent_id FROM community_comments WHERE id=?', [req.params.id])
        if (isReplyR.length && Number(isReplyR[0].parent_id) > 0) {
          await query('UPDATE community_comments SET reply_count = GREATEST(0, reply_count - 1) WHERE id=?', [isReplyR[0].parent_id])
        }
        await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
        await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id=?', [c.post_id])
      } else {
        const replyIds = await query('SELECT id FROM community_comments WHERE parent_id=?', [req.params.id])
        for (const r of replyIds) {
          deleteFileRecordsByRef(r.id, 'comment').catch(() => {})
        }
        await query('DELETE FROM community_comments WHERE id=? OR parent_id=?', [req.params.id, req.params.id])
        const replyCount = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE parent_id=?', [req.params.id])
        const deletedReplies = replyCount[0]?.cnt || 0
        await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - ' + (1 + deletedReplies) + ') WHERE id=?', [c.post_id])
      }

      deleteFileRecordsByRef(req.params.id, 'comment').catch(() => {})

      emitSafe(COMMENT_EVENTS.DELETED, { commentId: Number(req.params.id), postId: c.post_id, userId })

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT id, post_id, parent_id, user_id FROM community_comments WHERE id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })

      const c = comment[0]
      if (Number(c.parent_id) > 0) return res.json({ code: 400, msg: '不能置顶回复' })

      const post = await query('SELECT user_id FROM community_posts WHERE id=?', [c.post_id])
      if (!post || post.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      const isPostOwner = post[0].user_id === userId
      const isAdminUser = await isAdmin(req)
      if (!isPostOwner && !isAdminUser) {
        return res.json({ code: 403, msg: '无权置顶此评论' })
      }

      const current = await query('SELECT is_pinned FROM community_comments WHERE id=?', [req.params.id])
      const newPinned = current[0]?.is_pinned ? 0 : 1
      await query('UPDATE community_comments SET is_pinned=? WHERE id=?', [newPinned, req.params.id])

      res.json({ code: 200, msg: newPinned ? '置顶成功' : '取消置顶成功', data: { isPinned: !!newPinned } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Comment Moderation APIs ====================

  app.get('/api/community/moderator/comments/pending', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      if (!isAdminUser) {
        const sectionIds = await getModeratorSectionIds(userId)
        if (sectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })
      }

      const { page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)

      let whereClause = "WHERE cc.status='pending'"
      if (!isAdminUser) {
        const sectionIds = await getModeratorSectionIds(userId)
        // 需要通过 post 关联 section
        whereClause += ` AND cp.section_id IN (${sectionIds.map(() => '?').join(',')})`
      }

      const countResult = await query(
        `SELECT COUNT(*) as total FROM community_comments cc
         JOIN community_posts cp ON cc.post_id = cp.id
         ${whereClause}`,
        isAdminUser ? [] : (await getModeratorSectionIds(userId))
      )
      const total = countResult[0]?.total || 0

      const params = isAdminUser ? [] : (await getModeratorSectionIds(userId))
      const list = await query(
        `SELECT cc.id, cc.post_id as postId, cc.parent_id as parentId, cc.user_id as userId,
                cc.user_name as userName, cc.content, cc.images, cc.status,
                cc.like_count as likeCount, cc.reply_count as replyCount,
                cc.create_time as createTime,
                cp.title as postTitle, cp.section_id as sectionId,
                cs.name as sectionName
         FROM community_comments cc
         JOIN community_posts cp ON cc.post_id = cp.id
         JOIN community_sections cs ON cp.section_id = cs.id
         ${whereClause}
         ORDER BY cc.create_time ASC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        params
      )
      for (const item of list) {
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/moderator/comment/:id/approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      const c = comment[0]

      if (!(await canAccessSection(userId, c.section_id))) return res.json({ code: 403, msg: '无权限' })

      await query("UPDATE community_comments SET status='published' WHERE id=?", [req.params.id])
      await query('UPDATE community_posts SET comment_count = comment_count + 1 WHERE id=?', [c.post_id])

      const targetEmail = await getUserEmail(c.user_id)
      if (targetEmail) {
        sendNotificationEmail('comment_approved', targetEmail, {
          username: c.user_name,
          subject: '评论已通过审核',
          content: '您的评论已通过审核并发布。'
        })
      }

      res.json({ code: 200, msg: '审核通过' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/moderator/comment/:id/reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { reason } = req.body
      const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=?', [req.params.id])
      if (!comment || comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
      const c = comment[0]

      if (!(await canAccessSection(userId, c.section_id))) return res.json({ code: 403, msg: '无权限' })

      await query("UPDATE community_comments SET status='rejected' WHERE id=?", [req.params.id])

      const targetEmail = await getUserEmail(c.user_id)
      if (targetEmail) {
        const reasonText = reason ? ` 原因：${reason}` : ''
        sendNotificationEmail('comment_rejected', targetEmail, {
          username: c.user_name,
          subject: '评论未通过审核',
          content: `您的评论未通过审核。${reasonText}`
        })
      }

      res.json({ code: 200, msg: '已拒绝' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/moderator/comments/batch-approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { ids } = req.body
      if (!ids || !Array.isArray(ids) || ids.length === 0) return res.json({ code: 400, msg: '缺少评论ID列表' })

      let approved = 0
      for (const commentId of ids) {
        const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=? AND cc.status=?', [commentId, 'pending'])
        if (comment.length === 0) continue
        const c = comment[0]
        if (!(await canAccessSection(userId, c.section_id))) continue

        await query("UPDATE community_comments SET status='published' WHERE id=?", [commentId])
        await query('UPDATE community_posts SET comment_count = comment_count + 1 WHERE id=?', [c.post_id])
        approved++

        const targetEmail = await getUserEmail(c.user_id)
        if (targetEmail) {
          sendNotificationEmail('comment_approved', targetEmail, {
            username: c.user_name,
            subject: '评论已通过审核',
            content: '您的评论已通过审核并发布。'
          })
        }
      }

      res.json({ code: 200, msg: `已通过 ${approved} 条评论` })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/moderator/comments/batch-reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { ids, reason } = req.body
      if (!ids || !Array.isArray(ids) || ids.length === 0) return res.json({ code: 400, msg: '缺少评论ID列表' })

      let rejected = 0
      for (const commentId of ids) {
        const comment = await query('SELECT cc.id, cc.post_id, cc.user_id, cc.user_name, cp.section_id FROM community_comments cc JOIN community_posts cp ON cc.post_id = cp.id WHERE cc.id=? AND cc.status=?', [commentId, 'pending'])
        if (comment.length === 0) continue
        const c = comment[0]
        if (!(await canAccessSection(userId, c.section_id))) continue

        await query("UPDATE community_comments SET status='rejected' WHERE id=?", [commentId])
        rejected++

        const targetEmail = await getUserEmail(c.user_id)
        if (targetEmail) {
          const reasonText = reason ? ` 原因：${reason}` : ''
          sendNotificationEmail('comment_rejected', targetEmail, {
            username: c.user_name,
            subject: '评论未通过审核',
            content: `您的评论未通过审核。${reasonText}`
          })
        }
      }

      res.json({ code: 200, msg: `已拒绝 ${rejected} 条评论` })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Draft APIs ====================

  app.get('/api/community/drafts', async (req, res) => {
    try {
      const { userId } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId参数' })

      const drafts = await query(
        `SELECT id, user_id as userId, section_id as sectionId, title, content,
                images, tags, official_tags as officialTags, has_resource as hasResource,
                resource_type as resourceType, resource_url as resourceUrl,
                resource_price as resourcePrice, resource_price_type as resourcePriceType,
                extract_code as extractCode, permission,
                create_time as createTime, update_time as updateTime
         FROM community_drafts WHERE user_id=? ORDER BY update_time DESC`, [Number(userId)]
      )
      for (const d of drafts) {
        try { d.tags = d.tags ? JSON.parse(d.tags) : [] } catch { d.tags = [] }
        try { d.officialTags = d.officialTags ? JSON.parse(d.officialTags) : [] } catch { d.officialTags = [] }
        try { d.images = d.images ? JSON.parse(d.images) : [] } catch { d.images = [] }
        d.hasResource = !!d.hasResource
      }

      res.json({ code: 200, msg: 'success', data: drafts })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/draft', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const {
        id, sectionId, title, content: rawContent, images, tags, officialTags,
        hasResource, resourceType, resourceUrl, resourcePrice, resourcePriceType,
        extractCode, permission
      } = req.body
      const content = sanitizeCommunityContent(rawContent)

      const imgs = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'
      const tg = tags ? (typeof tags === 'string' ? tags : JSON.stringify(tags)) : '[]'
      const ot = officialTags ? (typeof officialTags === 'string' ? officialTags : JSON.stringify(officialTags)) : '[]'

      if (id) {
        await query(
          `UPDATE community_drafts SET section_id=?, title=?, content=?, images=?, tags=?, official_tags=?,
           has_resource=?, resource_type=?, resource_url=?, resource_price=?, resource_price_type=?,
           extract_code=?, permission=?, update_time=${nowExpr}
           WHERE id=? AND user_id=?`,
          [sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public', id, userId]
        )
        res.json({ code: 200, msg: '草稿已更新', data: { id } })
      } else {
        const result = await query(
          `INSERT INTO community_drafts (user_id, section_id, title, content, images, tags, official_tags,
            has_resource, resource_type, resource_url, resource_price, resource_price_type, extract_code, permission)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [userId, sectionId || 0, title || '', content || '', imgs, tg, ot,
           hasResource ? 1 : 0, resourceType || '', resourceUrl || '', resourcePrice || 0, resourcePriceType || 'free',
           extractCode || '', permission || 'public']
        )
        res.json({ code: 200, msg: '草稿已保存', data: { id: result.insertId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/draft/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      await query('DELETE FROM community_drafts WHERE id=? AND user_id=?', [req.params.id, userId])
      res.json({ code: 200, msg: '草稿已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin APIs ====================

  app.get('/api/community/admin/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  p.title, p.status, p.is_pinned as isPinned, p.is_global_pinned as isGlobalPinned,
                  p.is_essence as isEssence, p.is_hot as isHot, p.custom_badge as customBadge,
                  p.like_count as likeCount, p.comment_count as commentCount,
                  p.view_count as viewCount, p.create_time as createTime
                FROM community_posts p WHERE 1=1`
      const params = []

      if (status) { sql += ' AND p.status=?'; params.push(status) }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      const list = await query(sql + ` ORDER BY p.id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/community/admin/post/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { status } = req.body
      if (!status) return res.json({ code: 400, msg: '缺少status参数' })

      await query('UPDATE community_posts SET status=?, update_time=' + nowExpr + ' WHERE id=?', [status, req.params.id])
      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId, reason, duration } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      let bannedUntil = null
      if (duration) {
        const hours = Number(duration)
        bannedUntil = `DATE_ADD(NOW(), INTERVAL ${hours} HOUR)`
      }

      const userInfo = await query('SELECT nickname FROM users WHERE id=?', [targetUserId])
      const userName = userInfo[0]?.nickname || ''

      const existing = await query('SELECT id FROM community_banned_users WHERE user_id=?', [targetUserId])
      if (existing.length > 0) {
        if (bannedUntil) {
          await query(`UPDATE community_banned_users SET reason=?, banned_until=${bannedUntil} WHERE user_id=?`,
            [reason || '', targetUserId])
        } else {
          await query('UPDATE community_banned_users SET reason=?, banned_until=NULL WHERE user_id=?',
            [reason || '', targetUserId])
        }
      } else {
        const sql = bannedUntil
          ? `INSERT INTO community_banned_users (user_id, user_name, reason, banned_until) VALUES (?,?,?,${bannedUntil})`
          : 'INSERT INTO community_banned_users (user_id, user_name, reason) VALUES (?,?,?)'
        const params = bannedUntil
          ? [targetUserId, userName, reason || '']
          : [targetUserId, userName, reason || '']
        await query(sql, params)
      }

      res.json({ code: 200, msg: '用户已被禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userId: targetUserId } = req.body
      if (!targetUserId) return res.json({ code: 400, msg: '缺少userId参数' })

      await query('DELETE FROM community_banned_users WHERE user_id=?', [targetUserId])
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/banned', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, reason, banned_until as bannedUntil, create_time as createTime
         FROM community_banned_users ORDER BY create_time DESC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== User Search API ====================

  app.get('/api/community/user/search', async (req, res) => {
    try {
      const { keyword } = req.query
      if (!keyword || keyword.length < 1) return res.json({ code: 400, msg: '请输入搜索关键词' })
      const rows = await query(
        `SELECT id, username, nickname, avatar FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 10`,
        [`%${keyword}%`, `%${keyword}%`]
      )
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== User Community Stats ====================

  app.get('/api/community/user/:userId/stats', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })

      const [[postCountRow]] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [[commentCountRow]] = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [[likeReceivedRow]] = await query('SELECT IFNULL(SUM(like_count), 0) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [[coinReceivedRow]] = await query('SELECT IFNULL(SUM(coin_count), 0) as cnt FROM community_posts WHERE user_id=? AND status=? AND is_deleted=0', [userId, 'published'])
      const [[favoriteRow]] = await query('SELECT COUNT(*) as cnt FROM community_favorites WHERE user_id=?', [userId])
      const [[followerRow]] = await query('SELECT COUNT(*) as cnt FROM user_follows WHERE following_id=?', [userId])
      const [[followingRow]] = await query('SELECT COUNT(*) as cnt FROM user_follows WHERE follower_id=?', [userId])

      const moderatorSections = await query(
        `SELECT cm.section_id as sectionId, cs.name as sectionName, cm.role
         FROM community_moderators cm
         JOIN community_sections cs ON cm.section_id=cs.id AND cs.is_deleted=0
         WHERE cm.user_id=?`, [userId]
      )

      res.json({ code: 200, msg: 'success', data: {
        postCount: postCountRow?.cnt || 0,
        commentCount: commentCountRow?.cnt || 0,
        likeReceived: likeReceivedRow?.cnt || 0,
        coinReceived: coinReceivedRow?.cnt || 0,
        collectionCount: favoriteRow?.cnt || 0,
        followerCount: followerRow?.cnt || 0,
        followingCount: followingRow?.cnt || 0,
        moderatorSections,
        trustLevel: 0
      }})
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/user/:userId/recent-posts', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      const posts = await query(
        `SELECT id, title, section_id as sectionId, create_time as createTime,
                like_count as likeCount, comment_count as commentCount, view_count as viewCount
         FROM community_posts
         WHERE user_id=? AND status='published' AND is_deleted=0
         ORDER BY create_time DESC LIMIT 5`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: posts })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/user/:userId/recent-comments', async (req, res) => {
    try {
      const userId = Number(req.params.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      const comments = await query(
        `SELECT cc.id, cc.content, cc.post_id as postId, cc.create_time as createTime,
                p.title as postTitle
         FROM community_comments cc
         LEFT JOIN community_posts p ON cc.post_id=p.id
         WHERE cc.user_id=? AND cc.status='published' AND cc.is_deleted=0
         ORDER BY cc.create_time DESC LIMIT 5`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: comments })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Report APIs ====================

  app.post('/api/community/post/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      // Store detailed report record
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'post', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      // Also increment the old counter for backward compatibility
      await query('UPDATE community_posts SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const postTitle = await query('SELECT title FROM community_posts WHERE id=?', [Number(req.params.id)])
      const adminEmailsRp = await getAdminEmails()
      for (const adminEmail of adminEmailsRp) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到帖子举报',
          content: `用户 ${user[0]?.username || ''} 举报了帖子《${postTitle[0]?.title || ''}》，原因：${reportReason || '其他'}。`
        })
      }

      // 自动封禁检测
      const targetPost = await query('SELECT user_id FROM community_posts WHERE id=?', [Number(req.params.id)])
      if (targetPost.length > 0) {
        await checkAutoBan(targetPost[0].user_id)
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/comment/:id/report', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reportReason, reportDetail } = req.body || {}

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
         VALUES (?,?,?,?,?,?)`,
        [userId, user[0]?.username || '', 'comment', Number(req.params.id), reportReason || '其他', reportDetail || '']
      )

      await query('UPDATE community_comments SET reported = COALESCE(reported,0) + 1 WHERE id=?', [req.params.id])

      // 举报通知管理员
      const adminEmailsCr = await getAdminEmails()
      for (const adminEmail of adminEmailsCr) {
        sendNotificationEmail('report_notify', adminEmail, {
          username: '管理员',
          subject: '收到评论举报',
          content: `用户 ${user[0]?.username || ''} 举报了一条评论，原因：${reportReason || '其他'}。`
        })
      }

      // 自动封禁检测
      const targetComment = await query('SELECT user_id FROM community_comments WHERE id=?', [Number(req.params.id)])
      if (targetComment.length > 0) {
        await checkAutoBan(targetComment[0].user_id)
      }

      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let whereClause = "r.status = 'pending'"
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        whereClause += ` AND (r.target_type='post' AND p.section_id IN (${modSectionIds.map(() => '?').join(',')}) OR r.target_type='comment' AND cp.section_id IN (${modSectionIds.map(() => '?').join(',')}))`
        params.push(...modSectionIds, ...modSectionIds)
      }

      const reports = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName,
                r.target_type as targetType, r.target_id as targetId, r.report_reason as reportReason,
                r.report_detail as reportDetail, r.status, r.create_time as createTime
         FROM community_reports r
         LEFT JOIN community_posts p ON r.target_type='post' AND r.target_id = p.id
         LEFT JOIN community_comments cc ON r.target_type='comment' AND r.target_id = cc.id
         LEFT JOIN community_posts cp ON r.target_type='comment' AND cc.post_id = cp.id
         WHERE ${whereClause} ORDER BY r.create_time DESC LIMIT 100`,
         params
      )

      // Enrich with target info
      const enriched = []
      for (const r of reports) {
        const item = { ...r }
        if (r.targetType === 'post') {
          const post = await query('SELECT id, title, user_id as userId, user_name as userName, status FROM community_posts WHERE id=?', [r.targetId])
          if (post.length > 0) {
            item.targetTitle = post[0].title
            item.targetUserId = post[0].userId
            item.targetUserName = post[0].userName
            item.targetStatus = post[0].status
          }
        } else {
          const comment = await query('SELECT id, content, user_id as userId, user_name as userName, post_id as postId FROM community_comments WHERE id=?', [r.targetId])
          if (comment.length > 0) {
            item.targetTitle = (comment[0].content || '').substring(0, 50)
            item.targetUserId = comment[0].userId
            item.targetUserName = comment[0].userName
            item.postId = comment[0].postId
          }
        }
        enriched.push(item)
      }

      res.json({ code: 200, msg: 'success', data: enriched })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/report/ignore/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      if (!isAdminUser) {
        const report = await query('SELECT target_type, target_id FROM community_reports WHERE id=?', [Number(req.params.id)])
        if (report.length === 0) return res.json({ code: 404, msg: '举报不存在' })
        const { target_type, target_id } = report[0]
        if (target_type === 'post') {
          if (!(await canReviewModAction(userId, target_id))) return res.json({ code: 403, msg: '无权限' })
        } else if (target_type === 'comment') {
          const comment = await query('SELECT post_id FROM community_comments WHERE id=?', [target_id])
          if (comment.length === 0) return res.json({ code: 404, msg: '评论不存在' })
          if (!(await canReviewModAction(userId, comment[0].post_id))) return res.json({ code: 403, msg: '无权限' })
        } else {
          return res.json({ code: 403, msg: '无权限' })
        }
      }
      const operatorName = await getAdminUserName(req)
      await query('UPDATE community_reports SET status=?, handled_by=?, handled_at=NOW(), handle_result=? WHERE id=?', ['ignored', userId, 'ignored', Number(req.params.id)])
      // 通知举报人
      try {
        const report = await query('SELECT reporter_id FROM community_reports WHERE id=?', [Number(req.params.id)])
        if (report.length > 0) {
          const reporter = await query('SELECT username, email FROM users WHERE id=?', [report[0].reporter_id])
          if (reporter.length > 0 && reporter[0].email) {
            sendNotificationEmail('report_result', reporter[0].email, {
              username: reporter[0].username || '',
              subject: '举报处理结果',
              content: '您提交的举报已被管理员审核，处理结果为：不予处理。'
            })
          }
        }
      } catch {}
      res.json({ code: 200, msg: '已忽略' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Unlock Request APIs ====================

  app.post('/api/community/post/:id/request-unlock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}

      const post = await query('SELECT id, user_id, is_locked FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      if (!post[0].is_locked) return res.json({ code: 400, msg: '该帖子未被锁定' })
      if (post[0].user_id !== userId) return res.json({ code: 403, msg: '只有帖子作者可以申请解锁' })

      // Check if already has a pending request
      const existing = await query(
        'SELECT id FROM community_unlock_requests WHERE post_id=? AND user_id=? AND status=?',
        [req.params.id, userId, 'pending']
      )
      if (existing.length > 0) return res.json({ code: 400, msg: '已有待处理的解锁申请' })

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        `INSERT INTO community_unlock_requests (post_id, user_id, user_name, reason) VALUES (?,?,?,?)`,
        [Number(req.params.id), userId, user[0]?.username || '', reason || '']
      )
      res.json({ code: 200, msg: '解锁申请已提交' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/unlock-requests', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let whereClause = '1=1'
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        whereClause += ` AND p.section_id IN (${modSectionIds.map(() => '?').join(',')})`
        params.push(...modSectionIds)
      }

      const requests = await query(
        `SELECT r.id, r.post_id as postId, r.user_id as userId, r.user_name as userName,
                r.reason, r.status, r.admin_reply as adminReply, r.create_time as createTime,
                p.title as postTitle
         FROM community_unlock_requests r
         LEFT JOIN community_posts p ON r.post_id = p.id
         WHERE ${whereClause}
         ORDER BY r.status ASC, r.create_time DESC LIMIT 100`,
        params
      )
      res.json({ code: 200, msg: 'success', data: requests })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/unlock-request/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const ur = await query('SELECT * FROM community_unlock_requests WHERE id=?', [req.params.id])
      if (!ur.length) return res.json({ code: 404, msg: '申请不存在' })
      if (ur[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })
      if (!(await canManageModAction(userId, ur[0].post_id))) return res.json({ code: 403, msg: '无权限' })
      const { action, reply } = req.body || {}

      if (action === 'approve') {
        await query('UPDATE community_posts SET is_locked=0 WHERE id=?', [ur[0].post_id])
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['approved', reply || '', req.params.id])
        const adminNameUr = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请已通过', `您的解锁申请已通过`, 'unlock_resolved', ur[0].user_id, userId, adminNameUr || '管理人员']
        )
        systemLog('unlock_approve', userId, adminNameUr, 'post', ur[0].post_id, `通过解锁申请`)
        res.json({ code: 200, msg: '已通过解锁申请' })
      } else {
        await query('UPDATE community_unlock_requests SET status=?, admin_reply=?, update_time=NOW() WHERE id=?',
          ['rejected', reply || '', req.params.id])
        const adminNameUr = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['解锁申请被拒绝', reply ? `拒绝原因: ${reply}` : '您的解锁申请被拒绝', 'unlock_resolved', ur[0].user_id, userId, adminNameUr || '管理人员']
        )
        res.json({ code: 200, msg: '已拒绝解锁申请' })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/post/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })

      const post = await query('SELECT section_id, user_id, title, content FROM community_posts WHERE id=?', [req.params.id])
        if (post.length) {
        await query("UPDATE community_posts SET status='deleted', update_time=" + nowExpr + " WHERE id=?", [req.params.id])
        await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [post[0].section_id])
        deleteFileRecordsByRef(req.params.id, 'post').catch(() => {})
        cleanupPostContentImages(post[0].content, req.params.id)
        const adminNameRp = await getAdminUserName(req)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?, ?, ?, '')`,
          ['帖子被下架', `您的帖子《${post[0].title}》因被举报已被管理员下架`, 'report_resolved', post[0].user_id, userId, adminNameRp || '管理员']
        )
        // 通知所有举报人
        try {
          const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
          for (const r of reporters) {
            const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
            if (ru.length > 0 && ru[0].email) {
              sendNotificationEmail('report_result', ru[0].email, {
                username: ru[0].username || '',
                subject: '举报处理结果',
                content: `您举报的帖子《${post[0].title}》已被管理员下架处理。`
              })
            }
          }
          // 标记相关举报为已处理
          await query("UPDATE community_reports SET status='resolved' WHERE target_type='post' AND target_id=? AND status='pending'", [req.params.id])
        } catch {}
      }
      res.json({ code: 200, msg: '已下架' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/community/admin/report/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      await query('DELETE FROM community_comments WHERE id=?', [req.params.id])
      // 通知所有举报人并标记已处理
      try {
        const reporters = await query("SELECT DISTINCT reporter_id FROM community_reports WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
        for (const r of reporters) {
          const ru = await query('SELECT username, email FROM users WHERE id=?', [r.reporter_id])
          if (ru.length > 0 && ru[0].email) {
            sendNotificationEmail('report_result', ru[0].email, {
              username: ru[0].username || '',
              subject: '举报处理结果',
              content: '您举报的评论已被管理员删除处理。'
            })
          }
        }
        await query("UPDATE community_reports SET status='resolved' WHERE target_type='comment' AND target_id=? AND status='pending'", [req.params.id])
      } catch {}
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Moderator Center APIs ====================

  app.get('/api/community/moderator/stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let sectionFilter = ''
      let reportSectionFilter = ''
      const params = []
      const reportParams = []
      if (!isAdminUser && modSectionIds.length > 0) {
        const placeholders = modSectionIds.map(() => '?').join(',')
        sectionFilter = ` AND section_id IN (${placeholders})`
        reportSectionFilter = ` AND (r.target_type='post' AND p.section_id IN (${placeholders}) OR r.target_type='comment' AND cp.section_id IN (${placeholders}))`
        params.push(...modSectionIds)
        reportParams.push(...modSectionIds, ...modSectionIds)
      }

      const [{ pendingCount }] = await query(
        `SELECT COUNT(*) as pendingCount FROM community_posts WHERE status='pending'${sectionFilter}`, params)
      const [{ reportCount }] = await query(
        `SELECT COUNT(*) as reportCount FROM community_reports r LEFT JOIN community_posts p ON r.target_type='post' AND r.target_id=p.id LEFT JOIN community_comments cc ON r.target_type='comment' AND r.target_id=cc.id LEFT JOIN community_posts cp ON r.target_type='comment' AND cc.post_id=cp.id WHERE r.status='pending'${reportSectionFilter}`,
        reportParams.length > 0 ? reportParams : [])
      const [{ unlockCount }] = await query(
        `SELECT COUNT(*) as unlockCount FROM community_unlock_requests r LEFT JOIN community_posts p ON r.post_id=p.id WHERE r.status='pending'${sectionFilter}`,
        sectionFilter ? params : [])

      res.json({ code: 200, data: { pendingCount, reportCount, unlockCount } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/moderator/logs', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let whereClause = '1=1'
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        whereClause += ` AND section_id IN (${modSectionIds.map(() => '?').join(',')})`
        params.push(...modSectionIds)
      }

      const logs = await query(
        `SELECT id, section_id as sectionId, moderator_id as moderatorId, moderator_name as moderatorName,
                action, target_type as targetType, target_id as targetId, detail, create_time as createTime
         FROM community_moderator_logs WHERE ${whereClause} ORDER BY create_time DESC LIMIT 50`,
        params
      )
      res.json({ code: 200, data: logs })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/moderator/my-sections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const list = await query(
        `SELECT s.id, s.name, s.icon, s.icon_bg_color as iconBgColor, m.role,
                s.post_count as postCount
         FROM community_moderators m
          JOIN community_sections s ON m.section_id = s.id AND s.is_deleted=0
          WHERE m.user_id=? AND s.status='active'
         ORDER BY m.sort_order ASC`,
        [userId]
      )
      res.json({ code: 200, data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Batch Operations ====================

  app.post('/api/community/moderator/posts/batch-approve', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [] } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canReviewModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=? AND status=?', [postId, 'pending'])
        if (!post.length) continue
        await query(`UPDATE community_posts SET status='published', reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [userId, postId])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post[0].section_id])
        await logModeratorAction(post[0].section_id, userId, operatorName, 'approve', 'post', postId, `审核通过《${post[0].title}》`)
        count++
      }
      res.json({ code: 200, msg: `已通过 ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-reject', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [], reason = '内容不符合规范' } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canReviewModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title, user_id FROM community_posts WHERE id=? AND status=?', [postId, 'pending'])
        if (!post.length) continue
        await query(`UPDATE community_posts SET status='rejected', reject_reason=?, reviewed_by=?, reviewed_at=${nowExpr} WHERE id=?`, [reason, userId, postId])
        await logModeratorAction(post[0].section_id, userId, operatorName, 'reject', 'post', postId, `驳回《${post[0].title}》`)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
          ['帖子审核未通过', `帖子《${post[0].title}》未通过审核，原因：${reason}`, 'post_rejected', post[0].user_id, userId, operatorName]
        )
        count++
      }
      res.json({ code: 200, msg: `已驳回 ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [] } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canManageModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title, user_id FROM community_posts WHERE id=? AND is_deleted=0', [postId])
        if (!post.length) continue
        await query('UPDATE community_posts SET is_deleted=1, deleted_at=NOW() WHERE id=?', [postId])
        await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [post[0].section_id])
        await logModeratorAction(post[0].section_id, userId, operatorName, 'delete_post', 'post', postId, `批量删除帖子《${post[0].title}》`)
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
          ['帖子被删除', `您的帖子《${post[0].title}》已被管理人员删除`, 'post_deleted', post[0].user_id, userId, operatorName]
        )
        count++
      }
      res.json({ code: 200, msg: `已删除 ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [], targetSectionId } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      if (!targetSectionId) return res.json({ code: 400, msg: '请选择目标板块' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canManageModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=? AND is_deleted=0', [postId])
        if (!post.length || post[0].section_id === targetSectionId) continue
        const oldSectionId = post[0].section_id
        await query('UPDATE community_posts SET section_id=? WHERE id=?', [targetSectionId, postId])
        await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [oldSectionId])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [targetSectionId])
        await logModeratorAction(oldSectionId, userId, operatorName, 'move_post', 'post', postId, `批量移动帖子《${post[0].title}》到板块${targetSectionId}`)
        count++
      }
      res.json({ code: 200, msg: `已移动 ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-essence', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [], set = true } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canManageModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=? AND is_deleted=0', [postId])
        if (!post.length) continue
        await query('UPDATE community_posts SET is_essence=? WHERE id=?', [set ? 1 : 0, postId])
        await logModeratorAction(post[0].section_id, userId, operatorName, set ? 'essence' : 'unessence', 'post', postId, `${set ? '设为精华' : '取消精华'}《${post[0].title}》`)
        count++
      }
      res.json({ code: 200, msg: `${set ? '设为精华' : '取消精华'} ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-pin', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [], set = true } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canManageModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=? AND is_deleted=0', [postId])
        if (!post.length) continue
        await query('UPDATE community_posts SET is_pinned=? WHERE id=?', [set ? 1 : 0, postId])
        await logModeratorAction(post[0].section_id, userId, operatorName, set ? 'pin' : 'unpin', 'post', postId, `${set ? '置顶' : '取消置顶'}《${post[0].title}》`)
        count++
      }
      res.json({ code: 200, msg: `${set ? '置顶' : '取消置顶'} ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/posts/batch-lock', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [], set = true } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择帖子' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const postId of ids) {
        if (!(await canManageModAction(userId, postId))) continue
        const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=? AND is_deleted=0', [postId])
        if (!post.length) continue
        await query('UPDATE community_posts SET is_locked=? WHERE id=?', [set ? 1 : 0, postId])
        await logModeratorAction(post[0].section_id, userId, operatorName, set ? 'lock' : 'unlock', 'post', postId, `${set ? '锁定' : '解锁'}《${post[0].title}》`)
        count++
      }
      res.json({ code: 200, msg: `${set ? '锁定' : '解锁'} ${count} 篇`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/comments/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids = [] } = req.body || {}
      if (!ids.length) return res.json({ code: 400, msg: '请选择评论' })
      const operatorName = await getAdminUserName(req)
      let count = 0
      for (const commentId of ids) {
        const comment = await query('SELECT id, post_id, user_id, content FROM community_comments WHERE id=? AND is_deleted=0', [commentId])
        if (!comment.length) continue
        if (!(await canManageModAction(userId, comment[0].post_id))) continue
        await query('UPDATE community_comments SET is_deleted=1, deleted_at=NOW() WHERE id=?', [commentId])
        await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id=?', [comment[0].post_id])
        await logModeratorAction(0, userId, operatorName, 'delete_comment', 'comment', commentId, `批量删除评论`)
        count++
      }
      res.json({ code: 200, msg: `已删除 ${count} 条评论`, data: { count } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Comment Moderation ====================

  app.delete('/api/community/moderator/comment/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const comment = await query('SELECT id, post_id, user_id, content FROM community_comments WHERE id=?', [Number(req.params.id)])
      if (!comment.length) return res.json({ code: 404, msg: '评论不存在' })
      if (!(await canReviewModAction(userId, comment[0].post_id))) return res.json({ code: 403, msg: '无权限' })
      await query('UPDATE community_comments SET is_deleted=1, deleted_at=NOW() WHERE id=?', [Number(req.params.id)])
      await query('UPDATE community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id=?', [comment[0].post_id])
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(0, userId, operatorName, 'delete_comment', 'comment', comment[0].id, `删除评论`)
      if (comment[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
          ['评论被删除', `您的评论「${(comment[0].content || '').substring(0, 30)}」已被管理人员删除`, 'comment_deleted', comment[0].user_id, userId, operatorName]
        )
      }
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Post Management ====================

  app.post('/api/community/moderator/post/:id/move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { targetSectionId } = req.body || {}
      if (!targetSectionId) return res.json({ code: 400, msg: '请选择目标板块' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })
      const post = await query('SELECT id, section_id, title FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      const oldSectionId = post[0].section_id
      await query('UPDATE community_posts SET section_id=? WHERE id=?', [targetSectionId, req.params.id])
      await query('UPDATE community_sections SET post_count = GREATEST(0, post_count - 1) WHERE id=? AND is_deleted=0', [oldSectionId])
      await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [targetSectionId])
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(oldSectionId, userId, operatorName, 'move_post', 'post', post[0].id, `移动帖子《${post[0].title}》`)
      res.json({ code: 200, msg: '已移动' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/post/:id/edit', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await canManageModAction(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })
      const { title, content: rawContent, tags, officialTags } = req.body || {}
      const content = rawContent !== undefined ? sanitizeCommunityContent(rawContent) : undefined
      const post = await query('SELECT id, section_id, title, content, tags, user_id FROM community_posts WHERE id=?', [req.params.id])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      await savePostRevision(post[0].id, userId, post[0].title, post[0].content, post[0].tags, '管理人员编辑')
      const sets = []
      const vals = []
      if (title !== undefined) { sets.push('title=?'); vals.push(title) }
      if (content !== undefined) { sets.push('content=?'); vals.push(content) }
      if (tags !== undefined) { sets.push('tags=?'); vals.push(JSON.stringify(tags)) }
      if (officialTags !== undefined) { sets.push('official_tags=?'); vals.push(JSON.stringify(officialTags)) }
      if (!sets.length) return res.json({ code: 400, msg: '无修改内容' })
      sets.push('edit_count = edit_count + 1'); sets.push(`update_time=${nowExpr}`)
      vals.push(req.params.id)
      await query(`UPDATE community_posts SET ${sets.join(',')} WHERE id=?`, vals)
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(post[0].section_id, userId, operatorName, 'edit_post', 'post', post[0].id, `编辑帖子《${title || post[0].title}》`)
      if (post[0].user_id !== userId) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
          ['帖子被编辑', `管理人员编辑了您的帖子《${title || post[0].title}》`, 'system', post[0].user_id, userId, operatorName]
        )
      }
      res.json({ code: 200, msg: '已修改' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== User Ban / Blacklist ====================

  app.post('/api/community/moderator/section/:sectionId/ban', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId)
      if (!(await isModeratorOfSection(userId, sectionId))) return res.json({ code: 403, msg: '无权限' })
      const { bannedUserId, reason, days = 7 } = req.body || {}
      if (!bannedUserId) return res.json({ code: 400, msg: '请选择用户' })
      const banUntil = new Date(Date.now() + days * 86400000)
      const targetUser = await query('SELECT username FROM users WHERE id=?', [bannedUserId])
      const targetName = targetUser.length > 0 ? targetUser[0].username : ''
      await query(
        'INSERT INTO community_moderator_bans (section_id, user_id, banned_user_id, banned_user_name, reason, ban_until) VALUES (?,?,?,?,?,?)',
        [sectionId, userId, bannedUserId, targetName, reason || '', banUntil]
      )
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, operatorName, 'ban_user', 'user', bannedUserId, `禁言用户 ${targetName} ${days}天`)
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
        ['您已被禁言', `您在板块中的发言权限已被限制${days}天。${reason ? '原因：' + reason : ''}`, 'user_banned', bannedUserId, userId, operatorName]
      )
      res.json({ code: 200, msg: '已禁言' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/community/moderator/section/:sectionId/ban/:bannedUserId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId)
      if (!(await isModeratorOfSection(userId, sectionId))) return res.json({ code: 403, msg: '无权限' })
      await query('UPDATE community_moderator_bans SET is_active=0 WHERE section_id=? AND banned_user_id=? AND is_active=1', [sectionId, Number(req.params.bannedUserId)])
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, operatorName, 'unban_user', 'user', Number(req.params.bannedUserId), '解除禁言')
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
        ['禁言已解除', '您的禁言已被解除，发言权限已恢复', 'user_unbanned', Number(req.params.bannedUserId), userId, operatorName]
      )
      res.json({ code: 200, msg: '已解除禁言' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/moderator/section/:sectionId/bans', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId)
      if (!(await isModeratorOfSection(userId, sectionId))) return res.json({ code: 403, msg: '无权限' })
      const list = await query(
        `SELECT b.id, b.banned_user_id as bannedUserId, b.banned_user_name as bannedUserName, b.reason, b.ban_type as banType, b.ban_until as banUntil, b.is_active as isActive, b.create_time as createTime
         FROM community_moderator_bans b WHERE b.section_id=? ORDER BY b.create_time DESC LIMIT 50`,
        [sectionId]
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Moderator Resign ====================

  app.post('/api/community/moderator/resign/:sectionId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const sectionId = Number(req.params.sectionId)
      const existing = await query('SELECT id, role FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
      if (!existing.length) return res.json({ code: 404, msg: '您不是该板块的版主' })
      await query('DELETE FROM community_moderators WHERE section_id=? AND user_id=?', [sectionId, userId])
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(sectionId, userId, operatorName, 'resign', 'section', sectionId, `辞去${existing[0].role}职务`)
      res.json({ code: 200, msg: '已辞去版主职务' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Section Info (announcement/rules) ====================

  app.get('/api/community/section/:id/info', async (req, res) => {
    try {
      const rows = await query(
        'SELECT id, name, announcement, rules, banner_url as bannerUrl FROM community_sections WHERE id=? AND is_deleted=0',
        [req.params.id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '板块不存在' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/section/:id/update-info', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isModeratorOfSection(userId, req.params.id))) return res.json({ code: 403, msg: '无权限' })
      const { announcement, rules, bannerUrl } = req.body || {}
      const sets = []; const vals = []
      if (announcement !== undefined) { sets.push('announcement=?'); vals.push(announcement) }
      if (rules !== undefined) { sets.push('rules=?'); vals.push(rules) }
      if (bannerUrl !== undefined) { sets.push('banner_url=?'); vals.push(bannerUrl) }
      if (!sets.length) return res.json({ code: 400, msg: '无修改内容' })
      vals.push(req.params.id)
      await query(`UPDATE community_sections SET ${sets.join(',')} WHERE id=? AND is_deleted=0`, vals)
      const operatorName = await getAdminUserName(req)
      await logModeratorAction(req.params.id, userId, operatorName, 'update_section', 'section', req.params.id, '更新板块信息')
      systemLog(userId, 'update_section_info', 'community', `更新板块${req.params.id}公告/规则`, req => ({}))
      res.json({ code: 200, msg: '已更新' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Report Category ====================

  app.get('/api/community/report-categories', async (_req, res) => {
    res.json({ code: 200, data: [
      { key: 'spam', label: '垃圾广告' },
      { key: 'porn', label: '色情低俗' },
      { key: 'violence', label: '暴力血腥' },
      { key: 'abuse', label: '人身攻击' },
      { key: 'infringe', label: '侵权投诉' },
      { key: 'illegal', label: '违法违规' },
      { key: 'other', label: '其他' }
    ]})
  })

  // ==================== Enhanced Stats ====================

  app.get('/api/community/moderator/enhanced-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdminUser = await isAdmin(req)
      const modSectionIds = isAdminUser ? [] : await getModeratorSectionIds(userId)
      if (!isAdminUser && modSectionIds.length === 0) return res.json({ code: 403, msg: '无权限' })

      let filter = ''
      let logFilter = ''
      const params = []
      if (!isAdminUser && modSectionIds.length > 0) {
        const ph = modSectionIds.map(() => '?').join(',')
        filter = ` AND section_id IN (${ph})`
        logFilter = ` AND section_id IN (${ph})`
        params.push(...modSectionIds)
      }

      const [todayReview] = await query(`SELECT COUNT(*) as cnt FROM community_moderator_logs WHERE moderator_id=? AND action IN ('approve','reject') AND DATE(create_time)=CURDATE()${logFilter}`, [userId, ...(isAdminUser ? [] : params)])
      const [todayReports] = await query(`SELECT COUNT(*) as cnt FROM community_moderator_logs WHERE moderator_id=? AND action IN ('ignore_report','delete_post') AND DATE(create_time)=CURDATE()${logFilter}`, [userId, ...(isAdminUser ? [] : params)])
      const [totalPostCount] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE 1=1${filter}`, isAdminUser ? [] : params)
      const [totalCommentCount] = await query(
        `SELECT COUNT(*) as cnt FROM community_comments cc JOIN community_posts p ON cc.post_id=p.id WHERE cc.is_deleted=0${filter.replace('section_id', 'p.section_id')}`,
        isAdminUser ? [] : params
      )

      res.json({ code: 200, data: {
        todayReviewCount: todayReview?.cnt || 0,
        todayReportHandled: todayReports?.cnt || 0,
        totalPosts: totalPostCount?.cnt || 0,
        totalComments: totalCommentCount?.cnt || 0
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Sensitive Word Check ====================

  async function checkSensitiveWords(text) {
    if (!text) return { blocked: false }
    try {
      const words = await query('SELECT word, replacement FROM community_sensitive_words WHERE status=1')
      for (const w of words) {
        if (text.includes(w.word)) return { blocked: true, word: w.word, replacement: w.replacement || '' }
      }
    } catch {}
    return { blocked: false }
  }

  // ==================== Collection Moderation ====================

  app.post('/api/community/moderator/collection/:id/remove', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { reason } = req.body || {}
      const col = await query('SELECT id, name, user_id FROM community_collections WHERE id=?', [req.params.id])
      if (!col.length) return res.json({ code: 404, msg: '合集不存在' })
      await query('UPDATE community_collections SET status=? WHERE id=?', ['removed', req.params.id])
      const operatorName = await getAdminUserName(req)
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name) VALUES (?,?,?,?,?,?)`,
        ['合集被下架', `您的合集《${col[0].name}》已被下架。${reason ? '原因：' + reason : ''}`, 'system', col[0].user_id, userId, operatorName]
      )
      res.json({ code: 200, msg: '已下架' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Report Appeal ====================

  app.post('/api/community/report/:id/appeal', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body || {}
      const report = await query('SELECT id, status FROM community_reports WHERE id=? AND reporter_id=?', [req.params.id, userId])
      if (!report.length) return res.json({ code: 404, msg: '举报不存在或不属于您' })
      if (!['ignored', 'resolved'].includes(report[0].status)) return res.json({ code: 400, msg: '该举报不支持申诉' })
      await query('UPDATE community_reports SET status=?, appeal_reason=? WHERE id=?', ['appealed', reason || '', req.params.id])
      res.json({ code: 200, msg: '申诉已提交' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/moderator/appeals', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const list = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.reporter_name as reporterName, r.target_type as targetType,
                r.report_reason as reportReason, r.category, r.appeal_reason as appealReason, r.create_time as createTime
         FROM community_reports r WHERE r.status='appealed' ORDER BY r.create_time DESC LIMIT 50`
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/moderator/appeal/:id/handle', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { action } = req.body || {}
      if (action === 'accept') {
        await query('UPDATE community_reports SET status=? WHERE id=?', ['resolved', req.params.id])
        res.json({ code: 200, msg: '已采纳申诉' })
      } else {
        await query('UPDATE community_reports SET status=? WHERE id=?', ['ignored', req.params.id])
        res.json({ code: 200, msg: '已驳回申诉' })
      }
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Tag Management ====================

  app.get('/api/community/tags', async (req, res) => {
    try {
      const { keyword, sort = 'post_count', status, section_id, limit = 50 } = req.query
      let sql = `SELECT id, name, normalized_name as normalizedName, post_count as postCount, section_id as sectionId, status, is_official as isOfficial, create_time as createTime FROM community_tags`
      const conditions = []
      const params = []
      if (keyword) { conditions.push('name LIKE ?'); params.push(`%${keyword}%`) }
      if (status !== undefined) { conditions.push('status=?'); params.push(Number(status)) }
      if (section_id) { conditions.push('section_id=?'); params.push(Number(section_id)) }
      if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ')
      const orderBy = sort === 'name' ? 'normalized_name ASC' : 'post_count DESC'
      sql += ` ORDER BY ${orderBy} LIMIT ?`
      params.push(Math.min(Number(limit) || 50, 200))
      const tags = await query(sql, params)
      res.json({ code: 200, data: tags })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/tags', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { id, name, status, isOfficial } = req.body || {}
      if (!name) return res.json({ code: 400, msg: '标签名不能为空' })
      const normalized = name.trim().toLowerCase()
      if (id) {
        await query('UPDATE community_tags SET name=?, normalized_name=?, status=?, is_official=? WHERE id=?',
          [name.trim(), normalized, status ?? 1, isOfficial ?? 0, id])
        res.json({ code: 200, msg: '更新成功' })
      } else {
        await query('INSERT IGNORE INTO community_tags (name, normalized_name, status, is_official) VALUES (?,?,?,?)',
          [name.trim(), normalized, status ?? 1, isOfficial ?? 0])
        res.json({ code: 200, msg: '创建成功' })
      }
      await systemLog(userId, 'manage_tag', 'community', `${id ? '更新' : '创建'}标签「${name}」`, req => ({}))
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/community/tags/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      await query('DELETE FROM community_tags WHERE id=?', [req.params.id])
      await systemLog(userId, 'delete_tag', 'community', `删除标签ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/tags/merge', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { sourceId, targetId } = req.body || {}
      if (!sourceId || !targetId) return res.json({ code: 400, msg: '请选择源和目标标签' })
      const [[source]] = await query('SELECT id, name FROM community_tags WHERE id=?', [sourceId])
      const [[target]] = await query('SELECT id, name FROM community_tags WHERE id=?', [targetId])
      if (!source || !target) return res.json({ code: 404, msg: '标签不存在' })
      await query('UPDATE community_tags SET post_count = post_count + (SELECT post_count FROM (SELECT post_count FROM community_tags WHERE id=?) as t) WHERE id=?', [sourceId, targetId])
      await query('DELETE FROM community_tags WHERE id=?', [sourceId])
      await query(
        `UPDATE community_posts SET tags = JSON_REPLACE(JSON_SET(tags, '$', JSON_ARRAY(?)), '$', JSON_ARRAY(?)) WHERE JSON_CONTAINS(tags, JSON_QUOTE(?))`,
        [target.name, target.name, source.name]
      )
      await systemLog(userId, 'merge_tags', 'community', `合并标签「${source.name}」到「${target.name}」`, req => ({}))
      res.json({ code: 200, msg: '合并成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/tags/sync', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const posts = await query(
        `SELECT id, tags FROM community_posts WHERE is_deleted=0 AND tags IS NOT NULL AND tags != '' AND tags != '[]'`
      )
      const tagCounts = {}
      for (const post of posts) {
        try {
          const ts = JSON.parse(post.tags)
          if (Array.isArray(ts)) {
            for (const t of ts) {
              const n = (t && typeof t === 'string' ? t.trim() : '').toLowerCase()
              if (n) tagCounts[n] = (tagCounts[n] || 0) + 1
            }
          }
        } catch {}
      }
      for (const [name, count] of Object.entries(tagCounts)) {
        await query(
          'INSERT INTO community_tags (name, normalized_name, post_count) VALUES (?,?,?) ON DUPLICATE KEY UPDATE post_count=?',
          [name, name.toLowerCase(), count, count]
        )
      }
      await systemLog(userId, 'sync_tags', 'community', `同步标签，共${Object.keys(tagCounts).length}个`, req => ({}))
      res.json({ code: 200, msg: `已同步 ${Object.keys(tagCounts).length} 个标签` })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/tags/cloud', async (req, res) => {
    try {
      const { limit = 50 } = req.query
      const tags = await query(
        `SELECT DISTINCT name, post_count as postCount FROM community_tags WHERE status=1 ORDER BY post_count DESC LIMIT ?`,
        [Math.min(Number(limit) || 50, 100)]
      )
      const maxCount = tags.length > 0 ? tags[0].postCount : 1
      const cloud = tags.map(t => ({ name: t.name, count: t.postCount, weight: Math.max(1, Math.ceil((t.postCount / maxCount) * 5)) }))
      res.json({ code: 200, data: cloud })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/tags/hot', async (req, res) => {
    try {
      const { limit = 20 } = req.query
      const tags = await query(
        `SELECT name, post_count as count FROM community_tags WHERE status=1 ORDER BY post_count DESC LIMIT ?`,
        [Math.min(Number(limit) || 20, 50)]
      )
      res.json({ code: 200, data: tags })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Sensitive Words Management ====================

  app.get('/api/community/sensitive-words', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const words = await query('SELECT id, word, replacement, category, status, create_time as createTime FROM community_sensitive_words ORDER BY id DESC')
      res.json({ code: 200, data: words })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/sensitive-words', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { id, word, replacement, category } = req.body || {}
      if (!word) return res.json({ code: 400, msg: '敏感词不能为空' })
      if (id) {
        await query('UPDATE community_sensitive_words SET word=?, replacement=?, category=? WHERE id=?', [word.trim(), replacement || '', category || '', id])
        res.json({ code: 200, msg: '更新成功' })
      } else {
        await query('INSERT INTO community_sensitive_words (word, replacement, category) VALUES (?,?,?)', [word.trim(), replacement || '', category || ''])
        res.json({ code: 200, msg: '添加成功' })
      }
      await systemLog(userId, 'manage_sensitive_word', 'community', `${id ? '更新' : '添加'}敏感词「${word}」`, req => ({}))
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/community/sensitive-words/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })
      await query('DELETE FROM community_sensitive_words WHERE id=?', [req.params.id])
      await systemLog(userId, 'delete_sensitive_word', 'community', `删除敏感词ID${req.params.id}`, req => ({}))
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Community Analytics ====================

  app.get('/api/community/analytics/overview', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const [[totalPosts]] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0')
      const [[totalComments]] = await query('SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0')
      const [[totalSections]] = await query('SELECT COUNT(*) as cnt FROM community_sections WHERE is_deleted=0')
      const [[todayPosts]] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE is_deleted=0 AND DATE(create_time)=CURDATE()`)
      const [[todayComments]] = await query(`SELECT COUNT(*) as cnt FROM community_comments WHERE is_deleted=0 AND DATE(create_time)=CURDATE()`)
      const [[pendingCount]] = await query(`SELECT COUNT(*) as cnt FROM community_posts WHERE status='pending' AND is_deleted=0`)
      const [[reportCount]] = await query(`SELECT COUNT(*) as cnt FROM community_reports WHERE status='pending'`)
      const [[todayActiveUsers]] = await query(
        `SELECT COUNT(DISTINCT COALESCE(p.user_id, c.user_id)) as cnt
         FROM (SELECT user_id FROM community_posts WHERE DATE(create_time)=CURDATE() AND is_deleted=0 UNION SELECT user_id FROM community_comments WHERE DATE(create_time)=CURDATE() AND is_deleted=0) t
         JOIN community_posts p ON p.user_id=t.user_id JOIN community_comments c ON c.user_id=t.user_id LIMIT 1`,
      )
      const d = await query(
        `SELECT COUNT(DISTINCT user_id) as cnt FROM (
           SELECT user_id FROM community_posts WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
           UNION SELECT user_id FROM community_comments WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
         ) t`
      )
      const weeklyActive = d[0]?.cnt || 0
      const m = await query(
        `SELECT COUNT(DISTINCT user_id) as cnt FROM (
           SELECT user_id FROM community_posts WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           UNION SELECT user_id FROM community_comments WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
         ) t`
      )
      const monthlyActive = m[0]?.cnt || 0
      const [[totalCollections]] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE status != \'removed\'')
      const [[totalBans]] = await query('SELECT COUNT(*) as cnt FROM community_moderator_bans WHERE is_active=1')
      const [[essenceCount]] = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE is_essence=1 AND is_deleted=0')

      res.json({ code: 200, data: {
        totalPosts: totalPosts.cnt, totalComments: totalComments.cnt, totalSections: totalSections.cnt,
        todayPosts: todayPosts.cnt, todayComments: todayComments.cnt, pendingCount: pendingCount.cnt,
        reportCount: reportCount.cnt, todayActiveUsers: todayActiveUsers?.cnt || 0,
        weeklyActive, monthlyActive, totalCollections: totalCollections.cnt,
        totalBans: totalBans.cnt, essenceCount: essenceCount.cnt
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/analytics/trends', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { days = 30 } = req.query
      const limit = Math.min(Number(days) || 30, 90)

      const posts = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM community_posts
         WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      const comments = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM community_comments
         WHERE is_deleted=0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      const users = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as cnt FROM users
         WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE(create_time) ORDER BY date`, [limit]
      )
      res.json({ code: 200, data: { posts, comments, users } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/analytics/sections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const sections = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor,
                COUNT(p.id) as postCount,
                COALESCE(SUM(p.view_count), 0) as totalViews,
                COALESCE(SUM(p.comment_count), 0) as totalComments,
                COALESCE(SUM(p.like_count), 0) as totalLikes,
                COALESCE(SUM(CASE WHEN p.create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END), 0) as recentPosts,
                COUNT(DISTINCT cm.user_id) as moderatorCount
         FROM community_sections cs
         LEFT JOIN community_posts p ON p.section_id=cs.id AND p.is_deleted=0
         LEFT JOIN community_moderators cm ON cm.section_id=cs.id
         WHERE cs.is_deleted=0
         GROUP BY cs.id ORDER BY postCount DESC`
      )
      res.json({ code: 200, data: sections })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/analytics/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const [[totalPaid]] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE is_paid=1 AND status != \'removed\'')
      const [[totalRevenue]] = await query(
        `SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp
         JOIN community_collections cc ON cp.content_id=cc.id WHERE cp.content_type='collection'`
      )
      const top = await query(
        `SELECT cc.id, cc.title, COUNT(cp.id) as subscribeCount, cc.is_paid as isPaid, cc.price_balance as priceBalance
         FROM community_collections cc
         LEFT JOIN content_purchases cp ON cp.content_id=cc.id AND cp.content_type='collection'
         WHERE cc.status != 'removed'
         GROUP BY cc.id ORDER BY subscribeCount DESC LIMIT 20`
      )
      res.json({ code: 200, data: { totalPaid: totalPaid.cnt, totalRevenue: totalRevenue.total, top } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/analytics/user-ranking', async (req, res) => {
    try {
      const { type = 'posts', limit = 20 } = req.query
      let data = []
      const lim = Math.min(Number(limit) || 20, 100)
      if (type === 'posts') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COUNT(p.id) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0 AND p.status='published'
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      } else if (type === 'likes') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COALESCE(SUM(p.like_count), 0) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      } else if (type === 'coins') {
        data = await query(
          `SELECT u.id, u.nickname, u.avatar, COALESCE(SUM(p.coin_count), 0) as cnt FROM users u
           LEFT JOIN community_posts p ON p.user_id=u.id AND p.is_deleted=0
           GROUP BY u.id ORDER BY cnt DESC LIMIT ?`, [lim]
        )
      }
      res.json({ code: 200, data })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Notifications ====================

  app.get('/api/community/notifications/unread-count', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query('SELECT COUNT(*) as cnt FROM sys_notifications WHERE target_user_id=? AND is_read=0', [userId])
      res.json({ code: 200, data: { count: rows[0]?.cnt || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Collection Admin ====================

  app.get('/api/community/admin/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { keyword, status } = req.query
      const conditions = []
      const params = []

      if (keyword) {
        conditions.push('(cc.title LIKE ? OR u.username LIKE ? OR u.nickname LIKE ?)')
        params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`)
      }
      if (status) {
        conditions.push('cc.status = ?')
        params.push(status)
      }

      const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : ''

      const list = await query(
        `SELECT cc.id, cc.title, cc.user_id as userId,
                COALESCE(NULLIF(u.nickname,''), u.username) as userName,
                cc.is_paid as isPaid, cc.price_balance as priceBalance,
                cc.status, cc.section_id as sectionId,
                cc.post_count as postCount,
                (SELECT COUNT(*) FROM content_purchases cp WHERE cp.content_id=cc.id AND cp.content_type='collection') as subscribeCount,
                cc.create_time as createTime
         FROM community_collections cc
         LEFT JOIN users u ON cc.user_id = u.id
         ${where}
         ORDER BY cc.create_time DESC`,
        params
      )

      res.json({ code: 200, data: list })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/admin/collection/:id/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { status } = req.body || {}
      if (!['active', 'suspended', 'removed'].includes(status)) return res.json({ code: 400, msg: '无效的状态' })

      const col = await query('SELECT id, name FROM community_collections WHERE id=?', [req.params.id])
      if (!col.length) return res.json({ code: 404, msg: '合集不存在' })

      await query('UPDATE community_collections SET status=? WHERE id=?', [status, req.params.id])

      const operatorName = await getAdminUserName(req)
      systemLog('update_collection_status', userId, operatorName, 'collection', Number(req.params.id),
        `将合集《${col[0].name}》状态更改为${status}`)

      res.json({ code: 200, msg: '状态已更新' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/community/admin/collection/:id/feature', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { featured } = req.body || {}
      if (featured === undefined) return res.json({ code: 400, msg: '请指定featured值' })

      try {
        const cols = await query("SHOW COLUMNS FROM community_collections LIKE 'is_featured'")
        if (!cols || cols.length === 0) {
          await query('ALTER TABLE community_collections ADD COLUMN is_featured TINYINT DEFAULT 0')
        }
      } catch (e) { /* column may already exist */ }

      const col = await query('SELECT id, name FROM community_collections WHERE id=?', [req.params.id])
      if (!col.length) return res.json({ code: 404, msg: '合集不存在' })

      await query('UPDATE community_collections SET is_featured=? WHERE id=?', [featured ? 1 : 0, req.params.id])

      const operatorName = await getAdminUserName(req)
      systemLog(featured ? 'feature_collection' : 'unfeature_collection', userId, operatorName, 'collection', Number(req.params.id),
        `${featured ? '推荐' : '取消推荐'}合集《${col[0].name}》`)

      res.json({ code: 200, msg: featured ? '已推荐' : '已取消推荐' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/community/admin/collection-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const [[totalRow]] = await query('SELECT COUNT(*) as cnt FROM community_collections')
      const [[activeRow]] = await query("SELECT COUNT(*) as cnt FROM community_collections WHERE status='active'")
      const [[paidRow]] = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE is_paid=1')
      const [[totalRevenueRow]] = await query(
        "SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp WHERE cp.content_type='collection'"
      )
      const [[todayRevenueRow]] = await query(
        "SELECT COALESCE(SUM(cp.amount), 0) as total FROM content_purchases cp WHERE cp.content_type='collection' AND DATE(cp.create_time)=CURDATE()"
      )

      res.json({ code: 200, data: {
        totalCollections: totalRow.cnt,
        activeCollections: activeRow.cnt,
        paidCollections: paidRow.cnt,
        totalRevenue: totalRevenueRow.total,
        todayRevenue: todayRevenueRow.total
      }})
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Image Management ====================

  app.get('/api/community/admin/images', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { page = 1, pageSize = 20, keyword, userId: filterUserId, dateFrom, dateTo } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      const limit = Number(pageSize)

      let where = "WHERE f.category='community_image'"
      const params = []

      if (keyword) {
        where += ' AND f.file_name LIKE ?'
        params.push(`%${keyword}%`)
      }
      if (filterUserId) {
        where += ' AND f.user_id=?'
        params.push(Number(filterUserId))
      }
      if (dateFrom) {
        where += ' AND f.create_time >= ?'
        params.push(dateFrom)
      }
      if (dateTo) {
        where += ' AND f.create_time <= ?'
        params.push(dateTo + ' 23:59:59')
      }

      const countResult = await query(`SELECT COUNT(*) as total FROM file_repository f ${where}`, params)
      const total = countResult[0]?.total || 0

      const images = await query(
        `SELECT f.id, f.file_name, f.file_path AS url, f.file_size, f.user_id,
                u.nickname AS uploader_name, f.create_time, f.ref_type
         FROM file_repository f
         LEFT JOIN users u ON f.user_id = u.id
         ${where}
         ORDER BY f.create_time DESC
         LIMIT ? OFFSET ?`,
        [...params, limit, offset]
      )

      res.json({ code: 200, msg: 'success', data: { list: images, total, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/images/batch-delete', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { ids } = req.body || {}
      if (!ids || !Array.isArray(ids) || !ids.length) return res.json({ code: 400, msg: '缺少图片ID列表' })

      const filteredIds = ids.filter(Number).map(Number)
      await deleteFileRecordsByIds(filteredIds)

      await systemLog(userId, 'batch_delete_images', 'community', `批量删除${filteredIds.length}张社区图片`, req => ({}))
      res.json({ code: 200, msg: '删除成功', data: { count: filteredIds.length } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/image-stats', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const [totalRow, sizeRow, todayRow] = await Promise.all([
        query("SELECT COUNT(*) as cnt FROM file_repository WHERE category='community_image'"),
        query("SELECT COALESCE(SUM(file_size), 0) as total_size FROM file_repository WHERE category='community_image'"),
        query("SELECT COUNT(*) as cnt FROM file_repository WHERE category='community_image' AND DATE(create_time)=CURDATE()")
      ])

      res.json({
        code: 200,
        data: {
          totalImages: totalRow[0]?.cnt || 0,
          totalSize: sizeRow[0]?.total_size || 0,
          todayUploaded: todayRow[0]?.cnt || 0
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Voting APIs ====================

  app.post('/api/community/post/:id/vote', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const postId = Number(req.params.id)
      const { question, options, maxSelect, endTime } = req.body
      if (!question || !question.trim()) return res.json({ code: 400, msg: '请输入投票问题' })
      if (!options || !Array.isArray(options) || options.length < 2) return res.json({ code: 400, msg: '至少需要2个选项' })

      const postRow = await query('SELECT user_id, section_id FROM community_posts WHERE id=?', [postId])
      if (!postRow || postRow.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (postRow[0].user_id !== userId && !(await canAccessSection(userId, postRow[0].section_id))) {
        return res.json({ code: 403, msg: '无权限创建投票' })
      }

      const result = await query(
        `INSERT INTO community_votes (post_id, question, options, max_select, end_time, create_time)
         VALUES (?,?,?,?,?,NOW())`,
        [postId, question.trim(), JSON.stringify(options), maxSelect || 1, endTime || null]
      )

      res.json({ code: 200, msg: '投票创建成功', data: { id: result.insertId } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/vote/:voteId/cast', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { optionIndexes } = req.body
      if (!optionIndexes || !Array.isArray(optionIndexes) || optionIndexes.length === 0) {
        return res.json({ code: 400, msg: '请选择投票选项' })
      }

      const voteId = Number(req.params.voteId)

      const voteRow = await query('SELECT id, post_id, options, max_select, end_time, closed FROM community_votes WHERE id=?', [voteId])
      if (!voteRow || voteRow.length === 0) return res.json({ code: 404, msg: '投票不存在' })
      const v = voteRow[0]

      if (v.closed === 1) return res.json({ code: 400, msg: '投票已关闭' })
      if (v.end_time && new Date(v.end_time) < new Date()) return res.json({ code: 400, msg: '投票已结束' })

      const opts = JSON.parse(v.options || '[]')
      const maxSelect = v.max_select || 1
      if (optionIndexes.length > maxSelect) return res.json({ code: 400, msg: `最多选择 ${maxSelect} 项` })
      for (const idx of optionIndexes) {
        if (idx < 0 || idx >= opts.length) return res.json({ code: 400, msg: '无效的选项' })
      }

      const existing = await query('SELECT id FROM community_vote_records WHERE vote_id=? AND user_id=?', [voteId, userId])
      if (existing && existing.length > 0) return res.json({ code: 400, msg: '您已经投过票了' })

      for (const idx of optionIndexes) {
        await query(
          'INSERT INTO community_vote_records (vote_id, user_id, option_index, create_time) VALUES (?,?,?,NOW())',
          [voteId, userId, idx]
        )
      }

      const countRows = await query(
        `SELECT option_index, COUNT(*) as cnt FROM community_vote_records WHERE vote_id=? GROUP BY option_index`,
        [voteId]
      )
      const counts = {}
      for (const r of countRows) {
        counts[r.option_index] = r.cnt
      }

      res.json({ code: 200, msg: '投票成功', data: { counts } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/post/:id/votes', async (req, res) => {
    try {
      const postId = Number(req.params.id)
      const currentUserId = await getUserId(req)

      const votes = await query(
        `SELECT id, post_id as postId, question, options, max_select as maxSelect, end_time as endTime, create_time as createTime, closed
         FROM community_votes WHERE post_id=? ORDER BY create_time DESC`,
        [postId]
      )

      for (const vote of votes) {
        try { vote.options = vote.options ? JSON.parse(vote.options) : [] } catch { vote.options = [] }

        const countRows = await query(
          `SELECT option_index, COUNT(*) as cnt FROM community_vote_records WHERE vote_id=? GROUP BY option_index`,
          [vote.id]
        )
        vote.optionCounts = {}
        for (const r of countRows) {
          vote.optionCounts[r.option_index] = r.cnt
        }

        vote.userVoted = false
        if (currentUserId > 0) {
          const userRecord = await query('SELECT id FROM community_vote_records WHERE vote_id=? AND user_id=? LIMIT 1', [vote.id, currentUserId])
          vote.userVoted = userRecord && userRecord.length > 0
        }
      }

      res.json({ code: 200, msg: 'success', data: votes })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/vote/:voteId/close', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const voteId = Number(req.params.voteId)
      const voteRow = await query('SELECT id, post_id FROM community_votes WHERE id=?', [voteId])
      if (!voteRow || voteRow.length === 0) return res.json({ code: 404, msg: '投票不存在' })

      const postRow = await query('SELECT user_id, section_id FROM community_posts WHERE id=?', [voteRow[0].post_id])
      if (!postRow || postRow.length === 0) return res.json({ code: 404, msg: '帖子不存在' })

      if (postRow[0].user_id !== userId && !(await canAccessSection(userId, postRow[0].section_id))) {
        return res.json({ code: 403, msg: '无权限关闭投票' })
      }

      await query('UPDATE community_votes SET closed=1 WHERE id=?', [voteId])

      res.json({ code: 200, msg: '投票已关闭' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Data Export (admin) ====================

  app.get('/api/community/admin/export/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const { sectionId, startDate, endDate, status } = req.query
      let sql = `SELECT p.id, p.title, p.user_name as author,
                 (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0) as sectionName,
                 p.status, p.view_count as viewCount, p.like_count as likeCount,
                 p.comment_count as commentCount, p.create_time as createTime
                 FROM community_posts p WHERE 1=1`
      const params = []
      if (sectionId) { sql += ' AND p.section_id=?'; params.push(sectionId) }
      if (startDate) { sql += ' AND p.create_time >= ?'; params.push(startDate) }
      if (endDate) { sql += ' AND p.create_time <= ?'; params.push(endDate + ' 23:59:59') }
      if (status) { sql += ' AND p.status=?'; params.push(status) }
      sql += ' ORDER BY p.id DESC'

      const rows = await query(sql, params)

      const csvHeader = 'ID,标题,作者,板块,状态,浏览,点赞,评论,创建时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.title || '').replace(/"/g, '""')}","${(r.author || '').replace(/"/g, '""')}","${(r.sectionName || '').replace(/"/g, '""')}","${r.status}","${r.viewCount}","${r.likeCount}","${r.commentCount}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=posts_export.csv')
      res.send(csv)
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/export/reports', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const rows = await query(
        `SELECT r.id, r.reporter_name as reporterName, r.target_type as targetType,
                r.target_id as targetId, r.report_reason as reportReason,
                r.report_detail as reportDetail, r.status, r.create_time as createTime
         FROM community_reports r ORDER BY r.id DESC`
      )

      const csvHeader = 'ID,举报人,目标类型,目标ID,举报原因,详情,状态,创建时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.reporterName || '').replace(/"/g, '""')}","${r.targetType}","${r.targetId}","${(r.reportReason || '').replace(/"/g, '""')}","${(r.reportDetail || '').replace(/"/g, '""')}","${r.status}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=reports_export.csv')
      res.send(csv)
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/admin/export/users', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const rows = await query(
        `SELECT u.id, COALESCE(NULLIF(u.nickname,''), u.username) as nickname, u.email,
                (SELECT COUNT(*) FROM community_posts WHERE user_id=u.id AND status='published') as postCount,
                (SELECT COUNT(*) FROM community_comments WHERE user_id=u.id) as commentCount,
                u.create_time as createTime
         FROM users u WHERE u.status='1' ORDER BY postCount DESC`
      )

      const csvHeader = '用户ID,昵称,邮箱,帖子数,评论数,注册时间\n'
      const csvBody = rows.map(r =>
        `"${r.id}","${(r.nickname || '').replace(/"/g, '""')}","${(r.email || '').replace(/"/g, '""')}","${r.postCount}","${r.commentCount}","${r.createTime ? formatDateTime(r.createTime) : ''}"`
      ).join('\n')

      const csv = '\uFEFF' + csvHeader + csvBody
      res.setHeader('Content-Type', 'text/csv; charset=utf-8')
      res.setHeader('Content-Disposition', 'attachment; filename=users_export.csv')
      res.send(csv)
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== 社区排行榜增强 ====================

  app.get('/api/community/rankings/essence', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.title, p.is_essence as isEssence, p.view_count as viewCount,
                p.like_count as likeCount, p.comment_count as commentCount,
                p.create_time as createTime
         FROM community_posts p
         WHERE p.is_essence=1 AND p.status='published' AND p.is_deleted=0
         ORDER BY p.view_count DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/rankings/donations', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT u.id, COALESCE(NULLIF(u.nickname,''), u.username) as userName,
                CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(u.avatar, '') END as userAvatar,
                COALESCE(SUM(cl.amount), 0) as totalDonated
         FROM community_coin_logs cl
         JOIN users u ON u.id = cl.to_user_id
         GROUP BY u.id ORDER BY totalDonated DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/rankings/sections-active', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT cs.id, cs.name, cs.icon, cs.icon_bg_color as iconBgColor,
                COUNT(p.id) as postCount,
                COALESCE(SUM(p.view_count), 0) as totalViewCount,
                COALESCE(SUM(p.comment_count), 0) as totalCommentCount
         FROM community_sections cs
         LEFT JOIN community_posts p ON p.section_id=cs.id AND p.is_deleted=0 AND p.status='published' AND p.create_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
         WHERE cs.status='active' AND cs.is_deleted=0
         GROUP BY cs.id ORDER BY postCount DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/rankings/daily', async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50)
      const list = await query(
        `SELECT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                p.title, p.view_count as viewCount, p.like_count as likeCount,
                p.comment_count as commentCount, p.create_time as createTime
         FROM community_posts p
         WHERE p.status='published' AND p.is_deleted=0 AND DATE(p.create_time)=CURDATE()
         ORDER BY p.view_count DESC LIMIT ?`, [limit]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Image Upload ====================

  app.post('/api/community/upload-image', communityImageUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择图片' })
      const { resolveUploadPath, recordFileUpload, getUserId, checkStorageQuota, updateUserUsedBytes, buildFileDesc } = require('./upload.cjs')
      const url = await resolveUploadPath(req.file, req, false)
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}
      const quota = await checkStorageQuota(userId, req.file.size || 0, 'community_image')
      if (!quota.ok) return res.json({ code: 400, msg: quota.msg })
      await recordFileUpload({
        userId,
        fileName: req.file.originalname,
        fileUrl: url,
        fileSize: req.file.size || 0,
        fileType: path.extname(req.file.originalname),
        mimeType: req.file.mimetype || '',
        category: 'community_image',
        description: buildFileDesc ? buildFileDesc({ category: 'community_image', refType: 'community_post' }) : ''
      })
      await updateUserUsedBytes(userId)
      res.json({ code: 200, msg: '上传成功', data: { url } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/delete-image', async (req, res) => {
    try {
      const { url } = req.body || {}
      if (!url) return res.json({ code: 400, msg: '缺少图片URL' })
      const { getDefaultStorage } = require('./storage-config.cjs')
      const { deleteFromCloud, getUserId } = require('./upload.cjs')
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}
      const userCtx = { userId, roles: [], levelId: 0, backend: false }
      const storage = await getDefaultStorage(userCtx)
      if (!storage) return res.json({ code: 500, msg: '未找到存储配置' })
      const key = new URL(url).pathname.replace(/^\//, '')
      await deleteFromCloud(storage, key)
      await query('DELETE FROM file_repository WHERE file_path=?', [url])
      if (userId) {
        const { updateUserUsedBytes } = require('../utils/file-helper.cjs')
        await updateUserUsedBytes(userId)
      }
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Community] delete-image:', e.message)
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Trust Level APIs ====================

  app.get('/api/community/user/:userId/trust-level', async (req, res) => {
    try {
      const userId = Number(req.params.userId)
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })
      let row = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      if (row.length === 0) {
        await initTrustLevel(userId)
        row = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      }
      const data = row[0]
      const score = calcTrustScore(data.post_count, data.comment_count, data.like_received, data.report_count, data.ban_count)
      const level = getTrustLevelByScore(score)
      const levelNames = ['新手', '成员', '活跃', '资深']
      res.json({ code: 200, msg: 'success', data: {
        ...data,
        score,
        level,
        levelName: levelNames[level] || '新手'
      }})
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/trust-levels/calculate', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const users = await query(
        `SELECT u.id as userId,
                COALESCE(pc.cnt, 0) as postCount,
                COALESCE(cc.cnt, 0) as commentCount,
                COALESCE(lr.cnt, 0) as likeReceived,
                COALESCE(rp.cnt, 0) as reportCount,
                COALESCE(bc.cnt, 0) as banCount
         FROM users u
         LEFT JOIN (SELECT user_id, COUNT(*) as cnt FROM community_posts WHERE status='published' AND is_deleted=0 GROUP BY user_id) pc ON u.id=pc.user_id
         LEFT JOIN (SELECT user_id, COUNT(*) as cnt FROM community_comments WHERE status='published' AND is_deleted=0 GROUP BY user_id) cc ON u.id=cc.user_id
         LEFT JOIN (SELECT p.user_id, COUNT(*) as cnt FROM community_likes l JOIN community_posts p ON l.post_id=p.id WHERE p.status='published' AND p.is_deleted=0 GROUP BY p.user_id) lr ON u.id=lr.user_id
         LEFT JOIN (SELECT target_id as user_id, COUNT(*) as cnt FROM community_reports WHERE target_type='post' AND status='pending' GROUP BY target_id) rp ON u.id=rp.user_id
         LEFT JOIN (SELECT banned_user_id, COUNT(*) as cnt FROM community_moderator_bans WHERE is_active=1 GROUP BY banned_user_id) bc ON u.id=bc.banned_user_id
         ORDER BY u.id`
      )

      let updated = 0
      for (const u of users) {
        const score = calcTrustScore(u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount)
        const level = getTrustLevelByScore(score)
        await query(
          `INSERT INTO community_trust_levels (user_id, level, post_count, comment_count, like_received, report_count, ban_count, score, last_calculated)
           VALUES (?,?,?,?,?,?,?,?,NOW())
           ON DUPLICATE KEY UPDATE level=?, post_count=?, comment_count=?, like_received=?, report_count=?, ban_count=?, score=?, last_calculated=NOW()`,
          [u.userId, level, u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount, score,
           level, u.postCount, u.commentCount, u.likeReceived, u.reportCount, u.banCount, score]
        )
        updated++
      }

      res.json({ code: 200, msg: '已重新计算所有信任等级', data: { total: updated } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Content Quality Score ====================

  app.get('/api/community/analytics/quality-scores', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId || !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { limit = 50 } = req.query
      const posts = await query(
        `SELECT p.id, p.title, p.user_name as userName, p.section_id as sectionId,
                p.view_count as viewCount, p.like_count as likeCount,
                p.comment_count as commentCount, p.favorite_count as favoriteCount,
                p.coin_count as coinCount, p.is_essence as isEssence,
                p.create_time as createTime,
                (p.view_count * 0.1 + p.like_count * 3 + p.comment_count * 2 +
                 p.favorite_count * 5 + p.coin_count * 4 + IF(p.is_essence, 10, 0) +
                 GREATEST(0, 30 - DATEDIFF(NOW(), p.create_time)) * 0.5) as qualityScore
         FROM community_posts p
         WHERE p.is_deleted=0 AND p.status='published'
         ORDER BY qualityScore DESC LIMIT ?`,
        [Math.min(Number(limit) || 50, 100)]
      )
      const top = posts.slice(0, 10).map(p => ({
        ...p, qualityScore: Math.round(p.qualityScore * 10) / 10
      }))
      const avgScore = posts.length > 0
        ? Math.round(posts.reduce((s, p) => s + p.qualityScore, 0) / posts.length * 10) / 10
        : 0
      res.json({ code: 200, data: { top, avgScore, total: posts.length } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ==================== Community Profile API ====================

  app.get('/api/community/user/:userId/community-profile', async (req, res) => {
    try {
      const userId = Number(req.params.userId)
      if (!userId) return res.json({ code: 400, msg: '无效的用户ID' })

      const trustRow = await query('SELECT * FROM community_trust_levels WHERE user_id=?', [userId])
      let trustLevel = 0, postCount = 0, commentCount = 0, reportCount = 0
      if (trustRow.length > 0) {
        const d = trustRow[0]
        trustLevel = d.level
        postCount = d.post_count
        commentCount = d.comment_count
        reportCount = d.report_count
      }

      const modSections = await query(
        `SELECT cm.section_id as sectionId, cm.role, cs.name as sectionName, cs.icon_bg_color as iconBgColor
         FROM community_moderators cm
         LEFT JOIN community_sections cs ON cm.section_id = cs.id
         WHERE cm.user_id=?`,
        [userId]
      )

      const bans = await query(
        "SELECT section_id as sectionId, reason, ban_until as banUntil, is_active as isActive FROM community_moderator_bans WHERE banned_user_id=? AND is_active=1 AND (ban_until IS NULL OR ban_until > NOW())",
        [userId]
      )

      const levelNames = ['新手', '成员', '活跃', '资深']

      res.json({ code: 200, msg: 'success', data: {
        trustLevel,
        trustLevelName: levelNames[trustLevel] || '新手',
        moderatorSections: modSections,
        banStatus: bans.length > 0 ? { banned: true, bans } : { banned: false, bans: [] },
        postCount,
        commentCount,
        reportCount
      }})
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Auto-Ban Settings APIs ====================

  app.get('/api/community/admin/auto-ban-settings', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const cfg = await getAutoBanSettings()
      res.json({ code: 200, msg: 'success', data: cfg })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/admin/auto-ban-settings', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { threshold, durationHours } = req.body || {}
      if (threshold !== undefined && threshold > 0) {
        await query(
          'INSERT INTO community_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?',
          ['auto_ban_threshold', String(threshold), String(threshold)]
        )
      }
      if (durationHours !== undefined && durationHours > 0) {
        await query(
          'INSERT INTO community_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?',
          ['auto_ban_duration_hours', String(durationHours), String(durationHours)]
        )
      }
      const cfg = await getAutoBanSettings()
      res.json({ code: 200, msg: '设置已更新', data: cfg })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Post Revision APIs ====================

  app.get('/api/community/post/:id/revisions', async (req, res) => {
    try {
      const postId = Number(req.params.id)
      const revisions = await query(
        `SELECT pr.id, pr.editor_id as editorId, COALESCE(NULLIF(u.nickname,''), u.username, '') as editorName,
                pr.edit_summary as editSummary, pr.version, pr.create_time as createTime
         FROM community_post_revisions pr
         LEFT JOIN users u ON pr.editor_id = u.id
         WHERE pr.post_id=?
         ORDER BY pr.version DESC`,
        [postId]
      )
      res.json({ code: 200, msg: 'success', data: revisions })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/community/post/:id/revisions/:revId', async (req, res) => {
    try {
      const rev = await query(
        'SELECT * FROM community_post_revisions WHERE id=? AND post_id=?',
        [Number(req.params.revId), Number(req.params.id)]
      )
      if (!rev.length) return res.json({ code: 404, msg: '版本不存在' })
      res.json({ code: 200, msg: 'success', data: rev[0] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/community/post/:id/revisions/:revId/restore', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const postId = Number(req.params.id)
      const post = await query('SELECT id, user_id, title, content, tags FROM community_posts WHERE id=?', [postId])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })

      if (post[0].user_id !== userId && !(await canAccessSection(userId, post[0].section_id)) && !(await isAdminById(userId))) {
        return res.json({ code: 403, msg: '无权恢复版本' })
      }

      const rev = await query(
        'SELECT * FROM community_post_revisions WHERE id=? AND post_id=?',
        [Number(req.params.revId), postId]
      )
      if (!rev.length) return res.json({ code: 404, msg: '版本不存在' })

      // Save current as revision before restoring
      await savePostRevision(postId, userId, post[0].title, post[0].content, post[0].tags, '恢复版本前自动保存')

      await query(
        'UPDATE community_posts SET title=?, content=?, tags=?, update_time=NOW() WHERE id=?',
        [rev[0].title, rev[0].content, rev[0].tags, postId]
      )

      res.json({ code: 200, msg: '已恢复到版本 #' + rev[0].version })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Scheduled Post Publisher & Hider ====================
  setInterval(async () => {
    try {
      const now = new Date()
      const scheduledPosts = await query(
        `SELECT id, user_id, user_name, user_avatar, section_id, title FROM community_posts
         WHERE status='scheduled' AND scheduled_time IS NOT NULL AND scheduled_time <= ?`,
        [now]
      )
      for (const post of scheduledPosts) {
        const sec = await query('SELECT review_required FROM community_sections WHERE id=? AND is_deleted=0', [post.section_id])
        const reviewRequired = sec.length > 0 && sec[0].review_required === 1
        const newStatus = reviewRequired ? 'pending' : 'published'
        await query('UPDATE community_posts SET status=?, update_time=NOW() WHERE id=?', [newStatus, post.id])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post.section_id])
        try {
          await systemLog(post.user_id, 'post_scheduled_publish', 'community', `定时发布帖子「${post.title}」`, req => ({}))
        } catch {}
        const msg = reviewRequired
          ? `您的帖子「${post.title}」已由系统自动提交，正在等待审核。`
          : `您的帖子「${post.title}」已按预定时间自动发布。`
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
          ['帖子发布提醒', msg, 'post_scheduled', post.id ? 'post' : 'system', post.id || 0, post.user_id]
        )
        console.log(`[ScheduledPost] Published post ${post.id}: "${post.title}" (status: ${newStatus})`)
      }

      // 自动隐藏到期的帖子
      const hidePosts = await query(
        `SELECT id, user_id, title FROM community_posts
         WHERE auto_hide_at IS NOT NULL AND auto_hide_at <= ? AND is_hidden=0`,
        [now]
      )
      for (const post of hidePosts) {
        await query('UPDATE community_posts SET is_hidden=1, update_time=NOW() WHERE id=?', [post.id])
        try {
          await systemLog(post.user_id, 'post_auto_hide', 'community', `自动隐藏帖子「${post.title}」`, req => ({}))
        } catch {}
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
          ['帖子隐藏提醒', `您的帖子「${post.title}」已按预定时间自动隐藏。`, 'post_hidden', post.id ? 'post' : 'system', post.id || 0, post.user_id]
        )
        console.log(`[AutoHide] Hidden post ${post.id}: "${post.title}"`)
      }
    } catch (e) {
      console.error('[Scheduler] Cron error:', e.message)
    }
  }, 60000)
}

module.exports = communityRoutes
