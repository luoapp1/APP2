const { query, getSystemOperator, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community/community-utils.cjs')

const communitySections = require('./community/community-sections.cjs')
const communityPosts = require('./community/community-posts.cjs')
const communityInteractions = require('./community/community-interactions.cjs')
const communityAdmin = require('./community/community-admin.cjs')
const communityModerator = require('./community/community-moderator.cjs')

function communityRoutes(app) {
  communitySections(app)
  communityPosts(app)
  communityInteractions(app)
  communityAdmin(app)
  communityModerator(app)

  // 定时发帖与自动隐藏已迁移至统一调度器 server/scheduler/tasks.cjs
}

module.exports = communityRoutes
