const { query, getSystemOperator, sessions, SESSION_TTL, nowExpr, progressTasksByAction, systemLog, sanitizeCommunityContent, emitSafe, POST_EVENTS, COMMENT_EVENTS, SECTION_EVENTS, deleteFileRecordsByRef, deleteFileRecordsByIds, sendNotificationEmail, getAdminEmails, multer, path, communityUploadDir, communityImageUpload, getModeratorEmails, getUserEmail, createMentionNotifications, getAdminUserName, getUserId, getUserRoles, isAdmin, isAdminById, canAccessSection, initTrustLevel, calcTrustScore, getTrustLevelByScore, incrementPostCount, incrementCommentCount, incrementLikeReceived, getAutoBanSettings, checkAutoBan, savePostRevision, getModeratorRoles, getModeratorRoleCodes, getAvailableRoles, getHighestRoleIndex, isModeratorOfSection, isModeratorOfPost, getModeratorSectionIds, REVIEWER_ONLY_ROLES, getModeratorRoleForPost, canReviewModAction, canManageModAction, logModeratorAction, cleanupPostContentImages, checkSensitiveWords } = require('./community/community-utils.cjs')

const communitySections = require('./community/community-sections.cjs')
const communityPosts = require('./community/community-posts.cjs')
const communityInteractions = require('./community/community-interactions.cjs')
const communityAdmin = require('./community/community-admin.cjs')
const communityModerator = require('./community/community-moderator.cjs')

function communityRoutes(app) {
  communitySections(app)
  communityPosts(app)
  communityInteractions(app)
  communityAdmin(app)
  communityModerator(app)

  // ==================== Scheduled Post Publisher & Hider ====================
  setInterval(async () => {
    try {
      const now = new Date()
      const scheduledPosts = await query(
        `SELECT id, user_id, user_name, user_avatar, section_id, title FROM community_posts
         WHERE status='scheduled' AND scheduled_time IS NOT NULL AND scheduled_time <= ?`,
        [now]
      )
      for (const post of scheduledPosts) {
        const sec = await query('SELECT review_required FROM community_sections WHERE id=? AND is_deleted=0', [post.section_id])
        const reviewRequired = sec.length > 0 && sec[0].review_required === 1
        const newStatus = reviewRequired ? 'pending' : 'published'
        await query('UPDATE community_posts SET status=?, update_time=NOW() WHERE id=?', [newStatus, post.id])
        await query('UPDATE community_sections SET post_count = post_count + 1 WHERE id=? AND is_deleted=0', [post.section_id])
        try {
          await systemLog(post.user_id, 'post_scheduled_publish', 'community', `定时发布帖子「${post.title}」`, req => ({}))
        } catch {}
        const msg = reviewRequired
          ? `您的帖子「${post.title}」已由系统自动提交，正在等待审核。`
          : `您的帖子「${post.title}」已按预定时间自动发布。`
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
          ['帖子发布提醒', msg, 'post_scheduled', post.id ? 'post' : 'system', post.id || 0, post.user_id]
        )
        console.log(`[ScheduledPost] Published post ${post.id}: "${post.title}" (status: ${newStatus})`)
      }

      // 自动隐藏到期的帖子
      const hidePosts = await query(
        `SELECT id, user_id, title FROM community_posts
         WHERE auto_hide_at IS NOT NULL AND auto_hide_at <= ? AND is_hidden=0`,
        [now]
      )
      for (const post of hidePosts) {
        await query('UPDATE community_posts SET is_hidden=1, update_time=NOW() WHERE id=?', [post.id])
        try {
          await systemLog(post.user_id, 'post_auto_hide', 'community', `自动隐藏帖子「${post.title}」`, req => ({}))
        } catch {}
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_type, target_id, user_id, create_time) VALUES (?,?,?,?,?,?,NOW())`,
          ['帖子隐藏提醒', `您的帖子「${post.title}」已按预定时间自动隐藏。`, 'post_hidden', post.id ? 'post' : 'system', post.id || 0, post.user_id]
        )
        console.log(`[AutoHide] Hidden post ${post.id}: "${post.title}"`)
      }
    } catch (e) {
      console.error('[Scheduler] Cron error:', e.message)
    }
  }, 60000)
}

module.exports = communityRoutes
