const { query, getSystemOperator } = require('../database.cjs')
const { deductBalance, deductPoints, addBalance, addPoints } = require('./account-utils.cjs')
const { hasPermission, getPermissionValue } = require('../middleware/level-permissions.cjs')

async function getUserBalancesMap(userId) {
  const rows = await query('SELECT currency_key, available, frozen FROM user_currency_balance WHERE user_id=?', [userId])
  const map = {}
  for (const r of rows) { map[r.currency_key] = Number(r.available || 0) + Number(r.frozen || 0) }
  return map
}
const nowExpr = 'NOW()'
const randFn = 'RAND()'
const { logFromReq } = require('../middleware/security.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')
const { executePenalty } = require('./custom-task.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')
const { sessions, SESSION_TTL, authRequired, requirePermission } = require('./system.cjs')

function isAdmin(req) {
  const rawToken = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = rawToken.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session && Date.now() - session.createdAt <= SESSION_TTL) return (session.roles || []).some(r => ['R_ADMIN','R_SUPER','R_MODERATOR','R_REVIEWER'].includes(r))
  return false
}

function getUserId(req) {
  let raw = req.headers.authorization || req.headers.token || req.query.token || ''
  if (!raw) {
    const cookies = (req.headers.cookie || '').split(';')
    for (const c of cookies) {
      const [k, ...rest] = c.trim().split('=')
      if (k === 'auth_token') { raw = decodeURIComponent(rest.join('=')); break }
    }
  }
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function getUserEmailFromAppstore(userId) {
  try {
    const rows = await query('SELECT email FROM users WHERE id=?', [userId])
    return rows.length > 0 ? rows[0].email : ''
  } catch { return '' }
}
const { calcCommission } = require('./commission.cjs')
const { deleteFileRecordsByRef } = require('../utils/file-helper.cjs')

function formatDateTime(d) {
  if (!d) return ''
  const dd = new Date(d)
  const pad = (n) => String(n).padStart(2, '0')
  return `${dd.getFullYear()}-${pad(dd.getMonth() + 1)}-${pad(dd.getDate())} ${pad(dd.getHours())}:${pad(dd.getMinutes())}:${pad(dd.getSeconds())}`
}

function parseJsonFields(obj, fields) {
  for (const f of fields) {
    try { obj[f] = obj[f] ? JSON.parse(obj[f]) : [] } catch { obj[f] = [] }
  }
  return obj
}

function appStoreRoutes(router) {

  // GET /api/app/list — 应用列表
  router.get('/api/app/list', async (req, res) => {
    try {
      const { keyword, category, status, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT id, name, package_name as packageName, version, version_code as versionCode,
                icon, icon_bg_color as iconBgColor, size_mb as sizeMb, downloads, rating,
                categories,
                description, update_content as updateContent, screenshots, tags, official_tags as officialTags,
                has_ads as hasAds, requires_network as requiresNetwork, has_paid_content as hasPaidContent, is_free as isFree,
                download_url as downloadUrl,
                coin_count as coinCount, coin_people as coinPeople, developer, category,
                price_type as priceType, price_amount as priceAmount,
                category_id as categoryId, is_pinned as isPinned, is_featured as isFeatured, is_official as isOfficial, user_id as userId,
                status, create_time as createTime, update_time as updateTime
               FROM app_store WHERE 1=1`
      const params = []

      if (keyword) {
        sql += ' AND (name LIKE ? OR package_name LIKE ?)'
        params.push(`%${keyword}%`, `%${keyword}%`)
      }
      if (category) { sql += ' AND (category=? OR category LIKE ? OR categories LIKE ?)'; params.push(category, `%\"${category}\"%`, `%\"${category}\"%`) }
      if (status !== undefined && status !== '') { sql += ' AND status=?'; params.push(status) }

      // 拉黑过滤
      const { getBlockedUserIds, getBlockerUserIds } = require('./user-block.cjs')
      const rawToken = req.headers.authorization || req.headers.token || req.query.token || ''
      const token = rawToken.replace(/^Bearer\s+/i, '')
      let authAppUserId = 0
      if (token) {
        const session = sessions.get(token)
        if (session && Date.now() - session.createdAt <= SESSION_TTL) {
          authAppUserId = Number(session.userId) || 0
        } else {
          try {
            const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
            if (rows.length > 0) {
              const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
              if (Date.now() - createdAt <= SESSION_TTL) authAppUserId = Number(rows[0].user_id) || 0
            }
          } catch {}
        }
      }
      if (authAppUserId > 0) {
        const [bid, brid] = await Promise.all([
          getBlockedUserIds(authAppUserId),
          getBlockerUserIds(authAppUserId)
        ])
        const excludeIds = [...new Set([...bid, ...brid])]
        if (excludeIds.length > 0) {
          sql += ` AND user_id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const listSql = sql + ` ORDER BY is_pinned DESC, id DESC LIMIT ${parseInt(pageSize)} OFFSET ${offset}`
      const [[countResult], list] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM (${sql}) t`, params),
        query(listSql, params)
      ])
      const total = countResult?.total || 0
      for (const item of list) {
        parseJsonFields(item, ['screenshots', 'tags', 'officialTags'])
      }
      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/hot-today — 今日热点（按今日点击量降序）
  router.get('/api/app/hot-today', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 5
      const sql = `SELECT a.id, a.name, a.package_name as packageName, a.version, a.version_code as versionCode,
                a.icon, a.icon_bg_color as iconBgColor, a.size_mb as sizeMb, a.downloads, a.rating,
                a.categories,
                a.description, a.update_content as updateContent, a.screenshots, a.tags, a.official_tags as officialTags,
                a.has_ads as hasAds, a.requires_network as requiresNetwork, a.has_paid_content as hasPaidContent, a.is_free as isFree,
                a.download_url as downloadUrl,
                a.coin_count as coinCount, a.coin_people as coinPeople, a.developer, a.category,
                a.price_type as priceType, a.price_amount as priceAmount,
                a.category_id as categoryId, a.is_pinned as isPinned, a.is_featured as isFeatured, a.is_official as isOfficial, a.user_id as userId,
                a.status, a.create_time as createTime, a.update_time as updateTime,
                COUNT(c.id) as clickCount
               FROM app_store a
               LEFT JOIN app_clicks c ON a.id=c.app_id AND DATE(c.create_time)=CURDATE()
               WHERE a.status='1'
               GROUP BY a.id
               ORDER BY clickCount DESC, a.is_pinned DESC, a.id DESC
               LIMIT ${limit}`
      const list = await query(sql)
      for (const item of list) {
        parseJsonFields(item, ['screenshots', 'tags', 'officialTags'])
      }
      res.json({ code: 200, msg: 'success', data: { list } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/trending-week — 本周趋势（按本周点击量降序）
  router.get('/api/app/trending-week', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 5
      const sql = `SELECT a.id, a.name, a.package_name as packageName, a.version, a.version_code as versionCode,
                a.icon, a.icon_bg_color as iconBgColor, a.size_mb as sizeMb, a.downloads, a.rating,
                a.categories,
                a.description, a.update_content as updateContent, a.screenshots, a.tags, a.official_tags as officialTags,
                a.has_ads as hasAds, a.requires_network as requiresNetwork, a.has_paid_content as hasPaidContent, a.is_free as isFree,
                a.download_url as downloadUrl,
                a.coin_count as coinCount, a.coin_people as coinPeople, a.developer, a.category,
                a.price_type as priceType, a.price_amount as priceAmount,
                a.category_id as categoryId, a.is_pinned as isPinned, a.is_featured as isFeatured, a.is_official as isOfficial, a.user_id as userId,
                a.status, a.create_time as createTime, a.update_time as updateTime,
                COUNT(c.id) as clickCount
               FROM app_store a
               LEFT JOIN app_clicks c ON a.id=c.app_id AND YEARWEEK(c.create_time, 1)=YEARWEEK(CURDATE(), 1)
               WHERE a.status='1'
               GROUP BY a.id
               ORDER BY clickCount DESC, a.is_pinned DESC, a.id DESC
               LIMIT ${limit}`
      const list = await query(sql)
      for (const item of list) {
        parseJsonFields(item, ['screenshots', 'tags', 'officialTags'])
      }
      res.json({ code: 200, msg: 'success', data: { list } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/:id/detail — 应用详情
  router.get('/api/app/:id/detail', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      if (!appId) return res.json({ code: 400, msg: '参数错误' })

      const [app] = await query(
        `SELECT a.id, a.name, a.package_name as packageName, a.version, a.version_code as versionCode,
                a.icon, a.icon_bg_color as iconBgColor, a.size_mb as sizeMb, a.downloads, a.rating,
                a.categories, a.description, a.update_content as updateContent, a.screenshots, a.tags,
                a.official_tags as officialTags, a.has_ads as hasAds, a.requires_network as requiresNetwork,
                a.has_paid_content as hasPaidContent, a.is_free as isFree, a.download_url as downloadUrl,
                a.coin_count as coinCount, a.coin_people as coinPeople, a.developer, a.category,
                a.price_type as priceType, a.price_amount as priceAmount, a.category_id as categoryId,
                a.is_pinned as isPinned, a.is_featured as isFeatured, a.is_official as isOfficial,
                a.user_id as userId, a.status, a.content_permission as contentPermission,
                a.content_price as contentPrice, a.content_price_type as contentPriceType,
                a.access_password as accessPassword, a.access_password_tips as accessPasswordTips,
                COALESCE(a.type, 'apk') as type,
                a.create_time as createTime, a.update_time as updateTime,
                u.username as userName, u.avatar as userAvatar
         FROM app_store a
         LEFT JOIN users u ON u.id = a.user_id
         WHERE a.id=?`, [appId]
      )
      if (!app) return res.json({ code: 404, msg: '应用不存在' })
      parseJsonFields(app, ['screenshots', 'tags', 'officialTags', 'categories'])

      const [comments, versions] = await Promise.all([
        query(
          `SELECT c.id, c.app_id as appId, c.parent_id as parentId, c.user_id as userId,
                  c.user_name as userName,
                  COALESCE(u.avatar, '') as userAvatar,
                  c.device, c.version,
                  c.content, c.likes, c.replies, c.reported, c.is_pinned as isPinned,
                  c.rating, c.create_time as createTime,
                  COALESCE((SELECT COUNT(*) FROM comment_likes cl WHERE cl.comment_id = c.id), 0) as likeCount
           FROM app_comments c
           LEFT JOIN users u ON u.id = c.user_id
           WHERE c.app_id=? ORDER BY c.is_pinned DESC, c.likes DESC, c.id DESC`,
          [appId]
        ),
        query(
          `SELECT id, app_id as appId, user_id as userId, user_name as userName, name,
                  package_name as packageName, category, description, icon, icon_bg_color as iconBgColor,
                  version, version_code as versionCode, size_mb as sizeMb, download_url as downloadUrl,
                  screenshots, tags, version_type as versionType, has_ads as hasAds,
                  requires_network as requiresNetwork, has_paid_content as hasPaidContent,
                  is_free as isFree, downloads, rating, coin_count as coinCount, coin_people as coinPeople,
                  status, submission_status as submissionStatus, review_comment as reviewComment,
                  create_time as createTime, update_time as updateTime
           FROM app_uploads WHERE app_id=? AND status='1' ORDER BY create_time DESC`,
          [appId]
        )
      ])

      for (const v of versions) {
        parseJsonFields(v, ['screenshots', 'tags'])
      }

      const ratingStats = await query(
        `SELECT
           ROUND(AVG(rating), 1) as average,
           COUNT(*) as total,
           SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as star1,
           SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as star2,
           SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as star3,
           SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as star4,
           SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as star5
         FROM app_comments WHERE app_id=? AND rating > 0`,
        [appId]
      )
      const rs = ratingStats?.[0] || {}
      const distribution = {}
      for (let i = 1; i <= 5; i++) distribution[i] = Number(rs['star' + i]) || 0

      res.json({
        code: 200, msg: 'success',
        data: {
          app,
          comments,
          versions,
          ratingStats: { average: Number(rs.average) || 0, total: Number(rs.total) || 0, distribution }
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/version/save — 添加/更新版本 (任何用户)
  router.post('/api/app/version/save', async (req, res) => {
    try {
      const { id, appId, version, versionCode, sizeMb, downloads, rating,
              downloadUrl, updateContent, tags, officialTags, hasAds, requiresNetwork, hasPaidContent, isFree, isCurrent, userId, userName } = req.body
      const tg = tags ? JSON.stringify(tags) : '[]'
      const ot = officialTags ? JSON.stringify(officialTags) : '[]'

      if (id) {
        if (isCurrent) {
          await query('UPDATE app_versions SET is_current=0 WHERE app_id=(SELECT app_id FROM app_versions WHERE id=?)', [id])
        }
        await query(
          `UPDATE app_versions SET version=?, version_code=?, size_mb=?, downloads=?, rating=?,
           download_url=?, update_content=?, tags=?, official_tags=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?, is_current=?, user_name=? WHERE id=?`,
          [version, versionCode || '', sizeMb || 0, downloads || 0, rating || 0,
           downloadUrl || '', updateContent || '', tg, ot,
           hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
           isCurrent ? 1 : 0, userName || '', id]
        )
        res.json({ code: 200, msg: '版本更新成功', data: { id } })
      } else {
        // 如果设为当前版本，取消同应用的其它当前版本
        if (isCurrent) {
          await query('UPDATE app_versions SET is_current=0 WHERE app_id=?', [appId])
        }
        const result = await query(
          `INSERT INTO app_versions (app_id, version, version_code, size_mb, downloads, rating,
           download_url, update_content, tags, official_tags, has_ads, requires_network, has_paid_content, is_free, is_current, user_id, user_name)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [appId, version, versionCode || '', sizeMb || 0, downloads || 0, rating || 0,
           downloadUrl || '', updateContent || '', tg, ot,
           hasAds ? 1 : 0, requiresNetwork ? 1 : 0, hasPaidContent ? 1 : 0, isFree ? 1 : 0,
           isCurrent ? 1 : 0, userId || 0, userName || '']
        )
        // 同步更新 app_store 版本号
        if (isCurrent) {
          await query('UPDATE app_store SET version=?, version_code=?, size_mb=? WHERE id=?',
            [version, versionCode || '', sizeMb || 0, appId])
        }
        res.json({ code: 200, msg: '版本新增成功', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/app/version/:id — 删除版本
  router.delete('/api/app/version/:id', async (req, res) => {
    try {
      await query('DELETE FROM app_versions WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '版本删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 用户上传 ==========

  // POST /api/app/upload — 用户上传应用
  router.post('/api/app/upload', async (req, res) => {
    try {
      const { userId, userName, name, packageName, category, description, icon, price_type, price_amount } = req.body

      // 自动审核管线
      let appStatus = '0'
      try {
        const mp = require('./community/moderation-pipeline.cjs')
        const pipelineResult = await mp.moderationPipeline(userId || 0, {
          text: (name || '') + ' ' + (description || ''),
          name: name || '',
          description: description || '',
          screenshots: screenshotUrls || []
        }, 'app')
        if (pipelineResult.action === 'reject') {
          executePenalty(userId || 0, '', 'app_rejected', {})
          return res.json({ code: 400, msg: pipelineResult.reason || '内容不符合社区规范，无法提交' })
        }
        if (pipelineResult.action === 'publish') {
          appStatus = '1'
        }
      } catch (e) { console.error('[appstore] moderation pipeline error:', e.message) }

      // A3: 应用提交数量上限
      const maxApps = parseInt(await getPermissionValue(userId || 0, 'appstore', 'A3') || '999')
      const [countRow] = await query('SELECT COUNT(*) as cnt FROM app_uploads WHERE user_id=?', [userId || 0])
      if (countRow && Number(countRow.cnt) >= maxApps) {
        return res.json({ code: 400, msg: `当前等级最多提交${maxApps}个应用，您已提交${countRow.cnt}个` })
      }

      // A5: 可创建付费应用
      if (price_type === 'paid' || price_type === 'balance') {
        const canPaid = await hasPermission(userId || 0, 'appstore', 'A5')
        if (!canPaid) return res.json({ code: 403, msg: '当前等级不支持创建付费应用' })
      }

      // A1: 应用提交免审核
      if (await hasPermission(userId || 0, 'appstore', 'A1')) {
        appStatus = '1'
      }

      // A4: 应用定价上限
      if (price_type === 'paid' || price_type === 'balance') {
        const maxPrice = parseInt(await getPermissionValue(userId || 0, 'appstore', 'A4') || '0')
        if (maxPrice > 0 && Number(price_amount || 0) > maxPrice) {
          return res.json({ code: 400, msg: `当前等级应用定价上限为${maxPrice}元` })
        }
      }

      const result = await query(
        `INSERT INTO app_uploads (user_id, user_name, name, package_name, category, description, icon, status, price_type, price_amount)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [userId || 0, userName || '', name, packageName || '', category || '工具', description || '', icon || '', appStatus, price_type || 'free', Number(price_amount || 0)]
      )
      // 同时创建 app_store 待审核记录
      await query(
        `INSERT INTO app_store (name, package_name, version, version_code, icon, icon_bg_color, size_mb, description, category, status, price_type, price_amount)
         VALUES (?, ?, '1.0.0', '100', ?, '#00BFA5', 0, ?, ?, '0', ?, ?)`,
        [name, packageName || '', icon || '', description || '', category || '工具', price_type || 'free', Number(price_amount || 0)]
      )

      // 投稿待审核通知管理员
      const adminEmails = await getAdminEmails()
      for (const adminEmail of adminEmails) {
        sendNotificationEmail('submission_review', adminEmail, {
          username: '管理员',
          subject: '投稿待审核通知',
          content: `用户 ${userName || ''} 提交了应用投稿《${name}》，请尽快审核。`
        })
      }

      res.json({ code: 200, msg: '上传成功，等待审核', data: { id: result.insertId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/uploads — 用户上传列表
  router.get('/api/app/uploads', async (req, res) => {
    try {
      const { userId } = req.query
      let sql = `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                  name, package_name as packageName, category, description, icon,
                  status, create_time as createTime, update_time as updateTime
                 FROM app_uploads WHERE 1=1`
      const params = []
      if (userId) { sql += ' AND user_id=?'; params.push(userId) }
      const list = await query(sql + ' ORDER BY id DESC', params)
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/recommend — 随便看看推荐
  router.get('/api/app/recommend', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, icon_bg_color as iconBgColor, downloads, icon
         FROM app_store WHERE status='1' ORDER BY ${randFn} LIMIT 6`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 应用分类管理 ==========

  // GET /api/category/list
  router.get('/api/category/list', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, icon, sort_order as sortOrder, status, create_time as createTime
         FROM app_categories ORDER BY sort_order ASC, id ASC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/category/save
  router.post('/api/category/save', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const { id, name, icon, sortOrder, status } = req.body
      if (id) {
        await query(
          `UPDATE app_categories SET name=?, icon=?, sort_order=?, status=? WHERE id=?`,
          [name, icon || '', Number(sortOrder) || 0, status || '1', Number(id)]
        )
        logFromReq(req, 'update', 'category', Number(id), `更新分类"${name}"`)
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO app_categories (name, icon, sort_order, status) VALUES (?,?,?,?)`,
          [name, icon || '', Number(sortOrder) || 0, status || '1']
        )
        logFromReq(req, 'create', 'category', result.insertId, `新增分类"${name}"`)
        res.json({ code: 200, msg: '新增成功', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/category/:id
  router.delete('/api/category/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      await query('DELETE FROM app_categories WHERE id=?', [Number(req.params.id)])
      logFromReq(req, 'delete', 'category', req.params.id, `删除分类ID:${req.params.id}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 投币打赏 ==========

  // POST /api/app/:id/tip — 用户打赏（需登录，支持余额/积分）
  router.post('/api/app/:id/tip', async (req, res) => {
    try {
      const { userId, userName, amount, message, tipType = 'balance' } = req.body
      const appId = Number(req.params.id)
      const tipAmount = Number(amount) || 0

      if (tipAmount <= 0) return res.json({ code: 400, msg: '打赏金额必须大于0' })

      // 检查是否给自己打赏：用 user_id (如果应用关联了用户) 或 developer 字段匹配
      const appInfo = await query('SELECT id, name, user_id as userId, developer FROM app_store WHERE id=?', [appId])
      if (!appInfo || appInfo.length === 0) return res.json({ code: 404, msg: '应用不存在' })
      const appOwnerId = Number(appInfo[0].userId || 0)
      const appDev = (appInfo[0].developer || '').trim()
      const tipUserName = (userName || user?.username || '').trim()

      const isSelf = appOwnerId > 0
        ? appOwnerId === Number(userId)
        : appDev && tipUserName && appDev === tipUserName

      if (isSelf) return res.json({ code: 400, msg: '不能给自己打赏' })

      const users = await query('SELECT id, username, avatar FROM users WHERE id=?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      const bm = await getUserBalancesMap(Number(userId))
      users[0].balance = bm.balance || 0
      users[0].points = bm.points || 0

      const user = users[0]

      // 扣除打赏者余额/积分
      let newBalance = Number(user.balance)
      let newPoints = Number(user.points || 0)
      if (tipType === 'balance') {
        if (Number(user.balance) < tipAmount) return res.json({ code: 400, msg: '余额不足' })
        newBalance = Number(user.balance) - tipAmount
        await deductBalance(Number(userId), user.username, tipAmount, '应用打赏', `打赏应用《${appInfo[0].name || ''}》`)
      } else {
        if (Number(user.points || 0) < tipAmount) return res.json({ code: 400, msg: '积分不足' })
        newPoints = Number(user.points || 0) - tipAmount
        await deductPoints(Number(userId), user.username, tipAmount, '应用打赏', `打赏应用《${appInfo[0].name || ''}》`)
      }

      // 给应用拥有者增加余额/积分
      let ownerId = Number(appInfo[0].userId || 0)
      if (ownerId === 0 && appInfo[0].developer) {
        const ownerRow = await query('SELECT id FROM users WHERE username=? LIMIT 1', [appInfo[0].developer])
        if (ownerRow && ownerRow.length > 0) ownerId = Number(ownerRow[0].id)
      }
      if (ownerId > 0 && ownerId !== Number(userId)) {
        const ownerInfo = await query('SELECT username FROM users WHERE id=?', [ownerId])
        const ownerName = ownerInfo[0]?.username || ''
        if (tipType === 'balance') {
          await addBalance(ownerId, ownerName, tipAmount, '打赏收入', `收到 ${user.username} 打赏应用《${appInfo[0].name || ''}》`)
        } else {
          await addPoints(ownerId, ownerName, tipAmount, '打赏收入', `收到 ${user.username} 打赏应用《${appInfo[0].name || ''}》`)
        }
      }

      await query(
        `INSERT INTO app_tips (app_id, user_id, user_name, amount, tip_type, message) VALUES (?, ?, ?, ?, ?, ?)`,
        [appId, Number(userId), userName || user.username, tipAmount, tipType, message || '']
      )
      await query('UPDATE app_store SET coin_count=coin_count+?, coin_people=coin_people+1 WHERE id=?', [tipAmount, appId])

      const trimmedMsg = (message || '').trim()
      const commentContent = trimmedMsg
        ? `[打赏${tipAmount}${tipType === 'balance' ? '元' : '积分'}] ${trimmedMsg}`
        : `[打赏${tipAmount}${tipType === 'balance' ? '元' : '积分'}]`
      await query(
        `INSERT INTO app_comments (app_id, user_id, user_name, content, rating)
         VALUES (?, ?, ?, ?, 0)`,
        [appId, Number(userId), userName || user.username, commentContent]
      )

      // 通知应用作者收到打赏
      if (ownerId > 0) {
        const unit = tipType === 'balance' ? '元' : '积分'
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
           VALUES (?, ?, 'system', ?, ?, ?, '')`,
          ['收到打赏', `${userName || user.username} 给您的应用《${appInfo[0].name || ''}》打赏了 ${tipAmount}${unit}`, ownerId, userId, userName || user.username]
        )
      }

      res.json({ code: 200, msg: '打赏成功', data: { tipType, amount: tipAmount, newBalance, newPoints } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:id/purchase — 购买应用
  router.post('/api/app/:id/purchase', async (req, res) => {
    const appId = Number(req.params.id)
    const { userId: rawUserId, priceType, couponId: rawCouponId } = req.body
    const userId = Number(rawUserId || 0)
    const couponId = Number(rawCouponId || 0)
    if (!userId || userId <= 0) return res.json({ code: 401, msg: '请先登录' })
    try {
      const app = await query('SELECT user_id, price_type, price_amount, name FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })
      const info = app[0]

      // 上传者自己免费下载
      if (info.user_id > 0 && Number(info.user_id) === userId) {
        return res.json({ code: 200, msg: '您是该应用的上传者，可免费下载', data: { isOwner: true, alreadyPurchased: false, paidPrice: 0 } })
      }

      const price_type = priceType || info.price_type || 'free'
      const price_amount = Number(info.price_amount || 0)

      // 检查是否已购买
      const bought = await query('SELECT id FROM app_purchases WHERE app_id=? AND user_id=?', [appId, userId])
      if (bought.length) return res.json({ code: 200, msg: '您已购买过该应用，可直接下载', data: { alreadyPurchased: true } })

      if (price_type === 'free' || price_amount <= 0) {
        // A7: 应用下载免购买(次/日)
        const freeDaily = parseInt(await getPermissionValue(userId, 'appstore', 'A7') || '0')
        if (freeDaily > 0) {
          const today = new Date().toISOString().substring(0, 10)
          const todayFree = await query(
            `SELECT COUNT(*) as cnt FROM app_purchases WHERE user_id=? AND price_type='free' AND DATE(create_time)=?`,
            [userId, today]
          )
          if ((todayFree[0]?.cnt || 0) < freeDaily) {
            await query(`INSERT INTO app_purchases (app_id, user_id, user_name, price_type, original_price, paid_price, discount_rate)
              VALUES (?, ?, ?, 'free', 0, 0, 1.0)`, [appId, userId, ''])
            await query('UPDATE app_store SET downloads=downloads+1 WHERE id=?', [appId])
            return res.json({ code: 200, msg: '等级特权：免费下载', data: { alreadyPurchased: false, paidPrice: 0 } })
          }
        }
        await query(`INSERT INTO app_purchases (app_id, user_id, user_name, price_type, original_price, paid_price, discount_rate)
          VALUES (?, ?, ?, 'free', 0, 0, 1.0)`, [appId, userId, ''])
        await query('UPDATE app_store SET downloads=downloads+1 WHERE id=?', [appId])
        return res.json({ code: 200, msg: '免费应用，已获得下载权限', data: { alreadyPurchased: false, paidPrice: 0 } })
      }

      // 获取用户信息
      const users = await query('SELECT username FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })
      const bmApp = await getUserBalancesMap(userId)
      users[0].balance = bmApp.balance || 0
      users[0].points = bmApp.points || 0
      const user = users[0]

      // 应用折扣率 - 使用最新会员模型
      const { getUserLevel } = require('./content.cjs')
      const userLevel = await getUserLevel(userId)
      let discountRate = 1.0
      let membershipName = ''
      if (userLevel) {
        const ml = await query('SELECT currency_discounts, discount_rate, points_discount_rate, name FROM membership_levels WHERE id=?', [userLevel.levelId])
        if (ml.length) {
          if (ml[0].currency_discounts) {
            try {
              const cd = JSON.parse(ml[0].currency_discounts)
              discountRate = Number(cd[price_type] || 1.0)
            } catch {}
          }
          if (discountRate === 1.0) {
            if (price_type === 'points') {
              discountRate = Number(ml[0].points_discount_rate || 1.0)
            } else {
              discountRate = Number(ml[0].discount_rate || 1.0)
            }
          }
          membershipName = ml[0].name || ''
        }
      }
      let finalPrice = Math.round(price_amount * discountRate * 100) / 100

      // 优惠券处理
      let couponDiscount = 0
      let usedCouponName = ''
      let ucCid = 0
      if (couponId) {
        const nowStr = formatDateTime(new Date())
        const uc = await query('SELECT coupon_data, status, expire_time, coupon_id, remaining_value FROM user_coupons WHERE id=? AND user_id=?', [couponId, userId])
        if (!uc.length) return res.json({ code: 400, msg: '优惠券不存在' })
        if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })
        if (uc[0].expire_time && uc[0].expire_time < nowStr) {
          await query("UPDATE user_coupons SET status='expired' WHERE id=?", [couponId])
          return res.json({ code: 400, msg: '优惠券已过期' })
        }
        const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
        const c = await query('SELECT type, value, max_discount, scope, is_multi_use, min_order, name FROM coupons WHERE id=?', [uc[0].coupon_id])
        if (!c.length) return res.json({ code: 404, msg: '优惠券模板不存在' })
        const couponType = c[0].type || cd.type
        const couponValue = Number(c[0].value || cd.value || 0)
        const couponMaxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
        const couponScope = c[0].scope || cd.scope
        const isMultiUse = !!(c[0].is_multi_use)

        const isPointsCoupon = couponType === 'fixed_points' || couponType === 'points_percent'
        const isBalanceCoupon = couponType === 'fixed' || couponType === 'percent'
        if (isPointsCoupon && price_type !== 'points') return res.json({ code: 400, msg: '此优惠券仅限积分支付时使用' })
        if (isBalanceCoupon && price_type === 'points') return res.json({ code: 400, msg: '此优惠券仅限余额支付时使用' })

        if (couponScope && couponScope !== 'all' && couponScope !== 'product') {
          return res.json({ code: 400, msg: '此优惠券不适用于应用购买' })
        }

        const minOrder = Number(c[0].min_order || cd.minOrder || 0)
        if (minOrder > 0 && finalPrice < minOrder) {
          return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
        }

        usedCouponName = c[0].name || cd.name || ''
        ucCid = uc[0].coupon_id
        let availableValue = couponValue
        if (isMultiUse) {
          availableValue = uc[0].remaining_value !== null && uc[0].remaining_value !== undefined
            ? Number(uc[0].remaining_value) : couponValue
        }

        if (couponType === 'fixed' || couponType === 'fixed_points') {
          couponDiscount = Math.min(availableValue, finalPrice)
        } else {
          couponDiscount = Math.floor(finalPrice * couponValue / 100 * 100) / 100
          if (couponMaxDisc > 0 && couponDiscount > couponMaxDisc) couponDiscount = couponMaxDisc
        }
        if (couponDiscount > finalPrice) couponDiscount = finalPrice

        const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
        const beforeRemaining = isMultiUse ? availableValue : null

        if (isMultiUse) {
          if (afterRemaining <= 0) {
            await query(
              `UPDATE user_coupons SET status='used', use_time=?, use_scene='app_buy', use_amount=use_amount+?, remaining_value=0 WHERE id=?`,
              [nowStr, couponDiscount, couponId]
            )
          } else {
            await query(
              `UPDATE user_coupons SET use_time=?, use_scene='app_buy', use_amount=use_amount+?, remaining_value=? WHERE id=?`,
              [nowStr, couponDiscount, afterRemaining, couponId]
            )
          }
        } else {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene='app_buy', use_amount=? WHERE id=?`,
            [nowStr, couponDiscount, couponId]
          )
        }

        await query(
          `INSERT INTO coupon_usage_logs (user_coupon_id, user_id, user_name, coupon_id, coupon_name, use_scene, use_amount, before_remaining, after_remaining, order_desc, use_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          [couponId, userId, user.username || '', uc[0].coupon_id, usedCouponName, 'app_buy', couponDiscount, beforeRemaining, afterRemaining, `购买应用 #${appId} 原价${price_type==='points'?'积分':'¥'}${finalPrice.toFixed(2)} ${price_type==='points'?'积分':'余额'}减${price_type==='points'?couponDiscount+'积分':'¥'+couponDiscount.toFixed(2)}`, nowStr]
        )

        finalPrice = Math.max(0, finalPrice - couponDiscount)
      }

      const orderAmount = finalPrice + couponDiscount

      if (price_type === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalPrice) return res.json({ code: 400, msg: `余额不足，需要 ${finalPrice} 元，当前余额 ${currentBalance} 元`, data: { needBalance: finalPrice, currentBalance } })
        await deductBalance(userId, user.username || '', finalPrice, '应用购买', `购买应用《${info.name || ''}》`)
      } else if (price_type === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalPrice) return res.json({ code: 400, msg: `积分不足，需要 ${finalPrice} 积分，当前积分 ${currentPoints}` })
        await deductPoints(userId, user.username || '', finalPrice, '应用购买', `购买应用《${info.name || ''}》`)
      }

      // 写入购买记录
      await query(`INSERT INTO app_purchases (app_id, user_id, user_name, price_type, original_price, paid_price, discount_rate)
        VALUES (?, ?, ?, ?, ?, ?, ?)`, [appId, userId, user.username || '', price_type, price_amount, finalPrice, discountRate])

      // 创建结算订单记录 - 根据结算规则确定确认期
      const appBuyerLevel = user.level_id || 0
      const appConfirmCfg = await query('SELECT confirm_days FROM settlement_config WHERE level_id=? AND enabled=1', [appBuyerLevel])
      let appConfirmDays = 0
      if (!appConfirmCfg.length || appConfirmCfg[0].confirm_days === null || appConfirmCfg[0].confirm_days === undefined) {
        const def = await query('SELECT confirm_days FROM settlement_config WHERE level_id=0 AND enabled=1')
        appConfirmDays = def.length ? (def[0].confirm_days || 0) : 7
      } else {
        appConfirmDays = appConfirmCfg[0].confirm_days || 0
      }
      const appDeadline = appConfirmDays > 0 ? new Date(Date.now() + appConfirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19) : null
      const appOrderStatus = appConfirmDays > 0 ? 'shipped' : 'completed'
      const orderNo = 'AO' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
      await query(
        `INSERT INTO orders (order_no, buyer_id, buyer_name, seller_id, seller_name, order_type, order_desc, pay_type, total_amount, paid_amount, coupon_id, coupon_discount, ref_id, ref_table, status, confirm_days, confirm_deadline, shipped_at, confirmed_at)
         VALUES (?,?,?,(SELECT user_id FROM app_uploads WHERE id=? LIMIT 1),?,?,?,?,?,?,?,?,?,?,?,?,NOW(),${appConfirmDays > 0 ? 'NULL' : 'NOW()'})`,
        [orderNo, userId, user.username || '', appId, (info.author || ''), 'app_purchase', `购买应用《${info.name || ''}》`, price_type, price_amount, finalPrice, couponId > 0 ? ucCid : 0, couponDiscount, appId, 'app_store', appOrderStatus, appConfirmDays, appDeadline]
      )

      if (price_type === 'balance' && finalPrice > 0) {
        calcCommission(appId, 'app', finalPrice, userId)
      }

      // 通知购买者
      const unit = price_type === 'balance' ? '元' : '积分'
      const discountInfo = discountRate < 1 ? `（${membershipName}折扣${Math.round(discountRate*100)}%）` : ''
      const couponInfo = couponDiscount > 0 ? `（使用优惠券${usedCouponName}抵扣${price_type==='points'?couponDiscount+'积分':'¥'+couponDiscount}）` : ''
      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await query(`INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
        VALUES (?, ?, 'system', ?, 0, ?, '')`,
        ['购买成功', `您已成功购买《${info.name}》，支付 ${finalPrice}${unit}${discountInfo}${couponInfo}，可永久下载`, userId, sysOpName])

      // 通知上传者
      if (info.user_id > 0 && Number(info.user_id) !== userId) {
      await query(`INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
        VALUES (?, ?, 'system', ?, ?, ?, '')`,
        ['应用售出', `用户 ${user.username} 购买了您的应用《${info.name}》，收入 ${finalPrice}${unit}`, info.user_id, userId, user.username])
      }

      // 增加下载计数
      await query('UPDATE app_store SET downloads=downloads+1 WHERE id=?', [appId])

      const newBalance = price_type === 'balance' ? Math.round((Number(user.balance) - finalPrice) * 100) / 100 : Number(user.balance)
      const newPoints = price_type === 'points' ? Number(user.points) - finalPrice : Number(user.points)

      await progressTasksByAction(userId, '', 'download')
      await progressTasksByAction(userId, '', 'purchase')

      res.json({ code: 200, msg: '购买成功', data: { alreadyPurchased: false, paidPrice: finalPrice, discountRate, membershipName, couponDiscount, couponName: usedCouponName, newBalance, newPoints } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/:id/purchase-status — 检查购买状态
  router.get('/api/app/:id/purchase-status', async (req, res) => {
    const appId = Number(req.params.id)
    const userId = Number(req.query.userId || 0)
    if (!userId || userId <= 0) return res.json({ code: 200, data: { purchased: false } })
    try {
      const app = await query('SELECT user_id FROM app_store WHERE id=?', [appId])
      if (app.length && app[0].user_id === userId) {
        return res.json({ code: 200, data: { purchased: true } })
      }
      const bought = await query('SELECT id FROM app_purchases WHERE app_id=? AND user_id=?', [appId, userId])
      res.json({ code: 200, data: { purchased: bought.length > 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/:id/purchasers — 购买者列表
  router.get('/api/app/:id/purchasers', async (req, res) => {
    const appId = Number(req.params.id)
    try {
      const list = await query(
        `SELECT p.id, p.app_id as appId, p.user_id as userId, p.user_name as userName,
                p.price_type as priceType, p.original_price as originalPrice, p.paid_price as paidPrice,
                p.discount_rate as discountRate, p.create_time as createTime,
                u.avatar, u.level_name as levelName
         FROM app_purchases p
         LEFT JOIN users u ON u.id = p.user_id
         WHERE p.app_id=?
         ORDER BY p.create_time DESC`, [appId]
      )
      res.json({ code: 200, data: { list } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/:id/tips — 打赏列表
  router.get('/api/app/:id/tips', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                amount, tip_type as tipType, message, create_time as createTime
         FROM app_tips WHERE app_id=? ORDER BY id DESC`,
        [Number(req.params.id)]
      )
      const stats = await query(
        `SELECT
           SUM(CASE WHEN tip_type='balance' THEN amount ELSE 0 END) as totalBalance,
           SUM(CASE WHEN tip_type='points' THEN amount ELSE 0 END) as totalPoints
         FROM app_tips WHERE app_id=?`,
        [Number(req.params.id)]
      )
      res.json({ code: 200, msg: 'success', data: { list, stats: stats[0] || { totalBalance: 0, totalPoints: 0 } } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 评论管理 ==========

  // POST /api/app/:appId/comment — 发表评论
  router.post('/api/app/:appId/comment', async (req, res) => {
    try {
      const appId = Number(req.params.appId)
      const { userId, userName, rating, content } = req.body
      if (!appId || !userId) return res.json({ code: 400, msg: '参数错误' })
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const app = await query('SELECT id FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })

      const r = Math.min(5, Math.max(0, Number(rating) || 0))
      await query(
        `INSERT INTO app_comments (app_id, user_id, user_name, content, rating)
         VALUES (?, ?, ?, ?, ?)`,
        [appId, Number(userId), userName || '', content.trim(), r]
      )

      const ratingStats = await query(
        `SELECT ROUND(AVG(rating), 1) as average, COUNT(*) as total
         FROM app_comments WHERE app_id=? AND rating > 0`,
        [appId]
      )
      const rs = ratingStats?.[0] || {}
      await query(
        'UPDATE app_store SET rating=? WHERE id=?',
        [Number(rs.average) || 0, appId]
      )

      res.json({ code: 200, msg: '评论成功', data: {} })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:appId/comment/:cid/reply — 回复评论
  router.post('/api/app/:appId/comment/:cid/reply', async (req, res) => {
    try {
      const appId = Number(req.params.appId)
      const parentId = Number(req.params.cid)
      const { userId, userName, content } = req.body
      if (!appId || !parentId || !userId) return res.json({ code: 400, msg: '参数错误' })
      if (!content || !content.trim()) return res.json({ code: 400, msg: '回复内容不能为空' })

      const app = await query('SELECT id FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })

      const parent = await query('SELECT id FROM app_comments WHERE id=? AND app_id=?', [parentId, appId])
      if (!parent.length) return res.json({ code: 404, msg: '评论不存在' })

      await query(
        `INSERT INTO app_comments (app_id, parent_id, user_id, user_name, content)
         VALUES (?, ?, ?, ?, ?)`,
        [appId, parentId, Number(userId), userName || '', content.trim()]
      )
      await query('UPDATE app_comments SET replies=replies+1 WHERE id=?', [parentId])

      res.json({ code: 200, msg: '回复成功', data: {} })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:appId/comment/:cid/like — 点赞/取消点赞
  router.post('/api/app/:appId/comment/:cid/like', async (req, res) => {
    try {
      const userId = Number(req.body.userId)
      const commentId = Number(req.params.cid)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query(
        'SELECT id FROM comment_likes WHERE comment_id=? AND user_id=?',
        [commentId, userId]
      )
      if (existing.length > 0) {
        await query('DELETE FROM comment_likes WHERE comment_id=? AND user_id=?', [commentId, userId])
        await query('UPDATE app_comments SET likes = GREATEST(0, likes - 1) WHERE id=?', [commentId])
        const c = await query('SELECT likes as likeCount FROM app_comments WHERE id=?', [commentId])
        res.json({ code: 200, msg: '已取消点赞', data: { liked: false, likeCount: c[0]?.likeCount || 0 } })
      } else {
        await query('INSERT INTO comment_likes (comment_id, user_id) VALUES (?,?)', [commentId, userId])
        await query('UPDATE app_comments SET likes = likes + 1 WHERE id=?', [commentId])
        const c = await query('SELECT likes as likeCount FROM app_comments WHERE id=?', [commentId])
        res.json({ code: 200, msg: '已点赞', data: { liked: true, likeCount: c[0]?.likeCount || 0 } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/app/comment/:id — 管理员删除评论
  router.delete('/api/app/comment/:id', async (req, res) => {
    try {
      const comments = await query('SELECT user_id FROM app_comments WHERE id=?', [Number(req.params.id)])
      const commentUserId = comments && comments.length > 0 ? comments[0].user_id : null
      await query('DELETE FROM comment_likes WHERE comment_id=?', [Number(req.params.id)])
      await query('DELETE FROM app_comments WHERE id=?', [Number(req.params.id)])
      deleteFileRecordsByRef(Number(req.params.id), 'app_comment').catch(() => {})
      if (commentUserId) {
        executePenalty(commentUserId, '', 'review_malicious', { reason: '应用评论因违规被管理员删除' })
      }
      logFromReq(req, 'delete', 'comment', req.params.id, `管理员删除评论ID:${req.params.id}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/app/:appId/comment/:cid — 用户删除自己的评论
  router.delete('/api/app/:appId/comment/:cid', async (req, res) => {
    try {
      const commentId = Number(req.params.cid)
      const userId = Number(req.query.userId)
      const comment = (await query('SELECT id, user_id FROM app_comments WHERE id=?', [commentId]))[0]
      if (!comment) return res.json({ code: 404, msg: '评论不存在' })
      if (userId && comment.user_id !== userId) return res.json({ code: 403, msg: '无权删除他人评论' })
      await query('DELETE FROM comment_likes WHERE comment_id=?', [commentId])
      await query('DELETE FROM app_comments WHERE id=?', [commentId])
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/reports — 举报列表
  router.get('/api/app/reports', async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT c.id, c.app_id as appId, a.name as appName, c.user_name as userName,
                c.content, c.reported, c.create_time as createTime
         FROM app_comments c LEFT JOIN app_store a ON c.app_id = a.id
         WHERE c.reported > 0 ORDER BY c.reported DESC, c.id DESC
         LIMIT ? OFFSET ?`, [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM app_comments WHERE reported > 0')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/comment/:id/ignore — 忽略举报
  router.post('/api/app/comment/:id/ignore', async (req, res) => {
    try {
      await query('UPDATE app_comments SET reported=0 WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '已忽略', data: {} })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 置顶管理 ==========

  // PUT /api/app/comment/:id/pin — 切换评论置顶状态 (A6)
  router.put('/api/app/comment/:id/pin', async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const maxPin = parseInt(await getPermissionValue(userId, 'appstore', 'A6') || '0')
      if (maxPin <= 0) return res.json({ code: 403, msg: '当前等级无评论置顶权限' })
      const commentId = Number(req.params.id)

      const comment = (await query('SELECT id, app_id, is_pinned FROM app_comments WHERE id=?', [commentId]))[0]
      if (!comment) return res.json({ code: 404, msg: '评论不存在' })

      if (!comment.is_pinned) {
        const pinnedCount = (await query(
          'SELECT COUNT(*) as cnt FROM app_comments WHERE app_id=? AND is_pinned=1',
          [comment.app_id]
        ))[0]?.cnt || 0
        if (pinnedCount >= maxPin) return res.json({ code: 400, msg: `当前等级最多置顶${maxPin}条评论` })
      }

      const toggled = comment.is_pinned ? 0 : 1
      await query('UPDATE app_comments SET is_pinned=? WHERE id=?', [toggled, commentId])
      res.json({ code: 200, msg: toggled ? '已置顶' : '已取消置顶', data: { isPinned: !!toggled } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:appId/comment/:cid/pin — 切换评论置顶状态 (前端调用)
  router.post('/api/app/:appId/comment/:cid/pin', async (req, res) => {
    try {
      const userId = getUserId(req) || req.body?.userId || 0
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const maxPin = parseInt(await getPermissionValue(userId, 'appstore', 'A6') || '0')
      if (maxPin <= 0) return res.json({ code: 403, msg: '当前等级无评论置顶权限' })
      const commentId = Number(req.params.cid)

      const comment = (await query('SELECT id, app_id, is_pinned FROM app_comments WHERE id=?', [commentId]))[0]
      if (!comment) return res.json({ code: 404, msg: '评论不存在' })

      if (!comment.is_pinned) {
        const pinnedCount = (await query(
          'SELECT COUNT(*) as cnt FROM app_comments WHERE app_id=? AND is_pinned=1',
          [comment.app_id]
        ))[0]?.cnt || 0
        if (pinnedCount >= maxPin) return res.json({ code: 400, msg: `当前等级最多置顶${maxPin}条评论` })
      }

      const toggled = comment.is_pinned ? 0 : 1
      await query('UPDATE app_comments SET is_pinned=? WHERE id=?', [toggled, commentId])
      res.json({ code: 200, msg: toggled ? '已置顶' : '已取消置顶', data: { isPinned: !!toggled } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:id/pin — 切换置顶状态
  router.post('/api/app/:id/pin', async (req, res) => {
    try {
      const { pinned } = req.body
      await query('UPDATE app_store SET is_pinned=? WHERE id=?', [pinned ? 1 : 0, Number(req.params.id)])
      logFromReq(req, 'update', 'app', req.params.id, pinned ? `置顶应用ID:${req.params.id}` : `取消置顶应用ID:${req.params.id}`)
      res.json({ code: 200, msg: pinned ? '已置顶' : '已取消置顶', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:id/official — 切换官方认证状态
  router.post('/api/app/:id/official', async (req, res) => {
    try {
      const { isOfficial } = req.body
      const flag = isOfficial ? 1 : 0
      await query('UPDATE app_store SET is_official=? WHERE id=?', [flag, Number(req.params.id)])
      logFromReq(req, 'update', 'app', req.params.id, isOfficial ? `官方认证应用ID:${req.params.id}` : `取消官方认证应用ID:${req.params.id}`)
      res.json({ code: 200, msg: isOfficial ? '已设为官方认证' : '已取消官方认证', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/app/:id/featured — 切换精品推荐状态
  router.post('/api/app/:id/featured', async (req, res) => {
    try {
      const userId = getUserId(req)
      const { isFeatured } = req.body
      // A9: 推荐位加权 - 限制可推荐应用数量
      if (isFeatured && userId) {
        const maxFeatured = parseInt(await getPermissionValue(userId, 'appstore', 'A9') || '0')
        if (maxFeatured > 0) {
          const count = await query('SELECT COUNT(*) as cnt FROM app_store WHERE is_featured=1 AND user_id=?', [userId])
          if ((count[0]?.cnt || 0) >= maxFeatured) {
            return res.json({ code: 400, msg: `当前等级最多推荐${maxFeatured}个应用` })
          }
        }
      }
      const flag = isFeatured ? 1 : 0
      await query('UPDATE app_store SET is_featured=? WHERE id=?', [flag, Number(req.params.id)])
      logFromReq(req, 'update', 'app', req.params.id, isFeatured ? `精品推荐应用ID:${req.params.id}` : `取消精品推荐应用ID:${req.params.id}`)
      res.json({ code: 200, msg: isFeatured ? '已设为精品推荐' : '已取消精品推荐', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })
  // POST /api/app/:appId/comment/:cid/report — 举报评论(cid>0)或举报应用(cid=0)
  router.post('/api/app/:appId/comment/:cid/report', async (req, res) => {
    try {
      const { userId, reason } = req.body || {}
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 401, msg: '请先登录' })
      const cid = Number(req.params.cid) || 0
      const appId = Number(req.params.appId)

      const user = await query('SELECT username FROM users WHERE id=?', [uid])
      const userName = user[0]?.username || ''

      if (cid > 0) {
        await query('UPDATE app_comments SET reported = COALESCE(reported,0) + 1 WHERE id=?', [cid])
        await query(
          `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
           VALUES (?,?,?,?,?,?)`,
          [uid, userName, 'app_comment', cid, reason || '其他', '']
        )
      } else {
        await query(
          `INSERT INTO community_reports (reporter_id, reporter_name, target_type, target_id, report_reason, report_detail)
           VALUES (?,?,?,?,?,?)`,
          [uid, userName, 'app', appId, reason || '其他', '']
        )
      }
      logFromReq(req, 'report', cid > 0 ? 'app_comment' : 'app', cid > 0 ? String(cid) : String(appId),
        `用户举报${cid > 0 ? '评论' : '应用'}ID:${cid > 0 ? cid : appId}, 原因:${reason || '其他'}`)
      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
  // ========== App合集管理 ==========

  // POST /api/appstore/collections - 创建合集(所有登录用户)
  router.post('/api/appstore/collections', authRequired, async (req, res) => {
    try {
      const { name, description, coverUrl, appIds, isPublic } = req.body
      if (!name) return res.json({ code: 400, msg: '合集名称不能为空' })
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const admin = isAdmin(req)
      // A10: 合集/捆绑包创建数量限制
      const maxCollections = parseInt(await getPermissionValue(userId, 'appstore', 'A10') || '0')
      if (!admin && maxCollections > 0) {
        const cnt = await query('SELECT COUNT(*) as cnt FROM app_collections WHERE creator_id=?', [userId])
        if ((cnt[0]?.cnt || 0) >= maxCollections) {
          return res.json({ code: 400, msg: `当前等级最多创建${maxCollections}个合集` })
        }
      }
      const status = admin ? 'active' : 'pending'
      const publicFlag = isPublic !== false ? 1 : 0
      const result = await query(
        'INSERT INTO app_collections (name, description, cover_url, user_id, creator_id, is_public, status) VALUES (?,?,?,?,?,?,?)',
        [name, description || '', coverUrl || '', userId, userId, publicFlag, status]
      )
      const collectionId = result.insertId
      if (appIds && Array.isArray(appIds) && appIds.length > 0) {
        for (const appId of appIds) {
          await query('INSERT IGNORE INTO app_collection_items (collection_id, app_id) VALUES (?,?)', [collectionId, Number(appId)])
        }
      }
      logFromReq(req, 'create', 'app_collection', collectionId, `创建应用合集"${name}"`)
      res.json({ code: 200, msg: admin ? '创建成功' : '创建成功，等待审核', data: { id: collectionId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/appstore/collections/:id - 更新合集(所有者或管理员)
  router.put('/api/appstore/collections/:id', authRequired, async (req, res) => {
    try {
      const { name, description, coverUrl, sortOrder, status } = req.body
      const userId = getUserId(req)
      const admin = isAdmin(req)
      const [col] = await query('SELECT user_id, creator_id FROM app_collections WHERE id=?', [Number(req.params.id)])
      if (!col) return res.json({ code: 404, msg: '合集不存在' })
      if (!admin && col.creator_id !== userId) return res.json({ code: 403, msg: '无权限' })
      await query(
        'UPDATE app_collections SET name=?, description=?, cover_url=?, sort_order=?, status=? WHERE id=?',
        [name, description || '', coverUrl || '', Number(sortOrder) || 0, status || 'active', Number(req.params.id)]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/appstore/collections/:id - 删除合集(所有者或管理员)
  router.delete('/api/appstore/collections/:id', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      const admin = isAdmin(req)
      const [col] = await query('SELECT user_id, creator_id FROM app_collections WHERE id=?', [Number(req.params.id)])
      if (!col) return res.json({ code: 404, msg: '合集不存在' })
      if (!admin && col.creator_id !== userId) return res.json({ code: 403, msg: '无权限' })
      await query('DELETE FROM app_collection_items WHERE collection_id=?', [Number(req.params.id)])
      await query('DELETE FROM app_collections WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections - 合集列表(公开+已审核)
  router.get('/api/appstore/collections', async (req, res) => {
    try {
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.user_id as userId, c.creator_id as creatorId,
                c.status, c.sort_order as sortOrder, c.view_count as viewCount, c.likes,
                c.is_public as isPublic, c.is_pinned as isPinned, c.is_featured as isFeatured,
                c.create_time as createTime, c.update_time as updateTime,
                COUNT(aci.collection_id) as appCount
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         WHERE c.status='active'
         GROUP BY c.id
         ORDER BY c.is_pinned DESC, c.is_featured DESC, c.likes DESC, c.id DESC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/mine - 我的合集
  router.get('/api/appstore/collections/mine', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.status,
                c.is_public as isPublic, c.view_count as viewCount, c.likes,
                c.create_time as createTime, c.update_time as updateTime,
                COUNT(aci.collection_id) as appCount
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         WHERE c.creator_id=?
         GROUP BY c.id
         ORDER BY c.id DESC`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/ranking - 排行榜
  router.get('/api/appstore/collections/ranking', async (req, res) => {
    try {
      const { type = 'hot', page = 1, pageSize = 20 } = req.query
      let order = 'c.likes DESC, c.view_count DESC'
      if (type === 'new') order = 'c.id DESC'
      else if (type === 'apps') order = 'appCount DESC'
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.likes, c.view_count as viewCount,
                COUNT(aci.collection_id) as appCount, c.create_time as createTime
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         WHERE c.status='active' AND c.is_public=1
         GROUP BY c.id
         ORDER BY ${order}
         LIMIT ${parseInt(pageSize)} OFFSET ${offset}`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/search - 搜索合集
  router.get('/api/appstore/collections/search', async (req, res) => {
    try {
      const { keyword, page = 1, pageSize = 20 } = req.query
      if (!keyword) return res.json({ code: 200, data: [] })
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.likes, c.view_count as viewCount,
                COUNT(aci.collection_id) as appCount, c.create_time as createTime
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         WHERE c.status='active' AND c.is_public=1 AND (c.name LIKE ? OR c.description LIKE ?)
         GROUP BY c.id
         ORDER BY c.likes DESC
         LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        [`%${keyword}%`, `%${keyword}%`]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/featured - 精选合集
  router.get('/api/appstore/collections/featured', async (req, res) => {
    try {
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.likes, c.view_count as viewCount,
                COUNT(aci.collection_id) as appCount
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         WHERE c.status='active' AND c.is_featured=1
         GROUP BY c.id
         ORDER BY c.sort_order ASC, c.id DESC
         LIMIT 10`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/favorited - 我收藏的合集
  router.get('/api/appstore/collections/favorited', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.likes, c.view_count as viewCount,
                (SELECT COUNT(*) FROM app_collection_items WHERE collection_id = c.id) as appCount
         FROM collection_favorites cf
         JOIN app_collections c ON c.id = cf.collection_id AND c.status='active'
         WHERE cf.user_id=?
         ORDER BY cf.create_time DESC`, [Number(userId)]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/:id - 合集详情
  router.get('/api/appstore/collections/:id', async (req, res) => {
    try {
      const userId = getUserId(req)
      const collection = await query(
        `SELECT id, name, description, cover_url as coverUrl, user_id as userId, creator_id as creatorId,
                status, sort_order as sortOrder, view_count as viewCount, likes,
                is_public as isPublic, is_pinned as isPinned, is_featured as isFeatured,
                create_time as createTime, update_time as updateTime
         FROM app_collections WHERE id=?`, [Number(req.params.id)]
      )
      if (!collection || collection.length === 0) return res.json({ code: 404, msg: '合集不存在' })

      await query('UPDATE app_collections SET view_count=view_count+1 WHERE id=?', [Number(req.params.id)])

      const items = await query(
        `SELECT aci.id, aci.collection_id as collectionId, aci.app_id as appId, aci.sort_order as sortOrder,
                a.name, a.icon, a.icon_bg_color as iconBgColor, a.package_name as packageName,
                a.description, a.downloads, a.rating, a.category, a.status as appStatus
         FROM app_collection_items aci
         LEFT JOIN app_store a ON a.id = aci.app_id
         WHERE aci.collection_id=? ORDER BY aci.sort_order ASC, aci.id ASC`, [Number(req.params.id)]
      )

      let liked = false, favorited = false
      if (userId) {
        const [lk] = await query('SELECT 1 FROM collection_likes WHERE collection_id=? AND user_id=?', [Number(req.params.id), userId])
        const [fv] = await query('SELECT 1 FROM collection_favorites WHERE collection_id=? AND user_id=?', [Number(req.params.id), userId])
        liked = !!lk; favorited = !!fv
      }

      res.json({ code: 200, msg: 'success', data: { collection: collection[0], items, liked, favorited } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/appstore/collections/:id/apps - 添加应用
  router.post('/api/appstore/collections/:id/apps', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      const admin = isAdmin(req)
      const [col] = await query('SELECT creator_id FROM app_collections WHERE id=?', [Number(req.params.id)])
      if (!col) return res.json({ code: 404, msg: '合集不存在' })
      if (!admin && col.creator_id !== userId) return res.json({ code: 403, msg: '无权限' })
      const { appIds } = req.body
      if (!appIds || !Array.isArray(appIds) || appIds.length === 0) return res.json({ code: 400, msg: '请选择应用' })
      let added = 0
      for (const appId of appIds) {
        try { await query('INSERT IGNORE INTO app_collection_items (collection_id, app_id) VALUES (?,?)', [Number(req.params.id), Number(appId)]); added++ } catch {}
      }
      res.json({ code: 200, msg: `已添加${added}个应用`, data: { count: added } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/appstore/collections/:id/apps/:appId - 移除应用
  router.delete('/api/appstore/collections/:id/apps/:appId', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      const admin = isAdmin(req)
      const [col] = await query('SELECT creator_id FROM app_collections WHERE id=?', [Number(req.params.id)])
      if (!col) return res.json({ code: 404, msg: '合集不存在' })
      if (!admin && col.creator_id !== userId) return res.json({ code: 403, msg: '无权限' })
      await query('DELETE FROM app_collection_items WHERE collection_id=? AND app_id=?', [Number(req.params.id), Number(req.params.appId)])
      res.json({ code: 200, msg: '移除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/appstore/collections/:id/public - 切换公开/私密
  router.put('/api/appstore/collections/:id/public', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      const [col] = await query('SELECT creator_id FROM app_collections WHERE id=?', [Number(req.params.id)])
      if (!col) return res.json({ code: 404, msg: '合集不存在' })
      if (col.creator_id !== userId) return res.json({ code: 403, msg: '无权限' })
      const { isPublic } = req.body
      await query('UPDATE app_collections SET is_public=? WHERE id=?', [isPublic ? 1 : 0, Number(req.params.id)])
      res.json({ code: 200, msg: isPublic ? '已设为公开' : '已设为私密' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/appstore/collections/:id/like - 点赞/取消
  router.post('/api/appstore/collections/:id/like', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const [exists] = await query('SELECT id FROM collection_likes WHERE collection_id=? AND user_id=?', [Number(req.params.id), userId])
      if (exists) {
        await query('DELETE FROM collection_likes WHERE id=?', [exists.id])
        await query('UPDATE app_collections SET likes=GREATEST(likes-1,0) WHERE id=?', [Number(req.params.id)])
        res.json({ code: 200, msg: '已取消点赞', data: { liked: false } })
      } else {
        await query('INSERT INTO collection_likes (collection_id, user_id) VALUES (?,?)', [Number(req.params.id), userId])
        await query('UPDATE app_collections SET likes=likes+1 WHERE id=?', [Number(req.params.id)])
        res.json({ code: 200, msg: '已点赞', data: { liked: true } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/appstore/collections/:id/favorite - 收藏/取消
  router.post('/api/appstore/collections/:id/favorite', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const [exists] = await query('SELECT id FROM collection_favorites WHERE collection_id=? AND user_id=?', [Number(req.params.id), userId])
      if (exists) {
        await query('DELETE FROM collection_favorites WHERE id=?', [exists.id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query('INSERT INTO collection_favorites (collection_id, user_id) VALUES (?,?)', [Number(req.params.id), userId])
        res.json({ code: 200, msg: '已收藏', data: { favorited: true } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/appstore/collections/:id/report - 举报合集
  router.post('/api/appstore/collections/:id/report', authRequired, async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { reason } = req.body
      await query('INSERT INTO collection_reports (collection_id, reporter_id, reason) VALUES (?,?,?)', [Number(req.params.id), userId, reason || ''])
      res.json({ code: 200, msg: '举报成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/review/list - 审核队列(管理员)
  router.get('/api/appstore/collections/review/list', authRequired, async (req, res) => {
    try {
      if (!isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.creator_id as creatorId,
                c.status, c.create_time as createTime, u.username as creatorName,
                COUNT(aci.collection_id) as appCount
         FROM app_collections c
         LEFT JOIN app_collection_items aci ON aci.collection_id = c.id
         LEFT JOIN users u ON u.id = c.creator_id
         WHERE c.status='pending'
         GROUP BY c.id
         ORDER BY c.id ASC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/appstore/collections/:id/review - 审核合集(管理员)
  router.put('/api/appstore/collections/:id/review', authRequired, async (req, res) => {
    try {
      if (!isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { action } = req.body
      const newStatus = action === 'approve' ? 'active' : 'rejected'
      await query('UPDATE app_collections SET status=? WHERE id=?', [newStatus, Number(req.params.id)])
      logFromReq(req, 'review', 'app_collection', req.params.id, `${action === 'approve' ? '通过' : '拒绝'}合集审核`)
      res.json({ code: 200, msg: action === 'approve' ? '已通过' : '已拒绝' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/appstore/collections/:id/pin - 置顶/取消(管理员)
  router.put('/api/appstore/collections/:id/pin', authRequired, async (req, res) => {
    try {
      if (!isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { pinned } = req.body
      await query('UPDATE app_collections SET is_pinned=? WHERE id=?', [pinned ? 1 : 0, Number(req.params.id)])
      res.json({ code: 200, msg: pinned ? '已置顶' : '已取消置顶' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/appstore/collections/:id/featured - 精选/取消(管理员)
  router.put('/api/appstore/collections/:id/featured', authRequired, async (req, res) => {
    try {
      if (!isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { featured } = req.body
      await query('UPDATE app_collections SET is_featured=? WHERE id=?', [featured ? 1 : 0, Number(req.params.id)])
      res.json({ code: 200, msg: featured ? '已设为精选' : '已取消精选' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/app/collections/:appId - 获取包含该应用的合集
  router.get('/api/app/collections/:appId', async (req, res) => {
    try {
      const list = await query(
        `SELECT c.id, c.name, c.description, c.cover_url as coverUrl, c.likes, c.view_count as viewCount,
                COUNT(aci2.collection_id) as appCount
         FROM app_collection_items aci
         JOIN app_collections c ON c.id = aci.collection_id
         LEFT JOIN app_collection_items aci2 ON aci2.collection_id = c.id
         WHERE aci.app_id=? AND c.status='active' AND c.is_public=1
         GROUP BY c.id
         ORDER BY c.likes DESC
         LIMIT 10`, [Number(req.params.appId)]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/collections/favorited - 我收藏的合集
  // ========== 1. 应用版本更新日志 ==========
  router.get('/api/app/:id/changelog', async (req, res) => {
    try {
      const list = await query(
        `SELECT id, app_id as appId, version, version_code as versionCode, size_mb as sizeMb,
                download_url as downloadUrl, update_content as updateContent,
                version_type as versionType, is_current as isCurrent,
                user_id as userId, user_name as userName, create_time as createTime
         FROM app_versions WHERE app_id=? ORDER BY create_time DESC`, [Number(req.params.id)]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 3. 应用套餐/合集管理 ==========

  router.get('/api/appstore/bundles', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      let where = 'WHERE 1=1'; const params = []
      if (status) { where += ' AND b.status=?'; params.push(status) }
      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM app_bundles b ${where}`, params),
        query(
          `SELECT b.*,
            COUNT(bi.bundle_id) as appCount
           FROM app_bundles b
           LEFT JOIN app_bundle_items bi ON bi.bundle_id = b.id
           ${where} GROUP BY b.id ORDER BY b.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])
      res.json({ code: 200, msg: 'success', data: { list: listRows, total: countRows[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/appstore/bundles', authRequired, async (req, res) => {
    try {
      const { name, description, coverUrl, userId, priceBalance, status } = req.body
      if (!name) return res.json({ code: 400, msg: '套餐名称不能为空' })
      const result = await query(
        'INSERT INTO app_bundles (name, description, cover_url, user_id, price_balance, status) VALUES (?,?,?,?,?,?)',
        [name, description || '', coverUrl || '', Number(userId) || 0, Number(priceBalance) || 0, status || 'active']
      )
      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/appstore/bundles/:id', authRequired, async (req, res) => {
    try {
      const { name, description, coverUrl, priceBalance, status } = req.body
      await query(
        'UPDATE app_bundles SET name=?, description=?, cover_url=?, price_balance=?, status=? WHERE id=?',
        [name || '', description || '', coverUrl || '', Number(priceBalance) || 0, status || 'active', Number(req.params.id)]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/appstore/bundles/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM app_bundle_items WHERE bundle_id=?', [Number(req.params.id)])
      await query('DELETE FROM app_bundles WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/appstore/bundles/:id/apps', authRequired, async (req, res) => {
    try {
      const { appIds } = req.body
      if (!appIds || !Array.isArray(appIds) || appIds.length === 0) return res.json({ code: 400, msg: '请选择应用' })
      let maxOrder = await query('SELECT MAX(sort_order) as m FROM app_bundle_items WHERE bundle_id=?', [Number(req.params.id)])
      let sortOrder = (maxOrder[0]?.m || 0)
      let added = 0
      for (const appId of appIds) {
        sortOrder++
        try {
          await query('INSERT IGNORE INTO app_bundle_items (bundle_id, app_id, sort_order) VALUES (?,?,?)',
            [Number(req.params.id), Number(appId), sortOrder])
          added++
        } catch {}
      }
      res.json({ code: 200, msg: `已添加${added}个应用`, data: { count: added } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/appstore/bundles/:id/apps/:appId', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM app_bundle_items WHERE bundle_id=? AND app_id=?',
        [Number(req.params.id), Number(req.params.appId)])
      res.json({ code: 200, msg: '移除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 4. 内测管理 ==========
  router.post('/api/app/:id/beta-users', async (req, res) => {
    try {
      const { userIds } = req.body
      if (!userIds || !Array.isArray(userIds)) return res.json({ code: 400, msg: '缺少用户列表' })
      let added = 0
      for (const uid of userIds) {
        try {
          await query('INSERT IGNORE INTO app_beta_users (app_id, user_id) VALUES (?,?)',
            [Number(req.params.id), Number(uid)])
          added++
        } catch {}
      }
      res.json({ code: 200, msg: `已添加${added}个内测用户`, data: { count: added } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/app/:id/beta', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      const app = await query('SELECT id, version_type FROM app_versions WHERE app_id=? AND is_current=1 LIMIT 1', [appId])
      let isBeta = false
      if (app.length > 0 && app[0].version_type === 'beta') isBeta = true
      let isBetaUser = false
      const userId = Number(req.query.userId || 0)
      if (userId > 0 && isBeta) {
        const b = await query('SELECT id FROM app_beta_users WHERE app_id=? AND user_id=?', [appId, userId])
        isBetaUser = b.length > 0
      }
      const betaUsers = await query(
        'SELECT bu.user_id as userId, u.username, u.nickname, u.avatar FROM app_beta_users bu LEFT JOIN users u ON bu.user_id=u.id WHERE bu.app_id=?',
        [appId]
      )
      res.json({ code: 200, msg: 'success', data: { isBeta, isBetaUser, betaUsers } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 5. 相关应用推荐 ==========
  router.get('/api/app/:id/related', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      const app = await query('SELECT category, categories, tags FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })
      const { category, categories, tags } = app[0]
      let tagArr = []
      try { tagArr = tags ? JSON.parse(tags) : [] } catch { tagArr = [] }
      let catArr = [category]
      try { const c = JSON.parse(categories || '[]'); if (c.length) catArr = c } catch {}

      const tagConditions = tagArr.map(() => 'tags LIKE ?').join(' OR ')
      const catConditions = catArr.map(() => 'category=?').join(' OR ')
      const params = []

      let where = 'WHERE id!=? AND status=\'1\''
      params.push(appId)
      if (tagArr.length > 0) {
        where += ` AND (${tagConditions}`
        for (const t of tagArr) params.push(`%${t}%`)
        if (catArr.length > 0) {
          where += ` OR ${catConditions})`
          for (const c of catArr) params.push(c)
        } else {
          where += `)`
        }
      } else if (catArr.length > 0) {
        where += ` AND (${catConditions})`
        for (const c of catArr) params.push(c)
      }

      const list = await query(
        `SELECT id, name, package_name as packageName, icon, icon_bg_color as iconBgColor,
                version, size_mb as sizeMb, downloads, rating, category, description,
                price_type as priceType, price_amount as priceAmount
         FROM app_store ${where} ORDER BY rating DESC, downloads DESC LIMIT 10`, params
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 6. 申诉管理 ==========
  router.post('/api/appeal/submit', authRequired, async (req, res) => {
    try {
      const { userId } = req.user
      const { targetType, targetId, reason } = req.body
      if (!targetType || !targetId) return res.json({ code: 400, msg: '缺少申诉目标信息' })
      const reasonFull = reason || ''
      const targetInfo = targetType && targetId ? `[${targetType}#${targetId}] ${reasonFull}` : reasonFull
      const userRow = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        'INSERT INTO user_appeals (user_id, username, reason) VALUES (?,?,?)',
        [userId, userRow[0]?.username || '', targetInfo]
      )
      res.json({ code: 200, msg: '申诉已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/admin/appeals', authRequired, async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      let where = 'WHERE 1=1'; const params = []
      if (status) { where += ' AND a.status=?'; params.push(status) }
      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM user_appeals a ${where}`, params),
        query(
          `SELECT a.*, u.username, u.nickname
           FROM user_appeals a LEFT JOIN users u ON a.user_id=u.id
           ${where} ORDER BY a.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])
      res.json({ code: 200, msg: 'success', data: { list: listRows, total: countRows[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/admin/appeals/:id', authRequired, async (req, res) => {
    try {
      const { action, reply } = req.body
      const newStatus = action === 'approve' ? 'approved' : 'rejected'
      await query(
        'UPDATE user_appeals SET status=?, admin_note=?, review_time=NOW() WHERE id=?',
        [newStatus, reply || '', Number(req.params.id)]
      )
      res.json({ code: 200, msg: '处理成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 7. 应用收藏 (简化版toggle+list) ==========
  router.post('/api/appstore/:id/favorite', authRequired, async (req, res) => {
    try {
      const uid = req.user.userId; const appId = Number(req.params.id)
      const existing = await query('SELECT id FROM app_favorites WHERE user_id=? AND app_id=?', [uid, appId])
      if (existing.length > 0) {
        await query('DELETE FROM app_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query('INSERT INTO app_favorites (user_id, app_id, group_id) VALUES (?,?,1)', [uid, appId])
        await progressTasksByAction(uid, '', 'favorite')
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/appstore/favorites', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const list = await query(
        `SELECT f.id, f.app_id as appId, f.create_time as createTime,
                a.name, a.icon, a.icon_bg_color as iconBgColor, a.package_name as packageName,
                a.version, a.downloads, a.rating, a.category
         FROM app_favorites f
         JOIN app_store a ON f.app_id=a.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 8. 开发者数据分析 ==========
  router.get('/api/app/:id/analytics', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      const app = await query('SELECT id, downloads, rating FROM app_store WHERE id=?', [appId])
      if (!app.length) return res.json({ code: 404, msg: '应用不存在' })

      const [stats, dailyDownloads, ratingAvg] = await Promise.all([
        query(
          'SELECT COALESCE(SUM(downloads),0) as total FROM app_daily_stats WHERE app_id=?', [appId]
        ),
        query(
          `SELECT stat_date as date, downloads
           FROM app_daily_stats WHERE app_id=? AND stat_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           ORDER BY stat_date ASC`, [appId]
        ),
        query(
          'SELECT AVG(rating) as avg FROM app_comments WHERE app_id=? AND rating > 0', [appId]
        )
      ])

      res.json({ code: 200, msg: 'success', data: {
        downloadCount: app[0].downloads || 0,
        ratingAvg: Math.round((Number(ratingAvg[0]?.avg) || 0) * 10) / 10,
        dailyDownloads: dailyDownloads.map(d => ({ date: d.date, downloads: d.downloads }))
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/appstore/developer/analytics', async (req, res) => {
    try {
      const userId = getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const apps = await query(
        `SELECT id, name, downloads, rating, coin_count as revenue
         FROM app_store WHERE user_id=? AND status='1'`, [userId]
      )
      const totalApps = apps.length
      const totalDownloads = apps.reduce((s, a) => s + (a.downloads || 0), 0)
      const totalRevenue = apps.reduce((s, a) => s + (a.revenue || 0), 0)

      const recentStats = await query(
        `SELECT stat_date as date, SUM(downloads) as downloads
         FROM app_daily_stats WHERE app_id IN (SELECT id FROM app_store WHERE user_id=? AND status='1')
         AND stat_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
         GROUP BY stat_date ORDER BY stat_date ASC`, [userId]
      )

      const topApps = apps
        .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
        .slice(0, 5)

      res.json({ code: 200, msg: 'success', data: {
        totalApps,
        totalDownloads,
        totalRevenue,
        recentStats: recentStats.map(d => ({ date: d.date, downloads: d.downloads || 0, revenue: 0 })),
        topApps: topApps.map(a => ({ name: a.name, downloads: a.downloads || 0, revenue: a.revenue || 0, rating: a.rating || 0 }))
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/:id/ratings — 评分详情
  router.get('/api/appstore/:id/ratings', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      const filter = req.query.filter || 'all'
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 10

      const app = await query('SELECT name FROM app_store WHERE id=?', [appId])
      if (!app || app.length === 0) return res.json({ code: 404, msg: '应用不存在' })

      let where = 'app_id=? AND parent_id=0'
      const params = [appId]
      if (filter !== 'all') {
        where += ' AND rating=?'
        params.push(Number(filter))
      }

      const offset = (page - 1) * pageSize
      const comments = await query(
        `SELECT c.id, c.user_name as userName, c.rating, c.content, c.device,
                c.version, c.create_time as createTime, c.likes
         FROM app_comments c WHERE ${where}
         ORDER BY c.is_pinned DESC, c.create_time DESC LIMIT ? OFFSET ?`,
        [...params, pageSize, offset]
      )
      const cnt = await query(`SELECT COUNT(*) as total FROM app_comments WHERE ${where}`, params)

      const dist = await query(
        'SELECT rating, COUNT(*) as cnt FROM app_comments WHERE app_id=? AND parent_id=0 AND rating > 0 GROUP BY rating',
        [appId]
      )
      const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
      let totalRated = 0
      let sumRating = 0
      for (const d of dist) {
        const star = Number(d.rating)
        if (star >= 1 && star <= 5) {
          distribution[star] = Number(d.cnt)
          totalRated += Number(d.cnt)
          sumRating += star * Number(d.cnt)
        }
      }
      const avgRating = totalRated > 0 ? Math.round(sumRating / totalRated * 10) / 10 : 0
      const fiveStarPercent = totalRated > 0 ? Math.round((distribution[5] / totalRated) * 100) : 0
      const goodRate = totalRated > 0 ? Math.round(((distribution[4] + distribution[5]) / totalRated) * 100) : 0

      const trend = await query(
        `SELECT DATE(create_time) as date, AVG(rating) as avgRating
         FROM app_comments WHERE app_id=? AND rating > 0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
         GROUP BY DATE(create_time) ORDER BY date ASC`,
        [appId]
      )

      res.json({
        code: 200, msg: 'success', data: {
          appName: app[0].name,
          comments,
          total: cnt[0]?.total || 0,
          stats: { total: totalRated, average: avgRating, fiveStarPercent, goodRate, distribution },
          trend
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/analytics/funnel — 漏斗分析
  router.get('/api/analytics/funnel', async (req, res) => {
    try {
      const funnelName = req.query.funnelName || 'register'
      const startDate = req.query.startDate || '2024-01-01'
      const endDate = req.query.endDate || new Date().toISOString().substring(0, 10)

      let funnelData = []
      let trendData = []

      if (funnelName === 'register') {
        const totalVisits = await query(
          `SELECT COUNT(*) as cnt FROM browse_history WHERE create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const registered = await query(
          `SELECT COUNT(*) as cnt FROM users WHERE create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const verified = await query(
          `SELECT COUNT(DISTINCT e.user_id) as cnt FROM currency_transactions e JOIN users u ON e.user_id=u.id
           WHERE u.create_time >= ? AND u.create_time < DATE_ADD(?, INTERVAL 1 DAY) AND e.currency_key='experience' AND e.amount >= 50`,
          [startDate, endDate]
        )
        const active = await query(
          `SELECT COUNT(DISTINCT user_id) as cnt FROM checkin_records
           WHERE checkin_date >= ? AND checkin_date <= ?`,
          [startDate, endDate]
        )
        const visitCount = Number(totalVisits[0]?.cnt || 0)
        const regCount = Number(registered[0]?.cnt || 0)
        const verCount = Number(verified[0]?.cnt || 0)
        const actCount = Number(active[0]?.cnt || 0)
        funnelData = [
          { name: '访问', count: visitCount, rate: 100, stepRate: 100 },
          { name: '注册', count: regCount, rate: visitCount > 0 ? Math.round(regCount / visitCount * 100) : 0, stepRate: visitCount > 0 ? Math.round(regCount / visitCount * 100) : 0 },
          { name: '活跃', count: verCount, rate: regCount > 0 ? Math.round(verCount / visitCount * 100) : 0, stepRate: regCount > 0 ? Math.round(verCount / regCount * 100) : 0 },
          { name: '签到', count: actCount, rate: regCount > 0 ? Math.round(actCount / visitCount * 100) : 0, stepRate: verCount > 0 ? Math.round(actCount / verCount * 100) : 0 }
        ]
      } else if (funnelName === 'download') {
        const browseApps = await query(
          `SELECT COUNT(DISTINCT app_id) as cnt FROM browse_history WHERE target_type='app' AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const viewDetails = await query(
          `SELECT COUNT(DISTINCT app_id) as cnt FROM browse_history WHERE target_type='app_detail' AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const downloads = await query(
          `SELECT COUNT(*) as cnt FROM app_purchases WHERE create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const rated = await query(
          `SELECT COUNT(DISTINCT app_id) as cnt FROM app_comments WHERE rating > 0 AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const b1 = Number(browseApps[0]?.cnt || 0)
        const b2 = Number(viewDetails[0]?.cnt || 0)
        const b3 = Number(downloads[0]?.cnt || 0)
        const b4 = Number(rated[0]?.cnt || 0)
        funnelData = [
          { name: '浏览', count: b1, rate: 100, stepRate: 100 },
          { name: '查看详情', count: b2, rate: b1 > 0 ? Math.round(b2 / b1 * 100) : 0, stepRate: b1 > 0 ? Math.round(b2 / b1 * 100) : 0 },
          { name: '下载', count: b3, rate: b1 > 0 ? Math.round(b3 / b1 * 100) : 0, stepRate: b2 > 0 ? Math.round(b3 / b2 * 100) : 0 },
          { name: '评分', count: b4, rate: b1 > 0 ? Math.round(b4 / b1 * 100) : 0, stepRate: b3 > 0 ? Math.round(b4 / b3 * 100) : 0 }
        ]
      } else if (funnelName === 'recharge') {
        const visitors = await query('SELECT COUNT(*) as cnt FROM users WHERE create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const addedPayment = await query('SELECT COUNT(*) as cnt FROM recharge_orders WHERE status=\'completed\' AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const recharged = await query('SELECT COUNT(DISTINCT user_id) as cnt FROM recharge_orders WHERE status=\'completed\' AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const repeatedRecharge = await query(
          `SELECT COUNT(DISTINCT user_id) as cnt FROM recharge_orders WHERE status='completed' AND user_id IN
           (SELECT DISTINCT user_id FROM recharge_orders WHERE status='completed' GROUP BY user_id HAVING COUNT(*) >= 2)
           AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const v1 = Number(visitors[0]?.cnt || 0)
        const v2 = Number(addedPayment[0]?.cnt || 0)
        const v3 = Number(recharged[0]?.cnt || 0)
        const v4 = Number(repeatedRecharge[0]?.cnt || 0)
        funnelData = [
          { name: '新用户', count: v1, rate: 100, stepRate: 100 },
          { name: '添加支付', count: v2, rate: v1 > 0 ? Math.round(v2 / v1 * 100) : 0, stepRate: v1 > 0 ? Math.round(v2 / v1 * 100) : 0 },
          { name: '首次充值', count: v3, rate: v1 > 0 ? Math.round(v3 / v1 * 100) : 0, stepRate: v2 > 0 ? Math.round(v3 / v2 * 100) : 0 },
          { name: '重复充值', count: v4, rate: v1 > 0 ? Math.round(v4 / v1 * 100) : 0, stepRate: v3 > 0 ? Math.round(v4 / v3 * 100) : 0 }
        ]
      } else if (funnelName === 'invite') {
        const withInviteCode = await query('SELECT COUNT(*) as cnt FROM users WHERE invite_code IS NOT NULL AND invite_code!=\'\' AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const shared = await query('SELECT COUNT(*) as cnt FROM invite_codes WHERE used=1 AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const invited = await query('SELECT COUNT(*) as cnt FROM users WHERE invited_by > 0 AND create_time >= ? AND create_time < DATE_ADD(?, INTERVAL 1 DAY)', [startDate, endDate])
        const invitedActive = await query(
          `SELECT COUNT(DISTINCT u.id) as cnt FROM users u
           JOIN checkin_records c ON u.id=c.user_id WHERE u.invited_by > 0 AND u.create_time >= ? AND u.create_time < DATE_ADD(?, INTERVAL 1 DAY)`,
          [startDate, endDate]
        )
        const f1 = Number(withInviteCode[0]?.cnt || 0)
        const f2 = Number(shared[0]?.cnt || 0)
        const f3 = Number(invited[0]?.cnt || 0)
        const f4 = Number(invitedActive[0]?.cnt || 0)
        funnelData = [
          { name: '获取邀请码', count: f1, rate: 100, stepRate: 100 },
          { name: '分享邀请', count: f2, rate: f1 > 0 ? Math.round(f2 / f1 * 100) : 0, stepRate: f1 > 0 ? Math.round(f2 / f1 * 100) : 0 },
          { name: '受邀注册', count: f3, rate: f1 > 0 ? Math.round(f3 / f1 * 100) : 0, stepRate: f2 > 0 ? Math.round(f3 / f2 * 100) : 0 },
          { name: '受邀活跃', count: f4, rate: f1 > 0 ? Math.round(f4 / f1 * 100) : 0, stepRate: f3 > 0 ? Math.round(f4 / f3 * 100) : 0 }
        ]
      }

      res.json({
        code: 200, msg: 'success', data: { funnel: funnelData, trend: trendData }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/appstore/dev/analytics/:id — 单个应用开发者分析
  router.get('/api/appstore/dev/analytics/:id', async (req, res) => {
    try {
      const appId = Number(req.params.id)
      const app = await query('SELECT id, name, downloads, rating FROM app_store WHERE id=?', [appId])
      if (!app || app.length === 0) return res.json({ code: 404, msg: '应用不存在' })

      const [dailyStats, ratingTrend, incomeTrend, totalTips, totalComments, avgRating] = await Promise.all([
        query(
          `SELECT stat_date as date, downloads
           FROM app_daily_stats WHERE app_id=? AND stat_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           ORDER BY stat_date ASC`, [appId]
        ),
        query(
          `SELECT DATE(create_time) as date, AVG(rating) as rating
           FROM app_comments WHERE app_id=? AND rating > 0 AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           GROUP BY DATE(create_time) ORDER BY date ASC`, [appId]
        ),
        query(
          `SELECT DATE(create_time) as date, SUM(amount) as amount
           FROM app_tips WHERE app_id=? AND create_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
           GROUP BY DATE(create_time) ORDER BY date ASC`, [appId]
        ),
        query('SELECT COALESCE(SUM(amount), 0) as total FROM app_tips WHERE app_id=?', [appId]),
        query('SELECT COUNT(*) as cnt FROM app_comments WHERE app_id=? AND parent_id=0', [appId]),
        query('SELECT AVG(rating) as avg FROM app_comments WHERE app_id=? AND rating > 0', [appId])
      ])

      res.json({
        code: 200, msg: 'success', data: {
          summary: {
            totalDownloads: app[0].downloads || 0,
            avgRating: Math.round((Number(avgRating[0]?.avg) || 0) * 10) / 10,
            totalTips: Number(totalTips[0]?.total || 0).toFixed(2),
            totalComments: totalComments[0]?.cnt || 0
          },
          dailyStats: dailyStats.map(d => ({ date: new Date(d.date).toISOString().substring(0, 10), downloads: d.downloads || 0 })),
          ratings: ratingTrend.map(r => ({ date: new Date(r.date).toISOString().substring(0, 10), rating: Math.round(Number(r.rating) * 10) / 10 })),
          income: incomeTrend.map(i => ({ date: new Date(i.date).toISOString().substring(0, 10), amount: Number(i.amount || 0) }))
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = appStoreRoutes
