const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('./system.cjs')

module.exports = function appealsRoutes(app) {

  // ==================== 提交申诉 ====================

  app.post('/api/appeals', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const userName = req.user.userName
      const { reason, banUntil } = req.body

      if (!reason) {
        return res.json({ code: 400, msg: '请填写申诉原因' })
      }

      await query(
        `INSERT INTO user_appeals (user_id, username, reason, ban_until, status, create_time)
         VALUES (?, ?, ?, ?, 'pending', NOW())`,
        [userId, userName, reason, banUntil || null]
      )

      res.json({ code: 200, msg: '申诉已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 获取当前用户申诉列表 ====================

  app.get('/api/appeals', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { page = 1, pageSize = 20 } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)

      const [list, cnt] = await Promise.all([
        query(
          `SELECT id, reason, ban_until AS banUntil, status, admin_note AS adminNote,
                  create_time AS createTime, review_time AS reviewTime
           FROM user_appeals
           WHERE user_id = ?
           ORDER BY create_time DESC
           LIMIT ? OFFSET ?`,
          [userId, Number(pageSize), offset]
        ),
        query('SELECT COUNT(*) AS total FROM user_appeals WHERE user_id = ?', [userId])
      ])

      res.json({
        code: 200,
        data: { list, total: cnt[0].total }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 管理员: 获取所有申诉列表 ====================

  app.get('/api/appeals/admin', authRequired, requirePermission('appeals'), async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      const params = []

      let whereClause = ''
      if (status) {
        whereClause = 'WHERE a.status = ?'
        params.push(status)
      }

      const [list, cnt] = await Promise.all([
        query(
          `SELECT a.id, a.user_id AS userId, a.username, a.reason, a.ban_until AS banUntil,
                  a.status, a.admin_id AS adminId, a.admin_note AS adminNote,
                  a.create_time AS createTime, a.review_time AS reviewTime,
                  u.nickname, u.avatar
           FROM user_appeals a
           LEFT JOIN users u ON a.user_id = u.id
           ${whereClause}
           ORDER BY a.create_time DESC
           LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), offset]
        ),
        query(`SELECT COUNT(*) AS total FROM user_appeals a ${whereClause}`, params)
      ])

      res.json({
        code: 200,
        data: { list, total: cnt[0].total }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 管理员: 审核申诉 ====================

  app.post('/api/appeals/:id/review', authRequired, requirePermission('appeals'), async (req, res) => {
    try {
      const adminId = req.user.userId
      const { id } = req.params
      const { status, adminNote } = req.body

      if (!status || !['approved', 'rejected'].includes(status)) {
        return res.json({ code: 400, msg: '请提供正确的审核状态 (approved/rejected)' })
      }

      const existing = await query('SELECT id FROM user_appeals WHERE id = ?', [Number(id)])
      if (!existing.length) {
        return res.json({ code: 404, msg: '申诉不存在' })
      }

      await query(
        `UPDATE user_appeals
         SET status = ?, admin_id = ?, admin_note = ?, review_time = NOW()
         WHERE id = ?`,
        [status, adminId, adminNote || '', Number(id)]
      )

      res.json({ code: 200, msg: '审核完成' })
    } catch (e) {
      res.serverError(e)
    }
  })

}
