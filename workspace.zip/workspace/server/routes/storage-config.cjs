const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const path = require('path')
const fs = require('fs')
const { encryptStorageConfig } = require('../utils/crypto.cjs')
const { decryptStorageConfig, decryptStorageConfigs, sanitizeConfigForLog, sanitizeConfigForResponse } = require('../utils/storage-decrypt.cjs')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

const STORAGE_TYPES = [
  { value: 'local', label: '本地存储' },
  { value: 'cos', label: '腾讯云COS' },
  { value: 'oss', label: '阿里云OSS' },
  { value: 'minio', label: 'MinIO' },
  { value: 's3', label: 'AWS S3' },
  { value: 'qiniu', label: '七牛云Kodo' },
  { value: 'huawei', label: '华为云OBS' }
]

function getStorageClient(config) {
  if (config.type === 'cos') {
    const COS = require('cos-nodejs-sdk-v5')
    return new COS({
      SecretId: config.access_key,
      SecretKey: config.secret_key
    })
  }
  if (config.type === 'oss') {
    const OSS = require('ali-oss')
    return new OSS({
      region: config.region,
      accessKeyId: config.access_key,
      accessKeySecret: config.secret_key,
      bucket: config.bucket,
      endpoint: config.endpoint
    })
  }
  return null
}

async function uploadToCloud(config, localFilePath, remoteKey) {
  if (!config || config.type === 'local') return null

  try {
    if (config.type === 'cos') {
      const COS = require('cos-nodejs-sdk-v5')
      const cos = new COS({ SecretId: config.access_key, SecretKey: config.secret_key })
      return new Promise((resolve, reject) => {
        const fileStream = fs.createReadStream(localFilePath)
        cos.putObject({
          Bucket: config.bucket,
          Region: config.region,
          Key: remoteKey,
          Body: fileStream,
          ContentLength: fs.statSync(localFilePath).size
        }, (err, data) => {
          if (err) return reject(err)
          const url = config.base_url
            ? `${config.base_url.replace(/\/$/, '')}/${remoteKey}`
            : `https://${config.bucket}.cos.${config.region}.myqcloud.com/${remoteKey}`
          resolve({ url, key: remoteKey })
        })
      })
    }

    if (config.type === 'oss') {
      const OSS = require('ali-oss')
      const client = new OSS({
        region: config.region,
        accessKeyId: config.access_key,
        accessKeySecret: config.secret_key,
        bucket: config.bucket,
        endpoint: config.endpoint
      })
      const result = await client.put(remoteKey, localFilePath)
      const url = config.base_url
        ? `${config.base_url.replace(/\/$/, '')}/${remoteKey}`
        : result.url
      return { url, key: remoteKey }
    }

    if (config.type === 'minio') {
      const Minio = require('minio')
      const minioClient = new Minio.Client({
        endPoint: config.endpoint.replace(/^https?:\/\//, '').split(':')[0],
        port: parseInt(config.endpoint.split(':').pop()) || 9000,
        useSSL: config.endpoint.startsWith('https'),
        accessKey: config.access_key,
        secretKey: config.secret_key
      })
      const fileStream = fs.createReadStream(localFilePath)
      const stat = fs.statSync(localFilePath)
      await minioClient.putObject(config.bucket, remoteKey, fileStream, stat.size)
      const url = config.base_url
        ? `${config.base_url.replace(/\/$/, '')}/${remoteKey}`
        : `${config.endpoint}/${config.bucket}/${remoteKey}`
      return { url, key: remoteKey }
    }

    // S3-compatible generic upload
    const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3')
    const s3 = new S3Client({
      region: config.region,
      endpoint: config.endpoint,
      credentials: {
        accessKeyId: config.access_key,
        secretAccessKey: config.secret_key
      },
      forcePathStyle: true
    })
    const fileStream = fs.createReadStream(localFilePath)
    await s3.send(new PutObjectCommand({
      Bucket: config.bucket,
      Key: remoteKey,
      Body: fileStream,
      ContentLength: fs.statSync(localFilePath).size
    }))
    const url = config.base_url
      ? `${config.base_url.replace(/\/$/, '')}/${remoteKey}`
      : `${config.endpoint}/${config.bucket}/${remoteKey}`
    return { url, key: remoteKey }
  } catch (e) {
    console.error(`[Storage] 上传到 ${config.type} 失败:`, e.message)
    return null
  }
}

module.exports = function storageConfigRoutes(app) {
  app.get('/api/storage-config/types', authRequired, async (req, res) => {
    try {
      res.json({ code: 200, data: STORAGE_TYPES })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/storage-config/audiences', authRequired, async (req, res) => {
    try {
      const roles = await query("SELECT role_name as label, role_code as value FROM roles WHERE enabled=1 ORDER BY id")
      const levels = await query("SELECT name as label, CAST(level AS CHAR) as value FROM membership_levels WHERE status='1' AND name!='' ORDER BY level")
      res.json({ code: 200, data: { roles, levels } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/storage-config/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM storage_configs ORDER BY is_default DESC, id')
      res.json({ code: 200, data: decryptStorageConfigs(rows) })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/storage-config/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM storage_configs WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, message: '配置不存在' })
      res.json({ code: 200, data: decryptStorageConfig(rows[0]) })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/storage-config', authRequired, requirePermission('add'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { name, type, endpoint, region, bucket, access_key, secret_key, local_dir, remote_dir, expiry_seconds, base_url, is_default, status, applicable_roles, applicable_levels } = req.body
      if (!name || !type) return res.json({ code: 400, message: '名称和类型不能为空' })

      const encrypted = encryptStorageConfig({ access_key: access_key || '', secret_key: secret_key || '' })

      if (is_default) {
        await query('UPDATE storage_configs SET is_default=0')
      }

      await query(
        `INSERT INTO storage_configs (name, type, endpoint, region, bucket, access_key, secret_key, local_dir, remote_dir, expiry_seconds, base_url, is_default, status, applicable_roles, applicable_levels) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [name, type, endpoint || '', region || '', bucket || '', encrypted.access_key, encrypted.secret_key, local_dir || '', remote_dir || '', expiry_seconds || 0, base_url || '', is_default ? 1 : 0, status || '1', applicable_roles || '', applicable_levels || '']
      )
      res.json({ code: 200, message: '创建成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.put('/api/storage-config/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { name, type, endpoint, region, bucket, access_key, secret_key, local_dir, remote_dir, expiry_seconds, base_url, is_default, status, applicable_roles, applicable_levels } = req.body

      if (is_default) {
        await query('UPDATE storage_configs SET is_default=0')
      }

      const encrypted = encryptStorageConfig({ access_key: access_key || '', secret_key: secret_key || '' })

      const updates = []
      const params = []
      for (const [k, v] of Object.entries({ name, type, endpoint, region, bucket, access_key: encrypted.access_key, secret_key: encrypted.secret_key, local_dir, remote_dir, expiry_seconds, base_url, status, applicable_roles, applicable_levels })) {
        if (v !== undefined) { updates.push(`${k}=?`); params.push(v ?? '') }
      }
      updates.push(`is_default=?`); params.push(is_default ? 1 : 0)
      updates.push(`update_time=NOW()`)
      params.push(req.params.id)

      await query(`UPDATE storage_configs SET ${updates.join(',')} WHERE id=?`, params)
      res.json({ code: 200, message: '更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/storage-config/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM storage_configs WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.put('/api/storage-config/:id/default', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('UPDATE storage_configs SET is_default=0')
      await query('UPDATE storage_configs SET is_default=1 WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '设为默认成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/storage-config/test', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { id } = req.body
      const rows = id
        ? await query('SELECT * FROM storage_configs WHERE id=?', [id])
        : await query("SELECT * FROM storage_configs WHERE is_default=1 AND status='1'")

      if (!rows.length) return res.json({ code: 400, message: '未找到存储配置' })
      const cfg = decryptStorageConfig(rows[0])

      if (cfg.type === 'local') {
        const dir = path.resolve(__dirname, '..', cfg.local_dir || 'uploads')
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
        return res.json({ code: 200, message: `本地目录 ${cfg.local_dir} 可用`, data: { dir } })
      }

      const client = getStorageClient(cfg)
      if (!client && cfg.type !== 'local') {
        return res.json({ code: 400, message: `存储类型 ${cfg.type} 暂不支持` })
      }

      if (cfg.type === 'cos') {
        return new Promise((resolve) => {
          client.headBucket({ Bucket: cfg.bucket, Region: cfg.region }, (err) => {
            if (err) return resolve(res.json({ code: 500, message: '连接失败: ' + err.message }))
            resolve(res.json({ code: 200, message: 'COS 连接成功', data: { bucket: cfg.bucket, region: cfg.region } }))
          })
        })
      }
      if (cfg.type === 'oss') {
        try {
          await client.list({ 'max-keys': 1 })
          res.json({ code: 200, message: 'OSS 连接成功', data: { bucket: cfg.bucket, region: cfg.region } })
        } catch (e) {
          res.json({ code: 500, message: '连接失败: ' + (e.message || String(e)) })
        }
      } else {
        res.json({ code: 200, message: '配置有效' })
      }
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/storage-config/default', async (req, res) => {
    try {
      const rows = await query("SELECT * FROM storage_configs WHERE is_default=1 AND status='1'")
      if (!rows.length) return res.json({ code: 200, data: null })
      const isAdminUser = await isAdmin(req)
      res.json({ code: 200, data: isAdminUser ? decryptStorageConfig(rows[0]) : sanitizeConfigForResponse(rows[0]) })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 浏览云存储文件列表
  app.get('/api/storage-config/:id/browse', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM storage_configs WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, message: '配置不存在' })
      const cfg = decryptStorageConfig(rows[0])
      if (cfg.type === 'local') return res.json({ code: 400, message: '本地存储请使用文件仓库功能' })

      const prefix = (req.query.prefix || cfg.remote_dir || '').replace(/^\//, '')
      const marker = req.query.marker || ''
      const pageSize = Math.min(100, Math.max(5, parseInt(req.query.pageSize) || 20))
      const sortBy = req.query.sortBy || 'name'
      const sortOrder = req.query.sortOrder || 'asc'

      if (cfg.type === 'cos') {
        const COS = require('cos-nodejs-sdk-v5')
        const cos = new COS({ SecretId: cfg.access_key, SecretKey: cfg.secret_key })
        cos.getBucket({
          Bucket: cfg.bucket,
          Region: cfg.region,
          Prefix: prefix || undefined,
          Delimiter: '',
          MaxKeys: pageSize,
          Marker: marker || undefined
        }, (err, data) => {
          if (err) return res.json({ code: 500, message: 'COS 列表失败: ' + err.message })
          const files = (data.Contents || []).filter(f => f.Key !== prefix).map(f => {
            const safeKey = f.Key
            const url = cfg.base_url
              ? `${cfg.base_url.replace(/\/$/, '')}/${safeKey.split('/').map(encodeURIComponent).join('/')}`
              : `https://${cfg.bucket}.cos.${cfg.region}.myqcloud.com/${safeKey.split('/').map(encodeURIComponent).join('/')}`
            return {
              key: safeKey,
              name: safeKey.split('/').pop(),
              size: f.Size || 0,
              mtime: f.LastModified,
              url,
              etag: (f.ETag || '').replace(/"/g, '')
            }
          })
          sortFiles(files, sortBy, sortOrder)
          res.json({
            code: 200,
            data: {
              files,
              nextMarker: data.NextMarker || (data.IsTruncated ? (files[files.length - 1]?.key || '') : ''),
              isTruncated: data.IsTruncated || false,
              maxKeys: data.MaxKeys || pageSize
            }
          })
        })
        return
      }

      if (cfg.type === 'oss') {
        const OSS = require('ali-oss')
        const client = new OSS({
          region: cfg.region,
          accessKeyId: cfg.access_key,
          accessKeySecret: cfg.secret_key,
          bucket: cfg.bucket,
          endpoint: cfg.endpoint
        })
        const result = await client.list({
          prefix: prefix || undefined,
          delimiter: '',
          'max-keys': pageSize,
          marker: marker || undefined
        })
        const files = (result.objects || []).filter(f => f.name !== prefix).map(f => {
          const safeKey = f.name
          const url = f.url || (cfg.base_url
            ? `${cfg.base_url.replace(/\/$/, '')}/${safeKey.split('/').map(encodeURIComponent).join('/')}`
            : `https://${cfg.bucket}.${cfg.region}.aliyuncs.com/${safeKey.split('/').map(encodeURIComponent).join('/')}`)
          return {
            key: safeKey,
            name: safeKey.split('/').pop(),
            size: f.size || 0,
            mtime: f.lastModified,
            url,
            etag: f.etag || ''
          }
        })
        sortFiles(files, sortBy, sortOrder)
        return res.json({
          code: 200,
          data: {
            files,
            nextMarker: result.nextMarker || '',
            isTruncated: result.isTruncated || false
          }
        })
      }

      res.json({ code: 400, message: `存储类型 ${cfg.type} 暂不支持文件浏览` })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 删除云存储文件
  app.delete('/api/storage-config/:id/file', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT * FROM storage_configs WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, message: '配置不存在' })
      const cfg = decryptStorageConfig(rows[0])
      const key = req.query.key || ''
      if (!key) return res.json({ code: 400, message: '请提供文件 key' })

      if (cfg.type === 'cos') {
        const COS = require('cos-nodejs-sdk-v5')
        const cos = new COS({ SecretId: cfg.access_key, SecretKey: cfg.secret_key })
        cos.deleteObject({ Bucket: cfg.bucket, Region: cfg.region, Key: key }, (err) => {
          if (err) return res.json({ code: 500, message: 'COS 删除失败: ' + err.message })
          res.json({ code: 200, message: '删除成功' })
        })
        return
      }

      if (cfg.type === 'oss') {
        const OSS = require('ali-oss')
        const client = new OSS({
          region: cfg.region, accessKeyId: cfg.access_key,
          accessKeySecret: cfg.secret_key, bucket: cfg.bucket, endpoint: cfg.endpoint
        })
        await client.delete(key)
        return res.json({ code: 200, message: '删除成功' })
      }

      res.json({ code: 400, message: `存储类型 ${cfg.type} 暂不支持删除` })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/storage/sign-url', async (req, res) => {
    try {
      const { url, configId } = req.query
      if (!url) return res.json({ code: 400, message: '缺少文件URL' })

      const ext = String(url).split('.').pop()?.toLowerCase() || ''
      const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico']
      if (imageExts.includes(ext)) return res.json({ code: 200, data: { url: url, signed: false } })

      let cfg
      if (configId) {
        const rows = await query('SELECT * FROM storage_configs WHERE id=? AND status=\'1\'', [Number(configId)])
        cfg = rows[0] ? decryptStorageConfig(rows[0]) : null
      } else {
        const rows = await query("SELECT * FROM storage_configs WHERE status='1' ORDER BY is_default DESC, id LIMIT 1")
        cfg = rows[0] ? decryptStorageConfig(rows[0]) : null
      }
      if (!cfg || cfg.type === 'local') return res.json({ code: 200, data: { url: url, signed: false } })

      const expiry = cfg.expiry_seconds || 0
      if (expiry <= 0) return res.json({ code: 200, data: { url: url, signed: false } })

      let key = String(url)
      if (cfg.base_url) {
        const base = cfg.base_url.replace(/\/+$/, '')
        if (key.startsWith(base + '/')) key = key.substring(base.length + 1)
        else if (key.startsWith(base)) key = key.substring(base.length)
      } else {
        try { key = new URL(url).pathname.replace(/^\//, '') } catch {}
      }

      if (cfg.type === 'oss') {
        const OSS = require('ali-oss')
        const client = new OSS({
          region: cfg.region, accessKeyId: cfg.access_key,
          accessKeySecret: cfg.secret_key, bucket: cfg.bucket, endpoint: cfg.endpoint
        })
        const signedUrl = client.signatureUrl(key, { expires: expiry })
        return res.json({ code: 200, data: { url: signedUrl, signed: true } })
      }

      if (cfg.type === 'cos') {
        const COS = require('cos-nodejs-sdk-v5')
        const cos = new COS({ SecretId: cfg.access_key, SecretKey: cfg.secret_key })
        const signedUrl = cos.getObjectUrl({
          Bucket: cfg.bucket, Region: cfg.region, Key: key,
          Sign: true, Expires: expiry
        })
        return res.json({ code: 200, data: { url: signedUrl, signed: true } })
      }

      if (cfg.type === 'minio') {
        try {
          const Minio = require('minio')
          const parts = String(cfg.endpoint).replace(/^https?:\/\//, '').split(':')
          const minioClient = new Minio.Client({
            endPoint: parts[0],
            port: parseInt(parts[1]) || (cfg.endpoint.startsWith('https') ? 443 : 9000),
            useSSL: String(cfg.endpoint).startsWith('https'),
            accessKey: cfg.access_key,
            secretKey: cfg.secret_key
          })
          const signedUrl = await minioClient.presignedGetObject(cfg.bucket, key, expiry)
          return res.json({ code: 200, data: { url: signedUrl, signed: true } })
        } catch {}
      }

      res.json({ code: 200, data: { url: url, signed: false } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}

function sortFiles(files, sortBy, sortOrder) {
  const mul = sortOrder === 'desc' ? -1 : 1
  if (sortBy === 'size') files.sort((a, b) => (a.size - b.size) * mul)
  else if (sortBy === 'time') files.sort((a, b) => (new Date(a.mtime).getTime() - new Date(b.mtime).getTime()) * mul)
  else files.sort((a, b) => a.name.localeCompare(b.name) * mul)
}

module.exports.uploadToCloud = uploadToCloud
module.exports.getDefaultStorage = async (userCtx) => {
  const configs = decryptStorageConfigs(await query("SELECT * FROM storage_configs WHERE status='1' ORDER BY is_default DESC, id"))
  if (!configs.length) return null
  if (!userCtx) return configs[0]

  const { roles = [], levelId, backend } = userCtx
  const isAdmin = roles.includes('R_SUPER') || roles.includes('R_ADMIN')

  if (backend && isAdmin) {
    const backendCfg = configs.find(c => c.applicable_levels === 'backend')
    if (backendCfg) return backendCfg
    return configs[0]
  }

  for (const cfg of configs) {
    if (cfg.applicable_levels === 'backend') continue

    const cfgRoles = (cfg.applicable_roles || '').split(',').map(s => s.trim()).filter(Boolean)
    const cfgLevels = (cfg.applicable_levels || '').split(',').map(s => s.trim()).filter(Boolean)

    const rolesMatch = cfgRoles.length === 0 || cfgRoles.includes('all') || cfgRoles.some(r => roles.includes(r))
    const levelsMatch = cfgLevels.length === 0 || cfgLevels.includes('all') || (levelId !== undefined && cfgLevels.includes(String(levelId)))

    if (rolesMatch && levelsMatch) return cfg
  }

  return configs[0]
}
