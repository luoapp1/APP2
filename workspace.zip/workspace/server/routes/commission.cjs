const crypto = require('crypto')
const { query } = require('../database.cjs')
const { addBalance, addPoints, deductBalance, deductPoints, addExperience, earnCurrency } = require('./account-utils.cjs')
const { sessions, SESSION_TTL, authRequired } = require('./system.cjs')
const { hasPermission, getPermissionValue } = require('../middleware/level-permissions.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

function genCode() { return crypto.randomBytes(8).toString('hex') }

function safeJsonParse(str) {
  if (!str || typeof str === 'object') return str
  try { return JSON.parse(str) } catch { return {} }
}

// 计算返佣（模块级函数，供其他路由调用）
async function calcCommission(orderId, orderType, orderAmount, userId, paymentMethod = 'balance') {
  try {
    const userRows = await query('SELECT id, referrer_id, referrer_code, username FROM users WHERE id=?', [userId])
    if (!userRows.length || !userRows[0].referrer_id) return

    const referrerId = userRows[0].referrer_id
    const referrerRows = await query('SELECT username FROM users WHERE id=?', [referrerId])
    const referrerName = referrerRows.length > 0 ? referrerRows[0].username : ''
    const referrerCode = userRows[0].referrer_code || ''

    let inviteCodeId = 0
    let inviteCodeType = ''
    if (referrerCode) {
      const codeRows = await query('SELECT id, type FROM invite_codes WHERE code=?', [referrerCode])
      if (codeRows.length) {
        inviteCodeId = codeRows[0].id
        inviteCodeType = codeRows[0].type || ''
      }
      // 也查 user_codes
      if (!inviteCodeId) {
        const ucRows = await query('SELECT id FROM user_codes WHERE code=?', [referrerCode])
        if (ucRows.length) {
          inviteCodeId = ucRows[0].id
          inviteCodeType = 'user'
        }
      }
    }

    const levelRow = await query('SELECT level_id FROM users WHERE id=?', [referrerId])
    const levelId = levelRow.length > 0 ? levelRow[0].level_id : 0

    const [r1, r2, r3, r4, r5] = await Promise.all([
      inviteCodeId
        ? query('SELECT * FROM commission_rules WHERE status=? AND invite_code_id=? AND (order_type=? OR order_type=?)', ['1', inviteCodeId, orderType, 'all'])
        : Promise.resolve([]),
      inviteCodeType
        ? query("SELECT * FROM commission_rules WHERE status=? AND invite_code_type=? AND invite_code_id=0 AND (order_type=? OR order_type=?)", ['1', inviteCodeType, orderType, 'all'])
        : Promise.resolve([]),
      query("SELECT * FROM commission_rules WHERE status=? AND user_id=? AND invite_code_id=0 AND invite_code_type='' AND (order_type=? OR order_type=?)", ['1', referrerId, orderType, 'all']),
      levelId
        ? query("SELECT * FROM commission_rules WHERE status=? AND user_level_id=? AND invite_code_id=0 AND invite_code_type='' AND (order_type=? OR order_type=?)", ['1', levelId, orderType, 'all'])
        : Promise.resolve([]),
      query("SELECT * FROM commission_rules WHERE status=? AND user_level_id=0 AND user_id=0 AND invite_code_id=0 AND invite_code_type='' AND (order_type=? OR order_type=?)", ['1', orderType, 'all'])
    ])

    let matchedRule = null
    for (const rules of [r1, r2, r3, r4, r5]) {
      for (const r of rules) {
        const rc = safeJsonParse(r.rate_config) || {}
        const hasDyn = Object.keys(rc).length > 0
        if (hasDyn) { matchedRule = r; break }
        const rRate = Number(r.rate) || 0 || Number(r.points_rate) || 0
        if (rRate > 0) { matchedRule = r; break }
      }
      if (matchedRule) break
    }

    if (matchedRule) {
      const rule = matchedRule
      const rateConfig = safeJsonParse(rule.rate_config) || {}
      const hasDynamicRates = Object.keys(rateConfig).length > 0

      if (!hasDynamicRates) {
        // 旧模式：只有单一 rate/paymentMethod
        const useRate = paymentMethod === 'points' ? Number(rule.points_rate) : Number(rule.rate)
        const currencyKey = paymentMethod === 'points' ? 'points' : 'balance'
        const amount = Number((orderAmount * useRate / 100).toFixed(2))
        if (amount <= 0) return

        await earnCurrency(referrerId, referrerName, currencyKey, amount, '推广返佣', orderId, `${orderType} #${orderId} 返佣`)

        await query(
          `INSERT INTO commission_records (order_id, order_type, order_amount, user_id, user_name, referrer_id, referrer_name, rate, level, reward_type, amount, points_amount, currency_details, status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [orderId, orderType, orderAmount, userId, '', referrerId, referrerName, useRate, rule.level || 1, currencyKey,
            currencyKey === 'balance' ? amount : 0, currencyKey === 'points' ? amount : 0,
            JSON.stringify({ [currencyKey]: amount }), 'completed']
        )
        return
      }

      // 新模式：rate_config 多币种
      const csRows = await query('SELECT currency_key, currency_type FROM currency_settings')
      const quotaSet = new Set(csRows.filter(r => r.currency_type === 'quota').map(r => r.currency_key))
      const currencyDetails = {}
      for (const [currencyKey, rateStr] of Object.entries(rateConfig)) {
        if (quotaSet.has(currencyKey)) continue
        const rate = Number(rateStr)
        if (rate <= 0) continue
        const amount = Number((orderAmount * rate / 100).toFixed(2))
        if (amount <= 0) continue
        try {
          await earnCurrency(referrerId, referrerName, currencyKey, amount, '推广返佣', orderId, `${orderType} #${orderId} 返佣`)
          currencyDetails[currencyKey] = amount
        } catch (err) { console.error(`返佣货币 ${currencyKey} 发放失败:`, err.message) }
      }

      if (Object.keys(currencyDetails).length === 0) return

      await query(
        `INSERT INTO commission_records (order_id, order_type, order_amount, user_id, user_name, referrer_id, referrer_name, rate, level, reward_type, amount, points_amount, currency_details, status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [orderId, orderType, orderAmount, userId, '', referrerId, referrerName,
          currencyDetails['balance'] ? Number(rateConfig['balance'] || 0) : 0,
          rule.level || 1, 'multi',
          currencyDetails['balance'] || 0, currencyDetails['points'] || 0,
          JSON.stringify(currencyDetails), 'completed']
      )
    }
  } catch (e) { console.error('返佣计算失败:', e.message) }
}

module.exports = function commissionRoutes(app) {
  // 获取返佣规则列表
  app.get('/api/commission/rules', async (req, res) => {
    try {
      const list = await query('SELECT * FROM commission_rules ORDER BY id')
      const parsed = list.map(r => ({ ...r, rate_config: safeJsonParse(r.rate_config) }))
      res.json({ code: 200, data: parsed })
    } catch (e) { res.serverError(e) }
  })

  // 保存返佣规则
  app.post('/api/commission/rule/save', authRequired, adminRequired, async (req, res) => {
    try {
      const { id, name, order_type, rate, points_rate, rate_config, user_level_id, user_level_name, user_id, invite_code_id, invite_code_type, status } = req.body
      const rc = rate_config ? JSON.stringify(rate_config) : null
      if (id) {
        await query(
          'UPDATE commission_rules SET name=?, order_type=?, rate=?, points_rate=?, rate_config=?, user_level_id=?, user_level_name=?, user_id=?, invite_code_id=?, invite_code_type=?, status=? WHERE id=?',
          [name, order_type, rate || 0, points_rate || 0, rc, user_level_id || 0, user_level_name || '', user_id || 0, invite_code_id || 0, invite_code_type || '', status || '1', Number(id)]
        )
        logFromReq(req, 'update', 'commission_rule', Number(id), `更新返佣规则"${name}"`)
      } else {
        const result = await query(
          'INSERT INTO commission_rules (name, order_type, rate, points_rate, rate_config, user_level_id, user_level_name, user_id, invite_code_id, invite_code_type, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
          [name, order_type, rate || 0, points_rate || 0, rc, user_level_id || 0, user_level_name || '', user_id || 0, invite_code_id || 0, invite_code_type || '', status || '1']
        )
        logFromReq(req, 'create', 'commission_rule', result.insertId, `新增返佣规则"${name}"`)
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  // 删除返佣规则
  app.post('/api/commission/rule/delete', authRequired, adminRequired, async (req, res) => {
    try {
      await query('DELETE FROM commission_rules WHERE id=?', [Number(req.body.id)])
      logFromReq(req, 'delete', 'commission_rule', req.body.id, `删除返佣规则ID:${req.body.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  // 返佣记录列表
  app.get('/api/commission/records', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20, code } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = userId ? 'WHERE referrer_id=?' : 'WHERE 1=1'
      let params = userId ? [userId] : []

      if (code) { where += ' AND user_id IN (SELECT id FROM users WHERE referrer_code=?)'; params.push(code) }
      if (req.query.status) { where += ' AND status=?'; params.push(req.query.status) }

      const total = await query(`SELECT COUNT(*) as total FROM commission_records ${where}`, params)
      const list = await query(
        `SELECT * FROM commission_records ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      const parsedList = list.map(r => ({ ...r, currency_details: safeJsonParse(r.currency_details) }))
      res.json({ code: 200, data: { list: parsedList, total: total[0]?.total || 0 } })
    } catch (e) { res.serverError(e) }
  })

  // 生成推广链接
  app.post('/api/commission/referral/generate', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const existing = await query('SELECT * FROM user_codes WHERE user_id=? AND auto_generated=1', [userId])
      if (existing.length) {
        return res.json({ code: 200, data: existing[0] })
      }

      const code = genCode()
      await query(
        'INSERT INTO user_codes (user_id, code, label, max_uses, auto_generated) VALUES (?,?,?,0,1)',
        [userId, code, '默认推广码']
      )
      res.json({ code: 200, data: { user_id: userId, code } })
    } catch (e) { res.serverError(e) }
  })

  // 获取推广链接
  app.get('/api/commission/referral', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const row = await query('SELECT * FROM user_codes WHERE user_id=? AND auto_generated=1', [userId])
      res.json({ code: 200, data: row.length > 0 ? row[0] : null })
    } catch (e) { res.serverError(e) }
  })

  // 通过推广码绑定推荐人
  app.post('/api/commission/referral/bind', async (req, res) => {
    try {
      const { code } = req.body
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      // 先查 user_codes
      let ref = await query('SELECT * FROM user_codes WHERE code=? AND status=?', [code, '1'])
      if (!ref.length) {
        // 兼容旧的 referral_links
        ref = await query('SELECT * FROM referral_links WHERE code=?', [code])
      }
      if (!ref.length) return res.json({ code: 404, msg: '推广码无效' })
      if (ref[0].user_id === userId) return res.json({ code: 400, msg: '不能绑定自己的推广码' })

      const currentRef = await query('SELECT referrer_id FROM users WHERE id=?', [userId])
      if (currentRef.length && currentRef[0].referrer_id) {
        return res.json({ code: 400, msg: '已绑定推荐人' })
      }

      await query('UPDATE users SET referrer_id=?, referrer_code=? WHERE id=?', [ref[0].user_id, code, userId])

      // 更新统计
      if (ref[0].auto_generated !== undefined) {
        await query('UPDATE user_codes SET register_count=register_count+1 WHERE id=?', [ref[0].id])
      } else {
        await query('UPDATE referral_links SET register_count=register_count+1 WHERE id=?', [ref[0].id])
      }

      res.json({ code: 200, msg: '推荐人绑定成功' })
    } catch (e) { res.serverError(e) }
  })

  // 提现记录
  app.get('/api/commission/withdraw/list', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status, userId: queryUserId } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE 1=1'
      const params = []

      const currentUserId = await getUserId(req)
      if (currentUserId) {
        const isAdmin = await checkAdmin(req)
        if (!isAdmin) { where += ' AND user_id=?'; params.push(currentUserId) }
      }

      if (status) { where += ' AND status=?'; params.push(status) }
      if (queryUserId && currentUserId !== Number(queryUserId)) { where += ' AND user_id=?'; params.push(Number(queryUserId)) }

      const total = await query(`SELECT COUNT(*) as total FROM withdraw_records ${where}`, params)
      const list = await query(
        `SELECT * FROM withdraw_records ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      res.json({ code: 200, data: { list, total: total[0]?.total || 0 } })
    } catch (e) { res.serverError(e) }
  })

  // 申请提现
  app.post('/api/commission/withdraw/apply', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { amount, method, account, realName } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '提现金额无效' })

      const users = await query('SELECT username FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })
      const balRows = await query('SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=\'balance\'', [userId])
      users[0].balance = Number(balRows[0]?.available || 0)

      if (users[0].balance < Number(amount)) return res.json({ code: 400, msg: '余额不足' })

      // E1: 提现权限
      const canWithdraw = await hasPermission(userId, 'monetize', 'E1')
      if (!canWithdraw) return res.json({ code: 403, msg: '当前等级不支持提现' })

      // E2: 最低提现金额 — 等级越低门槛越高 (Lv.8=100, Lv.20=1)
      const minWithdraw = parseFloat(await getPermissionValue(userId, 'monetize', 'E2') || '0')
      if (minWithdraw > 0 && Number(amount) < minWithdraw) {
        return res.json({ code: 400, msg: `当前等级最低提现${minWithdraw}元` })
      }

      await query(
        `INSERT INTO withdraw_records (user_id, user_name, amount, method, account, real_name, status)
         VALUES (?,?,?,?,?,?,?)`,
        [userId, users[0].username, Number(amount), method || 'alipay', account || '', realName || '', 'pending']
      )
      await deductBalance(userId, users[0].username, Number(amount), '余额提现', `提现申请 ${method || 'alipay'} ${account || ''}`)

      // 提现通知管理员
      const adminEmails = await getAdminEmails()
      for (const adminEmail of adminEmails) {
        sendNotificationEmail('withdraw_request', adminEmail, {
          username: '管理员',
          subject: '新的提现申请',
          content: `用户 ${users[0].username} 申请提现 ${amount} 元，请尽快处理。`
        })
      }

      res.json({ code: 200, msg: '提现申请已提交' })
    } catch (e) { res.serverError(e) }
  })

  // 审核提现
  app.post('/api/commission/withdraw/review', authRequired, adminRequired, async (req, res) => {
    try {
      const { id, status, remark } = req.body
      const reviewerId = await getUserId(req)
      const reviewer = await query('SELECT username FROM users WHERE id=?', [reviewerId])
      const reviewerName = reviewer.length > 0 ? reviewer[0].username : ''

      if (status === 'rejected') {
        const record = await query('SELECT user_id, amount, user_name FROM withdraw_records WHERE id=?', [Number(id)])
        if (record.length > 0) {
          await addBalance(record[0].user_id, record[0].user_name || '', record[0].amount, '提现退回', `提现申请被拒绝，退回余额`)
        }
      }

      await query(
        'UPDATE withdraw_records SET status=?, remark=?, reviewed_by=?, reviewed_by_name=?, reviewed_at=NOW() WHERE id=?',
        [status, remark || '', reviewerId, reviewerName, Number(id)]
      )
      logFromReq(req, 'update', 'withdraw', Number(id), `审核提现ID:${id} ${status === 'completed' ? '通过' : '拒绝'}${remark ? '(' + remark + ')' : ''}`)

      // 提现结果通知用户
      const userEmail = await query('SELECT u.email FROM users u JOIN withdraw_records wr ON wr.user_id=u.id WHERE wr.id=?', [Number(id)])
      if (userEmail.length > 0 && userEmail[0].email) {
        sendNotificationEmail('withdraw_result', userEmail[0].email, {
          username: record[0].user_name || '',
          subject: status === 'completed' ? '提现审核通过' : '提现审核拒绝',
          content: status === 'completed'
            ? `您的提现申请已通过，金额 ${record[0].amount} 元将尽快到账。`
            : `您的提现申请被拒绝，金额已退回余额。${remark ? '原因：' + remark : ''}`
        })
      }

      res.json({ code: 200, msg: status === 'completed' ? '提现已通过' : '提现已拒绝' })
    } catch (e) { res.serverError(e) }
  })

  async function checkAdmin(req) {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
    const session = sessions.get(token)
    if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
    return false
  }

  // ========== 19. 多级返佣计算 ==========

  app.post('/api/commission/calculate', authRequired, adminRequired, async (req, res) => {
    try {
      const { userId, orderAmount, orderId, orderType } = req.body
      const uid = Number(userId)
      const amount = Number(orderAmount)
      if (!uid || !amount || amount <= 0) return res.json({ code: 400, msg: '参数错误' })

      const userRows = await query('SELECT id, referrer_id, referrer_id_2, referrer_code, username FROM users WHERE id=?', [uid])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })

      const user = userRows[0]
      const results = []

      async function calcSingleLevel(refId, level) {
        if (!refId) return
        const referrerRows = await query('SELECT id, username, level_id FROM users WHERE id=?', [refId])
        if (!referrerRows.length) return
        const referrer = referrerRows[0]
        const referrerCode = user.referrer_code || ''

        let inviteCodeId = 0
        let inviteCodeType = ''
        if (referrerCode) {
          const codeRows = await query('SELECT id, type FROM invite_codes WHERE code=?', [referrerCode])
          if (codeRows.length) {
            inviteCodeId = codeRows[0].id
            inviteCodeType = codeRows[0].type || ''
          }
          if (!inviteCodeId) {
            const ucRows = await query('SELECT id FROM user_codes WHERE code=?', [referrerCode])
            if (ucRows.length) {
              inviteCodeId = ucRows[0].id
              inviteCodeType = 'user'
            }
          }
        }

        let rules = []
        if (inviteCodeId) {
          rules = await query(
            'SELECT * FROM commission_rules WHERE status=? AND invite_code_id=? AND level=? AND (order_type=? OR order_type=?)',
            ['1', inviteCodeId, level, orderType || 'all', 'all']
          )
        }
        if (!rules.length && inviteCodeType) {
          rules = await query(
            'SELECT * FROM commission_rules WHERE status=? AND invite_code_type=? AND invite_code_id=0 AND level=? AND (order_type=? OR order_type=?)',
            ['1', inviteCodeType, level, orderType || 'all', 'all']
          )
        }
        if (!rules.length) {
          rules = await query(
            "SELECT * FROM commission_rules WHERE status=? AND user_id=? AND invite_code_id=0 AND invite_code_type='' AND level=? AND (order_type=? OR order_type=?)",
            ['1', refId, level, orderType || 'all', 'all']
          )
        }
        if (!rules.length) {
          const levelRow = await query('SELECT level_id FROM users WHERE id=?', [refId])
          const levelId = levelRow.length > 0 ? levelRow[0].level_id : 0
          if (levelId) {
            rules = await query(
              "SELECT * FROM commission_rules WHERE status=? AND user_level_id=? AND invite_code_id=0 AND invite_code_type='' AND level=? AND (order_type=? OR order_type=?)",
              ['1', levelId, level, orderType || 'all', 'all']
            )
          }
        }
        if (!rules.length) {
          rules = await query(
            "SELECT * FROM commission_rules WHERE status=? AND user_level_id=0 AND user_id=0 AND invite_code_id=0 AND invite_code_type='' AND level=? AND (order_type=? OR order_type=?)",
            ['1', level, orderType || 'all', 'all']
          )
        }

        if (rules.length) {
          const rule = rules[0]
          const commAmount = (amount * rule.rate / 100).toFixed(2)
          results.push({ referrerId: refId, referrerName: referrer.username, level, rate: rule.rate, amount: Number(commAmount) })
        }
      }

      await calcSingleLevel(user.referrer_id, 1)
      await calcSingleLevel(user.referrer_id_2, 2)

      res.json({ code: 200, data: { userId: uid, orderAmount: amount, results } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 20. 返佣数据看板 ==========

  app.get('/api/commission/stats/dashboard', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const uid = userId || Number(req.query.userId) || 0

      const totalEarnings = await query(
        'SELECT COALESCE(SUM(amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=?',
        [uid, 'completed']
      )

      const todayEarnings = await query(
        'SELECT COALESCE(SUM(amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=? AND DATE(create_time)=CURDATE()',
        [uid, 'completed']
      )

      const level1Earnings = await query(
        'SELECT COALESCE(SUM(amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=? AND level=1',
        [uid, 'completed']
      )

      const level2Earnings = await query(
        'SELECT COALESCE(SUM(amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=? AND level=2',
        [uid, 'completed']
      )

      const totalPointsEarnings = await query(
        'SELECT COALESCE(SUM(points_amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=?',
        [uid, 'completed']
      )

      const todayPointsEarnings = await query(
        'SELECT COALESCE(SUM(points_amount), 0) as total FROM commission_records WHERE referrer_id=? AND status=? AND DATE(create_time)=CURDATE()',
        [uid, 'completed']
      )

      const clickCount = await query(
        'SELECT COALESCE(SUM(click_count), 0) as clicks FROM user_codes WHERE user_id=?',
        [uid]
      )

      const referralLinks = await query('SELECT id, code FROM user_codes WHERE user_id=? AND status=?', [uid, '1'])
      let referralCount = 0
      if (referralLinks.length) {
        const codes = referralLinks.map(r => r.code)
        const placeholders = codes.map(() => '?').join(',')
        const cnt = await query(
          `SELECT COUNT(*) as cnt FROM users WHERE referrer_code IN (${placeholders})`,
          codes
        )
        referralCount = cnt[0]?.cnt || 0
      }

      const recentOrders = await query(
        `SELECT cr.* FROM commission_records cr
         WHERE cr.referrer_id=? AND cr.status=? ORDER BY cr.create_time DESC LIMIT 5`,
        [uid, 'completed']
      )

      res.json({
        code: 200, data: {
          totalEarnings: Number(totalEarnings[0]?.total || 0),
          todayEarnings: Number(todayEarnings[0]?.total || 0),
          totalPointsEarnings: Number(totalPointsEarnings[0]?.total || 0),
          todayPointsEarnings: Number(todayPointsEarnings[0]?.total || 0),
          level1Earnings: Number(level1Earnings[0]?.total || 0),
          level2Earnings: Number(level2Earnings[0]?.total || 0),
          clickCount: clickCount[0]?.clicks || 0,
          referralCount,
          recentOrders: recentOrders.map(r => ({
            id: r.id,
            orderId: r.order_id,
            orderType: r.order_type,
            orderAmount: Number(r.order_amount),
            commission: Number(r.amount) || 0,
            pointsCommission: Number(r.points_amount) || 0,
            level: r.level || 1,
            rate: Number(r.rate),
            referrerName: r.referrer_name,
            status: r.status,
            createTime: r.create_time
          }))
        }
      })
    } catch (e) { res.serverError(e) }
  })

  // ========== 21. 推广素材管理 ==========

  app.get('/api/commission/materials', async (req, res) => {
    try {
      const list = await query('SELECT * FROM promotion_materials ORDER BY create_time DESC')
      res.json({ code: 200, data: list })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/commission/materials', async (req, res) => {
    try {
      const isAdminUser = await checkAdmin(req)
      if (!isAdminUser) return res.json({ code: 403, msg: '仅管理员可操作' })
      const { title, image_url, description, type } = req.body
      if (!title) return res.json({ code: 400, msg: '标题不能为空' })
      const result = await query(
        'INSERT INTO promotion_materials (title, image_url, description, type) VALUES (?,?,?,?)',
        [title, image_url || '', description || '', type || 'poster']
      )
      res.json({ code: 200, msg: '添加成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  app.delete('/api/commission/materials/:id', async (req, res) => {
    try {
      const isAdminUser = await checkAdmin(req)
      if (!isAdminUser) return res.json({ code: 403, msg: '仅管理员可操作' })
      await query('DELETE FROM promotion_materials WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/commission/materials/:id/share', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const mid = Number(req.params.id)
      const material = await query('SELECT id FROM promotion_materials WHERE id=?', [mid])
      if (!material.length) return res.json({ code: 404, msg: '素材不存在' })
      if (userId) {
        await query('UPDATE user_codes SET click_count=click_count+1 WHERE user_id=?', [userId])
      }
      res.json({ code: 200, msg: '记录成功' })
    } catch (e) { res.serverError(e) }
  })
}

module.exports.calcCommission = calcCommission
