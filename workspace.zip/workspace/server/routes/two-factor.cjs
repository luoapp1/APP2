const { query } = require('../database.cjs')
const speakeasy = require('speakeasy')
const { sessions } = require('./system.cjs')

// Auto-migrate columns
;(async () => {
  try {
    const cols = await query("SHOW COLUMNS FROM users LIKE 'two_factor_enabled'")
    if (!cols || cols.length === 0) {
      await query("ALTER TABLE users ADD COLUMN two_factor_enabled TINYINT DEFAULT 0")
      console.log('[2FA] Added two_factor_enabled column to users')
    }
    const cols2 = await query("SHOW COLUMNS FROM users LIKE 'two_factor_secret'")
    if (!cols2 || cols2.length === 0) {
      await query("ALTER TABLE users ADD COLUMN two_factor_secret VARCHAR(64) DEFAULT NULL")
      console.log('[2FA] Added two_factor_secret column to users')
    }
  } catch (e) { console.error('[2FA] Migration error:', e.message) }
})()

function getUserId(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token || !sessions) return 0
  const session = sessions.get(token)
  if (session) return session.userId
  return 0
}

function authRequired(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token || !sessions) return res.status(401).json({ code: 401, msg: '请先登录' })
  const session = sessions.get(token)
  if (!session) return res.status(401).json({ code: 401, msg: '登录已过期' })
  req.user = session
  next()
}

const tempSessions = new Map()

// 2FA临时会话清理已迁移至统一调度器 server/scheduler/tasks.cjs

function twoFactorRoutes(app) {
  // Check if user has 2FA enabled (called during login)
  app.get('/api/two-factor/status/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId)
      if (!userId) return res.json({ code: 400, msg: '参数错误' })
      const rows = await query('SELECT two_factor_enabled, two_factor_secret FROM users WHERE id=?', [userId])
      if (rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      const enabled = rows[0].two_factor_enabled === 1
      if (enabled) {
        const tempToken = require('crypto').randomBytes(16).toString('hex')
        tempSessions.set(tempToken, { userId, createdAt: Date.now() })
        res.json({ code: 200, data: { enabled: true, tempSessionToken: tempToken } })
      } else {
        res.json({ code: 200, data: { enabled: false } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // Verify 2FA code during login
  app.post('/api/two-factor/verify', async (req, res) => {
    try {
      const { token: code, tempSessionToken } = req.body
      if (!code || !tempSessionToken) return res.json({ code: 400, msg: '参数错误' })

      const temp = tempSessions.get(tempSessionToken)
      if (!temp) return res.json({ code: 401, msg: '会话已过期，请重新登录' })
      tempSessions.delete(tempSessionToken)

      const rows = await query('SELECT two_factor_secret FROM users WHERE id=? AND two_factor_enabled=1', [temp.userId])
      if (rows.length === 0) return res.json({ code: 400, msg: '用户未启用两步验证' })

      const verified = speakeasy.totp.verify({
        secret: rows[0].two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1
      })

      if (!verified) return res.json({ code: 400, msg: '验证码错误或已过期' })

      // Generate final auth token
      const crypto = require('crypto')
      const finalToken = crypto.randomBytes(32).toString('hex')
      const userRows = await query('SELECT username, roles FROM users WHERE id=?', [temp.userId])
      const user = userRows[0]
      const roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || [])
      sessions.set(finalToken, {
        userId: temp.userId,
        userName: user.username,
        roles,
        createdAt: Date.now()
      })

      res.json({ code: 200, msg: '验证成功', data: { token: finalToken } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // Generate 2FA secret for setup
  app.post('/api/two-factor/setup', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const user = await query('SELECT username, two_factor_enabled FROM users WHERE id=?', [userId])
      if (user.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      if (user[0].two_factor_enabled) return res.json({ code: 400, msg: '已启用两步验证，请先禁用' })

      const secret = speakeasy.generateSecret({
        name: `ArtDesignPro:${user[0].username}`,
        length: 20
      })

      // Store secret temporarily encoded
      await query('UPDATE users SET two_factor_secret=? WHERE id=?', [secret.base32, userId])

      res.json({
        code: 200,
        data: {
          secret: secret.base32,
          otpauth_url: secret.otpauth_url
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // Enable 2FA (confirm setup with verification code)
  app.post('/api/two-factor/enable', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { token: code } = req.body
      if (!code) return res.json({ code: 400, msg: '请输入验证码' })

      const rows = await query('SELECT two_factor_secret FROM users WHERE id=?', [userId])
      if (rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      if (!rows[0].two_factor_secret) return res.json({ code: 400, msg: '请先生成两步验证密钥' })

      const verified = speakeasy.totp.verify({
        secret: rows[0].two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1
      })

      if (!verified) return res.json({ code: 400, msg: '验证码错误，请重试' })

      await query('UPDATE users SET two_factor_enabled=1 WHERE id=?', [userId])

      res.json({ code: 200, msg: '两步验证已启用' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // Disable 2FA
  app.post('/api/two-factor/disable', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { token: code } = req.body
      if (!code) return res.json({ code: 400, msg: '请输入验证码' })

      const rows = await query('SELECT two_factor_secret FROM users WHERE id=? AND two_factor_enabled=1', [userId])
      if (rows.length === 0) return res.json({ code: 400, msg: '未启用两步验证' })

      const verified = speakeasy.totp.verify({
        secret: rows[0].two_factor_secret,
        encoding: 'base32',
        token: code,
        window: 1
      })

      if (!verified) return res.json({ code: 400, msg: '验证码错误，请重试' })

      await query('UPDATE users SET two_factor_enabled=0, two_factor_secret=NULL WHERE id=?', [userId])

      res.json({ code: 200, msg: '两步验证已禁用' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // Get current 2FA status
  app.get('/api/two-factor/my-status', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const rows = await query('SELECT two_factor_enabled FROM users WHERE id=?', [userId])
      if (rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      res.json({ code: 200, data: { enabled: rows[0].two_factor_enabled === 1 } })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = twoFactorRoutes
module.exports.tempSessions = tempSessions
