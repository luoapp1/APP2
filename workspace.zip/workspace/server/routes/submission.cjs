const { query, getSystemOperator } = require('../database.cjs')
const { executePenalty } = require('./custom-task.cjs')
const nowExpr = 'NOW()'
const { logFromReq } = require('../middleware/security.cjs')
const { deleteFileRecordsByRef } = require('../utils/file-helper.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { hasPermission } = require('../middleware/level-permissions.cjs')

function isAdmin(req) {
  const token = (req.headers?.authorization || '').replace(/^Bearer\s+/i, '').trim()
  if (!token) return false
  const session = sessions.get(token)
  if (session && Date.now() - session.createdAt <= SESSION_TTL) return (session.roles || []).some(r => ['R_ADMIN', 'R_SUPER', 'R_MODERATOR', 'R_REVIEWER'].includes(r))
  return false
}

function getUserIdFromSession(req) {
  const token = (req.headers?.authorization || '').replace(/^Bearer\s+/i, '').trim()
  if (!token) return 0
  const session = sessions.get(token)
  if (session && Date.now() - session.createdAt <= SESSION_TTL) return Number(session.userId) || 0
  return 0
}

function submissionRoutes(router) {

  // GET /api/submission/stats — 投稿统计 (按用户)
  router.get('/api/submission/stats', async (req, res) => {
    try {
      const { userId } = req.query
      let statsSql = `SELECT 
        COALESCE(SUM(s.downloads), 0) as totalDownloads,
        COALESCE(SUM(s.coin_count), 0) as totalCoins,
        COALESCE(SUM(s.coin_people), 0) as totalCoinPeople
      FROM app_uploads u
      LEFT JOIN app_store s ON u.app_id = s.id AND s.status = '1'
      WHERE 1=1`
      const params = []
      if (userId) {
        statsSql += ' AND u.user_id=?'
        params.push(userId)
      }
      const stats = await query(statsSql, params)

      const statusCount = await query(
        `SELECT submission_status as status, COUNT(*) as count 
         FROM app_uploads WHERE user_id=? 
         GROUP BY submission_status`,
        [userId]
      )

      let totalReviews = 0, totalFiveStar = 0
      if (userId) {
        const reviewStats = await query(
          `SELECT COUNT(*) as total, COALESCE(SUM(CASE WHEN c.rating = 5 THEN 1 ELSE 0 END), 0) as fiveStar
           FROM app_comments c
           INNER JOIN app_uploads u ON c.app_id = u.app_id
           WHERE u.user_id = ?`,
          [userId]
        )
        if (reviewStats[0]) {
          totalReviews = reviewStats[0].total || 0
          totalFiveStar = reviewStats[0].fiveStar || 0
        }
      }

      res.json({ code: 200, msg: 'success', data: {
        totalDownloads: stats[0]?.totalDownloads || 0,
        totalReviews,
        totalFiveStar,
        totalCoins: stats[0]?.totalCoins || 0,
        totalSubmissions: statusCount.reduce((sum, s) => sum + s.count, 0),
        statusCount
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/submission/list — 投稿列表
  router.get('/api/submission/list', async (req, res) => {
    try {
      const { userId, status, keyword, type, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT u.id, u.app_id as appId, u.user_id as userId, u.user_name as userName,
                  u.name, u.package_name as packageName, u.category, u.description, u.icon,
                  u.price_type as priceType, u.price_amount as priceAmount,
                  u.version, u.version_code as versionCode, u.size_mb as sizeMb,
                  COALESCE(s.downloads, u.downloads, 0) as downloads,
                  COALESCE(s.rating, u.rating, 0) as rating,
                  COALESCE(s.coin_count, u.coin_count, 0) as coins,
                  COALESCE(s.coin_people, u.coin_people, 0) as coinPeople,
                  u.review_count as reviews,
                  u.five_star_count as fiveStarCount,
                  u.screenshots, u.tags, u.official_tags as officialTags, u.download_url as downloadUrl,
                  u.version_type as versionType, u.has_ads as hasAds,
                  u.requires_network as requiresNetwork, u.has_paid_content as hasPaidContent,
                  u.is_free as isFree,
                  u.submission_status as submissionStatus, u.review_comment as reviewComment,
                  u.review_by as reviewBy, u.review_time as reviewTime,
                  u.type, u.resource_zip_url as resourceZipUrl,
                  u.create_time as createTime, u.update_time as updateTime
               FROM app_uploads u
               LEFT JOIN app_store s ON u.app_id = s.id AND s.status = '1'
               WHERE 1=1`
      const params = []

      if (userId) { sql += ' AND u.user_id=?'; params.push(userId) }
      if (type) { sql += ' AND u.type=?'; params.push(type) }
      if (status) { sql += ' AND u.submission_status=?'; params.push(status) }
      else { sql += ' AND u.submission_status != ?'; params.push('deleted') }
      if (keyword) {
        sql += ' AND (u.name LIKE ? OR u.package_name LIKE ?)'
        params.push(`%${keyword}%`, `%${keyword}%`)
      }

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0

      sql += ' ORDER BY u.id DESC LIMIT ? OFFSET ?'
      params.push(parseInt(pageSize), offset)
      const list = await query(sql, params)
      for (const item of list) {
        try { item.screenshots = item.screenshots ? JSON.parse(item.screenshots) : [] } catch { item.screenshots = [] }
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/submission/review-list — 管理员审核列表
  router.get('/api/submission/review-list', async (req, res) => {
    try {
      if (!isAdmin(req)) return res.json({ code: 403, msg: '无审核权限' })
      const { keyword, submissionStatus, page = 1, pageSize = 20 } = req.query
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      let where = '1=1'
      const params = []

      if (submissionStatus) { where += ' AND submission_status=?'; params.push(submissionStatus) }
      else { where += ' AND submission_status != ?'; params.push('deleted') }
      if (keyword) {
        where += ' AND (name LIKE ? OR package_name LIKE ? OR user_name LIKE ?)'
        params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`)
      }

      const countResult = await query(`SELECT COUNT(*) as total FROM app_uploads WHERE ${where}`, params)

      const list = await query(
        `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                name, package_name as packageName, category, description, icon, icon_bg_color as iconBgColor,
                price_type as priceType, price_amount as priceAmount,
                version, version_code as versionCode, size_mb as sizeMb,
                download_url as downloadUrl, screenshots, tags, official_tags as officialTags,
                version_type as versionType, has_ads as hasAds,
                requires_network as requiresNetwork, has_paid_content as hasPaidContent,
                is_free as isFree,
                submission_status as submissionStatus, review_comment as reviewComment,
                review_by as reviewBy, review_time as reviewTime,
                type, resource_zip_url as resourceZipUrl,
                create_time as createTime, update_time as updateTime,
                (SELECT COUNT(*) FROM community_reports WHERE target_type='app' AND target_id=app_uploads.id AND status='pending') as pendingReports,
                TIMESTAMPDIFF(HOUR, create_time, NOW()) as waitHours,
                COALESCE((SELECT level FROM community_trust_levels WHERE user_id=app_uploads.user_id LIMIT 1), 0) as trustLevel
         FROM app_uploads WHERE ${where}
         ORDER BY
           CASE submission_status WHEN 'pending' THEN 0 ELSE 99 END,
           CASE WHEN (SELECT COUNT(*) FROM community_reports WHERE target_type='app' AND target_id=app_uploads.id AND status='pending') >= 3 THEN 0 ELSE 1 END,
           TIMESTAMPDIFF(HOUR, create_time, NOW()) DESC,
           COALESCE((SELECT level FROM community_trust_levels WHERE user_id=app_uploads.user_id), 3) ASC
         LIMIT ? OFFSET ?`,
        [...params, parseInt(pageSize), offset]
      )
      for (const item of list) {
        try { item.screenshots = item.screenshots ? JSON.parse(item.screenshots) : [] } catch { item.screenshots = [] }
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.officialTags = item.officialTags ? JSON.parse(item.officialTags) : [] } catch { item.officialTags = [] }
      }

      const counts = await query('SELECT submission_status as status, COUNT(*) as count FROM app_uploads GROUP BY submission_status')
      const countMap = {}
      for (const c of counts) { countMap[c.status] = c.count }

      res.json({
        code: 200, msg: 'success',
        data: {
          list, total: countResult[0]?.total || 0, page: parseInt(page), pageSize: parseInt(pageSize),
          pendingCount: countMap.pending || 0,
          approvedCount: countMap.approved || 0,
          rejectedCount: countMap.rejected || 0,
          removedCount: countMap.removed || 0,
          draftCount: countMap.draft || 0,
          deletedCount: countMap.deleted || 0
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/submission/:id — 投稿详情
  // GET /api/submission/versions — 某应用的所有版本（必须在 :id 之前）
  router.get('/api/submission/versions', async (req, res) => {
    try {
      const { packageName, userId } = req.query
      if (!packageName) return res.json({ code: 400, msg: '缺少包名' })
      let sql = `SELECT id, app_id as appId, name, package_name as packageName,
                  version, version_code as versionCode, size_mb as sizeMb,
                  submission_status as submissionStatus, review_comment as reviewComment,
                  create_time as createTime, update_time as updateTime
               FROM app_uploads WHERE package_name=?`
      const params = [packageName]
      if (userId) { sql += ' AND user_id=?'; params.push(userId) }
      sql += ' ORDER BY id DESC'
      const list = await query(sql, params)
      res.json({ code: 200, msg: 'success', data: { list } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/submission/:id', async (req, res) => {
    try {
      let item = await query(
        `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                name, package_name as packageName, category, description, icon,
                price_type as priceType, price_amount as priceAmount,
                version, version_code as versionCode, size_mb as sizeMb,
                downloads, rating, coin_count as coinCount, coin_people as coinPeople,
                review_count as reviewCount, five_star_count as fiveStarCount,
                screenshots, tags, official_tags as officialTags, download_url as downloadUrl,
                version_type as versionType, has_ads as hasAds,
                requires_network as requiresNetwork, has_paid_content as hasPaidContent,
                is_free as isFree,
                submission_status as submissionStatus, review_comment as reviewComment,
                review_by as reviewBy, review_time as reviewTime,
                type, resource_zip_url as resourceZipUrl,
                create_time as createTime, update_time as updateTime
         FROM app_uploads WHERE id=?`, [req.params.id]
      )
      if (!item || item.length === 0) {
        item = await query(
          `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                  name, package_name as packageName, category, description, icon,
                  price_type as priceType, price_amount as priceAmount,
                  version, version_code as versionCode, size_mb as sizeMb,
                  downloads, rating, coin_count as coinCount, coin_people as coinPeople,
                  review_count as reviewCount, five_star_count as fiveStarCount,
                  screenshots, tags, official_tags as officialTags, download_url as downloadUrl,
                  version_type as versionType, has_ads as hasAds,
                  requires_network as requiresNetwork, has_paid_content as hasPaidContent,
                  is_free as isFree,
                  submission_status as submissionStatus, review_comment as reviewComment,
                  review_by as reviewBy, review_time as reviewTime,
                  type, resource_zip_url as resourceZipUrl,
                  create_time as createTime, update_time as updateTime
           FROM app_uploads WHERE app_id=? ORDER BY id DESC LIMIT 1`, [req.params.id]
        )
      }
      if (!item || item.length === 0) {
        return res.json({ code: 404, msg: '投稿不存在' })
      }
      const data = item[0]
      try { data.screenshots = data.screenshots ? JSON.parse(data.screenshots) : [] } catch { data.screenshots = [] }
      try { data.tags = data.tags ? JSON.parse(data.tags) : [] } catch { data.tags = [] }
      try { data.officialTags = data.officialTags ? JSON.parse(data.officialTags) : [] } catch { data.officialTags = [] }
      res.json({ code: 200, msg: 'success', data })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/submission/save — 保存投稿（草稿或更新）
  router.post('/api/submission/save', async (req, res) => {
    try {
      const { id, userId, userName, name, packageName, category, description,
              icon, iconBgColor, version, versionCode, sizeMb, downloadUrl, screenshots, tags,
              officialTags, submissionStatus, versionType, hasAds, requiresNetwork, hasPaidContent, isFree,
              price_type, price_amount, type, resourceZipUrl } = req.body

      const submissionType = type || 'apk'

      let categorySingle = category || '工具'
      let categoriesJson = '[]'
      try {
        const parsed = JSON.parse(category)
        if (Array.isArray(parsed) && parsed.length > 0) {
          categorySingle = parsed[0]
          categoriesJson = category
        }
      } catch {}

      const ss = screenshots ? JSON.stringify(screenshots) : '[]'
      const vt = versionType || ''
      // 自动将版本类型加入标签数组
      let tgArr = tags || []
      if (vt && !tgArr.includes(vt)) tgArr = [vt, ...tgArr]
      const tg = JSON.stringify(tgArr)
      const ot = officialTags ? JSON.stringify(officialTags) : '[]'
      const ha = hasAds !== undefined ? (hasAds ? 1 : 0) : 0
      const rn = requiresNetwork !== undefined ? (requiresNetwork ? 1 : 0) : 1
      const hpc = hasPaidContent !== undefined ? (hasPaidContent ? 1 : 0) : 0
      const free = isFree !== undefined ? (isFree ? 1 : 0) : 1
      let status = submissionStatus || 'draft'

      if (id) {
        const existing = await query('SELECT user_id, app_id, submission_status FROM app_uploads WHERE id=?', [id])
        if (!existing || existing.length === 0) {
          return res.json({ code: 404, msg: '投稿不存在' })
        }
        if (!submissionStatus) { status = existing[0].submission_status || 'draft' }
        // A2: 编辑后免重审 — 非A2用户编辑已通过投稿需要重新审核
        if (existing[0].app_id && existing[0].app_id > 0 && existing[0].submission_status === 'approved' && status !== 'draft') {
          const userIdFromSession = getUserIdFromSession(req)
          const hasA2 = userIdFromSession ? await hasPermission(userIdFromSession, 'appstore', 'A2') : false
          if (!hasA2) {
            status = 'pending'
          }
        }
        await query(
            `UPDATE app_uploads SET name=?, package_name=?, category=?, description=?, icon=?,
             icon_bg_color=?, version=?, version_code=?, size_mb=?, download_url=?, screenshots=?, tags=?,
             official_tags=?, version_type=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?,
             price_type=?, price_amount=?, type=?, resource_zip_url=?,
             submission_status=?, update_time=${nowExpr} WHERE id=?`,
            [name || '', packageName || '', categorySingle, description || '', icon || '',
             iconBgColor || '#00BFA5',
             version || '1.0.0', versionCode || '100', sizeMb || 0, downloadUrl || '', ss, tg,
             ot,
             vt, ha, rn, hpc, free,
             price_type || 'free', Number(price_amount || 0),
             submissionType, resourceZipUrl || '',
             status, id]
        )
         // 当状态变为 draft 或 pending 时（需要重新审核），将 app_store 下架
         if (existing[0].app_id && existing[0].app_id > 0 && (status === 'draft' || status === 'pending') && existing[0].submission_status === 'approved') {
           await query(`UPDATE app_store SET status='0', update_time=${nowExpr} WHERE id=?`, [existing[0].app_id])
         }
          // 已通过状态下编辑，同步更新 app_store（仅 APK 类型）
          if (existing[0].app_id && existing[0].app_id > 0 && status !== 'draft' && status !== 'pending' && submissionType !== 'zip') {
          await query(
            `UPDATE app_store SET name=?, package_name=?, category=?, description=?, icon=?,
             version=?, version_code=?, size_mb=?, download_url=?, screenshots=?, tags=?,
             official_tags=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?,
             price_type=?, price_amount=?, update_time=${nowExpr} WHERE id=?`,
            [name || '', packageName || '', categorySingle, description || '', icon || '',
             version || '1.0.0', versionCode || '100', sizeMb || 0, downloadUrl || '', ss, tg,
             ot,
             ha, rn, hpc, free,
             price_type || 'free', Number(price_amount || 0), existing[0].app_id]
          )
        }
        const msg = status === 'draft' ? '保存成功，提交后将重新审核' : '保存成功'
        res.json({ code: 200, msg, data: { id } })
      } else {
        const result = await query(
          `INSERT INTO app_uploads (user_id, user_name, name, package_name, category, description,
           icon, icon_bg_color, version, version_code, size_mb, download_url, screenshots, tags,
           official_tags, version_type, has_ads, requires_network, has_paid_content, is_free,
           price_type, price_amount, type, resource_zip_url, submission_status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [userId || 0, userName || '', name, packageName || '', categorySingle,
           description || '', icon || '', iconBgColor || '#00BFA5',
           version || '1.0.0', versionCode || '100',
           sizeMb || 0, downloadUrl || '', ss, tg,
           ot,
           vt, ha, rn, hpc, free,
           price_type || 'free', Number(price_amount || 0),
           submissionType, resourceZipUrl || '', status]
        )
        res.json({ code: 200, msg: '保存成功', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/submission/:id/submit — 提交审核
  router.post('/api/submission/:id/submit', async (req, res) => {
    try {
      const sessionUserId = getUserIdFromSession(req)
      const existing = await query('SELECT id, submission_status, user_id, name FROM app_uploads WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) {
        return res.json({ code: 404, msg: '投稿不存在' })
      }
      if (sessionUserId && existing[0].user_id !== sessionUserId && !isAdmin(req)) {
        return res.json({ code: 403, msg: '无权提交他人投稿' })
      }
      const currentStatus = existing[0].submission_status
      if (currentStatus !== 'draft' && currentStatus !== 'rejected') {
        return res.json({ code: 400, msg: '当前状态不允许提交审核' })
      }
      await query(
        `UPDATE app_uploads SET submission_status='pending', update_time=${nowExpr} WHERE id=?`,
        [req.params.id]
      )
      if (existing[0].user_id > 0) {
        const sysOp = await getSystemOperator()
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,?,?,?,?,'')`,
          ['应用已提交审核', `您的应用《${existing[0].name}》已提交审核，请耐心等待`, 'app_pending', existing[0].user_id, sysOp ? sysOp.id : 0, sysOp ? (sysOp.username || '系统') : '系统']
        ).catch(() => {})
      }
      res.json({ code: 200, msg: '已提交审核', data: { id: req.params.id } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // PUT /api/submission/:id/status — 审核操作 (管理员) / 上架下架 (上传者)
  router.put('/api/submission/:id/status', async (req, res) => {
    try {
      const { submissionStatus, reviewComment, reviewBy } = req.body
      const sessionUserId = getUserIdFromSession(req)
      const isAdminUser = isAdmin(req)

      const validStatuses = ['approved', 'rejected', 'removed', 'deleted', 'draft']
      if (!validStatuses.includes(submissionStatus)) {
        return res.json({ code: 400, msg: '无效的状态值' })
      }

      const existing = await query('SELECT id, submission_status, app_id, user_id, package_name, type FROM app_uploads WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) {
        return res.json({ code: 404, msg: '投稿不存在' })
      }

      const isOwner = sessionUserId && sessionUserId === existing[0].user_id

      // 管理员可审批/拒绝；上传者仅可下架/删除/重新上架自己的投稿
      if (submissionStatus === 'removed' || submissionStatus === 'deleted' || submissionStatus === 'draft') {
        if (!isAdminUser && !isOwner) {
          return res.json({ code: 403, msg: '无权限操作' })
        }
      } else if (submissionStatus === 'approved') {
        const currentStatus = existing[0].submission_status
        if (currentStatus === 'removed') {
          if (!isAdminUser && !isOwner) {
            return res.json({ code: 403, msg: '无权限操作' })
          }
        } else if (currentStatus !== 'pending') {
          return res.json({ code: 400, msg: '只有审核中的投稿可以批准' })
        } else if (!isAdminUser) {
          return res.json({ code: 403, msg: '无审核权限' })
        }
      } else {
        if (!isAdminUser) {
          return res.json({ code: 403, msg: '无审核权限' })
        }
      }

      const currentStatus = existing[0].submission_status

      await query(
        `UPDATE app_uploads SET submission_status=?, review_comment=?, review_by=?, 
         review_time=${nowExpr}, update_time=${nowExpr} WHERE id=?`,
        [submissionStatus, reviewComment || '', reviewBy || '', req.params.id]
      )

      // 下架：禁用 app_store
      if (submissionStatus === 'removed') {
        if (existing[0].app_id && existing[0].app_id > 0) {
          await query(`UPDATE app_store SET status='0' WHERE id=?`, [existing[0].app_id])
        }
        if (existing[0].user_id) {
          executePenalty(existing[0].user_id, '', 'app_takedown', { reason: '应用因违规被下架' })
        }
      }

      // 删除：清理关联文件
      if (submissionStatus === 'deleted') {
        if (existing[0].app_id) deleteFileRecordsByRef(existing[0].app_id, 'app').catch(() => {})
        deleteFileRecordsByRef(req.params.id, 'submission').catch(() => {})
        if (existing[0].user_id) {
          executePenalty(existing[0].user_id, '', 'app_deleted', { reason: '应用因违规被删除' })
        }
      }

      // 批准时同步更新 app_store (仅 APK 类型)
      if (submissionStatus === 'approved') {
        const sub = existing[0]
        if (sub.type === 'zip') {
          // ZIP 类型不上架 app_store，直接通知
          if (sub.user_id && sub.user_id > 0) {
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES (?, ?, 'system', ?, ?, ?, '')`,
              ['资源审核通过', `您的资源《${sub.name || ''}》已通过审核`, sub.user_id, sessionUserId || 0, reviewBy || '管理员']
            )
          }
        } else {
        const upload = await query(
          `SELECT name, package_name, category, description, icon, version, version_code,
                  size_mb, download_url, screenshots, tags, official_tags,
                  has_ads, requires_network, has_paid_content, is_free,
                  price_type, price_amount,
                  downloads, rating,
                  coin_count, coin_people, review_count, five_star_count, user_id, user_name
           FROM app_uploads WHERE id=?`, [req.params.id]
        )
        if (upload && upload.length > 0) {
          const u = upload[0]
          let storeEntry = null
          if (sub.app_id && sub.app_id > 0) {
            storeEntry = await query('SELECT id FROM app_store WHERE id=?', [sub.app_id])
          }
          if (!storeEntry || storeEntry.length === 0) {
            storeEntry = await query('SELECT id FROM app_store WHERE package_name=? AND status=?', [u.package_name, '1'])
          }
          const storeId = (storeEntry && storeEntry.length > 0) ? storeEntry[0].id : 0

          let result = null

          if (storeId > 0) {
        await query(
            `UPDATE app_uploads SET name=?, package_name=?, category=?, description=?, icon=?,
             icon_bg_color=?, version=?, version_code=?, size_mb=?, download_url=?, screenshots=?, tags=?,
             official_tags=?, version_type=?, has_ads=?, requires_network=?, has_paid_content=?, is_free=?,
             price_type=?, price_amount=?, type=?, resource_zip_url=?,
             submission_status=?, update_time=${nowExpr} WHERE id=?`,
            [name || '', packageName || '', categorySingle, description || '', icon || '',
             iconBgColor || '#00BFA5',
             version || '1.0.0', versionCode || '100', sizeMb || 0, downloadUrl || '', ss, tg,
             ot,
             vt, ha, rn, hpc, free,
             price_type || 'free', Number(price_amount || 0),
             submissionType, resourceZipUrl || '',
             status, id]
        )
            await query('UPDATE app_uploads SET app_id=? WHERE id=?', [storeId, req.params.id])
          } else {
            const result = await query(
              `INSERT INTO app_store (name, package_name, category, description, icon,
               version, version_code, size_mb, download_url, screenshots, tags, official_tags,
               has_ads, requires_network, has_paid_content, is_free,
               price_type, price_amount,
               downloads, rating, coin_count, coin_people, user_id, developer, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'1')`,
              [u.name, u.package_name, u.category, u.description, u.icon,
               u.version, u.version_code, u.size_mb, u.download_url, u.screenshots || '[]', u.tags || '[]', u.official_tags || '[]',
               u.has_ads, u.requires_network, u.has_paid_content, u.is_free,
               u.price_type || 'free', u.price_amount || 0,
               u.downloads, u.rating, u.coin_count, u.coin_people, u.user_id, u.user_name]
            )
            await query('UPDATE app_uploads SET app_id=? WHERE id=?', [result.insertId, req.params.id])
          }

          const finalStoreId = storeId || (result ? result.insertId : 0)
          const existingVer = await query('SELECT id FROM app_versions WHERE app_id=? AND version=?', [finalStoreId, u.version])
          if (existingVer && existingVer.length > 0) {
            await query('UPDATE app_versions SET is_current=0 WHERE app_id=?', [finalStoreId])
            await query(
               `UPDATE app_versions SET size_mb=?, downloads=?, rating=?, tags=?, download_url=?, user_id=?, user_name=?,
                description=?, screenshots=?, is_current=1
                WHERE app_id=? AND version=?`,
               [u.size_mb, u.downloads, u.rating, u.tags || '[]', u.download_url || '', u.user_id, u.user_name,
                u.description || '', u.screenshots || '[]', finalStoreId, u.version]
            )
          } else {
            await query('UPDATE app_versions SET is_current=0 WHERE app_id=?', [finalStoreId])
            await query(
               `INSERT INTO app_versions (app_id, version, version_code, size_mb, downloads, rating, tags, download_url, update_content, user_id, user_name, description, screenshots, is_current)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
               [finalStoreId, u.version, u.version_code, u.size_mb, u.downloads, u.rating,
                u.tags || '[]', u.download_url || '', '', u.user_id, u.user_name, u.description || '', u.screenshots || '[]', 1]
            )
          }

          // Get the actual operator info (admin or owner)
          const actorId = sessionUserId || 0
          let actorName = reviewBy || ''
          if (actorId > 0) {
            const actorInfo = await query('SELECT username FROM users WHERE id=?', [actorId])
            if (actorInfo && actorInfo.length > 0) {
              actorName = actorInfo[0].username || actorName
            }
          }

          if (u.user_id && u.user_id > 0) {
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES (?, ?, 'system', ?, ?, ?, '')`,
              ['应用审核通过', `您的应用《${u.name}》已通过审核，现在可以在应用商店中查看了`, u.user_id, actorId, actorName || '管理员']
            )
          }
        }
        }
      }

      // 记录审核日志
      if (submissionStatus === 'approved' || submissionStatus === 'rejected') {
        try {
          const action = submissionStatus === 'approved' ? 'manual_approve' : 'manual_reject'
          const reason = submissionStatus === 'rejected' ? (reviewComment || '管理员驳回') : '审核通过'
          await query(
            `INSERT INTO moderation_log (target_type, target_id, action, reason, rule_name, moderator_type, old_status, new_status, operator_id, create_time)
             VALUES ('app',?,'${action}',?,'manual_review','manual','pending','${submissionStatus}',?,NOW())`,
            [req.params.id, reason, sessionUserId || 1]
          )
        } catch (e) { console.error('[submission] moderation_log write error:', e.message) }
      }

      // 通知用户审核结果（拒绝/下架）
      if (submissionStatus === 'rejected' || submissionStatus === 'removed') {
        const sub = existing[0]
        if (sub.user_id && sub.user_id > 0) {
          // Get the actual operator info (admin or owner)
          const actorId = sessionUserId || 0
          let actorName = reviewBy || ''
          if (actorId > 0) {
            const actorInfo = await query('SELECT username FROM users WHERE id=?', [actorId])
            if (actorInfo && actorInfo.length > 0) {
              actorName = actorInfo[0].username || actorName
            }
          }

          const subData = await query('SELECT name FROM app_uploads WHERE id=?', [req.params.id])
          const appName = (subData && subData.length > 0) ? subData[0].name : ''
          const reason = reviewComment ? `。原因：${reviewComment}` : ''
          if (submissionStatus === 'rejected') {
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES (?, ?, 'system', ?, ?, ?, '')`,
              ['应用审核未通过', `您的应用《${appName}》审核未通过${reason}`, sub.user_id, actorId, actorName || '管理员']
            )
          } else {
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
               VALUES (?, ?, 'system', ?, ?, ?, '')`,
              ['应用已下架', `您的应用《${appName}》已被下架${reason}`, sub.user_id, actorId, actorName || '管理员']
            )
          }
        }
      }

      logFromReq(req, 'update', 'submission', req.params.id, `审核投稿ID:${req.params.id} ${submissionStatus === 'approved' ? '通过' : submissionStatus === 'rejected' ? '拒绝' : '下架'}${reviewComment ? '(' + reviewComment + ')' : ''}`)

      res.json({ code: 200, msg: '操作成功', data: { id: req.params.id } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/submission/:id — 删除投稿
  router.delete('/api/submission/:id', async (req, res) => {
    try {
      const sessionUserId = getUserIdFromSession(req)
      if (!sessionUserId && !isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const isAdminUser = isAdmin(req)
      const existing = await query('SELECT id, app_id, user_id FROM app_uploads WHERE id=?', [req.params.id])
      if (!existing || existing.length === 0) {
        return res.json({ code: 404, msg: '投稿不存在' })
      }
      if (!isAdminUser && existing[0].user_id !== sessionUserId) return res.json({ code: 403, msg: '无权限删除他人投稿' })
      if (existing[0].app_id) deleteFileRecordsByRef(existing[0].app_id, 'app').catch(() => {})
      await query('DELETE FROM app_uploads WHERE id=?', [req.params.id])
      deleteFileRecordsByRef(req.params.id, 'submission').catch(() => {})
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 2. 投稿草稿管理 ==========
  router.get('/api/submission/drafts', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 20 } = req.query
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const [list, countRows] = await Promise.all([
        query(
          `SELECT id, app_id as appId, user_id as userId, user_name as userName,
                  name, package_name as packageName, category, description, icon,
                  version, type, submission_status as submissionStatus,
                  review_comment as reviewComment, create_time as createTime, update_time as updateTime
           FROM app_uploads WHERE user_id=? AND submission_status='draft'
           ORDER BY update_time DESC LIMIT ? OFFSET ?`,
          [Number(userId), Number(pageSize), offset]
        ),
        query("SELECT COUNT(*) as total FROM app_uploads WHERE user_id=? AND submission_status='draft'", [Number(userId)])
      ])
      res.json({ code: 200, msg: 'success', data: {
        list, total: countRows[0]?.total || 0, page: parseInt(page), pageSize: parseInt(pageSize)
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/submission/drafts', async (req, res) => {
    try {
      const { userId, ids } = req.body
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      let where = "user_id=? AND submission_status='draft'"
      const params = [Number(userId)]
      if (ids && Array.isArray(ids) && ids.length > 0) {
        where += ` AND id IN (${ids.map(() => '?').join(',')})`
        params.push(...ids.map(Number))
      }
      const toDelete = await query(`SELECT id, app_id FROM app_uploads WHERE ${where}`, params)
      for (const d of toDelete) {
        if (d.app_id) deleteFileRecordsByRef(d.app_id, 'app').catch(() => {})
        deleteFileRecordsByRef(d.id, 'submission').catch(() => {})
      }
      await query(`DELETE FROM app_uploads WHERE ${where}`, params)
      res.json({ code: 200, msg: '草稿已删除', data: { count: toDelete.length } })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = submissionRoutes
