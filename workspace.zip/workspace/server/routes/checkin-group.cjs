const { query } = require('../database.cjs')
const { systemLog } = require('../middleware/security.cjs')
const { emitSafe, CHECKIN_EVENTS } = require('../plugins/events.cjs')
const { authRequired } = require('./system.cjs')
const nowExpr = 'NOW()'

function safeJsonParse(s, fallback = {}) {
  if (!s) return fallback
  try { return typeof s === 'string' ? JSON.parse(s) : s } catch { return fallback }
}

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function getUserInfo(req) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
    if (!token) return { userId: 0, userName: '' }
    const { sessions } = require('./system.cjs')
    const session = sessions.get(token)
    if (session) return { userId: session.userId, userName: session.userName }
  } catch {}
  return { userId: 0, userName: '' }
}

function checkinGroupRoutes(router) {
  // ==================== 签到分组 ====================

  router.get('/api/operation/checkin-group/list', authRequired, adminRequired, async (req, res) => {
    try {
      const records = await query(
        `SELECT cg.id, cg.name, cg.level_id as levelId, cg.icon, cg.icon_color as iconColor,
                cg.points, cg.experience, cg.balance,
                cg.points_consecutive as pointsConsecutive,
                cg.experience_consecutive as experienceConsecutive,
                cg.balance_consecutive as balanceConsecutive,
                cg.makeup_points_cost as makeupPointsCost,
                cg.makeup_balance_cost as makeupBalanceCost,
                cg.reward_config, cg.makeup_config,
                cg.sort_order as sortOrder, cg.status,
                cg.create_time as createTime, cg.update_time as updateTime,
                ml.name as levelName
         FROM checkin_groups cg
         LEFT JOIN membership_levels ml ON cg.level_id = ml.id
         ORDER BY cg.sort_order ASC, cg.id ASC`
      )
      for (const r of records) {
        r.rewardConfig = safeJsonParse(r.reward_config)
        r.makeupConfig = safeJsonParse(r.makeup_config)
      }
      res.json({ code: 200, msg: 'success', data: { records, current: 1, size: 100, total: records.length } })
    } catch (e) {
      console.error('签到分组查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/checkin-group/save', authRequired, adminRequired, async (req, res) => {
    try {
      const { id, name, levelId, icon, iconColor,
              rewardConfig, makeupConfig,
              sortOrder, status } = req.body

      // 从 rewardConfig JSON 提取旧列值保持同步
      const rc = rewardConfig && typeof rewardConfig === 'object' ? rewardConfig : safeJsonParse(rewardConfig)
      const base = rc.base || {}
      const cons = rc.consecutive || {}
      const points = Number(base.points) || 0
      const experience = Number(base.experience) || 0
      const balance = Number(base.balance) || 0
      const pointsConsecutive = Number(cons.points) || 0
      const experienceConsecutive = Number(cons.experience) || 0
      const balanceConsecutive = Number(cons.balance) || 0

      const mc = makeupConfig && typeof makeupConfig === 'object' ? makeupConfig : safeJsonParse(makeupConfig)
      const makeupPointsCost = Number(mc.points) || 0
      const makeupBalanceCost = Number(mc.balance) || 0

      const rcJson = JSON.stringify(rc)
      const mcJson = JSON.stringify(mc)

      if (name && name.length > 100) return res.json({ code: 400, msg: '分组名称不能超过 100 字符' })

      if (id) {
        await query(
          `UPDATE checkin_groups SET name=?, level_id=?, icon=?, icon_color=?, points=?, experience=?, balance=?,
           points_consecutive=?, experience_consecutive=?, balance_consecutive=?,
           makeup_points_cost=?, makeup_balance_cost=?,
           reward_config=?, makeup_config=?,
           sort_order=?, status=?, update_time=${nowExpr} WHERE id=?`,
          [name, Number(levelId) || 0, icon || '', iconColor || '#409EFF',
           points, experience, balance,
           pointsConsecutive, experienceConsecutive, balanceConsecutive,
           makeupPointsCost, makeupBalanceCost,
           rcJson, mcJson,
           Number(sortOrder) || 0, status || '1', Number(id)]
        )
        const { userId, userName } = getUserInfo(req)
        systemLog('update', userId, userName, 'checkin_group', Number(id), `更新签到规则《${name}》`)
        emitSafe(CHECKIN_EVENTS.GROUP_SAVED, { groupId: Number(id), name, action: 'update' })
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO checkin_groups (name, level_id, icon, icon_color, points, experience, balance,
           points_consecutive, experience_consecutive, balance_consecutive,
           makeup_points_cost, makeup_balance_cost,
           reward_config, makeup_config, sort_order, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [name, Number(levelId) || 0, icon || '', iconColor || '#409EFF',
           points, experience, balance,
           pointsConsecutive, experienceConsecutive, balanceConsecutive,
           makeupPointsCost, makeupBalanceCost,
           rcJson, mcJson,
           Number(sortOrder) || 0, status || '1']
        )
        const newId = result.insertId
        const { userId, userName } = getUserInfo(req)
        systemLog('create', userId, userName, 'checkin_group', newId, `新建签到规则《${name}》`)
        emitSafe(CHECKIN_EVENTS.GROUP_SAVED, { groupId: newId, name, action: 'create' });
        res.json({ code: 200, msg: '添加成功', data: { id: newId } })
      }
    } catch (e) {
      console.error('保存签到分组失败:', e.message)
      res.json({ code: 500, msg: '保存失败' })
    }
  })

  router.delete('/api/operation/checkin-group/:id', authRequired, adminRequired, async (req, res) => {
    try {
      const id = Number(req.params.id)
      const before = await query('SELECT name FROM checkin_groups WHERE id=?', [id])
      const groupName = before[0]?.name || id
      await query('DELETE FROM checkin_milestones WHERE group_id = ?', [id])
      await query('DELETE FROM checkin_groups WHERE id = ?', [id])
      const { userId, userName } = getUserInfo(req)
      systemLog('delete', userId, userName, 'checkin_group', id, `删除签到规则《${groupName}》`)
      emitSafe(CHECKIN_EVENTS.GROUP_DELETED, { groupId: id, name: groupName })
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      console.error('删除签到分组失败:', e.message)
      res.json({ code: 500, msg: '删除失败' })
    }
  })

  // ==================== 阶梯奖励 ====================

  router.get('/api/operation/checkin-milestone/list', authRequired, adminRequired, async (req, res) => {
    try {
      const { groupId } = req.query
      let records = []
      if (groupId) {
        records = await query(
          `SELECT * FROM checkin_milestones WHERE group_id=? ORDER BY days ASC, sort_order ASC`,
          [Number(groupId)]
        )
      } else {
        records = await query(
          `SELECT cm.*, cg.name as group_name FROM checkin_milestones cm
           LEFT JOIN checkin_groups cg ON cm.group_id = cg.id
           ORDER BY cm.group_id, cm.days ASC`
        )
      }
      res.json({ code: 200, msg: 'success', data: { records, total: records.length } })
    } catch (e) {
      console.error('阶梯奖励查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败' })
    }
  })

  router.post('/api/operation/checkin-milestone/save', authRequired, adminRequired, async (req, res) => {
    try {
      const { id, groupId, days, points, experience, balance,
              rewardConfig,
              makeupCount,
              cardKeyType, cardKeyValue, cardKeyDuration, cardKeyDurationUnit,
              cardKeyExtraPoints, cardKeyExtraExperience, cardKeyExtraBalance,
              sortOrder, status } = req.body

      const rc = rewardConfig && typeof rewardConfig === 'object' ? rewardConfig : safeJsonParse(rewardConfig)
      const currencies = rc.currencies || {}
      const pts = Number(points) || Number(currencies.points) || 0
      const exp = Number(experience) || Number(currencies.experience) || 0
      const bal = Number(balance) || Number(currencies.balance) || 0
      if (!rc.currencies || Object.keys(rc.currencies).length === 0) {
        rc.currencies = { points: pts, experience: exp, balance: bal }
      }
      const rcJson = JSON.stringify(rc)

      const ckType = cardKeyType || rc.cardKey?.type || ''
      const ckVal = Number(cardKeyValue) || Number(rc.cardKey?.value) || 0
      const ckDur = Number(cardKeyDuration) || Number(rc.cardKey?.duration) || 0
      const ckDurUnit = cardKeyDurationUnit || rc.cardKey?.durationUnit || ''
      const ckExtraPts = Number(cardKeyExtraPoints) || Number(rc.cardKey?.extras?.points) || 0
      const ckExtraExp = Number(cardKeyExtraExperience) || Number(rc.cardKey?.extras?.experience) || 0
      const ckExtraBal = Number(cardKeyExtraBalance) || Number(rc.cardKey?.extras?.balance) || 0

      if (id) {
        await query(
          `UPDATE checkin_milestones SET group_id=?, days=?, points=?, experience=?, balance=?,
           reward_config=?,
           makeup_count=?,
           card_key_type=?, card_key_value=?, card_key_duration=?, card_key_duration_unit=?,
           card_key_extra_points=?, card_key_extra_experience=?, card_key_extra_balance=?,
           sort_order=?, status=? WHERE id=?`,
          [Number(groupId) || 0, Number(days) || 0, pts, exp, bal,
           rcJson,
           Number(makeupCount) || 0,
           ckType, ckVal, ckDur, ckDurUnit,
           ckExtraPts, ckExtraExp, ckExtraBal,
           Number(sortOrder) || 0, status || '1', Number(id)]
        )
        const { userId: uidMs, userName: unameMs } = getUserInfo(req)
        systemLog('update', uidMs, unameMs, 'checkin_milestone', Number(id), `更新阶梯奖励(第${days}天)`)
        emitSafe(CHECKIN_EVENTS.MILESTONE_SAVED, { milestoneId: Number(id), groupId: Number(groupId), days: Number(days), action: 'update' })
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO checkin_milestones (group_id, days, points, experience, balance,
           reward_config,
           makeup_count,
           card_key_type, card_key_value, card_key_duration, card_key_duration_unit,
           card_key_extra_points, card_key_extra_experience, card_key_extra_balance, sort_order, status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [Number(groupId) || 0, Number(days) || 0, pts, exp, bal,
           rcJson,
           Number(makeupCount) || 0,
           ckType, ckVal, ckDur, ckDurUnit,
           ckExtraPts, ckExtraExp, ckExtraBal,
           Number(sortOrder) || 0, status || '1']
        )
        const newMsId = result.insertId
        const { userId: uidMs, userName: unameMs } = getUserInfo(req)
        systemLog('create', uidMs, unameMs, 'checkin_milestone', newMsId, `新增阶梯奖励(第${days}天)`)
        emitSafe(CHECKIN_EVENTS.MILESTONE_SAVED, { milestoneId: newMsId, groupId: Number(groupId), days: Number(days), action: 'create' })
        res.json({ code: 200, msg: '添加成功', data: { id: newMsId } })
      }
    } catch (e) {
      console.error('保存阶梯奖励失败:', e.message)
      res.json({ code: 500, msg: '保存失败' })
    }
  })

  router.delete('/api/operation/checkin-milestone/:id', authRequired, adminRequired, async (req, res) => {
    try {
      const id = Number(req.params.id)
      const before = await query('SELECT days, group_id FROM checkin_milestones WHERE id=?', [id])
      const detail = before.length > 0 ? `删除阶梯奖励(第${before[0].days}天)` : `删除阶梯奖励(id=${id})`
      await query('DELETE FROM checkin_milestones WHERE id=?', [id])
      const { userId, userName } = getUserInfo(req)
      systemLog('delete', userId, userName, 'checkin_milestone', id, detail)
      emitSafe(CHECKIN_EVENTS.MILESTONE_DELETED, { milestoneId: id })
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.json({ code: 500, msg: '删除失败' })
    }
  })
}

module.exports = checkinGroupRoutes
