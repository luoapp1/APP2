const { query } = require('../database.cjs')

function getDateRange(period) {
  const now = new Date()
  switch (period) {
    case 'week': {
      const start = new Date(now)
      start.setDate(start.getDate() - start.getDay())
      start.setHours(0, 0, 0, 0)
      return { start: start.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) }
    }
    case 'month': {
      const start = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`
      return { start, end: now.toISOString().slice(0, 10) }
    }
    case 'year': {
      const start = `${now.getFullYear()}-01-01`
      return { start, end: now.toISOString().slice(0, 10) }
    }
    default: return null
  }
}

module.exports = function (app) {
  app.get('/api/ranking/:type', async (req, res) => {
    try {
      const { type } = req.params
      const pageSize = parseInt(req.query.pageSize) || 50
      const currentUserId = parseInt(req.query.userId) || 0
      const period = req.query.period || 'all'
      const dateRange = getDateRange(period)
      let sql = ''
      let params = []

      switch (type) {
        case 'apps':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COUNT(ast.id) AS count
            FROM users u
            INNER JOIN app_store ast ON ast.user_id = u.id
            WHERE ast.status = '1' AND u.status = '1'
            ${dateRange ? 'AND ast.create_time >= ?' : ''}
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          if (dateRange) params.push(dateRange.start)
          break
        case 'posts':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COUNT(cp.id) AS count
            FROM users u
            INNER JOIN community_posts cp ON cp.user_id = u.id
            WHERE cp.status = 'published' AND u.status = '1'
            ${dateRange ? 'AND cp.create_time >= ?' : ''}
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          if (dateRange) params.push(dateRange.start)
          break
        case 'experience':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   u.experience AS count,
                   el.icon AS level_icon
            FROM users u
            LEFT JOIN experience_levels el ON el.level = (
              SELECT MAX(el2.level) FROM experience_levels el2
              WHERE el2.exp_required <= u.experience AND el2.status = '1'
            )
            WHERE u.status = '1'
            ORDER BY u.experience DESC
            LIMIT ${pageSize}
          `
          break
        case 'points':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   u.points AS count
            FROM users u
            WHERE u.status = '1'
            ORDER BY u.points DESC
            LIMIT ${pageSize}
          `
          break
        case 'donations':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COALESCE(SUM(br.amount), 0) AS count
            FROM users u
            LEFT JOIN balance_records br ON br.user_id = u.id AND br.type = 'earn'
            WHERE u.status = '1'
            ${dateRange ? 'AND br.create_time >= ?' : ''}
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          if (dateRange) params.push(dateRange.start)
          break
        case 'favorites':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COALESCE(SUM(fav_count), 0) AS count
            FROM users u
            LEFT JOIN (
              SELECT user_id, COUNT(*) as fav_count FROM post_favorites
              ${dateRange ? 'WHERE create_time >= ?' : ''}
              GROUP BY user_id
            ) pf ON pf.user_id = u.id
            WHERE u.status = '1'
            GROUP BY u.id
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          if (dateRange) params.push(dateRange.start)
          break
        case 'active-users':
          sql = `
            SELECT u.id AS user_id, u.username, u.nickname, u.avatar,
                   COALESCE(post_cnt, 0) + COALESCE(comment_cnt, 0) AS count
            FROM users u
            LEFT JOIN (
              SELECT user_id, COUNT(*) as post_cnt FROM community_posts
              WHERE status IN ('published','reviewed')
              ${dateRange ? 'AND create_time >= ?' : ''}
              GROUP BY user_id
            ) p ON p.user_id = u.id
            LEFT JOIN (
              SELECT user_id, COUNT(*) as comment_cnt FROM community_comments
              WHERE is_deleted=0 ${dateRange ? 'AND create_time >= ?' : ''}
              GROUP BY user_id
            ) c ON c.user_id = u.id
            WHERE u.status = '1'
            ORDER BY count DESC
            LIMIT ${pageSize}
          `
          if (dateRange) { params.push(dateRange.start); params.push(dateRange.start) }
          break
        default:
          return res.json({ code: 400, msg: '不支持的排行榜类型', data: null })
      }

      const [cachedRows, rows] = await Promise.all([
        (async () => {
          try {
            const [cache] = await query(
              'SELECT data FROM ranking_cache WHERE type=? AND period=? AND updated_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)',
              [type, period]
            )
            if (cache && cache.data) return typeof cache.data === 'string' ? JSON.parse(cache.data) : cache.data
          } catch {}
          return null
        })(),
        query(sql, params)
      ])
      const resultRows = cachedRows || rows

      resultRows.forEach((r, i) => {
        r.rank = i + 1
        r.rankChange = 0
      })

      if (currentUserId > 0 && resultRows.length > 0) {
        const ids = resultRows.map((r) => r.user_id)
        const placeholders = ids.map(() => '?').join(',')
        const followed = await query(
          `SELECT following_id FROM user_follows WHERE follower_id = ? AND following_id IN (${placeholders})`,
          [currentUserId, ...ids]
        )
        const followedSet = new Set(followed.map((f) => f.following_id))
        resultRows.forEach((r) => {
          r.is_followed = followedSet.has(r.user_id) ? 1 : 0
        })
      }

      if (!cachedRows && rows.length > 0) {
        try {
          await query(
            'INSERT INTO ranking_cache (type, period, data, updated_at) VALUES (?,?,?,NOW()) ON DUPLICATE KEY UPDATE data=?, updated_at=NOW()',
            [type, period, JSON.stringify(rows), JSON.stringify(rows)]
          )
        } catch {}
      }

      res.json({ code: 200, msg: 'ok', data: { list: resultRows, period } })
    } catch (e) {
      console.error('排行榜查询失败:', e)
      res.json({ code: 500, msg: '查询失败', data: null })
    }
  })
}
