const { query, getPool } = require('../database.cjs')
const { earnCurrency } = require('./account-utils.cjs')
const crypto = require('crypto')
const { sessions, SESSION_TTL, authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      if (Date.now() - row.created_at > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, createdAt: row.created_at })
      return Number(row.user_id) || 0
    }
  } catch {}
  return 0
}

function now() { return 'NOW()' }

const nowExpr = 'NOW()'

function formatDateTime(d) {
  if (!d) return ''
  const dt = new Date(d)
  const pad = (n) => String(n).padStart(2, '0')
  return `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`
}

function addDays(date, days) {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function rechargeRoutes(app) {
  app.get('/api/recharge/amounts', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM recharge_amounts WHERE status=1 ORDER BY sort_order ASC, amount ASC')
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/recharge/payment-methods', async (_req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'payment_%'")
      const cfg = {}
      rows.forEach(r => { cfg[r.config_key] = r.config_value })

      const methods = []
      const epayConfigured = !!(cfg.payment_epay_pid && cfg.payment_epay_key && cfg.payment_epay_api_url)
      methods.push({ key: 'epay', name: '易支付', available: epayConfigured, hint: epayConfigured ? '' : '凭证未配置' })

      const wechatConfigured = !!(cfg.payment_wechat_app_id && cfg.payment_wechat_mch_id && cfg.payment_wechat_api_key)
      methods.push({ key: 'wechat', name: '微信支付', available: wechatConfigured, hint: wechatConfigured ? '' : '凭证未配置' })

      const alipayConfigured = !!(cfg.payment_alipay_app_id && cfg.payment_alipay_private_key && cfg.payment_alipay_public_key)
      methods.push({ key: 'alipay', name: '支付宝', available: alipayConfigured, hint: alipayConfigured ? '' : '凭证未配置' })

      res.json({ code: 200, data: methods })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/admin/recharge/amounts', authRequired, adminRequired, async (req, res) => {
    try {
      const { amounts } = req.body
      if (!Array.isArray(amounts)) return res.json({ code: 400, msg: '参数错误' })

      await query('DELETE FROM recharge_amounts')
      for (const a of amounts) {
        await query(
          `INSERT INTO recharge_amounts (amount, label, discount, status, gift_points, gift_experience, gift_balance, gift_coupon_ids, gift_title_id, gift_avatar_frame_id, gift_member_level_id, gift_member_days, first_only, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            Number(a.amount) || 0,
            a.label || '',
            a.discount || '',
            a.status !== 0 ? 1 : 0,
            Number(a.gift_points) || 0,
            Number(a.gift_experience) || 0,
            Number(a.gift_balance) || 0,
            a.gift_coupon_ids ? JSON.stringify(a.gift_coupon_ids) : null,
            Number(a.gift_title_id) || 0,
            Number(a.gift_avatar_frame_id) || 0,
            Number(a.gift_member_level_id) || 0,
            Number(a.gift_member_days) || 0,
            a.first_only ? 1 : 0,
            Number(a.sort_order) || 0
          ]
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/admin/payment-config', authRequired, adminRequired, async (req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'payment_%'")
      const config = {}
      rows.forEach(r => { config[r.config_key] = r.config_value })
      res.json({ code: 200, data: config })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/admin/payment-config', authRequired, adminRequired, async (req, res) => {
    try {
      const configs = req.body
      for (const [key, value] of Object.entries(configs)) {
        if (!key.startsWith('payment_')) continue
        const exist = await query("SELECT id FROM sys_config WHERE config_key=?", [key])
        if (exist.length > 0) {
          await query("UPDATE sys_config SET config_value=? WHERE config_key=?", [String(value), key])
        } else {
          await query("INSERT INTO sys_config (config_key, config_value) VALUES (?, ?)", [key, String(value)])
        }
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/recharge/create', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { amount, payMethod } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '金额无效' })
      if (!['alipay', 'wechat', 'epay'].includes(payMethod)) return res.json({ code: 400, msg: '支付方式无效' })

      const orderNo = 'RC' + Date.now() + Math.random().toString(36).slice(2, 8)

      const amountConfigs = await query('SELECT id FROM recharge_amounts WHERE amount=? AND status=1 LIMIT 1', [Number(amount)])
      const rechargeAmountId = amountConfigs.length > 0 ? amountConfigs[0].id : 0

      await query(
        `INSERT INTO recharge_orders (order_no, user_id, amount, pay_method, status, recharge_amount_id, create_time)
         VALUES (?, ?, ?, ?, 'pending', ?, ${nowExpr})`,
        [orderNo, userId, Number(amount), payMethod, rechargeAmountId]
      )

      const configs = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'payment_%'")
      const cfg = {}
      configs.forEach(r => { cfg[r.config_key] = r.config_value })

      let payUrl = ''
      if (payMethod === 'epay') {
        const pid = cfg.payment_epay_pid || ''
        const key = cfg.payment_epay_key || ''
        const apiUrl = cfg.payment_epay_api_url || ''
        const notifyUrl = cfg.payment_epay_notify_url || ''
        if (!pid || !key || !apiUrl) return res.json({ code: 400, msg: '易支付未配置' })

        const clientip = (req.ip || req.socket?.remoteAddress || '127.0.0.1').replace(/^::ffff:/, '')
        const params = {
          pid, type: 'alipay',
          out_trade_no: orderNo,
          notify_url: notifyUrl,
          return_url: notifyUrl,
          name: '余额充值',
          money: String(amount),
          clientip
        }
        const signKeys = Object.keys(params).filter(k => params[k] !== '' && params[k] !== undefined).sort()
        const signStr = signKeys.map(k => `${k}=${params[k]}`).join('&') + key
        params.sign = crypto.createHash('md5').update(signStr).digest('hex')
        params.sign_type = 'MD5'

        const qs = new URLSearchParams(params).toString()
        payUrl = `${apiUrl.replace(/\/+$/, '')}/submit.php?${qs}`
      } else if (payMethod === 'alipay') {
        payUrl = cfg.payment_alipay_app_id ? '/api/recharge/alipay/pay?orderNo=' + orderNo : ''
        if (!payUrl) return res.json({ code: 400, msg: '支付宝未配置' })
      } else if (payMethod === 'wechat') {
        payUrl = cfg.payment_wechat_app_id ? '/api/recharge/wechat/pay?orderNo=' + orderNo : ''
        if (!payUrl) return res.json({ code: 400, msg: '微信支付未配置' })
      }

      res.json({ code: 200, data: { orderNo, payUrl } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 模拟支付（开发测试用） ==========
  app.post('/api/recharge/simulate', async (req, res) => {
    try {
      const { orderNo, userId: directUserId, amount: directAmount, payMethod: directPayMethod } = req.body

      let order
      const conn = await getPool().promise().getConnection()

      if (directUserId && directAmount) {
        const orderNo2 = 'RC' + Date.now() + Math.random().toString(36).slice(2, 8)
        const amountConfigs = await conn.query('SELECT id FROM recharge_amounts WHERE amount=? AND status=1 LIMIT 1', [Number(directAmount)])
        const rechargeAmountId = amountConfigs[0] && amountConfigs[0].length > 0 ? amountConfigs[0][0].id : 0

        await conn.query(
          `INSERT INTO recharge_orders (order_no, user_id, amount, pay_method, status, recharge_amount_id, create_time)
           VALUES (?, ?, ?, ?, 'pending', ?, ${nowExpr})`,
          [orderNo2, Number(directUserId), Number(directAmount), directPayMethod || 'wechat', rechargeAmountId]
        )

        try {
          await conn.beginTransaction()
          const orders = await conn.query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending' FOR UPDATE", [orderNo2])
          if (orders[0].length === 0) {
            await conn.rollback()
            conn.release()
            return res.json({ code: 404, msg: '订单创建失败' })
          }
          order = orders[0][0]
          await conn.query(`UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?`,
            ['sim_' + Date.now(), orderNo2])

          const userRows = await conn.query('SELECT username FROM users WHERE id=?', [order.user_id])
          const userName = (userRows[0] && userRows[0][0]) ? userRows[0][0].username : ''

          await earnCurrency(order.user_id, userName, 'balance', Number(order.amount), 'recharge', orderNo2, '余额充值', conn)
          await processRechargeGifts(order, conn)
          await conn.commit()
          conn.release()

          return res.json({ code: 200, msg: '模拟充值成功', data: { orderNo: orderNo2, amount: order.amount, userId: order.user_id } })
        } catch (e) {
          await conn.rollback()
          conn.release()
          throw e
        }
      }

      if (!orderNo) return res.json({ code: 400, msg: '缺少订单号' })

      try {
        await conn.beginTransaction()

        const orders = await conn.query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending' FOR UPDATE", [orderNo])
        if (orders[0].length === 0) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 404, msg: '订单不存在或已处理' })
        }

        order = orders[0][0]
        await conn.query(`UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?`,
          ['sim_' + Date.now(), orderNo])

        const userRows = await conn.query('SELECT username FROM users WHERE id=?', [order.user_id])
        const userName = (userRows[0] && userRows[0][0]) ? userRows[0][0].username : ''

        await earnCurrency(order.user_id, userName, 'balance', Number(order.amount), 'recharge', orderNo, '余额充值', conn)
        await processRechargeGifts(order, conn)

        await conn.commit()
        conn.release()

        res.json({ code: 200, msg: '模拟充值成功', data: { orderNo, amount: order.amount } })
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
    } catch (e) {
      console.error('[simulate] 模拟充值失败:', e)
      res.json({ code: 500, msg: e.message })
    }
  })

  // ========== 支付成功后的赠送引擎 ==========
  async function processRechargeGifts(order, conn) {
    const rechargeAmountId = order.recharge_amount_id || 0
    if (!rechargeAmountId) return

    const configs = await conn.query('SELECT * FROM recharge_amounts WHERE id=? AND status=1', [rechargeAmountId])
    if (!configs[0] || !configs[0].length) return
    const cfg = configs[0][0]
    const userId = order.user_id

    const userNameRows = await conn.query('SELECT username FROM users WHERE id=?', [userId])
    const userName = (userNameRows[0] && userNameRows[0][0]) ? userNameRows[0][0].username : ''
    const orderNo = order.order_no
    const sourceType = 'recharge_gift'
    const sourceId = orderNo

    const isFirstOnly = cfg.first_only === 1
    if (isFirstOnly) {
      const paidCount = await conn.query(
        "SELECT COUNT(*) as cnt FROM recharge_orders WHERE user_id=? AND status='paid' AND id != ?",
        [userId, order.id]
      )
      const paidOrders = paidCount[0] && paidCount[0][0] ? Number(paidCount[0][0].cnt) : 0
      if (paidOrders > 0) return
    }

    const giftDetails = []

    if (cfg.gift_balance > 0) {
      await earnCurrency(userId, userName, 'balance', Number(cfg.gift_balance), sourceType, sourceId, '充值赠送余额', conn)
      giftDetails.push(`赠送余额 ${Number(cfg.gift_balance).toFixed(2)}`)
    }

    if (cfg.gift_points > 0) {
      await earnCurrency(userId, userName, 'points', Number(cfg.gift_points), sourceType, sourceId, '充值赠送积分', conn)
      giftDetails.push(`赠送积分 ${cfg.gift_points}`)
    }

    if (cfg.gift_experience > 0) {
      await earnCurrency(userId, userName, 'experience', Number(cfg.gift_experience), sourceType, sourceId, '充值赠送经验', conn)
      giftDetails.push(`赠送经验 ${cfg.gift_experience}`)
    }

    let couponItems = []
    if (cfg.gift_coupon_ids) {
      try {
        couponItems = typeof cfg.gift_coupon_ids === 'string' ? JSON.parse(cfg.gift_coupon_ids) : cfg.gift_coupon_ids
      } catch { couponItems = [] }
    }
    if (Array.isArray(couponItems) && couponItems.length > 0) {
      for (const task of couponItems) {
        const cid = typeof task === 'object' && task !== null ? task.id : task
        const grantCount = typeof task === 'object' && task !== null ? (Number(task.count) || 1) : 1
        if (!cid) continue

        const couponRows = await conn.query('SELECT * FROM coupons WHERE id=? AND status=?', [cid, '1'])
        if (!couponRows[0] || !couponRows[0].length) continue
        const c = couponRows[0][0]

        let userExpireTime
        if (c.expire_type === 'fixed' && c.expire_time) {
          userExpireTime = formatDateTime(new Date(c.expire_time))
        } else if (c.valid_days > 0) {
          userExpireTime = formatDateTime(addDays(new Date(), c.valid_days))
        } else {
          userExpireTime = formatDateTime(addDays(new Date(), 30))
        }

        const couponData = JSON.stringify({
          name: c.name,
          type: c.type,
          value: Number(c.value),
          minOrder: Number(c.min_order),
          maxDiscount: Number(c.max_discount),
          scope: c.scope,
          targetIds: c.target_ids,
          category: c.category
        })

        if (c.is_multi_use) {
          const totalValue = Number(c.value) * grantCount
          await conn.query(
            `INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())`,
            [userId, c.id, 'unused', couponData, userExpireTime, totalValue]
          )
        } else {
          for (let i = 0; i < grantCount; i++) {
            await conn.query(
              `INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())`,
              [userId, c.id, 'unused', couponData, userExpireTime, null]
            )
          }
        }

        try {
          await conn.query('UPDATE coupons SET claimed_count = claimed_count + ? WHERE id=?', [grantCount, c.id])
        } catch {}
        giftDetails.push(`赠送优惠券: ${c.name} x${grantCount}`)
      }
    }

    if (cfg.gift_title_id > 0) {
      const existingTitle = await conn.query('SELECT id FROM user_titles WHERE user_id=? AND title_id=?', [userId, cfg.gift_title_id])
      if (!existingTitle[0] || !existingTitle[0].length) {
        await conn.query(
          'INSERT INTO user_titles (user_id, title_id, is_active, grant_by, grant_time) VALUES (?, ?, 1, ?, NOW())',
          [userId, cfg.gift_title_id, '充值赠送']
        )
        const titleNameRows = await conn.query('SELECT name FROM custom_titles WHERE id=?', [cfg.gift_title_id])
        const titleName = (titleNameRows[0] && titleNameRows[0][0]) ? titleNameRows[0][0].name : ''
        giftDetails.push(`赠送称号: ${titleName}`)
      }
    }

    if (cfg.gift_avatar_frame_id > 0) {
      const existingFrame = await conn.query('SELECT id FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, cfg.gift_avatar_frame_id])
      if (!existingFrame[0] || !existingFrame[0].length) {
        await conn.query(
          'INSERT INTO user_avatar_frames (user_id, frame_id, is_active, obtain_type, obtain_time) VALUES (?, ?, 0, ?, NOW())',
          [userId, cfg.gift_avatar_frame_id, 'recharge']
        )
        const frameNameRows = await conn.query('SELECT name FROM avatar_frames WHERE id=?', [cfg.gift_avatar_frame_id])
        const frameName = (frameNameRows[0] && frameNameRows[0][0]) ? frameNameRows[0][0].name : ''
        giftDetails.push(`赠送头像框: ${frameName}`)
      }
    }

    if (cfg.gift_member_days > 0 && cfg.gift_member_level_id > 0) {
      const levelRows = await conn.query('SELECT id, name FROM membership_levels WHERE id=? AND status=?', [cfg.gift_member_level_id, '1'])
      if (levelRows[0] && levelRows[0].length) {
        const level = levelRows[0][0]
        const existingMember = await conn.query(
          'SELECT id FROM user_memberships WHERE user_id=? AND level_id=? AND expire_time > NOW() ORDER BY expire_time DESC LIMIT 1',
          [userId, cfg.gift_member_level_id]
        )
        if (existingMember[0] && existingMember[0].length) {
          await conn.query(
            'UPDATE user_memberships SET expire_time = DATE_ADD(expire_time, INTERVAL ? DAY) WHERE id=?',
            [cfg.gift_member_days, existingMember[0][0].id]
          )
        } else {
          await conn.query(
            'INSERT INTO user_memberships (user_id, level_id, level_name, expire_time) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY))',
            [userId, level.id, level.name, cfg.gift_member_days]
          )
        }
        giftDetails.push(`赠送会员: ${level.name} ${cfg.gift_member_days}天`)

        const userRows = await conn.query('SELECT level_id, expire_time FROM users WHERE id=?', [userId])
        const userLevel = userRows[0] && userRows[0][0] ? userRows[0][0] : null
        if (!userLevel || !userLevel.level_id || new Date(userLevel.expire_time) < new Date()) {
          await conn.query('UPDATE users SET level_id=?, level_name=?, expire_time=DATE_ADD(IFNULL(expire_time, NOW()), INTERVAL ? DAY) WHERE id=?',
            [level.id, level.name, cfg.gift_member_days, userId])
        }
      }
    }

    if (giftDetails.length > 0) {
      const msg = giftDetails.join('；')
      try {
        await conn.query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, is_read, create_time) VALUES (?,?,?,?,0,NOW())`,
          ['充值赠送', `恭喜！你充值 ${order.amount} 元获得：${msg}`, 'system', userId]
        )
      } catch {}
      console.log(`[recharge-gift] user=${userId} order=${orderNo} gifts: ${msg}`)
    }
  }

  app.all('/api/recharge/callback/epay/return', async (req, res) => {
    res.send(`<html><body><script>window.location.href='/#/appstore/assets?recharge=success'</script></body></html>`)
  })

  app.all('/api/recharge/callback/epay/notify', async (req, res) => {
    try {
      const params = req.method === 'POST' ? req.body : req.query
      const { out_trade_no, trade_no, money, trade_status, sign, sign_type } = params
      if (!out_trade_no || trade_status !== 'TRADE_SUCCESS') return res.send('fail')

      const configs = await query("SELECT config_key, config_value FROM sys_config WHERE config_key='payment_epay_key'")
      const epayKey = configs[0]?.config_value || ''

      const signParams = { ...params }
      delete signParams.sign
      delete signParams.sign_type
      const signStr = Object.keys(signParams).sort().map(k => `${k}=${signParams[k]}`).join('&') + epayKey
      const mySign = crypto.createHash('md5').update(signStr).digest('hex')
      if (sign !== mySign) return res.send('sign error')

      const clientIp = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket?.remoteAddress || ''
      const whiteConfig = await query("SELECT config_value FROM sys_config WHERE config_key='payment_epay_ip_whitelist'")
      const whitelist = whiteConfig[0]?.config_value || ''
      const allowedIps = whitelist ? whitelist.split(',').map(s => s.trim()).filter(Boolean) : ['127.0.0.1', '::1', '::ffff:127.0.0.1']
      if (!allowedIps.some(ip => clientIp === ip || clientIp.includes(ip) || ip.includes(clientIp))) {
        console.error('[recharge] 回调来源IP不在白名单:', clientIp)
        return res.send('ip not allowed')
      }

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const orders = await conn.query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending' FOR UPDATE", [out_trade_no])
        if (orders[0].length === 0) {
          await conn.rollback()
          conn.release()
          return res.send('ok')
        }

        const order = orders[0][0]
        await conn.query(`UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?`, [trade_no || '', out_trade_no])

        const epayUserRows = await conn.query('SELECT username FROM users WHERE id=?', [order.user_id])
        const epayUserName = epayUserRows[0] && epayUserRows[0][0] ? epayUserRows[0][0].username : ''

        await earnCurrency(order.user_id, epayUserName, 'balance', Number(order.amount), 'recharge', out_trade_no, '余额充值', conn)

        await processRechargeGifts(order, conn)

        await conn.commit()
        conn.release()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }

      res.send('success')
    } catch (e) {
      console.error('充值回调错误:', e)
      res.send('fail')
    }
  })

  app.get('/api/recharge/order/:orderNo/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const orders = await query('SELECT order_no as orderNo, status, amount, pay_method as payMethod, paid_time as paidTime, create_time as createTime FROM recharge_orders WHERE order_no=? AND user_id=?', [req.params.orderNo, userId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      res.json({ code: 200, data: orders[0] })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/recharge/orders', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE user_id=?'; const params = [userId]
      if (status) { where += ' AND status=?'; params.push(status) }
      const [rows, countRows] = await Promise.all([
        query(`SELECT * FROM recharge_orders ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, Number(pageSize), offset]),
        query(`SELECT COUNT(*) as cnt FROM recharge_orders ${where}`, params)
      ])
      res.json({ code: 200, data: { list: rows, total: countRows[0]?.cnt || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/admin/recharge/orders', authRequired, adminRequired, async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = ''
      const params = []
      if (status) { where = "WHERE status=?"; params.push(status) }
      const rows = await query(
        `SELECT r.*, u.username FROM recharge_orders r LEFT JOIN users u ON r.user_id=u.id ${where} ORDER BY r.create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      const total = await query(`SELECT COUNT(*) as cnt FROM recharge_orders ${where}`, params)
      res.json({ code: 200, data: { list: rows, total: total[0]?.cnt || 0 } })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/recharge/alipay/callback', async (req, res) => {
    try {
      const { out_trade_no, trade_no, total_amount } = req.body
      if (!out_trade_no) return res.json({ code: 400, msg: '参数错误' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const orders = await conn.query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending' FOR UPDATE", [out_trade_no])
        if (orders[0].length === 0) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 200, msg: 'ok' })
        }

        const order = orders[0][0]
        await conn.query(`UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?`, [trade_no || 'alipay_' + Date.now(), out_trade_no])

        const alipayUserRows = await conn.query('SELECT username FROM users WHERE id=?', [order.user_id])
        const alipayUserName = (alipayUserRows[0] && alipayUserRows[0][0]) ? alipayUserRows[0][0].username : ''

        await earnCurrency(order.user_id, alipayUserName, 'balance', Number(order.amount), 'recharge', out_trade_no, '支付宝充值', conn)

        await processRechargeGifts(order, conn)

        await conn.commit()
        conn.release()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }

      res.json({ code: 200, msg: 'success' })
    } catch (e) { console.error('支付宝回调错误:', e); res.serverError(e) }
  })

  app.post('/api/recharge/wechat/callback', async (req, res) => {
    try {
      const { out_trade_no, transaction_id } = req.body
      if (!out_trade_no) return res.json({ code: 400, msg: '参数错误' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const orders = await conn.query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending' FOR UPDATE", [out_trade_no])
        if (orders[0].length === 0) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 200, msg: 'ok' })
        }

        const order = orders[0][0]
        await conn.query(`UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?`, [transaction_id || 'wx_' + Date.now(), out_trade_no])

        const wxUserRows = await conn.query('SELECT username FROM users WHERE id=?', [order.user_id])
        const wxUserName = (wxUserRows[0] && wxUserRows[0][0]) ? wxUserRows[0][0].username : ''

        await earnCurrency(order.user_id, wxUserName, 'balance', Number(order.amount), 'recharge', out_trade_no, '微信充值', conn)

        await processRechargeGifts(order, conn)

        await conn.commit()
        conn.release()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }

      res.json({ code: 200, msg: 'success' })
    } catch (e) { console.error('微信回调错误:', e); res.serverError(e) }
  })
}

module.exports = { rechargeRoutes }
