const { query } = require('../database.cjs')
const crypto = require('crypto')
const { sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) {
      sessions.delete(token)
      return 0
    }
    return Number(session.userId) || 0
  }
  return 0
}

const nowExpr = 'NOW()'

function rechargeRoutes(app) {
  // ========== 充值金额列表 ==========
  app.get('/api/recharge/amounts', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM recharge_amounts WHERE status=1 ORDER BY amount ASC')
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  // ========== 管理员: 保存充值金额配置 ==========
  app.post('/api/admin/recharge/amounts', async (req, res) => {
    try {
      const { amounts } = req.body
      if (!Array.isArray(amounts)) return res.json({ code: 400, msg: '参数错误' })

      await query('DELETE FROM recharge_amounts')
      for (const a of amounts) {
        await query(
          `INSERT INTO recharge_amounts (amount, label, discount, status) VALUES (?, ?, ?, ?)`,
          [Number(a.amount) || 0, a.label || '', a.discount || '', a.status !== 0 ? 1 : 0]
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 获取支付配置 ==========
  app.get('/api/admin/payment-config', async (req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'payment_%'")
      const config = {}
      rows.forEach(r => { config[r.config_key] = r.config_value })
      res.json({ code: 200, data: config })
    } catch (e) { res.serverError(e) }
  })

  // ========== 保存支付配置 ==========
  app.post('/api/admin/payment-config', async (req, res) => {
    try {
      const configs = req.body
      for (const [key, value] of Object.entries(configs)) {
        if (!key.startsWith('payment_')) continue
        const exist = await query("SELECT id FROM sys_config WHERE config_key=?", [key])
        if (exist.length > 0) {
          await query("UPDATE sys_config SET config_value=? WHERE config_key=?", [String(value), key])
        } else {
          await query("INSERT INTO sys_config (config_key, config_value) VALUES (?, ?)", [key, String(value)])
        }
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 创建充值订单 ==========
  app.post('/api/recharge/create', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { amount, payMethod } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '金额无效' })
      if (!['alipay', 'wechat', 'epay'].includes(payMethod)) return res.json({ code: 400, msg: '支付方式无效' })

      const orderNo = 'RC' + Date.now() + Math.random().toString(36).slice(2, 8)
      await query(
        `INSERT INTO recharge_orders (order_no, user_id, amount, pay_method, status, create_time)
         VALUES (?, ?, ?, ?, 'pending', ${nowExpr})`,
        [orderNo, userId, Number(amount), payMethod]
      )

      // 获取支付配置
      const configs = await query("SELECT config_key, config_value FROM sys_config WHERE config_key LIKE 'payment_%'")
      const cfg = {}
      configs.forEach(r => { cfg[r.config_key] = r.config_value })

      let payUrl = ''
      if (payMethod === 'epay') {
        const pid = cfg.payment_epay_pid || ''
        const key = cfg.payment_epay_key || ''
        const apiUrl = cfg.payment_epay_api_url || ''
        const notifyUrl = cfg.payment_epay_notify_url || ''
        if (!pid || !key || !apiUrl) return res.json({ code: 400, msg: '易支付未配置' })

        const clientip = (req.ip || req.socket?.remoteAddress || '127.0.0.1').replace(/^::ffff:/, '')
        const params = {
          pid, type: 'alipay',
          out_trade_no: orderNo,
          notify_url: notifyUrl,
          return_url: notifyUrl,
          name: '余额充值',
          money: String(amount),
          clientip
        }
        const signKeys = Object.keys(params).filter(k => params[k] !== '' && params[k] !== undefined).sort()
        const signStr = signKeys.map(k => `${k}=${params[k]}`).join('&') + key
        params.sign = crypto.createHash('md5').update(signStr).digest('hex')
        params.sign_type = 'MD5'

        const qs = new URLSearchParams(params).toString()
        payUrl = `${apiUrl.replace(/\/+$/, '')}/submit.php?${qs}`
      } else if (payMethod === 'alipay') {
        payUrl = cfg.payment_alipay_app_id ? '/api/recharge/alipay/pay?orderNo=' + orderNo : ''
        if (!payUrl) return res.json({ code: 400, msg: '支付宝未配置' })
      } else if (payMethod === 'wechat') {
        payUrl = cfg.payment_wechat_app_id ? '/api/recharge/wechat/pay?orderNo=' + orderNo : ''
        if (!payUrl) return res.json({ code: 400, msg: '微信支付未配置' })
      }

      res.json({ code: 200, data: { orderNo, payUrl } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 易支付同步/异步回调 ==========
  app.all('/api/recharge/callback/epay/return', async (req, res) => {
    res.send(`<html><body><script>window.location.href='/#/appstore/assets?recharge=success'</script></body></html>`)
  })

  // ========== 易支付异步通知回调 ==========
  app.all('/api/recharge/callback/epay/notify', async (req, res) => {
    try {
      const params = req.method === 'POST' ? req.body : req.query
      const { out_trade_no, trade_no, money, trade_status, sign, sign_type } = params
      if (!out_trade_no || trade_status !== 'TRADE_SUCCESS') return res.send('fail')

      const configs = await query("SELECT config_key, config_value FROM sys_config WHERE config_key='payment_epay_key'")
      const epayKey = configs[0]?.config_value || ''

      // 验证签名
      const signParams = { ...params }
      delete signParams.sign
      delete signParams.sign_type
      const signStr = Object.keys(signParams).sort().map(k => `${k}=${signParams[k]}`).join('&') + epayKey
      const mySign = crypto.createHash('md5').update(signStr).digest('hex')
      if (sign !== mySign) return res.send('sign error')

      const orders = await query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending'", [out_trade_no])
      if (orders.length === 0) return res.send('ok')

      const order = orders[0]
      await query("UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?", [trade_no || '', out_trade_no])
      await query("UPDATE users SET balance = balance + ? WHERE id = ?", [Number(order.amount), order.user_id])
      await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, create_time)
        SELECT ${order.user_id}, username, 'earn', ${Number(order.amount)}, balance, '余额充值', ?, ${nowExpr}
        FROM users WHERE id=${order.user_id}`,
        [`充值订单 ${out_trade_no}`])

      res.send('success')
    } catch (e) {
      console.error('充值回调错误:', e)
      res.send('fail')
    }
  })

  // ========== 16. 支付状态查询 ==========
  app.get('/api/recharge/order/:orderNo/status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const orders = await query('SELECT order_no as orderNo, status, amount, pay_method as payMethod, paid_time as paidTime, create_time as createTime FROM recharge_orders WHERE order_no=? AND user_id=?', [req.params.orderNo, userId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      res.json({ code: 200, data: orders[0] })
    } catch (e) { res.serverError(e) }
  })

  // ========== 充值订单列表 ==========
  app.get('/api/recharge/orders', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = 'WHERE user_id=?'; const params = [userId]
      if (status) { where += ' AND status=?'; params.push(status) }
      const [rows, countRows] = await Promise.all([
        query(`SELECT * FROM recharge_orders ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, Number(pageSize), offset]),
        query(`SELECT COUNT(*) as cnt FROM recharge_orders ${where}`, params)
      ])
      res.json({ code: 200, data: { list: rows, total: countRows[0]?.cnt || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 管理员: 充值订单列表 ==========
  app.get('/api/admin/recharge/orders', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      let where = ''
      const params = []
      if (status) { where = "WHERE status=?"; params.push(status) }
      const rows = await query(
        `SELECT r.*, u.username FROM recharge_orders r LEFT JOIN users u ON r.user_id=u.id ${where} ORDER BY r.create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      const total = await query(`SELECT COUNT(*) as cnt FROM recharge_orders ${where}`, params)
      res.json({ code: 200, data: { list: rows, total: total[0]?.cnt || 0 } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 18. 支付宝支付回调 ==========
  app.post('/api/recharge/alipay/callback', async (req, res) => {
    try {
      const { out_trade_no, trade_no, total_amount } = req.body
      if (!out_trade_no) return res.json({ code: 400, msg: '参数错误' })
      const orders = await query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending'", [out_trade_no])
      if (orders.length === 0) return res.json({ code: 200, msg: 'ok' })
      const order = orders[0]
      await query("UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?", [trade_no || 'alipay_' + Date.now(), out_trade_no])
      await query("UPDATE users SET balance = balance + ? WHERE id = ?", [Number(order.amount), order.user_id])
      await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, create_time)
        SELECT ${order.user_id}, username, 'earn', ${Number(order.amount)}, balance, '支付宝充值', ?, ${nowExpr}
        FROM users WHERE id=${order.user_id}`,
        [`充值订单 ${out_trade_no}`])
      res.json({ code: 200, msg: 'success' })
    } catch (e) { console.error('支付宝回调错误:', e); res.serverError(e) }
  })

  // ========== 微信支付回调 ==========
  app.post('/api/recharge/wechat/callback', async (req, res) => {
    try {
      const { out_trade_no, transaction_id } = req.body
      if (!out_trade_no) return res.json({ code: 400, msg: '参数错误' })
      const orders = await query("SELECT * FROM recharge_orders WHERE order_no=? AND status='pending'", [out_trade_no])
      if (orders.length === 0) return res.json({ code: 200, msg: 'ok' })
      const order = orders[0]
      await query("UPDATE recharge_orders SET status='paid', trade_no=?, paid_time=${nowExpr} WHERE order_no=?", [transaction_id || 'wx_' + Date.now(), out_trade_no])
      await query("UPDATE users SET balance = balance + ? WHERE id = ?", [Number(order.amount), order.user_id])
      await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, create_time)
        SELECT ${order.user_id}, username, 'earn', ${Number(order.amount)}, balance, '微信充值', ?, ${nowExpr}
        FROM users WHERE id=${order.user_id}`,
        [`充值订单 ${out_trade_no}`])
      res.json({ code: 200, msg: 'success' })
    } catch (e) { console.error('微信回调错误:', e); res.serverError(e) }
  })
}

module.exports = { rechargeRoutes }
