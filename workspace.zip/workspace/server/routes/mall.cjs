const { query, getSystemOperator } = require('../database.cjs')
const { deductBalance, deductPoints } = require('./account-utils.cjs')
const { authRequired, optionalAuth, requirePermission } = require('./system.cjs')
const { sendNotificationEmail } = require('./email.cjs')
const { calcCommission } = require('./commission.cjs')
const kdniao = require('../utils/kdniao.cjs')
const logisticsConfig = require('./logistics-config.cjs')
const nowExpr = 'NOW()'

function mallRoutes(router) {

  // 检查商品是否在销售期内，过期自动标记为下架
  async function checkProductSaleEnd(pid) {
    await query(`UPDATE mall_products SET status='off' WHERE id=? AND sale_end_time IS NOT NULL AND sale_end_time < NOW() AND status='1'`, [pid])
  }

  function formatProduct(r) {
    return {
      ...r,
      categoryId: r.category_id, categoryName: r.category_name,
      coverImage: r.cover_image, coverVideo: r.cover_video,
      priceType: r.price_type, originalPrice: r.original_price,
      productType: r.product_type, virtualContent: r.virtual_content,
      salesCount: r.sales_count, isRecommended: r.is_recommended,
      sortOrder: r.sort_order, purchaseLimitConfig: safeJSON(r.purchase_limit_config),
      commissionConfig: safeJSON(r.commission_config), customFields: safeJSON(r.custom_fields),
      afterSalesConfig: safeJSON(r.after_sales_config), services: safeJSON(r.services),
      tags: safeJSON(r.tags), productParams: safeJSON(r.product_params),
      paymentMethods: safeJSON(r.payment_methods),
      saleEndTime: r.sale_end_time || null,
      productSubtype: r.product_subtype || '',
      previewImages: safeJSON(r.preview_images),
      sourceFileUrl: r.source_file_url || '',
      createdBy: r.created_by || 0, createdByName: r.created_by_name || '',
      createTime: r.create_time, updateTime: r.update_time
    }
  }

  async function applyCoupon(userCouponId, userId, totalAmount, paymentMethod, orderRefId) {
    const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [userCouponId, userId])
    if (!uc.length) return { error: '优惠券不存在或不属于您' }
    if (uc[0].status !== 'unused') return { error: '优惠券已使用或已过期' }

    const now = new Date().toISOString().replace('T', ' ').slice(0, 19)
    if (uc[0].expire_time && uc[0].expire_time < now) {
      await query("UPDATE user_coupons SET status='expired' WHERE id=?", [userCouponId])
      return { error: '优惠券已过期' }
    }

    const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
    const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
    if (!c.length) return { error: '优惠券模板不存在' }

    const scope = c[0].scope || cd.scope || ''
    if (scope && scope !== 'all' && scope !== 'mall') {
      return { error: '此优惠券不适用于商城场景' }
    }

    const minOrder = Number(c[0].min_order || cd.minOrder || 0)
    if (totalAmount < minOrder) {
      return { error: `未达到最低消费 ¥${minOrder}` }
    }

    const type = c[0].type || cd.type || ''
    const value = Number(c[0].value || cd.value || 0)
    const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
    const isMultiUse = !!(c[0].is_multi_use)

    const isPointsCoupon = type.includes('points')
    if (isPointsCoupon && paymentMethod !== 'points') {
      return { error: '此券仅限积分支付时使用' }
    }
    if (!isPointsCoupon && paymentMethod === 'points') {
      return { error: '此券仅限余额支付时使用' }
    }

    let availableValue = value
    if (isMultiUse) {
      availableValue = uc[0].remaining_value !== null ? Number(uc[0].remaining_value) : value
    }

    let couponDiscount = 0
    if (type === 'fixed' || type.includes('fixed')) {
      couponDiscount = Math.min(availableValue, totalAmount)
    } else if (type === 'percent' || type === 'discount' || type.includes('discount') || type.includes('percent')) {
      couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
      if (maxDisc > 0 && couponDiscount > maxDisc) couponDiscount = maxDisc
      couponDiscount = Math.min(couponDiscount, totalAmount)
    } else {
      couponDiscount = Math.min(value, totalAmount)
    }

    const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
    if (isMultiUse) {
      if (afterRemaining <= 0) {
        await query(
          `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=0 WHERE id=?`,
          [now, orderRefId, couponDiscount, userCouponId]
        )
      } else {
        await query(
          `UPDATE user_coupons SET use_time=?, use_scene='mall', use_order_id=?, use_amount=use_amount+?, remaining_value=? WHERE id=?`,
          [now, orderRefId, couponDiscount, afterRemaining, userCouponId]
        )
      }
    } else {
      await query(
        `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=NULL WHERE id=?`,
        [now, orderRefId, couponDiscount, userCouponId]
      )
    }

    return { couponDiscount, couponUsedId: userCouponId }
  }

  // ==================== 分类 ====================
  router.get('/api/mall/categories/all', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/categories', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? AND parent_id=0 ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  // 分类管理 - 增删改
  router.post('/api/mall/categories', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const { name, parentId, icon, sortOrder } = req.body
      if (!name) return res.json({ code: 400, msg: '分类名称不能为空' })
      const result = await query(
        'INSERT INTO mall_categories (parent_id, name, icon, sort_order, status) VALUES (?,?,?,?,?)',
        [parentId || 0, name, icon || '', sortOrder || 0, '1']
      )
      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/categories/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const { name, parentId, icon, sortOrder, status } = req.body
      await query(
        'UPDATE mall_categories SET parent_id=?, name=?, icon=?, sort_order=?, status=? WHERE id=?',
        [parentId || 0, name || '', icon || '', sortOrder || 0, status || '1', Number(req.params.id)]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/categories/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const [children, products] = await Promise.all([
        query('SELECT COUNT(*) as cnt FROM mall_categories WHERE parent_id=?', [req.params.id]),
        query('SELECT COUNT(*) as cnt FROM mall_products WHERE category_id=?', [req.params.id])
      ])
      if (children[0].cnt > 0) return res.json({ code: 400, msg: '该分类下有子分类，无法删除' })
      if (products[0].cnt > 0) return res.json({ code: 400, msg: '该分类下有商品，无法删除' })
      await query('DELETE FROM mall_categories WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  // ==================== 购物车 ====================
  router.get('/api/mall/cart', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const rows = await query(
        `SELECT c.id, c.user_id as userId, c.product_id as productId, c.option_id as optionId, c.quantity,
                p.name as productName, p.cover_image as coverImage, p.price, p.original_price as originalPrice,
                p.stock, p.status as productStatus, p.price_type as priceType, p.freight,
                o.name as optionName, o.price as optionPrice, o.original_price as optionOriginalPrice, o.stock as optionStock, o.image as optionImage
         FROM mall_cart_items c
         JOIN mall_products p ON c.product_id = p.id
         LEFT JOIN mall_product_options o ON c.option_id = o.id
         WHERE c.user_id = ?
         ORDER BY c.id DESC`, [userId])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/cart', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { productId, optionId, quantity = 1 } = req.body
      if (!productId) return res.json({ code: 400, msg: '请选择商品' })
      const productRows = await query('SELECT id, status, stock FROM mall_products WHERE id=?', [productId])
      if (!productRows || !productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      if (productRows[0].status !== 'published' && productRows[0].status !== '1') return res.json({ code: 400, msg: '商品已下架' })

      const existing = await query(
        'SELECT id, quantity FROM mall_cart_items WHERE user_id=? AND product_id=? AND option_id=?',
        [userId, productId, optionId || 0]
      )
      if (existing.length) {
        await query('UPDATE mall_cart_items SET quantity = quantity + ? WHERE id=?', [quantity, existing[0].id])
        res.json({ code: 200, msg: '已更新购物车数量' })
      } else {
        await query(
          'INSERT INTO mall_cart_items (user_id, product_id, option_id, quantity) VALUES (?,?,?,?)',
          [userId, productId, optionId || 0, quantity]
        )
        res.json({ code: 200, msg: '已加入购物车' })
      }
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/cart/:id', authRequired, async (req, res) => {
    try {
      const { quantity } = req.body
      if (quantity < 1) return res.json({ code: 400, msg: '数量不能小于1' })
      await query('UPDATE mall_cart_items SET quantity=? WHERE id=? AND user_id=?', [quantity, req.params.id, req.user.userId])
      res.json({ code: 200, msg: '已更新' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/cart/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM mall_cart_items WHERE id=? AND user_id=?', [req.params.id, req.user.userId])
      res.json({ code: 200, msg: '已移除' })
    } catch (e) { res.serverError(e) }
  })

  // 购物车清空/批量删除
  router.post('/api/mall/cart/clear', authRequired, async (req, res) => {
    try {
      const { ids } = req.body
      if (ids && ids.length) {
        await query(`DELETE FROM mall_cart_items WHERE user_id=? AND id IN (${ids.map(() => '?').join(',')})`, [req.user.userId, ...ids])
      } else {
        await query('DELETE FROM mall_cart_items WHERE user_id=?', [req.user.userId])
      }
      res.json({ code: 200, msg: '已清空' })
    } catch (e) { res.serverError(e) }
  })

  // 购物车结算下单
  router.post('/api/mall/cart/checkout', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { cartIds, addressId, remark = '', userCouponId } = req.body

      if (!cartIds || !cartIds.length) return res.json({ code: 400, msg: '请选择要结算的商品' })

      const cartItems = await query(
        `SELECT c.*, p.name, p.price, p.price_type, p.product_type, p.virtual_content, p.status, p.stock, p.freight,
                o.name as option_name, o.price as option_price, o.stock as option_stock
         FROM mall_cart_items c
         JOIN mall_products p ON c.product_id = p.id
         LEFT JOIN mall_product_options o ON c.option_id = o.id
         WHERE c.user_id=? AND c.id IN (${cartIds.map(() => '?').join(',')})`,
        [userId, ...cartIds]
      )

      if (!cartItems.length) return res.json({ code: 400, msg: '购物车为空' })

      // 校验库存
      for (const item of cartItems) {
        if (item.status !== 'published' && item.status !== '1') return res.json({ code: 400, msg: `商品"${item.name}"已下架` })
        if (item.option_id && item.option_stock < item.quantity) return res.json({ code: 400, msg: `"${item.name} - ${item.option_name}"库存不足` })
        if (!item.option_id && item.stock < item.quantity) return res.json({ code: 400, msg: `商品"${item.name}"库存不足` })
      }

      const userRows = await query('SELECT balance, username FROM users WHERE id=?', [userId])
      const user = userRows[0]

      // 计算总金额
      let totalAmount = 0
      let totalFreight = 0
      for (const item of cartItems) {
        const unitPrice = item.option_price || item.price
        totalAmount += unitPrice * item.quantity
        totalFreight += item.freight || 0
      }

      // 优惠券处理
      let couponDiscount = 0
      if (userCouponId) {
        const couponRows = await query(
          'SELECT coupon_data, id FROM user_coupons WHERE id=? AND user_id=? AND status=? AND expire_time > NOW()',
          [userCouponId, userId, 'unused']
        )
        if (couponRows.length) {
          const uc = couponRows[0]
          const couponData = safeJSON(uc.coupon_data)
          if (couponData.type === 'fixed') couponDiscount = Math.min(couponData.value, totalAmount)
          else if (couponData.type === 'percent') couponDiscount = Math.min(totalAmount * couponData.value / 100, couponData.max_discount || totalAmount)
          if (totalAmount - couponDiscount < couponData.min_order) couponDiscount = 0
          else {
            totalAmount -= couponDiscount
            await query('UPDATE user_coupons SET status=?, use_scene=?, use_time=NOW() WHERE id=?', ['used', 'mall', uc.id])
          }
        }
      }

      // 扣款
      if (user.balance < totalAmount) return res.json({ code: 400, msg: `余额不足，需要¥${totalAmount.toFixed(2)}，当前余额¥${Number(user.balance).toFixed(2)}` })
      await query('UPDATE users SET balance = ROUND(balance - ?, 2) WHERE id=?', [totalAmount, userId])
      await query(
        'INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,?,?, (SELECT balance FROM users WHERE id=?),?,?)',
        [userId, user.username || '', 'spend', totalAmount, userId, '商城购物', `商城下单，共${cartItems.length}件商品`]
      )

      // 获取地址信息
      let receiverName = '', receiverPhone = '', addressInfo = ''
      if (addressId) {
        const addrRows = await query('SELECT name, phone, province, city, district, detail FROM user_addresses WHERE id=? AND user_id=?', [addressId, userId])
        if (addrRows.length) {
          const a = addrRows[0]
          receiverName = a.name || ''
          receiverPhone = a.phone || ''
          addressInfo = `${a.province}${a.city}${a.district}${a.detail}`
        }
      }

      // 逐个商品创建订单和发货
      const orderIds = []
      const deliveryItems = []
      for (const item of cartItems) {
        const product = { id: item.product_id, name: item.name, product_type: item.product_type, virtual_content: item.virtual_content }
        const unitPrice = item.option_price || item.price
        const itemTotal = unitPrice * item.quantity

        const orderNo = genOrderNo()
        let insertId
        try {
          const result = await query(
            `INSERT INTO mall_orders (order_no, user_id, status, total_amount, discount_amount, freight, payment_method, payment_time, remark, receiver_name, receiver_phone, receiver_address, user_custom_fields) VALUES (?,?,'paid',?,0,0,'balance',NOW(),?,?,?,?,?)`,
            [orderNo, userId, itemTotal, remark || '', receiverName, receiverPhone, addressInfo, JSON.stringify({})]
          )
          const orderId = result.insertId
          orderIds.push(orderId)

          // 订单商品
          const productName = item.option_name ? `${item.name} (${item.option_name})` : item.name
          await query(
            'INSERT INTO mall_order_items (order_id, product_id, option_id, product_name, option_name, price, quantity, image) VALUES (?,?,?,?,?,?,?,?)',
            [orderId, item.product_id, item.option_id || 0, productName, item.option_name || '', unitPrice, item.quantity, '']
          )

          // 虚拟商品自动发货
          const orderItem = { option_id: item.option_id, quantity: item.quantity }
          let deliveryInfo = ''
          if (item.product_type && item.product_type !== 'physical') {
            deliveryInfo = await autoDeliver(orderItem, product, user)
          }
          if (deliveryInfo) {
            await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
            deliveryItems.push({ orderId, productName, deliveryInfo })
          }

          // 减库存
          if (item.option_id) {
            await query('UPDATE mall_product_options SET stock = GREATEST(stock - ?, 0) WHERE id=?', [item.quantity, item.option_id])
          }
          await query('UPDATE mall_products SET stock = GREATEST(stock - ?, 0), sales_count = sales_count + ? WHERE id=?', [item.quantity, item.quantity, item.product_id])
        } catch (e) {
          console.error('创建订单失败:', e)
        }
      }

      // 清空已结算的购物车项
      await query(`DELETE FROM mall_cart_items WHERE id IN (${cartIds.map(() => '?').join(',')})`, cartIds)

      let msg = `下单成功！共${orderIds.length}笔订单，实付¥${totalAmount.toFixed(2)}`
      if (couponDiscount > 0) msg += `，优惠券抵扣¥${couponDiscount.toFixed(2)}`
      
      // 如果只有一个订单且只有一件商品，返回订单ID
      const firstOrderId = orderIds[0] || 0
      res.json({ code: 200, msg, data: { orderIds, totalAmount, couponDiscount, orderId: firstOrderId, deliveryItems } })
    } catch (e) { res.serverError(e) }
  })

  // ==================== 商品 ====================
  router.get('/api/mall/products', async (req, res) => {
    try {
      const { categoryId, status, productType, priceType, isRecommended, admin, userId, minPrice, maxPrice, sortBy, sortOrder, page = 1, pageSize = 20 } = req.query
      const params = []
      let where = '1=1'
      if (categoryId) { where += ' AND p.category_id=?'; params.push(categoryId) }
      if (productType) { where += ' AND p.product_type=?'; params.push(productType) }
      if (priceType) { where += ' AND p.price_type=?'; params.push(priceType) }
      if (isRecommended) { where += ' AND p.is_recommended=1' }
      if (userId) { where += ' AND p.created_by=?'; params.push(userId) }
      if (minPrice) { where += ' AND p.price >= ?'; params.push(Number(minPrice)) }
      if (maxPrice) { where += ' AND p.price <= ?'; params.push(Number(maxPrice)) }

      let orderBy = 'p.sort_order, p.id DESC'
      const so = (sortOrder || 'desc').toLowerCase()
      const dir = so === 'asc' ? 'ASC' : 'DESC'
      switch (sortBy) {
        case 'sales': orderBy = `p.sales_count ${dir}, p.sort_order`; break
        case 'price': orderBy = `p.price ${dir}, p.sort_order`; break
        case 'newest': orderBy = `p.id ${dir}`; break
        case 'rating': orderBy = `p.avg_rating ${dir}, p.sort_order`; break
        default: break
      }

      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_products p WHERE ${where}`, params),
        query(
          `SELECT p.*, c.name as category_name
           FROM mall_products p LEFT JOIN mall_categories c ON p.category_id=c.id
           WHERE ${where} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])
      res.json({
        code: 200,
        data: {
          list: listRows.map(r => formatProduct(r)),
          total: countRows[0]?.total || 0,
          page: Number(page),
          pageSize: Number(pageSize)
        }
      })
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/products/:id', async (req, res) => {
    try {
      const [rows, options, images] = await Promise.all([
        query('SELECT id, category_id, name, subtitle, description, cover_image, cover_video, price_type, price, original_price, stock, product_type, virtual_content, status, sales_count, is_recommended, sort_order, freight, services, purchase_limit_config, commission_config, custom_fields, after_sales_config, tags, product_params, payment_methods, created_by, created_by_name, sale_end_time, product_subtype, freight_free_amount, product_type_config, preview_images, source_file_url, create_time, update_time FROM mall_products WHERE id=?', [req.params.id]),
        query('SELECT id, product_id, name, spec_name, price, original_price, points_price, stock, image, sort_order, card_config FROM mall_product_options WHERE product_id=? ORDER BY sort_order', [req.params.id]),
        query('SELECT id, product_id, url, sort_order FROM mall_product_images WHERE product_id=? ORDER BY sort_order', [req.params.id])
      ])
      if (!rows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = formatProduct(rows[0])
      product.options = options.map(o => ({ id: o.id, productId: o.product_id, name: o.name, specName: o.spec_name || '', price: o.price, originalPrice: o.original_price, pointsPrice: o.points_price, stock: o.stock, image: o.image, sortOrder: o.sort_order, cardConfig: safeJSON(o.card_config) }))
      product.images = images.map(i => ({ id: i.id, url: i.url, sortOrder: i.sort_order }))
      res.json({ code: 200, data: product })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/products', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const b = req.body
      const userId = req.user?.userId || 0
      const userName = req.user?.userName || ''
      const result = await query(
        `INSERT INTO mall_products (category_id,name,subtitle,description,cover_image,cover_video,price_type,price,original_price,stock,product_type,virtual_content,status,is_recommended,sort_order,freight,services,purchase_limit_config,commission_config,custom_fields,after_sales_config,tags,product_params,payment_methods,sale_end_time,created_by,created_by_name,create_time,update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,${nowExpr},${nowExpr})`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', b.status || 'draft',
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null, userId, userName]
      )
      const pid = result.insertId
      await saveProductRelations(pid, b)
      res.json({ code: 200, msg: '创建成功', data: { id: pid } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/products/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const b = req.body; const id = req.params.id
      await query(
        `UPDATE mall_products SET category_id=?,name=?,subtitle=?,description=?,cover_image=?,cover_video=?,price_type=?,price=?,original_price=?,stock=?,product_type=?,virtual_content=?,status=?,is_recommended=?,sort_order=?,freight=?,services=?,purchase_limit_config=?,commission_config=?,custom_fields=?,after_sales_config=?,tags=?,product_params=?,payment_methods=?,sale_end_time=?,update_time=${nowExpr} WHERE id=?`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', b.status || 'draft',
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null, id]
      )
      await saveProductRelations(id, b)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/products/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const id = req.params.id
      await Promise.all([
        query('DELETE FROM mall_products WHERE id=?', [id]),
        query('DELETE FROM mall_product_options WHERE product_id=?', [id]),
        query('DELETE FROM mall_product_images WHERE product_id=?', [id])
      ])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  async function saveProductRelations(productId, body) {
    await query('DELETE FROM mall_product_options WHERE product_id=?', [productId])
    if (body.options && body.options.length) {
      for (const o of body.options) {
        await query(
          `INSERT INTO mall_product_options (product_id,name,spec_name,price,original_price,points_price,stock,image,sort_order,card_config) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [productId, o.name, o.specName || '', o.price || 0, o.originalPrice || 0, o.pointsPrice || 0, o.stock || 0, o.image || '', o.sortOrder || 0, JSON.stringify(o.cardConfig || {})]
        )
      }
    }
    await query('DELETE FROM mall_product_images WHERE product_id=?', [productId])
    if (body.images && body.images.length) {
      for (const img of body.images) {
        await query(
          `INSERT INTO mall_product_images (product_id,url,sort_order) VALUES (?,?,?)`,
          [productId, img.url || img, img.sortOrder || 0]
        )
      }
    }
  }

  function formatProduct(r) {
    return {
      ...r,
      categoryId: r.category_id, categoryName: r.category_name,
      coverImage: r.cover_image, coverVideo: r.cover_video,
      priceType: r.price_type, originalPrice: r.original_price,
      productType: r.product_type, virtualContent: r.virtual_content,
      salesCount: r.sales_count, isRecommended: r.is_recommended,
      sortOrder: r.sort_order, purchaseLimitConfig: safeJSON(r.purchase_limit_config),
      commissionConfig: safeJSON(r.commission_config), customFields: safeJSON(r.custom_fields),
      afterSalesConfig: safeJSON(r.after_sales_config), services: safeJSON(r.services),
      tags: safeJSON(r.tags), productParams: safeJSON(r.product_params),
      paymentMethods: safeJSON(r.payment_methods),
      saleEndTime: r.sale_end_time || null,
      productSubtype: r.product_subtype || '',
      previewImages: safeJSON(r.preview_images),
      sourceFileUrl: r.source_file_url || '',
      createdBy: r.created_by || 0, createdByName: r.created_by_name || '',
      createTime: r.create_time, updateTime: r.update_time
    }
  }

  function safeJSON(v) { try { return typeof v === 'string' ? JSON.parse(v) : (v || []) } catch { return [] } }

  // 虚拟商品自动发货
  async function autoDeliver(item, product, user) {
    let deliveryInfo = ''
    let cardConfig = {}

    // 如果选择了规格，从规格读取卡密配置
    if (item.option_id) {
      const optRows = await query('SELECT * FROM mall_product_options WHERE id=?', [item.option_id])
      if (optRows.length && optRows[0].card_config) {
        cardConfig = safeJSON(optRows[0].card_config)
      }
    }

    // 从商品级虚拟内容读取（兼容旧数据）
    const vContent = product.virtual_content || ''
    if (!cardConfig.enabled && vContent) {
      deliveryInfo = vContent
      return deliveryInfo
    }

    // 没有卡密配置，返回空
    if (!cardConfig.enabled) {
      return ''
    }

    const cfgType = cardConfig.type || 'card_key'
    const cardType = cardConfig.cardType || 'membership'
    const targetId = cardConfig.targetId || 0
    const value = cardConfig.value || 0
    const durationUnit = cardConfig.durationUnit || 'day'
    const extraPoints = cardConfig.extraPoints || 0
    const extraBalance = cardConfig.extraBalance || 0
    const extraExperience = cardConfig.extraExperience || 0

    if (cfgType === 'auto_recharge') {
      // 自动充值：直接给账户加积分/余额/经验/开通会员，不生成卡密
      if (cardType === 'points') {
        await query('UPDATE users SET points = points + ? WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'earn',?, (SELECT points FROM users WHERE id=?), '商城购买赠送', ?)`,
          [user.id, user.username || '', value, user.id, `购买《${product.name || ''}》赠送${value}积分`]
        )
        deliveryInfo = `赠送 ${value} 积分`
      } else if (cardType === 'balance') {
        await query('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '商城购买赠送', ?)`,
          [user.id, user.username || '', value, user.id, `购买《${product.name || ''}》赠送¥${value}`]
        )
        deliveryInfo = `赠送 ¥${value} 余额`
      } else if (cardType === 'experience') {
        await query('UPDATE users SET experience = experience + ? WHERE id=?', [value, user.id])
        await query(
          `INSERT INTO experience_records (user_id, user_name, amount, source, description) VALUES (?,?,?,?,?)`,
          [user.id, user.username || '', value, '商城购买赠送', `购买《${product.name || ''}》赠送${value}经验`]
        )
        deliveryInfo = `赠送 ${value} 经验`
      } else {
        // membership or free - 直接开通会员
        const lv = await query('SELECT id, name FROM membership_levels WHERE id=?', [targetId])
        if (lv && lv.length > 0) {
          const expDate = new Date(Date.now() + value * 24 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)
          await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
            [targetId, lv[0].name, expDate, user.id])
          await query(
            `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
             VALUES (?, ?, ?, ?, 'balance', 'mall', ?, ?)`,
            [user.id, targetId, lv[0].name, 0, value, expDate]
          )
          deliveryInfo = `开通会员：${lv[0].name}，有效期 ${value} 天`
        } else {
          deliveryInfo = '开通会员失败：会员等级不存在'
        }
      }
    } else if (cfgType === 'card_key') {
      // 卡密：全部 cardType 都生成卡密返回给用户
      const qty = item.quantity || 1
      const cards = []
      for (let i = 0; i < qty; i++) {
        const cardNo = 'MC' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
        const cardPwd = Math.random().toString(36).slice(2, 10).toUpperCase()
        const targetName = cardConfig.targetName || ''
        await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, extra_balance, duration, duration_unit, status, create_by, create_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,'0',?,${nowExpr})`,
          [cardNo, cardPwd, cardType, targetId, targetName, value, extraPoints, extraExperience, extraBalance, value, durationUnit, '系统自动发货']
        )
        cards.push(`卡密：${cardNo}，密码：${cardPwd}` + (targetName ? `，类型：${targetName}` : ''))
      }
      deliveryInfo = cards.join('\n')
    } else if (cfgType === 'invite_code') {
      const count = cardConfig.inviteCodeCount || 1
      const maxUses = cardConfig.maxUses || 1
      const rewardType = cardConfig.rewardType || 'membership'
      const rewardValue = cardConfig.rewardValue || 0
      const rewardDurationUnit = cardConfig.rewardDurationUnit || 'day'
      const rewardTargetId = cardConfig.targetId || 0
      const codes = []
      for (let i = 0; i < count; i++) {
        const code = 'INV' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 4).toUpperCase() + String(i)
        await query(
          `INSERT INTO invite_codes (code, created_by, created_by_name, max_uses, use_count, reward_type, reward_value, reward_duration_unit, reward_target_id, status, create_time) VALUES (?,?,?,?,0,?,?,?,?,'1',${nowExpr})`,
          [code, user.id, user.username || '', maxUses, rewardType, rewardValue, rewardDurationUnit, rewardTargetId]
        )
        codes.push(code)
        // tiny delay to avoid same timestamp
        await new Promise(r => setTimeout(r, 1))
      }
      deliveryInfo = `邀请码：${codes.join(', ')}`
    } else if (cfgType === 'custom') {
      const customCards = cardConfig.customCards || []
      if (customCards.length === 0) {
        deliveryInfo = '卡池已空，请联系客服'
      } else {
        // 随机抽取一张
        const idx = Math.floor(Math.random() * customCards.length)
        const card = customCards[idx]
        customCards.splice(idx, 1)
        // 更新规格的卡池和库存
        if (item.option_id) {
          cardConfig.customCards = customCards
          await query(
            `UPDATE mall_product_options SET card_config=?, stock=? WHERE id=?`,
            [JSON.stringify(cardConfig), customCards.length, item.option_id]
          )
          // 同步减商品主库存
          await query('UPDATE mall_products SET stock = stock - 1 WHERE id=? AND stock > 0', [product.id])
        }
        const parts = card.split(':')
        const cardNo = parts[0] || ''
        const cardPwd = parts.slice(1).join(':') || ''
        deliveryInfo = `卡密：${cardNo}，密码：${cardPwd}`
      }
    }

    return deliveryInfo
  }

  // ==================== 订单 ====================
  function genOrderNo() {
    const now = new Date()
    const d = now.toISOString().slice(2,10).replace(/-/g,'')
    const t = String(now.getHours()).padStart(2,'0') + String(now.getMinutes()).padStart(2,'0') + String(now.getSeconds()).padStart(2,'0')
    const r = Math.random().toString(36).slice(2,8).toUpperCase()
    return d + t + r
  }

  router.post('/api/mall/orders', authRequired, async (req, res) => {
    try {
      const { productId, optionId, quantity = 1, paymentMethod = 'balance', remark = '', userCustomFields = null, userCouponId, addressId } = req.body
      const userId = req.user?.userId

      const [productRows] = await Promise.all([
        query('SELECT * FROM mall_products WHERE id=?', [productId])
      ])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      if (product.status !== 'published') return res.json({ code: 400, msg: '商品已下架' })
      if (product.sale_end_time) {
        await checkProductSaleEnd(productId)
        const [updated] = await query('SELECT status FROM mall_products WHERE id=?', [productId])
        if (updated && updated.status !== 'published') return res.json({ code: 400, msg: '商品销售已截止' })
      }

      let price = product.price
      let optionName = ''
      let optionIdVal = optionId || 0
      if (optionIdVal) {
        const optRows = await query('SELECT * FROM mall_product_options WHERE id=? AND product_id=?', [optionIdVal, productId])
        if (optRows.length) { price = optRows[0].price; optionName = optRows[0].name }
      }

      let totalAmount = price * quantity
      if (paymentMethod === 'points') {
        if (optionIdVal) {
          const optRows2 = await query('SELECT points_price FROM mall_product_options WHERE id=?', [optionIdVal])
          if (optRows2.length && optRows2[0].points_price) totalAmount = optRows2[0].points_price * quantity
        } else if (product.points_price) {
          totalAmount = product.points_price * quantity
        }
      }
      // ===== 促销活动折扣 =====
      let promotionDiscount = 0
      let promotionName = ''
      const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ')
      const promos = await query(
        `SELECT DISTINCT pr.* FROM mall_promotions pr
         LEFT JOIN mall_promotion_products pp ON pr.id = pp.promotion_id
         WHERE pr.status='1' AND pr.start_time <= ? AND pr.end_time >= ?
         AND (pp.product_id = ? OR pp.product_id IS NULL OR NOT EXISTS (SELECT 1 FROM mall_promotion_products WHERE promotion_id=pr.id))`,
        [nowStr, nowStr, productId]
      )
      if (promos.length) {
        const promo = promos[0]
        if (promo.type === 'discount') {
          if (!promo.min_amount || totalAmount >= promo.min_amount) {
            promotionDiscount = Math.min(totalAmount * promo.discount_value / 100, promo.max_discount || totalAmount)
            promotionName = promo.name
          }
        } else if (promo.type === 'fixed') {
          if (!promo.min_amount || totalAmount >= promo.min_amount) {
            promotionDiscount = Math.min(promo.discount_value, totalAmount)
            promotionName = promo.name
          }
        }
        totalAmount = Math.round((totalAmount - promotionDiscount) * 100) / 100
        if (totalAmount < 0) totalAmount = 0
      }
      const freight = product.freight || 0
      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // ===== 优惠券处理 =====
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const result = await applyCoupon(userCouponId, userId, totalAmount, paymentMethod, 0)
        if (result.error) return res.json({ code: 400, msg: result.error })
        couponDiscount = result.couponDiscount
        couponUsedId = result.couponUsedId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      // ===== 扣款 =====
      if (paymentMethod === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `余额不足，需要 ¥${finalAmount}，当前余额 ¥${currentBalance}` })
        }
        await deductBalance(userId, user.username || '', finalAmount, '商城购物', `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣¥' + couponDiscount + ')' : ''}`)
      } else if (paymentMethod === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `积分不足，需要 ${finalAmount} 积分，当前积分 ${currentPoints}` })
        }
        await deductPoints(userId, user.username || '', finalAmount, '商城购物', `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣' + couponDiscount + '积分)' : ''}`)
      }

      // ===== 获取收货地址 =====
      let receiverName = '', receiverPhone = '', receiverAddress = ''
      if (addressId) {
        const addrRows = await query('SELECT * FROM user_addresses WHERE id=? AND user_id=?', [addressId, userId])
        if (addrRows.length) {
          const a = addrRows[0]
          receiverName = a.name || ''
          receiverPhone = a.phone || ''
          receiverAddress = `${a.province}${a.city}${a.district}${a.detail}`
        }
      }

      // ===== 创建订单（已支付） =====
      const orderNo = genOrderNo()
      const orderResult = await query(
        `INSERT INTO mall_orders (order_no, user_id, status, total_amount, freight, payment_method, discount_amount, remark, receiver_name, receiver_phone, receiver_address, user_custom_fields, payment_time, create_time, update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,${nowExpr},${nowExpr},${nowExpr})`,
        [orderNo, userId, 'paid', totalAmount, freight, paymentMethod, couponDiscount, remark, receiverName, receiverPhone, receiverAddress, JSON.stringify(userCustomFields || {})]
      )
      const orderId = orderResult.insertId

      await query(
        `INSERT INTO mall_order_items (order_id, product_id, option_id, product_name, option_name, price, quantity, image, virtual_content)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [orderId, productId, optionIdVal, product.name, optionName, price, quantity, product.cover_image || '', product.virtual_content || '']
      )

      // ===== 销量 + 库存 =====
      await query('UPDATE mall_products SET sales_count = sales_count + ? WHERE id=?', [quantity, productId])
      if (optionIdVal) {
        await query('UPDATE mall_product_options SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, optionIdVal, quantity])
      } else {
        await query('UPDATE mall_products SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, productId, quantity])
      }

      // ===== 虚拟商品自动发货 =====
      let deliveryInfo = ''
      if (product.product_type && product.product_type.startsWith('virtual')) {
        const item = { id: orderId, product_id: productId, option_id: optionIdVal, quantity }
        deliveryInfo = await autoDeliver(item, product, user)
        if (deliveryInfo) {
          await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
        }
      }

      // ===== 系统通知 =====
      const sysOp = await getSystemOperator()
      const sysOpName = (sysOp && sysOp.username) ? sysOp.username : '管理员'
      const unit = paymentMethod === 'balance' ? '元' : '积分'
      let notifyContent = `您已成功购买《${product.name || ''}》，支付 ${finalAmount}${unit}`
      if (couponDiscount > 0) {
        notifyContent += `（优惠券抵扣 ${couponDiscount}${unit}）`
      }
      if (deliveryInfo) {
        notifyContent += `\n发货内容：${deliveryInfo}`
      }
      try {
        await query(
          `INSERT INTO sys_notifications (from_user_id, from_user_name, target_user_id, title, content, type, create_time)
           VALUES (?,?,?,?,?,'system',${nowExpr})`,
          [sysOp && sysOp.id ? sysOp.id : 1, sysOpName, userId, `购买商品《${product.name || ''}》`, notifyContent]
        )
      } catch (e) { console.error('[mall] purchase notification failed:', orderId, e.message) }

      // 返佣计算
      try { calcCommission(orderId, 'mall', totalAmount, userId, paymentMethod) } catch (e) { console.error('[mall] commission calc failed:', orderId, e.message) }

      res.json({ code: 200, msg: '支付成功', data: {
        id: orderId, orderNo,
        productType: product.product_type || '',
        deliveryInfo
      }})
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/orders/:id/pay', authRequired, async (req, res) => {
    try {
      const { paymentMethod = 'balance', userCouponId } = req.body
      const userId = req.user?.userId

      const orderRows = await query('SELECT * FROM mall_orders WHERE id=? AND user_id=?', [req.params.id, userId])
      if (!orderRows.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orderRows[0]
      if (order.status !== 'pending') return res.json({ code: 400, msg: '订单状态不允许支付' })

      const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [req.params.id])
      if (!items.length) return res.json({ code: 400, msg: '订单无商品' })
      const item = items[0]

      const productRows = await query('SELECT * FROM mall_products WHERE id=?', [item.product_id])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      const priceType = product.price_type || 'balance'
      let totalAmount = Number(order.total_amount)

      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // 优惠券验证与使用
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const result = await applyCoupon(userCouponId, userId, totalAmount, paymentMethod || 'balance', req.params.id)
        if (result.error) return res.json({ code: 400, msg: result.error })
        couponDiscount = result.couponDiscount
        couponUsedId = result.couponUsedId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      if (paymentMethod === 'balance') {
        const currentBalance = Number(user.balance || 0)
        if (currentBalance < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `余额不足，需要 ¥${finalAmount}，当前余额 ¥${currentBalance}` })
        }
        await deductBalance(userId, user.username || '', finalAmount, '商城购物', `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣¥' + couponDiscount + ')' : ''}`)
      } else if (paymentMethod === 'points') {
        const currentPoints = Number(user.points || 0)
        if (currentPoints < finalAmount) {
          if (couponUsedId) {
            await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
          }
          return res.json({ code: 400, msg: `积分不足，需要 ${finalAmount} 积分，当前积分 ${currentPoints}` })
        }
        await deductPoints(userId, user.username || '', finalAmount, '商城购物', `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣' + couponDiscount + '积分)' : ''}`)
      }

      // 创建订单
      const result = await query(
        `INSERT INTO mall_reviews (product_id, user_id, order_id, rating, content, images, dim_product_rating, dim_service_rating, dim_logistics_rating) VALUES (?,?,?,?,?,?,?,?,?)`,
        [productId, userId, orderId || 0, rating, content || '', JSON.stringify(imgs), dp, ds, dl]
      )
      await query('UPDATE mall_products SET avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM mall_reviews WHERE product_id=?) WHERE id=?', [productId, productId])
      res.json({ code: 200, msg: '评价成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/reviews/:id/reply', async (req, res) => {
    try {
      const { reply } = req.body
      await query(`UPDATE mall_reviews SET reply=?, reply_time=${nowExpr} WHERE id=?`, [reply, req.params.id])
      res.json({ code: 200, msg: '回复成功' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 12. 创建售后 ==========
  router.post('/api/mall/after-sales', authRequired, async (req, res) => {
    try {
      const userId = req.user?.userId || req.body.userId || 0
      const orderId = req.body.orderId || req.body.order_id
      const { type, reason, images, description } = req.body
      if (!orderId || !type) return res.json({ code: 400, msg: '缺少必要参数' })
      const order = await query('SELECT id, user_id FROM mall_orders WHERE id=?', [Number(orderId)])
      if (!order.length) return res.json({ code: 404, msg: '订单不存在' })
      const result = await query(
        `INSERT INTO mall_after_sales (order_id, user_id, type, reason, description, images) VALUES (?,?,?,?,?,?)`,
        [Number(orderId), Number(userId), type, reason || '', description || '', JSON.stringify(images || [])]
      )
      res.json({ code: 200, msg: '售后申请已提交', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 9. 用户地址管理 ==========
  router.get('/api/user/addresses', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const list = await query(
        'SELECT id, user_id as userId, name, phone, province, city, district, detail, is_default as isDefault, create_time as createTime FROM user_addresses WHERE user_id=? ORDER BY is_default DESC, id DESC',
        [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/user/addresses', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { name, phone, province, city, district, detail, isDefault } = req.body
      if (isDefault) await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      const result = await query(
        'INSERT INTO user_addresses (user_id, name, phone, province, city, district, detail, is_default) VALUES (?,?,?,?,?,?,?,?)',
        [userId, name || '', phone || '', province || '', city || '', district || '', detail || '', isDefault ? 1 : 0]
      )
      res.json({ code: 200, msg: '添加成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/user/addresses/:id', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { name, phone, province, city, district, detail, isDefault } = req.body
      if (isDefault) await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      await query(
        'UPDATE user_addresses SET name=?, phone=?, province=?, city=?, district=?, detail=?, is_default=? WHERE id=? AND user_id=?',
        [name || '', phone || '', province || '', city || '', district || '', detail || '', isDefault ? 1 : 0, Number(req.params.id), userId]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/user/addresses/:id', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      await query('DELETE FROM user_addresses WHERE id=? AND user_id=?', [Number(req.params.id), userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/user/addresses/:id/default', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      await query('UPDATE user_addresses SET is_default=1 WHERE id=? AND user_id=?', [Number(req.params.id), userId])
      res.json({ code: 200, msg: '已设为默认地址' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 10. 商城收藏 ==========
  router.post('/api/mall/favorites/:productId', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const productId = Number(req.params.productId)
      const existing = await query('SELECT id FROM mall_favorites WHERE user_id=? AND product_id=?', [userId, productId])
      if (existing.length > 0) {
        await query('DELETE FROM mall_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query('INSERT INTO mall_favorites (user_id, product_id) VALUES (?,?)', [userId, productId])
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/favorites', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const list = await query(
        `SELECT f.id, f.product_id as productId, f.create_time as createTime,
                p.name, p.cover_image as coverImage, p.price, p.price_type as priceType,
                p.sales_count as salesCount, p.status
         FROM mall_favorites f
         JOIN mall_products p ON f.product_id=p.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) { res.serverError(e) }
  })

}

module.exports = mallRoutes
