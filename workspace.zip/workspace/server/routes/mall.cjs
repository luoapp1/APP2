const { query, getSystemOperator } = require('../database.cjs')
const { addBalance, addPoints, deductBalance, deductPoints, addExperience, refundCurrency, spendCurrency } = require('./account-utils.cjs')
const { hasPermission, getPermissionValue } = require('../middleware/level-permissions.cjs')
const { authRequired, optionalAuth, requirePermission } = require('./system.cjs')
const { sendNotificationEmail } = require('./email.cjs')
const { calcCommission } = require('./commission.cjs')
const { executePenalty } = require('./custom-task.cjs')
const kdniao = require('../utils/kdniao.cjs')
const logisticsConfig = require('./logistics-config.cjs')
const cardPoolRoutes = require('./card-pool.cjs')
const nowExpr = 'NOW()'

let _currencyUnitCache = null
async function getCurrencyUnit(currencyKey) {
  if (!_currencyUnitCache) {
    const rows = await query('SELECT currency_key, display_name FROM currency_settings')
    _currencyUnitCache = {}
    for (const r of rows) {
      _currencyUnitCache[r.currency_key] = r.display_name || r.currency_key
    }
  }
  return _currencyUnitCache[currencyKey] || currencyKey
}

function mallRoutes(router) {

  // 检查商品是否在销售期内，过期自动标记为下架
  async function checkProductSaleEnd(pid) {
    await query(`UPDATE mall_products SET status='off' WHERE id=? AND sale_end_time IS NOT NULL AND sale_end_time < NOW() AND status='1'`, [pid])
  }


  async function applyCoupon(userCouponId, userId, totalAmount, paymentMethod, orderRefId) {
    const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [userCouponId, userId])
    if (!uc.length) return { error: '优惠券不存在或不属于您' }
    if (uc[0].status !== 'unused') return { error: '优惠券已使用或已过期' }

    const now = new Date().toISOString().replace('T', ' ').slice(0, 19)
    if (uc[0].expire_time && uc[0].expire_time < now) {
      await query("UPDATE user_coupons SET status='expired' WHERE id=?", [userCouponId])
      return { error: '优惠券已过期' }
    }

    const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
    const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
    if (!c.length) return { error: '优惠券模板不存在' }

    const scope = c[0].scope || cd.scope || ''
    if (scope && scope !== 'all' && scope !== 'mall') {
      return { error: '此优惠券不适用于商城场景' }
    }

    const minOrder = Number(c[0].min_order || cd.minOrder || 0)
    if (totalAmount < minOrder) {
      return { error: `未达到最低消费 ¥${minOrder}` }
    }

    const type = c[0].type || cd.type || ''
    const value = Number(c[0].value || cd.value || 0)
    const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
    const isMultiUse = !!(c[0].is_multi_use)

    const isPointsCoupon = type.includes('points')
    if (isPointsCoupon && paymentMethod !== 'points') {
      return { error: '此券仅限积分支付时使用' }
    }
    if (!isPointsCoupon && paymentMethod === 'points') {
      return { error: '此券仅限余额支付时使用' }
    }

    let availableValue = value
    if (isMultiUse) {
      availableValue = uc[0].remaining_value !== null ? Number(uc[0].remaining_value) : value
    }

    let couponDiscount = 0
    if (type === 'fixed' || type.includes('fixed')) {
      couponDiscount = Math.min(availableValue, totalAmount)
    } else if (type === 'percent' || type === 'discount' || type.includes('discount') || type.includes('percent')) {
      couponDiscount = Math.floor(totalAmount * value / 100 * 100) / 100
      if (maxDisc > 0 && couponDiscount > maxDisc) couponDiscount = maxDisc
      couponDiscount = Math.min(couponDiscount, totalAmount)
    } else {
      couponDiscount = Math.min(value, totalAmount)
    }

    const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
    if (isMultiUse) {
      if (afterRemaining <= 0) {
        await query(
          `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=0 WHERE id=?`,
          [now, orderRefId, couponDiscount, userCouponId]
        )
      } else {
        await query(
          `UPDATE user_coupons SET use_time=?, use_scene='mall', use_order_id=?, use_amount=use_amount+?, remaining_value=? WHERE id=?`,
          [now, orderRefId, couponDiscount, afterRemaining, userCouponId]
        )
      }
    } else {
      await query(
        `UPDATE user_coupons SET status='used', use_time=?, use_scene='mall', use_order_id=?, use_amount=?, remaining_value=NULL WHERE id=?`,
        [now, orderRefId, couponDiscount, userCouponId]
      )
    }

    return { couponDiscount, couponUsedId: userCouponId }
  }

  // ==================== 分类 ====================
  router.get('/api/mall/categories/all', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/categories', async (req, res) => {
    try {
      const rows = await query('SELECT id, parent_id as parentId, name, icon, sort_order as sortOrder, status FROM mall_categories WHERE status=? AND parent_id=0 ORDER BY sort_order ASC, id ASC', ['1'])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  // 分类管理 - 增删改
  router.post('/api/mall/categories', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const { name, parentId, icon, sortOrder } = req.body
      if (!name) return res.json({ code: 400, msg: '分类名称不能为空' })
      const result = await query(
        'INSERT INTO mall_categories (parent_id, name, icon, sort_order, status) VALUES (?,?,?,?,?)',
        [parentId || 0, name, icon || '', sortOrder || 0, '1']
      )
      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/categories/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const { name, parentId, icon, sortOrder, status } = req.body
      await query(
        'UPDATE mall_categories SET parent_id=?, name=?, icon=?, sort_order=?, status=? WHERE id=?',
        [parentId || 0, name || '', icon || '', sortOrder || 0, status || '1', Number(req.params.id)]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/categories/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const [children, products] = await Promise.all([
        query('SELECT COUNT(*) as cnt FROM mall_categories WHERE parent_id=?', [req.params.id]),
        query('SELECT COUNT(*) as cnt FROM mall_products WHERE category_id=?', [req.params.id])
      ])
      if (children[0].cnt > 0) return res.json({ code: 400, msg: '该分类下有子分类，无法删除' })
      if (products[0].cnt > 0) return res.json({ code: 400, msg: '该分类下有商品，无法删除' })
      await query('DELETE FROM mall_categories WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  // ==================== 购物车 ====================
  router.get('/api/mall/cart', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const rows = await query(
        `SELECT c.id, c.user_id as userId, c.product_id as productId, c.option_id as optionId, c.quantity,
                p.name as productName, p.cover_image as coverImage, p.price, p.original_price as originalPrice,
                p.stock, p.status as productStatus, p.price_type as priceType, p.freight,
                o.name as optionName, o.price as optionPrice, o.original_price as optionOriginalPrice, o.stock as optionStock, o.image as optionImage
         FROM mall_cart_items c
         JOIN mall_products p ON c.product_id = p.id
         LEFT JOIN mall_product_options o ON c.option_id = o.id
         WHERE c.user_id = ?
         ORDER BY c.id DESC`, [userId])
      res.json({ code: 200, data: rows })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/cart', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { productId, optionId, quantity = 1 } = req.body
      if (!productId) return res.json({ code: 400, msg: '请选择商品' })
      const productRows = await query('SELECT id, status, stock FROM mall_products WHERE id=?', [productId])
      if (!productRows || !productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      if (productRows[0].status !== 'published' && productRows[0].status !== '1') return res.json({ code: 400, msg: '商品已下架' })

      const existing = await query(
        'SELECT id, quantity FROM mall_cart_items WHERE user_id=? AND product_id=? AND option_id=?',
        [userId, productId, optionId || 0]
      )
      if (existing.length) {
        await query('UPDATE mall_cart_items SET quantity = quantity + ? WHERE id=?', [quantity, existing[0].id])
        res.json({ code: 200, msg: '已更新购物车数量' })
      } else {
        await query(
          'INSERT INTO mall_cart_items (user_id, product_id, option_id, quantity) VALUES (?,?,?,?)',
          [userId, productId, optionId || 0, quantity]
        )
        res.json({ code: 200, msg: '已加入购物车' })
      }
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/cart/:id', authRequired, async (req, res) => {
    try {
      const { quantity } = req.body
      if (quantity < 1) return res.json({ code: 400, msg: '数量不能小于1' })
      await query('UPDATE mall_cart_items SET quantity=? WHERE id=? AND user_id=?', [quantity, req.params.id, req.user.userId])
      res.json({ code: 200, msg: '已更新' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/cart/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM mall_cart_items WHERE id=? AND user_id=?', [req.params.id, req.user.userId])
      res.json({ code: 200, msg: '已移除' })
    } catch (e) { res.serverError(e) }
  })

  // 购物车清空/批量删除
  router.post('/api/mall/cart/clear', authRequired, async (req, res) => {
    try {
      const { ids } = req.body
      if (ids && ids.length) {
        await query(`DELETE FROM mall_cart_items WHERE user_id=? AND id IN (${ids.map(() => '?').join(',')})`, [req.user.userId, ...ids])
      } else {
        await query('DELETE FROM mall_cart_items WHERE user_id=?', [req.user.userId])
      }
      res.json({ code: 200, msg: '已清空' })
    } catch (e) { res.serverError(e) }
  })

  // 购物车结算下单
  router.post('/api/mall/cart/checkout', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { cartIds, addressId, remark = '', userCouponId } = req.body

      if (!cartIds || !cartIds.length) return res.json({ code: 400, msg: '请选择要结算的商品' })

      const cartItems = await query(
        `SELECT c.*, p.name, p.price, p.price_type, p.product_type, p.product_subtype, p.decoration_id, p.duration_days, p.virtual_content, p.status, p.stock, p.freight,
                o.name as option_name, o.price as option_price, o.stock as option_stock
         FROM mall_cart_items c
         JOIN mall_products p ON c.product_id = p.id
         LEFT JOIN mall_product_options o ON c.option_id = o.id
         WHERE c.user_id=? AND c.id IN (${cartIds.map(() => '?').join(',')})`,
        [userId, ...cartIds]
      )

      if (!cartItems.length) return res.json({ code: 400, msg: '购物车为空' })

      // 校验库存
      for (const item of cartItems) {
        if (item.status !== 'published' && item.status !== '1') return res.json({ code: 400, msg: `商品"${item.name}"已下架` })
        if (item.option_id && item.option_stock < item.quantity) return res.json({ code: 400, msg: `"${item.name} - ${item.option_name}"库存不足` })
        if (!item.option_id && item.stock < item.quantity) return res.json({ code: 400, msg: `商品"${item.name}"库存不足` })
      }

      const userRows = await query('SELECT username FROM users WHERE id=?', [userId])
      if (userRows && userRows.length > 0) {
        const balRows = await query('SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=\'balance\'', [userId])
        userRows[0].balance = Number(balRows[0]?.available || 0)
      }
      const user = userRows[0]

      // 计算总金额
      let totalAmount = 0
      let totalFreight = 0
      for (const item of cartItems) {
        const unitPrice = item.option_price || item.price
        totalAmount += unitPrice * item.quantity
        totalFreight += item.freight || 0
      }

      // 优惠券处理
      let couponDiscount = 0
      if (userCouponId) {
        const couponRows = await query(
          'SELECT coupon_data, id FROM user_coupons WHERE id=? AND user_id=? AND status=? AND expire_time > NOW()',
          [userCouponId, userId, 'unused']
        )
        if (couponRows.length) {
          const uc = couponRows[0]
          const couponData = safeJSON(uc.coupon_data)
          if (couponData.type === 'fixed') couponDiscount = Math.min(couponData.value, totalAmount)
          else if (couponData.type === 'percent') couponDiscount = Math.min(totalAmount * couponData.value / 100, couponData.max_discount || totalAmount)
          if (totalAmount - couponDiscount < couponData.min_order) couponDiscount = 0
          else {
            totalAmount -= couponDiscount
            await query('UPDATE user_coupons SET status=?, use_scene=?, use_time=NOW() WHERE id=?', ['used', 'mall', uc.id])
          }
        }
      }

      // 扣款
      if (user.balance < totalAmount) return res.json({ code: 400, msg: `余额不足，需要¥${totalAmount.toFixed(2)}，当前余额¥${Number(user.balance).toFixed(2)}` })
      await deductBalance(userId, user.username || '', totalAmount, '商城购物', `商城下单，共${cartItems.length}件商品`)

      // 获取地址信息
      let receiverName = '', receiverPhone = '', addressInfo = ''
      if (addressId) {
        const addrRows = await query('SELECT name, phone, province, city, district, detail FROM user_addresses WHERE id=? AND user_id=?', [addressId, userId])
        if (addrRows.length) {
          const a = addrRows[0]
          receiverName = a.name || ''
          receiverPhone = a.phone || ''
          addressInfo = `${a.province}${a.city}${a.district}${a.detail}`
        }
      }

      // 逐个商品创建订单和发货
      const orderIds = []
      const deliveryItems = []
      for (const item of cartItems) {
        const product = { id: item.product_id, name: item.name, product_type: item.product_type, virtual_content: item.virtual_content }
        const unitPrice = item.option_price || item.price
        const itemTotal = unitPrice * item.quantity

        const orderNo = genOrderNo()
        let insertId
        try {
          const result = await query(
            `INSERT INTO mall_orders (order_no, user_id, status, total_amount, discount_amount, freight, payment_method, payment_time, remark, receiver_name, receiver_phone, receiver_address, user_custom_fields) VALUES (?,?,'paid',?,0,0,'balance',NOW(),?,?,?,?,?)`,
            [orderNo, userId, itemTotal, remark || '', receiverName, receiverPhone, addressInfo, JSON.stringify({})]
          )
          const orderId = result.insertId
          orderIds.push(orderId)

          // 订单商品
          const productName = item.option_name ? `${item.name} (${item.option_name})` : item.name
          await query(
            'INSERT INTO mall_order_items (order_id, product_id, option_id, product_name, option_name, price, quantity, image) VALUES (?,?,?,?,?,?,?,?)',
            [orderId, item.product_id, item.option_id || 0, productName, item.option_name || '', unitPrice, item.quantity, '']
          )

          // 虚拟商品自动发货
          const orderItem = { id: orderId, option_id: item.option_id, quantity: item.quantity }
          let deliveryInfo = ''
          if (item.product_type && item.product_type !== 'physical') {
            deliveryInfo = await autoDeliver(orderItem, product, user)
          }
          if (deliveryInfo) {
            await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
            deliveryItems.push({ orderId, productName, deliveryInfo })
            // 站内通知
            try {
              await query(
                `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
                ['购买成功', `您购买的商品「${productName}」已发货：${deliveryInfo}`, 'mall', user.id]
              )
            } catch {}
          }

          // 减库存
          if (item.option_id) {
            await query('UPDATE mall_product_options SET stock = GREATEST(stock - ?, 0) WHERE id=?', [item.quantity, item.option_id])
          }
          await query('UPDATE mall_products SET stock = GREATEST(stock - ?, 0), sales_count = sales_count + ? WHERE id=?', [item.quantity, item.quantity, item.product_id])
        } catch (e) {
          console.error('创建订单失败:', e)
        }
      }

      // 清空已结算的购物车项
      await query(`DELETE FROM mall_cart_items WHERE id IN (${cartIds.map(() => '?').join(',')})`, cartIds)

      let msg = `下单成功！共${orderIds.length}笔订单，实付¥${totalAmount.toFixed(2)}`
      if (couponDiscount > 0) msg += `，优惠券抵扣¥${couponDiscount.toFixed(2)}`
      
      // 如果只有一个订单且只有一件商品，返回订单ID
      const firstOrderId = orderIds[0] || 0
      res.json({ code: 200, msg, data: { orderIds, totalAmount, couponDiscount, orderId: firstOrderId, deliveryItems } })
    } catch (e) { res.serverError(e) }
  })

  // ==================== 商品 ====================
  router.get('/api/mall/products', optionalAuth, async (req, res) => {
    try {
      const { categoryId, status, productType, priceType, isRecommended, admin, userId, minPrice, maxPrice, sortBy, sortOrder, page = 1, pageSize = 20 } = req.query
      const params = []
      let where = '1=1'
      if (categoryId) { where += ' AND p.category_id=?'; params.push(categoryId) }
      if (productType) { where += ' AND p.product_type=?'; params.push(productType) }
      if (priceType) { where += ' AND p.price_type=?'; params.push(priceType) }
      if (isRecommended) { where += ' AND p.is_recommended=1' }
      if (userId) { where += ' AND p.created_by=?'; params.push(userId) }
      if (minPrice) { where += ' AND p.price >= ?'; params.push(Number(minPrice)) }
      if (maxPrice) { where += ' AND p.price <= ?'; params.push(Number(maxPrice)) }

      let orderBy = 'p.sort_order, p.id DESC'
      const so = (sortOrder || 'desc').toLowerCase()
      const dir = so === 'asc' ? 'ASC' : 'DESC'
      switch (sortBy) {
        case 'sales': orderBy = `p.sales_count ${dir}, p.sort_order`; break
        case 'price': orderBy = `p.price ${dir}, p.sort_order`; break
        case 'newest': orderBy = `p.id ${dir}`; break
        case 'rating': orderBy = `p.avg_rating ${dir}, p.sort_order`; break
        default: break
      }

      const [countRows, listRows] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM mall_products p WHERE ${where}`, params),
        query(
          `SELECT p.*, c.name as category_name
           FROM mall_products p LEFT JOIN mall_categories c ON p.category_id=c.id
           WHERE ${where} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
        )
      ])

      // 装饰品商品：回退到装饰品表自身的图标
      {
        const imageMap = {}
        // 1) 商品级 decoration_id
        const productDecs = listRows.filter(r => r.product_type === 'decoration' && !r.cover_image && r.decoration_id)
        if (productDecs.length) {
          const afIds = [...new Set(productDecs.filter(r => r.product_subtype === 'avatar_frame').map(r => r.decoration_id))]
          const otherIds = [...new Set(productDecs.filter(r => r.product_subtype !== 'avatar_frame').map(r => r.decoration_id))]
          await fetchDecorationImages(afIds, otherIds, imageMap)
          listRows.forEach(r => {
            if (!r.cover_image && imageMap[r.decoration_id]) r.cover_image = imageMap[r.decoration_id]
          })
        }
        // 2) virtual_auto 商品：从规格 card_config 中取 decorationId
        const virtualAutoProds = listRows.filter(r => r.product_type === 'virtual_auto' && !r.cover_image)
        if (virtualAutoProds.length) {
          const prodIds = virtualAutoProds.map(r => r.id)
          try {
            const optRows = await query(
              `SELECT product_id, card_config FROM mall_product_options WHERE product_id IN (${prodIds.map(() => '?').join(',')}) ORDER BY sort_order`,
              prodIds
            )
            const afIds = []
            const otherIds = []
            const prodDecMap = {}
            optRows.forEach(opt => {
              const cfg = safeJSON(opt.card_config)
              if (cfg && cfg.type === 'decoration' && cfg.decorationId) {
                prodDecMap[opt.product_id] = cfg.decorationId
                if (cfg.decorationSubtype === 'avatar_frame') {
                  afIds.push(cfg.decorationId)
                } else {
                  otherIds.push(cfg.decorationId)
                }
              }
            })
            if (afIds.length || otherIds.length) {
              await fetchDecorationImages([...new Set(afIds)], [...new Set(otherIds)], imageMap)
              listRows.forEach(r => {
                if (!r.cover_image && prodDecMap[r.id] && imageMap[prodDecMap[r.id]]) {
                  r.cover_image = imageMap[prodDecMap[r.id]]
                }
              })

              // 填充 virtual_auto 商品的 decorationConfig（实时预览用）
              const configMap2 = {}
              if (otherIds.length) {
                try {
                  const cfgRows = await query(`SELECT id, config_json FROM decorations WHERE id IN (${otherIds.map(() => '?').join(',')})`, [...new Set(otherIds)])
                  cfgRows.forEach(r2 => { configMap2[r2.id] = safeJSON(r2.config_json) })
                } catch {}
              }
              if (Object.keys(configMap2).length) {
                listRows.forEach(r => {
                  if (r.decorationConfig) return
                  const decId = prodDecMap[r.id]
                  if (decId && configMap2[decId]) {
                    r.decorationConfig = configMap2[decId]
                  }
                })
              }
            }
          } catch {}
        }

        // 3) config_json (实时预览用)
        const configMap = {}
        const allDecProds = listRows.filter(r => r.product_type === 'decoration' && r.decoration_id)
        if (allDecProds.length) {
          const afCfgIds = [...new Set(allDecProds.filter(r => r.product_subtype === 'avatar_frame').map(r => r.decoration_id))]
          const otherCfgIds = [...new Set(allDecProds.filter(r => r.product_subtype !== 'avatar_frame').map(r => r.decoration_id))]
          if (afCfgIds.length) {
            try {
              const rows = await query(`SELECT id, config_json FROM avatar_frames WHERE id IN (${afCfgIds.map(() => '?').join(',')})`, afCfgIds)
              rows.forEach(r => { configMap[r.id] = safeJSON(r.config_json) })
            } catch {}
          }
          if (otherCfgIds.length) {
            try {
              const rows = await query(`SELECT id, config_json FROM decorations WHERE id IN (${otherCfgIds.map(() => '?').join(',')})`, otherCfgIds)
              rows.forEach(r => { configMap[r.id] = safeJSON(r.config_json) })
            } catch {}
          }
          listRows.forEach(r => {
            if (r.decoration_id && configMap[r.decoration_id]) {
              r.decorationConfig = configMap[r.decoration_id]
            }
          })
        }
      }

      // 加载规格选项：提取天数、最低积分价、拥有状态
      const allProdIds = listRows.map(r => r.id)
      let durationLabelMap = {}
      let minPointsPriceMap = {}
      let ownedStatusMap = {}
      if (allProdIds.length) {
        let optRows = []
        try {
          optRows = await query(
            `SELECT id, product_id, points_price, currency_prices, card_config FROM mall_product_options WHERE product_id IN (${allProdIds.map(() => '?').join(',')}) ORDER BY sort_order`,
            allProdIds
          )
        } catch {}

        // 天数标签 & 最低积分价
        optRows.forEach(o => {
          const cfg = safeJSON(o.card_config)
          let days = 0
          let isPerm = false
          if (cfg) {
            if (cfg.decorationDurationDays > 0) days = cfg.decorationDurationDays
            else if ('decorationDurationDays' in cfg && cfg.decorationDurationDays === 0) isPerm = true
            else if (cfg.value > 0 && cfg.durationUnit === 'day') days = cfg.value
            else if (cfg.value === 0 && cfg.durationUnit === 'day') isPerm = true
          }
          if (isPerm) {
            durationLabelMap[o.product_id] = '永久'
          } else if (days > 0 && durationLabelMap[o.product_id] !== '永久') {
            const prev = durationLabelMap[o.product_id]
            const prevDays = prev ? parseInt(prev) || 0 : 0
            if (days > prevDays) durationLabelMap[o.product_id] = days + '天'
          }
          if (o.points_price > 0 && (!minPointsPriceMap[o.product_id] || o.points_price < minPointsPriceMap[o.product_id])) {
            minPointsPriceMap[o.product_id] = o.points_price
          }
        })

        // 拥有状态（仅登录用户）
        if (req.user?.userId && optRows.length) {
          const userId = req.user.userId
          const decoByProduct = {}
          optRows.forEach(o => {
            const cfg = safeJSON(o.card_config)
            if (cfg?.type === 'decoration' && cfg.decorationId) {
              const key = `${cfg.decorationId}_${cfg.decorationSubtype || ''}`
              if (!decoByProduct[o.product_id]) {
                decoByProduct[o.product_id] = { decoId: cfg.decorationId, subtype: cfg.decorationSubtype || '', key }
              }
            }
          })

          if (Object.keys(decoByProduct).length) {
            const afIds = [...new Set(Object.values(decoByProduct).filter(d => d.subtype === 'avatar_frame').map(d => d.decoId))]
            const titleIds = [...new Set(Object.values(decoByProduct).filter(d => d.subtype === 'title').map(d => d.decoId))]
            const otherEntries = Object.values(decoByProduct).filter(d => d.subtype && d.subtype !== 'avatar_frame' && d.subtype !== 'title')
            const otherDecIds = [...new Set(otherEntries.map(d => d.decoId))]
            const otherSubtypes = [...new Set(otherEntries.map(d => d.subtype))]

            const owned = {} // decoId_subtype -> { isPermanent, expireTime }

            if (afIds.length) {
              const rows = await query('SELECT frame_id FROM user_avatar_frames WHERE user_id=? AND frame_id IN (' + afIds.map(() => '?').join(',') + ')', [userId, ...afIds])
              rows.forEach(r => { owned[`${r.frame_id}_avatar_frame`] = { isPermanent: true } })
            }
            if (titleIds.length) {
              const rows = await query('SELECT title_id, expire_time FROM user_titles WHERE user_id=? AND title_id IN (' + titleIds.map(() => '?').join(',') + ')', [userId, ...titleIds])
              rows.forEach(r => {
                const k = `${r.title_id}_title`
                if (!r.expire_time) { owned[k] = owned[k] ? { ...owned[k], isPermanent: true } : { isPermanent: true } }
                else if (!owned[k]) { owned[k] = { expireTime: r.expire_time } }
              })
            }
            if (otherDecIds.length && otherSubtypes.length) {
              const rows = await query('SELECT decoration_id, decoration_type, expire_time FROM user_decorations WHERE user_id=? AND decoration_id IN (' + otherDecIds.map(() => '?').join(',') + ') AND decoration_type IN (' + otherSubtypes.map(() => '?').join(',') + ')', [userId, ...otherDecIds, ...otherSubtypes])
              rows.forEach(r => {
                const k = `${r.decoration_id}_${r.decoration_type}`
                if (!r.expire_time) { owned[k] = owned[k] ? { ...owned[k], isPermanent: true } : { isPermanent: true } }
                else if (!owned[k]) { owned[k] = { expireTime: r.expire_time } }
              })
            }

            // 映射回商品
            const nowDate = new Date()
            Object.entries(decoByProduct).forEach(([pid, d]) => {
              const entry = owned[d.key]
              if (entry?.isPermanent) {
                ownedStatusMap[pid] = { status: 'permanent' }
              } else if (entry?.expireTime) {
                const remaining = Math.max(0, Math.ceil((new Date(entry.expireTime) - nowDate) / 86400000))
                if (remaining > 0 && (!ownedStatusMap[pid] || ownedStatusMap[pid].status !== 'permanent')) {
                  ownedStatusMap[pid] = { status: 'temporary', remainingDays: remaining }
                }
              }
              if (!ownedStatusMap[pid]) {
                ownedStatusMap[pid] = { status: 'not_owned' }
              }
            })
          }
        }
      }

      res.json({
        code: 200,
        data: {
          list: listRows.map(r => ({
            ...formatProduct(r),
            durationLabel: durationLabelMap[r.id] || getDurationLabel(null, r.duration_days),
            minPointsPrice: minPointsPriceMap[r.id] || 0,
            ownedStatus: ownedStatusMap[r.id] || null
          })),
          total: countRows[0]?.total || 0,
          page: Number(page),
          pageSize: Number(pageSize)
        }
      })
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/products/:id', async (req, res) => {
    try {
      const [rows, options, images] = await Promise.all([
        query('SELECT id, category_id, name, subtitle, description, cover_image, cover_video, price_type, price, original_price, currency_prices, stock, product_type, virtual_content, status, sales_count, is_recommended, sort_order, freight, services, purchase_limit_config, commission_config, custom_fields, after_sales_config, tags, product_params, payment_methods, created_by, created_by_name, sale_end_time, product_subtype, decoration_id, duration_days, bundle_config, product_type_config, preview_images, source_file_url, create_time, update_time FROM mall_products WHERE id=?', [req.params.id]),
        query('SELECT id, product_id, name, spec_name, price, original_price, points_price, currency_prices, stock, image, sort_order, card_config, purchase_limit FROM mall_product_options WHERE product_id=? ORDER BY sort_order', [req.params.id]),
        query('SELECT id, product_id, url, sort_order FROM mall_product_images WHERE product_id=? ORDER BY sort_order', [req.params.id])
      ])
      if (!rows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = formatProduct(rows[0])
      product.options = options.map(o => ({ id: o.id, productId: o.product_id, name: o.name, specName: o.spec_name || '', price: o.price, originalPrice: o.original_price, pointsPrice: o.points_price, currencyPrices: safeJSON(o.currency_prices), stock: o.stock, image: o.image, sortOrder: o.sort_order, purchaseLimit: o.purchase_limit || 0, cardConfig: safeJSON(o.card_config) }))
      product.images = images.map(i => ({ id: i.id, url: i.url, sortOrder: i.sort_order }))

      // 附带装饰品配置（实时预览用）
      if (product.decorationId) {
        const [decRows] = await query('SELECT config_json FROM decorations WHERE id = ?', [product.decorationId])
        if (decRows && (decRows).length) {
          product.decorationConfig = safeJSON(decRows[0].config_json)
        }
      }

      res.json({ code: 200, data: product })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/products', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const b = req.body
      const userId = req.user?.userId || 0
      const userName = req.user?.userName || ''

      // B1: 开店权限
      const canOpenStore = await hasPermission(userId, 'mall', 'B1')
      if (!canOpenStore) return res.json({ code: 403, msg: '当前等级不支持开店，请提升等级至Lv.4' })

      // B2: 上架商品数量上限
      const maxProducts = parseInt(await getPermissionValue(userId, 'mall', 'B2') || '999')
      const [countRow] = await query('SELECT COUNT(*) as cnt FROM mall_products WHERE created_by=? AND status!=\'deleted\'', [userId])
      if (countRow && Number(countRow.cnt) >= maxProducts) {
        return res.json({ code: 400, msg: `当前等级最多上架${maxProducts}个商品` })
      }

      // B3: 商品免审核
      if (await hasPermission(userId, 'mall', 'B3')) {
        b.status = 'published'
      }

      // B4: 商品定价上限
      const maxPrice = parseInt(await getPermissionValue(userId, 'mall', 'B4') || '0')
      if (maxPrice > 0 && Number(b.price || 0) > maxPrice) {
        return res.json({ code: 400, msg: `当前等级商品定价上限为${maxPrice}元` })
      }

      // 自动审核管线
      let productStatus = b.status || 'draft'
      try {
        const mp = require('./community/moderation-pipeline.cjs')
        const pipelineResult = await mp.moderationPipeline(userId, {
          text: (b.name || '') + ' ' + (b.description || ''),
          name: b.name || '',
          description: b.description || '',
          images: b.coverImage ? [b.coverImage] : [],
          price: b.price || 0
        }, 'product')
        if (pipelineResult.action === 'reject') {
          return res.json({ code: 400, msg: pipelineResult.reason || '内容不符合社区规范，无法创建' })
        }
        if (pipelineResult.action === 'publish') {
          productStatus = 'published'
        } else if (pipelineResult.status) {
          productStatus = pipelineResult.status
        }
      } catch (e) { console.error('[mall] moderation pipeline error:', e.message) }

      const result = await query(
        `INSERT INTO mall_products (category_id,name,subtitle,description,cover_image,cover_video,price_type,price,original_price,currency_prices,stock,product_type,virtual_content,status,is_recommended,sort_order,freight,services,purchase_limit_config,commission_config,custom_fields,after_sales_config,tags,product_params,payment_methods,sale_end_time,product_subtype,decoration_id,duration_days,bundle_config,created_by,created_by_name,create_time,update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,${nowExpr},${nowExpr})`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, JSON.stringify(b.currencyPrices || {}), b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', productStatus,
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null,
          b.productSubtype || '', b.decorationId || 0, b.durationDays || 0,
          JSON.stringify(b.bundleConfig || []), userId, userName]
      )
      const pid = result.insertId
      await saveProductRelations(pid, b)
      res.json({ code: 200, msg: '创建成功', data: { id: pid } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/products/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const b = req.body; const id = req.params.id
      await query(
        `UPDATE mall_products SET category_id=?,name=?,subtitle=?,description=?,cover_image=?,cover_video=?,price_type=?,price=?,original_price=?,currency_prices=?,stock=?,product_type=?,virtual_content=?,status=?,is_recommended=?,sort_order=?,freight=?,services=?,purchase_limit_config=?,commission_config=?,custom_fields=?,after_sales_config=?,tags=?,product_params=?,payment_methods=?,sale_end_time=?,product_subtype=?,decoration_id=?,duration_days=?,bundle_config=?,update_time=${nowExpr} WHERE id=?`,
        [b.categoryId || 0, b.name, b.subtitle || '', b.description || '', b.coverImage || '', b.coverVideo || '',
         b.priceType || 'balance', b.price || 0, b.originalPrice || 0, JSON.stringify(b.currencyPrices || {}), b.stock || 0,
         b.productType || 'virtual_auto', b.virtualContent || '', b.status || 'draft',
         b.isRecommended ? 1 : 0, b.sortOrder || 0, b.freight || 0,
         JSON.stringify(b.services || []), JSON.stringify(b.purchaseLimitConfig || []),
         JSON.stringify(b.commissionConfig || []), JSON.stringify(b.customFields || []),
         JSON.stringify(b.afterSalesConfig || {}), JSON.stringify(b.tags || []), JSON.stringify(b.productParams || []),
         JSON.stringify(b.paymentMethods || ['balance']), b.saleEndTime || null,
          b.productSubtype || '', b.decorationId || 0, b.durationDays || 0,
          JSON.stringify(b.bundleConfig || []), id]
      )
      await saveProductRelations(id, b)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/mall/products/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const id = req.params.id
      const product = await query('SELECT created_by FROM mall_products WHERE id=?', [id])
      const sellerId = product && product.length > 0 ? product[0].created_by : 0
      await Promise.all([
        query('DELETE FROM mall_products WHERE id=?', [id]),
        query('DELETE FROM mall_product_options WHERE product_id=?', [id]),
        query('DELETE FROM mall_product_images WHERE product_id=?', [id])
      ])
      if (sellerId) executePenalty(sellerId, '', 'product_fraud', {})
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  async function saveProductRelations(productId, body) {
    await query('DELETE FROM mall_product_options WHERE product_id=?', [productId])
    if (body.options && body.options.length) {
      for (const o of body.options) {
        await query(
          `INSERT INTO mall_product_options (product_id,name,spec_name,price,original_price,points_price,currency_prices,stock,image,sort_order,card_config,purchase_limit) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [productId, o.name, o.specName || '', o.price || 0, o.originalPrice || 0, o.pointsPrice || 0, JSON.stringify(o.currencyPrices || {}), o.stock || 0, o.image || '', o.sortOrder || 0, JSON.stringify(o.cardConfig || {}), o.purchaseLimit || 0]
        )
      }
    }
    await query('DELETE FROM mall_product_images WHERE product_id=?', [productId])
    if (body.images && body.images.length) {
      for (const img of body.images) {
        await query(
          `INSERT INTO mall_product_images (product_id,url,sort_order) VALUES (?,?,?)`,
          [productId, img.url || img, img.sortOrder || 0]
        )
      }
    }
  }

  function formatProduct(r) {
    return {
      ...r,
      categoryId: r.category_id, categoryName: r.category_name,
      coverImage: r.cover_image, coverVideo: r.cover_video,
      priceType: r.price_type, originalPrice: r.original_price,
      productType: r.product_type, virtualContent: r.virtual_content,
      salesCount: r.sales_count, isRecommended: r.is_recommended,
      sortOrder: r.sort_order, purchaseLimitConfig: safeJSON(r.purchase_limit_config),
      commissionConfig: safeJSON(r.commission_config), customFields: safeJSON(r.custom_fields),
      afterSalesConfig: safeJSON(r.after_sales_config), services: safeJSON(r.services),
      tags: safeJSON(r.tags), productParams: safeJSON(r.product_params),
      paymentMethods: safeJSON(r.payment_methods),
      currencyPrices: safeJSON(r.currency_prices),
      saleEndTime: r.sale_end_time || null,
      productSubtype: r.product_subtype || '',
      decorationId: r.decoration_id || 0, durationDays: r.duration_days || 0,
      bundleConfig: safeJSON(r.bundle_config),
      previewImages: safeJSON(r.preview_images),
      sourceFileUrl: r.source_file_url || '',
      createdBy: r.created_by || 0, createdByName: r.created_by_name || '',
      createTime: r.create_time, updateTime: r.update_time
    }
  }

  function safeJSON(v) { try { return typeof v === 'string' ? JSON.parse(v) : (v || []) } catch { return [] } }

  function getDurationLabel(cfg, days) {
    if (cfg) {
      if (cfg.decorationDurationDays > 0) return cfg.decorationDurationDays + '天'
      if ('decorationDurationDays' in cfg && cfg.decorationDurationDays === 0) return '永久'
      if (cfg.value > 0 && cfg.durationUnit === 'day') return cfg.value + '天'
      if (cfg.value === 0 && cfg.durationUnit === 'day') return '永久'
    }
    const d = days || 0
    return d > 0 ? d + '天' : ''
  }

  async function checkDecorationOwnership(userId, productId, optionId, productRow) {
    let decoId = 0
    let decoSubtype = ''

    if (productRow.product_type === 'decoration') {
      decoId = productRow.decoration_id || 0
      decoSubtype = productRow.product_subtype || ''
    } else if (productRow.product_type === 'virtual_auto' && optionId > 0) {
      const [optRow] = await query('SELECT card_config FROM mall_product_options WHERE id=?', [optionId])
      const cfg = safeJSON(optRow?.card_config)
      if (cfg?.type === 'decoration' && cfg.decorationId) {
        decoId = cfg.decorationId
        decoSubtype = cfg.decorationSubtype || ''
      }
    }

    if (!decoId) return null

    if (decoSubtype === 'avatar_frame') {
      const [row] = await query('SELECT id FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, decoId])
      if (row) return '您已永久拥有该头像框'
    } else if (decoSubtype === 'title') {
      const [row] = await query('SELECT id, expire_time FROM user_titles WHERE user_id=? AND title_id=?', [userId, decoId])
      if (row && !row.expire_time) return '您已永久拥有该称号'
    } else if (decoSubtype) {
      const [row] = await query('SELECT id, expire_time FROM user_decorations WHERE user_id=? AND decoration_id=? AND decoration_type=?', [userId, decoId, decoSubtype])
      if (row && !row.expire_time) return '您已永久拥有该装饰品'
    }

    return null
  }

  async function fetchDecorationImages(avatarFrameIds, otherDecIds, imageMap) {
    if (avatarFrameIds.length) {
      try {
        const rows = await query(`SELECT id, image_url FROM avatar_frames WHERE id IN (${avatarFrameIds.map(() => '?').join(',')})`, avatarFrameIds)
        rows.forEach(r => { imageMap[r.id] = r.image_url })
      } catch {}
    }
    if (otherDecIds.length) {
      try {
        const rows = await query(`SELECT id, image_url FROM decorations WHERE id IN (${otherDecIds.map(() => '?').join(',')})`, otherDecIds)
        rows.forEach(r => { imageMap[r.id] = r.image_url })
      } catch {}
    }
  }

  // 虚拟商品自动发货
  async function autoDeliver(item, product, user) {
    let deliveryInfo = ''
    let cardConfig = {}

    // 如果选择了规格，从规格读取卡密配置
    if (item.option_id) {
      const optRows = await query('SELECT * FROM mall_product_options WHERE id=?', [item.option_id])
      if (optRows.length && optRows[0].card_config) {
        cardConfig = safeJSON(optRows[0].card_config)
      }
    }

    // 从商品级虚拟内容读取（兼容旧数据）
    const vContent = product.virtual_content || ''
    if (!cardConfig.enabled && vContent) {
      deliveryInfo = vContent
      return deliveryInfo
    }

    // 没有卡密配置，返回空
    if (!cardConfig.enabled) {
      return ''
    }

    const cfgType = cardConfig.type || 'card_key'
    const cardType = cardConfig.cardType || 'membership'
    const targetId = cardConfig.targetId || 0
    const value = cardConfig.value || 0
    const durationUnit = cardConfig.durationUnit || 'day'
    const extraPoints = cardConfig.extraPoints || 0
    const extraBalance = cardConfig.extraBalance || 0
    const extraExperience = cardConfig.extraExperience || 0

    if (cfgType === 'auto_recharge') {
      // 自动充值：直接给账户加积分/余额/经验/开通会员，不生成卡密
      if (cardType === 'points') {
        await addPoints(user.id, user.username || '', value, '商城购买赠送', `购买《${product.name || ''}》赠送${value}积分`)
        deliveryInfo = `赠送 ${value} 积分`
      } else if (cardType === 'balance') {
        await addBalance(user.id, user.username || '', value, '商城购买赠送', `购买《${product.name || ''}》赠送¥${value}`)
        deliveryInfo = `赠送 ¥${value} 余额`
      } else if (cardType === 'experience') {
        await addExperience(user.id, user.username || '', value, '商城购买赠送', `购买《${product.name || ''}》赠送${value}经验`)
        deliveryInfo = `赠送 ${value} 经验`
      } else {
        // membership or free - 直接开通会员
        const lv = await query('SELECT id, name FROM membership_levels WHERE id=?', [targetId])
        if (lv && lv.length > 0) {
          const expDate = new Date(Date.now() + value * 24 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)
          await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
            [targetId, lv[0].name, expDate, user.id])
          await query(
            `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
             VALUES (?, ?, ?, ?, 'balance', 'mall', ?, ?)`,
            [user.id, targetId, lv[0].name, 0, value, expDate]
          )
          deliveryInfo = `开通会员：${lv[0].name}，有效期 ${value} 天`
        } else {
          deliveryInfo = '开通会员失败：会员等级不存在'
        }
      }
    } else if (cfgType === 'card_key') {
      // 卡密：全部 cardType 都生成卡密返回给用户
      const qty = item.quantity || 1
      const cards = []
      for (let i = 0; i < qty; i++) {
        const cardNo = 'MC' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
        const cardPwd = Math.random().toString(36).slice(2, 10).toUpperCase()
        const targetName = cardConfig.targetName || ''
        await query(
          `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, extra_points, extra_experience, extra_balance, duration, duration_unit, status, create_by, create_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,'0',?,${nowExpr})`,
          [cardNo, cardPwd, cardType, targetId, targetName, value, extraPoints, extraExperience, extraBalance, value, durationUnit, '系统自动发货']
        )
        cards.push(`卡密：${cardNo}，密码：${cardPwd}` + (targetName ? `，类型：${targetName}` : ''))
      }
      deliveryInfo = cards.join('\n')
    } else if (cfgType === 'invite_code') {
      const count = cardConfig.inviteCodeCount || 1
      const maxUses = cardConfig.maxUses || 1
      const rewardType = cardConfig.rewardType || 'membership'
      const rewardValue = cardConfig.rewardValue || 0
      const rewardDurationUnit = cardConfig.rewardDurationUnit || 'day'
      const rewardTargetId = cardConfig.targetId || 0
      const codes = []
      for (let i = 0; i < count; i++) {
        const code = 'INV' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 4).toUpperCase() + String(i)
        await query(
          `INSERT INTO invite_codes (code, created_by, created_by_name, max_uses, use_count, reward_type, reward_value, reward_duration_unit, reward_target_id, status, create_time) VALUES (?,?,?,?,0,?,?,?,?,'1',${nowExpr})`,
          [code, user.id, user.username || '', maxUses, rewardType, rewardValue, rewardDurationUnit, rewardTargetId]
        )
        codes.push(code)
        // tiny delay to avoid same timestamp
        await new Promise(r => setTimeout(r, 1))
      }
      deliveryInfo = `邀请码：${codes.join(', ')}`
    } else if (cfgType === 'custom') {
      const customCards = cardConfig.customCards || []
      if (customCards.length === 0) {
        deliveryInfo = '卡池已空，请联系客服'
      } else {
        // 随机抽取一张
        const idx = Math.floor(Math.random() * customCards.length)
        const card = customCards[idx]
        customCards.splice(idx, 1)
        // 更新规格的卡池和库存
        if (item.option_id) {
          cardConfig.customCards = customCards
          await query(
            `UPDATE mall_product_options SET card_config=?, stock=? WHERE id=?`,
            [JSON.stringify(cardConfig), customCards.length, item.option_id]
          )
          // 同步减商品主库存
          await query('UPDATE mall_products SET stock = stock - 1 WHERE id=? AND stock > 0', [product.id])
        }
        const parts = card.split(':')
        const cardNo = parts[0] || ''
        const cardPwd = parts.slice(1).join(':') || ''
        deliveryInfo = `卡密：${cardNo}，密码：${cardPwd}`
      }
    } else if (cfgType === 'card_pool') {
      // 支持多卡池：poolIds 数组 + poolMode (sequential/random)
      const poolIds = cardConfig.poolIds && cardConfig.poolIds.length
        ? cardConfig.poolIds
        : (cardConfig.poolId ? [cardConfig.poolId] : [])
      const poolMode = cardConfig.poolMode || 'random'

      if (!poolIds.length) {
        deliveryInfo = '卡池配置错误，请联系客服'
      } else {
        let poolId
        if (poolMode === 'sequential') {
          const idx = (cardConfig._seqIndex || 0) % poolIds.length
          poolId = poolIds[idx]
          cardConfig._seqIndex = (idx + 1) % poolIds.length
          // 持久化序列索引
          if (item.option_id) {
            await query('UPDATE mall_product_options SET card_config=? WHERE id=?',
              [JSON.stringify(cardConfig), item.option_id])
          }
        } else {
          poolId = poolIds[Math.floor(Math.random() * poolIds.length)]
        }

        const card = await cardPoolRoutes.drawFromPool(poolId)
        if (!card) {
          deliveryInfo = '卡池已空，请联系客服'
        } else {
          if (item.option_id) {
            await query('UPDATE mall_product_options SET stock = stock - 1 WHERE id=? AND stock > 0', [item.option_id])
            await query('UPDATE mall_products SET stock = stock - 1 WHERE id=? AND stock > 0', [product.id])
          }
          deliveryInfo = `卡密：${card.number}，密码：${card.password}`
        }
      }
    } else if (cfgType === 'text') {
      deliveryInfo = cardConfig.textContent || '请联系客服获取内容'
    } else if (cfgType === 'decoration') {
      const decoSubtype = cardConfig.decorationSubtype || ''
      const decoId = cardConfig.decorationId || 0
      const decoDuration = cardConfig.decorationDurationDays || 0

      if (!decoId || !decoSubtype) {
        deliveryInfo = '装饰品配置不完整，请联系客服'
      } else {
        const expireTime = decoDuration > 0
          ? new Date(Date.now() + decoDuration * 86400000).toISOString().replace('T', ' ').slice(0, 19)
          : null

        if (decoSubtype === 'avatar_frame') {
          await query(
            'INSERT IGNORE INTO user_avatar_frames (user_id, frame_id, is_active, obtain_type) VALUES (?,?,0,?)',
            [user.id, decoId, 'mall']
          )
          deliveryInfo = `头像框：${product.name || ''}`
        } else if (decoSubtype === 'title') {
          const [existingTitle] = await query('SELECT id, expire_time FROM user_titles WHERE user_id=? AND title_id=?', [user.id, decoId])
          if (existingTitle) {
            if (existingTitle.expire_time && decoDuration > 0) {
              await query('UPDATE user_titles SET expire_time=DATE_ADD(expire_time, INTERVAL ? DAY), grant_by=? WHERE id=?', [decoDuration, 'mall', existingTitle.id])
            }
          } else {
            await query('INSERT INTO user_titles (user_id, title_id, is_active, grant_by, expire_time) VALUES (?,?,1,?,?)', [user.id, decoId, 'mall', expireTime])
          }
          deliveryInfo = `称号：${product.name || ''}` + (expireTime ? ` (有效期至 ${expireTime.slice(0, 10)})` : '')
        } else if (['avatar_effect', 'comment_background', 'nickname_effect', 'home_bg'].includes(decoSubtype)) {
          const [existingDec] = await query('SELECT id, expire_time FROM user_decorations WHERE user_id=? AND decoration_id=?', [user.id, decoId])
          if (existingDec) {
            if (existingDec.expire_time && decoDuration > 0) {
              await query('UPDATE user_decorations SET expire_time=DATE_ADD(expire_time, INTERVAL ? DAY), obtain_type=? WHERE id=?', [decoDuration, 'mall', existingDec.id])
            }
          } else {
            await query('INSERT INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type, expire_time) VALUES (?,?,?,1,?,?)', [user.id, decoId, decoSubtype, 'mall', expireTime])
          }
          const typeNames = { avatar_effect: '头像特效', comment_background: '评论背景', nickname_effect: '昵称特效', home_bg: '主页背景' }
          deliveryInfo = `${typeNames[decoSubtype] || '装饰品'}：${product.name || ''}` + (expireTime ? ` (有效期至 ${expireTime.slice(0, 10)})` : '')
        } else {
          deliveryInfo = '未知装饰品类型，请联系客服'
        }
      }
    }

    // 记录发货日志
    if (deliveryInfo && item.id) {
      const cardNoMatch = deliveryInfo.match(/卡密：(.+?)[，,\s]/)
      const cardNo = cardNoMatch ? cardNoMatch[1] : ''
      try {
        await query(
          `INSERT INTO delivery_logs (order_id, user_id, product_id, product_name, option_id, card_type, delivery_info, card_number) VALUES (?,?,?,?,?,?,?,?)`,
          [item.id, user.id, product.id, product.name, item.option_id || 0, cfgType, deliveryInfo, cardNo]
        )
      } catch (e) { /* 日志插入失败不影响主流程 */ }
    }

    return deliveryInfo
  }

  // ==================== 订单 ====================
  function genOrderNo() {
    const now = new Date()
    const d = now.toISOString().slice(2,10).replace(/-/g,'')
    const t = String(now.getHours()).padStart(2,'0') + String(now.getMinutes()).padStart(2,'0') + String(now.getSeconds()).padStart(2,'0')
    const r = Math.random().toString(36).slice(2,8).toUpperCase()
    return d + t + r
  }

  router.get('/api/mall/orders', authRequired, requirePermission('view'), async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1
      const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100)
      const offset = (page - 1) * pageSize
      const { keyword, status } = req.query

      let where = 'WHERE 1=1'
      const params = []
      if (status) { where += ' AND o.status = ?'; params.push(status) }
      if (keyword) {
        where += ' AND (o.order_no LIKE ? OR o.receiver_name LIKE ?)'
        params.push(`%${keyword}%`, `%${keyword}%`)
      }

      const [orders] = await Promise.all([
        query(
          `SELECT o.* FROM mall_orders o ${where} ORDER BY o.create_time DESC LIMIT ? OFFSET ?`,
          [...params, pageSize, offset]
        )
      ])

      const [totalRow] = await query(
        `SELECT COUNT(*) AS total FROM mall_orders o ${where}`,
        params
      )
      const total = totalRow ? totalRow.total : 0

      // 获取所有订单的商品明细
      const orderIds = orders.map(o => o.id)
      let itemsMap = {}
      if (orderIds.length > 0) {
        const items = await query(
          `SELECT oi.* FROM mall_order_items oi WHERE oi.order_id IN (${orderIds.map(() => '?').join(',')})`,
          orderIds
        )
        for (const it of items) {
          if (!itemsMap[it.order_id]) itemsMap[it.order_id] = []
          itemsMap[it.order_id].push({
            id: it.id, productName: it.product_name, optionName: it.option_name,
            image: it.image, price: it.price, quantity: it.quantity
          })
        }
      }

      const list = orders.map(o => ({
        id: o.id, orderNo: o.order_no, status: o.status,
        totalAmount: o.total_amount, freight: o.freight,
        discountAmount: o.discount_amount, paymentMethod: o.payment_method,
        paymentTime: o.payment_time, createTime: o.create_time,
        receiverName: o.receiver_name, receiverPhone: o.receiver_phone,
        receiverAddress: o.receiver_address,
        remark: o.remark, items: itemsMap[o.id] || []
      }))

      res.json({ code: 200, data: { list, total, page, pageSize } })
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/orders/check-purchased', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const productId = parseInt(req.query.productId) || 0
      if (!productId) return res.json({ code: 400, msg: '缺少 productId' })

      const [rows] = await query(
        `SELECT COUNT(*) as cnt FROM mall_orders WHERE user_id = ? AND product_id = ? AND status IN ('paid','completed')`,
        [userId, productId]
      )
      const purchased = rows && rows[0].cnt > 0
      res.json({ code: 200, data: { purchased, count: rows ? rows[0].cnt : 0 } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/mall/orders/my', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const page = parseInt(req.query.page) || 1
      const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100)
      const offset = (page - 1) * pageSize

      const [orders] = await Promise.all([
        query(
          `SELECT o.*, 
            GROUP_CONCAT(DISTINCT CONCAT(oi.product_name,' x',oi.quantity) SEPARATOR '；') AS items_summary,
            COUNT(DISTINCT oi.id) AS item_count
           FROM mall_orders o
           LEFT JOIN mall_order_items oi ON oi.order_id = o.id
           WHERE o.user_id = ?
           GROUP BY o.id
           ORDER BY o.create_time DESC
           LIMIT ? OFFSET ?`,
          [userId, pageSize, offset]
        )
      ])

      const list = (orders || []).map(o => ({
        id: o.id,
        orderNo: o.order_no,
        status: o.status,
        totalAmount: o.total_amount,
        freight: o.freight,
        paymentMethod: o.payment_method,
        discountAmount: o.discount_amount,
        remark: o.remark,
        itemsSummary: o.items_summary || '',
        itemCount: o.item_count || 0,
        createTime: o.create_time,
        updateTime: o.update_time,
        paymentTime: o.payment_time,
      }))

      res.json({ code: 200, msg: 'success', data: { list, page, pageSize } })
    } catch (err) {
      console.error('Get mall orders error:', err)
      res.status(500).json({ error: '获取订单列表失败' })
    }
  })

  router.post('/api/mall/orders', authRequired, async (req, res) => {
    try {
      const { productId, optionId, quantity = 1, paymentMethod = 'balance', remark = '', userCustomFields = null, userCouponId, addressId, agreedPolicyId } = req.body
      const userId = req.user?.userId

      const [productRows] = await Promise.all([
        query('SELECT * FROM mall_products WHERE id=?', [productId])
      ])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      if (product.status !== 'published') return res.json({ code: 400, msg: '商品已下架' })
      if (product.sale_end_time) {
        await checkProductSaleEnd(productId)
        const [updated] = await query('SELECT status FROM mall_products WHERE id=?', [productId])
        if (updated && updated.status !== 'published') return res.json({ code: 400, msg: '商品销售已截止' })
      }

      let price = product.price
      let optionName = ''
      let optionIdVal = optionId || 0
      let optRows = null
      if (optionIdVal) {
        optRows = await query('SELECT * FROM mall_product_options WHERE id=? AND product_id=?', [optionIdVal, productId])
        if (optRows.length) { price = optRows[0].price; optionName = optRows[0].name }
      }

      let totalAmount = price * quantity
      const cp = (optRows && optRows[0] && optRows[0].currency_prices)
        ? safeJSON(optRows[0].currency_prices)
        : safeJSON(product.currency_prices)
      if (cp && cp[paymentMethod] != null && cp[paymentMethod] > 0) {
        totalAmount = cp[paymentMethod] * quantity
      } else if (paymentMethod === 'points' && !(cp && cp.points != null)) {
        if (optionIdVal && optRows && optRows[0] && optRows[0].points_price) {
          totalAmount = optRows[0].points_price * quantity
        } else if (product.points_price) {
          totalAmount = product.points_price * quantity
        }
      }
      // ===== 限购 + 装饰品去重检查 =====
      const purchaseLimitConfig = safeJSON(product.purchase_limit_config)

      // 方案B: 全局（商品级）限购
      const globalLimit = (purchaseLimitConfig || []).find(l => l.type === 'global')
      if (globalLimit && globalLimit.limit > 0) {
        const [boughtRow] = await query(
          'SELECT COUNT(*) AS cnt FROM mall_orders o INNER JOIN mall_order_items oi ON o.id=oi.order_id WHERE o.user_id=? AND o.status IN ("paid","completed") AND oi.product_id=?',
          [userId, productId]
        )
        if (Number(boughtRow.cnt) >= globalLimit.limit) {
          return res.json({ code: 400, msg: `该商品每用户限购${globalLimit.limit}件，您已达到上限` })
        }
      }

      // 规格级限购
      if (optionIdVal) {
        const [optRow] = await query('SELECT purchase_limit FROM mall_product_options WHERE id=?', [optionIdVal])
        if (optRow && Number(optRow.purchase_limit) > 0) {
          const [boughtOptRow] = await query(
            'SELECT COUNT(*) AS cnt FROM mall_orders o INNER JOIN mall_order_items oi ON o.id=oi.order_id WHERE o.user_id=? AND o.status IN ("paid","completed") AND oi.product_id=? AND oi.option_id=?',
            [userId, productId, optionIdVal]
          )
          if (Number(boughtOptRow.cnt) >= Number(optRow.purchase_limit)) {
            return res.json({ code: 400, msg: `该套餐每用户限购${optRow.purchase_limit}次，您已达到上限` })
          }
        }
      }

      // 方案A: 装饰品去重（永久拥有拒绝）
      if (product.product_type === 'decoration' || product.product_type === 'virtual_auto') {
        const ownershipErr = await checkDecorationOwnership(userId, productId, optionIdVal || 0, product)
        if (ownershipErr) return res.json({ code: 400, msg: ownershipErr })
      }
      // ===== 限购检查结束 =====

      // ===== 促销活动折扣 =====
      let promotionDiscount = 0
      let promotionName = ''
      const nowStr = new Date().toISOString().slice(0, 19).replace('T', ' ')
      const promos = await query(
        `SELECT DISTINCT pr.* FROM mall_promotions pr
         LEFT JOIN mall_promotion_products pp ON pr.id = pp.promotion_id
         WHERE pr.status='1' AND pr.start_time <= ? AND pr.end_time >= ?
         AND (pp.product_id = ? OR pp.product_id IS NULL OR NOT EXISTS (SELECT 1 FROM mall_promotion_products WHERE promotion_id=pr.id))`,
        [nowStr, nowStr, productId]
      )
      if (promos.length) {
        const promo = promos[0]
        if (promo.type === 'discount') {
          if (!promo.min_amount || totalAmount >= promo.min_amount) {
            promotionDiscount = Math.min(totalAmount * promo.discount_value / 100, promo.max_discount || totalAmount)
            promotionName = promo.name
          }
        } else if (promo.type === 'fixed') {
          if (!promo.min_amount || totalAmount >= promo.min_amount) {
            promotionDiscount = Math.min(promo.discount_value, totalAmount)
            promotionName = promo.name
          }
        }
        totalAmount = Math.round((totalAmount - promotionDiscount) * 100) / 100
        if (totalAmount < 0) totalAmount = 0
      }
      const freight = product.freight || 0
      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // ===== 优惠券处理 =====
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const result = await applyCoupon(userCouponId, userId, totalAmount, paymentMethod, 0)
        if (result.error) return res.json({ code: 400, msg: result.error })
        couponDiscount = result.couponDiscount
        couponUsedId = result.couponUsedId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      // ===== 扣款 =====
      try {
        await spendCurrency(userId, user.username || '', paymentMethod, finalAmount, '商城购物', '', `购买商品《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣)' : ''}`)
      } catch (e) {
        if (couponUsedId) {
          await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
        }
        return res.json({ code: 400, msg: `支付失败: ${e.message}` })
      }

      // ===== 获取收货地址 =====
      let receiverName = '', receiverPhone = '', receiverAddress = ''
      if (addressId) {
        const addrRows = await query('SELECT * FROM user_addresses WHERE id=? AND user_id=?', [addressId, userId])
        if (addrRows.length) {
          const a = addrRows[0]
          receiverName = a.name || ''
          receiverPhone = a.phone || ''
          receiverAddress = `${a.province}${a.city}${a.district}${a.detail}`
        }
      }

      // ===== 协议确认 =====
      if (agreedPolicyId) {
        const agreeRows = await query("SELECT id FROM policy_versions WHERE id=? AND type='agreement' AND status='published'", [agreedPolicyId])
        if (!agreeRows || !agreeRows.length) return res.json({ code: 400, msg: '协议版本无效或未发布' })
      }

      // ===== 创建订单（已支付） =====
      const orderNo = genOrderNo()
      const orderResult = await query(
        `INSERT INTO mall_orders (order_no, user_id, status, total_amount, freight, payment_method, discount_amount, remark, receiver_name, receiver_phone, receiver_address, user_custom_fields, agreed_policy_id, agreed_at, payment_time, create_time, update_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),${nowExpr},${nowExpr},${nowExpr})`,
        [orderNo, userId, 'paid', totalAmount, freight, paymentMethod, couponDiscount, remark, receiverName, receiverPhone, receiverAddress, JSON.stringify(userCustomFields || {}), agreedPolicyId || 0]
      )
      const orderId = orderResult.insertId

      await query(
        `INSERT INTO mall_order_items (order_id, product_id, option_id, product_name, option_name, price, quantity, image, virtual_content)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [orderId, productId, optionIdVal, product.name, optionName, price, quantity, product.cover_image || '', product.virtual_content || '']
      )

      // ===== 销量 + 库存 =====
      await query('UPDATE mall_products SET sales_count = sales_count + ? WHERE id=?', [quantity, productId])
      if (optionIdVal) {
        await query('UPDATE mall_product_options SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, optionIdVal, quantity])
      } else {
        await query('UPDATE mall_products SET stock = stock - ? WHERE id=? AND stock >= ?', [quantity, productId, quantity])
      }

      // ===== 虚拟商品自动发货 =====
      let deliveryInfo = ''
      if (product.product_type && product.product_type.startsWith('virtual')) {
        const item = { id: orderId, product_id: productId, option_id: optionIdVal, quantity }
        deliveryInfo = await autoDeliver(item, product, user)
        if (deliveryInfo) {
          await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
          try {
            await query(
              `INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
              ['购买成功', `您购买的商品「${product.name}」已发货：${deliveryInfo}`, 'mall', userId]
            )
          } catch {}
        }
      }

      // ===== 套装批量发货 =====
      let bundleConfig = []
      try { bundleConfig = typeof product.bundle_config === 'string' ? JSON.parse(product.bundle_config) : (product.bundle_config || []) } catch { bundleConfig = [] }
      for (const bItem of bundleConfig) {
        if (bItem.type === 'decoration' && bItem.decorationId) {
          const [bDecRows] = await query('SELECT * FROM decorations WHERE id = ?', [bItem.decorationId])
          if (bDecRows && (bDecRows).length) {
            const bDec = bDecRows[0]
            const bDuration = bItem.durationDays || bDec.duration_days || 0
            const expireTime = bDuration > 0 ? new Date(Date.now() + bDuration * 86400000).toISOString().slice(0, 19).replace('T', ' ') : null
            if (expireTime) {
              await query('INSERT INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type, expire_time) VALUES (?,?,?,0,"mall",?)',
                [userId, bItem.decorationId, bDec.type, expireTime])
            } else {
              await query('INSERT INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type) VALUES (?,?,?,0,"mall")',
                [userId, bItem.decorationId, bDec.type])
            }
            const bInfo = `套装赠品：${bDec.name}`
            deliveryInfo = deliveryInfo ? deliveryInfo + '\n' + bInfo : bInfo
          }
        }
        if (bItem.type === 'card_pool' && bItem.poolId) {
          try {
            const cardPoolRoutes = require('./card-pool.cjs')
            const bCard = await cardPoolRoutes.drawFromPool(bItem.poolId)
            if (bCard) {
              const bCardInfo = `套装卡密：${bCard.number}，密码：${bCard.password}`
              deliveryInfo = deliveryInfo ? deliveryInfo + '\n' + bCardInfo : bCardInfo
            }
          } catch {}
        }
      }
      if (deliveryInfo) {
        await query('UPDATE mall_order_items SET virtual_content=? WHERE order_id=?', [deliveryInfo, orderId])
      }

      // ===== 系统通知 =====
      const sysOp = await getSystemOperator()
      const sysOpName = (sysOp && sysOp.username) ? sysOp.username : '管理员'
      const unit = await getCurrencyUnit(paymentMethod)
      let notifyContent = `您已成功购买《${product.name || ''}》，支付 ${finalAmount} ${unit}`
      if (couponDiscount > 0) {
        notifyContent += `（优惠券抵扣 ${couponDiscount}${unit}）`
      }
      if (deliveryInfo) {
        notifyContent += `\n发货内容：${deliveryInfo}`
      }
      try {
        await query(
          `INSERT INTO sys_notifications (from_user_id, from_user_name, target_user_id, title, content, type, create_time)
           VALUES (?,?,?,?,?,'system',${nowExpr})`,
          [sysOp && sysOp.id ? sysOp.id : 1, sysOpName, userId, `购买商品《${product.name || ''}》`, notifyContent]
        )
      } catch (e) { console.error('[mall] purchase notification failed:', orderId, e.message) }

      // 返佣计算
      try { calcCommission(orderId, 'mall', totalAmount, userId, paymentMethod) } catch (e) { console.error('[mall] commission calc failed:', orderId, e.message) }

      res.json({ code: 200, msg: '支付成功', data: {
        id: orderId, orderNo,
        productType: product.product_type || '',
        deliveryInfo
      }})
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/orders/:id/status', authRequired, requirePermission('handle'), async (req, res) => {
    try {
      const { status, logisticsCompany, logisticsNo } = req.body
      const orderRows = await query('SELECT * FROM mall_orders WHERE id=?', [req.params.id])
      if (!orderRows.length) return res.json({ code: 404, msg: '订单不存在' })

      const fields = ['status = ?', 'update_time = NOW()']
      const values = [status]
      if (logisticsCompany) { fields.push('logistics_company = ?'); values.push(logisticsCompany) }
      if (logisticsNo) { fields.push('logistics_no = ?'); values.push(logisticsNo) }
      if (status === 'paid' || status === 'completed') { fields.push('payment_time = NOW()') }
      values.push(req.params.id)

      await query(`UPDATE mall_orders SET ${fields.join(', ')} WHERE id=?`, values)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/mall/orders/:id/pay', authRequired, async (req, res) => {
    try {
      const { paymentMethod = 'balance', userCouponId } = req.body
      const userId = req.user?.userId

      const orderRows = await query('SELECT * FROM mall_orders WHERE id=? AND user_id=?', [req.params.id, userId])
      if (!orderRows.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orderRows[0]
      if (order.status !== 'pending') return res.json({ code: 400, msg: '订单状态不允许支付' })

      const items = await query('SELECT * FROM mall_order_items WHERE order_id=?', [req.params.id])
      if (!items.length) return res.json({ code: 400, msg: '订单无商品' })
      const item = items[0]

      const productRows = await query('SELECT * FROM mall_products WHERE id=?', [item.product_id])
      if (!productRows.length) return res.json({ code: 404, msg: '商品不存在' })
      const product = productRows[0]
      const priceType = product.price_type || 'balance'
      let totalAmount = Number(order.total_amount)

      const userRows = await query('SELECT * FROM users WHERE id=?', [userId])
      if (!userRows.length) return res.json({ code: 404, msg: '用户不存在' })
      const user = userRows[0]

      // 优惠券验证与使用
      let couponDiscount = 0
      let couponUsedId = null
      if (userCouponId) {
        const result = await applyCoupon(userCouponId, userId, totalAmount, paymentMethod || 'balance', req.params.id)
        if (result.error) return res.json({ code: 400, msg: result.error })
        couponDiscount = result.couponDiscount
        couponUsedId = result.couponUsedId
      }

      const finalAmount = Math.max(0, totalAmount - couponDiscount)

      try {
        await spendCurrency(userId, user.username || '', paymentMethod, finalAmount, '商城购物', '', `支付订单#${req.params.id} - 《${product.name || ''}》${couponDiscount > 0 ? ' (优惠券抵扣)' : ''}`)
      } catch (e) {
        if (couponUsedId) {
          await query("UPDATE user_coupons SET status='unused', use_time=NULL, use_scene=NULL, use_order_id=NULL, use_amount=0 WHERE id=?", [couponUsedId])
        }
        return res.json({ code: 400, msg: `支付失败: ${e.message}` })
      }

      // ===== 支付成功，更新订单状态 =====

      // 创建订单
      const result = await query(
        `INSERT INTO mall_reviews (product_id, user_id, order_id, rating, content, images, dim_product_rating, dim_service_rating, dim_logistics_rating) VALUES (?,?,?,?,?,?,?,?,?)`,
        [productId, userId, orderId || 0, rating, content || '', JSON.stringify(imgs), dp, ds, dl]
      )
      await query('UPDATE mall_products SET avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM mall_reviews WHERE product_id=?) WHERE id=?', [productId, productId])
      res.json({ code: 200, msg: '评价成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/mall/reviews/:id/reply', async (req, res) => {
    try {
      const { reply } = req.body
      await query(`UPDATE mall_reviews SET reply=?, reply_time=${nowExpr} WHERE id=?`, [reply, req.params.id])
      res.json({ code: 200, msg: '回复成功' })
    } catch (e) { res.serverError(e) }
  })

  // DELETE /api/mall/reviews/:id — 管理员删除商城评价
  router.delete('/api/mall/reviews/:id', async (req, res) => {
    try {
      const rows = await query('SELECT id, user_id, product_id FROM mall_reviews WHERE id=?', [Number(req.params.id)])
      if (!rows || !rows.length) return res.json({ code: 404, msg: '评价不存在' })
      const review = rows[0]
      await query('DELETE FROM mall_reviews WHERE id=?', [Number(req.params.id)])
      await query('UPDATE mall_products SET avg_rating = (SELECT COALESCE(AVG(rating), 0) FROM mall_reviews WHERE product_id=?) WHERE id=?', [review.product_id, review.product_id])
      if (review.user_id) {
        executePenalty(review.user_id, '', 'review_malicious', { reason: '商城评价因违规被管理员删除' })
      }
      logFromReq(req, 'delete', 'mall_review', req.params.id, `管理员删除商城评价ID:${req.params.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 12. 创建售后 ==========
  router.post('/api/mall/after-sales', authRequired, async (req, res) => {
    try {
      const userId = req.user?.userId || req.body.userId || 0
      const orderId = req.body.orderId || req.body.order_id
      const { type, reason, images, description } = req.body
      if (!orderId || !type) return res.json({ code: 400, msg: '缺少必要参数' })
      const order = await query('SELECT id, user_id FROM mall_orders WHERE id=?', [Number(orderId)])
      if (!order.length) return res.json({ code: 404, msg: '订单不存在' })
      const result = await query(
        `INSERT INTO mall_after_sales (order_id, user_id, type, reason, description, images) VALUES (?,?,?,?,?,?)`,
        [Number(orderId), Number(userId), type, reason || '', description || '', JSON.stringify(images || [])]
      )
      res.json({ code: 200, msg: '售后申请已提交', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  // ========== 9. 用户地址管理 ==========
  router.get('/api/user/addresses', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const list = await query(
        'SELECT id, user_id as userId, name, phone, province, city, district, detail, is_default as isDefault, create_time as createTime FROM user_addresses WHERE user_id=? ORDER BY is_default DESC, id DESC',
        [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) { res.serverError(e) }
  })

  router.post('/api/user/addresses', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { name, phone, province, city, district, detail, isDefault } = req.body
      if (isDefault) await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      const result = await query(
        'INSERT INTO user_addresses (user_id, name, phone, province, city, district, detail, is_default) VALUES (?,?,?,?,?,?,?,?)',
        [userId, name || '', phone || '', province || '', city || '', district || '', detail || '', isDefault ? 1 : 0]
      )
      res.json({ code: 200, msg: '添加成功', data: { id: result.insertId } })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/user/addresses/:id', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { name, phone, province, city, district, detail, isDefault } = req.body
      if (isDefault) await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      await query(
        'UPDATE user_addresses SET name=?, phone=?, province=?, city=?, district=?, detail=?, is_default=? WHERE id=? AND user_id=?',
        [name || '', phone || '', province || '', city || '', district || '', detail || '', isDefault ? 1 : 0, Number(req.params.id), userId]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) { res.serverError(e) }
  })

  router.delete('/api/user/addresses/:id', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      await query('DELETE FROM user_addresses WHERE id=? AND user_id=?', [Number(req.params.id), userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  router.put('/api/user/addresses/:id/default', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      await query('UPDATE user_addresses SET is_default=0 WHERE user_id=?', [userId])
      await query('UPDATE user_addresses SET is_default=1 WHERE id=? AND user_id=?', [Number(req.params.id), userId])
      res.json({ code: 200, msg: '已设为默认地址' })
    } catch (e) { res.serverError(e) }
  })

  // ========== 10. 商城收藏 ==========
  router.post('/api/mall/favorites/:productId', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const productId = Number(req.params.productId)
      const existing = await query('SELECT id FROM mall_favorites WHERE user_id=? AND product_id=?', [userId, productId])
      if (existing.length > 0) {
        await query('DELETE FROM mall_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query('INSERT INTO mall_favorites (user_id, product_id) VALUES (?,?)', [userId, productId])
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) { res.serverError(e) }
  })

  router.get('/api/mall/favorites', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const list = await query(
        `SELECT f.id, f.product_id as productId, f.create_time as createTime,
                p.name, p.cover_image as coverImage, p.price, p.price_type as priceType,
                p.sales_count as salesCount, p.status
         FROM mall_favorites f
         JOIN mall_products p ON f.product_id=p.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`, [userId]
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) { res.serverError(e) }
  })

}

module.exports = mallRoutes
