const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('../routes/system.cjs')
const { getThresholds, clearThresholdCache } = require('../middleware/abuse-detection.cjs')
const { executePenalty } = require('./custom-task.cjs')

function abuseAdminRoutes(app) {
  app.get('/api/admin/abuse/risks', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const { page = 1, pageSize = 20, riskType, status, riskLevel } = req.query
      let where = 'WHERE 1=1'
      const params = []
      if (riskType) { where += ' AND r.risk_type=?'; params.push(riskType) }
      if (status) { where += ' AND r.status=?'; params.push(status) }
      if (riskLevel) { where += ' AND r.risk_level=?'; params.push(Number(riskLevel)) }
      const offset = (Number(page) - 1) * Number(pageSize)
      const [countRows, list] = await Promise.all([
        query(`SELECT COUNT(*) as total FROM user_risks r ${where}`, params),
        query(
          `SELECT r.*, u.username, u.nickname, u.avatar
           FROM user_risks r LEFT JOIN users u ON r.user_id = u.id
           ${where} ORDER BY r.detected_at DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), offset]
        )
      ])
      res.json({ code: 200, data: { list, total: countRows[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/admin/abuse/risks/:id/resolve', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const { note } = req.body || {}
      const adminId = req.user?.userId || 0
      const [risk] = await query('SELECT user_id FROM user_risks WHERE id=?', [req.params.id])
      await query(
        "UPDATE user_risks SET status='resolved', resolved_at=NOW(), resolved_by=?, resolve_note=? WHERE id=?",
        [adminId, note || '', req.params.id]
      )
      if (risk && risk.user_id) executePenalty(risk.user_id, '', 'report_verified', { reason: note || '举报经核实违规' })
      res.json({ code: 200, msg: '已标记为已处理' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/admin/abuse/risks/:id/ignore', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const adminId = req.user?.userId || 0
      await query(
        "UPDATE user_risks SET status='ignored', resolved_at=NOW(), resolved_by=?, resolve_note='管理员忽略' WHERE id=?",
        [adminId, req.params.id]
      )
      res.json({ code: 200, msg: '已忽略' })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/admin/abuse/thresholds', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const thresholds = await getThresholds()
      res.json({ code: 200, data: thresholds })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/admin/abuse/thresholds', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const body = req.body || {}
      const promises = []
      for (const [key, val] of Object.entries(body)) {
        if (key.startsWith('spam_') || key.startsWith('batch_') || key.startsWith('follow_')) {
          promises.push(
            query(
              "INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?) ON DUPLICATE KEY UPDATE config_value=?",
              ['abuse_' + key, String(val), '异常检测阈值:' + key, String(val)]
            )
          )
        }
      }
      await Promise.all(promises)
      clearThresholdCache()
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  app.get('/api/admin/abuse/stats', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const [byType, byLevel] = await Promise.all([
        query("SELECT risk_type, COUNT(*) as cnt FROM user_risks WHERE status='active' GROUP BY risk_type"),
        query("SELECT risk_level, COUNT(*) as cnt FROM user_risks WHERE status='active' GROUP BY risk_level")
      ])
      res.json({ code: 200, data: { byType, byLevel } })
    } catch (e) { res.serverError(e) }
  })
}

module.exports = abuseAdminRoutes
