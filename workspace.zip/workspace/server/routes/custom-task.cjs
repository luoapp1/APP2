const { query, getSystemOperator } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { emitSafe, TASK_EVENTS } = require('../plugins/events.cjs')

function formatDateTime(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    const pad = (n) => String(n).padStart(2, '0')
    return `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`
  } catch { return '' }
}

async function sendNotification(userId, title, content) {
  try {
    const sysOpName = (await getSystemOperator())?.username || '管理员'
    await query(
      `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?, ?, 'system', ?, 0, ?, '')`,
      [title, content, userId, sysOpName]
    )
  } catch {}
}

function getPeriodKey(taskType) {
  const now = new Date()
  if (taskType === 'daily') return formatDateTime(now).slice(0, 10)
  if (taskType === 'weekly') return getWeekKey(now)
  if (taskType === 'monthly') return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
  if (taskType === 'yearly') return `${now.getFullYear()}`
  return ''
}

function getWeekKey(date) {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  const monday = new Date(d.setDate(diff))
  return monday.toISOString().slice(0, 10)
}

async function grantTaskReward(task, userId, userName) {
  const rewards = []
  if (task.points_reward > 0) {
    await query('UPDATE users SET points = points + ? WHERE id = ?', [task.points_reward, Number(userId)])
    const bal = await query('SELECT points FROM users WHERE id = ?', [Number(userId)])
    await query(
       `INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
        VALUES (?, ?, 'earn', ?, ?, ?, ?)`,
      [Number(userId), userName || '', task.points_reward, bal[0]?.points || 0, task.name, `完成任务: ${task.name}`]
    )
    rewards.push(`${task.points_reward}积分`)
  }
  if (task.exp_reward > 0) {
    await query('UPDATE users SET experience = experience + ? WHERE id = ?', [task.exp_reward, Number(userId)])
    rewards.push(`${task.exp_reward}经验`)
  }
  if (task.balance_reward > 0) {
    await query('UPDATE users SET balance = balance + ? WHERE id = ?', [task.balance_reward, Number(userId)])
    const bal = await query('SELECT balance FROM users WHERE id = ?', [Number(userId)])
    await query(
       `INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description)
        VALUES (?, ?, 'earn', ?, ?, ?, ?)`,
      [Number(userId), userName || '', task.balance_reward, bal[0]?.balance || 0, task.name, `完成任务: ${task.name}`]
    )
    rewards.push(`${task.balance_reward}元余额`)
  }
  if (task.title_id > 0) {
    const titles = await query('SELECT * FROM custom_titles WHERE id = ?', [task.title_id])
    if (titles && titles.length > 0) {
      const title = titles[0]
      const hasTitle = await query('SELECT id FROM user_titles WHERE user_id = ? AND title_id = ?', [Number(userId), task.title_id])
      if (!hasTitle || !hasTitle.length) {
        await query(
          'INSERT INTO user_titles (user_id, title_id, is_active, grant_by) VALUES (?, ?, 1, ?)',
          [Number(userId), title.id, 'task']
        )
      }
      rewards.push(`称号"${title.name}"`)
    }
  }
  if (task.card_key_type && task.card_key_type !== '') {
    try {
      const cardNo = 'TASK-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
      const pwd = Math.random().toString(36).substring(2, 10).toUpperCase()
      await query(
        `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, duration, duration_unit)
         VALUES (?, ?, ?, 0, ?, ?, ?, ?)`,
        [cardNo, pwd, task.card_key_type || '', task.card_key_value || 0, '', task.card_key_duration || 0, '']
      )
      rewards.push(`卡密奖励(${cardNo})`)
    } catch {}
  }
  return rewards
}

async function progressTasksByAction(userId, userName, actionType, count = 1) {
  if (!userId || userId <= 0) return
  try {
    const now = new Date()
    const tasks = await query(
      "SELECT * FROM custom_tasks WHERE status = '1' AND action_type = ? ORDER BY id",
      [actionType]
    )

    for (const task of tasks) {
      if (task.start_time && new Date(task.start_time) > now) continue
      if (task.end_time && new Date(task.end_time) < now) continue

      const periodKey = getPeriodKey(task.task_type)
      const existing = await query(
        'SELECT * FROM task_records WHERE user_id = ? AND task_id = ? AND period_key = ?',
        [Number(userId), task.id, periodKey]
      )

      let record = existing && existing.length > 0 ? existing[0] : null
      if (record && record.status === 'completed') continue

      const newProgress = (record ? record.progress : 0) + Number(count)
      const completed = newProgress >= task.target_count && task.target_count > 0

      if (record) {
        await query(
          'UPDATE task_records SET progress = ?, status = ?, completed_at = ? WHERE id = ?',
          [newProgress, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, record.id]
        )
      } else {
        await query(
          'INSERT INTO task_records (user_id, user_name, task_id, task_name, progress, target_count, status, completed_at, period_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [Number(userId), userName || '', task.id, task.name, newProgress, task.target_count, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, periodKey]
        )
      }

      if (completed) {
        const rewards = await grantTaskReward(task, userId, userName)
        const rewardText = rewards.length > 0 ? `获得: ${rewards.join('、')}` : ''
        sendNotification(Number(userId), '任务完成', `恭喜完成"${task.name}"任务！${rewardText}`)
        emitSafe(TASK_EVENTS.COMPLETED, { userId: Number(userId), userName, taskId: task.id, taskName: task.name, actionType })
      }
    }
  } catch (e) {
    console.error('progressTasksByAction error:', e.message)
  }
}

function customTaskRoutes(router) {
  router.get('/api/custom-task/list', async (req, res) => {
    try {
      const { status } = req.query
      let where = ''
      const params = []
      if (status) { where = 'WHERE status = ?'; params.push(status) }
      const list = await query(`SELECT * FROM custom_tasks ${where} ORDER BY sort_order, id`, params)
      res.json({ code: 200, data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/save', async (req, res) => {
    try {
      const {
        id, name, description, icon, task_type, action_type, target_count,
        section_id, section_limit, points_reward, exp_reward, balance_reward,
        card_key_type, card_key_value, card_key_duration, title_id, status, sort_order,
        start_time, end_time
      } = req.body

      if (!name || !task_type || !action_type) {
        return res.json({ code: 400, msg: '任务名称、类型和动作类型不能为空' })
      }

      const fields = {
        name, description: description || '', icon: icon || '',
        task_type, action_type, target_count: target_count || 1,
        section_id: section_id || 0, section_limit: section_limit || 0,
        points_reward: points_reward || 0, exp_reward: exp_reward || 0,
        balance_reward: balance_reward || 0,
        card_key_type: card_key_type || '', card_key_value: card_key_value || 0,
        card_key_duration: card_key_duration || 0, title_id: title_id || 0,
        status: status || '1', sort_order: sort_order || 0,
        start_time: start_time || null, end_time: end_time || null
      }

      if (id) {
        const sets = Object.keys(fields).map(k => `${k}=?`).join(',')
        const vals = Object.values(fields)
        await query(`UPDATE custom_tasks SET ${sets} WHERE id=?`, [...vals, Number(id)])
        logFromReq(req, 'update', 'custom_task', Number(id), `更新自定义任务"${name}"`)
      } else {
        const keys = Object.keys(fields).join(',')
        const placeholders = Object.keys(fields).map(() => '?').join(',')
        const result = await query(`INSERT INTO custom_tasks (${keys}) VALUES (${placeholders})`, Object.values(fields))
        logFromReq(req, 'create', 'custom_task', result.insertId, `新增自定义任务"${name}"`)
      }
      res.json({ code: 200, msg: id ? '更新成功' : '创建成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/delete', async (req, res) => {
    try {
      await query('DELETE FROM custom_tasks WHERE id = ?', [Number(req.body.id)])
      logFromReq(req, 'delete', 'custom_task', req.body.id, `删除自定义任务ID:${req.body.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/custom-task/my', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const now = new Date()
      const dateKey = formatDateTime(now).slice(0, 10)
      const weekKey = getWeekKey(now)
      const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      const yearKey = `${now.getFullYear()}`

      const tasks = await query("SELECT * FROM custom_tasks WHERE status = '1' ORDER BY sort_order, id")
      const records = await query(
        'SELECT * FROM task_records WHERE user_id = ?',
        [Number(userId)]
      )

      const result = tasks.filter(task => {
        if (task.start_time && new Date(task.start_time) > now) return false
        if (task.end_time && new Date(task.end_time) < now) return false
        return true
      }).map(task => {
        let periodKey = ''
        if (task.task_type === 'daily') periodKey = dateKey
        else if (task.task_type === 'weekly') periodKey = weekKey
        else if (task.task_type === 'monthly') periodKey = monthKey
        else if (task.task_type === 'yearly') periodKey = yearKey

        const record = records.find(r => r.task_id === task.id && r.period_key === periodKey)
        return {
          ...task,
          progress: record ? record.progress : 0,
          completed: record ? record.status === 'completed' : false,
          recordId: record ? record.id : null
        }
      })

      res.json({ code: 200, data: result })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/do', async (req, res) => {
    try {
      const { userId, taskId, actionCount = 1 } = req.body
      if (!userId || !taskId) return res.json({ code: 400, msg: '参数不完整' })

      const tasks = await query('SELECT * FROM custom_tasks WHERE id = ? AND status = ?', [Number(taskId), '1'])
      if (!tasks || !tasks.length) return res.json({ code: 404, msg: '任务不存在或已下线' })

      const task = tasks[0]
      const now = new Date()

      if (task.start_time && new Date(task.start_time) > now) {
        return res.json({ code: 400, msg: '任务尚未开始' })
      }
      if (task.end_time && new Date(task.end_time) < now) {
        return res.json({ code: 400, msg: '任务已结束' })
      }

      const periodKey = getPeriodKey(task.task_type)
      const existing = await query(
        'SELECT * FROM task_records WHERE user_id = ? AND task_id = ? AND period_key = ?',
        [Number(userId), Number(taskId), periodKey]
      )

      let record = existing && existing.length > 0 ? existing[0] : null
      const newProgress = (record ? record.progress : 0) + Number(actionCount)
      const completed = newProgress >= task.target_count && task.target_count > 0

      if (record) {
        await query(
          'UPDATE task_records SET progress = ?, status = ?, completed_at = ? WHERE id = ?',
          [newProgress, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, record.id]
        )
      } else {
        const userName = req.headers['x-user-name'] || ''
        await query(
          'INSERT INTO task_records (user_id, user_name, task_id, task_name, progress, target_count, status, completed_at, period_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [Number(userId), userName, Number(taskId), task.name, newProgress, task.target_count, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, periodKey]
        )
      }

      const rewards = []
      if (completed) {
        const r = await grantTaskReward(task, userId, req.headers['x-user-name'] || '')
        rewards.push(...r)
        sendNotification(Number(userId), '任务完成', `恭喜完成"${task.name}"任务！获得: ${rewards.join('、')}`)
      }

      res.json({
        code: 200,
        msg: completed ? '任务完成!' : `进度 +${actionCount}`,
        data: { progress: newProgress, target: task.target_count, completed, rewards }
      })
    } catch (e) {
      res.serverError(e)
    }
  })
}

customTaskRoutes.progressTasksByAction = progressTasksByAction

module.exports = customTaskRoutes
