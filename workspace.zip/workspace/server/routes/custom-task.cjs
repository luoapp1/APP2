const { query, getSystemOperator } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { getPermissionValue } = require('../middleware/level-permissions.cjs')
const { emitSafe, TASK_EVENTS } = require('../plugins/events.cjs')
const { deductExperience, addExperience, addBalance, addPoints, deductBalance, addCurrency, deductCurrency } = require('./account-utils.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function formatDateTime(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    const pad = (n) => String(n).padStart(2, '0')
    return `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`
  } catch { return '' }
}

async function sendNotification(userId, title, content) {
  try {
    const sysOpName = (await getSystemOperator())?.username || '管理员'
    await query(
      `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?, ?, 'system', ?, 0, ?, '')`,
      [title, content, userId, sysOpName]
    )
  } catch {}
}

function getPeriodKey(taskType) {
  const now = new Date()
  if (taskType === 'daily') return formatDateTime(now).slice(0, 10)
  if (taskType === 'weekly') return getWeekKey(now)
  if (taskType === 'monthly') return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
  if (taskType === 'yearly') return `${now.getFullYear()}`
  return ''
}

function getWeekKey(date) {
  const d = new Date(date)
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  const monday = new Date(d.setDate(diff))
  return monday.toISOString().slice(0, 10)
}

async function grantTaskReward(task, userId, userName) {
  // H2: 任务系统经验奖励倍率
  let rewardMultiplier = 1.0
  try { rewardMultiplier = parseFloat(await getPermissionValue(userId, 'function', 'H2') || '1.0') } catch {}
  const rewards = []

  // currency_rewards: JSON {currency_key: amount, ...}
  let curRewards = {}
  if (task.currency_rewards) {
    try { curRewards = typeof task.currency_rewards === 'string' ? JSON.parse(task.currency_rewards) : task.currency_rewards } catch {}
  }
  for (const [key, amt] of Object.entries(curRewards)) {
    const adj = Math.round(Number(amt) * rewardMultiplier * 100) / 100
    if (adj <= 0) continue
    await addCurrency(userId, userName || '', key, adj, task.name, `完成任务: ${task.name}`)
    // look up display_name for log
    const [cs] = await query('SELECT display_name FROM currency_settings WHERE currency_key=?', [key])
    rewards.push(`${adj}${cs?.display_name || key}`)
  }

  // backward compat: individual columns
  const pointsReward = Math.round((task.points_reward || 0) * rewardMultiplier)
  const expReward = Math.round((task.exp_reward || 0) * rewardMultiplier)
  const balanceReward = Math.round((task.balance_reward || 0) * rewardMultiplier * 100) / 100
  if (pointsReward > 0 && !curRewards.points) {
    await addPoints(userId, userName || '', pointsReward, task.name, `完成任务: ${task.name}`)
    rewards.push(`${pointsReward}积分`)
  }
  if (expReward > 0 && !curRewards.experience) {
    await addExperience(userId, userName || '', expReward, task.name, `完成任务: ${task.name}`, task.id)
    rewards.push(`${expReward}经验`)
  }
  if (balanceReward > 0 && !curRewards.balance) {
    await addBalance(userId, userName || '', balanceReward, task.name, `完成任务: ${task.name}`)
    rewards.push(`${balanceReward}元余额`)
  }
  if (task.title_id > 0) {
    const titles = await query('SELECT * FROM custom_titles WHERE id = ?', [task.title_id])
    if (titles && titles.length > 0) {
      const title = titles[0]
      const hasTitle = await query('SELECT id FROM user_titles WHERE user_id = ? AND title_id = ?', [Number(userId), task.title_id])
      if (!hasTitle || !hasTitle.length) {
        await query(
          'INSERT INTO user_titles (user_id, title_id, is_active, grant_by) VALUES (?, ?, 1, ?)',
          [Number(userId), title.id, 'task']
        )
      }
      rewards.push(`称号"${title.name}"`)
    }
  }
  if (task.card_key_type && task.card_key_type !== '') {
    try {
      const cardNo = 'TASK-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
      const pwd = Math.random().toString(36).substring(2, 10).toUpperCase()
      await query(
        `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value, duration, duration_unit)
         VALUES (?, ?, ?, 0, ?, ?, ?, ?)`,
        [cardNo, pwd, task.card_key_type || '', task.card_key_value || 0, '', task.card_key_duration || 0, '']
      )
      rewards.push(`卡密奖励(${cardNo})`)
    } catch {}
  }
  return rewards
}

async function progressTasksByAction(userId, userName, actionType, count = 1) {
  if (!userId || userId <= 0) return
  try {
    const now = new Date()
    const tasks = await query(
      "SELECT * FROM custom_tasks WHERE status = '1' AND action_type = ? AND (direction IS NULL OR direction = 'earn') ORDER BY id",
      [actionType]
    )

    for (const task of tasks) {
      if (task.start_time && new Date(task.start_time) > now) continue
      if (task.end_time && new Date(task.end_time) < now) continue

      const periodKey = getPeriodKey(task.task_type)
      const existing = await query(
        'SELECT * FROM task_records WHERE user_id = ? AND task_id = ? AND period_key = ?',
        [Number(userId), task.id, periodKey]
      )

      let record = existing && existing.length > 0 ? existing[0] : null
      if (record && record.status === 'completed') continue

      const newProgress = (record ? record.progress : 0) + Number(count)
      const completed = newProgress >= task.target_count && task.target_count > 0

      if (record) {
        await query(
          'UPDATE task_records SET progress = ?, status = ?, completed_at = ? WHERE id = ?',
          [newProgress, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, record.id]
        )
      } else {
        await query(
          'INSERT INTO task_records (user_id, user_name, task_id, task_name, progress, target_count, status, completed_at, period_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [Number(userId), userName || '', task.id, task.name, newProgress, task.target_count, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, periodKey]
        )
      }

      if (completed) {
        const rewards = await grantTaskReward(task, userId, userName)
        const rewardText = rewards.length > 0 ? `获得: ${rewards.join('、')}` : ''
        sendNotification(Number(userId), '任务完成', `恭喜完成"${task.name}"任务！${rewardText}`)
        emitSafe(TASK_EVENTS.COMPLETED, { userId: Number(userId), userName, taskId: task.id, taskName: task.name, actionType })
      }
    }
  } catch (e) {
    console.error('progressTasksByAction error:', e.message)
  }
}

function parsePenaltyConfig(task) {
  try {
    return task.penalty_config ? JSON.parse(task.penalty_config) : {}
  } catch {
    return {}
  }
}

function getAmountFromBands(penaltyConfig, metadata) {
  const bands = penaltyConfig.duration_bands
  if (!bands || !Array.isArray(bands) || !bands.length) return null
  const days = Number(metadata.durationDays) || 0
  if (days <= 0) return null
  for (const band of bands) {
    if (days >= (band.min_days || 0) && days <= (band.max_days || 0)) {
      return Number(band.amount) || 0
    }
  }
  return null
}

function calculatePenaltyAmount(baseAmount, currentCount, penaltyConfig) {
  const stepMultiplier = Number(penaltyConfig.step_multiplier) || 0.5
  const maxMultiplier = Number(penaltyConfig.max_multiplier) || 5.0
  const multiplier = Math.min(1 + currentCount * stepMultiplier, maxMultiplier)
  return Math.round(baseAmount * multiplier)
}

async function executeAdditionalActions(userId, taskId, penaltyConfig, currentCount, lastTime) {
  if (!penaltyConfig.additional_actions || !Array.isArray(penaltyConfig.additional_actions)) return

  for (const action of penaltyConfig.additional_actions) {
    if (currentCount >= (action.trigger_count || 0)) {
      const durationMinutes = action.duration_minutes || 0
      const until = durationMinutes > 0
        ? new Date(Date.now() + durationMinutes * 60000)
        : null

      if (action.action === 'mute_post' || action.action === 'mute_all') {
        const existing = await query(
          'SELECT id FROM community_banned_users WHERE user_id = ? AND is_active = 1 AND banned_until > NOW()',
          [Number(userId)]
        )
        if (!existing || !existing.length) {
          await query(
            'INSERT INTO community_banned_users (user_id, user_name, reason, banned_until, is_active) VALUES (?, ?, ?, ?, 1)',
            [Number(userId), '', `累计违规 ${currentCount} 次触发禁言`, until ? formatDateTime(until) : null]
          )
        } else if (until) {
          await query(
            "UPDATE community_banned_users SET banned_until = GREATEST(banned_until, ?), reason = CONCAT(reason, '; 累计违规升级') WHERE user_id = ? AND is_active = 1",
            [formatDateTime(until), Number(userId)]
          )
        }
      }

      if (action.action === 'freeze_account') {
        const freezeUntil = until ? formatDateTime(until) : null
        await query(
          'UPDATE users SET status = \'0\', ban_until = ? WHERE id = ?',
          [freezeUntil, Number(userId)]
        )
      }

      if (action.action === 'ban_from_chat') {
        await query(
          'INSERT INTO chat_room_bans (room_id, user_id, type, reason, ban_until, banned_by, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [0, Number(userId), 'permanent', `累计违规 ${currentCount} 次触发聊天室封禁`, until ? formatDateTime(until) : null, 0, 'active']
        )
      }

      if (action.action === 'deduct_exp' && (action.amount || 0) > 0) {
        await deductExperience(Number(userId), '', Number(action.amount), '附加惩罚', `累计违规 ${currentCount} 次触发附加扣除经验`, taskId)
      }

      if (action.action === 'deduct_balance' && (action.amount || 0) > 0) {
        await deductBalance(Number(userId), '', Number(action.amount), '附加惩罚', `累计违规 ${currentCount} 次触发附加扣除余额`, taskId)
      }

      if (action.action && action.action.length > 0 && !['deduct_exp', 'deduct_balance', 'mute_post', 'mute_all', 'freeze_account', 'ban_from_chat'].includes(action.action) && (action.amount || 0) > 0) {
        await deductCurrency(Number(userId), '', String(action.action), Number(action.amount), '附加惩罚', `累计违规 ${currentCount} 次触发附加扣除${action.action}`, taskId)
      }
    }
  }
}

function getDayKey() {
  return new Date().toISOString().slice(0, 10)
}

async function checkDailyDeductionLimit(userId, threshold) {
  const dayKey = getDayKey()
  const rows = await query(
    "SELECT COALESCE(SUM(amount), 0) as total FROM currency_transactions WHERE user_id = ? AND currency_key='experience' AND tx_type='spend' AND DATE(create_time) = ?",
    [Number(userId), dayKey]
  )
  return (rows[0]?.total || 0) >= threshold
}

async function executePenalty(userId, userName, actionType, metadata = {}) {
  if (!userId || userId <= 0) return { executed: false, reason: 'invalid_user' }
  try {
    const tasks = await query(
      "SELECT * FROM custom_tasks WHERE status = '1' AND action_type = ? AND direction = 'spend' ORDER BY id",
      [actionType]
    )
    if (!tasks || !tasks.length) return { executed: false, reason: 'no_matching_rule' }

    const results = []
    for (const task of tasks) {
      const penaltyConfig = parsePenaltyConfig(task)
      const bandAmount = getAmountFromBands(penaltyConfig, metadata)
      const baseAmount = bandAmount !== null ? bandAmount : (task.exp_reward || 0)
      if (baseAmount <= 0) continue

      const existing = await query(
        'SELECT * FROM user_violation_counts WHERE user_id = ? AND task_id = ?',
        [Number(userId), task.id]
      )
      const currentCount = existing && existing.length > 0 ? existing[0].count : 0
      const nextCount = currentCount + 1

      const finalAmount = calculatePenaltyAmount(baseAmount, currentCount, penaltyConfig)
      const desc = currentCount > 0
        ? `${task.name}（第${nextCount}次，x${(1 + currentCount * (penaltyConfig.step_multiplier || 0.5)).toFixed(1)}加成）`
        : task.name

      await deductExperience(Number(userId), userName || '', finalAmount, task.name, desc, task.id)

      if (existing && existing.length > 0) {
        await query(
          'UPDATE user_violation_counts SET count = ?, last_time = NOW() WHERE id = ?',
          [nextCount, existing[0].id]
        )
      } else {
        await query(
          'INSERT INTO user_violation_counts (user_id, task_id, count, last_time) VALUES (?, ?, ?, NOW())',
          [Number(userId), task.id, nextCount]
        )
      }

      await executeAdditionalActions(Number(userId), task.id, penaltyConfig, nextCount)

      sendNotification(Number(userId), '经验扣除通知',
        `因"${task.name}"，扣除 ${finalAmount} 经验值。${metadata.reason ? `原因：${metadata.reason}` : ''}`)

      const dailyLimit = Number(penaltyConfig.daily_deduction_limit) || 500
      if (await checkDailyDeductionLimit(Number(userId), dailyLimit)) {
        const sentToday = await query(
          "SELECT id FROM sys_notifications WHERE target_user_id = ? AND title = '经验下降过快提醒' AND DATE(create_time) = ?",
          [Number(userId), getDayKey()]
        )
        if (!sentToday || !sentToday.length) {
          sendNotification(Number(userId), '经验下降过快提醒',
            '你的经验值今日下降过快，请注意遵守社区规范。如有疑问可联系管理员申诉。')
        }
      }

      results.push({ taskId: task.id, taskName: task.name, amount: finalAmount, count: nextCount })
    }

    if (results.length > 0) {
      emitSafe('penalty:executed', { userId: Number(userId), userName, actionType, results })
    }
    return { executed: results.length > 0, results }
  } catch (e) {
    console.error('executePenalty error:', e.message)
    return { executed: false, reason: 'error', error: e.message }
  }
}

function customTaskRoutes(router) {
  router.get('/api/custom-task/list', authRequired, adminRequired, async (req, res) => {
    try {
      const { status, direction } = req.query
      const conditions = []
      const params = []
      if (status) { conditions.push('status = ?'); params.push(status) }
      if (direction) { conditions.push('(direction = ? OR (direction IS NULL AND ? = \'earn\'))'); params.push(direction, direction) }
      const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : ''
      const list = await query(`SELECT * FROM custom_tasks ${where} ORDER BY sort_order, id`, params)
      res.json({ code: 200, data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/save', authRequired, adminRequired, async (req, res) => {
    try {
      const {
        id, name, description, icon, task_type, action_type, target_count,
        section_id, section_limit, points_reward, exp_reward, balance_reward,
        currency_rewards,
        card_key_type, card_key_value, card_key_duration, title_id, status, sort_order,
        start_time, end_time, direction, penalty_config
      } = req.body

      if (!name || !action_type) {
        return res.json({ code: 400, msg: '任务名称和动作类型不能为空' })
      }

      const fields = {
        name, description: description || '', icon: icon || '',
        task_type: task_type || 'once', action_type, target_count: target_count || 1,
        section_id: section_id || 0, section_limit: section_limit || 0,
        points_reward: points_reward || 0, exp_reward: exp_reward || 0,
        balance_reward: balance_reward || 0,
        currency_rewards: currency_rewards ? (typeof currency_rewards === 'string' ? currency_rewards : JSON.stringify(currency_rewards)) : null,
        card_key_type: card_key_type || '', card_key_value: card_key_value || 0,
        card_key_duration: card_key_duration || 0, title_id: title_id || 0,
        status: status || '1', sort_order: sort_order || 0,
        start_time: start_time || null, end_time: end_time || null,
        direction: direction || 'earn',
        penalty_config: penalty_config ? (typeof penalty_config === 'string' ? penalty_config : JSON.stringify(penalty_config)) : null
      }

      if (id) {
        const sets = Object.keys(fields).map(k => `${k}=?`).join(',')
        const vals = Object.values(fields)
        await query(`UPDATE custom_tasks SET ${sets} WHERE id=?`, [...vals, Number(id)])
        logFromReq(req, 'update', 'custom_task', Number(id), `更新${fields.direction === 'spend' ? '惩罚规则' : '任务'}"${name}"`)
      } else {
        const keys = Object.keys(fields).join(',')
        const placeholders = Object.keys(fields).map(() => '?').join(',')
        const result = await query(`INSERT INTO custom_tasks (${keys}) VALUES (${placeholders})`, Object.values(fields))
        logFromReq(req, 'create', 'custom_task', result.insertId, `新增${fields.direction === 'spend' ? '惩罚规则' : '任务'}"${name}"`)
      }
      res.json({ code: 200, msg: id ? '更新成功' : '创建成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/delete', authRequired, adminRequired, async (req, res) => {
    try {
      await query('DELETE FROM custom_tasks WHERE id = ?', [Number(req.body.id)])
      logFromReq(req, 'delete', 'custom_task', req.body.id, `删除自定义任务ID:${req.body.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/custom-task/my', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const now = new Date()
      const dateKey = formatDateTime(now).slice(0, 10)
      const weekKey = getWeekKey(now)
      const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      const yearKey = `${now.getFullYear()}`

      const tasks = await query("SELECT * FROM custom_tasks WHERE status = '1' ORDER BY sort_order, id")
      const records = await query(
        'SELECT * FROM task_records WHERE user_id = ?',
        [Number(userId)]
      )

      const result = tasks.filter(task => {
        if (task.start_time && new Date(task.start_time) > now) return false
        if (task.end_time && new Date(task.end_time) < now) return false
        return true
      }).map(task => {
        let periodKey = ''
        if (task.task_type === 'daily') periodKey = dateKey
        else if (task.task_type === 'weekly') periodKey = weekKey
        else if (task.task_type === 'monthly') periodKey = monthKey
        else if (task.task_type === 'yearly') periodKey = yearKey

        const record = records.find(r => r.task_id === task.id && r.period_key === periodKey)
        return {
          ...task,
          progress: record ? record.progress : 0,
          completed: record ? record.status === 'completed' : false,
          recordId: record ? record.id : null
        }
      })

      res.json({ code: 200, data: result })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/custom-task/do', authRequired, async (req, res) => {
    try {
      const { taskId, actionCount = 1 } = req.body
      const userId = req.user.userId
      const userName = req.user.userName
      if (!userId || !taskId) return res.json({ code: 400, msg: '参数不完整' })

      const tasks = await query('SELECT * FROM custom_tasks WHERE id = ? AND status = ?', [Number(taskId), '1'])
      if (!tasks || !tasks.length) return res.json({ code: 404, msg: '任务不存在或已下线' })

      const task = tasks[0]
      const now = new Date()

      if (task.start_time && new Date(task.start_time) > now) {
        return res.json({ code: 400, msg: '任务尚未开始' })
      }
      if (task.end_time && new Date(task.end_time) < now) {
        return res.json({ code: 400, msg: '任务已结束' })
      }

      const periodKey = getPeriodKey(task.task_type)
      const existing = await query(
        'SELECT * FROM task_records WHERE user_id = ? AND task_id = ? AND period_key = ?',
        [Number(userId), Number(taskId), periodKey]
      )

      let record = existing && existing.length > 0 ? existing[0] : null
      const newProgress = (record ? record.progress : 0) + Number(actionCount)
      const completed = newProgress >= task.target_count && task.target_count > 0

      if (record) {
        await query(
          'UPDATE task_records SET progress = ?, status = ?, completed_at = ? WHERE id = ?',
          [newProgress, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, record.id]
        )
      } else {
        const userName = req.user.userName
        await query(
          'INSERT INTO task_records (user_id, user_name, task_id, task_name, progress, target_count, status, completed_at, period_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [Number(userId), userName, Number(taskId), task.name, newProgress, task.target_count, completed ? 'completed' : 'pending', completed ? formatDateTime(now) : null, periodKey]
        )
      }

      const rewards = []
      if (completed) {
        const r = await grantTaskReward(task, userId, userName || '')
        rewards.push(...r)
        sendNotification(Number(userId), '任务完成', `恭喜完成"${task.name}"任务！获得: ${rewards.join('、')}`)
      }

      res.json({
        code: 200,
        msg: completed ? '任务完成!' : `进度 +${actionCount}`,
        data: { progress: newProgress, target: task.target_count, completed, rewards }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/operation/penalty/logs', authRequired, adminRequired, async (req, res) => {
    try {
      const { userId, taskId, startTime, endTime, page = 1, pageSize = 20 } = req.query
      const conditions = ["type = 'expense'"]
      const params = []
      if (userId) { conditions.push('user_id = ?'); params.push(Number(userId)) }
      if (taskId) { conditions.push('task_id = ?'); params.push(Number(taskId)) }
      if (startTime) { conditions.push('create_time >= ?'); params.push(startTime) }
      if (endTime) { conditions.push('create_time <= ?'); params.push(endTime) }
      const where = 'WHERE ' + conditions.join(' AND ')
      const offset = (Number(page) - 1) * Number(pageSize)
      const [total, list] = await Promise.all([
        query(`SELECT COUNT(*) as cnt FROM currency_transactions ${where}`, params),
        query(`SELECT * FROM currency_transactions ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, Number(pageSize), offset])
      ])
      res.json({ code: 200, data: { total: total[0]?.cnt || 0, list, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/operation/penalty/stats', authRequired, adminRequired, async (req, res) => {
    try {
      const { startTime, endTime } = req.query
      const conditions = ["er.tx_type = 'spend'"]
      const params = []
      if (startTime) { conditions.push('er.create_time >= ?'); params.push(startTime) }
      if (endTime) { conditions.push('er.create_time <= ?'); params.push(endTime) }
      const where = 'WHERE ' + conditions.join(' AND ')
      const rows = await query(
        `SELECT ct.id as task_id, ct.name as task_name, COUNT(*) as trigger_count, COALESCE(SUM(er.amount), 0) as total_amount
         FROM currency_transactions er LEFT JOIN custom_tasks ct ON er.task_id = ct.id
         ${where} GROUP BY ct.id, ct.name ORDER BY total_amount DESC`,
        params
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/operation/penalty/manual', authRequired, adminRequired, async (req, res) => {
    try {
      const { userId, amount, reason, skipNotification } = req.body
      if (!userId || !amount || amount <= 0) {
        return res.json({ code: 400, msg: '用户ID和扣分值不能为空' })
      }
      const users = await query('SELECT id, username FROM users WHERE id = ?', [Number(userId)])
      if (!users || !users.length) return res.json({ code: 404, msg: '用户不存在' })

      await deductExperience(Number(userId), users[0].username, Number(amount), '管理员手动扣分', reason || '管理员手动操作', 0)

      if (!skipNotification) {
        sendNotification(Number(userId), '经验扣除通知', `管理员扣除了 ${amount} 经验值。${reason ? `原因：${reason}` : ''}`)
      }

      logFromReq(req, 'penalty', 'manual', Number(userId), `手动扣除用户${users[0].username}经验${amount}`)
      res.json({ code: 200, msg: '扣除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
}

customTaskRoutes.progressTasksByAction = progressTasksByAction
customTaskRoutes.executePenalty = executePenalty

module.exports = customTaskRoutes
