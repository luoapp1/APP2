const { query } = require('../database.cjs')

module.exports = function loginHistoryRoutes(app) {
  const auth = require('./system.cjs').authRequired

  app.get('/api/login-history', auth, async (req, res) => {
    try {
      const userId = req.user.userId
      const page = Math.max(1, parseInt(req.query.page) || 1)
      const pageSize = Math.min(50, Math.max(1, parseInt(req.query.pageSize) || 20))

      const [rows, countResult] = await Promise.all([
        query(
          `SELECT id, ip, user_agent, device_type, os, browser,
                  ip_country, ip_province, ip_city, ip_isp, is_new_device, create_time
           FROM login_history
           WHERE user_id = ?
           ORDER BY create_time DESC
           LIMIT ? OFFSET ?`,
          [userId, pageSize, (page - 1) * pageSize]
        ),
        query('SELECT COUNT(*) as total FROM login_history WHERE user_id = ?', [userId])
      ])

      res.json({
        code: 200,
        data: {
          list: rows || [],
          total: countResult[0]?.total || 0,
          page,
          pageSize
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/auth/logout-all', auth, async (req, res) => {
    try {
      const userId = req.user.userId
      const currentToken = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')

      await query('DELETE FROM sessions WHERE user_id = ? AND token != ?', [userId, currentToken])

      const { sessions: sessionsMap } = require('./system.cjs')
      if (sessionsMap) {
        for (const [token, session] of sessionsMap) {
          if (session.userId === userId && token !== currentToken) {
            sessionsMap.delete(token)
          }
        }
      }

      res.json({ code: 200, msg: '其他设备已全部下线' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/auth/logout-everywhere', auth, async (req, res) => {
    try {
      const userId = req.user.userId

      await query('DELETE FROM sessions WHERE user_id = ?', [userId])

      const { sessions: sessionsMap } = require('./system.cjs')
      if (sessionsMap) {
        for (const [token, session] of sessionsMap) {
          if (session.userId === userId) {
            sessionsMap.delete(token)
          }
        }
      }

      res.json({ code: 200, msg: '所有设备已全部下线，请重新登录' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}
