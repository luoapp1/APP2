const { query } = require('../database.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')
const { authRequired } = require('./system.cjs')

function postFavoriteRoutes(router) {
  router.get('/api/post-favorite/list', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const rows = await query(
        `SELECT f.*, p.title, LEFT(p.content, 200) as summary, p.section_id, p.create_time as post_time, u.username as author,
                p.content_permission as contentPermission, p.user_id as postUserId,
                (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
                 OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
                 OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
         FROM post_favorites f
         JOIN community_posts p ON f.post_id=p.id
         LEFT JOIN users u ON p.user_id=u.id
         WHERE f.user_id=? ORDER BY f.create_time DESC`,
        [Number(userId)]
      )
      // 过滤付费内容
      for (const item of rows) {
        if (item.contentPermission === 'paid' || item.has_restricted) {
          item.summary = '该帖子含付费/加密内容'
        }
      }
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/post-favorite/toggle', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { postId } = req.body
      if (!userId || !postId) return res.json({ code: 400, msg: '参数不完整' })

      const existing = await query(
        'SELECT id FROM post_favorites WHERE user_id=? AND post_id=?',
        [Number(userId), Number(postId)]
      )

      if (existing && existing.length > 0) {
        await query('DELETE FROM post_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        await query(
          'INSERT INTO post_favorites (user_id, post_id) VALUES (?,?)',
          [Number(userId), Number(postId)]
        )
        await progressTasksByAction(Number(userId), '', 'favorite')
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/post-favorite/check', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { postId } = req.query
      if (!userId || !postId) return res.json({ code: 400, msg: '参数不完整' })

      const rows = await query(
        'SELECT id FROM post_favorites WHERE user_id=? AND post_id=?',
        [Number(userId), Number(postId)]
      )
      res.json({ code: 200, data: { favorited: rows && rows.length > 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = postFavoriteRoutes
