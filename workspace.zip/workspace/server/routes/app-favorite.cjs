const { query, getUserId } = require('../database.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')

function appFavoriteRoutes(router) {
  async function ensureDefaultGroup(userId) {
    const rows = await query('SELECT id FROM app_favorite_groups WHERE user_id=?', [userId])
    if (rows && rows.length > 0) return rows[0].id
    const r = await query("INSERT INTO app_favorite_groups (user_id, name, sort_order) VALUES (?,'默认收藏夹',0)", [userId])
    return r.insertId
  }

  // ---- 分组管理 ----

  // 获取分组列表（含计数）
  router.get('/api/app-favorite/groups', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      await ensureDefaultGroup(Number(userId))
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM app_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM app_favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM app_favorite_groups g WHERE g.user_id=? ORDER BY g.sort_order ASC, g.id ASC`,
        [Number(userId)]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 查看某用户公开的应用分组列表
  router.get('/api/app-favorite/groups/user/:uid', async (req, res) => {
    try {
      const uid = parseInt(req.params.uid) || 0
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM app_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM app_favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM app_favorite_groups g WHERE g.user_id=? AND g.is_public=1 ORDER BY g.sort_order ASC, g.id ASC`,
        [uid]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 创建分组
  router.post('/api/app-favorite/groups', async (req, res) => {
    try {
      const userId = req.body.userId || req.headers['x-user-id']
      const { name } = req.body
      if (!userId || !name || !name.trim()) return res.json({ code: 400, msg: '名称不能为空' })
      const maxOrder = await query('SELECT MAX(sort_order) as m FROM app_favorite_groups WHERE user_id=?', [Number(userId)])
      const sortOrder = (maxOrder && maxOrder[0]?.m != null) ? maxOrder[0].m + 1 : 0
      const r = await query('INSERT INTO app_favorite_groups (user_id, name, sort_order) VALUES (?,?,?)', [Number(userId), name.trim(), sortOrder])
      const g = await query('SELECT * FROM app_favorite_groups WHERE id=?', [r.insertId])
      res.json({ code: 200, data: g[0] || null })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 修改分组名称
  router.put('/api/app-favorite/groups/:id', async (req, res) => {
    try {
      const userId = req.body.userId || req.headers['x-user-id']
      const gid = parseInt(req.params.id)
      const { name } = req.body
      if (!userId || !name || !name.trim()) return res.json({ code: 400, msg: '名称不能为空' })
      const g = await query('SELECT id FROM app_favorite_groups WHERE id=? AND user_id=?', [gid, Number(userId)])
      if (!g || g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      await query('UPDATE app_favorite_groups SET name=? WHERE id=?', [name.trim(), gid])
      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 删除分组
  router.delete('/api/app-favorite/groups/:id', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      const gid = parseInt(req.params.id)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groups = await query('SELECT id FROM app_favorite_groups WHERE user_id=? AND id!=?', [Number(userId), gid])
      if (groups.length === 0) return res.json({ code: 400, msg: '至少保留一个分组' })
      const defaultId = await ensureDefaultGroup(Number(userId))
      await query('UPDATE app_favorites SET group_id=? WHERE group_id=? AND user_id=?', [defaultId, gid, Number(userId)])
      await query('DELETE FROM app_favorite_groups WHERE id=? AND user_id=?', [gid, Number(userId)])
      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 设置公开/私密
  router.put('/api/app-favorite/groups/:id/visibility', async (req, res) => {
    try {
      const userId = req.body.userId || req.headers['x-user-id']
      const gid = parseInt(req.params.id)
      const { is_public } = req.body
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const g = await query('SELECT id FROM app_favorite_groups WHERE id=? AND user_id=?', [gid, Number(userId)])
      if (!g || g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      await query('UPDATE app_favorite_groups SET is_public=? WHERE id=?', [is_public ? 1 : 0, gid])
      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ---- 收藏/取消/列表/检查/移动 ----

  router.get('/api/app-favorite/list', async (req, res) => {
    try {
      const userId = req.query.userId || req.headers['x-user-id']
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groupId = parseInt(req.query.groupId) || 0
      let groupWhere = ''
      const params = [Number(userId)]
      if (groupId > 0) { groupWhere = ' AND f.group_id=?'; params.push(groupId) }
      const rows = await query(
        `SELECT f.*, a.name as app_name, a.icon, a.category, a.package_name, a.version,
                a.description, a.downloads, a.rating, a.size_mb, a.icon_bg_color,
                g.name as group_name
         FROM app_favorites f
         JOIN app_store a ON f.app_id=a.id
         LEFT JOIN app_favorite_groups g ON f.group_id=g.id
         WHERE f.user_id=? ${groupWhere}
         ORDER BY f.create_time DESC`,
        params
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 查看某用户公开分组中的应用收藏
  router.get('/api/app-favorite/list/user/:uid', async (req, res) => {
    try {
      const uid = parseInt(req.params.uid) || 0
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groupId = parseInt(req.query.groupId) || 0
      let groupWhere = ''
      const params = [uid]
      if (groupId > 0) { groupWhere = ' AND f.group_id=?'; params.push(groupId) }
      const rows = await query(
        `SELECT f.*, a.name as app_name, a.icon, a.category, a.package_name, a.version,
                a.description, a.downloads, a.rating, a.size_mb, a.icon_bg_color,
                g.name as group_name
         FROM app_favorites f
         JOIN app_store a ON f.app_id=a.id
         LEFT JOIN app_favorite_groups g ON f.group_id=g.id
         WHERE f.user_id=? AND g.is_public=1 ${groupWhere}
         ORDER BY f.create_time DESC`,
        params
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/app-favorite/toggle', async (req, res) => {
    try {
      const { userId, appId, groupId } = req.body
      if (!userId || !appId) return res.json({ code: 400, msg: '参数不完整' })
      const existing = await query(
        'SELECT id, group_id FROM app_favorites WHERE user_id=? AND app_id=?',
        [Number(userId), Number(appId)]
      )
      if (existing && existing.length > 0) {
        await query('DELETE FROM app_favorites WHERE id=?', [existing[0].id])
        res.json({ code: 200, msg: '已取消收藏', data: { favorited: false } })
      } else {
        let gid = parseInt(groupId) || 0
        if (gid <= 0) gid = await ensureDefaultGroup(Number(userId))
        await query('INSERT INTO app_favorites (user_id, app_id, group_id) VALUES (?,?,?)',
          [Number(userId), Number(appId), gid])
        await progressTasksByAction(Number(userId), '', 'favorite')
        res.json({ code: 200, msg: '收藏成功', data: { favorited: true, groupId: gid } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/app-favorite/check', async (req, res) => {
    try {
      const { userId, appId } = req.query
      if (!userId || !appId) return res.json({ code: 400, msg: '参数不完整' })
      const rows = await query(
        'SELECT id, group_id FROM app_favorites WHERE user_id=? AND app_id=?',
        [Number(userId), Number(appId)]
      )
      res.json({ code: 200, data: {
        favorited: rows && rows.length > 0,
        groupId: rows && rows.length > 0 ? rows[0].group_id : 0
      }})
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/app-favorite/move', async (req, res) => {
    try {
      const userId = req.body.userId || req.headers['x-user-id']
      const { appId, targetGroupId } = req.body
      if (!userId || !appId || !targetGroupId) return res.json({ code: 400, msg: '参数不完整' })
      const g = await query('SELECT id FROM app_favorite_groups WHERE id=? AND user_id=?',
        [Number(targetGroupId), Number(userId)])
      if (!g || g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      await query('UPDATE app_favorites SET group_id=? WHERE user_id=? AND app_id=?',
        [Number(targetGroupId), Number(userId), Number(appId)])
      res.json({ code: 200, msg: '移动成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = appFavoriteRoutes
