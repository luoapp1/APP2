const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function redeemCodeRoutes(router) {
  const prefix = '/api/admin/redeem-codes'
  const crypto = require('crypto')

  function genCode() {
    return crypto.randomBytes(6).toString('hex').toUpperCase()
  }

  // 手动新增单个兑换码
  router.post(prefix, authRequired, adminRequired, async (req, res) => {
    try {
      const { code, productId, productName } = req.body
      if (!code || !productId) return res.json({ code: 400, msg: '缺少参数' })

      await query(
        `INSERT INTO redeem_codes (code, batch_id, reward_type, product_id, product_name, status) VALUES (?,?,?,?,?,?)`,
        [code.trim().toUpperCase(), 'MANUAL-' + Date.now(), 'product', productId, productName || '', 'unused']
      )
      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 生成兑换码
  router.post(`${prefix}/generate`, authRequired, adminRequired, async (req, res) => {
    try {
      const { count = 10, rewardType, productId, productName, decorationId, decorationName,
        cardPoolId, cardPoolName, durationDays = 0, expireDays = 0, createdBy = 0 } = req.body
      if (!rewardType || count < 1 || count > 500) return res.json({ code: 400, msg: '参数错误' })

      const batchId = 'BATCH-' + Date.now()
      const expireTime = expireDays > 0
        ? new Date(Date.now() + expireDays * 86400000).toISOString().slice(0, 19).replace('T', ' ')
        : null
      const codes = []

      for (let i = 0; i < count; i++) {
        let code
        do { code = genCode() } while (codes.includes(code))
        codes.push(code)
        await query(
          `INSERT INTO redeem_codes (code, batch_id, reward_type, product_id, product_name, decoration_id, decoration_name, card_pool_id, card_pool_name, duration_days, created_by, expire_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [code, batchId, rewardType, productId || 0, productName || '', decorationId || 0, decorationName || '',
            cardPoolId || 0, cardPoolName || '', durationDays || 0, createdBy || 0, expireTime]
        )
      }

      res.json({ code: 200, data: { batchId, count, codes } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 兑换码列表
  router.get(prefix, async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1
      const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100)
      const offset = (page - 1) * pageSize
      const status = req.query.status || ''
      const batchId = req.query.batchId || ''
      const keyword = req.query.keyword || ''

      let where = 'WHERE 1=1'
      const params = []
      if (status) { where += ' AND status = ?'; params.push(status) }
      if (batchId) { where += ' AND batch_id = ?'; params.push(batchId) }
      if (keyword) { where += ' AND code LIKE ?'; params.push(`%${keyword}%`) }

      const countResult = await query(`SELECT COUNT(*) as total FROM redeem_codes ${where}`, params)
      const total = (countResult && countResult[0]) ? countResult[0].total : 0

      const rows = await query(
        `SELECT * FROM redeem_codes ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [...params, pageSize, offset]
      )

      res.json({ code: 200, data: { list: rows || [], total, page, pageSize } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 兑换码统计
  router.get(`${prefix}/stats`, async (req, res) => {
    try {
      const rows = await query(
        `SELECT batch_id, status, COUNT(*) as cnt FROM redeem_codes GROUP BY batch_id, status ORDER BY batch_id DESC LIMIT 50`
      )
      res.json({ code: 200, data: rows || [] })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })
}

// 用户兑换接口
function userRedeemRoutes(router, authRequired) {
  router.post('/api/user/redeem', authRequired, async (req, res) => {
    try {
      const { code } = req.body
      const userId = req.user?.userId || 0
      const userName = req.user?.userName || ''

      if (!code || !userId) return res.json({ code: 400, msg: '缺少参数' })

      const rows = await query('SELECT * FROM redeem_codes WHERE code = ?', [code.trim().toUpperCase()])
      if (!rows || !rows.length) return res.json({ code: 404, msg: '兑换码不存在' })

      const rc = rows[0]
      if (rc.status !== 'unused') return res.json({ code: 400, msg: '该兑换码已被使用' })
      if (rc.expire_time && new Date(rc.expire_time) < new Date()) {
        return res.json({ code: 400, msg: '该兑换码已过期' })
      }

      let rewardDetail = ''

      if (rc.reward_type === 'decoration' && rc.decoration_id) {
        const duration = rc.duration_days || 0
        const expireTime = duration > 0
          ? new Date(Date.now() + duration * 86400000).toISOString().slice(0, 19).replace('T', ' ')
          : null
        if (expireTime) {
          await query('INSERT INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type, expire_time) VALUES (?,?,?,"0","redeem",?)',
            [userId, rc.decoration_id, rc.decoration_name, expireTime])
        } else {
          await query('INSERT INTO user_decorations (user_id, decoration_id, decoration_type, is_active, obtain_type) VALUES (?,?,?,"0","redeem")',
            [userId, rc.decoration_id, rc.decoration_name])
        }
        rewardDetail = `装饰品「${rc.decoration_name}」`
      } else if (rc.reward_type === 'card_pool' && rc.card_pool_id) {
        const cardPoolRoutes = require('./card-pool.cjs')
        const card = await cardPoolRoutes.drawFromPool(rc.card_pool_id)
        if (!card) return res.json({ code: 400, msg: '卡池已空，请联系管理员' })
        rewardDetail = `卡密：${card.number}，密码：${card.password}`
      } else if (rc.reward_type === 'product' && rc.product_id) {
        rewardDetail = `商品「${rc.product_name}」`
        await query(`INSERT INTO mall_orders (user_id, product_id, option_id, quantity, total_amount, payment_method, status, create_time) VALUES (?,?,0,1,0,'redeem','paid',NOW())`,
          [userId, rc.product_id])
        await query('UPDATE mall_products SET sales_count = sales_count + 1 WHERE id = ?', [rc.product_id])
      }

      await query('UPDATE redeem_codes SET status="used", used_by=?, used_by_name=?, used_at=NOW() WHERE id=?',
        [userId, userName, rc.id])

      // 记录通知
      try {
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id) VALUES (?,?,?,?)`,
          ['兑换成功', `您已成功兑换${rewardDetail}`, 'redeem', userId])
      } catch {}

      res.json({ code: 200, data: { rewardDetail } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })
}

module.exports = { redeemCodeRoutes, userRedeemRoutes }
