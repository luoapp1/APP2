const { query, getPool } = require('../database.cjs')

function safeJsonParse(s, fallback = {}) {
  if (!s) return fallback
  try { return typeof s === 'string' ? JSON.parse(s) : s } catch { return fallback }
}

function trimZeros(s) {
  return s.replace(/\.0+$/, '').replace(/(\.\d+?)0+$/, '$1')
}

async function getUserId(req) {
  const { sessions, SESSION_TTL } = require('./system.cjs')
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      if (Date.now() - row.created_at > SESSION_TTL) {
        query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
        return 0
      }
      sessions.set(token, { userId: row.user_id, createdAt: row.created_at })
      return Number(row.user_id) || 0
    }
  } catch {}
  return 0
}

const curLabelMap = { balance: '余额', points: '积分', experience: '经验', qedxtc: '金币' }
function curLabel(key) { return curLabelMap[key] || key }

module.exports = function exchangeRoutes(app) {
  app.get('/api/exchange/config', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const [user] = await query('SELECT id, username, level_id FROM users WHERE id=?', [userId])
      if (!user) return res.json({ code: 404, msg: '用户不存在' })

      let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [user.level_id || 0])
      if (!configs.length) configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
      if (!configs.length) return res.json({ code: 200, data: { exchanges: [], balances: {} } })

      const cfg = configs[0]
      const ec = safeJsonParse(cfg.exchange_config)

      // Build legacy exchange config if using old format
      const exchangeRates = Object.keys(ec).length > 0 ? ec : {
        points_to_balance: Number(cfg.points_to_balance_rate) || 1,
        balance_to_points: Number(cfg.balance_to_points_rate) || 1
      }

      // Get all exchangeable currency info
      const currencies = await query(
        'SELECT currency_key, display_name, display_symbol, decimal_places, card_color FROM currency_settings WHERE is_visible=1 ORDER BY sort_order'
      )
      const curMap = {}
      for (const c of currencies) curMap[c.currency_key] = c

      // Get user balances
      const balances = {}
      const balRows = await query('SELECT currency_key, available FROM user_currency_balance WHERE user_id=?', [userId])
      for (const r of balRows) balances[r.currency_key] = Number(r.available || 0)

      // Build exchange pairs
      const exchanges = []
      for (const [rateKey, rate] of Object.entries(exchangeRates)) {
        const r = Number(rate)
        if (r <= 0) continue
        const parts = rateKey.split('_to_')
        if (parts.length !== 2) continue
        const fromKey = parts[0]
        const toKey = parts[1]
        const fromCur = curMap[fromKey]
        const toCur = curMap[toKey]
        if (!fromCur || !toCur) continue
        exchanges.push({
          typeKey: `${fromKey}_to_${toKey}`,
          tabName: `${curLabel(fromKey)}兑换${curLabel(toKey)}`,
          rateDesc: `1 ${fromCur.display_symbol || fromKey} = ${r} ${toCur.display_symbol || toKey}`,
          rate: r,
          fromCurrency: fromKey,
          toCurrency: toKey,
          fromDisplayName: fromCur.display_name || fromKey,
          toDisplayName: toCur.display_name || toKey,
          fromSymbol: fromCur.display_symbol || '',
          toSymbol: toCur.display_symbol || '',
          fromDecimalPlaces: fromCur.decimal_places || 0,
          toDecimalPlaces: toCur.decimal_places || 0,
        })
      }

      res.json({ code: 200, data: { exchanges, balances } })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/exchange/apply', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { fromCurrency, toCurrency, fromAmount } = req.body
      if (!fromCurrency || !toCurrency || !fromAmount || Number(fromAmount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      const [user] = await query('SELECT id, username, level_id FROM users WHERE id=?', [userId])
      if (!user) return res.json({ code: 404, msg: '用户不存在' })

      let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [user.level_id || 0])
      if (!configs.length) configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
      if (!configs.length) return res.json({ code: 400, msg: '暂无可用的兑换配置' })

      const cfg = configs[0]
      const ec = safeJsonParse(cfg.exchange_config)
      const exchangeRates = Object.keys(ec).length > 0 ? ec : {
        points_to_balance: Number(cfg.points_to_balance_rate) || 1,
        balance_to_points: Number(cfg.balance_to_points_rate) || 1
      }

      const rateKey = `${fromCurrency}_to_${toCurrency}`
      const rate = Number(exchangeRates[rateKey])
      if (!rate || rate <= 0) return res.json({ code: 400, msg: '不支持的兑换方向' })

      const fromAmt = Number(fromAmount)
      const toAmt = Math.floor(fromAmt * rate)

      const [fromCs] = await query('SELECT decimal_places, currency_type, display_name FROM currency_settings WHERE currency_key=?', [fromCurrency])
      const [toCs] = await query('SELECT decimal_places, currency_type, display_name FROM currency_settings WHERE currency_key=?', [toCurrency])
      if (fromCs && fromCs.currency_type === 'quota') return res.json({ code: 403, msg: '该币种不支持兑换' })
      if (toCs && toCs.currency_type === 'quota') return res.json({ code: 403, msg: '该币种不支持兑换' })

      const fromDp = fromCs?.decimal_places ?? 0
      const toDp = toCs?.decimal_places ?? 0
      const fromF = trimZeros(Number(fromAmt).toFixed(fromDp))
      const toF = trimZeros(Number(toAmt).toFixed(toDp))

      const desc = `兑换: ${fromF} ${fromCs?.display_name || fromCurrency} → ${toF} ${toCs?.display_name || toCurrency}`

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        // ensure fromCurrency balance exists
        const [fromBalRow] = await conn.query(
          'SELECT available, frozen FROM user_currency_balance WHERE user_id=? AND currency_key=? FOR UPDATE',
          [userId, fromCurrency]
        )
        if (!fromBalRow || !fromBalRow.length) {
          await conn.query(
            'INSERT INTO user_currency_balance (user_id, currency_key, available, frozen) VALUES (?, ?, 0, 0)',
            [userId, fromCurrency]
          )
        }
        const fromAvailable = fromBalRow && fromBalRow.length ? Number(fromBalRow[0].available || 0) : 0

        if (fromAvailable < fromAmt) {
          await conn.rollback()
          conn.release()
          return res.json({ code: 400, msg: `${fromCurrency} 余额不足 (可用: ${fromAvailable})` })
        }

        // deduct from source
        await conn.query(
          'UPDATE user_currency_balance SET available = available - ?, updated_at = NOW() WHERE user_id=? AND currency_key=?',
          [fromAmt, userId, fromCurrency]
        )
        // write from transaction record
        const [afterFrom] = await conn.query(
          'SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=?',
          [userId, fromCurrency]
        )
        const afterFromAvail = afterFrom[0]?.available ?? 0
        await conn.query(
          'INSERT INTO currency_transactions (user_id,user_name,currency_key,tx_type,amount,balance_before,balance_after,source_type,source_id,description,create_time) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())',
          [userId, user.username, fromCurrency, 'spend', fromAmt, fromAvailable, afterFromAvail, 'exchange', '', desc]
        )

        // ensure toCurrency balance exists
        const [toBalRow] = await conn.query(
          'SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=?',
          [userId, toCurrency]
        )
        if (!toBalRow || !toBalRow.length) {
          await conn.query(
            'INSERT INTO user_currency_balance (user_id, currency_key, available, frozen) VALUES (?, ?, 0, 0)',
            [userId, toCurrency]
          )
        }
        const toBefore = toBalRow && toBalRow.length ? Number(toBalRow[0].available || 0) : 0

        // add to target
        await conn.query(
          'UPDATE user_currency_balance SET available = available + ?, updated_at = NOW() WHERE user_id=? AND currency_key=?',
          [toAmt, userId, toCurrency]
        )
        const toAfter = toBefore + toAmt
        await conn.query(
          'INSERT INTO currency_transactions (user_id,user_name,currency_key,tx_type,amount,balance_before,balance_after,source_type,source_id,description,create_time) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())',
          [userId, user.username, toCurrency, 'earn', toAmt, toBefore, toAfter, 'exchange', '', desc]
        )

        await conn.commit()
      } catch (e) {
        try { await conn.rollback() } catch (_) {}
        conn.release()
        return res.json({ code: 400, msg: e.message })
      }
      conn.release()

      res.json({ code: 200, msg: '兑换成功', data: { fromAmount: fromF, toAmount: toF, fromCurrency, toCurrency } })
    } catch (e) { res.serverError(e) }
  })
}
