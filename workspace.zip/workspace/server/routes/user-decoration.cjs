const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')

function init(app) {
  app.get('/api/user/decorations', authRequired, (req, res) => {
    const userId = req.user.userId
    const type = req.query.type || ''
    if (!type) return res.json({ code: 400, message: '缺少 type 参数' })

    if (type === 'avatar_frame') {
      query(
        `SELECT af.*, uf.is_active, uf.obtain_type, uf.obtain_time
         FROM avatar_frames af
         INNER JOIN user_avatar_frames uf ON uf.frame_id = af.id AND uf.user_id = ?
         WHERE af.status = '1'
         ORDER BY uf.is_active DESC, uf.id DESC`,
        [userId]
      )
        .then(rows => {
          const active = rows.find(r => r.is_active === 1)
          res.json({ code: 200, data: rows, active: active || null })
        })
        .catch(err => res.json({ code: 500, message: err.message }))
    } else if (type === 'title') {
      query(
        `SELECT ct.*, ut.is_active, ut.grant_by, ut.grant_time, ut.expire_time
         FROM custom_titles ct
         INNER JOIN user_titles ut ON ut.title_id = ct.id AND ut.user_id = ?
         WHERE ct.status = '1'
         ORDER BY ut.is_active DESC, ut.id DESC`,
        [userId]
      )
        .then(rows => {
          const active = rows.filter(r => r.is_active === 1)
          res.json({ code: 200, data: rows, active: active })
        })
        .catch(err => res.json({ code: 500, message: err.message }))
    } else {
      query(
        `SELECT d.*, ud.is_active, ud.obtain_type, ud.create_time AS obtain_time, ud.expire_time
         FROM decorations d
         INNER JOIN user_decorations ud ON ud.decoration_id = d.id AND ud.user_id = ?
         WHERE d.type = ? AND d.status = '1'
         ORDER BY ud.is_active DESC, ud.id DESC`,
        [userId, type]
      )
        .then(rows => {
          const active = rows.find(r => r.is_active === 1)
          res.json({ code: 200, data: rows, active: active || null })
        })
        .catch(err => res.json({ code: 500, message: err.message }))
    }
  })

  app.post('/api/user/activate-decoration', authRequired, (req, res) => {
    const userId = req.user.userId
    const { type, decoration_id } = req.body
    if (!type || !decoration_id) return res.json({ code: 400, message: '缺少参数' })

    if (type === 'avatar_frame') {
      query('SELECT id FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [userId, decoration_id])
        .then(([row]) => {
          if (!row) return res.json({ code: 404, message: '未拥有此头像框' })
          query('UPDATE user_avatar_frames SET is_active=0 WHERE user_id=?', [userId])
            .then(() => {
              query('UPDATE user_avatar_frames SET is_active=1 WHERE user_id=? AND frame_id=?', [userId, decoration_id])
                .then(() => {
                  query('SELECT image_url FROM avatar_frames WHERE id=?', [decoration_id])
                    .then(([frame]) => {
                      const frameUrl = frame ? frame.image_url : ''
                      query('UPDATE users SET active_frame_id=?, active_frame_url=? WHERE id=?', [decoration_id, frameUrl, userId])
                    })
                  res.json({ code: 200, message: '设置成功' })
                })
            })
        })
        .catch(err => res.json({ code: 500, message: err.message }))
      return
    }

    if (type === 'title') {
      query('SELECT id FROM user_titles WHERE user_id=? AND title_id=?', [userId, decoration_id])
        .then(([row]) => {
          if (!row) return res.json({ code: 404, message: '未拥有此称号' })

          const checkExpire = () => {
            query('SELECT expire_time FROM user_titles WHERE user_id=? AND title_id=?', [userId, decoration_id])
              .then(([ut]) => {
                if (ut && ut.expire_time && new Date(ut.expire_time) < new Date()) {
                  query('UPDATE user_titles SET is_active=0 WHERE user_id=? AND title_id=?', [userId, decoration_id])
                  return res.json({ code: 400, message: '称号已过期' })
                }
                doActivate()
              })
          }

          const doActivate = () => {
            query('UPDATE user_titles SET is_active=0 WHERE user_id=?', [userId])
              .then(() => {
                query('UPDATE user_titles SET is_active=1 WHERE user_id=? AND title_id=?', [userId, decoration_id])
                  .then(() => {
                    query('SELECT name FROM custom_titles WHERE id=?', [decoration_id])
                      .then(([title]) => {
                        const titleName = title ? title.name : ''
                        query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [decoration_id, titleName, userId])
                      })
                    res.json({ code: 200, message: '设置成功' })
                  })
              })
          }

          checkExpire()
        })
        .catch(err => res.json({ code: 500, message: err.message }))
      return
    }

    query('SELECT id FROM user_decorations WHERE user_id=? AND decoration_id=?', [userId, decoration_id])
      .then(([row]) => {
        if (!row) return res.json({ code: 404, message: '未拥有此装饰品' })

        query('SELECT expire_time FROM user_decorations WHERE user_id=? AND decoration_id=?', [userId, decoration_id])
          .then(([ud]) => {
            if (ud && ud.expire_time && new Date(ud.expire_time) < new Date()) {
              query('UPDATE user_decorations SET is_active=0 WHERE user_id=? AND decoration_id=?', [userId, decoration_id])
              return res.json({ code: 400, message: '装饰品已过期' })
            }

            query('UPDATE user_decorations SET is_active=0 WHERE user_id=? AND decoration_type=?', [userId, type])
              .then(() => {
                query('UPDATE user_decorations SET is_active=1 WHERE user_id=? AND decoration_id=?', [userId, decoration_id])
                  .then(() => {
                    const fieldMap = {
                      avatar_effect: 'active_avatar_effect_id',
                      comment_background: 'active_comment_background_id',
                      nickname_effect: 'active_nickname_effect_id',
                      home_bg: 'active_home_bg_id'
                    }
                    const field = fieldMap[type]
                    const updates = []
                    if (field) {
                      updates.push(query(`UPDATE users SET ${field}=? WHERE id=?`, [decoration_id, userId]))
                    }
                    if (type === 'avatar_effect') {
                      updates.push(query('SELECT image_url FROM decorations WHERE id=?', [decoration_id]).then(([dec]) => {
                        const url = dec?.image_url || ''
                        return query('UPDATE users SET original_avatar=avatar, avatar=? WHERE id=?', [url, userId])
                      }))
                    }
                    Promise.all(updates).then(() => {
                      res.json({ code: 200, message: '设置成功' })
                    })
                  })
              })
          })
      })
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  app.post('/api/user/cancel-decoration', authRequired, (req, res) => {
    const userId = req.user.userId
    const { type } = req.body
    if (!type) return res.json({ code: 400, message: '缺少 type 参数' })

    if (type === 'avatar_frame') {
      query('UPDATE user_avatar_frames SET is_active=0 WHERE user_id=?', [userId])
        .then(() => query('UPDATE users SET active_frame_id=0, active_frame_url="" WHERE id=?', [userId]))
        .then(() => res.json({ code: 200, message: '已取消' }))
        .catch(err => res.json({ code: 500, message: err.message }))
      return
    }

    if (type === 'title') {
      query('UPDATE user_titles SET is_active=0 WHERE user_id=?', [userId])
        .then(() => query('UPDATE users SET active_title_id=0, active_title_name="" WHERE id=?', [userId]))
        .then(() => res.json({ code: 200, message: '已取消' }))
        .catch(err => res.json({ code: 500, message: err.message }))
      return
    }

    const fieldMap = {
      avatar_effect: 'active_avatar_effect_id',
      comment_background: 'active_comment_background_id',
      nickname_effect: 'active_nickname_effect_id',
      home_bg: 'active_home_bg_id'
    }
    const field = fieldMap[type]
    if (!field) return res.json({ code: 400, message: '无效的装饰类型' })

    query('UPDATE user_decorations SET is_active=0 WHERE user_id=? AND decoration_type=?', [userId, type])
      .then(() => {
        const updates = [query(`UPDATE users SET ${field}=0 WHERE id=?`, [userId])]
        if (type === 'avatar_effect') {
          updates.push(query('UPDATE users SET avatar=original_avatar, original_avatar="" WHERE id=? AND original_avatar!=""', [userId]))
        }
        return Promise.all(updates)
      })
      .then(() => res.json({ code: 200, message: '已取消' }))
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  // 返回全部装饰品+用户拥有状态（用于装饰品管理页浏览）
  app.get('/api/user/decorations-with-ownership', authRequired, (req, res) => {
    const userId = req.user.userId
    const type = req.query.type || ''
    const validTypes = ['avatar_effect', 'comment_background', 'nickname_effect', 'home_bg']
    if (!type || !validTypes.includes(type)) return res.json({ code: 400, message: '无效的类型' })

    const activeFieldMap = {
      avatar_effect: 'active_avatar_effect_id',
      comment_background: 'active_comment_background_id',
      nickname_effect: 'active_nickname_effect_id',
      home_bg: 'active_home_bg_id'
    }
    const activeField = activeFieldMap[type]

    Promise.all([
      query("SELECT * FROM decorations WHERE type=? AND status='1' ORDER BY sort_order ASC", [type]),
      query('SELECT decoration_id, obtain_type, expire_time, create_time FROM user_decorations WHERE user_id=? AND decoration_type=?', [userId, type]),
      query(`SELECT ${activeField} as active_id FROM users WHERE id=?`, [userId])
    ])
      .then(([allItems, userItems, [userRow]]) => {
        const userMap = {}
        const now = new Date()
        userItems.forEach(r => {
          if (r.expire_time && new Date(r.expire_time + ' UTC') < now) return
          userMap[r.decoration_id] = {
            obtainType: r.obtain_type,
            expireTime: r.expire_time,
            obtainTime: r.create_time
          }
        })
        const activeId = userRow?.active_id || 0

        const items = allItems.map(item => ({
          ...item,
          owned: !!userMap[item.id],
          obtainType: userMap[item.id]?.obtainType || null,
          expireTime: userMap[item.id]?.expireTime || null,
          obtainTime: userMap[item.id]?.obtainTime || null,
          isActive: item.id === activeId
        }))
        items.sort((a, b) => (b.owned ? 1 : 0) - (a.owned ? 1 : 0))

        res.json({ code: 200, data: { items, activeId } })
      })
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  app.get('/api/user/all-decorations', authRequired, (req, res) => {
    const userId = req.user.userId

    Promise.all([
      query(
        `SELECT af.*, uf.is_active FROM avatar_frames af
         INNER JOIN user_avatar_frames uf ON uf.frame_id = af.id AND uf.user_id = ?
         WHERE af.status = '1'`, [userId]
      ),
      query(
        `SELECT ct.*, ut.is_active FROM custom_titles ct
         INNER JOIN user_titles ut ON ut.title_id = ct.id AND ut.user_id = ?
         WHERE ct.status = '1'`, [userId]
      ),
      query(
        `SELECT d.*, ud.is_active FROM decorations d
         INNER JOIN user_decorations ud ON ud.decoration_id = d.id AND ud.user_id = ?
         WHERE d.type = 'avatar_effect' AND d.status = '1'`, [userId]
      ),
      query(
        `SELECT d.*, ud.is_active FROM decorations d
         INNER JOIN user_decorations ud ON ud.decoration_id = d.id AND ud.user_id = ?
         WHERE d.type = 'comment_background' AND d.status = '1'`, [userId]
      ),
      query(
        `SELECT d.*, ud.is_active FROM decorations d
         INNER JOIN user_decorations ud ON ud.decoration_id = d.id AND ud.user_id = ?
         WHERE d.type = 'nickname_effect' AND d.status = '1'`, [userId]
      )
    ])
      .then(([frames, titles, avatarEffects, commentBgs, nicknameEffects]) => {
        res.json({
          code: 200,
          data: {
            avatar_frame: frames,
            title: titles,
            avatar_effect: avatarEffects,
            comment_background: commentBgs,
            nickname_effect: nicknameEffects
          }
        })
      })
      .catch(err => res.json({ code: 500, message: err.message }))
  })

  // 装饰品赠送
  app.post('/api/user/transfer-decoration', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { decorationId, targetUserId } = req.body
      if (!decorationId || !targetUserId) return res.json({ code: 400, message: '缺少参数' })
      if (targetUserId === userId) return res.json({ code: 400, message: '不能赠送给自己' })

      const { query } = require('../database.cjs')
      const [rows] = await query(
        'SELECT id FROM user_decorations WHERE user_id=? AND decoration_id=?',
        [userId, decorationId]
      )
      if (!rows || !rows.length) {
        return res.json({ code: 404, message: '你未拥有该装饰品' })
      }

      const decRow = rows[0]
      await query(
        'UPDATE user_decorations SET user_id=?, obtain_type="transfer" WHERE id=?',
        [targetUserId, decRow.id]
      )

      res.json({ code: 200, msg: '赠送成功' })
    } catch (e) {
      res.json({ code: 500, message: e.message })
    }
  })
}

module.exports = { init }
