const { query, getSystemOperator } = require('../database.cjs')
const bcrypt = require('bcryptjs')
const { systemLog } = require('../middleware/security.cjs')
const sessions = require('./system.cjs').sessions
const { authRequired, requirePermission } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')
const { emitSafe, USER_EVENTS } = require('../plugins/events.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')

function getUserFromReq(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (token && sessions) {
    const session = sessions.get(token)
    if (session) return { userId: session.userId, userName: session.userName }
  }
  return { userId: 0, userName: 'anonymous' }
}

function adminRequired(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  if (!token || !sessions) return res.json({ code: 401, msg: '请先登录' })
  let session = sessions.get(token)
  if (!session) {
    query('SELECT * FROM sessions WHERE token=?', [token]).then(rows => {
      const row = rows && rows.length > 0 ? rows[0] : null
      if (!row) return res.json({ code: 401, msg: '登录已过期' })
      const roles = JSON.parse(row.roles || '[]')
      if (!roles.includes('R_SUPER') && !roles.includes('R_ADMIN'))
        return res.json({ code: 403, msg: '无权限访问' })
      session = { userId: row.user_id, userName: row.user_name, roles, createdAt: row.created_at }
      sessions.set(token, session)
      req.user = session
      next()
    }).catch(() => res.json({ code: 401, msg: '登录已过期' }))
    return
  }
  const roles = session.roles || []
  if (!roles.includes('R_SUPER') && !roles.includes('R_ADMIN')) {
    return res.json({ code: 403, msg: '无权限访问' })
  }
  req.user = session
  return next()
}

function userRoutes(router) {
  // POST /api/auth/register
  router.post('/api/auth/register', async (req, res) => {
    try {
      const { username, password, inviteCode, email, emailCode, phone, smsCode } = req.body

      // 读取注册配置
      const cfgRows = await query('SELECT config_key, config_value FROM sys_config WHERE config_key LIKE ?', ['register_%'])
      const cfg = {}
      for (const r of cfgRows) cfg[r.config_key] = r.config_value

      const registerEnabled = cfg.register_enabled !== 'false'
      if (!registerEnabled) return res.json({ code: 400, msg: '管理员已关闭注册功能' })

      const usernameMin = parseInt(cfg.register_username_min) || 3
      const passwordMin = parseInt(cfg.register_password_min) || 6
      const verifyType = cfg.register_verify_type || 'none'
      const defaultLevelId = parseInt(cfg.register_default_level) || 0
      const startId = parseInt(cfg.register_start_id) || 0

      if (!username || !password) return res.json({ code: 400, msg: '用户名和密码不能为空' })
      if (username.length < usernameMin || username.length > 20) return res.json({ code: 400, msg: '用户名长度需在' + usernameMin + '-20个字符之间' })
      if (password.length < passwordMin) return res.json({ code: 400, msg: '密码长度不能少于' + passwordMin + '个字符' })

      // 邮箱验证
      if (verifyType === 'email') {
        if (!email) return res.json({ code: 400, msg: '请输入邮箱地址' })
        if (!emailCode) return res.json({ code: 400, msg: '请输入邮箱验证码' })
        const vRow = await query('SELECT * FROM email_verifications WHERE email=? AND code=? AND type=? AND used=0 AND expires_at > NOW() ORDER BY create_time DESC LIMIT 1', [email, emailCode, 'register'])
        if (vRow.length === 0) return res.json({ code: 400, msg: '验证码无效或已过期' })
        await query('UPDATE email_verifications SET used=1 WHERE id=?', [vRow[0].id])
      }

      // 手机验证
      if (verifyType === 'mobile') {
        if (!phone) return res.json({ code: 400, msg: '请输入手机号' })
        if (!smsCode) return res.json({ code: 400, msg: '请输入短信验证码' })
        const vRow = await query('SELECT * FROM sms_verifications WHERE phone=? AND code=? AND type=? AND used=0 AND expires_at > NOW() ORDER BY create_time DESC LIMIT 1', [phone, smsCode, 'register'])
        if (vRow.length === 0) return res.json({ code: 400, msg: '验证码无效或已过期' })
        await query('UPDATE sms_verifications SET used=1 WHERE id=?', [vRow[0].id])
      }

      const existing = await query('SELECT id FROM users WHERE username=?', [username])
      if (existing && existing.length > 0) return res.json({ code: 400, msg: '用户名已存在' })

      const hash = bcrypt.hashSync(password, 10)

      const { eventBus } = require('../plugins/events.cjs')
      eventBus.emit(USER_EVENTS.BEFORE_REGISTER, { username, inviteCode })

      // 用户ID起始编号处理
      let insertSql = `INSERT INTO users (username, password, password_hash, status, points`
      let insertVals = [username, password, hash, '1', 0]
      
      if (startId > 0) {
        insertSql += `, id`
        insertVals.push(startId)
      }
      
      if (verifyType === 'email' && email) {
        insertSql += `, email`
        insertVals.push(email)
      }
      if (verifyType === 'mobile' && phone) {
        insertSql += `, phone`
        insertVals.push(phone)
      }
      
      insertSql += `) VALUES (` + Array(insertVals.length).fill('?').join(',') + `)`

      const result = await query(insertSql, insertVals)
      const userId = result.insertId

      // 应用默认会员等级
      if (defaultLevelId > 0) {
        const lv = await query('SELECT id, name FROM membership_levels WHERE id=? AND status=?', [defaultLevelId, '1'])
        if (lv && lv.length > 0) {
          await query('UPDATE users SET level_id=?, level_name=? WHERE id=?', [lv[0].id, lv[0].name, userId])
        }
      }

      await progressTasksByAction(userId, username, 'register')

      if (inviteCode) {
        try {
          const codes = await query('SELECT * FROM invite_codes WHERE code=? AND status=?', [inviteCode, '1'])
          if (!codes || codes.length === 0) {
            return res.json({ code: 400, msg: '邀请码不存在或已失效' })
          }
          const code = codes[0]
          if (code.max_uses > 0 && code.use_count >= code.max_uses) {
            return res.json({ code: 400, msg: '邀请码已被使用完' })
          } else if (code.expires_at && new Date(code.expires_at) < new Date()) {
            return res.json({ code: 400, msg: '邀请码已过期' })
          }
              await query('UPDATE invite_codes SET use_count=use_count+1 WHERE id=?', [code.id])
              if (code.max_uses > 0 && code.use_count + 1 >= code.max_uses) {
                await query("UPDATE invite_codes SET status='0', used_at=NOW() WHERE id=?", [code.id])
              }
              await query('UPDATE users SET referrer_id=?, referrer_code=? WHERE id=?',
                [code.created_by_user_id || code.created_by || 0, inviteCode, userId])

              // Process rewards if defined
              if (code.reward_type && code.reward_value) {
                const rewardTypes = String(code.reward_type).split(',')
                const rewardValues = String(code.reward_value).split(',')
                for (let i = 0; i < rewardTypes.length; i++) {
                  const rt = rewardTypes[i].trim()
                  const rv = parseInt(rewardValues[i]) || 0
                  if (rt === 'points') {
                    await query('UPDATE users SET points=points+? WHERE id=?', [rv, userId])
                    await query("INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT COALESCE(points,0) FROM users WHERE id=?),'邀请奖励','邀请码注册奖励')",
                      [userId, userId, rv, userId])
                  } else if (rt === 'balance') {
                    await query('UPDATE users SET balance=balance+? WHERE id=?', [rv, userId])
                    await query("INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT COALESCE(balance,0) FROM users WHERE id=?),'邀请奖励','邀请码注册奖励')",
                      [userId, userId, rv, userId])
                  } else if (rt === 'experience') {
                    await query('UPDATE users SET experience=experience+? WHERE id=?', [rv, userId])
                    await query("INSERT INTO experience_records (user_id, user_name, amount, source, description) VALUES (?,(SELECT username FROM users WHERE id=?),?,'邀请奖励','邀请码注册奖励')",
                      [userId, userId, rv])
                  } else if (rt === 'membership') {
                    const duration = parseInt(rewardValues[i + 1]) || 30
                    const lvId = rv
                    const lv = await query('SELECT id, name FROM membership_levels WHERE id=?', [lvId])
                    if (lv && lv.length > 0) {
                      const expDate = new Date(Date.now() + duration * 24 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)
                      await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
                        [lvId, lv[0].name, expDate, userId])
                      await query(
                        `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
                         VALUES (?, ?, ?, 0, 'cardkey', 'cardkey', ?, ?)`,
                        [userId, lvId, lv[0].name, duration, expDate]
                      )
                    }
                  }
                }
              }

              // Notify the code creator
              if (code.created_by_user_id && code.created_by_user_id > 0 && code.type !== 'admin') {
                const sysOpName = (await getSystemOperator())?.username || '管理员'
                await query(
                  "INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES (?,?,'invite',?, 0, ?, '')",
                  ['新用户注册', `用户 ${username} 使用您的邀请码注册成功`, code.created_by_user_id, sysOpName]
                )
              }
        } catch (ie) { /* ignore invite code errors */ }
      }

      systemLog('create', 0, username, 'user', userId, '用户注册')

      // 新用户注册邮件通知
      if (email) {
        sendNotificationEmail('user_register', email, {
          username: username,
          subject: '欢迎注册 Art Design Pro',
          content: `欢迎 ${username} 注册 Art Design Pro，您可以享受内容创作、资源交易等服务。`
        })
      }

      emitSafe(USER_EVENTS.REGISTERED, { userId, username, inviteCode })

      res.json({ code: 200, msg: '注册成功', data: { userId } })
    } catch (e) {
      console.error('注册失败:', e.message)
      res.json({ code: 500, msg: '注册失败: ' + e.message })
    }
  })

  // GET /api/user/list
  router.get('/api/user/membership-purchases/:userId', adminRequired, async (req, res) => {
    try {
      const rows = await query(
        `SELECT mp.id, mp.level_id as levelId, mp.level_name as levelName, mp.amount,
                mp.pay_type as payType, mp.purchase_type as purchaseType,
                mp.duration_days as durationDays, mp.expire_time as expireTime, mp.create_time as createTime
         FROM membership_purchases mp WHERE mp.user_id=? ORDER BY mp.expire_time DESC, mp.id DESC`,
        [Number(req.params.userId)]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/list
  router.get('/api/user/list', adminRequired, async (req, res) => {
    try {
      const { current = 1, size = 20, userName, userPhone, userEmail, qq, status, sortField, sortOrder } = req.query
      const page = parseInt(current) || 1
      const pageSize = parseInt(size) || 20
      const offset = (page - 1) * pageSize

      let where = ['1=1']
      let params = []
      if (userName) { where.push('username LIKE ?'); params.push(`%${userName}%`) }
      if (userPhone) { where.push('phone LIKE ?'); params.push(`%${userPhone}%`) }
      if (userEmail) { where.push('email LIKE ?'); params.push(`%${userEmail}%`) }
      if (qq) { where.push('qq LIKE ?'); params.push(`%${qq}%`) }
      if (status) { where.push('status = ?'); params.push(status) }

      const whereClause = where.join(' AND ')

      let totalRow
      const rows = await query(`SELECT COUNT(*) as total FROM users WHERE ${whereClause}`, params)
      totalRow = rows[0]
      const total = totalRow.total

      const allowedSorts = {
        id: 'id',
        points: 'points',
        balance: 'balance',
        experience: 'experience',
        createTime: 'create_time'
      }
      const orderField = allowedSorts[sortField] || 'id'
      const orderDir = sortOrder === 'asc' ? 'ASC' : 'DESC'

      const records = await query(
        `SELECT id, username as userName, phone as userPhone, email as userEmail,
                gender as userGender, avatar, status, points, level_id as level, level_name as levelName,
                expire_time as expireTime, roles as userRoles, nickname, bio, balance, experience,
                create_time as createTime, update_time as updateTime,
                signature, qq, bg_url as bgUrl, age, birthday, register_address as registerAddress,
                ban_until as banUntil, follow_count as followCount, fans_count as fansCount,
                used_bytes as usedBytes, bonus_data_limit_mb as bonusDataLimitMb, bonus_file_limit_mb as bonusFileLimitMb,
                (SELECT COUNT(*) FROM community_posts WHERE user_id = users.id AND deleted_at IS NULL) as postCount
         FROM users WHERE ${whereClause} ORDER BY ${orderField} ${orderDir} LIMIT ${pageSize} OFFSET ${offset}`,
        params
      )

      const list = records.map(r => {
        try { r.userRoles = typeof r.userRoles === 'string' ? JSON.parse(r.userRoles) : (r.userRoles || []) } catch { r.userRoles = [] }
        return r
      })

      res.json({ code: 200, msg: 'success', data: { records: list, current: page, size: pageSize, total } })
    } catch (e) {
      console.error('用户列表查询失败:', e.message)
      res.json({ code: 500, msg: '查询失败: ' + e.message })
    }
  })

  // POST /api/user/update
  router.post('/api/user/update', adminRequired, requirePermission('edit'), async (req, res) => {
    try {
      const { id, username, phone, gender, role, points, level_id, expireTime, password, nickname, bio, balance, email, experience, avatar, qq, signature, bg_url, register_address, age, birthday, ban_until, status, used_bytes, bonus_data_limit_mb, bonus_file_limit_mb } = req.body
      if (!id) return res.json({ code: 400, msg: '缺少用户ID' })

      const users = await query('SELECT * FROM users WHERE id = ?', [Number(id)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })

      const sets = []
      const params = []

      if (username) { sets.push('username = ?'); params.push(username) }
      if (phone) { sets.push('phone = ?'); params.push(phone) }
      if (gender) { sets.push('gender = ?'); params.push(gender) }
      if (role) { sets.push('roles = ?'); params.push(JSON.stringify(Array.isArray(role) ? role : [role])) }
      if (points !== undefined) { sets.push('points = ?'); params.push(Number(points)) }
      if (level_id !== undefined) {
        const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level_id)])
        const lv = lvs && lvs.length > 0 ? lvs[0] : null
        sets.push('level_id = ?'); params.push(Number(level_id))
        sets.push('level_name = ?'); params.push(lv ? lv.name : '普通会员')
      }
      if (expireTime !== undefined) {
        let exp = expireTime || null
        if (exp && typeof exp === 'string' && exp.includes('T')) {
          exp = exp.replace('T', ' ').replace(/\.\d{3}Z$/, '').replace(/Z$/, '')
        }
        sets.push('expire_time = ?'); params.push(exp)
      }
      if (password && password.trim()) {
        const hash = bcrypt.hashSync(password, 10)
        sets.push('password = ?'); params.push(password)
        sets.push('password_hash = ?'); params.push(hash)
      }
      if (nickname !== undefined) { sets.push('nickname = ?'); params.push(nickname) }
      if (bio !== undefined) { sets.push('bio = ?'); params.push(bio) }
      if (balance !== undefined) { sets.push('balance = ?'); params.push(Number(balance)) }
      if (email !== undefined) { sets.push('email = ?'); params.push(email) }
      if (experience !== undefined) {
        sets.push('experience = ?'); params.push(Number(experience))
        if (level_id === undefined) {
          const expLvs = await query(
            "SELECT id, name, level FROM experience_levels WHERE exp_required <= ? AND status='1' ORDER BY exp_required DESC LIMIT 1",
            [Number(experience)]
          )
          const expLv = expLvs && expLvs.length > 0 ? expLvs[0] : null
          if (expLv) {
            sets.push('level_id = ?'); params.push(Number(expLv.id))
            sets.push('level_name = ?'); params.push(expLv.name)
          }
        }
      }
      if (avatar !== undefined) { sets.push('avatar = ?'); params.push(avatar) }
      if (qq !== undefined) { sets.push('qq = ?'); params.push(qq) }
      if (signature !== undefined) { sets.push('signature = ?'); params.push(signature) }
      if (bg_url !== undefined) { sets.push('bg_url = ?'); params.push(bg_url) }
      if (register_address !== undefined) { sets.push('register_address = ?'); params.push(register_address) }
      if (age !== undefined) { sets.push('age = ?'); params.push(Number(age)) }
      if (birthday !== undefined) {
        sets.push('birthday = ?'); params.push(birthday || null)
      }
      if (ban_until !== undefined) {
        let ban = ban_until || null
        if (ban && typeof ban === 'string') {
          ban = ban.replace('T', ' ').replace(/\.\d{3}Z$/, '').replace(/Z$/, '')
        }
        sets.push('ban_until = ?'); params.push(ban)
      }
      if (status !== undefined) { sets.push('status = ?'); params.push(status) }
      if (used_bytes !== undefined) { sets.push('used_bytes = ?'); params.push(Number(used_bytes)) }
      if (bonus_data_limit_mb !== undefined) { sets.push('bonus_data_limit_mb = ?'); params.push(Number(bonus_data_limit_mb)) }
      if (bonus_file_limit_mb !== undefined) { sets.push('bonus_file_limit_mb = ?'); params.push(Number(bonus_file_limit_mb)) }

      // 处理会员购买记录
      const memberPurchases = req.body.member_purchases
      if (Array.isArray(memberPurchases) && memberPurchases.length > 0) {
        let bestLevelId = 0, bestLevelName = '', bestDuration = 0
        for (const mp of memberPurchases) {
          if (!mp.levelId || mp.levelId <= 0) continue
          const lvs = await query('SELECT id, name FROM membership_levels WHERE id=?', [mp.levelId])
          const lv = lvs?.[0]
          const durationDays = mp.durationDays || 0
          const expireTime = durationDays > 0
            ? new Date(Date.now() + durationDays * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            : null
          await query(
            `INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time)
             VALUES (?,?,?,?,?,?,?,?)`,
            [id, mp.levelId, lv?.name || '', mp.amount || 0, 'admin', 'admin_grant', durationDays, expireTime]
          )
          if (durationDays > bestDuration) {
            bestDuration = durationDays; bestLevelId = mp.levelId; bestLevelName = lv?.name || ''
          }
        }
        if (bestLevelId > 0) {
          sets.push('level_id = ?'); params.push(bestLevelId)
          sets.push('level_name = ?'); params.push(bestLevelName)
          if (bestDuration > 0) {
            const exp = new Date(Date.now() + bestDuration * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            sets.push('expire_time = ?'); params.push(exp)
          }
        }
      }

      if (sets.length === 0 && (!Array.isArray(memberPurchases) || memberPurchases.length === 0))
        return res.json({ code: 200, msg: '无更新字段', data: { success: true } })

      if (sets.length > 0) {
        const nowExpr = 'NOW()'
        sets.push(`update_time = ${nowExpr}`)
        params.push(Number(id))
        await query(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, params)

        const op = getUserFromReq(req)
        systemLog('update', op.userId, op.userName, 'user', Number(id), `更新用户信息`)

        emitSafe(USER_EVENTS.PROFILE_UPDATED, { userId: Number(id), fields: Object.keys(req.body).filter(k => k !== 'id') })

        // 禁封通知
        if (ban_until !== undefined) {
          const userEmail = await query('SELECT email, username FROM users WHERE id=?', [Number(id)])
          if (userEmail.length > 0 && userEmail[0].email) {
            const isBan = ban_until && (new Date(ban_until) > new Date())
            sendNotificationEmail('account_ban_user', userEmail[0].email, {
              username: userEmail[0].username,
              subject: isBan ? '账号已被禁封' : '账号已解封',
              content: isBan ? `您的账号已被禁封至 ${ban_until}，如有疑问请联系客服。` : '您的账号已解封，可以正常使用。'
            })
          }
        }
        // 手机号修改通知
        if (phone !== undefined) {
          const userEmail = await query('SELECT email FROM users WHERE id=?', [Number(id)])
          if (userEmail.length > 0 && userEmail[0].email) {
            sendNotificationEmail('phone_changed', userEmail[0].email, {
              username: '',
              subject: '手机号已修改',
              content: '您的绑定手机号已被修改。如非本人操作，请立即联系客服。'
            })
          }
        }
      }

      res.json({ code: 200, msg: '更新成功', data: { success: true } })
    } catch (e) {
      console.error('用户更新失败:', e.message)
      res.json({ code: 500, msg: '更新失败: ' + e.message })
    }
  })

  // POST /api/user/create
  router.post('/api/user/create', adminRequired, requirePermission('add'), async (req, res) => {
    try {
      const { username, phone, gender, role, points, level_id, expireTime, nickname, bio, balance, email, experience } = req.body
      if (!username) return res.json({ code: 400, msg: '缺少用户名' })

      const existing = await query('SELECT id FROM users WHERE username = ?', [username])
      if (existing && existing.length > 0) return res.json({ code: 400, msg: '用户名已存在' })

      let levelName = '普通会员'
      if (level_id !== undefined && level_id > 0) {
        const lvs = await query('SELECT id, name FROM membership_levels WHERE id = ?', [Number(level_id)])
        if (lvs && lvs.length > 0) levelName = lvs[0].name
      }

      let exp = expireTime || null
      if (exp && typeof exp === 'string' && exp.includes('T')) {
        exp = exp.replace('T', ' ').replace(/\.\d{3}Z$/, '').replace(/Z$/, '')
      }

      const result = await query(
        `INSERT INTO users (username, phone, gender, roles, points, level_id, level_name, expire_time, nickname, bio, balance, email, experience)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [username, phone || '', gender || '男',
         JSON.stringify(Array.isArray(role) ? role : []),
         points !== undefined ? Number(points) : 0,
         level_id !== undefined ? Number(level_id) : 0,
         levelName,
         exp,
         nickname || '',
         bio || '',
         balance !== undefined ? Number(balance) : 0,
         email || '',
         experience !== undefined ? Number(experience) : 0]
      )

      const newId = result.insertId
      const op = getUserFromReq(req)
      systemLog('create', op.userId, op.userName, 'user', newId, `新建用户"${username}"`)

      emitSafe(USER_EVENTS.CREATED, { userId: newId, username })

      res.json({ code: 200, msg: '添加成功', data: { id: newId } })
    } catch (e) {
      console.error('创建用户失败:', e.message)
      res.json({ code: 500, msg: '创建失败: ' + e.message })
    }
  })

  // DELETE /api/user/:id
  router.delete('/api/user/:id', adminRequired, requirePermission('delete'), async (req, res) => {
    try {
      const nowExpr = 'NOW()'
      const user = await query('SELECT username FROM users WHERE id=?', [Number(req.params.id)])
      const uname = user && user.length > 0 ? user[0].username : '未知'
      await query(`UPDATE users SET status = '4', update_time = ${nowExpr} WHERE id = ?`, [Number(req.params.id)])
      const op = getUserFromReq(req)
      systemLog('delete', op.userId, op.userName, 'user', Number(req.params.id), `注销用户"${uname}"`)
      emitSafe(USER_EVENTS.DELETED, { userId: Number(req.params.id), username: uname })
      res.json({ code: 200, msg: '注销成功', data: { success: true } })
    } catch (e) {
      console.error('注销用户失败:', e.message)
      res.json({ code: 500, msg: '操作失败: ' + e.message })
    }
  })

  // GET /api/user/profile — 获取用户个人信息
  router.get('/api/user/profile', async (req, res) => {
    try {
      const uid = Number(req.query.userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })

      const rows = await query(
        `SELECT id, username, nickname, avatar, bg_url as bgUrl, signature, bio, gender, phone, qq, email,
                balance, points, experience, level_id as levelId, level_name as levelName,
                show_coin as showCoin, follow_count as followCount, fans_count as fansCount,
                active_title_id as activeTitleId, active_title_name as activeTitleName,
                active_title_id2 as activeTitleId2, active_title_name2 as activeTitleName2,
                active_title_id3 as activeTitleId3, active_title_name3 as activeTitleName3,
                DATE_FORMAT(birthday, '%Y-%m-%d') as birthday,
                TIMESTAMPDIFF(YEAR, birthday, CURDATE()) as age,
                register_address as registerAddress,
                status, ban_until as banUntil,
                hide_birthday as hideBirthday, hide_qq as hideQq,
                hide_email as hideEmail, hide_address as hideAddress,
                create_time as createTime, roles
         FROM users WHERE id=?`, [uid]
      )
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      const u = rows[0]
      const expLvs = await query(
        "SELECT name, level, icon, icon_color as iconColor, text_color as textColor, bg_color as bgColor FROM experience_levels WHERE exp_required <= ? AND status='1' ORDER BY exp_required DESC LIMIT 1",
        [u.experience || 0]
      )
      u.expLevelName = expLvs && expLvs.length > 0 ? expLvs[0].name : 'Lv.1'
      u.expLevel = expLvs && expLvs.length > 0 ? expLvs[0].level : 1
      u.expIcon = expLvs && expLvs.length > 0 ? expLvs[0].icon : ''
      u.expIconColor = expLvs && expLvs.length > 0 ? expLvs[0].iconColor : '#00BFA5'
      u.expTextColor = expLvs && expLvs.length > 0 ? expLvs[0].textColor : '#FFFFFF'
      u.expBgColor = expLvs && expLvs.length > 0 ? expLvs[0].bgColor : '#508DFF'
      const activeTitles = []
      if (u.activeTitleId || u.activeTitleId2 || u.activeTitleId3) {
        const ids = [u.activeTitleId, u.activeTitleId2, u.activeTitleId3].filter(id => id > 0)
        if (ids.length > 0) {
          const titleRows = await query(`SELECT id, name, color, bg_color as bgColor, icon FROM custom_titles WHERE id IN (${ids.join(',')})`)
          if (titleRows && titleRows.length > 0) {
            for (const tr of titleRows) {
              if (tr.id === u.activeTitleId) activeTitles.push({ id: tr.id, name: tr.name, color: tr.color || '#409EFF', bgColor: tr.bgColor || '#ecf5ff', icon: tr.icon || '', slot: 1 })
              if (tr.id === u.activeTitleId2) activeTitles.push({ id: tr.id, name: tr.name, color: tr.color || '#409EFF', bgColor: tr.bgColor || '#ecf5ff', icon: tr.icon || '', slot: 2 })
              if (tr.id === u.activeTitleId3) activeTitles.push({ id: tr.id, name: tr.name, color: tr.color || '#409EFF', bgColor: tr.bgColor || '#ecf5ff', icon: tr.icon || '', slot: 3 })
            }
          }
        }
      }
      u.activeTitles = activeTitles
      const ownedTitleRows = await query(`SELECT ct.id, ct.name, ct.color, ct.bg_color as bgColor, ct.icon FROM custom_titles ct JOIN user_titles ut ON ct.id = ut.title_id WHERE ut.user_id = ? ORDER BY ut.grant_time`, [uid])
      u.ownedTitles = (ownedTitleRows || []).map(t => ({ id: t.id, name: t.name, color: t.color || '#409EFF', bgColor: t.bgColor || '#ecf5ff', icon: t.icon || '' }))
      try { u.roles = typeof u.roles === 'string' ? JSON.parse(u.roles) : (u.roles || []) } catch { u.roles = [] }
      res.json({ code: 200, msg: 'success', data: u })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // PUT /api/user/profile — 更新个人信息
  router.put('/api/user/profile', async (req, res) => {
    try {
      const uid = Number(req.body.userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })

      const { nickname, avatar, signature, bio, gender, phone, qq, email, bgUrl, birthday, hideBirthday, hideQq, hideEmail, hideAddress } = req.body
      const updates = []
      const params = []
      if (nickname !== undefined) { updates.push('nickname=?'); params.push(nickname) }
      if (avatar !== undefined) { updates.push('avatar=?'); params.push(avatar) }
      if (signature !== undefined) { updates.push('signature=?'); params.push(signature) }
      if (bio !== undefined) { updates.push('bio=?'); params.push(bio) }
      if (gender !== undefined) { updates.push('gender=?'); params.push(gender) }
      if (phone !== undefined) { updates.push('phone=?'); params.push(phone) }
      if (qq !== undefined) { updates.push('qq=?'); params.push(qq) }
      if (email !== undefined) { updates.push('email=?'); params.push(email) }
      if (bgUrl !== undefined) { updates.push('bg_url=?'); params.push(bgUrl) }
      if (birthday !== undefined) {
        const user = await query('SELECT birthday FROM users WHERE id=?', [uid])
        if (user.length && user[0].birthday) return res.json({ code: 400, msg: '生日已设置，不可修改' })
        updates.push('birthday=?'); params.push(birthday || null)
      }
      if (hideBirthday !== undefined) { updates.push('hide_birthday=?'); params.push(hideBirthday ? 1 : 0) }
      if (hideQq !== undefined) { updates.push('hide_qq=?'); params.push(hideQq ? 1 : 0) }
      if (hideEmail !== undefined) { updates.push('hide_email=?'); params.push(hideEmail ? 1 : 0) }
      if (hideAddress !== undefined) { updates.push('hide_address=?'); params.push(hideAddress ? 1 : 0) }

      if (updates.length === 0) return res.json({ code: 400, msg: '无更新内容' })

      const nowExpr = 'NOW()'
      updates.push(`update_time=${nowExpr}`)
      params.push(uid)
      await query(`UPDATE users SET ${updates.join(',')} WHERE id=?`, params)
      await progressTasksByAction(uid, '', 'profile')
      emitSafe(USER_EVENTS.PROFILE_UPDATED, { userId: uid, fields: Object.keys(req.body).filter(k => k !== 'userId') })
      res.json({ code: 200, msg: '更新成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/user/change-email — 修改邮箱（先验证当前邮箱身份）
  router.post('/api/user/change-email', async (req, res) => {
    try {
      const { userId, code, newEmail } = req.body
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      if (!code || !newEmail) return res.json({ code: 400, msg: '请填写验证码和新邮箱' })
      const user = await query('SELECT email FROM users WHERE id=?', [uid])
      if (!user.length) return res.json({ code: 404, msg: '用户不存在' })
      const currentEmail = user[0].email
      if (!currentEmail) return res.json({ code: 400, msg: '当前账号未绑定邮箱' })
      const vcode = await query("SELECT * FROM email_verifications WHERE email=? AND code=? AND type='change_email' AND used=0 AND expires_at > NOW() ORDER BY create_time DESC LIMIT 1", [currentEmail, code])
      if (vcode.length === 0) return res.json({ code: 400, msg: '验证码无效或已过期' })
      const exist = await query('SELECT id FROM users WHERE email=? AND id!=?', [newEmail, uid])
      if (exist.length) return res.json({ code: 400, msg: '该邮箱已被其他账号绑定' })
      await query("UPDATE email_verifications SET used=1 WHERE id=?", [vcode[0].id])
      await query('UPDATE users SET email=?, update_time=NOW() WHERE id=?', [newEmail, uid])
      res.json({ code: 200, msg: '邮箱修改成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/comments — 获取用户评论记录
  router.get('/api/user/comments', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 20 } = req.query
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      const offset = (Number(page) - 1) * Number(pageSize)
      const rows = await query(
        `SELECT c.id, c.app_id as appId, a.name as appName, c.content, c.likes, c.rating, c.create_time as createTime
         FROM app_comments c LEFT JOIN app_store a ON c.app_id=a.id
         WHERE c.user_id=? AND c.parent_id=0
         ORDER BY c.create_time DESC LIMIT ? OFFSET ?`,
        [uid, Number(pageSize), offset]
      )
      const [tc] = await query(
        `SELECT COUNT(*) as total FROM app_comments WHERE user_id=? AND parent_id=0`, [uid]
      )
      res.json({ code: 200, msg: 'success', data: { list: rows, total: tc?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/community-comments — 获取用户社区帖子评论
  router.get('/api/user/community-comments', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 20 } = req.query
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      // 拉黑过滤
      const { SESSION_TTL } = require('./system.cjs')
      const rawToken2 = req.headers.authorization || req.headers.token || req.query.token || ''
      const token2 = rawToken2.replace(/^Bearer\s+/i, '')
      let viewerId2 = 0
      if (token2) {
        const session = sessions.get(token2)
        if (session && Date.now() - session.createdAt <= SESSION_TTL) {
          viewerId2 = Number(session.userId) || 0
        } else {
          try {
            const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token2])
            if (rows.length > 0) {
              const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
              if (Date.now() - createdAt <= SESSION_TTL) viewerId2 = Number(rows[0].user_id) || 0
            }
          } catch {}
        }
      }
      if (viewerId2 > 0) {
        const blockRow2 = await query("SELECT id FROM user_blocks WHERE blocker_id=? AND blocked_id=? AND status='active'", [uid, viewerId2])
        if (blockRow2.length > 0) return res.json({ code: 200, msg: 'success', data: { list: [], total: 0 } })
      }
      const offset = (Number(page) - 1) * Number(pageSize)
      const rows = await query(
        `SELECT cc.id, cc.post_id as postId, p.title as postTitle, cc.content, cc.like_count as likes,
                cc.create_time as createTime
         FROM community_comments cc LEFT JOIN community_posts p ON cc.post_id=p.id
         WHERE cc.user_id=? AND cc.parent_id=0
         ORDER BY cc.create_time DESC LIMIT ? OFFSET ?`,
        [uid, Number(pageSize), offset]
      )
      const [tc] = await query(
        `SELECT COUNT(*) as total FROM community_comments WHERE user_id=? AND parent_id=0`, [uid]
      )
      res.json({ code: 200, msg: 'success', data: { list: rows, total: tc?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // POST /api/auth/change-pwd — 修改密码
  router.post('/api/auth/change-pwd', async (req, res) => {
    try {
      const { userId, oldPwd, newPwd } = req.body
      const users = await query('SELECT id, password, password_hash FROM users WHERE id=?', [Number(userId)])
      if (!users || users.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      const user = users[0]
      const passwordMatch = user.password_hash
        ? bcrypt.compareSync(oldPwd, user.password_hash)
        : (user.password === oldPwd)
      if (!passwordMatch) return res.json({ code: 400, msg: '原密码错误' })
      const hash = bcrypt.hashSync(newPwd, 10)
      await query('UPDATE users SET password=?, password_hash=? WHERE id=?', [newPwd, hash, Number(userId)])
      emitSafe(USER_EVENTS.PASSWORD_CHANGED, { userId: Number(userId) })
      res.json({ code: 200, msg: '密码修改成功', data: {} })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/user/apps — 获取用户发布的应用
  router.get('/api/user/apps', async (req, res) => {
    try {
      const uid = Number(req.query.userId) || 0
      // 拉黑过滤：如果当前用户被此用户拉黑，则不返回内容
      const { SESSION_TTL } = require('./system.cjs')
      const rawToken = req.headers.authorization || req.headers.token || req.query.token || ''
      const token = rawToken.replace(/^Bearer\s+/i, '')
      let viewerId = 0
      if (token) {
        const session = sessions.get(token)
        if (session && Date.now() - session.createdAt <= SESSION_TTL) {
          viewerId = Number(session.userId) || 0
        } else {
          try {
            const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
            if (rows.length > 0) {
              const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
              if (Date.now() - createdAt <= SESSION_TTL) viewerId = Number(rows[0].user_id) || 0
            }
          } catch {}
        }
      }
      if (viewerId > 0) {
        const blockRow = await query("SELECT id FROM user_blocks WHERE blocker_id=? AND blocked_id=? AND status='active'", [uid, viewerId])
        if (blockRow.length > 0) return res.json({ code: 200, msg: 'success', data: { list: [] } })
      }
      const rows = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, category, downloads, rating,
                coin_count as coinCount, coin_people as coinPeople, developer, create_time as createTime
         FROM app_store WHERE user_id=? OR developer=(SELECT username FROM users WHERE id=?)
         ORDER BY create_time DESC`,
        [uid, uid]
      )
      res.json({ code: 200, msg: 'success', data: { list: rows } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
  // POST /api/user/delete-request — 用户申请注销账号
  router.post('/api/user/delete-request', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      const [existing] = await query('SELECT id FROM user_delete_requests WHERE user_id=? AND status="pending"', [uid])
      if (existing) return res.json({ code: 400, msg: '已有待审核的注销申请' })
      await query('INSERT INTO user_delete_requests (user_id, username) VALUES (?, (SELECT username FROM users WHERE id=?))', [uid, uid])
      emitSafe(USER_EVENTS.DELETE_REQUESTED, { userId: uid })
      res.json({ code: 200, msg: '注销申请已提交，等待管理员审核' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/delete-requests — 管理员查看注销审核列表
  router.get('/api/user/delete-requests', async (req, res) => {
    try {
      const { status } = req.query
      let sql = 'SELECT * FROM user_delete_requests WHERE 1=1'
      const params = []
      if (status) { sql += ' AND status=?'; params.push(status) }
      sql += ' ORDER BY create_time DESC'
      const rows = await query(sql, params)
      res.json({ code: 200, msg: 'success', data: rows })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/delete-request/:id/review — 管理员审核注销申请
  router.post('/api/user/delete-request/:id/review', async (req, res) => {
    try {
      const { status: reqStatus, adminNote, adminId } = req.body
      const id = Number(req.params.id)
      const [r] = await query('SELECT * FROM user_delete_requests WHERE id=?', [id])
      if (!r) return res.json({ code: 404, msg: '申请不存在' })
      const approved = reqStatus === 'approved'
      const newStatus = approved ? 'approved' : 'rejected'
      await query('UPDATE user_delete_requests SET status=?, admin_id=?, admin_note=? WHERE id=?',
        [newStatus, Number(adminId) || 0, adminNote || '', id])
      if (approved) {
        await query('UPDATE users SET status="4" WHERE id=?', [r.user_id])
      }
      res.json({ code: 200, msg: approved ? '已通过注销' : '已拒绝注销' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ========== 账号申诉 ==========

  // POST /api/user/appeal — 被封禁用户提交申诉
  router.post('/api/user/appeal', async (req, res) => {
    try {
      const { userId, reason } = req.body
      const uid = Number(userId) || 0
      if (!uid) return res.json({ code: 400, msg: '缺少userId' })
      if (!reason || !reason.trim()) return res.json({ code: 400, msg: '请填写申诉理由' })

      // 检查用户是否真的被封禁
      const [user] = await query('SELECT username, ban_until FROM users WHERE id=?', [uid])
      if (!user) return res.json({ code: 404, msg: '用户不存在' })
      if (!user.ban_until || new Date(user.ban_until) <= new Date()) {
        return res.json({ code: 400, msg: '该账号未被封禁，无需申诉' })
      }

      // 检查是否已有待处理的申诉
      const [existing] = await query('SELECT id FROM user_appeals WHERE user_id=? AND status="pending"', [uid])
      if (existing) return res.json({ code: 400, msg: '已有待审核的申诉申请' })

      await query('INSERT INTO user_appeals (user_id, username, reason, ban_until) VALUES (?, ?, ?, ?)',
        [uid, user.username, reason.trim(), user.ban_until])

      // 通知管理员
      const adminEmails = await getAdminEmails()
      for (const adminEmail of adminEmails) {
        sendNotificationEmail('account_appeal', adminEmail, {
          username: '管理员',
          subject: '新的账号申诉',
          content: `用户 ${user.username}（ID:${uid}）提交了账号申诉。申诉理由：${reason.trim()}。封禁截止时间：${user.ban_until || '永久封禁'}。请及时处理。`
        })
      }

      // 站内通知管理员
      try {
        const admins = await query("SELECT id FROM users WHERE roles LIKE '%R_SUPER%' OR roles LIKE '%R_ADMIN%'")
        const sysOp = (await getSystemOperator())?.username || '管理员'
        for (const admin of admins) {
          await query(
            `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES ('新的账号申诉', ?, 'system', ?, 0, ?, '')`,
            [`用户 ${user.username} 提交了账号申诉，申诉理由：${reason.trim()}`, admin.id, sysOp]
          )
        }
      } catch {}

      res.json({ code: 200, msg: '申诉已提交，等待管理员审核' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/appeals — 管理员查看申诉列表
  router.get('/api/user/appeals', async (req, res) => {
    try {
      const { status: reqStatus, page = 1, pageSize = 20 } = req.query
      let sql = `SELECT a.*, a.ban_until as banUntil FROM user_appeals a WHERE 1=1`
      const params = []
      if (reqStatus) { sql += ' AND a.status=?'; params.push(reqStatus) }
      sql += ' ORDER BY a.create_time DESC'
      const rows = await query(sql, params)
      const total = rows.length
      res.json({ code: 200, msg: 'success', data: { list: rows, total } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/appeal/:id/review — 管理员审核申诉
  router.post('/api/user/appeal/:id/review', async (req, res) => {
    try {
      const { status: reqStatus, adminNote, adminId } = req.body
      const id = Number(req.params.id)
      const [r] = await query('SELECT * FROM user_appeals WHERE id=?', [id])
      if (!r) return res.json({ code: 404, msg: '申诉不存在' })
      if (r.status !== 'pending') return res.json({ code: 400, msg: '该申诉已处理' })

      const approved = reqStatus === 'approved'
      const newStatus = approved ? 'approved' : 'rejected'
      const now = new Date().toISOString().replace('T', ' ').substring(0, 19)

      await query('UPDATE user_appeals SET status=?, admin_id=?, admin_note=?, review_time=? WHERE id=?',
        [newStatus, Number(adminId) || 0, adminNote || '', now, id])

      // 通过申诉: 解封用户
      if (approved) {
        await query('UPDATE users SET ban_until=NULL WHERE id=?', [r.user_id])

        // 通知用户
        const [targetUser] = await query('SELECT username, email FROM users WHERE id=?', [r.user_id])
        if (targetUser && targetUser.email) {
          sendNotificationEmail('account_ban_user', targetUser.email, {
            username: targetUser.username || '',
            subject: '账号解封通知',
            content: '管理员已通过您的申诉，账号已解除封禁，可以正常使用。'
          })
        }
      } else {
        // 拒绝时也通知用户
        try {
          const [targetUser] = await query('SELECT username, email FROM users WHERE id=?', [r.user_id])
          if (targetUser && targetUser.email) {
            sendNotificationEmail('account_ban_user', targetUser.email, {
              username: targetUser.username || '',
              subject: '申诉未通过',
              content: `管理员拒绝了您的申诉申请${adminNote ? '，原因：' + adminNote : ''}。`
            })
          }
        } catch {}
      }

      res.json({ code: 200, msg: '操作成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/balance-records — 余额流水
  router.get('/api/user/balance-records', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 20 } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const offset = (Number(page) - 1) * Number(pageSize)
      const list = await query(
        'SELECT * FROM balance_records WHERE user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
        [Number(userId), Number(pageSize), offset]
      )
      const total = await query('SELECT COUNT(*) as cnt FROM balance_records WHERE user_id=?', [Number(userId)])
      res.json({ code: 200, data: { list, total: total[0]?.cnt || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/experience-records — 经验流水
  router.get('/api/user/experience-records', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 100 } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const offset = (Number(page) - 1) * Number(pageSize)
      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, amount, source, description, create_time, 'earn' as type
         FROM experience_records WHERE user_id=?
         UNION ALL
         SELECT id, user_id as userId, user_name as userName, experience_earned as amount,
                '签到奖励' as source, '' as description, checkin_date as create_time, 'earn' as type
         FROM checkin_records WHERE user_id=? AND experience_earned > 0
         ORDER BY create_time DESC LIMIT ? OFFSET ?`,
        [Number(userId), Number(userId), Number(pageSize), offset]
      )
      const total = await query(
        `SELECT COUNT(*) as cnt FROM (
          SELECT 1 FROM experience_records WHERE user_id=?
          UNION ALL
          SELECT 1 FROM checkin_records WHERE user_id=? AND experience_earned > 0
        ) AS t`,
        [Number(userId), Number(userId)]
      )
      res.json({ code: 200, data: { list, total: total[0]?.cnt || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/membership-records — 会员购买记录
  router.get('/api/user/membership-records', async (req, res) => {
    try {
      const { userId, page = 1, pageSize = 100 } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })
      const offset = (Number(page) - 1) * Number(pageSize)
      const list = await query(
        `SELECT mp.*, mp2.name as product_name
         FROM membership_purchases mp
         LEFT JOIN membership_products mp2 ON mp.product_id=mp2.id
         WHERE mp.user_id=?
         ORDER BY mp.create_time DESC LIMIT ? OFFSET ?`,
        [Number(userId), Number(pageSize), offset]
      )
      const total = await query('SELECT COUNT(*) as cnt FROM membership_purchases WHERE user_id=?', [Number(userId)])
      res.json({ code: 200, data: { list, total: total[0]?.cnt || 0 } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ---------- 2FA ----------

  // GET /api/user/2fa/status
  router.get('/api/user/2fa/status', authRequired, async (req, res) => {
    try {
      const rows = await query('SELECT twofa_enabled, twofa_secret FROM users WHERE id=?', [req.user.userId])
      const u = rows[0] || {}
      res.json({ code: 200, data: { enabled: !!u.twofa_enabled } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/2fa/setup
  router.post('/api/user/2fa/setup', authRequired, async (req, res) => {
    try {
      const speakeasy = require('speakeasy')
      const QRCode = require('qrcode')
      const username = req.user.userName || 'user'
      const secret = speakeasy.generateSecret({
        name: `ArtDesignPro:${username}`,
        length: 20
      })
      const otpauthUrl = speakeasy.otpauthURL({
        secret: secret.base32,
        label: `ArtDesignPro:${username}`,
        issuer: 'ArtDesignPro'
      })
      const qrCodeSvg = await QRCode.toString(otpauthUrl, { type: 'svg' })
      await query('UPDATE users SET twofa_secret=? WHERE id=?', [secret.base32, req.user.userId])
      res.json({ code: 200, data: { secret: secret.base32, qrCode: qrCodeSvg, method: 'totp' } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/2fa/verify
  router.post('/api/user/2fa/verify', authRequired, async (req, res) => {
    try {
      const { token } = req.body
      if (!token) return res.json({ code: 400, msg: '请输入验证码' })
      if (!/^\d{6}$/.test(token)) return res.json({ code: 400, msg: '验证码格式错误' })
      const rows = await query('SELECT twofa_secret FROM users WHERE id=?', [req.user.userId])
      if (!rows.length || !rows[0].twofa_secret) return res.json({ code: 400, msg: '请先设置2FA' })
      const speakeasy = require('speakeasy')
      const verified = speakeasy.totp.verify({
        secret: rows[0].twofa_secret,
        encoding: 'base32',
        token: token
      })
      if (!verified) return res.json({ code: 400, msg: '验证码无效' })
      await query('UPDATE users SET twofa_enabled=1 WHERE id=?', [req.user.userId])
      res.json({ code: 200, msg: '2FA已启用' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // POST /api/user/2fa/disable
  router.post('/api/user/2fa/disable', authRequired, async (req, res) => {
    try {
      const { token } = req.body
      if (!token) return res.json({ code: 400, msg: '请输入验证码' })
      if (!/^\d{6}$/.test(token)) return res.json({ code: 400, msg: '验证码格式错误' })
      const rows = await query('SELECT twofa_enabled, twofa_secret FROM users WHERE id=?', [req.user.userId])
      if (!rows.length || !rows[0].twofa_enabled) return res.json({ code: 400, msg: '2FA未启用' })
      const speakeasy = require('speakeasy')
      const verified = speakeasy.totp.verify({
        secret: rows[0].twofa_secret,
        encoding: 'base32',
        token: token
      })
      if (!verified) return res.json({ code: 400, msg: '验证码无效' })
      await query('UPDATE users SET twofa_enabled=0, twofa_secret=NULL WHERE id=?', [req.user.userId])
      res.json({ code: 200, msg: '2FA已禁用' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ---------- 用户仪表盘统计 ----------

  // GET /api/user/dashboard/stats
  router.get('/api/user/dashboard/stats', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const today = new Date()
      const thirtyDaysAgo = new Date(today)
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29)

      // 最近30天每日发帖数
      const postsByDay = await query(
        `SELECT DATE(create_time) as date, COUNT(*) as count
         FROM community_posts WHERE user_id=? AND create_time >= ?
         GROUP BY DATE(create_time) ORDER BY date`,
        [userId, thirtyDaysAgo.toISOString().slice(0, 10)]
      )

      // 最近30天每日获赞数
      const likesByDay = await query(
        `SELECT DATE(cl.create_time) as date, COUNT(*) as count
         FROM community_likes cl
         INNER JOIN community_posts cp ON cl.post_id=cp.id AND cp.user_id=?
         WHERE cl.create_time >= ?
         GROUP BY DATE(cl.create_time) ORDER BY date`,
        [userId, thirtyDaysAgo.toISOString().slice(0, 10)]
      )

      // 总计统计
      const [totalPosts, totalFavorites, totalCoins, userData] = await Promise.all([
        query("SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=? AND status IN ('published','reviewed')", [userId]),
        query('SELECT COUNT(*) as cnt FROM community_favorites WHERE user_id=?', [userId]),
        query('SELECT COALESCE(SUM(amount),0) as total FROM balance_records WHERE user_id=? AND type=?', [userId, 'earn']),
        query('SELECT experience FROM users WHERE id=?', [userId])
      ])

      const experience = Number(userData[0]?.experience || 0)
      const expLevels = await query("SELECT level, exp_required, name FROM experience_levels WHERE status='1' ORDER BY exp_required ASC")
      let currentLevel = 1; let nextLevelExp = 0
      for (const lv of expLevels) {
        if (experience >= lv.exp_required) currentLevel = Math.max(currentLevel, lv.level)
        if (!nextLevelExp && lv.exp_required > experience) nextLevelExp = lv.exp_required
      }

      // 填充每日数据（补齐30天缺失日期）
      const postMap = {}; postsByDay.forEach(r => { postMap[r.date] = r.count })
      const likeMap = {}; likesByDay.forEach(r => { likeMap[r.date] = r.count })
      const filledPosts = []; const filledLikes = []
      for (let i = 0; i < 30; i++) {
        const d = new Date(today); d.setDate(d.getDate() - 29 + i)
        const ds = d.toISOString().slice(0, 10)
        filledPosts.push({ date: ds, count: postMap[ds] || 0 })
        filledLikes.push({ date: ds, count: likeMap[ds] || 0 })
      }

      res.json({
        code: 200,
        data: {
          postsByDay: filledPosts,
          likesReceived: filledLikes,
          totalPosts: totalPosts[0]?.cnt || 0,
          totalLikes: 0,
          totalFavorites: totalFavorites[0]?.cnt || 0,
          totalCoins: Number(totalCoins[0]?.total || 0),
          currentLevel,
          nextLevelExp
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ---------- 隐私设置 ----------

  // GET /api/user/privacy-settings
  router.get('/api/user/privacy-settings', authRequired, async (req, res) => {
    try {
      const rows = await query('SELECT hide_birthday, hide_qq, hide_email, hide_address FROM users WHERE id=?', [req.user.userId])
      const u = rows[0] || {}
      res.json({
        code: 200,
        data: {
          hideBirthday: !!u.hide_birthday,
          hideQq: !!u.hide_qq,
          hideEmail: !!u.hide_email,
          hideAddress: !!u.hide_address
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // PUT /api/user/privacy-settings
  router.put('/api/user/privacy-settings', authRequired, async (req, res) => {
    try {
      const { hideBirthday, hideQq, hideEmail, hideAddress } = req.body
      await query('UPDATE users SET hide_birthday=?, hide_qq=?, hide_email=?, hide_address=? WHERE id=?',
        [hideBirthday ? 1 : 0, hideQq ? 1 : 0, hideEmail ? 1 : 0, hideAddress ? 1 : 0, req.user.userId])
      res.json({ code: 200, msg: '隐私设置已更新' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // GET /api/user/:id - get user by ID (public, limited fields, must be last)
  router.get('/api/user/:id', async (req, res, next) => {
    try {
      const id = parseInt(req.params.id)
      if (!id || id <= 0) return next()
      const rows = await query('SELECT id, username, nickname, avatar FROM users WHERE id=?', [id])
      if (!rows || rows.length === 0) return res.json({ code: 404, msg: '用户不存在' })
      res.json(rows[0])
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = userRoutes
