const { query } = require('../database.cjs')
const { getSysConfig } = require('../utils/sys-config-cache.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')

function cookieConsentRoutes(app) {
  app.get('/api/cookie-consent/config', async (req, res) => {
    try {
      const enabled = await getSysConfig('cookie_consent_enabled')
      const title = await getSysConfig('cookie_consent_title')
      const content = await getSysConfig('cookie_consent_content')
      const agreeText = await getSysConfig('cookie_consent_agree_text')
      const declineText = await getSysConfig('cookie_consent_decline_text')
      const categories = await getSysConfig('cookie_consent_categories')
      let cats = []
      try { cats = JSON.parse(categories || '[]') } catch {}
      res.json({
        code: 200,
        data: {
          enabled: enabled !== 'false' && enabled !== '0',
          title: title || 'Cookie 声明',
          content: content || '本站使用 Cookie 来改善您的浏览体验、分析网站流量并提供个性化内容。继续使用本站即表示您同意我们使用 Cookie。',
          agreeText: agreeText || '同意全部',
          declineText: declineText || '仅必要',
          categories: cats.length > 0 ? cats : [
            { key: 'necessary', label: '必要 Cookie', description: '网站正常运行所需，无法关闭', required: true },
            { key: 'analytics', label: '分析 Cookie', description: '帮助我们了解访问者如何使用网站', required: false },
            { key: 'marketing', label: '营销 Cookie', description: '用于广告投放和个性化推荐', required: false }
          ]
        }
      })
    } catch (e) {
      console.error('[cookie-consent config]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })

  app.post('/api/cookie-consent/accept', async (req, res) => {
    try {
      const { categories } = req.body
      const userId = req.userId || 0
      const sessionId = req.cookies?.connect_sid || req.headers['x-session-id'] || ''
      const ip = req.ip || req.connection?.remoteAddress || ''
      const acceptedCategories = Array.isArray(categories) ? categories : ['necessary']
      await query(
        'INSERT INTO cookie_consents (user_id, session_id, ip, accepted_categories) VALUES (?,?,?,?)',
        [userId, sessionId, ip, JSON.stringify(acceptedCategories)]
      )
      res.cookie('cookie_consent', '1', { maxAge: 365 * 24 * 60 * 60 * 1000, httpOnly: false, sameSite: 'lax' })
      res.json({ code: 200, msg: '已记录' })
    } catch (e) {
      console.error('[cookie-consent accept]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })

  app.get('/api/cookie-consent/status', async (req, res) => {
    try {
      const sessionId = req.cookies?.connect_sid || req.headers['x-session-id'] || ''
      const hasCookie = req.cookies?.cookie_consent === '1'
      let hasRecord = false
      if (sessionId) {
        const rows = await query('SELECT id FROM cookie_consents WHERE session_id=? ORDER BY accepted_at DESC LIMIT 1', [sessionId])
        hasRecord = rows.length > 0
      }
      res.json({ code: 200, data: { consented: hasCookie || hasRecord } })
    } catch (e) {
      res.json({ code: 200, data: { consented: false } })
    }
  })

  app.get('/api/admin/cookie-consent/stats', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const total = await query('SELECT COUNT(*) AS cnt FROM cookie_consents')
      const today = await query("SELECT COUNT(*) AS cnt FROM cookie_consents WHERE DATE(accepted_at)=CURDATE()")
      const byCategory = await query(
        "SELECT accepted_categories, COUNT(*) AS cnt FROM cookie_consents GROUP BY accepted_categories ORDER BY cnt DESC LIMIT 20"
      )
      res.json({
        code: 200,
        data: {
          total: total[0].cnt,
          today: today[0].cnt,
          byCategory: byCategory.map(r => {
            let cats = []
            try { cats = JSON.parse(r.accepted_categories) } catch {}
            return { categories: cats, count: r.cnt }
          })
        }
      })
    } catch (e) {
      console.error('[cookie-consent stats]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })
}

module.exports = cookieConsentRoutes
