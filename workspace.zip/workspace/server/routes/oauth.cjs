const { query } = require('../database.cjs')
const crypto = require('crypto')
const https = require('https')
const { sessions, saveSession } = require('./system.cjs')
const { getSysConfig, invalidateSysConfig } = require('../utils/sys-config-cache.cjs')

function generateToken() {
  return crypto.randomBytes(32).toString('hex')
}

async function getOAuthConfig(provider) {
  try {
    const val = await getSysConfig(`oauth_${provider}_config`)
    if (val) {
      try { return JSON.parse(val) } catch { return null }
    }
    return null
  } catch { return null }
}

async function setOAuthConfig(provider, config) {
  await query(
    "INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?) ON DUPLICATE KEY UPDATE config_value=?",
    [`oauth_${provider}_config`, JSON.stringify(config), `${provider} OAuth 配置`, JSON.stringify(config)]
  )
  invalidateSysConfig()
}

async function getEnabledProviders() {
  const { getSysConfigRows } = require('../utils/sys-config-cache.cjs')
  const rows = await getSysConfigRows()
  const providers = []
  for (const row of rows) {
    if (row.config_key && row.config_key.startsWith('oauth_') && row.config_key.endsWith('_config')) {
      try {
        const cfg = JSON.parse(row.config_value)
        if (cfg && cfg.enabled) {
          providers.push({ provider: row.config_key.replace(/^oauth_/, '').replace(/_config$/, ''), ...cfg })
        }
      } catch {}
    }
  }
  return providers
}
async function findOrCreateOAuthUser(provider, providerUserId, userInfo) {
  let rows = await query(
    'SELECT user_id FROM oauth_accounts WHERE provider=? AND provider_user_id=?',
    [provider, providerUserId]
  )
  if (rows.length > 0) {
    const uid = rows[0].user_id
    const userRows = await query('SELECT id, username, roles, status FROM users WHERE id=?', [uid])
    if (userRows.length > 0) return userRows[0]
  }

  let username = (userInfo.name || userInfo.login || `${provider}_${providerUserId}`).replace(/[^a-zA-Z0-9_\u4e00-\u9fff]/g, '')
  if (!username || username.length < 2) username = `${provider}_user_${Date.now()}`

  const existing = await query('SELECT id FROM users WHERE username=?', [username])
  if (existing.length > 0) username = username + '_' + Date.now().toString(36)

  const defaultPassword = crypto.randomBytes(16).toString('hex')
  const bcrypt = require('bcryptjs')
  const hashedPassword = await bcrypt.hash(defaultPassword, 10)

  const avatar = userInfo.avatar_url || userInfo.picture || userInfo.headimgurl || ''

  const result = await query(
    'INSERT INTO users (username, password, nickname, avatar, roles, status, email) VALUES (?,?,?,?,?,?,?)',
    [username, hashedPassword, userInfo.name || userInfo.login || username, avatar, JSON.stringify(['R_USER']), '1', userInfo.email || '']
  )

  const userId = result.insertId

  // Initialize trust level
  try {
    await query(
      'INSERT IGNORE INTO community_trust_levels (user_id, level, post_count, comment_count, like_received, report_count, ban_count, score) VALUES (?, 0, 0, 0, 0, 0, 0, 0)',
      [userId]
    )
  } catch (e) { console.error('[oauth] trust level init failed:', userId, e.message) }

  await query(
    'INSERT INTO oauth_accounts (user_id, provider, provider_user_id, access_token, provider_data) VALUES (?,?,?,?,?)',
    [userId, provider, providerUserId, '', JSON.stringify(userInfo)]
  )

  return query('SELECT id, username, roles, status FROM users WHERE id=?', [userId]).then(r => r[0])
}

function fetchJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url)
    const req = https.request({
      hostname: u.hostname,
      path: u.pathname + u.search,
      method: options.method || 'GET',
      headers: {
        'User-Agent': 'ArtDesignPro/1.0',
        'Accept': 'application/json',
        ...options.headers
      }
    }, (res) => {
      let body = ''
      res.on('data', chunk => body += chunk)
      res.on('end', () => {
        try { resolve(JSON.parse(body)) } catch { reject(new Error('Invalid JSON response')) }
      })
    })
    req.on('error', reject)
    if (options.body) req.write(options.body)
    req.end()
  })
}

function oauthRoutes(app) {
  // Get enabled providers
  app.get('/api/oauth/providers', async (_req, res) => {
    try {
      const providers = await getEnabledProviders()
      res.json({ code: 200, data: providers })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GitHub OAuth login redirect
  app.get('/api/oauth/github/login', async (_req, res) => {
    try {
      const config = await getOAuthConfig('github')
      if (!config || !config.enabled) return res.json({ code: 400, msg: 'GitHub登录未配置' })
      const state = generateToken()
      const redirectUri = encodeURIComponent(config.redirectUri)
      const url = `https://github.com/login/oauth/authorize?client_id=${config.clientId}&redirect_uri=${redirectUri}&scope=user:email&state=${state}`
      res.redirect(url)
    } catch (e) {
      res.serverError(e)
    }
  })

  // GitHub OAuth callback
  app.get('/api/oauth/github/callback', async (req, res) => {
    try {
      const { code } = req.query
      if (!code) return res.json({ code: 400, msg: '缺少授权码' })

      const config = await getOAuthConfig('github')
      if (!config || !config.enabled) return res.json({ code: 400, msg: 'GitHub登录未配置' })

      // Get access token
      const tokenRes = await fetchJson('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          code,
          redirect_uri: config.redirectUri
        })
      })

      if (!tokenRes.access_token) return res.json({ code: 400, msg: '获取访问令牌失败' })

      // Get user info
      const userInfo = await fetchJson('https://api.github.com/user', {
        headers: { 'Authorization': `Bearer ${tokenRes.access_token}`, 'User-Agent': 'ArtDesignPro' }
      })

      const user = await findOrCreateOAuthUser('github', String(userInfo.id), {
        name: userInfo.name,
        login: userInfo.login,
        avatar_url: userInfo.avatar_url,
        email: userInfo.email
      })

      if (user.status !== '1') return res.json({ code: 403, msg: '账号已被禁用' })

       const token = generateToken()
       const roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || [])
       const refreshToken = 'rt-' + crypto.randomBytes(32).toString('hex')
       const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
       const ua = req.headers['user-agent'] || ''
       sessions.set(token, {
         userId: user.id,
         userName: user.username,
         roles,
         createdAt: Date.now()
       })
       saveSession(token, refreshToken, user.id, user.username, roles, { deviceId: '', ip, userAgent: ua })

       // Redirect to frontend with token
       res.redirect(`/?oauth_token=${token}&oauth_user=${encodeURIComponent(JSON.stringify({ id: user.id, username: user.username }))}`)
     } catch (e) {
       console.error('[OAuth GitHub] Error:', e.message)
       res.serverError(e)
     }
  })

  // Google OAuth login redirect
  app.get('/api/oauth/google/login', async (_req, res) => {
    try {
      const config = await getOAuthConfig('google')
      if (!config || !config.enabled) return res.json({ code: 400, msg: 'Google登录未配置' })
      const state = generateToken()
      const redirectUri = encodeURIComponent(config.redirectUri)
      const url = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${config.clientId}&redirect_uri=${redirectUri}&response_type=code&scope=openid%20profile%20email&state=${state}`
      res.redirect(url)
    } catch (e) {
      res.serverError(e)
    }
  })

  // Google OAuth callback
  app.get('/api/oauth/google/callback', async (req, res) => {
    try {
      const { code } = req.query
      if (!code) return res.json({ code: 400, msg: '缺少授权码' })

      const config = await getOAuthConfig('google')
      if (!config || !config.enabled) return res.json({ code: 400, msg: 'Google登录未配置' })

      const tokenRes = await fetchJson('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          code,
          grant_type: 'authorization_code',
          redirect_uri: config.redirectUri
        })
      })

      if (!tokenRes.id_token) return res.json({ code: 400, msg: '获取令牌失败' })

      // Decode JWT id_token (simplified)
      const payload = JSON.parse(Buffer.from(tokenRes.id_token.split('.')[1], 'base64').toString())

      const user = await findOrCreateOAuthUser('google', payload.sub, {
        name: payload.name,
        login: payload.email,
        avatar_url: payload.picture,
        email: payload.email
      })

      if (user.status !== '1') return res.json({ code: 403, msg: '账号已被禁用' })

       const token = generateToken()
       const roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || [])
       const refreshToken = 'rt-' + crypto.randomBytes(32).toString('hex')
       const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
       const ua = req.headers['user-agent'] || ''
       sessions.set(token, {
         userId: user.id,
         userName: user.username,
         roles,
         createdAt: Date.now()
       })
       saveSession(token, refreshToken, user.id, user.username, roles, { deviceId: '', ip, userAgent: ua })

       res.redirect(`/?oauth_token=${token}&oauth_user=${encodeURIComponent(JSON.stringify({ id: user.id, username: user.username }))}`)
     } catch (e) {
       console.error('[OAuth Google] Error:', e.message)
       res.serverError(e)
     }
  })

  // WeChat OAuth login redirect
  app.get('/api/oauth/wechat/login', async (_req, res) => {
    try {
      const config = await getOAuthConfig('wechat')
      if (!config || !config.enabled) return res.json({ code: 400, msg: '微信登录未配置' })
      const state = generateToken()
      const redirectUri = encodeURIComponent(config.redirectUri)
      const url = `https://open.weixin.qq.com/connect/qrconnect?appid=${config.clientId}&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_login&state=${state}#wechat_redirect`
      res.redirect(url)
    } catch (e) {
      res.serverError(e)
    }
  })

  // WeChat OAuth callback
  app.get('/api/oauth/wechat/callback', async (req, res) => {
    try {
      const { code } = req.query
      if (!code) return res.json({ code: 400, msg: '缺少授权码' })

      const config = await getOAuthConfig('wechat')
      if (!config || !config.enabled) return res.json({ code: 400, msg: '微信登录未配置' })

      const tokenRes = await fetchJson(
        `https://api.weixin.qq.com/sns/oauth2/access_token?appid=${config.clientId}&secret=${config.clientSecret}&code=${code}&grant_type=authorization_code`
      )

      if (!tokenRes.openid) return res.json({ code: 400, msg: '获取微信信息失败' })

      let userInfo = { openid: tokenRes.openid, unionid: tokenRes.unionid, nickname: '', headimgurl: '' }
      if (tokenRes.access_token) {
        try {
          const infoRes = await fetchJson(
            `https://api.weixin.qq.com/sns/userinfo?access_token=${tokenRes.access_token}&openid=${tokenRes.openid}`
          )
          if (infoRes.nickname) userInfo = { ...userInfo, ...infoRes }
        } catch {}
      }

      const user = await findOrCreateOAuthUser('wechat', tokenRes.openid, {
        name: userInfo.nickname || `微信用户${Date.now().toString(36)}`,
        login: `wx_${tokenRes.openid.slice(0, 8)}`,
        avatar_url: userInfo.headimgurl || '',
        email: ''
      })

      if (user.status !== '1') return res.json({ code: 403, msg: '账号已被禁用' })

       const token = generateToken()
       const roles = typeof user.roles === 'string' ? JSON.parse(user.roles) : (user.roles || [])
       const refreshToken = 'rt-' + crypto.randomBytes(32).toString('hex')
       const ip = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || ''
       const ua = req.headers['user-agent'] || ''
       sessions.set(token, {
         userId: user.id,
         userName: user.username,
         roles,
         createdAt: Date.now()
       })
       saveSession(token, refreshToken, user.id, user.username, roles, { deviceId: '', ip, userAgent: ua })

       res.redirect(`/?oauth_token=${token}&oauth_user=${encodeURIComponent(JSON.stringify({ id: user.id, username: user.username }))}`)
     } catch (e) {
       console.error('[OAuth WeChat] Error:', e.message)
       res.serverError(e)
     }
  })

  // Save OAuth config
  app.post('/api/oauth/config', async (req, res) => {
    try {
      const { provider, clientId, clientSecret, redirectUri, enabled } = req.body
      if (!provider) return res.json({ code: 400, msg: '缺少provider' })
      await setOAuthConfig(provider, { clientId, clientSecret, redirectUri, enabled: !!enabled })
      res.json({ code: 200, msg: '配置已保存' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // Get OAuth config
  app.get('/api/oauth/config/:provider', async (req, res) => {
    try {
      const config = await getOAuthConfig(req.params.provider)
      res.json({ code: 200, data: config || {} })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = oauthRoutes
