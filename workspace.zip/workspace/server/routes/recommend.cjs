const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) return 0
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

function recommendRoutes(app) {

  // GET /api/appstore/recommend — 应用推荐（猜你喜欢）
  app.get('/api/appstore/recommend', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const limit = parseInt(req.query.limit) || 6

      if (!userId) {
        const list = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description
           FROM app_store WHERE status='1' ORDER BY downloads DESC, rating DESC LIMIT ?`, [limit]
        )
        return res.json({ code: 200, msg: 'success', data: list, type: 'hot' })
      }

      const historyApps = await query(
        `SELECT DISTINCT bh.app_id, a.categories, a.tags, a.category
         FROM browse_history bh
         JOIN app_store a ON bh.app_id = a.id
         WHERE bh.user_id=? AND a.status='1'
         ORDER BY bh.create_time DESC LIMIT 20`,
        [userId]
      )

      const purchasedApps = await query(
        `SELECT a.id, a.categories, a.tags, a.category
         FROM app_purchases ap
         JOIN app_store a ON ap.app_id = a.id
         WHERE ap.user_id=? AND a.status='1' LIMIT 20`,
        [userId]
      )

      const allUserTags = new Set()
      const allUserCategories = new Set()
      const userAppIds = new Set()

      const extractTags = (cats, tags, category) => {
        if (category) allUserCategories.add(category)
        if (cats) {
          try {
            const parsed = typeof cats === 'string' ? JSON.parse(cats) : cats
            if (Array.isArray(parsed)) parsed.forEach(c => allUserCategories.add(c))
          } catch {}
        }
        if (tags) {
          try {
            const parsed = typeof tags === 'string' ? JSON.parse(tags) : tags
            if (Array.isArray(parsed)) parsed.forEach(t => allUserTags.add(t))
          } catch {}
        }
      }

      for (const h of historyApps) {
        userAppIds.add(h.app_id)
        extractTags(h.categories, h.tags, h.category)
      }
      for (const p of purchasedApps) {
        userAppIds.add(p.id)
        extractTags(p.categories, p.tags, p.category)
      }

      let list = []
      const userTagArr = [...allUserTags]
      const userCatArr = [...allUserCategories]

      if (userTagArr.length > 0 || userCatArr.length > 0) {
        const conditions = []
        const params = []

        for (const cat of userCatArr.slice(0, 5)) {
          conditions.push('(category=? OR categories LIKE ?)')
          params.push(cat, `%"${cat}"%`)
        }
        for (const tag of userTagArr.slice(0, 5)) {
          conditions.push('tags LIKE ?')
          params.push(`%"${tag}"%`)
        }

        const excludeIds = [...userAppIds].slice(0, 40)
        let excludeClause = ''
        if (excludeIds.length > 0) {
          excludeClause = ` AND id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }

        list = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description, tags
           FROM app_store WHERE status='1'${excludeClause} AND (${conditions.join(' OR ')})
           ORDER BY downloads DESC, rating DESC LIMIT ?`,
          [...params, limit]
        )
      }

      if (list.length < limit) {
        const fillCount = limit - list.length
        const existingIds = list.map(l => l.id)
        let excludeClause = ''
        const excludeParams = [...existingIds]
        if (existingIds.length > 0) {
          excludeClause = ` AND id NOT IN (${existingIds.map(() => '?').join(',')})`
        }
        const fillList = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description, tags
           FROM app_store WHERE status='1'${excludeClause}
           ORDER BY downloads DESC, RAND() LIMIT ?`,
          [...excludeParams, fillCount]
        )
        list = list.concat(fillList)
      }

      res.json({ code: 200, msg: 'success', data: list, type: userId ? 'personalized' : 'hot' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/recommend/for-you — 基于标签的个性化推荐
  app.get('/api/recommend/for-you', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const limit = parseInt(req.query.limit) || 8

      if (!userId) {
        // 未登录用户：返回热门应用
        const list = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description
           FROM app_store WHERE status='1' ORDER BY downloads DESC, rating DESC LIMIT ?`, [limit]
        )
        for (const item of list) {
          try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        }
        return res.json({ code: 200, msg: 'success', data: { list, type: 'hot' } })
      }

      // 登录用户：基于浏览历史和下载记录推荐
      const historyApps = await query(
        `SELECT DISTINCT bh.app_id, a.categories, a.tags
         FROM browse_history bh
         JOIN app_store a ON bh.app_id = a.id
         WHERE bh.user_id=? AND a.status='1'
         ORDER BY bh.create_time DESC LIMIT 20`,
        [userId]
      )

      const purchasedApps = await query(
        `SELECT a.id, a.categories, a.tags
         FROM app_purchases ap
         JOIN app_store a ON ap.app_id = a.id
         WHERE ap.user_id=? AND a.status='1' LIMIT 20`,
        [userId]
      )

      const allUserTags = new Set()
      const allUserCategories = new Set()
      const userAppIds = new Set()

      const extractTags = (cats, tags) => {
        if (cats) {
          try {
            const parsed = typeof cats === 'string' ? JSON.parse(cats) : cats
            if (Array.isArray(parsed)) parsed.forEach(c => allUserCategories.add(c))
          } catch {}
        }
        if (tags) {
          try {
            const parsed = typeof tags === 'string' ? JSON.parse(tags) : tags
            if (Array.isArray(parsed)) parsed.forEach(t => allUserTags.add(t))
          } catch {}
        }
      }

      for (const h of historyApps) {
        userAppIds.add(h.app_id)
        extractTags(h.categories, h.tags)
      }
      for (const p of purchasedApps) {
        userAppIds.add(p.id)
        extractTags(p.categories, p.tags)
      }

      let list = []
      const userTagArr = [...allUserTags]
      const userCatArr = [...allUserCategories]

      if (userTagArr.length > 0 || userCatArr.length > 0) {
        const conditions = []
        const params = []

        for (const cat of userCatArr.slice(0, 5)) {
          conditions.push('(category=? OR categories LIKE ?)')
          params.push(cat, `%"${cat}"%`)
        }
        for (const tag of userTagArr.slice(0, 5)) {
          conditions.push('tags LIKE ?')
          params.push(`%"${tag}"%`)
        }

        const excludeIds = [...userAppIds].slice(0, 40)
        let excludeClause = ''
        if (excludeIds.length > 0) {
          excludeClause = ` AND id NOT IN (${excludeIds.map(() => '?').join(',')})`
          params.push(...excludeIds)
        }

        list = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description, tags
           FROM app_store WHERE status='1'${excludeClause} AND (${conditions.join(' OR ')})
           ORDER BY downloads DESC, rating DESC LIMIT ?`,
          [...params, limit]
        )
      }

      if (list.length < limit) {
        const fillCount = limit - list.length
        const existingIds = list.map(l => l.id)
        let excludeClause = ''
        if (existingIds.length > 0) {
          excludeClause = ` AND id NOT IN (${existingIds.map(() => '?').join(',')})`
        }
        const fillList = await query(
          `SELECT id, name, icon, icon_bg_color as iconBgColor, size_mb as sizeMb,
                  downloads, rating, category, description, tags
           FROM app_store WHERE status='1'${excludeClause}
           ORDER BY downloads DESC, RAND() LIMIT ?`,
          [...existingIds, fillCount]
        )
        list = list.concat(fillList)
      }

      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
      }

      res.json({ code: 200, msg: 'success', data: { list, type: 'personalized' } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // GET /api/recommend/hot-tags — 热门标签推荐
  app.get('/api/recommend/hot-tags', async (_req, res) => {
    try {
      const list = await query(
        `SELECT id, name, icon, icon_bg_color as iconBgColor, downloads, rating, tags
         FROM app_store WHERE status='1' AND tags IS NOT NULL AND tags != '[]'
         ORDER BY downloads DESC LIMIT 30`
      )
      const tagMap = {}
      for (const item of list) {
        try {
          const tags = item.tags ? JSON.parse(item.tags) : []
          for (const tag of tags) {
            if (!tagMap[tag]) tagMap[tag] = { tag, count: 0 }
            tagMap[tag].count++
          }
        } catch {}
      }
      const hotTags = Object.values(tagMap).sort((a, b) => b.count - a.count).slice(0, 10)
      res.json({ code: 200, msg: 'success', data: hotTags })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = { recommendRoutes }
