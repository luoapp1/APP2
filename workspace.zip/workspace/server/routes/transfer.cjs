const { query, getPool } = require('../database.cjs')
const crypto = require('crypto')
const { sessions, SESSION_TTL } = require('./system.cjs')

function withTransaction(callback) {
  return new Promise((resolve, reject) => {
    getPool().getConnection((err, conn) => {
      if (err) return reject(err)
      conn.beginTransaction(async (beginErr) => {
        if (beginErr) { conn.release(); return reject(beginErr) }
        try {
          const result = await callback(conn)
          conn.commit((commitErr) => {
            if (commitErr) { conn.rollback(() => conn.release()); return reject(commitErr) }
            conn.release()
            resolve(result)
          })
        } catch (e) {
          conn.rollback(() => conn.release())
          reject(e)
        }
      })
    })
  })
}

function genOrderNo() {
  return 'TR' + crypto.randomBytes(16).toString('hex').toUpperCase()
}

async function createCompletedOrder({ buyerId, buyerName, sellerId, sellerName, orderType, orderDesc, payType, paidAmount }) {
  // 根据结算规则确定确认期
  const buyer = await query('SELECT level_id FROM users WHERE id=?', [buyerId])
  const buyerLevel = buyer.length ? (buyer[0].level_id || 0) : 0
  const confirmCfg = await query('SELECT confirm_days FROM settlement_config WHERE level_id=? AND enabled=1', [buyerLevel])
  let confirmDays = 0
  if (!confirmCfg.length || confirmCfg[0].confirm_days === null || confirmCfg[0].confirm_days === undefined) {
    const def = await query('SELECT confirm_days FROM settlement_config WHERE level_id=0 AND enabled=1')
    confirmDays = def.length ? (def[0].confirm_days || 0) : 7
  } else {
    confirmDays = confirmCfg[0].confirm_days || 0
  }
  const deadline = confirmDays > 0 ? new Date(Date.now() + confirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19) : null
  const status = confirmDays > 0 ? 'shipped' : 'completed'

  const orderNo = genOrderNo()
  const res = await query(
    `INSERT INTO orders (order_no, buyer_id, buyer_name, seller_id, seller_name, order_type, order_desc,
      pay_type, total_amount, paid_amount, status, confirm_days, confirm_deadline, shipped_at, confirmed_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),${confirmDays > 0 ? 'NULL' : "NOW()"})`,
    [orderNo, buyerId, buyerName, sellerId || 0, sellerName || '', orderType, orderDesc, payType, paidAmount, paidAmount, status, confirmDays, deadline]
  )
  return { orderId: res.lastID, orderNo, status, confirmDays, confirmDeadline: deadline }
}

async function validateSettlement(userId, payType, amount) {
  const users = await query('SELECT level_id, balance, points, username FROM users WHERE id=?', [userId])
  if (!users.length) return { valid: false, msg: '用户不存在' }
  const u = users[0]

  let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [u.level_id || 0])
  if (!configs.length) configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
  if (!configs.length) return { valid: true }
  const cfg = configs[0]
  const isPoints = payType === 'points'

  if (isPoints && !cfg.points_transfer_enabled) return { valid: false, msg: '当前等级不允许积分转出' }
  if (!isPoints && !cfg.balance_transfer_enabled) return { valid: false, msg: '当前等级不允许余额转出' }

  const currentBalance = isPoints ? (u.points || 0) : (u.balance || 0)
  if (currentBalance < amount) return { valid: false, msg: isPoints ? '积分不足' : '余额不足' }

  if (isPoints && cfg.single_max_points > 0 && amount > cfg.single_max_points) return { valid: false, msg: `单次最多转出${cfg.single_max_points}积分` }
  if (isPoints && cfg.single_min_points > 0 && amount < cfg.single_min_points) return { valid: false, msg: `单次最少转出${cfg.single_min_points}积分` }
  if (!isPoints && cfg.single_max_balance > 0 && amount > cfg.single_max_balance) return { valid: false, msg: `单次最多转出${cfg.single_max_balance}元` }
  if (!isPoints && cfg.single_min_balance > 0 && amount < cfg.single_min_balance) return { valid: false, msg: `单次最少转出${cfg.single_min_balance}元` }

  const today = new Date().toISOString().slice(0, 10)
  if (isPoints && cfg.daily_limit_points_amount > 0) {
    const spent = await query('SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type=? AND date(create_time)=?', [userId, 'points', today])
    if (spent[0].total + amount > cfg.daily_limit_points_amount) return { valid: false, msg: `每日积分转出上限${cfg.daily_limit_points_amount}` }
  }
  if (!isPoints && cfg.daily_limit_balance_amount > 0) {
    const spent = await query('SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type=? AND date(create_time)=?', [userId, 'balance', today])
    if (spent[0].total + amount > cfg.daily_limit_balance_amount) return { valid: false, msg: `每日余额转出上限${cfg.daily_limit_balance_amount}元` }
  }
  if (cfg.daily_limit_times > 0) {
    const cnt = await query('SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND date(create_time)=?', [userId, today])
    if (cnt[0].cnt >= cfg.daily_limit_times) return { valid: false, msg: `每日转出上限${cfg.daily_limit_times}次` }
  }

  let feeRate = 0, feeAmount = 0
  if (isPoints) feeRate = cfg.points_transfer_fee || 0
  else feeRate = cfg.balance_transfer_fee || 0
  if (feeRate > 0) feeAmount = Math.round(amount * feeRate) / 100

  return { valid: true, cfg, feeRate, feeAmount }
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function getConfig(key) {
  try {
    const rows = await query('SELECT config_value FROM sys_config WHERE config_key=?', [key])
    return rows.length > 0 ? rows[0].config_value : 'false'
  } catch { return 'false' }
}

module.exports = function transferRoutes(app) {
  // 获取转账配置
  app.get('/api/transfer/config', async (req, res) => {
    try {
      const keys = ['points_transfer_enabled', 'points_transfer_fee', 'balance_transfer_enabled', 'balance_transfer_fee']
      const rows = await query('SELECT config_key, config_value FROM sys_config WHERE config_key IN (?,?,?,?)', keys)
      const cfg = {}
      for (const r of rows) cfg[r.config_key] = r.config_value
      res.json({ code: 200, data: cfg })
    } catch (e) { res.serverError(e) }
  })

  // 积分转账
  app.post('/api/transfer/points', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('points_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      // 结算规则校验
      const chk = await validateSettlement(userId, 'points', Number(amount))
      if (!chk.valid) return res.json({ code: chk.msg === '积分不足' ? 402 : 400, msg: chk.msg })

      const feeRate = chk.feeRate
      const fee = chk.feeAmount || Math.floor(Number(amount) * feeRate / 100)

      const fromUser = await query('SELECT username, points FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      if (fromUser[0].points < Number(amount) + fee) {
        return res.json({ code: 400, msg: '积分不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const deductResult = await conn.query('UPDATE users SET points=points-? WHERE id=? AND points>=?', [Number(amount) + fee, userId, Number(amount) + fee])
        if (deductResult[0].affectedRows === 0) {
          await conn.rollback()
          return res.json({ code: 400, msg: '积分不足' })
        }
        await conn.query('UPDATE users SET points=points+? WHERE id=?', [Number(amount), Number(toUserId)])

        await conn.query(
          'INSERT INTO points_transfer_records (from_user_id, from_user_name, to_user_id, to_user_name, amount, fee, remark) VALUES (?,?,?,?,?,?,?)',
          [userId, fromUser[0].username, Number(toUserId), toUser[0].username, Number(amount), fee, remark || '']
        )

        if (fee > 0) {
          await conn.query(
            "INSERT INTO points_records (user_id, user_name, type, points, source, description) VALUES (?,?,?,?,?,?)",
            [userId, fromUser[0].username, 'expense', fee, 'transfer', '积分转账手续费']
          )
        }

        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      // 创建结算订单记录
      await createCompletedOrder({
        buyerId: userId, buyerName: fromUser[0].username,
        sellerId: Number(toUserId), sellerName: toUser[0].username,
        orderType: 'transfer_points', orderDesc: remark || '积分转账',
        payType: 'points', paidAmount: Number(amount)
      })

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.serverError(e) }
  })

  // 余额转账
  app.post('/api/transfer/balance', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('balance_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '余额转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      // 结算规则校验
      const chk = await validateSettlement(userId, 'balance', Number(amount))
      if (!chk.valid) return res.json({ code: chk.msg === '余额不足' ? 402 : 400, msg: chk.msg })

      const feeRate = chk.feeRate
      const fee = (Number(amount) * feeRate / 100).toFixed(2)

      const fromUser = await query('SELECT username, balance FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      if (fromUser[0].balance < Number(amount) + Number(fee)) {
        return res.json({ code: 400, msg: '余额不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      const totalDeduct = (Number(amount) + Number(fee)).toFixed(2)

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const deductResult = await conn.query('UPDATE users SET balance=balance-? WHERE id=? AND balance>=?', [Number(totalDeduct), userId, Number(totalDeduct)])
        if (deductResult[0].affectedRows === 0) {
          await conn.rollback()
          return res.json({ code: 400, msg: '余额不足' })
        }
        await conn.query('UPDATE users SET balance=balance+? WHERE id=?', [Number(amount), Number(toUserId)])

        await conn.query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '余额转账', ?)`,
          [userId, fromUser[0].username, Number(totalDeduct), userId, `转账给 ${toUser[0].username}(含手续费${Number(fee).toFixed(2)})`])
        await conn.query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '余额转账', ?)`,
          [Number(toUserId), toUser[0].username, Number(amount), Number(toUserId), `收到 ${fromUser[0].username} 转账`])

        await conn.query(
          'INSERT INTO balance_transfer_records (from_user_id, from_user_name, to_user_id, to_user_name, amount, fee, remark) VALUES (?,?,?,?,?,?,?)',
          [userId, fromUser[0].username, Number(toUserId), toUser[0].username, Number(amount), Number(fee), remark || '']
        )

        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      // 创建结算订单记录
      await createCompletedOrder({
        buyerId: userId, buyerName: fromUser[0].username,
        sellerId: Number(toUserId), sellerName: toUser[0].username,
        orderType: 'transfer_balance', orderDesc: remark || '余额转账',
        payType: 'balance', paidAmount: Number(amount)
      })

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.serverError(e) }
  })

  // 积分购买
  app.post('/api/transfer/points/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('points_purchase_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分购买功能未开启' })

      const rate = parseInt(await getConfig('points_purchase_rate')) || 1
      const { amount } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '金额无效' })

      const balanceAmount = Number(amount)
      const points = Math.floor(balanceAmount * rate)

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        const result = await conn.query('UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?', [balanceAmount, userId, balanceAmount])
        if (result.affectedRows === 0) {
          await conn.rollback()
          return res.json({ code: 400, msg: '余额不足' })
        }

        await conn.query('UPDATE users SET points = points + ? WHERE id = ?', [points, userId])
        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      await query(
        "INSERT INTO points_records (user_id, user_name, type, points, source, description) VALUES (?,?,?,?,?,?)",
        [userId, '', 'earn', points, 'purchase', `现金购买${points}积分(￥${balanceAmount})`]
      )
      await query(
        "INSERT INTO balance_records (user_id, user_name, type, amount, balance, description) VALUES (?,?,?,?,(SELECT balance FROM users WHERE id=?),?)",
        [userId, '', 'expense', balanceAmount, userId, `购买${points}积分`]
      )

      res.json({ code: 200, msg: `成功购买${points}积分`, data: { points } })
    } catch (e) { res.serverError(e) }
  })

  // 转账记录
  app.get('/api/transfer/records', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20, type } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)

      let pointTotal, balanceTotal, pointList, balanceList

      if (!type || type === 'points') {
        pointTotal = await query(
          'SELECT COUNT(*) as total FROM points_transfer_records WHERE from_user_id=? OR to_user_id=?',
          [userId, userId]
        )
        pointList = await query(
          'SELECT * FROM points_transfer_records WHERE from_user_id=? OR to_user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
          [userId, userId, Number(pageSize), offset]
        )
      }

      if (!type || type === 'balance') {
        balanceTotal = await query(
          'SELECT COUNT(*) as total FROM balance_transfer_records WHERE from_user_id=? OR to_user_id=?',
          [userId, userId]
        )
        balanceList = await query(
          'SELECT * FROM balance_transfer_records WHERE from_user_id=? OR to_user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?',
          [userId, userId, Number(pageSize), offset]
        )
      }

      res.json({
        code: 200,
        data: {
          points: { list: pointList || [], total: pointTotal ? pointTotal[0]?.total || 0 : 0 },
          balance: { list: balanceList || [], total: balanceTotal ? balanceTotal[0]?.total || 0 : 0 }
        }
      })
    } catch (e) { res.serverError(e) }
  })
}
