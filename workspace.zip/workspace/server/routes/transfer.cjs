const { query, getPool } = require('../database.cjs')
const crypto = require('crypto')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { addBalance, addPoints, deductBalance, deductPoints } = require('./account-utils.cjs')

function safeJsonParse(s, fallback = {}) {
  if (!s) return fallback
  try { return typeof s === 'string' ? JSON.parse(s) : s } catch { return fallback }
}

async function getUserBalancesMap(userId) {
  const rows = await query('SELECT currency_key, available, frozen FROM user_currency_balance WHERE user_id=?', [userId])
  const map = {}
  for (const r of rows) { map[r.currency_key] = Number(r.available || 0) + Number(r.frozen || 0) }
  return map
}

function withTransaction(callback) {
  return new Promise((resolve, reject) => {
    getPool().promise().getConnection().then(async (conn) => {
      try {
        await conn.beginTransaction()
        const result = await callback(conn)
        await conn.commit()
        conn.release()
        resolve(result)
      } catch (e) {
        try { await conn.rollback() } catch (_) {}
        conn.release()
        reject(e)
      }
    }).catch(reject)
  })
}

function genOrderNo() {
  return 'TR' + crypto.randomBytes(16).toString('hex').toUpperCase()
}

async function createCompletedOrder({ buyerId, buyerName, sellerId, sellerName, orderType, orderDesc, payType, paidAmount }) {
  // 根据结算规则确定确认期
  const buyer = await query('SELECT level_id FROM users WHERE id=?', [buyerId])
  const buyerLevel = buyer.length ? (buyer[0].level_id || 0) : 0
  const confirmCfg = await query('SELECT confirm_days FROM settlement_config WHERE level_id=? AND enabled=1', [buyerLevel])
  let confirmDays = 0
  if (!confirmCfg.length || confirmCfg[0].confirm_days === null || confirmCfg[0].confirm_days === undefined) {
    const def = await query('SELECT confirm_days FROM settlement_config WHERE level_id=0 AND enabled=1')
    confirmDays = def.length ? (def[0].confirm_days || 0) : 7
  } else {
    confirmDays = confirmCfg[0].confirm_days || 0
  }
  const deadline = confirmDays > 0 ? new Date(Date.now() + confirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19) : null
  const status = confirmDays > 0 ? 'shipped' : 'completed'

  const orderNo = genOrderNo()
  const res = await query(
    `INSERT INTO orders (order_no, buyer_id, buyer_name, seller_id, seller_name, order_type, order_desc,
      pay_type, total_amount, paid_amount, status, confirm_days, confirm_deadline, shipped_at, confirmed_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),${confirmDays > 0 ? 'NULL' : "NOW()"})`,
    [orderNo, buyerId, buyerName, sellerId || 0, sellerName || '', orderType, orderDesc, payType, paidAmount, paidAmount, status, confirmDays, deadline]
  )
  return { orderId: res.lastID, orderNo, status, confirmDays, confirmDeadline: deadline }
}

async function validateSettlement(userId, payType, amount) {
  const users = await query('SELECT level_id, username FROM users WHERE id=?', [userId])
  if (users && users.length > 0) {
    const balRows = await query('SELECT currency_key, available, frozen FROM user_currency_balance WHERE user_id=?', [userId])
    const map = {}
    for (const r of balRows) { map[r.currency_key] = Number(r.available || 0) + Number(r.frozen || 0) }
    users[0].balance = map.balance || 0
    users[0].points = map.points || 0
  }
  if (!users.length) return { valid: false, msg: '用户不存在' }
  const u = users[0]

  let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [u.level_id || 0])
  if (!configs.length) configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
  if (!configs.length) return { valid: true }
  const cfg = configs[0]
  const isPoints = payType === 'points'

  if (isPoints && !cfg.points_transfer_enabled) return { valid: false, msg: '当前等级不允许积分转出' }
  if (!isPoints && !cfg.balance_transfer_enabled) return { valid: false, msg: '当前等级不允许余额转出' }

  const currentBalance = isPoints ? (u.points || 0) : (u.balance || 0)
  if (currentBalance < amount) return { valid: false, msg: isPoints ? '积分不足' : '余额不足' }

  if (isPoints && cfg.single_max_points > 0 && amount > cfg.single_max_points) return { valid: false, msg: `单次最多转出${cfg.single_max_points}积分` }
  if (isPoints && cfg.single_min_points > 0 && amount < cfg.single_min_points) return { valid: false, msg: `单次最少转出${cfg.single_min_points}积分` }
  if (!isPoints && cfg.single_max_balance > 0 && amount > cfg.single_max_balance) return { valid: false, msg: `单次最多转出${cfg.single_max_balance}元` }
  if (!isPoints && cfg.single_min_balance > 0 && amount < cfg.single_min_balance) return { valid: false, msg: `单次最少转出${cfg.single_min_balance}元` }

  const today = new Date().toISOString().slice(0, 10)
  if (isPoints && cfg.daily_limit_points_amount > 0) {
    const spent = await query('SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type=? AND date(create_time)=?', [userId, 'points', today])
    if (spent[0].total + amount > cfg.daily_limit_points_amount) return { valid: false, msg: `每日积分转出上限${cfg.daily_limit_points_amount}` }
  }
  if (!isPoints && cfg.daily_limit_balance_amount > 0) {
    const spent = await query('SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type=? AND date(create_time)=?', [userId, 'balance', today])
    if (spent[0].total + amount > cfg.daily_limit_balance_amount) return { valid: false, msg: `每日余额转出上限${cfg.daily_limit_balance_amount}元` }
  }
  const tc = safeJsonParse(cfg.transfer_config)
  const currencyCfg = (tc[payType] || {})
  const timeLimits = currencyCfg.timeLimits || []
  for (const tl of timeLimits) {
    const maxTimes = Number(tl.maxTimes) || 0
    const days = Number(tl.days) || 0
    if (maxTimes <= 0 || days <= 0) continue
    const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10)
    const cnt = await query(
      `SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND pay_type=? AND status!='cancelled' AND date(create_time)>=?`,
      [userId, payType, since]
    )
    if (cnt[0].cnt >= maxTimes) return { valid: false, msg: `${days}天内最多转出${maxTimes}次` }
  }

  let feeRate = 0, feeAmount = 0
  if (isPoints) feeRate = cfg.points_transfer_fee || 0
  else feeRate = cfg.balance_transfer_fee || 0
  if (feeRate > 0) feeAmount = Math.round(amount * feeRate) / 100

  return { valid: true, cfg, feeRate, feeAmount }
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function getConfig(key) {
  try {
    const rows = await query('SELECT config_value FROM sys_config WHERE config_key=?', [key])
    return rows.length > 0 ? rows[0].config_value : 'false'
  } catch { return 'false' }
}

module.exports = function transferRoutes(app) {
  // 获取转账配置
  app.get('/api/transfer/config', async (req, res) => {
    try {
      const keys = ['points_transfer_enabled', 'points_transfer_fee', 'balance_transfer_enabled', 'balance_transfer_fee']
      const rows = await query('SELECT config_key, config_value FROM sys_config WHERE config_key IN (?,?,?,?)', keys)
      const cfg = {}
      for (const r of rows) cfg[r.config_key] = r.config_value
      res.json({ code: 200, data: cfg })
    } catch (e) { res.serverError(e) }
  })

  // 积分转账
  app.post('/api/transfer/points', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      // 配额币种拦截
      const [cs] = await query('SELECT currency_type FROM currency_settings WHERE currency_key=?', ['points'])
      if (cs && cs.currency_type === 'quota') return res.json({ code: 403, msg: '该币种不支持转账' })

      const enabled = await getConfig('points_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      // 结算规则校验
      const chk = await validateSettlement(userId, 'points', Number(amount))
      if (!chk.valid) return res.json({ code: chk.msg === '积分不足' ? 402 : 400, msg: chk.msg })

      const feeRate = chk.feeRate
      const fee = chk.feeAmount || Math.floor(Number(amount) * feeRate / 100)

      const fromUser = await query('SELECT username FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      const bm = await getUserBalancesMap(userId)
      fromUser[0].points = bm.points || 0
      if (fromUser[0].points < Number(amount) + fee) {
        return res.json({ code: 400, msg: '积分不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        await deductPoints(userId, fromUser[0].username, Number(amount), 'transfer', remark || '积分转账', conn)
        if (fee > 0) {
          await deductPoints(userId, fromUser[0].username, fee, 'transfer', '积分转账手续费', conn)
        }
        await addPoints(Number(toUserId), toUser[0].username, Number(amount), 'transfer', `收到 ${fromUser[0].username} 转账`, conn)

        await conn.query(
          'INSERT INTO currency_transactions (user_id, user_name, currency_key, tx_type, amount, balance_after, source_type, source_id, description, create_time) VALUES (?,?,?,?,?, (SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=? LIMIT 1), ?,?,?,NOW())',
          [userId, fromUser[0].username, 'points', 'spend', fee, userId, 'points', 'transfer', 0, '积分转账手续费']
        )

        await createCompletedOrder({
          buyerId: userId, buyerName: fromUser[0].username,
          sellerId: Number(toUserId), sellerName: toUser[0].username,
          orderType: 'transfer_points', orderDesc: remark || '积分转账',
          payType: 'points', paidAmount: Number(amount)
        })

        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.serverError(e) }
  })

  // 余额转账
  app.post('/api/transfer/balance', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const [cs] = await query('SELECT currency_type FROM currency_settings WHERE currency_key=?', ['balance'])
      if (cs && cs.currency_type === 'quota') return res.json({ code: 403, msg: '该币种不支持转账' })

      const enabled = await getConfig('balance_transfer_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '余额转账功能未开启' })

      const { toUserId, amount, remark } = req.body
      if (!toUserId || !amount || Number(amount) <= 0) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      // 结算规则校验
      const chk = await validateSettlement(userId, 'balance', Number(amount))
      if (!chk.valid) return res.json({ code: chk.msg === '余额不足' ? 402 : 400, msg: chk.msg })

      const feeRate = chk.feeRate
      const fee = (Number(amount) * feeRate / 100).toFixed(2)

      const fromUser = await query('SELECT username FROM users WHERE id=?', [userId])
      if (!fromUser.length) return res.json({ code: 404, msg: '用户不存在' })
      const bmBal = await getUserBalancesMap(userId)
      fromUser[0].balance = bmBal.balance || 0
      if (fromUser[0].balance < Number(amount) + Number(fee)) {
        return res.json({ code: 400, msg: '余额不足(含手续费)' })
      }

      const toUser = await query('SELECT username FROM users WHERE id=?', [Number(toUserId)])
      if (!toUser.length) return res.json({ code: 404, msg: '目标用户不存在' })

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        await deductBalance(userId, fromUser[0].username, Number(amount), 'transfer', remark || '余额转账', conn)
        await deductBalance(userId, fromUser[0].username, Number(fee), 'transfer', '余额转账手续费', conn)
        await addBalance(Number(toUserId), toUser[0].username, Number(amount), 'transfer', `收到 ${fromUser[0].username} 转账`, conn)

        await conn.query(
          'INSERT INTO currency_transactions (user_id, user_name, currency_key, tx_type, amount, balance_after, source_type, source_id, description, create_time) VALUES (?,?,?,?,?, (SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=? LIMIT 1), ?,?,?,NOW())',
          [userId, fromUser[0].username, 'balance', 'spend', Number(fee), userId, 'balance', 'transfer', 0, '余额转账手续费']
        )

        await createCompletedOrder({
          buyerId: userId, buyerName: fromUser[0].username,
          sellerId: Number(toUserId), sellerName: toUser[0].username,
          orderType: 'transfer_balance', orderDesc: remark || '余额转账',
          payType: 'balance', paidAmount: Number(amount)
        })

        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      res.json({ code: 200, msg: '转账成功' })
    } catch (e) { res.serverError(e) }
  })

  // 积分购买
  app.post('/api/transfer/points/purchase', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const enabled = await getConfig('points_purchase_enabled')
      if (enabled !== 'true') return res.json({ code: 403, msg: '积分购买功能未开启' })

      const rate = parseInt(await getConfig('points_purchase_rate')) || 1
      const { amount } = req.body
      if (!amount || Number(amount) <= 0) return res.json({ code: 400, msg: '金额无效' })

      const balanceAmount = Number(amount)
      const points = Math.floor(balanceAmount * rate)

      const conn = await getPool().promise().getConnection()
      try {
        await conn.beginTransaction()

        await deductBalance(userId, '', balanceAmount, 'purchase', `购买${points}积分`, conn)
        await addPoints(userId, '', points, 'purchase', `现金购买${points}积分(￥${balanceAmount})`, conn)
        await conn.commit()
      } catch (e) {
        await conn.rollback()
        conn.release()
        throw e
      }
      conn.release()

      res.json({ code: 200, msg: `成功购买${points}积分`, data: { points } })
    } catch (e) { res.serverError(e) }
  })

  // 转账记录
  app.get('/api/transfer/records', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 20, type } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)

      let pointTotal, balanceTotal, pointList, balanceList

      if (!type || type === 'points') {
        pointTotal = await query(
          "SELECT COUNT(*) as total FROM currency_transactions WHERE user_id=? AND source_type='transfer' AND currency_key='points'",
          [userId]
        )
        pointList = await query(
          "SELECT * FROM currency_transactions WHERE user_id=? AND source_type='transfer' AND currency_key='points' ORDER BY create_time DESC LIMIT ? OFFSET ?",
          [userId, Number(pageSize), offset]
        )
      }

      if (!type || type === 'balance') {
        balanceTotal = await query(
          "SELECT COUNT(*) as total FROM currency_transactions WHERE user_id=? AND source_type='transfer' AND currency_key='balance'",
          [userId]
        )
        balanceList = await query(
          "SELECT * FROM currency_transactions WHERE user_id=? AND source_type='transfer' AND currency_key='balance' ORDER BY create_time DESC LIMIT ? OFFSET ?",
          [userId, Number(pageSize), offset]
        )
      }

      res.json({
        code: 200,
        data: {
          points: { list: pointList || [], total: pointTotal ? pointTotal[0]?.total || 0 : 0 },
          balance: { list: balanceList || [], total: balanceTotal ? balanceTotal[0]?.total || 0 : 0 }
        }
      })
    } catch (e) { res.serverError(e) }
  })
}
