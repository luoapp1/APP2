const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return { userId: 0, roles: [] }
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return { userId: 0, roles: [] } }
    return { userId: Number(session.userId) || 0, roles: session.roles || [] }
  }
  return { userId: 0, roles: [] }
}

module.exports = function filePolicyRoutes(app) {
  app.get('/api/file-policy/list', async (req, res) => {
    try {
      const list = await query('SELECT * FROM file_policies ORDER BY id')
      res.json({ code: 200, data: list })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/file-policy/save', async (req, res) => {
    try {
      const { id, name, user_level_id, user_level_name, role_code, max_file_size_mb, allowed_types, banned_types, status, image_compress_enabled, image_max_width, image_max_height, image_quality } = req.body
      const data = [
        name || '', user_level_id || 0, user_level_name || '', role_code || '',
        max_file_size_mb || 10, allowed_types || '', banned_types || '', status || '1',
        image_compress_enabled ? 1 : 0, image_max_width || 1200, image_max_height || 0, image_quality ?? 0.8
      ]
      if (id) {
        await query(
          'UPDATE file_policies SET name=?, user_level_id=?, user_level_name=?, role_code=?, max_file_size_mb=?, allowed_types=?, banned_types=?, status=?, image_compress_enabled=?, image_max_width=?, image_max_height=?, image_quality=? WHERE id=?',
          [...data, Number(id)]
        )
      } else {
        await query(
          'INSERT INTO file_policies (name, user_level_id, user_level_name, role_code, max_file_size_mb, allowed_types, banned_types, status, image_compress_enabled, image_max_width, image_max_height, image_quality) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
          data
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/file-policy/delete', async (req, res) => {
    try {
      await query('DELETE FROM file_policies WHERE id=?', [Number(req.body.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.serverError(e) }
  })

  // 检查用户上传权限（按角色/等级匹配）
  const DEFAULT_DATA = { max_size_mb: 10, allowed_all: true, image_compress_enabled: false, image_max_width: 1200, image_max_height: 0, image_quality: 0.8 }

  app.get('/api/file-policy/check', async (req, res) => {
    try {
      const { userId, roles } = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { ...DEFAULT_DATA } })

      const user = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
      if (!user.length) return res.json({ code: 200, data: { ...DEFAULT_DATA } })

      const levelId = user[0].level_id || 0
      let policy = null

      // 优先级: 角色='*'（所有角色）> 具体角色匹配 > 等级匹配 > 默认策略
      const allRolePolicy = await query("SELECT * FROM file_policies WHERE status='1' AND role_code='*' ORDER BY id LIMIT 1")
      if (allRolePolicy.length) policy = allRolePolicy[0]

      if (!policy && roles.length > 0) {
        const placeholders = roles.map(() => '?').join(',')
        const rows = await query(
          `SELECT * FROM file_policies WHERE status='1' AND role_code IN (${placeholders}) ORDER BY id LIMIT 1`,
          roles
        )
        if (rows.length) policy = rows[0]
      }
      if (!policy && levelId) {
        const rows = await query(
          "SELECT * FROM file_policies WHERE status='1' AND role_code='' AND user_level_id=? ORDER BY id LIMIT 1",
          [levelId]
        )
        if (rows.length) policy = rows[0]
      }
      if (!policy) {
        const rows = await query("SELECT * FROM file_policies WHERE status='1' AND user_level_id=0 AND role_code='' ORDER BY id LIMIT 1")
        if (rows.length) policy = rows[0]
      }

      res.json({
        code: 200,
        data: {
          max_size_mb: policy ? policy.max_file_size_mb : 10,
          allowed_types: policy ? policy.allowed_types : '',
          banned_types: policy ? policy.banned_types : '',
          allowed_all: !policy,
          image_compress_enabled: policy ? !!(policy.image_compress_enabled) : false,
          image_max_width: policy ? (policy.image_max_width || 1200) : 1200,
          image_max_height: policy ? (policy.image_max_height || 0) : 0,
          image_quality: policy ? (policy.image_quality ?? 0.8) : 0.8
        }
      })
    } catch (e) { res.serverError(e) }
  })
}
