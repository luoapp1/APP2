const { query } = require('../database.cjs')
const nowExpr = 'NOW()'
const { logFromReq } = require('../middleware/security.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function officialTagRoutes(router) {

  router.get('/api/official-tags/list', authRequired, adminRequired, async (req, res) => {
    try {
      const list = await query(
        `SELECT id, name, color, bg_color as bgColor, sort_order as sortOrder, status, create_time as createTime
         FROM app_official_tags ORDER BY sort_order ASC, id ASC`
      )
      res.json({ code: 200, msg: 'success', data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/official-tags/save', authRequired, adminRequired, async (req, res) => {
    try {
      const { id, name, color, bgColor, sortOrder, status } = req.body
      if (id) {
        await query(
          `UPDATE app_official_tags SET name=?, color=?, bg_color=?, sort_order=?, status=? WHERE id=?`,
          [name, color || '#2563eb', bgColor || '#dbeafe', Number(sortOrder) || 0, status || '1', Number(id)]
        )
        logFromReq(req, 'update', 'official_tag', Number(id), `更新官方标签"${name}"`)
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO app_official_tags (name, color, bg_color, sort_order, status) VALUES (?,?,?,?,?)`,
          [name, color || '#2563eb', bgColor || '#dbeafe', Number(sortOrder) || 0, status || '1']
        )
        logFromReq(req, 'create', 'official_tag', result.insertId, `新增官方标签"${name}"`)
        res.json({ code: 200, msg: '新增成功', data: { id: result.insertId } })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/official-tags/:id', authRequired, adminRequired, async (req, res) => {
    try {
      await query('DELETE FROM app_official_tags WHERE id=?', [Number(req.params.id)])
      logFromReq(req, 'delete', 'official_tag', req.params.id, `删除官方标签ID:${req.params.id}`)
      res.json({ code: 200, msg: '删除成功', data: { success: true } })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = officialTagRoutes
