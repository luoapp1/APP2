const crypto = require('crypto')
const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

function genCode() {
  return crypto.randomBytes(6).toString('hex').toUpperCase().substring(0, 8)
}

// 阶梯计价辅助函数
function calcTieredCost(amount, tiers) {
  if (!tiers || !tiers.length) return 0
  const sorted = [...tiers].sort((a, b) => (a.maxAmount || 0) - (b.maxAmount || 0))
  let cost = 0
  let prevMax = 0
  for (const tier of sorted) {
    const max = Number(tier.maxAmount) || 999999
    const qty = Number(tier.quantity) || 1
    const tc = Number(tier.totalCost) || 0
    const unit = tc / qty
    if (amount <= prevMax) break
    const inTier = Math.min(amount, max) - prevMax
    if (inTier > 0) cost += inTier * unit
    prevMax = max
    if (amount <= max) break
  }
  if (amount > prevMax) {
    const last = sorted[sorted.length - 1]
    const unit = (Number(last.totalCost) || 0) / (Number(last.quantity) || 1)
    cost += (amount - prevMax) * unit
  }
  return Math.round(cost * 100) / 100
}

// 计算单个邀请码的费用（基于存储的奖励参数和当前配置）
async function calcSingleCodeCost(code, costConfig, userId) {
  let cost = 0
  const types = code.reward_type ? String(code.reward_type).split(',').filter(Boolean) : []
  const values = code.reward_value ? String(code.reward_value).split(',').filter(Boolean) : []
  const dur = Number(code.reward_duration) || 30

  for (let i = 0; i < types.length; i++) {
    const rt = types[i].trim()
    const rv = parseInt(values[i]) || 0
    if (rt === 'points') cost += calcTieredCost(rv, costConfig.pointsPricing || [])
    else if (rt === 'balance') cost += calcTieredCost(rv, costConfig.balancePricing || [])
    else if (rt === 'experience') cost += calcTieredCost(rv, costConfig.expPricing || [])
    else if (rt === 'membership') {
      const pricing = costConfig.membershipPricing || {}
      const durKey = String(dur)
      if (pricing[durKey] !== undefined) {
        cost += Number(pricing[durKey])
      } else {
        const keys = Object.keys(pricing).map(Number).sort((a, b) => a - b)
        if (keys.length > 0) {
          const perDay = Number(pricing[String(keys[0])]) / keys[0]
          cost += Math.round(perDay * dur * 100) / 100
        }
      }
    }
  }

  // VIP discount
  if (costConfig.vipDiscount && costConfig.vipDiscount.enabled) {
    const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
    if (user.length && user[0].level_id === Number(costConfig.vipDiscount.levelId)) {
      const lv = await query('SELECT discount_rate FROM membership_levels WHERE id=?', [costConfig.vipDiscount.levelId])
      if (lv.length) {
        const rate = Number(lv[0].discount_rate) || 1
        cost = Math.round(cost * rate * 100) / 100
      }
    }
  }
  return cost
}

module.exports = function inviteRoutes(app) {
  app.post('/api/invite/generate', authRequired, requirePermission('generate'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { count = 1, maxUses = 1, expiresDays = 0, rewardType, rewardValue, rewardDuration } = req.body
      const codes = []
      for (let i = 0; i < count; i++) {
        const code = genCode()
        const expiresAt = expiresDays > 0 ? new Date(Date.now() + expiresDays * 86400000).toISOString().replace('T', ' ').substring(0, 19) : null
        const userId = await getUserId(req)
        await query(
          'INSERT INTO invite_codes (code, created_by, created_by_name, max_uses, expires_at, type, reward_type, reward_value, reward_duration) VALUES (?,?,?,?,?,?,?,?,?)',
          [code, userId, '管理员', maxUses, expiresAt, 'admin', rewardType || '', rewardValue || '', rewardDuration || 0]
        )
        codes.push(code)
      }
      res.json({ code: 200, data: { codes }, msg: `成功生成${count}个邀请码` })
    } catch (e) { res.json({ code: 500, msg: '生成失败: ' + e.message }) }
  })

  // 用户自己生成邀请码
  app.post('/api/invite/generate-user', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_enabled'")
      if (!cfg || !cfg.length || cfg[0].config_value !== 'true') {
        return res.json({ code: 403, msg: '暂未开放用户生成邀请码' })
      }

      const maxCfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_max'")
      const maxCount = maxCfg && maxCfg.length ? parseInt(maxCfg[0].config_value) || 5 : 5

      const maxUsesCfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_max_uses'")
      const maxUsesLimit = maxUsesCfg && maxUsesCfg.length ? parseInt(maxUsesCfg[0].config_value) || 10 : 10

      const { rewardType, rewardValue, rewardDuration = 30, count = 1, maxUses = 1 } = req.body
      const genCount = Math.max(1, Math.min(100, parseInt(count) || 1))
      const genMaxUses = Math.max(1, Math.min(maxUsesLimit, parseInt(maxUses) || 1))

      const myUsed = await query(
        "SELECT COUNT(*) as cnt FROM invite_codes WHERE type='user' AND created_by_user_id=? AND status='1' AND use_count < max_uses",
        [userId]
      )
      if (myUsed[0].cnt + genCount > maxCount) {
        return res.json({ code: 400, msg: `最多只能保留${maxCount}个有效邀请码，当前已有${myUsed[0].cnt}个` })
      }

      const rewardTypes = rewardType ? String(rewardType).split(',').filter(Boolean) : []
      const rewardValues = rewardValue ? String(rewardValue).split(',').filter(Boolean) : []

      // 计算生成费用（单次，乘以生成数量和使用次数）
      let costPerCode = 0
      if (rewardTypes.length > 0) {
        const costCfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_cost_config'")
        let costConfig = {}
        if (costCfg.length && costCfg[0].config_value) {
          try { costConfig = JSON.parse(costCfg[0].config_value) } catch {}
        }
        if (!costConfig.enabled) {
          return res.json({ code: 400, msg: '暂未开放付费生成邀请码功能' })
        }

        const dummyCode = { reward_type: rewardType, reward_value: rewardValue, reward_duration: rewardDuration }
        costPerCode = await calcSingleCodeCost(dummyCode, costConfig, userId)

        const totalCost = Math.round(costPerCode * genCount * genMaxUses * 100) / 100

        if (totalCost > 0) {
          const userBalance = await query('SELECT balance, username FROM users WHERE id=?', [userId])
          if (!userBalance.length || Number(userBalance[0].balance) < totalCost) {
            return res.json({ code: 400, msg: `余额不足，需要 ${totalCost.toFixed(2)} 元（${genCount}个邀请码）` })
          }
          await query('UPDATE users SET balance = balance - ? WHERE id=?', [totalCost, userId])
          await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '邀请码生成', ?)`,
            [userId, userBalance[0].username || '', totalCost, userId, `生成${genCount}个邀请码（含${rewardTypes.length}项奖励）`])
        }
      }

      const codes = []
      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      const userName = user && user.length > 0 ? user[0].username : ''
      for (let i = 0; i < genCount; i++) {
        const code = genCode()
        await query(
          'INSERT INTO invite_codes (code, created_by, created_by_name, type, created_by_user_id, max_uses, expires_at, reward_type, reward_value, reward_duration) VALUES (?,?,?,?,?,?,?,?,?,?)',
          [code, userId, userName, 'user', userId, genMaxUses, null, rewardType || '', rewardValue || '', rewardDuration || 0]
        )
        codes.push(code)
      }
      res.json({ code: 200, data: { codes }, msg: `成功生成${genCount}个邀请码` })
    } catch (e) { res.json({ code: 500, msg: '生成失败: ' + e.message }) }
  })

  // 用户撤销自己未使用的邀请码
  app.post('/api/invite/my/revoke/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const id = Number(req.params.id)
      const rows = await query(
        'SELECT * FROM invite_codes WHERE id=? AND created_by_user_id=? AND type=?',
        [id, userId, 'user']
      )
      if (!rows.length) return res.json({ code: 404, msg: '邀请码不存在' })
      const code = rows[0]
      if (code.use_count > 0) return res.json({ code: 400, msg: '邀请码已被使用，无法撤销' })

      // 重新计算费用并退款
      let refund = 0
      if (code.reward_type) {
        const costCfg = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_cost_config'")
        let costConfig = {}
        if (costCfg.length && costCfg[0].config_value) {
          try { costConfig = JSON.parse(costCfg[0].config_value) } catch {}
        }
        if (costConfig.enabled) {
          refund = Math.round((await calcSingleCodeCost(code, costConfig, userId)) * code.max_uses * 100) / 100
        }
      }

      await query("UPDATE invite_codes SET status='3' WHERE id=?", [id])

      if (refund > 0) {
        const user = await query('SELECT username, balance FROM users WHERE id=?', [userId])
        await query('UPDATE users SET balance = balance + ? WHERE id=?', [refund, userId])
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '邀请码撤销', ?)`,
          [userId, user[0]?.username || '', refund, userId, `撤销邀请码 ${code.code} 退款`])
      }

      res.json({ code: 200, msg: refund > 0 ? `已撤销，退还 ${refund.toFixed(2)} 元` : '已撤销' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 用户删除自己的邀请码（仅未使用或已撤回的）
  app.delete('/api/invite/my/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const id = Number(req.params.id)
      const rows = await query(
        'SELECT * FROM invite_codes WHERE id=? AND created_by_user_id=? AND type=?',
        [id, userId, 'user']
      )
      if (!rows.length) return res.json({ code: 404, msg: '邀请码不存在' })
      if (rows[0].use_count > 0) return res.json({ code: 400, msg: '邀请码已被使用，无法删除' })
      await query('DELETE FROM invite_codes WHERE id=?', [id])
      res.json({ code: 200, msg: '已删除' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 用户查看自己的邀请码
  app.get('/api/invite/my', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const list = await query(
        "SELECT * FROM invite_codes WHERE created_by_user_id=? ORDER BY create_time DESC",
        [userId]
      )
      res.json({ code: 200, data: { list } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/invite/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { page = 1, pageSize = 20, status } = req.query
      const offset = (page - 1) * pageSize
      let where = '1=1'
      if (status === 'unused') where = "status='1' AND use_count < max_uses"
      else if (status === 'used') where = "status='2' OR use_count >= max_uses"
      const list = await query(`SELECT * FROM invite_codes WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM invite_codes WHERE ${where}`)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/invite/verify', async (req, res) => {
    try {
      const { code } = req.body
      if (!code) return res.json({ code: 400, msg: '请输入邀请码' })
      const rows = await query('SELECT * FROM invite_codes WHERE code=?', [code.toUpperCase()])
      if (rows.length === 0) return res.json({ code: 400, msg: '邀请码不存在' })
      const inv = rows[0]
      if (inv.status !== '1') return res.json({ code: 400, msg: '邀请码已失效' })
      if (inv.use_count >= inv.max_uses) return res.json({ code: 400, msg: '邀请码已被使用' })
      if (inv.expires_at && new Date(inv.expires_at) < new Date()) return res.json({ code: 400, msg: '邀请码已过期' })
      res.json({ code: 200, data: { valid: true, code: inv.code }, msg: '邀请码有效' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/invite/use', async (req, res) => {
    try {
      const { code, userId, userName } = req.body
      if (!code || !userId) return res.json({ code: 400, msg: '参数不完整' })
      const rows = await query('SELECT * FROM invite_codes WHERE code=?', [code.toUpperCase()])
      if (rows.length === 0) return res.json({ code: 400, msg: '邀请码不存在' })
      const inv = rows[0]
      if (inv.use_count >= inv.max_uses) return res.json({ code: 400, msg: '邀请码已被使用' })
      const newCount = inv.use_count + 1
      const newStatus = newCount >= inv.max_uses ? '2' : '1'

      let invitedList = []
      try { invitedList = JSON.parse(inv.invited_users || '[]') } catch { invitedList = [] }
      invitedList.push({ userId, userName: userName || '', time: new Date().toISOString() })

      await query(
        'UPDATE invite_codes SET use_count=?, status=?, used_by=?, used_by_name=?, used_at=NOW(), invited_users=? WHERE id=?',
        [newCount, newStatus, userId, userName || '', JSON.stringify(invitedList), inv.id]
      )

      if (inv.reward_type && inv.reward_value) {
        const rewards = JSON.parse(inv.reward_value)
        if (rewards.points && rewards.points > 0) {
          await query('UPDATE users SET points=points+? WHERE id=?', [rewards.points, userId])
          await query("INSERT INTO points_records (user_id, user_name, type, points, source, description) VALUES (?,?,?,?,?,?)",
            [userId, userName || '', 'earn', rewards.points, '邀请奖励', '邀请码注册奖励'])
        }
        if (rewards.balance && rewards.balance > 0) {
          await query('UPDATE users SET balance=balance+? WHERE id=?', [rewards.balance, userId])
          await query("INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,?,?, (SELECT balance FROM users WHERE id=?), ?, ?)",
            [userId, userName || '', 'earn', rewards.balance, userId, '邀请奖励', '邀请码使用奖励'])
        }
        if (rewards.exp && rewards.exp > 0) {
          await query('UPDATE users SET experience=experience+? WHERE id=?', [rewards.exp, userId])
        }
        if (rewards.levelId && rewards.levelId > 0) {
          const lvs = await query('SELECT id, name FROM membership_levels WHERE id=?', [rewards.levelId])
          if (lvs.length) {
            const duration = inv.reward_duration || 30
            const expireDate = new Date(Date.now() + duration * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
              [rewards.levelId, lvs[0].name, expireDate, userId])
          }
        }
      }

      if (inv.created_by > 0) {
        await query('UPDATE users SET points=points+10 WHERE id=?', [inv.created_by])
        await query("INSERT INTO points_records (user_id, user_name, type, points, source, description) VALUES (?,?,?,?,?,?)",
          [inv.created_by, inv.created_by_name || '', 'earn', 10, '邀请奖励', '邀请用户注册奖励'])
        await progressTasksByAction(inv.created_by, inv.created_by_name || '', 'invite')
      }
      await progressTasksByAction(userId, userName || '', 'invite')
      res.json({ code: 200, msg: '邀请码使用成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/invite/required', async (req, res) => {
    try {
      const cnt = await query("SELECT COUNT(*) as total FROM invite_codes WHERE status='1' AND use_count < max_uses")
      res.json({ code: 200, data: { required: cnt[0].total > 0, availableCount: cnt[0].total } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/invite/config', async (req, res) => {
    try {
      const keys = ['invite_user_enabled', 'invite_user_max', 'invite_user_max_uses', 'register_invite_required']
      const placeholders = keys.map(() => '?').join(',')
      const rows = await query(`SELECT config_key, config_value FROM sys_config WHERE config_key IN (${placeholders})`, keys)
      const config = {}
      for (const r of rows) config[r.config_key] = r.config_value
      res.json({ code: 200, data: config })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 保存基本邀请码配置（管理员）
  app.post('/api/invite/config/save', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { invite_user_max, invite_user_max_uses } = req.body
      if (invite_user_max !== undefined) {
        await upsertConfig('invite_user_max', String(Math.max(1, parseInt(invite_user_max) || 5)))
      }
      if (invite_user_max_uses !== undefined) {
        await upsertConfig('invite_user_max_uses', String(Math.max(1, parseInt(invite_user_max_uses) || 10)))
      }
      res.json({ code: 200, msg: '配置已保存' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  async function upsertConfig(key, value) {
    const existing = await query('SELECT id FROM sys_config WHERE config_key=?', [key])
    if (existing.length) {
      await query("UPDATE sys_config SET config_value=?, update_time=NOW() WHERE config_key=?", [value, key])
    } else {
      await query('INSERT INTO sys_config (config_key, config_value) VALUES (?,?)', [key, value])
    }
  }

  // 获取用户生成邀请码的配置（公开接口，前端调用）
  app.get('/api/invite/generate-config', async (req, res) => {
    try {
      const rows = await query("SELECT config_value FROM sys_config WHERE config_key='invite_user_cost_config'")
      let config = {}
      if (rows.length && rows[0].config_value) {
        try { config = JSON.parse(rows[0].config_value) } catch {}
      }
      // 获取会员等级列表（含折扣率）
      const levels = await query("SELECT id, name, discount_rate FROM membership_levels WHERE status='1' ORDER BY id")
      // 如果 VIP 折扣开启，从对应会员等级读取折扣率
      if (config.vipDiscount && config.vipDiscount.enabled && config.vipDiscount.levelId) {
        const lv = levels.find(l => l.id === config.vipDiscount.levelId)
        config.vipDiscountRate = lv ? (Number(lv.discount_rate) || 1) : 1
      }
      res.json({ code: 200, data: { ...config, membershipLevels: levels, vipDiscountRate: config.vipDiscountRate } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // 保存用户生成邀请码的配置（管理员）
  app.post('/api/invite/generate-config/save', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const config = req.body
      if (!config || typeof config !== 'object') return res.json({ code: 400, msg: '配置数据无效' })

      const existing = await query("SELECT id FROM sys_config WHERE config_key='invite_user_cost_config'")
      if (existing.length) {
        await query("UPDATE sys_config SET config_value=?, update_time=NOW() WHERE config_key='invite_user_cost_config'",
          [JSON.stringify(config)])
      } else {
        await query("INSERT INTO sys_config (config_key, config_value) VALUES (?,?)",
          ['invite_user_cost_config', JSON.stringify(config)])
      }
      res.json({ code: 200, msg: '配置已保存' })
    } catch (e) { res.json({ code: 500, msg: '保存失败: ' + e.message }) }
  })

  // 获取会员等级列表（用于配置管理）
  app.get('/api/invite/membership-levels', async (req, res) => {
    try {
      const levels = await query("SELECT id, name, discount_rate FROM membership_levels WHERE status='1' ORDER BY id")
      res.json({ code: 200, data: levels })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/invite/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      await query('DELETE FROM invite_codes WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.delete('/api/invite/my/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      await query('DELETE FROM invite_codes WHERE id=? AND created_by_user_id=?', [Number(req.params.id), userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ========== 邀请排行榜 ==========
  app.get('/api/invite/ranking', async (req, res) => {
    try {
      const sortBy = req.query.sortBy || 'inviteCount'
      const period = req.query.period || 'all'

      let dateFilter = ''
      if (period === 'today') {
        dateFilter = ' AND u.create_time >= CURDATE()'
      } else if (period === 'week') {
        dateFilter = ' AND u.create_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)'
      } else if (period === 'month') {
        dateFilter = ' AND u.create_time >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)'
      }

      let orderBy = 'inviteCount DESC'
      if (sortBy === 'commission') orderBy = 'commission DESC'
      else if (sortBy === 'overall') orderBy = '(inviteCount + commission) DESC'

      const ranking = await query(
        `SELECT
           inviter.id as userId,
           inviter.username as userName,
           inviter.avatar,
           COUNT(invited.id) as inviteCount,
           COALESCE(SUM(cr.amount), 0) as commission,
           (COUNT(invited.id) + COALESCE(SUM(cr.amount), 0) * 0.5) as overallScore
         FROM users inviter
          LEFT JOIN users invited ON invited.referrer_id = inviter.id${dateFilter}
         LEFT JOIN commission_records cr ON cr.referrer_id = inviter.id
         WHERE inviter.status='1'
         GROUP BY inviter.id, inviter.username, inviter.avatar
         HAVING inviteCount > 0
         ORDER BY ${orderBy}
         LIMIT 10`
      )

      const overview = await query(
        `SELECT
           COUNT(DISTINCT inviter.id) as activeInviterCount,
           COUNT(invited.id) as totalInvites,
           COALESCE(SUM(cr.amount), 0) as totalCommission
         FROM users inviter
          LEFT JOIN users invited ON invited.referrer_id = inviter.id
         LEFT JOIN commission_records cr ON cr.referrer_id = inviter.id
         WHERE inviter.status='1'`
      )

      const activeInviterCount = Number(overview[0]?.activeInviterCount || 0)
      const totalInvites = Number(overview[0]?.totalInvites || 0)
      const totalCommission = Number(overview[0]?.totalCommission || 0)
      const totalUsers = await query('SELECT COUNT(*) as cnt FROM users WHERE status=\'1\'')
      const conversionRate = Number(totalUsers[0]?.cnt || 0) > 0
        ? Math.round((totalInvites / Number(totalUsers[0].cnt)) * 100)
        : 0

      res.json({
        code: 200, msg: 'success', data: {
          ranking,
          overview: { totalInvites, totalCommission: totalCommission.toFixed(2), activeInviterCount, conversionRate }
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}
