const { query } = require('../database.cjs')
const { sessions } = require('./system.cjs')
const { executePenalty } = require('./custom-task.cjs')

function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (!session || !session.userId) return 0
  return session.userId
}

function authRequired(req, res, next) {
  if (!getUserId(req)) return res.status(401).json({ code: 401, msg: '请先登录' })
  req.userId = getUserId(req)
  next()
}

module.exports = function (app) {

  app.post('/api/community/vote/submit', authRequired, async (req, res) => {
    try {
      const { postId, optionIndex } = req.body
      const userId = req.userId

      if (postId == null || optionIndex == null) {
        return res.json({ code: 400, msg: '参数不完整' })
      }

      const postRows = await query('SELECT content FROM community_posts WHERE id=?', [Number(postId)])
      if (!postRows.length) return res.json({ code: 404, msg: '帖子不存在' })

      let voteData = null
      try {
        const parsed = JSON.parse(postRows[0].content || '{}')
        if (parsed.type === 'doc' && Array.isArray(parsed.content)) {
          for (const node of parsed.content) {
            if (node.type === 'voteCard') {
              voteData = node.attrs || {}
              break
            }
          }
        }
      } catch (_) {}

      if (!voteData) return res.json({ code: 400, msg: '该帖子不包含投票' })

      let options = []
      try {
        options = typeof voteData.options === 'string' ? JSON.parse(voteData.options) : (voteData.options || [])
      } catch { options = [] }

      if (Number(optionIndex) < 0 || Number(optionIndex) >= options.length) {
        return res.json({ code: 400, msg: '选项不存在' })
      }

      let voteRows = await query('SELECT id FROM community_votes WHERE post_id=?', [Number(postId)])
      let voteId

      if (!voteRows.length) {
        const result = await query(
          'INSERT INTO community_votes (post_id, question, options, max_select) VALUES (?,?,?,?)',
          [Number(postId), voteData.question || '', JSON.stringify(options), voteData.maxSelect || 1]
        )
        voteId = result.insertId
      } else {
        voteId = voteRows[0].id
      }

      const existing = await query(
        'SELECT id FROM community_vote_records WHERE vote_id=? AND user_id=? AND option_index=?',
        [voteId, userId, Number(optionIndex)]
      )
      if (existing.length) {
        executePenalty(userId, '', 'vote_cheat', {})
        return res.json({ code: 400, msg: '你已经投过此选项了' })
      }

      const maxSelect = voteData.maxSelect || 1
      const userVoteCount = await query(
        'SELECT COUNT(*) as cnt FROM community_vote_records WHERE vote_id=? AND user_id=?',
        [voteId, userId]
      )
      if (userVoteCount[0].cnt >= maxSelect) {
        return res.json({ code: 400, msg: '最多只能选' + maxSelect + '项' })
      }

      await query('INSERT INTO community_vote_records (vote_id, user_id, option_index) VALUES (?,?,?)',
        [voteId, userId, Number(optionIndex)])
      await query('UPDATE community_votes SET total_votes=total_votes+1 WHERE id=?', [voteId])

      res.json({ code: 200, msg: '投票成功' })
    } catch (err) {
      console.error('Vote submit error:', err)
      res.json({ code: 500, msg: '投票失败' })
    }
  })

  app.get('/api/community/vote/result/:postId', async (req, res) => {
    try {
      const postId = Number(req.params.postId)

      const voteRows = await query('SELECT * FROM community_votes WHERE post_id=?', [postId])
      if (!voteRows.length) return res.json({ code: 200, data: { options: [], results: [], total: 0 } })

      const v = voteRows[0]
      let options = []
      try { options = typeof v.options === 'string' ? JSON.parse(v.options) : (v.options || []) } catch {}

      const records = await query(
        'SELECT option_index, COUNT(*) as count FROM community_vote_records WHERE vote_id=? GROUP BY option_index',
        [v.id]
      )

      const resultMap = {}
      records.forEach(r => { resultMap[r.option_index] = r.count })

      const results = options.map((opt, idx) => ({
        index: idx,
        text: opt,
        count: resultMap[idx] || 0
      }))

      res.json({
        code: 200,
        data: {
          question: v.question,
          options: results,
          total: v.total_votes,
          maxSelect: v.max_select
        }
      })
    } catch (err) {
      console.error('Vote result error:', err)
      res.json({ code: 500, msg: '获取投票结果失败' })
    }
  })

  app.get('/api/community/vote/my/:postId', authRequired, async (req, res) => {
    try {
      const postId = Number(req.params.postId)
      const userId = req.userId

      const voteRows = await query('SELECT id FROM community_votes WHERE post_id=?', [postId])
      if (!voteRows.length) return res.json({ code: 200, data: [] })

      const records = await query(
        'SELECT option_index FROM community_vote_records WHERE vote_id=? AND user_id=?',
        [voteRows[0].id, userId]
      )

      res.json({ code: 200, data: records.map(r => r.option_index) })
    } catch (err) {
      console.error('My votes error:', err)
      res.json({ code: 500, msg: '获取失败' })
    }
  })

  // ========== 独立投票 ==========

  function autoCloseExpiredVotes() {
    query("UPDATE standalone_votes SET status='closed' WHERE status='active' AND end_time IS NOT NULL AND end_time < NOW()").catch(() => {})
    query("UPDATE community_votes SET status='closed' WHERE status='active' AND end_time IS NOT NULL AND end_time < NOW()").catch(() => {})
  }

  // GET /api/votes - 列出活跃投票（自动关闭过期）
  app.get('/api/votes', async (req, res) => {
    try {
      await autoCloseExpiredVotes()
      const { page = 1, pageSize = 20 } = req.query
      const offset = (Number(page) - 1) * Number(pageSize)
      const [list, cnt] = await Promise.all([
        query('SELECT * FROM standalone_votes ORDER BY create_time DESC LIMIT ? OFFSET ?', [Number(pageSize), offset]),
        query('SELECT COUNT(*) as total FROM standalone_votes')
      ])
      res.json({ code: 200, data: { list, total: cnt[0].total, page: Number(page), pageSize: Number(pageSize) } })
    } catch (err) {
      res.json({ code: 500, msg: '获取投票失败' })
    }
  })

  // GET /api/votes/:id - 投票详情（带计数）
  app.get('/api/votes/:id', async (req, res) => {
    try {
      await autoCloseExpiredVotes()
      const rows = await query('SELECT * FROM standalone_votes WHERE id=?', [Number(req.params.id)])
      if (!rows.length) return res.json({ code: 404, msg: '投票不存在' })
      const v = rows[0]
      let options = []
      try { options = typeof v.options === 'string' ? JSON.parse(v.options) : (v.options || []) } catch {}

      const records = await query(
        'SELECT option_index, COUNT(*) as count FROM standalone_vote_records WHERE vote_id=? GROUP BY option_index',
        [v.id]
      )
      const resultMap = {}
      records.forEach(r => { resultMap[r.option_index] = r.count })

      const results = options.map((opt, idx) => ({
        index: idx,
        text: opt,
        count: resultMap[idx] || 0
      }))

      res.json({
        code: 200,
        data: { id: v.id, title: v.title, options: results, maxSelect: v.max_select, endTime: v.end_time, status: v.status, totalVotes: v.total_votes }
      })
    } catch (err) {
      res.json({ code: 500, msg: '获取投票详情失败' })
    }
  })

  // POST /api/votes - 创建独立投票
  app.post('/api/votes', authRequired, async (req, res) => {
    try {
      const { title, options, maxSelect = 1, endTime } = req.body
      if (!title || !options || !Array.isArray(options) || options.length < 2) {
        return res.json({ code: 400, msg: '标题和至少两个选项不能为空' })
      }
      const result = await query(
        'INSERT INTO standalone_votes (title, options, max_select, end_time, create_by) VALUES (?, ?, ?, ?, ?)',
        [title, JSON.stringify(options), maxSelect, endTime || null, req.userId]
      )
      res.json({ code: 200, msg: '投票创建成功', data: { id: result.insertId } })
    } catch (err) {
      res.json({ code: 500, msg: '创建失败' })
    }
  })

  // POST /api/votes/:id/close - 手动关闭
  app.post('/api/votes/:id/close', authRequired, async (req, res) => {
    try {
      await query("UPDATE standalone_votes SET status='closed' WHERE id=? AND status='active'", [Number(req.params.id)])
      res.json({ code: 200, msg: '投票已关闭' })
    } catch (err) {
      res.json({ code: 500, msg: '关闭失败' })
    }
  })

  // POST /api/votes/:id/vote - 独立投票提交
  app.post('/api/votes/:id/vote', authRequired, async (req, res) => {
    try {
      const voteId = Number(req.params.id)
      const userId = req.userId
      const { optionIndex } = req.body

      const votes = await query("SELECT * FROM standalone_votes WHERE id=? AND status='active'", [voteId])
      if (!votes.length) return res.json({ code: 400, msg: '投票不存在或已关闭' })

      const v = votes[0]
      if (v.end_time && new Date(v.end_time) < new Date()) return res.json({ code: 400, msg: '投票已过期' })

      let options = []
      try { options = typeof v.options === 'string' ? JSON.parse(v.options) : (v.options || []) } catch {}

      if (Number(optionIndex) < 0 || Number(optionIndex) >= options.length) {
        return res.json({ code: 400, msg: '选项不存在' })
      }

      const maxSelect = v.max_select || 1
      const userVoteCount = await query('SELECT COUNT(*) as cnt FROM standalone_vote_records WHERE vote_id=? AND user_id=?', [voteId, userId])
      if (userVoteCount[0].cnt >= maxSelect) return res.json({ code: 400, msg: '最多只能选' + maxSelect + '项' })

      const result = await query('INSERT IGNORE INTO standalone_vote_records (vote_id, user_id, option_index) VALUES (?,?,?)', [voteId, userId, Number(optionIndex)])
      if (result.changes) {
        await query('UPDATE standalone_votes SET total_votes=total_votes+1 WHERE id=?', [voteId])
      }

      res.json({ code: 200, msg: '投票成功' })
    } catch (err) {
      res.json({ code: 500, msg: '投票失败' })
    }
  })
}
