const { query, getSystemOperator } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { progressTasksByAction } = require('./custom-task.cjs')
const { systemLog } = require('../middleware/security.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isCheckinEnabled() {
  try {
    const rows = await query("SELECT config_value FROM sys_config WHERE config_key='checkin_enabled'")
    if (rows.length > 0) return rows[0].config_value === 'true'
  } catch {}
  return true
}

async function getUserCheckinGroup(userLevelId) {
  const groups = await query('SELECT * FROM checkin_groups WHERE status=? ORDER BY sort_order ASC, id ASC', ['1'])
  if (!groups.length) return null
  const matched = groups.find(g => Number(g.level_id) === Number(userLevelId))
  return matched || groups[0]
}

function calcRewardFromGroup(group, consecutiveDays) {
  const base = { points: group.points || 0, experience: group.experience || 0, balance: Number(group.balance) || 0 }
  const bonus = {
    points: Math.min(consecutiveDays - 1, 30) * (group.points_consecutive || 0),
    experience: Math.min(consecutiveDays - 1, 30) * (group.experience_consecutive || 0),
    balance: Math.min(consecutiveDays - 1, 30) * Number(group.balance_consecutive || 0)
  }
  return {
    points: base.points + bonus.points,
    experience: base.experience + bonus.experience,
    balance: base.balance + bonus.balance
  }
}

async function getMilestoneRewards(groupId, consecutiveDays) {
  const milestones = await query(
    'SELECT * FROM checkin_milestones WHERE group_id=? AND days=? AND status=? ORDER BY sort_order',
    [groupId, consecutiveDays, '1']
  )
  return milestones
}

async function applyMilestoneRewards(userId, userName, groupId, consecutiveDays) {
  const milestones = await getMilestoneRewards(groupId, consecutiveDays)
  const rewards = { points: 0, experience: 0, balance: 0, cardKeys: [] }

  for (const m of milestones) {
    rewards.points += m.points || 0
    rewards.experience += m.experience || 0
    rewards.balance += Number(m.balance) || 0

    if (m.card_key_type && m.card_key_value) {
      const ts = Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase()
      const cardNo = `SIGN-${ts}`
      const pwd = Math.random().toString(36).substring(2, 10).toUpperCase()

      let targetName = ''
      let targetId = 0
      if (m.card_key_type === 'membership') {
        const lvs = await query('SELECT name FROM membership_levels WHERE id=?', [m.card_key_value])
        targetName = lvs.length > 0 ? lvs[0].name : '会员'
        targetId = m.card_key_value
      } else if (m.card_key_type === 'points') {
        targetName = `${m.card_key_value}积分`
      } else if (m.card_key_type === 'experience') {
        targetName = `${m.card_key_value}经验值`
      } else if (m.card_key_type === 'balance') {
        targetName = `${m.card_key_value}元余额`
      } else if (m.card_key_type === 'makeup') {
        targetName = `补签${m.card_key_value}天`
      }

      await query(
        `INSERT INTO card_keys (card_no, password, type, target_id, target_name, value,
         extra_points, extra_experience, extra_balance, duration, duration_unit, status, create_by)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,'0','签到奖励')`,
        [cardNo, pwd, m.card_key_type, targetId, targetName, m.card_key_value,
         m.card_key_extra_points || 0, m.card_key_extra_experience || 0, Number(m.card_key_extra_balance) || 0,
         m.card_key_duration || 0, m.card_key_duration_unit || '']
      )

      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?,?,'system',?, 0, ?, '')`,
        [`签到${consecutiveDays}天阶梯奖励`, `恭喜！连续签到${consecutiveDays}天，获得卡密：${cardNo}（${targetName}），密码：${pwd}`, userId, sysOpName]
      )

      rewards.cardKeys.push({ cardNo, password: pwd, type: m.card_key_type, targetName })
    }
  }

  return rewards
}

module.exports = function checkinRoutes(app) {
  // ==================== 签到 ====================

  app.post('/api/checkin', authRequired, async (req, res) => {
    try {
      const enabled = await isCheckinEnabled()
      if (!enabled) return res.json({ code: 400, message: '签到功能暂未开放' })

      const userId = await getUserId(req)
      const today = new Date().toISOString().substring(0, 10)
      const existing = await query('SELECT id FROM checkin_records WHERE user_id=? AND checkin_date=?', [userId, today])
      if (existing.length > 0) return res.json({ code: 400, message: '今日已签到' })

      const user = await query(
        'SELECT username, points, experience, balance, level_id, last_checkin_date, consecutive_checkins FROM users WHERE id=?',
        [userId]
      )
      if (user.length === 0) return res.json({ code: 404, message: '用户不存在' })

      const yesterday = new Date(Date.now() - 86400000).toISOString().substring(0, 10)
      const lastDate = user[0].last_checkin_date
      let consecutive = user[0].consecutive_checkins || 0
      if (lastDate === yesterday) { consecutive += 1 }
      else if (lastDate === today) { /* 不应到达 */ }
      else { consecutive = 1 }

      const group = await getUserCheckinGroup(user[0].level_id || 0)
      if (!group) return res.json({ code: 400, message: '签到配置未设置' })

      const reward = calcRewardFromGroup(group, consecutive)
      const milestoneRewards = await applyMilestoneRewards(userId, user[0].username, group.id, consecutive)

      const totalPoints = reward.points + milestoneRewards.points
      const totalExp = reward.experience + milestoneRewards.experience
      const totalBalance = reward.balance + milestoneRewards.balance

      await query('INSERT INTO checkin_records (user_id, user_name, checkin_date, consecutive_days, points_earned, experience_earned) VALUES (?,?,?,?,?,?)',
        [userId, user[0].username, today, consecutive, totalPoints, totalExp])

      await query('UPDATE users SET points=points+?, experience=experience+?, balance=balance+?, last_checkin_date=?, consecutive_checkins=? WHERE id=?',
        [totalPoints, totalExp, totalBalance, today, consecutive, userId])

      if (totalPoints > 0) {
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'earn',?, (SELECT points FROM users WHERE id=?), '每日签到', ?)`,
          [userId, user[0].username, totalPoints, userId, `连续签到第${consecutive}天`])
      }
      if (totalBalance > 0) {
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '每日签到', ?)`,
          [userId, user[0].username, totalBalance, userId, `连续签到第${consecutive}天`])
      }

      const hasMilestone = milestoneRewards.points > 0 || milestoneRewards.experience > 0 || milestoneRewards.balance > 0 || milestoneRewards.cardKeys.length > 0
      if (hasMilestone) {
        const sysOpName = (await getSystemOperator())?.username || '管理员'
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
           VALUES (?,?,'system',?, 0, ?, '')`,
          [`连续签到${consecutive}天达成`, `恭喜！连续签到${consecutive}天，获得阶梯奖励！积分+${milestoneRewards.points}，经验+${milestoneRewards.experience}，余额+${milestoneRewards.balance}`, userId, sysOpName]
        )
      }

      await progressTasksByAction(userId, user[0].username, 'checkin')
      res.json({
        code: 200, message: '签到成功',
        data: {
          consecutive,
          pointsEarned: totalPoints,
          experienceEarned: totalExp,
          balanceEarned: totalBalance,
          milestoneRewards: milestoneRewards.cardKeys.map(c => ({ cardNo: c.cardNo, type: c.type, targetName: c.targetName }))
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ==================== 补签 ====================

  app.post('/api/checkin/makeup', authRequired, async (req, res) => {
    try {
      const enabled = await isCheckinEnabled()
      if (!enabled) return res.json({ code: 400, message: '签到功能暂未开放' })

      const userId = await getUserId(req)
      const { cardNo, password } = req.body
      if (!cardNo || !password) return res.json({ code: 400, message: '请输入补签卡号和密码' })

      const cards = await query(
        'SELECT id, type, value, target_id, target_name, status FROM card_keys WHERE card_no=? AND password=? AND type=?',
        [cardNo, password, 'makeup']
      )
      if (!cards || cards.length === 0) return res.json({ code: 404, message: '补签卡不存在或密码错误，或卡密类型不是补签卡' })
      const card = cards[0]
      if (card.status === '1') return res.json({ code: 400, message: '该补签卡已被使用' })

      const makeupDays = card.value || 1
      const user = await query(
        'SELECT username, last_checkin_date, consecutive_checkins FROM users WHERE id=?',
        [userId]
      )
      if (user.length === 0) return res.json({ code: 404, message: '用户不存在' })

      const today = new Date()
      const todayStr = today.toISOString().substring(0, 10)
      const lastDate = user[0].last_checkin_date
      let consecutive = user[0].consecutive_checkins || 0
      let madeUpCount = 0

      for (let i = 1; i <= makeupDays; i++) {
        const checkDate = new Date(today)
        checkDate.setDate(checkDate.getDate() - i)
        const checkDateStr = checkDate.toISOString().substring(0, 10)

        if (checkDateStr === lastDate) break
        const alreadyChecked = await query('SELECT id FROM checkin_records WHERE user_id=? AND checkin_date=?', [userId, checkDateStr])
        if (alreadyChecked.length > 0) continue

        await query('INSERT INTO checkin_records (user_id, user_name, checkin_date, consecutive_days, points_earned, experience_earned) VALUES (?,?,?,?,?,?)',
          [userId, user[0].username, checkDateStr, 0, 0, 0])
        madeUpCount++
      }

      if (madeUpCount > 0) {
        consecutive += madeUpCount
        await query('UPDATE users SET last_checkin_date=?, consecutive_checkins=? WHERE id=?',
          [todayStr, consecutive, userId])
      }

      await query(
        `UPDATE card_keys SET status='1', redeem_by=?, redeem_time=NOW() WHERE id=?`,
        [user[0].username, card.id]
      )

      const sysOpName = (await getSystemOperator())?.username || '管理员'
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar)
         VALUES (?,?,'system',?, 0, ?, '')`,
        ['补签成功', `您使用补签卡成功补签${madeUpCount}天，当前连续签到${consecutive}天`, userId, sysOpName]
      )

      res.json({ code: 200, message: `补签成功，补签${madeUpCount}天`, data: { madeUpCount, consecutive } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ==================== 查询接口 ====================

  app.get('/api/checkin/status', authRequired, async (req, res) => {
    try {
      const enabled = await isCheckinEnabled()
      const userId = await getUserId(req)
      const today = new Date().toISOString().substring(0, 10)
      const checked = await query('SELECT id, consecutive_days, points_earned, experience_earned FROM checkin_records WHERE user_id=? AND checkin_date=?', [userId, today])
      const user = await query('SELECT consecutive_checkins, level_id FROM users WHERE id=?', [userId])
      const consecutive = user.length > 0 ? user[0].consecutive_checkins : 0

      let nextReward = { points: 0, experience: 0, balance: 0 }
      let upcomingMilestones = []
      if (enabled) {
        const group = await getUserCheckinGroup(user.length > 0 ? user[0].level_id : 0)
        if (group) {
          nextReward = calcRewardFromGroup(group, consecutive + 1)
          const milestones = await query(
            'SELECT days, points, experience, balance, card_key_type, card_key_value FROM checkin_milestones WHERE group_id=? AND days>? AND status=? ORDER BY days ASC LIMIT 5',
            [group.id, consecutive, '1']
          )
          upcomingMilestones = milestones
        }
      }

      res.json({
        code: 200,
        data: {
          enabled,
          checkedToday: checked.length > 0,
          consecutive,
          todayRecord: checked.length > 0 ? checked[0] : null,
          nextReward,
          upcomingMilestones
        }
      })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/checkin/history', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { page = 1, pageSize = 31 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query('SELECT * FROM checkin_records WHERE user_id=? ORDER BY checkin_date DESC LIMIT ? OFFSET ?', [userId, parseInt(pageSize), offset])
      const cnt = await query('SELECT COUNT(*) as total FROM checkin_records WHERE user_id=?', [userId])
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ==================== 签到排行榜 ====================

  app.get('/api/checkin/ranking', async (req, res) => {
    try {
      const { month } = req.query
      const targetMonth = month || new Date().toISOString().substring(0, 7)

      const users = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.level_name as levelName,
                u.consecutive_checkins as consecutiveCheckins,
                COUNT(cr.id) as totalCheckins,
                SUM(cr.points_earned) as totalPointsEarned
         FROM users u
         LEFT JOIN checkin_records cr ON u.id = cr.user_id AND cr.checkin_date LIKE ?
         WHERE u.status = '1'
         GROUP BY u.id
         ORDER BY u.consecutive_checkins DESC, totalCheckins DESC
          LIMIT 15`,
        [targetMonth + '%']
      )

      const ranking = users.map((u, i) => ({
        rank: i + 1,
        userId: u.id,
        username: u.username,
        nickname: u.nickname || u.username,
        avatar: u.avatar,
        levelName: u.levelName || '普通会员',
        consecutiveCheckins: u.consecutiveCheckins || 0,
        totalCheckins: u.totalCheckins || 0,
        totalPointsEarned: u.totalPointsEarned || 0
      }))

      res.json({ code: 200, data: { ranking, month: targetMonth } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/checkin/enabled-status', async (req, res) => {
    try {
      const enabled = await isCheckinEnabled()
      res.json({ code: 200, data: { enabled } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/checkin/enabled-status', authRequired, requirePermission('toggle'), async (req, res) => {
    try {
      const operator = getSystemOperator(req)
      const { enabled } = req.body || {}
      await query("UPDATE sys_config SET config_value = ? WHERE config_key = 'checkin_enabled'",
        [String(enabled === true || enabled === 'true')])
      systemLog(req, 'update', '签到开关', 0, `签到功能已被${operator} ${enabled ? '启用' : '停用'}`)
      res.json({ code: 200, data: { enabled: !!enabled } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ==================== 签到日历 ====================

  app.get('/api/checkin/calendar', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const year = parseInt(req.query.year) || new Date().getFullYear()
      const month = parseInt(req.query.month) || (new Date().getMonth() + 1)
      const startDate = `${year}-${String(month).padStart(2, '0')}-01`
      const endDate = `${year}-${String(month).padStart(2, '0')}-${new Date(year, month, 0).getDate()}`

      const records = await query(
        'SELECT checkin_date, consecutive_days FROM checkin_records WHERE user_id=? AND checkin_date BETWEEN ? AND ? ORDER BY checkin_date',
        [userId, startDate, endDate]
      )
      const recordMap = {}
      records.forEach(r => { recordMap[r.checkin_date] = r.consecutive_days || 0 })

      const daysInMonth = new Date(year, month, 0).getDate()
      const calendar = []
      for (let d = 1; d <= daysInMonth; d++) {
        const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`
        calendar.push({
          date: dateStr,
          checked: !!recordMap[dateStr],
          streak: recordMap[dateStr] || 0
        })
      }

      res.json({ code: 200, data: { calendar, year, month } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ==================== 补签卡数量 ====================

  app.get('/api/checkin/makeups/available', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cards = await query(
        "SELECT COUNT(*) as cnt FROM card_keys WHERE type='makeup' AND status='0' AND create_by=?",
        [userId]
      )
      // 也可查 user_coupons / user_gift_claims 等
      res.json({ code: 200, data: { count: cards[0]?.cnt || 0 } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
