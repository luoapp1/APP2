const { query } = require('../database.cjs')

async function getBalance(userId) {
  const [row] = await query('SELECT balance, points FROM users WHERE id=?', [userId])
  return { balance: Number(row?.balance || 0), points: Number(row?.points || 0) }
}

async function deductBalance(userId, userName, amount, source, description) {
  await query('UPDATE users SET balance = ROUND(balance - ?, 2) WHERE id=?', [amount, userId])
  const { balance } = await getBalance(userId)
  await query(
    'INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,?,?,?,?,?)',
    [userId, userName, 'expense', amount, balance, source, description])
}

async function addBalance(userId, userName, amount, source, description) {
  await query('UPDATE users SET balance = ROUND(balance + ?, 2) WHERE id=?', [amount, userId])
  const { balance } = await getBalance(userId)
  await query(
    'INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,?,?,?,?,?)',
    [userId, userName, 'earn', amount, balance, source, description])
}

async function deductPoints(userId, userName, amount, source, description) {
  await query('UPDATE users SET points = points - ? WHERE id=?', [amount, userId])
  const { points } = await getBalance(userId)
  await query(
    'INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,?,?,?,?,?)',
    [userId, userName, 'expense', amount, points, source, description])
}

async function addPoints(userId, userName, amount, source, description) {
  await query('UPDATE users SET points = points + ? WHERE id=?', [amount, userId])
  const { points } = await getBalance(userId)
  await query(
    'INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,?,?,?,?,?)',
    [userId, userName, 'earn', amount, points, source, description])
}

module.exports = { deductBalance, addBalance, deductPoints, addPoints, getBalance }
