const { query, getPool } = require('../database.cjs')

function luhnChecksum(digits) {
  let sum = 0
  let alt = false
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = parseInt(digits[i])
    if (alt) { d *= 2; if (d > 9) d -= 9 }
    sum += d
    alt = !alt
  }
  return (10 - (sum % 10)) % 10
}

function generateAccountNumber(prefix) {
  let body = String(prefix)
  while (body.length < 4) body += '0'
  for (let i = 0; i < 13; i++) {
    body += Math.floor(Math.random() * 10)
  }
  return body + luhnChecksum(body)
}

function formatAccountNumber(num) {
  if (!num || num.length < 16) return num
  const n = String(num)
  return `${n.slice(0,4)}-${n.slice(4,8)}-${n.slice(8,12)}-${n.slice(12)}`
}

function db(conn) {
  return conn ? (sql, params) => conn.query(sql, params) : (sql, params) => query(sql, params)
}

async function getCurrencyBalance(userId, currencyKey, conn) {
  const q = db(conn)
  const [row] = await q(
    'SELECT available, frozen FROM user_currency_balance WHERE user_id=? AND currency_key=?',
    [userId, currencyKey]
  )
  return {
    available: Number(row?.available || 0),
    frozen: Number(row?.frozen || 0)
  }
}

async function getUserBalances(userId, conn) {
  const q = db(conn)
  const rows = await q(
    `SELECT cs.currency_key, cs.display_name, cs.display_symbol, cs.decimal_places,
            COALESCE(ucb.available, 0) as available, COALESCE(ucb.frozen, 0) as frozen,
            ucb.account_number
     FROM currency_settings cs
     LEFT JOIN user_currency_balance ucb ON ucb.currency_key = cs.currency_key AND ucb.user_id = ?
     WHERE cs.is_visible = 1
     ORDER BY cs.sort_order`,
    [userId]
  )
  return rows.map(r => ({
    currency_key: r.currency_key,
    display_name: r.display_name,
    display_symbol: r.display_symbol || '',
    decimal_places: r.decimal_places,
    available: Number(r.available || 0),
    frozen: Number(r.frozen || 0),
    total: Number(r.available || 0) + Number(r.frozen || 0),
    account_number: r.account_number ? formatAccountNumber(r.account_number) : ''
  }))
}

async function ensureBalance(userId, currencyKey, conn) {
  const q = db(conn)
  const [existing] = await q(
    'SELECT account_number FROM user_currency_balance WHERE user_id=? AND currency_key=?',
    [userId, currencyKey]
  )
  if (existing) {
    if (!existing.account_number) {
      const prefix = await getAccountPrefix(currencyKey, conn)
      const accNum = generateAccountNumber(prefix)
      await q(
        'UPDATE user_currency_balance SET account_number=? WHERE user_id=? AND currency_key=?',
        [accNum, userId, currencyKey]
      )
    }
    return
  }
  const prefix = await getAccountPrefix(currencyKey, conn)
  const accNum = generateAccountNumber(prefix)
  await q(
    'INSERT IGNORE INTO user_currency_balance (user_id, currency_key, available, frozen, account_number) VALUES (?, ?, 0, 0, ?)',
    [userId, currencyKey, accNum]
  )
}

async function getAccountPrefix(currencyKey, conn) {
  const q = db(conn)
  const [row] = await q(
    'SELECT account_prefix FROM currency_settings WHERE currency_key=?',
    [currencyKey]
  )
  if (row && row.account_prefix && /^\d{4}$/.test(row.account_prefix)) {
    return row.account_prefix
  }
  const hash = currencyKey.split('').reduce((s, c) => s + c.charCodeAt(0), 0) % 10000
  return String(8800 + hash).slice(0, 4)
}

async function writeTransaction(userId, userName, currencyKey, txType, amount, balanceBefore, balanceAfter, sourceType, sourceId, description, conn) {
  const q = db(conn)
  return q(
    `INSERT INTO currency_transactions (user_id,user_name,currency_key,tx_type,amount,balance_before,balance_after,source_type,source_id,description)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [userId, userName || '', currencyKey, txType, amount, balanceBefore, balanceAfter, sourceType || '', sourceId || '', description || '']
  )
}

async function earnCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  if (sourceType === 'transfer') {
    const [cs] = await db(conn)('SELECT currency_type FROM currency_settings WHERE currency_key=?', [currencyKey])
    if (cs && cs.currency_type === 'quota') throw new Error(`${currencyKey} 是次数配额，不支持转账`)
  }
  await ensureBalance(userId, currencyKey, conn)
  const before = await getCurrencyBalance(userId, currencyKey, conn)
  const q = db(conn)
  await q(
    'UPDATE user_currency_balance SET available = available + ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ?',
    [amount, userId, currencyKey]
  )
  const after = await getCurrencyBalance(userId, currencyKey, conn)
  await writeTransaction(userId, userName, currencyKey, 'earn', amount, before.available, after.available, sourceType, sourceId, description, conn)
  return after
}
async function spendCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  if (sourceType === 'transfer') {
    const [cs] = await db(conn)('SELECT currency_type FROM currency_settings WHERE currency_key=?', [currencyKey])
    if (cs && cs.currency_type === 'quota') throw new Error(`${currencyKey} 是次数配额，不支持转账`)
  }
  await ensureBalance(userId, currencyKey, conn)
  const q = db(conn)
  const result = await q(
    'UPDATE user_currency_balance SET available = available - ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ? AND available - frozen >= ?',
    [amount, userId, currencyKey, amount]
  )
  if (!result.changes) {
    const bal = await getCurrencyBalance(userId, currencyKey, conn)
    throw new Error(`${currencyKey} 余额不足 (可用: ${bal.available}, 冻结: ${bal.frozen})`)
  }
  const after = await getCurrencyBalance(userId, currencyKey, conn)
  const before = { available: Number(after.available) + Number(amount) }
  await writeTransaction(userId, userName, currencyKey, 'spend', amount, before.available, after.available, sourceType, sourceId, description, conn)
  return after
}
async function spendCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  await ensureBalance(userId, currencyKey, conn)
  const q = db(conn)
  const result = await q(
    'UPDATE user_currency_balance SET available = available - ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ? AND available - frozen >= ?',
    [amount, userId, currencyKey, amount]
  )
  if (!result.changes) {
    const bal = await getCurrencyBalance(userId, currencyKey, conn)
    throw new Error(`${currencyKey} 余额不足 (可用: ${bal.available}, 冻结: ${bal.frozen})`)
  }
  const after = await getCurrencyBalance(userId, currencyKey, conn)
  const before = { available: Number(after.available) + Number(amount) }
  await writeTransaction(userId, userName, currencyKey, 'spend', amount, before.available, after.available, sourceType, sourceId, description, conn)
  return after
}

async function adminAdjustCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  await ensureBalance(userId, currencyKey, conn)
  const before = await getCurrencyBalance(userId, currencyKey, conn)
  const q = db(conn)
  if (amount >= 0) {
    await q(
      'UPDATE user_currency_balance SET available = available + ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ?',
      [amount, userId, currencyKey]
    )
  } else {
    const absAmount = Math.abs(amount)
    const result = await q(
      'UPDATE user_currency_balance SET available = available - ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ? AND available - frozen >= ?',
      [absAmount, userId, currencyKey, absAmount]
    )
    if (!result.changes) throw new Error('扣除后可用余额不足')
  }
  const after = await getCurrencyBalance(userId, currencyKey, conn)
  const txType = 'admin_adjust'
  await writeTransaction(userId, userName, currencyKey, txType, Math.abs(amount), before.available, after.available, sourceType || 'admin', sourceId || '', description || '管理员调整', conn)
  return after
}

async function freezeCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  await ensureBalance(userId, currencyKey, conn)
  const q = db(conn)
  const result = await q(
    'UPDATE user_currency_balance SET available = available - ?, frozen = frozen + ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ? AND available >= ?',
    [amount, amount, userId, currencyKey, amount]
  )
  if (!result.changes) throw new Error('可冻结余额不足')
  const bal = await getCurrencyBalance(userId, currencyKey, conn)
  await writeTransaction(userId, userName, currencyKey, 'freeze', amount, bal.available + amount, bal.available, sourceType, sourceId, description, conn)
  return bal
}

async function unfreezeCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  await ensureBalance(userId, currencyKey, conn)
  const q = db(conn)
  const result = await q(
    'UPDATE user_currency_balance SET available = available + ?, frozen = frozen - ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ? AND frozen >= ?',
    [amount, amount, userId, currencyKey, amount]
  )
  if (!result.changes) throw new Error('解冻金额超过已冻结金额')
  const bal = await getCurrencyBalance(userId, currencyKey, conn)
  await writeTransaction(userId, userName, currencyKey, 'unfreeze', amount, bal.available - amount, bal.available, sourceType, sourceId, description, conn)
  return bal
}

async function refundCurrency(userId, userName, currencyKey, amount, sourceType, sourceId, description, conn) {
  if (!amount || amount <= 0) return
  await ensureBalance(userId, currencyKey, conn)
  const before = await getCurrencyBalance(userId, currencyKey, conn)
  const q = db(conn)
  await q(
    'UPDATE user_currency_balance SET available = available + ?, updated_at = NOW() WHERE user_id = ? AND currency_key = ?',
    [amount, userId, currencyKey]
  )
  const after = await getCurrencyBalance(userId, currencyKey, conn)
  await writeTransaction(userId, userName, currencyKey, 'refund', amount, before.available, after.available, sourceType, sourceId, description, conn)
  return after
}

// -- 向后兼容的包装函数 --

async function getBalance(userId, conn) {
  const rows = await getUserBalances(userId, conn)
  const balance = rows.find(r => r.currency_key === 'balance')
  const points = rows.find(r => r.currency_key === 'points')
  return {
    balance: balance ? balance.available : 0,
    points: points ? points.available : 0,
    currencies: rows
  }
}

async function deductBalance(userId, userName, amount, source, description, conn) {
  return spendCurrency(userId, userName, 'balance', amount, source || '', '', description, conn)
}

async function addBalance(userId, userName, amount, source, description, conn) {
  return earnCurrency(userId, userName, 'balance', amount, source || '', '', description, conn)
}

async function deductPoints(userId, userName, amount, source, description, conn) {
  return spendCurrency(userId, userName, 'points', amount, source || '', '', description, conn)
}

async function addPoints(userId, userName, amount, source, description, conn) {
  return earnCurrency(userId, userName, 'points', amount, source || '', '', description, conn)
}

async function deductExperience(userId, userName, amount, source, description, taskId, conn) {
  return spendCurrency(userId, userName, 'experience', amount, source || '', taskId ? String(taskId) : '', description, conn)
}

async function addExperience(userId, userName, amount, source, description, taskId, conn) {
  return earnCurrency(userId, userName, 'experience', amount, source || '', taskId ? String(taskId) : '', description, conn)
}

async function addCurrency(userId, userName, currencyKey, amount, source, description, conn) {
  return earnCurrency(userId, userName, currencyKey, amount, source || '', '', description, conn)
}

async function deductCurrency(userId, userName, currencyKey, amount, source, description, conn) {
  return spendCurrency(userId, userName, currencyKey, amount, source || '', '', description, conn)
}

module.exports = {
  earnCurrency,
  spendCurrency,
  adminAdjustCurrency,
  freezeCurrency,
  unfreezeCurrency,
  refundCurrency,
  getCurrencyBalance,
  getUserBalances,
  writeTransaction,
  ensureBalance,
  formatAccountNumber,
  deductBalance,
  addBalance,
  deductPoints,
  addPoints,
  deductExperience,
  addExperience,
  addCurrency,
  deductCurrency,
  getBalance
}
