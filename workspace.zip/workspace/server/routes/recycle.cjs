const { query } = require('../database.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  return false
}

module.exports = function recycleRoutes(app) {
  app.post('/api/recycle/trash', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { table, id, reason } = req.body
      if (!table || !id) return res.json({ code: 400, message: '参数不完整' })
      const row = await query(`SELECT * FROM \`${table}\` WHERE id=?`, [id])
      if (row.length === 0) return res.json({ code: 404, message: '记录不存在' })
      const uid = await getUserId(req)
      const userRows = await query('SELECT level_id FROM users WHERE id=?', [uid])
      const userLevelId = userRows[0]?.level_id || 0
      await query('INSERT INTO recycle_bin (original_table, original_id, data_json, deleted_by, deleted_by_name, delete_reason, user_level_id) VALUES (?,?,?,?,?,?,?)',
        [table, id, JSON.stringify(row[0]), uid, '管理员', reason || '', userLevelId])
      res.json({ code: 200, message: '已放入回收站' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/recycle/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { page = 1, pageSize = 20, table } = req.query
      const offset = (page - 1) * pageSize

      // Auto-delete expired items based on membership level retention days
      await query(
        `DELETE rb FROM recycle_bin rb
         LEFT JOIN membership_levels ml ON ml.id = rb.user_level_id
         WHERE ml.recycle_retention_days > 0
           AND rb.create_time < DATE_SUB(NOW(), INTERVAL ml.recycle_retention_days DAY)`
      )

      let where = '1=1'
      const params = []
      if (table) { where += ' AND original_table=?'; params.push(table) }
      const list = await query(`SELECT * FROM recycle_bin WHERE ${where} ORDER BY create_time DESC LIMIT ? OFFSET ?`, [...params, parseInt(pageSize), offset])
      const cnt = await query(`SELECT COUNT(*) as total FROM recycle_bin WHERE ${where}`, params)
      res.json({ code: 200, data: { list, total: cnt[0].total } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/recycle/restore/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rb = await query('SELECT * FROM recycle_bin WHERE id=?', [req.params.id])
      if (rb.length === 0) return res.json({ code: 404, message: '回收站记录不存在' })
      const { original_table, data_json } = rb[0]
      const data = JSON.parse(data_json)
      const columns = Object.keys(data).filter(k => k !== 'id')
      const placeholders = columns.map(() => '?').join(',')
      const values = columns.map(k => data[k])
      await query(`INSERT INTO \`${original_table}\` (${columns.map(c => `\`${c}\``).join(',')}) VALUES (${placeholders})`, values)
      await query('DELETE FROM recycle_bin WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '恢复成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/recycle/:id', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM recycle_bin WHERE id=?', [req.params.id])
      res.json({ code: 200, message: '已永久删除' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/recycle/clear', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM recycle_bin')
      res.json({ code: 200, message: '回收站已清空' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}
