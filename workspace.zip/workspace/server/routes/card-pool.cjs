const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

function cardPoolRoutes(router) {
  const prefix = '/api/admin/card-pools'

  // 列表
  router.get(prefix, async (req, res) => {
    try {
      const { page = 1, pageSize = 20, type, status } = req.query
      const conditions = []
      const params = []
      if (type) { conditions.push('type = ?'); params.push(type) }
      if (status) { conditions.push('status = ?'); params.push(status) }
      const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : ''
      const offset = (Number(page) - 1) * Number(pageSize)

      const [rows] = await query(
        `SELECT id, name, type, card_type, total_count, used_count, expiry_days, status, description, create_time
         FROM card_pools ${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      const [countResult] = await query(`SELECT COUNT(*) as total FROM card_pools ${where}`, params)
      res.json({ code: 200, data: { list: rows, total: countResult[0]?.total || 0 } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 低库存预警列表（必须在 /:id 之前注册）
  router.get(`${prefix}/low-stock`, async (req, res) => {
    try {
      const [rows] = await query(
        `SELECT id, name, total_count, used_count, COALESCE(warning_threshold, 20) as warning_threshold, expiry_days, status FROM card_pools WHERE status='active' AND total_count > 0 AND total_count <= COALESCE(warning_threshold, 20) ORDER BY total_count ASC`
      )
      res.json({ code: 200, data: rows || [] })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 详情
  router.get(`${prefix}/:id`, async (req, res) => {
    try {
      const [rows] = await query('SELECT * FROM card_pools WHERE id = ?', [req.params.id])
      if (!rows.length) return res.status(404).json({ code: 404, msg: '卡池不存在' })
      const pool = rows[0]
      try { pool.cards_data = JSON.parse(pool.cards_data) }
      catch { pool.cards_data = [] }
      res.json({ code: 200, data: pool })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 创建
  router.post(prefix, authRequired, adminRequired, async (req, res) => {
    try {
      const { name, type = 'card_key', card_type = 'membership', target_id = 0, value = 0,
        duration_unit = 'day', extra_points = 0, extra_balance = 0, extra_experience = 0,
        cards_data = '[]', expiry_days = 0, description = '' } = req.body

      if (!name) return res.status(400).json({ code: 400, msg: '请输入卡池名称' })

      const cardsArr = Array.isArray(cards_data) ? cards_data : JSON.parse(String(cards_data))
      const total = cardsArr.length

      const warning_threshold = req.body.warning_threshold !== undefined ? req.body.warning_threshold : 20
      const [result] = await query(
        `INSERT INTO card_pools (name, type, card_type, target_id, value, duration_unit, extra_points, extra_balance, extra_experience, cards_data, total_count, expiry_days, warning_threshold, description)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [name, type, card_type, target_id, value, duration_unit, extra_points, extra_balance, extra_experience,
         JSON.stringify(cardsArr), total, expiry_days, warning_threshold, description]
      )
      res.json({ code: 200, data: { id: result.insertId } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 更新
  router.put(`${prefix}/:id`, authRequired, adminRequired, async (req, res) => {
    try {
      const fields = ['name', 'type', 'card_type', 'target_id', 'value', 'duration_unit',
        'extra_points', 'extra_balance', 'extra_experience', 'expiry_days', 'warning_threshold', 'description', 'status']
      const sets = []; const params = []

      for (const f of fields) {
        if (req.body[f] !== undefined) {
          sets.push(`${f} = ?`); params.push(req.body[f])
        }
      }

      if (req.body.cards_data !== undefined) {
        const arr = Array.isArray(req.body.cards_data) ? req.body.cards_data : JSON.parse(String(req.body.cards_data))
        sets.push('cards_data = ?'); params.push(JSON.stringify(arr))
        sets.push('total_count = ?'); params.push(arr.length)
      }

      sets.push('update_time = NOW()')
      params.push(req.params.id)

      await query(`UPDATE card_pools SET ${sets.join(', ')} WHERE id = ?`, params)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 删除
  router.delete(`${prefix}/:id`, authRequired, adminRequired, async (req, res) => {
    try {
      await query('DELETE FROM card_pools WHERE id = ?', [req.params.id])
      res.json({ code: 200, msg: '已删除' })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 批量导入卡密
  router.post(`${prefix}/:id/import`, authRequired, adminRequired, async (req, res) => {
    try {
      const id = req.params.id
      const { cards = [] } = req.body

      const [rows] = await query('SELECT cards_data FROM card_pools WHERE id = ?', [id])
      if (!rows.length) return res.status(404).json({ code: 404, msg: '卡池不存在' })

      let existing = []
      try { existing = JSON.parse(rows[0].cards_data) }
      catch { existing = [] }

      const existingSet = new Set(existing.map((c) => c.number))
      const newCards = []
      const duplicates = []
      const now = new Date().toISOString()

      for (const c of cards) {
        if (!c.number) continue
        if (existingSet.has(c.number)) { duplicates.push(c); continue }
        newCards.push({ number: c.number, password: c.password || '', created_at: now }); existingSet.add(c.number)
      }

      const merged = [...existing, ...newCards]
      const importResult = { added: newCards.length, duplicates: duplicates.length, total: merged.length }

      await query('UPDATE card_pools SET cards_data = ?, total_count = ?, update_time = NOW() WHERE id = ?',
        [JSON.stringify(merged), merged.length, id])

      res.json({ code: 200, data: importResult })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 发放卡密（从卡池取出一张）
  async function drawFromPool(poolId) {
    const [rows] = await query('SELECT * FROM card_pools WHERE id = ?', [poolId])
    if (!rows.length) return null

    const pool = rows[0]
    let cards = []
    try { cards = JSON.parse(pool.cards_data) } catch { cards = [] }

    // 过滤过期卡密
    const now = new Date()
    if (pool.expiry_days > 0) {
      const validCards = []
      for (const c of cards) {
        if (!c.created_at) { validCards.push(c); continue }
        const created = new Date(c.created_at)
        const expireDate = new Date(created.getTime() + pool.expiry_days * 86400000)
        if (expireDate > now) validCards.push(c)
      }
      if (cards.length !== validCards.length) {
        cards = validCards
        await query('UPDATE card_pools SET cards_data = ?, total_count = ?, update_time = NOW() WHERE id = ?',
          [JSON.stringify(cards), cards.length, poolId])
      }
    }
    if (!cards.length) return null

    const card = cards[Math.floor(Math.random() * cards.length)]
    const remaining = cards.filter((c) => c.number !== card.number)
    const newUsed = pool.used_count + 1

    await query(
      'UPDATE card_pools SET cards_data = ?, used_count = ?, total_count = ?, update_time = NOW() WHERE id = ?',
      [JSON.stringify(remaining), newUsed, remaining.length, poolId]
    )
    return { number: card.number, password: card.password || '' }
  }

  // 导出 drawFromPool 供其他模块使用
  ;cardPoolRoutes.drawFromPool = drawFromPool
}

module.exports = cardPoolRoutes
