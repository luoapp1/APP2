const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { encrypt, decrypt, maskKey } = require('../utils/crypto.cjs')

const ENCRYPT_KEYS = ['accessKeyId', 'accessKeySecret', 'secretId', 'secretKey',
  'appKey', 'appSecret', 'apiKey', 'password', 'accountSid', 'authToken', 'cdKey']

const SECRET_KEYS = ['accessKeySecret', 'secretKey', 'appSecret', 'apiKey', 'password', 'authToken']

function encryptConfigJson(cfg) {
  if (!cfg) return '{}'
  const obj = typeof cfg === 'string' ? JSON.parse(cfg) : JSON.parse(JSON.stringify(cfg))
  for (const k of ENCRYPT_KEYS) {
    if (obj[k] && typeof obj[k] === 'string' && obj[k] !== '') obj[k] = encrypt(obj[k])
  }
  return JSON.stringify(obj)
}

function decryptConfigJson(cfg) {
  if (!cfg) return '{}'
  const obj = typeof cfg === 'string' ? JSON.parse(cfg) : JSON.parse(JSON.stringify(cfg))
  for (const k of ENCRYPT_KEYS) {
    if (obj[k] && typeof obj[k] === 'string') {
      try { obj[k] = decrypt(obj[k]) } catch {}
    }
  }
  return JSON.stringify(obj)
}

function sanitizeForResponse(config) {
  if (!config) return config
  const cp = { ...config }
  try {
    const obj = typeof cp.config_json === 'string' ? JSON.parse(cp.config_json) : cp.config_json
    for (const k of ENCRYPT_KEYS) {
      if (obj[k] && typeof obj[k] === 'string' && obj[k] !== '') {
        try {
          const dec = decrypt(obj[k])
          obj[k] = SECRET_KEYS.includes(k) ? maskKey(dec) : dec
        } catch { obj[k] = '***' }
      }
    }
    cp.config_json = JSON.stringify(obj)
  } catch {}
  return cp
}

function isMasked(val) {
  return !val || val === '' || /^\*{2,}$/.test(val)
}

function getDecryptedConfig(config) {
  const cp = { ...config }
  cp.config_json = decryptConfigJson(cp.config_json)
  return cp
}

module.exports = function smsConfigRoutes(app) {
  app.get('/api/sms/configs', authRequired, async (req, res) => {
    try {
      const rows = await query('SELECT * FROM sms_config ORDER BY id')
      res.json({ code: 200, data: rows.map(sanitizeForResponse) })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/sms/config/:id', authRequired, async (req, res) => {
    try {
      const rows = await query('SELECT * FROM sms_config WHERE id=?', [req.params.id])
      if (rows.length === 0) return res.json({ code: 404, message: '配置不存在' })
      res.json({ code: 200, data: sanitizeForResponse(rows[0]) })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/sms/config', authRequired, requirePermission('add'), async (req, res) => {
    try {
      const { provider, name, config_json, sign_name, template_code, enabled, is_default } = req.body
      if (!provider) return res.json({ code: 400, message: '请选择短信服务商' })
      const raw = typeof config_json === 'string' ? config_json : JSON.stringify(config_json || {})
      if (is_default) await query('UPDATE sms_config SET is_default=0')
      const result = await query(
        'INSERT INTO sms_config (name, provider, config_json, sign_name, template_code, enabled, is_default) VALUES (?,?,?,?,?,?,?)',
        [name || '', provider, encryptConfigJson(raw), sign_name || '', template_code || '', enabled !== false ? 1 : 0, is_default ? 1 : 0]
      )
      logFromReq(req, 'add', 'sms_config', result.insertId, `添加短信配置: ${provider}`)
      res.json({ code: 200, message: '添加成功', data: { id: result.insertId } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.put('/api/sms/config/:id', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      const { provider, name, config_json, sign_name, template_code, enabled, is_default } = req.body
      const existing = await query('SELECT id, config_json FROM sms_config WHERE id=?', [req.params.id])
      if (existing.length === 0) return res.json({ code: 404, message: '配置不存在' })

      const raw = typeof config_json === 'string' ? config_json : JSON.stringify(config_json || {})
      let finalJson
      try {
        const newCfg = JSON.parse(raw)
        const oldCfg = typeof existing[0].config_json === 'string'
          ? JSON.parse(existing[0].config_json) : (existing[0].config_json || {})

        for (const k of ENCRYPT_KEYS) {
          if (newCfg[k] === '' || newCfg[k] === undefined) {
            newCfg[k] = oldCfg[k] || ''
          } else if (isMasked(newCfg[k])) {
            newCfg[k] = oldCfg[k] || ''
          }
        }
        finalJson = JSON.stringify(newCfg)
      } catch { finalJson = raw }

      if (is_default) await query('UPDATE sms_config SET is_default=0')
      await query(
        'UPDATE sms_config SET name=?, provider=?, config_json=?, sign_name=?, template_code=?, enabled=?, is_default=?, update_time=NOW() WHERE id=?',
        [name || '', provider, encryptConfigJson(finalJson), sign_name || '', template_code || '', enabled !== false ? 1 : 0, is_default ? 1 : 0, req.params.id]
      )
      logFromReq(req, 'edit', 'sms_config', Number(req.params.id), `更新短信配置: ${provider}`)
      res.json({ code: 200, message: '更新成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/sms/config/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      const existing = await query('SELECT provider FROM sms_config WHERE id=?', [req.params.id])
      if (existing.length === 0) return res.json({ code: 404, message: '配置不存在' })
      await query('DELETE FROM sms_config WHERE id=?', [req.params.id])
      logFromReq(req, 'delete', 'sms_config', Number(req.params.id), `删除短信配置: ${existing[0].provider}`)
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}

module.exports.getDecryptedConfig = getDecryptedConfig
module.exports.decryptConfigJson = decryptConfigJson
