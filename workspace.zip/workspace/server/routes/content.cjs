const { query } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { calcCommission } = require('./commission.cjs')

function formatDateTime(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    const pad = (n) => String(n).padStart(2, '0')
    return `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`
  } catch { return '' }
}

const SESSION_TTL = 24 * 60 * 60 * 1000
const sessions = new Map()

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return session.userId
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length) {
      const r = rows[0]
      const ca = typeof r.created_at === 'number' ? r.created_at : new Date(r.created_at).getTime()
      if (Date.now() - ca > SESSION_TTL) { query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {}); return 0 }
      sessions.set(token, { userId: r.user_id, roles: JSON.parse(r.roles || '[]'), createdAt: ca })
      return r.user_id
    }
  } catch {}
  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length) {
      try { return JSON.parse(rows[0].roles || '[]') } catch { return [] }
    }
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
}

async function getUserLevel(userId) {
  if (!userId) return null
  try {
    const rows = await query(
      `SELECT um.level_id, um.level_name, um.expire_time, ml.tier
       FROM user_memberships um
       JOIN membership_levels ml ON um.level_id = ml.id
       WHERE um.user_id = ? AND um.expire_time > NOW()
       ORDER BY ml.tier DESC, um.expire_time DESC
       LIMIT 1`,
      [userId]
    )
    if (!rows.length) return null
    const r = rows[0]
    return { levelId: r.level_id, levelName: r.level_name, tier: r.tier || 1, expireTime: r.expire_time }
  } catch { return null }
}

async function recalcUserMembership(userId) {
  if (!userId) return
  try {
    const level = await getUserLevel(userId)
    if (level) {
      await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
        [level.levelId, level.levelName, level.expireTime, userId])
    } else {
      await query("UPDATE users SET level_id=0, level_name='普通会员', expire_time=NULL WHERE id=?", [userId])
    }
  } catch (e) {
    console.error('[membership] recalcUserMembership failed:', e.message)
  }
}

function contentRoutes(app) {

  // ==================== Content Visibility Check ====================
  app.get('/api/content/visibility/:type/:id', async (req, res) => {
    try {
      const { type, id } = req.params
      const userId = await getUserId(req)
      const table = type === 'app' ? 'app_store' : 'community_posts'

      const rows = await query(
        `SELECT content_permission, content_price, content_price_type, access_password, access_password_tips, user_id
         FROM ${table} WHERE id=?`, [id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })

      const item = rows[0]
      const perm = item.content_permission || 'public'
      const resp = { code: 200, data: { permission: perm, accessible: true } }

      if (perm === 'public') return res.json(resp)

      if (perm === 'login') {
        resp.data.accessible = !!userId
        return res.json(resp)
      }

      if (perm === 'comment') {
        if (!userId) { resp.data.accessible = false; return res.json(resp) }
        const commentTable = type === 'app' ? 'app_comments' : 'community_comments'
        const contentField = type === 'app' ? 'app_id' : 'post_id'
        const comments = await query(`SELECT id FROM ${commentTable} WHERE ${contentField}=? AND user_id=?`, [id, userId])
        resp.data.accessible = comments.length > 0
        return res.json(resp)
      }

      if (perm === 'paid') {
        if (!userId) { resp.data.accessible = false; resp.data.price = item.content_price; return res.json(resp) }
        resp.data.price = item.content_price || 0
        resp.data.priceType = item.content_price_type || 'balance'
        const pur = await query('SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
        resp.data.accessible = pur.length > 0 || Number(item.user_id) === userId
        resp.data.purchased = pur.length > 0
        return res.json(resp)
      }

      if (perm === 'level1' || perm === 'level2') {
        if (!userId) { resp.data.accessible = false; return res.json(resp) }
        const lvl = await getUserLevel(userId)
        if (!lvl) { resp.data.accessible = false; return res.json(resp) }
        if (perm === 'level1') resp.data.accessible = lvl.tier >= 1
        else resp.data.accessible = lvl.tier >= 2
        return res.json(resp)
      }

      if (perm === 'password') {
        resp.data.accessible = false
        resp.data.passwordSet = !!item.access_password
        resp.data.passwordTips = item.access_password_tips || ''
        return res.json(resp)
      }

      res.json(resp)
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Password Verify ====================
  app.post('/api/content/verify-password/:type/:id', async (req, res) => {
    try {
      const { type, id } = req.params
      const { password } = req.body
      if (!password && password !== '0') return res.json({ code: 400, msg: '请输入密码' })
      const table = type === 'app' ? 'app_store' : 'community_posts'
      const rows = await query(`SELECT access_password FROM ${table} WHERE id=?`, [id])
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })
      if (rows[0].access_password === password) {
        return res.json({ code: 200, msg: '验证成功', data: { valid: true } })
      }
      res.json({ code: 400, msg: '密码错误', data: { valid: false } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Content Purchase ====================
  app.post('/api/content/purchase/:type/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { type, id } = req.params

      const table = type === 'app' ? 'app_store' : 'community_posts'
      const rows = await query(
        `SELECT content_price, content_price_type, content_permission, user_id, title, content
         FROM ${table} WHERE id=?`, [id]
      )
      if (!rows.length) return res.json({ code: 404, msg: '内容不存在' })

      const item = rows[0]
      let hasPaywall = false
      if (item.content_permission !== 'paid' && item.content_permission !== 'mixed') {
        try {
          const c = typeof item.content === 'string' ? JSON.parse(item.content) : item.content
          if (c?.type === 'doc') {
            const check = (node) => { if (node?.type === 'paywall') { hasPaywall = true; return } if (node?.content) { for (const n of node.content) check(n) } }
            check(c)
          } else if (Array.isArray(c)) {
            for (const b of c) { if (b?.type === 'paywall' || (b?.content && JSON.stringify(b.content).includes('"type":"paywall"'))) { hasPaywall = true; break } }
          }
        } catch {}
        if (!hasPaywall) return res.json({ code: 400, msg: '此内容非付费内容' })
      }

      let price, priceType
      if (item.content_permission === 'paid') {
        price = Number(item.content_price) || 0
        priceType = item.content_price_type || 'balance'
      } else {
        price = Number(req.body?.price) || 0
        priceType = req.body?.priceType || 'balance'
      }
      if (price <= 0) return res.json({ code: 400, msg: '价格异常' })

      if (Number(item.user_id) === userId) return res.json({ code: 400, msg: '自己的内容无需购买' })

      if (item.content_permission === 'paid') {
        const existing = await query('SELECT id FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
        if (existing.length) return res.json({ code: 400, msg: '已购买过此内容' })
      }

      const user = await query('SELECT balance, points, username FROM users WHERE id=?', [userId])
      if (!user.length) return res.json({ code: 404, msg: '用户不存在' })

      const u = user[0]
      const buyerName = u.username || ''

      // 会员折扣 - 使用最新会员模型
      const userLevel = await getUserLevel(userId)
      let discountRate = 1.0
      let membershipName = ''
      if (userLevel) {
        const ml = await query('SELECT name, discount_rate, points_discount_rate FROM membership_levels WHERE id=?', [userLevel.levelId])
        if (ml.length) {
          discountRate = priceType === 'points' ? Number(ml[0].points_discount_rate || 1.0) : Number(ml[0].discount_rate || 1.0)
          membershipName = ml[0].name || ''
        }
      }
      const originalPrice = price
      let finalPrice = Math.round(originalPrice * discountRate * 100) / 100

      // 优惠券处理
      const couponId = Number(req.body?.couponId) || 0
      let couponDiscount = 0
      let usedCouponName = ''
      let ucCid = 0
      if (couponId) {
        const nowStr = formatDateTime(new Date())
        const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [couponId, userId])
        if (!uc.length) return res.json({ code: 400, msg: '优惠券不存在' })
        if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })
        if (uc[0].expire_time && uc[0].expire_time < nowStr) {
          await query("UPDATE user_coupons SET status='expired' WHERE id=?", [couponId])
          return res.json({ code: 400, msg: '优惠券已过期' })
        }
        const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
        const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
        if (!c.length) return res.json({ code: 404, msg: '优惠券模板不存在' })
        const couponType = c[0].type || cd.type
        const couponValue = Number(c[0].value || cd.value || 0)
        const couponMaxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
        const couponScope = c[0].scope || cd.scope
        const isMultiUse = !!(c[0].is_multi_use)

        // payType校验
        const isPointsCoupon = couponType === 'fixed_points' || couponType === 'points_percent'
        const isBalanceCoupon = couponType === 'fixed' || couponType === 'percent'
        if (isPointsCoupon && priceType !== 'points') return res.json({ code: 400, msg: '此优惠券仅限积分支付时使用' })
        if (isBalanceCoupon && priceType === 'points') return res.json({ code: 400, msg: '此优惠券仅限余额支付时使用' })

        // scope校验: 内容购买只能使用通用券
        if (couponScope && couponScope !== 'all' && couponScope !== 'product') {
          return res.json({ code: 400, msg: '此优惠券不适用于内容购买' })
        }

        // 最低消费
        const minOrder = Number(c[0].min_order || cd.minOrder || 0)
        if (minOrder > 0 && finalPrice < minOrder) {
          return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
        }

        usedCouponName = c[0].name || cd.name || ''
        ucCid = uc[0].coupon_id
        let availableValue = couponValue
        if (isMultiUse) {
          availableValue = uc[0].remaining_value !== null && uc[0].remaining_value !== undefined
            ? Number(uc[0].remaining_value) : couponValue
        }

        if (couponType === 'fixed' || couponType === 'fixed_points') {
          couponDiscount = Math.min(availableValue, finalPrice)
        } else {
          couponDiscount = Math.floor(finalPrice * couponValue / 100 * 100) / 100
          if (couponMaxDisc > 0 && couponDiscount > couponMaxDisc) couponDiscount = couponMaxDisc
        }
        if (couponDiscount > finalPrice) couponDiscount = finalPrice

        const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
        const beforeRemaining = isMultiUse ? availableValue : null

        if (isMultiUse) {
          if (afterRemaining <= 0) {
            await query(
              `UPDATE user_coupons SET status='used', use_time=?, use_scene='content_buy', use_amount=use_amount+?, remaining_value=0 WHERE id=?`,
              [nowStr, couponDiscount, couponId]
            )
          } else {
            await query(
              `UPDATE user_coupons SET use_time=?, use_scene='content_buy', use_amount=use_amount+?, remaining_value=? WHERE id=?`,
              [nowStr, couponDiscount, afterRemaining, couponId]
            )
          }
        } else {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene='content_buy', use_amount=? WHERE id=?`,
            [nowStr, couponDiscount, couponId]
          )
        }

        await query(
          `INSERT INTO coupon_usage_logs (user_coupon_id, user_id, user_name, coupon_id, coupon_name, use_scene, use_amount, before_remaining, after_remaining, order_desc, use_time)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          [couponId, userId, buyerName, uc[0].coupon_id, usedCouponName, 'content_buy', couponDiscount, beforeRemaining, afterRemaining, `购买内容 #${id} 原价${priceType==='points'?'积分':'¥'}${(finalPrice).toFixed(2)} ${priceType==='points'?'积分':'余额'}减${priceType==='points'?couponDiscount+'积分':'¥'+couponDiscount.toFixed(2)}`, nowStr]
        )

        finalPrice = Math.max(0, finalPrice - couponDiscount)
      }

      const orderAmount = finalPrice + couponDiscount

      if (priceType === 'balance') {
        if (Number(u.balance) < finalPrice) return res.json({ code: 400, msg: '余额不足' })
        await query('UPDATE users SET balance = balance - ? WHERE id=?', [finalPrice, userId])
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '内容购买', ?)`,
          [userId, buyerName, finalPrice, userId, `购买${type==='post'?'帖子':'应用'} #${id}${discountRate < 1 ? ' (' + membershipName + Math.round(discountRate*100) + '%折扣)' : ''}`])
      } else {
        if (Number(u.points || 0) < finalPrice) return res.json({ code: 400, msg: '积分不足' })
        await query('UPDATE users SET points = points - ? WHERE id=?', [finalPrice, userId])
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '内容购买', ?)`,
          [userId, buyerName, finalPrice, userId, `购买${type==='post'?'帖子':'应用'} #${id}${discountRate < 1 ? ' (' + membershipName + Math.round(discountRate*100) + '%折扣)' : ''}`])
      }

      // Split profit calculation
      let commissionAmount = 0
      let commissionRate = 0
      const authorId = Number(item.user_id)
      if (authorId) {
        const typeMap = { community_posts: 'post', app_store: 'app' }
        const specificType = typeMap[type] || 'content'
        const ruleResult = await query(
          `SELECT rate FROM commission_rules
           WHERE status='1' AND ((order_type=? OR order_type='all') AND (user_id=? OR user_id=0) AND invite_code_id=0 AND invite_code_type='')
           ORDER BY user_id DESC LIMIT 1`, [specificType, authorId]
        )
        if (!ruleResult.length) {
          const fallback = await query(
            `SELECT rate FROM commission_rules
             WHERE status='1' AND ((order_type='content' OR order_type='all') AND (user_id=? OR user_id=0) AND invite_code_id=0 AND invite_code_type='')
             ORDER BY user_id DESC LIMIT 1`, [authorId]
          )
          if (fallback.length) commissionRate = Number(fallback[0].rate)
        } else {
          commissionRate = Number(ruleResult[0].rate)
        }
        if (!commissionRate) {
          const authorLevel = await query('SELECT level_id FROM users WHERE id=?', [authorId])
          if (authorLevel.length && authorLevel[0].level_id) {
            const lvlRule = await query(
              `SELECT rate FROM commission_rules
               WHERE status='1' AND ((order_type=? OR order_type='content' OR order_type='all') AND user_level_id=? AND user_id=0 AND invite_code_id=0 AND invite_code_type='')
               LIMIT 1`, [specificType, authorLevel[0].level_id]
            )
            if (lvlRule.length) commissionRate = Number(lvlRule[0].rate)
          }
        }
        if (!commissionRate) {
          const globalRule = await query(
            `SELECT rate FROM commission_rules
             WHERE status='1' AND ((order_type=? OR order_type='content' OR order_type='all') AND user_level_id=0 AND user_id=0 AND invite_code_id=0 AND invite_code_type='')
             ORDER BY rate DESC LIMIT 1`, [specificType]
          )
          if (globalRule.length) commissionRate = Number(globalRule[0].rate)
        }
        commissionAmount = parseFloat((finalPrice * commissionRate / 100).toFixed(2))
        if (commissionAmount > 0) {
          await query('UPDATE users SET balance = balance + ? WHERE id=?', [commissionAmount, authorId])
          const authorInfo = await query('SELECT username FROM users WHERE id=?', [authorId])
          const authorName = authorInfo.length ? authorInfo[0].username : ''
          await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'earn',?, (SELECT balance FROM users WHERE id=?), '内容收益', ?)`,
            [authorId, authorName, commissionAmount, authorId, `${type==='post'?'帖子':'应用'} #${id} 销售分佣`])
          await query(
            `INSERT INTO commission_records (order_id, order_type, order_amount, user_id, user_name, referrer_id, referrer_name, rate, amount, status)
             VALUES (?,?,?,?,?,?,?,?,?,'completed')`,
            [id, type, finalPrice, authorId, '', 0, '', commissionRate, commissionAmount]
          )
        }
      }

      const blockIndex = item.content_permission === 'mixed' ? (Number(req.body?.blockIndex) ?? -1) : -1

      await query(
        `INSERT INTO content_purchases (user_id, content_type, content_id, author_id, amount, pay_type, commission_amount, commission_rate, block_index)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [userId, type, Number(id), authorId, finalPrice, priceType, commissionAmount, commissionRate, blockIndex]
      )

      // 创建结算订单记录 - 根据结算规则确定确认期
      const buyerLevel = user[0].level_id || 0
      const contentConfirmCfg = await query('SELECT confirm_days FROM settlement_config WHERE level_id=? AND enabled=1', [buyerLevel])
      let contentConfirmDays = 0
      if (!contentConfirmCfg.length || contentConfirmCfg[0].confirm_days === null || contentConfirmCfg[0].confirm_days === undefined) {
        const def = await query('SELECT confirm_days FROM settlement_config WHERE level_id=0 AND enabled=1')
        contentConfirmDays = def.length ? (def[0].confirm_days || 0) : 7
      } else {
        contentConfirmDays = contentConfirmCfg[0].confirm_days || 0
      }
      const contentDeadline = contentConfirmDays > 0 ? new Date(Date.now() + contentConfirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19) : null
      const contentOrderStatus = contentConfirmDays > 0 ? 'shipped' : 'completed'
      const orderNo = 'CO' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
      const contentTypeLabel = type === 'community_posts' ? '帖子' : '应用'
      await query(
        `INSERT INTO orders (order_no, buyer_id, buyer_name, seller_id, seller_name, order_type, order_desc, pay_type, total_amount, paid_amount, coupon_id, coupon_discount, ref_id, ref_table, status, confirm_days, confirm_deadline, shipped_at, confirmed_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),${contentConfirmDays > 0 ? 'NULL' : "NOW()"})`,
        [orderNo, userId, user[0].username, authorId, (item.author_name || ''), 'content_purchase', `购买${contentTypeLabel}《${item.title || item.name || ''}》`, priceType, originalPrice, finalPrice, couponId > 0 ? ucCid : 0, couponDiscount, Number(id), type, contentOrderStatus, contentConfirmDays, contentDeadline]
      )

      // 推广返佣
      if (priceType === 'balance' && finalPrice > 0) {
        const orderTypeMap = { community_posts: 'post', app_store: 'app' }
        calcCommission(Number(id), orderTypeMap[type] || 'content', finalPrice, userId)
      }

      res.json({ code: 200, msg: '购买成功', data: { originalPrice: orderAmount, finalPrice, discountRate, membershipName, couponDiscount, couponName: usedCouponName } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Purchase Status ====================
  app.get('/api/content/purchased/:type/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { type, id } = req.params
      if (!userId) return res.json({ code: 200, data: { purchased: false, boughtBlocks: [], fullPurchase: false } })
      const pur = await query('SELECT id, block_index FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [type, Number(id), userId])
      const fullPurchase = pur.some((r) => r.block_index < 0)
      const purchased = pur.length > 0
      const boughtBlocks = pur.filter((r) => r.block_index >= 0).map((r) => r.block_index)
      res.json({ code: 200, data: { purchased, boughtBlocks, fullPurchase } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Purchase History ====================
  app.get('/api/content/purchases/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT cp.*, COALESCE(cp2.title, a.name) as content_title
         FROM content_purchases cp
         LEFT JOIN community_posts cp2 ON cp.content_type='post' AND cp.content_id=cp2.id
         LEFT JOIN app_store a ON cp.content_type='app' AND cp.content_id=a.id
         WHERE cp.user_id=?
         ORDER BY cp.create_time DESC LIMIT ? OFFSET ?`,
        [userId, size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM content_purchases WHERE user_id=?', [userId])
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Membership Products CRUD ====================
  app.get('/api/membership/products', async (req, res) => {
    try {
      const levelId = Number(req.query.levelId) || 0
      let where = ''
      const params = []
      if (levelId) { where = 'WHERE level_id=?'; params.push(levelId) }
      const rows = await query(`SELECT * FROM membership_products ${where} ORDER BY level_id, price`, params)
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/membership/my-memberships', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        `SELECT um.*, ml.tier, ml.discount_rate, ml.points_discount_rate, ml.points_multiplier,
                ml.data_limit_mb, ml.file_limit_mb, ml.text_color, ml.bg_color, ml.icon
         FROM user_memberships um
         JOIN membership_levels ml ON um.level_id = ml.id
         WHERE um.user_id = ? AND um.expire_time > NOW()
         ORDER BY ml.tier DESC, um.expire_time DESC`,
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/membership/my-current-level', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: null })
      const level = await getUserLevel(userId)
      res.json({ code: 200, data: level })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/membership/product/save', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const { id, levelId, name, price, originalPrice, durationDays, isPromo, promoEndTime, giftPoints, giftBalance, giftExperience, giftCouponIds, giftDataLimitMb, giftFileLimitMb, purchaseLimit, status } = req.body
      if (id) {
        await query(
          `UPDATE membership_products SET level_id=?, name=?, price=?, original_price=?, duration_days=?, is_promo=?, promo_end_time=?, gift_points=?, gift_balance=?, gift_experience=?, gift_coupon_ids=?, gift_data_limit_mb=?, gift_file_limit_mb=?, purchase_limit=?, status=?
           WHERE id=?`,
          [levelId || 0, name || '', price || 0, originalPrice || 0, durationDays || 30, isPromo ? 1 : 0, promoEndTime || null, Number(giftPoints) || 0, Number(giftBalance) || 0, Number(giftExperience) || 0, giftCouponIds || '', Number(giftDataLimitMb) || 0, Number(giftFileLimitMb) || 0, Number(purchaseLimit) || 0, status || '1', id]
        )
        logFromReq(req, 'update', 'membership_product', id, `更新会员商品"${name}"`)
      } else {
        const result = await query(
          `INSERT INTO membership_products (level_id, name, price, original_price, duration_days, is_promo, promo_end_time, gift_points, gift_balance, gift_experience, gift_coupon_ids, gift_data_limit_mb, gift_file_limit_mb, purchase_limit, status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [levelId || 0, name || '', price || 0, originalPrice || 0, durationDays || 30, isPromo ? 1 : 0, promoEndTime || null, Number(giftPoints) || 0, Number(giftBalance) || 0, Number(giftExperience) || 0, giftCouponIds || '', Number(giftDataLimitMb) || 0, Number(giftFileLimitMb) || 0, Number(purchaseLimit) || 0, status || '1']
        )
        logFromReq(req, 'create', 'membership_product', result.insertId, `新增会员商品"${name}"`)
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/membership/product/:id', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      await query('DELETE FROM membership_products WHERE id=?', [req.params.id])
      logFromReq(req, 'delete', 'membership_product', req.params.id, `删除会员商品ID:${req.params.id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Membership Purchase ====================
  app.post('/api/membership/buy', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { productId, payType, couponId } = req.body
      const paymentType = payType || 'balance'

      const product = await query('SELECT * FROM membership_products WHERE id=? AND status=?', [productId, '1'])
      if (!product.length) return res.json({ code: 404, msg: '商品不存在或已下架' })

      const prod = product[0]

      let actualPrice
      if (paymentType === 'points') {
        actualPrice = Number(prod.points_price) > 0
          ? Number(prod.points_price)
          : (prod.is_promo && (!prod.promo_end_time || new Date(prod.promo_end_time) > new Date()) ? Number(prod.price) : (Number(prod.original_price) || Number(prod.price)))
      } else {
        actualPrice = prod.is_promo && (!prod.promo_end_time || new Date(prod.promo_end_time) > new Date()) ? Number(prod.price) : (Number(prod.original_price) || Number(prod.price))
      }

      const user = await query('SELECT balance, username, points, level_id, level_name, expire_time FROM users WHERE id=?', [userId])

      // 优惠券处理
      let couponDiscount = 0
      let usedCouponName = ''
      if (couponId) {
        const nowStr = formatDateTime(new Date())
        const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [couponId, userId])
        if (!uc.length) return res.json({ code: 400, msg: '优惠券不存在' })
        if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })
        if (uc[0].expire_time && uc[0].expire_time < nowStr) {
          await query("UPDATE user_coupons SET status='expired' WHERE id=?", [couponId])
          return res.json({ code: 400, msg: '优惠券已过期' })
        }

        const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
        const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
        if (!c.length) return res.json({ code: 400, msg: '优惠券模板不存在' })
        const scope = c[0].scope || cd.scope

        if (scope !== 'all' && scope !== 'membership') {
          return res.json({ code: 400, msg: '此优惠券仅限商城场景使用' })
        }

        const targetIds = c[0].target_ids || cd.targetIds || ''
        if (targetIds) {
          const ids = targetIds.split(',').map(Number)
          if (ids.length > 0 && !ids.includes(Number(prod.level_id))) {
            return res.json({ code: 400, msg: '此优惠券不适用于该会员等级' })
          }
        }

        const minOrder = Number(c[0].min_order || cd.minOrder || 0)
        if (minOrder > 0 && actualPrice < minOrder) {
          return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
        }

        const type = c[0].type || cd.type
        const value = Number(c[0].value || cd.value || 0)
        const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
        const isMultiUse = !!(c[0].is_multi_use)

        // payType校验: 积分券仅积分支付可用
        const isPointsCoupon = type === 'fixed_points' || type === 'points_percent'
        const isBalanceCoupon = type === 'fixed' || type === 'percent'
        if (isPointsCoupon && paymentType !== 'points') {
          return res.json({ code: 400, msg: '此券仅限积分支付时使用' })
        }
        if (isBalanceCoupon && paymentType === 'points') {
          return res.json({ code: 400, msg: '此券仅限余额支付时使用' })
        }

        // 多用途券: 从剩余值中取
        let availableValue = value
        if (isMultiUse) {
          const remaining = uc[0].remaining_value !== null && uc[0].remaining_value !== undefined
            ? Number(uc[0].remaining_value)
            : value
          availableValue = remaining
        }

        if (type === 'fixed' || type === 'fixed_points') {
          couponDiscount = Math.min(availableValue, actualPrice)
        } else if (type === 'percent' || type === 'points_percent') {
          couponDiscount = Math.floor(actualPrice * value / 100 * 100) / 100
          if (maxDisc > 0 && couponDiscount > maxDisc) couponDiscount = maxDisc
        }
        if (couponDiscount > actualPrice) couponDiscount = actualPrice

        usedCouponName = c[0].name || cd.name || ''

        // 更新优惠券状态(多用途/单次)
        const beforeRemaining = isMultiUse ? availableValue : null
        const afterRemaining = isMultiUse ? Math.max(0, availableValue - couponDiscount) : null
        if (isMultiUse) {
          if (afterRemaining <= 0) {
            await query(
              `UPDATE user_coupons SET status='used', use_time=?, use_scene='membership_buy', use_amount=use_amount+?, remaining_value=0 WHERE id=?`,
              [nowStr, couponDiscount, couponId]
            )
          } else {
            await query(
              `UPDATE user_coupons SET use_time=?, use_scene='membership_buy', use_amount=use_amount+?, remaining_value=? WHERE id=?`,
              [nowStr, couponDiscount, afterRemaining, couponId]
            )
          }
        } else {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene='membership_buy', use_amount=? WHERE id=?`,
            [nowStr, couponDiscount, couponId]
          )
        }

        // 写入使用日志
        const userName = user[0].username || ''
        await query(
          `INSERT INTO coupon_usage_logs (user_coupon_id, user_id, user_name, coupon_id, coupon_name, use_scene, use_amount, before_remaining, after_remaining, order_desc, use_time)
           VALUES (?,?,?,?,?,'membership_buy',?,?,?,?,?)`,
          [couponId, userId, userName, uc[0].coupon_id, usedCouponName, couponDiscount, beforeRemaining, afterRemaining, `购买 ${prod.name || ''} 原价¥${(actualPrice+couponDiscount).toFixed(2)} ${paymentType==='points'?'积分':'余额'}减¥${couponDiscount.toFixed(2)}`, nowStr]
        )

        actualPrice = Math.max(0, actualPrice - couponDiscount)
      }

      const orderAmount = actualPrice + couponDiscount

      if (paymentType === 'points') {
        if (Number(user[0].points || 0) < actualPrice) return res.json({ code: 400, msg: '积分不足' })
      } else {
        if (Number(user[0].balance || 0) < actualPrice) return res.json({ code: 400, msg: '余额不足' })
      }

      const level = await query('SELECT * FROM membership_levels WHERE id=?', [prod.level_id])
      if (!level.length) return res.json({ code: 404, msg: '会员等级不存在' })

      if (paymentType === 'points') {
        await query('UPDATE users SET points = points - ? WHERE id=?', [actualPrice, userId])
        const newPoints = Number(user[0].points || 0) - actualPrice
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,'expense',?,?,'会员购买',?)`,
          [userId, user[0].username || '', actualPrice, newPoints, `购买${level[0].name}`])
      } else {
        await query('UPDATE users SET balance = balance - ? WHERE id=?', [actualPrice, userId])
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,'expense',?, (SELECT balance FROM users WHERE id=?), '会员购买', ?)`,
          [userId, user[0].username || '', actualPrice, userId, `购买${level[0].name}`])
      }

      const now = new Date()
      const purchaseType = await determinePurchaseType(userId, prod.level_id)
      const PERMANENT_DATE = new Date('2199-12-31T23:59:59.000Z')
      let expireTime

      if (prod.duration_days === 0) {
        expireTime = PERMANENT_DATE
      } else {
        const nowStr = now.toISOString().slice(0, 19).replace('T', ' ')

        if (purchaseType === 'renew') {
          const existing = await query(
            'SELECT expire_time FROM user_memberships WHERE user_id=? AND level_id=? AND expire_time > NOW() ORDER BY expire_time DESC LIMIT 1',
            [userId, prod.level_id]
          )
          const base = existing.length ? new Date(existing[0].expire_time) : now
          if (base < now) base.setTime(now.getTime())
          expireTime = new Date(base.getTime() + prod.duration_days * 86400000)
        } else {
          expireTime = new Date(now.getTime() + prod.duration_days * 86400000)
        }
      }

      const expireTimeStr = expireTime.toISOString().slice(0, 19).replace('T', ' ')

      // 写入或更新 user_memberships
      if (purchaseType === 'renew') {
        const existing = await query(
          'SELECT id FROM user_memberships WHERE user_id=? AND level_id=? ORDER BY expire_time DESC LIMIT 1',
          [userId, prod.level_id]
        )
        if (existing.length) {
          await query('UPDATE user_memberships SET expire_time=? WHERE id=?', [expireTimeStr, existing[0].id])
        } else {
          await query('INSERT INTO user_memberships (user_id, level_id, level_name, expire_time) VALUES (?,?,?,?)',
            [userId, prod.level_id, level[0].name, expireTimeStr])
        }
      } else {
        await query('INSERT INTO user_memberships (user_id, level_id, level_name, expire_time) VALUES (?,?,?,?)',
          [userId, prod.level_id, level[0].name, expireTimeStr])
      }

      await recalcUserMembership(userId)

      // 购买更高等级时，同步延长所有低等级会员时长
      const lowerExtendedIds = []
      if (prod.duration_days > 0) {
        const boughtLevel = level[0].level || 0
        const lowerMemberships = await query(
          `SELECT um.id, um.level_id, um.expire_time, ml.level
           FROM user_memberships um
           JOIN membership_levels ml ON um.level_id = ml.id
           WHERE um.user_id=? AND um.level_id!=? AND um.expire_time > NOW() AND ml.level < ?`,
          [userId, prod.level_id, boughtLevel]
        )
        for (const m of lowerMemberships) {
          const base = new Date(m.expire_time)
          const extended = new Date(base.getTime() + prod.duration_days * 86400000)
          await query('UPDATE user_memberships SET expire_time=? WHERE id=?',
            [extended.toISOString().slice(0, 19).replace('T', ' '), m.id])
          lowerExtendedIds.push(`${m.id}:${m.level_id}:${base.toISOString()}`)
        }
        if (lowerMemberships.length) await recalcUserMembership(userId)
      }

      // ==================== 赠送逻辑 ====================
      const lv = level[0]
      const lvGiftPoints = Number(lv.gift_points) || 0
      const lvGiftBalance = Number(lv.gift_balance) || 0
      const lvGiftExperience = Number(lv.gift_experience) || 0

      const planGiftPoints = Number(prod.gift_points) || 0
      const planGiftBalance = Number(prod.gift_balance) || 0
      const planGiftExperience = Number(prod.gift_experience) || 0
      const planGiftDataMb = Number(prod.gift_data_limit_mb) || 0
      const planGiftFileMb = Number(prod.gift_file_limit_mb) || 0
      const planPurchaseLimit = Number(prod.purchase_limit) || 0

      // 统计该等级之前的购买次数（用于判断是否首次）
      const levelPurchaseCount = await query(
        'SELECT COUNT(*) as cnt FROM membership_purchases WHERE user_id=? AND level_id=?',
        [userId, prod.level_id]
      )
      const isFirstLevelPurchase = !levelPurchaseCount.length || levelPurchaseCount[0].cnt === 0

      // 统计该产品的购买次数（用于赠送次数限制）
      const productPurchaseCount = await query(
        'SELECT COUNT(*) as cnt FROM membership_purchases WHERE user_id=? AND product_id=?',
        [userId, productId]
      )
      const productPurchaseCnt = productPurchaseCount.length ? productPurchaseCount[0].cnt : 0
      const planGiftBlocked = planPurchaseLimit > 0 && productPurchaseCnt >= planPurchaseLimit

      const parseGiftCoupons = (raw) => {
        try {
          const parsed = JSON.parse(raw || '[]')
          if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object') return parsed
        } catch (_e) { void _e }
        return (raw || '').split(',').map(Number).filter(Boolean).map(id => ({ id }))
      }
      const lvGiftCoupons = isFirstLevelPurchase ? parseGiftCoupons(lv.gift_coupon_ids) : []
      const planGiftCoupons = planGiftBlocked ? [] : parseGiftCoupons(prod.gift_coupon_ids)
      const allGiftCoupons = [...lvGiftCoupons, ...planGiftCoupons]

      const totalGiftPoints = (isFirstLevelPurchase ? lvGiftPoints : 0) + (planGiftBlocked ? 0 : planGiftPoints)
      const totalGiftBalance = (isFirstLevelPurchase ? lvGiftBalance : 0) + (planGiftBlocked ? 0 : planGiftBalance)
      const totalGiftExperience = (isFirstLevelPurchase ? lvGiftExperience : 0) + (planGiftBlocked ? 0 : planGiftExperience)
      const totalGiftDataMb = planGiftBlocked ? 0 : planGiftDataMb
      const totalGiftFileMb = planGiftBlocked ? 0 : planGiftFileMb

      if (totalGiftPoints > 0 || totalGiftBalance > 0 || totalGiftExperience > 0 || allGiftCoupons.length > 0 || totalGiftDataMb > 0 || totalGiftFileMb > 0) {
        const userName = user[0].username || ''

        if (totalGiftPoints > 0) {
          await query('UPDATE users SET points = points + ? WHERE id=?', [totalGiftPoints, userId])
          const newPoints = Number(user[0].points || 0) + totalGiftPoints
          await query(
            'INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,?,?,?,?,?,?)',
            [userId, userName, 'earn', totalGiftPoints, newPoints, '会员开通赠送', `开通${lv.name}赠送积分`]
          )
        }

        if (totalGiftBalance > 0) {
          await query('UPDATE users SET balance = balance + ? WHERE id=?', [totalGiftBalance, userId])
          const newBalance = Number(user[0].balance || 0) + totalGiftBalance
          await query(
            'INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,?,?,?,?,?,?)',
            [userId, userName, 'earn', totalGiftBalance, newBalance, '会员开通赠送', `开通${lv.name}赠送余额`]
          )
        }

        if (totalGiftExperience > 0) {
          await query('UPDATE users SET experience = experience + ? WHERE id=?', [totalGiftExperience, userId])
        }

        if (allGiftCoupons.length > 0) {
          for (const gc of allGiftCoupons) {
            if (gc.id) {
              // Old format: coupon ID - look up from coupons table
              const c = await query('SELECT * FROM coupons WHERE id=? AND status=?', [gc.id, '1'])
              if (!c.length) continue
              const ct = c[0]
              const expireTime = ct.expire_time
                ? ct.expire_time
                : new Date(Date.now() + (ct.valid_days || 30) * 86400000).toISOString().slice(0, 19).replace('T', ' ')
              const couponData = JSON.stringify({
                name: ct.name, type: ct.type, value: Number(ct.value),
                minOrder: Number(ct.min_order), maxDiscount: Number(ct.max_discount),
                scope: ct.scope, targetIds: ct.target_ids, category: ct.category
              })
              await query(
                'INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())',
                [userId, ct.id, 'unused', couponData, expireTime, ct.is_multi_use ? Number(ct.value) : null]
              )
            } else {
              // New format: custom coupon data
              const couponData = JSON.stringify({
                name: gc.name || '会员赠送券',
                type: gc.type || 'fixed',
                value: Number(gc.value) || 0,
                minOrder: Number(gc.minOrder) || 0,
                maxDiscount: Number(gc.maxDiscount) || 0,
                scope: gc.scope || 'all',
                targetIds: '',
                category: gc.category || 'member'
              })
              const expireTime = new Date(Date.now() + ((gc.validDays || 30) * 86400000)).toISOString().slice(0, 19).replace('T', ' ')
              await query(
                'INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())',
                [userId, 0, 'unused', couponData, expireTime, gc.is_multi_use ? Number(gc.value) : null]
              )
            }
          }
        }

        if (totalGiftDataMb > 0 || totalGiftFileMb > 0) {
          await query(
            'UPDATE users SET bonus_data_limit_mb = bonus_data_limit_mb + ?, bonus_file_limit_mb = bonus_file_limit_mb + ? WHERE id=?',
            [totalGiftDataMb, totalGiftFileMb, userId]
          )
        }
      }

      await query(
        `INSERT INTO membership_purchases (user_id, product_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time, gift_points, gift_balance, gift_experience, gift_coupon_count, gift_data_mb, gift_file_mb, lower_extended_ids)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [userId, productId, prod.level_id, level[0].name, orderAmount, paymentType, purchaseType, prod.duration_days, expireTimeStr, totalGiftPoints, totalGiftBalance, totalGiftExperience, allGiftCoupons.length, totalGiftDataMb, totalGiftFileMb, lowerExtendedIds.length ? JSON.stringify(lowerExtendedIds) : null]
      )

      // 授予会员专属称号
      const lvTitleId = Number(lv.title_id) || 0
      if (lvTitleId > 0) {
        await query('INSERT IGNORE INTO user_titles (user_id, title_id, grant_by, grant_time) VALUES (?,?,?,NOW())', [userId, lvTitleId, 'membership'])
        const curUser = await query('SELECT active_title_id FROM users WHERE id=?', [userId])
        if (curUser.length && Number(curUser[0].active_title_id) === 0) {
          const titleInfo = await query('SELECT name FROM custom_titles WHERE id=?', [lvTitleId])
          if (titleInfo.length) {
            await query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [lvTitleId, titleInfo[0].name, userId])
          }
        }
      }

      // 授予会员专属头像框
      const lvFrameId = Number(lv.frame_id) || 0
      if (lvFrameId > 0) {
        await query('INSERT IGNORE INTO user_avatar_frames (user_id, frame_id, obtain_type, obtain_time) VALUES (?,?,?,NOW())', [userId, lvFrameId, 'membership'])
        const curUser2 = await query('SELECT active_frame_id FROM users WHERE id=?', [userId])
        if (curUser2.length && Number(curUser2[0].active_frame_id) === 0) {
          await query('UPDATE users SET active_frame_id=?, active_frame_url=(SELECT image_url FROM avatar_frames WHERE id=?) WHERE id=?', [lvFrameId, lvFrameId, userId])
        }
      }

      // 创建结算订单记录 - 根据结算规则确定确认期
      const buyerLevelId = user[0].level_id || 0
      const confirmCfg = await query('SELECT confirm_days FROM settlement_config WHERE level_id=? AND enabled=1', [buyerLevelId])
      let confirmDays = 0
      if (!confirmCfg.length || confirmCfg[0].confirm_days === null || confirmCfg[0].confirm_days === undefined) {
        const def = await query('SELECT confirm_days FROM settlement_config WHERE level_id=0 AND enabled=1')
        confirmDays = def.length ? (def[0].confirm_days || 0) : 7
      } else {
        confirmDays = confirmCfg[0].confirm_days || 0
      }
      const deadline = confirmDays > 0 ? new Date(Date.now() + confirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19) : null
      const orderStatus = confirmDays > 0 ? 'shipped' : 'completed'
      const orderNo = 'MO' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
      await query(
        `INSERT INTO orders (order_no, buyer_id, buyer_name, order_type, order_desc, pay_type, total_amount, paid_amount, status, confirm_days, confirm_deadline, shipped_at, confirmed_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW(),${confirmDays > 0 ? 'NULL' : "NOW()"})`,
        [orderNo, userId, user[0].username || '', 'membership', `购买${level[0].name}`, paymentType, orderAmount, actualPrice, orderStatus, confirmDays, deadline]
      )

      calcCommission(productId, 'membership', orderAmount, userId)

      res.json({
        code: 200, msg: '购买成功',
        data: {
          levelName: level[0].name,
          expireTime: expireTime.toISOString(),
          payType: paymentType,
          couponDiscount,
          couponName: usedCouponName,
          finalAmount: actualPrice,
          gifts: {
            points: totalGiftPoints,
            balance: totalGiftBalance,
            experience: totalGiftExperience,
            couponCount: allGiftCoupons.length,
            dataLimitMb: totalGiftDataMb,
            fileLimitMb: totalGiftFileMb,
            isFirstLevel: isFirstLevelPurchase
          }
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  async function determinePurchaseType(userId, newLevelId) {
    const existing = await query(
      `SELECT id, expire_time FROM user_memberships WHERE user_id=? AND level_id=? ORDER BY expire_time DESC LIMIT 1`,
      [userId, newLevelId]
    )
    if (existing.length && new Date(existing[0].expire_time) > new Date()) return 'renew'

    const current = await query(
      `SELECT um.level_id, ml.tier
       FROM user_memberships um
       JOIN membership_levels ml ON um.level_id = ml.id
       WHERE um.user_id = ? AND um.expire_time > NOW()
       ORDER BY ml.tier DESC
       LIMIT 1`,
      [userId]
    )
    if (!current.length) return 'buy'
    const currTier = current[0].tier || 1

    const newLevel = await query('SELECT tier FROM membership_levels WHERE id=?', [newLevelId])
    const newTier = newLevel.length ? newLevel[0].tier : 1

    if (newTier < currTier) return 'downgrade'
    return 'buy'
  }

  // ==================== 会员专属礼包领取 ====================

  app.get('/api/membership/daily-gift-status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const user = await query('SELECT level_id, expire_time FROM users WHERE id=?', [userId])
      if (!user.length || !user[0].level_id) return res.json({ code: 200, data: { enabled: false } })

      const levelId = user[0].level_id
      if (user[0].expire_time && new Date(user[0].expire_time) < new Date()) {
        return res.json({ code: 200, data: { enabled: false } })
      }

      const lv = await query(
        'SELECT daily_gift_enabled, daily_gift_interval_days, daily_gift_points, daily_gift_balance, daily_gift_experience FROM membership_levels WHERE id=?',
        [levelId]
      )
      if (!lv.length || !lv[0].daily_gift_enabled) return res.json({ code: 200, data: { enabled: false } })

      const intervalDays = Number(lv[0].daily_gift_interval_days) || 1
      const today = new Date().toISOString().slice(0, 10)

      const lastClaim = await query(
        'SELECT claim_date FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? ORDER BY claim_date DESC LIMIT 1',
        [userId, levelId, 'daily']
      )

      let canClaim = true
      let nextClaimDate = ''
      if (lastClaim.length) {
        const lastDate = new Date(lastClaim[0].claim_date)
        const todayDate = new Date(today)
        const diffDays = Math.floor((todayDate - lastDate) / 86400000)
        if (diffDays < intervalDays) {
          canClaim = false
          nextClaimDate = new Date(lastDate.getTime() + intervalDays * 86400000).toISOString().slice(0, 10)
        }
      }

      const parts = []
      if (Number(lv[0].daily_gift_points)) parts.push(`${lv[0].daily_gift_points}积分`)
      if (Number(lv[0].daily_gift_balance)) parts.push(`¥${lv[0].daily_gift_balance}`)
      if (Number(lv[0].daily_gift_experience)) parts.push(`${lv[0].daily_gift_experience}经验`)

      res.json({
        code: 200,
        data: {
          enabled: true,
          canClaim,
          nextClaimDate,
          intervalDays,
          desc: parts.join(' + ') || '专属礼包',
          points: Number(lv[0].daily_gift_points) || 0,
          balance: Number(lv[0].daily_gift_balance) || 0,
          experience: Number(lv[0].daily_gift_experience) || 0
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/membership/gift-status', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { daily: { enabled: false }, birthday: { enabled: false } } })

      const user = await query('SELECT level_id, expire_time, birthday FROM users WHERE id=?', [userId])
      if (!user.length || !user[0].level_id) return res.json({ code: 200, data: { daily: { enabled: false }, birthday: { enabled: false } } })

      const levelId = user[0].level_id
      const expired = user[0].expire_time && new Date(user[0].expire_time) < new Date()

      const lv = await query(
        'SELECT daily_gift_enabled, daily_gift_interval_days, daily_gift_points, daily_gift_balance, daily_gift_experience, birthday_gift_points, birthday_gift_balance, birthday_gift_experience FROM membership_levels WHERE id=?',
        [levelId]
      )

      const daily = { enabled: false, canClaim: false, nextClaimDate: '', intervalDays: 1, desc: '' }
      const birthday = { enabled: false, canClaim: false, desc: '' }

      if (!expired && lv.length) {
        // Daily
        if (lv[0].daily_gift_enabled) {
          daily.enabled = true
          daily.intervalDays = Number(lv[0].daily_gift_interval_days) || 1
          const parts = []
          if (Number(lv[0].daily_gift_points)) parts.push(lv[0].daily_gift_points + '积分')
          if (Number(lv[0].daily_gift_balance)) parts.push('¥' + lv[0].daily_gift_balance)
          if (Number(lv[0].daily_gift_experience)) parts.push(lv[0].daily_gift_experience + '经验')
          daily.desc = parts.join(' + ') || '专属礼包'

          const today = new Date().toISOString().slice(0, 10)
          const lastClaim = await query(
            'SELECT claim_date FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? ORDER BY claim_date DESC LIMIT 1',
            [userId, levelId, 'daily']
          )
          if (lastClaim.length) {
            const lastDate = new Date(lastClaim[0].claim_date)
            const todayDate = new Date(today)
            const diffDays = Math.floor((todayDate - lastDate) / 86400000)
            if (diffDays < daily.intervalDays) {
              daily.canClaim = false
              daily.nextClaimDate = new Date(lastDate.getTime() + daily.intervalDays * 86400000).toISOString().slice(0, 10)
            } else {
              daily.canClaim = true
            }
          } else {
            daily.canClaim = true
          }
        }

        // Birthday
        const bday = user[0].birthday
        if (bday) {
          const bdCheck = await query('SELECT MONTH(birthday)=MONTH(CURDATE()) AND DAY(birthday)=DAY(CURDATE()) AS ok FROM users WHERE id=?', [userId])
          if (bdCheck.length && bdCheck[0].ok) {
            const bParts = []
            if (Number(lv[0].birthday_gift_points)) bParts.push(lv[0].birthday_gift_points + '积分')
            if (Number(lv[0].birthday_gift_balance)) bParts.push('¥' + lv[0].birthday_gift_balance)
            if (Number(lv[0].birthday_gift_experience)) bParts.push(lv[0].birthday_gift_experience + '经验')
            if (bParts.length) {
              birthday.enabled = true
              birthday.desc = bParts.join(' + ')
              const todayStr = new Date().toISOString().slice(0, 10)
              const yearStr = new Date().getFullYear().toString()
              const claimedThisYear = await query(
                'SELECT id FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? AND claim_date LIKE ?',
                [userId, levelId, 'birthday', yearStr + '%']
              )
              birthday.canClaim = !claimedThisYear.length
            }
          }
        }
      }

      res.json({ code: 200, data: { daily, birthday } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/membership/claim-daily-gift', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const user = await query('SELECT level_id, expire_time FROM users WHERE id=?', [userId])
      if (!user.length || !user[0].level_id) return res.json({ code: 400, msg: '未开通会员' })
      const levelId = user[0].level_id

      // Check membership not expired
      if (user[0].expire_time && new Date(user[0].expire_time) < new Date()) {
        return res.json({ code: 400, msg: '会员已过期' })
      }

      const lv = await query(
        'SELECT daily_gift_enabled, daily_gift_interval_days, daily_gift_points, daily_gift_balance, daily_gift_experience, daily_gift_coupon_ids FROM membership_levels WHERE id=?',
        [levelId]
      )
      if (!lv.length || !lv[0].daily_gift_enabled) return res.json({ code: 400, msg: '当前等级未开启专属礼包' })

      const intervalDays = Number(lv[0].daily_gift_interval_days) || 1
      const today = new Date().toISOString().slice(0, 10)

      // Check last claim: must be at least interval_days ago (by calendar date)
      const lastClaim = await query(
        'SELECT claim_date FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? ORDER BY claim_date DESC LIMIT 1',
        [userId, levelId, 'daily']
      )
      if (lastClaim.length) {
        const lastDate = new Date(lastClaim[0].claim_date)
        const todayDate = new Date(today)
        const diffDays = Math.floor((todayDate - lastDate) / 86400000)
        if (diffDays < intervalDays) {
          const nextDate = new Date(lastDate.getTime() + intervalDays * 86400000).toISOString().slice(0, 10)
          return res.json({ code: 400, msg: `${intervalDays}天内已领取，下次可领取日期: ${nextDate}` })
        }
      }

      // Grant gifts
      const giftPoints = Number(lv[0].daily_gift_points) || 0
      const giftBalance = Number(lv[0].daily_gift_balance) || 0
      const giftExperience = Number(lv[0].daily_gift_experience) || 0

      if (giftPoints > 0) await query('UPDATE users SET points=points+? WHERE id=?', [giftPoints, userId])
      if (giftBalance > 0) await query('UPDATE users SET balance=balance+? WHERE id=?', [giftBalance, userId])
      if (giftExperience > 0) await query('UPDATE users SET experience=experience+? WHERE id=?', [giftExperience, userId])

      // Grant daily gift coupons
      let couponCount = 0
      const raw = lv[0].daily_gift_coupon_ids
      if (raw) {
        let coupons = []
        try {
          const parsed = JSON.parse(raw)
          if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object') coupons = parsed
        } catch (_e) { void _e }
        if (!coupons.length) {
          coupons = (raw || '').split(',').map(Number).filter(Boolean).map(id => ({ id }))
        }
        for (const gc of coupons) {
          if (gc.id) {
            const c = await query('SELECT * FROM coupons WHERE id=? AND status=?', [gc.id, '1'])
            if (!c.length) continue
            const ct = c[0]
            const expireTime = ct.expire_time || new Date(Date.now() + (ct.valid_days || 30) * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            const couponData = JSON.stringify({ name: ct.name, type: ct.type, value: Number(ct.value), minOrder: Number(ct.min_order), maxDiscount: Number(ct.max_discount), scope: ct.scope, targetIds: ct.target_ids, category: ct.category })
            await query('INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())', [userId, ct.id, 'unused', couponData, expireTime, ct.is_multi_use ? Number(ct.value) : null])
          } else {
            const couponData = JSON.stringify({ name: gc.name || '专属礼包券', type: gc.type || 'fixed', value: Number(gc.value) || 0, minOrder: Number(gc.minOrder) || 0, maxDiscount: Number(gc.maxDiscount) || 0, scope: gc.scope || 'all', targetIds: '', category: gc.category || 'member' })
            const expireTime = new Date(Date.now() + ((gc.validDays || 30) * 86400000)).toISOString().slice(0, 19).replace('T', ' ')
            await query('INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())', [userId, 0, 'unused', couponData, expireTime, null])
          }
          couponCount++
        }
      }

      // Record claim
      await query('INSERT IGNORE INTO user_gift_claims (user_id, level_id, gift_type, claim_date) VALUES (?,?,?,?)', [userId, levelId, 'daily', today])

      res.json({ code: 200, msg: '领取成功', data: { points: giftPoints, balance: giftBalance, experience: giftExperience, couponCount } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/membership/claim-birthday-gift', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const user = await query('SELECT level_id, expire_time, birthday FROM users WHERE id=?', [userId])
      if (!user.length || !user[0].level_id) return res.json({ code: 400, msg: '未开通会员' })

      if (!user[0].birthday) return res.json({ code: 400, msg: '未设置生日信息' })

      const bdCheck = await query('SELECT MONTH(birthday)=MONTH(CURDATE()) AND DAY(birthday)=DAY(CURDATE()) AS ok FROM users WHERE id=?', [userId])
      if (!bdCheck.length || !bdCheck[0].ok) {
        return res.json({ code: 400, msg: '今天不是您的生日' })
      }

      const today = new Date()

      if (user[0].expire_time && new Date(user[0].expire_time) < today) {
        return res.json({ code: 400, msg: '会员已过期' })
      }

      const levelId = user[0].level_id
      const lv = await query(
        'SELECT birthday_gift_points, birthday_gift_balance, birthday_gift_experience, birthday_gift_coupon_ids FROM membership_levels WHERE id=?',
        [levelId]
      )
      if (!lv.length) return res.json({ code: 400, msg: '等级不存在' })

      const todayStr = today.toISOString().slice(0, 10)
      const yearStr = today.getFullYear().toString()

      // Check not already claimed this year
      const claimed = await query(
        'SELECT id FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? AND claim_date=?',
        [userId, levelId, 'birthday', todayStr]
      )
      if (claimed.length) return res.json({ code: 400, msg: '今日已领取生日礼包' })

      const claimedThisYear = await query(
        'SELECT id FROM user_gift_claims WHERE user_id=? AND level_id=? AND gift_type=? AND claim_date LIKE ?',
        [userId, levelId, 'birthday', yearStr + '%']
      )
      if (claimedThisYear.length) return res.json({ code: 400, msg: '今年已领取过生日礼包' })

      const giftPoints = Number(lv[0].birthday_gift_points) || 0
      const giftBalance = Number(lv[0].birthday_gift_balance) || 0
      const giftExperience = Number(lv[0].birthday_gift_experience) || 0

      if (giftPoints > 0) await query('UPDATE users SET points=points+? WHERE id=?', [giftPoints, userId])
      if (giftBalance > 0) await query('UPDATE users SET balance=balance+? WHERE id=?', [giftBalance, userId])
      if (giftExperience > 0) await query('UPDATE users SET experience=experience+? WHERE id=?', [giftExperience, userId])

      let couponCount = 0
      const raw = lv[0].birthday_gift_coupon_ids
      if (raw) {
        let coupons = []
        try {
          const parsed = JSON.parse(raw)
          if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object') coupons = parsed
        } catch (_e) { void _e }
        if (!coupons.length) {
          coupons = (raw || '').split(',').map(Number).filter(Boolean).map(id => ({ id }))
        }
        for (const gc of coupons) {
          if (gc.id) {
            const c = await query('SELECT * FROM coupons WHERE id=? AND status=?', [gc.id, '1'])
            if (!c.length) continue
            const ct = c[0]
            const expireTime = ct.expire_time || new Date(Date.now() + (ct.valid_days || 30) * 86400000).toISOString().slice(0, 19).replace('T', ' ')
            const couponData = JSON.stringify({ name: ct.name, type: ct.type, value: Number(ct.value), minOrder: Number(ct.min_order), maxDiscount: Number(ct.max_discount), scope: ct.scope, targetIds: ct.target_ids, category: ct.category })
            await query('INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())', [userId, ct.id, 'unused', couponData, expireTime, ct.is_multi_use ? Number(ct.value) : null])
          } else {
            const couponData = JSON.stringify({ name: gc.name || '生日礼包券', type: gc.type || 'fixed', value: Number(gc.value) || 0, minOrder: Number(gc.minOrder) || 0, maxDiscount: Number(gc.maxDiscount) || 0, scope: gc.scope || 'all', targetIds: '', category: gc.category || 'member' })
            const expireTime = new Date(Date.now() + ((gc.validDays || 30) * 86400000)).toISOString().slice(0, 19).replace('T', ' ')
            await query('INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value, receive_time) VALUES (?,?,?,?,?,?,NOW())', [userId, 0, 'unused', couponData, expireTime, null])
          }
          couponCount++
        }
      }

      await query('INSERT IGNORE INTO user_gift_claims (user_id, level_id, gift_type, claim_date) VALUES (?,?,?,?)', [userId, levelId, 'birthday', todayStr])

      res.json({ code: 200, msg: '生日快乐! 领取成功', data: { points: giftPoints, balance: giftBalance, experience: giftExperience, couponCount } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Membership Purchase History ====================
  app.get('/api/membership/purchases/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        `SELECT mp.*, mp2.name as product_name
         FROM membership_purchases mp
         LEFT JOIN membership_products mp2 ON mp.product_id=mp2.id
         WHERE mp.user_id=?
         ORDER BY mp.create_time DESC`,
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin: Membership Products List ====================
  app.get('/api/admin/membership/purchases', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT mp.*, u.nickname as userName
         FROM membership_purchases mp
         LEFT JOIN users u ON mp.user_id=u.id
         ORDER BY mp.create_time DESC LIMIT ? OFFSET ?`,
        [size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM membership_purchases')
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== Admin: Content Purchases List ====================
  app.get('/api/admin/content/purchases', async (req, res) => {
    try {
      if (!(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      const page = Number(req.query.page) || 1
      const size = Number(req.query.size) || 20
      const offset = (page - 1) * size
      const rows = await query(
        `SELECT cp.*, u.nickname as userName
         FROM content_purchases cp
         LEFT JOIN users u ON cp.user_id=u.id
         ORDER BY cp.create_time DESC LIMIT ? OFFSET ?`,
        [size, offset]
      )
      const total = await query('SELECT COUNT(*) as c FROM content_purchases')
      res.json({ code: 200, data: { records: rows, total: total[0].c, page, size } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== My Earnings (Author) ====================
  app.get('/api/content/earnings/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const total = await query(
        'SELECT COALESCE(SUM(commission_amount),0) as total FROM content_purchases WHERE author_id=?',
        [userId]
      )
      const records = await query(
        `SELECT cp.*, COALESCE(cp2.title, a.name) as content_title
         FROM content_purchases cp
         LEFT JOIN community_posts cp2 ON cp.content_type='post' AND cp.content_id=cp2.id
         LEFT JOIN app_store a ON cp.content_type='app' AND cp.content_id=a.id
         WHERE cp.author_id=?
         ORDER BY cp.create_time DESC LIMIT 50`,
        [userId]
      )
      res.json({ code: 200, data: { total: total[0]?.total || 0, records } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ==================== SysConfig: Split Profit Toggle ====================
  app.get('/api/content/config', async (req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key IN ('content_split_enabled','content_split_global_rate')")
      const config = {}
      rows.forEach(r => { config[r.config_key] = r.config_value })
      res.json({ code: 200, data: config })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = { contentRoutes, recalcUserMembership, getUserLevel }
