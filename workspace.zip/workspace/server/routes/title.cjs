const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function titleRoutes(app) {
  app.get('/api/title/list', async (req, res) => {
    try {
      const list = await query("SELECT * FROM custom_titles WHERE status='1' ORDER BY sort_order ASC")
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/all', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const list = await query('SELECT * FROM custom_titles ORDER BY sort_order ASC')
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/title/save', authRequired, requirePermission('add'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { id, name, icon, color, bgColor, description, conditionType, conditionValue, sortOrder, status } = req.body
      if (id) {
        await query(`UPDATE custom_titles SET name=?,icon=?,color=?,bg_color=?,description=?,condition_type=?,condition_value=?,sort_order=?,status=? WHERE id=?`,
          [name, icon || '', color || '#409EFF', bgColor || '#ecf5ff', description || '', conditionType || 'manual', conditionValue || '', sortOrder || 0, status || '1', id])
        logFromReq(req, 'update', 'title', id, `更新称号"${name}"`)
      } else {
        const result = await query(`INSERT INTO custom_titles (name,icon,color,bg_color,description,condition_type,condition_value,sort_order,status) VALUES (?,?,?,?,?,?,?,?,?)`,
          [name, icon || '', color || '#409EFF', bgColor || '#ecf5ff', description || '', conditionType || 'manual', conditionValue || '', sortOrder || 0, status || '1'])
        logFromReq(req, 'create', 'title', result.insertId || 0, `新增称号"${name}"`)
      }
      res.json({ code: 200, message: '保存成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/title/:id', authRequired, requirePermission('delete'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      await query('DELETE FROM user_titles WHERE title_id=?', [req.params.id])
      await query('DELETE FROM custom_titles WHERE id=?', [req.params.id])
      logFromReq(req, 'delete', 'title', req.params.id, `删除称号ID:${req.params.id}`)
      res.json({ code: 200, message: '删除成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/:id/grant-title', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const userId = parseInt(req.params.id)
      const { titleId } = req.body
      const existing = await query('SELECT id FROM user_titles WHERE user_id=? AND title_id=?', [userId, titleId])
      if (existing.length === 0) {
        await query('INSERT INTO user_titles (user_id, title_id, grant_by) VALUES (?,?,?)', [userId, titleId, '管理员'])
      }
      const title = await query('SELECT name FROM custom_titles WHERE id=?', [titleId])
      const titleName = title.length > 0 ? title[0].name : ''
      await query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [titleId, titleName, userId])
      logFromReq(req, 'update', 'title', titleId, `授予用户${userId}称号ID:${titleId}`)
      res.json({ code: 200, message: '授予成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.delete('/api/user/:id/revoke-title/:titleId', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const userId = parseInt(req.params.id)
      const titleId = parseInt(req.params.titleId)
      await query('DELETE FROM user_titles WHERE user_id=? AND title_id=?', [userId, titleId])
      await query('UPDATE users SET active_title_id=0, active_title_name="" WHERE id=? AND active_title_id=?', [userId, titleId])
      logFromReq(req, 'delete', 'title', titleId, `撤销用户${userId}称号ID:${titleId}`)
      res.json({ code: 200, message: '撤销成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/user/active-title', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { titleId } = req.body
      const row = titleId > 0
        ? await query('SELECT t.name FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=? AND ut.title_id=?', [userId, titleId])
        : []
      const name = row.length > 0 ? row[0].name : ''
      await query('UPDATE users SET active_title_id=?, active_title_name=? WHERE id=?', [titleId || 0, name, userId])
      res.json({ code: 200, message: '设置成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/user/titles', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const list = await query(`SELECT t.*, ut.grant_time FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=? ORDER BY ut.grant_time DESC`, [userId])
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/user/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id)
      const list = await query(`SELECT t.*, ut.grant_time FROM custom_titles t JOIN user_titles ut ON t.id=ut.title_id WHERE ut.user_id=?`, [userId])
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/title/:id/users', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const titleId = parseInt(req.params.id)
      const list = await query(
        `SELECT u.id, u.username, u.nickname, u.avatar, u.level_name as levelName,
                ut.grant_time as grantTime, ut.is_active as isActive
         FROM user_titles ut JOIN users u ON ut.user_id = u.id
         WHERE ut.title_id = ? ORDER BY ut.grant_time DESC`, [titleId]
      )
      res.json({ code: 200, data: list })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // ===== 称号自动扫描 =====

  // GET /api/admin/titles/scan-config
  app.get('/api/admin/titles/scan-config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_interval'")
      const interval = rows.length > 0 ? parseInt(rows[0].config_value) || 60 : 60
      const lastScan = await query("SELECT config_value FROM sys_config WHERE config_key='title_scan_last'")
      res.json({ code: 200, data: { interval, lastScan: lastScan.length > 0 ? lastScan[0].config_value : '' } })
    } catch (e) { res.status(500).json({ code: 500, msg: e.message }) }
  })

  // PUT /api/admin/titles/scan-config
  app.put('/api/admin/titles/scan-config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { interval } = req.body
      const min = Math.max(1, Math.min(1440, parseInt(interval) || 60))
      await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('title_scan_interval',?,?) ON DUPLICATE KEY UPDATE config_value=?", [String(min), '称号自动扫描间隔(分钟)', String(min)])
      res.json({ code: 200, msg: '设置成功', data: { interval: min } })
    } catch (e) { res.status(500).json({ code: 500, msg: e.message }) }
  })

  app.post('/api/admin/titles/check', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { userId } = req.body
      const targetUserId = Number(userId) || 0
      const result = await checkAndGrantAutoTitles(targetUserId)
      res.json({ code: 200, msg: '检查完成', data: result })
    } catch (e) { res.status(500).json({ code: 500, msg: e.message }) }
  })
}

async function checkAndGrantAutoTitles(userId) {
  const titles = await query("SELECT * FROM custom_titles WHERE condition_type != 'manual' AND status='1'")
  if (!titles.length) return { unlocked: [], stats: {} }

  const { stats, rolesArr } = await computeUserStats(userId)

  const unlocked = []
  for (const t of titles) {
    const key = t.condition_type
    const threshold = key === 'has_role' ? 1 : Number(t.condition_value)
    let currentValue
    if (key === 'has_role') {
      currentValue = rolesArr.includes(String(t.condition_value)) ? 1 : 0
    } else {
      currentValue = stats[key] || 0
    }
    if (currentValue >= threshold) {
      const existing = await query('SELECT id FROM user_titles WHERE user_id=? AND title_id=?', [userId, t.id])
      if (!existing.length) {
        await query('INSERT INTO user_titles (user_id, title_id, grant_by) VALUES (?,?,?)', [userId, t.id, 'auto'])
        unlocked.push({ id: t.id, name: t.name })
      }
    }
  }
  return { unlocked, stats }
}

async function computeUserStats(userId) {
  const [
    userRows,
    coinRows,
    likeReceivedRows,
    likesGivenRows,
    followerRows,
    followingRows,
    collectionRows,
    favoriteRows,
    votePartRows,
    taskRows,
    topicFollowRows,
    draftRows,
    mallOrderRows,
    chatMsgRows,
    contentPurchaseRows,
    appRows,
    appCommentRows,
    postSharedRows,
    expRows,
    pointsEarnedRows,
    pointsSpentRows,
    membershipRows,
    rechargeRows,
    inviteRows,
    balanceSpentRows,
    reportRows,
    withdrawRows,
    gamePlayedRows,
    gameWonRows,
    mallReviewRows,
    couponRows,
    messageRows,
    ratingRows,
    trustRows,
    appFavRows,
    colFavRows,
    mallFavRows,
    verifyRows
  ] = await Promise.all([
    query(
      `SELECT (SELECT COUNT(*) FROM community_posts WHERE user_id=? AND status IN ('published','reviewed')) as post_count,
              (SELECT COUNT(*) FROM community_comments WHERE user_id=?) as comment_count,
              (SELECT COUNT(*) FROM checkin_records WHERE user_id=?) as checkin_days,
              roles
       FROM users WHERE id=?`, [userId, userId, userId, userId]
    ),
    query('SELECT COALESCE(SUM(amount),0) as total FROM balance_records WHERE user_id=? AND type=?', [userId, 'earn']),
    query('SELECT COALESCE(SUM(like_count),0) as total FROM community_posts WHERE user_id=? AND status IN (\'published\',\'reviewed\')', [userId]),
    query('SELECT COUNT(*) as total FROM community_likes WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM user_follows WHERE following_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM user_follows WHERE follower_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM community_collections WHERE user_id=? AND is_deleted=0', [userId]),
    query('SELECT COUNT(*) as total FROM community_favorites WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM community_vote_records WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM task_records WHERE user_id=? AND status=\'completed\'', [userId]),
    query('SELECT COUNT(*) as total FROM topic_follows WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM community_drafts WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM mall_orders WHERE user_id=? AND status<>\'cancelled\'', [userId]),
    query('SELECT COUNT(*) as total FROM chat_room_messages WHERE from_user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM content_purchases WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM app_purchases WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM app_comments WHERE user_id=?', [userId]),
    query('SELECT COALESCE(SUM(share_count),0) as total FROM community_posts WHERE user_id=? AND status IN (\'published\',\'reviewed\')', [userId]),
    query('SELECT COALESCE(SUM(amount),0) as total FROM experience_records WHERE user_id=?', [userId]),
    query('SELECT COALESCE(SUM(points),0) as total FROM points_records WHERE user_id=? AND type=\'earn\'', [userId]),
    query('SELECT COALESCE(SUM(points),0) as total FROM points_records WHERE user_id=? AND type=\'expense\'', [userId]),
    query('SELECT COUNT(*) as total FROM membership_purchases WHERE user_id=?', [userId]),
    query('SELECT COALESCE(SUM(amount),0) as total FROM recharge_orders WHERE user_id=? AND status=\'paid\'', [userId]),
    query('SELECT COUNT(*) as total FROM invite_codes WHERE created_by=? AND use_count>0', [userId]),
    query('SELECT COALESCE(SUM(amount),0) as total FROM balance_records WHERE user_id=? AND type IN (\'expense\',\'consume\')', [userId]),
    query('SELECT COUNT(*) as total FROM community_reports WHERE reporter_id=?', [userId]),
    query('SELECT COALESCE(SUM(amount),0) as total FROM withdraw_records WHERE user_id=? AND status=\'completed\'', [userId]),
    query('SELECT COUNT(*) as total FROM game_records WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM game_records WHERE user_id=? AND result=\'win\'', [userId]),
    query('SELECT COUNT(*) as total FROM mall_reviews WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM coupon_usage_logs WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM private_messages WHERE from_user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM community_ratings WHERE user_id=?', [userId]),
    query('SELECT level as total FROM community_trust_levels WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM app_favorites WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM collection_favorites WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM mall_favorites WHERE user_id=?', [userId]),
    query('SELECT COUNT(*) as total FROM verification_requests WHERE user_id=? AND status=\'approved\'', [userId])
  ])

  const u = userRows[0]
  const stats = {
    post_count: u?.post_count || 0,
    like_received: Number(likeReceivedRows[0]?.total || 0),
    comment_count: u?.comment_count || 0,
    checkin_days: u?.checkin_days || 0,
    coin_received: Number(coinRows[0]?.total || 0),
    likes_given: likesGivenRows[0]?.total || 0,
    follower_count: followerRows[0]?.total || 0,
    following_count: followingRows[0]?.total || 0,
    collection_count: collectionRows[0]?.total || 0,
    favorite_count: favoriteRows[0]?.total || 0,
    vote_participated: votePartRows[0]?.total || 0,
    task_completed: taskRows[0]?.total || 0,
    topic_followed: topicFollowRows[0]?.total || 0,
    draft_count: draftRows[0]?.total || 0,
    mall_orders: mallOrderRows[0]?.total || 0,
    chat_messages: chatMsgRows[0]?.total || 0,
    content_purchased: contentPurchaseRows[0]?.total || 0,
    app_count: appRows[0]?.total || 0,
    app_comments: appCommentRows[0]?.total || 0,
    post_shared: Number(postSharedRows[0]?.total || 0),
    experience_total: Number(expRows[0]?.total || 0),
    points_earned: pointsEarnedRows[0]?.total || 0,
    points_spent: pointsSpentRows[0]?.total || 0,
    membership_count: membershipRows[0]?.total || 0,
    recharge_total: Number(rechargeRows[0]?.total || 0),
    invite_success: inviteRows[0]?.total || 0,
    balance_spent: Number(balanceSpentRows[0]?.total || 0),
    report_count: reportRows[0]?.total || 0,
    withdraw_total: Number(withdrawRows[0]?.total || 0),
    game_played: gamePlayedRows[0]?.total || 0,
    game_won: gameWonRows[0]?.total || 0,
    mall_review_count: mallReviewRows[0]?.total || 0,
    coupon_used_count: couponRows[0]?.total || 0,
    message_sent: messageRows[0]?.total || 0,
    rating_count: ratingRows[0]?.total || 0,
    trust_level: trustRows[0]?.total || 0,
    app_favorite_count: appFavRows[0]?.total || 0,
    collection_favorite_count: colFavRows[0]?.total || 0,
    mall_favorite_count: mallFavRows[0]?.total || 0,
    verified: verifyRows[0]?.total || 0
  }

  let rolesArr = []
  try { rolesArr = JSON.parse(u?.roles || '[]') } catch {}
  return { stats, rolesArr }
}

module.exports.checkAndGrantAutoTitles = checkAndGrantAutoTitles
