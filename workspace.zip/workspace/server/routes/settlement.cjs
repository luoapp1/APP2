/**
 * Settlement / 确认收货结算系统
 *
 * Flow:
 * 1. 创建订单 (createOrder) → status=shipped, 资金冻结
 * 2. 确认收货 (confirmOrder) → status=completed, 资金解冻转入卖家
 * 3. 申请退款 (requestRefund) → status=refunding
 * 4. 同意/拒绝退款 (respondRefund) → status=refunded / 退回 shipped
 * 5. 管理员审核退款 (adminRefund)
 *
 * 定时自动确认: 启动时注册 setInterval, 每分钟检查过期订单
 */

const { query, getPool } = require('../database.cjs')
const { sendNotificationEmail, getAdminEmails } = require('./email.cjs')

async function addNotification({ fromUserId, fromUserName, targetUserId, title, content, type = 'system' }) {
  try {
    let name = fromUserName || ''
    if (!name && fromUserId > 0) {
      const users = await query('SELECT username FROM users WHERE id=?', [fromUserId])
      name = users[0]?.username || ''
    }
    await query(
      `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [title, content, type, targetUserId || 0, fromUserId || 0, name]
    )
  } catch (e) { console.error('[settlement] notify failed:', e.message) }
}

function parseGiftCouponsForRefund(json) {
  if (!json) return []
  try {
    const arr = JSON.parse(json)
    return (Array.isArray(arr) ? arr : []).map(c => typeof c === 'string' ? c : (c.name || '')).filter(Boolean)
  } catch { return [] }
}

async function cleanupPurchaseAfterRefund(order) {
  const buyerId = order.buyer_id
  const orderType = order.order_type
  const refId = order.ref_id || 0
  const refTable = order.ref_table || ''

  try {
    if (orderType === 'app_purchase') {
      // 删除应用购买记录
      if (refId > 0) {
        await query('DELETE FROM app_purchases WHERE app_id=? AND user_id=?', [refId, buyerId])
      }
      // 也清理可能的内容购买记录
      await query('DELETE FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [refTable || 'app_store', refId, buyerId])
      // 清理社区附件购买
      await query('DELETE FROM community_attach_purchases WHERE user_id=? AND post_id=?', [buyerId, refId])
    } else if (orderType === 'content_purchase') {
      // 删除内容购买记录
      await query('DELETE FROM content_purchases WHERE content_type=? AND content_id=? AND user_id=?', [refTable, refId, buyerId])
      // 如果是应用内容，也删除应用购买记录
      if (refTable === 'app_store') {
        await query('DELETE FROM app_purchases WHERE app_id=? AND user_id=?', [refId, buyerId])
      }
      // 清理社区附件购买
      await query('DELETE FROM community_attach_purchases WHERE user_id=? AND post_id=?', [buyerId, refId])
    } else if (orderType === 'membership') {
      const purchases = await query(
        'SELECT * FROM membership_purchases WHERE user_id=? AND amount=? ORDER BY create_time DESC LIMIT 1',
        [buyerId, order.paid_amount]
      )
      let purchase = purchases.length ? purchases[0] : null
      if (!purchase) {
        const latest = await query(
          'SELECT * FROM membership_purchases WHERE user_id=? ORDER BY create_time DESC LIMIT 1',
          [buyerId]
        )
        purchase = latest.length ? latest[0] : null
      }

      if (purchase) {
        // 1. 扣回赠品
        const gPoints = Number(purchase.gift_points) || 0
        const gBalance = Number(purchase.gift_balance) || 0
        const gExperience = Number(purchase.gift_experience) || 0
        const gDataMb = Number(purchase.gift_data_mb) || 0
        const gFileMb = Number(purchase.gift_file_mb) || 0

        if (gPoints > 0) {
          await query('UPDATE users SET points = GREATEST(0, points - ?) WHERE id=?', [gPoints, buyerId])
          const curPts = await query('SELECT points FROM users WHERE id=?', [buyerId])
          await query(
            'INSERT INTO points_records (user_id, user_name, type, points, balance, source, description) VALUES (?,(SELECT username FROM users WHERE id=?),?,?,?,?,?)',
            [buyerId, buyerId, 'expense', gPoints, curPts[0]?.points || 0, '会员退款扣回', `退款扣回${purchase.level_name}赠送积分`]
          )
        }
        if (gBalance > 0) {
          await query('UPDATE users SET balance = GREATEST(0, balance - ?) WHERE id=?', [gBalance, buyerId])
          const curBal = await query('SELECT balance FROM users WHERE id=?', [buyerId])
          await query(
            'INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description) VALUES (?,(SELECT username FROM users WHERE id=?),?,?,?,?,?)',
            [buyerId, buyerId, 'expense', gBalance, curBal[0]?.balance || 0, '会员退款扣回', `退款扣回${purchase.level_name}赠送余额`]
          )
        }
        if (gExperience > 0) {
          await query('UPDATE users SET experience = GREATEST(0, experience - ?) WHERE id=?', [gExperience, buyerId])
        }
        if (gDataMb > 0) {
          await query('UPDATE users SET bonus_data_limit_mb = GREATEST(0, bonus_data_limit_mb - ?) WHERE id=?', [gDataMb, buyerId])
        }
        if (gFileMb > 0) {
          await query('UPDATE users SET bonus_file_limit_mb = GREATEST(0, bonus_file_limit_mb - ?) WHERE id=?', [gFileMb, buyerId])
        }
        // 扣回赠送的优惠券（失效处理）
        if (Number(purchase.gift_coupon_count) > 0) {
          const level = await query('SELECT gift_coupon_ids FROM membership_levels WHERE id=?', [purchase.level_id])
          const prod = await query('SELECT gift_coupon_ids FROM membership_products WHERE id=?', [purchase.product_id])
          const levelCoupons = parseGiftCouponsForRefund(level[0]?.gift_coupon_ids || null)
          const planCoupons = parseGiftCouponsForRefund(prod[0]?.gift_coupon_ids || null)
          const allCouponNames = [...levelCoupons, ...planCoupons]
          if (allCouponNames.length) {
            await query(
              `UPDATE user_coupons uc
               JOIN coupons c ON uc.coupon_id = c.id
               SET uc.status = 'expired'
               WHERE uc.user_id = ? AND c.name IN (${allCouponNames.map(() => '?').join(',')})
               AND uc.status = 'unused' AND uc.create_time >= ?`,
              [buyerId, ...allCouponNames, purchase.create_time]
            )
          }
        }

        // 2. 缩短/删除 user_memberships
        const durationDays = Number(purchase.duration_days) || 0
        if (durationDays > 0) {
          if (purchase.purchase_type === 'renew') {
            // 续费：缩短到期时间
            await query(
              'UPDATE user_memberships SET expire_time = DATE_SUB(expire_time, INTERVAL ? DAY) WHERE user_id=? AND level_id=? AND expire_time > NOW() ORDER BY expire_time DESC LIMIT 1',
              [durationDays, buyerId, purchase.level_id]
            )
            // 清理已过期的
            await query('DELETE FROM user_memberships WHERE user_id=? AND expire_time <= NOW()', [buyerId])
          } else {
            // 新购买/降级：删除该条
            await query(
              'DELETE FROM user_memberships WHERE user_id=? AND level_id=? ORDER BY expire_time DESC LIMIT 1',
              [buyerId, purchase.level_id]
            )
          }

          // 回退低等级延长
          const lowerIds = purchase.lower_extended_ids
          if (lowerIds) {
            let parsed = []
            try { parsed = JSON.parse(lowerIds) } catch {}
            for (const entry of parsed) {
              const [umId, lvId, oldExpireStr] = entry.split(':')
              if (umId && oldExpireStr) {
                await query('UPDATE user_memberships SET expire_time=? WHERE id=? AND user_id=?',
                  [oldExpireStr.slice(0, 19).replace('T', ' '), umId, buyerId])
              }
            }
            // 清理已过期的
            await query('DELETE FROM user_memberships WHERE user_id=? AND expire_time <= NOW()', [buyerId])
          }
        }

        // 3. 删除购买记录
        await query('DELETE FROM membership_purchases WHERE id=?', [purchase.id])

        // 4. 回收称号
        const level2 = await query('SELECT title_id FROM membership_levels WHERE id=?', [purchase.level_id])
        if (level2.length && level2[0].title_id) {
          await query('DELETE FROM user_titles WHERE user_id=? AND title_id=?', [buyerId, level2[0].title_id])
          await query('UPDATE users SET active_title_id=NULL WHERE id=? AND active_title_id=?', [buyerId, level2[0].title_id])
        }

        // 5. 回收头像框
        const level3 = await query('SELECT frame_id FROM membership_levels WHERE id=?', [purchase.level_id])
        if (level3.length && level3[0].frame_id) {
          await query('DELETE FROM user_avatar_frames WHERE user_id=? AND frame_id=?', [buyerId, level3[0].frame_id])
          await query('UPDATE users SET active_frame_id=NULL WHERE id=? AND active_frame_id=?', [buyerId, level3[0].frame_id])
        }

        // 6. 重新计算会员等级
        const remaining = await query(
          'SELECT * FROM user_memberships WHERE user_id=? AND expire_time > NOW() ORDER BY expire_time DESC',
          [buyerId]
        )
        if (remaining.length) {
          const best = remaining[0]
          await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?',
            [best.level_id, best.level_name, best.expire_time, buyerId])
        } else {
          await query("UPDATE users SET level_id=0, level_name='普通会员', expire_time=NULL WHERE id=?", [buyerId])
        }
      }
    }
  } catch (e) {
    console.error('清理退款购买记录失败:', e.message)
  }
}

async function isAdminById(userId) {
  if (!userId) return false
  try {
    const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
    if (rows && rows.length > 0) {
      try {
        const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
        return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
      } catch { return false }
      }
    } catch (e) { console.error('[settlement] isAdmin check failed:', userId, e.message) }
  return false
}

async function getSellerPointsMultiplier(sellerId) {
  if (!sellerId) return 1.0
  try {
    const rows = await query(
      `SELECT ml.points_multiplier FROM user_memberships um
       JOIN membership_levels ml ON um.level_id = ml.id
       WHERE um.user_id = ? AND um.expire_time > NOW()
       ORDER BY ml.tier DESC LIMIT 1`,
      [sellerId]
    )
    if (!rows.length) return 1.0
    return Number(rows[0].points_multiplier) || 1.0
  } catch { return 1.0 }
}

module.exports = function (app) {

  // ========== 生成订单号 ==========
  function genOrderNo(prefix = 'PO') {
    const ts = Date.now().toString(36).toUpperCase()
    const rand = Math.random().toString(36).substring(2, 6).toUpperCase()
    return `${prefix}${ts}${rand}`
  }

  // ========== 获取用户确认收货天数 ==========
  async function getConfirmDays(userId) {
    const configs = await query('SELECT * FROM settlement_config WHERE enabled=1 ORDER BY level_id DESC')
    if (!configs.length) return 7
    const user = await query('SELECT level_id FROM users WHERE id=?', [userId])
    const levelId = (user[0]?.level_id) || 0
    for (const c of configs) {
      if (c.level_id === levelId) return c.confirm_days
    }
    const def = configs.find(c => c.level_id === 0)
    return def ? def.confirm_days : 7
  }

  // ========== 创建订单（资金冻结） ==========
  // POST /api/settlement/create-order
  app.post('/api/settlement/create-order', async (req, res) => {
    try {
      const { buyerId, buyerName, sellerId, sellerName, orderType, orderDesc, refId, refTable, payType, totalAmount, couponId, couponDiscount, paidAmount } = req.body

      if (!buyerId || !orderType || !paidAmount) {
        return res.json({ code: 400, msg: '缺少必要参数' })
      }

      const confirmDays = await getConfirmDays(buyerId)
      const deadline = new Date(Date.now() + confirmDays * 86400000).toISOString().replace('T', ' ').slice(0, 19)
      const orderNo = genOrderNo(orderType === 'membership' ? 'MO' : orderType === 'app_purchase' ? 'AO' : 'PO')

      const result = await query(
        `INSERT INTO orders (order_no, buyer_id, buyer_name, seller_id, seller_name, order_type, order_desc,
          ref_id, ref_table, pay_type, total_amount, coupon_id, coupon_discount, paid_amount,
          status, confirm_days, confirm_deadline, shipped_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'shipped',?,?,NOW())`,
        [orderNo, buyerId, buyerName || '', sellerId || 0, sellerName || '', orderType, orderDesc || '',
         refId || 0, refTable || '', payType || 'balance', totalAmount || paidAmount, couponId || 0, couponDiscount || 0, paidAmount,
         confirmDays, deadline]
      )

      // 扣除买家资产 (冻结)
      if (payType === 'points') {
        await query('UPDATE users SET points = points - ? WHERE id=?', [paidAmount, buyerId])
        await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
                     VALUES (?,(SELECT username FROM users WHERE id=?),'expense',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
                     [buyerId, buyerId, paidAmount, buyerId, orderType, orderDesc || '', result.lastID || 0, 'order_freeze'])
      } else {
        await query('UPDATE users SET balance = balance - ? WHERE id=?', [paidAmount, buyerId])
        await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
                     VALUES (?,(SELECT username FROM users WHERE id=?),'expense',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
                     [buyerId, buyerId, paidAmount, buyerId, orderType, orderDesc || '', result.lastID || 0, 'order_freeze'])
      }

      // 通知买家
      addNotification({ targetUserId: buyerId, title: '订单已创建', content: `您的订单「${orderDesc || orderNo}」已创建，将在${confirmDays}天后自动确认收货。`, type: 'system' })
      // 通知卖家
      if (sellerId > 0) {
        addNotification({ targetUserId: sellerId, fromUserId: buyerId, fromUserName: buyerName, title: '新订单', content: `${buyerName || '买家'}购买了「${orderDesc || orderNo}」，金额${paidAmount}，将在${confirmDays}天后自动结算。`, type: 'system' })
      }

      // 订单邮件通知
      const adminEmails = await getAdminEmails()
      for (const adminEmail of adminEmails) {
        sendNotificationEmail('new_order', adminEmail, {
          username: '管理员',
          subject: '新订单通知',
          content: `${buyerName || '买家'}购买了「${orderDesc || orderNo}」，金额${paidAmount}。`
        })
        sendNotificationEmail('order_create', adminEmail, {
          username: '管理员',
          subject: '新订单已创建',
          content: `订单「${orderDesc || orderNo}」已创建，买家 ${buyerName || ''}，金额 ${paidAmount}。`
        })
      }

      res.json({ code: 200, msg: '订单已创建', data: { orderId: result.lastID, orderNo, confirmDeadline: deadline, confirmDays } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 确认收货 ==========
  // POST /api/settlement/confirm
  app.post('/api/settlement/confirm', async (req, res) => {
    try {
      const { orderId, userId } = req.body

      const orders = await query('SELECT * FROM orders WHERE id=?', [orderId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orders[0]

      if (order.status !== 'shipped') {
        return res.json({ code: 400, msg: '订单状态不允许确认收货' })
      }

      // 只有买家可以确认收货
      if (order.buyer_id !== userId) {
        return res.json({ code: 403, msg: '只有买家可以确认收货' })
      }

      const conn = await getPool().getConnection()
      try {
        await conn.beginTransaction()
        await conn.query('UPDATE orders SET status=?, confirmed_at=NOW() WHERE id=?', ['completed', orderId])

        // 资金解冻转入卖家
        if (order.seller_id > 0) {
          if (order.pay_type === 'points') {
            const multiplier = await getSellerPointsMultiplier(order.seller_id)
            const totalPoints = Math.round(Number(order.total_amount || order.paid_amount) * multiplier)
            await conn.query('UPDATE users SET points = points + ? WHERE id=?', [totalPoints, order.seller_id])
            await conn.query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
                         VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
                         [order.seller_id, order.seller_id, totalPoints, order.seller_id, order.order_type, `订单结算${multiplier !== 1 ? '(' + multiplier.toFixed(1) + '倍积分)' : ''}: ${order.order_desc || order.order_no}`, orderId, 'order_settle'])
          } else {
            await conn.query('UPDATE users SET balance = balance + ? WHERE id=?', [order.paid_amount, order.seller_id])
            await conn.query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
                         VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
                         [order.seller_id, order.seller_id, order.paid_amount, order.seller_id, order.order_type, `订单结算: ${order.order_desc || order.order_no}`, orderId, 'order_settle'])
          }
        }

        await conn.commit()
        conn.release()
      } catch (txErr) {
        await conn.rollback()
        conn.release()
        throw txErr
      }

      // 通知买家
      if (order.seller_id > 0) {
        const buyerUser = await query('SELECT username FROM users WHERE id=?', [order.buyer_id])
        addNotification({ targetUserId: order.seller_id, title: '买家已确认收货', content: `${buyerUser[0]?.username || '买家'}已确认收货「${order.order_desc || order.order_no}」，资金已到账。`, type: 'system' })
      }

      res.json({ code: 200, msg: '确认收货成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 申请退款 ==========
  // POST /api/settlement/request-refund
  app.post('/api/settlement/request-refund', async (req, res) => {
    try {
      const { orderId, userId, reason } = req.body

      const orders = await query('SELECT * FROM orders WHERE id=?', [orderId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orders[0]

      if (order.buyer_id !== userId) return res.json({ code: 403, msg: '只有买家可以申请退款' })
      if (order.status !== 'shipped') return res.json({ code: 400, msg: '当前状态不可申请退款' })

      await query(
        'UPDATE orders SET status=?, refund_reason=?, refund_requested_at=NOW() WHERE id=?',
        ['refunding', reason || '', orderId]
      )

      // 通知卖家
      if (order.seller_id > 0) {
        const buyerUser = await query('SELECT username FROM users WHERE id=?', [userId])
        addNotification({ targetUserId: order.seller_id, fromUserId: userId, fromUserName: buyerUser[0]?.username, title: '买家申请退款', content: `${buyerUser[0]?.username || '买家'}对订单「${order.order_desc || order.order_no}」申请退款，原因: ${reason || '未填写'}。`, type: 'system' })
      }

      res.json({ code: 200, msg: '退款申请已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 响应退款（卖家同意/拒绝） ==========
  // POST /api/settlement/respond-refund
  app.post('/api/settlement/respond-refund', async (req, res) => {
    try {
      const { orderId, userId, action, reason } = req.body // action: 'agree' | 'reject'

      const orders = await query('SELECT * FROM orders WHERE id=?', [orderId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orders[0]

      if (order.status !== 'refunding') return res.json({ code: 400, msg: '当前状态不可操作' })
      if (order.admin_review === 'pending') return res.json({ code: 400, msg: '已上报管理员审核，请等待管理员处理' })
      if (order.seller_id !== userId) return res.json({ code: 403, msg: '只有收款方可操作' })

      const sellerName = order.seller_name || ''

      if (action === 'agree') {
        await query('UPDATE orders SET status=?, refund_responded_at=NOW() WHERE id=?', ['refunded', orderId])
        // 退款给买家
        if (order.pay_type === 'points') {
          await query('UPDATE users SET points = points + ? WHERE id=?', [order.paid_amount, order.buyer_id])
          await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
                       VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
                       [order.buyer_id, order.buyer_id, order.paid_amount, order.buyer_id, 'refund', `退款: ${order.order_desc || order.order_no}`, orderId, 'order_refund'])
        } else {
          await query('UPDATE users SET balance = balance + ? WHERE id=?', [order.paid_amount, order.buyer_id])
          await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
                       VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
                       [order.buyer_id, order.buyer_id, order.paid_amount, order.buyer_id, 'refund', `退款: ${order.order_desc || order.order_no}`, orderId, 'order_refund'])
        }
        // 清理购买记录
        await cleanupPurchaseAfterRefund(order)
        // 通知买家
        addNotification({ targetUserId: order.buyer_id, fromUserId: userId, fromUserName: sellerName, title: '退款已通过', content: `卖家${sellerName}已同意退款「${order.order_desc || order.order_no}」，${order.pay_type === 'points' ? order.paid_amount + '积分' : '￥' + order.paid_amount}已退回。`, type: 'system' })
        res.json({ code: 200, msg: '退款成功' })
      } else {
        await query('UPDATE orders SET status=?, refund_reason=CONCAT(refund_reason, ?), refund_responded_at=NOW() WHERE id=?', ['shipped', reason ? ' [卖家拒绝: ' + reason + ']' : '', orderId])
        // 通知买家
        addNotification({ targetUserId: order.buyer_id, fromUserId: userId, fromUserName: sellerName, title: '退款被拒绝', content: `卖家${sellerName}拒绝了退款「${order.order_desc || order.order_no}」${reason ? '，原因: ' + reason : ''}。`, type: 'system' })
        res.json({ code: 200, msg: '已拒绝退款' })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 买家上报管理员 ==========
  // POST /api/settlement/report-to-admin
  app.post('/api/settlement/report-to-admin', async (req, res) => {
    try {
      const { orderId, userId, reason } = req.body

      const orders = await query('SELECT * FROM orders WHERE id=?', [orderId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orders[0]

      if (order.buyer_id !== userId) return res.json({ code: 403, msg: '只有买家可以上报' })
      if (order.status !== 'refunding') return res.json({ code: 400, msg: '当前状态不可上报管理员' })

      await query(
        `UPDATE orders SET refund_reason = CONCAT(COALESCE(refund_reason,''), ?), admin_review = 'pending' WHERE id=?`,
        [reason ? ' [买家上报: ' + reason + ']' : '', orderId]
      )
      // 通知管理员
      const buyerUser = await query('SELECT username FROM users WHERE id=?', [userId])
      addNotification({ targetUserId: 0, fromUserId: userId, fromUserName: buyerUser[0]?.username, title: '退款上报', content: `买家${buyerUser[0]?.username || ''}对订单「${order.order_desc || order.order_no}」上报管理员审核，原因: ${reason || '未填写'}。`, type: 'system' })
      res.json({ code: 200, msg: '已上报管理员审核' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 管理员查看待审核退款 ==========
  // GET /api/settlement/admin-reports
  app.get('/api/settlement/admin-reports', async (req, res) => {
    try {
      const list = await query(
        `SELECT o.*, b.username as buyer_name_full, s.username as seller_name_full
         FROM orders o
         LEFT JOIN users b ON o.buyer_id = b.id
         LEFT JOIN users s ON o.seller_id = s.id
         WHERE o.admin_review = 'pending' OR (o.status = 'refunding' AND o.refund_reason IS NOT NULL)
         ORDER BY o.create_time DESC`
      )
      res.json({ code: 200, data: { list } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 管理员审核退款 ==========
  // POST /api/settlement/admin-refund
  app.post('/api/settlement/admin-refund', async (req, res) => {
    try {
      const { orderId, userId, action, reason } = req.body

      if (!(await isAdminById(userId))) return res.json({ code: 403, msg: '仅管理员可操作' })

      const orders = await query('SELECT * FROM orders WHERE id=?', [orderId])
      if (!orders.length) return res.json({ code: 404, msg: '订单不存在' })
      const order = orders[0]

      if (action === 'agree') {
        await query(`UPDATE orders SET status=?, admin_review='reviewed', refund_reviewed_by=?, refund_reviewed_by_name=(SELECT username FROM users WHERE id=?),
          refund_reason=CONCAT(COALESCE(refund_reason,''), ?), reviewed_at=NOW() WHERE id=?`,
          ['refunded', userId, userId, reason ? ' [管理员同意: ' + reason + ']' : '', orderId])
        // 退款
        if (order.pay_type === 'points') {
          await query('UPDATE users SET points = points + ? WHERE id=?', [order.paid_amount, order.buyer_id])
          await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
                       VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
                       [order.buyer_id, order.buyer_id, order.paid_amount, order.buyer_id, 'admin_refund', `管理员退款: ${order.order_desc || order.order_no}`, orderId, 'order_refund'])
        } else {
          await query('UPDATE users SET balance = balance + ? WHERE id=?', [order.paid_amount, order.buyer_id])
          await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
                       VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
                       [order.buyer_id, order.buyer_id, order.paid_amount, order.buyer_id, 'admin_refund', `管理员退款: ${order.order_desc || order.order_no}`, orderId, 'order_refund'])
        }
        // 清理购买记录
        await cleanupPurchaseAfterRefund(order)
        // 通知买家和卖家
        const adminUser = await query('SELECT username FROM users WHERE id=?', [userId])
        const adminName = adminUser[0]?.username || '管理员'
        addNotification({ targetUserId: order.buyer_id, fromUserId: userId, fromUserName: adminName, title: '管理员审核退款通过', content: `管理员${adminName}已通过退款「${order.order_desc || order.order_no}」。${order.refund_reason ? '退款原因: ' + order.refund_reason : ''}${reason ? '。管理员意见: ' + reason : ''}` + (order.pay_type === 'points' ? `，${order.paid_amount}积分已退回。` : `，￥${order.paid_amount}已退回。`), type: 'system' })
        if (order.seller_id > 0) {
          addNotification({ targetUserId: order.seller_id, fromUserId: userId, fromUserName: adminName, title: '管理员审核退款通过', content: `管理员${adminName}已通过「${order.order_desc || order.order_no}」的退款申请，资金已退回买家。${order.refund_reason ? '退款原因: ' + order.refund_reason : ''}${reason ? '。管理员意见: ' + reason : ''}`, type: 'system' })
        }
        res.json({ code: 200, msg: '管理员审核退款成功' })
      } else {
        await query(`UPDATE orders SET status=?, admin_review='reviewed', refund_reviewed_by=?, refund_reviewed_by_name=(SELECT username FROM users WHERE id=?),
          refund_reason=CONCAT(COALESCE(refund_reason,''), ?), reviewed_at=NOW() WHERE id=?`,
          ['shipped', userId, userId, reason ? ' [管理员驳回: ' + reason + ']' : '', orderId])
        // 通知买家和卖家
        const adminUser = await query('SELECT username FROM users WHERE id=?', [userId])
        const adminName = adminUser[0]?.username || '管理员'
        addNotification({ targetUserId: order.buyer_id, fromUserId: userId, fromUserName: adminName, title: '管理员驳回退款', content: `管理员${adminName}驳回了退款「${order.order_desc || order.order_no}」${reason ? '，原因: ' + reason : ''}。` + (order.seller_id > 0 ? '可与卖家协商解决。' : '') })
        if (order.seller_id > 0) {
          addNotification({ targetUserId: order.seller_id, fromUserId: userId, fromUserName: adminName, title: '管理员驳回退款', content: `管理员${adminName}驳回了买家对「${order.order_desc || order.order_no}」的退款申请${reason ? '，原因: ' + reason : ''}。` })
        }
        res.json({ code: 200, msg: '已驳回退款申请' })
      }
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 查询订单列表 ==========
  // GET /api/settlement/orders?userId=&type=&status=
  app.get('/api/settlement/orders', async (req, res) => {
    try {
      const { userId, type, status: st, page = 1, pageSize = 20 } = req.query
      const conds = []
      const params = []

      if (userId) { conds.push('(o.buyer_id=? OR o.seller_id=?)'); params.push(Number(userId), Number(userId)) }
      if (type) { conds.push('o.order_type=?'); params.push(type) }
      if (st) { conds.push('o.status=?'); params.push(st) }

      const where = conds.length ? 'WHERE ' + conds.join(' AND ') : ''
      const offset = (Number(page) - 1) * Number(pageSize)

      const list = await query(
        `SELECT o.*, b.username as buyer_name_full, s.username as seller_name_full
         FROM orders o
         LEFT JOIN users b ON o.buyer_id = b.id
         LEFT JOIN users s ON o.seller_id = s.id
         ${where} ORDER BY o.create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), offset]
      )
      const total = await query(`SELECT COUNT(*) as cnt FROM orders o ${where}`, params)

      res.json({ code: 200, data: { list, total: total[0]?.cnt || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 查询待结算统计 ==========
  // GET /api/settlement/pending-stats?userId=
  app.get('/api/settlement/pending-stats', async (req, res) => {
    try {
      const { userId } = req.query
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })

      const userIdNum = Number(userId)
      const [row] = await query(
        `SELECT
           COALESCE(SUM(CASE WHEN buyer_id=? AND status='shipped' AND pay_type!='points' THEN paid_amount ELSE 0 END),0) as out_balance,
           COALESCE(SUM(CASE WHEN buyer_id=? AND status='shipped' AND pay_type='points' THEN paid_amount ELSE 0 END),0) as out_points,
           COALESCE(SUM(CASE WHEN seller_id=? AND status='shipped' AND pay_type!='points' THEN paid_amount ELSE 0 END),0) as in_balance,
           COALESCE(SUM(CASE WHEN seller_id=? AND status='shipped' AND pay_type='points' THEN paid_amount ELSE 0 END),0) as in_points
         FROM orders WHERE ((buyer_id=? AND status='shipped') OR (seller_id=? AND status='shipped'))`,
        [userIdNum, userIdNum, userIdNum, userIdNum, userIdNum, userIdNum]
      )

      res.json({
        code: 200,
        data: {
          pendingOutBalance: row?.out_balance || 0,
          pendingOutPoints: row?.out_points || 0,
          pendingInBalance: row?.in_balance || 0,
          pendingInPoints: row?.in_points || 0
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 自动确认收货（定时任务） ==========
  async function autoConfirmExpired() {
    try {
      const expired = await query(
        `SELECT id FROM orders WHERE status='shipped' AND confirm_deadline IS NOT NULL AND confirm_deadline <= NOW()`
      )
      for (const o of expired) {
        try {
          const orders = await query('SELECT * FROM orders WHERE id=?', [o.id])
          if (!orders.length) continue
          const order = orders[0]
          await query('UPDATE orders SET status=?, confirmed_at=NOW() WHERE id=?', ['completed', o.id])
          if (order.seller_id > 0) {
            if (order.pay_type === 'points') {
              const multiplier = await getSellerPointsMultiplier(order.seller_id)
              const totalPoints = Math.round(Number(order.total_amount || order.paid_amount) * multiplier)
              await query('UPDATE users SET points = points + ? WHERE id=?', [totalPoints, order.seller_id])
              await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description, ref_id, ref_type)
                           VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT points FROM users WHERE id=?),?,?,?,?)`,
                           [order.seller_id, order.seller_id, totalPoints, order.seller_id, order.order_type, `自动结算${multiplier !== 1 ? '(' + multiplier.toFixed(1) + '倍积分)' : ''}: ${order.order_desc || order.order_no}`, o.id, 'auto_settle'])
            } else {
              await query('UPDATE users SET balance = balance + ? WHERE id=?', [order.paid_amount, order.seller_id])
              await query(`INSERT INTO balance_records (user_id, user_name, type, amount, balance, source, description, ref_id, ref_type)
                           VALUES (?,(SELECT username FROM users WHERE id=?),'earn',?, (SELECT balance FROM users WHERE id=?),?,?,?,?)`,
                           [order.seller_id, order.seller_id, order.paid_amount, order.seller_id, order.order_type, `自动结算: ${order.order_desc || order.order_no}`, o.id, 'auto_settle'])
            }
          }
        } catch (e) { console.error('[settlement] auto-settle order failed:', o.id, e.message) }
      }
    } catch (e) { console.error('[settlement] auto-settle batch failed:', e.message) }
  }

  // 自动确认已迁移至统一调度器 server/scheduler/tasks.cjs

  // ===== 后台：时效配置 CRUD =====
  app.get('/api/settlement/config', async (req, res) => {
    try {
      const list = await query('SELECT * FROM settlement_config ORDER BY level_id')
      res.json({ code: 200, data: { list } })
    } catch (e) { res.serverError(e) }
  })

  app.post('/api/settlement/config', async (req, res) => {
    try {
      const { levelId, levelName, confirmDays, enabled, balanceTransferEnabled, pointsTransferEnabled,
              singleMinBalance, singleMaxBalance, singleMinPoints, singleMaxPoints,
              dailyLimitBalanceAmount, dailyLimitPointsAmount, dailyLimitTimes, weeklyLimitTimes, yearlyLimitTimes,
              balanceTransferFee, pointsTransferFee, balanceToPointsRate, pointsToBalanceRate } = req.body
      await query(`INSERT INTO settlement_config (level_id, level_name, confirm_days, enabled,
        balance_transfer_enabled, points_transfer_enabled,
        single_min_balance, single_max_balance, single_min_points, single_max_points,
        daily_limit_balance_amount, daily_limit_points_amount, daily_limit_times, weekly_limit_times, yearly_limit_times,
        balance_transfer_fee, points_transfer_fee, balance_to_points_rate, points_to_balance_rate)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [levelId || 0, levelName || '普通用户', confirmDays || 7, enabled ?? 1,
         balanceTransferEnabled ?? 1, pointsTransferEnabled ?? 1,
         singleMinBalance || 0, singleMaxBalance || 0, singleMinPoints || 0, singleMaxPoints || 0,
         dailyLimitBalanceAmount || 0, dailyLimitPointsAmount || 0, dailyLimitTimes || 0, weeklyLimitTimes || 0, yearlyLimitTimes || 0,
         balanceTransferFee || 0, pointsTransferFee || 0, balanceToPointsRate || 1, pointsToBalanceRate || 1])
      res.json({ code: 200, msg: '配置已添加' })
    } catch (e) { res.serverError(e) }
  })

  app.put('/api/settlement/config/:id', async (req, res) => {
    try {
      const { levelId, levelName, confirmDays, enabled, balanceTransferEnabled, pointsTransferEnabled,
              singleMinBalance, singleMaxBalance, singleMinPoints, singleMaxPoints,
              dailyLimitBalanceAmount, dailyLimitPointsAmount, dailyLimitTimes, weeklyLimitTimes, yearlyLimitTimes,
              balanceTransferFee, pointsTransferFee, balanceToPointsRate, pointsToBalanceRate } = req.body
      await query(`UPDATE settlement_config SET level_id=?, level_name=?, confirm_days=?, enabled=?,
        balance_transfer_enabled=?, points_transfer_enabled=?,
        single_min_balance=?, single_max_balance=?, single_min_points=?, single_max_points=?,
        daily_limit_balance_amount=?, daily_limit_points_amount=?, daily_limit_times=?, weekly_limit_times=?, yearly_limit_times=?,
        balance_transfer_fee=?, points_transfer_fee=?, balance_to_points_rate=?, points_to_balance_rate=? WHERE id=?`,
        [levelId || 0, levelName || '普通用户', confirmDays || 7, enabled ?? 1,
         balanceTransferEnabled ?? 1, pointsTransferEnabled ?? 1,
         singleMinBalance || 0, singleMaxBalance || 0, singleMinPoints || 0, singleMaxPoints || 0,
         dailyLimitBalanceAmount || 0, dailyLimitPointsAmount || 0, dailyLimitTimes || 0, weeklyLimitTimes || 0, yearlyLimitTimes || 0,
         balanceTransferFee || 0, pointsTransferFee || 0, balanceToPointsRate || 1, pointsToBalanceRate || 1,
         req.params.id])
      res.json({ code: 200, msg: '配置已更新' })
    } catch (e) { res.serverError(e) }
  })

  // ===== 获取用户对应的结算规则 =====
  app.get('/api/settlement/user-config', async (req, res) => {
    try {
      const userId = parseInt(req.query.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '缺少userId' })

      const users = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })

      const user = users[0]
      const levelId = user.level_id || 0

      let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [levelId])
      if (!configs.length) {
        configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
      }
      if (!configs.length) {
        configs = [{
          confirm_days: 7, balance_transfer_enabled: 1, points_transfer_enabled: 1,
          single_min_balance: 0, single_max_balance: 0, single_min_points: 0, single_max_points: 0,
          daily_limit_balance_amount: 0, daily_limit_points_amount: 0, daily_limit_times: 0, weekly_limit_times: 0,
          yearly_limit_times: 0, balance_transfer_fee: 0, points_transfer_fee: 0,
          balance_to_points_rate: 1, points_to_balance_rate: 1
        }]
      }

      res.json({ code: 200, data: configs[0] })
    } catch (e) { res.serverError(e) }
  })

  // ===== 校验转出限额 =====
  app.post('/api/settlement/validate-transfer', async (req, res) => {
    try {
      const { userId, payType, amount } = req.body
      if (!userId || !amount || amount <= 0) return res.json({ code: 400, msg: '参数错误' })

      const users = await query('SELECT id, username, level_id, balance, points FROM users WHERE id=?', [userId])
      if (!users.length) return res.json({ code: 404, msg: '用户不存在' })
      const u = users[0]

      let configs = await query('SELECT * FROM settlement_config WHERE level_id=? AND enabled=1', [u.level_id || 0])
      if (!configs.length) configs = await query('SELECT * FROM settlement_config WHERE level_id=0 AND enabled=1')
      if (!configs.length) return res.json({ code: 200, data: { valid: true } })

      const cfg = configs[0]
      const isPoints = payType === 'points'

      // 开关检查
      if (isPoints && !cfg.points_transfer_enabled) return res.json({ code: 403, msg: '当前等级不允许积分转出' })
      if (!isPoints && !cfg.balance_transfer_enabled) return res.json({ code: 403, msg: '当前等级不允许余额转出' })

      // 余额/积分不足
      const currentBalance = isPoints ? u.points : u.balance
      if (currentBalance < amount) {
        return res.json({ code: 402, msg: isPoints ? '积分不足' : '余额不足' })
      }

      // 单次限额
      if (isPoints && cfg.single_max_points > 0 && amount > cfg.single_max_points) {
        return res.json({ code: 400, msg: `单次最多转出${cfg.single_max_points}积分` })
      }
      if (isPoints && cfg.single_min_points > 0 && amount < cfg.single_min_points) {
        return res.json({ code: 400, msg: `单次最少转出${cfg.single_min_points}积分` })
      }
      if (!isPoints && cfg.single_max_balance > 0 && amount > cfg.single_max_balance) {
        return res.json({ code: 400, msg: `单次最多转出${cfg.single_max_balance}元` })
      }
      if (!isPoints && cfg.single_min_balance > 0 && amount < cfg.single_min_balance) {
        return res.json({ code: 400, msg: `单次最少转出${cfg.single_min_balance}元` })
      }

      // 每日限额
      const today = new Date().toISOString().slice(0, 10)
      if (isPoints && cfg.daily_limit_points_amount > 0) {
        const todaySpent = await query(`SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type='points' AND status!='cancelled' AND date(create_time)=?`, [userId, today])
        if (todaySpent[0].total + amount > cfg.daily_limit_points_amount) {
          return res.json({ code: 400, msg: `每日积分转出上限${cfg.daily_limit_points_amount}，今日已用${todaySpent[0].total}` })
        }
      }
      if (!isPoints && cfg.daily_limit_balance_amount > 0) {
        const todaySpent = await query(`SELECT COALESCE(SUM(paid_amount),0) as total FROM orders WHERE buyer_id=? AND pay_type='balance' AND status!='cancelled' AND date(create_time)=?`, [userId, today])
        if (todaySpent[0].total + amount > cfg.daily_limit_balance_amount) {
          return res.json({ code: 400, msg: `每日余额转出上限${cfg.daily_limit_balance_amount}元，今日已用${todaySpent[0].total}` })
        }
      }

      // 次数限制
      if (cfg.daily_limit_times > 0) {
        const todayCnt = await query(`SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND status!='cancelled' AND date(create_time)=?`, [userId, today])
        if (todayCnt[0].cnt >= cfg.daily_limit_times) {
          return res.json({ code: 400, msg: `每日转出上限${cfg.daily_limit_times}次` })
        }
      }
      if (cfg.weekly_limit_times > 0) {
        const weekAgo = new Date(Date.now() - 7*86400000).toISOString().slice(0,10)
        const weekCnt = await query(`SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND status!='cancelled' AND create_time>=?`, [userId, weekAgo])
        if (weekCnt[0].cnt >= cfg.weekly_limit_times) {
          return res.json({ code: 400, msg: `每周转出上限${cfg.weekly_limit_times}次` })
        }
      }
      if (cfg.yearly_limit_times > 0) {
        const yearAgo = new Date(Date.now() - 365*86400000).toISOString().slice(0,10)
        const yearCnt = await query(`SELECT COUNT(*) as cnt FROM orders WHERE buyer_id=? AND status!='cancelled' AND create_time>=?`, [userId, yearAgo])
        if (yearCnt[0].cnt >= cfg.yearly_limit_times) {
          return res.json({ code: 400, msg: `每年转出上限${cfg.yearly_limit_times}次` })
        }
      }

      // 手续费信息
      let feeRate = 0, feeAmount = 0
      if (isPoints) feeRate = cfg.points_transfer_fee || 0
      else feeRate = cfg.balance_transfer_fee || 0
      if (feeRate > 0) feeAmount = Math.round(amount * feeRate) / 100

      res.json({ code: 200, data: { valid: true, feeRate, feeAmount, confirmDays: cfg.confirm_days } })
    } catch (e) { res.serverError(e) }
  })

  app.delete('/api/settlement/config/:id', async (req, res) => {
    try {
      await query('DELETE FROM settlement_config WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '配置已删除' })
    } catch (e) { res.serverError(e) }
  })
}
