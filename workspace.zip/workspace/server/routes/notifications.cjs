const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')

function notificationsRoutes(app) {

  app.get('/api/notifications/unread-count', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const rows = await query(
        `SELECT type, COUNT(*) as cnt FROM sys_notifications
         WHERE target_user_id = ? AND is_read = 0
         GROUP BY type`,
        [userId]
      )
      const result = { total: 0, system: 0, comment: 0, like: 0, follow: 0, mention: 0 }
      for (const r of rows) {
        result.total += r.cnt
        if (result[r.type] !== undefined) result[r.type] = r.cnt
      }
      res.json({ code: 200, data: result })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/notifications', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { type, page = 1, pageSize = 20, unread } = req.query

      let whereClause = 'target_user_id = ?'
      const params = [userId]

      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      }
      if (unread === '1') {
        whereClause += ' AND is_read = 0'
      }

      const list = await query(
        `SELECT n.id, n.title, n.content, n.type, n.target_url as targetUrl, n.target_user_id as targetUserId,
                n.from_user_id as fromUserId, n.from_user_name as fromUserName,
                n.from_user_avatar as fromUserAvatar, n.is_read as isRead,
                n.create_time as createTime
         FROM sys_notifications n
         WHERE ${whereClause}
         ORDER BY n.create_time DESC
         LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )

      const cnt = await query(
        `SELECT COUNT(*) as total FROM sys_notifications WHERE ${whereClause}`,
        params
      )

      res.setHeader('X-Route-Source', 'notifications-list')
      res.json({
        code: 200,
        data: {
          list,
          total: cnt[0]?.total || 0,
          page: Number(page),
          pageSize: Number(pageSize)
        }
      })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/notifications/read-all', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { type } = req.body || {}

      let whereClause = 'target_user_id = ? AND is_read = 0'
      const params = [userId]

      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      }

      await query(
        `UPDATE sys_notifications SET is_read = 1 WHERE ${whereClause}`,
        params
      )

      res.json({ code: 200, msg: '已全部标记为已读' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/notifications/:id/read', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const notificationId = Number(req.params.id)

      const rows = await query(
        'SELECT id, target_user_id FROM sys_notifications WHERE id = ?',
        [notificationId]
      )
      if (!rows || rows.length === 0) {
        return res.json({ code: 404, msg: '通知不存在' })
      }
      if (rows[0].target_user_id !== userId) {
        return res.json({ code: 403, msg: '无权操作此通知' })
      }

      await query(
        'UPDATE sys_notifications SET is_read = 1 WHERE id = ?',
        [notificationId]
      )

      res.json({ code: 200, msg: '已标记为已读' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/messages/conversations', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId

      const rows = await query(
        `SELECT
           CASE WHEN pm.from_user_id = ? THEN pm.to_user_id ELSE pm.from_user_id END as partnerId,
           pm.content, pm.image_url, pm.is_recalled, pm.create_time,
           SUM(CASE WHEN pm.to_user_id = ? AND pm.is_read = 0 THEN 1 ELSE 0 END) as unreadCount
         FROM private_messages pm
         INNER JOIN (
           SELECT
             CASE WHEN from_user_id = ? THEN to_user_id ELSE from_user_id END as partner,
             MAX(id) as max_id
           FROM private_messages
           WHERE from_user_id = ? OR to_user_id = ?
           GROUP BY partner
         ) lm ON lm.max_id = pm.id
         GROUP BY partnerId, pm.content, pm.image_url, pm.is_recalled, pm.create_time
         ORDER BY pm.create_time DESC
         LIMIT 50`,
        [userId, userId, userId, userId, userId]
      )

      if (!rows || rows.length === 0) {
        return res.json({ code: 200, data: [] })
      }

      const partnerIds = rows.map(r => r.partnerId)
      const placeholders = partnerIds.map(() => '?').join(',')
      const users = await query(
        `SELECT id, username, avatar FROM users WHERE id IN (${placeholders})`,
        partnerIds
      )
      const userMap = {}
      for (const u of users) {
        userMap[u.id] = u
      }

      const result = rows.map(r => {
        let lastContent = r.content || ''
        if (r.is_recalled) {
          lastContent = '[消息已撤回]'
        } else if (r.image_url) {
          lastContent = '[图片]'
        }
        return {
          userId: r.partnerId,
          userName: userMap[r.partnerId]?.username || '',
          avatar: userMap[r.partnerId]?.avatar || '',
          lastMessage: lastContent,
          lastTime: r.create_time,
          unreadCount: r.unreadCount || 0
        }
      })

      res.json({ code: 200, data: result })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

}

module.exports = notificationsRoutes
