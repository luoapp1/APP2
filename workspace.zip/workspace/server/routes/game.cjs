const { query } = require('../database.cjs')

function gameRoutes(app) {

  // ======================== 管理端 API ========================

  app.get('/api/game/list', async (_req, res) => {
    try {
      const rows = await query('SELECT id, game_type, enabled, create_time, update_time FROM game_configs')
      const gameDefs = {
        lottery: { name: '金币抽奖', icon: '🎰', desc: '9宫格抽奖赢好礼' },
        card_guess: { name: '卡片字母竞猜', icon: '🃏', desc: '翻牌竞猜赢大奖' },
        dice: { name: '大小点数竞猜', icon: '🎲', desc: '竞猜大小赢积分' },
        rps: { name: '剪刀石头布', icon: '✊', desc: '经典对决赢积分' },
      }

      // 统计今日参与数据
      const today = new Date().toISOString().slice(0, 10)
      const stats = await query(
        "SELECT game_type, COUNT(*) as cnt, SUM(points_spent) as spent FROM game_records WHERE DATE(create_time)=? GROUP BY game_type",
        [today]
      )
      const statMap = {}
      stats.forEach(s => { statMap[s.game_type] = { cnt: s.cnt || 0, spent: s.spent || 0 } })

      const list = Object.entries(gameDefs).map(([type, def]) => {
        const cfg = rows.find(r => r.game_type === type)
        return {
          gameType: type,
          name: def.name,
          icon: def.icon,
          desc: def.desc,
          enabled: cfg ? cfg.enabled : 0,
          todayCount: statMap[type]?.cnt || 0,
          todaySpent: statMap[type]?.spent || 0,
          hasConfig: !!cfg
        }
      })

      res.json({ code: 200, data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/game/config/:gameType', async (req, res) => {
    try {
      const { gameType } = req.params
      const rows = await query('SELECT * FROM game_configs WHERE game_type=?', [gameType])
      if (!rows.length) return res.json({ code: 200, data: null })
      const row = rows[0]
      res.json({
        code: 200,
        data: {
          id: row.id,
          gameType: row.game_type,
          enabled: row.enabled,
          config: typeof row.config_data === 'string' ? JSON.parse(row.config_data) : row.config_data,
          createTime: row.create_time,
          updateTime: row.update_time
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.post('/api/game/config/:gameType', async (req, res) => {
    try {
      const { gameType } = req.params
      const { enabled, config } = req.body
      if (!config) return res.json({ code: 400, msg: '配置数据不能为空' })

      // 校验概率
      if (config.grids) {
        const total = config.grids.reduce((s, g) => s + (Number(g.probability) || 0), 0)
        if (total > 100) return res.json({ code: 400, msg: '概率总和不能超过100%' })
      }

      const json = JSON.stringify(config)
      const existing = await query('SELECT id FROM game_configs WHERE game_type=?', [gameType])
      if (existing.length) {
        await query(
          'UPDATE game_configs SET config_data=?, enabled=?, update_time=NOW() WHERE game_type=?',
          [json, enabled !== undefined ? (enabled ? 1 : 0) : existing[0].enabled, gameType]
        )
      } else {
        await query(
          'INSERT INTO game_configs (game_type, config_data, enabled) VALUES (?,?,?)',
          [gameType, json, enabled !== undefined ? (enabled ? 1 : 0) : 0]
        )
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ======================== 会员折扣计算 ========================

  async function getMemberDiscount(userId) {
    try {
      const user = await query('SELECT level_id, expire_time FROM users WHERE id=?', [userId])
      if (!user.length || !user[0].level_id) return 1
      const u = user[0]
      if (u.expire_time && new Date(u.expire_time) < new Date()) return 1
      return { levelId: u.level_id }
    } catch { return 1 }
  }

  async function calcCost(baseCost, memberInfo, gameType) {
    if (memberInfo === 1 || !memberInfo) return baseCost
    const cfgs = await query('SELECT config_data FROM game_configs WHERE game_type=?', [gameType])
    if (!cfgs.length) return baseCost
    const config = typeof cfgs[0].config_data === 'string' ? JSON.parse(cfgs[0].config_data) : cfgs[0].config_data
    const discounts = config.memberDiscounts || []
    const d = discounts.find(d => d.levelId === memberInfo.levelId)
    if (!d) return baseCost
    return Math.floor(baseCost * d.discount)
  }

  // ======================== 金币抽奖 ========================

  app.post('/api/game/lottery/draw', async (req, res) => {
    try {
      const { userId, times } = req.body
      if (!userId) return res.json({ code: 400, msg: '请先登录' })
      const drawTimes = times === 10 ? 10 : 1

      const cfgs = await query('SELECT * FROM game_configs WHERE game_type=?', ['lottery'])
      if (!cfgs.length || !cfgs[0].enabled) return res.json({ code: 400, msg: '游戏已停用' })
      const config = typeof cfgs[0].config_data === 'string' ? JSON.parse(cfgs[0].config_data) : cfgs[0].config_data

      const baseCost = drawTimes === 10 ? (config.costPerDraw10 || config.costPerDraw * 10) : config.costPerDraw
      const memberInfo = await getMemberDiscount(userId)
      const actualCost = await calcCost(baseCost, memberInfo, 'lottery')

      const user = await query('SELECT points FROM users WHERE id=?', [userId])
      if (!user.length || user[0].points < actualCost) return res.json({ code: 400, msg: '积分不足' })

      // 检查保底
      const pityCount = config.pityCount || 0
      let streak = 0
      if (pityCount > 0) {
        const lastRecords = await query(
          'SELECT result FROM game_records WHERE user_id=? AND game_type=? ORDER BY id DESC LIMIT ?',
          [userId, 'lottery', pityCount]
        )
        for (const r of lastRecords) {
          if (r.result === 'lose') streak++
          else break
        }
      }

      const grids = config.grids || []
      const results = []
      for (let i = 0; i < drawTimes; i++) {
        let grid
        if (pityCount > 0 && streak >= pityCount) {
          const pityIdx = config.pityGridIndex || 0
          grid = grids.find(g => g.index === pityIdx) || grids[0]
          streak = 0
        } else {
          grid = pickByProbability(grids)
          if (grid && (grid.type === 'thanks' || grid.value <= 0)) {
            streak++
          } else {
            streak = 0
          }
        }
        results.push(grid)
      }

      // 扣除积分
      await query('UPDATE users SET points=points-? WHERE id=?', [actualCost, userId])
      await query(
        'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
        [userId, -actualCost, 'game', '金币抽奖消耗']
      )

      // 发放奖励 & 写记录
      let totalWon = 0
      const rewards = []
      for (const grid of results) {
        const prize = await grantPrize(userId, grid)
        if (prize.pointsWon) totalWon += prize.pointsWon
        rewards.push(prize)
        await query(
          'INSERT INTO game_records (user_id, game_type, result, points_spent, points_won, detail) VALUES (?,?,?,?,?,?)',
          [
            userId, 'lottery',
            prize.isWin ? 'win' : grid?.type === 'thanks' ? 'lose' : 'win',
            Math.floor(actualCost / drawTimes), prize.pointsWon || 0,
            JSON.stringify({ gridIndex: grid?.index, gridName: grid?.name, gridType: grid?.type, gridValue: grid?.value, ...prize })
          ]
        )
      }

      res.json({
        code: 200,
        data: {
          results: rewards.map((prize, i) => {
            const r = results[i]
            return {
              gridIndex: r?.index, name: r?.name, type: r?.type, value: r?.value,
              extra: prize?.extra || '', isWin: prize?.isWin || false
            }
          }),
          cost: actualCost,
          won: totalWon,
          streak
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ======================== 卡片字母竞猜 ========================

  app.post('/api/game/card-guess/flip', async (req, res) => {
    try {
      const { userId, cardIndex } = req.body
      if (!userId) return res.json({ code: 400, msg: '请先登录' })
      if (cardIndex === undefined || cardIndex < 0 || cardIndex > 2) return res.json({ code: 400, msg: '无效的卡片选择' })

      const cfgs = await query('SELECT * FROM game_configs WHERE game_type=?', ['card_guess'])
      if (!cfgs.length || !cfgs[0].enabled) return res.json({ code: 400, msg: '游戏已停用' })
      const config = typeof cfgs[0].config_data === 'string' ? JSON.parse(cfgs[0].config_data) : cfgs[0].config_data

      const baseCost = config.costPerFlip || 10
      const memberInfo = await getMemberDiscount(userId)
      const actualCost = await calcCost(baseCost, memberInfo, 'card_guess')

      const user = await query('SELECT points FROM users WHERE id=?', [userId])
      if (!user.length || user[0].points < actualCost) return res.json({ code: 400, msg: '积分不足' })

      // 保底检查
      const pityCount = config.pityCount || 0
      let streak = 0
      if (pityCount > 0) {
        const lastRecords = await query(
          'SELECT result FROM game_records WHERE user_id=? AND game_type=? ORDER BY id DESC LIMIT ?',
          [userId, 'card_guess', pityCount]
        )
        for (const r of lastRecords) {
          if (r.result === 'lose') streak++
          else break
        }
      }

      const cards = config.cards || [{ name: 'A', isWin: false }, { name: 'B', isWin: false }, { name: 'C', isWin: false }]
      let card
      if (pityCount > 0 && streak >= pityCount) {
        card = cards.find(c => c.isWin) || cards[0]
        streak = 0
      } else {
        card = pickByProbability(cards.map(c => ({
          ...c,
          probability: c.probability !== undefined ? c.probability : (c.isWin ? 30 : 70 / cards.filter(x => !x.isWin).length || 35)
        })))
      }

      const isWin = card?.isWin || false
      const wonPoints = isWin ? (config.winReward || baseCost * (config.winMultiplier || 2)) : 0

      await query('UPDATE users SET points=points-? WHERE id=?', [actualCost, userId])
      await query(
        'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
        [userId, -actualCost, 'game', '卡片竞猜消耗']
      )

      await query(
        'INSERT INTO game_records (user_id, game_type, result, points_spent, points_won, detail) VALUES (?,?,?,?,?,?)',
        [userId, 'card_guess', isWin ? 'win' : 'lose', actualCost, wonPoints,
          JSON.stringify({ chosenIndex: cardIndex, cardName: card?.name, cardLabel: card?.label, isWin })]
      )

      if (wonPoints > 0) {
        await query('UPDATE users SET points=points+? WHERE id=?', [wonPoints, userId])
        await query(
          'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
          [userId, wonPoints, 'game', '卡片竞猜获得']
        )
      }

      res.json({ code: 200, data: { cardIndex, cardName: card?.name, cardLabel: card?.label, isWin, wonPoints, cost: actualCost } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ======================== 大小点数竞猜 ========================

  app.post('/api/game/dice/bet', async (req, res) => {
    try {
      const { userId, bet } = req.body
      if (!userId) return res.json({ code: 400, msg: '请先登录' })
      if (!['big', 'small'].includes(bet)) return res.json({ code: 400, msg: '请选择大或小' })

      const cfgs = await query('SELECT * FROM game_configs WHERE game_type=?', ['dice'])
      if (!cfgs.length || !cfgs[0].enabled) return res.json({ code: 400, msg: '游戏已停用' })
      const config = typeof cfgs[0].config_data === 'string' ? JSON.parse(cfgs[0].config_data) : cfgs[0].config_data

      const baseCost = config.costPerBet || 10
      const memberInfo = await getMemberDiscount(userId)
      const actualCost = await calcCost(baseCost, memberInfo, 'dice')

      const user = await query('SELECT points FROM users WHERE id=?', [userId])
      if (!user.length || user[0].points < actualCost) return res.json({ code: 400, msg: '积分不足' })

      const max = config.maxNumber || 6
      const threshold = config.threshold !== undefined ? config.threshold : Math.ceil(max / 2)
      const multiplier = config.winMultiplier || 2

      const number = Math.floor(Math.random() * max) + 1
      const isBig = number >= threshold
      const isWin = (bet === 'big' && isBig) || (bet === 'small' && !isBig)
      const wonPoints = isWin ? Math.floor(baseCost * multiplier) : 0

      await query('UPDATE users SET points=points-? WHERE id=?', [actualCost, userId])
      await query(
        'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
        [userId, -actualCost, 'game', '大小竞猜消耗']
      )

      await query(
        'INSERT INTO game_records (user_id, game_type, result, points_spent, points_won, detail) VALUES (?,?,?,?,?,?)',
        [userId, 'dice', isWin ? 'win' : 'lose', actualCost, wonPoints,
          JSON.stringify({ bet, number, isBig, threshold, max })]
      )

      if (wonPoints > 0) {
        await query('UPDATE users SET points=points+? WHERE id=?', [wonPoints, userId])
        await query(
          'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
          [userId, wonPoints, 'game', '大小竞猜获得']
        )
      }

      res.json({ code: 200, data: { bet, number, isBig, isWin, wonPoints, cost: actualCost } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ======================== 剪刀石头布 ========================

  app.post('/api/game/rps/play', async (req, res) => {
    try {
      const { userId, choice } = req.body
      if (!userId) return res.json({ code: 400, msg: '请先登录' })
      if (!['rock', 'paper', 'scissors'].includes(choice)) return res.json({ code: 400, msg: '无效的选择' })

      const cfgs = await query('SELECT * FROM game_configs WHERE game_type=?', ['rps'])
      if (!cfgs.length || !cfgs[0].enabled) return res.json({ code: 400, msg: '游戏已停用' })
      const config = typeof cfgs[0].config_data === 'string' ? JSON.parse(cfgs[0].config_data) : cfgs[0].config_data

      const baseCost = config.costPerPlay || 10
      const memberInfo = await getMemberDiscount(userId)
      const actualCost = await calcCost(baseCost, memberInfo, 'rps')

      const user = await query('SELECT points FROM users WHERE id=?', [userId])
      if (!user.length || user[0].points < actualCost) return res.json({ code: 400, msg: '积分不足' })

      const options = ['rock', 'paper', 'scissors']
      const names = { rock: '石头', paper: '布', scissors: '剪刀' }
      const systemChoice = options[Math.floor(Math.random() * 3)]

      let result, wonPoints
      if (choice === systemChoice) {
        result = 'draw'
        const drawRefund = config.drawRefund !== false
        wonPoints = drawRefund ? actualCost : 0
      } else if (
        (choice === 'rock' && systemChoice === 'scissors') ||
        (choice === 'paper' && systemChoice === 'rock') ||
        (choice === 'scissors' && systemChoice === 'paper')
      ) {
        result = 'win'
        wonPoints = Math.floor(baseCost * (config.winMultiplier || 2))
      } else {
        result = 'lose'
        wonPoints = 0
      }

      await query('UPDATE users SET points=points-? WHERE id=?', [actualCost, userId])
      await query(
        'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
        [userId, -actualCost, 'game', '剪刀石头布消耗']
      )

      await query(
        'INSERT INTO game_records (user_id, game_type, result, points_spent, points_won, detail) VALUES (?,?,?,?,?,?)',
        [userId, 'rps', result, actualCost, result === 'win' ? wonPoints : 0,
          JSON.stringify({ userChoice: choice, userChoiceName: names[choice], systemChoice, systemChoiceName: names[systemChoice] })]
      )

      if (wonPoints > 0) {
        await query('UPDATE users SET points=points+? WHERE id=?', [wonPoints, userId])
        if (result === 'win') {
          await query(
            'INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)',
            [userId, wonPoints, 'game', '剪刀石头布获胜']
          )
        }
      }

      res.json({
        code: 200,
        data: {
          userChoice: choice, userChoiceName: names[choice],
          systemChoice, systemChoiceName: names[systemChoice],
          result, wonPoints, cost: actualCost
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ======================== 参与记录查询 ========================

  app.get('/api/game/records', async (req, res) => {
    try {
      const { gameType, userId, page = 1, pageSize = 20 } = req.query
      let where = 'WHERE 1=1'
      const params = []
      if (gameType) { where += ' AND game_type=?'; params.push(gameType) }
      if (userId) { where += ' AND user_id=?'; params.push(Number(userId)) }
      const offset = (Number(page) - 1) * Number(pageSize)

      const [rows, countResult] = await Promise.all([
        query(
          `SELECT gr.*, u.username, u.avatar FROM game_records gr LEFT JOIN users u ON gr.user_id=u.id ${where} ORDER BY gr.id DESC LIMIT ? OFFSET ?`,
          [...params, Number(pageSize), offset]
        ),
        query(`SELECT COUNT(*) as total FROM game_records ${where}`, params)
      ])

      // 处理 JSON 字段
      const list = rows.map(r => ({
        id: r.id, userId: r.user_id, username: r.username, avatar: r.avatar,
        gameType: r.game_type, result: r.result,
        pointsSpent: r.points_spent, pointsWon: r.points_won,
        detail: typeof r.detail === 'string' ? JSON.parse(r.detail) : r.detail,
        createTime: r.create_time
      }))

      res.json({
        code: 200,
        data: { list, total: countResult[0]?.total || 0, page: Number(page), pageSize: Number(pageSize) }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.get('/api/game/stats', async (req, res) => {
    try {
      const today = new Date().toISOString().slice(0, 10)
      const stats = await query(
        `SELECT game_type, COUNT(*) as total_plays, SUM(points_spent) as total_spent, SUM(points_won) as total_won,
         SUM(CASE WHEN DATE(create_time)=? THEN 1 ELSE 0 END) as today_plays,
         SUM(CASE WHEN DATE(create_time)=? THEN points_spent ELSE 0 END) as today_spent
         FROM game_records GROUP BY game_type`,
        [today, today]
      )
      res.json({ code: 200, data: stats })
    } catch (e) {
      res.serverError(e)
    }
  })
}

function pickByProbability(items) {
  if (!items || !items.length) return null
  const total = items.reduce((s, i) => s + (Number(i.probability) || 0), 0)
  if (total <= 0) return items[Math.floor(Math.random() * items.length)]
  let r = Math.random() * total
  for (const item of items) {
    r -= (Number(item.probability) || 0)
    if (r <= 0) return item
  }
  return items[items.length - 1]
}

async function grantPrize(userId, grid) {
  const result = { isWin: false, pointsWon: 0, extra: '' }
  if (!grid) return result
  const v = Number(grid.value) || 0
  const type = grid.type || 'thanks'

  if (type === 'points' && v > 0) {
    await query('UPDATE users SET points=points+? WHERE id=?', [v, userId])
    await query('INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)', [userId, v, 'game', `金币抽奖获得${v}积分`])
    result.isWin = true
    result.pointsWon = v
  } else if (type === 'balance' && v > 0) {
    await query('UPDATE users SET balance=balance+? WHERE id=?', [v, userId])
    await query('INSERT INTO balance_records (user_id, amount, type, description, balance_after) VALUES (?,?,?,?, (SELECT balance FROM users WHERE id=?))', [userId, v, 'game', `金币抽奖获得${v}元余额`, userId])
    result.isWin = true
    result.extra = `余额+¥${v}`
  } else if (type === 'coupon' && grid.couponId) {
    const couponId = Number(grid.couponId)
    const coupon = await query('SELECT * FROM coupons WHERE id=? AND status=?', [couponId, '1'])
    if (coupon.length) {
      const c = coupon[0]
      const expireTime = c.expire_time ? c.expire_time : new Date(Date.now() + (c.valid_days || 30) * 86400000).toISOString().slice(0, 19).replace('T', ' ')
      await query(
        'INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value) VALUES (?,?,?,?,?,?)',
        [userId, c.id, 'unused', JSON.stringify(c), expireTime, c.value || 0]
      )
      result.isWin = true
      result.extra = `优惠券:${c.name}`
    }
  } else if (type === 'membership' && grid.targetLevelId && v > 0) {
    const days = v
    const lv = await query('SELECT id, name FROM membership_levels WHERE id=?', [Number(grid.targetLevelId)])
    if (lv.length) {
      const expDate = new Date(Date.now() + days * 86400000).toISOString().slice(0, 19).replace('T', ' ')
      await query('UPDATE users SET level_id=?, level_name=?, expire_time=? WHERE id=?', [lv[0].id, lv[0].name, expDate, userId])
      await query(
        'INSERT INTO membership_purchases (user_id, level_id, level_name, amount, pay_type, purchase_type, duration_days, expire_time) VALUES (?,?,?,?,?,?,?,?)',
        [userId, lv[0].id, lv[0].name, 0, 'game', 'lottery', days, expDate]
      )
      result.isWin = true
      result.extra = `会员:${lv[0].name} ${days}天`
    }
  } else if (type === 'cardkey' && v > 0) {
    const code = 'GK' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase()
    await query(
      'INSERT INTO card_keys (code, type, value, target_id, target_name, status, create_time) VALUES (?,?,?,?,?,?,NOW())',
      [code, 'fixed', v, 0, grid.name || '金币抽奖卡密', '1']
    )
    result.isWin = true
    result.extra = `卡密:${code}`
  } else if (type !== 'thanks') {
    result.isWin = true
    if (v > 0) {
      await query('UPDATE users SET points=points+? WHERE id=?', [v, userId])
      await query('INSERT INTO points_records (user_id, amount, type, description) VALUES (?,?,?,?)', [userId, v, 'game', `金币抽奖获得${v}积分`])
      result.pointsWon = v
    }
  }

  return result
}

module.exports = gameRoutes
