const { query, getPool } = require('../database.cjs')
const { addBalance, addPoints, deductBalance, deductPoints, addExperience } = require('./account-utils.cjs')
const { sessions, SESSION_TTL, authRequired } = require('./system.cjs')
const { hasPermission, getPermissionValue } = require('../middleware/level-permissions.cjs')
const { sanitizeCommunityContent } = require('../middleware/security.cjs')

const nowExpr = 'NOW()'

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {}); return 0 }
      sessions.set(token, { userId: row.user_id, createdAt })
      return Number(row.user_id) || 0
    }
  } catch { return 0 }
  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) return JSON.parse(rows[0].roles || '[]')
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.includes('admin') || roles.includes('super_admin')
}

function safeInt(v, def) {
  const n = parseInt(v)
  return isNaN(n) ? def : n
}

function safeFloat(v, def) {
  const n = parseFloat(v)
  return isNaN(n) ? def : n
}

module.exports = function collectionRoutes(app) {
  // ========== POST ==========

  // 创建合集
  app.post('/api/community/collection', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { title, description, coverImage, sectionId, isPaid, priceBalance, pricePoints, previewCount, sortMode, currency_prices, payment_methods } = req.body || {}
      if (!title || !title.trim()) return res.json({ code: 400, msg: '合集标题不能为空' })

      // D3: 创建合集数量上限
      const maxCollections = parseInt(await getPermissionValue(userId, 'social', 'D3') || '999')
      const cnt = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE creator_id=?', [userId])
      if ((cnt[0]?.cnt || 0) >= maxCollections) {
        return res.json({ code: 400, msg: `当前等级最多创建${maxCollections}个合集` })
      }

      const userRow = (await query('SELECT username, avatar FROM users WHERE id=?', [userId]))?.[0] || {}
      const userName = userRow.username || ''
      const userAvatar = userRow.avatar || ''

      const isPaidInt = isPaid ? 1 : 0
      const balanceVal = safeFloat(priceBalance, 0)
      const pointsVal = safeInt(pricePoints, 0)
      const cp = currency_prices ? (typeof currency_prices === 'string' ? currency_prices : JSON.stringify(currency_prices)) : null
      const pm = payment_methods ? (typeof payment_methods === 'string' ? payment_methods : JSON.stringify(payment_methods)) : null

      const result = await query(
        `INSERT INTO community_collections (user_id, user_name, user_avatar, title, description, cover_image,
         section_id, is_paid, price_balance, price_points, preview_count, sort_mode, status, currency_prices, payment_methods)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)`,
        [userId, userName, userAvatar, title.trim(), description || '', coverImage || '', sectionId || 0,
         isPaidInt, balanceVal, pointsVal, previewCount || 0, sortMode || 'manual', cp, pm]
      )

      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) {
      console.error('[Collection] create:', e.message)
      res.serverError(e)
    }
  })

  // 向合集添加帖子
  app.post('/api/community/collection/:id/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许添加帖子' })

      const { postIds, isPreview } = req.body || {}
      if (!postIds || !Array.isArray(postIds) || postIds.length === 0) {
        return res.json({ code: 400, msg: '请选择帖子' })
      }

      for (const pid of postIds) {
        const post = await query('SELECT id, user_id FROM community_posts WHERE id=? AND status IN (\'published\',\'reviewed\')', [pid])
        if (!post.length) return res.json({ code: 400, msg: `帖子 ${pid} 不存在或未发布` })
        if (post[0].user_id !== userId) return res.json({ code: 403, msg: `帖子 ${pid} 不属于你` })
      }

      for (const pid of postIds) {
        const existing = await query('SELECT collection_id FROM community_collection_posts WHERE post_id=?', [pid])
        if (existing.length) return res.json({ code: 400, msg: `帖子 ${pid} 已归属其他合集` })
      }

      const currentMaxSort = await query('SELECT MAX(sort_order) as ms FROM community_collection_posts WHERE collection_id=?', [cid])
      let nextSort = (currentMaxSort[0].ms || 0) + 1

      for (const pid of postIds) {
        await query(
          'INSERT INTO community_collection_posts (collection_id, post_id, sort_order, is_preview) VALUES (?,?,?,?)',
          [cid, pid, nextSort, isPreview ? 1 : 0]
        )
        nextSort++
      }

      const newCount = await query('SELECT COUNT(*) as cnt FROM community_collection_posts WHERE collection_id=?', [cid])
      await query('UPDATE community_collections SET post_count=?, update_time=' + nowExpr + ' WHERE id=?', [newCount[0].cnt, cid])

      res.json({ code: 200, msg: '添加成功' })
    } catch (e) {
      console.error('[Collection] add posts:', e.message)
      res.serverError(e)
    }
  })

  // 购买合集
  app.post('/api/community/collection/:id/buy', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

    if (c.user_id === userId) return res.json({ code: 400, msg: '作者无需购买自己的合集' })
    if (!c.is_paid) return res.json({ code: 400, msg: '本合集为免费合集，无需购买' })

    const { payType } = req.body || {}
    if (!payType) return res.json({ code: 400, msg: '请选择支付方式' })

    let price = 0
    let currencyKey = ''
    let unitLabel = ''
    if (payType === 'points') {
      price = Number(c.price_points) || 0
      currencyKey = 'points'
      unitLabel = '积分'
    } else if (payType === 'balance') {
      price = Number(c.price_balance) || 0
      currencyKey = 'balance'
      unitLabel = '余额'
    } else {
      const cp = c.currency_prices ? (typeof c.currency_prices === 'string' ? JSON.parse(c.currency_prices) : c.currency_prices) : {}
      if (cp[payType]) {
        price = Number(cp[payType]) || 0
        currencyKey = payType
        const cs = await query('SELECT display_name FROM currency_settings WHERE currency_key=?', [payType])
        unitLabel = cs.length > 0 ? cs[0].display_name : payType
      }
    }
    if (price <= 0) return res.json({ code: 400, msg: '本合集未设置该支付方式的价格' })

    const already = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
    if (already.length) return res.json({ code: 400, msg: '已购买此合集' })

    const field = currencyKey

    const user = await query(`SELECT nickname FROM users WHERE id=?`, [userId])
    if (user.length === 0) return res.json({ code: 404, msg: '用户不存在' })


    const fromName = user[0].nickname || ('user_' + userId)

    let userBalance
    const ub = await query('SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=?', [userId, field])
    userBalance = Number(ub[0]?.available) || 0
    if (userBalance < price) return res.json({ code: 400, msg: unitLabel + '不足' })

    const conn = await getPool().promise().getConnection()
    try {
      await conn.beginTransaction()

      if (payType === 'points') {
        await deductPoints(userId, fromName, price, '合集购买', '购买合集《' + c.title + '》', conn)
        await addPoints(c.user_id, c.user_name || '', price, '合集销售收入', '合集《' + c.title + '》销售', conn)
      } else if (payType === 'balance') {
        await deductBalance(userId, fromName, price, 'collection_purchase', '购买合集《' + c.title + '》', conn)
        await addBalance(c.user_id, c.user_name || '', price, 'collection_income', '合集《' + c.title + '》销售收入', conn)
      } else {
        const { deductBalance, addBalance, deductPoints, addPoints } = require('./account-utils.cjs')
        await deductBalance(userId, fromName, price, 'collection_purchase', '购买合集《' + c.title + '》', conn)
        await addBalance(c.user_id, c.user_name || '', price, 'collection_income', '合集《' + c.title + '》销售收入', conn)
      }

      await conn.query('INSERT INTO user_paid_collections (user_id, collection_id, amount, pay_type) VALUES (?,?,?,?)', [userId, cid, price, payType])
      await conn.query('UPDATE community_collections SET subscribe_count = subscribe_count + 1 WHERE id=?', [cid])

      await conn.commit()
      conn.release()

      try {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, is_read, create_time)
           VALUES (?,?, 'collection_purchase',?,?,?,0,NOW())`,
          ['合集购买通知', '用户 ' + fromName + ' 购买了你的合集《' + c.title + '》', c.user_id, userId, fromName]
        )
      } catch (e) { console.error('[collection] purchase notify failed:', c.title, e.message) }

      res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      await conn.rollback()
      conn.release()
      console.error('[Collection] buy transaction error:', e.message, e.stack)
      res.json({ code: 500, msg: '购买失败：' + (e.message || '未知错误') })
    }
    } catch (e) {
      console.error('[Collection] buy outer error:', e.message)
      res.json({ code: 500, msg: '购买失败：' + (e.message || '未知错误') })
    }
  })

  // ========== GET (静态路由必须放在 :id 之前) ==========

  // 我的合集列表
  app.get('/api/community/collection/mine', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT * FROM community_collections WHERE user_id=? AND is_deleted=0 ORDER BY update_time DESC LIMIT ? OFFSET ?`,
          [userId, pageSize, offset]
        ),
        query('SELECT COUNT(*) as cnt FROM community_collections WHERE user_id=? AND is_deleted=0', [userId])
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] mine:', e.message)
      res.serverError(e)
    }
  })

  // 某用户的合集列表（公开）
  app.get('/api/community/collection/user/:userId', async (req, res) => {
    try {
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize
      const uid = safeInt(req.params.userId, 0)

      const author = await query('SELECT status FROM users WHERE id=?', [uid])
      const authorBanned = !!(author.length && author[0].status === '0')

      if (authorBanned) return res.json({ code: 200, data: { list: [], total: 0, page, pageSize } })

      const [rows, total] = await Promise.all([
        query(
          `SELECT * FROM community_collections WHERE user_id=? AND is_deleted=0 AND status IN ('serializing','finished')
           ORDER BY update_time DESC LIMIT ? OFFSET ?`,
          [uid, pageSize, offset]
        ),
        query(
          'SELECT COUNT(*) as cnt FROM community_collections WHERE user_id=? AND is_deleted=0 AND status IN (\'serializing\',\'finished\')',
          [uid]
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] user:', e.message)
      res.serverError(e)
    }
  })

  // 已购合集列表
  app.get('/api/community/collection/paid', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT c.*, upc.amount as paid_amount, upc.pay_time
           FROM user_paid_collections upc
           INNER JOIN community_collections c ON upc.collection_id = c.id AND c.is_deleted = 0
           WHERE upc.user_id=? ORDER BY upc.pay_time DESC LIMIT ? OFFSET ?`,
          [userId, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM user_paid_collections upc
           INNER JOIN community_collections c ON upc.collection_id = c.id AND c.is_deleted = 0
           WHERE upc.user_id=?`,
          [userId]
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] paid:', e.message)
      res.serverError(e)
    }
  })

  // 精选合集（用于推荐）
  app.get('/api/community/collections/featured', async (req, res) => {
    try {
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 10)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT c.* FROM community_collections c
           INNER JOIN users u ON c.user_id = u.id AND u.status = '1'
           WHERE c.is_deleted=0 AND c.status IN ('serializing','finished') AND c.post_count > 0
           ORDER BY c.subscribe_count DESC, c.view_count DESC, c.update_time DESC
           LIMIT ? OFFSET ?`,
          [pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM community_collections c
           INNER JOIN users u ON c.user_id = u.id AND u.status = '1'
           WHERE c.is_deleted=0 AND c.status IN ('serializing','finished') AND c.post_count > 0`
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] featured:', e.message)
      res.serverError(e)
    }
  })

  // 获取帖子所属合集
  app.get('/api/community/post/:id/collection', async (req, res) => {
    try {
      const pid = safeInt(req.params.id, 0)
      const rows = await query(
        `SELECT c.* FROM community_collections c
         INNER JOIN community_collection_posts ccp ON c.id = ccp.collection_id
         WHERE ccp.post_id=? AND c.is_deleted=0`,
        [pid]
      )
      if (!rows.length) return res.json({ code: 200, data: null })

      const c = rows[0]
      const posts = await query(
        `SELECT ccp.sort_order, ccp.is_preview, p.id
         FROM community_collection_posts ccp
         INNER JOIN community_posts p ON ccp.post_id = p.id
         WHERE ccp.collection_id=? AND p.status NOT IN ('deleted')
         ORDER BY ccp.sort_order ASC`,
        [c.id]
      )

      const currentIndex = posts.findIndex(p => p.id === pid)
      const prevPost = currentIndex > 0 ? posts[currentIndex - 1] : null
      const nextPost = currentIndex < posts.length - 1 ? posts[currentIndex + 1] : null

      res.json({
        code: 200,
        data: {
          collection: c,
          postIndex: currentIndex + 1,
          totalPosts: posts.length,
          prevPost: prevPost ? { id: prevPost.id } : null,
          nextPost: nextPost ? { id: nextPost.id } : null,
        }
      })
    } catch (e) {
      console.error('[Collection] post-collection:', e.message)
      res.serverError(e)
    }
  })

  // 获取合集详情 (动态路由，放在最后)
  app.get('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cid = safeInt(req.params.id, 0)
      if (!cid) return res.json({ code: 404, msg: '合集不存在' })

      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

      const isAuthor = userId === c.user_id
      let hasPaid = false
      if (userId) {
        const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, c.id])
        hasPaid = paid.length > 0
      }

      const author = await query('SELECT status FROM users WHERE id=?', [c.user_id])
      const authorBanned = !!(author.length && author[0].status === '0')
      const collectionUserId = c.user_id

      // 作者装饰信息
      let authorDecorations = {}
      try {
        const adRows = await query(
          `SELECT u.avatar as userAvatar,
                  (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = u.id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                  (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect,
                  (SELECT d.config_json FROM decorations d WHERE d.id = u.active_comment_background_id AND d.type = 'comment_background' AND d.status = '1') as userCommentBackground,
                  (SELECT el.icon FROM experience_levels el WHERE el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status='1' ORDER BY el.exp_required DESC LIMIT 1) as userExpLevelIcon,
                  ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                  ct.name as userTitleName, ct.icon as userTitleIcon,
                  (SELECT GROUP_CONCAT(ct2.icon SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1' AND ct2.icon IS NOT NULL AND ct2.icon != '') as userAllTitleIcons,
                  (SELECT GROUP_CONCAT(ct2.name SEPARATOR '|||') FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id WHERE ut2.user_id = u.id AND ct2.status='1') as userActiveTitleNames,
                  (SELECT COUNT(*) FROM community_moderators WHERE section_id=${safeInt(c.section_id, 0)} AND user_id=u.id) as authorIsModerator
           FROM users u
           LEFT JOIN membership_levels ml ON ml.id = u.level_id
           LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
           WHERE u.id=?`,
          [collectionUserId]
        )
        if (adRows && adRows.length > 0) {
          const ad = adRows[0]
          ad.userAllTitleIcons = ad.userAllTitleIcons ? ad.userAllTitleIcons.split('|||') : []
          ad.userActiveTitleNames = ad.userActiveTitleNames ? ad.userActiveTitleNames.split('|||') : []
          authorDecorations = ad
        }
      } catch (e) { console.error('[Collection] author decorations:', e.message) }

      // 点赞数
      const likeCountRes = await query('SELECT COUNT(*) as cnt FROM collection_likes WHERE collection_id=?', [c.id])
      c.like_count = likeCountRes[0]?.cnt || 0

      // 当前用户是否已点赞
      let isLiked = false
      if (userId) {
        const liked = await query('SELECT id FROM collection_likes WHERE collection_id=? AND user_id=?', [c.id, userId])
        isLiked = liked.length > 0
      }

      if (authorBanned && !hasPaid && !isAuthor) {
        return res.json({ code: 200, data: { ...c, hidden: true, reason: 'author_banned' } })
      }

      let posts = await query(
        `SELECT ccp.sort_order, ccp.is_preview, ccp.post_id,
                p.id, p.title, p.status as post_status, p.user_id as post_user_id,
                p.user_name as post_user_name, p.view_count, p.comment_count, p.like_count,
                p.cover_url as coverUrl,
                LEFT(p.content, 200) as summary, p.create_time as post_create_time,
                (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
                 OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
                 OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
         FROM community_collection_posts ccp
         INNER JOIN community_posts p ON ccp.post_id = p.id
         WHERE ccp.collection_id=?
         ORDER BY ccp.sort_order ASC`,
        [c.id]
      )

      const effectivePosts = []
      let effectiveCount = 0
      for (const p of posts) {
        const isDeleted = p.post_status === 'deleted'
        if (isDeleted) {
          effectivePosts.push({ ...p, invalid: true, invalid_reason: '帖子已删除或隐藏，无法阅读' })
        } else {
          effectiveCount++
          // 过滤含受限内容的帖子摘要
          if (p.has_restricted && !isAuthor && !hasPaid) {
            p.summary = '该帖子含付费/限制内容，购买合集后查看'
          }
          effectivePosts.push({ ...p, invalid: false })
        }
      }

      if (effectiveCount !== c.post_count) {
        await query('UPDATE community_collections SET post_count=? WHERE id=?', [effectiveCount, c.id])
        c.post_count = effectiveCount
      }

      let subscribers = []
      if (isAuthor && c.subscribe_count > 0) {
        subscribers = await query(
          `SELECT upc.user_id, upc.amount, upc.pay_time, upc.pay_type, u.nickname as user_name
           FROM user_paid_collections upc
           INNER JOIN users u ON upc.user_id = u.id
           WHERE upc.collection_id=? ORDER BY upc.pay_time DESC LIMIT 50`,
          [c.id]
        )
      }

      res.json({
        code: 200,
        data: { ...c, userName: c.user_name, ...authorDecorations, posts: effectivePosts, isAuthor, hasPaid, hidden: false, subscribers, isLiked, like_count: c.like_count }
      })
    } catch (e) {
      console.error('[Collection] get:', e.message)
      res.serverError(e)
    }
  })

  // 检查是否已购买
  app.get('/api/community/collection/:id/check-paid', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { hasPaid: false } })

      const cid = safeInt(req.params.id, 0)
      const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, data: { hasPaid: paid.length > 0 } })
    } catch (e) {
      console.error('[Collection] check-paid:', e.message)
      res.serverError(e)
    }
  })

  // 获取合集内某篇帖子内容
  app.get('/api/community/collection/:id/post/:postId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cid = safeInt(req.params.id, 0)
      const pid = safeInt(req.params.postId, 0)

      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

      const ccp = await query('SELECT * FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      if (!ccp.length) return res.json({ code: 404, msg: '帖子不在合集中' })

      const post = await query('SELECT * FROM community_posts WHERE id=? AND status IN (\'published\',\'reviewed\')', [pid])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      const p = post[0]

      const isAuthor = userId === c.user_id
      const isTrial = ccp[0].is_preview === 1

      if (!isAuthor && !isTrial && c.is_paid && (Number(c.price_balance) > 0 || Number(c.price_points) > 0)) {
        if (!userId) return res.json({ code: 401, msg: '请先登录' })
        const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
        if (!paid.length) return res.json({ code: 403, msg: '请购买合集后阅读', needBuy: true, collection: c })
      }

      res.json({ code: 200, data: p })
    } catch (e) {
      console.error('[Collection] post content:', e.message)
      res.serverError(e)
    }
  })

  // ========== PUT ==========

  // 更新合集信息
  app.put('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId && !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { title, description, coverImage, isPaid, priceBalance, pricePoints, previewCount, sortMode, status, currency_prices, payment_methods } = req.body || {}

      const updates = []
      const params = []
      if (title !== undefined) { updates.push('title=?'); params.push(title.trim()) }
      if (description !== undefined) { updates.push('description=?'); params.push(description) }
      if (coverImage !== undefined) { updates.push('cover_image=?'); params.push(coverImage) }
      if (isPaid !== undefined) { updates.push('is_paid=?'); params.push(isPaid ? 1 : 0) }
      if (priceBalance !== undefined) { updates.push('price_balance=?'); params.push(safeFloat(priceBalance, 0)) }
      if (pricePoints !== undefined) { updates.push('price_points=?'); params.push(safeInt(pricePoints, 0)) }
      if (previewCount !== undefined) { updates.push('preview_count=?'); params.push(safeInt(previewCount, 0)) }
      if (sortMode !== undefined) { updates.push('sort_mode=?'); params.push(sortMode) }
      if (currency_prices !== undefined) { updates.push('currency_prices=?'); params.push(typeof currency_prices === 'string' ? currency_prices : JSON.stringify(currency_prices)) }
      if (payment_methods !== undefined) { updates.push('payment_methods=?'); params.push(typeof payment_methods === 'string' ? payment_methods : JSON.stringify(payment_methods)) }
      if (status !== undefined) {
        if (collection[0].status === 'finished' && status !== 'finished') {
          return res.json({ code: 400, msg: '已完结合集不允许恢复为草稿或连载中状态' })
        }
        updates.push('status=?'); params.push(status)
      }
      if (updates.length === 0) return res.json({ code: 400, msg: '无更新内容' })

      updates.push('update_time=' + nowExpr)
      params.push(cid)

      await query(`UPDATE community_collections SET ${updates.join(',')} WHERE id=?`, params)

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      console.error('[Collection] update:', e.message)
      res.serverError(e)
    }
  })

  // 更新帖子排序
  app.put('/api/community/collection/:id/posts/sort', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })
      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许调整排序' })

      const { sortedPostIds } = req.body || {}
      if (!sortedPostIds || !Array.isArray(sortedPostIds)) {
        return res.json({ code: 400, msg: '请提供排序后的帖子ID列表' })
      }

      for (let i = 0; i < sortedPostIds.length; i++) {
        await query('UPDATE community_collection_posts SET sort_order=? WHERE collection_id=? AND post_id=?',
          [i + 1, cid, sortedPostIds[i]])
      }

      await query('UPDATE community_collections SET update_time=' + nowExpr + ' WHERE id=?', [cid])

      res.json({ code: 200, msg: '排序更新成功' })
    } catch (e) {
      console.error('[Collection] sort:', e.message)
      res.serverError(e)
    }
  })

  // 设置/取消试读帖
  app.put('/api/community/collection/:id/posts/:postId/preview', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      const { isPreview } = req.body || {}

      await query('UPDATE community_collection_posts SET is_preview=? WHERE collection_id=? AND post_id=?',
        [isPreview ? 1 : 0, cid, safeInt(req.params.postId, 0)])

      res.json({ code: 200, msg: '设置成功' })
    } catch (e) {
      console.error('[Collection] preview:', e.message)
      res.serverError(e)
    }
  })

  // ========== DELETE ==========

  // 删除合集（仅草稿可删）
  app.delete('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId && !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      if (collection[0].status !== 'draft') return res.json({ code: 400, msg: '仅草稿状态的合集可删除' })

      await query('UPDATE community_collections SET is_deleted=1, update_time=' + nowExpr + ' WHERE id=?', [cid])
      await query('DELETE FROM community_collection_posts WHERE collection_id=?', [cid])

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Collection] delete:', e.message)
      res.serverError(e)
    }
  })

  // 从合集移除帖子
  app.delete('/api/community/collection/:id/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })
      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许移除帖子' })

      const { postIds } = req.body || {}
      if (!postIds || !Array.isArray(postIds) || postIds.length === 0) {
        return res.json({ code: 400, msg: '请选择要移除的帖子' })
      }

      for (const pid of postIds) {
        await query('DELETE FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      }

      const newCount = await query('SELECT COUNT(*) as cnt FROM community_collection_posts WHERE collection_id=?', [cid])
      await query('UPDATE community_collections SET post_count=?, update_time=' + nowExpr + ' WHERE id=?', [newCount[0].cnt, cid])

      res.json({ code: 200, msg: '移除成功' })
    } catch (e) {
      console.error('[Collection] remove posts:', e.message)
      res.serverError(e)
    }
  })

  // ========== 收藏分组 API ==========

  // 确保用户有默认分组
  async function ensureDefaultGroup(userId) {
    const rows = await query('SELECT id FROM collection_favorite_groups WHERE user_id=?', [userId])
    if (!rows.length) {
      const r = await query('INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,\'默认收藏夹\',0)', [userId])
      return r.insertId
    }
    return rows[0].id
  }

  // 创建分组
  app.post('/api/community/favorite/groups', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { name } = req.body || {}
      if (!name || !name.trim()) return res.json({ code: 400, msg: '分组名称不能为空' })
      const maxOrder = await query('SELECT MAX(sort_order) as m FROM collection_favorite_groups WHERE user_id=?', [userId])
      const sortOrder = (maxOrder[0]?.m || 0) + 1
      const r = await query('INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,?,?)', [userId, name.trim(), sortOrder])
      res.json({ code: 200, data: { id: r.insertId, name: name.trim(), sort_order: sortOrder, count: 0 } })
    } catch (e) {
      console.error('[Favorite] create group:', e.message)
      res.serverError(e)
    }
  })

  // 修改分组名
  app.put('/api/community/favorite/groups/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      if (!g.length) return res.json({ code: 404, msg: '分组不存在' })
      const { name } = req.body || {}
      if (!name || !name.trim()) return res.json({ code: 400, msg: '分组名称不能为空' })
      await query('UPDATE collection_favorite_groups SET name=? WHERE id=?', [name.trim(), gid])
      res.json({ code: 200, msg: '修改成功' })
    } catch (e) {
      console.error('[Favorite] update group:', e.message)
      res.serverError(e)
    }
  })

  // 删除分组（合集移到默认分组）
  app.delete('/api/community/favorite/groups/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groups = await query('SELECT id FROM collection_favorite_groups WHERE user_id=? AND id!=?', [userId, gid])
      if (!groups.length) return res.json({ code: 400, msg: '至少保留一个分组' })
      const defaultId = await ensureDefaultGroup(userId)
      if (gid === defaultId) return res.json({ code: 400, msg: '不能删除默认分组' })
      await query('UPDATE collection_favorites SET group_id=? WHERE group_id=? AND user_id=?', [defaultId, gid, userId])
      await query('DELETE FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Favorite] delete group:', e.message)
      res.serverError(e)
    }
  })

  // 排序分组
  app.post('/api/community/favorite/groups/reorder', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids } = req.body || {}
      if (!ids || !Array.isArray(ids)) return res.json({ code: 400, msg: '参数错误' })
      for (let i = 0; i < ids.length; i++) {
        await query('UPDATE collection_favorite_groups SET sort_order=? WHERE id=? AND user_id=?', [i, ids[i], userId])
      }
      res.json({ code: 200, msg: '排序成功' })
    } catch (e) {
      console.error('[Favorite] reorder:', e.message)
      res.serverError(e)
    }
  })

  // 设置分组公开/私密
  app.put('/api/community/favorite/groups/:id/visibility', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      if (g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      const { is_public } = req.body || {}
      if (is_public !== 0 && is_public !== 1) return res.json({ code: 400, msg: '参数错误' })
      // 从公开切私密时检查是否有人关注
      if (!is_public) {
        const fcs = await query('SELECT COUNT(*) as cnt FROM favorite_group_follows WHERE group_id=?', [gid])
        if (fcs[0].cnt > 0) return res.json({ code: 400, msg: '已有用户关注，无法设为私密' })
      }
      await query('UPDATE collection_favorite_groups SET is_public=? WHERE id=?', [is_public, gid])
      res.json({ code: 200, msg: '设置成功' })
    } catch (e) {
      console.error('[Favorite] visibility:', e.message)
      res.serverError(e)
    }
  })

  // 关注公开分组
  app.post('/api/community/favorite/groups/:id/follow', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const g = await query('SELECT id, is_public FROM collection_favorite_groups WHERE id=?', [gid])
      if (g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      if (!g[0].is_public) return res.json({ code: 400, msg: '该分组未公开' })
      const existed = await query('SELECT id FROM favorite_group_follows WHERE group_id=? AND follower_id=?', [gid, userId])
      if (existed.length > 0) return res.json({ code: 200, msg: '已关注' })
      await query('INSERT INTO favorite_group_follows (group_id, follower_id) VALUES (?,?)', [gid, userId])
      res.json({ code: 200, msg: '关注成功' })
    } catch (e) {
      console.error('[Favorite] follow:', e.message)
      res.serverError(e)
    }
  })

  // 取消关注
  app.delete('/api/community/favorite/groups/:id/follow', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      await query('DELETE FROM favorite_group_follows WHERE group_id=? AND follower_id=?', [gid, userId])
      res.json({ code: 200, msg: '已取消关注' })
    } catch (e) {
      console.error('[Favorite] unfollow:', e.message)
      res.serverError(e)
    }
  })

  // 获取已关注的公开分组
  app.get('/api/community/favorite/groups/following', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        `SELECT g.id, g.user_id, g.name, g.is_public, g.create_time,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM favorite_group_follows f
         INNER JOIN collection_favorite_groups g ON f.group_id=g.id
         WHERE f.follower_id=? ORDER BY f.create_time DESC`,
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      console.error('[Favorite] following:', e.message)
      res.serverError(e)
    }
  })

  // 查看某用户公开的分组列表
  app.get('/api/community/favorite/groups/user/:uid', async (req, res) => {
    try {
      const uid = safeInt(req.params.uid, 0)
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM collection_favorites WHERE group_id=g.id AND user_id=g.user_id) +
          (SELECT COUNT(*) FROM post_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM collection_favorite_groups g WHERE g.user_id=? AND g.is_public=1 ORDER BY g.sort_order ASC, g.id ASC`,
        [uid]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      console.error('[Favorite] user groups:', e.message)
      res.serverError(e)
    }
  })

  // 获取收藏列表(支持按分组筛选)
  app.get('/api/community/favorite/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      let where = 'cf.user_id=?'
      const params = [userId]
      if (groupId > 0) {
        where += ' AND cf.group_id=?'
        params.push(groupId)
      }

      const [rows, total] = await Promise.all([
        query(
          `SELECT cf.id as fav_id, cf.group_id, c.* FROM collection_favorites cf
           INNER JOIN community_collections c ON cf.collection_id=c.id AND c.is_deleted=0
           WHERE ${where} ORDER BY cf.create_time DESC LIMIT ? OFFSET ?`,
          [...params, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM collection_favorites cf
           INNER JOIN community_collections c ON cf.collection_id=c.id AND c.is_deleted=0
           WHERE ${where}`,
          params
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] list:', e.message)
      res.serverError(e)
    }
  })

  // 移动合集到其他分组
  app.post('/api/community/favorite/move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { collectionIds, targetGroupId } = req.body || {}
      if (!collectionIds || !Array.isArray(collectionIds) || !targetGroupId) {
        return res.json({ code: 400, msg: '参数错误' })
      }
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [targetGroupId, userId])
      if (!g.length) return res.json({ code: 404, msg: '分组不存在' })
      for (const cid of collectionIds) {
        await query('UPDATE collection_favorites SET group_id=? WHERE user_id=? AND collection_id=?', [targetGroupId, userId, cid])
      }
      res.json({ code: 200, msg: '移动成功' })
    } catch (e) {
      console.error('[Favorite] move:', e.message)
      res.serverError(e)
    }
  })

  // 收藏合集（需要传 groupId）
  app.post('/api/community/collection/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      await ensureDefaultGroup(userId)
      const groupId = safeInt(req.body?.groupId, 0)
      if (groupId <= 0) return res.json({ code: 400, msg: '请选择收藏分组' })
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [groupId, userId])
      if (!g.length) return res.json({ code: 400, msg: '分组不存在' })

      await query(
        'INSERT INTO collection_favorites (user_id, collection_id, group_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE group_id=VALUES(group_id)',
        [userId, cid, groupId]
      )
      res.json({ code: 200, msg: '收藏成功' })
    } catch (e) {
      console.error('[Collection] favorite:', e.message)
      res.serverError(e)
    }
  })

  // 取消收藏
  app.delete('/api/community/collection/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      await query('DELETE FROM collection_favorites WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, msg: '已取消收藏' })
    } catch (e) {
      console.error('[Collection] unfavorite:', e.message)
      res.serverError(e)
    }
  })

  // 检查收藏状态（返回分组信息）
  app.get('/api/community/collection/:id/favorite/check', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const rows = await query(
        'SELECT cf.id, cf.group_id, g.name as group_name FROM collection_favorites cf LEFT JOIN collection_favorite_groups g ON cf.group_id=g.id WHERE cf.user_id=? AND cf.collection_id=?',
        [userId, cid]
      )
      res.json({ code: 200, data: { favorited: rows.length > 0, groupId: rows[0]?.group_id || 0, groupName: rows[0]?.group_name || '' } })
    } catch (e) {
      console.error('[Collection] fav-check:', e.message)
      res.serverError(e)
    }
  })

  // ========== 帖子收藏 API ==========

  // 取消收藏帖子
  app.delete('/api/community/post/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const pid = safeInt(req.params.id, 0)
      await query('DELETE FROM post_favorites WHERE user_id=? AND post_id=?', [userId, pid])
      res.json({ code: 200, msg: '已取消收藏' })
    } catch (e) {
      console.error('[PostFavorite] remove:', e.message)
      res.serverError(e)
    }
  })

  // 检查帖子收藏状态
  app.get('/api/community/post/:id/favorite/check', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const pid = safeInt(req.params.id, 0)
      const rows = await query(
        'SELECT pf.id, pf.group_id, g.name as group_name FROM post_favorites pf LEFT JOIN collection_favorite_groups g ON pf.group_id=g.id WHERE pf.user_id=? AND pf.post_id=?',
        [userId, pid]
      )
      res.json({ code: 200, data: { favorited: rows.length > 0, groupId: rows[0]?.group_id || 0, groupName: rows[0]?.group_name || '' } })
    } catch (e) {
      console.error('[PostFavorite] check:', e.message)
      res.serverError(e)
    }
  })

  // 统一收藏列表（帖子和合集）
  app.get('/api/community/favorite/items', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 50)
      const offset = (page - 1) * pageSize

      const gWhere = groupId > 0 ? ' AND f.group_id=' + groupId : ''

      const [cols, posts] = await Promise.all([
        query(
          `SELECT 'collection' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              c.id, c.title, c.cover_image, c.description, c.post_count, c.view_count,
              c.user_id, c.user_name, c.user_avatar, c.subscribe_count, COALESCE(c.section_id,0) as section_id,
              (SELECT name FROM community_sections WHERE id=c.section_id AND is_deleted=0 LIMIT 1) as section_name
            FROM collection_favorites f
            INNER JOIN community_collections c ON f.collection_id=c.id AND c.is_deleted=0
            WHERE f.user_id=? ${gWhere}`,
          [userId]
        ),
        query(
          `SELECT 'post' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              p.id, p.title, p.content, p.images, 0 as post_count, p.view_count,
              p.user_id, p.user_name, p.user_avatar, p.like_count, p.comment_count, p.section_id,
              (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0 LIMIT 1) as section_name,
              LEFT(p.content, 200) as description,
              p.content_permission as contentPermission, p.content_price as contentPrice,
              p.content_price_type as contentPriceType,
              (SELECT COUNT(*) FROM content_purchases WHERE content_type='post' AND content_id=p.id) as soldCount,
              (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
               OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
               OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
            FROM post_favorites f
            INNER JOIN community_posts p ON f.post_id=p.id AND p.status NOT IN ('deleted')
            WHERE f.user_id=? ${gWhere}`,
          [userId]
        )
      ])

      const all = [...(Array.isArray(cols) ? cols : []), ...(Array.isArray(posts) ? posts : [])]
      all.sort((a, b) => new Date(b.fav_time).getTime() - new Date(a.fav_time).getTime())

      // 批量查询当前用户已购买的帖子
      const postIds = all.filter(x => x.item_type === 'post').map(x => x.id)
      const purchasedSet = new Set()
      if (postIds.length > 0) {
        try {
          const purchases = await query(
            `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${postIds.map(() => '?').join(',')})`,
            [userId, ...postIds]
          )
          purchases.forEach(p => purchasedSet.add(p.content_id))
        } catch (e) { console.error('[collection] batch purchase check failed:', e.message) }
      }
      for (const item of all) {
        if (item.item_type === 'post') {
          item.isAuthor = item.user_id === userId
          item.hasPurchased = purchasedSet.has(item.id) || item.isAuthor
          if (item.hasPurchased) item.has_restricted = false
        }
      }

      // 查询评论记录
      if (postIds.length > 0) {
        const commentedSet = new Set()
        try {
          const comments = await query(
            `SELECT DISTINCT post_id FROM community_comments WHERE post_id IN (${postIds.map(() => '?').join(',')}) AND user_id = ? AND is_deleted=0`,
            [...postIds, userId]
          )
          comments.forEach(c => commentedSet.add(c.post_id))
        } catch (e) { console.error('[collection] batch comment check failed:', e.message) }
        const [viewerRow] = await query(`SELECT level_id as viewerLevelId FROM users WHERE id = ?`, [userId])
        const titleRows = await query(`SELECT title_id FROM user_titles WHERE user_id = ? AND is_active = 1`, [userId])
        const viewerTitleIds = titleRows.map(r => r.title_id)
        for (const item of all) {
          if (item.item_type === 'post') {
            item.hasCommented = commentedSet.has(item.id)
            item.viewerLevelId = (viewerRow && viewerRow.viewerLevelId) || 0
            item.viewerTitleIds = viewerTitleIds
          }
        }
      }

      const list = all.slice(offset, offset + pageSize)

      res.json({ code: 200, data: { list, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] items:', e.message)
      res.serverError(e)
    }
  })

  // 查看某用户公开分组的收藏项目
  app.get('/api/community/favorite/items/user/:uid', async (req, res) => {
    try {
      const uid = safeInt(req.params.uid, 0)
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 50)
      const offset = (page - 1) * pageSize

      const gWhere = groupId > 0 ? ' AND f.group_id=' + groupId : ''

      const [cols, posts] = await Promise.all([
        query(
          `SELECT 'collection' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              c.id, c.title, c.cover_image, c.description, c.post_count, c.view_count,
              c.user_id, c.user_name, c.user_avatar, c.subscribe_count, COALESCE(c.section_id,0) as section_id,
              (SELECT name FROM community_sections WHERE id=c.section_id AND is_deleted=0 LIMIT 1) as section_name
            FROM collection_favorites f
            INNER JOIN collection_favorite_groups g ON f.group_id=g.id AND g.is_public=1
            INNER JOIN community_collections c ON f.collection_id=c.id AND c.is_deleted=0
            WHERE f.user_id=? ${gWhere}`,
          [uid]
        ),
        query(
          `SELECT 'post' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              p.id, p.title, p.content, p.images, 0 as post_count, p.view_count,
              p.user_id, p.user_name, p.user_avatar, p.like_count, p.comment_count, p.section_id,
              (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0 LIMIT 1) as section_name,
              p.content_permission as contentPermission, p.content_price as contentPrice,
              p.content_price_type as contentPriceType,
              (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
               OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
               OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
            FROM post_favorites f
            INNER JOIN collection_favorite_groups g ON f.group_id=g.id AND g.is_public=1
            INNER JOIN community_posts p ON f.post_id=p.id AND p.status NOT IN ('deleted')
            WHERE f.user_id=? ${gWhere}`,
          [uid]
        )
      ])

      const all = [...(Array.isArray(cols) ? cols : []), ...(Array.isArray(posts) ? posts : [])]
      all.sort((a, b) => new Date(b.fav_time).getTime() - new Date(a.fav_time).getTime())

      const list = all.slice(offset, offset + pageSize)
      res.json({ code: 200, data: { list, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] public items:', e.message)
      res.serverError(e)
    }
  })

  // ========== 29. 阅读进度 ==========

  app.post('/api/community/collection/:id/progress', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { postId } = req.body || {}
      const pid = safeInt(postId, 0)

      const collection = await query('SELECT id, post_count FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const totalPosts = collection[0].post_count || 1
      const ccp = await query('SELECT sort_order FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      const sortOrder = ccp.length > 0 ? ccp[0].sort_order : 1
      const progressPct = totalPosts > 0 ? ((sortOrder / totalPosts) * 100).toFixed(2) : 0

      await query(
        'INSERT INTO collection_read_progress (user_id, collection_id, last_post_id, progress_pct) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE last_post_id=VALUES(last_post_id), progress_pct=VALUES(progress_pct), update_time=NOW()',
        [userId, cid, pid, Number(progressPct)]
      )
      res.json({ code: 200, msg: '进度已更新', data: { progressPct: Number(progressPct), lastPostId: pid } })
    } catch (e) {
      console.error('[Collection] progress:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/progress', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const row = await query('SELECT * FROM collection_read_progress WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, data: row.length > 0 ? row[0] : null })
    } catch (e) {
      console.error('[Collection] get progress:', e.message)
      res.serverError(e)
    }
  })

  // ========== 30. 合集评论/评分 ==========

  app.post('/api/community/collection/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { content: rawContent, parent_id: parentId = 0, images, rating } = req.body || {}
      const content = sanitizeCommunityContent(rawContent)
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const collection = await query('SELECT id, user_id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const userInfo = await query('SELECT nickname, avatar FROM users WHERE id=?', [userId])
      const userName = userInfo[0]?.nickname || ('user_' + userId)
      const userAvatar = userInfo[0]?.avatar || ''
      const imgStr = images ? (typeof images === 'string' ? images : JSON.stringify(images)) : '[]'

      let commentStatus = 'published'
      const commentSkipReview = await hasPermission(userId, 'community', 'C2')
      if (commentSkipReview) {
        commentStatus = 'published'
      } else {
        try {
          const mp = require('./community/moderation-pipeline.cjs')
          const pipelineResult = await mp.moderationPipeline(userId, {
            text: content || '',
            title: '',
            content: content || ''
          }, 'comment')
          if (pipelineResult.action === 'reject') commentStatus = 'rejected'
          if (pipelineResult.action === 'pending') commentStatus = 'pending'
        } catch (e) { console.error('[collection] moderation pipeline error:', e.message) }
      }

      const insertParentId = Number(parentId) || 0
      const result = await query(
        `INSERT INTO community_comments (post_id, parent_id, user_id, user_name, user_avatar, content, images, status)
         VALUES (?,?,?,?,?,?,?,?)`,
        [cid, insertParentId, userId, userName, userAvatar, content.trim(), imgStr, commentStatus]
      )

      if (insertParentId > 0) {
        await query('UPDATE community_comments SET reply_count = reply_count + 1 WHERE id=?', [insertParentId])
      }
      if (commentStatus !== 'rejected') {
        try {
          const { incrementCommentCount } = require('./community/community-utils.cjs')
          await incrementCommentCount(userId)
        } catch (e) { /* ignore */ }
      }

      if (rating > 0 && rating <= 5 && insertParentId === 0) {
        const existing = await query(
          'SELECT id FROM community_ratings WHERE user_id=? AND target_type=? AND target_id=?',
          [userId, 'collection', cid]
        )
        if (existing.length) {
          await query('UPDATE community_ratings SET rating=? WHERE id=?', [rating, existing[0].id])
        } else {
          await query(
            'INSERT INTO community_ratings (user_id, target_type, target_id, rating) VALUES (?,?,?,?)',
            [userId, 'collection', cid, rating]
          )
        }
        try {
          await query(
            `UPDATE community_collections SET 
               rating_count = (SELECT COUNT(*) FROM community_ratings WHERE target_type='collection' AND target_id=?)
             WHERE id=?`,
            [cid, cid]
          )
        } catch {} // rating_avg column may not exist yet
      }

      res.json({ code: 200, msg: commentStatus === 'rejected' ? '评论已被系统拦截' : '评论成功', data: { id: result.insertId, status: commentStatus } })
    } catch (e) {
      console.error('[Collection] comment:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/comments', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const sortBy = req.query.sortBy || 'default'
      const offset = (page - 1) * pageSize

      const currentUserId = await getUserId(req)
      const isAdminUser = await isAdmin(req)

      let statusFilter = "AND c.status='published'"
      if (currentUserId > 0) {
        const collectionOwner = await query('SELECT user_id FROM community_collections WHERE id=?', [cid])
        const isCollectionOwner = collectionOwner.length > 0 && collectionOwner[0].user_id === currentUserId
        if (isAdminUser || isCollectionOwner) {
          statusFilter = ''
        } else {
          statusFilter = `AND (c.status='published' OR (c.status='pending' AND c.user_id=${currentUserId}) OR (c.status='rejected' AND c.user_id=${currentUserId}))`
        }
      }

      const totalResult = await query(
        `SELECT COUNT(*) as cnt FROM community_comments c WHERE c.post_id=? AND c.parent_id=0 AND c.is_deleted=0 ${statusFilter}`, [cid]
      )
      const total = totalResult[0]?.cnt || 0

      const allCountResult = await query(
        `SELECT COUNT(*) as cnt FROM community_comments c WHERE c.post_id=? AND c.is_deleted=0 ${statusFilter}`, [cid]
      )
      const commentCount = allCountResult[0]?.cnt || 0

      const orderClause = sortBy === 'hot'
        ? 'ORDER BY c.is_pinned DESC, (c.like_count + c.reply_count) DESC, c.create_time DESC'
        : 'ORDER BY c.is_pinned DESC, c.create_time DESC'

      const list = await query(
        `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                c.content, c.images,
                c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                c.create_time as createTime,
                u.is_verified as userIsVerified,
                COALESCE(el.name, 'Lv.1') as userExpLevelName,
                el.icon as userExpLevelIcon,
                COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                u.active_title_name as userTitleName,
                ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                ut_all.allIcons as userAllTitleIcons,
                ut_all.allNames as userAllTitleNames,
                (SELECT GROUP_CONCAT(ct3.name SEPARATOR '|||') FROM user_titles ut3 JOIN custom_titles ct3 ON ut3.title_id = ct3.id WHERE ut3.user_id = c.user_id AND ct3.status = '1' AND ut3.title_id IN (u.active_title_id, u.active_title_id2, u.active_title_id3)) as userActiveTitleNames,
                (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect,
                (SELECT JSON_OBJECT('image_url', d2.image_url, 'config_json', d2.config_json, 'css_class', d2.css_class) FROM decorations d2 WHERE d2.id = u.active_comment_background_id AND d2.type = 'comment_background' AND d2.status = '1') as userCommentBackground
         FROM community_comments c
         LEFT JOIN users u ON c.user_id = u.id
         LEFT JOIN experience_levels el ON el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status = '1'
           AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el2.status = '1' AND el2.exp_required > el.exp_required)
         LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
         LEFT JOIN membership_levels ml ON ml.id = u.level_id
         LEFT JOIN (
           SELECT ut2.user_id,
             GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
             GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
           FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
           WHERE ct2.status = '1' GROUP BY ut2.user_id
         ) ut_all ON u.id = ut_all.user_id
         WHERE c.post_id=? AND c.parent_id=0 AND c.is_deleted=0 ${statusFilter}
         ${orderClause} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`,
        [cid]
      )

      let allReplies = []
      if (list.length > 0) {
        const commentIds = list.map(c => c.id)
        allReplies = await query(
          `SELECT c.id, c.post_id as postId, c.parent_id as parentId, c.user_id as userId,
                  c.user_name as userName, CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), c.user_avatar, '') END as userAvatar,
                  c.content, c.images,
                  c.like_count as likeCount, c.reply_count as replyCount, c.is_pinned as isPinned,
                  c.create_time as createTime,
                  u.is_verified as userIsVerified,
                  COALESCE(el.name, 'Lv.1') as userExpLevelName,
                  el.icon as userExpLevelIcon,
                  COALESCE(el.text_color, '#FFFFFF') as userExpLevelTextColor,
                  COALESCE(el.bg_color, '#508DFF') as userExpLevelBgColor,
                  u.active_title_name as userTitleName,
                  ct.icon as userTitleIcon, ct.color as userTitleColor, ct.bg_color as userTitleBgColor,
                  ml.name as userMemberLevelName, ml.icon as userMemberLevelIcon,
                  ut_all.allIcons as userAllTitleIcons,
                  ut_all.allNames as userAllTitleNames,
                  (SELECT GROUP_CONCAT(ct3.name SEPARATOR '|||') FROM user_titles ut3 JOIN custom_titles ct3 ON ut3.title_id = ct3.id WHERE ut3.user_id = c.user_id AND ct3.status = '1' AND ut3.title_id IN (u.active_title_id, u.active_title_id2, u.active_title_id3)) as userActiveTitleNames,
                  (SELECT af.image_url FROM user_avatar_frames uaf JOIN avatar_frames af ON uaf.frame_id = af.id WHERE uaf.user_id = c.user_id AND uaf.is_active = 1 AND af.status = '1' LIMIT 1) as userAvatarFrame,
                  (SELECT d.config_json FROM decorations d WHERE d.id = u.active_nickname_effect_id AND d.type = 'nickname_effect' AND d.status = '1') as userNicknameEffect,
                  (SELECT JSON_OBJECT('image_url', d2.image_url, 'config_json', d2.config_json, 'css_class', d2.css_class) FROM decorations d2 WHERE d2.id = u.active_comment_background_id AND d2.type = 'comment_background' AND d2.status = '1') as userCommentBackground
           FROM community_comments c
           LEFT JOIN users u ON c.user_id = u.id
           LEFT JOIN experience_levels el ON el.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el.status = '1'
             AND NOT EXISTS (SELECT 1 FROM experience_levels el2 WHERE el2.exp_required <= COALESCE((SELECT available + frozen FROM user_currency_balance WHERE user_id=u.id AND currency_key='experience'), 0) AND el2.status = '1' AND el2.exp_required > el.exp_required)
           LEFT JOIN custom_titles ct ON ct.id = u.active_title_id
           LEFT JOIN membership_levels ml ON ml.id = u.level_id
           LEFT JOIN (
             SELECT ut2.user_id,
               GROUP_CONCAT(CASE WHEN ct2.icon IS NOT NULL AND ct2.icon != '' THEN ct2.icon END SEPARATOR '|||') as allIcons,
               GROUP_CONCAT(ct2.name SEPARATOR '|||') as allNames
             FROM user_titles ut2 JOIN custom_titles ct2 ON ut2.title_id = ct2.id
             WHERE ct2.status = '1' GROUP BY ut2.user_id
           ) ut_all ON u.id = ut_all.user_id
           WHERE c.post_id=? AND c.parent_id>0 AND c.is_deleted=0 AND c.parent_id IN (${commentIds.join(',')}) ORDER BY c.create_time ASC`,
          [cid]
        )
      }

      const replyMap = {}
      for (const r of allReplies) {
        const pid = r.parentId
        if (!replyMap[pid]) replyMap[pid] = []
        replyMap[pid].push(r)
      }
      const nestedList = list.map(c => ({
        ...c,
        replies: replyMap[c.id] || [],
        replyCount: c.replyCount || (replyMap[c.id]?.length || 0)
      }))

      res.json({ code: 200, data: { list: nestedList, total, commentCount, page, pageSize } })
    } catch (e) {
      console.error('[Collection] comments:', e.message)
      res.serverError(e)
    }
  })

  app.post('/api/community/collection/:id/rate', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { rating } = req.body || {}
      const r = safeInt(rating, 0)
      if (r < 1 || r > 5) return res.json({ code: 400, msg: '评分范围为1-5' })

      const collection = await query('SELECT id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const existing = await query(
        'SELECT id FROM community_ratings WHERE user_id=? AND target_type=? AND target_id=?',
        [userId, 'collection', cid]
      )
      if (existing.length) {
        await query('UPDATE community_ratings SET rating=? WHERE id=?', [r, existing[0].id])
      } else {
        await query(
          'INSERT INTO community_ratings (user_id, target_type, target_id, rating) VALUES (?,?,?,?)',
          [userId, 'collection', cid, r]
        )
      }
      res.json({ code: 200, msg: '评分成功' })
    } catch (e) {
      console.error('[Collection] rate:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/rating', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const rows = await query(
        "SELECT COUNT(*) as count, COALESCE(AVG(rating), 0) as avg FROM community_ratings WHERE target_type=? AND target_id=?",
        ['collection', cid]
      )
      res.json({
        code: 200,
        data: { avgRating: Number(Number(rows[0]?.avg || 0).toFixed(1)), count: rows[0]?.count || 0 }
      })
    } catch (e) {
      console.error('[Collection] get rating:', e.message)
      res.serverError(e)
    }
  })

  // ========== 31. 批量排序 ==========

  app.put('/api/community/collection/:id/posts/batch-sort', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      const { items } = req.body || {}
      if (!items || !Array.isArray(items)) return res.json({ code: 400, msg: '请提供排序数据' })

      for (const item of items) {
        await query(
          'UPDATE community_collection_posts SET sort_order=? WHERE collection_id=? AND post_id=?',
          [safeInt(item.sortOrder, 0), cid, safeInt(item.postId, 0)]
        )
      }
      await query('UPDATE community_collections SET update_time=' + nowExpr + ' WHERE id=?', [cid])
      res.json({ code: 200, msg: '排序更新成功' })
    } catch (e) {
      console.error('[Collection] batch-sort:', e.message)
      res.serverError(e)
    }
  })

  // ========== 32. 分享追踪 ==========

  app.post('/api/community/collection/:id/share', authRequired, async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      await query('UPDATE community_collections SET share_count = COALESCE(share_count,0) + 1 WHERE id=?', [cid])
      res.json({ code: 200, msg: '分享成功' })
    } catch (e) {
      console.error('[Collection] share:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/share-stats', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const row = await query('SELECT COALESCE(share_count, 0) as share_count FROM community_collections WHERE id=?', [cid])
      res.json({ code: 200, data: { shareCount: row.length > 0 ? row[0].share_count : 0 } })
    } catch (e) {
      console.error('[Collection] share-stats:', e.message)
      res.serverError(e)
    }
  })

  // ========== 合集点赞 ==========
  app.post('/api/community/collection/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      if (!cid) return res.json({ code: 400, msg: '参数错误' })
      await query('INSERT IGNORE INTO collection_likes (collection_id, user_id) VALUES (?,?)', [cid, userId])
      res.json({ code: 200, msg: '点赞成功' })
    } catch (e) {
      console.error('[Collection] like:', e.message)
      res.serverError(e)
    }
  })

  app.delete('/api/community/collection/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      await query('DELETE FROM collection_likes WHERE collection_id=? AND user_id=?', [cid, userId])
      res.json({ code: 200, msg: '已取消点赞' })
    } catch (e) {
      console.error('[Collection] unlike:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/like', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cid = safeInt(req.params.id, 0)
      let liked = false
      if (userId) {
        const rows = await query('SELECT id FROM collection_likes WHERE collection_id=? AND user_id=?', [cid, userId])
        liked = rows.length > 0
      }
      const countRes = await query('SELECT COUNT(*) as cnt FROM collection_likes WHERE collection_id=?', [cid])
      res.json({ code: 200, data: { liked, count: countRes[0]?.cnt || 0 } })
    } catch (e) {
      console.error('[Collection] like check:', e.message)
      res.serverError(e)
    }
  })

  // 更新分组列表（计数含帖子和合集）
  app.get('/api/community/favorite/groups', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      await ensureDefaultGroup(userId)
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM collection_favorites WHERE group_id=g.id AND user_id=g.user_id) +
          (SELECT COUNT(*) FROM post_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM collection_favorite_groups g WHERE g.user_id=? ORDER BY g.sort_order ASC, g.id ASC`,
        [userId]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      console.error('[Favorite] groups:', e.message)
      res.serverError(e)
    }
  })
}
