const { query } = require('../database.cjs')
const { sessions, SESSION_TTL } = require('./system.cjs')
const { hasPermission, getPermissionValue } = require('../middleware/level-permissions.cjs')

const nowExpr = 'NOW()'

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0

  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) {
      const row = rows[0]
      const createdAt = typeof row.created_at === 'number' ? row.created_at : new Date(row.created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {}); return 0 }
      sessions.set(token, { userId: row.user_id, createdAt })
      return Number(row.user_id) || 0
    }
  } catch { return 0 }
  return 0
}

async function getUserRoles(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return []
  const session = sessions.get(token)
  if (session) return session.roles || []
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows && rows.length > 0) return JSON.parse(rows[0].roles || '[]')
  } catch {}
  return []
}

async function isAdmin(req) {
  const roles = await getUserRoles(req)
  return roles.includes('admin') || roles.includes('super_admin')
}

function safeInt(v, def) {
  const n = parseInt(v)
  return isNaN(n) ? def : n
}

function safeFloat(v, def) {
  const n = parseFloat(v)
  return isNaN(n) ? def : n
}

module.exports = function collectionRoutes(app) {
  // ========== POST ==========

  // 创建合集
  app.post('/api/community/collection', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { title, description, coverImage, sectionId, isPaid, priceBalance, pricePoints, previewCount, sortMode } = req.body || {}
      if (!title || !title.trim()) return res.json({ code: 400, msg: '合集标题不能为空' })

      // D3: 创建合集数量上限
      const maxCollections = parseInt(await getPermissionValue(userId, 'social', 'D3') || '999')
      const cnt = await query('SELECT COUNT(*) as cnt FROM community_collections WHERE creator_id=?', [userId])
      if ((cnt[0]?.cnt || 0) >= maxCollections) {
        return res.json({ code: 400, msg: `当前等级最多创建${maxCollections}个合集` })
      }

      const userRow = (await query('SELECT username, avatar FROM users WHERE id=?', [userId]))?.[0] || {}
      const userName = userRow.username || ''
      const userAvatar = userRow.avatar || ''

      const isPaidInt = isPaid ? 1 : 0
      const balanceVal = safeFloat(priceBalance, 0)
      const pointsVal = safeInt(pricePoints, 0)

      const result = await query(
        `INSERT INTO community_collections (user_id, user_name, user_avatar, title, description, cover_image,
         section_id, is_paid, price_balance, price_points, preview_count, sort_mode, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft')`,
        [userId, userName, userAvatar, title.trim(), description || '', coverImage || '', sectionId || 0,
         isPaidInt, balanceVal, pointsVal, previewCount || 0, sortMode || 'manual']
      )

      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) {
      console.error('[Collection] create:', e.message)
      res.serverError(e)
    }
  })

  // 向合集添加帖子
  app.post('/api/community/collection/:id/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许添加帖子' })

      const { postIds, isPreview } = req.body || {}
      if (!postIds || !Array.isArray(postIds) || postIds.length === 0) {
        return res.json({ code: 400, msg: '请选择帖子' })
      }

      for (const pid of postIds) {
        const post = await query('SELECT id, user_id FROM community_posts WHERE id=? AND status IN (\'published\',\'reviewed\')', [pid])
        if (!post.length) return res.json({ code: 400, msg: `帖子 ${pid} 不存在或未发布` })
        if (post[0].user_id !== userId) return res.json({ code: 403, msg: `帖子 ${pid} 不属于你` })
      }

      for (const pid of postIds) {
        const existing = await query('SELECT collection_id FROM community_collection_posts WHERE post_id=?', [pid])
        if (existing.length) return res.json({ code: 400, msg: `帖子 ${pid} 已归属其他合集` })
      }

      const currentMaxSort = await query('SELECT MAX(sort_order) as ms FROM community_collection_posts WHERE collection_id=?', [cid])
      let nextSort = (currentMaxSort[0].ms || 0) + 1

      for (const pid of postIds) {
        await query(
          'INSERT INTO community_collection_posts (collection_id, post_id, sort_order, is_preview) VALUES (?,?,?,?)',
          [cid, pid, nextSort, isPreview ? 1 : 0]
        )
        nextSort++
      }

      const newCount = await query('SELECT COUNT(*) as cnt FROM community_collection_posts WHERE collection_id=?', [cid])
      await query('UPDATE community_collections SET post_count=?, update_time=' + nowExpr + ' WHERE id=?', [newCount[0].cnt, cid])

      res.json({ code: 200, msg: '添加成功' })
    } catch (e) {
      console.error('[Collection] add posts:', e.message)
      res.serverError(e)
    }
  })

  // 购买合集
  app.post('/api/community/collection/:id/buy', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

    if (c.user_id === userId) return res.json({ code: 400, msg: '作者无需购买自己的合集' })
    if (!c.is_paid) return res.json({ code: 400, msg: '本合集为免费合集，无需购买' })

    const { payType } = req.body || {}
    if (!payType || !['balance', 'points'].includes(payType)) {
      return res.json({ code: 400, msg: '请选择支付方式' })
    }

    const price = payType === 'points' ? Number(c.price_points) : Number(c.price_balance)
    if (price <= 0) return res.json({ code: 400, msg: '本合集未设置该支付方式的价格' })

    const already = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
    if (already.length) return res.json({ code: 400, msg: '已购买此合集' })

    const field = payType === 'points' ? 'points' : 'balance'
    const unitLabel = payType === 'points' ? '积分' : '余额'

    const user = await query(`SELECT ${field}, nickname FROM users WHERE id=?`, [userId])
    if (!user.length) return res.json({ code: 404, msg: '用户不存在' })
    if (Number(user[0][field]) < price) return res.json({ code: 400, msg: unitLabel + '不足' })

    const fromName = user[0].nickname || ('user_' + userId)

    if (payType === 'points') {
      await query('UPDATE users SET points = points - ? WHERE id=?', [price, userId])
      await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
        VALUES (?,?,'expense',?, (SELECT points FROM users WHERE id=?), '合集购买', ?)`,
        [userId, fromName, price, userId, '购买合集《' + c.title + '》'])
      await query('UPDATE users SET points = points + ? WHERE id=?', [price, c.user_id])
      await query(`INSERT INTO points_records (user_id, user_name, type, points, balance, source, description)
        VALUES (?,?,'income',?, (SELECT points FROM users WHERE id=?), '合集销售收入', ?)`,
        [c.user_id, c.user_name || '', price, c.user_id, '合集《' + c.title + '》销售'])
    } else {
      await query('UPDATE users SET balance = balance - ? WHERE id=?', [price, userId])
      await query(`INSERT INTO balance_records (user_id, amount, balance, type, source, description, create_time)
        VALUES (?, ?, (SELECT balance FROM users WHERE id=?), 'consume', 'collection_purchase', ?, NOW())`,
        [userId, -price, userId, '购买合集《' + c.title + '》'])
      await query('UPDATE users SET balance = balance + ? WHERE id=?', [price, c.user_id])
      await query(`INSERT INTO balance_records (user_id, amount, balance, type, source, description, create_time)
        VALUES (?, ?, (SELECT balance FROM users WHERE id=?), 'income', 'collection_income', ?, NOW())`,
        [c.user_id, price, c.user_id, '合集《' + c.title + '》销售收入'])
    }

    await query('INSERT INTO user_paid_collections (user_id, collection_id, amount, pay_type) VALUES (?,?,?,?)', [userId, cid, price, payType])
    await query('UPDATE community_collections SET subscribe_count = subscribe_count + 1 WHERE id=?', [cid])

    try {
      await query(
        `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, is_read, create_time)
         VALUES (?,?, 'collection_purchase',?,?,?,0,NOW())`,
        ['合集购买通知', '用户 ' + fromName + ' 购买了你的合集《' + c.title + '》', c.user_id, userId, fromName]
      )
    } catch (e) { console.error('[collection] purchase notify failed:', c.title, e.message) }

    res.json({ code: 200, msg: '购买成功' })
    } catch (e) {
      console.error('[Collection] buy:', e.message)
      res.serverError(e)
    }
  })

  // ========== GET (静态路由必须放在 :id 之前) ==========

  // 我的合集列表
  app.get('/api/community/collection/mine', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT * FROM community_collections WHERE user_id=? AND is_deleted=0 ORDER BY update_time DESC LIMIT ? OFFSET ?`,
          [userId, pageSize, offset]
        ),
        query('SELECT COUNT(*) as cnt FROM community_collections WHERE user_id=? AND is_deleted=0', [userId])
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] mine:', e.message)
      res.serverError(e)
    }
  })

  // 某用户的合集列表（公开）
  app.get('/api/community/collection/user/:userId', async (req, res) => {
    try {
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize
      const uid = safeInt(req.params.userId, 0)

      const author = await query('SELECT status FROM users WHERE id=?', [uid])
      const authorBanned = !!(author.length && author[0].status === '0')

      if (authorBanned) return res.json({ code: 200, data: { list: [], total: 0, page, pageSize } })

      const [rows, total] = await Promise.all([
        query(
          `SELECT * FROM community_collections WHERE user_id=? AND is_deleted=0 AND status IN ('serializing','finished')
           ORDER BY update_time DESC LIMIT ? OFFSET ?`,
          [uid, pageSize, offset]
        ),
        query(
          'SELECT COUNT(*) as cnt FROM community_collections WHERE user_id=? AND is_deleted=0 AND status IN (\'serializing\',\'finished\')',
          [uid]
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] user:', e.message)
      res.serverError(e)
    }
  })

  // 已购合集列表
  app.get('/api/community/collection/paid', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT c.*, upc.amount as paid_amount, upc.pay_time
           FROM user_paid_collections upc
           INNER JOIN community_collections c ON upc.collection_id = c.id AND c.is_deleted = 0
           WHERE upc.user_id=? ORDER BY upc.pay_time DESC LIMIT ? OFFSET ?`,
          [userId, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM user_paid_collections upc
           INNER JOIN community_collections c ON upc.collection_id = c.id AND c.is_deleted = 0
           WHERE upc.user_id=?`,
          [userId]
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] paid:', e.message)
      res.serverError(e)
    }
  })

  // 精选合集（用于推荐）
  app.get('/api/community/collections/featured', async (req, res) => {
    try {
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 10)
      const offset = (page - 1) * pageSize

      const [rows, total] = await Promise.all([
        query(
          `SELECT c.* FROM community_collections c
           INNER JOIN users u ON c.user_id = u.id AND u.status = '1'
           WHERE c.is_deleted=0 AND c.status IN ('serializing','finished') AND c.post_count > 0
           ORDER BY c.subscribe_count DESC, c.view_count DESC, c.update_time DESC
           LIMIT ? OFFSET ?`,
          [pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM community_collections c
           INNER JOIN users u ON c.user_id = u.id AND u.status = '1'
           WHERE c.is_deleted=0 AND c.status IN ('serializing','finished') AND c.post_count > 0`
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Collection] featured:', e.message)
      res.serverError(e)
    }
  })

  // 获取帖子所属合集
  app.get('/api/community/post/:id/collection', async (req, res) => {
    try {
      const pid = safeInt(req.params.id, 0)
      const rows = await query(
        `SELECT c.* FROM community_collections c
         INNER JOIN community_collection_posts ccp ON c.id = ccp.collection_id
         WHERE ccp.post_id=? AND c.is_deleted=0`,
        [pid]
      )
      if (!rows.length) return res.json({ code: 200, data: null })

      const c = rows[0]
      const posts = await query(
        `SELECT ccp.sort_order, ccp.is_preview, p.id
         FROM community_collection_posts ccp
         INNER JOIN community_posts p ON ccp.post_id = p.id
         WHERE ccp.collection_id=? AND p.status NOT IN ('deleted')
         ORDER BY ccp.sort_order ASC`,
        [c.id]
      )

      const currentIndex = posts.findIndex(p => p.id === pid)
      const prevPost = currentIndex > 0 ? posts[currentIndex - 1] : null
      const nextPost = currentIndex < posts.length - 1 ? posts[currentIndex + 1] : null

      res.json({
        code: 200,
        data: {
          collection: c,
          postIndex: currentIndex + 1,
          totalPosts: posts.length,
          prevPost: prevPost ? { id: prevPost.id } : null,
          nextPost: nextPost ? { id: nextPost.id } : null,
        }
      })
    } catch (e) {
      console.error('[Collection] post-collection:', e.message)
      res.serverError(e)
    }
  })

  // 获取合集详情 (动态路由，放在最后)
  app.get('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cid = safeInt(req.params.id, 0)
      if (!cid) return res.json({ code: 404, msg: '合集不存在' })

      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

      const isAuthor = userId === c.user_id
      let hasPaid = false
      if (userId) {
        const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, c.id])
        hasPaid = paid.length > 0
      }

      const author = await query('SELECT status FROM users WHERE id=?', [c.user_id])
      const authorBanned = !!(author.length && author[0].status === '0')
      const collectionUserId = c.user_id

      if (authorBanned && !hasPaid && !isAuthor) {
        return res.json({ code: 200, data: { ...c, hidden: true, reason: 'author_banned' } })
      }

      let posts = await query(
        `SELECT ccp.sort_order, ccp.is_preview, ccp.post_id,
                p.id, p.title, p.status as post_status, p.user_id as post_user_id,
                p.user_name as post_user_name, p.view_count, p.comment_count, p.like_count,
                LEFT(p.content, 200) as summary, p.create_time as post_create_time,
                (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
                 OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
                 OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
         FROM community_collection_posts ccp
         INNER JOIN community_posts p ON ccp.post_id = p.id
         WHERE ccp.collection_id=?
         ORDER BY ccp.sort_order ASC`,
        [c.id]
      )

      const effectivePosts = []
      let effectiveCount = 0
      for (const p of posts) {
        const isDeleted = p.post_status === 'deleted'
        if (isDeleted) {
          effectivePosts.push({ ...p, invalid: true, invalid_reason: '帖子已删除或隐藏，无法阅读' })
        } else {
          effectiveCount++
          // 过滤含受限内容的帖子摘要
          if (p.has_restricted && !isAuthor && !hasPaid) {
            p.summary = '该帖子含付费/限制内容，购买合集后查看'
          }
          effectivePosts.push({ ...p, invalid: false })
        }
      }

      if (effectiveCount !== c.post_count) {
        await query('UPDATE community_collections SET post_count=? WHERE id=?', [effectiveCount, c.id])
        c.post_count = effectiveCount
      }

      let subscribers = []
      if (isAuthor && c.subscribe_count > 0) {
        subscribers = await query(
          `SELECT upc.user_id, upc.amount, upc.pay_time, upc.pay_type, u.nickname as user_name
           FROM user_paid_collections upc
           INNER JOIN users u ON upc.user_id = u.id
           WHERE upc.collection_id=? ORDER BY upc.pay_time DESC LIMIT 50`,
          [c.id]
        )
      }

      res.json({
        code: 200,
        data: { ...c, posts: effectivePosts, isAuthor, hasPaid, hidden: false, subscribers }
      })
    } catch (e) {
      console.error('[Collection] get:', e.message)
      res.serverError(e)
    }
  })

  // 检查是否已购买
  app.get('/api/community/collection/:id/check-paid', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: { hasPaid: false } })

      const cid = safeInt(req.params.id, 0)
      const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, data: { hasPaid: paid.length > 0 } })
    } catch (e) {
      console.error('[Collection] check-paid:', e.message)
      res.serverError(e)
    }
  })

  // 获取合集内某篇帖子内容
  app.get('/api/community/collection/:id/post/:postId', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const cid = safeInt(req.params.id, 0)
      const pid = safeInt(req.params.postId, 0)

      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      const c = collection[0]

      const ccp = await query('SELECT * FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      if (!ccp.length) return res.json({ code: 404, msg: '帖子不在合集中' })

      const post = await query('SELECT * FROM community_posts WHERE id=? AND status IN (\'published\',\'reviewed\')', [pid])
      if (!post.length) return res.json({ code: 404, msg: '帖子不存在' })
      const p = post[0]

      const isAuthor = userId === c.user_id
      const isTrial = ccp[0].is_preview === 1

      if (!isAuthor && !isTrial && c.is_paid && (Number(c.price_balance) > 0 || Number(c.price_points) > 0)) {
        if (!userId) return res.json({ code: 401, msg: '请先登录' })
        const paid = await query('SELECT id FROM user_paid_collections WHERE user_id=? AND collection_id=?', [userId, cid])
        if (!paid.length) return res.json({ code: 403, msg: '请购买合集后阅读', needBuy: true, collection: c })
      }

      res.json({ code: 200, data: p })
    } catch (e) {
      console.error('[Collection] post content:', e.message)
      res.serverError(e)
    }
  })

  // ========== PUT ==========

  // 更新合集信息
  app.put('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId && !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })

      const { title, description, coverImage, isPaid, priceBalance, pricePoints, previewCount, sortMode, status } = req.body || {}

      const updates = []
      const params = []
      if (title !== undefined) { updates.push('title=?'); params.push(title.trim()) }
      if (description !== undefined) { updates.push('description=?'); params.push(description) }
      if (coverImage !== undefined) { updates.push('cover_image=?'); params.push(coverImage) }
      if (isPaid !== undefined) { updates.push('is_paid=?'); params.push(isPaid ? 1 : 0) }
      if (priceBalance !== undefined) { updates.push('price_balance=?'); params.push(safeFloat(priceBalance, 0)) }
      if (pricePoints !== undefined) { updates.push('price_points=?'); params.push(safeInt(pricePoints, 0)) }
      if (previewCount !== undefined) { updates.push('preview_count=?'); params.push(safeInt(previewCount, 0)) }
      if (sortMode !== undefined) { updates.push('sort_mode=?'); params.push(sortMode) }
      if (status !== undefined) {
        if (collection[0].status === 'finished' && status !== 'finished') {
          return res.json({ code: 400, msg: '已完结合集不允许恢复为草稿或连载中状态' })
        }
        updates.push('status=?'); params.push(status)
      }
      if (updates.length === 0) return res.json({ code: 400, msg: '无更新内容' })

      updates.push('update_time=' + nowExpr)
      params.push(cid)

      await query(`UPDATE community_collections SET ${updates.join(',')} WHERE id=?`, params)

      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      console.error('[Collection] update:', e.message)
      res.serverError(e)
    }
  })

  // 更新帖子排序
  app.put('/api/community/collection/:id/posts/sort', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })
      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许调整排序' })

      const { sortedPostIds } = req.body || {}
      if (!sortedPostIds || !Array.isArray(sortedPostIds)) {
        return res.json({ code: 400, msg: '请提供排序后的帖子ID列表' })
      }

      for (let i = 0; i < sortedPostIds.length; i++) {
        await query('UPDATE community_collection_posts SET sort_order=? WHERE collection_id=? AND post_id=?',
          [i + 1, cid, sortedPostIds[i]])
      }

      await query('UPDATE community_collections SET update_time=' + nowExpr + ' WHERE id=?', [cid])

      res.json({ code: 200, msg: '排序更新成功' })
    } catch (e) {
      console.error('[Collection] sort:', e.message)
      res.serverError(e)
    }
  })

  // 设置/取消试读帖
  app.put('/api/community/collection/:id/posts/:postId/preview', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      const { isPreview } = req.body || {}

      await query('UPDATE community_collection_posts SET is_preview=? WHERE collection_id=? AND post_id=?',
        [isPreview ? 1 : 0, cid, safeInt(req.params.postId, 0)])

      res.json({ code: 200, msg: '设置成功' })
    } catch (e) {
      console.error('[Collection] preview:', e.message)
      res.serverError(e)
    }
  })

  // ========== DELETE ==========

  // 删除合集（仅草稿可删）
  app.delete('/api/community/collection/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId && !(await isAdmin(req))) return res.json({ code: 403, msg: '无权限' })
      if (collection[0].status !== 'draft') return res.json({ code: 400, msg: '仅草稿状态的合集可删除' })

      await query('UPDATE community_collections SET is_deleted=1, update_time=' + nowExpr + ' WHERE id=?', [cid])
      await query('DELETE FROM community_collection_posts WHERE collection_id=?', [cid])

      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Collection] delete:', e.message)
      res.serverError(e)
    }
  })

  // 从合集移除帖子
  app.delete('/api/community/collection/:id/posts', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })
      if (collection[0].status === 'finished') return res.json({ code: 400, msg: '已完结合集不允许移除帖子' })

      const { postIds } = req.body || {}
      if (!postIds || !Array.isArray(postIds) || postIds.length === 0) {
        return res.json({ code: 400, msg: '请选择要移除的帖子' })
      }

      for (const pid of postIds) {
        await query('DELETE FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      }

      const newCount = await query('SELECT COUNT(*) as cnt FROM community_collection_posts WHERE collection_id=?', [cid])
      await query('UPDATE community_collections SET post_count=?, update_time=' + nowExpr + ' WHERE id=?', [newCount[0].cnt, cid])

      res.json({ code: 200, msg: '移除成功' })
    } catch (e) {
      console.error('[Collection] remove posts:', e.message)
      res.serverError(e)
    }
  })

  // ========== 收藏分组 API ==========

  // 确保用户有默认分组
  async function ensureDefaultGroup(userId) {
    const rows = await query('SELECT id FROM collection_favorite_groups WHERE user_id=?', [userId])
    if (!rows.length) {
      const r = await query('INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,\'默认收藏夹\',0)', [userId])
      return r.insertId
    }
    return rows[0].id
  }

  // 创建分组
  app.post('/api/community/favorite/groups', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { name } = req.body || {}
      if (!name || !name.trim()) return res.json({ code: 400, msg: '分组名称不能为空' })
      const maxOrder = await query('SELECT MAX(sort_order) as m FROM collection_favorite_groups WHERE user_id=?', [userId])
      const sortOrder = (maxOrder[0]?.m || 0) + 1
      const r = await query('INSERT INTO collection_favorite_groups (user_id, name, sort_order) VALUES (?,?,?)', [userId, name.trim(), sortOrder])
      res.json({ code: 200, data: { id: r.insertId, name: name.trim(), sort_order: sortOrder, count: 0 } })
    } catch (e) {
      console.error('[Favorite] create group:', e.message)
      res.serverError(e)
    }
  })

  // 修改分组名
  app.put('/api/community/favorite/groups/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      if (!g.length) return res.json({ code: 404, msg: '分组不存在' })
      const { name } = req.body || {}
      if (!name || !name.trim()) return res.json({ code: 400, msg: '分组名称不能为空' })
      await query('UPDATE collection_favorite_groups SET name=? WHERE id=?', [name.trim(), gid])
      res.json({ code: 200, msg: '修改成功' })
    } catch (e) {
      console.error('[Favorite] update group:', e.message)
      res.serverError(e)
    }
  })

  // 删除分组（合集移到默认分组）
  app.delete('/api/community/favorite/groups/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groups = await query('SELECT id FROM collection_favorite_groups WHERE user_id=? AND id!=?', [userId, gid])
      if (!groups.length) return res.json({ code: 400, msg: '至少保留一个分组' })
      const defaultId = await ensureDefaultGroup(userId)
      if (gid === defaultId) return res.json({ code: 400, msg: '不能删除默认分组' })
      await query('UPDATE collection_favorites SET group_id=? WHERE group_id=? AND user_id=?', [defaultId, gid, userId])
      await query('DELETE FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      console.error('[Favorite] delete group:', e.message)
      res.serverError(e)
    }
  })

  // 排序分组
  app.post('/api/community/favorite/groups/reorder', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { ids } = req.body || {}
      if (!ids || !Array.isArray(ids)) return res.json({ code: 400, msg: '参数错误' })
      for (let i = 0; i < ids.length; i++) {
        await query('UPDATE collection_favorite_groups SET sort_order=? WHERE id=? AND user_id=?', [i, ids[i], userId])
      }
      res.json({ code: 200, msg: '排序成功' })
    } catch (e) {
      console.error('[Favorite] reorder:', e.message)
      res.serverError(e)
    }
  })

  // 设置分组公开/私密
  app.put('/api/community/favorite/groups/:id/visibility', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [gid, userId])
      if (g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      const { is_public } = req.body || {}
      if (is_public !== 0 && is_public !== 1) return res.json({ code: 400, msg: '参数错误' })
      // 从公开切私密时检查是否有人关注
      if (!is_public) {
        const fcs = await query('SELECT COUNT(*) as cnt FROM favorite_group_follows WHERE group_id=?', [gid])
        if (fcs[0].cnt > 0) return res.json({ code: 400, msg: '已有用户关注，无法设为私密' })
      }
      await query('UPDATE collection_favorite_groups SET is_public=? WHERE id=?', [is_public, gid])
      res.json({ code: 200, msg: '设置成功' })
    } catch (e) {
      console.error('[Favorite] visibility:', e.message)
      res.serverError(e)
    }
  })

  // 关注公开分组
  app.post('/api/community/favorite/groups/:id/follow', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const g = await query('SELECT id, is_public FROM collection_favorite_groups WHERE id=?', [gid])
      if (g.length === 0) return res.json({ code: 404, msg: '分组不存在' })
      if (!g[0].is_public) return res.json({ code: 400, msg: '该分组未公开' })
      const existed = await query('SELECT id FROM favorite_group_follows WHERE group_id=? AND follower_id=?', [gid, userId])
      if (existed.length > 0) return res.json({ code: 200, msg: '已关注' })
      await query('INSERT INTO favorite_group_follows (group_id, follower_id) VALUES (?,?)', [gid, userId])
      res.json({ code: 200, msg: '关注成功' })
    } catch (e) {
      console.error('[Favorite] follow:', e.message)
      res.serverError(e)
    }
  })

  // 取消关注
  app.delete('/api/community/favorite/groups/:id/follow', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const gid = safeInt(req.params.id, 0)
      if (gid <= 0) return res.json({ code: 400, msg: '参数错误' })
      await query('DELETE FROM favorite_group_follows WHERE group_id=? AND follower_id=?', [gid, userId])
      res.json({ code: 200, msg: '已取消关注' })
    } catch (e) {
      console.error('[Favorite] unfollow:', e.message)
      res.serverError(e)
    }
  })

  // 获取已关注的公开分组
  app.get('/api/community/favorite/groups/following', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const rows = await query(
        `SELECT g.id, g.user_id, g.name, g.is_public, g.create_time,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM favorite_group_follows f
         INNER JOIN collection_favorite_groups g ON f.group_id=g.id
         WHERE f.follower_id=? ORDER BY f.create_time DESC`,
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      console.error('[Favorite] following:', e.message)
      res.serverError(e)
    }
  })

  // 查看某用户公开的分组列表
  app.get('/api/community/favorite/groups/user/:uid', async (req, res) => {
    try {
      const uid = safeInt(req.params.uid, 0)
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM collection_favorites WHERE group_id=g.id AND user_id=g.user_id) +
          (SELECT COUNT(*) FROM post_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM collection_favorite_groups g WHERE g.user_id=? AND g.is_public=1 ORDER BY g.sort_order ASC, g.id ASC`,
        [uid]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      console.error('[Favorite] user groups:', e.message)
      res.serverError(e)
    }
  })

  // 获取收藏列表(支持按分组筛选)
  app.get('/api/community/favorite/collections', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      let where = 'cf.user_id=?'
      const params = [userId]
      if (groupId > 0) {
        where += ' AND cf.group_id=?'
        params.push(groupId)
      }

      const [rows, total] = await Promise.all([
        query(
          `SELECT cf.id as fav_id, cf.group_id, c.* FROM collection_favorites cf
           INNER JOIN community_collections c ON cf.collection_id=c.id AND c.is_deleted=0
           WHERE ${where} ORDER BY cf.create_time DESC LIMIT ? OFFSET ?`,
          [...params, pageSize, offset]
        ),
        query(
          `SELECT COUNT(*) as cnt FROM collection_favorites cf
           INNER JOIN community_collections c ON cf.collection_id=c.id AND c.is_deleted=0
           WHERE ${where}`,
          params
        )
      ])

      res.json({ code: 200, data: { list: rows, total: total[0].cnt, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] list:', e.message)
      res.serverError(e)
    }
  })

  // 移动合集到其他分组
  app.post('/api/community/favorite/move', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const { collectionIds, targetGroupId } = req.body || {}
      if (!collectionIds || !Array.isArray(collectionIds) || !targetGroupId) {
        return res.json({ code: 400, msg: '参数错误' })
      }
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [targetGroupId, userId])
      if (!g.length) return res.json({ code: 404, msg: '分组不存在' })
      for (const cid of collectionIds) {
        await query('UPDATE collection_favorites SET group_id=? WHERE user_id=? AND collection_id=?', [targetGroupId, userId, cid])
      }
      res.json({ code: 200, msg: '移动成功' })
    } catch (e) {
      console.error('[Favorite] move:', e.message)
      res.serverError(e)
    }
  })

  // 收藏合集（需要传 groupId）
  app.post('/api/community/collection/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      await ensureDefaultGroup(userId)
      const groupId = safeInt(req.body?.groupId, 0)
      if (groupId <= 0) return res.json({ code: 400, msg: '请选择收藏分组' })
      const g = await query('SELECT id FROM collection_favorite_groups WHERE id=? AND user_id=?', [groupId, userId])
      if (!g.length) return res.json({ code: 400, msg: '分组不存在' })

      await query(
        'INSERT INTO collection_favorites (user_id, collection_id, group_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE group_id=VALUES(group_id)',
        [userId, cid, groupId]
      )
      res.json({ code: 200, msg: '收藏成功' })
    } catch (e) {
      console.error('[Collection] favorite:', e.message)
      res.serverError(e)
    }
  })

  // 取消收藏
  app.delete('/api/community/collection/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      await query('DELETE FROM collection_favorites WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, msg: '已取消收藏' })
    } catch (e) {
      console.error('[Collection] unfavorite:', e.message)
      res.serverError(e)
    }
  })

  // 检查收藏状态（返回分组信息）
  app.get('/api/community/collection/:id/favorite/check', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const rows = await query(
        'SELECT cf.id, cf.group_id, g.name as group_name FROM collection_favorites cf LEFT JOIN collection_favorite_groups g ON cf.group_id=g.id WHERE cf.user_id=? AND cf.collection_id=?',
        [userId, cid]
      )
      res.json({ code: 200, data: { favorited: rows.length > 0, groupId: rows[0]?.group_id || 0, groupName: rows[0]?.group_name || '' } })
    } catch (e) {
      console.error('[Collection] fav-check:', e.message)
      res.serverError(e)
    }
  })

  // ========== 帖子收藏 API ==========

  // 取消收藏帖子
  app.delete('/api/community/post/:id/favorite', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const pid = safeInt(req.params.id, 0)
      await query('DELETE FROM post_favorites WHERE user_id=? AND post_id=?', [userId, pid])
      res.json({ code: 200, msg: '已取消收藏' })
    } catch (e) {
      console.error('[PostFavorite] remove:', e.message)
      res.serverError(e)
    }
  })

  // 检查帖子收藏状态
  app.get('/api/community/post/:id/favorite/check', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const pid = safeInt(req.params.id, 0)
      const rows = await query(
        'SELECT pf.id, pf.group_id, g.name as group_name FROM post_favorites pf LEFT JOIN collection_favorite_groups g ON pf.group_id=g.id WHERE pf.user_id=? AND pf.post_id=?',
        [userId, pid]
      )
      res.json({ code: 200, data: { favorited: rows.length > 0, groupId: rows[0]?.group_id || 0, groupName: rows[0]?.group_name || '' } })
    } catch (e) {
      console.error('[PostFavorite] check:', e.message)
      res.serverError(e)
    }
  })

  // 统一收藏列表（帖子和合集）
  app.get('/api/community/favorite/items', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 50)
      const offset = (page - 1) * pageSize

      const gWhere = groupId > 0 ? ' AND f.group_id=' + groupId : ''

      const [cols, posts] = await Promise.all([
        query(
          `SELECT 'collection' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              c.id, c.title, c.cover_image, c.description, c.post_count, c.view_count,
              c.user_id, c.user_name, c.user_avatar, c.subscribe_count, COALESCE(c.section_id,0) as section_id,
              (SELECT name FROM community_sections WHERE id=c.section_id AND is_deleted=0 LIMIT 1) as section_name
            FROM collection_favorites f
            INNER JOIN community_collections c ON f.collection_id=c.id AND c.is_deleted=0
            WHERE f.user_id=? ${gWhere}`,
          [userId]
        ),
        query(
          `SELECT 'post' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              p.id, p.title, p.content, p.images, 0 as post_count, p.view_count,
              p.user_id, p.user_name, p.user_avatar, p.like_count, p.comment_count, p.section_id,
              (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0 LIMIT 1) as section_name,
              LEFT(p.content, 200) as description,
              p.content_permission as contentPermission, p.content_price as contentPrice,
              p.content_price_type as contentPriceType,
              (SELECT COUNT(*) FROM content_purchases WHERE content_type='post' AND content_id=p.id) as soldCount,
              (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
               OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
               OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
            FROM post_favorites f
            INNER JOIN community_posts p ON f.post_id=p.id AND p.status NOT IN ('deleted')
            WHERE f.user_id=? ${gWhere}`,
          [userId]
        )
      ])

      const all = [...(Array.isArray(cols) ? cols : []), ...(Array.isArray(posts) ? posts : [])]
      all.sort((a, b) => new Date(b.fav_time).getTime() - new Date(a.fav_time).getTime())

      // 批量查询当前用户已购买的帖子
      const postIds = all.filter(x => x.item_type === 'post').map(x => x.id)
      const purchasedSet = new Set()
      if (postIds.length > 0) {
        try {
          const purchases = await query(
            `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${postIds.map(() => '?').join(',')})`,
            [userId, ...postIds]
          )
          purchases.forEach(p => purchasedSet.add(p.content_id))
        } catch (e) { console.error('[collection] batch purchase check failed:', e.message) }
      }
      for (const item of all) {
        if (item.item_type === 'post') {
          item.isAuthor = item.user_id === userId
          item.hasPurchased = purchasedSet.has(item.id) || item.isAuthor
          if (item.hasPurchased) item.has_restricted = false
        }
      }

      // 查询评论记录
      if (postIds.length > 0) {
        const commentedSet = new Set()
        try {
          const comments = await query(
            `SELECT DISTINCT post_id FROM community_comments WHERE post_id IN (${postIds.map(() => '?').join(',')}) AND user_id = ? AND is_deleted=0`,
            [...postIds, userId]
          )
          comments.forEach(c => commentedSet.add(c.post_id))
        } catch (e) { console.error('[collection] batch comment check failed:', e.message) }
        const [viewerRow] = await query(`SELECT level_id as viewerLevelId FROM users WHERE id = ?`, [userId])
        const titleRows = await query(`SELECT title_id FROM user_titles WHERE user_id = ? AND is_active = 1`, [userId])
        const viewerTitleIds = titleRows.map(r => r.title_id)
        for (const item of all) {
          if (item.item_type === 'post') {
            item.hasCommented = commentedSet.has(item.id)
            item.viewerLevelId = (viewerRow && viewerRow.viewerLevelId) || 0
            item.viewerTitleIds = viewerTitleIds
          }
        }
      }

      const list = all.slice(offset, offset + pageSize)

      res.json({ code: 200, data: { list, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] items:', e.message)
      res.serverError(e)
    }
  })

  // 查看某用户公开分组的收藏项目
  app.get('/api/community/favorite/items/user/:uid', async (req, res) => {
    try {
      const uid = safeInt(req.params.uid, 0)
      if (uid <= 0) return res.json({ code: 400, msg: '参数错误' })
      const groupId = safeInt(req.query.groupId, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 50)
      const offset = (page - 1) * pageSize

      const gWhere = groupId > 0 ? ' AND f.group_id=' + groupId : ''

      const [cols, posts] = await Promise.all([
        query(
          `SELECT 'collection' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              c.id, c.title, c.cover_image, c.description, c.post_count, c.view_count,
              c.user_id, c.user_name, c.user_avatar, c.subscribe_count, COALESCE(c.section_id,0) as section_id,
              (SELECT name FROM community_sections WHERE id=c.section_id AND is_deleted=0 LIMIT 1) as section_name
            FROM collection_favorites f
            INNER JOIN collection_favorite_groups g ON f.group_id=g.id AND g.is_public=1
            INNER JOIN community_collections c ON f.collection_id=c.id AND c.is_deleted=0
            WHERE f.user_id=? ${gWhere}`,
          [uid]
        ),
        query(
          `SELECT 'post' as item_type, f.id as fav_id, f.group_id, f.create_time as fav_time,
              p.id, p.title, p.content, p.images, 0 as post_count, p.view_count,
              p.user_id, p.user_name, p.user_avatar, p.like_count, p.comment_count, p.section_id,
              (SELECT name FROM community_sections WHERE id=p.section_id AND is_deleted=0 LIMIT 1) as section_name,
              p.content_permission as contentPermission, p.content_price as contentPrice,
              p.content_price_type as contentPriceType,
              (p.has_resource=1 OR p.content LIKE '%"type":\\"paywall\\"%' OR p.content LIKE '%"type":\\"passwordUnlock\\"%'
               OR p.content LIKE '%"type":\\"memberUnlock\\"%' OR p.content LIKE '%"type":\\"experienceUnlock\\"%'
               OR p.content LIKE '%"type":\\"followUnlock\\"%') as has_restricted
            FROM post_favorites f
            INNER JOIN collection_favorite_groups g ON f.group_id=g.id AND g.is_public=1
            INNER JOIN community_posts p ON f.post_id=p.id AND p.status NOT IN ('deleted')
            WHERE f.user_id=? ${gWhere}`,
          [uid]
        )
      ])

      const all = [...(Array.isArray(cols) ? cols : []), ...(Array.isArray(posts) ? posts : [])]
      all.sort((a, b) => new Date(b.fav_time).getTime() - new Date(a.fav_time).getTime())

      const list = all.slice(offset, offset + pageSize)
      res.json({ code: 200, data: { list, page, pageSize } })
    } catch (e) {
      console.error('[Favorite] public items:', e.message)
      res.serverError(e)
    }
  })

  // ========== 29. 阅读进度 ==========

  app.post('/api/community/collection/:id/progress', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { postId } = req.body || {}
      const pid = safeInt(postId, 0)

      const collection = await query('SELECT id, post_count FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const totalPosts = collection[0].post_count || 1
      const ccp = await query('SELECT sort_order FROM community_collection_posts WHERE collection_id=? AND post_id=?', [cid, pid])
      const sortOrder = ccp.length > 0 ? ccp[0].sort_order : 1
      const progressPct = totalPosts > 0 ? ((sortOrder / totalPosts) * 100).toFixed(2) : 0

      await query(
        'INSERT INTO collection_read_progress (user_id, collection_id, last_post_id, progress_pct) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE last_post_id=VALUES(last_post_id), progress_pct=VALUES(progress_pct), update_time=NOW()',
        [userId, cid, pid, Number(progressPct)]
      )
      res.json({ code: 200, msg: '进度已更新', data: { progressPct: Number(progressPct), lastPostId: pid } })
    } catch (e) {
      console.error('[Collection] progress:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/progress', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const row = await query('SELECT * FROM collection_read_progress WHERE user_id=? AND collection_id=?', [userId, cid])
      res.json({ code: 200, data: row.length > 0 ? row[0] : null })
    } catch (e) {
      console.error('[Collection] get progress:', e.message)
      res.serverError(e)
    }
  })

  // ========== 30. 合集评论/评分 ==========

  app.post('/api/community/collection/:id/comment', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { content } = req.body || {}
      if (!content || !content.trim()) return res.json({ code: 400, msg: '评论内容不能为空' })

      const collection = await query('SELECT id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const user = await query('SELECT username, avatar FROM users WHERE id=?', [userId])
      const userName = user[0]?.username || ''
      const userAvatar = user[0]?.avatar || ''

      await query(
        'INSERT INTO community_comments (post_id, user_id, user_name, user_avatar, content) VALUES (?,?,?,?,?)',
        [cid, userId, userName, userAvatar, content.trim()]
      )
      res.json({ code: 200, msg: '评论成功' })
    } catch (e) {
      console.error('[Collection] comment:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/comments', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const page = safeInt(req.query.page, 1)
      const pageSize = safeInt(req.query.pageSize, 20)
      const offset = (page - 1) * pageSize

      const [list, total] = await Promise.all([
        query(
          `SELECT id, user_id as userId, user_name as userName, user_avatar as userAvatar,
                  content, create_time as createTime
           FROM community_comments WHERE post_id=? AND is_deleted=0
           ORDER BY id DESC LIMIT ? OFFSET ?`,
          [cid, pageSize, offset]
        ),
        query(
          'SELECT COUNT(*) as cnt FROM community_comments WHERE post_id=? AND is_deleted=0',
          [cid]
        )
      ])
      res.json({ code: 200, data: { list, total: total[0]?.cnt || 0, page, pageSize } })
    } catch (e) {
      console.error('[Collection] comments:', e.message)
      res.serverError(e)
    }
  })

  app.post('/api/community/collection/:id/rate', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const { rating } = req.body || {}
      const r = safeInt(rating, 0)
      if (r < 1 || r > 5) return res.json({ code: 400, msg: '评分范围为1-5' })

      const collection = await query('SELECT id FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })

      const existing = await query(
        'SELECT id FROM community_ratings WHERE user_id=? AND target_type=? AND target_id=?',
        [userId, 'collection', cid]
      )
      if (existing.length) {
        await query('UPDATE community_ratings SET rating=? WHERE id=?', [r, existing[0].id])
      } else {
        await query(
          'INSERT INTO community_ratings (user_id, target_type, target_id, rating) VALUES (?,?,?,?)',
          [userId, 'collection', cid, r]
        )
      }
      res.json({ code: 200, msg: '评分成功' })
    } catch (e) {
      console.error('[Collection] rate:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/rating', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const rows = await query(
        "SELECT COUNT(*) as count, COALESCE(AVG(rating), 0) as avg FROM community_ratings WHERE target_type=? AND target_id=?",
        ['collection', cid]
      )
      res.json({
        code: 200,
        data: { avgRating: Number(Number(rows[0]?.avg || 0).toFixed(1)), count: rows[0]?.count || 0 }
      })
    } catch (e) {
      console.error('[Collection] get rating:', e.message)
      res.serverError(e)
    }
  })

  // ========== 31. 批量排序 ==========

  app.put('/api/community/collection/:id/posts/batch-sort', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const cid = safeInt(req.params.id, 0)
      const collection = await query('SELECT * FROM community_collections WHERE id=? AND is_deleted=0', [cid])
      if (!collection.length) return res.json({ code: 404, msg: '合集不存在' })
      if (collection[0].user_id !== userId) return res.json({ code: 403, msg: '仅作者可编辑' })

      const { items } = req.body || {}
      if (!items || !Array.isArray(items)) return res.json({ code: 400, msg: '请提供排序数据' })

      for (const item of items) {
        await query(
          'UPDATE community_collection_posts SET sort_order=? WHERE collection_id=? AND post_id=?',
          [safeInt(item.sortOrder, 0), cid, safeInt(item.postId, 0)]
        )
      }
      await query('UPDATE community_collections SET update_time=' + nowExpr + ' WHERE id=?', [cid])
      res.json({ code: 200, msg: '排序更新成功' })
    } catch (e) {
      console.error('[Collection] batch-sort:', e.message)
      res.serverError(e)
    }
  })

  // ========== 32. 分享追踪 ==========

  app.post('/api/community/collection/:id/share', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const userId = await getUserId(req)
      await query('UPDATE community_collections SET share_count = COALESCE(share_count,0) + 1 WHERE id=?', [cid])
      res.json({ code: 200, msg: '分享成功' })
    } catch (e) {
      console.error('[Collection] share:', e.message)
      res.serverError(e)
    }
  })

  app.get('/api/community/collection/:id/share-stats', async (req, res) => {
    try {
      const cid = safeInt(req.params.id, 0)
      const row = await query('SELECT COALESCE(share_count, 0) as share_count FROM community_collections WHERE id=?', [cid])
      res.json({ code: 200, data: { shareCount: row.length > 0 ? row[0].share_count : 0 } })
    } catch (e) {
      console.error('[Collection] share-stats:', e.message)
      res.serverError(e)
    }
  })

  // 更新分组列表（计数含帖子和合集）
  app.get('/api/community/favorite/groups', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      await ensureDefaultGroup(userId)
      const groups = await query(
        `SELECT g.*,
          (SELECT COUNT(*) FROM collection_favorites WHERE group_id=g.id AND user_id=g.user_id) +
          (SELECT COUNT(*) FROM post_favorites WHERE group_id=g.id AND user_id=g.user_id) as count,
          (SELECT COUNT(*) FROM favorite_group_follows WHERE group_id=g.id) as follower_count
         FROM collection_favorite_groups g WHERE g.user_id=? ORDER BY g.sort_order ASC, g.id ASC`,
        [userId]
      )
      res.json({ code: 200, data: groups })
    } catch (e) {
      console.error('[Favorite] groups:', e.message)
      res.serverError(e)
    }
  })
}
