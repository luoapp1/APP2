const { query } = require('../database.cjs')
const { addBalance, addPoints } = require('./account-utils.cjs')
const { authRequired, sessions, SESSION_TTL } = require('./system.cjs')
const { hasPermission } = require('../middleware/level-permissions.cjs')
const fs = require('fs')
const path = require('path')
const { execSync } = require('child_process')

const EXPORT_DIR = path.join(__dirname, '..', 'data-exports')

function gdprRoutes(app) {
  app.post('/api/user/export-data', authRequired, async (req, res) => {
    try {
      const userId = req.userId

      // H3: 数据导出权限
      const canExport = await hasPermission(userId, 'function', 'H3')
      if (!canExport) return res.json({ code: 403, msg: '当前等级无数据导出权限' })

      const pending = await query("SELECT id FROM user_data_exports WHERE user_id=? AND status='pending'", [userId])
      if (pending.length > 0) {
        return res.json({ code: 400, msg: '已有进行中的导出请求，请等待完成后重试', data: { id: pending[0].id } })
      }

      const result = await query('INSERT INTO user_data_exports (user_id, status) VALUES (?,?)', [userId, 'pending'])
      const exportId = result.insertId

      process.nextTick(() => performExport(exportId, userId))

      res.json({ code: 200, msg: '数据导出已提交，请稍后查看', data: { id: exportId } })
    } catch (e) {
      console.error('[gdpr export-data POST]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })

  app.get('/api/user/export-data', authRequired, async (req, res) => {
    try {
      const userId = req.userId
      const rows = await query(
        'SELECT id, status, file_size, requested_at, completed_at, expires_at FROM user_data_exports WHERE user_id=? ORDER BY requested_at DESC LIMIT 10',
        [userId]
      )
      res.json({ code: 200, data: rows })
    } catch (e) {
      console.error('[gdpr export-data GET]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })

  app.get('/api/user/export-data/:id', authRequired, async (req, res) => {
    try {
      const rows = await query('SELECT * FROM user_data_exports WHERE id=? AND user_id=?', [req.params.id, req.userId])
      if (!rows.length) return res.json({ code: 404, msg: '未找到' })
      const exp = rows[0]
      if (exp.status === 'pending' || exp.status === 'processing') {
        return res.json({ code: 200, data: { status: exp.status } })
      }
      if (exp.status === 'failed') {
        return res.json({ code: 500, msg: '导出失败' })
      }
      if (!exp.file_path || !fs.existsSync(exp.file_path)) {
        return res.json({ code: 404, msg: '文件已过期或不存在' })
      }
      if (exp.expires_at && new Date(exp.expires_at) < new Date()) {
        return res.json({ code: 410, msg: '文件已过期' })
      }
      res.download(exp.file_path, `data-export-${req.userId}.zip`)
    } catch (e) {
      console.error('[gdpr export-data download]', e.message)
      res.json({ code: 500, msg: '服务器内部错误' })
    }
  })
}

async function performExport(exportId, userId) {
  try {
    await query("UPDATE user_data_exports SET status='processing' WHERE id=?", [exportId])

    const user = await query(
      'SELECT id, username, email, phone, nickname, avatar, bio, gender, birthday, register_address, level_id, level_name, status, create_time FROM users WHERE id=?',
      [userId]
    )

    const [posts, comments, orders, messages, follows, likes, checkins, pointsRecords, balanceRecords, mallOrders, appPurchases] = await Promise.all([
      query('SELECT id, section_id, title, content, images, tags, status, create_time FROM community_posts WHERE user_id=?', [userId]),
      query('SELECT id, post_id, content, create_time FROM community_comments WHERE user_id=?', [userId]),
      query('SELECT id, app_id, amount, payment_method, status, create_time FROM orders WHERE buyer_id=?', [userId]),
      query('SELECT id, from_user_id, to_user_id, content, is_read, create_time FROM private_messages WHERE from_user_id=? OR to_user_id=? ORDER BY create_time', [userId, userId]),
      query('SELECT follower_id, following_id, create_time FROM user_follows WHERE follower_id=? OR following_id=?', [userId, userId]),
      query('SELECT id, post_id, create_time FROM community_likes WHERE user_id=?', [userId]),
      query('SELECT id, checkin_date, points_earned, consecutive_days FROM checkin_records WHERE user_id=?', [userId]),
      query('SELECT id, tx_type as type, amount as points, balance_after as balance, source_type as source, description, create_time FROM currency_transactions WHERE user_id=? AND currency_key=\'points\'', [userId]),
      query('SELECT id, tx_type as type, amount, balance_after as balance, source_type as source, description, create_time FROM currency_transactions WHERE user_id=? AND currency_key=\'balance\'', [userId]),
      query('SELECT id, product_id, product_name, amount, status, create_time FROM mall_orders WHERE user_id=?', [userId]),
      query('SELECT id, app_id, amount, status, create_time FROM app_purchases WHERE user_id=?', [userId])
    ])

    const data = {
      exportedAt: new Date().toISOString(),
      userId,
      profile: user[0] || null,
      posts: { count: posts.length, items: posts },
      comments: { count: comments.length, items: comments },
      orders: { count: orders.length, items: orders },
      mallOrders: { count: mallOrders.length, items: mallOrders },
      appPurchases: { count: appPurchases.length, items: appPurchases },
      messages: { count: messages.length, items: messages },
      follows: { count: follows.length, items: follows },
      likes: { count: likes.length, items: likes },
      checkins: { count: checkins.length, items: checkins },
      pointsRecords: { count: pointsRecords.length, items: pointsRecords },
      balanceRecords: { count: balanceRecords.length, items: balanceRecords }
    }

    if (!fs.existsSync(EXPORT_DIR)) fs.mkdirSync(EXPORT_DIR, { recursive: true })
    const jsonPath = path.join(EXPORT_DIR, `export-${exportId}.json`)
    fs.writeFileSync(jsonPath, JSON.stringify(data, null, 2), 'utf8')
    const zipPath = path.join(EXPORT_DIR, `export-${exportId}.zip`)
    execSync(`zip -j "${zipPath}" "${jsonPath}"`, { stdio: 'ignore' })
    fs.unlinkSync(jsonPath)

    const stat = fs.statSync(zipPath)
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    await query('UPDATE user_data_exports SET status=?, file_path=?, file_size=?, completed_at=?, expires_at=? WHERE id=?',
      ['completed', zipPath, stat.size, new Date(), expiresAt, exportId])
  } catch (e) {
    console.error('[GDPR] export failed:', exportId, e.message)
    await query("UPDATE user_data_exports SET status='failed' WHERE id=?", [exportId])
  }
}

module.exports = gdprRoutes
