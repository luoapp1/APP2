const { query } = require('../database.cjs')
const { hasPermission } = require('../middleware/level-permissions.cjs')
const systemRoutes = require('./system.cjs')
const { authRequired } = systemRoutes

function adminRequired(req, res, next) {
  const roles = req.user?.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

module.exports = function (app) {
  const router = require('express').Router()
  const sessions = systemRoutes.sessions
  const SESSION_TTL = 7 * 24 * 60 * 60 * 1000

  function formatDateTime(date) {
    const d = new Date(date)
    const pad = (n) => String(n).padStart(2, '0')
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
  }

  async function getUserId(req) {
    const raw = req.headers.authorization || req.headers.token || req.query.token || ''
    const token = raw.replace(/^Bearer\s+/i, '')
    if (!token) return 0
    const session = sessions.get(token)
    if (session) {
      if (Date.now() - session.createdAt > SESSION_TTL) {
        sessions.delete(token)
        return 0
      }
      return Number(session.userId) || 0
    }
    try {
      const rows = await query('SELECT * FROM sessions WHERE token=?', [token])
      if (rows.length) {
        const s = rows[0]
        const createdAt = s.created_at ? new Date(s.created_at).getTime() : Date.now()
        if (Date.now() - createdAt > SESSION_TTL) {
          await query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {})
          return 0
        }
        sessions.set(token, { userId: s.user_id, userName: s.user_name, roles: [], createdAt })
        return Number(s.user_id) || 0
      }
    } catch { return 0 }
    return 0
  }

  async function isAdminById(userId) {
    if (!userId) return false
    try {
      const rows = await query('SELECT roles FROM users WHERE id=?', [userId])
      if (rows && rows.length > 0) {
        try {
          const roles = typeof rows[0].roles === 'string' ? JSON.parse(rows[0].roles) : (rows[0].roles || [])
          return roles.some(r => r === 'R_SUPER' || r === 'R_ADMIN')
        } catch { return false }
      }
    } catch { return false }
    return false
  }

  router.get('/api/community/topics', async (req, res) => {
    try {
      const { page = 1, pageSize = 50, status } = req.query
      const pageSizeNum = Math.min(parseInt(pageSize) || 50, 200)
      const offset = (parseInt(page) - 1) * pageSizeNum

      let whereClause = '1=1'
      const baseParams = []
      if (status !== undefined && status !== '') {
        whereClause += ' AND t.status=?'
        baseParams.push(status)
      } else {
        whereClause += " AND t.status='1'"
      }

      const countSql = `SELECT COUNT(*) as total FROM community_topics t WHERE ${whereClause}`
      const total = (await query(countSql, baseParams))[0]?.total || 0

      const listSql = `
        SELECT t.*,
          COALESCE(pc.cnt, 0) as post_count,
          COALESCE(pc.view_sum, 0) as view_count,
          COALESCE(fc.cnt, 0) as follower_count
        FROM community_topics t
        LEFT JOIN (
          SELECT topic_id, COUNT(*) as cnt, COALESCE(SUM(view_count), 0) as view_sum
          FROM community_posts WHERE status='published' GROUP BY topic_id
        ) pc ON t.id = pc.topic_id
        LEFT JOIN (
          SELECT topic_id, COUNT(*) as cnt FROM topic_follows GROUP BY topic_id
        ) fc ON t.id = fc.topic_id
        WHERE ${whereClause}
        ORDER BY t.sort_order ASC, t.id DESC
        LIMIT ? OFFSET ?
      `
      const listParams = [...baseParams, pageSizeNum, offset]
      const list = await query(listSql, listParams)

      for (const topic of list) {
        topic.heat = (topic.post_count || 0) * 100 + (topic.view_count || 0)
      }

      res.json({ code: 200, data: { list, total } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/community/topics/config', async (req, res) => {
    try {
      const rows = await query("SELECT config_key, config_value FROM sys_config WHERE config_key IN ('topic_create_min_exp_level','topic_create_allowed_levels')")
      const config = { minExpLevel: 0, allowedLevels: [] }
      for (const r of rows) {
        if (r.config_key === 'topic_create_min_exp_level') config.minExpLevel = Number(r.config_value) || 0
        if (r.config_key === 'topic_create_allowed_levels') config.allowedLevels = r.config_value ? r.config_value.split(',').map(Number).filter(Boolean) : []
      }
      res.json({ code: 200, data: config })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/community/topics/config', adminRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdmin = await isAdminById(userId)
      if (!isAdmin) return res.json({ code: 403, msg: '仅管理员可配置话题权限' })
      const { minExpLevel, allowedLevels } = req.body
      if (minExpLevel !== undefined) {
        const exist = await query("SELECT id FROM sys_config WHERE config_key='topic_create_min_exp_level'")
        if (exist.length) {
          await query("UPDATE sys_config SET config_value=? WHERE config_key='topic_create_min_exp_level'", [String(minExpLevel)])
        } else {
          await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('topic_create_min_exp_level',?,?)", [String(minExpLevel), '话题创建最低经验等级'])
        }
      }
      if (allowedLevels !== undefined) {
        const val = Array.isArray(allowedLevels) ? allowedLevels.join(',') : String(allowedLevels || '')
        const exist = await query("SELECT id FROM sys_config WHERE config_key='topic_create_allowed_levels'")
        if (exist.length) {
          await query("UPDATE sys_config SET config_value=? WHERE config_key='topic_create_allowed_levels'", [val])
        } else {
          await query("INSERT INTO sys_config (config_key, config_value, description) VALUES ('topic_create_allowed_levels',?,?)", [val, '允许创建话题的会员等级ID列表'])
        }
      }
      res.json({ code: 200, msg: '配置更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/community/topics/:id', async (req, res) => {
    try {
      const rows = await query(`
        SELECT t.*,
          COALESCE(pc.cnt, 0) as post_count,
          COALESCE(pc.view_sum, 0) as view_count,
          COALESCE(fc.cnt, 0) as follower_count
        FROM community_topics t
        LEFT JOIN (
          SELECT topic_id, COUNT(*) as cnt, COALESCE(SUM(view_count), 0) as view_sum
          FROM community_posts WHERE status='published' GROUP BY topic_id
        ) pc ON t.id = pc.topic_id
        LEFT JOIN (
          SELECT topic_id, COUNT(*) as cnt FROM topic_follows GROUP BY topic_id
        ) fc ON t.id = fc.topic_id
        WHERE t.id=?
      `, [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '话题不存在' })
      const topic = rows[0]
      topic.heat = (topic.post_count || 0) * 100 + (topic.view_count || 0)

      res.json({ code: 200, data: topic })
    } catch (e) {
      res.serverError(e)
    }
  })

  // POST /api/community/topics/:id/follow - 关注话题
  router.post('/api/community/topics/:id/follow', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const topicId = Number(req.params.id)
      const exist = await query('SELECT id FROM topic_follows WHERE topic_id=? AND user_id=?', [topicId, userId])
      if (exist.length) return res.json({ code: 200, msg: '已关注', data: { following: true } })
      await query('INSERT INTO topic_follows (topic_id, user_id, create_time) VALUES (?,?,?)', [topicId, userId, formatDateTime(new Date())])
      const cnt = await query('SELECT COUNT(*) as cnt FROM topic_follows WHERE topic_id=?', [topicId])
      res.json({ code: 200, msg: '关注成功', data: { following: true, follower_count: cnt[0]?.cnt || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // DELETE /api/community/topics/:id/follow - 取消关注话题
  router.delete('/api/community/topics/:id/follow', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const topicId = Number(req.params.id)
      await query('DELETE FROM topic_follows WHERE topic_id=? AND user_id=?', [topicId, userId])
      const cnt = await query('SELECT COUNT(*) as cnt FROM topic_follows WHERE topic_id=?', [topicId])
      res.json({ code: 200, msg: '已取消关注', data: { following: false, follower_count: cnt[0]?.cnt || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/community/topics/:id/follow - 查询关注状态
  router.get('/api/community/topics/:id/follow', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const topicId = Number(req.params.id)
      const exist = await query('SELECT id FROM topic_follows WHERE topic_id=? AND user_id=?', [topicId, userId || 0])
      const cnt = await query('SELECT COUNT(*) as cnt FROM topic_follows WHERE topic_id=?', [topicId])
      res.json({ code: 200, data: { following: userId ? exist.length > 0 : false, follower_count: cnt[0]?.cnt || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // GET /api/community/topics/:id/followers - 获取话题关注者列表
  router.get('/api/community/topics/:id/followers', async (req, res) => {
    try {
      const topicId = Number(req.params.id)
      const { page = 1, pageSize = 20 } = req.query
      const limit = Math.min(parseInt(pageSize), 50)
      const offset = (parseInt(page) - 1) * limit
      const followers = await query(
        `SELECT u.id as user_id, u.username, u.nickname, u.avatar, tf.create_time
         FROM topic_follows tf
         LEFT JOIN users u ON tf.user_id = u.id
         WHERE tf.topic_id=?
         ORDER BY tf.create_time DESC
         LIMIT ? OFFSET ?`,
        [topicId, limit, offset]
      )
      const total = followers.length > 0
        ? (await query('SELECT COUNT(*) as cnt FROM topic_follows WHERE topic_id=?', [topicId]))[0]?.cnt || 0
        : 0
      res.json({ code: 200, data: { list: followers, total, page: parseInt(page), pageSize: limit } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/community/topics', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      // D13: 创建话题权限
      const canCreateTopic = await hasPermission(userId, 'social', 'D13')
      if (!canCreateTopic) return res.json({ code: 403, msg: '当前等级不支持创建话题' })

      const isAdmin = await isAdminById(userId)
      if (!isAdmin) {
        const minLevelRow = await query("SELECT config_value FROM sys_config WHERE config_key='topic_create_min_exp_level'")
        const minLevel = Number(minLevelRow[0]?.config_value || 0)
        if (minLevel > 0) {
          const balRows = await query('SELECT available FROM user_currency_balance WHERE user_id=? AND currency_key=\'experience\'', [userId])
          const userRow = balRows.length > 0 ? [{ experience: Number(balRows[0].available || 0) }] : [{ experience: 0 }]
          const userExp = userRow[0]?.experience || 0
          const expRow = await query("SELECT level FROM experience_levels WHERE exp_required <= ? AND status='1' ORDER BY exp_required DESC LIMIT 1", [userExp])
          const userExpLevel = expRow[0]?.level || 0
          if (userExpLevel < minLevel) return res.json({ code: 403, msg: `需要经验等级 Lv.${minLevel} 以上才能创建话题` })
        }
        const allowedLevelsRow = await query("SELECT config_value FROM sys_config WHERE config_key='topic_create_allowed_levels'")
        if (allowedLevelsRow[0]?.config_value) {
          const allowedIds = allowedLevelsRow[0].config_value.split(',').map(Number).filter(Boolean)
          if (allowedIds.length > 0) {
            const userRow = await query('SELECT level_id, level_name FROM users WHERE id=?', [userId])
            const userLevelId = userRow[0]?.level_id || 0
            if (!allowedIds.includes(userLevelId)) {
              const names = await query('SELECT name FROM membership_levels WHERE id IN (' + allowedIds.join(',') + ')')
              const nameList = names.map((n) => n.name).join('、')
              return res.json({ code: 403, msg: `仅限 ${nameList} 会员创建话题` })
            }
          }
        }
      }

      const { name, icon, description } = req.body
      if (!name || !name.trim()) return res.json({ code: 400, msg: '话题名称不能为空' })

      const exist = await query('SELECT id FROM community_topics WHERE name=?', [name.trim()])
      if (exist.length) return res.json({ code: 400, msg: '话题名称已存在' })

      const user = await query('SELECT username FROM users WHERE id=?', [userId])
      await query(
        'INSERT INTO community_topics (name, icon, description, creator_id, creator_name, create_time) VALUES (?,?,?,?,?,?)',
        [name.trim(), icon || '', description || '', userId, user[0]?.username || '', formatDateTime(new Date())]
      )
      res.json({ code: 200, msg: '话题创建成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/community/topics/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdmin = await isAdminById(userId)
      const topic = await query('SELECT * FROM community_topics WHERE id=?', [req.params.id])
      if (!topic.length) return res.json({ code: 404, msg: '话题不存在' })
      if (!isAdmin && topic[0].creator_id !== userId) return res.json({ code: 403, msg: '无权限编辑此话题' })

      const { name, icon, description, status, sortOrder } = req.body
      const sets = []
      const params = []
      if (name !== undefined) { sets.push('name=?'); params.push(name.trim()) }
      if (icon !== undefined) { sets.push('icon=?'); params.push(icon) }
      if (description !== undefined) { sets.push('description=?'); params.push(description) }
      if (status !== undefined) { sets.push('status=?'); params.push(status) }
      if (sortOrder !== undefined) { sets.push('sort_order=?'); params.push(Number(sortOrder)) }
      if (!sets.length) return res.json({ code: 400, msg: '无更新内容' })
      params.push(req.params.id)
      await query(`UPDATE community_topics SET ${sets.join(',')} WHERE id=?`, params)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/community/topics/:id', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })
      const isAdmin = await isAdminById(userId)
      if (!isAdmin) return res.json({ code: 403, msg: '仅管理员可删除话题' })

      await query('DELETE FROM community_topics WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/community/topics/:id/posts', async (req, res) => {
    try {
      const topicId = Number(req.params.id)
      const { page = 1, pageSize = 20, sort = 'latest', userId } = req.query
      const topic = await query('SELECT * FROM community_topics WHERE id=?', [topicId])
      if (!topic.length) return res.json({ code: 404, msg: '话题不存在' })
      const topicName = topic[0].name

      let sql = `SELECT DISTINCT p.id, p.section_id as sectionId, p.user_id as userId, p.user_name as userName,
                  CASE WHEN u.avatar LIKE 'avatar:%' THEN '' ELSE COALESCE(NULLIF(u.avatar,''), p.user_avatar, '') END as userAvatar, p.title, p.content, p.tags,
                  p.images, p.is_pinned as isPinned, p.is_essence as isEssence, p.is_hot as isHot,
                  p.like_count as likeCount, p.comment_count as commentCount, p.view_count as viewCount,
                  p.create_time as createTime, p.update_time as updateTime,
                  p.content_permission as contentPermission, p.content_price as contentPrice,
                  p.content_price_type as contentPriceType,
                  u.level_name as userLevelName
                FROM community_posts p
                LEFT JOIN community_post_topics pt ON p.id = pt.post_id
                LEFT JOIN users u ON p.user_id = u.id
                WHERE p.status='published' AND (pt.topic_id = ? OR p.tags LIKE ? OR p.official_tags LIKE ? OR p.topic_id = ?)`

      const params = [topicId, `%${topicName}%`, `%${topicName}%`, topicId]

      let orderBy = 'p.is_pinned DESC, p.id DESC'
      if (sort === 'hot') orderBy = 'p.is_pinned DESC, p.is_hot DESC, p.like_count DESC'
      else if (sort === 'latest') orderBy = 'p.id DESC'

      const offset = (parseInt(page) - 1) * parseInt(pageSize)
      const countResult = await query(`SELECT COUNT(*) as total FROM (${sql}) t`, params)
      const total = countResult[0]?.total || 0
      const list = await query(sql + ` ORDER BY ${orderBy} LIMIT ${parseInt(pageSize)} OFFSET ${offset}`, params)

      for (const item of list) {
        try { item.tags = item.tags ? JSON.parse(item.tags) : [] } catch { item.tags = [] }
        try { item.images = item.images ? JSON.parse(item.images) : [] } catch { item.images = [] }
      }

      if (Number(userId) && list.length > 0) {
        try {
          const paidPosts = list.filter(p => p.contentPermission && p.contentPermission !== 'public')
          if (paidPosts.length > 0) {
            const paidIds = paidPosts.map(p => p.id)
            const paidSet = new Set()
            const purchases = await query(
              `SELECT content_id FROM content_purchases WHERE content_type='post' AND user_id=? AND content_id IN (${paidIds.map(() => '?').join(',')})`,
              [Number(userId), ...paidIds]
            )
            purchases.forEach(p => paidSet.add(p.content_id))
            for (const item of paidPosts) {
              if (item.userId === Number(userId)) continue
              if (paidSet.has(item.id)) continue
              item.content = '部分内容付费 - 需购买后查看'
              item.contentFiltered = true
              try { item.images = [] } catch {}
            }
          }
        } catch {}
      } else if (list.length > 0) {
        for (const item of list) {
          if (item.contentPermission && item.contentPermission !== 'public') {
            item.content = '部分内容付费 - 需购买后查看'
            item.contentFiltered = true
            try { item.images = [] } catch {}
          }
        }
      }

      res.json({ code: 200, data: { list, total, page: parseInt(page), pageSize: parseInt(pageSize) } })
    } catch (e) {
      res.serverError(e)
    }
  })

  app.use(router)
}
