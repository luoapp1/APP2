const { query, getPool, getDBProxy } = require('../database.cjs')
const nowExpr = 'NOW()'
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { sendNotificationEmail } = require('./email.cjs')

const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

const chatImageUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg'
      cb(null, 'chat_' + Date.now() + '_' + Math.round(Math.random() * 10000) + ext)
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowedExt = /\.(jpg|jpeg|png|gif|webp|bmp)$/i
    const allowedMime = /^image\/(jpeg|png|gif|webp|bmp)$/i
    const validExt = allowedExt.test(path.extname(file.originalname).toLowerCase())
    const validMime = allowedMime.test(file.mimetype)
    if (validExt && validMime) {
      cb(null, true)
    } else {
      cb(new Error('仅支持 jpg、jpeg、png、gif、webp、bmp 格式的图片'))
    }
  }
})

function notificationRoutes(router) {

  router.get('/api/notifications', async (req, res) => {
    try {
      const { userId = 0, page = 1, pageSize = 20, type } = req.query
      const uid = Number(userId)

      // 获取用户通知偏好，排除已关闭的通知类型
      let disabledTypes = []
      if (uid > 0) {
        try {
          const prefRows = await query(
            'SELECT notification_type FROM user_notification_settings WHERE user_id = ? AND enabled = 0',
            [uid]
          )
          disabledTypes = prefRows.map(r => r.notification_type)
        } catch { /* 表可能不存在,忽略 */ }
      }

      let whereClause = '(target_user_id = 0 OR target_user_id = ?)'
      const params = [uid]
      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      } else if (disabledTypes.length > 0) {
        whereClause += ' AND type NOT IN (' + disabledTypes.map(() => '?').join(',') + ')'
        params.push(...disabledTypes)
      }
      const list = await query(
        `SELECT n.id, n.title, n.content, n.type, n.target_url as targetUrl, n.is_read as isRead, n.create_time as createTime,
                n.from_user_id as fromUserId,
                n.from_user_name as _fromUserName,
                n.from_user_avatar as _fromUserAvatar
         FROM sys_notifications n
         WHERE ${whereClause}
         ORDER BY n.id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )

      if (list.length > 0) {
        const userIds = [...new Set(list.map(n => n.fromUserId).filter(id => id > 0))]
        const userNames = [...new Set(list.map(n => n.fromUserId === 0 ? n._fromUserName : null).filter(Boolean))]
        const [userByIdRows, userByNameRows, sysCfg] = await Promise.all([
          userIds.length > 0
            ? query(`SELECT u.id, u.username, u.avatar, u.roles, u.active_title_id FROM users u WHERE u.id IN (${userIds.map(() => '?').join(',')})`, userIds)
            : Promise.resolve([]),
          userNames.length > 0
            ? query(`SELECT u.username, u.avatar, u.roles, u.active_title_id FROM users u WHERE u.username IN (${userNames.map(() => '?').join(',')})`, userNames)
            : Promise.resolve([]),
          query("SELECT config_value FROM sys_config WHERE config_key='system_operator_id'")
        ])

        const userMap = {}
        for (const u of userByIdRows) userMap[u.id] = u
        const userNameMap = {}
        for (const u of userByNameRows) userNameMap[u.username] = u

        let sysUser = null
        if (sysCfg.length > 0) {
          const sysRows = await query('SELECT username, avatar, roles, active_title_id FROM users WHERE id = ?', [Number(sysCfg[0].config_value) || 0])
          if (sysRows.length > 0) sysUser = sysRows[0]
        }

        const titleIds = [...new Set([
          ...userByIdRows.map(u => u.active_title_id),
          ...userByNameRows.map(u => u.active_title_id),
          sysUser?.active_title_id
        ].filter(Boolean))]
        const titleRows = titleIds.length > 0
          ? await query(`SELECT id, name, color, bg_color FROM custom_titles WHERE id IN (${titleIds.map(() => '?').join(',')})`, titleIds)
          : []
        const titleMap = {}
        for (const t of titleRows) titleMap[t.id] = t

        function resolveUser(user) {
          if (!user) return {}
          const t = titleMap[user.active_title_id] || {}
          return { username: user.username, avatar: user.avatar, roles: user.roles, title: t.name || '', titleColor: t.color || '#409EFF', titleBg: t.bg_color || '#ecf5ff' }
        }
        const sysResolved = resolveUser(sysUser)

        for (const n of list) {
          if (n._fromUserName && n._fromUserName !== '' && n._fromUserName !== '管理员') {
            n.fromUserName = n._fromUserName
          } else {
            const byId = userMap[n.fromUserId]
            const byName = userNameMap[n._fromUserName]
            const resolved = byId || byName || sysResolved
            n.fromUserName = resolved.username || ''
            n.fromUserAvatar = n._fromUserAvatar || resolved.avatar || ''
            n.fromUserRoles = resolved.roles || '[]'
            n.fromUserTitle = resolved.title || ''
            n.fromUserTitleColor = resolved.titleColor || '#409EFF'
            n.fromUserTitleBg = resolved.titleBg || '#ecf5ff'
          }
          if (!n.fromUserAvatar && n._fromUserName && n._fromUserName !== '管理员') {
            n.fromUserAvatar = ''
          }
          delete n._fromUserName
          delete n._fromUserAvatar
        }
      }
      const cnt = await query(
        `SELECT COUNT(*) as total FROM sys_notifications
         WHERE ${whereClause}`,
        params
      )
      const unread = await query(
        `SELECT COUNT(*) as cnt FROM sys_notifications
         WHERE ${whereClause} AND is_read = 0`,
        params
      )
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0, unread: unread[0]?.cnt || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/notifications/read-all', async (req, res) => {
    try {
      const { userId, type } = req.body
      let whereClause = '(target_user_id = 0 OR target_user_id = ?) AND is_read = 0'
      const params = [Number(userId) || 0]
      if (type) {
        whereClause += ' AND type = ?'
        params.push(type)
      }
      await query(
        `UPDATE sys_notifications SET is_read = 1 WHERE ${whereClause}`,
        params
      )
      res.json({ code: 200, msg: '已全部标为已读' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/notifications/:id/read', async (req, res) => {
    try {
      const { id } = req.params
      await query('UPDATE sys_notifications SET is_read = 1 WHERE id = ?', [Number(id)])
      res.json({ code: 200, msg: 'ok' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 私信增强 ==========

  function buildUserInfoQuery(uField, nField) {
    return `
      CASE WHEN ${nField} NOT IN ('', '管理员') THEN ${nField}
           ELSE COALESCE(${uField}_u.username, ${uField}_u2.username, ${uField}_sys.username, '')
      END
    `
  }

  function buildAvatarQuery(uField, nField) {
    return `COALESCE(NULLIF(${nField}, ''), ${uField}_u.avatar, ${uField}_u2.avatar, ${uField}_sys.avatar)`
  }

  const messageSelect = `
    SELECT p.id, p.from_user_id as fromUserId,
           ` + buildUserInfoQuery('f', 'p.from_user_name') + ` as fromUserName,
           ` + buildAvatarQuery('f', 'p.from_user_avatar') + ` as fromUserAvatar,
           p.to_user_id as toUserId, p.content, p.image_url as imageUrl,
           p.is_read as isRead, p.is_recalled as isRecalled,
           p.report_status as reportStatus,
           p.message_type as messageType,
           p.order_card as orderCard,
           p.create_time as createTime
    FROM private_messages p
    LEFT JOIN users f_u ON f_u.id = p.from_user_id AND p.from_user_id > 0
    LEFT JOIN users f_u2 ON f_u2.username = p.from_user_name AND p.from_user_id = 0 AND p.from_user_name != ''
    LEFT JOIN sys_config cfg ON cfg.config_key = 'system_operator_id'
    LEFT JOIN users f_sys ON f_sys.id = CAST(cfg.config_value AS INTEGER)`

  router.get('/api/messages/conversations', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })

      const partners = await query(
        `SELECT DISTINCT
           CASE WHEN from_user_id = ? THEN to_user_id ELSE from_user_id END as partnerId
         FROM private_messages
         WHERE from_user_id = ? OR to_user_id = ?`,
        [uid, uid, uid]
      )

      if (!partners || partners.length === 0) {
        return res.json({ code: 200, msg: 'success', data: [] })
      }

      const hidden = await query(
        'SELECT partner_id FROM hidden_conversations WHERE user_id = ?',
        [uid]
      )
      const hiddenIds = new Set(hidden.map((r) => r.partner_id))

      const partnerIds = partners.map(p => p.partnerId).filter(id => id && !hiddenIds.has(id))
      if (!partnerIds.length) {
        return res.json({ code: 200, msg: 'success', data: [] })
      }

      const [userRows, lastMsgRows, unreadRows] = await Promise.all([
        query('SELECT id, username, avatar FROM users WHERE id IN (?)', [partnerIds]),
        query(
          `SELECT pm.content, pm.image_url, pm.is_recalled, pm.create_time, last_ids.partnerId
           FROM private_messages pm
           INNER JOIN (
             SELECT MAX(id) as max_id,
                    CASE WHEN from_user_id = ? THEN to_user_id ELSE from_user_id END as partnerId
             FROM private_messages
             WHERE from_user_id = ? OR to_user_id = ?
             GROUP BY partnerId
           ) last_ids ON pm.id = last_ids.max_id`,
          [uid, uid, uid]
        ),
        query(
          'SELECT from_user_id as partnerId, COUNT(*) as cnt FROM private_messages WHERE to_user_id = ? AND is_read = 0 GROUP BY from_user_id',
          [uid]
        )
      ])

      const userMap = {}
      for (const u of userRows) userMap[u.id] = u
      const lastMsgMap = {}
      for (const m of lastMsgRows) lastMsgMap[m.partnerId] = m
      const unreadMap = {}
      for (const r of unreadRows) unreadMap[r.partnerId] = r.cnt

      const result = []
      for (const pid of partnerIds) {
        const pUser = userMap[pid]
        const lastMsg = lastMsgMap[pid]
        let lastContent = lastMsg?.content || ''
        if (lastMsg?.is_recalled) {
          lastContent = '[消息已撤回]'
        } else if (lastMsg?.image_url) {
          lastContent = '[图片]'
        }
        result.push({
          userId: pid,
          userName: pUser?.username || '',
          userAvatar: pUser?.avatar || '',
          lastTime: lastMsg?.create_time || '',
          lastContent,
          unread: unreadMap[pid] || 0
        })
      }

      result.sort((a, b) => {
        if (!a.lastTime) return 1
        if (!b.lastTime) return -1
        return new Date(b.lastTime).getTime() - new Date(a.lastTime).getTime()
      })

      res.json({ code: 200, msg: 'success', data: result })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 获取用户订单列表（用于在聊天中分享）
  router.get('/api/messages/orders', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })

      const orders = await query(
        `SELECT id, order_no as orderNo, order_type as orderType, order_desc as orderDesc,
                total_amount as totalAmount, paid_amount as paidAmount, pay_type as payType,
                status, create_time as createTime
         FROM orders
         WHERE buyer_id = ? OR seller_id = ?
         ORDER BY id DESC LIMIT 20`,
        [uid, uid]
      )
      res.json({ code: 200, msg: 'success', data: orders })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.get('/api/messages/:targetUserId', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      const tid = Number(req.params.targetUserId)
      if (!uid || !tid) return res.json({ code: 400, msg: '参数错误' })

      await query(
        `UPDATE private_messages SET is_read = 1
         WHERE from_user_id = ? AND to_user_id = ? AND is_read = 0`,
        [tid, uid]
      )

      const messages = await query(
        messageSelect + `
         WHERE (p.from_user_id = ? AND p.to_user_id = ?)
            OR (p.from_user_id = ? AND p.to_user_id = ?)
         ORDER BY p.id ASC`,
        [uid, tid, tid, uid]
      )

      res.json({ code: 200, msg: 'success', data: messages })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 上传聊天图片
  router.post('/api/messages/upload-image', chatImageUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) return res.json({ code: 400, msg: '请选择图片' })
      const { resolveUploadPath, recordFileUpload, getUserId, checkStorageQuota, updateUserUsedBytes, buildFileDesc } = require('./upload.cjs')
      const url = await resolveUploadPath(req.file, req, false)
      let userId = 0
      try { const auth = await getUserId(req); userId = auth.userId || 0 } catch {}
      const quota = await checkStorageQuota(userId, req.file.size || 0, 'chat_image')
      if (!quota.ok) return res.json({ code: 400, msg: quota.msg })
      await recordFileUpload({
        userId,
        fileName: req.file.originalname,
        fileUrl: url,
        fileSize: req.file.size || 0,
        fileType: path.extname(req.file.originalname),
        mimeType: req.file.mimetype || '',
        category: 'chat_image',
        description: buildFileDesc({ category: 'chat_image', refType: 'chat' })
      })
      await updateUserUsedBytes(userId)
      res.json({ code: 200, msg: '上传成功', data: { url } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 发送消息（增强版：支持图片、敏感词过滤、黑名单拦截）
  router.post('/api/messages/:targetUserId', async (req, res) => {
    try {
      const { userId, userName, userAvatar, content, imageUrl, messageType, orderCard } = req.body
      const uid = Number(userId)
      const tid = Number(req.params.targetUserId)
      if (!uid || !tid) return res.json({ code: 400, msg: '参数不完整' })
      if (!content && !imageUrl) return res.json({ code: 400, msg: '消息内容不能为空' })
      if (content && content.length > 5000) return res.json({ code: 400, msg: '消息内容不能超过 5000 字符' })

      const ALLOWED_MSG_TYPES = ['text', 'image', 'order']
      const rawMsgType = messageType || 'text'
      if (!ALLOWED_MSG_TYPES.includes(rawMsgType)) return res.json({ code: 400, msg: '无效的消息类型' })

      if (imageUrl && typeof imageUrl === 'string' && !imageUrl.startsWith('http://') && !imageUrl.startsWith('https://') && !imageUrl.startsWith('data:image/')) {
        return res.json({ code: 400, msg: '无效的图片链接格式' })
      }

      // 黑名单拦截
      const blocked = await query(
        `SELECT id FROM user_blocks WHERE blocker_id = ? AND blocked_id = ? AND status = 'active'`,
        [tid, uid]
      )
      if (blocked && blocked.length > 0) {
        return res.json({ code: 403, msg: '对方已将你拉黑，无法发送消息' })
      }
      const blockedByMe = await query(
        `SELECT id FROM user_blocks WHERE blocker_id = ? AND blocked_id = ? AND status = 'active'`,
        [uid, tid]
      )
      if (blockedByMe && blockedByMe.length > 0) {
        return res.json({ code: 403, msg: '你已拉黑对方，无法发送消息' })
      }

      // 敏感词过滤
      let filteredContent = content || ''
      try {
        const sensitiveWords = await query(
          `SELECT word FROM sensitive_words WHERE enabled = 1`
        )
        if (sensitiveWords && sensitiveWords.length > 0) {
          for (const sw of sensitiveWords) {
            if (sw.word && filteredContent.includes(sw.word)) {
              filteredContent = filteredContent.replaceAll(sw.word, '*'.repeat(sw.word.length))
            }
          }
        }
      } catch (e) { /* 敏感词过滤失败不影响发送 */ }

      const avatar = userAvatar || '#448AFF'
      const msgType = rawMsgType
      const result = await query(
        `INSERT INTO private_messages (from_user_id, from_user_name, from_user_avatar, to_user_id, content, image_url, message_type, order_card)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [uid, userName || '用户', avatar, tid, filteredContent || '', imageUrl || '', msgType, orderCard || '']
      )

      await query(
        `DELETE FROM hidden_conversations
         WHERE (user_id = ? AND partner_id = ?) OR (user_id = ? AND partner_id = ?)`,
        [uid, tid, tid, uid]
      )

      // 私信通知收信人邮箱
      try {
        const targetUser = await query('SELECT email FROM users WHERE id=?', [tid])
        if (targetUser.length > 0 && targetUser[0].email) {
          sendNotificationEmail('private_message', targetUser[0].email, {
            username: '',
            subject: '收到新的私信',
            content: `${userName || '用户'} 给您发送了一条私信，请登录查看。`
          })
        }
      } catch {}

      res.json({
        code: 200,
        msg: '发送成功',
        data: {
          id: result.insertId,
          fromUserId: uid,
          fromUserName: userName,
          fromUserAvatar: avatar,
          toUserId: tid,
          content: filteredContent,
          imageUrl: imageUrl || '',
          messageType: msgType,
          orderCard: orderCard || '',
          isRead: 0,
          isRecalled: 0,
          reportStatus: 'none',
          createTime: new Date().toISOString()
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 撤回消息
  router.put('/api/messages/:id/recall', async (req, res) => {
    try {
      const { userId } = req.body
      const uid = Number(userId)
      const msgId = Number(req.params.id)
      if (!uid || !msgId) return res.json({ code: 400, msg: '参数错误' })

      const msg = await query(
        `SELECT id, from_user_id, create_time FROM private_messages WHERE id = ?`,
        [msgId]
      )
      if (!msg || !msg.length) return res.json({ code: 404, msg: '消息不存在' })
      if (msg[0].from_user_id !== uid) return res.json({ code: 403, msg: '只能撤回自己发送的消息' })

      // 2分钟撤回限制
      const msgTime = new Date(msg[0].create_time).getTime()
      const now = Date.now()
      if (now - msgTime > 2 * 60 * 1000) {
        return res.json({ code: 400, msg: '超过2分钟无法撤回' })
      }

      await query(
        `UPDATE private_messages SET is_recalled = 1, content = '', image_url = '' WHERE id = ?`,
        [msgId]
      )

      res.json({ code: 200, msg: '消息已撤回' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 举报消息
  router.post('/api/messages/:id/report', async (req, res) => {
    try {
      const { userId, reason, detail } = req.body
      const uid = Number(userId)
      const msgId = Number(req.params.id)
      if (!uid || !msgId) return res.json({ code: 400, msg: '参数错误' })

      const msg = await query(
        `SELECT id, from_user_id, to_user_id, content, image_url FROM private_messages WHERE id = ?`,
        [msgId]
      )
      if (!msg || !msg.length) return res.json({ code: 404, msg: '消息不存在' })

      // 更新消息举报状态
      await query(
        `UPDATE private_messages SET report_status = 'reported' WHERE id = ? AND report_status = 'none'`,
        [msgId]
      )

      // 插入举报记录
      const targetUid = msg[0].from_user_id === uid ? msg[0].to_user_id : msg[0].from_user_id
      await query(
        `INSERT INTO chat_reports (reporter_id, message_id, target_user_id, reason, detail)
         VALUES (?, ?, ?, ?, ?)`,
        [uid, msgId, targetUid, reason || '', detail || '']
      )

      res.json({ code: 200, msg: '举报已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 搜索消息
  router.get('/api/messages/search', async (req, res) => {
    try {
      const { userId, keyword, page = 1, pageSize = 20 } = req.query
      const uid = Number(userId)
      const kw = (keyword || '').trim()
      if (!uid) return res.json({ code: 400, msg: '请先登录' })
      if (!kw) return res.json({ code: 400, msg: '请输入搜索关键词' })

      const offset = (Number(page) - 1) * Number(pageSize)
      const messages = await query(
        `SELECT id, from_user_id as fromUserId, from_user_name as fromUserName,
                from_user_avatar as fromUserAvatar, to_user_id as toUserId,
                content, image_url as imageUrl, is_read as isRead,
                is_recalled as isRecalled, report_status as reportStatus,
                create_time as createTime
         FROM private_messages
         WHERE (from_user_id = ? OR to_user_id = ?)
           AND is_recalled = 0
           AND content LIKE ?
         ORDER BY id DESC LIMIT ? OFFSET ?`,
        [uid, uid, '%' + kw + '%', Number(pageSize), offset]
      )

      const cnt = await query(
        `SELECT COUNT(*) as total FROM private_messages
         WHERE (from_user_id = ? OR to_user_id = ?)
           AND is_recalled = 0
           AND content LIKE ?`,
        [uid, uid, '%' + kw + '%']
      )

      res.json({ code: 200, msg: 'success', data: { list: messages, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 删除/隐藏对话
  router.delete('/api/messages/conversations/:partnerId', async (req, res) => {
    try {
      const { userId } = req.query
      const uid = Number(userId)
      const pid = Number(req.params.partnerId)
      if (!uid || !pid) return res.json({ code: 400, msg: '参数错误' })

      await query(
        `INSERT IGNORE INTO hidden_conversations (user_id, partner_id) VALUES (?, ?)`,
        [uid, pid]
      )
      res.json({ code: 200, msg: '已删除对话' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 敏感词管理（管理员） ==========

  router.get('/api/admin/sensitive-words', async (req, res) => {
    try {
      const { page = 1, pageSize = 50 } = req.query
      const list = await query(
        `SELECT id, word, category, enabled, create_time as createTime
         FROM sensitive_words ORDER BY id DESC LIMIT ? OFFSET ?`,
        [Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM sensitive_words')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.post('/api/admin/sensitive-words', async (req, res) => {
    try {
      const { words, category } = req.body
      if (!words) return res.json({ code: 400, msg: '请提供敏感词' })
      const wordList = words.split(/[,，\n\s]+/).map(w => w.trim()).filter(w => w)
      if (!wordList.length) return res.json({ code: 400, msg: '请提供有效的敏感词' })

      for (const w of wordList) {
        const exist = await query('SELECT id FROM sensitive_words WHERE word = ?', [w])
        if (!exist || !exist.length) {
          await query('INSERT INTO sensitive_words (word, category) VALUES (?, ?)', [w, category || 'general'])
        }
      }
      res.json({ code: 200, msg: `成功添加 ${wordList.length} 个敏感词` })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/admin/sensitive-words/:id', async (req, res) => {
    try {
      const { word, category, enabled } = req.body
      const id = Number(req.params.id)
      if (!id || !word) return res.json({ code: 400, msg: '参数错误' })

      await query(
        `UPDATE sensitive_words SET word = ?, category = ?, enabled = ? WHERE id = ?`,
        [word, category || 'general', enabled !== undefined ? enabled : 1, id]
      )
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.delete('/api/admin/sensitive-words/:id', async (req, res) => {
    try {
      const id = Number(req.params.id)
      if (!id) return res.json({ code: 400, msg: '参数错误' })
      await query('DELETE FROM sensitive_words WHERE id = ?', [id])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 26. 通知类型 ==========

  router.get('/api/notifications/types', async (req, res) => {
    try {
      res.json({
        code: 200, data: [
          { type: 'system', label: '系统通知' },
          { type: 'comment', label: '评论' },
          { type: 'like', label: '点赞' },
          { type: 'follow', label: '关注' },
          { type: 'mention', label: '@提及' },
          { type: 'collection', label: '收藏' },
          { type: 'collection_purchase', label: '合集购买' },
          { type: 'content_purchase', label: '内容购买' },
          { type: 'order', label: '订单通知' },
          { type: 'commission', label: '返佣通知' },
          { type: 'withdraw', label: '提现通知' },
          { type: 'chat', label: '聊天消息' },
          { type: 'report', label: '举报通知' },
          { type: 'promotion', label: '推广通知' },
          { type: 'login_alert', label: '登录提醒' }
        ]
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 27. 推送通知注册 ==========

  router.post('/api/notifications/push/register', async (req, res) => {
    try {
      const { userId, subscription } = req.body
      if (!userId || !subscription) return res.json({ code: 400, msg: '参数不完整' })
      const uid = Number(userId)

      const existing = await query('SELECT id FROM users WHERE id = ?', [uid])
      if (!existing.length) return res.json({ code: 404, msg: '用户不存在' })

      const sub = typeof subscription === 'string' ? subscription : JSON.stringify(subscription)
      await query(
        'INSERT INTO sys_config (config_key, config_value, description) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)',
        ['push_subscription_' + uid, sub, 'Web Push Subscription for user ' + uid]
      )

      res.json({ code: 200, msg: '注册成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 28. 通知设置 ==========

  router.get('/api/user/notification-settings', async (req, res) => {
    try {
      const userId = Number(req.query.userId) || 0
      if (!userId) return res.json({ code: 400, msg: '请先登录' })

      const settings = await query('SELECT notification_type as type, enabled FROM user_notification_settings WHERE user_id = ?', [userId])
      res.json({ code: 200, data: settings })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/user/notification-settings', async (req, res) => {
    try {
      const { userId, settings } = req.body
      const uid = Number(userId)
      if (!uid) return res.json({ code: 400, msg: '请先登录' })
      if (!settings || !Array.isArray(settings)) return res.json({ code: 400, msg: '参数错误' })

      for (const s of settings) {
        if (s.type) {
          await query(
            'INSERT INTO user_notification_settings (user_id, notification_type, enabled) VALUES (?,?,?) ON DUPLICATE KEY UPDATE enabled = VALUES(enabled)',
            [uid, s.type, s.enabled ? 1 : 0]
          )
        }
      }
      res.json({ code: 200, msg: '保存成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ========== 举报管理（管理员） ==========

  router.get('/api/admin/chat-reports', async (req, res) => {
    try {
      const { page = 1, pageSize = 20, status } = req.query
      let whereClause = ''
      const params = []
      if (status) {
        whereClause = 'WHERE r.status = ?'
        params.push(status)
      }

      const list = await query(
        `SELECT r.id, r.reporter_id as reporterId, r.message_id as messageId,
                r.target_user_id as targetUserId, r.reason, r.detail,
                r.status, r.handler_id as handlerId, r.handle_notes as handleNotes,
                r.create_time as createTime, r.handle_time as handleTime,
                ru.username as reporterName, tu.username as targetUserName
         FROM chat_reports r
         LEFT JOIN users ru ON ru.id = r.reporter_id
         LEFT JOIN users tu ON tu.id = r.target_user_id
         ${whereClause}
         ORDER BY r.id DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )

      const cnt = await query(
        `SELECT COUNT(*) as total FROM chat_reports r ${whereClause}`,
        params
      )

      // 附上消息内容
      for (const item of list) {
        if (item.messageId) {
          const msg = await query(
            'SELECT content, image_url FROM private_messages WHERE id = ?',
            [item.messageId]
          )
          if (msg && msg.length) {
            item.messageContent = msg[0].content || (msg[0].image_url ? '[图片]' : '')
          }
        }
      }

      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.serverError(e)
    }
  })

  router.put('/api/admin/chat-reports/:id', async (req, res) => {
    try {
      const { status, handleNotes, handlerId } = req.body
      const id = Number(req.params.id)
      if (!id || !status) return res.json({ code: 400, msg: '参数错误' })

      const report = await query('SELECT id, status FROM chat_reports WHERE id = ?', [id])
      if (!report || !report.length) return res.json({ code: 404, msg: '举报不存在' })

      await query(
        `UPDATE chat_reports SET status = ?, handle_notes = ?, handler_id = ?,
         handle_time = ${nowExpr} WHERE id = ?`,
        [status, handleNotes || '', handlerId || 0, id]
      )
      res.json({ code: 200, msg: '处理成功' })
    } catch (e) {
      res.serverError(e)
    }
  })
}

module.exports = notificationRoutes
