const { query, getPool } = require('../database.cjs')
const { logFromReq } = require('../middleware/security.cjs')
const { sessions, SESSION_TTL, authRequired } = require('./system.cjs')

function adminRequired(req, res, next) {
  const roles = req.user.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return next()
  return res.status(403).json({ code: 403, msg: '无管理员权限' })
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return session.userId
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length) {
      const r = rows[0]
      const ca = typeof r.created_at === 'number' ? r.created_at : new Date(r.created_at).getTime()
      if (Date.now() - ca > SESSION_TTL) { query('DELETE FROM sessions WHERE token=?', [token]).catch(() => {}); return 0 }
      sessions.set(token, { userId: r.user_id, roles: JSON.parse(r.roles || '[]'), createdAt: ca })
      return r.user_id
    }
  } catch {}
  return 0
}

function addDays(date, days) {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function formatDateTime(d) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    const pad = (n) => String(n).padStart(2, '0')
    return `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`
  } catch { return '' }
}

function orderDesc(scene, orderAmount, discountAmount, payType) {
  const pt = payType === 'points' ? '积分' : '余额'
  const scenes = { membership_buy: '购买会员', product_buy: '购买商品' }
  const sceneDesc = scenes[scene] || scene || ''
  return `${sceneDesc} 原价¥${Number(orderAmount).toFixed(2)} ${pt}减¥${discountAmount.toFixed(2)}`
}

const SCOPE_LABELS = { all: '通用', product: '商品', membership: '会员' }
const CATEGORY_LABELS = { general: '通用券', member: '会员券', product: '商品券', event: '活动券', new_user: '新人券', rush: '限时抢券' }
const TYPE_LABELS = { fixed: '固定余额', percent: '余额折扣', fixed_points: '固定积分', points_percent: '积分折扣' }

function packCoupon(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description || '',
    type: row.type,
    typeLabel: TYPE_LABELS[row.type] || row.type,
    value: Number(row.value),
    minOrder: Number(row.min_order),
    maxDiscount: Number(row.max_discount),
    scope: row.scope,
    scopeLabel: SCOPE_LABELS[row.scope] || row.scope,
    targetIds: row.target_ids ? row.target_ids.split(',').map(Number) : [],
    targetNames: row.target_names || '',
    totalCount: row.total_count,
    claimedCount: row.claimed_count,
    perUserLimit: row.per_user_limit,
    startTime: row.start_time,
    expireTime: row.expire_time,
    validDays: row.valid_days,
    category: row.category,
    categoryLabel: CATEGORY_LABELS[row.category] || row.category,
    isRecommend: !!row.is_recommend,
    isNewUser: !!row.is_new_user,
    isRush: !!row.is_rush,
    isMultiUse: !!row.is_multi_use,
    sortOrder: row.sort_order,
    status: row.status,
    createTime: row.create_time,
    requiredLevelIds: row.required_level_ids ? row.required_level_ids.split(',').map(Number) : [],
    requiredLevelNames: row.required_level_names ? row.required_level_names.split(',') : []
  }
}

module.exports = function (app) {

  // ==================== 管理端 CRUD ====================

  // 优惠券列表
  app.get('/api/coupon/list', async (req, res) => {
    try {
      const { current = 1, size = 20, name, scope, category, status, type } = req.query
      const page = Math.max(Number(current) || 1, 1)
      const pageSize = Math.max(Number(size) || 20, 1)

      let where = 'WHERE 1=1'
      const params = []

      if (name) { where += ' AND name LIKE ?'; params.push(`%${name}%`) }
      if (scope) { where += ' AND scope=?'; params.push(scope) }
      if (category) { where += ' AND category=?'; params.push(category) }
      if (status) { where += ' AND status=?'; params.push(status) }
      if (type) { where += ' AND type=?'; params.push(type) }

      const countRows = await query(`SELECT COUNT(*) as total FROM coupons ${where}`, params)
      const total = countRows[0]?.total || 0
      const offset = (page - 1) * pageSize

      const rows = await query(
        `SELECT * FROM coupons ${where} ORDER BY sort_order ASC, id DESC LIMIT ? OFFSET ?`,
        [...params, pageSize, offset]
      )

      res.json({
        code: 200,
        data: {
          records: rows.map(packCoupon),
          total,
          current: page,
          size: pageSize
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 创建优惠券
  app.post('/api/coupon', authRequired, adminRequired, async (req, res) => {
    try {
      const {
        name, description, type, value, minOrder, maxDiscount,
        scope, targetIds, targetNames, totalCount, perUserLimit,
        startTime, expireTime, validDays, category,
        isRecommend, isNewUser, isRush, isMultiUse, sortOrder, status,
        requiredLevelIds, requiredLevelNames
      } = req.body

      if (!name) return res.json({ code: 400, msg: '请填写优惠券名称' })

      const result = await query(
        `INSERT INTO coupons (name, description, type, value, min_order, max_discount,
         scope, target_ids, target_names, total_count, per_user_limit,
         start_time, expire_time, valid_days, category,
         is_recommend, is_new_user, is_rush, is_multi_use, sort_order, status,
         required_level_ids, required_level_names)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          name, description || '', type || 'fixed', Number(value) || 0, Number(minOrder) || 0,
          Number(maxDiscount) || 0, scope || 'all',
          Array.isArray(targetIds) ? targetIds.join(',') : (targetIds || ''),
          targetNames || '', Number(totalCount) || 0, Number(perUserLimit) || 1,
          startTime || null, expireTime || null, Number(validDays) || 0,
          category || 'general', isRecommend ? 1 : 0, isNewUser ? 1 : 0,
          isRush ? 1 : 0, isMultiUse ? 1 : 0, Number(sortOrder) || 0, status || '1',
          Array.isArray(requiredLevelIds) ? requiredLevelIds.join(',') : (requiredLevelIds || ''),
          Array.isArray(requiredLevelNames) ? requiredLevelNames.join(',') : (requiredLevelNames || '')
        ]
      )

      logFromReq(req, 'create', 'coupon', result.insertId, `创建优惠券:${name}`)
      res.json({ code: 200, msg: '创建成功', data: { id: result.insertId } })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 更新优惠券
  app.put('/api/coupon/:id', authRequired, adminRequired, async (req, res) => {
    try {
      const { id } = req.params
      const {
        name, description, type, value, minOrder, maxDiscount,
        scope, targetIds, targetNames, totalCount, perUserLimit,
        startTime, expireTime, validDays, category,
        isRecommend, isNewUser, isRush, isMultiUse, sortOrder, status,
        requiredLevelIds, requiredLevelNames
      } = req.body

      const existing = await query('SELECT * FROM coupons WHERE id=?', [id])
      if (!existing.length) return res.json({ code: 404, msg: '优惠券不存在' })

      await query(
        `UPDATE coupons SET name=?, description=?, type=?, value=?, min_order=?, max_discount=?,
         scope=?, target_ids=?, target_names=?, total_count=?, per_user_limit=?,
         start_time=?, expire_time=?, valid_days=?, category=?,
         is_recommend=?, is_new_user=?, is_rush=?, is_multi_use=?, sort_order=?, status=?,
         required_level_ids=?, required_level_names=?
         WHERE id=?`,
        [
          name || existing[0].name, description || '', type || existing[0].type,
          Number(value) || 0, Number(minOrder) || 0, Number(maxDiscount) || 0,
          scope || existing[0].scope,
          Array.isArray(targetIds) ? targetIds.join(',') : (targetIds || existing[0].target_ids),
          targetNames || existing[0].target_names,
          totalCount !== undefined ? Number(totalCount) : existing[0].total_count,
          perUserLimit !== undefined ? Number(perUserLimit) : existing[0].per_user_limit,
          startTime !== undefined ? startTime : existing[0].start_time,
          expireTime !== undefined ? expireTime : existing[0].expire_time,
          validDays !== undefined ? Number(validDays) : existing[0].valid_days,
          category || existing[0].category,
          isRecommend !== undefined ? (isRecommend ? 1 : 0) : existing[0].is_recommend,
          isNewUser !== undefined ? (isNewUser ? 1 : 0) : existing[0].is_new_user,
          isRush !== undefined ? (isRush ? 1 : 0) : existing[0].is_rush,
          isMultiUse !== undefined ? (isMultiUse ? 1 : 0) : existing[0].is_multi_use,
          Number(sortOrder) || 0,
          status || existing[0].status,
          requiredLevelIds !== undefined
            ? (Array.isArray(requiredLevelIds) ? requiredLevelIds.join(',') : requiredLevelIds)
            : existing[0].required_level_ids,
          requiredLevelNames !== undefined
            ? (Array.isArray(requiredLevelNames) ? requiredLevelNames.join(',') : requiredLevelNames)
            : existing[0].required_level_names,
          id
        ]
      )

      logFromReq(req, 'update', 'coupon', id, `更新优惠券:${name || existing[0].name}`)
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 删除优惠券
  app.delete('/api/coupon/:id', authRequired, adminRequired, async (req, res) => {
    try {
      const { id } = req.params
      await query('DELETE FROM coupons WHERE id=?', [id])
      logFromReq(req, 'delete', 'coupon', id, `删除优惠券ID:${id}`)
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // ==================== 用户端 API ====================

  // 可领取的优惠券列表
  app.get('/api/coupon/available', async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { category, scope } = req.query
      const now = formatDateTime(new Date())

      let where = "WHERE status='1'"
      const params = []

      where += ' AND (expire_time IS NULL OR expire_time > ?)'
      params.push(now)
      where += ' AND (start_time IS NULL OR start_time <= ?)'
      params.push(now)

      if (category) { where += ' AND category=?'; params.push(category) }
      if (scope) { where += ' AND scope=?'; params.push(scope) }

      where += ' AND (total_count = 0 OR claimed_count < total_count)'

      const rows = await query(
        `SELECT * FROM coupons ${where} ORDER BY is_recommend DESC, sort_order ASC, id DESC`,
        params
      )

      const coupons = rows.map(packCoupon)

      const claimedMap = {}
      let userLevelId = 0
      if (userId) {
        const claimed = await query(
          `SELECT coupon_id, COUNT(*) as cnt FROM user_coupons WHERE user_id=? GROUP BY coupon_id`,
          [userId]
        )
        claimed.forEach((r) => { claimedMap[r.coupon_id] = r.cnt })
        const userRow = await query('SELECT level_id FROM users WHERE id=?', [userId])
        userLevelId = userRow.length ? (userRow[0].level_id || 0) : 0
      }

      res.json({
        code: 200,
        data: coupons.map((c) => {
          let canClaim = true
          let claimStatus = 'available'
          if (!userId) {
            canClaim = false
            claimStatus = 'not_logged_in'
          } else if (!(c.totalCount === 0 || c.claimedCount < c.totalCount)) {
            canClaim = false
            claimStatus = 'sold_out'
          } else if (c.perUserLimit > 0 && (claimedMap[c.id] || 0) >= c.perUserLimit) {
            canClaim = false
            claimStatus = 'claimed'
          } else if (c.requiredLevelIds && c.requiredLevelIds.length > 0 && !c.requiredLevelIds.includes(userLevelId)) {
            canClaim = false
            claimStatus = 'level_required'
          }
          return {
            ...c,
            canClaim,
            claimStatus,
            claimedByUser: claimedMap[c.id] || 0,
            levelRequired: c.requiredLevelIds && c.requiredLevelIds.length > 0
              ? { ids: c.requiredLevelIds, names: c.requiredLevelNames }
              : null
          }
        })
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 领取优惠券
  app.post('/api/coupon/claim/:id', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { id } = req.params
      const now = formatDateTime(new Date())

      const coupon = await query('SELECT * FROM coupons WHERE id=? AND status=?', [id, '1'])
      if (!coupon.length) return res.json({ code: 404, msg: '优惠券不存在或已下架' })

      const c = coupon[0]

      // 检查领取时间
      if (c.start_time && c.start_time > now) return res.json({ code: 400, msg: '还未到领取时间' })
      if (c.expire_time && c.expire_time < now) return res.json({ code: 400, msg: '领取已截止' })

      // 检查库存
      if (c.total_count > 0 && c.claimed_count >= c.total_count) {
        return res.json({ code: 400, msg: '已被领完' })
      }

      // 检查每人限领
      if (c.per_user_limit > 0) {
        const claimed = await query(
          'SELECT COUNT(*) as cnt FROM user_coupons WHERE user_id=? AND coupon_id=?',
          [userId, id]
        )
        if (claimed[0].cnt >= c.per_user_limit) {
          return res.json({ code: 400, msg: '已达到领取上限' })
        }
      }

      // 仅新人检查
      if (c.is_new_user) {
        const userCoupons = await query('SELECT COUNT(*) as cnt FROM user_coupons WHERE user_id=?', [userId])
        if (userCoupons[0].cnt > 0) {
          return res.json({ code: 400, msg: '仅限新人领取' })
        }
      }

      // 会员等级限制检查
      if (c.required_level_ids) {
        const levelIds = c.required_level_ids.split(',').map(Number).filter(Boolean)
        if (levelIds.length > 0) {
          const userRow = await query('SELECT level_id FROM users WHERE id=?', [userId])
          const userLevelId = userRow.length ? (userRow[0].level_id || 0) : 0
          if (!levelIds.includes(userLevelId)) {
            const levelNames = c.required_level_names || '指定会员'
            return res.json({ code: 400, msg: `仅限${levelNames}领取` })
          }
        }
      }

      // 计算过期时间
      let userExpireTime
      if (c.expire_time) {
        userExpireTime = c.expire_time
      } else if (c.valid_days > 0) {
        userExpireTime = formatDateTime(addDays(new Date(), c.valid_days))
      } else {
        userExpireTime = formatDateTime(addDays(new Date(), 30))
      }

      // 使用事务保护领取操作，防止并发超领
      const conn = await getPool().promise().getConnection()
      try {
        await conn.query('BEGIN')
        // FOR UPDATE 锁行防止并发超领
        await conn.query('SELECT total_count, claimed_count FROM coupons WHERE id=? FOR UPDATE', [id])

        // 二次检查库存（在锁内重新验证）
        const couponAfterLock = await conn.query('SELECT * FROM coupons WHERE id=? AND status=?', [id, '1'])
        if (!couponAfterLock.length) {
          await conn.query('ROLLBACK')
          return res.json({ code: 404, msg: '优惠券不存在或已下架' })
        }
        const c2 = couponAfterLock[0]
        if (c2.total_count > 0 && c2.claimed_count >= c2.total_count) {
          await conn.query('ROLLBACK')
          return res.json({ code: 400, msg: '已被领完' })
        }

        // 增加领取计数
        await conn.query('UPDATE coupons SET claimed_count = claimed_count + 1 WHERE id=?', [id])

        // 写入用户优惠券
        const couponData = JSON.stringify({
          name: c.name,
          type: c.type,
          value: Number(c.value),
          minOrder: Number(c.min_order),
          maxDiscount: Number(c.max_discount),
          scope: c.scope,
          targetIds: c.target_ids,
          category: c.category
        })

        await conn.query(
          `INSERT INTO user_coupons (user_id, coupon_id, status, coupon_data, expire_time, remaining_value) VALUES (?,?,?,?,?,?)`,
          [userId, id, 'unused', couponData, userExpireTime, c.is_multi_use ? Number(c.value) : null]
        )

        await conn.query('COMMIT')
      } catch (e) {
        await conn.query('ROLLBACK')
        throw e
      } finally {
        conn.release()
      }

      res.json({ code: 200, msg: '领取成功' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 我的优惠券
  app.get('/api/coupon/my', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })


      // 自动过期
      await query(
        "UPDATE user_coupons SET status='expired' WHERE user_id=? AND status='unused' AND expire_time < ?",
        [userId, now]
      )

      let where = 'WHERE uc.user_id=?'
      const params = [userId]

      if (status === 'unused') {
        where += " AND uc.status='unused' AND uc.expire_time >= ?"
        params.push(now)
      } else if (status === 'used') {
        where += " AND uc.status='used'"
      } else if (status === 'expired') {
        where += " AND (uc.status='expired' OR (uc.status='unused' AND uc.expire_time < ?))"
        params.push(now)
      }

      const rows = await query(
        `SELECT uc.*, c.name, c.type, c.value, c.min_order, c.scope, c.category, c.is_multi_use
         FROM user_coupons uc LEFT JOIN coupons c ON uc.coupon_id = c.id
         ${where} ORDER BY uc.receive_time DESC`,
        params
      )

      res.json({
        code: 200,
        data: rows.map((r) => ({
          id: r.id,
          couponId: r.coupon_id,
          name: r.name || (r.coupon_data ? JSON.parse(r.coupon_data).name : ''),
          type: r.type || (r.coupon_data ? JSON.parse(r.coupon_data).type : ''),
          value: Number(r.value || (r.coupon_data ? JSON.parse(r.coupon_data).value : 0)),
          minOrder: Number(r.min_order || (r.coupon_data ? JSON.parse(r.coupon_data).minOrder : 0)),
          scope: r.scope || (r.coupon_data ? JSON.parse(r.coupon_data).scope : ''),
          category: r.category || (r.coupon_data ? JSON.parse(r.coupon_data).category : ''),
          status: r.status,
          expireTime: r.expire_time,
          receiveTime: r.receive_time,
          useTime: r.use_time,
          useScene: r.use_scene,
          useAmount: Number(r.use_amount),
          isMultiUse: !!r.is_multi_use,
          remainingValue: r.remaining_value !== null ? Number(r.remaining_value) : null
        }))
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 获取可用优惠券（结算时按场景筛选）
  app.get('/api/coupon/usable', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 200, data: [] })

      const { scene, targetId, orderAmount, payType } = req.query
      const now = formatDateTime(new Date())

      // 自动过期
      await query(
        "UPDATE user_coupons SET status='expired' WHERE user_id=? AND status='unused' AND expire_time < ?",
        [userId, now]
      )

      const rows = await query(
        `SELECT uc.*, c.name, c.type, c.value, c.min_order, c.max_discount, c.scope, c.target_ids, c.category, c.is_multi_use
         FROM user_coupons uc LEFT JOIN coupons c ON uc.coupon_id = c.id
         WHERE uc.user_id=? AND uc.status='unused' AND uc.expire_time >= ?
         ORDER BY c.value DESC, uc.expire_time ASC`,
        [userId, now]
      )

      let result = rows.map((r) => {
        const cd = r.coupon_data ? JSON.parse(r.coupon_data) : {}
        const scope = r.scope || cd.scope
        const targetIds = r.target_ids || cd.targetIds || ''
        const tid = Number(targetId) || 0
        const type = r.type || cd.type

        // payType过滤: 积分券仅积分支付可用, 余额券仅余额支付可用
        if (payType) {
          const isPointsCoupon = type === 'fixed_points' || type === 'points_percent'
          const isBalanceCoupon = type === 'fixed' || type === 'percent'
          if (payType === 'points' && isBalanceCoupon) return null
          if (payType === 'balance' && isPointsCoupon) return null
        }

        // 场景过滤
        if (scene) {
          if (scope === 'all') { /* pass */ }
          else if (scope === 'product' && (scene.startsWith('product') || scene === 'content_buy')) { /* pass */ }
          else if (scope === 'membership' && scene.startsWith('membership')) { /* pass */ }
          else return null
        }

        // 指定商品/等级过滤
        if (targetIds) {
          const ids = targetIds.split(',').map(Number)
          if (tid && ids.length > 0 && !ids.includes(tid)) return null
        }

        // 最低消费
        const minOrder = Number(r.min_order || cd.minOrder || 0)
        const orderAmt = Number(orderAmount) || 0
        if (orderAmt > 0 && minOrder > 0 && orderAmt < minOrder) return null

        return {
          userCouponId: r.id,
          couponId: r.coupon_id,
          name: r.name || cd.name,
          type,
          value: Number(r.value || cd.value || 0),
          minOrder,
          maxDiscount: Number(r.max_discount || cd.maxDiscount || 0),
          scope,
          category: r.category || cd.category,
          expireTime: r.expire_time,
          isMultiUse: !!r.is_multi_use,
          remainingValue: r.remaining_value !== null ? Number(r.remaining_value) : null
        }
      }).filter(Boolean)

      // 面值大的排前面
      result.sort((a, b) => b.value - a.value)

      res.json({ code: 200, data: result })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 使用记录
  app.get('/api/coupon/history', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const rows = await query(
        `SELECT uc.*, c.name, c.type, c.value
         FROM user_coupons uc LEFT JOIN coupons c ON uc.coupon_id = c.id
         WHERE uc.user_id=? AND uc.status IN ('used','expired')
         ORDER BY uc.use_time DESC, uc.receive_time DESC
         LIMIT 50`,
        [userId]
      )

      res.json({
        code: 200,
        data: rows.map((r) => ({
          id: r.id,
          name: r.name || (r.coupon_data ? JSON.parse(r.coupon_data).name : ''),
          type: r.type || (r.coupon_data ? JSON.parse(r.coupon_data).type : ''),
          value: Number(r.value || (r.coupon_data ? JSON.parse(r.coupon_data).value : 0)),
          status: r.status,
          expireTime: r.expire_time,
          receiveTime: r.receive_time,
          useTime: r.use_time,
          useScene: r.use_scene,
          useAmount: Number(r.use_amount)
        }))
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 验证并使用优惠券
  app.post('/api/coupon/use', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userCouponId, scene, targetId, orderAmount, orderId, payType } = req.body

      const uc = await query('SELECT * FROM user_coupons WHERE id=? AND user_id=?', [userCouponId, userId])
      if (!uc.length) return res.json({ code: 404, msg: '优惠券不存在' })
      if (uc[0].status !== 'unused') return res.json({ code: 400, msg: '优惠券已使用或已过期' })

      const now = formatDateTime(new Date())
      if (uc[0].expire_time && uc[0].expire_time < now) {
        await query("UPDATE user_coupons SET status='expired' WHERE id=?", [userCouponId])
        return res.json({ code: 400, msg: '优惠券已过期' })
      }

      const cd = uc[0].coupon_data ? JSON.parse(uc[0].coupon_data) : {}
      const c = await query('SELECT * FROM coupons WHERE id=?', [uc[0].coupon_id])
      if (!c.length) return res.json({ code: 404, msg: '优惠券模板不存在' })
      const scope = c[0].scope || cd.scope
      const targetIds = c[0].target_ids || cd.targetIds || ''
      const tid = Number(targetId) || 0

      // 场景校验
      if (scene) {
        if (scope === 'all') { /* pass */ }
        else if (scope === 'product' && !scene.startsWith('product')) {
          return res.json({ code: 400, msg: '此优惠券仅限商城场景使用' })
        } else if (scope === 'membership' && !scene.startsWith('membership')) {
          return res.json({ code: 400, msg: '此优惠券仅限会员场景使用' })
        }
      }

      // 指定商品/等级校验
      if (targetIds) {
        const ids = targetIds.split(',').map(Number)
        if (tid && ids.length > 0 && !ids.includes(tid)) {
          return res.json({ code: 400, msg: '此优惠券不适用于该商品' })
        }
      }

      // 最低消费
      const minOrder = Number(c[0].min_order || cd.minOrder || 0)
      const orderAmt = Number(orderAmount) || 0
      if (orderAmt > 0 && minOrder > 0 && orderAmt < minOrder) {
        return res.json({ code: 400, msg: `未达到最低消费 ¥${minOrder}` })
      }

      const type = c[0].type || cd.type
      const value = Number(c[0].value || cd.value || 0)
      const maxDisc = Number(c[0].max_discount || cd.maxDiscount || 0)
      const isMultiUse = !!(c[0].is_multi_use)

      // 多用途券: 从剩余值中取
      let availableValue = value
      if (isMultiUse) {
        const remaining = uc[0].remaining_value !== null && uc[0].remaining_value !== undefined
          ? Number(uc[0].remaining_value)
          : value
        availableValue = remaining
      }

      // 积分券只能用于积分支付, 余额券只能用于余额支付
      const isPointsCoupon = type === 'fixed_points' || type === 'points_percent'
      const isBalanceCoupon = type === 'fixed' || type === 'percent'
      const actualPayType = payType || 'balance'
      if (isPointsCoupon && actualPayType !== 'points') {
        return res.json({ code: 400, msg: '此券仅限积分支付时使用' })
      }
      if (isBalanceCoupon && actualPayType === 'points') {
        return res.json({ code: 400, msg: '此券仅限余额支付时使用' })
      }

      // 计算优惠金额
      let discountAmount = 0
      const calcBase = isPointsCoupon ? orderAmt : orderAmt  // points coupons use the same calculation base

      if (type === 'fixed' || type === 'fixed_points') {
        discountAmount = Math.min(availableValue, orderAmt)
      } else if (type === 'percent' || type === 'points_percent') {
        discountAmount = Math.floor(orderAmt * value / 100 * 100) / 100
        if (maxDisc > 0 && discountAmount > maxDisc) discountAmount = maxDisc
        discountAmount = Math.min(discountAmount, orderAmt)
      }

      const beforeRemaining = isMultiUse ? availableValue : null
      const afterRemaining = isMultiUse ? Math.max(0, availableValue - discountAmount) : null

      // 更新使用状态
      if (isMultiUse) {
        if (afterRemaining <= 0) {
          await query(
            `UPDATE user_coupons SET status='used', use_time=?, use_scene=?, use_order_id=?, use_amount=?, remaining_value=0 WHERE id=?`,
            [now, scene || '', Number(orderId) || 0, Number(uc[0].use_amount || 0) + discountAmount, userCouponId]
          )
        } else {
          await query(
            `UPDATE user_coupons SET use_time=?, use_scene=?, use_order_id=?, use_amount=use_amount+?, remaining_value=? WHERE id=?`,
            [now, scene || '', Number(orderId) || 0, discountAmount, afterRemaining, userCouponId]
          )
        }
      } else {
        await query(
          `UPDATE user_coupons SET status='used', use_time=?, use_scene=?, use_order_id=?, use_amount=?, remaining_value=NULL WHERE id=?`,
          [now, scene || '', Number(orderId) || 0, discountAmount, userCouponId]
        )
      }

      // 写入使用日志
      const userRow = await query('SELECT username FROM users WHERE id=?', [userId])
      const userName = userRow.length ? (userRow[0].username || '') : ''
      await query(
        `INSERT INTO coupon_usage_logs (user_coupon_id, user_id, user_name, coupon_id, coupon_name, use_scene, use_amount, before_remaining, after_remaining, order_desc, use_time)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        [userCouponId, userId, userName, uc[0].coupon_id, c[0].name || cd.name || '', scene || '', discountAmount, beforeRemaining, afterRemaining, orderDesc(scene, orderAmount, discountAmount, payType), now]
      )

      res.json({
        code: 200,
        msg: '优惠券使用成功',
        data: {
          userCouponId,
          name: c[0].name || cd.name,
          discountAmount,
          finalAmount: Math.max(0, orderAmt - discountAmount),
          isMultiUse,
          remainingValue: afterRemaining
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 优惠券使用记录(用户端)
  app.get('/api/coupon/usage/logs', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userCouponId, page = 1, size = 20 } = req.query
      let where = 'WHERE user_id=?'
      const params = [userId]

      if (userCouponId) { where += ' AND user_coupon_id=?'; params.push(Number(userCouponId)) }

      const total = await query(`SELECT COUNT(*) as cnt FROM coupon_usage_logs ${where}`, params)
      const rows = await query(
        `SELECT * FROM coupon_usage_logs ${where} ORDER BY use_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(size), (Number(page) - 1) * Number(size)]
      )

      res.json({
        code: 200,
        data: {
          records: rows,
          total: total[0]?.cnt || 0,
          page: Number(page),
          size: Number(size)
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 领取记录管理(管理端)
  app.get('/api/coupon/claims', authRequired, adminRequired, async (req, res) => {
    try {
      const { couponId, page = 1, size = 20 } = req.query
      let where = 'WHERE 1=1'
      const params = []

      if (couponId) { where += ' AND uc.coupon_id=?'; params.push(Number(couponId)) }

      const total = await query(
        `SELECT COUNT(*) as cnt FROM user_coupons uc ${where}`,
        params
      )

      const rows = await query(
        `SELECT uc.id, uc.user_id, uc.coupon_id, uc.status, uc.expire_time, uc.use_time, uc.use_amount,
                uc.remaining_value, uc.receive_time,
                u.username, u.email,
                c.name as coupon_name, c.value as coupon_value, c.type as coupon_type
         FROM user_coupons uc
         LEFT JOIN users u ON uc.user_id = u.id
         LEFT JOIN coupons c ON uc.coupon_id = c.id
         ${where}
         ORDER BY uc.receive_time DESC
         LIMIT ? OFFSET ?`,
        [...params, Number(size), (Number(page) - 1) * Number(size)]
      )

      res.json({
        code: 200,
        data: {
          records: rows.map(r => ({
            id: r.id,
            userId: r.user_id,
            userName: r.username || '',
            userEmail: r.email || '',
            couponId: r.coupon_id,
            couponName: r.coupon_name || '',
            couponValue: r.coupon_value,
            couponType: r.coupon_type,
            status: r.status,
            expireTime: r.expire_time,
            useTime: r.use_time,
            useAmount: r.use_amount,
            remainingValue: r.remaining_value,
            receiveTime: r.receive_time
          })),
          total: total[0]?.cnt || 0,
          page: Number(page),
          size: Number(size)
        }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 使用日志管理(管理端)
  app.get('/api/coupon/usage/all', authRequired, adminRequired, async (req, res) => {
    try {
      const { couponId, userId, page = 1, size = 20 } = req.query
      let where = 'WHERE 1=1'
      const params = []

      if (couponId) { where += ' AND coupon_id=?'; params.push(Number(couponId)) }
      if (userId) { where += ' AND user_id=?'; params.push(Number(userId)) }

      const total = await query(`SELECT COUNT(*) as cnt FROM coupon_usage_logs ${where}`, params)
      const rows = await query(
        `SELECT * FROM coupon_usage_logs ${where} ORDER BY use_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(size), (Number(page) - 1) * Number(size)]
      )

      res.json({
        code: 200,
        data: { records: rows, total: total[0]?.cnt || 0, page: Number(page), size: Number(size) }
      })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 用户券详情(含剩余值)
  app.get('/api/coupon/my/:userCouponId/logs', async (req, res) => {
    try {
      const userId = await getUserId(req)
      if (!userId) return res.json({ code: 401, msg: '请先登录' })

      const { userCouponId } = req.params
      const logs = await query(
        `SELECT * FROM coupon_usage_logs WHERE user_id=? AND user_coupon_id=? ORDER BY use_time DESC`,
        [userId, Number(userCouponId)]
      )

      res.json({ code: 200, data: logs })
    } catch (e) {
      res.serverError(e)
    }
  })

}
