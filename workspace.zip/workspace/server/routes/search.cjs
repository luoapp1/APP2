const { query } = require('../database.cjs')

module.exports = function searchRoutes(app) {

  app.get('/api/search', async (req, res) => {
    try {
      const { q = '', types } = req.query
      if (!q.trim()) {
        return res.json({
          code: 200,
          data: { apps: [], posts: [], products: [], users: [], collections: [] }
        })
      }

      const keyword = `%${q.trim()}%`
      const typeList = types ? types.split(',') : ['app', 'post', 'mall', 'user', 'community']
      const limit = 5

      const result = { apps: [], posts: [], products: [], users: [], collections: [] }
      const queries = []

      if (typeList.includes('app')) {
        queries.push(
          query(
            `SELECT id, name, description FROM app_store
             WHERE status='1' AND (name LIKE ? OR description LIKE ? OR developer LIKE ? OR tags LIKE ?)
             LIMIT ${limit}`,
            [keyword, keyword, keyword, keyword]
          ).then(rows => {
            result.apps = rows.map(r => ({
              id: r.id,
              title: r.name,
              type: 'app',
              brief: (r.description || '').substring(0, 100)
            }))
          })
        )
      }

      if (typeList.includes('post')) {
        queries.push(
          query(
            `SELECT id, title, content FROM community_posts
             WHERE is_deleted=0 AND status IN ('published','reviewed')
               AND (title LIKE ? OR content LIKE ?)
             LIMIT ${limit}`,
            [keyword, keyword]
          ).then(rows => {
            result.posts = rows.map(r => ({
              id: r.id,
              title: r.title,
              type: 'post',
              brief: (r.content || '').substring(0, 100)
            }))
          })
        )
      }

      if (typeList.includes('mall')) {
        queries.push(
          query(
            `SELECT id, name, description FROM mall_products
             WHERE status='1' AND (name LIKE ? OR description LIKE ?)
             LIMIT ${limit}`,
            [keyword, keyword]
          ).then(rows => {
            result.products = rows.map(r => ({
              id: r.id,
              title: r.name,
              type: 'product',
              brief: (r.description || '').substring(0, 100)
            }))
          })
        )
      }

      if (typeList.includes('user')) {
        queries.push(
          query(
            `SELECT id, username, nickname, bio FROM users
             WHERE status='1' AND username LIKE ?
             LIMIT ${limit}`,
            [keyword]
          ).then(rows => {
            result.users = rows.map(r => ({
              id: r.id,
              title: r.nickname || r.username,
              type: 'user',
              brief: (r.bio || '').substring(0, 100)
            }))
          })
        )
      }

      if (typeList.includes('community')) {
        queries.push(
          query(
            `SELECT id, title, description FROM community_collections
             WHERE is_deleted=0 AND (title LIKE ? OR description LIKE ?)
             LIMIT ${limit}`,
            [keyword, keyword]
          ).then(rows => {
            result.collections = rows.map(r => ({
              id: r.id,
              title: r.title,
              type: 'collection',
              brief: (r.description || '').substring(0, 100)
            }))
          })
        )
      }

      await Promise.all(queries)

      res.json({ code: 200, data: result })
    } catch (e) {
      res.status(500).json({ code: 500, message: e.message })
    }
  })
}
