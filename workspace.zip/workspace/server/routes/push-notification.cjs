const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')
const nowExpr = 'NOW()'

function pushNotificationRoutes(router) {

  router.post('/api/push-notification/send', authRequired, async (req, res) => {
    try {
      const { type, targetType, targetIds, title, content, link, channels } = req.body
      if (!title || !content) {
        return res.json({ code: 400, msg: '标题和内容不能为空' })
      }

      let targetUsers = []
      if (targetType === 'specific' && targetIds) {
        const ids =         targetIds.split(',').map((s) => Number(s.trim())).filter(Boolean)
        targetUsers = await query(
          `SELECT id FROM users WHERE id IN (${ids.map(() => '?').join(',')})`,
          ids
        )
      } else if (targetType === 'membership') {
        const levelId = req.body.membershipLevel
        if (levelId === 'all') {
          targetUsers = await query('SELECT id FROM users WHERE status=\'1\'')
        } else {
          targetUsers = await query('SELECT id FROM users WHERE level_id=? AND status=\'1\'', [Number(levelId)])
        }
      } else {
        targetUsers = await query('SELECT id FROM users WHERE status=\'1\'')
      }

      if (targetUsers.length === 0) {
        return res.json({ code: 400, msg: '没有找到目标用户' })
      }

      const channelsArr = channels || ['app']
      for (const user of targetUsers) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name)
           VALUES (?, ?, ?, ?, ?, 0, '系统')`,
          [title || '', content || '', type || 'system', link || '', user.id]
        )
      }

      await query(
        `INSERT INTO push_notifications (type, target_type, target_count, title, content, link, channels, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'sent')`,
        [type || 'system', targetType, targetUsers.length, title, content, link || '', JSON.stringify(channelsArr)]
      )

      res.json({ code: 200, msg: '发送成功', data: { targetCount: targetUsers.length } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/push-notification/draft', authRequired, async (req, res) => {
    try {
      const { type, targetType, targetIds, title, content, link, channels, membershipLevel } = req.body
      if (!title) {
        return res.json({ code: 400, msg: '标题不能为空' })
      }
      const channelsArr = channels || ['app']
      await query(
        `INSERT INTO push_notifications (type, target_type, target_ids, target_count, title, content, link, channels, status, membership_level)
         VALUES (?, ?, ?, 0, ?, ?, ?, ?, 'draft', ?)`,
        [type || 'system', targetType, targetIds || '', title, content || '', link || '', JSON.stringify(channelsArr), membershipLevel || '']
      )
      res.json({ code: 200, msg: '草稿已保存' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/push-notification/history', async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize

      const list = await query(
        `SELECT id, type, target_type as targetType, target_count as targetCount,
                title, content, link, channels, status, create_time as createTime
         FROM push_notifications ORDER BY id DESC LIMIT ? OFFSET ?`,
        [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM push_notifications')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/push-notification/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM push_notifications WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/notification/push', authRequired, async (req, res) => {
    try {
      const { type, targetType, targetIds, title, content, link, channels } = req.body
      if (!title || !content) {
        return res.json({ code: 400, msg: '标题和内容不能为空' })
      }

      let targetUsers = []
      if (targetType === 'specific' && targetIds) {
        const ids = targetIds.split(',').map((s) => Number(s.trim())).filter(Boolean)
        targetUsers = await query(
          `SELECT id FROM users WHERE id IN (${ids.map(() => '?').join(',')})`,
          ids
        )
      } else if (targetType === 'membership') {
        const levelId = req.body.membershipLevel
        if (levelId === 'all') {
          targetUsers = await query('SELECT id FROM users WHERE status=\'1\'')
        } else {
          targetUsers = await query('SELECT id FROM users WHERE level_id=? AND status=\'1\'', [Number(levelId)])
        }
      } else {
        targetUsers = await query('SELECT id FROM users WHERE status=\'1\'')
      }

      if (targetUsers.length === 0) {
        return res.json({ code: 400, msg: '没有找到目标用户' })
      }

      for (const user of targetUsers) {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_url, target_user_id, from_user_id, from_user_name)
           VALUES (?, ?, ?, ?, ?, 0, '系统')`,
          [title || '', content || '', type || 'system', link || '', user.id]
        )
      }

      await query(
        `INSERT INTO push_notifications (type, target_type, target_count, title, content, link, channels, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'sent')`,
        [type || 'system', targetType, targetUsers.length, title, content, link || '', JSON.stringify(channels || ['app'])]
      )

      res.json({ code: 200, msg: '发送成功', data: { targetCount: targetUsers.length } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/notification/history', async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 20
      const offset = (page - 1) * pageSize

      const list = await query(
        `SELECT id, type, target_type as targetType, target_count as targetCount,
                title, content, link, channels, status, create_time as createTime
         FROM push_notifications ORDER BY id DESC LIMIT ? OFFSET ?`,
        [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM push_notifications')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = pushNotificationRoutes
