const { query } = require('../database.cjs')
const { authRequired, requirePermission } = require('./system.cjs')

function abTestRoutes(router) {

  router.get('/api/ab-test/list', authRequired, async (req, res) => {
    try {
      const page = Number(req.query.page) || 1
      const pageSize = Number(req.query.pageSize) || 10
      const offset = (page - 1) * pageSize

      const list = await query(
        `SELECT id, name, target_page as targetPage, goal, traffic, status,
                create_time as createTime, update_time as updateTime
         FROM ab_tests ORDER BY id DESC LIMIT ? OFFSET ?`,
        [pageSize, offset]
      )
      const cnt = await query('SELECT COUNT(*) as total FROM ab_tests')
      res.json({ code: 200, msg: 'success', data: { list, total: cnt[0]?.total || 0 } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.get('/api/ab-test/:id', authRequired, async (req, res) => {
    try {
      const test = await query(
        `SELECT id, name, target_page as targetPage, goal, traffic, status,
                create_time as createTime
         FROM ab_tests WHERE id=?`, [Number(req.params.id)]
      )
      if (!test || test.length === 0) {
        return res.json({ code: 404, msg: '测试不存在' })
      }
      const variants = await query(
        `SELECT id, name, ratio, config, impressions, conversions, conversion_rate as conversionRate
         FROM ab_test_variants WHERE test_id=? ORDER BY id ASC`,
        [Number(req.params.id)]
      )
      for (const v of variants) {
        try { v.config = v.config ? JSON.parse(v.config) : {} } catch { v.config = {} }
      }
      res.json({ code: 200, msg: 'success', data: { ...test[0], variants } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/ab-test/save', authRequired, async (req, res) => {
    try {
      const { id, name, targetPage, goal, traffic, variants } = req.body
      if (!name) return res.json({ code: 400, msg: '名称不能为空' })

      if (id) {
        await query(
          `UPDATE ab_tests SET name=?, target_page=?, goal=?, traffic=?, update_time=NOW() WHERE id=?`,
          [name, targetPage || '', goal || 'ctr', Number(traffic) || 50, Number(id)]
        )
        await query('DELETE FROM ab_test_variants WHERE test_id=?', [Number(id)])
        if (variants && Array.isArray(variants)) {
          for (const v of variants) {
            await query(
              `INSERT INTO ab_test_variants (test_id, name, ratio, config) VALUES (?,?,?,?)`,
              [Number(id), v.name || '', Number(v.ratio) || 0, typeof v.config === 'string' ? v.config : JSON.stringify(v.config || {})]
            )
          }
        }
        res.json({ code: 200, msg: '更新成功', data: { id: Number(id) } })
      } else {
        const result = await query(
          `INSERT INTO ab_tests (name, target_page, goal, traffic, status) VALUES (?,?,?,?,'draft')`,
          [name, targetPage || '', goal || 'ctr', Number(traffic) || 50]
        )
        const testId = result.insertId
        if (variants && Array.isArray(variants)) {
          for (const v of variants) {
            await query(
              `INSERT INTO ab_test_variants (test_id, name, ratio, config) VALUES (?,?,?,?)`,
              [testId, v.name || '', Number(v.ratio) || 0, typeof v.config === 'string' ? v.config : JSON.stringify(v.config || {})]
            )
          }
        }
        res.json({ code: 200, msg: '创建成功', data: { id: testId } })
      }
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/ab-test/:id/start', authRequired, async (req, res) => {
    try {
      await query('UPDATE ab_tests SET status=\'running\', update_time=NOW() WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '测试已启动' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.post('/api/ab-test/:id/stop', authRequired, async (req, res) => {
    try {
      await query('UPDATE ab_tests SET status=\'stopped\', update_time=NOW() WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '测试已停止' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  router.delete('/api/ab-test/:id', authRequired, async (req, res) => {
    try {
      await query('DELETE FROM ab_test_variants WHERE test_id=?', [Number(req.params.id)])
      await query('DELETE FROM ab_tests WHERE id=?', [Number(req.params.id)])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = abTestRoutes
