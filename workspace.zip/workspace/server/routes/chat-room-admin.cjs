const { query } = require('../database.cjs')
const { authRequired } = require('./system.cjs')
const nowExpr = 'NOW()'

function chatRoomAdminRoutes(app) {

  // 获取加群申请列表
  app.get('/api/chat-rooms/:roomId/join-requests', authRequired, async (req, res) => {
    try {
      const rid = Number(req.params.roomId)
      if (!rid) return res.json({ code: 400, msg: '参数错误' })

      const list = await query(
        `SELECT id, user_id as userId, user_name as userName, user_avatar as userAvatar,
                reason, status, create_time as createTime
         FROM chat_room_join_requests
         WHERE room_id = ?
         ORDER BY id DESC`,
        [rid]
      )

      res.json({ code: 200, data: list })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 提交加群申请
  app.post('/api/chat-rooms/:roomId/join-requests', authRequired, async (req, res) => {
    try {
      const { reason } = req.body
      const rid = Number(req.params.roomId)
      const uid = req.user.userId
      const userName = req.user.userName || ''

      if (!rid || !uid) return res.json({ code: 400, msg: '参数错误' })

      const userInfo = await query('SELECT avatar FROM users WHERE id = ?', [uid])
      const userAvatar = (userInfo && userInfo.length) ? (userInfo[0].avatar || '') : ''

      const room = await query('SELECT id, status FROM chat_rooms WHERE id = ?', [rid])
      if (!room || !room.length) return res.json({ code: 404, msg: '聊天室不存在' })
      if (room[0].status !== 'active') return res.json({ code: 400, msg: '聊天室不可用' })

      const existing = await query(
        'SELECT id FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = ?',
        [rid, uid, 'active']
      )
      if (existing && existing.length) return res.json({ code: 400, msg: '你已在聊天室中' })

      const existingReq = await query(
        `SELECT id FROM chat_room_join_requests WHERE room_id = ? AND user_id = ? AND status = 'pending'`,
        [rid, uid]
      )
      if (existingReq && existingReq.length) return res.json({ code: 400, msg: '已提交申请，请等待审核' })

      await query(
        `INSERT INTO chat_room_join_requests (room_id, user_id, user_name, user_avatar, reason, status)
         VALUES (?, ?, ?, ?, ?, 'pending')`,
        [rid, uid, userName, userAvatar, reason || '']
      )

      res.json({ code: 200, msg: '申请已提交' })
    } catch (e) {
      res.serverError(e)
    }
  })

  // 审批加群申请
  app.put('/api/chat-rooms/:roomId/join-requests/:requestId', authRequired, async (req, res) => {
    try {
      const { status, reviewComment } = req.body
      const rid = Number(req.params.roomId)
      const requestId = Number(req.params.requestId)
      const uid = req.user.userId
      const userName = req.user.userName || ''

      if (!rid || !requestId) return res.json({ code: 400, msg: '参数错误' })
      if (!['approved', 'rejected'].includes(status)) return res.json({ code: 400, msg: '状态参数错误' })

      const member = await query(
        `SELECT role FROM chat_room_members WHERE room_id = ? AND user_id = ? AND status = 'active' AND role IN ('owner', 'admin')`,
        [rid, uid]
      )
      if (!member || !member.length) return res.json({ code: 403, msg: '仅群主或管理员可审批' })

      const request = await query(
        'SELECT * FROM chat_room_join_requests WHERE id = ? AND room_id = ?',
        [requestId, rid]
      )
      if (!request || !request.length) return res.json({ code: 404, msg: '申请不存在' })
      if (request[0].status !== 'pending') return res.json({ code: 400, msg: '该申请已处理' })

      await query(
        `UPDATE chat_room_join_requests SET status = ?, reviewed_by = ?, reviewed_name = ?, review_comment = ?, review_time = ${nowExpr}
         WHERE id = ?`,
        [status, uid, userName, reviewComment || '', requestId]
      )

      if (status === 'approved') {
        const targetUid = request[0].user_id
        const existingMember = await query(
          'SELECT id, status FROM chat_room_members WHERE room_id = ? AND user_id = ?',
          [rid, targetUid]
        )
        if (existingMember && existingMember.length) {
          if (existingMember[0].status !== 'active') {
            await query(
              `UPDATE chat_room_members SET status = 'active', join_time = ${nowExpr} WHERE id = ?`,
              [existingMember[0].id]
            )
          }
        } else {
          await query(
            `INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?, ?, 'member')`,
            [rid, targetUid]
          )
        }

        await query(
          `INSERT INTO chat_room_admin_logs (room_id, admin_id, admin_name, action, target_user_id, target_user_name, detail)
           VALUES (?, ?, ?, 'approve_join', ?, ?, ?)`,
          [rid, uid, userName, targetUid, request[0].user_name, '审核通过入群申请']
        )
      }

      res.json({ code: 200, msg: status === 'approved' ? '已通过申请' : '已拒绝申请' })
    } catch (e) {
      res.serverError(e)
    }
  })

}

module.exports = chatRoomAdminRoutes
