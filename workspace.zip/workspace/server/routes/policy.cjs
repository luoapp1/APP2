const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')

function policyRoutes(app) {
  // ============ 管理端 API ============

  app.get('/api/admin/policies', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const { type, status } = req.query
      let sql = 'SELECT * FROM policy_versions WHERE 1=1'
      const params = []
      if (type) { sql += ' AND type=?'; params.push(type) }
      if (status) { sql += ' AND status=?'; params.push(status) }
      sql += ' ORDER BY create_time DESC'
      const rows = await query(sql, params)
      res.json({ code: 200, data: rows })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/admin/policies/:id', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const rows = await query('SELECT * FROM policy_versions WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '未找到' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/admin/policies', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const { type, title, content } = req.body
      if (!type || !['privacy', 'agreement'].includes(type)) {
        return res.json({ code: 400, msg: 'type 必须为 privacy 或 agreement' })
      }
      const maxVer = await query('SELECT COALESCE(MAX(version),0) AS mv FROM policy_versions WHERE type=?', [type])
      const version = (maxVer[0].mv || 0) + 1
      const result = await query(
        'INSERT INTO policy_versions (type, title, content, version, status, created_by) VALUES (?,?,?,?,?,?)',
        [type, title || '', content || '', version, 'draft', req.userId || 0]
      )
      res.json({ code: 200, data: { id: result.insertId, version }, msg: '创建成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.put('/api/admin/policies/:id', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const { title, content } = req.body
      const rows = await query('SELECT * FROM policy_versions WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '未找到' })
      if (rows[0].status === 'published') return res.json({ code: 400, msg: '已发布的版本不可编辑，请创建新版本' })
      await query('UPDATE policy_versions SET title=?, content=?, update_time=NOW() WHERE id=?',
        [title || '', content || '', req.params.id])
      res.json({ code: 200, msg: '更新成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/admin/policies/:id/publish', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const rows = await query('SELECT * FROM policy_versions WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '未找到' })
      const policy = rows[0]
      await query('UPDATE policy_versions SET status=? WHERE type=? AND status=?', ['archived', policy.type, 'published'])
      await query('UPDATE policy_versions SET status=?, published_at=NOW() WHERE id=?', ['published', policy.id])
      const { invalidateSysConfig } = require('../utils/sys-config-cache.cjs')
      const key = policy.type === 'privacy' ? 'site_privacy_version' : 'site_agreement_version'
      await query("INSERT INTO sys_config (config_key, config_value, description) VALUES (?,?,?) ON DUPLICATE KEY UPDATE config_value=?, update_time=NOW()",
        [key, String(policy.version), policy.type + ' latest version', String(policy.version)])
      invalidateSysConfig()
      res.json({ code: 200, msg: '发布成功', data: { version: policy.version } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.delete('/api/admin/policies/:id', authRequired, requirePermission('admin'), async (req, res) => {
    try {
      const rows = await query('SELECT * FROM policy_versions WHERE id=?', [req.params.id])
      if (!rows.length) return res.json({ code: 404, msg: '未找到' })
      if (rows[0].status === 'published') return res.json({ code: 400, msg: '已发布的版本不可删除' })
      await query('DELETE FROM policy_versions WHERE id=?', [req.params.id])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  // ============ 用户端 API ============

  app.get('/api/policy/current', async (req, res) => {
    try {
      const { type } = req.query
      if (!type) return res.json({ code: 400, msg: '缺少 type 参数' })
      const rows = await query(
        'SELECT id, type, title, content, version, published_at FROM policy_versions WHERE type=? AND status=? ORDER BY version DESC LIMIT 1',
        [type, 'published']
      )
      if (!rows.length) return res.json({ code: 404, msg: '暂无发布版本' })
      res.json({ code: 200, data: rows[0] })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.get('/api/policy/check-consent', authRequired, async (req, res) => {
    try {
      const policies = await query(
        "SELECT type, MAX(version) AS version FROM policy_versions WHERE status='published' GROUP BY type"
      )
      const result = {}
      for (const p of policies) {
        const consented = await query(
          'SELECT id FROM user_policy_consents WHERE user_id=? AND policy_type=? AND policy_version>=?',
          [req.userId, p.type, p.version]
        )
        result[p.type] = {
          required_version: p.version,
          consented: consented.length > 0
        }
      }
      res.json({ code: 200, data: result })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/policy/consent', authRequired, async (req, res) => {
    try {
      const { type } = req.body
      if (!type || !['privacy', 'agreement'].includes(type)) {
        return res.json({ code: 400, msg: 'type 必须为 privacy 或 agreement' })
      }
      const rows = await query(
        "SELECT id, version FROM policy_versions WHERE type=? AND status='published' ORDER BY version DESC LIMIT 1",
        [type]
      )
      if (!rows.length) return res.json({ code: 404, msg: '暂无发布版本' })
      const policy = rows[0]
      await query(
        'INSERT INTO user_policy_consents (user_id, policy_type, policy_version_id, policy_version, ip) VALUES (?,?,?,?,?)',
        [req.userId, type, policy.id, policy.version, req.ip || '']
      )
      res.json({ code: 200, msg: '已同意', data: { type, version: policy.version } })
    } catch (e) {
      res.json({ code: 500, msg: e.message })
    }
  })
}

module.exports = policyRoutes
