const { query } = require('../database.cjs')
const {
  earnCurrency,
  spendCurrency,
  adminAdjustCurrency,
  getUserBalances,
  getCurrencyBalance,
} = require('./account-utils.cjs')

function currencyRoutes(app) {
  const { authRequired } = require('./system.cjs')

  const SYSTEM_DEFAULTS = [
    { currency_key: 'balance', display_name: '余额', display_icon: '', display_symbol: '￥', decimal_places: 2, sort_order: 1, currency_type: 'currency' },
    { currency_key: 'points', display_name: '积分', display_icon: '', display_symbol: '', decimal_places: 0, sort_order: 2, currency_type: 'currency' },
    { currency_key: 'experience', display_name: '经验', display_icon: '', display_symbol: '', decimal_places: 0, sort_order: 3, currency_type: 'currency' },
    { currency_key: 'makeup_count', display_name: '补签次数', display_icon: '', display_symbol: '', decimal_places: 0, sort_order: 4, currency_type: 'quota' },
    { currency_key: 'rename_count', display_name: '改名次数', display_icon: '', display_symbol: '', decimal_places: 0, sort_order: 5, currency_type: 'quota' },
  ]

  function ensureSystemCurrencies(rows) {
    const existing = new Set(rows.map(r => r.currency_key))
    const defaults = SYSTEM_DEFAULTS.filter(d => !existing.has(d.currency_key))
    return [...rows, ...defaults]
  }

  // 前台：获取所有可见货币配置
  app.get('/api/currency-settings', async (_req, res) => {
    try {
      const rows = await query(
        'SELECT currency_key, display_name, display_icon, display_symbol, decimal_places, sort_order, currency_type, card_color, account_prefix FROM currency_settings WHERE is_visible=1 ORDER BY sort_order'
      )
      res.json({ code: 200, data: ensureSystemCurrencies(rows) })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 管理端：获取所有货币配置（含隐藏）
  app.get('/api/admin/currency-settings', authRequired, async (_req, res) => {
    try {
      const rows = await query('SELECT * FROM currency_settings ORDER BY sort_order')
      res.json({ code: 200, data: ensureSystemCurrencies(rows) })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 管理端：更新货币配置
  app.put('/api/admin/currency-settings/:key', authRequired, async (req, res) => {
    try {
      const { key } = req.params
      const { display_name, display_icon, display_symbol, decimal_places, is_visible, is_exchangeable, currency_type, description, sort_order, card_color, account_prefix } = req.body
      const fields = []
      const values = []
      if (display_name !== undefined) { fields.push('display_name=?'); values.push(display_name) }
      if (display_icon !== undefined) { fields.push('display_icon=?'); values.push(display_icon) }
      if (display_symbol !== undefined) { fields.push('display_symbol=?'); values.push(display_symbol) }
      if (decimal_places !== undefined) { fields.push('decimal_places=?'); values.push(decimal_places) }
      if (is_visible !== undefined) { fields.push('is_visible=?'); values.push(is_visible) }
      if (is_exchangeable !== undefined) { fields.push('is_exchangeable=?'); values.push(is_exchangeable) }
      if (currency_type !== undefined) { fields.push('currency_type=?'); values.push(currency_type) }
      if (description !== undefined) { fields.push('description=?'); values.push(description) }
      if (sort_order !== undefined) { fields.push('sort_order=?'); values.push(sort_order) }
      if (card_color !== undefined) { fields.push('card_color=?'); values.push(card_color) }
      if (account_prefix !== undefined) { fields.push('account_prefix=?'); values.push(account_prefix) }
      if (fields.length === 0) return res.json({ code: 400, msg: '无更新字段' })
      fields.push('update_time=NOW()')
      values.push(key)
      await query(`UPDATE currency_settings SET ${fields.join(',')} WHERE currency_key=?`, values)
      const [updated] = await query('SELECT * FROM currency_settings WHERE currency_key=?', [key])
      res.json({ code: 200, data: updated })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 管理端：管理员调整用户货币余额
  // 管理端：创建新货币
  app.post('/api/admin/currency-settings', authRequired, async (req, res) => {
    try {
      const { currency_key, display_name, display_icon, display_symbol, decimal_places, is_visible, is_exchangeable, currency_type, description, sort_order, card_color, account_prefix } = req.body
      if (!currency_key || !display_name) return res.json({ code: 400, msg: '缺少 currency_key / display_name' })
      if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(currency_key)) return res.json({ code: 400, msg: 'currency_key 仅允许字母/数字/下划线，且不能以数字开头' })
      const [exists] = await query('SELECT id FROM currency_settings WHERE currency_key=?', [currency_key])
      if (exists) return res.json({ code: 400, msg: '该 currency_key 已存在' })
      await query(
        `INSERT INTO currency_settings (currency_key, display_name, display_icon, display_symbol, decimal_places, is_visible, is_exchangeable, currency_type, description, sort_order, card_color, account_prefix)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [currency_key, display_name, display_icon || '', display_symbol || '', decimal_places ?? 2, is_visible ?? 1, is_exchangeable ?? 0, currency_type ?? 'currency', description || '', sort_order ?? 99, card_color || '', account_prefix || '']
      )
      const [created] = await query('SELECT * FROM currency_settings WHERE currency_key=?', [currency_key])
      res.json({ code: 200, data: created })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 管理端：删除货币（系统保留货币不可删除）
  app.delete('/api/admin/currency-settings/:key', authRequired, async (req, res) => {
    try {
      const { key } = req.params
      const SYSTEM_CURRENCIES = ['balance', 'points', 'experience', 'makeup_count', 'rename_count']
      if (SYSTEM_CURRENCIES.includes(key)) return res.json({ code: 400, msg: '系统保留货币不可删除' })
      const [row] = await query('SELECT id FROM currency_settings WHERE currency_key=?', [key])
      if (!row) return res.json({ code: 400, msg: '货币不存在' })
      await query('DELETE FROM currency_settings WHERE currency_key=?', [key])
      res.json({ code: 200, msg: '删除成功' })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  app.post('/api/admin/currency/adjust', authRequired, async (req, res) => {
    try {
      const { user_id, currency_key, amount, description } = req.body
      if (!user_id || !currency_key || amount === undefined || amount === null) {
        return res.json({ code: 400, msg: '缺少 user_id / currency_key / amount' })
      }
      const [user] = await query('SELECT username FROM users WHERE id=?', [user_id])
      if (!user) return res.json({ code: 400, msg: '用户不存在' })
      const result = await adminAdjustCurrency(user_id, user.username, currency_key, Number(amount), 'admin', '', description || '管理员手动调整')
      res.json({ code: 200, data: result })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 用户：查询自己的余额
  app.get('/api/user/currency-balance', authRequired, async (req, res) => {
    try {
      let userId = req.user.userId
      const queryUserId = parseInt(req.query.userId)
      if (queryUserId && queryUserId !== userId) {
        const [u] = await query('SELECT roles FROM users WHERE id=?', [userId])
        const roles = (() => { try { return typeof u?.roles === 'string' ? JSON.parse(u.roles) : (u?.roles || []) } catch { return [] } })()
        if (roles.includes('admin') || roles.includes('R_SUPER')) userId = queryUserId
      }
      const currencies = await getUserBalances(userId)
      res.json({ code: 200, data: { currencies } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })

  // 用户：查询交易流水
  app.get('/api/user/currency-transactions', authRequired, async (req, res) => {
    try {
      const userId = req.user.userId
      const { currency_key, tx_type, page = 1, pageSize = 20 } = req.query
      let where = 'WHERE user_id = ?'
      const params = [userId]
      if (currency_key) { where += ' AND ct.currency_key = ?'; params.push(currency_key) }
      if (tx_type) { where += ' AND ct.tx_type = ?'; params.push(tx_type) }
      const [countRow] = await query(`SELECT COUNT(*) as total FROM currency_transactions ct ${where}`, params)
      const rows = await query(
        `SELECT ct.*, cs.display_name as currency_name FROM currency_transactions ct
         LEFT JOIN currency_settings cs ON cs.currency_key = ct.currency_key
         ${where} ORDER BY ct.create_time DESC LIMIT ? OFFSET ?`,
        [...params, Number(pageSize), (Number(page) - 1) * Number(pageSize)]
      )
      res.json({ code: 200, data: { list: rows, total: countRow.total, page: Number(page), pageSize: Number(pageSize) } })
    } catch (e) {
      res.status(500).json({ code: 500, msg: e.message })
    }
  })
}

module.exports = currencyRoutes
