const path = require('path')
const config = require('./config.cjs')

let pool
let tablesInitialized = false

function getPool() {
  if (pool) return pool

  const mysql = require('mysql2')
  const { host, port, user, password, database } = config.mysql
  pool = mysql.createPool({
    host, port, user, password, database,
    waitForConnections: true,
    connectionLimit: process.env.NODE_ENV === 'test' ? 5 : 25,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
    charset: 'utf8mb4',
    dateStrings: true
  })

  if (!tablesInitialized) {
    tablesInitialized = true
    initTables()
  }
  return pool
}

/**
 * Execute a SQL query and return results.
 *
 * **Return value format varies by SQL type:**
 * - SELECT / SHOW statements → returns the raw rows array from mysql2 (e.g., `[{ id: 1, name: 'foo' }, ...]`)
 * - INSERT / UPDATE / DELETE / REPLACE statements → returns `{ insertId: number, changes: number }`
 *   - `insertId` is the auto-increment ID for INSERT
 *   - `changes` is `affectedRows` for UPDATE/DELETE
 *
 * Example usage:
 * ```js
 * const rows = await query('SELECT * FROM users WHERE id=?', [1])   // rows is an array
 * const { insertId } = await query('INSERT INTO users (...) VALUES (...)', [...])
 * const { changes } = await query('UPDATE users SET ... WHERE id=?', [...])
 * ```
 *
 * @param {string} sql - SQL statement
 * @param {Array} [params=[]] - Query parameters
 * @returns {Promise<Array|{insertId: number, changes: number}>}
 */
function query(sql, params = []) {
  return getPool().promise().query(sql, params).then(([rows]) => {
    if (/^\s*SELECT|SHOW/i.test(sql)) return rows
    return { insertId: rows.insertId, changes: rows.affectedRows }
  })
}

function initTables() {
  const engine = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
  const autoInc = 'AUTO_INCREMENT'
  const now = 'NOW()'

  const tables = [
    `CREATE TABLE IF NOT EXISTS roles (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      role_name VARCHAR(100) NOT NULL,
      role_code VARCHAR(100) UNIQUE NOT NULL,
      description VARCHAR(500) DEFAULT '',
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS menus (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      parent_id INTEGER DEFAULT 0,
      name VARCHAR(100) NOT NULL,
      path VARCHAR(200) NOT NULL DEFAULT '',
      component VARCHAR(200) DEFAULT '',
      redirect VARCHAR(200) DEFAULT '',
      title VARCHAR(100) NOT NULL,
      icon VARCHAR(100) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      is_hidden TINYINT(1) DEFAULT 0,
      is_full_page TINYINT(1) DEFAULT 0,
      is_keep_alive TINYINT(1) DEFAULT 1,
      is_fixed_tab TINYINT(1) DEFAULT 0,
      auth_list TEXT,
      roles TEXT,
      enabled TINYINT(1) DEFAULT 1,
      mobile_path VARCHAR(200) DEFAULT '',
      icon_bg VARCHAR(20) DEFAULT '#4ECDC4',
      icon_svg TEXT,
      category VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS role_permissions (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      role_id INTEGER NOT NULL,
      menu_id INTEGER NOT NULL,
      auth_mark VARCHAR(100) DEFAULT '',
      UNIQUE(role_id, menu_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS membership_levels (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      tier INTEGER DEFAULT 1,
      parent_level_id INTEGER DEFAULT 0,
      price DECIMAL(10,2) DEFAULT 0,
      points_required INTEGER DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      points_multiplier DECIMAL(3,1) DEFAULT 1.0,
      points_discount_rate DECIMAL(3,1) DEFAULT 1.0,
      text_color VARCHAR(20) DEFAULT '#FFFFFF',
      bg_color VARCHAR(20) DEFAULT '#508DFF',
      benefits TEXT,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#909399',
      data_limit_mb INT DEFAULT 0,
      file_limit_mb INT DEFAULT 0,
      file_policy_ids TEXT,
      recycle_retention_days INT DEFAULT 0,
      gift_points INT DEFAULT 0,
      gift_balance DECIMAL(10,2) DEFAULT 0.00,
      gift_experience INT DEFAULT 0,
      gift_coupon_ids TEXT,
      perks TEXT,
      title_id INT DEFAULT 0,
      frame_id INT DEFAULT 0,
      daily_gift_enabled TINYINT(1) DEFAULT 0,
      daily_gift_interval_days INT DEFAULT 1,
      daily_gift_points INT DEFAULT 0,
      daily_gift_balance DECIMAL(10,2) DEFAULT 0.00,
      daily_gift_experience INT DEFAULT 0,
      daily_gift_coupon_ids TEXT,
      birthday_gift_points INT DEFAULT 0,
      birthday_gift_balance DECIMAL(10,2) DEFAULT 0.00,
      birthday_gift_experience INT DEFAULT 0,
      birthday_gift_coupon_ids TEXT,
      birthday_gift_makeup_count INT DEFAULT 0,
      daily_gift_makeup_count INT DEFAULT 0,
      gift_makeup_count INT DEFAULT 0,
      title_id INT DEFAULT 0,
      frame_id INT DEFAULT 0,
      auto_checkin TINYINT(1) DEFAULT 0,
      auto_checkin_time VARCHAR(5) DEFAULT '08:00',
      commission_rule_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // 迁移：会员等级自动签到字段
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS auto_checkin TINYINT(1) DEFAULT 0`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS auto_checkin_time VARCHAR(5) DEFAULT '08:00'`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS gift_makeup_count INT DEFAULT 0`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS daily_gift_makeup_count INT DEFAULT 0`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS birthday_gift_makeup_count INT DEFAULT 0`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS title_id INT DEFAULT 0`,
    `ALTER TABLE membership_levels ADD COLUMN IF NOT EXISTS frame_id INT DEFAULT 0`,

    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      username VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(200) NOT NULL,
      password_hash VARCHAR(200) DEFAULT '',
      phone VARCHAR(20) DEFAULT '',
      email VARCHAR(100) DEFAULT '',
      nickname VARCHAR(100) DEFAULT '',
      bio TEXT,
      balance DECIMAL(10,2) DEFAULT 0,
      experience INTEGER DEFAULT 0,
      gender VARCHAR(10) DEFAULT '男',
      avatar VARCHAR(500) DEFAULT '',
      bg_url VARCHAR(500) DEFAULT '',
      signature VARCHAR(300) DEFAULT '',
      qq VARCHAR(20) DEFAULT '',
      show_coin INTEGER DEFAULT 1,
      follow_count INTEGER DEFAULT 0,
      fans_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      points INTEGER DEFAULT 0,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '普通会员',
      expire_time DATETIME NULL,
      ban_until DATETIME NULL,
      is_verified TINYINT(1) DEFAULT 0,
      verified_org VARCHAR(200) DEFAULT '',
      active_title_id INTEGER DEFAULT 0,
      active_title_name VARCHAR(100) DEFAULT '',
      last_checkin_date DATE NULL,
      consecutive_checkins INTEGER DEFAULT 0,
      free_makeup_count INTEGER DEFAULT 0,
      referrer_id INTEGER DEFAULT 0,
      referrer_code VARCHAR(32) DEFAULT '',
      age INT DEFAULT 0,
      birthday DATE NULL,
      hide_birthday TINYINT(1) DEFAULT 0,
      hide_qq TINYINT(1) DEFAULT 0,
      hide_email TINYINT(1) DEFAULT 0,
      hide_address TINYINT(1) DEFAULT 0,
      register_address VARCHAR(200) DEFAULT '',
      reg_ip VARCHAR(45) DEFAULT '',
      deleted_at DATETIME NULL,
      roles TEXT,
      used_bytes BIGINT DEFAULT 0,
      bonus_data_limit_mb INT DEFAULT 0,
      bonus_file_limit_mb INT DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // 迁移：给 users 加 reg_ip 字段
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS reg_ip VARCHAR(45) DEFAULT ''`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS active_avatar_effect_id INT DEFAULT 0`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS active_comment_background_id INT DEFAULT 0`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS active_nickname_effect_id INT DEFAULT 0`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS active_home_bg_id INT DEFAULT 0`,

    `CREATE TABLE IF NOT EXISTS card_keys (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      card_no VARCHAR(100) UNIQUE NOT NULL,
      password VARCHAR(100) NOT NULL,
      type VARCHAR(20) NOT NULL DEFAULT 'membership',
      target_id INTEGER DEFAULT 0,
      target_name VARCHAR(100) DEFAULT '',
      value INTEGER DEFAULT 0,
      extra_points INTEGER DEFAULT 0,
      extra_experience INTEGER DEFAULT 0,
      extra_balance DECIMAL(10,2) DEFAULT 0,
      duration INTEGER DEFAULT 0,
      duration_unit VARCHAR(10) DEFAULT '',
      status VARCHAR(2) DEFAULT '0',
      create_by VARCHAR(100) DEFAULT '管理员',
      create_time DATETIME DEFAULT NOW(),
      redeem_by VARCHAR(100) DEFAULT '',
      redeem_time DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS points_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'earn',
      points INTEGER NOT NULL DEFAULT 0,
      balance INTEGER DEFAULT 0,
      source VARCHAR(200) DEFAULT '',
      description TEXT,
      ref_id INTEGER DEFAULT 0,
      ref_type VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS experience_levels (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      level INTEGER NOT NULL DEFAULT 0,
      exp_required INTEGER NOT NULL DEFAULT 0,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#00BFA5',
      text_color VARCHAR(20) DEFAULT '#FFFFFF',
      bg_color VARCHAR(20) DEFAULT '#508DFF',
      benefits TEXT,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_experience_gift_claims (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      level_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uk_user_level (user_id, level_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_experience_daily_claims (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      level_id INTEGER NOT NULL,
      claim_date DATE NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uk_user_level_date (user_id, level_id, claim_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS plugins (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      description TEXT,
      version VARCHAR(50) DEFAULT '1.0.0',
      author VARCHAR(100) DEFAULT '',
      icon VARCHAR(500) DEFAULT '',
      entry_url VARCHAR(500) DEFAULT '',
      component_name VARCHAR(200) DEFAULT '',
      plugin_dir VARCHAR(100) DEFAULT '',
      manifest TEXT,
      enabled INTEGER DEFAULT 1,
      sort_order INTEGER DEFAULT 0,
      points INTEGER DEFAULT 0,
      points_name VARCHAR(20) DEFAULT '金币',
      tags TEXT,
      format VARCHAR(20) DEFAULT 'package',
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_store (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      description TEXT,
      update_content TEXT,
      screenshots TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      developer VARCHAR(100) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      categories TEXT,
      category_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      is_pinned TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      official_tags TEXT,
      content_permission VARCHAR(20) DEFAULT 'public',
      content_price DECIMAL(10,2) DEFAULT 0,
      content_price_type VARCHAR(20) DEFAULT 'free',
      access_password VARCHAR(100) DEFAULT '',
      access_password_tips VARCHAR(500) DEFAULT '',
      is_featured TINYINT(1) DEFAULT 0,
      is_official TINYINT(1) DEFAULT 0,
      has_ads INTEGER DEFAULT 0,
      requires_network INTEGER DEFAULT 1,
      has_paid_content INTEGER DEFAULT 0,
      is_free INTEGER DEFAULT 1,
      price_type VARCHAR(20) DEFAULT 'free',
      price_amount DECIMAL(10,2) DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_comments (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      app_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(20) DEFAULT '#FF5777',
      device VARCHAR(200) DEFAULT '',
      version VARCHAR(50) DEFAULT '',
      content TEXT,
      likes INTEGER DEFAULT 0,
      replies INTEGER DEFAULT 0,
      reported INTEGER DEFAULT 0,
      is_pinned TINYINT(1) DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_versions (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      app_id INTEGER NOT NULL,
      version VARCHAR(50) NOT NULL,
      version_code VARCHAR(50) DEFAULT '',
      size_mb DECIMAL(10,1) DEFAULT 0,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      update_content TEXT,
      tags TEXT,
      download_url VARCHAR(500) DEFAULT '',
      is_current TINYINT(1) DEFAULT 0,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      official_tags TEXT,
      description TEXT,
      screenshots TEXT,
      has_ads INTEGER DEFAULT 0,
      has_paid_content INTEGER DEFAULT 0,
      is_free INTEGER DEFAULT 1,
      requires_network INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_uploads (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      app_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      name VARCHAR(200) NOT NULL,
      package_name VARCHAR(200) DEFAULT '',
      category VARCHAR(100) DEFAULT '工具',
      description TEXT,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      version VARCHAR(50) DEFAULT '1.0.0',
      version_code VARCHAR(50) DEFAULT '100',
      size_mb DECIMAL(10,1) DEFAULT 0,
      download_url VARCHAR(500) DEFAULT '',
      screenshots TEXT,
      tags TEXT,
      version_type VARCHAR(20) DEFAULT '',
      has_ads INTEGER DEFAULT 0,
      requires_network INTEGER DEFAULT 1,
      has_paid_content INTEGER DEFAULT 0,
      is_free INTEGER DEFAULT 1,
      downloads INTEGER DEFAULT 0,
      rating DECIMAL(2,1) DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      coin_people INTEGER DEFAULT 0,
      review_count INTEGER DEFAULT 0,
      five_star_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '0',
      submission_status VARCHAR(20) DEFAULT 'draft',
      review_comment TEXT,
      review_by VARCHAR(100) DEFAULT '',
      review_time DATETIME NULL,
      price_type VARCHAR(20) DEFAULT 'free',
      price_amount DECIMAL(10,2) DEFAULT 0,
      official_tags TEXT,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // Migration: ZIP resource submission fields
    `ALTER TABLE app_uploads ADD COLUMN IF NOT EXISTS type VARCHAR(10) DEFAULT 'apk'`,
    `ALTER TABLE app_uploads ADD COLUMN IF NOT EXISTS resource_zip_url VARCHAR(500) DEFAULT ''`,

    `CREATE TABLE IF NOT EXISTS app_categories (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(64) NOT NULL,
      icon VARCHAR(255) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status CHAR(1) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_tips (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(64) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      tip_type VARCHAR(20) DEFAULT 'balance',
      message VARCHAR(255) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
 
    `CREATE TABLE IF NOT EXISTS comment_likes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      comment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      UNIQUE(comment_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_official_tags (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(64) NOT NULL,
      color VARCHAR(20) DEFAULT '#2563eb',
      bg_color VARCHAR(20) DEFAULT '#dbeafe',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sys_notifications (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      title VARCHAR(200) NOT NULL,
      content TEXT DEFAULT '',
      type VARCHAR(20) DEFAULT 'system',
      target_user_id INTEGER DEFAULT 0,
      from_user_id INTEGER DEFAULT 0,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(200) DEFAULT '',
      is_read TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS private_messages (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(500) DEFAULT '#448AFF',
      to_user_id INTEGER NOT NULL,
      content TEXT DEFAULT '',
      image_url VARCHAR(500) DEFAULT '',
      message_type VARCHAR(20) DEFAULT 'text',
      order_card TEXT,
      is_read TINYINT(1) DEFAULT 0,
      is_recalled TINYINT(1) DEFAULT 0,
      report_status VARCHAR(20) DEFAULT 'none',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS hidden_conversations (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      partner_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, partner_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_purchases (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      app_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      price_type VARCHAR(20) DEFAULT 'free',
      original_price DECIMAL(10,2) DEFAULT 0,
      paid_price DECIMAL(10,2) DEFAULT 0,
      discount_rate DECIMAL(3,1) DEFAULT 1.0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sessions (
      token VARCHAR(100) PRIMARY KEY,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) NOT NULL,
      roles TEXT DEFAULT '[]',
      created_at INTEGER NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_attach_purchases (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      attach_url VARCHAR(500) NOT NULL DEFAULT '',
      coin_type VARCHAR(20) NOT NULL DEFAULT 'coin',
      coin_amount INTEGER NOT NULL DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_sections (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      icon_bg_color VARCHAR(20) DEFAULT '#00BFA5',
      description TEXT DEFAULT '',
      today_heat INTEGER DEFAULT 0,
      total_heat INTEGER DEFAULT 0,
      post_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'active',
      visibility VARCHAR(20) DEFAULT 'public',
      post_permission VARCHAR(20) DEFAULT 'all',
      view_permission VARCHAR(20) DEFAULT 'all',
      view_level_required INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_posts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      section_id INTEGER NOT NULL DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      title VARCHAR(500) DEFAULT '',
      content LONGTEXT DEFAULT '',
      device VARCHAR(100) DEFAULT '',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      images LONGTEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      is_pinned INTEGER DEFAULT 0,
      is_essence INTEGER DEFAULT 0,
      is_hot INTEGER DEFAULT 0,
      hot_manually_disabled TINYINT(1) DEFAULT 0,
      is_global_pinned TINYINT(1) DEFAULT 0,
      custom_badge VARCHAR(50) DEFAULT '',
      status VARCHAR(20) DEFAULT 'published',
      like_count INTEGER DEFAULT 0,
      comment_count INTEGER DEFAULT 0,
      coin_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      favorite_count INTEGER DEFAULT 0,
      topic_id INTEGER DEFAULT 0,
      content_permission VARCHAR(20) DEFAULT 'public',
      content_price DECIMAL(10,2) DEFAULT 0,
      content_price_type VARCHAR(20) DEFAULT 'free',
      access_password VARCHAR(100) DEFAULT '',
      access_password_tips VARCHAR(500) DEFAULT '',
      cover_url VARCHAR(500) DEFAULT '',
      is_edited INTEGER DEFAULT 0,
      edited_at DATETIME NULL,
      avatar_frame VARCHAR(500) DEFAULT '',
      name_color VARCHAR(20) DEFAULT '',
      is_anonymous INTEGER DEFAULT 0,
      is_deleted TINYINT(1) DEFAULT 0,
      deleted_at DATETIME NULL,
      edition INTEGER DEFAULT 1,
      community_id INTEGER DEFAULT 0,
      community_name VARCHAR(100) DEFAULT '',
      community_icon VARCHAR(500) DEFAULT '',
      review_status VARCHAR(20) DEFAULT 'approved',
      reviewed_at DATETIME NULL,
      reviewed_by VARCHAR(100) DEFAULT '',
      review_reason TEXT,
      reject_reason TEXT,
      locked INTEGER DEFAULT 0,
      is_locked INTEGER DEFAULT 0,
      locked_at DATETIME NULL,
      locked_by INTEGER DEFAULT 0,
      locked_reason VARCHAR(500) DEFAULT '',
      share_count INTEGER DEFAULT 0,
      content_type VARCHAR(20) DEFAULT 'text',
      attachment_urls TEXT,
      hidden_content TEXT,
      hidden_attachment_urls TEXT,
      free_read INTEGER DEFAULT 0,
      free_count INTEGER DEFAULT 500,
      cover_width INTEGER DEFAULT 0,
      cover_height INTEGER DEFAULT 0,
      duration_us INTEGER DEFAULT 0,
      size_mb DECIMAL(10,2) DEFAULT 0,
      mime_type VARCHAR(100) DEFAULT '',
      voice_url VARCHAR(500) DEFAULT '',
      voice_duration INTEGER DEFAULT 0,
      video_width INTEGER DEFAULT 0,
      video_height INTEGER DEFAULT 0,
      original_lang VARCHAR(10) DEFAULT '',
      translations TEXT,
      is_sticky_global TINYINT(1) DEFAULT 0,
      sticky_order INTEGER DEFAULT 0,
      sticky_section_id INTEGER DEFAULT 0,
      sticky_until DATETIME NULL,
      post_uid VARCHAR(36) DEFAULT '',
      summary VARCHAR(200) DEFAULT '',
      sort_weight DECIMAL(10,2) DEFAULT 0,
      scheduled_time DATETIME DEFAULT NULL,
      auto_hide_at DATETIME NULL,
      is_hidden TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_comments (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      parent_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      content TEXT NOT NULL,
      images TEXT DEFAULT '[]',
      like_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_likes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(post_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_favorites (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(post_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_drafts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      section_id INTEGER DEFAULT 0,
      title VARCHAR(500) DEFAULT '',
      content TEXT DEFAULT '',
      images TEXT DEFAULT '[]',
      tags TEXT DEFAULT '[]',
      official_tags TEXT DEFAULT '[]',
      has_resource INTEGER DEFAULT 0,
      resource_type VARCHAR(20) DEFAULT '',
      resource_url TEXT DEFAULT '',
      resource_price REAL DEFAULT 0,
      resource_price_type VARCHAR(20) DEFAULT 'free',
      extract_code VARCHAR(100) DEFAULT '',
      permission VARCHAR(20) DEFAULT 'public',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_collections (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      title VARCHAR(200) NOT NULL,
      description TEXT DEFAULT '',
      cover_image VARCHAR(500) DEFAULT '',
      post_count INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'draft',
      is_paid TINYINT(1) DEFAULT 0,
      price_balance DECIMAL(10,2) DEFAULT 0,
      price_points INTEGER DEFAULT 0,
      preview_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      subscribe_count INTEGER DEFAULT 0,
      sort_mode VARCHAR(20) DEFAULT 'manual',
      section_id INTEGER DEFAULT 0,
      is_deleted TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_collection_posts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      collection_id INTEGER NOT NULL,
      post_id INTEGER NOT NULL,
      sort_order INTEGER DEFAULT 0,
      is_preview TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(post_id),
      UNIQUE(collection_id, post_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_paid_collections (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      collection_id INTEGER NOT NULL,
      amount DECIMAL(10,2) DEFAULT 0,
      pay_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, collection_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_banned_users (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL UNIQUE,
      user_name VARCHAR(100) DEFAULT '',
      reason VARCHAR(500) DEFAULT '',
      banned_until DATETIME DEFAULT NULL,
      is_active TINYINT DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_coin_logs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(500) DEFAULT '',
      to_user_id INTEGER NOT NULL DEFAULT 0,
      amount INTEGER DEFAULT 0,
      coin_type VARCHAR(20) DEFAULT 'coin',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_moderators (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      section_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      role VARCHAR(20) DEFAULT '版主',
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(section_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_topics (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      description TEXT DEFAULT '',
      creator_id INTEGER DEFAULT 0,
      creator_name VARCHAR(100) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      post_count INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_post_topics (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      topic_id INTEGER NOT NULL,
      UNIQUE(post_id, topic_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_reports (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      reporter_id INTEGER NOT NULL,
      reporter_name VARCHAR(100) DEFAULT '',
      target_type VARCHAR(20) NOT NULL,
      target_id INTEGER NOT NULL,
      report_reason VARCHAR(100) DEFAULT '其他',
      report_detail TEXT,
      status VARCHAR(20) DEFAULT 'pending',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS community_unlock_requests (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      reason TEXT,
      status VARCHAR(20) DEFAULT 'pending',
      admin_reply VARCHAR(500) DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS avatar_frames (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      image_url VARCHAR(500) DEFAULT '',
      thumbnail_url VARCHAR(500) DEFAULT '',
      description VARCHAR(500) DEFAULT '',
      obtain_type VARCHAR(20) DEFAULT 'manual',
      exp_level_required INTEGER DEFAULT 0,
      member_level_required INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_follows (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      follower_id INTEGER NOT NULL,
      following_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(follower_id, following_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS custom_titles (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      color VARCHAR(20) DEFAULT '#409EFF',
      bg_color VARCHAR(20) DEFAULT '#ecf5ff',
      description VARCHAR(500) DEFAULT '',
      condition_type VARCHAR(20) DEFAULT 'manual',
      condition_value VARCHAR(200) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_titles (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      title_id INTEGER NOT NULL,
      is_active TINYINT(1) DEFAULT 1,
      grant_by VARCHAR(100) DEFAULT '',
      grant_time DATETIME DEFAULT NOW(),
      expire_time DATETIME NULL,
      UNIQUE(user_id, title_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS verification_requests (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      real_name VARCHAR(100) DEFAULT '',
      id_card VARCHAR(50) DEFAULT '',
      organization VARCHAR(200) DEFAULT '',
      reason TEXT,
      proof_urls TEXT,
      status VARCHAR(20) DEFAULT 'pending',
      review_comment TEXT,
      review_by VARCHAR(100) DEFAULT '',
      review_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS checkin_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      checkin_date DATE NOT NULL,
      consecutive_days INTEGER DEFAULT 1,
      points_earned INTEGER DEFAULT 0,
      experience_earned INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, checkin_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS email_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      host VARCHAR(200) NOT NULL DEFAULT '',
      port INTEGER NOT NULL DEFAULT 465,
      secure TINYINT(1) DEFAULT 1,
      user VARCHAR(200) NOT NULL DEFAULT '',
      password VARCHAR(200) NOT NULL DEFAULT '',
      from_name VARCHAR(100) DEFAULT '',
      from_address VARCHAR(200) DEFAULT '',
      test_address VARCHAR(200) DEFAULT '',
      register_verify TINYINT(1) DEFAULT 0,
      enabled TINYINT(1) DEFAULT 1,
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS email_verifications (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      email VARCHAR(200) NOT NULL,
      code VARCHAR(10) NOT NULL,
      type VARCHAR(20) DEFAULT 'register',
      used TINYINT(1) DEFAULT 0,
      expires_at DATETIME NOT NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sms_verifications (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      phone VARCHAR(20) NOT NULL,
      code VARCHAR(10) NOT NULL,
      type VARCHAR(20) DEFAULT 'register',
      used TINYINT(1) DEFAULT 0,
      expires_at DATETIME NOT NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sms_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) DEFAULT '' COMMENT '配置名称',
      provider VARCHAR(50) NOT NULL COMMENT '短信服务商',
      config_json TEXT DEFAULT '{}' COMMENT '服务商配置JSON',
      sign_name VARCHAR(100) DEFAULT '' COMMENT '短信签名',
      template_code VARCHAR(50) DEFAULT '' COMMENT '短信模板代码',
      enabled TINYINT(1) DEFAULT 1,
      is_default TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS invite_codes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      code VARCHAR(20) UNIQUE NOT NULL,
      created_by INTEGER DEFAULT 0,
      created_by_name VARCHAR(100) DEFAULT '',
      created_by_user_id INTEGER DEFAULT 0,
      used_by INTEGER DEFAULT 0,
      used_by_name VARCHAR(100) DEFAULT '',
      max_uses INTEGER DEFAULT 1,
      use_count INTEGER DEFAULT 0,
      type VARCHAR(50) DEFAULT 'one_time',
      reward_type VARCHAR(50) DEFAULT '',
      reward_value INTEGER DEFAULT 0,
      reward_duration INTEGER DEFAULT 0,
      reward_duration_unit VARCHAR(10) DEFAULT 'day',
      reward_target_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      used_at DATETIME NULL,
      expires_at DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS balance_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'earn',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      balance DECIMAL(10,2) DEFAULT 0,
      source VARCHAR(200) DEFAULT '',
      description TEXT,
      ref_id INTEGER DEFAULT 0,
      ref_type VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS file_repository (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT '',
      file_name VARCHAR(500) NOT NULL,
      file_path VARCHAR(500) NOT NULL,
      file_size BIGINT DEFAULT 0,
      file_type VARCHAR(100) DEFAULT '',
      mime_type VARCHAR(200) DEFAULT '',
      category VARCHAR(50) DEFAULT 'other',
      ref_id INTEGER DEFAULT 0,
      ref_type VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS recycle_bin (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      original_table VARCHAR(100) NOT NULL,
      original_id INTEGER NOT NULL,
      data_json TEXT NOT NULL,
      deleted_by INTEGER DEFAULT 0,
      deleted_by_name VARCHAR(100) DEFAULT '',
      delete_reason VARCHAR(500) DEFAULT '',
      user_level_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS system_logs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER DEFAULT 0,
      user_name VARCHAR(100) DEFAULT 'system',
      type VARCHAR(30) NOT NULL,
      target_type VARCHAR(50) DEFAULT '',
      target_id INTEGER DEFAULT 0,
      detail TEXT DEFAULT '',
      ip VARCHAR(50) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS custom_tasks (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      description TEXT DEFAULT '',
      icon VARCHAR(500) DEFAULT '',
      task_type VARCHAR(30) NOT NULL DEFAULT 'daily',
      action_type VARCHAR(30) NOT NULL DEFAULT 'post',
      target_count INTEGER DEFAULT 1,
      section_id INTEGER DEFAULT 0,
      section_limit INTEGER DEFAULT 0,
      points_reward INTEGER DEFAULT 0,
      exp_reward INTEGER DEFAULT 0,
      balance_reward DECIMAL(10,2) DEFAULT 0,
      card_key_type VARCHAR(20) DEFAULT '',
      card_key_value INTEGER DEFAULT 0,
      card_key_duration INTEGER DEFAULT 0,
      title_id INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS task_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      task_id INTEGER NOT NULL,
      task_name VARCHAR(200) DEFAULT '',
      progress INTEGER DEFAULT 0,
      target_count INTEGER DEFAULT 1,
      status VARCHAR(20) DEFAULT 'pending',
      completed_at DATETIME NULL,
      period_key VARCHAR(20) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS browse_history (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      item_type VARCHAR(10) NOT NULL,
      item_id INTEGER NOT NULL,
      item_title VARCHAR(300) DEFAULT '',
      item_cover VARCHAR(500) DEFAULT '',
      item_url VARCHAR(500) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_favorites (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      app_id INTEGER NOT NULL,
      group_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, app_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_favorite_groups (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      name VARCHAR(100) NOT NULL DEFAULT '默认收藏夹',
      sort_order INTEGER DEFAULT 0,
      is_public TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_favorite_group_follows (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      group_id INTEGER NOT NULL,
      follower_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uk_af_group_follower (group_id, follower_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS post_favorites (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      post_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, post_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sys_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      config_key VARCHAR(100) UNIQUE NOT NULL,
      config_value TEXT DEFAULT '',
      description VARCHAR(200) DEFAULT '',
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS commission_rules (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) DEFAULT '',
      order_type VARCHAR(30) DEFAULT 'all',
      rate DECIMAL(5,2) DEFAULT 0,
      points_rate DECIMAL(5,2) DEFAULT 0,
      reward_type VARCHAR(20) DEFAULT 'balance',
      user_level_id INTEGER DEFAULT 0,
      user_level_name VARCHAR(100) DEFAULT '',
      user_id INTEGER DEFAULT 0,
      invite_code_id INTEGER DEFAULT 0,
      invite_code_type VARCHAR(20) DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      level INTEGER DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS commission_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_id INTEGER DEFAULT 0,
      order_type VARCHAR(30) DEFAULT '',
      order_amount DECIMAL(10,2) DEFAULT 0,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      referrer_id INTEGER NOT NULL,
      referrer_name VARCHAR(100) DEFAULT '',
      rate DECIMAL(5,2) DEFAULT 0,
      level INTEGER DEFAULT 1,
      reward_type VARCHAR(20) DEFAULT 'balance',
      amount DECIMAL(10,2) DEFAULT 0,
      points_amount DECIMAL(10,2) DEFAULT 0,
      status VARCHAR(20) DEFAULT 'pending',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS withdraw_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL,
      method VARCHAR(30) DEFAULT 'alipay',
      account VARCHAR(200) DEFAULT '',
      real_name VARCHAR(50) DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      remark TEXT DEFAULT '',
      reviewed_by INTEGER DEFAULT 0,
      reviewed_by_name VARCHAR(100) DEFAULT '',
      reviewed_at DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_codes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      code VARCHAR(32) UNIQUE NOT NULL,
      label VARCHAR(100) DEFAULT '',
      max_uses INTEGER DEFAULT 0,
      used_count INTEGER DEFAULT 0,
      click_count INTEGER DEFAULT 0,
      register_count INTEGER DEFAULT 0,
      auto_generated TINYINT(1) DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      reward_type VARCHAR(50) DEFAULT '',
      reward_value VARCHAR(100) DEFAULT '',
      reward_duration INTEGER DEFAULT 0,
      reward_target_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      INDEX idx_user_id (user_id),
      INDEX idx_code (code)
    )${engine}`,
    `CREATE TABLE IF NOT EXISTS referral_links (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL UNIQUE,
      code VARCHAR(32) UNIQUE NOT NULL,
      mode VARCHAR(20) DEFAULT 'purchase',
      discount DECIMAL(5,2) DEFAULT 0,
      click_count INTEGER DEFAULT 0,
      register_count INTEGER DEFAULT 0,
      purchase_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS points_transfer_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      to_user_id INTEGER NOT NULL,
      to_user_name VARCHAR(100) DEFAULT '',
      amount INTEGER NOT NULL DEFAULT 0,
      fee INTEGER DEFAULT 0,
      remark VARCHAR(300) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS balance_transfer_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      to_user_id INTEGER NOT NULL,
      to_user_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      fee DECIMAL(10,2) DEFAULT 0,
      remark VARCHAR(300) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS file_policies (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) DEFAULT '',
      user_level_id INTEGER DEFAULT 0,
      user_level_name VARCHAR(100) DEFAULT '',
      role_code VARCHAR(100) DEFAULT '',
      user_id INTEGER DEFAULT 0,
      max_file_size_mb INTEGER DEFAULT 10,
      allowed_types TEXT DEFAULT '',
      banned_types TEXT DEFAULT '',
      status VARCHAR(2) DEFAULT '1',
      image_compress_enabled TINYINT(1) DEFAULT 0,
      image_max_width INT DEFAULT 1200,
      image_max_height INT DEFAULT 0,
      image_quality DECIMAL(3,1) DEFAULT 0.8,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS membership_products (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      level_id INTEGER NOT NULL DEFAULT 0,
      name VARCHAR(100) DEFAULT '',
      price DECIMAL(10,2) DEFAULT 0,
      original_price DECIMAL(10,2) DEFAULT 0,
      points_price DECIMAL(10,2) DEFAULT 0,
      points_original_price DECIMAL(10,2) DEFAULT 0,
      duration_days INTEGER DEFAULT 30,
      is_promo TINYINT(1) DEFAULT 0,
      promo_end_time DATETIME NULL,
      gift_points INT DEFAULT 0,
      gift_balance DECIMAL(10,2) DEFAULT 0.00,
      gift_experience INT DEFAULT 0,
      gift_coupon_ids TEXT,
      gift_data_limit_mb INT DEFAULT 0,
      gift_file_limit_mb INT DEFAULT 0,
      purchase_limit INT DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS membership_purchases (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      product_id INTEGER DEFAULT 0,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '',
      amount DECIMAL(10,2) DEFAULT 0,
      pay_type VARCHAR(20) DEFAULT 'balance',
      purchase_type VARCHAR(20) DEFAULT 'buy',
      duration_days INTEGER DEFAULT 0,
      expire_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_gift_claims (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      level_id INTEGER NOT NULL,
      gift_type VARCHAR(20) NOT NULL,
      claim_date DATE NOT NULL,
      claim_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uix_user_level_type_date (user_id, level_id, gift_type, claim_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS content_purchases (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      content_type VARCHAR(20) DEFAULT 'post',
      content_id INTEGER NOT NULL,
      author_id INTEGER DEFAULT 0,
      amount DECIMAL(10,2) DEFAULT 0,
      pay_type VARCHAR(20) DEFAULT 'balance',
      commission_amount DECIMAL(10,2) DEFAULT 0,
      commission_rate DECIMAL(5,2) DEFAULT 0,
      block_index INTEGER DEFAULT -1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS content_access_passwords (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      content_type VARCHAR(20) DEFAULT 'post',
      content_id INTEGER NOT NULL,
      password VARCHAR(100) NOT NULL,
      tips VARCHAR(200) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_delete_requests (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      username VARCHAR(100) DEFAULT '',
      admin_id INTEGER DEFAULT 0,
      admin_note VARCHAR(500) DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_appeals (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      username VARCHAR(100) DEFAULT '',
      reason TEXT,
      status VARCHAR(20) DEFAULT 'pending',
      admin_id INTEGER DEFAULT 0,
      admin_note VARCHAR(500) DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      review_time DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS checkin_groups (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      level_id INTEGER DEFAULT 0,
      icon VARCHAR(100) DEFAULT '',
      icon_color VARCHAR(20) DEFAULT '#409EFF',
      points INTEGER DEFAULT 5,
      experience INTEGER DEFAULT 2,
      balance DECIMAL(10,2) DEFAULT 0,
      points_consecutive INTEGER DEFAULT 2,
      experience_consecutive INTEGER DEFAULT 1,
      balance_consecutive DECIMAL(10,2) DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS checkin_milestones (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      group_id INTEGER NOT NULL DEFAULT 0,
      days INTEGER NOT NULL DEFAULT 3,
      points INTEGER DEFAULT 0,
      experience INTEGER DEFAULT 0,
      balance DECIMAL(10,2) DEFAULT 0,
      card_key_type VARCHAR(20) DEFAULT '',
      card_key_value INTEGER DEFAULT 0,
      card_key_duration INTEGER DEFAULT 0,
      card_key_duration_unit VARCHAR(10) DEFAULT '',
      card_key_extra_points INTEGER DEFAULT 0,
      card_key_extra_experience INTEGER DEFAULT 0,
      card_key_extra_balance DECIMAL(10,2) DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS experience_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      amount INTEGER NOT NULL DEFAULT 0,
      type VARCHAR(10) DEFAULT 'earn',
      source VARCHAR(100) DEFAULT '',
      description VARCHAR(500) DEFAULT '',
      task_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_violation_counts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      task_id INTEGER NOT NULL,
      count INTEGER DEFAULT 0,
      last_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uk_user_task (user_id, task_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS coupons (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      description TEXT DEFAULT '',
      type VARCHAR(20) NOT NULL DEFAULT 'fixed',
      value DECIMAL(10,2) NOT NULL DEFAULT 0,
      min_order DECIMAL(10,2) NOT NULL DEFAULT 0,
      max_discount DECIMAL(10,2) DEFAULT 0,
      scope VARCHAR(20) NOT NULL DEFAULT 'all',
      target_ids TEXT DEFAULT '',
      target_names TEXT DEFAULT '',
      total_count INTEGER DEFAULT 0,
      claimed_count INTEGER NOT NULL DEFAULT 0,
      per_user_limit INTEGER NOT NULL DEFAULT 1,
      start_time DATETIME DEFAULT NULL,
      expire_time DATETIME DEFAULT NULL,
      valid_days INTEGER DEFAULT 0,
      category VARCHAR(20) DEFAULT 'general',
      is_recommend TINYINT(1) DEFAULT 0,
      is_new_user TINYINT(1) DEFAULT 0,
      is_rush TINYINT(1) DEFAULT 0,
      required_level_ids TEXT DEFAULT '',
      required_level_names TEXT DEFAULT '',
      is_multi_use TINYINT(1) DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_coupons (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      coupon_id INTEGER NOT NULL,
      status VARCHAR(10) NOT NULL DEFAULT 'unused',
      coupon_data TEXT NOT NULL,
      expire_time DATETIME NOT NULL,
      use_time DATETIME DEFAULT NULL,
      use_scene VARCHAR(50) DEFAULT '',
      use_order_id INTEGER DEFAULT 0,
      use_amount DECIMAL(10,2) DEFAULT 0,
      remaining_value DECIMAL(10,2) DEFAULT NULL,
      receive_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS coupon_usage_logs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_coupon_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      coupon_id INTEGER NOT NULL,
      coupon_name VARCHAR(200) DEFAULT '',
      use_scene VARCHAR(50) DEFAULT '',
      use_amount DECIMAL(10,2) DEFAULT 0,
      before_remaining DECIMAL(10,2) DEFAULT NULL,
      after_remaining DECIMAL(10,2) DEFAULT NULL,
      order_desc VARCHAR(500) DEFAULT '',
      use_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // ===== SETTLEMENT SYSTEM (pinduoduo-style) =====
    `CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_no VARCHAR(50) NOT NULL UNIQUE,
      buyer_id INTEGER NOT NULL,
      buyer_name VARCHAR(100) DEFAULT '',
      seller_id INTEGER DEFAULT 0,
      seller_name VARCHAR(100) DEFAULT '',
      order_type VARCHAR(30) NOT NULL,
      order_desc VARCHAR(500) DEFAULT '',
      ref_id INTEGER DEFAULT 0,
      ref_table VARCHAR(50) DEFAULT '',
      pay_type VARCHAR(20) DEFAULT 'balance',
      total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      coupon_id INTEGER DEFAULT 0,
      coupon_discount DECIMAL(10,2) DEFAULT 0,
      paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      status VARCHAR(20) DEFAULT 'shipped',
      confirm_days INTEGER DEFAULT 7,
      confirm_deadline DATETIME,
      shipped_at DATETIME,
      confirmed_at DATETIME,
      refund_reason VARCHAR(500) DEFAULT '',
      refund_requested_at DATETIME,
      refund_responded_at DATETIME,
      refund_reviewed_by INTEGER DEFAULT 0,
      refund_reviewed_by_name VARCHAR(100) DEFAULT '',
      reviewed_at DATETIME,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS settlement_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      level_id INTEGER DEFAULT 0,
      level_name VARCHAR(100) DEFAULT '普通用户',
      confirm_days INTEGER DEFAULT 7,
      enabled INTEGER DEFAULT 1,
      balance_transfer_enabled INTEGER DEFAULT 1,
      points_transfer_enabled INTEGER DEFAULT 1,
      single_min_balance DECIMAL(10,2) DEFAULT 0,
      single_max_balance DECIMAL(10,2) DEFAULT 0,
      single_min_points INTEGER DEFAULT 0,
      single_max_points INTEGER DEFAULT 0,
      daily_limit_balance_amount DECIMAL(10,2) DEFAULT 0,
      daily_limit_points_amount INTEGER DEFAULT 0,
      daily_limit_times INTEGER DEFAULT 0,
      weekly_limit_times INTEGER DEFAULT 0,
      yearly_limit_times INTEGER DEFAULT 0,
      balance_transfer_fee DECIMAL(5,2) DEFAULT 0,
      points_transfer_fee DECIMAL(5,2) DEFAULT 0,
      balance_to_points_rate DECIMAL(10,2) DEFAULT 1,
      points_to_balance_rate DECIMAL(10,2) DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS topic_follows (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      topic_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(topic_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_blocks (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      blocker_id INTEGER NOT NULL,
      blocked_id INTEGER NOT NULL,
      reason TEXT DEFAULT '',
      status VARCHAR(20) DEFAULT 'active',
      reviewed TINYINT(1) DEFAULT 0,
      review_notes TEXT DEFAULT '',
      reviewer_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(blocker_id, blocked_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_reports (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      reporter_id INTEGER NOT NULL,
      message_id INTEGER DEFAULT 0,
      target_user_id INTEGER DEFAULT 0,
      conversation_id INTEGER DEFAULT 0,
      room_id INTEGER DEFAULT 0,
      reason VARCHAR(50) DEFAULT '',
      detail TEXT DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      handler_id INTEGER DEFAULT 0,
      handle_notes TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      handle_time DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS sensitive_words (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      word VARCHAR(100) NOT NULL,
      category VARCHAR(20) DEFAULT 'general',
      enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_rooms (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      description TEXT DEFAULT '',
      avatar VARCHAR(500) DEFAULT '',
      owner_id INTEGER NOT NULL,
      password VARCHAR(100) DEFAULT '',
      max_members INTEGER DEFAULT 500,
      member_limit INTEGER DEFAULT 50,
      join_mode VARCHAR(20) DEFAULT 'public',
      status VARCHAR(20) DEFAULT 'active',
      chat_enabled TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_members (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      role VARCHAR(20) DEFAULT 'member',
      muted_until DATETIME NULL,
      status VARCHAR(20) DEFAULT 'active',
      join_time DATETIME DEFAULT NOW(),
      UNIQUE(room_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_messages (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      from_user_id INTEGER NOT NULL,
      from_user_name VARCHAR(100) DEFAULT '',
      from_user_avatar VARCHAR(200) DEFAULT '',
      content TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      message_type VARCHAR(20) DEFAULT 'text',
      mention_ids TEXT DEFAULT '[]',
      is_recalled TINYINT(1) DEFAULT 0,
      report_status VARCHAR(20) DEFAULT 'none',
      order_card TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_admin_logs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      admin_id INTEGER NOT NULL,
      admin_name VARCHAR(100) DEFAULT '',
      action VARCHAR(50) NOT NULL,
      target_user_id INTEGER DEFAULT 0,
      target_user_name VARCHAR(100) DEFAULT '',
      detail TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_bans (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      type VARCHAR(20) DEFAULT 'temp',
      reason TEXT DEFAULT '',
      ban_until DATETIME NULL,
      banned_by INTEGER NOT NULL,
      status VARCHAR(20) DEFAULT 'active',
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(room_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_gifts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(500) DEFAULT '',
      price INTEGER DEFAULT 0,
      coin_type VARCHAR(20) DEFAULT 'coin',
      animation VARCHAR(500) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'active',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_gift_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER DEFAULT 0,
      gift_id INTEGER NOT NULL,
      from_user_id INTEGER NOT NULL,
      to_user_id INTEGER DEFAULT 0,
      quantity INTEGER DEFAULT 1,
      points_cost INTEGER DEFAULT 0,
      message_id INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_files (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      file_name VARCHAR(500) NOT NULL,
      file_url VARCHAR(500) NOT NULL,
      file_type VARCHAR(50) DEFAULT 'other',
      file_size INTEGER DEFAULT 0,
      mime_type VARCHAR(200) DEFAULT '',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS recharge_amounts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      label VARCHAR(100) DEFAULT '',
      discount VARCHAR(100) DEFAULT '',
      status TINYINT(1) DEFAULT 1,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS recharge_orders (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_no VARCHAR(64) NOT NULL,
      user_id INTEGER NOT NULL,
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      pay_method VARCHAR(20) DEFAULT 'epay',
      status VARCHAR(20) DEFAULT 'pending',
      trade_no VARCHAR(100) DEFAULT '',
      paid_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_join_requests (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(200) DEFAULT '',
      reason TEXT DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      reviewed_by INTEGER DEFAULT 0,
      reviewed_name VARCHAR(100) DEFAULT '',
      review_comment TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      review_time DATETIME NULL,
      UNIQUE(room_id, user_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS chat_room_limit_upgrades (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      room_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      current_limit INTEGER DEFAULT 50,
      request_limit INTEGER NOT NULL,
      reason TEXT DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      reviewed_by INTEGER DEFAULT 0,
      reviewed_name VARCHAR(100) DEFAULT '',
      review_comment TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      review_time DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // ===== 商城系统 =====
    `CREATE TABLE IF NOT EXISTS mall_categories (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      parent_id INTEGER DEFAULT 0,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(200) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_products (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      category_id INTEGER DEFAULT 0,
      name VARCHAR(200) NOT NULL,
      subtitle VARCHAR(200) DEFAULT '',
      description TEXT DEFAULT '',
      cover_image VARCHAR(500) DEFAULT '',
      cover_video VARCHAR(500) DEFAULT '',
      price_type VARCHAR(20) DEFAULT 'balance',
      price REAL DEFAULT 0,
      original_price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      product_type VARCHAR(20) DEFAULT 'virtual_auto',
      virtual_content TEXT DEFAULT '',
      status VARCHAR(20) DEFAULT 'draft',
      sales_count INTEGER DEFAULT 0,
      is_recommended INTEGER DEFAULT 0,
      sort_order INTEGER DEFAULT 0,
      freight REAL DEFAULT 0,
      services TEXT DEFAULT '[]',
      purchase_limit_config TEXT DEFAULT '[]',
      commission_config TEXT DEFAULT '[]',
      custom_fields TEXT DEFAULT '[]',
      after_sales_config TEXT DEFAULT '{}',
      tags TEXT DEFAULT '[]',
      product_params TEXT DEFAULT '[]',
      payment_methods TEXT DEFAULT '["balance"]',
      created_by INTEGER DEFAULT 0,
      created_by_name VARCHAR(100) DEFAULT '',
      sale_end_time DATETIME NULL,
      avg_rating REAL DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    // 迁移：添加 avg_rating 冗余字段（#355）
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS avg_rating REAL DEFAULT 0`,
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS product_subtype VARCHAR(30) DEFAULT ''`,
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS decoration_id INT DEFAULT 0`,
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS duration_days INT DEFAULT 0`,
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS bundle_config TEXT DEFAULT '[]'`,
    `ALTER TABLE mall_products ADD COLUMN IF NOT EXISTS product_type_config TEXT DEFAULT '[]'`,
    `ALTER TABLE mall_orders ADD COLUMN IF NOT EXISTS agreed_policy_id INT DEFAULT 0`,
     `ALTER TABLE mall_orders ADD COLUMN IF NOT EXISTS agreed_at DATETIME NULL`,
     `ALTER TABLE mall_product_options ADD COLUMN IF NOT EXISTS purchase_limit INT DEFAULT 0`,

    `CREATE TABLE IF NOT EXISTS mall_product_options (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      product_id INTEGER NOT NULL,
      name VARCHAR(200) NOT NULL,
      spec_name VARCHAR(200) DEFAULT '',
      price REAL DEFAULT 0,
      original_price REAL DEFAULT 0,
      points_price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      image VARCHAR(500) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      purchase_limit INTEGER DEFAULT 0,
      card_config TEXT DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS card_pools (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      type VARCHAR(50) DEFAULT 'card_key',
      card_type VARCHAR(50) DEFAULT 'membership',
      target_id INTEGER DEFAULT 0,
      value INTEGER DEFAULT 0,
      duration_unit VARCHAR(10) DEFAULT 'day',
      extra_points INTEGER DEFAULT 0,
      extra_balance DECIMAL(10,2) DEFAULT 0,
      extra_experience INTEGER DEFAULT 0,
      cards_data MEDIUMTEXT DEFAULT '[]',
      total_count INTEGER DEFAULT 0,
      used_count INTEGER DEFAULT 0,
      expiry_days INTEGER DEFAULT 0,
      warning_threshold INTEGER DEFAULT 20,
      description VARCHAR(500) DEFAULT '',
      status VARCHAR(20) DEFAULT 'active',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS delivery_logs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name VARCHAR(200) DEFAULT '',
      option_id INTEGER DEFAULT 0,
      card_type VARCHAR(30) DEFAULT '',
      delivery_info TEXT DEFAULT '',
      card_number VARCHAR(200) DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      INDEX idx_delivery_order (order_id),
      INDEX idx_delivery_user (user_id),
      INDEX idx_delivery_time (create_time)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS redeem_codes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      code VARCHAR(50) NOT NULL UNIQUE,
      batch_id VARCHAR(50) DEFAULT '',
      reward_type VARCHAR(20) NOT NULL,
      product_id INTEGER DEFAULT 0,
      product_name VARCHAR(200) DEFAULT '',
      decoration_id INTEGER DEFAULT 0,
      decoration_name VARCHAR(100) DEFAULT '',
      card_pool_id INTEGER DEFAULT 0,
      card_pool_name VARCHAR(200) DEFAULT '',
      duration_days INTEGER DEFAULT 0,
      status VARCHAR(20) DEFAULT 'unused',
      used_by INTEGER DEFAULT 0,
      used_by_name VARCHAR(100) DEFAULT '',
      used_at DATETIME NULL,
      created_by INTEGER DEFAULT 0,
      expire_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW(),
      INDEX idx_redeem_code (code),
      INDEX idx_redeem_batch (batch_id),
      INDEX idx_redeem_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_product_images (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      product_id INTEGER NOT NULL,
      url VARCHAR(500) NOT NULL,
      sort_order INTEGER DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_cart_items (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      option_id INTEGER DEFAULT 0,
      quantity INTEGER DEFAULT 1,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, product_id, option_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_orders (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_no VARCHAR(32) NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      status VARCHAR(20) DEFAULT 'pending',
      total_amount REAL DEFAULT 0,
      discount_amount REAL DEFAULT 0,
      freight REAL DEFAULT 0,
      payment_method VARCHAR(20) DEFAULT '',
      payment_time DATETIME NULL,
      receiver_name VARCHAR(100) DEFAULT '',
      receiver_phone VARCHAR(20) DEFAULT '',
      receiver_address VARCHAR(500) DEFAULT '',
      logistics_company VARCHAR(100) DEFAULT '',
      logistics_no VARCHAR(100) DEFAULT '',
      user_custom_fields TEXT DEFAULT '{}',
      remark VARCHAR(500) DEFAULT '',
      agreed_policy_id INTEGER DEFAULT 0,
      agreed_at DATETIME NULL,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_order_items (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      option_id INTEGER DEFAULT 0,
      product_name VARCHAR(200) DEFAULT '',
      option_name VARCHAR(200) DEFAULT '',
      price REAL DEFAULT 0,
      quantity INTEGER DEFAULT 1,
      image VARCHAR(500) DEFAULT '',
      virtual_content TEXT DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_order_logistics (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_id INTEGER NOT NULL,
      company VARCHAR(100) DEFAULT '',
      tracking_no VARCHAR(100) DEFAULT '',
      status VARCHAR(20) DEFAULT 'pending',
      details TEXT DEFAULT '[]',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS logistics_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      provider VARCHAR(50) NOT NULL DEFAULT 'kdniao',
      e_business_id VARCHAR(100) NOT NULL DEFAULT '',
      api_key_encrypted VARCHAR(500) NOT NULL DEFAULT '',
      customer_id VARCHAR(100) DEFAULT '',
      enabled TINYINT(1) DEFAULT 1,
      callback_url VARCHAR(500) DEFAULT '',
      update_time DATETIME DEFAULT NOW(),
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_reviews (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      order_id INTEGER NOT NULL,
      rating INTEGER DEFAULT 5,
      content TEXT DEFAULT '',
      images TEXT DEFAULT '[]',
      reply TEXT DEFAULT '',
      dim_product_rating DECIMAL(2,1) DEFAULT 0,
      dim_service_rating DECIMAL(2,1) DEFAULT 0,
      dim_logistics_rating DECIMAL(2,1) DEFAULT 0,
      reply_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_review_likes (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      review_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(review_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_after_sales (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      order_id INTEGER NOT NULL,
      order_item_id INTEGER DEFAULT 0,
      user_id INTEGER NOT NULL,
      type VARCHAR(20) DEFAULT 'refund',
      reason TEXT DEFAULT '',
      description TEXT DEFAULT '',
      images TEXT DEFAULT '[]',
      amount REAL DEFAULT 0,
      status VARCHAR(20) DEFAULT 'pending',
      seller_reply TEXT DEFAULT '',
      seller_reply_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_promotions (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      type VARCHAR(20) DEFAULT 'discount',
      discount_value REAL DEFAULT 0,
      min_amount REAL DEFAULT 0,
      user_types TEXT DEFAULT '[]',
      start_time DATETIME NULL,
      end_time DATETIME NULL,
      status VARCHAR(20) DEFAULT '1',
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_promotion_gifts (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      promotion_id INTEGER NOT NULL,
      gift_type VARCHAR(20) DEFAULT 'points',
      gift_value REAL DEFAULT 0,
      gift_detail JSON DEFAULT '{}'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_promotion_products (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      promotion_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      UNIQUE(promotion_id, product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS storage_configs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      type VARCHAR(50) DEFAULT 'local',
      name VARCHAR(100) DEFAULT '',
      config TEXT,
      endpoint VARCHAR(500) DEFAULT '',
      region VARCHAR(100) DEFAULT '',
      bucket VARCHAR(200) DEFAULT '',
      access_key VARCHAR(500) DEFAULT '',
      secret_key VARCHAR(500) DEFAULT '',
      local_dir VARCHAR(500) DEFAULT '',
      remote_dir VARCHAR(500) DEFAULT '',
      base_url VARCHAR(500) DEFAULT '',
      applicable_roles TEXT,
      applicable_levels TEXT,
      is_default TINYINT(1) DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS email_push_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      code VARCHAR(50) DEFAULT '',
      name VARCHAR(100) DEFAULT '',
      description VARCHAR(500) DEFAULT '',
      target VARCHAR(100) DEFAULT '',
      subject VARCHAR(200) DEFAULT '',
      template TEXT,
      enabled TINYINT(1) DEFAULT 0,
      user_group VARCHAR(20) DEFAULT 'all',
      level_ids TEXT,
      sort_order INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS email_templates (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(100) DEFAULT '',
      code VARCHAR(50) DEFAULT '',
      subject VARCHAR(200) DEFAULT '',
      html_content TEXT,
      description VARCHAR(500) DEFAULT '',
      sort_order INTEGER DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS section_moderators (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      section_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      UNIQUE(section_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS verification_config (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      condition_type VARCHAR(50) NOT NULL,
      threshold INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 0,
      logic_type VARCHAR(20) DEFAULT 'any',
      logic_count INTEGER DEFAULT 1,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_avatar_frames (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      frame_id INTEGER NOT NULL,
      is_active TINYINT(1) DEFAULT 0,
      obtain_type VARCHAR(20) DEFAULT 'manual',
      obtain_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, frame_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS game_configs (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      game_type VARCHAR(30) NOT NULL UNIQUE,
      config_data JSON NOT NULL,
      enabled TINYINT DEFAULT 1,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS game_records (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      game_type VARCHAR(30) NOT NULL,
      result VARCHAR(20) NOT NULL,
      points_spent INTEGER DEFAULT 0,
      points_won INTEGER DEFAULT 0,
      detail JSON,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS moderator_applications (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      section_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      user_name VARCHAR(100) DEFAULT '',
      user_avatar VARCHAR(500) DEFAULT '',
      reason TEXT DEFAULT '',
      desired_role VARCHAR(50) DEFAULT '版主',
      status VARCHAR(20) DEFAULT 'pending',
      reviewed_by INTEGER DEFAULT 0,
      reviewed_by_name VARCHAR(100) DEFAULT '',
      review_comment TEXT DEFAULT '',
      create_time DATETIME DEFAULT NOW(),
      review_time DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_collections (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      description TEXT,
      cover_url VARCHAR(500),
      user_id INT NOT NULL,
      status VARCHAR(20) DEFAULT 'active',
      sort_order INT DEFAULT 0,
      view_count INT DEFAULT 0,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS app_collection_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      collection_id INT NOT NULL,
      app_id INT NOT NULL,
      sort_order INT DEFAULT 0,
      create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uk_collection_app (collection_id, app_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS mall_favorites (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE(user_id, product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_addresses (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      name VARCHAR(50) DEFAULT '',
      phone VARCHAR(20) DEFAULT '',
      province VARCHAR(50) DEFAULT '',
      city VARCHAR(50) DEFAULT '',
      district VARCHAR(50) DEFAULT '',
      detail VARCHAR(200) DEFAULT '',
      is_default TINYINT(1) DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS ab_tests (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      target_page VARCHAR(500) DEFAULT '',
      goal VARCHAR(50) DEFAULT 'ctr',
      traffic INTEGER DEFAULT 50,
      status VARCHAR(20) DEFAULT 'draft',
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS ab_test_variants (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      test_id INTEGER NOT NULL,
      name VARCHAR(100) DEFAULT '',
      ratio INTEGER DEFAULT 0,
      config JSON,
      impressions INTEGER DEFAULT 0,
      conversions INTEGER DEFAULT 0,
      conversion_rate DOUBLE DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS push_notifications (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      type VARCHAR(50) DEFAULT 'system',
      target_type VARCHAR(50) DEFAULT 'all',
      target_ids TEXT,
      target_count INTEGER DEFAULT 0,
      title VARCHAR(500) DEFAULT '',
      content TEXT,
      link VARCHAR(500) DEFAULT '',
      channels VARCHAR(500) DEFAULT '["app"]',
      membership_level VARCHAR(20) DEFAULT '',
      status VARCHAR(20) DEFAULT 'draft',
      read_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      name VARCHAR(200) NOT NULL,
      type VARCHAR(50) DEFAULT 'discount',
      status VARCHAR(20) DEFAULT 'draft',
      start_time DATETIME NULL,
      end_time DATETIME NULL,
      cover_url VARCHAR(500) DEFAULT '',
      description TEXT,
      page_title VARCHAR(200) DEFAULT '',
      page_content TEXT,
      rules TEXT,
      rewards JSON,
      max_participants INTEGER DEFAULT 0,
      participant_count INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS ranking_cache (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      type VARCHAR(30) NOT NULL,
      period VARCHAR(10) NOT NULL DEFAULT 'all',
      data JSON,
      updated_at DATETIME DEFAULT NOW(),
      UNIQUE KEY uk_type_period (type, period)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_risks (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      risk_type VARCHAR(30) NOT NULL,
      risk_level INTEGER DEFAULT 1,
      evidence JSON,
      status VARCHAR(20) DEFAULT 'active',
      detected_at DATETIME DEFAULT NOW(),
      resolved_at DATETIME NULL,
      resolved_by INTEGER DEFAULT 0,
      resolve_note VARCHAR(500) DEFAULT '',
      INDEX idx_user_risks_user (user_id),
      INDEX idx_user_risks_type_status (risk_type, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS policy_versions (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      type VARCHAR(20) NOT NULL,
      title VARCHAR(200) DEFAULT '',
      content TEXT,
      version INTEGER DEFAULT 1,
      status VARCHAR(10) DEFAULT 'draft',
      published_at DATETIME NULL,
      created_by INTEGER DEFAULT 0,
      create_time DATETIME DEFAULT NOW(),
      update_time DATETIME DEFAULT NOW(),
      INDEX idx_policy_versions_type_status (type, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_policy_consents (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      policy_type VARCHAR(20) NOT NULL,
      policy_version_id INTEGER NOT NULL,
      policy_version INTEGER DEFAULT 1,
      ip VARCHAR(45) DEFAULT '',
      consented_at DATETIME DEFAULT NOW(),
      INDEX idx_user_policy_consents_user (user_id),
      INDEX idx_user_policy_consents_user_type (user_id, policy_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS cookie_consents (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER DEFAULT 0,
      session_id VARCHAR(100) DEFAULT '',
      ip VARCHAR(45) DEFAULT '',
      accepted_categories JSON,
      accepted_at DATETIME DEFAULT NOW(),
      INDEX idx_cookie_consents_user (user_id),
      INDEX idx_cookie_consents_session (session_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_data_exports (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      status VARCHAR(20) DEFAULT 'pending',
      file_path VARCHAR(500) DEFAULT '',
      file_size INTEGER DEFAULT 0,
      requested_at DATETIME DEFAULT NOW(),
      completed_at DATETIME NULL,
      expires_at DATETIME NULL,
      INDEX idx_user_data_exports_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS decorations (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      type VARCHAR(30) NOT NULL,
      name VARCHAR(100) NOT NULL,
      image_url VARCHAR(500) DEFAULT '',
      preview_url VARCHAR(500) DEFAULT '',
      config_json TEXT,
      css_class VARCHAR(100) DEFAULT '',
      description VARCHAR(500) DEFAULT '',
      obtain_type VARCHAR(20) DEFAULT 'manual',
      duration_days INT DEFAULT 0,
      status VARCHAR(2) DEFAULT '1',
      sort_order INT DEFAULT 0,
      create_time DATETIME DEFAULT NOW()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

    `CREATE TABLE IF NOT EXISTS user_decorations (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      user_id INTEGER NOT NULL,
      decoration_id INTEGER NOT NULL,
      decoration_type VARCHAR(30) NOT NULL,
      is_active TINYINT(1) DEFAULT 0,
      obtain_type VARCHAR(20) DEFAULT 'manual',
      expire_time DATETIME NULL,
      create_time DATETIME DEFAULT NOW(),
      UNIQUE KEY uix_user_decoration (user_id, decoration_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  ]

  const indexes = [
    'idx_users_username ON users(username)',
    'idx_users_status ON users(status)',
    'idx_card_keys_card_no ON card_keys(card_no)',
    'idx_card_keys_type ON card_keys(type)',
    'idx_points_records_user_id ON points_records(user_id)',
    'idx_points_records_type ON points_records(type)',
    'idx_app_comments_app_id ON app_comments(app_id)',
    'idx_app_store_status ON app_store(status)',
    'idx_app_versions_app_id ON app_versions(app_id)',
    'idx_app_uploads_user_id ON app_uploads(user_id)',
    'idx_app_tips_app ON app_tips(app_id)',
    'idx_app_tips_user ON app_tips(user_id)',
    'idx_sys_notifications_target_user ON sys_notifications(target_user_id)',
    'idx_private_messages_from ON private_messages(from_user_id)',
    'idx_private_messages_to ON private_messages(to_user_id)',
    'idx_private_messages_conversation ON private_messages(from_user_id, to_user_id)',
    'idx_app_purchases_app ON app_purchases(app_id)',
    'idx_app_purchases_user ON app_purchases(user_id)',
    'idx_app_purchases_user_app ON app_purchases(user_id, app_id)',
    'idx_community_posts_section_id ON community_posts(section_id)',
    'idx_community_posts_user_id ON community_posts(user_id)',
    'idx_community_posts_status ON community_posts(status)',
    'idx_community_posts_is_pinned ON community_posts(is_pinned)',
    'idx_community_posts_is_essence ON community_posts(is_essence)',
    'idx_community_posts_is_hot ON community_posts(is_hot)',
    'idx_community_comments_post_id ON community_comments(post_id)',
    'idx_community_comments_parent_id ON community_comments(parent_id)',
    'idx_community_likes_post_user ON community_likes(post_id, user_id)',
    'idx_community_favorites_post_user ON community_favorites(post_id, user_id)',
    'idx_community_drafts_user_id ON community_drafts(user_id)',
    'idx_community_banned_users_user_id ON community_banned_users(user_id)',
    'idx_community_collections_user_id ON community_collections(user_id)',
    'idx_community_collections_status ON community_collections(status)',
    'idx_community_collection_posts_collection ON community_collection_posts(collection_id)',
    'idx_user_paid_collections_user ON user_paid_collections(user_id)',
    'idx_user_paid_collections_collection ON user_paid_collections(collection_id)',
    'idx_user_follows_follower ON user_follows(follower_id)',
    'idx_user_follows_following ON user_follows(following_id)',
    'idx_user_titles_user ON user_titles(user_id)',
    'idx_checkin_records_user_date ON checkin_records(user_id, checkin_date)',
    'idx_verification_requests_user ON verification_requests(user_id)',
    'idx_email_verifications_email ON email_verifications(email)',
    'idx_invite_codes_code ON invite_codes(code)',
    'idx_balance_records_user ON balance_records(user_id)',
    'idx_file_repository_user ON file_repository(user_id)',
    'idx_recycle_bin_table ON recycle_bin(original_table)',
    'idx_system_logs_user ON system_logs(user_id)',
    'idx_system_logs_type ON system_logs(type)',
    'idx_system_logs_create ON system_logs(create_time)',
    'idx_task_records_user ON task_records(user_id)',
    'idx_orders_buyer ON orders(buyer_id)',
    'idx_orders_seller ON orders(seller_id)',
    'idx_orders_status ON orders(status)',
    'idx_orders_no ON orders(order_no)',
    'idx_task_records_period ON task_records(period_key)',
    'idx_app_favorites_user ON app_favorites(user_id)',
    'idx_app_favorites_app ON app_favorites(app_id)',
    'idx_post_favorites_user ON post_favorites(user_id)',
    'idx_post_favorites_post ON post_favorites(post_id)',
    'idx_commission_records_user ON commission_records(user_id)',
    'idx_commission_records_referrer ON commission_records(referrer_id)',
    'idx_withdraw_records_user ON withdraw_records(user_id)',
    'idx_referral_links_code ON referral_links(code)',
    'idx_membership_purchases_user ON membership_purchases(user_id)',
    'idx_content_purchases_user ON content_purchases(user_id)',
    'idx_content_purchases_content ON content_purchases(content_type, content_id)',
    'idx_content_access_passwords_content ON content_access_passwords(content_type, content_id)',
    'idx_experience_records_user_id ON experience_records(user_id)',
    'idx_coupons_status ON coupons(status)',
    'idx_coupons_scope ON coupons(scope)',
    'idx_coupons_category ON coupons(category)',
    'idx_user_coupons_user ON user_coupons(user_id)',
    'idx_user_coupons_status ON user_coupons(status)',
    'idx_user_coupons_coupon ON user_coupons(coupon_id)',
    'idx_topic_follows_topic ON topic_follows(topic_id)',
    'idx_topic_follows_user ON topic_follows(user_id)',
    'idx_post_topics_post ON community_post_topics(post_id)',
    'idx_post_topics_topic ON community_post_topics(topic_id)',
    'idx_user_blocks_blocker ON user_blocks(blocker_id)',
    'idx_user_blocks_blocked ON user_blocks(blocked_id)',
    'idx_user_blocks_status ON user_blocks(status)',
    'idx_chat_room_files_room_id ON chat_room_files(room_id)',
    'idx_recharge_orders_user ON recharge_orders(user_id)',
    'idx_recharge_orders_order_no ON recharge_orders(order_no)',
    'idx_mall_products_category ON mall_products(category_id)',
    'idx_mall_products_status ON mall_products(status)',
    'idx_mall_product_options_product ON mall_product_options(product_id)',
    'idx_card_pools_type ON card_pools(type)',
    'idx_card_pools_status ON card_pools(status)',
    'idx_mall_product_images_product ON mall_product_images(product_id)',
    'idx_mall_cart_items_user ON mall_cart_items(user_id)',
    'idx_mall_orders_user ON mall_orders(user_id)',
    'idx_mall_orders_status ON mall_orders(status)',
    'idx_mall_orders_order_no ON mall_orders(order_no)',
    'idx_mall_order_items_order ON mall_order_items(order_id)',
    'idx_mall_order_logistics_order ON mall_order_logistics(order_id)',
    'idx_logistics_config_provider ON logistics_config(provider)',
    'idx_mall_reviews_product ON mall_reviews(product_id)',
    'idx_mall_reviews_user ON mall_reviews(user_id)',
    'idx_mall_after_sales_order ON mall_after_sales(order_id)',
    'idx_mall_after_sales_user ON mall_after_sales(user_id)',
    'idx_game_configs_type ON game_configs(game_type)',
    'idx_game_records_user ON game_records(user_id)',
    'idx_game_records_type ON game_records(game_type)',
    'idx_game_records_time ON game_records(create_time)',
    'idx_posts_section_status_create ON community_posts(section_id, status, create_time)',
    'idx_posts_create_time ON community_posts(create_time)',
    'idx_comments_post_parent_time ON community_comments(post_id, parent_id, create_time)',
    'idx_notifications_target_read_id ON sys_notifications(target_user_id, is_read, id)',
    'idx_experience_levels_exp_status ON experience_levels(exp_required, status)',
    'idx_app_category_status ON app_store(category_id, status)',
    'idx_sessions_created ON sessions(created_at)',
    // === 29.2 外键/关联字段索引 ===
    'idx_coin_logs_post_id ON community_coin_logs(post_id)',
    'idx_coin_logs_from_user ON community_coin_logs(from_user_id)',
    'idx_coin_logs_to_user ON community_coin_logs(to_user_id)',
    'idx_community_comments_user ON community_comments(user_id)',
    'idx_community_reports_reporter ON community_reports(reporter_id)',
    'idx_community_reports_target ON community_reports(target_type, target_id)',
    'idx_chat_room_messages_room ON chat_room_messages(room_id)',
    'idx_chat_room_messages_user ON chat_room_messages(from_user_id)',
    'idx_chat_gift_records_room ON chat_gift_records(room_id)',
    'idx_chat_gift_records_gift ON chat_gift_records(gift_id)',
    'idx_chat_gift_records_from ON chat_gift_records(from_user_id)',
    'idx_chat_gift_records_to ON chat_gift_records(to_user_id)',
    'idx_browse_history_user ON browse_history(user_id)',
    'idx_browse_history_item ON browse_history(item_type, item_id)',
    'idx_coupon_usage_logs_user ON coupon_usage_logs(user_id)',
    'idx_coupon_usage_logs_coupon ON coupon_usage_logs(coupon_id)',
    'idx_coupon_usage_logs_uc ON coupon_usage_logs(user_coupon_id)',
    // === 29.3 低基数 status/enabled 字段索引 ===
    'idx_community_reports_status ON community_reports(status)',
    'idx_community_unlock_requests_post ON community_unlock_requests(post_id)',
    'idx_community_unlock_requests_status ON community_unlock_requests(status)',
    'idx_chat_reports_status ON chat_reports(status)',
    'idx_chat_rooms_status ON chat_rooms(status)',
    'idx_chat_room_bans_status ON chat_room_bans(status)',
    'idx_recharge_orders_status ON recharge_orders(status)',
    'idx_mall_after_sales_status ON mall_after_sales(status)',
    'idx_push_notifications_status ON push_notifications(status)',
    'idx_campaigns_status ON campaigns(status)',
    'idx_community_topics_status ON community_topics(status)',
    // === 29.4 ORDER BY create_time 索引 ===
    'idx_community_comments_ctime ON community_comments(create_time)',
    'idx_community_likes_ctime ON community_likes(create_time)',
    'idx_community_favorites_ctime ON community_favorites(create_time)',
    'idx_coin_logs_ctime ON community_coin_logs(create_time)',
    'idx_community_reports_ctime ON community_reports(create_time)',
    'idx_community_topics_ctime ON community_topics(create_time)',
    'idx_community_drafts_ctime ON community_drafts(create_time)',
    'idx_chat_room_messages_ctime ON chat_room_messages(create_time)',
    'idx_chat_gift_records_ctime ON chat_gift_records(create_time)',
    'idx_private_messages_ctime ON private_messages(create_time)',
    'idx_orders_ctime ON orders(create_time)',
    'idx_points_records_ctime ON points_records(create_time)',
    'idx_balance_records_ctime ON balance_records(create_time)',
    'idx_commission_records_ctime ON commission_records(create_time)',
    'idx_membership_purchases_ctime ON membership_purchases(create_time)',
    'idx_content_purchases_ctime ON content_purchases(create_time)',
    'idx_recharge_orders_ctime ON recharge_orders(create_time)',
    'idx_browse_history_ctime ON browse_history(create_time)',
    // === 29.5 高效复合索引（分页） ===
    'idx_browse_history_user_time ON browse_history(user_id, create_time)',
    'idx_points_records_user_time ON points_records(user_id, create_time)',
    'idx_balance_records_user_time ON balance_records(user_id, create_time)',
    'idx_orders_buyer_time ON orders(buyer_id, create_time)',
    'idx_private_messages_to_time ON private_messages(to_user_id, create_time)',
    'idx_comments_post_time ON community_comments(post_id, create_time)',
    'idx_balance_records_user_time ON balance_records(user_id, create_time)',
    'idx_experience_records_user_time ON experience_records(user_id, create_time)',
    'idx_experience_records_type ON experience_records(type)',
    'idx_user_violation_counts_user ON user_violation_counts(user_id)',
    'idx_user_violation_counts_task ON user_violation_counts(task_id)',
    'idx_checkin_records_user_time ON checkin_records(user_id, checkin_date)',
    'idx_decorations_type ON decorations(type)',
    'idx_decorations_status ON decorations(status)',
    'idx_user_decorations_user ON user_decorations(user_id)',
    'idx_user_decorations_type ON user_decorations(decoration_type)',
  ]

  const db = getPool().promise()
  tables.forEach(t => db.query(t).catch(err => console.error('建表错误:', t.substring(0, 50), err.message)))
  indexes.forEach(i => {
    try {
      db.query(`CREATE INDEX IF NOT EXISTS ${i}`).catch(() => {})
    } catch {}
  })

  db.query("SELECT id FROM menus WHERE name='ComplianceSettings'").then(([rows]) => {
    if (!rows || rows.length === 0) {
      db.query("INSERT INTO menus (parent_id, name, path, component, redirect, title, icon, sort_order, is_hidden, is_full_page, is_keep_alive, is_fixed_tab, auth_list, roles, enabled, mobile_path, icon_bg, icon_svg, category) VALUES (2, 'ComplianceSettings', 'compliance', '/appstore/compliance-settings', '', '合规设置', '', 16, 0, 0, 1, 0, '[{\"title\":\"编辑\",\"authMark\":\"edit\"}]', NULL, 1, '/appstore/compliance-settings', '#10B981', 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z', '')")
    }
  }).catch(err => console.error('菜单迁移检查失败:', err.message))
}

const getSystemOperator = async () => {
  try {
    const configRow = await query("SELECT config_value FROM sys_config WHERE config_key='system_operator_id'")
    if (!configRow || !configRow.length) return null
    const operatorId = parseInt(configRow[0].config_value)
    if (!operatorId || operatorId <= 0) return null
    const userRow = await query('SELECT id, username, avatar, roles, active_title_id FROM users WHERE id=?', [operatorId])
    if (!userRow || !userRow.length) return null
    return userRow[0]
  } catch { return null }
}

module.exports = { query, getSystemOperator, getPool }
