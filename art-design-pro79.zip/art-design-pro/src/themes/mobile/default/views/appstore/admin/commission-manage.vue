<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">推广返佣</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- 3个Tab -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-1 flex">
        <button v-for="tab in tabs" :key="tab.key" class="flex-1 h-8 text-xs rounded-lg font-medium transition-colors" :class="activeTab===tab.key ? 'bg-[#FF4757] text-white' : 'text-gray-500'" @click="activeTab=tab.key">{{ tab.label }}</button>
      </div>

      <!-- 返佣规则 -->
      <template v-if="activeTab==='rules'">
        <div class="bg-white mx-3 mt-3 rounded-xl p-3">
          <button v-auth="'add'" class="w-full h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openRuleDialog(null)">新增规则</button>
        </div>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div v-if="rulesLoading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
          <template v-else-if="rules.length>0">
            <div v-for="rule in rules" :key="rule.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors">
              <div class="flex items-start justify-between">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-1">
                    <span class="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">#{{ rule.id }}</span>
                    <span class="text-sm font-semibold text-gray-800 truncate">{{ rule.name }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded" :class="rule.status==='1'?'bg-green-50 text-green-600':'bg-gray-100 text-gray-400'">{{ rule.status==='1'?'启用':'禁用' }}</span>
                  </div>
                  <div class="grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs text-gray-400 mt-1">
                    <div>订单类型: <span class="text-gray-600">{{ orderTypeLabel(rule.order_type) }}</span></div>
                    <div>返佣比例: <span class="text-[#FF4757] font-medium">{{ rule.rate }}%</span></div>
                    <div class="col-span-2">适用范围: <span class="text-gray-600">{{ scopeLabel(rule) }}</span></div>
                  </div>
                </div>
                <div class="flex gap-1 flex-shrink-0 ml-2">
                  <button v-auth="'edit'" class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click.stop="openRuleDialog(rule)">编辑</button>
                  <button v-auth="'delete'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteRule(rule)">删除</button>
                </div>
              </div>
            </div>
            <div class="text-center text-xs text-gray-400 py-4">共 {{ rules.length }} 条</div>
          </template>
          <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无返佣规则</span></div>
        </div>
      </template>

      <!-- 返佣记录 -->
      <template v-if="activeTab==='records'">
        <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex items-center gap-2">
          <select v-model="recordStatus" class="flex-1 h-10 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchRecords(1)">
            <option value="">全部状态</option>
            <option value="pending">待结算</option>
            <option value="completed">已结算</option>
          </select>
        </div>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div v-if="recordsLoading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
          <template v-else-if="records.length>0">
            <div v-for="item in records" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
              <div class="flex items-start justify-between">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-0.5">
                    <span class="text-sm font-semibold text-gray-800">{{ item.order_type || '订单' }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status==='completed'?'bg-green-50 text-green-600':'bg-yellow-50 text-yellow-600'">{{ item.status==='completed'?'已结算':'待结算' }}</span>
                  </div>
                  <div class="text-xs text-gray-400">订单金额: {{ item.order_amount }} | 返佣 {{ item.commission_amount }} ({{ item.rate }}%)</div>
                  <div class="text-xs text-gray-400 mt-0.5">推广人ID: {{ item.referrer_id }} | {{ item.create_time }}</div>
                </div>
              </div>
            </div>
            <div class="flex items-center justify-between px-4 py-3">
              <span class="text-xs text-gray-400">共 {{ recordTotal }} 条</span>
              <div class="flex gap-1">
                <button :disabled="recordPage<=1" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="fetchRecords(recordPage-1)">上一页</button>
                <span class="text-xs text-gray-500 self-center">{{ recordPage }}/{{ Math.max(1,Math.ceil(recordTotal/15)) }}</span>
                <button :disabled="recordPage>=Math.ceil(recordTotal/15)" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="fetchRecords(recordPage+1)">下一页</button>
              </div>
            </div>
          </template>
          <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无返佣记录</span></div>
        </div>
      </template>

      <!-- 提现审核 -->
      <template v-if="activeTab==='withdraw'">
        <div class="bg-white mx-3 mt-3 rounded-xl p-3 flex items-center gap-2">
          <select v-model="withdrawStatus" class="flex-1 h-10 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchWithdraws(1)">
            <option value="">全部</option>
            <option value="pending">待审核</option>
            <option value="completed">已通过</option>
            <option value="rejected">已拒绝</option>
          </select>
        </div>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div v-if="withdrawLoading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
          <template v-else-if="withdraws.length>0">
            <div v-for="item in withdraws" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
              <div class="flex items-start justify-between">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-0.5">
                    <span class="text-sm font-semibold text-gray-800">{{ item.real_name || item.realName || '-' }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded" :class="wdStatusClass(item.status)">{{ wdStatusText(item.status) }}</span>
                  </div>
                  <div class="text-xs text-gray-400">金额: <span class="text-[#FF4757] font-medium">{{ item.amount }}</span> | {{ item.method }} {{ item.account }}</div>
                  <div class="text-xs text-gray-400 mt-0.5">申请: {{ item.create_time }}</div>
                </div>
                <div v-if="item.status==='pending'" class="flex gap-1 flex-shrink-0 ml-2">
                  <button class="text-xs px-2 py-1 rounded bg-green-50 text-green-500 active:bg-green-100" @click="reviewWithdraw(item,'completed')">通过</button>
                  <button class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="rejectWithdraw(item)">拒绝</button>
                </div>
              </div>
            </div>
            <div class="flex items-center justify-between px-4 py-3">
              <span class="text-xs text-gray-400">共 {{ withdrawTotal }} 条</span>
              <div class="flex gap-1">
                <button :disabled="withdrawPage<=1" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="fetchWithdraws(withdrawPage-1)">上一页</button>
                <span class="text-xs text-gray-500 self-center">{{ withdrawPage }}/{{ Math.max(1,Math.ceil(withdrawTotal/15)) }}</span>
                <button :disabled="withdrawPage>=Math.ceil(withdrawTotal/15)" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="fetchWithdraws(withdrawPage+1)">下一页</button>
              </div>
            </div>
          </template>
          <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无提现记录</span></div>
        </div>
      </template>
    </div>

    <!-- 规则编辑弹窗 -->
    <div v-if="ruleVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="ruleVisible=false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="ruleVisible=false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ ruleEditId?'编辑规则':'新增规则' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveRule">保存</button>
        </div>
        <div class="p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">规则名称</label><input v-model="ruleForm.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">订单类型</label><select v-model="ruleForm.order_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="all">全部</option><option value="membership">会员购买</option><option value="app">应用购买</option><option value="post">帖子购买</option><option value="resource">资源购买</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">返佣比例 (%)</label><input v-model.number="ruleForm.rate" type="number" min="0" max="100" step="0.1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">适用等级</label><select v-model="ruleForm.user_level_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option :value="0">所有用户</option><option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option></select></div>
          <div><label class="text-xs text-gray-500 mb-1 block">邀请码类型</label><select v-model="ruleForm.invite_code_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="">不限</option><option value="admin">官方邀请码</option><option value="user">用户邀请码</option></select></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="ruleForm.status==='1'?'bg-[#FF4757]':'bg-gray-200'" @click="ruleForm.status=ruleForm.status==='1'?'0':'1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="ruleForm.status==='1'?'translate-x-4.5':'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'CommissionManageMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const tabs=[{key:'rules',label:'返佣规则'},{key:'records',label:'返佣记录'},{key:'withdraw',label:'提现审核'}]
const activeTab=ref('rules')

// Rules
const rulesLoading=ref(false);const rules=ref<any[]>([])
const fetchRules=async()=>{rulesLoading.value=true;try{const res:any=await request.get({url:'/api/commission/rules'});rules.value=Array.isArray(res)?res:(res?.records||res?.data||[])}catch{}rulesLoading.value=false}
const ruleVisible=ref(false);const ruleEditId=ref<number|null>(null);const levelList=ref<any[]>([])
const ruleForm=reactive({name:'',order_type:'all',rate:0,user_level_id:0,invite_code_type:'',status:'1'})

const loadLevels=async()=>{try{const res:any=await request.get({url:'/api/operation/membership-level/list'});levelList.value=res?.records||res?.data?.records||[]}catch{}}

const orderTypeMap:Record<string,string>={all:'全部',membership:'会员购买',app:'应用购买',post:'帖子购买',post_resource:'帖子资源',resource:'资源购买'}
const orderTypeLabel=(t:string)=>orderTypeMap[t]||t||'全部'

const scopeLabel=(rule:any)=>{
  if(rule.invite_code_type==='admin')return'官方邀请码'
  if(rule.invite_code_type==='user')return'用户邀请码'
  if(rule.invite_code_id>0)return'指定邀请码'
  return rule.user_level_name||(rule.user_id?'用户专属':'全局')
}

const openRuleDialog=(rule:any|null)=>{
  ruleEditId.value=rule?.id||null
  if(rule){ruleForm.name=rule.name||'';ruleForm.order_type=rule.order_type||'all';ruleForm.rate=rule.rate||0;ruleForm.user_level_id=rule.user_level_id||0;ruleForm.invite_code_type=rule.invite_code_type||'';ruleForm.status=rule.status||'1'}else{Object.assign(ruleForm,{name:'',order_type:'all',rate:0,user_level_id:0,invite_code_type:'',status:'1'})}
  ruleVisible.value=true
}

const saveRule=async()=>{try{await request.post({url:'/api/commission/rule/save',data:{id:ruleEditId.value||undefined,...ruleForm}});showToast('保存成功');ruleVisible.value=false;fetchRules()}catch(e:any){showToast('保存失败: '+(e.message||''),'error')}}
const deleteRule=async(rule:any)=>{if(!confirm(`确认删除规则 ${rule.name||'#'+rule.id}？`))return;try{await request.post({url:'/api/commission/rule/delete',data:{id:rule.id}});showToast('删除成功');fetchRules()}catch{showToast('删除失败','error')}}

// Records
const recordsLoading=ref(false);const records=ref<any[]>([]);const recordTotal=ref(0);const recordPage=ref(1);const recordStatus=ref('')
const fetchRecords=async(p:number)=>{recordPage.value=p;recordsLoading.value=true;try{const params:any={page:p,pageSize:15};if(recordStatus.value)params.status=recordStatus.value;const res:any=await request.get({url:'/api/commission/records',params});records.value=res?.list||res?.records||res?.data?.list||[];recordTotal.value=res?.total||res?.data?.total||0}catch{}recordsLoading.value=false}

// Withdraws
const withdrawLoading=ref(false);const withdraws=ref<any[]>([]);const withdrawTotal=ref(0);const withdrawPage=ref(1);const withdrawStatus=ref('')
const wdStatusText=(s:string)=>s==='pending'?'待审核':s==='completed'?'已通过':s==='rejected'?'已拒绝':s
const wdStatusClass=(s:string)=>s==='pending'?'bg-yellow-50 text-yellow-600':s==='completed'?'bg-green-50 text-green-600':s==='rejected'?'bg-red-50 text-red-400':'bg-gray-100 text-gray-400'

const fetchWithdraws=async(p:number)=>{withdrawPage.value=p;withdrawLoading.value=true;try{const params:any={page:p,pageSize:15};if(withdrawStatus.value)params.status=withdrawStatus.value;const res:any=await request.get({url:'/api/commission/withdraw/list',params});withdraws.value=res?.list||res?.records||res?.data?.list||[];withdrawTotal.value=res?.total||res?.data?.total||0}catch{}withdrawLoading.value=false}

const reviewWithdraw=async(item:any,status:string)=>{try{await request.post({url:'/api/commission/withdraw/review',data:{id:item.id,status}});showToast(status==='completed'?'已通过':'已操作');fetchWithdraws(withdrawPage.value)}catch(e:any){showToast('操作失败: '+(e.message||''),'error')}}
const rejectWithdraw=async(item:any)=>{const reason=prompt('拒绝原因(可选):');try{await request.post({url:'/api/commission/withdraw/review',data:{id:item.id,status:'rejected',remark:reason||''}});showToast('已拒绝');fetchWithdraws(withdrawPage.value)}catch(e:any){showToast('操作失败: '+(e.message||''),'error')}}

watch(activeTab,(v)=>{
  if(v==='rules'&&rules.value.length===0)fetchRules()
  if(v==='records'&&records.value.length===0)fetchRecords(1)
  if(v==='withdraw'&&withdraws.value.length===0)fetchWithdraws(1)
})

onMounted(()=>{fetchRules();loadLevels()})
</script>

<style scoped>
.animate-slide-up { animation: slideUp 0.25s ease-out; }
@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
</style>
