<!-- 手机版主题布局 - 底部导航栏 -->
<template>
  <div class="mobile-theme">
    <RouterView />
    <nav class="bottom-nav" v-if="!hideNav">
      <div
        class="nav-item"
        :class="{ active: $route.path === '/appstore/browse' || $route.path === '/appstore/browse/' }"
        @click="$router.replace('/appstore/browse')"
      >
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span>首页</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: $route.path.startsWith('/appstore/category') }"
        @click="$router.replace('/appstore/category')"
      >
        <svg fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        <span>应用</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: $route.path.startsWith('/community') }"
        @click="$router.replace('/community')"
      >
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <span>社区</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: $route.path.startsWith('/appstore/game') }"
        @click="$router.replace('/appstore/game')"
      >
        <svg fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <span>发现</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: $route.path.startsWith('/appstore/mine') }"
        @click="$router.replace('/appstore/mine')"
      >
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
        <span>我的</span>
      </div>
    </nav>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

defineOptions({ name: 'MobileTheme' })

const route = useRoute()

  const hideRouteNames = [
    'CommunityPostDetail', 'CommunityForum', 'SectionManage',
    'CommunityPostCreate', 'CommunityPostEdit', 'Login', 'Register',
    'ForgetPassword', 'AppStoreLogin', 'AppStoreBrowseDetail',
    'AppStoreDetail', 'TestDetail', 'AppStoreProfile',
    'AppStoreProfileEdit', 'AppStoreProfileComments',
    'AppStoreRecords', 'AppStoreCheckin', 'AppStoreInvite',
    'AppStoreMembership', 'AppStoreExperience', 'AppStoreFootprints', 'Exception403', 'Exception404', 'Exception500',
    'DiscoverChat', 'ChatRooms', 'ChatRoomChat',
    'AdminCenter', 'UserManage', 'RoleManage', 'AppStoreTopicManage', 'AppStoreReviewMobile',
    'CardKeyManage', 'DeleteReviewMobile', 'VerificationManage',
    'TaskManageMobile', 'ExperienceMobile', 'TitleManageMobile', 'CommissionManageMobile',
    'FileRepoManageMobile', 'FilePolicyManageMobile',
    'PluginManageMobile', 'EmailConfigMobile', 'EmailTemplatesMobile', 'EmailPushMobile', 'SmsConfigMobile', 'StorageConfigMobile', 'StorageFilesMobile',
    'MembershipManage', 'PointsManage', 'CouponManageMobile', 'CheckinManageMobile',
    'MembershipProductsMobile', 'PurchaseRecordsMobile', 'AvatarFrameManageMobile',
    'ContentPurchasesMobile', 'PaymentConfigMobile', 'SettlementMobile', 'RechargeAmountsMobile',
    'MenuManageMobile', 'SiteConfig', 'SyslogMobile', 'RecycleBinMobile', 'MobileConsole',
    'CategoryManageMobile', 'ReportsManageMobile', 'OfficialTagsManageMobile',
    'AppManageMobile', 'PersonalSpace'
  ]
const hideRoutePrefixes = ['/operation', '/system', '/dashboard', '/result', '/appstore/mall', '/appstore/submissions']
const hideNav = computed(() => {
  return hideRouteNames.includes(route.name as string) || hideRoutePrefixes.some(p => route.path.startsWith(p))
})
</script>

<style scoped>
.mobile-theme {
  min-height: 100vh;
}
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255,255,255,.95);
  backdrop-filter: blur(20px);
  display: flex;
  justify-content: space-around;
  padding: 6px 0 max(8px, env(safe-area-inset-bottom));
  border-top: 1px solid rgba(0,0,0,.05);
  z-index: 999;
}
.nav-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  cursor: pointer;
  color: #9ca3af;
  transition: color .15s;
}
.nav-item svg { width: 22px; height: 22px; }
.nav-item span { font-size: 10px; }
.nav-item.active { color: #3D7BEA; }
</style>
