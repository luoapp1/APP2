const { query } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')
const { logFromReq } = require('../middleware/security.cjs')

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

module.exports = function emailRoutes(app) {
  // 公开接口：获取所有启用的邮箱配置列表
  app.get('/api/email/configs', async (req, res) => {
    try {
      const rows = await query('SELECT id, host, port, secure, user, from_name, from_address, enabled FROM email_config WHERE enabled=1')
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  // 公开接口：获取启用的邮件模板列表（用于注册配置等场景选择）
  app.get('/api/email/templates', async (req, res) => {
    try {
      const rows = await query("SELECT id, name, code, subject, status FROM email_templates WHERE status='1' ORDER BY id")
      res.json({ code: 200, data: rows })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.get('/api/email/config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const rows = await query('SELECT id,host,port,secure,user,from_name,from_address,test_address,register_verify,enabled FROM email_config LIMIT 1')
      res.json({ code: 200, data: rows.length > 0 ? rows[0] : null })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/config', authRequired, requirePermission('edit'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { host, port, secure, user, password, fromName, fromAddress, testAddress, registerVerify, enabled } = req.body
      const existing = await query('SELECT id FROM email_config LIMIT 1')
      if (existing.length > 0) {
        const id = existing[0].id
        await query(`UPDATE email_config SET host=?,port=?,secure=?,user=?,from_name=?,from_address=?,test_address=?,register_verify=?,enabled=?,update_time=NOW() WHERE id=?`,
          [host, port, secure ? 1 : 0, user, fromName || '', fromAddress || user, testAddress || '', registerVerify ? 1 : 0, enabled ? 1 : 0, id])
        if (password) await query('UPDATE email_config SET password=? WHERE id=?', [password, id])
      } else {
        await query(`INSERT INTO email_config (host,port,secure,user,password,from_name,from_address,test_address,register_verify,enabled) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [host, port, secure ? 1 : 0, user, password, fromName || '', fromAddress || user, testAddress || '', registerVerify ? 1 : 0, enabled ? 1 : 0])
      }
      logFromReq(req, 'config', 'email', 0, `更新邮件服务配置`)
      res.json({ code: 200, message: '保存成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/test', authRequired, requirePermission('test'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, message: '无权限' })
      const { to } = req.body
      const cfg = await query('SELECT * FROM email_config LIMIT 1')
      if (!cfg.length || !cfg[0].enabled) return res.json({ code: 400, message: '邮件服务未配置或未启用' })
      const tpl = await query("SELECT * FROM email_templates WHERE code='all' AND status='1'")
      let html
      if (tpl.length) {
        html = tpl[0].html_content
          .replace(/\{\{code\}\}/g, '---')
          .replace(/\{\{subject\}\}/g, '测试邮件')
          .replace(/\{\{content\}\}/g, '这是一封测试邮件，如果您收到此邮件，说明SMTP配置正确。')
          .replace(/\{\{message\}\}/g, '邮件服务配置正常，您可以开始使用邮件推送功能。')
          .replace(/\{\{username\}\}/g, '管理员')
      } else {
        html = '这是一封测试邮件，如果您收到此邮件，说明SMTP配置正确。'
      }
      const ok = await sendEmail(cfg[0], to || cfg[0].test_address, '测试邮件 - Art Design Pro', html)
      res.json({ code: ok ? 200 : 500, message: ok ? '发送成功' : '发送失败，请检查配置' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/send-code', async (req, res) => {
    try {
      const { email, type = 'register' } = req.body
      if (!email) return res.json({ code: 400, message: '请输入邮箱地址' })
      const cfg = await query('SELECT * FROM email_config LIMIT 1')
      if (!cfg.length || !cfg[0].enabled) return res.json({ code: 400, message: '邮件服务暂不可用' })
      const recent = await query("SELECT id FROM email_verifications WHERE email=? AND create_time > DATE_SUB(NOW(), INTERVAL 60 SECOND)", [email])
      if (recent.length > 0) return res.json({ code: 400, message: '请60秒后再试' })
      const code = String(Math.floor(100000 + Math.random() * 900000))
      const expiresAt = new Date(Date.now() + 10 * 60000).toISOString().replace('T', ' ').substring(0, 19)
      await query('INSERT INTO email_verifications (email, code, type, expires_at) VALUES (?,?,?,?)', [email, code, type, expiresAt])
      const tpl = await query("SELECT * FROM email_templates WHERE code=? AND status='1'", [type === 'register' ? 'register_verify' : 'all'])
      let html
      if (tpl.length) {
        html = tpl[0].html_content
          .replace(/\{\{code\}\}/g, code)
          .replace(/\{\{subject\}\}/g, type === 'register' ? '注册验证码' : '邮箱验证码')
          .replace(/\{\{content\}\}/g, '您好，您正在进行邮箱验证。')
          .replace(/\{\{message\}\}/g, '验证码10分钟内有效，请勿泄露给他人。')
          .replace(/\{\{username\}\}/g, email)
      } else {
        html = `<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif"><h2>邮箱验证码</h2><p>您的验证码是：</p><div style="font-size:32px;font-weight:bold;color:#409EFF;padding:10px 20px;background:#f0f7ff;display:inline-block;border-radius:6px;letter-spacing:4px">${code}</div><p style="margin-top:20px;color:#999">验证码10分钟内有效，请勿泄露。</p></div>`
      }
      const ok = await sendEmail(cfg[0], email, type === 'register' ? '注册验证码 - Art Design Pro' : '邮箱验证码 - Art Design Pro', html)
      res.json({ code: ok ? 200 : 500, message: ok ? '验证码已发送' : '发送失败' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/email/verify-code', async (req, res) => {
    try {
      const { email, code, type = 'register' } = req.body
      const row = await query(`SELECT * FROM email_verifications WHERE email=? AND code=? AND type=? AND used=0 AND expires_at > NOW() ORDER BY create_time DESC LIMIT 1`, [email, code, type])
      if (row.length === 0) return res.json({ code: 400, message: '验证码无效或已过期' })
      await query('UPDATE email_verifications SET used=1 WHERE id=?', [row[0].id])
      res.json({ code: 200, message: '验证成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/sms/send-code', async (req, res) => {
    try {
      const { phone, type = 'register' } = req.body
      if (!phone) return res.json({ code: 400, message: '请输入手机号码' })

      const channelCfg = await query("SELECT config_value FROM sys_config WHERE config_key='sms_channel_enabled'")
      const channelEnabled = !channelCfg.length || channelCfg[0].config_value === 'true'

      const recent = await query("SELECT id FROM sms_verifications WHERE phone=? AND create_time > DATE_SUB(NOW(), INTERVAL 60 SECOND)", [phone])
      if (recent.length > 0) return res.json({ code: 400, message: '请60秒后再试' })

      const code = String(Math.floor(100000 + Math.random() * 900000))
      const expiresAt = new Date(Date.now() + 10 * 60000).toISOString().replace('T', ' ').substring(0, 19)
      await query('INSERT INTO sms_verifications (phone, code, type, expires_at) VALUES (?,?,?,?)', [phone, code, type, expiresAt])

      if (!channelEnabled) {
        console.log('[SMS] 短信通道已关闭，验证码仅存库:', code)
        return res.json({ code: 200, message: '验证码已发送', data: { code } })
      }

      const sent = await trySendSms(phone, code, type)
      if (!sent) return res.json({ code: 500, message: '短信发送失败，请检查短信服务配置' })

      res.json({ code: 200, message: '验证码已发送', data: { code } })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })

  app.post('/api/sms/verify-code', async (req, res) => {
    try {
      const { phone, code, type = 'register' } = req.body
      const row = await query(`SELECT * FROM sms_verifications WHERE phone=? AND code=? AND type=? AND used=0 AND expires_at > NOW() ORDER BY create_time DESC LIMIT 1`, [phone, code, type])
      if (row.length === 0) return res.json({ code: 400, message: '验证码无效或已过期' })
      await query('UPDATE sms_verifications SET used=1 WHERE id=?', [row[0].id])
      res.json({ code: 200, message: '验证成功' })
    } catch (e) { res.status(500).json({ code: 500, message: e.message }) }
  })
}

async function sendEmail(config, to, subject, html) {
  try {
    const nodemailer = require('nodemailer')
    const transporter = nodemailer.createTransport({
      host: config.host, port: config.port,
      secure: config.secure === 1,
      auth: { user: config.user, pass: config.password }
    })
    await transporter.sendMail({ from: config.from_address ? `"${config.from_name || ''}" <${config.from_address}>` : config.user, to, subject, html })
    return true
  } catch (e) { console.error('邮件发送失败:', e.message); return false }
}

async function trySendSms(phone, code, type) {
  try {
    const { decryptConfigJson } = require('./sms-config.cjs')

    const cfgs = await query("SELECT * FROM sms_config WHERE enabled=1 ORDER BY is_default DESC, id ASC")
    if (!cfgs.length) { console.log('[SMS] 无启用的短信配置，验证码仅存库'); return true }

    const tplParams = type === 'register' ? `{"code":"${code}"}` : `{"code":"${code}"}`

    for (const cfg of cfgs) {
      cfg.config_json = decryptConfigJson(cfg.config_json)
    }
    const primary = cfgs[0]
    const fallback = cfgs.length > 1 ? cfgs[1] : null

    const sent = await sendWithProvider(primary, phone, code, type, tplParams)
    if (sent) return true

    if (fallback) {
      console.log(`[SMS] 主服务商 ${primary.provider} 发送失败，切换到备用 ${fallback.provider}`)
      return await sendWithProvider(fallback, phone, code, type, tplParams)
    }

    return false
  } catch (e) { console.error('[SMS] 发送异常:', e.message); return true }
}

async function sendWithProvider(cfg, phone, code, type, tplParams) {
  const json = typeof cfg.config_json === 'string' ? JSON.parse(cfg.config_json) : (cfg.config_json || {})
  const signName = cfg.sign_name || ''
  const tplCode = cfg.template_code || ''

  switch (cfg.provider) {
    case 'aliyun':
      return await sendAliyunSms(json.accessKeyId, json.accessKeySecret, signName, tplCode, phone, tplParams)
    case 'tencent':
      return await sendTencentSms(json.secretId, json.secretKey, json.appId, signName, tplCode, phone, code)
    case 'huawei':
      return await sendHuaweiSms(json.appKey, json.appSecret, json.sender || signName, tplCode, phone, code)
    default:
      console.log(`[SMS] 服务商 ${cfg.provider} 未实现真实发送，验证码已存库`)
      return true
  }
}

const crypto = require('crypto')

function sha256Hex(data) { return crypto.createHash('sha256').update(data, 'utf8').digest('hex') }
function hmacSha256(key, data) { return crypto.createHmac('sha256', key).update(data, 'utf8').digest('hex') }

async function sendAliyunSms(accessKeyId, accessKeySecret, signName, tplCode, phone, tplParams) {
  try {
    if (!accessKeyId || !accessKeySecret || !signName || !tplCode) { console.log('[SMS] 阿里云配置不完整'); return false }
    const params = {
      AccessKeyId: accessKeyId,
      Action: 'SendSms',
      Format: 'JSON',
      PhoneNumbers: phone,
      SignName: signName,
      TemplateCode: tplCode,
      TemplateParam: tplParams,
      SignatureMethod: 'HMAC-SHA1',
      SignatureVersion: '1.0',
      SignatureNonce: Date.now() + '' + Math.random(),
      Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
      Version: '2017-05-25',
      RegionId: 'cn-hangzhou'
    }
    const sorted = Object.keys(params).sort()
    const qs = sorted.map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k])).join('&')
    const strToSign = 'GET&%2F&' + encodeURIComponent(qs)
    const sig = crypto.createHmac('sha1', accessKeySecret + '&').update(strToSign, 'utf8').digest('base64')
    const url = 'https://dysmsapi.aliyuncs.com/?' + qs + '&Signature=' + encodeURIComponent(sig)
    const resp = await fetch(url)
    const data = await resp.json()
    console.log('[SMS] 阿里云响应:', JSON.stringify(data))
    return data.Code === 'OK'
  } catch (e) { console.error('[SMS] 阿里云发送失败:', e.message); return false }
}

async function sendTencentSms(secretId, secretKey, appId, signName, tplId, phone, code) {
  try {
    if (!secretId || !secretKey || !appId || !tplId) { console.log('[SMS] 腾讯云配置不完整'); return false }
    const payload = JSON.stringify({
      PhoneNumberSet: ['+86' + phone],
      SmsSdkAppId: appId,
      SignName: signName,
      TemplateId: tplId,
      TemplateParamSet: [code]
    })
    const timestamp = Math.floor(Date.now() / 1000)
    const date = new Date(timestamp * 1000).toISOString().substring(0, 10)
    const service = 'sms', host = 'sms.tencentcloudapi.com', action = 'SendSms', version = '2021-01-11'
    const ct = 'application/json; charset=utf-8'
    const hashedPayload = sha256Hex(payload)
    const canonicalRequest = ['POST', '/', '', 'content-type:' + ct, 'host:' + host, '', 'content-type;host', hashedPayload].join('\n')
    const stringToSign = ['TC3-HMAC-SHA256', timestamp, date + '/' + service + '/tc3_request', sha256Hex(canonicalRequest)].join('\n')
    const secretDate = hmacSha256('TC3' + secretKey, date)
    const secretService = hmacSha256(secretDate, service)
    const secretSigning = hmacSha256(secretService, 'tc3_request')
    const signature = hmacSha256(secretSigning, stringToSign).toString('hex')
    const auth = 'TC3-HMAC-SHA256 Credential=' + secretId + '/' + date + '/' + service + '/tc3_request, SignedHeaders=content-type;host, Signature=' + signature
    const resp = await fetch('https://' + host, {
      method: 'POST',
      headers: { 'Content-Type': ct, 'Host': host, 'X-TC-Action': action, 'X-TC-Version': version, 'X-TC-Timestamp': String(timestamp), 'Authorization': auth },
      body: payload
    })
    const data = await resp.json()
    console.log('[SMS] 腾讯云响应:', JSON.stringify(data))
    return data.Response && data.Response.SendStatusSet && data.Response.SendStatusSet[0] && data.Response.SendStatusSet[0].Code === 'Ok'
  } catch (e) { console.error('[SMS] 腾讯云发送失败:', e.message); return false }
}

async function sendHuaweiSms(appKey, appSecret, sender, tplId, phone, code) {
  try {
    if (!appKey || !appSecret || !sender || !tplId) { console.log('[SMS] 华为云配置不完整'); return false }
    const body = new URLSearchParams({ from: sender, to: '+86' + phone, templateId: tplId, templateParas: '["' + code + '"]', statusCallback: '' })
    const wsseHeader = buildHuaweiWsse(appKey, appSecret)
    const resp = await fetch('https://rtcsms.cn-north-1.myhuaweicloud.com:10743/sms/batchSendSms/v1', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': wsseHeader },
      body: body.toString()
    })
    const data = await resp.json()
    console.log('[SMS] 华为云响应:', JSON.stringify(data))
    return data.code === '000000'
  } catch (e) { console.error('[SMS] 华为云发送失败:', e.message); return false }
}

function buildHuaweiWsse(appKey, appSecret) {
  const nonce = Date.now() + '' + Math.random()
  const created = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')
  const digest = crypto.createHash('sha256').update(nonce + created + appSecret).digest('base64')
  return 'WSSE realm="SDP",profile="UsernameToken",type="Appkey"'
}
