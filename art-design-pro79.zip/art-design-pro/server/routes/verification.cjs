const { query, getSystemOperator } = require('../database.cjs')
const { authRequired, requirePermission, sessions, SESSION_TTL } = require('./system.cjs')

async function getUserId(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return 0
  const session = sessions.get(token)
  if (session) {
    if (Date.now() - session.createdAt > SESSION_TTL) { sessions.delete(token); return 0 }
    return Number(session.userId) || 0
  }
  try {
    const rows = await query('SELECT user_id, roles, created_at FROM sessions WHERE token=?', [token])
    if (rows.length > 0) {
      const createdAt = typeof rows[0].created_at === 'number' ? rows[0].created_at : new Date(rows[0].created_at).getTime()
      if (Date.now() - createdAt > SESSION_TTL) { return 0 }
      return Number(rows[0].user_id) || 0
    }
  } catch {}
  return 0
}

async function isAdmin(req) {
  const raw = req.headers.authorization || req.headers.token || req.query.token || ''
  const token = raw.replace(/^Bearer\s+/i, '')
  if (!token) return false
  const session = sessions.get(token)
  if (session) { const roles = session.roles || []; return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  try {
    const rows = await query('SELECT roles FROM sessions WHERE token=?', [token])
    if (rows.length > 0) { const roles = JSON.parse(rows[0].roles || '[]'); return roles.includes('R_SUPER') || roles.includes('R_ADMIN') }
  } catch {}
  return false
}

module.exports = function verificationRoutes(app) {
  // ===== 初始化表 =====
  function initVerificationTables() {
    try {
      const autoInc = 'AUTO_INCREMENT'
      query(`CREATE TABLE IF NOT EXISTS verification_config (
        id INTEGER PRIMARY KEY ${autoInc},
        condition_type VARCHAR(50) NOT NULL,
        threshold INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 0,
        logic_type VARCHAR(20) DEFAULT 'any',
        logic_count INTEGER DEFAULT 1,
        create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        update_time DATETIME DEFAULT CURRENT_TIMESTAMP
      )`)
      query("ALTER TABLE verification_requests ADD COLUMN selected_condition VARCHAR(50) DEFAULT ''").catch(() => {})
      query("ALTER TABLE verification_requests ADD COLUMN selected_app_id INTEGER DEFAULT 0").catch(() => {})
    } catch (e) {
      console.error('verification initTables error:', e.message)
    }
  }
  initVerificationTables()

  // ===== 管理员配置认证条件 =====
  app.get('/api/verification/config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const rows = await query('SELECT * FROM verification_config ORDER BY id')
      const conditions = [
        { type: 'follower_count', label: '粉丝数量' },
        { type: 'app_count', label: '上传应用数量' },
        { type: 'app_developer', label: '应用开发者' },
        { type: 'post_count', label: '发帖数量' },
      ]
      const map = {}
      rows.forEach(r => { map[r.condition_type] = r })
      const list = conditions.map(c => {
        const cfg = map[c.type]
        return {
          condition_type: c.type,
          label: c.label,
          threshold: cfg ? cfg.threshold : 0,
          is_active: cfg ? cfg.is_active : 0,
          id: cfg ? cfg.id : 0,
        }
      })
      const logicCfg = rows.length > 0 ? rows[0] : null
      res.json({
        code: 200,
        data: {
          conditions: list,
          logic_type: logicCfg ? logicCfg.logic_type : 'any',
          logic_count: logicCfg ? logicCfg.logic_count : 1,
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/verification/config', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { conditions, logic_type, logic_count } = req.body
      await query('DELETE FROM verification_config')
      for (const c of conditions) {
        await query('INSERT INTO verification_config (condition_type, threshold, is_active, logic_type, logic_count) VALUES (?, ?, ?, ?, ?)',
          [c.condition_type, c.threshold || 0, c.is_active ? 1 : 0, logic_type || 'any', logic_count || 1])
      }
      res.json({ code: 200, msg: '配置已保存' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ===== 客户端获取配置（公开） =====
  app.get('/api/verification/client-config', async (req, res) => {
    try {
      const rows = await query('SELECT * FROM verification_config WHERE is_active=1')
      const conditions = rows.map(r => ({
        condition_type: r.condition_type,
        label: { follower_count: '粉丝数量', app_count: '上传应用数量', app_developer: '应用开发者', post_count: '发帖数量' }[r.condition_type] || r.condition_type,
        threshold: r.threshold,
      }))
      const logicCfg = rows.length > 0 ? rows[0] : null
      res.json({
        code: 200,
        data: {
          conditions,
          logic_type: logicCfg ? logicCfg.logic_type : 'any',
          logic_count: logicCfg ? logicCfg.logic_count : 1,
        }
      })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ===== 获取用户已审核通过的应用列表 =====
  app.get('/api/verification/user-apps', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const apps = await query(
        "SELECT id, name, icon, package_name FROM app_uploads WHERE user_id=? AND submission_status='approved' ORDER BY create_time DESC",
        [userId]
      )
      res.json({ code: 200, data: apps })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
  app.post('/api/verification/apply', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const { realName, idCard, organization, reason, proofUrls, selectedCondition, selectedAppId } = req.body
      const pending = await query("SELECT id FROM verification_requests WHERE user_id=? AND status='pending'", [userId])
      if (pending.length > 0) return res.json({ code: 400, msg: '您已有待审核的认证申请' })
      const user = await query('SELECT is_verified FROM users WHERE id=?', [userId])
      if (user[0] && user[0].is_verified === 1) return res.json({ code: 400, msg: '您已是认证用户' })

      // 验证条件是否满足
      if (selectedCondition) {
        const config = await query('SELECT * FROM verification_config WHERE condition_type=? AND is_active=1', [selectedCondition])
        if (config.length === 0) return res.json({ code: 400, msg: '该认证条件未启用' })

        const threshold = config[0].threshold || 0
        let actualValue = 0
        const conditionLabel = { follower_count: '粉丝数', app_count: '应用数', app_developer: '应用开发者', post_count: '帖子数' }[selectedCondition] || selectedCondition

        if (selectedCondition === 'follower_count') {
          const rows = await query('SELECT COUNT(*) as cnt FROM user_follows WHERE following_id=?', [userId])
          actualValue = rows[0]?.cnt || 0
        } else if (selectedCondition === 'app_count') {
          const rows = await query("SELECT COUNT(*) as cnt FROM app_uploads WHERE user_id=? AND submission_status='approved'", [userId])
          actualValue = rows[0]?.cnt || 0
        } else if (selectedCondition === 'post_count') {
          const rows = await query('SELECT COUNT(*) as cnt FROM community_posts WHERE user_id=?', [userId])
          actualValue = rows[0]?.cnt || 0
        } else if (selectedCondition === 'app_developer') {
          if (!selectedAppId) return res.json({ code: 400, msg: '请选择已审核通过的应用' })
          const apps = await query("SELECT id FROM app_uploads WHERE id=? AND user_id=? AND submission_status='approved'", [selectedAppId, userId])
          if (apps.length === 0) return res.json({ code: 400, msg: '所选应用不是您上传的或未审核通过' })
          actualValue = 1 // 应用开发者只要有一个审核通过的应用就满足
        }

        if (actualValue < threshold) {
          return res.json({ code: 400, msg: `您的${conditionLabel}不足（需要≥${threshold}，当前为${actualValue}），不满足认证条件` })
        }
      }

      await query(`INSERT INTO verification_requests (user_id, user_name, real_name, id_card, organization, reason, proof_urls, selected_condition, selected_app_id)
         VALUES (?, (SELECT username FROM users WHERE id=?), ?, ?, ?, ?, ?, ?, ?)`,
        [userId, userId, realName || '', idCard || '', organization || '', reason || '', JSON.stringify(proofUrls || []), selectedCondition || '', selectedAppId || 0])

      // 向申请人发送通知
      try {
        await query(
          `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES ('认证申请已提交', '您的蓝V认证申请已提交，请耐心等待管理员审核', 'verification', ?, 0, '系统', '')`,
          [userId]
        )
      } catch {}

      // 向所有管理员发送系统通知
      try {
        const admins = await query("SELECT id FROM users WHERE roles LIKE '%R_SUPER%' OR roles LIKE '%R_ADMIN%'")
        const notifyMsg = `${realName || '用户'} 提交了蓝V认证申请，请及时审核`
        for (const admin of admins) {
          await query(
            `INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES ('新的认证申请', ?, 'verification', ?, ?, (SELECT username FROM users WHERE id=?), '')`,
            [notifyMsg, admin.id, userId, userId]
          )
        }
      } catch {}

      res.json({ code: 200, msg: '申请已提交，请等待审核' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  // ===== 公开查询用户认证状态 =====
  app.get('/api/verification/public-status/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId) || 0
      const user = await query('SELECT is_verified, verified_org FROM users WHERE id=?', [userId])
      let certificationTitle = ''
      if (user.length > 0 && user[0].is_verified === 1) {
        const approved = await query("SELECT reason FROM verification_requests WHERE user_id=? AND status='approved' ORDER BY create_time DESC LIMIT 1", [userId])
        if (approved.length > 0) certificationTitle = approved[0].reason || ''
      }
      res.json({ code: 200, data: { isVerified: user.length > 0 && user[0].is_verified === 1, verifiedOrg: user.length > 0 ? user[0].verified_org : '', certificationTitle } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/verification/status', authRequired, async (req, res) => {
    try {
      const userId = await getUserId(req)
      const user = await query('SELECT is_verified, verified_org FROM users WHERE id=?', [userId])
      const lastReq = await query('SELECT id, status, review_comment FROM verification_requests WHERE user_id=? ORDER BY create_time DESC LIMIT 1', [userId])
      let certificationTitle = ''
      if (user.length > 0 && user[0].is_verified === 1) {
        const approved = await query("SELECT reason FROM verification_requests WHERE user_id=? AND status='approved' ORDER BY create_time DESC LIMIT 1", [userId])
        if (approved.length > 0) certificationTitle = approved[0].reason || ''
      }
      res.json({ code: 200, data: { isVerified: user.length > 0 && user[0].is_verified === 1, verifiedOrg: user.length > 0 ? user[0].verified_org : '', certificationTitle, lastRequest: lastReq.length > 0 ? lastReq[0] : null } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.get('/api/verification/list', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { status = 'pending', page = 1, pageSize = 20 } = req.query
      const offset = (page - 1) * pageSize
      const list = await query(
        `SELECT vr.*, u.avatar, u.nickname FROM verification_requests vr JOIN users u ON vr.user_id=u.id WHERE vr.status=? ORDER BY vr.create_time DESC LIMIT ? OFFSET ?`,
        [status, parseInt(pageSize), offset])
      // 追加关联的应用名称
      const enriched = await Promise.all(list.map(async (item) => {
        let selectedAppName = ''
        if (item.selected_condition === 'app_developer' && item.selected_app_id) {
          const apps = await query('SELECT name FROM app_uploads WHERE id=?', [item.selected_app_id])
          if (apps.length > 0) selectedAppName = apps[0].name
        }
        return { ...item, selected_app_name: selectedAppName }
      }))
      const cnt = await query('SELECT COUNT(*) as total FROM verification_requests WHERE status=?', [status])
      res.json({ code: 200, data: { records: enriched, total: cnt[0].total } })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/verification/:id/review', authRequired, requirePermission('approve'), async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      const { action, comment } = req.body
      const reqId = parseInt(req.params.id)
      const vReq = await query('SELECT * FROM verification_requests WHERE id=?', [reqId])
      if (vReq.length === 0 || vReq[0].status !== 'pending') return res.json({ code: 400, msg: '申请不存在或已处理' })
      const now = new Date().toISOString().replace('T', ' ').substring(0, 19)
      if (action === 'approve') {
        await query("UPDATE verification_requests SET status='approved', review_comment=?, review_time=? WHERE id=?", [comment || '', now, reqId])
        await query('UPDATE users SET is_verified=1, verified_org=? WHERE id=?', [vReq[0].organization || '', vReq[0].user_id])
        const sysOpName1 = (await getSystemOperator())?.username || '管理员'
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES ('认证申请通过','恭喜，您的蓝V认证申请已通过审核！','system',?, 0, ?, '')`, [vReq[0].user_id, sysOpName1])
      } else {
        await query("UPDATE verification_requests SET status='rejected', review_comment=?, review_time=? WHERE id=?", [comment || '', now, reqId])
        const sysOpName2 = (await getSystemOperator())?.username || '管理员'
        await query(`INSERT INTO sys_notifications (title, content, type, target_user_id, from_user_id, from_user_name, from_user_avatar) VALUES ('认证申请未通过',?,'system',?, 0, ?, '')`, [comment || '您的蓝V认证申请未通过审核', vReq[0].user_id, sysOpName2])
      }
      res.json({ code: 200, msg: '操作成功' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })

  app.post('/api/verification/cancel', authRequired, async (req, res) => {
    try {
      if (!await isAdmin(req)) return res.json({ code: 403, msg: '无权限' })
      await query('UPDATE users SET is_verified=0, verified_org="" WHERE id=?', [req.body.userId])
      res.json({ code: 200, msg: '认证已取消' })
    } catch (e) { res.json({ code: 500, msg: e.message }) }
  })
}
