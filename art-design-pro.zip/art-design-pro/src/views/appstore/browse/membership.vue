<template>
  <div class="mc-page">
    <div class="mc-navbar">
      <button class="mc-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="mc-nav-title">会员中心</span>
      <div style="width:22px" />
    </div>

    <div v-if="loading" class="mc-loading">加载中...</div>

    <template v-else>
      <div class="mc-current" v-if="currentLevel">
        <div class="mc-badge" :style="{background: currentLevel.iconColor || '#6366F1'}">
          <span class="mc-badge-icon">{{ currentLevel.name?.charAt(0) || 'V' }}</span>
        </div>
        <div class="mc-info">
          <div class="mc-level-name">{{ currentLevel.name }}</div>
          <div class="mc-level-tier" v-if="currentLevel.tier === 2">二级会员</div>
          <div class="mc-expire" v-if="expireTime">
            {{ new Date(expireTime) > new Date() ? '有效期至 ' + expireTime.slice(0,10) : '已过期' }}
          </div>
        </div>
      </div>

      <div v-else class="mc-no-level">您还不是会员，立即开通享受专属权益</div>

      <div class="mc-products">
        <h3 class="mc-section-title">选择会员套餐</h3>
        <div v-if="!products.length" class="mc-empty">暂无可用套餐</div>
        <div v-for="p in products" :key="p.id" class="mc-product-card" :class="{ promo: p.is_promo }">
          <div class="mpc-badge" v-if="p.is_promo">限时优惠</div>
          <div class="mpc-name">{{ p.name }}</div>
          <div class="mpc-level">{{ levelName(p.level_id) }}</div>
          <div class="mpc-duration">{{ p.duration_days }}天</div>
          <div class="mpc-price">
            <span class="mpc-price-num">{{ p.is_promo ? p.price : (p.original_price || p.price) }}</span>
            <span class="mpc-price-unit">元</span>
            <span class="mpc-original" v-if="p.is_promo && p.original_price">{{ p.original_price }}元</span>
          </div>
          <button class="mpc-buy-btn" @click="doBuy(p)">立即购买</button>
        </div>
      </div>

      <div class="mc-history" v-if="purchases.length">
        <h3 class="mc-section-title">购买记录</h3>
        <div v-for="p in purchases" :key="'h'+p.id" class="mc-history-item">
          <div class="mhi-left">
            <span class="mhi-level">{{ p.level_name }}</span>
            <span class="mhi-type">{{ {buy:'购买',renew:'续费',upgrade:'升级'}[p.purchase_type] }}</span>
          </div>
          <div class="mhi-right">
            <span class="mhi-amount">{{ p.amount }}元</span>
            <span class="mhi-time">{{ p.create_time?.slice(0,10) }}</span>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'
import { getUserId } from '@/utils/auth'

const loading = ref(true)
const currentLevel = ref<any>(null)
const expireTime = ref('')
const products = ref<any[]>([])
const levels = ref<any[]>([])
const purchases = ref<any[]>([])

function levelName(id: number) {
  const l = levels.value.find((x: any) => x.id === id)
  return l ? (l.tier === 2 ? l.name + ' (二级)' : l.name) : '-'
}

async function loadData() {
  try {
    const uid = getUserId()
    const r1: any = await request.get({ url: '/api/membership/products' })
    products.value = (r1.data || r1 || []).filter((p: any) => p.status === '1')

    const r2: any = await request.get({ url: '/api/operation/membership-level/list' })
    levels.value = r2.data?.records || r2.data || []

    if (uid) {
      const r3: any = await request.get({ url: '/api/user/info', params: { userId: uid } })
      const info = r3.data || r3 || {}
      if (info.level_id) {
        currentLevel.value = levels.value.find((l: any) => l.id === info.level_id) || null
        expireTime.value = info.expire_time || ''
      }
      const r4: any = await request.get({ url: '/api/membership/purchases/my' })
      purchases.value = r4.data || r4 || []
    }
  } catch {} finally { loading.value = false }
}

async function doBuy(product: any) {
  try {
    const r: any = await request.post({ url: '/api/membership/buy', data: { productId: product.id } })
    ElMessage.success('购买成功! 当前等级: ' + (r.data?.levelName || ''))
    loadData()
  } catch (e: any) {
    ElMessage.error(e?.msg || '购买失败')
  }
}

onMounted(loadData)
</script>

<style scoped>
.mc-page { min-height: 100vh; background: #f8f9fa; }
.mc-navbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #fff; border-bottom: 1px solid #eee; }
.mc-nav-back { border: none; background: none; cursor: pointer; padding: 4px; }
.mc-nav-title { font-size: 17px; font-weight: 600; }
.mc-loading { text-align: center; padding: 60px 0; color: #999; }
.mc-current { display: flex; align-items: center; gap: 16px; padding: 20px; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; }
.mc-badge { width: 56px; height: 56px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.mc-badge-icon { font-size: 22px; font-weight: 700; }
.mc-info { flex: 1; }
.mc-level-name { font-size: 18px; font-weight: 700; }
.mc-level-tier { font-size: 12px; opacity: .8; }
.mc-expire { font-size: 13px; opacity: .7; margin-top: 4px; }
.mc-no-level { text-align: center; padding: 32px 16px; color: #666; background: #fff; margin: 12px; border-radius: 12px; }
.mc-products { padding: 16px; }
.mc-section-title { font-size: 16px; font-weight: 600; margin-bottom: 12px; }
.mc-empty { text-align: center; padding: 24px; color: #999; }
.mc-product-card { background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 12px; position: relative; border: 2px solid transparent; }
.mc-product-card.promo { border-color: #EF4444; }
.mpc-badge { position: absolute; top: -8px; right: 12px; background: #EF4444; color: #fff; font-size: 11px; padding: 2px 8px; border-radius: 8px; font-weight: 600; }
.mpc-name { font-size: 16px; font-weight: 600; }
.mpc-level { font-size: 13px; color: #666; margin-top: 4px; }
.mpc-duration { font-size: 13px; color: #999; margin-top: 2px; }
.mpc-price { margin: 12px 0; display: flex; align-items: baseline; gap: 4px; }
.mpc-price-num { font-size: 28px; font-weight: 700; color: #EF4444; }
.mpc-price-unit { font-size: 14px; color: #EF4444; }
.mpc-original { font-size: 13px; color: #999; text-decoration: line-through; }
.mpc-buy-btn { width: 100%; height: 40px; border: none; border-radius: 10px; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.mc-history { padding: 0 16px 16px; }
.mc-history-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
.mhi-left { display: flex; flex-direction: column; }
.mhi-level { font-size: 14px; font-weight: 500; }
.mhi-type { font-size: 12px; color: #999; }
.mhi-right { text-align: right; }
.mhi-amount { font-size: 14px; font-weight: 600; color: #EF4444; }
.mhi-time { font-size: 12px; color: #999; }
</style>
