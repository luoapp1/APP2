<template>
  <div class="min-h-screen bg-white flex flex-col">
    <div class="flex flex-1 overflow-hidden">
      <div class="w-[80px] bg-gray-50 flex-shrink-0 overflow-y-auto pb-16">
        <div
          v-for="cat in categories"
          :key="cat"
          class="px-2 py-3 text-center text-xs cursor-pointer transition-colors"
          :class="activeCategory === cat ? 'bg-white text-[#00BFA5] font-semibold' : 'text-gray-500'"
          @click="selectCategory(cat)"
        >{{ cat }}</div>
      </div>

      <div class="flex-1 overflow-y-auto pb-16 px-3">
        <div class="py-2.5 sticky top-0 bg-white z-10">
          <div class="flex items-center bg-gray-100 rounded-full px-3 py-2 gap-2">
            <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="1.5"/><path d="M21 21l-4.35-4.35" stroke-width="1.5" stroke-linecap="round"/></svg>
            <input v-model="keyword" class="flex-1 bg-transparent text-sm outline-none text-gray-600 placeholder-gray-400" placeholder="搜索应用" @keyup.enter="searchApps" />
          </div>
        </div>

        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-6 h-6 border-2 border-[#00BFA5] border-t-transparent rounded-full" />
        </div>

        <div v-else class="space-y-2.5">
          <div
            v-for="app in appList"
            :key="app.id"
            class="bg-white rounded-xl p-3 flex items-center gap-3 cursor-pointer active:bg-gray-50"
            @click="openDetail(app.id)"
          >
            <div class="w-[50px] h-[50px] rounded-2xl flex-shrink-0 flex items-center justify-center overflow-hidden" :style="{ background: app.iconBgColor || '#00BFA5' }">
              <img v-if="app.icon" :src="app.icon" class="w-full h-full object-cover" />
              <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div class="flex-1 min-w-0">
              <div class="text-sm font-semibold text-gray-900">{{ app.name }}</div>
              <div class="flex items-center gap-1.5 mt-0.5">
                <svg class="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                <span class="text-xs font-medium text-gray-700">{{ toNum(app.rating).toFixed(1) }}</span>
                <span class="text-xs text-gray-400">{{ app.version }}</span>
                <span class="text-[11px] text-gray-300">|</span>
                <span class="text-xs text-gray-400">{{ app.sizeMb }}MB</span>
              </div>
              <div class="flex items-center gap-1.5 mt-1 flex-wrap">
                <span v-for="ot in (app.officialTags || [])" :key="ot.id" class="text-[10px] px-1.5 py-0.5 rounded-full" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
                <span v-for="tag in (app.tags || [])" :key="tag" class="text-[10px] px-1.5 py-0.5 rounded-full" :class="tag === '星选' ? 'bg-purple-50 text-purple-600' : 'bg-teal-50 text-teal-600'">{{ tag }}</span>
                <span class="text-[11px] text-gray-400">{{ fmtCount(app.downloads) }}下载</span>
              </div>
            </div>
            <button class="flex-shrink-0 px-3 py-1 rounded-full border text-xs" style="border-color:#00BFA5;color:#00BFA5" @click.stop="openDetail(app.id)">查看</button>
          </div>
        </div>
      </div>
    </div>

    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-around py-1 z-10" style="padding-bottom:max(6px,env(safe-area-inset-bottom))">
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/browse')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span class="text-[10px]">首页</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer" style="color:#00BFA5">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        <span class="text-[10px]">应用</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/updates')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <span class="text-[10px]">社区</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/game')">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <span class="text-[10px]">发现</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/mine')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
        <span class="text-[10px]">我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchAppList, fetchCategoryList } from '@/api/appstore'

const keyword = ref('')
const activeCategory = ref('全部')
const appList = ref<any[]>([])
const loading = ref(true)
const categories = ref<string[]>(['全部'])

const toNum = (v: any) => Number(v) || 0
const fmtCount = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

const loadApps = async () => {
  loading.value = true
  try {
    const params: Record<string, unknown> = { page: 1, pageSize: 20, status: '1' }
    if (activeCategory.value !== '全部') {
      params.category = activeCategory.value
    }
    if (keyword.value) params.keyword = keyword.value
    const res: any = await fetchAppList(params)
    appList.value = res.list || []
  } catch {}
  loading.value = false
}

const selectCategory = (cat: string) => {
  activeCategory.value = cat
  loadApps()
}

const searchApps = () => loadApps()
const openDetail = (id: number) => window.open(`/#/appstore/browse/detail/${id}`, '_blank')

onMounted(async () => {
  try {
    const data: any = await fetchCategoryList()
    if (Array.isArray(data) && data.length > 0) {
      categories.value = ['全部', ...data.map((c: any) => c.name)]
    }
  } catch {}
  loadApps()
})
</script>
