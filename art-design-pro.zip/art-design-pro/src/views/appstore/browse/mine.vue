<template>
  <div style="min-height: 100vh; background: #f5f5f5; display: flex; flex-direction: column">
    <div style="flex: 1; overflow-y: auto; padding-bottom: 64px">
      <!-- 个人信息区 -->
      <div
        style="display: flex; align-items: center; padding: 16px; background: #fff; cursor: pointer"
        @click="handleAvatarClick"
      >
        <div
          style="
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: #f3f4f6;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
          "
        >
          <img
            v-if="isLogin && userInfo.avatar"
            :src="userInfo.avatar"
            style="width: 100%; height: 100%; object-fit: cover"
          />
          <svg
            v-else
            style="width: 28px; height: 28px; color: #d1d5db"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <div style="margin-left: 12px; flex: 1">
          <div style="font-size: 16px; font-weight: 600; color: #1f2937">{{
            isLogin ? userInfo.userName || '用户' : '请先登录'
          }}</div>
          <div style="display: flex; align-items: center; gap: 8px; margin-top: 2px">
            <span style="font-size: 12px; font-weight: 500; color: #00bfa5">{{
              isLogin ? levelName : 'Lv.0'
            }}</span>
            <div
              style="
                flex: 1;
                height: 6px;
                background: #f3f4f6;
                border-radius: 999px;
                overflow: hidden;
                max-width: 180px;
              "
            >
              <div
                style="height: 100%; border-radius: 999px; background: #00bfa5"
                :style="{ width: expPercent + '%' }"
              />
            </div>
          </div>
        </div>
        <div style="display: flex; align-items: center; gap: 4px">
          <span style="font-size: 12px; font-weight: 500; color: #9ca3af">{{ expDisplay }}</span>
          <svg
            style="width: 16px; height: 16px; color: #9ca3af"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 我的账户卡片 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; padding: 16px">
        <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 12px"
          >我的账户</div
        >
        <div style="display: grid; grid-template-columns: repeat(4, 1fr)">
          <div style="display: flex; flex-direction: column; align-items: center; gap: 2px">
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? balanceStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">余额</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6;
            "
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? pointsStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">积分</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6;
            "
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">0</span>
            <span style="font-size: 10px; color: #9ca3af">粉丝</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6;
            "
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">0</span>
            <span style="font-size: 10px; color: #9ca3af">付费</span>
          </div>
        </div>
      </div>

      <!-- 功能图标 -->
      <div style="background: #fff; margin: 0 12px; border-radius: 16px; padding: 20px 8px 8px 8px">
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); row-gap: 20px">
          <div
            v-for="item in funcIcons"
            :key="item.label"
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 6px;
              cursor: pointer;
            "
            @click="handleFuncIcon(item)"
          >
            <div
              style="
                width: 44px;
                height: 44px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
              "
              :style="{ background: item.bg }"
            >
              <svg
                style="width: 20px; height: 20px; color: #fff"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path :d="item.icon" />
              </svg>
            </div>
            <span style="font-size: 11px; color: #374151">{{ item.label }}</span>
          </div>
        </div>
        <div
          style="
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            padding: 12px 0;
          "
        >
          <div style="width: 12px; height: 4px; border-radius: 999px; background: #00bfa5" />
          <div style="width: 6px; height: 6px; border-radius: 50%; background: #e5e7eb" />
        </div>
        <div
          style="
            margin: 0 4px 12px 4px;
            background: #f5f5f5;
            border-radius: 12px;
            display: flex;
            align-items: center;
            padding: 10px 12px;
            gap: 8px;
            cursor: pointer;
          "
        >
          <svg
            style="width: 16px; height: 16px; color: #6b7280"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fill-rule="evenodd"
              d="M18 3a1 1 0 00-1.447-.894L8.763 6H5a3 3 0 000 6h.28l1.771 5.316A1 1 0 008 18h1a1 1 0 001-1v-4.382l6.553 3.276A1 1 0 0018 15V3z"
              clip-rule="evenodd"
            />
          </svg>
          <span
            style="
              flex: 1;
              font-size: 12px;
              color: #6b7280;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            "
            >全站规则，快来看看，不然就亏大了</span
          >
          <svg
            style="width: 14px; height: 14px; color: #9ca3af"
            fill="none"
            stroke="currentColor"
            stroke-width="2.5"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 菜单列表 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; overflow: hidden">
        <div
          v-for="(item, idx) in computedMenuItems"
          :key="item.label"
          style="display: flex; align-items: center; padding: 14px 16px; cursor: pointer"
          :style="{
            borderBottom: idx < computedMenuItems.length - 1 ? '1px solid #f9fafb' : 'none'
          }"
          @click="handleMenuItem(item)"
        >
          <svg
            style="width: 20px; height: 20px; margin-right: 12px; flex-shrink: 0"
            :style="{ color: item.highlight ? '#00BFA5' : '#9ca3af' }"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path :d="item.icon" />
          </svg>
          <span
            style="flex: 1; font-size: 14px"
            :style="{
              color: item.highlight ? '#00BFA5' : '#374151',
              fontWeight: item.highlight ? '600' : '400'
            }"
            >{{ item.label }}</span
          >
          <svg
            style="width: 16px; height: 16px; color: #d1d5db"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>

    <!-- 卡密兑换弹窗 -->
    <div
      v-if="showCardKeyDialog"
      style="
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
      "
      @click.self="showCardKeyDialog = false"
    >
      <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 16px"
          >卡密兑换</div
        >
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.cardNo"
            placeholder="请输入卡号"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.password"
            type="text"
            placeholder="请输入卡密密码"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div v-if="cardKeyMsg" style="font-size: 12px; color: #00bfa5; margin-bottom: 8px">{{
          cardKeyMsg
        }}</div>
        <div style="display: flex; gap: 10px">
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #f3f4f6;
              color: #374151;
              cursor: pointer;
            "
            @click="showCardKeyDialog = false"
            >取消</button
          >
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #00bfa5;
              color: #fff;
              cursor: pointer;
            "
            :disabled="cardKeyLoading"
            @click="handleRedeemCardKey"
            >{{ cardKeyLoading ? '兑换中...' : '确认兑换' }}</button
          >
        </div>
      </div>
    </div>

    <!-- 底部5栏Tab -->
    <div
      style="
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 1px solid #f3f4f6;
        display: flex;
        align-items: center;
        justify-content: space-around;
        padding: 4px 0 calc(max(6px, env(safe-area-inset-bottom)));
        z-index: 10;
      "
    >
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/browse')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
        </svg>
        <span style="font-size: 10px">首页</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/category')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <rect x="3" y="3" width="7" height="7" rx="1" />
          <rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" />
          <rect x="14" y="14" width="7" height="7" rx="1" />
        </svg>
        <span style="font-size: 10px">应用</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/updates')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path
            d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"
          />
        </svg>
        <span style="font-size: 10px">社区</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/game')"
      >
        <svg style="width: 20px; height: 20px" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" stroke-width="1.8"/>
          <path d="M8.5 12.5l2 2 5-5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span style="font-size: 10px">发现</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #00bfa5;
        "
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path
            d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"
          />
        </svg>
        <span style="font-size: 10px">我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref } from 'vue'
  import { useRouter } from 'vue-router'
  import { useUserStore } from '@/store/modules/user'
  import { fetchRedeemCardKey } from '@/api/appstore'

  const router = useRouter()
  const userStore = useUserStore()

  const showCardKeyDialog = ref(false)
  const cardKeyForm = ref({ cardNo: '', password: '' })
  const cardKeyMsg = ref('')
  const cardKeyLoading = ref(false)

  const isLogin = computed(() => userStore.isLogin)
  const userInfo = computed(() => userStore.info || {})

  const isAdmin = computed(() => {
    const roles: string[] = userStore.info.roles || []
    return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
  })

  const levelName = computed(() => {
    if (!isLogin.value) return 'Lv.0'
    return userStore.info.levelName || '普通会员'
  })

  const expCurrent = ref(0)
  const expMax = ref(1000)

  const expPercent = computed(() => {
    if (!isLogin.value || !expMax.value) return 0
    return Math.min(((expCurrent.value || 0) / expMax.value) * 100, 100)
  })

  const expDisplay = computed(() => {
    if (!isLogin.value) return '0/1000'
    return `${expCurrent.value || 0}/${expMax.value}`
  })

  const fetchExpLevels = async () => {
    try {
      const { fetchExpLevelList } = await import('@/api/operation')
      const data: any = await fetchExpLevelList()
      const levels = data?.records || data || []
      if (levels.length > 0) {
        levels.sort((a: any, b: any) => a.level - b.level)
        const exp = userStore.info.experience || 0
        expCurrent.value = exp
        const next = levels.find((l: any) => (l.expRequired || l.exp_required || 0) > exp)
        if (next) {
          expMax.value = next.expRequired || next.exp_required || 1000
        } else {
          expMax.value = levels[levels.length - 1].expRequired || levels[levels.length - 1].exp_required || 1000
        }
      }
    } catch (_e: unknown) {
      void _e
    }
  }

  fetchExpLevels()

  const formatNum = (val: number): string => {
    if (val >= 10000) {
      const w = Math.floor(val / 100) / 100
      return w % 1 === 0 ? `${w}万` : `${w.toFixed(2)}万`
    }
    return Number.isInteger(val) ? `${val}` : val.toFixed(2)
  }

  const balanceStr = computed(() => {
    if (!isLogin.value) return '--'
    const b = Number(userStore.info.balance || 0)
    return b >= 10000 ? formatNum(b) : b.toFixed(2)
  })

  const pointsStr = computed(() => {
    if (!isLogin.value) return '--'
    const p = Number(userStore.info.points || 0)
    return formatNum(p)
  })

  const funcIcons = [
    {
      label: '应用投稿',
      bg: '#3B82F6',
      icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4'
    },
    {
      label: '应用更新',
      bg: '#F97316',
      icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12'
    },
    {
      label: '我的收藏',
      bg: '#EF4444',
      icon: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'
    },
    {
      label: '签到',
      bg: '#F59E0B',
      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2zm3-6h.01M9 12l2 2 4-4'
    },
    {
      label: '下载管理',
      bg: '#22C55E',
      icon: 'M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'
    },
    {
      label: '排行榜',
      bg: '#EC4899',
      icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'
    },
    {
      label: '邀请福利',
      bg: '#10B981',
      icon: 'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z'
    },
    {
      label: '应用认领',
      bg: '#a3e635',
      icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4m0-4v4'
    }
  ]

  const menuItems = [
    {
      label: '后台管理',
      icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '板块管理',
      icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10',
      highlight: true,
      adminOnly: true
    },
    {
      label: '审核管理',
      icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '浏览足迹',
      icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
    },
    {
      label: '卡密兑换',
      icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'
    },
    {
      label: '主题选择',
      icon: 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01'
    },
    {
      label: '交流群组',
      icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'
    },
    {
      label: '联系我们',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z'
    },
    {
      label: '退出登录',
      icon: 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1',
      loginOnly: true
    },
    {
      label: '我的评论',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
      loginOnly: true
    }
  ]

  const computedMenuItems = computed(() => {
    const items = [...menuItems]
    return items.filter((item) => {
      if (item.adminOnly && !isAdmin.value) return false
      if (item.loginOnly && !isLogin.value) return false
      return true
    })
  })

  const handleFuncIcon = (item: any) => {
    if (item.label === '应用投稿') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/submissions')
    }
  }

  const handleAvatarClick = () => {
    if (!isLogin.value) {
      router.push('/appstore/browse/login')
    } else {
      router.push('/appstore/profile')
    }
  }

  const handleMenuItem = (item: any) => {
    if (item.label === '后台管理') {
      router.push('/dashboard/console')
    } else if (item.label === '板块管理') {
      router.push('/appstore/section-manage')
    } else if (item.label === '审核管理') {
      router.push('/appstore/review-mobile')
    } else if (item.label === '退出登录') {
      userStore.logOut()
      router.replace('/appstore/mine')
    } else if (item.label === '卡密兑换') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      cardKeyForm.value = { cardNo: '', password: '' }
      cardKeyMsg.value = ''
      showCardKeyDialog.value = true
    } else if (item.label === '我的评论') {
      router.push('/appstore/profile/comments')
    }
  }

  const handleRedeemCardKey = async () => {
    if (!cardKeyForm.value.cardNo || !cardKeyForm.value.password) {
      cardKeyMsg.value = '请输入卡号和密码'
      return
    }
    cardKeyLoading.value = true
    cardKeyMsg.value = ''
    try {
      const data = await fetchRedeemCardKey({
        cardNo: cardKeyForm.value.cardNo,
        password: cardKeyForm.value.password,
        userId: userStore.info.userId || 0,
        userName: userStore.info.userName || ''
      })
      cardKeyMsg.value = data.msg || '兑换成功'
      if (data.code === 200) {
        showCardKeyDialog.value = false
      }
    } catch (e: any) {
      cardKeyMsg.value = e?.msg || '兑换失败'
    } finally {
      cardKeyLoading.value = false
    }
  }
</script>
