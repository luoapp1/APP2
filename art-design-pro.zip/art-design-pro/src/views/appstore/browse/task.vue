<template>
  <div class="min-h-screen bg-[#f5f5f5] flex flex-col">
    <div class="bg-white px-4 py-3 flex items-center gap-3 border-b border-gray-100">
      <svg class="w-5 h-5 text-gray-500 cursor-pointer" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-lg font-semibold">任务中心</span>
    </div>

    <div class="flex-1 overflow-y-auto">
      <div class="px-4 py-3" v-if="loading">
        <div class="text-center text-gray-400 py-10">加载中...</div>
      </div>

      <template v-else>
        <div v-for="task in tasks" :key="task.id"
          class="mx-3 mb-2 bg-white rounded-xl px-4 py-3 flex items-center gap-3"
          :class="{ 'opacity-60': task.completed }">
          <div class="w-[42px] h-[42px] rounded-xl flex items-center justify-center flex-shrink-0"
            :style="{ background: task.completed ? '#d1d5db' : '#22C1C3' }">
            <span class="text-white text-lg" v-if="task.icon">{{ task.icon }}</span>
            <svg v-else class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l4.59-4.58L18 11l-6 6z"/>
            </svg>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-sm font-medium text-gray-800">{{ task.name }}</div>
            <div class="text-xs text-gray-400 mt-1">{{ task.description || typeLabel(task.task_type) + actionLabel(task.action_type) }}</div>
            <div class="mt-2 flex items-center gap-2">
              <div class="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div class="h-full rounded-full transition-all" :style="{ width: progressPercent(task) + '%', background: task.completed ? '#67c23a' : '#22C1C3' }" />
              </div>
              <span class="text-xs text-gray-500 flex-shrink-0">{{ task.progress }}/{{ task.target_count }}</span>
            </div>
            <div class="flex gap-2 mt-2 flex-wrap">
              <span v-if="task.points_reward > 0" class="text-xs text-orange-500 flex items-center gap-1">
                <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><text x="12" y="16" text-anchor="middle" fill="white" font-size="10">P</text></svg>
                +{{ task.points_reward }}积分
              </span>
              <span v-if="task.exp_reward > 0" class="text-xs text-blue-500">+{{ task.exp_reward }}经验</span>
              <span v-if="task.balance_reward > 0" class="text-xs text-green-500">+{{ task.balance_reward }}余额</span>
            </div>
          </div>
          <ElButton v-if="!task.completed" size="small" type="primary" :loading="doingId === task.id"
            @click="doTask(task)" style="background:#22C1C3;border-color:#22C1C3;border-radius:20px;flex-shrink:0">
            领取
          </ElButton>
          <ElTag v-else size="small" type="success" class="flex-shrink-0">已完成</ElTag>
        </div>

        <div v-if="tasks.length === 0" class="text-center text-gray-400 py-16">
          <svg class="w-16 h-16 mx-auto mb-3 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 5h6"/>
          </svg>
          <p>暂无可用任务</p>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { fetchMyTasks, doTask as doTaskApi } from '@/api/task'

defineOptions({ name: 'TaskCenter' })

const tasks = ref<any[]>([])
const loading = ref(true)
const doingId = ref<number | null>(null)

const userId = computed(() => {
  const store = (window as any).__USER_STORE__ || {}
  return store.userId || 0
})

function typeLabel(val: string) {
  const map: Record<string, string> = { daily: '每日', weekly: '每周', monthly: '每月', once: '一次性' }
  return map[val] || val
}

function actionLabel(val: string) {
  const map: Record<string, string> = {
    post: '发帖', comment: '评论', like: '点赞', checkin: '签到', share: '分享', download: '下载应用'
  }
  return map[val] || val
}

function progressPercent(task: any) {
  if (!task.target_count) return 0
  return Math.min(100, Math.round((task.progress || 0) / task.target_count * 100))
}

async function loadTasks() {
  loading.value = true
  try {
    const res: any = await fetchMyTasks(userId.value)
    tasks.value = res || []
  } finally {
    loading.value = false
  }
}

async function doTask(task: any) {
  doingId.value = task.id
  try {
    const res: any = await doTaskApi({ userId: userId.value, taskId: task.id, actionCount: 1 })
    if (res.completed) {
      ElMessage.success(`任务完成! ${res.rewards?.map((r: any) => `+${r.amount || r.name}`).join(', ') || ''}`)
    } else {
      ElMessage.success(`进度 +1`)
    }
      loadTasks()
    } else {
      ElMessage.warning(res.msg)
    }
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    doingId.value = null
  }
}

onMounted(loadTasks)
</script>
