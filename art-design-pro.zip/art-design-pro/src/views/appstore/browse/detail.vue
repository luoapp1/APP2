<template>
  <div class="app-detail-page min-h-screen bg-white relative">
    <!-- 顶部导航 -->
    <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
      <div class="flex items-center gap-3">
        <a href="/#/appstore/browse" class="flex items-center">
          <svg class="w-6 h-6 text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
          </svg>
        </a>
        <span class="text-base font-semibold text-gray-900">{{ app?.name || '加载中...' }}-{{ displayApp?.version || '' }}</span>
      </div>
      <div class="flex items-center gap-4">
        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle cx="12" cy="6" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="18" r="2"/>
        </svg>
      </div>
    </div>

    <!-- 应用不存在提示 -->
    <div v-if="!loading && !app" class="flex flex-col items-center justify-center py-20 text-gray-400">
      <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.5"/><path stroke-linecap="round" stroke-width="1.5" d="M12 8v4m0 4h.01"/></svg>
      <p class="text-base">应用不存在或已下架</p>
      <a href="/#/appstore/browse" class="mt-4 px-6 py-2 bg-blue-500 text-white rounded-full text-sm">返回应用商店</a>
    </div>

    <div v-else class="overflow-y-auto" style="height: calc(100vh - 140px); padding-bottom: 60px;">
      <!-- 应用信息头部 -->
      <div class="relative px-5 pt-5 pb-4">
        <div class="flex items-start gap-4">
          <div class="flex-shrink-0">
            <div class="w-18 h-18 rounded-[22px] flex items-center justify-center shadow-lg ring-4 ring-white" :style="{ background: app?.iconBgColor || iconColor(app?.name || '') }">
              <span v-if="!app?.icon" class="text-white font-bold text-2xl leading-none">{{ (app?.name || '?')[0] }}</span>
              <img v-else :src="app.icon" class="w-full h-full object-cover rounded-[22px]" />
            </div>
          </div>
          <div class="flex-1 min-w-0 pt-0.5">
            <h1 class="text-lg font-bold text-gray-900 leading-tight">{{ app?.name || '' }}
              <span v-if="app && app.status !== '1'" class="ml-2 inline-block px-2.5 py-0.5 text-[11px] rounded-full bg-orange-100 text-orange-600 font-medium align-middle">已下架</span>
            </h1>
            <p class="text-xs text-gray-400 mt-1">{{ app?.packageName || '' }}</p>
            <div class="flex gap-1.5 mt-2 flex-wrap">
              <span v-for="tag in (displayApp?.tags || [])" :key="tag" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium" :class="tagClass(tag)">
                <svg v-if="tag === '星选'" class="w-2.5 h-2.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                {{ tag }}
              </span>
              <span v-for="ot in (displayApp?.officialTags || [])" :key="ot.id" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
            </div>
            <div class="flex gap-1.5 mt-2 flex-wrap" v-if="displayApp">
              <span v-if="getPriceType() === 'free'" class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-green-50 text-green-600 border border-green-200">免费</span>
              <span v-else class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-red-50 text-red-600 border border-red-200">
                {{ displayApp.priceType === 'balance' ? '¥' + displayApp.priceAmount : displayApp.priceAmount + '积分' }}
              </span>
              <span v-if="displayApp.isFree" class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-green-50 text-green-600 border border-green-200">免费应用</span>
              <span v-if="displayApp.hasAds" class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600 border border-orange-200">含广告</span>
              <span v-if="displayApp.hasPaidContent" class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-purple-50 text-purple-600 border border-purple-200">含付费内容</span>
              <span v-if="displayApp.requiresNetwork" class="inline-block px-2 py-0.5 rounded-full text-[10px] font-medium bg-blue-50 text-blue-600 border border-blue-200">需联网</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 数据统计行 -->
      <div class="grid grid-cols-4 gap-2 px-4 pb-4">
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="flex items-center justify-center gap-1">
            <svg class="w-3.5 h-3.5 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <span class="text-sm font-bold text-gray-800">{{ toNum(displayApp?.rating).toFixed(1) }}</span>
          </div>
          <div class="text-[11px] text-gray-400 mt-0.5">评分</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="text-sm font-bold text-gray-800">{{ displayApp?.sizeMb ?? 0 }}MB</div>
          <div class="text-[11px] text-gray-400 mt-0.5">大小</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center" :class="{ 'cursor-pointer': purchased }" @click="purchased && openPurchasers()">
          <div class="text-sm font-bold text-gray-800">{{ formatCount(totalDownloads) }}</div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ purchased ? '已购买' : '下载' }}</div>
        </div>
        <div class="bg-gray-50/80 rounded-2xl py-3 px-1 text-center">
          <div class="text-sm font-bold text-gray-800">{{ (app?.coinCount ?? 0).toFixed(0) }}<span class="text-xs text-gray-400 font-normal">积分</span></div>
          <div class="text-[11px] text-gray-400 mt-0.5">{{ coinPeopleCount }}人投币</div>
        </div>
      </div>

      <!-- Tab 切换 -->
      <div class="sticky top-0 z-10 bg-white border-b border-gray-100">
        <div class="flex px-4">
          <div v-for="tab in tabs" :key="tab" class="relative px-5 py-3 text-sm cursor-pointer transition-colors" :class="activeTab === tab ? 'text-[#00BFA5] font-semibold' : 'text-gray-500'" @click="activeTab = tab">
            {{ tab }}
            <div v-if="activeTab === tab" class="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-full" style="background: #00BFA5"/>
          </div>
        </div>
      </div>

      <!-- Tab: 详情 -->
      <div v-if="activeTab === '详情'" class="px-4 pt-5 pb-20 space-y-4">
        <!-- 截图 -->
        <div v-if="(displayApp?.screenshots || []).length > 0" class="overflow-x-auto scrollbar-hide -mx-1">
          <div class="flex gap-2.5 px-1 pb-1" style="scroll-snap-type: x mandatory;">
            <div
              v-for="(shot, idx) in (displayApp?.screenshots || [])"
              :key="idx"
              class="flex-shrink-0 w-[130px] h-[230px] rounded-[18px] relative overflow-hidden shadow-sm"
              :style="{ background: getShotBg(shot) }"
              style="scroll-snap-align: start;"
            >
              <img
                v-if="getShotImage(shot)"
                :src="getShotImage(shot)"
                class="w-full h-full object-cover absolute inset-0"
              />
              <div v-else class="text-white text-center px-3 absolute inset-0 flex flex-col items-center justify-center">
                <div class="text-sm font-bold mb-1">{{ getShotText(shot) }}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 上传者信息 -->
        <div v-if="app?.developer || app?.userName" class="bg-gradient-to-r from-teal-50/60 to-blue-50/60 rounded-[18px] p-4 border border-teal-100/50">
          <div class="flex items-start gap-3">
            <div class="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center text-white text-sm font-bold shadow-sm" :style="{ background: app?.iconBgColor || iconColor(app?.name || '') }">
              {{ (app?.developer || app?.userName || '?')[0] }}
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2">
                <span class="text-sm font-semibold text-gray-800">{{ app?.developer || app?.userName }}</span>
                <span class="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-700 font-medium">上传者</span>
              </div>
              <p class="text-xs text-gray-500 mt-1.5 leading-relaxed">该应用由用户上传分享，请自行甄别内容安全性</p>
            </div>
          </div>
        </div>

        <!-- 关于应用 + 更新内容 -->
        <div class="bg-white rounded-[18px] p-5 shadow-sm border border-gray-100 space-y-4">
          <div>
            <h3 class="text-[15px] font-bold text-gray-900 mb-2.5 flex items-center gap-2">
              <span class="w-1 h-4 rounded-full bg-teal-500"></span>
              关于应用
            </h3>
            <p class="text-[13px] text-gray-500 leading-relaxed">{{ displayApp?.description || '暂无介绍' }}</p>
          </div>
          <div class="border-t border-gray-100 pt-4">
            <h3 class="text-[15px] font-bold text-gray-900 mb-2.5 flex items-center gap-2">
              <span class="w-1 h-4 rounded-full bg-teal-500"></span>
              更新内容
            </h3>
            <p class="text-xs text-gray-400 mb-2">版本 {{ displayApp?.version || '' }}</p>
            <p class="text-[13px] text-gray-500 leading-relaxed">{{ displayApp?.updateContent || '暂无更新内容' }}</p>
          </div>
        </div>

        <!-- 免责声明 -->
        <p class="text-[11px] text-gray-300 text-center leading-relaxed px-4">该软件由用户上传，仅用于学习用途。请在下载后24小时内删除，如造成您的权益受损请点击申诉</p>
      </div>

      <!-- Tab: 讨论 -->
      <div v-if="activeTab === '讨论'" class="px-4 pt-4">
        <!-- 评分统计区 -->
        <div class="relative overflow-hidden bg-gradient-to-br from-white via-white to-teal-50/30 rounded-2xl p-5 mb-5 shadow-sm border border-gray-100">
          <div class="flex items-center gap-5 relative z-10">
            <!-- 总分 -->
            <div class="text-center flex-shrink-0">
              <div class="relative inline-flex items-center justify-center w-20 h-20">
                <svg class="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="#f3f4f6" stroke-width="6" />
                  <circle cx="50" cy="50" r="42" fill="none" stroke="url(#scoreGrad)" stroke-width="6" stroke-linecap="round"
                    :stroke-dasharray="2 * Math.PI * 42"
                    :stroke-dashoffset="2 * Math.PI * 42 * (1 - toNum(ratingStats?.average) / 5)" />
                </svg>
                <div class="relative text-2xl font-extrabold text-gray-800 leading-none">{{ toNum(ratingStats?.average).toFixed(1) }}</div>
              </div>
              <div class="text-xs text-gray-400 mt-1 font-medium">{{ ratingStats?.total || 0 }} 人评价</div>
            </div>
            <!-- 星级分布条 -->
            <div class="flex-1 space-y-2 min-w-0">
              <div v-for="star in 5" :key="star" class="flex items-center gap-2">
                <div class="flex items-center gap-0.5 w-10 flex-shrink-0">
                  <span class="text-[11px] font-medium text-gray-500">{{ 6-star }}</span>
                  <svg class="w-3 h-3 text-amber-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                </div>
                <div class="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden relative">
                  <div class="absolute inset-0 h-full rounded-full transition-all duration-500" :style="{ width: starPercent(6-star) + '%', background: starGradient(6-star) }" />
                </div>
                <span class="text-[11px] text-gray-400 w-7 text-right tabular-nums font-medium">{{ ratingStats?.distribution?.[6-star] || 0 }}</span>
              </div>
            </div>
          </div>
          <!-- SVG gradient definition -->
          <svg width="0" height="0" class="absolute">
            <defs>
              <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#00BFA5" />
                <stop offset="100%" stop-color="#34d399" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        <!-- 评论输入区 -->
        <div class="bg-white rounded-2xl p-4 mb-5 shadow-sm border border-gray-100">
          <textarea
            v-model="commentText"
            maxlength="200"
            placeholder="说说你的看法..."
            rows="3"
            class="w-full bg-gray-50 rounded-xl p-3.5 text-sm outline-none resize-none border-0 placeholder:text-gray-400 focus:ring-2 focus:ring-teal-100 focus:bg-white transition-all"
          />
          <div class="flex items-center justify-between mt-3">
            <div class="flex items-center gap-1.5">
              <svg v-for="s in 5" :key="s" class="w-5 h-5 cursor-pointer transition-all duration-150 hover:scale-110" :class="s <= commentRating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20" @click="commentRating = s"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            </div>
            <button
              class="px-5 py-2 rounded-full text-sm font-semibold text-white transition-all duration-200 active:scale-95 shadow-md shadow-teal-200/50 hover:shadow-lg hover:shadow-teal-200/60"
              style="background: linear-gradient(135deg, #00BFA5, #00d4b8)"
              @click="submitComment"
            >发表评论</button>
          </div>
        </div>

        <!-- 评论排序 + 总数 -->
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-base font-bold text-gray-900">全部评论</h3>
          <div class="flex items-center gap-2">
            <span class="text-xs text-gray-400">{{ sortedComments.length }} 条</span>
            <div class="flex items-center gap-0.5 bg-gray-100 rounded-lg p-0.5">
              <button
                v-for="s in sortOptions"
                :key="s.value"
                class="px-2.5 py-1 rounded-md text-[11px] font-medium transition-all"
                :class="sortBy === s.value ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400 hover:text-gray-600'"
                @click="sortBy = s.value"
              >{{ s.label }}</button>
            </div>
          </div>
        </div>

        <!-- 评论列表 -->
        <div v-if="sortedComments.length > 0" class="space-y-3 pb-20">
          <div v-for="comment in sortedComments" :key="comment.id" class="bg-white rounded-2xl p-4 shadow-sm border transition-all duration-200" :class="comment.isPinned ? 'border-amber-200 bg-amber-50/40 ring-1 ring-amber-100' : 'border-gray-100 hover:shadow-md hover:border-gray-200'">
            <div class="flex items-start gap-3">
              <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold ring-2 ring-offset-1" :style="{ background: comment.userAvatar || '#FF5777', ringColor: comment.isPinned ? '#fde68a' : '#f3f4f6' }">{{ (comment.userName || '?')[0] }}</div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 flex-wrap">
                  <span class="text-sm font-semibold text-gray-800">{{ comment.userName }}</span>
                  <span v-if="comment.isPinned" class="inline-flex items-center gap-0.5 text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-semibold">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/></svg>置顶
                  </span>
                  <span v-if="comment.purchased" class="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-green-100 text-green-700 font-semibold">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>{{ purchaseTypeLabel(comment.purchaseType) }}
                  </span>
                  <span v-if="isTipComment(comment.content)" class="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-700 font-semibold">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10-4.48-10-10-10zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>打赏
                  </span>
                  <div v-if="comment.rating > 0" class="flex items-center gap-0.5 ml-auto">
                    <svg v-for="s in 5" :key="s" class="w-3.5 h-3.5" :class="s <= comment.rating ? 'text-amber-400' : 'text-gray-200'" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                  </div>
                </div>
                <p class="text-sm text-gray-700 mt-1.5 leading-relaxed" :class="isTipComment(comment.content) ? 'text-teal-600 font-medium' : ''">{{ comment.content }}</p>
                <div class="flex items-center gap-4 mt-3 flex-wrap">
                  <span class="text-[11px] text-gray-400">{{ relativeTime(comment.createTime) }}</span>
                  <span class="inline-flex items-center gap-1 text-[12px] cursor-pointer select-none transition-all duration-200 hover:scale-105" :class="comment.isLiked ? 'text-red-400' : 'text-gray-400 hover:text-red-300'" @click.stop="handleLike(comment)">
                    <svg class="w-3.5 h-3.5 transition-transform duration-300" :class="comment.isLiked ? 'scale-110' : ''" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                    <span class="font-medium">{{ comment.likeCount || 0 }}</span>
                  </span>
                    <span class="text-[12px] text-gray-400 cursor-pointer hover:text-teal-500 transition-colors font-medium" @click.stop="openReply(comment)">回复</span>
                  <span class="text-[12px] text-gray-400 cursor-pointer hover:text-gray-600 transition-colors font-medium" @click.stop="handleReport(comment)">举报</span>
                  <span v-if="canPin" class="text-[12px] text-amber-600 cursor-pointer hover:text-amber-500 transition-colors font-medium" @click.stop="handlePin(comment)">{{ comment.isPinned ? '取消置顶' : '置顶' }}</span>
                  <span v-if="comment.userId === userStore.info.userId" class="text-[12px] text-red-400 cursor-pointer hover:text-red-500 transition-colors font-medium" @click.stop="confirmDelete(comment)">删除</span>
                </div>
              </div>
            </div>

            <!-- 回复列表 -->
            <div v-if="comment.replies && comment.replies.length > 0" class="mt-3 ml-12">
              <div v-for="reply in comment.replies" :key="reply.id" class="pl-3.5 py-2 border-l-2 border-teal-200">
                <div class="flex items-start gap-2">
                  <div class="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-white text-[10px] font-bold ring-1 ring-offset-1 ring-gray-200" :style="{ background: reply.userAvatar || '#FF5777' }">{{ (reply.userName || '?')[0] }}</div>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-1.5 flex-wrap">
                      <span class="text-xs font-semibold text-gray-700">{{ reply.userName }}</span>
                      <span v-if="reply.purchased" class="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full bg-green-100 text-green-700 font-semibold">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>{{ purchaseTypeLabel(reply.purchaseType) }}
                      </span>
                      <span v-if="isTipComment(reply.content)" class="text-[10px] px-1.5 py-0.5 rounded-full bg-teal-100 text-teal-700 font-semibold">打赏</span>
                    </div>
                    <p class="text-xs text-gray-600 mt-0.5 leading-relaxed" :class="isTipComment(reply.content) ? 'text-teal-600 font-medium' : ''">{{ reply.content }}</p>
                    <div class="flex items-center gap-3 mt-1.5">
                      <span class="text-[10px] text-gray-400">{{ relativeTime(reply.createTime) }}</span>
                      <span class="inline-flex items-center gap-0.5 text-[10px] cursor-pointer transition-colors hover:scale-105" :class="reply.isLiked ? 'text-red-400' : 'text-gray-400 hover:text-red-300'" @click.stop="handleLike(reply)">
                        <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"/></svg>
                        <span>{{ reply.likeCount || 0 }}</span>
                      </span>
                      <span v-if="reply.userId === userStore.info.userId" class="text-[10px] text-red-400 cursor-pointer hover:text-red-500 transition-colors" @click.stop="deleteReply(reply)">删除</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 回复输入框 -->
            <div v-if="replyTarget === comment.id" class="ml-12 mt-3">
              <div class="flex items-center gap-2">
                <input v-model="replyText" maxlength="200" :placeholder="`回复 ${comment.userName}...`" class="flex-1 bg-gray-50 rounded-full px-4 py-2 text-xs outline-none border-0 focus:ring-2 focus:ring-teal-100 transition-all" @keyup.enter="doReply" />
                <button class="text-xs text-[#00BFA5] font-semibold" @click="doReply">发送</button>
                <button class="text-xs text-gray-400" @click="replyTarget = 0">取消</button>
              </div>
              <div class="text-[10px] text-gray-400 pl-4 mt-1">{{ replyText.length }}/200</div>
            </div>
          </div>
        </div>
        <div v-else class="text-center py-20 text-gray-400">
          <svg class="w-20 h-20 mx-auto mb-4 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
          <p class="text-sm">还没有评论，快来发表第一条吧</p>
        </div>

        <!-- 举报弹窗 -->
        <div v-if="showReportInput" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 200;" @click.self="showReportInput = false">
          <div style="background: #fff; border-radius: 20px; width: 300px; padding: 24px 20px;">
            <div style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: #1f2937;">举报评论</div>
            <input v-model="reportReason" placeholder="请填写举报原因" style="width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 16px; transition: border-color .2s;" />
            <div style="display: flex; gap: 10px;">
              <button style="flex:1; padding: 10px; border-radius: 10px; border: none; background: #f3f4f6; color: #374151; font-size: 14px; font-weight: 600; cursor: pointer;" @click="showReportInput = false">取消</button>
              <button style="flex:1; padding: 10px; border-radius: 10px; border: none; background: #EF4444; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="doReport">提交举报</button>
            </div>
          </div>
        </div>

        <!-- 删除确认弹窗 -->
        <div v-if="showDeleteConfirm" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 200;" @click.self="showDeleteConfirm = false">
          <div style="background: #fff; border-radius: 20px; width: 280px; padding: 28px 24px 20px; text-align: center;">
            <div style="font-size: 16px; font-weight: 700; margin-bottom: 10px; color: #1f2937;">确认删除</div>
            <div style="font-size: 13px; color: #6b7280; margin-bottom: 24px;">确定要删除这条评论吗？</div>
            <div style="display: flex; gap: 10px;">
              <button style="flex:1; padding: 11px; border-radius: 10px; border: none; background: #f3f4f6; color: #374151; font-size: 14px; font-weight: 600; cursor: pointer;" @click="showDeleteConfirm = false">取消</button>
              <button style="flex:1; padding: 11px; border-radius: 10px; border: none; background: #EF4444; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer;" @click="doDelete">确认删除</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab: 版本 -->
      <div v-if="activeTab === '版本'" class="px-4 pt-4 pb-20">
        <div class="space-y-3">
          <div v-for="ver in versions" :key="ver.id" class="group bg-gray-50/80 rounded-xl p-3.5 cursor-pointer transition-all duration-150 hover:bg-gray-100/90 active:scale-[0.985]" @click="gotoVersion(ver)">
            <div class="flex items-start gap-3">
              <!-- 版本图标 -->
              <div class="flex-shrink-0 w-11 h-11 rounded-2xl flex items-center justify-center shadow-sm" :style="{ background: ver.tags?.includes('星选') ? '#7C4DFF' : (app?.iconBgColor || iconColor(app?.name || '')) }">
                <span class="text-white font-bold text-sm leading-none">{{ (app?.name || '?')[0] }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <!-- 标题行 -->
                <div class="flex items-center gap-2 flex-wrap">
                  <span class="text-sm font-semibold text-gray-800">{{ app?.name }}</span>
                  <span v-if="ver.isCurrent" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold text-white bg-[#00BFA5] shadow-sm shadow-teal-200">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>
                    当前版本
                  </span>
                  <span v-else class="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium text-gray-500 bg-gray-200/80">{{ ver.version }}</span>
                </div>
                <!-- 标签行 -->
                <div class="flex flex-wrap items-center gap-1.5 mt-2" v-if="(ver.tags || []).length > 0 || (ver.officialTags || []).length > 0">
                  <span v-for="tag in (ver.tags || [])" :key="tag" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium" :class="tagClass(tag)">
                    <svg v-if="tag === '星选'" class="w-2.5 h-2.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    {{ tag }}
                  </span>
                  <span v-for="ot in (ver.officialTags || [])" :key="ot.id" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
                </div>
                <!-- 元数据行 -->
                <div class="flex items-center gap-0 mt-2 flex-wrap">
                  <span class="inline-flex items-center gap-1 text-[11px] text-gray-400">
                    <svg class="w-3 h-3 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    {{ toNum(ver.rating).toFixed(1) }}
                  </span>
                  <span class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span class="text-[11px] text-gray-400">{{ ver.sizeMb }} MB</span>
                  <span class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span class="text-[11px] text-gray-400">{{ formatCount(ver.downloads) }} 下载</span>
                  <span v-if="ver.userName" class="text-gray-200 mx-2 text-[10px]">|</span>
                  <span v-if="ver.userName" class="text-[11px] text-gray-400">{{ ver.userName }}</span>
                </div>
              </div>
              <svg class="mt-0.5 flex-shrink-0 transition-transform group-hover:translate-x-0.5" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
            </div>
          </div>
        </div>
        <!-- 无版本 -->
        <div v-if="versions.length === 0" class="text-center py-16 text-gray-400 text-sm">暂无历史版本</div>
      </div>
    </div>

    <!-- Toast -->
    <div v-if="toastText" class="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 px-5 py-2.5 rounded-full text-sm text-white" style="background: rgba(0,0,0,0.75);">{{ toastText }}</div>

    <!-- 底部操作栏 -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-between px-5 py-2 z-10" style="height: 60px;">
      <div class="flex flex-col items-center gap-0.5" :class="{ 'cursor-pointer': !isOwner }" @click="!isOwner && openTip()">
        <span class="text-sm font-semibold text-gray-800">{{ (app?.coinCount ?? 0).toFixed(0) }}</span>
        <span class="text-[10px] text-gray-400">{{ coinPeopleCount }}人投币</span>
      </div>
      <button
        v-if="app && app.status !== '1'"
        class="rounded-full px-14 font-semibold text-base text-gray-500 cursor-not-allowed"
        style="background: #e5e7eb; height: 42px;"
        disabled
      >已下架，无法下载</button>
      <button
        v-else-if="getPriceType() !== 'free' && !purchased"
        class="rounded-full px-14 font-semibold text-base text-white" style="background: #00BFA5; height: 42px;"
        @click="handleBuy"
      >{{ purchaseBtnLabel }}</button>
      <button v-else class="rounded-full px-14 font-semibold text-base text-white" style="background: #00BFA5; height: 42px;" @click="doDownload(null)">下载 {{ displayApp?.sizeMb ?? '0' }} MB</button>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer" @click="showTipList = true">
        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v13"/></svg>
        <span class="text-[10px] text-gray-500">打赏列表</span>
      </div>
    </div>

    <!-- 打赏列表弹窗 -->
    <div v-if="showTipList" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100;" @click.self="showTipList = false">
      <div style="background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 60vh; overflow-y: auto; padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <span style="font-size: 16px; font-weight: 600;">打赏记录</span>
          <span style="font-size: 13px; color: #00BFA5;">余额 {{ formatAmount(tipStats?.totalBalance) }}元 + 积分 {{ formatAmount(tipStats?.totalPoints) }}</span>
        </div>
        <div v-if="tipList.length === 0" style="text-align: center; padding: 40px 0; color: #9ca3af;">暂无打赏</div>
        <div v-for="t in tipList" :key="t.id" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #f3f4f6;">
          <div>
            <div style="font-size: 14px; font-weight: 500;">{{ t.userName }}</div>
            <div style="font-size: 12px; color: #9ca3af;">{{ t.message || '支持一下' }}</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 14px; font-weight: 600;" :style="{ color: t.tipType === 'balance' ? '#00BFA5' : '#f97316' }">{{ formatAmount(t.amount) }}{{ t.tipType === 'balance' ? '元' : '积分' }}</div>
            <div style="font-size: 10px; color: #9ca3af;">{{ t.createTime?.slice(0,10) }}</div>
          </div>
        </div>
        <button style="width: 100%; padding: 12px; margin-top: 12px; border-radius: 8px; border: none; background: #f3f4f6; font-size: 14px; cursor: pointer;" @click="showTipList = false">关闭</button>
      </div>
    </div>

    <!-- 投币弹窗 -->
    <div v-if="showTipDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showTipDialog = false">
      <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px;">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 8px;">打赏 {{ app?.name }}</div>
        <div style="display: flex; gap: 8px; margin-bottom: 12px;">
          <div style="flex: 1; padding: 8px; border-radius: 8px; text-align: center; font-size: 12px; cursor: pointer; border: 1px solid #e5e7eb;"
            :style="tipType === 'balance' ? { background: '#e6f9f6', borderColor: '#00BFA5', color: '#00BFA5', fontWeight: 600 } : { color: '#374151' }"
            @click="tipType = 'balance'">
            余额 ({{ balanceStr }})
          </div>
          <div style="flex: 1; padding: 8px; border-radius: 8px; text-align: center; font-size: 12px; cursor: pointer; border: 1px solid #e5e7eb;"
            :style="tipType === 'points' ? { background: '#e6f9f6', borderColor: '#00BFA5', color: '#00BFA5', fontWeight: 600 } : { color: '#374151' }"
            @click="tipType = 'points'">
             积分 ({{ userStore.info.points || 0 }})
           </div>
        </div>
        <div style="display: flex; gap: 8px; margin-bottom: 8px; flex-wrap: wrap;">
          <div v-for="amt in (tipType === 'balance' ? [1,2,5,8,10] : [1,3,5,10,20])" :key="amt" style="padding: 6px 12px; border-radius: 8px; font-size: 13px; cursor: pointer; border: 1px solid #e5e7eb;"
            :style="tipAmount === amt ? { background: '#00BFA5', color: '#fff', borderColor: '#00BFA5' } : { color: '#374151' }"
            @click="tipAmount = amt">{{ amt }}{{ tipType === 'balance' ? '元' : '积分' }}</div>
        </div>
        <div style="margin-bottom: 12px;">
          <input v-model.number="customAmount" type="number" placeholder="自定义金额" style="width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box;" @input="onCustomAmount" />
        </div>
        <div style="margin-bottom: 12px;">
          <input v-model="tipMessage" placeholder="留言(选填, 将显示在评论中)" style="width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box;" />
        </div>
        <div v-if="tipMsg" style="font-size: 12px; color: #00BFA5; margin-bottom: 8px; text-align: center;">{{ tipMsg }}</div>
        <div style="display: flex; gap: 10px;">
          <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer;" @click="showTipDialog = false">取消</button>
          <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="doTip">确认打赏</button>
        </div>
      </div>
    </div>
    <!-- 购买确认弹窗 -->
    <div v-if="showBuyDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showBuyDialog = false">
      <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px;">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 8px;">购买应用</div>
        <div style="font-size: 14px; color: #374151; margin-bottom: 6px;">{{ app?.name }}</div>
        <div style="font-size: 13px; color: #6b7280; margin-bottom: 12px;">
          原价 <span style="font-weight: 600; color: #1f2937;">{{ displayApp?.priceAmount }}{{ displayApp?.priceType === 'balance' ? '元' : '积分' }}</span>
          <template v-if="hasMembershipDiscount">
            &nbsp; 折扣后 <span style="font-weight: 600; color: #ef4444;">{{ calculatedPrice }}{{ displayApp?.priceType === 'balance' ? '元' : '积分' }}</span>
            <span style="font-size: 11px; color: #9ca3af;">&nbsp;({{ membershipDiscountLabel }})</span>
          </template>
        </div>
        <div style="font-size: 13px; color: #6b7280; margin-bottom: 16px;">购买后永久有效，可随时下载</div>
        <div v-if="buyMsg" style="font-size: 12px; color: #ef4444; margin-bottom: 8px; text-align: center;">{{ buyMsg }}</div>
        <div style="display: flex; gap: 10px;">
          <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer;" @click="showBuyDialog = false">取消</button>
          <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="doBuy">确认购买</button>
        </div>
      </div>
    </div>
    <!-- 下载弹窗 -->
    <div v-if="showDownloadDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showDownloadDialog = false">
      <div style="background: #fff; border-radius: 16px; width: 340px; padding: 24px 20px 16px;">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 16px;">下载 {{ app?.name }}</div>
        <template v-if="downloadUrl">
          <div style="font-size: 13px; color: #6b7280; margin-bottom: 8px;">下载链接：</div>
          <div style="background: #f3f4f6; border-radius: 8px; padding: 10px; font-size: 12px; color: #374151; word-break: break-all; margin-bottom: 16px; max-height: 80px; overflow-y: auto;">{{ downloadUrl }}</div>
          <div style="display: flex; gap: 10px;">
            <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: 1px solid #e5e7eb; background: #fff; color: #374151; cursor: pointer;" @click="copyDownloadUrl">复制链接</button>
            <button style="flex: 1; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #00BFA5; color: #fff; cursor: pointer;" @click="openDownloadUrl">打开下载</button>
          </div>
        </template>
        <template v-else>
          <div style="text-align: center; padding: 20px 0; color: #9ca3af; font-size: 14px;">暂无下载链接</div>
          <button style="width: 100%; padding: 10px; border-radius: 8px; font-size: 14px; border: none; background: #f3f4f6; color: #374151; cursor: pointer; margin-top: 8px;" @click="showDownloadDialog = false">关闭</button>
        </template>
      </div>
    </div>
    <!-- 购买者列表弹窗 -->
    <div v-if="showPurchasersDialog" style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100;" @click.self="showPurchasersDialog = false">
      <div style="background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 60vh; overflow-y: auto; padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <span style="font-size: 16px; font-weight: 600;">已购买用户 ({{ purchasersList.length }})</span>
        </div>
        <div v-if="purchasersList.length === 0" style="text-align: center; padding: 40px 0; color: #9ca3af;">暂无购买记录</div>
        <div v-for="p in purchasersList" :key="p.id" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f3f4f6;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 36px; height: 36px; border-radius: 50%; background: #e5e7eb; display: flex; align-items: center; justify-content: center; font-size: 14px; color: #6b7280; overflow: hidden;">
              <img v-if="p.avatar" :src="p.avatar" style="width: 100%; height: 100%; object-fit: cover;" />
              <span v-else>{{ (p.userName || '?')[0] }}</span>
            </div>
            <div>
              <div style="font-size: 14px; font-weight: 500;">{{ p.userName }}</div>
              <div style="font-size: 12px; color: #9ca3af;">{{ p.levelName || '普通会员' }} · {{ p.createTime }}</div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 13px; font-weight: 600;" :style="{ color: p.priceType === 'points' ? '#8B5CF6' : '#F59E0B' }">
              {{ p.paidPrice }}{{ p.priceType === 'balance' ? '元' : '积分' }}
            </div>
            <div style="font-size: 11px; color: #9ca3af;">{{ p.priceType === 'balance' ? '余额支付' : '积分支付' }}</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchAppDetail, fetchRecommendApps, fetchPostComment, fetchPostTip, fetchAppTips, fetchCommentLike, fetchDeleteComment, fetchReportComment, fetchReplyComment, fetchPinComment, fetchPurchaseApp, fetchPurchaseStatus, fetchPurchasers } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const app = ref<any>(null)
const loading = ref(true)
const comments = ref<any[]>([])
const versions = ref<any[]>([])
const ratingStats = ref<any>({ average: 0, total: 0, distribution: {} })
const recommendApps = ref<any[]>([])
const activeTab = ref('详情')
const selectedVersion = ref<any>(null)
const showBuyDialog = ref(false)
const purchased = ref(false)
const buyMsg = ref('')
const showDownloadDialog = ref(false)
const downloadUrl = ref('')
const showPurchasersDialog = ref(false)
const purchasersList = ref<any[]>([])
const sortBy = ref('newest')

const sortOptions = [
  { label: '最新', value: 'newest' },
  { label: '最热', value: 'hottest' },
]

const sortedComments = computed(() => {
  let list = [...comments.value]
  // Sort
  if (sortBy.value === 'hottest') {
    list.sort((a: any, b: any) => {
      const score = (c: any) => (c.likeCount || 0) + (c.replies?.length || 0) * 0.5
      return score(b) - score(a)
    })
  }
  // Pinned first
  list.sort((a: any, b: any) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0))
  return list
})

function relativeTime(dateStr: string): string {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const min = Math.floor(diff / 60000)
  if (min < 1) return '刚刚'
  if (min < 60) return `${min}分钟前`
  const hours = Math.floor(min / 60)
  if (hours < 24) return `${hours}小时前`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}天前`
  const months = Math.floor(days / 30)
  if (months < 12) return `${months}个月前`
  return dateStr.slice(0, 10)
}

const displayApp = computed(() => {
  if (!app.value) return null
  const sv = selectedVersion.value
  if (!sv) return app.value
  return {
    ...app.value,
    version: sv.version,
    versionCode: sv.versionCode,
    sizeMb: sv.sizeMb,
    downloads: sv.downloads,
    rating: sv.rating,
    downloadUrl: sv.downloadUrl,
    tags: (sv.tags && sv.tags.length > 0) ? sv.tags : app.value.tags,
    officialTags: (sv.officialTags && sv.officialTags.length > 0) ? sv.officialTags : app.value.officialTags,
    hasAds: sv.hasAds !== undefined ? !!sv.hasAds : !!app.value.hasAds,
    requiresNetwork: sv.requiresNetwork !== undefined ? !!sv.requiresNetwork : !!app.value.requiresNetwork,
    hasPaidContent: sv.hasPaidContent !== undefined ? !!sv.hasPaidContent : !!app.value.hasPaidContent,
    isFree: sv.isFree !== undefined ? !!sv.isFree : !!app.value.isFree,
    updateContent: sv.updateContent || '',
    description: sv.description || app.value.description,
    screenshots: (sv.screenshots && sv.screenshots.length > 0) ? sv.screenshots : app.value.screenshots,
  }
})

function gotoVersion(ver: any) {
  router.push({ query: { version: ver.version } })
}

watch(() => route.query.version, (v) => {
  if (v && versions.value.length) {
    const found = versions.value.find((item: any) => item.version === v)
    selectedVersion.value = found || null
    if (found) activeTab.value = '详情'
  } else {
    selectedVersion.value = null
  }
})

function getShotBg(shot: any) {
  if (typeof shot === 'string') return '#333'
  return shot.bgColor || '#222'
}
function getShotImage(shot: any) {
  if (typeof shot === 'string') return shot
  return shot.image || ''
}
function getShotText(shot: any) {
  if (typeof shot === 'string') return ''
  return shot.text || ''
}

const commentText = ref('')
const commentRating = ref(5)

const showTipDialog = ref(false)
const tipType = ref('balance')
const tipAmount = ref(5)
const tipMsg = ref('')
const tipMessage = ref('')
const customAmount = ref<number | ''>('')

const showTipList = ref(false)
const tipList = ref<any[]>([])
const tipStats = ref<any>(null)

const coinPeopleCount = computed(() => tipList.value.length)

const coinDisplay = computed(() => {
  const s = tipStats.value
  if (!s || (s.totalBalance === 0 && s.totalPoints === 0)) return String(app.value?.coinCount ?? 0)
  const parts: string[] = []
  if (s.totalBalance > 0) parts.push(`${s.totalBalance}元`)
  if (s.totalPoints > 0) parts.push(`${s.totalPoints}积分`)
  return parts.join('+')
})

const formatAmount = (value: any) => {
  if (value == null) return '0'
  const n = Number(value)
  return Number.isInteger(n) ? String(n) : n.toFixed(2)
}

const tabs = ['详情', '讨论', '版本']

const balanceStr = computed(() => {
  const b = Number(userStore.info.balance || 0)
  return b.toFixed(2)
})

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return false
  }
  return true
}

const submitComment = async () => {
  if (!checkLogin()) return
  if (!commentText.value.trim()) return
  if (commentText.value.length > 200) { showToast('评论最多200字', '#FF5777'); return }
  try {
    await fetchPostComment(Number(route.params.id), {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      rating: commentRating.value,
      content: commentText.value
    })
    commentText.value = ''
    commentRating.value = 5
    loadDetail()
  } catch {}
}

const handleLike = async (comment: any) => {
  if (!checkLogin()) return
  try {
    const res: any = await fetchCommentLike(
      Number(route.params.id), comment.id, userStore.info.userId || 0
    )
    comment.isLiked = res.liked
    comment.likeCount += res.liked ? 1 : -1
    if (comment.likeCount < 0) comment.likeCount = 0
    showToast(res.liked ? '已点赞' : '已取消')
  } catch (e) { console.error('like err:', e); showToast('操作失败') }
}

const showDeleteConfirm = ref(false)
const deleteTarget = ref<any>(null)

const confirmDelete = (comment: any) => {
  deleteTarget.value = comment
  showDeleteConfirm.value = true
}

const doDelete = async () => {
  if (!deleteTarget.value) return
  try {
    await fetchDeleteComment(Number(route.params.id), deleteTarget.value.id, userStore.info.userId || 0)
    showToast('已删除')
    showDeleteConfirm.value = false
    loadDetail()
  } catch { showToast('删除失败') }
}

const showReportInput = ref(false)
const reportTarget = ref<any>(null)
const reportReason = ref('')

const replyTarget = ref(0)
const replyText = ref('')

const isTipComment = (content: string) => content?.startsWith('[打赏')

const purchaseTypeLabel = (pt: string) => {
  if (pt === 'balance') return '余额已购'
  if (pt === 'points') return '积分已购'
  return '已购买'
}

const openReply = (comment: any) => {
  if (!userStore.info.userId) { showToast('请先登录', '#FF5777'); return }
  replyTarget.value = replyTarget.value === comment.id ? 0 : comment.id
  replyText.value = ''
}

const doReply = async () => {
  if (!replyText.value.trim()) return
  if (replyText.value.length > 200) { showToast('回复最多200字', '#FF5777'); return }
  try {
    await fetchReplyComment(Number(route.params.id), replyTarget.value, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || '匿名',
      content: replyText.value.trim()
    })
    replyTarget.value = 0
    replyText.value = ''
    showToast('回复成功', '#00BFA5')
    loadDetail()
  } catch { showToast('回复失败', '#FF5777') }
}

const deleteReply = async (reply: any) => {
  try {
    await fetchDeleteComment(Number(route.params.id), reply.id, userStore.info.userId || 0)
    showToast('已删除', '#00BFA5')
    loadDetail()
  } catch { showToast('删除失败', '#FF5777') }
}

const isOwner = computed(() => {
  const uid = userStore.info.userId
  if (!uid) return false
  return app.value.userId === uid || app.value.developer === userStore.info.userName
})

const canPin = computed(() => {
  if (isOwner.value) return true
  const roles = userStore.info.roles || []
  if (roles.includes('R_SUPER') || roles.includes('R_ADMIN')) return true
  return false
})

const handlePin = async (comment: any) => {
  try {
    const res: any = await fetchPinComment(Number(route.params.id), comment.id, userStore.info.userId)
    showToast(res.msg || (comment.isPinned ? '已取消置顶' : '已置顶'), '#00BFA5')
    loadDetail()
  } catch { showToast('操作失败', '#FF5777') }
}

const handleReport = (comment: any) => {
  reportTarget.value = comment
  reportReason.value = ''
  showReportInput.value = true
}

const doReport = async () => {
  if (!reportReason.value.trim()) return
  try {
    await fetchReportComment(Number(route.params.id), reportTarget.value.id, userStore.info.userId || 0, reportReason.value)
    showReportInput.value = false
    showToast('举报已提交')
  } catch { showToast('举报失败') }
}

const toastText = ref('')
const showToast = (text: string) => {
  toastText.value = text
  setTimeout(() => { toastText.value = '' }, 2000)
}

const openTip = () => {
  if (!checkLogin()) return
  showTipDialog.value = true
  tipType.value = 'balance'
  tipAmount.value = 1
  tipMsg.value = ''
  tipMessage.value = ''
  customAmount.value = ''
}

const onCustomAmount = () => {
  if (customAmount.value && Number(customAmount.value) > 0) {
    tipAmount.value = Number(customAmount.value)
  }
}

watch(tipType, (val) => {
  tipAmount.value = val === 'balance' ? 1 : 1
})

const doTip = async () => {
  try {
    const data = await fetchPostTip(Number(route.params.id), {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      amount: tipAmount.value,
      tipType: tipType.value,
      message: tipMessage.value
    })
    if (data.newBalance !== undefined) userStore.info.balance = data.newBalance
    if (data.newPoints !== undefined) userStore.info.points = data.newPoints
    tipMsg.value = data.msg || '打赏成功'
    setTimeout(() => { showTipDialog.value = false; loadDetail() }, 800)
  } catch (e: any) {
    tipMsg.value = e?.msg || '打赏失败'
  }
}

const getPriceType = () => {
  if (!app.value) return 'free'
  return (app.value as any).priceType || 'free'
}

const calculatedPrice = computed(() => {
  if (!app.value || !hasMembershipDiscount.value) return (app.value as any).priceAmount || 0
  const rate = Number((userStore.info as any).discountRate || (userStore.info as any).pointsDiscountRate || 1)
  const amt = Number((app.value as any).priceAmount || 0)
  return Math.round(amt * rate * 100) / 100
})

const hasMembershipDiscount = computed(() => {
  if (!app.value || !userStore.info) return false
  const pt = (app.value as any).priceType || 'free'
  const ml = Number(userStore.info.levelId || 0)
  if (ml <= 0) return false
  if (pt === 'balance') return Number(userStore.info.discountRate || 1) < 1
  if (pt === 'points') return Number(userStore.info.pointsDiscountRate || 1) < 1
  return false
})

const membershipDiscountLabel = computed(() => {
  const pt = (app.value as any).priceType || 'free'
  if (pt === 'balance') return `会员${Math.round((userStore.info.discountRate || 1) * 100)}折`
  if (pt === 'points') return `积分${Math.round((userStore.info.pointsDiscountRate || 1) * 100)}折`
  return ''
})

const purchaseBtnLabel = computed(() => {
  if (!app.value) return '购买'
  const pt = (app.value as any).priceType || 'free'
  const amt = (app.value as any).priceAmount || 0
  const final = calculatedPrice.value
  const unit = pt === 'balance' ? '元' : '积分'
  if (final !== amt) return `¥${final}${unit} 购买`
  return `¥${amt}${unit} 购买`
})

const handleBuy = () => {
  if (!userStore.info?.userId) {
    buyMsg.value = '请先登录'
    return
  }
  showBuyDialog.value = true
}

const doBuy = async () => {
  if (!app.value) return
  buyMsg.value = ''
  try {
    const pt = (app.value as any).priceType || 'free'
    const res: any = await fetchPurchaseApp(Number(app.value.id), userStore.info.userId, pt)
    purchased.value = true
    if (res?.alreadyPurchased) {
      showToast('您已购买过，可直接下载')
    } else {
      showToast('购买成功')
    }
    if (res?.newBalance !== undefined) userStore.info.balance = res.newBalance
    if (res?.newPoints !== undefined) userStore.info.points = res.newPoints
    showBuyDialog.value = false
    loadDetail()
    doDownload(null)
  } catch (e: any) {
    buyMsg.value = e?.msg || '购买失败'
  }
}

const toNum = (v: any) => Number(v) || 0

const acolorPool = ['#4F8AF7', '#6C5CE7', '#00BFA5', '#F97316', '#EC4899', '#EF4444', '#8B5CF6', '#10B981', '#3B82F6', '#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return acolorPool[hash % acolorPool.length]
}

const tagStyles: Record<string, string> = {
  '星选': 'bg-purple-50 text-purple-600 border border-purple-200',
  '官方版': 'bg-blue-50 text-blue-600 border border-blue-200',
  '测试版': 'bg-amber-50 text-amber-600 border border-amber-200',
  '国际版': 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  '灰度版': 'bg-slate-100 text-slate-600 border border-slate-200',
  '汉化版': 'bg-rose-50 text-rose-600 border border-rose-200',
  '破解版': 'bg-red-50 text-red-600 border border-red-200',
  '修改版': 'bg-orange-50 text-orange-600 border border-orange-200',
}
const fallbackTagClass = 'bg-teal-50 text-teal-600 border border-teal-200'
const tagClass = (tag: string) => tagStyles[tag] || fallbackTagClass

const totalDownloads = computed(() => {
  if (selectedVersion.value) return selectedVersion.value.downloads || 0
  const vd = versions.value.reduce((sum: number, v: any) => sum + (v.downloads || 0), 0)
  return vd > 0 ? vd : (app.value?.downloads || 0)
})

const bestComment = computed(() => comments.value.find((c: any) => c.rating >= 4) || comments.value[0] || null)

const starPercent = (star: number) => {
  const dist = ratingStats.value?.distribution || {}
  const max = Math.max(...Object.values(dist) as number[], 1)
  return Math.round(((dist[star] || 0) / max) * 100)
}

const starGradients = ['#fbbf24', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6']
const starGradient = (star: number) => {
  const idx = star - 1
  return `linear-gradient(90deg, ${starGradients[idx]}, ${starGradients[idx]}cc)`
}

const formatCount = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
  return String(n)
}

const doDownload = (ver: any) => {
  let url = ''
  if (ver) {
    url = ver.downloadUrl || ''
  } else {
    url = displayApp.value?.downloadUrl || ''
  }
  downloadUrl.value = url
  showDownloadDialog.value = true
}

const copyDownloadUrl = () => {
  if (downloadUrl.value) {
    navigator.clipboard?.writeText(downloadUrl.value).then(() => {
      showToast('链接已复制')
    }).catch(() => {
      showToast('复制失败，请手动复制')
    })
  }
}

const openDownloadUrl = () => {
  if (downloadUrl.value) {
    window.open(downloadUrl.value, '_blank')
    showDownloadDialog.value = false
  }
}

const openPurchasers = async () => {
  showPurchasersDialog.value = true
  purchasersList.value = []
  try {
    const res: any = await fetchPurchasers(Number(route.params.id))
    purchasersList.value = res?.list || []
  } catch {}
}

onMounted(async () => {
  await loadDetail()
  if (route.query.version) {
    const found = versions.value.find((item: any) => item.version === route.query.version)
    if (found) { selectedVersion.value = found; activeTab.value = '详情' }
  }
  try {
    const recs: any = await fetchRecommendApps()
    recommendApps.value = recs || []
  } catch {}
})

async function loadDetail() {
  const id = route.params.id as string
  if (!id) { loading.value = false; return }
  try {
    const res: any = await fetchAppDetail(Number(id), userStore.info.userId)
    app.value = res.app
    comments.value = res.comments || []
    versions.value = res.versions || []
    ratingStats.value = res.ratingStats || { average: 0, total: 0, distribution: {} }
  } catch (e) { console.error(e) }
  loading.value = false
  loadTips()
  checkPurchaseStatus()
}

async function checkPurchaseStatus() {
  const id = route.params.id as string
  if (!id || !userStore.info?.userId) return
  try {
    const res: any = await fetchPurchaseStatus(Number(id), userStore.info.userId)
    purchased.value = res?.purchased === true
  } catch {}
}

async function loadTips() {
  try {
    const data = await fetchAppTips(Number(route.params.id))
    tipList.value = data.list || []
    tipStats.value = data.stats || null
  } catch {}
}
</script>
