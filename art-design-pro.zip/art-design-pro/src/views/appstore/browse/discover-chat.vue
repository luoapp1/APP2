<template>
  <div class="min-h-screen bg-[#f5f5f5] flex flex-col">
    <!-- 顶部返回栏 -->
    <div class="bg-white px-3 py-3 flex items-center gap-3 border-b border-gray-100">
      <svg class="w-5 h-5 text-gray-700 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <img
        v-if="resolveAvatar(chatAvatar)"
        :src="resolveAvatar(chatAvatar)"
        class="w-[32px] h-[32px] rounded-full object-cover flex-shrink-0"
      />
      <div
        v-else
        class="w-[32px] h-[32px] rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
        :style="{ background: iconColor(chatName) }"
      >{{ (chatName || '?')[0] }}</div>
      <span class="text-sm font-semibold text-gray-800">{{ chatName }}</span>
    </div>

    <!-- 消息列表 -->
    <div ref="msgListRef" class="flex-1 overflow-y-auto px-4 py-3 space-y-3">
      <div v-for="msg in messages" :key="msg.id" class="flex" :class="msg.fromUserId === myUserId ? 'justify-end' : 'justify-start'">
        <div class="max-w-[75%]">
          <div
            class="px-3 py-2 rounded-2xl text-sm leading-relaxed"
            :class="msg.fromUserId === myUserId
              ? 'bg-[#95EC69] text-gray-800 rounded-br-sm'
              : 'bg-white text-gray-800 rounded-bl-sm'"
          >{{ msg.content }}</div>
          <div class="text-[10px] text-gray-400 mt-0.5" :class="msg.fromUserId === myUserId ? 'text-right' : 'text-left'">
            {{ fmtTime(msg.createTime) }}
          </div>
        </div>
      </div>
    </div>

    <!-- 输入框 -->
    <div class="bg-white border-t border-gray-100 px-3 py-2 flex items-center gap-2">
      <input
        v-model="inputMsg"
        class="flex-1 bg-[#f5f5f5] rounded-full px-4 py-2.5 text-sm outline-none border-none text-gray-700 placeholder-gray-400"
        placeholder="输入消息..."
        @keyup.enter="sendMsg"
      />
      <button
        class="w-[36px] h-[36px] rounded-full flex items-center justify-center flex-shrink-0 transition-colors"
        :class="inputMsg.trim() ? 'bg-[#00BFA5] text-white' : 'bg-gray-200 text-gray-400'"
        @click="sendMsg"
      >
        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
          <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
        </svg>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchMessages, fetchSendMessage } from '@/api/message'
import type { MessageItem } from '@/api/message'

const route = useRoute()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0

const targetUserId = Number(route.params.targetUserId)
const chatName = ref('')
const chatAvatar = ref('')

const messages = ref<MessageItem[]>([])
const inputMsg = ref('')
const msgListRef = ref<HTMLElement | null>(null)

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) {
    avatarMap[`avatar:${match[1]}`] = (mod as any).default
  }
}

const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar.startsWith('http') || avatar.startsWith('/uploads')) return avatar
  return ''
}

const colorPool = ['#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#AB47BC', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconColor = (name: string) => {
  if (!name) return '#448AFF'
  const hash = name.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  return new Date(t.replace(' ', 'T') + 'Z')
}

const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0')
}

const scrollToBottom = () => {
  nextTick(() => {
    if (msgListRef.value) {
      msgListRef.value.scrollTop = msgListRef.value.scrollHeight
    }
  })
}

const sendMsg = async () => {
  const txt = inputMsg.value.trim()
  if (!txt || !targetUserId) return
  try {
    const avatar = userStore.info?.avatar || ''
    const res: any = await fetchSendMessage(
      myUserId,
      userStore.info?.userName || userStore.info?.username || '用户',
      avatar,
      targetUserId,
      txt
    )
    messages.value.push(res || { id: Date.now(), fromUserId: myUserId, content: txt, createTime: new Date().toISOString(), isRead: 0 })
    inputMsg.value = ''
    scrollToBottom()
  } catch {}
}

onMounted(async () => {
  if (!targetUserId) return
  try {
    const res: any = await fetchMessages(myUserId, targetUserId)
    const list = Array.isArray(res) ? res : (res.list || [])
    messages.value = list
    if (list.length > 0) {
      const last = list[list.length - 1]
      if (last.fromUserId === myUserId) {
        const partnerMsg = list.find((m: MessageItem) => m.fromUserId !== myUserId)
        if (partnerMsg) {
          chatName.value = partnerMsg.fromUserName
          chatAvatar.value = partnerMsg.fromUserAvatar || ''
        }
      } else {
        chatName.value = last.fromUserName
        chatAvatar.value = last.fromUserAvatar || ''
      }
    }
    scrollToBottom()
  } catch {}
})
</script>
