<template>
  <div class="min-h-screen bg-[#f5f5f5] flex flex-col">
    <!-- 顶部标题栏 -->
    <div class="bg-white px-4 py-3 flex items-center justify-between">
      <div class="text-base font-bold text-gray-800">私信</div>
      <div class="relative cursor-pointer" @click="$router.push('/appstore/discover/system')">
        <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        <div v-if="unreadNotifs > 0" class="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FF5777] text-white text-[9px] flex items-center justify-center">
          {{ unreadNotifs > 99 ? '99+' : unreadNotifs }}
        </div>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto pb-16">

      <!-- 4个圆形功能按钮 -->
      <div class="bg-white px-4 py-4">
        <div class="flex justify-around">
          <div
            v-for="item in funcBtns"
            :key="item.label"
            class="flex flex-col items-center gap-1.5 cursor-pointer active:opacity-70"
            @click="handleFuncBtn(item.key)"
          >
            <div class="w-[50px] h-[50px] rounded-full flex items-center justify-center" :style="{ background: item.bg }">
              <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="item.icon"/></svg>
            </div>
            <span class="text-[11px] text-gray-600 font-medium">{{ item.label }}</span>
          </div>
        </div>
      </div>

      <div class="h-2 bg-gray-50" />

      <!-- 消息列表 -->
      <div class="bg-white">
        <div v-if="loadingConvs" class="flex justify-center py-16">
          <div class="animate-spin w-5 h-5 border-2 border-[#00BFA5] border-t-transparent rounded-full" />
        </div>

        <div v-else-if="conversations.length === 0 && !loadingConvs" class="flex flex-col items-center justify-center py-20">
          <svg class="w-16 h-16 text-gray-200 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
          </svg>
          <span class="text-sm text-gray-400">暂无消息</span>
        </div>

        <div v-else>
          <div
            v-for="conv in conversations"
            :key="conv.userId"
            class="flex items-center gap-3 px-4 py-3 cursor-pointer active:bg-gray-50 border-b border-gray-50"
            @touchstart="onTouchStart(conv)"
            @touchend="onTouchEnd(conv)"
            @touchmove="onTouchCancel"
            @click="onItemClick(conv)"
          >
            <div
              v-if="conv.userId === 0"
              class="w-[48px] h-[48px] rounded-full flex items-center justify-center flex-shrink-0"
              style="background: linear-gradient(135deg, #FFB74D, #FF9800)"
            >
              <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
              </svg>
            </div>
            <div
              v-else-if="conv.userId === -1"
              class="w-[48px] h-[48px] rounded-full flex items-center justify-center flex-shrink-0"
              style="background: linear-gradient(135deg, #448AFF, #2979FF)"
            >
              <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
              </svg>
            </div>
            <img
              v-else-if="resolveAvatar(conv.userAvatar)"
              :src="resolveAvatar(conv.userAvatar)"
              class="w-[48px] h-[48px] rounded-full object-cover flex-shrink-0"
            />
            <div
              v-else
              class="w-[48px] h-[48px] rounded-full flex items-center justify-center flex-shrink-0 text-white text-base font-bold"
              :style="{ background: iconColor(conv.userName) }"
            >{{ (conv.userName || '?')[0] }}</div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between">
                <span class="text-sm font-semibold text-gray-800">{{ conv.userName }}</span>
                <span class="text-[10px] text-gray-400 flex-shrink-0 ml-2">{{ fmtTime(conv.lastTime) }}</span>
              </div>
              <div class="text-xs text-gray-400 mt-0.5 truncate" :class="{ 'text-gray-700 font-medium': conv.unread > 0 }">
                {{ conv.lastContent }}
              </div>
            </div>
            <div v-if="conv.unread > 0" class="w-5 h-5 rounded-full bg-[#FF5777] text-white text-[10px] flex items-center justify-center flex-shrink-0">
              {{ conv.unread > 99 ? '99+' : conv.unread }}
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- 底部导航栏 -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-around py-1 z-10" style="padding-bottom:max(6px,env(safe-area-inset-bottom))">
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/browse')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span class="text-[10px]">首页</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/category')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        <span class="text-[10px]">应用</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/updates')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <span class="text-[10px]">社区</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer" style="color:#00BFA5">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <span class="text-[10px]">发现</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/mine')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
        <span class="text-[10px]">我的</span>
      </div>
    </div>

    <!-- 删除确认弹窗 -->
    <div v-if="showDeleteDialog" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="showDeleteDialog = false">
      <div class="bg-white rounded-xl w-72 overflow-hidden" @click.stop>
        <div class="px-6 py-5 text-center">
          <div class="text-base font-semibold text-gray-800 mb-2">删除该对话</div>
          <div class="text-sm text-gray-500">将不再显示此对话，对方再发消息时会重新出现</div>
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="showDeleteDialog = false">取消</div>
          <div class="flex-1 py-3 text-center text-base text-[#FF5777] font-medium cursor-pointer active:bg-gray-50" @click="confirmHide">删除</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchConversations, fetchNotifications, fetchHideConversation } from '@/api/message'

const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0
const unreadNotifs = ref(0)
const unreadComments = ref(0)

const conversations = ref<any[]>([])
const loadingConvs = ref(false)

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) {
    avatarMap[`avatar:${match[1]}`] = (mod as any).default
  }
}

const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar.startsWith('http') || avatar.startsWith('/uploads')) return avatar
  return ''
}

const colorPool = ['#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#AB47BC', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconColor = (name: string) => {
  if (!name) return '#448AFF'
  const hash = name.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

let longPressTimer: any = null
let longPressTarget: any = null
let isLongPressed = false
const showDeleteDialog = ref(false)
const pendingDeleteConv = ref<any>(null)

const onTouchStart = (conv: any) => {
  if (conv.userId === 0 || conv.userId === -1) return
  isLongPressed = false
  longPressTarget = conv
  longPressTimer = setTimeout(() => {
    isLongPressed = true
    pendingDeleteConv.value = conv
    showDeleteDialog.value = true
  }, 600)
}

const onTouchEnd = (conv: any) => {
  if (longPressTimer) {
    clearTimeout(longPressTimer)
    longPressTimer = null
  }
  if (!isLongPressed) {
    openConversation(conv)
  }
}

const onTouchCancel = () => {
  if (longPressTimer) {
    clearTimeout(longPressTimer)
    longPressTimer = null
  }
  longPressTarget = null
}

const onItemClick = (conv: any) => {
}

const confirmHide = async () => {
  showDeleteDialog.value = false
  const conv = pendingDeleteConv.value
  if (!conv) return
  try {
    await fetchHideConversation(conv.userId, myUserId)
    conversations.value = conversations.value.filter(c => c.userId !== conv.userId)
  } catch {}
  pendingDeleteConv.value = null
}

const funcBtns = [
  { key: 'fav', label: '收藏', bg: 'linear-gradient(135deg, #FFB74D, #FF9800)', icon: 'M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z' },
  { key: 'notif', label: '通知', bg: 'linear-gradient(135deg, #FF5777, #EF4444)', icon: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
  { key: 'sponsor', label: '赞助', bg: 'linear-gradient(135deg, #66BB6A, #43A047)', icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z' },
  { key: 'rank', label: '排行', bg: 'linear-gradient(135deg, #448AFF, #2979FF)', icon: 'M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12' }
]

const handleFuncBtn = (key: string) => {
  if (key === 'notif') {
    router.push('/appstore/discover/system')
  } else if (key === 'sponsor') {
    router.push('/appstore/reports')
  } else if (key === 'rank') {
    router.push('/appstore/category')
  }
}

const openConversation = (conv: any) => {
  if (conv.userId === 0) {
    router.push('/appstore/discover/system')
  } else if (conv.userId === -1) {
    router.push('/appstore/discover/comments')
  } else {
    router.push(`/appstore/discover/chat/${conv.userId}`)
  }
}

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  return new Date(t.replace(' ', 'T') + 'Z')
}

const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  if (diff < 604800000) return Math.floor(diff / 86400000) + '天前'
  if (diff < 2592000000) return Math.floor(diff / 2592000000) + '个月前'
  return (d.getMonth() + 1) + '/' + d.getDate()
}

const loadUnreadNotifs = async () => {
  try {
    const res: any = await fetchNotifications(myUserId, 1, 'system')
    unreadNotifs.value = res.unread || 0
  } catch {}
}

const loadUnreadComments = async () => {
  try {
    const res: any = await fetchNotifications(myUserId, 1, 'comment')
    unreadComments.value = res.unread || 0
  } catch {}
}

const loadConversations = async () => {
  loadingConvs.value = true
  try {
    const res: any = await fetchConversations(myUserId)
    const convs = Array.isArray(res) ? res : (res.list || [])
    const result = [
      {
        userId: 0,
        userName: '系统通知',
        userAvatar: '',
        lastTime: new Date().toISOString(),
        lastContent: '系统消息',
        unread: unreadNotifs.value
      },
      {
        userId: -1,
        userName: '评论消息',
        userAvatar: '',
        lastTime: new Date().toISOString(),
        lastContent: '评论消息',
        unread: unreadComments.value
      }
    ]
    for (const c of convs) {
      result.push(c)
    }
    conversations.value = result
    result[0].unread = unreadNotifs.value
  } catch {}
  loadingConvs.value = false
}

onMounted(async () => {
  await loadUnreadNotifs()
  await loadUnreadComments()
  loadConversations()
})
</script>
