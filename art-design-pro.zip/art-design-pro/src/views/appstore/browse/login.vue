<template>
  <div class="flex w-full h-screen">
    <LoginLeftView />

    <div class="relative flex-1">
      <AuthTopBar />

      <div class="auth-right-wrap">
        <div class="form">
          <h3 class="title">{{ $t('login.title') }}</h3>
          <p class="sub-title">{{ $t('login.subTitle') }}</p>
          <ElForm
            ref="formRef"
            :model="formData"
            :rules="rules"
            :key="formKey"
            @keyup.enter="handleSubmit"
            style="margin-top: 25px"
          >
            <ElFormItem prop="username">
              <ElInput
                class="custom-height"
                :placeholder="$t('login.placeholder.username')"
                v-model.trim="formData.username"
              />
            </ElFormItem>
            <ElFormItem prop="password">
              <ElInput
                class="custom-height"
                :placeholder="$t('login.placeholder.password')"
                v-model.trim="formData.password"
                type="password"
                autocomplete="off"
                show-password
              />
            </ElFormItem>

            <div class="flex-cb mt-2 text-sm">
              <ElCheckbox v-model="formData.rememberPassword">{{ $t('login.rememberPwd') }}</ElCheckbox>
              <span class="text-theme cursor-pointer">{{ $t('login.forgetPwd') }}</span>
            </div>

            <div style="margin-top: 30px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="handleSubmit"
                :loading="loading"
                v-ripple
              >
                {{ $t('login.btnText') }}
              </ElButton>
            </div>

            <div class="mt-5 text-sm text-gray-600">
              <span>{{ $t('login.noAccount') }}</span>
              <span class="text-theme cursor-pointer">{{ $t('login.register') }}</span>
            </div>
          </ElForm>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useI18n } from 'vue-i18n'
import { fetchLogin, fetchGetUserInfo } from '@/api/auth'
import { HttpError } from '@/utils/http/error'
import { type FormInstance, type FormRules } from 'element-plus'

defineOptions({ name: 'AppStoreLogin' })

const { t, locale } = useI18n()
const formKey = ref(0)

watch(locale, () => {
  formKey.value++
})

const userStore = useUserStore()
const router = useRouter()

const formRef = ref<FormInstance>()
const loading = ref(false)

const formData = reactive({
  username: '',
  password: '',
  rememberPassword: true
})

const rules = computed<FormRules>(() => ({
  username: [{ required: true, message: t('login.placeholder.username'), trigger: 'blur' }],
  password: [{ required: true, message: t('login.placeholder.password'), trigger: 'blur' }]
}))

const handleSubmit = async () => {
  if (!formRef.value) return
  try {
    const valid = await formRef.value.validate()
    if (!valid) return
    loading.value = true

    const { username, password } = formData
    const res: any = await fetchLogin({ userName: username, password })

    if (!res.token) {
      throw new Error('Login failed - no token received')
    }

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    router.replace('/appstore/mine')
  } catch (error) {
    if (error instanceof HttpError) {
      console.error('[Login] HTTP Error:', error.code)
    } else {
      console.error('[Login] Error:', error)
    }
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
@reference '@styles/core/tailwind.css';

.auth-right-wrap {
  @apply absolute inset-0 w-[440px] h-[650px] py-[5px] m-auto overflow-hidden
    max-sm:px-7 max-sm:w-full
    animate-[slideInRight_0.6s_cubic-bezier(0.25,0.46,0.45,0.94)_forwards]
    max-md:animate-none;

  .form {
    @apply h-full py-[40px];
  }

  .title {
    @apply text-g-900 text-4xl font-semibold max-md:text-3xl max-sm:pt-10;
  }

  .sub-title {
    @apply mt-[10px] text-g-600 text-sm;
  }

  .custom-height {
    @apply !h-[40px];
  }
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
