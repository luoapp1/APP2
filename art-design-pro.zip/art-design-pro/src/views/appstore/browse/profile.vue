<template>
  <div style="position: relative; min-height: 100vh; background: #0a1226; overflow-x: hidden;">
    <!-- 背景图区 -->
    <div style="position: fixed; top: 0; left: 0; width: 100%; height: 65%; z-index: 0;"></div>
    <div v-if="profile.bgUrl" style="position: fixed; top: 0; left: 0; width: 100%; height: 65%; z-index: 1; background-position: center; background-size: cover;" :style="{ backgroundImage: 'url('+profile.bgUrl+')' }"></div>
    <div v-if="profile.bgUrl" style="position: fixed; top: 0; left: 0; width: 100%; height: 65%; z-index: 1; background: linear-gradient(180deg, rgba(10,18,38,0.55) 0%, rgba(10,18,38,0.4) 30%, rgba(15,26,53,0.35) 60%, rgba(30,50,101,0.5) 100%);"></div>
    <div v-if="!profile.bgUrl" style="position: fixed; top: 0; left: 0; width: 100%; height: 65%; background: linear-gradient(180deg, #0a1226 0%, #0f1a35 30%, #152246 55%, #1e3265 80%, #284a80 100%); z-index: 1;"></div>
    <canvas ref="starCanvas" style="position: fixed; top: 0; left: 0; width: 100%; height: 65%; z-index: 2; pointer-events: none;"></canvas>
    <div style="position: fixed; top: 8%; left: 10%; width: 80%; height: 30%; background: radial-gradient(ellipse at 40% 50%, rgba(29, 200, 175, 0.25) 0%, rgba(24, 185, 170, 0.08) 40%, transparent 70%); z-index: 3; pointer-events: none;"></div>
    <div style="position: fixed; top: 15%; left: 20%; width: 60%; height: 20%; background: radial-gradient(ellipse at 50% 50%, rgba(60, 180, 255, 0.12) 0%, transparent 55%); z-index: 3; pointer-events: none;"></div>
    <svg viewBox="0 0 400 160" style="position: fixed; bottom: 0; width: 100%; height: 40%; z-index: 3; pointer-events: none;" preserveAspectRatio="none">
      <defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#dce6f0" stop-opacity="0.75"/><stop offset="100%" stop-color="#fff" stop-opacity="0.92"/></linearGradient></defs>
      <path d="M0 130 Q 100 110 200 125 Q 300 140 400 120 L 400 160 L 0 160 Z" fill="url(#sg)"/>
      <path d="M0 140 Q 80 125 150 136 Q 260 148 350 130 Q 390 135 400 132 L 400 160 L 0 160 Z" fill="#fff" opacity="0.85"/>
      <g transform="translate(55,102)"><rect x="-3" y="6" width="6" height="26" fill="#3a2818"/><polygon points="0,-24 -24,10 24,10" fill="#132516"/><polygon points="0,-15 -18,6 18,6" fill="#183228" opacity="0.9"/></g>
      <g transform="translate(320,108)"><rect x="-3" y="5" width="6" height="24" fill="#3a2818"/><polygon points="0,-22 -22,9 22,9" fill="#132516"/><polygon points="0,-13 -16,5 16,5" fill="#183228" opacity="0.9"/></g>
      <g transform="translate(195,124)"><rect x="-24" y="-10" width="48" height="26" fill="#5a3820" rx="2"/><polygon points="-28,-10 0,-30 28,-10" fill="#7a5a3a"/><rect x="-6" y="-22" width="12" height="16" fill="#2a1810" rx="1"/><rect x="-8" y="0" width="16" height="10" fill="#ff9944" opacity="0.55"/><rect x="-4" y="-5" width="8" height="5" fill="#ffcc55" opacity="0.35"/></g>
    </svg>

    <!-- 顶部导航 -->
    <div style="position: relative; z-index: 100; padding: 48px 16px 0; display: flex; align-items: center; justify-content: space-between;">
      <div @click="$router.back()" style="cursor: pointer; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: rgba(255,255,255,0.1); backdrop-filter: blur(4px);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg></div>
      <div style="display: flex; align-items: center; gap: 20px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" style="cursor: pointer; opacity: 0.9;"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <div style="cursor: pointer; display: flex; flex-direction: column; gap: 3px; opacity: 0.9;"><div style="width: 4.5px; height: 4.5px; background: white; border-radius: 50%;"/><div style="width: 4.5px; height: 4.5px; background: white; border-radius: 50%;"/><div style="width: 4.5px; height: 4.5px; background: white; border-radius: 50%;"/></div>
      </div>
    </div>

    <!-- 个人信息区 -->
    <div style="position: relative; z-index: 10; padding: 20px 22px 20px;">
      <div style="display: flex; align-items: center; gap: 14px;">
        <div style="width: 70px; height: 70px; border-radius: 50%; flex-shrink: 0; overflow: hidden; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 16px rgba(255,100,80,0.35); position: relative;">
          <img v-if="profile.avatar" :src="profile.avatar" style="width: 100%; height: 100%; object-fit: cover;" />
          <div v-else style="width: 100%; height: 100%; background: linear-gradient(135deg, #FF6B6B 0%, #E8443A 50%, #FF8E53 100%); display: flex; align-items: center; justify-content: center;">
            <svg viewBox="0 0 100 100" style="width: 80%; height: 80%;"><ellipse cx="50" cy="65" rx="22" ry="18" fill="#9B8565"/><circle cx="50" cy="40" r="20" fill="#9B8565"/><circle cx="32" cy="24" r="10" fill="#9B8565"/><circle cx="32" cy="24" r="6" fill="#F0D4A0"/><circle cx="68" cy="24" r="10" fill="#9B8565"/><circle cx="68" cy="24" r="6" fill="#F0D4A0"/><ellipse cx="43" cy="37" rx="5" ry="6" fill="white"/><ellipse cx="57" cy="37" rx="5" ry="6" fill="white"/><circle cx="44.5" cy="37.5" r="2.5" fill="#222"/><circle cx="58.5" cy="37.5" r="2.5" fill="#222"/><ellipse cx="50" cy="43" rx="2.5" ry="1.8" fill="#FF6B6B"/><path d="M35 54 Q30 64 28 80 L72 80 Q70 64 65 54 Q55 61 50 57 Q45 61 35 54Z" fill="#EE3B3B" opacity="0.85"/><path d="M28 78 L26 84 L74 84 L72 78Z" fill="#CC2020"/></svg>
          </div>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 7px; margin-bottom: 4px;">
            <span style="color: #fff; font-size: 18px; font-weight: 700; letter-spacing: 0.3px;">{{ profile.nickname || profile.username || '用户' }}</span>
            <span style="background: linear-gradient(135deg, #24D6C4, #1BBFAE); color: #fff; font-size: 9px; padding: 2.5px 7px; border-radius: 9px; font-weight: 600; box-shadow: 0 1px 4px rgba(36,214,196,0.3);">{{ profile.levelName || 'Lv.0' }}</span>
          </div>
          <div style="color: rgba(255,255,255,0.5); font-size: 11.5px;">注册日期：{{ formatDate(profile.createTime) }}</div>
        </div>
      </div>

      <div style="display: flex; justify-content: center; gap: 36px; margin-top: 20px;">
        <div style="text-align: center;"><div style="color: #fff; font-size: 18px; font-weight: 700;">{{ formatNum(profile.balance || 0) }}</div><div style="color: rgba(255,255,255,0.5); font-size: 10px; margin-top: 2px;">余额</div></div>
        <div style="text-align: center;"><div style="color: #fff; font-size: 18px; font-weight: 700;">{{ formatNum(profile.followCount || 0) }}</div><div style="color: rgba(255,255,255,0.5); font-size: 10px; margin-top: 2px;">关注</div></div>
        <div style="text-align: center;"><div style="color: #fff; font-size: 18px; font-weight: 700;">{{ formatNum(profile.fansCount || 0) }}</div><div style="color: rgba(255,255,255,0.5); font-size: 10px; margin-top: 2px;">粉丝</div></div>
      </div>

      <div style="display: flex; align-items: flex-start; gap: 5px; margin-top: 16px; padding: 0 14px;">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="2" style="margin-top: 2.5px; flex-shrink: 0;"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        <span style="color: rgba(255,255,255,0.65); font-size: 12.5px; line-height: 1.5;">{{ profile.signature || '这个人很懒，什么都没写...' }}</span>
      </div>

      <div style="display: flex; gap: 10px; margin-top: 16px;">
        <button @click="goEdit" style="flex: 1; background: rgba(140,155,175,0.22); color: #fff; border: 1px solid rgba(255,255,255,0.18); border-radius: 20px; padding: 9px 0; font-size: 13.5px; cursor: pointer; backdrop-filter: blur(8px);">编辑</button>
        <button @click="handleLogout" style="flex: 1; background: rgba(140,155,175,0.12); color: #fff; border: 1px solid rgba(255,255,255,0.12); border-radius: 20px; padding: 9px 0; font-size: 13.5px; cursor: pointer; backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; gap: 5px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>退出</button>
      </div>
    </div>

    <!-- 白色内容面板 -->
    <div style="position: relative; z-index: 20; background: #f7f7f7; border-radius: 20px 20px 0 0; min-height: 600px; margin-top: -4px; box-shadow: 0 -6px 24px rgba(0,0,0,0.06);">
      <div style="display: flex; padding: 14px 6px 0; border-bottom: 1px solid #edf0f3; background: #f7f7f7; border-radius: 20px 20px 0 0;">
        <div v-for="tab in tabs" :key="tab" style="flex: 1; text-align: center; padding-bottom: 10px; position: relative; cursor: pointer;" @click="activeTab = tab">
          <span :style="{ color: activeTab === tab ? '#24D6C4' : '#999', fontSize: '13px', fontWeight: activeTab === tab ? 600 : 400 }">{{ tab }}</span>
          <div v-if="activeTab === tab" style="position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 20px; height: 3px; background: #24D6C4; border-radius: 2px;"></div>
        </div>
      </div>

      <!-- 应用列表 -->
      <div v-if="activeTab === '应用'" style="min-height: 320px;">
        <div v-if="userApps.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 20px;">
          <div style="width: 90px; height: 73px; border-radius: 12px; background: #eef0f4; display: flex; align-items: center; justify-content: center;"><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="3"/><path d="M2 7h20"/><path d="M7 2v5"/></svg></div>
          <div style="color: #c0c4cc; font-size: 14px; margin-top: 12px;">暂无应用</div>
        </div>
        <div v-else style="padding: 10px 14px;">
          <div v-for="app in userApps" :key="'a'+app.id" style="display: flex; align-items: center; gap: 12px; padding: 14px; background: #fff; border-radius: 16px; margin-bottom: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); cursor: pointer;" @click="goAppDetail(app.id)">
            <div style="width: 48px; height: 48px; border-radius: 12px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.08);" :style="{ background: app.iconBgColor || '#00BFA5' }">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div style="flex: 1; min-width: 0;">
              <div style="font-size: 14px; font-weight: 500; color: #222;">{{ app.name }}</div>
              <div style="font-size: 12px; color: #aaa; margin-top: 3px;">{{ app.category || '工具' }} &middot; {{ formatNum(app.downloads || 0) }} 下载</div>
            </div>
            <div style="display: flex; align-items: center; gap: 3px; color: #FFB800; font-size: 13px; font-weight: 500;"><svg width="13" height="13" viewBox="0 0 24 24" fill="#FFB800"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>{{ Number(app.rating || 0).toFixed(1) }}</div>
          </div>
        </div>
      </div>

      <!-- 评论列表 - 卡片式 -->
      <div v-if="activeTab === '评论'" style="min-height: 320px;">
        <div v-if="allComments.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 20px;">
          <div style="width: 75px; height: 58px; border-radius: 12px; background: #eef0f4; display: flex; align-items: center; justify-content: center;"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h16a2 2 0 012 2z"/></svg></div>
          <div style="color: #c0c4cc; font-size: 14px; margin-top: 12px;">暂无评论</div>
        </div>
        <div v-else style="padding: 10px 14px;">
          <div v-for="c in allComments" :key="'c'+c.id" style="background: #fff; border-radius: 18px; padding: 16px; margin-bottom: 10px; box-shadow: 0 1px 4px rgba(0,0,0,0.04);">

            <!-- 评论者信息 -->
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px; position: relative;">
              <div style="width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, #FF6B6B, #E8443A); flex-shrink: 0; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                <svg viewBox="0 0 100 100" style="width: 70%; height: 70%;"><ellipse cx="50" cy="65" rx="22" ry="18" fill="#9B8565"/><circle cx="50" cy="40" r="20" fill="#9B8565"/><circle cx="32" cy="24" r="10" fill="#9B8565"/><circle cx="32" cy="24" r="6" fill="#F0D4A0"/><circle cx="68" cy="24" r="10" fill="#9B8565"/><circle cx="68" cy="24" r="6" fill="#F0D4A0"/><ellipse cx="43" cy="37" rx="5" ry="6" fill="white"/><ellipse cx="57" cy="37" rx="5" ry="6" fill="white"/><circle cx="44.5" cy="37.5" r="2.5" fill="#222"/><circle cx="58.5" cy="37.5" r="2.5" fill="#222"/></svg>
              </div>
              <div style="flex: 1;">
                <div style="font-size: 14px; font-weight: 500; color: #222;">{{ profile.nickname || profile.username }}</div>
                <div style="font-size: 11px; color: #b2b2b2; margin-top: 1px;">{{ c.createTime?.slice(0,10) || '' }}</div>
              </div>
              <button v-if="isOwner" @click="handleDeleteComment(c)" style="position: absolute; top: -4px; right: -4px; background: none; border: none; cursor: pointer; padding: 6px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              </button>
            </div>

            <!-- 评分行 -->
            <div v-if="Number(c.rating) > 0" style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
              <span style="background: #F7B731; color: #fff; font-size: 12px; padding: 3px 10px; border-radius: 6px; font-weight: 500;">评分</span>
              <div style="display: flex; gap: 4px;">
                <div v-for="s in 5" :key="s" style="width: 22px; height: 22px; border-radius: 4px; background: #F7B731; display: flex; align-items: center; justify-content: center;">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                </div>
              </div>
              <span style="font-size: 12px; color: #D68B00; font-weight: 500;">{{ Number(c.rating).toFixed(0) >= 5 ? '非常好' : Number(c.rating).toFixed(0) >= 3 ? '一般' : '差评' }}</span>
            </div>

            <!-- 评论内容 -->
            <div v-if="c.content && !c.content.startsWith('[打赏')" style="font-size: 14px; color: #333; line-height: 1.6; margin-bottom: 12px;">{{ c.content }}</div>

            <!-- 应用信息卡 -->
            <div style="background: #f5f6f8; border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 12px; cursor: pointer;" @click="goAppDetail(c.appId)">
              <div style="width: 44px; height: 44px; border-radius: 10px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; background: #00BFA5;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 14px; font-weight: 500; color: #222;">{{ c.appName }}</div>
                <div style="font-size: 11px; color: #999; margin-top: 2px;">{{ c.likes || 0 }}人点评</div>
              </div>
              <div style="text-align: center;" v-if="Number(c.rating) > 0">
                <div style="font-size: 22px; font-weight: 700; color: #222;">{{ Number(c.rating).toFixed(1) }}</div>
                <div style="display: flex; gap: 2px; margin-top: 2px;">
                  <svg v-for="s in 5" :key="s" width="10" height="10" viewBox="0 0 24 24" fill="#F7B731"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-if="!['应用','评论'].includes(activeTab)" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 80px 20px;">
        <div style="color: #c0c4cc; font-size: 14px;">暂无内容</div>
      </div>
    </div>

    <!-- 隐藏的上传input -->
    <input ref="avatarInput" type="file" accept="image/*" style="display: none;" @change="onAvatarChange" />
    <input ref="bgInput" type="file" accept="image/*" style="display: none;" @change="onBgChange" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { ElMessageBox, ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const profile = ref<any>({})
const userApps = ref<any[]>([])
const userComments = ref<any[]>([])
const activeTab = ref('应用')
const tabs = ref(['应用', '评论', '帖子', '粉丝', '关注'])
const starCanvas = ref<HTMLCanvasElement | null>(null)

const allComments = computed(() => userComments.value)

const isOwner = computed(() => {
  const profileId = String(route.params.userId || '')
  const myId = String(userStore.info.userId || '')
  return !profileId || profileId === myId
})

const formatNum = (n: number) => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(Math.round(n * 100) / 100)
}

const formatDate = (d: string) => {
  if (!d) return '2025年01月01日'
  const t = new Date(d)
  return `${t.getFullYear()}年${String(t.getMonth()+1).padStart(2,'0')}月${String(t.getDate()).padStart(2,'0')}日`
}

const loadProfile = async () => {
  try {
    const userId = route.params.userId || userStore.info.userId || 1
    const data: any = await request.get({ url: '/api/user/profile?userId=' + userId })
    profile.value = data
  } catch (e) { console.error(e) }
}

const loadUserApps = async () => {
  try {
    const userId = route.params.userId || userStore.info.userId || 1
    const data: any = await request.get({ url: '/api/user/apps?userId=' + userId })
    userApps.value = data?.list || []
  } catch {}
}

const loadUserComments = async () => {
  try {
    const userId = route.params.userId || userStore.info.userId || 1
    const data: any = await request.get({ url: `/api/user/comments?userId=${userId}` })
    userComments.value = data?.list || []
  } catch {}
}

const drawStars = () => {
  nextTick(() => {
    const cvs = starCanvas.value
    if (!cvs) return
    const ctx = cvs.getContext('2d')
    if (!ctx) return
    cvs.width = cvs.offsetWidth
    cvs.height = cvs.offsetHeight
    for (let i = 0; i < 60; i++) {
      const x = Math.random() * cvs.width
      const y = Math.random() * cvs.height * 0.75
      const r = Math.random() * 1.8 + 0.6
      ctx.beginPath()
      ctx.arc(x, y, r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.6 + 0.2})`
      ctx.fill()
    }
  })
}

const goEdit = () => router.push('/appstore/profile/edit')
const goAppDetail = (id: number) => router.push(`/appstore/browse/detail/${id}`)
const handleLogout = () => { userStore.logOut?.(); router.push('/appstore/browse/login') }

const handleDeleteComment = async (c: any) => {
  try {
    await ElMessageBox.confirm('确定要删除这条评论吗？删除后不可恢复。', '删除评论', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      type: 'warning'
    })
    const uid = userStore.info.userId || 1
    await request.del({ url: `/api/app/${c.appId}/comment/${c.id}?userId=${uid}` })
    ElMessage.success('已删除')
    userComments.value = userComments.value.filter(item => item.id !== c.id)
  } catch {}
}

onMounted(() => { loadProfile(); loadUserApps(); loadUserComments(); drawStars() })
</script>
