<template>
  <div class="min-h-screen bg-[#f5f5f5] flex flex-col">
    <div class="bg-white px-3 py-3 flex items-center gap-3 border-b border-gray-100">
      <svg class="w-5 h-5 text-gray-700 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1">{{ pageTitle }}</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-4">
      <div v-if="loading" class="flex justify-center py-20">
        <div class="animate-spin w-5 h-5 border-2 border-gray-300 border-t-gray-600 rounded-full" />
      </div>

      <div v-else-if="messages.length > 0" class="px-4 pt-3 space-y-3">
        <template v-for="(group, gi) in groupedMessages" :key="gi">
          <div class="text-center py-2">
            <span class="text-[11px] text-gray-400 bg-[#f5f5f5] px-3 py-0.5 rounded-full">{{ group.label }}</span>
          </div>
          <div
            v-for="msg in group.items"
            :key="msg.id"
            class="bg-white rounded-xl px-3 py-3 relative overflow-hidden"
            :class="msg.isRead ? 'opacity-75' : ''"
          >
            <div v-if="!msg.isRead" class="absolute left-0 top-3 bottom-3 w-[3px] rounded-r-full" :style="{ background: notifyType === 'comment' ? '#448AFF' : '#FFB74D' }" />
            <div class="flex items-start gap-3">
              <div class="w-[36px] h-[36px] rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" :style="{ background: iconBg }">
                <svg class="w-[18px] h-[18px] text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path v-if="notifyType === 'comment'" d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
                  <path v-else d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                </svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between mb-1.5">
                  <span class="text-[13px] font-semibold" :class="msg.isRead ? 'text-gray-500' : 'text-gray-800'">{{ msg.title }}</span>
                  <span class="text-[10px] text-gray-400 flex-shrink-0 ml-2">{{ fmtTimeShort(msg.createTime) }}</span>
                </div>
                <div class="text-[12px] leading-relaxed" :class="msg.isRead ? 'text-gray-400' : 'text-gray-600'">{{ msg.content }}</div>
              </div>
            </div>
          </div>
        </template>
      </div>

      <div v-else class="flex flex-col items-center justify-center py-24">
        <svg class="w-16 h-16 text-gray-200 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path v-if="notifyType === 'comment'" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
          <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        <span class="text-sm text-gray-400">{{ notifyType === 'comment' ? '暂无评论消息' : '暂无系统消息' }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchNotifications, fetchMarkNotificationsRead } from '@/api/message'
import type { NotificationItem } from '@/api/message'

const route = useRoute()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0

const notifyType = route.path.includes('/comments') ? 'comment' : ((route.query.type as string) || 'system')
const pageTitle = computed(() => notifyType === 'comment' ? '评论' : '系统')
const iconBg = computed(() => notifyType === 'comment' ? 'linear-gradient(135deg, #448AFF, #2979FF)' : 'linear-gradient(135deg, #FFB74D, #FF9800)')

const messages = ref<NotificationItem[]>([])
const loading = ref(true)

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  return new Date(t.replace(' ', 'T') + 'Z')
}

const getDayLabel = (dateStr: string) => {
  const d = toUtcDate(dateStr)
  const now = new Date()
  const todayStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()))
  const yesterdayStart = new Date(todayStart.getTime() - 86400000)
  const msgDay = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()))
  if (msgDay.getTime() === todayStart.getTime()) return '今天'
  if (msgDay.getTime() === yesterdayStart.getTime()) return '昨天'
  return '更早'
}

const groupedMessages = computed(() => {
  const groups: { label: string; items: NotificationItem[] }[] = []
  let lastLabel = ''
  for (const msg of messages.value) {
    const label = getDayLabel(msg.createTime)
    if (label !== lastLabel) {
      groups.push({ label, items: [] })
      lastLabel = label
    }
    groups[groups.length - 1].items.push(msg)
  }
  return groups
})

const fmtTimeShort = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const y = d.getFullYear()
  const m = (d.getMonth() + 1).toString().padStart(2, '0')
  const day = d.getDate().toString().padStart(2, '0')
  const h = d.getHours().toString().padStart(2, '0')
  const min = d.getMinutes().toString().padStart(2, '0')
  return `${y}/${m}/${day} ${h}:${min}`
}

onMounted(async () => {
  try {
    const res: any = await fetchNotifications(myUserId, 1, notifyType)
    messages.value = res.list || []
    await fetchMarkNotificationsRead(myUserId, notifyType)
  } catch {}
  loading.value = false
})
</script>
