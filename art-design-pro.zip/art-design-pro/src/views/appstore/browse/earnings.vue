<template>
  <div class="earn-page">
    <div class="earn-navbar">
      <button class="earn-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="earn-nav-title">创作收益</span>
      <div style="width:22px" />
    </div>

    <div class="earn-header">
      <div class="earn-total-label">累计收益</div>
      <div class="earn-total-amount">{{ totalEarning }}</div>
    </div>

    <div class="earn-list">
      <div class="earn-section-title">收益明细</div>
      <div v-if="!records.length" class="earn-empty">暂无收益记录</div>
      <div v-for="r in records" :key="r.id" class="earn-item">
        <div class="ei-left">
          <div class="ei-title">{{ r.content_title || '内容 #'+r.content_id }}</div>
          <div class="ei-meta">{{ r.content_type==='app'?'应用':'帖子' }} · {{ r.create_time?.slice(0,16) }}</div>
        </div>
        <div class="ei-right">
          <span class="ei-amount">+{{ r.commission_amount }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import request from '@/utils/http'

const totalEarning = ref(0)
const records = ref<any[]>([])

async function loadData() {
  try {
    const r: any = await request.get({ url: '/api/content/earnings/my' })
    const d = r.data || r
    totalEarning.value = d.total || 0
    records.value = d.records || d || []
  } catch {}
}

onMounted(loadData)
</script>

<style scoped>
.earn-page { min-height: 100vh; background: #f8f9fa; }
.earn-navbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #fff; border-bottom: 1px solid #eee; }
.earn-nav-back { border: none; background: none; cursor: pointer; padding: 4px; }
.earn-nav-title { font-size: 17px; font-weight: 600; }
.earn-header { padding: 24px 16px; background: linear-gradient(135deg, #10B981, #059669); color: #fff; text-align: center; }
.earn-total-label { font-size: 14px; opacity: .8; }
.earn-total-amount { font-size: 36px; font-weight: 700; margin-top: 4px; }
.earn-list { padding: 16px; }
.earn-section-title { font-size: 16px; font-weight: 600; margin-bottom: 12px; }
.earn-empty { text-align: center; padding: 32px; color: #999; }
.earn-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #fff; border-radius: 10px; margin-bottom: 8px; }
.ei-left { flex: 1; }
.ei-title { font-size: 14px; font-weight: 500; }
.ei-meta { font-size: 12px; color: #999; margin-top: 2px; }
.ei-right { text-align: right; }
.ei-amount { font-size: 16px; font-weight: 600; color: #10B981; }
</style>
