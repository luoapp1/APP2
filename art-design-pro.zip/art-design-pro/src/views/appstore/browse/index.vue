<template>
  <div class="home-page">
    <!-- 搜索栏 -->
    <div class="search-section">
      <div class="search-box">
        <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="1.5"/><path d="M21 21l-4.35-4.35" stroke-width="1.5" stroke-linecap="round"/></svg>
        <input v-model="keyword" class="search-input" placeholder="搜索全网应用" @keyup.enter="searchApps" />
      </div>
    </div>

    <!-- 标签导航 -->
    <div class="tag-bar">
      <div
        v-for="tag in tagList"
        :key="tag.name"
        class="tag-item"
        :class="{ active: activeTag === tag.name }"
        @click="activeTag = tag.name; filterByTag(tag.name)"
      >{{ tag.name }}</div>
    </div>

    <div class="scroll-area">

      <!-- 蓝色横幅 -->
      <div class="banner-card" @click="$router.push('/appstore/category')">
        <div class="banner-bg" />
        <svg class="banner-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2" stroke-linecap="round"/></svg>
        <div class="banner-text">
          <div class="banner-title">新手必看教程</div>
          <div class="banner-sub">发帖指引之基础篇</div>
        </div>
        <svg class="banner-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </div>

      <!-- 5个快捷入口 -->
      <div class="quick-entry-card">
        <div class="quick-grid">
          <div v-for="item in quickIcons" :key="item.label" class="quick-item" @click="$router.push(item.link)">
            <div class="quick-icon" :style="{ background: item.bg }">
              <svg viewBox="0 0 24 24" fill="currentColor"><path :d="item.icon"/></svg>
            </div>
            <span class="quick-label">{{ item.label }}</span>
          </div>
        </div>
      </div>

      <!-- 应用收录通知 -->
      <div class="notice-bar">
        <svg class="notice-icon" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
        <span class="notice-text">应用商店已收录 {{ total }} 款优质应用</span>
        <svg class="notice-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </div>

      <!-- 应用列表 -->
      <div class="app-section">
        <div class="section-header">
          <span class="section-title">推荐应用</span>
          <span class="section-more" @click="$router.push('/appstore/category')">更多 <svg class="inline-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg></span>
        </div>

        <div v-if="loading" class="loading-spinner">
          <div class="spinner" />
        </div>

        <div v-for="app in appList" :key="app.id" class="app-card" @click="openDetail(app.id)">
          <div class="app-icon" :style="{ background: app.iconBgColor || iconColor(app.name) }">
            <img v-if="app.icon" :src="app.icon" />
            <span v-else class="app-icon-letter">{{ (app.name || '?')[0] }}</span>
          </div>
          <div class="app-info">
            <div class="app-name">{{ app.name }}</div>
            <div class="app-rating-row">
              <svg class="star-icon" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              <span class="rating-text">{{ toNum(app.rating).toFixed(1) }}</span>
              <span class="version-text">{{ app.version }}</span>
            </div>
            <div class="app-tags-row">
              <span v-for="ot in (app.officialTags || [])" :key="ot.id" class="app-tag" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
              <span v-for="tag in (app.tags || [])" :key="tag" class="app-tag" :class="tag === '星选' ? 'tag-star' : 'tag-normal'">{{ tag }}</span>
              <span class="app-meta">{{ app.sizeMb }} MB</span>
              <span class="app-meta-sep">&middot;</span>
              <span class="app-meta">{{ fmtCount(app.downloads) }}{{ app.downloads > 0 ? ' 下载' : '' }}</span>
            </div>
          </div>
          <button class="view-btn" @click.stop="openDetail(app.id)">查看</button>
        </div>
      </div>
    </div>

    <!-- 评分弹窗 -->
    <div v-if="showRateDialog" class="modal-overlay" @click.self="showRateDialog = false">
      <div class="modal-card">
        <div class="modal-title">评价 {{ ratingTarget?.name }}</div>
        <div class="star-picker">
          <svg v-for="s in 5" :key="s" class="star-btn" :class="s <= ratingScore ? 'active' : ''" fill="currentColor" viewBox="0 0 20 20" @click="ratingScore = s"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
        </div>
        <div v-if="rateMsg" class="modal-msg">{{ rateMsg }}</div>
        <div class="modal-actions">
          <button class="btn-cancel" @click="showRateDialog = false">取消</button>
          <button class="btn-confirm" @click="submitRating">确认评分</button>
        </div>
      </div>
    </div>

    <!-- 打赏弹窗 -->
    <div v-if="showTipDialog" class="modal-overlay" @click.self="showTipDialog = false">
      <div class="modal-card">
        <div class="modal-title">打赏 {{ tipTarget?.name }}</div>
        <div class="amount-grid">
          <div v-for="amt in [1,2,5,8,10]" :key="amt" class="amount-item" :class="{ active: tipAmount === amt }" @click="tipAmount = amt">{{ amt }}元</div>
        </div>
        <input v-model.number="customTipAmount" type="number" placeholder="自定义金额" class="modal-input" @input="onCustomTipAmount" />
        <input v-model="tipMessage" placeholder="留言(选填)" class="modal-input" />
        <div v-if="tipMsg" class="modal-msg">{{ tipMsg }}</div>
        <div class="modal-actions">
          <button class="btn-cancel" @click="showTipDialog = false">取消</button>
          <button class="btn-confirm" @click="submitTip">确认打赏</button>
        </div>
      </div>
    </div>

    <!-- 底部导航 -->
    <div class="bottom-nav">
      <div class="nav-item active">
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span>首页</span>
      </div>
      <div class="nav-item" @click="$router.push('/appstore/category')">
        <svg fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        <span>应用</span>
      </div>
      <div class="nav-item" @click="$router.push('/community')">
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <span>社区</span>
      </div>
      <div class="nav-item" :class="{ active: $route.path === '/appstore/game' }" @click="$router.push('/appstore/game')">
        <svg fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <span>发现</span>
      </div>
      <div class="nav-item" @click="$router.push('/appstore/mine')">
        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
        <span>我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchAppList, fetchPostComment, fetchPostTip, fetchCategoryList } from '@/api/appstore'
import { useUserStore } from '@/store/modules/user'

const router = useRouter()
const userStore = useUserStore()
const keyword = ref('')
const activeTag = ref('推荐')
const appList = ref<any[]>([])
const total = ref(0)
const loading = ref(true)

const showRateDialog = ref(false)
const showTipDialog = ref(false)
const ratingTarget = ref<any>(null)
const ratingScore = ref(5)
const rateMsg = ref('')
const tipTarget = ref<any>(null)
const tipAmount = ref(5)
const tipMsg = ref('')
const tipMessage = ref('')
const customTipAmount = ref<number | ''>('')
const ratedApps = reactive<Record<number, boolean>>({})

const tagList = ref<{ id: number, name: string }[]>([{ id: 0, name: '推荐' }])

const quickIcons = [
  { label: '星选', bg: '#8B5CF6', icon: 'M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z', link: '/appstore/category' },
  { label: '排行榜', bg: '#F97316', icon: 'M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12', link: '/appstore/category' },
  { label: '必备', bg: '#3B82F6', icon: 'M5 13l4 4L19 7', link: '/appstore/category' },
  { label: '发现', bg: '#EC4899', icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z', link: '/appstore/game' },
  { label: '专题', bg: '#22C55E', icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10', link: '/appstore/category' },
]

const toNum = (v: any) => Number(v) || 0
const fmtCount = (n: number): string => {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
  return String(n)
}

const colorPool = ['#4F8AF7', '#6C5CE7', '#00BFA5', '#F97316', '#EC4899', '#EF4444', '#8B5CF6', '#10B981', '#3B82F6', '#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const checkLogin = (): boolean => {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return false
  }
  return true
}

const handleRate = (app: any) => {
  if (!checkLogin()) return
  ratingTarget.value = app
  ratingScore.value = 5
  rateMsg.value = ''
  showRateDialog.value = true
}

const submitRating = async () => {
  if (!ratingTarget.value) return
  try {
    await fetchPostComment(ratingTarget.value.id, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      rating: ratingScore.value,
      content: `评分 ${ratingScore.value} 星`
    })
    ratedApps[ratingTarget.value.id] = true
    rateMsg.value = '评价成功'
    setTimeout(() => { showRateDialog.value = false }, 800)
  } catch (e: any) {
    rateMsg.value = e?.msg || '评价失败'
  }
}

const handleTip = (app: any) => {
  if (!checkLogin()) return
  tipTarget.value = app
  tipAmount.value = 2
  tipMsg.value = ''
  tipMessage.value = ''
  customTipAmount.value = ''
  showTipDialog.value = true
}

const onCustomTipAmount = () => {
  if (customTipAmount.value && Number(customTipAmount.value) > 0) {
    tipAmount.value = Number(customTipAmount.value)
  }
}

const submitTip = async () => {
  if (!tipTarget.value) return
  try {
    const data = await fetchPostTip(tipTarget.value.id, {
      userId: userStore.info.userId,
      userName: userStore.info.userName || userStore.info.username,
      amount: tipAmount.value,
      tipType: 'balance',
      message: tipMessage.value
    })
    if (data.newBalance !== undefined) userStore.info.balance = data.newBalance
    if (data.newPoints !== undefined) userStore.info.points = data.newPoints
    tipMsg.value = data.msg || '打赏成功'
    setTimeout(() => { showTipDialog.value = false }, 800)
  } catch (e: any) {
    tipMsg.value = e?.msg || '打赏失败'
  }
}

const loadApps = async () => {
  loading.value = true
  try {
    const params: Record<string, any> = { page: 1, pageSize: 10, status: '1' }
    if (activeTag.value && activeTag.value !== '推荐') params.category = activeTag.value
    if (keyword.value) params.keyword = keyword.value
    const res: any = await fetchAppList(params)
    appList.value = res.list || []
    total.value = res.total || 0
  } catch {}
  loading.value = false
}

const searchApps = () => loadApps()
const filterByTag = (tag: string) => { activeTag.value = tag; loadApps() }
const openDetail = (id: number) => window.open(`/#/appstore/browse/detail/${id}`, '_blank')

const loadCategories = async () => {
  try {
    const res: any = await fetchCategoryList()
    const cats = res || []
    tagList.value = [{ id: 0, name: '推荐' }, ...cats.map((c: any) => ({ id: c.id, name: c.name }))]
  } catch {}
}

onMounted(() => { loadCategories(); loadApps() })
</script>

<style scoped>
.home-page {
  min-height: 100vh;
  background: linear-gradient(180deg, #f0fdf6 0%, #f8fafc 30%, #f5f5f5 100%);
  display: flex;
  flex-direction: column;
  padding-bottom: 56px;
}

/* ===== 搜索栏 ===== */
.search-section {
  padding: 14px 16px 10px;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff;
  border-radius: 28px;
  padding: 11px 18px;
  box-shadow: 0 2px 12px rgba(0,0,0,.04);
  border: 1.5px solid #e8f5f0;
  transition: border-color .2s, box-shadow .2s;
}

.search-box:focus-within {
  border-color: #00BFA5;
  box-shadow: 0 2px 16px rgba(0,191,165,.1);
}

.search-icon {
  width: 17px;
  height: 17px;
  color: #94a3b8;
  flex-shrink: 0;
}

.search-input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  font-size: 14px;
  color: #334155;
}

.search-input::placeholder {
  color: #cbd5e1;
}

/* ===== 标签栏 ===== */
.tag-bar {
  display: flex;
  overflow-x: auto;
  gap: 8px;
  padding: 4px 16px 10px;
  scrollbar-width: none;
}

.tag-bar::-webkit-scrollbar { display: none; }

.tag-item {
  flex-shrink: 0;
  padding: 6px 16px;
  border-radius: 20px;
  font-size: 13px;
  cursor: pointer;
  background: #fff;
  color: #64748b;
  border: 1px solid #e2e8f0;
  font-weight: 500;
  transition: all .2s;
}

.tag-item.active {
  background: #00BFA5;
  color: #fff;
  border-color: #00BFA5;
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,191,165,.25);
}

/* ===== 滚动区域 ===== */
.scroll-area {
  flex: 1;
  overflow-y: auto;
  padding: 0 12px 16px;
}

/* ===== 横幅 ===== */
.banner-card {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 14px 14px;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  margin-top: 4px;
}

.banner-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #4F8AF7 0%, #6C5CE7 100%);
  z-index: 0;
}

.banner-icon {
  width: 28px;
  height: 28px;
  color: rgba(255,255,255,.85);
  flex-shrink: 0;
  position: relative;
  z-index: 1;
}

.banner-text {
  flex: 1;
  min-width: 0;
  position: relative;
  z-index: 1;
}

.banner-title {
  font-size: 15px;
  font-weight: 700;
  color: #fff;
}

.banner-sub {
  font-size: 12px;
  color: rgba(255,255,255,.7);
  margin-top: 1px;
}

.banner-arrow {
  width: 14px;
  height: 14px;
  color: rgba(255,255,255,.6);
  flex-shrink: 0;
  position: relative;
  z-index: 1;
}

/* ===== 快捷入口 ===== */
.quick-entry-card {
  background: #fff;
  border-radius: 20px;
  margin-top: 10px;
  padding: 18px 12px 14px;
  box-shadow: 0 2px 12px rgba(0,0,0,.03);
}

.quick-grid {
  display: flex;
  justify-content: space-around;
}

.quick-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  cursor: pointer;
  transition: transform .15s;
}

.quick-item:active { transform: scale(.93); }

.quick-icon {
  width: 42px;
  height: 42px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0,0,0,.08);
}

.quick-icon svg {
  width: 18px;
  height: 18px;
}

.quick-label {
  font-size: 11px;
  color: #475569;
  font-weight: 500;
}

.quick-item:active { transform: scale(.93); }

.quick-icon {
  width: 50px;
  height: 50px;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 16px rgba(0,0,0,.1);
}

.quick-icon svg {
  width: 22px;
  height: 22px;
  color: #fff;
}

.quick-label {
  font-size: 11px;
  color: #64748b;
  font-weight: 500;
}

/* ===== 通知栏 ===== */
.notice-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  background: linear-gradient(135deg, #e6f9f6, #dff7f3);
  border-radius: 14px;
  margin-top: 10px;
  padding: 11px 14px;
}

.notice-icon {
  width: 16px;
  height: 16px;
  color: #00BFA5;
  flex-shrink: 0;
}

.notice-text {
  flex: 1;
  font-size: 12px;
  color: #059669;
  font-weight: 500;
}

.notice-arrow {
  width: 14px;
  height: 14px;
  color: #00BFA5;
  flex-shrink: 0;
}

/* ===== 应用列表 ===== */
.app-section {
  margin-top: 16px;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 4px;
  margin-bottom: 10px;
}

.section-title {
  font-size: 16px;
  font-weight: 800;
  color: #0f172a;
}

.section-more {
  font-size: 12px;
  color: #94a3b8;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 2px;
}

.inline-icon {
  width: 12px;
  height: 12px;
  display: inline;
}

.loading-spinner {
  display: flex;
  justify-content: center;
  padding: 32px 0;
}

.spinner {
  width: 24px;
  height: 24px;
  border: 2.5px solid #e2e8f0;
  border-top-color: #00BFA5;
  border-radius: 50%;
  animation: spin .7s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

/* ===== 应用卡片 ===== */
.app-card {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff;
  border-radius: 14px;
  padding: 10px 12px;
  margin-bottom: 8px;
  cursor: pointer;
  box-shadow: 0 1px 6px rgba(0,0,0,.02);
  border: 1px solid #f1f5f9;
  transition: box-shadow .15s;
}

.app-card:hover {
  box-shadow: 0 2px 14px rgba(0,0,0,.05);
}

.app-icon {
  width: 44px;
  height: 44px;
  border-radius: 13px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: 0 3px 8px rgba(0,0,0,.06);
}

.app-icon img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.app-icon svg {
  width: 18px;
  height: 18px;
}

.app-icon-letter {
  font-size: 18px;
  font-weight: 700;
  color: #fff;
  line-height: 1;
}

.app-info {
  flex: 1;
  min-width: 0;
}

.app-name {
  font-size: 14px;
  font-weight: 700;
  color: #0f172a;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.app-rating-row {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 1px;
}

.star-icon {
  width: 12px;
  height: 12px;
  color: #f59e0b;
  flex-shrink: 0;
}

.rating-text {
  font-size: 11px;
  font-weight: 600;
  color: #475569;
}

.version-text {
  font-size: 10px;
  color: #94a3b8;
}

.app-tags-row {
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 2px;
  flex-wrap: wrap;
}

.app-tag {
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 5px;
  font-weight: 500;
}

.tag-star { background: #ede9fe; color: #7c3aed; }
.tag-normal { background: #d1fae5; color: #059669; }

.app-meta {
  font-size: 11px;
  color: #94a3b8;
}

.app-meta-sep {
  font-size: 11px;
  color: #cbd5e1;
}

.view-btn {
  flex-shrink: 0;
  padding: 4px 14px;
  border-radius: 14px;
  border: 1.5px solid #00BFA5;
  color: #00BFA5;
  font-size: 11px;
  font-weight: 600;
  background: #fff;
  cursor: pointer;
  transition: all .15s;
}

.view-btn:hover {
  background: #00BFA5;
  color: #fff;
}

/* ===== 弹窗 ===== */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  animation: fadeIn .2s;
}

.modal-card {
  background: #fff;
  border-radius: 20px;
  width: 320px;
  padding: 24px 20px 16px;
}

.modal-title {
  font-size: 17px;
  font-weight: 700;
  color: #1e293b;
  margin-bottom: 14px;
}

.star-picker {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-bottom: 16px;
}

.star-btn {
  width: 36px;
  height: 36px;
  cursor: pointer;
  color: #e2e8f0;
  transition: color .15s, transform .15s;
}

.star-btn.active {
  color: #f59e0b;
}

.star-btn:active { transform: scale(.9); }

.amount-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
}

.amount-item {
  padding: 8px 16px;
  border-radius: 10px;
  font-size: 13px;
  cursor: pointer;
  border: 1px solid #e2e8f0;
  color: #475569;
  font-weight: 500;
  transition: all .15s;
}

.amount-item.active {
  background: #00BFA5;
  color: #fff;
  border-color: #00BFA5;
}

.modal-input {
  width: 100%;
  padding: 10px 14px;
  border: 1.5px solid #e2e8f0;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  color: #334155;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.modal-input:focus { border-color: #00BFA5; }

.modal-msg {
  font-size: 12px;
  color: #00BFA5;
  text-align: center;
  margin-bottom: 8px;
}

.modal-actions {
  display: flex;
  gap: 10px;
}

.btn-cancel {
  flex: 1;
  padding: 11px;
  border-radius: 10px;
  font-size: 14px;
  border: none;
  background: #f1f5f9;
  color: #64748b;
  font-weight: 600;
  cursor: pointer;
}

.btn-confirm {
  flex: 1;
  padding: 11px;
  border-radius: 10px;
  font-size: 14px;
  border: none;
  background: #00BFA5;
  color: #fff;
  font-weight: 600;
  cursor: pointer;
}

/* ===== 底部导航 ===== */
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255,255,255,.95);
  backdrop-filter: blur(16px);
  border-top: 1px solid #f1f5f9;
  display: flex;
  justify-content: space-around;
  padding: 6px 0 max(8px, env(safe-area-inset-bottom));
  z-index: 50;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  cursor: pointer;
  color: #94a3b8;
  transition: color .15s;
}

.nav-item svg {
  width: 22px;
  height: 22px;
}

.nav-item span {
  font-size: 9px;
}

.nav-item.active {
  color: #00BFA5;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
</style>
