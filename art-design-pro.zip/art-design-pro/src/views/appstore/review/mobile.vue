<template>
  <div class="review-mobile-page">
    <div class="page-header">
      <div class="header-left" @click="handleGoBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
      </div>
      <div class="header-center">
        <div class="header-title">投稿审核</div>
        <div class="header-sub">共 {{ total }} 条</div>
      </div>
      <div class="header-right" @click="searchOpen = !searchOpen">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card stat-card--pending"><div class="stat-card-value">{{ statusCounts.pending }}</div><div class="stat-card-label">待审核</div></div>
      <div class="stat-card stat-card--approved"><div class="stat-card-value">{{ statusCounts.approved }}</div><div class="stat-card-label">已通过</div></div>
      <div class="stat-card stat-card--rejected"><div class="stat-card-value">{{ statusCounts.rejected }}</div><div class="stat-card-label">未通过</div></div>
      <div class="stat-card stat-card--total"><div class="stat-card-value">{{ statusCounts.removed }}</div><div class="stat-card-label">已下架</div></div>
    </div>

    <div class="filter-tabs">
      <span v-for="tab in statusTabs" :key="tab.value" :class="['filter-tab', { active: activeStatus === tab.value }]" @click="handleStatusChange(tab.value)">{{ tab.label }}</span>
    </div>

    <div v-if="searchOpen" class="search-bar">
      <input ref="searchInputRef" v-model="searchKeyword" class="search-input" placeholder="搜索应用/包名/上传者" @keyup.enter="fetchData" />
      <button class="search-btn" @click="fetchData">搜索</button>
    </div>

    <div class="content-area">
      <div v-if="loading" style="display:flex;justify-content:center;padding:40px 0">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2" style="animation:spin 0.8s linear infinite"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg>
      </div>

      <div v-else-if="tableData.length === 0" class="empty-state">
        <svg class="empty-icon" viewBox="0 0 120 120" fill="none">
          <rect x="36" y="30" width="48" height="60" rx="6" stroke="#CDD6E8" stroke-width="1.5" fill="white"/>
          <path d="M42 48h36M42 58h28M42 68h20" stroke="#E8EDF5" stroke-width="3" stroke-linecap="round"/>
          <rect x="20" y="24" width="80" height="10" rx="5" fill="#E8EDF5" opacity="0.6"/>
        </svg>
        <p class="empty-text">暂无审核记录</p>
      </div>

      <div v-else class="review-list">
        <div v-for="group in groupedData" :key="group.packageName" class="review-card">
          <div class="card-main" @click="toggleExpand(group.packageName)">
            <div class="card-icon" :style="{ background: group.latest.iconBgColor || '#00BFA5' }">
              <img v-if="group.latest.icon" :src="group.latest.icon" class="icon-img" />
              <svg v-else width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div class="card-info">
              <div class="card-name">
                {{ group.latest.name }}
                <span class="version-count-badge">{{ group.items.length }}个版本</span>
              </div>
              <div class="card-meta">{{ group.latest.userName }} | {{ group.latest.category || '-' }}</div>
              <div class="card-meta-sub">{{ group.packageName }}</div>
              <div class="card-time">{{ group.latest.createTime }}</div>
            </div>
            <svg :class="['card-arrow', { rotated: expandedGroup === group.packageName }]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>
          </div>

          <div v-if="expandedGroup === group.packageName" class="card-detail-list">
            <div v-for="item in group.items" :key="item.id" class="sub-item">
              <div class="sub-item-header">
                <span :class="['status-badge', 'status-' + item.submissionStatus]">{{ getStatusLabel(item.submissionStatus) }}</span>
                <span class="sub-item-version">v{{ item.version }}</span>
                <span class="sub-item-time">{{ item.createTime }}</span>
              </div>

              <div class="sub-item-body">
                <div class="detail-row"><span class="detail-label">大小</span><span class="detail-value">{{ item.sizeMb || 0 }} MB</span></div>
                <div class="detail-row"><span class="detail-label">下载地址</span><span class="detail-value detail-link">{{ item.downloadUrl || '-' }}</span></div>
                <div class="detail-row" v-if="item.description"><span class="detail-label">描述</span><span class="detail-value">{{ item.description }}</span></div>
                <div class="detail-row"><span class="detail-label">计价</span><span class="detail-value" :style="{ color: priceColor(item), fontWeight: 500 }">{{ formatPrice(item) }}</span></div>
                <div class="detail-row" v-if="item.versionType"><span class="detail-label">版本类型</span><span class="detail-value">{{ item.versionType }}</span></div>
                <div class="detail-section" v-if="item.hasAds || !item.isFree || item.hasPaidContent || item.requiresNetwork !== false">
                  <div class="detail-section-title">应用标志</div>
                  <div class="tags-row">
                    <span v-if="item.isFree" class="tag-badge" style="background:#dcfce7;color:#16a34a">免费</span>
                    <span v-if="item.hasAds" class="tag-badge" style="background:#fff7ed;color:#ea580c">含广告</span>
                    <span v-if="item.hasPaidContent" class="tag-badge" style="background:#f3e8ff;color:#9333ea">含付费内容</span>
                    <span v-if="item.requiresNetwork" class="tag-badge" style="background:#dbeafe;color:#2563eb">需联网</span>
                  </div>
                </div>
              </div>

              <div v-if="resolvedScreenshots(item).length > 0" class="detail-section">
                <div class="detail-section-title">应用截图</div>
                <div class="screenshots-row">
                  <div v-for="(ss, si) in resolvedScreenshots(item).slice(0, 6)" :key="si" class="screenshot-thumb" @click="viewScreenshot(ss, resolvedScreenshots(item), si)">
                    <img :src="ss" class="screenshot-img" />
                  </div>
                </div>
              </div>

              <div v-if="resolvedTags(item).length > 0 || (item.officialTags || []).length > 0" class="detail-section">
                <div class="detail-section-title">标签</div>
                <div class="tags-row">
                  <span v-for="(t, ti) in resolvedTags(item)" :key="ti" class="tag-badge" :style="tagBadgeStyle(t)">{{ t }}</span>
                  <span v-for="ot in (item.officialTags || [])" :key="'ot'+ot.id" class="tag-badge" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
                </div>
              </div>

              <div v-if="item.reviewBy" class="detail-section">
                <div class="detail-section-title">审核信息</div>
                <div class="detail-row"><span class="detail-label">审核人</span><span class="detail-value">{{ item.reviewBy }}</span></div>
                <div class="detail-row" v-if="item.reviewTime"><span class="detail-label">时间</span><span class="detail-value">{{ item.reviewTime }}</span></div>
                <div class="detail-row" v-if="item.reviewComment"><span class="detail-label">备注</span><span class="detail-value" style="color:#f59e0b">{{ item.reviewComment }}</span></div>
              </div>

              <div class="sub-item-actions">
                <button class="action-btn action-edit-info" @click.stop="handleEditInfo(item)">编辑信息</button>
                <button v-if="item.submissionStatus === 'draft'" class="action-btn action-submit" @click.stop="handleSubmitReview(item)">提交审核</button>
                <button v-if="item.submissionStatus === 'pending'" class="action-btn action-approve" @click.stop="handleApprove(item)">通过</button>
                <button v-if="item.submissionStatus === 'pending'" class="action-btn action-reject" @click.stop="handleReject(item)">驳回</button>
                <button v-if="item.submissionStatus === 'approved'" class="action-btn action-remove" @click.stop="handleRemove(item)">下架</button>
                <button v-if="item.submissionStatus === 'removed'" class="action-btn action-relist" @click.stop="handleRelist(item)">重新上架</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="total > pageSize" class="pagination-wrap">
      <el-pagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="prev, pager, next" @current-change="fetchData" />
    </div>

    <!-- 驳回弹窗 -->
    <div v-if="showRejectDialog" class="dialog-overlay" @click.self="showRejectDialog = false">
      <div class="dialog-panel">
        <div class="dialog-title">驳回投稿</div>
        <div class="dialog-app-name">{{ rejectItem?.name }}</div>
        <textarea v-model="rejectComment" class="dialog-textarea" placeholder="请输入驳回原因（可选）" rows="4" />
        <div class="dialog-buttons">
          <button class="dialog-btn dialog-btn-cancel" @click="showRejectDialog = false">取消</button>
          <button class="dialog-btn dialog-btn-confirm" @click="confirmReject">确认驳回</button>
        </div>
      </div>
    </div>

    <!-- 截图预览 -->
    <div v-if="previewVisible" class="screenshot-overlay" @click.self="previewVisible = false">
      <div class="screenshot-viewer">
        <img :src="previewImages[previewIndex]" class="screenshot-full" />
        <div class="screenshot-nav"><span class="screenshot-counter">{{ previewIndex + 1 }} / {{ previewImages.length }}</span></div>
        <button class="screenshot-close" @click="previewVisible = false"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        <button v-if="previewIndex > 0" class="screenshot-prev" @click.stop="previewIndex--"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg></button>
        <button v-if="previewIndex < previewImages.length - 1" class="screenshot-next" @click.stop="previewIndex++"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M9 18l6-6-6-6"/></svg></button>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="showEditDialog" class="dialog-overlay" @click.self="showEditDialog = false">
      <div class="edit-panel">
        <div class="edit-panel-header">
          <button class="edit-panel-back" @click="showEditDialog = false">取消</button>
          <div class="edit-panel-title">编辑信息</div>
          <button class="edit-panel-save" :disabled="editSaving" @click="handleSaveEdit">{{ editSaving ? '保存中...' : '保存' }}</button>
        </div>
        <div class="edit-panel-body">
          <!-- 应用图标 -->
          <div class="edit-field">
            <label class="edit-label">应用图标</label>
            <div class="edit-icon-row">
              <div class="edit-icon-preview" :style="{ background: editForm.iconBg || '#00BFA5' }">
                <img v-if="editForm.icon" :src="editForm.icon" class="edit-icon-img" />
                <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
              </div>
              <button class="edit-icon-btn" @click="triggerIconUpload">更换图标</button>
            </div>
            <input ref="iconInput" type="file" accept="image/*" style="display:none" @change="onIconUpload" />
          </div>
          <div class="edit-field">
            <label class="edit-label">应用名称</label>
            <input v-model="editForm.name" class="edit-input" placeholder="请输入应用名称" />
          </div>
          <div class="edit-field">
            <label class="edit-label">包名</label>
            <input v-model="editForm.packageName" class="edit-input" placeholder="请输入包名" />
          </div>
          <div class="edit-field">
            <label class="edit-label">分类</label>
            <select v-model="editForm.category" class="edit-select">
              <option value="" disabled>请选择分类</option>
              <option v-for="c in editCategoryOptions" :key="c" :value="c">{{ c }}</option>
            </select>
          </div>
          <div class="edit-field">
            <label class="edit-label">版本号</label>
            <input v-model="editForm.version" class="edit-input" placeholder="请输入版本号" />
          </div>
          <div class="edit-field">
            <label class="edit-label">大小(MB)</label>
            <input v-model.number="editForm.sizeMb" type="number" class="edit-input" placeholder="请输入大小" />
          </div>
          <div class="edit-field">
            <label class="edit-label">描述</label>
            <textarea v-model="editForm.description" class="edit-textarea" placeholder="请输入应用描述" rows="3" />
          </div>
          <div class="edit-field">
            <label class="edit-label">标签（逗号分隔）</label>
            <input v-model="editForm.tagsStr" class="edit-input" placeholder="如: 工具,社交,免费" />
          </div>
          <div class="edit-field">
            <label class="edit-label">官方标签（可多选）</label>
            <div class="edit-official-tags">
              <label v-for="ot in editOfficialTagList" :key="ot.id" class="ot-check-label">
                <input type="checkbox" :value="ot.id" v-model="editForm.officialTagIds" class="ot-checkbox" />
                <span class="ot-chip" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
              </label>
            </div>
          </div>
          <div class="edit-field">
            <label class="edit-label">应用标志</label>
            <div class="edit-switch-group">
              <label class="switch-label">
                <input type="checkbox" v-model="editForm.hasAds" class="toggle-input" />
                <span class="toggle-text">是否有广告</span>
              </label>
              <label class="switch-label">
                <input type="checkbox" v-model="editForm.requiresNetwork" class="toggle-input" />
                <span class="toggle-text">是否需要联网</span>
              </label>
              <label class="switch-label">
                <input type="checkbox" v-model="editForm.hasPaidContent" class="toggle-input" />
                <span class="toggle-text">是否包含付费内容</span>
              </label>
              <label class="switch-label">
                <input type="checkbox" v-model="editForm.isFree" class="toggle-input" />
                <span class="toggle-text">是否免费应用</span>
              </label>
            </div>
          </div>
          <div class="edit-field">
            <label class="edit-label">收费方式</label>
            <div class="edit-price-type">
              <button :class="['edit-price-btn', { active: editForm.price_type !== 'balance' && editForm.price_type !== 'points' }]" @click="editForm.price_type = 'free'; editForm.price_amount = 0">免费</button>
              <button :class="['edit-price-btn', { active: editForm.price_type === 'balance' }]" @click="editForm.price_type = 'balance'">余额</button>
              <button :class="['edit-price-btn', { active: editForm.price_type === 'points' }]" @click="editForm.price_type = 'points'">积分</button>
            </div>
          </div>
          <div class="edit-field" v-if="editForm.price_type === 'balance' || editForm.price_type === 'points'">
            <label class="edit-label">{{ editForm.price_type === 'balance' ? '价格(元)' : '价格(积分)' }}</label>
            <input v-model.number="editForm.price_amount" type="number" class="edit-input" placeholder="请输入金额" min="0" step="0.01" />
          </div>
          <div class="edit-field">
            <label class="edit-label">应用截图</label>
            <div class="edit-screenshots">
              <div v-for="(img, i) in editScreenshots" :key="i" class="edit-screenshot-item">
                <img :src="img" class="edit-screenshot-img" />
                <button class="edit-screenshot-del" @click="editScreenshots.splice(i, 1)">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
              </div>
              <div class="edit-screenshot-item edit-screenshot-add" @click="triggerScreenshotUpload">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
              </div>
            </div>
            <input ref="screenshotInput" type="file" accept="image/*" multiple style="display:none" @change="onScreenshotsUpload" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import { fetchReviewList, fetchUpdateSubmissionStatus, fetchSaveSubmission, fetchSubmitReview } from '@/api/submission'
import { fetchCategoryList, fetchOfficialTags } from '@/api/appstore'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const userName = computed(() => userStore.getUserInfo.userName || userStore.getUserInfo.nickname || '')
const roles = computed(() => userStore.getUserInfo.roles || [])

const loading = ref(false)
const searchKeyword = ref('')
const searchOpen = ref(false)
const searchInputRef = ref<HTMLInputElement>()
const activeStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const tableData = ref<any[]>([])
const expandedGroup = ref<string | null>(null)

const showRejectDialog = ref(false)
const rejectComment = ref('')
const rejectItem = ref<any>(null)

const previewVisible = ref(false)
const previewImages = ref<string[]>([])
const previewIndex = ref(0)

const showEditDialog = ref(false)
const editSaving = ref(false)
const editItem = ref<any>(null)
const iconInput = ref<HTMLInputElement>()
const screenshotInput = ref<HTMLInputElement>()
const editScreenshots = ref<string[]>([])
const editOfficialTagList = ref<any[]>([])
const editForm = reactive({
  name: '', packageName: '', category: '', version: '', sizeMb: 0, description: '', tagsStr: '', icon: '', iconBg: '',
  officialTagIds: [] as number[],
  hasAds: false, requiresNetwork: true, hasPaidContent: false, isFree: true,
  price_type: 'free' as string, price_amount: 0 as number
})
const categoryOptions = ref<string[]>([])

const editCategoryOptions = computed(() => {
  const cats = [...categoryOptions.value]
  if (editForm.category && !cats.includes(editForm.category)) {
    cats.unshift(editForm.category)
  }
  return cats
})

const statusTabs = [
  { label: '全部', value: '' }, { label: '审核中', value: 'pending' }, { label: '已通过', value: 'approved' },
  { label: '未通过', value: 'rejected' }, { label: '已下架', value: 'removed' }, { label: '草稿', value: 'draft' }
]
const statusCounts = reactive({ pending: 0, approved: 0, rejected: 0, removed: 0 })

const groupedData = computed(() => {
  const map = new Map<string, any[]>()
  for (const item of tableData.value) {
    const key = item.packageName || String(item.id)
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(item)
  }
  const groups: { packageName: string; latest: any; items: any[] }[] = []
  for (const [pkg, items] of map) {
    groups.push({ packageName: pkg, latest: items[0], items })
  }
  return groups
})

function getStatusLabel(status: string) {
  const map: Record<string, string> = { approved: '已通过', pending: '审核中', rejected: '未通过', removed: '已下架', draft: '草稿' }
  return map[status] || status
}

function formatPrice(item: any): string {
  const pt = item.priceType || 'free'
  const pa = Number(item.priceAmount || 0)
  if (pt === 'free' || pa <= 0) return '免费'
  if (pt === 'balance') return `余额 ${pa} 元`
  if (pt === 'points') return `积分 ${pa}`
  return '免费'
}

function priceColor(item: any): string {
  const pt = item.priceType || 'free'
  if (pt === 'free') return '#10B981'
  if (pt === 'balance') return '#F59E0B'
  if (pt === 'points') return '#8B5CF6'
  return '#10B981'
}

function resolvedScreenshots(item: any): string[] {
  try {
    if (Array.isArray(item.screenshots)) return item.screenshots.filter(Boolean)
    if (typeof item.screenshots === 'string') {
      const parsed = JSON.parse(item.screenshots)
      return Array.isArray(parsed) ? parsed.filter(Boolean) : []
    }
  } catch (_e: unknown) { void _e }
  return []
}

function resolvedTags(item: any): string[] {
  try {
    if (Array.isArray(item.tags)) return item.tags.filter(Boolean)
    if (typeof item.tags === 'string') {
      const parsed = JSON.parse(item.tags)
      return Array.isArray(parsed) ? parsed.filter(Boolean) : []
    }
  } catch (_e: unknown) { void _e }
  return []
}

const tagColorMap: Record<string, { bg: string; color: string }> = {
  '星选': { bg: '#f3e8ff', color: '#7c3aed' },
  '官方版': { bg: '#dbeafe', color: '#2563eb' },
  '测试版': { bg: '#fef3c7', color: '#d97706' },
  '国际版': { bg: '#e0e7ff', color: '#4f46e5' },
  '灰度版': { bg: '#f1f5f9', color: '#475569' },
  '汉化版': { bg: '#ffe4e6', color: '#e11d48' },
  '破解版': { bg: '#fecaca', color: '#dc2626' },
  '修改版': { bg: '#ffedd5', color: '#ea580c' },
}
const defaultTagStyle = { bg: '#ccfbf1', color: '#0d9488' }
const tagBadgeStyle = (tag: string) => {
  const s = tagColorMap[tag] || defaultTagStyle
  return { backgroundColor: s.bg, color: s.color }
}

function handleStatusChange(value: string) { activeStatus.value = value; page.value = 1; fetchData() }

function toggleExpand(packageName: string) {
  expandedGroup.value = expandedGroup.value === packageName ? null : packageName
}

async function fetchData() {
  loading.value = true
  try {
    const data: any = await fetchReviewList({ keyword: searchKeyword.value, submissionStatus: activeStatus.value, page: page.value, pageSize: pageSize.value })
    if (data) {
      tableData.value = data.list || []
      total.value = data.total || 0
      statusCounts.pending = data.pendingCount || 0
      statusCounts.approved = data.approvedCount || 0
      statusCounts.rejected = data.rejectedCount || 0
      statusCounts.removed = data.removedCount || 0
    }
  } catch (_e: unknown) { void _e } finally { loading.value = false }
}

async function fetchCategories() {
  try {
    const data: any = await fetchCategoryList()
    if (data) {
      const list = data.records || data.list || data || []
      const names = list.map((c: any) => c.name || c.category || '').filter(Boolean)
      categoryOptions.value = [...new Set(names as string[])].sort()
    }
  } catch (_e: unknown) { void _e }
}

function handleGoBack() { router.back() }

function handleApprove(item: any) {
  ElMessageBox.confirm(`确定通过「${item.name}」的投稿吗？`, '审核通过', {
    confirmButtonText: '确定通过', cancelButtonText: '取消', type: 'success', customClass: 'mobile-msgbox'
  }).then(async () => {
    await fetchUpdateSubmissionStatus(item.id, { submissionStatus: 'approved', reviewBy: userName.value, reviewComment: '', role: roles.value[0] || '' })
    ElMessage.success('已通过审核'); expandedGroup.value = null; fetchData()
  }).catch(() => {})
}

function handleReject(item: any) { rejectItem.value = item; rejectComment.value = ''; showRejectDialog.value = true }

async function confirmReject() {
  if (!rejectItem.value) return
  try {
    await fetchUpdateSubmissionStatus(rejectItem.value.id, { submissionStatus: 'rejected', reviewBy: userName.value, reviewComment: rejectComment.value, role: roles.value[0] || '' })
    ElMessage.success('已驳回'); showRejectDialog.value = false; expandedGroup.value = null; fetchData()
  } catch { ElMessage.error('操作失败') }
}

function handleRemove(item: any) {
  ElMessageBox.confirm(`确定下架「${item.name}」吗？`, '下架确认', {
    confirmButtonText: '确定下架', cancelButtonText: '取消', type: 'warning', customClass: 'mobile-msgbox'
  }).then(async () => {
    await fetchUpdateSubmissionStatus(item.id, { submissionStatus: 'removed', reviewBy: userName.value, reviewComment: '', role: roles.value[0] || '' })
    ElMessage.success('已下架'); expandedGroup.value = null; fetchData()
  }).catch(() => {})
}

async function handleSubmitReview(item: any) {
  try {
    await fetchSubmitReview(item.id)
    ElMessage.success('已提交审核'); expandedGroup.value = null; fetchData()
  } catch { ElMessage.error('提交失败') }
}

function handleRelist(item: any) {
  ElMessageBox.confirm(`确定重新上架「${item.name}」吗？`, '重新上架', {
    confirmButtonText: '确定上架', cancelButtonText: '取消', type: 'success', customClass: 'mobile-msgbox'
  }).then(async () => {
    await fetchUpdateSubmissionStatus(item.id, { submissionStatus: 'approved', reviewBy: userName.value, reviewComment: '', role: roles.value[0] || '' })
    ElMessage.success('已重新上架'); expandedGroup.value = null; fetchData()
  }).catch(() => {})
}

function viewScreenshot(url: string, images: string[], index: number) {
  previewImages.value = images; previewIndex.value = index; previewVisible.value = true
}

function handleEditInfo(item: any) {
  editItem.value = item
  editForm.name = item.name || ''
  editForm.packageName = item.packageName || ''
  editForm.category = item.category || ''
  editForm.version = item.version || ''
  editForm.sizeMb = item.sizeMb || 0
  editForm.description = item.description || ''
  editForm.icon = item.icon || ''
  editForm.iconBg = item.iconBgColor || ''
  const tags = resolvedTags(item)
  editForm.tagsStr = tags.join(', ')
  editScreenshots.value = [...resolvedScreenshots(item)]
  const ots = item.officialTags || []
  editForm.officialTagIds = (Array.isArray(ots) ? ots : []).map((t: any) => t.id)
  editForm.hasAds = !!item.hasAds
  editForm.requiresNetwork = item.requiresNetwork !== undefined ? !!item.requiresNetwork : true
  editForm.hasPaidContent = !!item.hasPaidContent
  editForm.isFree = item.isFree !== undefined ? !!item.isFree : true
  editForm.price_type = item.priceType || 'free'
  editForm.price_amount = Number(item.priceAmount || 0)
  showEditDialog.value = true
}

function triggerIconUpload() { iconInput.value?.click() }

async function onIconUpload(e: Event) {
  const input = e.target as HTMLInputElement
  if (!input.files?.length) return
  const fd = new FormData()
  fd.append('file', input.files[0])
  try {
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
    if (res.url) editForm.icon = res.url
  } catch { /* ignore */ }
  input.value = ''
}

function triggerScreenshotUpload() { screenshotInput.value?.click() }

async function onScreenshotsUpload(e: Event) {
  const input = e.target as HTMLInputElement
  if (!input.files?.length) return
  for (const file of Array.from(input.files)) {
    const fd = new FormData()
    fd.append('file', file)
    try {
      const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
      if (res.url) editScreenshots.value.push(res.url)
    } catch { /* ignore */ }
  }
  input.value = ''
}

async function handleSaveEdit() {
  const item = editItem.value
  if (!item) return
  editSaving.value = true
  try {
    const tags = editForm.tagsStr.split(',').map((s: string) => s.trim()).filter(Boolean)
    const officialTags = editForm.officialTagIds.map(id => {
      const ot = editOfficialTagList.value.find((t: any) => t.id === id)
      return ot ? { id: ot.id, name: ot.name, color: ot.color, bgColor: ot.bgColor } : null
    }).filter(Boolean)
    await fetchSaveSubmission({
      id: item.id,
      name: editForm.name,
      packageName: editForm.packageName,
      category: editForm.category,
      version: editForm.version,
      sizeMb: editForm.sizeMb,
      description: editForm.description,
      icon: editForm.icon,
      iconBgColor: editForm.iconBg,
      tags,
      officialTags,
      hasAds: editForm.hasAds,
      requiresNetwork: editForm.requiresNetwork,
      hasPaidContent: editForm.hasPaidContent,
      isFree: editForm.isFree,
      price_type: editForm.price_type,
      price_amount: editForm.price_amount,
      screenshots: editScreenshots.value
    })
    ElMessage.success('保存成功')
    showEditDialog.value = false
    fetchData()
  } catch { ElMessage.error('保存失败') } finally { editSaving.value = false }
}

async function loadOfficialTags() {
  try {
    const res: any = await fetchOfficialTags()
    editOfficialTagList.value = (res || []).filter((t: any) => t.status === '1')
  } catch { /* ignore */ }
}

onMounted(() => { fetchCategories(); loadOfficialTags(); fetchData() })
</script>

<style scoped>
@keyframes spin { to { transform: rotate(360deg); } }
.review-mobile-page { min-height: 100vh; background: #f5f5f5; padding-bottom: 20px; }
.page-header { display: flex; align-items: center; padding: 12px 16px; background: #fff; position: sticky; top: 0; z-index: 10; }
.header-left, .header-right { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.header-center { flex: 1; text-align: center; }
.header-title { font-size: 17px; font-weight: 600; color: #1f2937; }
.header-sub { font-size: 11px; color: #9ca3af; margin-top: 1px; }
.stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; padding: 12px 16px; background: #fff; border-top: 1px solid #f3f4f6; }
.stat-card { text-align: center; padding: 8px 4px; border-radius: 10px; }
.stat-card--pending { background: #fef3c7; } .stat-card--approved { background: #d1fae5; } .stat-card--rejected { background: #fee2e2; } .stat-card--total { background: #e0e7ff; }
.stat-card-value { font-size: 22px; font-weight: 700; color: #1f2937; }
.stat-card-label { font-size: 10px; color: #6b7280; margin-top: 2px; }
.filter-tabs { display: flex; gap: 6px; padding: 10px 16px; background: #fff; border-top: 1px solid #f3f4f6; overflow-x: auto; white-space: nowrap; }
.filter-tab { font-size: 12px; padding: 5px 12px; border-radius: 20px; background: #f3f4f6; color: #6b7280; cursor: pointer; flex-shrink: 0; border: 1px solid transparent; transition: all 0.2s; }
.filter-tab.active { background: #00BFA5; color: #fff; border-color: #00BFA5; }
.search-bar { display: flex; gap: 8px; padding: 8px 16px 12px; background: #fff; border-top: 1px solid #f3f4f6; }
.search-input { flex: 1; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 20px; font-size: 13px; outline: none; background: #f9fafb; }
.search-input:focus { border-color: #00BFA5; background: #fff; }
.search-btn { padding: 8px 16px; border: none; border-radius: 20px; background: #00BFA5; color: #fff; font-size: 13px; cursor: pointer; }
.content-area { padding: 8px 16px 0; }
.empty-state { text-align: center; padding: 60px 0; }
.empty-icon { width: 80px; height: 80px; }
.empty-text { font-size: 13px; color: #9ca3af; margin-top: 12px; }
.review-list { display: flex; flex-direction: column; gap: 8px; }
.review-card { background: #fff; border-radius: 14px; padding: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
.card-main { display: flex; align-items: flex-start; gap: 12px; cursor: pointer; }
.card-icon { width: 46px; height: 46px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; overflow: hidden; }
.icon-img { width: 100%; height: 100%; object-fit: cover; }
.card-info { flex: 1; min-width: 0; }
.card-name { font-size: 15px; font-weight: 600; color: #1f2937; display: flex; align-items: center; gap: 8px; }
.status-badge { font-size: 10px; padding: 2px 7px; border-radius: 10px; font-weight: 500; flex-shrink: 0; }
.status-pending { background: #fef3c7; color: #d97706; } .status-approved { background: #d1fae5; color: #059669; } .status-rejected { background: #fee2e2; color: #dc2626; } .status-removed { background: #e0e7ff; color: #4f46e5; } .status-draft { background: #f3f4f6; color: #6b7280; }
.card-meta { font-size: 12px; color: #6b7280; margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.card-meta-sub { font-size: 11px; color: #9ca3af; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.card-time { font-size: 11px; color: #b0b7c3; margin-top: 4px; }
.card-arrow { flex-shrink: 0; margin-top: 4px; transition: transform 0.2s; }
.card-arrow.rotated { transform: rotate(180deg); }
.version-count-badge { font-size: 10px; padding: 2px 7px; border-radius: 10px; background: #e0e7ff; color: #4f46e5; font-weight: 500; flex-shrink: 0; }
.card-detail-list { margin-top: 8px; padding-top: 8px; border-top: 1px solid #f3f4f6; }
.sub-item { padding: 10px 0 10px 12px; border-left: 3px solid #00BFA5; border-bottom: 1px solid #f9fafb; margin-left: 4px; }
.sub-item:last-child { border-bottom: none; }
.sub-item-header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.sub-item-version { font-size: 13px; font-weight: 600; color: #1f2937; }
.sub-item-time { font-size: 11px; color: #b0b7c3; margin-left: auto; }
.sub-item-body { margin-bottom: 6px; }
.sub-item-actions { display: flex; gap: 6px; margin-top: 8px; }
.detail-section { margin-bottom: 8px; }
.detail-section-title { font-size: 12px; font-weight: 600; color: #6b7280; margin-bottom: 6px; }
.detail-row { display: flex; gap: 8px; padding: 3px 0; font-size: 12px; }
.detail-label { color: #9ca3af; flex-shrink: 0; min-width: 60px; }
.detail-value { color: #374151; word-break: break-all; }
.detail-link { color: #3B82F6; font-size: 11px; }
.screenshots-row { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; }
.screenshot-thumb { width: 80px; height: 80px; border-radius: 8px; overflow: hidden; flex-shrink: 0; background: #f3f4f6; cursor: pointer; }
.screenshot-img { width: 100%; height: 100%; object-fit: cover; }
.screenshot-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.92); display: flex; align-items: center; justify-content: center; z-index: 1000; }
.screenshot-viewer { position: relative; display: flex; flex-direction: column; align-items: center; max-width: 100vw; max-height: 100vh; }
.screenshot-full { max-width: 100vw; max-height: 80vh; object-fit: contain; border-radius: 4px; }
.screenshot-nav { margin-top: 12px; }
.screenshot-counter { font-size: 13px; color: #ccc; }
.screenshot-close { position: absolute; top: -44px; right: 0; background: none; border: none; cursor: pointer; padding: 8px; }
.screenshot-prev, .screenshot-next { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(0,0,0,0.4); border: none; border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.screenshot-prev { left: -48px; } .screenshot-next { right: -48px; }
.tags-row { display: flex; flex-wrap: wrap; gap: 6px; }
.tag-badge { font-size: 11px; padding: 3px 10px; border-radius: 12px; font-weight: 500; }
.card-actions { display: none; }
.action-btn { padding: 6px 10px; border: none; border-radius: 8px; font-size: 11px; font-weight: 500; cursor: pointer; white-space: nowrap; }
.action-edit-info { background: #e0e7ff; color: #4f46e5; }
.action-submit { background: #fef3c7; color: #d97706; }
.action-approve { background: #d1fae5; color: #059669; }
.action-reject { background: #fee2e2; color: #dc2626; }
.action-remove { background: #e0e7ff; color: #4f46e5; }
.action-relist { background: #d1fae5; color: #059669; }
.pagination-wrap { display: flex; justify-content: center; padding: 16px 0; }
.dialog-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 24px; }
.dialog-panel { background: #fff; border-radius: 16px; width: 100%; max-width: 340px; padding: 24px 20px 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
.dialog-title { font-size: 17px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
.dialog-app-name { font-size: 13px; color: #6b7280; margin-bottom: 16px; }
.dialog-textarea { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 13px; outline: none; resize: none; box-sizing: border-box; font-family: inherit; }
.dialog-textarea:focus { border-color: #00BFA5; }
.dialog-buttons { display: flex; gap: 10px; margin-top: 16px; }
.dialog-btn { flex: 1; padding: 10px; border: none; border-radius: 10px; font-size: 14px; font-weight: 500; cursor: pointer; }
.dialog-btn-cancel { background: #f3f4f6; color: #374151; }
.dialog-btn-confirm { background: #ef4444; color: #fff; }
.edit-panel { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 -10px 40px rgba(0,0,0,0.2); position: fixed; bottom: 0; left: 0; right: 0; }
.edit-panel-header { display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; border-bottom: 1px solid #f3f4f6; }
.edit-panel-back { font-size: 14px; color: #6b7280; background: none; border: none; cursor: pointer; padding: 0; }
.edit-panel-title { font-size: 16px; font-weight: 600; color: #1f2937; }
.edit-panel-save { font-size: 14px; color: #00BFA5; font-weight: 600; background: none; border: none; cursor: pointer; padding: 0; }
.edit-panel-save:disabled { color: #9ca3af; cursor: not-allowed; }
.edit-panel-body { padding: 16px; overflow-y: auto; flex: 1; }
.edit-field { margin-bottom: 14px; }
.edit-label { display: block; font-size: 12px; color: #6b7280; margin-bottom: 4px; font-weight: 500; }
.edit-input { width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box; }
.edit-input:focus { border-color: #00BFA5; }
.edit-select { width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box; background: #fff; appearance: auto; }
.edit-select:focus { border-color: #00BFA5; }
.edit-textarea { width: 100%; padding: 8px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; outline: none; resize: none; box-sizing: border-box; font-family: inherit; }
.edit-textarea:focus { border-color: #00BFA5; }
.edit-icon-row { display: flex; align-items: center; gap: 12px; }
.edit-icon-preview { width: 56px; height: 56px; border-radius: 14px; display: flex; align-items: center; justify-content: center; color: #fff; overflow: hidden; flex-shrink: 0; }
.edit-icon-img { width: 100%; height: 100%; object-fit: cover; }
.edit-icon-btn { padding: 6px 14px; border: 1px solid #d1d5db; border-radius: 8px; background: #fff; font-size: 12px; color: #374151; cursor: pointer; }
.edit-screenshots { display: flex; flex-wrap: wrap; gap: 8px; }
.edit-screenshot-item { width: 64px; height: 64px; border-radius: 8px; overflow: hidden; position: relative; flex-shrink: 0; background: #f3f4f6; }
.edit-screenshot-img { width: 100%; height: 100%; object-fit: cover; }
.edit-screenshot-del { position: absolute; top: 2px; right: 2px; width: 18px; height: 18px; border-radius: 50%; background: rgba(0,0,0,0.5); border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; padding: 0; }
.edit-screenshot-add { display: flex; align-items: center; justify-content: center; border: 2px dashed #d1d5db; cursor: pointer; background: #f9fafb; }
.edit-official-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.ot-check-label { display: flex; align-items: center; cursor: pointer; }
.ot-checkbox { display: none; }
.ot-checkbox:checked + .ot-chip { outline: 2px solid #00BFA5; outline-offset: 1px; }
.ot-chip { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 500; transition: outline 0.15s; }
.edit-switch-group { display: flex; flex-direction: column; gap: 8px; }
.switch-label { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: #374151; }
.toggle-input { width: 16px; height: 16px; accent-color: #00BFA5; cursor: pointer; }
.toggle-text { user-select: none; }
.edit-price-type { display: flex; gap: 8px; }
.edit-price-btn { flex: 1; padding: 8px 0; border: 1px solid #e5e7eb; border-radius: 8px; background: #f9fafb; color: #6b7280; font-size: 13px; cursor: pointer; transition: all 0.2s; }
.edit-price-btn.active { background: #e6f9f6; border-color: #00BFA5; color: #00BFA5; font-weight: 600; }
</style>
