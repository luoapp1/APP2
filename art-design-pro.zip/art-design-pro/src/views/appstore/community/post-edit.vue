<template>
  <div class="post-edit-page">
    <!-- ==================== TOP NAVBAR ==================== -->
    <div class="navbar">
      <button class="nav-btn" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="nav-title">{{ isEditMode ? '编辑帖子' : '发布帖子' }}</span>
      <div class="nav-actions">
        <button
          class="submit-btn"
          :disabled="submitting || !form.title.trim() || !formContent.trim()"
          @click="handlePublish"
        >{{ submitting ? '发布中...' : '发布' }}</button>
      </div>
    </div>

    <!-- ==================== SCROLLABLE CONTENT ==================== -->
    <div class="content-scroll">
      <!-- Title Input -->
      <div class="title-area">
        <input
          v-model="form.title"
          type="text"
          maxlength="100"
          placeholder="输入一个吸引人的标题..."
          class="title-input"
        />
      </div>

      <!-- Section + Tags Row + Count -->
      <div class="meta-row">
        <div class="meta-row-left">
          <button class="section-trigger" @click="showSectionPicker = true">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            <span class="section-trigger-text">{{ selectedSectionName || '选择板块' }}</span>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          <button class="tag-trigger" @click="showTagPicker = true">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7" stroke-width="2.5" stroke-linecap="round"/></svg>
            <span class="tag-trigger-text">{{ subSectionTags.length > 0 ? `${subSectionTags.length} 个标签` : '添加标签' }}</span>
          </button>
        </div>
        <div class="title-count">{{ form.title.length }}/100</div>
      </div>

      <!-- Selected Tags Display -->
      <div v-if="subSectionTags.length > 0" class="tags-display">
        <span
          v-for="(tag, idx) in subSectionTags"
          :key="idx"
          class="tag-chip"
        >
          #{{ tag }}
          <button class="tag-chip-remove" @click="removeSubTag(idx)">&times;</button>
        </span>
      </div>

      <div class="divider"/>

      <!-- ==================== CONTENT BLOCKS ==================== -->
      <div class="blocks-area">
        <template v-for="(block, idx) in contentBlocks" :key="idx">
          <!-- Text Block -->
          <div v-if="block.type === 'text'" class="block-text" :class="{ 'block-active': activeBlockIdx === idx }">
            <textarea
              v-model="block.value"
              rows="1"
              placeholder="在这里写下你的内容..."
              class="text-editor"
              @input="onBlockResize($event)"
              @focus="activeBlockIdx = idx"
              @blur="activeBlockIdx = -1"
            />
          </div>

          <!-- Image Block -->
          <div v-else-if="block.type === 'image'" class="block-images">
            <div
              v-for="(img, iIdx) in block.images"
              :key="iIdx"
              class="image-item"
            >
              <img :src="img" class="image-thumb" />
              <button class="image-remove" @click="removeBlockImage(idx, iIdx)">&times;</button>
            </div>
            <label
              v-if="block.images && block.images.length < 9"
              class="image-add"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
              <input type="file" accept="image/*" multiple class="hidden" @change="(e: any) => handleBlockImageUpload(e, idx)" />
            </label>
          </div>

          <!-- Attachment Block -->
          <div
            v-else-if="block.type === 'attachment'"
            class="block-attachment"
            @click="openAttachmentModal(idx)"
          >
            <button class="attachment-remove" @click.stop="removeBlock(idx)">&times;</button>
            <div class="attachment-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
            </div>
            <div class="attachment-info">
              <div class="attachment-title">{{ block.title || '附件' }}</div>
              <div class="attachment-desc">{{ block.desc || '点击设置' }}</div>
            </div>
            <div class="attachment-meta">
              <span class="attachment-price-tag">{{ priceTypeLabelFull(block.priceType || 'free', block.coin || 0) }}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </div>
          <!-- Link Block -->
          <div
            v-else-if="block.type === 'link'"
            class="block-link"
          >
            <button class="block-link-remove" @click="removeBlock(idx)">&times;</button>
            <div class="block-link-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
            </div>
            <div class="block-link-info">
              <input
                v-model="block.title"
                type="text"
                placeholder="链接标题"
                class="block-link-title-input"
              />
              <input
                v-model="block.url"
                type="text"
                placeholder="粘贴链接地址"
                class="block-link-url-input"
              />
            </div>
          </div>

          <!-- App Block -->
          <div
            v-else-if="block.type === 'app'"
            class="block-app"
          >
            <button class="app-remove" @click.stop="removeBlock(idx)">&times;</button>
            <div class="app-card">
              <div class="app-icon-wrap" :style="{ background: block.appIcon ? undefined : avatarColor(block.appName || 'a') }">
                <img v-if="block.appIcon" :src="block.appIcon" class="app-icon-img" />
                <span v-else class="app-icon-letter">{{ block.appName?.charAt(0) || 'A' }}</span>
              </div>
              <div class="app-info">
                <div class="app-name">{{ block.appName || '应用' }}</div>
                <div class="app-desc">{{ block.desc || '' }}</div>
              </div>
              <div class="app-free-tag" v-if="!block.coinCount || block.coinCount === 0">免费</div>
              <div class="app-price-tag" v-else>{{ block.coinCount }}硬币</div>
            </div>
          </div>
        </template>

        <!-- ==================== APP SELECTOR (INLINE) ==================== -->
        <div v-if="showAppSelector" class="app-selector-area">
          <div class="app-selector-header">
            <span class="app-selector-title">选择应用</span>
            <button class="app-selector-close" @click="showAppSelector = false">&times;</button>
          </div>
          <div class="app-selector-tabs">
            <button
              class="app-tab"
              :class="{ 'app-tab-active': appSourceTab === 'submission' }"
              @click="switchAppTab('submission')"
            >我的投稿</button>
            <button
              class="app-tab"
              :class="{ 'app-tab-active': appSourceTab === 'store' }"
              @click="switchAppTab('store')"
            >本站应用</button>
          </div>
          <div class="app-selector-search">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            <input
              v-model="appSearchQuery"
              type="text"
              :placeholder="appSourceTab === 'submission' ? '搜索我的投稿...' : '搜索本站应用...'"
              class="app-search-input"
              @input="filterApps"
            />
          </div>
          <div v-if="appLoading" class="app-selector-loading">加载中...</div>
          <div v-else-if="filteredAppList.length === 0" class="app-selector-empty">暂无结果</div>
          <div v-else class="app-selector-list">
            <button
              v-for="app in filteredAppList"
              :key="app.id"
              class="app-selector-item"
              @click="selectApp(app)"
            >
              <div class="app-selector-icon" :style="{ background: avatarColor(app.name) }">
                <img v-if="app.icon" :src="app.icon" class="app-selector-icon-img" />
                <span v-else class="app-selector-icon-letter">{{ app.name?.charAt(0) || 'A' }}</span>
              </div>
              <div class="app-selector-info">
                <div class="app-selector-name">{{ app.name }}</div>
                <div class="app-selector-meta">{{ app.category || '' }} · {{ app.version || '' }}</div>
              </div>
              <div class="app-selector-price" v-if="!app.coinCount || app.coinCount === 0">免费</div>
              <div class="app-selector-price app-selector-price-coin" v-else>{{ app.coinCount }}硬币</div>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- ==================== BOTTOM TOOLBAR ==================== -->
    <div class="toolbar">
      <button class="toolbar-btn" @click="insertEmoji" title="表情">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9" stroke-width="2.5" stroke-linecap="round"/><line x1="15" y1="9" x2="15.01" y2="9" stroke-width="2.5" stroke-linecap="round"/></svg>
      </button>
      <label class="toolbar-btn" title="图片">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="4" width="20" height="16" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M2 16l5-4 3 2 2-3 5 5"/></svg>
        <input type="file" accept="image/*" multiple class="hidden" @change="handleGlobalImageUpload" />
      </label>
      <button class="toolbar-btn" @click="addAttachmentBlock" title="附件">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>
      </button>
      <button class="toolbar-btn" @click="addLinkBlock" title="链接">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
      </button>
      <button class="toolbar-btn" @click="toggleAppSelector" title="应用">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="3"/></svg>
      </button>
    </div>

    <!-- ==================== SECTION PICKER MODAL ==================== -->
    <Teleport to="body">
      <Transition name="modal-fade">
        <div
          v-if="showSectionPicker"
          class="modal-overlay"
          @click.self="showSectionPicker = false"
        >
          <div class="picker-panel">
            <div class="picker-header">
              <span class="picker-title">选择板块</span>
              <button class="picker-close" @click="showSectionPicker = false">&times;</button>
            </div>
            <div class="picker-body">
              <button
                v-for="sec in sections"
                :key="sec.id"
                class="picker-item"
                :class="{ 'picker-item-active': form.sectionId === sec.id }"
                @click="selectSection(sec)"
              >
                <div class="picker-item-left">
                  <div class="picker-item-icon" :style="{ background: avatarColor(sec.name) }">
                    {{ sec.name?.charAt(0) || '?' }}
                  </div>
                  <div class="picker-item-info">
                    <div class="picker-item-name">{{ sec.name }}</div>
                    <div class="picker-item-desc">{{ sec.description || '暂无描述' }}</div>
                  </div>
                </div>
                <div v-if="form.sectionId === sec.id" class="picker-check">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
              </button>
            </div>
            <div class="picker-footer">
              <button class="picker-confirm" @click="showSectionPicker = false">确定</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- ==================== TAG PICKER MODAL ==================== -->
    <Teleport to="body">
      <Transition name="modal-fade">
        <div
          v-if="showTagPicker"
          class="modal-overlay"
          @click.self="showTagPicker = false"
        >
          <div class="picker-panel">
            <div class="picker-header">
              <span class="picker-title">添加标签</span>
              <button class="picker-close" @click="showTagPicker = false">&times;</button>
            </div>
            <div class="picker-body">
              <div class="tag-input-row">
                <input
                  v-model="tagPickerInput"
                  type="text"
                  placeholder="输入自定义标签，回车添加"
                  class="tag-picker-input"
                  @keydown.enter.prevent="addTagFromPicker"
                />
                <button class="tag-picker-add" @click="addTagFromPicker" :disabled="!tagPickerInput.trim()">添加</button>
              </div>
              <div class="tag-picker-presets-label">常用标签</div>
              <div class="tag-picker-presets">
                <button
                  v-for="tag in presetTags"
                  :key="tag"
                  class="tag-preset-chip"
                  :class="{ 'tag-preset-used': subSectionTags.includes(tag) }"
                  :disabled="subSectionTags.includes(tag)"
                  @click="addPresetTag(tag)"
                >{{ tag }}</button>
              </div>
            </div>
            <div class="picker-footer">
              <button class="picker-confirm" @click="showTagPicker = false">完成</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- ==================== ATTACHMENT SETTINGS MODAL ==================== -->
    <Teleport to="body">
      <Transition name="modal-fade">
        <div
          v-if="attachmentModalVisible"
          class="modal-overlay"
          @click.self="closeAttachmentModal"
        >
          <div class="picker-panel">
            <div class="picker-header">
              <span class="picker-title">附件设置</span>
              <button class="picker-close" @click="closeAttachmentModal">&times;</button>
            </div>
            <div class="picker-body">
              <div class="form-group">
                <label class="form-label">附件标题</label>
                <input v-model="editingAttachment.title" placeholder="输入附件标题" class="form-input" />
              </div>
              <div class="form-group">
                <label class="form-label">描述</label>
                <input v-model="editingAttachment.desc" placeholder="附件描述（选填）" class="form-input" />
              </div>
              <div class="form-group">
                <label class="form-label">资源链接</label>
                <input v-model="editingAttachment.url" placeholder="输入链接地址" class="form-input" />
              </div>
              <div class="form-group">
                <label class="form-label">提取码（选填）</label>
                <input v-model="editingAttachment.extractCode" placeholder="选填" class="form-input" />
              </div>
              <div class="form-group">
                <label class="form-label">价格类型</label>
                <div class="price-row">
                  <button
                    v-for="pt in attachmentPriceTypes"
                    :key="pt.value"
                    class="price-btn"
                    :class="{ 'price-btn-active': editingAttachment.priceType === pt.value }"
                    @click="editingAttachment.priceType = pt.value"
                  >{{ pt.label }}</button>
                </div>
              </div>
              <div v-if="editingAttachment.priceType !== 'free'" class="form-group">
                <label class="form-label">{{ editingAttachment.priceType === 'balance' ? '余额数量' : '积分数量' }}</label>
                <input v-model.number="editingAttachment.coin" type="number" min="0" placeholder="0" class="form-input" />
              </div>
            </div>
            <div class="picker-footer">
              <button class="picker-confirm" @click="saveAttachment">保存</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import {
  fetchCommunitySections,
  fetchCommunitySection,
  fetchCommunityPost,
  fetchModerators,
  createCommunityPost,
  updateCommunityPost
} from '@/api/community'
import { fetchSubmissionList } from '@/api/submission'
import { fetchAppList } from '@/api/appstore'
import type { CommunitySection } from '@/api/community'
import type { SubmissionItem } from '@/api/submission'
import type { AppItem } from '@/api/appstore'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const editPostId = computed(() => {
  const id = route.params.id
  return id ? Number(id) : 0
})
const isEditMode = computed(() => editPostId.value > 0)

const sections = ref<CommunitySection[]>([])
const sectionInfo = ref<any>(null)
const submitting = ref(false)
const activeBlockIdx = ref(-1)
const showSectionPicker = ref(false)
const showTagPicker = ref(false)
const showAppSelector = ref(false)
const appSourceTab = ref<'submission' | 'store'>('submission')
const appList = ref<(SubmissionItem | AppItem)[]>([])
const filteredAppList = ref<(SubmissionItem | AppItem)[]>([])
const appSearchQuery = ref('')
const appLoading = ref(false)
const tagPickerInput = ref('')

const presetTags = ['闲聊', '新人报道', '技术问答', '资源分享', '作品展示', '问题求助', '经验分享', '其他']

const subSectionTags = ref<string[]>([])
const priceTypes = [
  { value: 'free', label: '免费' },
  { value: 'balance', label: '余额' },
  { value: 'points', label: '积分' }
]
const attachmentPriceTypes = [
  { value: 'free', label: '免费' },
  { value: 'balance', label: '余额' },
  { value: 'points', label: '积分' }
]

const selectedSectionName = computed(() => {
  if (!form.sectionId) return ''
  return sections.value.find(s => s.id === form.sectionId)?.name || ''
})

function priceTypeLabel(type: string) {
  const pt = attachmentPriceTypes.find(p => p.value === type)
  return pt?.label || '免费'
}

function priceTypeLabelFull(type: string, amount: number) {
  if (type === 'free' || !type) return '免费'
  const pt = attachmentPriceTypes.find(p => p.value === type)
  if (amount && amount > 0) return `${amount}${pt?.label || ''}`
  return pt?.label || '免费'
}

function addTagFromPicker() {
  const v = tagPickerInput.value.trim()
  if (v && !subSectionTags.value.includes(v)) {
    subSectionTags.value.push(v)
  }
  tagPickerInput.value = ''
}

function addPresetTag(tag: string) {
  if (!subSectionTags.value.includes(tag)) {
    subSectionTags.value.push(tag)
  }
}

function removeSubTag(idx: number) {
  subSectionTags.value.splice(idx, 1)
}

function selectSection(sec: CommunitySection) {
  form.sectionId = sec.id
}

const form = reactive({
  sectionId: 0,
  title: '',
  tags: [] as string[]
})

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  extractCode?: string
  priceType?: string
  coin?: number
  coinCount?: number
  appId?: number
  appName?: string
  appIcon?: string
  fileName?: string
}

const contentBlocks = ref<ContentBlock[]>([
  { type: 'text', value: '' }
])

const attachmentModalVisible = ref(false)
const editingBlockIdx = ref(-1)
const editingAttachment = reactive({
  title: '',
  desc: '',
  url: '',
  extractCode: '',
  priceType: 'free',
  coin: 0
})

function onBlockResize(e: Event) {
  const el = e.target as HTMLTextAreaElement
  el.style.height = 'auto'
  el.style.height = el.scrollHeight + 'px'
}

function insertEmoji() {
  const block = ensureTextBlockAtEnd()
  block.value = (block.value || '') + ' :) '
}

function insertTopicTag() {
  const tag = prompt('输入话题标签')
  if (!tag || !tag.trim()) return
  form.tags.push(tag.trim())
  const block = ensureTextBlockAtEnd()
  block.value = (block.value || '') + ' #' + tag.trim() + '# '
}

function addAttachmentBlock() {
  contentBlocks.value.push({
    type: 'attachment',
    title: '',
    desc: '',
    url: '',
    extractCode: '',
    priceType: 'free',
    coin: 0
  })
  contentBlocks.value.push({ type: 'text', value: '' })
}

function addLinkBlock() {
  contentBlocks.value.push({
    type: 'link',
    title: '',
    url: ''
  })
  contentBlocks.value.push({ type: 'text', value: '' })
}

async function toggleAppSelector() {
  showAppSelector.value = !showAppSelector.value
  appSearchQuery.value = ''
  filteredAppList.value = []
  appList.value = []
}

async function switchAppTab(tab: 'submission' | 'store') {
  appSourceTab.value = tab
  appSearchQuery.value = ''
  filteredAppList.value = []
  appList.value = []
}

async function loadAppsBySearch() {
  const q = appSearchQuery.value.trim()
  if (!q) {
    filteredAppList.value = []
    return
  }
  appLoading.value = true
  try {
    if (appSourceTab.value === 'submission') {
      const res: any = await fetchSubmissionList({ page: 1, pageSize: 200, keyword: q })
      const list = Array.isArray(res) ? res : (res.list || res.data || [])
      appList.value = list
      filteredAppList.value = list.filter((app: any) =>
        app.name.toLowerCase().includes(q.toLowerCase()) ||
        (app.category && app.category.toLowerCase().includes(q.toLowerCase())) ||
        (app.packageName && app.packageName.toLowerCase().includes(q.toLowerCase()))
      )
    } else {
      const res: any = await fetchAppList({ page: 1, pageSize: 200 })
      const list = Array.isArray(res) ? res : (res.list || res.data || [])
      appList.value = list
      filteredAppList.value = list.filter((app: any) =>
        app.name.toLowerCase().includes(q.toLowerCase()) ||
        (app.category && app.category.toLowerCase().includes(q.toLowerCase())) ||
        (app.packageName && app.packageName.toLowerCase().includes(q.toLowerCase()))
      )
    }
  } catch {} finally {
    appLoading.value = false
  }
}

function filterApps() {
  loadAppsBySearch()
}

function selectApp(app: any) {
  contentBlocks.value.push({
    type: 'app',
    appId: app.id,
    appName: app.name,
    appIcon: app.icon,
    desc: app.description || app.category || '',
    coinCount: app.coinCount || 0
  })
  contentBlocks.value.push({ type: 'text', value: '' })
  showAppSelector.value = false
  appSearchQuery.value = ''
  filteredAppList.value = []
}

function removeBlock(idx: number) {
  contentBlocks.value.splice(idx, 1)
  if (contentBlocks.value.length === 0) {
    contentBlocks.value.push({ type: 'text', value: '' })
  }
  mergeConsecutiveTextBlocks()
}

function removeBlockImage(blockIdx: number, imgIdx: number) {
  const block = contentBlocks.value[blockIdx]
  if (block && block.images) {
    block.images.splice(imgIdx, 1)
    if (block.images.length === 0) {
      contentBlocks.value.splice(blockIdx, 1)
      if (contentBlocks.value.length === 0) {
        contentBlocks.value.push({ type: 'text', value: '' })
      }
      mergeConsecutiveTextBlocks()
    }
  }
}

function handleBlockImageUpload(e: Event, blockIdx: number) {
  const files = (e.target as HTMLInputElement).files
  if (!files) return
  const block = contentBlocks.value[blockIdx]
  if (!block || !block.images) return
  const remaining = 9 - block.images.length
  const toUpload = Array.from(files).slice(0, remaining)
  toUpload.forEach(file => {
    const reader = new FileReader()
    reader.onload = () => {
      if (reader.result && block.images) {
        block.images.push(reader.result as string)
      }
    }
    reader.readAsDataURL(file)
  })
  ;(e.target as HTMLInputElement).value = ''
}

function handleGlobalImageUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  const dataUrls: string[] = []
  const toUpload = Array.from(files)
  let loaded = 0

  toUpload.forEach(file => {
    const reader = new FileReader()
    reader.onload = () => {
      loaded++
      if (reader.result) dataUrls.push(reader.result as string)
      if (loaded === toUpload.length) {
        contentBlocks.value.push({ type: 'image', images: dataUrls })
        contentBlocks.value.push({ type: 'text', value: '' })
      }
    }
    reader.readAsDataURL(file)
  })
  ;(e.target as HTMLInputElement).value = ''
}

function ensureTextBlockAtEnd(): ContentBlock {
  const last = contentBlocks.value[contentBlocks.value.length - 1]
  if (last && last.type === 'text') return last
  const newBlock: ContentBlock = { type: 'text', value: '' }
  contentBlocks.value.push(newBlock)
  return newBlock
}

function mergeConsecutiveTextBlocks() {
  for (let i = contentBlocks.value.length - 2; i >= 0; i--) {
    const a = contentBlocks.value[i]
    const b = contentBlocks.value[i + 1]
    if (a && b && a.type === 'text' && b.type === 'text') {
      a.value = (a.value || '') + '\n' + (b.value || '')
      contentBlocks.value.splice(i + 1, 1)
    }
  }
}

function openAttachmentModal(idx: number) {
  editingBlockIdx.value = idx
  const block = contentBlocks.value[idx]
  if (block && block.type === 'attachment') {
    editingAttachment.title = block.title || ''
    editingAttachment.desc = block.desc || ''
    editingAttachment.url = block.url || ''
    editingAttachment.extractCode = block.extractCode || ''
    editingAttachment.priceType = block.priceType || 'balance'
    editingAttachment.coin = block.coin || 0
  }
  attachmentModalVisible.value = true
}

function closeAttachmentModal() {
  attachmentModalVisible.value = false
}

function saveAttachment() {
  const idx = editingBlockIdx.value
  const block = contentBlocks.value[idx]
  if (block && block.type === 'attachment') {
    block.title = editingAttachment.title
    block.desc = editingAttachment.desc
    block.url = editingAttachment.url
    block.extractCode = editingAttachment.extractCode
    block.priceType = editingAttachment.priceType
    block.coin = editingAttachment.coin
  }
  attachmentModalVisible.value = false
}

const formContent = computed(() => {
  return contentBlocks.value
    .filter(b => b.type === 'text')
    .map(b => b.value || '')
    .join('\n')
})

const allImages = computed(() => {
  const imgs: string[] = []
  contentBlocks.value.forEach(b => {
    if (b.type === 'image' && b.images) imgs.push(...b.images)
  })
  return imgs
})

const avatarPalette = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#84CC16','#E11D48','#0EA5E9','#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name||'').length; i++) hash = name.charCodeAt(i) + ((hash<<5)-hash)
  return avatarPalette[Math.abs(hash)%avatarPalette.length]
}

async function loadSections() {
  try {
    const res: any = await fetchCommunitySections()
    sections.value = Array.isArray(res) ? res : (res.list || [])
  } catch {}
}

async function loadSectionInfo() {
  const sectionIdFromQuery = route.query.sectionId || route.params.sectionId
  if (!sectionIdFromQuery) return
  try {
    const r: any = await fetchCommunitySection(Number(sectionIdFromQuery))
    sectionInfo.value = r.data || r
    const modRes: any = await fetchModerators(Number(sectionIdFromQuery))
  } catch {}
}

async function loadExistingPost() {
  if (!editPostId.value) return
  try {
    const res: any = await fetchCommunityPost(editPostId.value, getUserId())
    const post = res.data || res
    if (!post) return
    form.sectionId = post.sectionId || 0
    form.title = post.title || ''

    if (post.content) {
      try {
        const parsed = JSON.parse(post.content)
        if (Array.isArray(parsed) && parsed.length > 0) {
          contentBlocks.value = parsed
          return
        }
      } catch {}
      contentBlocks.value = [{ type: 'text', value: post.content }]
    }
    if (post.images && post.images.length > 0) {
      contentBlocks.value.push({ type: 'image', images: post.images })
      contentBlocks.value.push({ type: 'text', value: '' })
    }
    form.tags = post.tags || []
  } catch {}
}

function getUserId(): number {
  return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0
}

async function buildPayload(): Promise<Record<string, unknown>> {
  return {
    sectionId: form.sectionId,
    title: form.title.trim(),
    content: JSON.stringify(contentBlocks.value),
    images: allImages.value,
    tags: subSectionTags.value.concat(form.tags)
  }
}

async function handlePublish() {
  if (!form.title.trim() || !formContent.value.trim()) return
  submitting.value = true
  try {
    const payload = await buildPayload()
    if (isEditMode.value) {
      await updateCommunityPost(editPostId.value, payload)
    } else {
      await createCommunityPost(payload)
    }
    router.back()
  } catch {} finally {
    submitting.value = false
  }
}

onMounted(async () => {
  await loadSections()
  if (isEditMode.value) {
    await loadExistingPost()
  } else {
    const sectionIdFromQuery = route.query.sectionId
    if (sectionIdFromQuery) {
      form.sectionId = Number(sectionIdFromQuery) || 0
    }
  }
  loadSectionInfo()
})
</script>

<style scoped>
/* ==================== BASE ==================== */
.post-edit-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  height: 100dvh;
  background: #fff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* ==================== NAVBAR ==================== */
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  padding-top: calc(12px + env(safe-area-inset-top, 0px));
  background: rgba(255,255,255,0.92);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid #f0f0f0;
  flex-shrink: 0;
  z-index: 10;
}

.nav-btn {
  width: 36px;
  height: 36px;
  border-radius: 12px;
  background: #f5f5f5;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #333;
  cursor: pointer;
  transition: all 0.15s;
  flex-shrink: 0;
}
.nav-btn:active {
  background: #e8e8e8;
  transform: scale(0.95);
}

.nav-title {
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
  letter-spacing: -0.3px;
}

.nav-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.submit-btn {
  border: none;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 600;
  color: #fff;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(99,102,241,0.3);
}
.submit-btn:active:not(:disabled) {
  transform: scale(0.96);
}
.submit-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: none;
}

/* ==================== CONTENT ==================== */
.content-scroll {
  flex: 1;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.title-area {
  padding: 16px 16px 0;
}

.title-input {
  width: 100%;
  border: none;
  outline: none;
  font-size: 20px;
  font-weight: 700;
  color: #1a1a1a;
  letter-spacing: -0.3px;
  line-height: 1.4;
  padding: 0;
}
.title-input::placeholder {
  color: #ccc;
  font-weight: 500;
}

.title-count {
  font-size: 11px;
  color: #bbb;
  margin-top: 4px;
}

/* ==================== META ROW ==================== */
.meta-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 16px 0;
}

.meta-row-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.title-count {
  font-size: 11px;
  color: #c0c0c0;
  font-weight: 500;
  flex-shrink: 0;
}

.section-trigger,
.tag-trigger {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 11px;
  border-radius: 18px;
  border: 1px solid #eee;
  background: #fafafa;
  color: #666;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s;
  white-space: nowrap;
}
.section-trigger:active,
.tag-trigger:active {
  background: #f0f0f0;
  border-color: #ddd;
  transform: scale(0.97);
}
.section-trigger-text {
  color: #333;
  font-weight: 600;
}
.tag-trigger-text {
  color: #666;
}

/* ==================== TAGS DISPLAY ==================== */
.tags-display {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 12px 16px 0;
}

.tag-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 12px;
  border-radius: 16px;
  font-size: 12px;
  font-weight: 600;
  color: #6366f1;
  background: rgba(99,102,241,0.08);
}

.tag-chip-remove {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: none;
  background: rgba(99,102,241,0.2);
  color: #6366f1;
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  line-height: 1;
  padding: 0;
}

.divider {
  height: 1px;
  background: #f0f0f0;
  margin: 12px 16px 0;
}

/* ==================== BLOCKS ==================== */
.blocks-area {
  padding: 16px;
}

.block-text {
  margin-bottom: 12px;
  padding: 12px;
  border-radius: 14px;
  border: 1.5px solid transparent;
  transition: all 0.2s;
}
.block-active {
  border-color: #e0e0ff;
  background: #fafaff;
}

.text-editor {
  width: 100%;
  border: none;
  outline: none;
  font-size: 16px;
  color: #222;
  line-height: 1.75;
  resize: none;
  background: transparent;
  font-family: inherit;
}
.text-editor::placeholder {
  color: #c5c5c5;
}

/* Image Block */
.block-images {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 12px;
}

.image-item {
  position: relative;
  width: 90px;
  height: 90px;
  border-radius: 14px;
  overflow: hidden;
  background: #f5f5f5;
  flex-shrink: 0;
  box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}

.image-thumb {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-remove {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  border: none;
  background: rgba(0,0,0,0.5);
  backdrop-filter: blur(4px);
  color: #fff;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  line-height: 1;
  padding: 0;
}

.image-add {
  width: 90px;
  height: 90px;
  border-radius: 14px;
  border: 2px dashed #e0e0e0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ccc;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.15s;
}
.image-add:active {
  background: #fafafa;
  border-color: #ccc;
}

/* Attachment Block */
.block-attachment {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  background: linear-gradient(135deg, #fafafa, #f5f5f5);
  border-radius: 16px;
  border: 1px solid #eee;
  cursor: pointer;
  margin-bottom: 10px;
  transition: all 0.2s;
}
.block-attachment:active {
  transform: scale(0.985);
  background: #f0f0f0;
}

.attachment-remove {
  position: absolute;
  top: 6px;
  right: 6px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: none;
  background: #e0e0e0;
  color: #999;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 1;
}

.attachment-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: linear-gradient(135deg, #818cf8, #6366f1);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}

.attachment-info {
  flex: 1;
  min-width: 0;
}

.attachment-title {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a1a;
  line-height: 1.3;
}

.attachment-desc {
  font-size: 11px;
  color: #aaa;
  margin-top: 2px;
}

.attachment-meta {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
  color: #ccc;
}

.attachment-price {
  font-size: 11px;
  color: #6366f1;
  font-weight: 600;
}

.attachment-price-tag {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 8px;
  font-weight: 600;
  color: #6366f1;
  background: rgba(99,102,241,0.08);
}

/* ==================== TOOLBAR ==================== */
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-around;
  padding: 6px 8px;
  padding-bottom: calc(6px + env(safe-area-inset-bottom, 0px));
  background: rgba(255,255,255,0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.toolbar-btn {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  border: none;
  background: transparent;
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.15s;
}
.toolbar-btn:active {
  background: #f5f5f5;
  transform: scale(0.94);
}

/* ==================== MODAL OVERLAY ==================== */
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 200;
  background: rgba(0,0,0,0.4);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  display: flex;
  align-items: flex-end;
  justify-content: center;
}

.modal-fade-enter-active,
.modal-fade-leave-active {
  transition: opacity 0.25s ease;
}
.modal-fade-enter-active .picker-panel,
.modal-fade-leave-active .picker-panel {
  transition: transform 0.3s cubic-bezier(0.32, 0.72, 0, 1);
}
.modal-fade-enter-from,
.modal-fade-leave-to {
  opacity: 0;
}
.modal-fade-enter-from .picker-panel,
.modal-fade-leave-to .picker-panel {
  transform: translateY(100%);
}

/* ==================== PICKER PANEL ==================== */
.picker-panel {
  width: 100%;
  max-width: 500px;
  max-height: 75vh;
  background: #fff;
  border-radius: 24px 24px 0 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 -4px 30px rgba(0,0,0,0.1);
}

.picker-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 10px;
  border-bottom: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.picker-title {
  font-size: 16px;
  font-weight: 700;
  color: #1a1a1a;
}

.picker-close {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  border: none;
  background: #f3f3f3;
  color: #666;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.picker-body {
  flex: 1;
  overflow-y: auto;
  padding: 4px 0;
  -webkit-overflow-scrolling: touch;
}

.picker-footer {
  padding: 10px 16px;
  padding-bottom: calc(10px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.picker-confirm {
  width: 100%;
  padding: 12px;
  border-radius: 14px;
  border: none;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  color: #fff;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

/* ==================== SECTION PICKER ITEMS ==================== */
.picker-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 10px 16px;
  border: none;
  background: transparent;
  cursor: pointer;
  transition: background 0.12s;
}
.picker-item:active {
  background: #f7f7f7;
}

.picker-item-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.picker-item-icon {
  width: 38px;
  height: 38px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  flex-shrink: 0;
}

.picker-title {
  font-size: 17px;
  font-weight: 700;
  color: #1a1a1a;
}

.picker-close {
  width: 32px;
  height: 32px;
  border-radius: 10px;
  border: none;
  background: #f3f3f3;
  color: #666;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.picker-body {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
  -webkit-overflow-scrolling: touch;
}

.picker-footer {
  padding: 12px 20px;
  padding-bottom: calc(12px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.picker-confirm {
  width: 100%;
  padding: 14px;
  border-radius: 16px;
  border: none;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}
.picker-confirm:active {
  transform: scale(0.98);
}

/* ==================== SECTION PICKER ITEMS ==================== */
.picker-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 14px 20px;
  border: none;
  background: transparent;
  cursor: pointer;
  transition: background 0.12s;
}
.picker-item:active {
  background: #f7f7f7;
}

.picker-item-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.picker-item-icon {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 18px;
  font-weight: 700;
  flex-shrink: 0;
}

.picker-item-info {
  text-align: left;
}

.picker-item-name {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a1a;
}

.picker-item-desc {
  font-size: 12px;
  color: #aaa;
  margin-top: 2px;
}

.picker-check {
  color: #6366f1;
  flex-shrink: 0;
}

/* ==================== TAG PICKER ==================== */
.tag-input-row {
  display: flex;
  gap: 8px;
  padding: 8px 16px 4px;
}

.tag-picker-input {
  flex: 1;
  padding: 8px 14px;
  border-radius: 12px;
  border: 1.5px solid #eee;
  background: #f8f8f8;
  font-size: 13px;
  color: #333;
  outline: none;
  transition: border 0.15s;
}
.tag-picker-input:focus {
  border-color: #6366f1;
  background: #fff;
}
.tag-picker-input::placeholder {
  color: #bbb;
}

.tag-picker-add {
  padding: 8px 16px;
  border-radius: 12px;
  border: none;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.15s;
}
.tag-picker-add:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.tag-picker-presets-label {
  padding: 12px 16px 6px;
  font-size: 11px;
  color: #aaa;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.tag-picker-presets {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 4px 16px 12px;
}

.tag-preset-chip {
  padding: 5px 14px;
  border-radius: 16px;
  border: 1.5px solid #eee;
  background: #fafafa;
  font-size: 12px;
  color: #555;
  cursor: pointer;
  transition: all 0.15s;
}
.tag-preset-chip:active:not(:disabled) {
  background: #f0f0f0;
  border-color: #ddd;
}
.tag-preset-chip:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.tag-preset-used {
  background: rgba(99,102,241,0.08);
  border-color: rgba(99,102,241,0.3);
  color: #6366f1;
}

/* ==================== FORM ELEMENTS ==================== */
.form-group {
  padding: 0 20px 14px;
}

.form-label {
  display: block;
  font-size: 12px;
  font-weight: 600;
  color: #999;
  margin-bottom: 6px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.form-input {
  width: 100%;
  padding: 12px 16px;
  border-radius: 14px;
  border: 1.5px solid #eee;
  background: #f8f8f8;
  font-size: 14px;
  color: #333;
  outline: none;
  transition: all 0.15s;
  box-sizing: border-box;
}
.form-input:focus {
  border-color: #6366f1;
  background: #fff;
}
.form-input::placeholder {
  color: #bbb;
}

.price-row {
  display: flex;
  gap: 8px;
}

.price-btn {
  flex: 1;
  padding: 10px;
  border-radius: 14px;
  border: 1.5px solid #eee;
  background: #f8f8f8;
  font-size: 13px;
  font-weight: 600;
  color: #888;
  cursor: pointer;
  transition: all 0.15s;
}
.price-btn-active {
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  color: #fff;
  border-color: transparent;
  box-shadow: 0 2px 10px rgba(99,102,241,0.3);
}
.price-btn:active {
  transform: scale(0.97);
}

/* ==================== LINK BLOCK ==================== */
.block-link {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
  border-radius: 14px;
  border: 1px solid #d1fae5;
  margin-bottom: 8px;
  position: relative;
}

.block-link-remove {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: none;
  background: rgba(16,185,129,0.15);
  color: #10b981;
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.block-link-icon {
  width: 32px;
  height: 32px;
  border-radius: 10px;
  background: linear-gradient(135deg, #34d399, #10b981);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}

.block-link-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.block-link-title-input {
  border: none;
  outline: none;
  background: transparent;
  font-size: 13px;
  font-weight: 600;
  color: #065f46;
  padding: 0;
}
.block-link-title-input::placeholder {
  color: #6ee7b7;
}

.block-link-url-input {
  border: none;
  outline: none;
  background: transparent;
  font-size: 11px;
  color: #059669;
  padding: 0;
}
.block-link-url-input::placeholder {
  color: #a7f3d0;
}

/* ==================== APP BLOCK ==================== */
.block-app {
  position: relative;
  margin-bottom: 8px;
}

.app-remove {
  position: absolute;
  top: -5px;
  right: -5px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid #fff;
  background: #f3f4f6;
  color: #999;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 1;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.app-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #fdf4ff, #faf5ff);
  border-radius: 14px;
  border: 1px solid #f0e6ff;
}

.app-icon-wrap {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
}

.app-icon-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.app-icon-letter {
  color: #fff;
  font-size: 17px;
  font-weight: 700;
}

.app-info {
  flex: 1;
  min-width: 0;
}

.app-name {
  font-size: 13px;
  font-weight: 600;
  color: #4c1d95;
  line-height: 1.3;
}

.app-desc {
  font-size: 11px;
  color: #a78bfa;
  margin-top: 1px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.app-free-tag {
  padding: 3px 8px;
  border-radius: 6px;
  background: rgba(139,92,246,0.1);
  color: #7c3aed;
  font-size: 10px;
  font-weight: 600;
  flex-shrink: 0;
}

/* ==================== APP SELECTOR ==================== */
.app-selector-area {
  border: 2px solid #f0e6ff;
  border-radius: 18px;
  background: linear-gradient(135deg, #fdf4ff, #faf5ff);
  margin-bottom: 12px;
  overflow: hidden;
}

.app-selector-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 10px;
}

.app-selector-title {
  font-size: 14px;
  font-weight: 700;
  color: #4c1d95;
}

.app-selector-close {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  border: none;
  background: rgba(139,92,246,0.1);
  color: #7c3aed;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.app-selector-loading {
  padding: 24px;
  text-align: center;
  font-size: 13px;
  color: #a78bfa;
}

.app-selector-empty {
  padding: 24px;
  text-align: center;
  font-size: 13px;
  color: #bbb;
}

.app-selector-tabs {
  display: flex;
  gap: 6px;
  padding: 4px 12px 10px;
}

.app-tab {
  flex: 1;
  padding: 8px;
  border-radius: 12px;
  border: none;
  background: rgba(139,92,246,0.06);
  color: #a78bfa;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s;
}
.app-tab-active {
  background: rgba(139,92,246,0.15);
  color: #7c3aed;
  font-weight: 600;
}
.app-tab:active {
  transform: scale(0.97);
}

.app-selector-search {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 12px 8px;
  padding: 10px 14px;
  background: rgba(139,92,246,0.06);
  border-radius: 14px;
  color: #a78bfa;
}

.app-search-input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-size: 13px;
  color: #333;
}
.app-search-input::placeholder {
  color: #c4b5fd;
}

.app-selector-list {
  padding: 4px 8px 8px;
  max-height: 280px;
  overflow-y: auto;
}

.app-selector-item {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  padding: 10px 8px;
  border: none;
  background: transparent;
  border-radius: 14px;
  cursor: pointer;
  text-align: left;
  transition: background 0.12s;
  color: #7c3aed;
}
.app-selector-item:active {
  background: rgba(139,92,246,0.08);
}

.app-selector-icon {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
}

.app-selector-icon-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.app-selector-icon-letter {
  color: #fff;
  font-size: 17px;
  font-weight: 700;
}

.app-selector-info {
  flex: 1;
  min-width: 0;
}

.app-selector-name {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a1a;
}

.app-selector-meta {
  font-size: 11px;
  color: #aaa;
  margin-top: 2px;
}

.app-selector-price {
  padding: 3px 10px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 600;
  color: #10b981;
  background: rgba(16,185,129,0.08);
  flex-shrink: 0;
}
.app-selector-price-coin {
  color: #7c3aed;
  background: rgba(139,92,246,0.08);
}

/* ==================== APP PRICE TAG ==================== */
.app-price-tag {
  padding: 3px 8px;
  border-radius: 6px;
  background: rgba(139,92,246,0.1);
  color: #7c3aed;
  font-size: 10px;
  font-weight: 600;
  flex-shrink: 0;
}
</style>
