<template>
  <div class="post-detail-page">
    <!-- ==================== TOP NAVBAR (WHITE) ==================== -->
    <div class="navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <div class="nav-author">
        <div class="nav-avatar" :style="{ background: avatarColor(post?.userName || '') }">
          {{ (post?.userName || '?')[0] }}
        </div>
        <div class="nav-author-info">
          <span class="nav-name">{{ post?.userName || '--' }}</span>
          <span class="nav-time">{{ fmtTime(post?.createTime || '') }}</span>
        </div>
      </div>
      <div class="nav-actions">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
        <svg class="nav-dots" width="20" height="20" viewBox="0 0 24 24" fill="#333" @click.stop="showMenu = !showMenu"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
      </div>
    </div>

    <!-- ==================== DROPDOWN MENU ==================== -->
    <Teleport to="body">
      <div v-if="showMenu" class="menu-overlay" @click="showMenu = false">
        <div class="menu-panel" @click.stop>
          <div class="menu-item" @click="handleShare">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/></svg>
            <span>分享</span>
          </div>
          <div v-if="(post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin())" class="menu-item" @click="goEditPost(); showMenu = false">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            <span>编辑</span>
          </div>
          <div v-if="(post as any)?.isLocked" class="menu-item menu-item-locked" @click="showMenu = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            <span>{{ userIsAdmin() ? '已锁定(管理员可管理)' : '已锁定' }}</span>
          </div>
          <template v-if="hasCommunityPermission('pin') || hasCommunityPermission('essence') || hasCommunityPermission('boost') || hasCommunityPermission('lock')">
            <div class="menu-divider" />
            <div v-if="hasCommunityPermission('pin')" class="menu-item" @click="handlePinPin(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 7h6l-4 5 2 8-7-4-7 4 2-8-4-5h6z"/></svg>
              <span>{{ post?.isPinned ? '取消置顶' : '置顶' }}</span>
            </div>
            <div v-if="hasCommunityPermission('essence')" class="menu-item" @click="handleEssence(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26"/></svg>
              <span>{{ post?.isEssence ? '取消加精' : '加精' }}</span>
            </div>
            <div v-if="hasCommunityPermission('boost')" class="menu-item" @click="handleHot(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"/></svg>
              <span>{{ post?.isHot ? '取消热帖' : '热帖' }}</span>
            </div>
            <div v-if="hasCommunityPermission('lock')" class="menu-item" @click="handleLock(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <span>{{ (post as any)?.isLocked ? '解锁' : '锁定' }}</span>
            </div>
          </template>
          <template v-if="(post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin())">
            <div class="menu-divider" />
            <div class="menu-item menu-item-danger" @click="handleDeletePost(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              <span>删除</span>
            </div>
          </template>
          <div v-if="getUserId()" class="menu-item" @click="showReportDialog = true; showMenu = false">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></svg>
            <span>举报</span>
          </div>
          <div v-if="(post as any)?.isLocked && post?.userId === getUserId() && !userIsAdmin()" class="menu-item" @click="handleRequestUnlock(); showMenu = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
            <span>申请解锁</span>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== LOADING / EMPTY ==================== -->
    <div v-if="loading" class="loading-wrap"><div class="spin"/></div>
    <div v-else-if="!post" class="empty-wrap"><span>帖子不存在或已被删除</span></div>

    <!-- ==================== CONTENT ==================== -->
    <div v-else class="content-scroll">

      <!-- ===== TITLE ===== -->
      <h1 class="post-title">
        <span class="title-badge title-badge-pin" v-if="post.isPinned">顶</span>
        <span class="title-badge title-badge-essence" v-if="post.isEssence">精</span>
        <span class="title-badge title-badge-hot" v-if="post.isHot">热</span>
        <span class="title-badge title-badge-lock" v-if="(post as any).isLocked">锁</span>
        <span>{{ post.title }}</span>
      </h1>

      <div v-if="post.status === 'pending'" class="status-bar status-pending">审核中，仅自己可见</div>
      <div v-else-if="post.status === 'rejected'" class="status-bar status-rejected">审核未通过{{ post.rejectReason ? '：' + post.rejectReason : '' }}</div>
      <div v-if="(post as any).isLocked" class="status-bar status-locked">该帖已被管理员锁定，禁止编辑和评论</div>

      <!-- ===== SOFTWARE INFO LIST (【】 format) ===== -->
      <div v-if="post.hasResource || post.content" class="info-list">
        <div class="info-row" v-if="post.title">
          <span class="info-label">【标题】</span><span class="info-value">{{ post.title }}</span>
        </div>
        <div class="info-row" v-if="post.title && post.title.includes('v')">
          <span class="info-label">【软件版本】</span><span class="info-value info-link">{{ post.title.match(/v[\d.]+/)?.[0] || '--' }}</span>
        </div>
        <div class="info-row" v-if="post.resourceType">
          <span class="info-label">【软件大小】</span><span class="info-value">{{ post.resourceType }}</span>
        </div>
        <div class="info-row" v-if="post.device">
          <span class="info-label">【测试系统】</span><span class="info-value">{{ post.device }}</span>
        </div>
      </div>

      <!-- ===== CONTENT BLOCKS ===== -->
      <template v-if="contentBlocks.length">
        <template v-for="(block, idx) in contentBlocks" :key="idx">
          <!-- Text Block -->
          <div v-if="block.type === 'text' && block.value" class="post-body">{{ block.value }}</div>

          <!-- Image Block -->
          <div v-else-if="block.type === 'image' && block.images && block.images.length" class="images-grid" :class="gridClassFor(block.images.length)">
            <div v-for="(img, i) in block.images" :key="i" class="image-item" @click="previewBlockImage(block.images!, i)">
              <img :src="img" />
            </div>
          </div>

          <!-- Attachment Block -->
          <div v-else-if="block.type === 'attachment'" class="block-attachment-card" @click="handleAttachmentClick(block)">
            <div class="bac-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
            </div>
            <div class="bac-info">
              <div class="bac-title">{{ block.title || '附件' }}</div>
              <div class="bac-desc">{{ block.desc || '' }}</div>
            </div>
            <div class="bac-price">
              <span v-if="isAttachPurchased(block.url)" class="bac-purchased">已购买</span>
              <span v-else-if="block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0" class="bac-free">免费</span>
              <span v-else class="bac-coin">{{ block.coin || 0 }}{{ block.priceType === 'points' ? '积分' : '余额' }}</span>
            </div>
          </div>

          <!-- Link Block -->
          <div v-else-if="block.type === 'link'" class="block-link-card" @click="block.url && window.open(block.url, '_blank')">
            <div class="blc-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
            </div>
            <div class="blc-info">
              <div class="blc-title">{{ block.title || '链接' }}</div>
              <div class="blc-url">{{ block.url || '' }}</div>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
          </div>

          <!-- App Block -->
          <div v-else-if="block.type === 'app'" class="block-app-card" @click="block.appId && $router.push('/appstore/browse/detail/' + block.appId)">
            <div class="bac-app-icon" :style="{ background: block.appIcon ? undefined : avatarColor(block.appName || 'a') }">
              <img v-if="block.appIcon" :src="block.appIcon" class="bac-app-img" />
              <span v-else class="bac-app-letter">{{ (block.appName || 'A')[0] }}</span>
            </div>
            <div class="bac-app-info">
              <div class="bac-app-name">{{ block.appName || '应用' }}</div>
              <div class="bac-app-desc">{{ block.desc || '' }}</div>
            </div>
            <div class="bac-app-price">
              <span v-if="!block.coinCount || block.coinCount === 0" class="bac-free">免费</span>
              <span v-else class="bac-coin">{{ block.coinCount }}余额</span>
            </div>
          </div>
        </template>
      </template>

      <!-- ===== CONTENT PERMISSION BARRIER ===== -->
      <div v-if="permBarrier" class="perm-barrier">
        <div class="perm-barrier-icon">
          <svg v-if="post.contentPermission==='paid'" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="5" y1="8" x2="5" y2="20"/><line x1="12" y1="8" x2="12" y2="20"/><line x1="19" y1="8" x2="19" y2="20"/></svg>
          <svg v-else-if="post.contentPermission==='password'" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
          <svg v-else width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
        </div>
        <div class="perm-barrier-text">{{ barrierText }}</div>
        <div class="perm-barrier-price" v-if="post.contentPermission==='paid'">
          {{ post.contentPrice || 0 }} {{ post.contentPriceType==='points'?'积分':'余额' }}
        </div>
        <input v-if="post.contentPermission==='password'" v-model="pwdInput" type="password" placeholder="请输入访问密码" class="perm-pwd-input" @keyup.enter="verifyPassword" />
        <button v-if="post.contentPermission==='paid'" class="perm-buy-btn" @click="buyContent">立即购买</button>
        <button v-if="post.contentPermission==='password'" class="perm-buy-btn" @click="verifyPassword">验证密码</button>
        <button v-if="post.contentPermission==='comment'" class="perm-buy-btn" @click="scrollToComments">发表评论解锁</button>
        <button v-if="post.contentPermission==='login'" class="perm-buy-btn" @click="$router.push('/login')">登录查看</button>
        <button v-if="post.contentPermission==='level1' || post.contentPermission==='level2'" class="perm-buy-btn" @click="$router.push('/membership')">开通会员</button>
      </div>

      <!-- fallback: plain text if no blocks parsed -->
      <div v-else-if="post.content" class="post-body">{{ post.content }}</div>

      <!-- ===== DOWNLOAD SECTION ===== -->
      <div v-if="post.hasResource" class="download-block">
        <div class="download-heading">下载地址</div>
        <div class="download-card">
          <div class="download-icon-box">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
          </div>
          <div class="download-info">
            <div class="download-desc">评论999最高爆100金币</div>
            <div class="download-hint">需要支付 {{ post.resourcePrice || 1 }}余额</div>
          </div>
          <div class="download-btn-wrap">
            <span class="download-price-tag">$ {{ post.resourcePrice || 1 }}</span>
            <button class="download-btn">{{ post.resourcePrice || 1 }}余额</button>
          </div>
        </div>
        <div v-if="post.extractCode" class="extract-row">
          <span>提取码：</span><span class="extract-val">{{ post.extractCode }}</span>
        </div>
      </div>

      <!-- ===== TAGS ===== -->
      <div class="tags-row">
        <span class="tag-pill" v-for="tag in tagsList" :key="tag">
          <span class="tag-dot" :style="{background: tagDotColor(tag)}"/>
          {{ tag }}
        </span>
      </div>

      <!-- ===== BOTTOM ACTION BAR ===== -->
      <div class="post-action-bar">
        <button class="action-btn" :class="{active: post?.isLiked}" @click="toggleLike">
          <svg width="20" height="20" viewBox="0 0 24 24" :fill="post?.isLiked ? '#ef4444' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/>
          </svg>
          <span>{{ post?.likeCount || 0 }}</span>
        </button>
        <button class="action-btn" @click="scrollToComments">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span>{{ post?.commentCount || 0 }}</span>
        </button>
        <button class="action-btn" :class="{active: post?.isFavorited}" @click="toggleFav">
          <svg width="20" height="20" viewBox="0 0 24 24" :fill="post?.isFavorited ? '#f59e0b' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
          <span>{{ post?.favoriteCount || 0 }}</span>
        </button>
        <button class="action-btn" @click="showDonateModal = true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"/><text x="12" y="16.5" text-anchor="middle" fill="currentColor" font-size="13" font-weight="bold">¥</text>
          </svg>
          <span>打赏</span>
        </button>
      </div>

    <!-- ==================== COIN LOGS MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showCoinLogs" class="donate-overlay" @click.self="showCoinLogs = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏记录</span>
            <button class="dm-close" @click="showCoinLogs = false">&times;</button>
          </div>
          <div class="coin-logs-body">
            <div v-if="coinLogs.length===0" class="coin-logs-empty">暂无打赏记录</div>
            <div v-else class="donate-item" v-for="log in coinLogs" :key="log.id">
              <div class="donate-avatar" :style="{ background: avatarColor(log.fromUserName) }">{{ (log.fromUserName||'?')[0] }}</div>
              <div class="donate-info">
                <span class="donate-name">{{ log.fromUserName }}</span>
                <span class="donate-time">{{ fmtTime(log.createTime) }}</span>
              </div>
              <div class="donate-amount">
                <span class="donate-val">{{ log.amount }}</span>
                <span class="donate-unit">{{ log.coinType === 'points' ? '积分' : '余额' }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- 附件信息弹窗 -->
    <Teleport to="body">
      <div v-if="attachInfoDialog.show" class="attach-overlay" @click.self="attachInfoDialog.show = false">
        <div class="attach-modal">
          <div class="attach-modal-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22C3D0" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
          </div>
          <h3 class="attach-modal-title">{{ attachInfoDialog.title || '附件信息' }}</h3>
          <p v-if="attachInfoDialog.desc" class="attach-modal-desc">{{ attachInfoDialog.desc }}</p>
          <div class="attach-modal-fields">
            <div v-if="attachInfoDialog.url" class="attach-field">
              <span class="attach-field-label">下载链接</span>
              <span class="attach-field-value attach-field-url">{{ attachInfoDialog.url }}</span>
            </div>
            <div v-if="attachInfoDialog.extractCode" class="attach-field">
              <span class="attach-field-label">提取码</span>
              <span class="attach-field-value attach-field-code">{{ attachInfoDialog.extractCode }}</span>
            </div>
          </div>
          <div class="attach-modal-actions">
            <button class="attach-btn attach-btn-copy" @click="navigator.clipboard?.writeText(attachInfoDialog.url);ElMessage.success('链接已复制')">复制链接</button>
            <button class="attach-btn attach-btn-close" @click="attachInfoDialog.show = false">关闭</button>
          </div>
        </div>
      </div>
    </Teleport>

      <!-- ===== COMMENTS ===== -->
      <div class="comments-section">
        <div class="cs-head">
          <span class="cs-head-title">评论 <em>{{ sortedComments.length }}</em></span>
          <div class="cs-sort">
            <button v-for="s in ['最热','最新']" :key="s" class="cs-sort-btn" :class="{on: sortBy===s}" @click="sortBy=s">{{ s }}</button>
          </div>
        </div>

        <!-- 输入栏 -->
        <div class="cs-input-row" v-if="!(post as any)?.isLocked || userIsAdmin()">
          <div class="cs-input-av" :style="{ background: avatarGrad((userStore.info as any)?.username || '我') }">
            {{ ((userStore.info as any)?.username || '我').slice(0,1) }}
          </div>
          <div class="cs-input-wrap">
            <input v-model="newCommentText" :placeholder="(post as any)?.isLocked ? '管理员评论...' : '说点什么...'" class="cs-input" @keyup.enter="submitComment" ref="commentInputEl"/>
          </div>
          <button class="cs-send" :disabled="!newCommentText.trim()" @click="submitComment">发送</button>
        </div>

        <!-- 列表 -->
        <div v-if="commentsLoading" class="cs-loading"><span class="cs-spin"/></div>
        <div v-else-if="sortedComments.length===0" class="cs-empty">
          <div class="cs-empty-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
          <p>还没有评论</p>
          <span>来说两句吧</span>
        </div>

        <div v-else class="cs-list">
          <div v-for="c in sortedComments" :key="c.id" class="cs-item" :class="{ pinned: c.isPinned }">
            <div class="cs-item-av" :style="{ background: avatarGrad(c.userName) }">
              {{ (c.userName||'?').slice(0,1) }}
            </div>
            <div class="cs-item-main">
              <div class="cs-item-meta">
                <span class="cs-item-name">{{ c.userName }}</span>
                <span v-if="c.userId === post?.userId" class="cs-item-tag">作者</span>
                <span v-if="c.isPinned" class="cs-item-tag pinned-tag">置顶</span>
                <span class="cs-item-time">{{ fmtTime(c.createTime) }}</span>
              </div>
              <div class="cs-item-body">{{ c.content }}</div>
              <div class="cs-item-acts">
                <button class="cs-act" @click="toggleReplyInput(c)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>
                  <span v-if="c.replyCount">{{ c.replyCount }}</span>
                </button>
                <button class="cs-act" :class="{on: c._isLiked}" @click="handleCommentLike(c)">
                  <svg viewBox="0 0 24 24" :fill="c._isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>
                  <span v-if="c.likeCount||c._isLiked">{{ (c.likeCount||0)+(c._isLiked?1:0)-(c._originalLiked?1:0) }}</span>
                </button>
                <button v-if="getUserId()" class="cs-act report-act" @click="handleReportComment(c)">举报</button>
                <button v-if="canPinComment(c)" class="cs-act pin-act" :class="{on: c.isPinned}" @click="handlePinComment(c)">
                  <svg viewBox="0 0 24 24" :fill="c.isPinned ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 7h6l-4 5 2 8-7-4-7 4 2-8-4-5h6z"/></svg>
                  {{ c.isPinned ? '取消' : '置顶' }}
                </button>
                <button v-if="canDeleteComment(c)" class="cs-act del" @click="handleDeleteComment(c)">删除</button>
              </div>

              <!-- 回复框 -->
              <div v-if="replyingTo===c.id" class="cs-reply-panel">
                <span class="cs-reply-to">回复 <b>{{ c.userName }}</b></span>
                <div class="cs-reply-row">
                  <input v-model="replyText" class="cs-reply-input" @keyup.enter="submitReply(c)"/>
                  <button class="cs-reply-cancel" @click="replyingTo=null;replyText=''">取消</button>
                  <button class="cs-reply-send" @click="submitReply(c)">发送</button>
                </div>
              </div>

              <!-- 子回复 -->
              <div v-if="c.replies&&c.replies.length" class="cs-sub-wrap">
                <div v-for="r in c.replies" :key="r.id" class="cs-sub-item">
                  <div class="cs-sub-item-av" :style="{ background: avatarGrad(r.userName) }">{{ (r.userName||'?').slice(0,1) }}</div>
                  <div class="cs-sub-item-main">
                    <div class="cs-sub-item-meta">
                      <span class="cs-sub-item-name">{{ r.userName }}</span>
                      <span class="cs-sub-item-time">{{ fmtTime(r.createTime) }}</span>
                    </div>
                    <div class="cs-sub-item-body">{{ r.content }}</div>
                    <div class="cs-sub-item-acts">
                      <button v-if="getUserId()" class="cs-act report-act" @click="handleReportComment(r)">举报</button>
                      <button v-if="canDeleteReply(r)" class="cs-act del" @click="handleDeleteReply(c, r)">删除</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="bottom-spacer"/>
    </div>

    <!-- ==================== DONATE MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showDonateModal" class="donate-overlay" @click.self="showDonateModal = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏作者</span>
            <button class="dm-close" @click="showDonateModal = false">&times;</button>
          </div>
          <div class="dm-body">
            <!-- Balance + Points -->
            <div class="dm-balance-row">
              <div class="dm-bal-item">
                <span class="dm-bal-label">余额</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.balance || 0 }}</span>
              </div>
              <div class="dm-bal-item">
                <span class="dm-bal-label">积分</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.points || 0 }}</span>
              </div>
            </div>
            <!-- Payment type -->
            <div class="dm-type-row">
              <span class="dm-type-label">支付方式</span>
              <div class="dm-type-tabs">
                <button class="dm-type-tab" :class="{active: donateType === 'coin'}" @click="donateType = 'coin'">余额</button>
                <button class="dm-type-tab" :class="{active: donateType === 'points'}" @click="donateType = 'points'">积分</button>
              </div>
            </div>
            <!-- Amount selector -->
            <div class="dm-amount-row">
              <span class="dm-type-label">打赏数量</span>
              <div class="dm-amount-opts">
                <button v-for="n in donateType==='coin' ? [1,5,10,50] : [10,50,100,500]" :key="n" class="dm-amt-btn" :class="{active: donateAmount===n}" @click="donateAmount=n">{{ n }}</button>
              </div>
            </div>
            <!-- Custom amount -->
            <div class="dm-custom-row">
              <input v-model.number="donateAmount" type="number" min="1" class="dm-custom-input" placeholder="自定义数量"/>
            </div>
          </div>
          <div class="dm-footer">
            <button class="dm-cancel" @click="showDonateModal = false">取消</button>
            <button class="dm-confirm" :disabled="donating || donateAmount < 1" @click="doDonate">{{ donating ? '打赏中...' : '确认打赏 ' + donateAmount + (donateType==='points'?'积分':'余额') }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== REPORT DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showReportDialog" class="donate-overlay" @click.self="showReportDialog = false">
        <div class="report-dialog">
          <div class="report-header">
            <span>举报{{ reportTarget === 'comment' ? '评论' : '帖子' }}</span>
            <button class="report-close" @click="showReportDialog = false">&times;</button>
          </div>
          <div class="report-body">
            <p class="report-label">请选择举报原因</p>
            <div class="report-types">
              <label v-for="r in reportTypes" :key="r" class="report-type-item" :class="{ active: reportReason === r }">
                <input type="radio" :value="r" v-model="reportReason" />
                <span>{{ r }}</span>
              </label>
            </div>
            <div class="report-detail-row">
              <textarea v-model="reportDetail" class="report-textarea" placeholder="补充详细描述(选填)" maxlength="200"></textarea>
            </div>
          </div>
          <div class="report-footer">
            <button class="report-cancel" @click="showReportDialog = false">取消</button>
            <button class="report-confirm" :disabled="reporting || !reportReason" @click="doReport">{{ reporting ? '提交中...' : '提交举报' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== IMAGE PREVIEW ==================== -->
    <Teleport to="body">
      <div v-if="previewVisible" class="img-over" @click="closePreview">
        <span class="img-over-close" @click="closePreview">&times;</span>
        <span class="img-over-idx">{{ previewIndex+1 }}/{{ previewImages.length }}</span>
        <img v-if="previewImages[previewIndex]" :src="previewImages[previewIndex]" class="img-over-src"/>
        <button class="img-over-prev" @click.stop="prevImage">&lsaquo;</button>
        <button class="img-over-next" @click.stop="nextImage">&rsaquo;</button>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/store/modules/user'
import { useMenuStore } from '@/store/modules/menu'
import { fetchCommunityPost, likePost, favoritePost, sendCoin, fetchCoinLogs, fetchComments, postComment, deleteComment, pinComment, pinPost, essencePost, hotPost, lockPost, reportPost, reportComment, requestUnlock } from '@/api/community'
import type { CommunityPost, CommunityComment } from '@/api/community'

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  extractCode?: string
  priceType?: string
  coin?: number
  coinCount?: number
  appId?: number
  appName?: string
  appIcon?: string
  fileName?: string
}

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()
const { menuList } = storeToRefs(menuStore)
const postId = computed(() => Number(route.params.id) || 0)

const post = ref<CommunityPost | null>(null)
const loading = ref(true)
const comments = ref<(CommunityComment & { _isLiked?: boolean; _originalLiked?: boolean })[]>([])
const commentsLoading = ref(false)
const replyingTo = ref<number | null>(null)
const replyText = ref('')
const newCommentText = ref('')
const commentInputEl = ref<HTMLInputElement | null>(null)
const previewVisible = ref(false)
const previewIndex = ref(0)
const previewImages = ref<string[]>([])
const sortBy = ref('最热')
const sortedComments = computed(() => {
  const list = [...comments.value]
  if (sortBy.value === '最新') {
    list.sort((a, b) => new Date(b.createTime).getTime() - new Date(a.createTime).getTime())
  } else {
    list.sort((a, b) => (b.likeCount + b.replyCount) - (a.likeCount + a.replyCount))
  }
  list.sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0))
  return list
})
const showDonateModal = ref(false)
const donateAmount = ref(1)
const donateType = ref('coin')
const donating = ref(false)
const pwdInput = ref('')
const permPassed = ref(false)
const permBarrier = computed(() => {
  if (!post.value) return false
  const cp = post.value.contentPermission
  if (!cp || cp === 'public') return false
  const isAuthor = (post.value as any).userId === getUserId()
  if (isAuthor) return false
  if (permPassed.value && (cp === 'password')) return false
  return true
})
const barrierText = computed(() => {
  const cp = post.value?.contentPermission
  const map: Record<string, string> = {
    paid: '此内容需要付费后查看',
    password: '此内容需要密码访问' + (post.value?.accessPasswordTips ? ' (提示: ' + post.value.accessPasswordTips + ')' : ''),
    login: '请登录后查看',
    comment: '评论后即可查看内容',
    level1: '一级会员及以上可查看',
    level2: '二级会员及以上可查看'
  }
  return map[cp || ''] || '内容受限'
})

async function buyContent() {
  try {
    await request.post({ url: `/api/content/purchase/post/${postId.value}` })
    ElMessage.success('购买成功')
    await loadPost()
  } catch (e: any) { ElMessage.error(e?.msg || '购买失败') }
}
async function verifyPassword() {
  try {
    const r: any = await request.post({ url: `/api/content/verify-password/post/${postId.value}`, data: { password: pwdInput.value } })
    if (r.data?.valid) { permPassed.value = true; pwdInput.value = '' }
    else ElMessage.error('密码错误')
  } catch { ElMessage.error('验证失败') }
}

const showReportDialog = ref(false)
const reportTarget = ref<'post' | 'comment'>('post')
const reportTargetId = ref(0)
const reportReason = ref('')
const reportDetail = ref('')
const reporting = ref(false)
const reportTypes = ['色情低俗', '政治敏感', '垃圾广告', '辱骂攻击', '侵权内容', '其他违规']
const coinLogs = ref<any[]>([])
const showCoinLogs = ref(false)
const lastDonateTime = ref(0)
const purchasedAttachUrls = ref<string[]>([])
const attachInfoDialog = ref({ show: false, title: '', desc: '', url: '', extractCode: '' })
const showMenu = ref(false)

const contentBlocks = computed<ContentBlock[]>(() => {
  if (!post.value?.content) return []
  try {
    const parsed = JSON.parse(post.value.content)
    if (Array.isArray(parsed)) return parsed as ContentBlock[]
  } catch {}
  return []
})

const coinLogPointsTotal = computed(() => coinLogs.value.filter((l: any) => l.coinType === 'points').reduce((s: number, l: any) => s + l.amount, 0))
const coinLogCoinTotal = computed(() => coinLogs.value.filter((l: any) => l.coinType !== 'points').reduce((s: number, l: any) => s + l.amount, 0))
const coinLogDisplay = computed(() => {
  const parts: string[] = []
  if (coinLogPointsTotal.value) parts.push(`${coinLogPointsTotal.value}积分`)
  if (coinLogCoinTotal.value) parts.push(`${coinLogCoinTotal.value}余额`)
  return parts.length ? `已打赏 ${parts.join(' ')}` : `已打赏 0积分余额`
})

const tagsList = computed(() => {
  const off = (post.value?.officialTags || []).filter(Boolean)
  const user = (post.value?.tags || []).filter(Boolean)
  const seen = new Set<string>()
  return [...off, ...user].filter(t => {
    if (seen.has(t)) return false
    seen.add(t)
    return true
  })
})

const pal = ['#6366F1','#EC4899','#F59E0B','#10B981','#3B82F6','#8B5CF6','#EF4444','#14B8A6','#F97316','#84CC16']
const pal2 = ['#4F46E5','#DB2777','#D97706','#059669','#2563EB','#7C3AED','#DC2626','#0D9488','#EA580C','#65A30D']
function avatarColor(n: string) { let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h); return pal[Math.abs(h) % pal.length] }
function avatarGrad(n: string) { let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h); const i = Math.abs(h) % pal.length; return `linear-gradient(135deg, ${pal[i]}, ${pal2[i]})` }
function fmtTime(t: string) {
  if (!t) return ''
  const d = Date.now() - new Date(t).getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}
function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }
function canDeleteComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid) return false
  return c.userId === uid || post.value?.userId === uid || userIsAdmin()
}
function canPinComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid || c.parentId) return false
  return post.value?.userId === uid || userIsAdmin()
}
function canDeleteReply(r: CommunityComment) {
  const uid = getUserId()
  if (!uid) return false
  return r.userId === uid || post.value?.userId === uid || userIsAdmin()
}

/**
 * Check if current user has the given button-level permission
 * for CommunityPostManage menu via authList
 */
function hasCommunityPermission(authMark: string): boolean {
  const findAuthList = (nodes: any[]): any[] | null => {
    for (const n of nodes) {
      if (n.name === 'CommunityPostManage' && n.meta?.authList?.length) return n.meta.authList
      if (n.children?.length) {
        const result = findAuthList(n.children)
        if (result) return result
      }
    }
    return null
  }
  const authList = findAuthList(menuList.value as any[])
  if (!authList) return userIsAdmin() // fallback: menu not in tree, check admin role
  return authList.some((a: any) => a.authMark === authMark)
}

function tagDotColor(t: string) { return t === '玩机广场' ? '#4BCB73' : t === '资源分享' ? '#999' : '#22C3D0' }

async function loadPost() {
  if (!postId.value) return
  loading.value = true
  try { const r: any = await fetchCommunityPost(postId.value, getUserId()); post.value = r.data || r } catch {} finally { loading.value = false }
}
async function loadComments() {
  if (!postId.value) return
  commentsLoading.value = true
  try {
    const r: any = await fetchComments(postId.value, { page: 1, pageSize: 50 })
    const list = r.data?.list || r.list || r.data || []
    comments.value = (list as CommunityComment[]).map(c => ({ ...c, _isLiked: false, _originalLiked: false }))
  } catch {} finally { commentsLoading.value = false }
}
async function handleLike() {
  const u = getUserId(); if (!u || !post.value) return
  try { await likePost(post.value.id, u); post.value.isLiked = !post.value.isLiked; post.value.likeCount = (post.value.likeCount || 0) + (post.value.isLiked ? 1 : -1) } catch {}
}
async function handleFavorite() {
  const u = getUserId(); if (!u || !post.value) return
  try { await favoritePost(post.value.id, u); post.value.isFavorited = !post.value.isFavorited; post.value.favoriteCount = (post.value.favoriteCount || 0) + (post.value.isFavorited ? 1 : -1) } catch {}
}
const toggleLike = handleLike
const toggleFav = handleFavorite
function scrollToComments() {
  document.querySelector('.comments-section')?.scrollIntoView({ behavior: 'smooth' })
}
async function doDonate() {
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再打赏'); return }
  if (!post.value || donateAmount.value < 1) return
  const elapsed = Date.now() - lastDonateTime.value
  if (elapsed < 30000) {
    const remain = Math.ceil((30000 - elapsed) / 1000)
    ElMessage.warning(`请等待 ${remain} 秒后再打赏`)
    return
  }
  donating.value = true
  try {
    await sendCoin(post.value.id, { userId: u, amount: donateAmount.value, coinType: donateType.value })
    post.value.coinCount = (post.value.coinCount || 0) + donateAmount.value
    lastDonateTime.value = Date.now()
    showDonateModal.value = false
    await loadCoinLogs()
    ElMessage.success('打赏成功')
  } catch {} finally { donating.value = false }
}

async function handleReward() {
  showDonateModal.value = true
}

async function handleSendCoinQuick() {
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再打赏'); return }
  if (!post.value) return
  const elapsed = Date.now() - lastDonateTime.value
  if (elapsed < 30000) {
    const remain = Math.ceil((30000 - elapsed) / 1000)
    ElMessage.warning(`请等待 ${remain} 秒后再打赏`)
    return
  }
  try {
    await sendCoin(post.value.id, { userId: u, amount: 1 })
    post.value.coinCount = (post.value.coinCount || 0) + 1
    lastDonateTime.value = Date.now()
    await loadCoinLogs()
    ElMessage.success('打赏成功')
  } catch {}
}

function isAttachPurchased(url?: string) {
  return !!(url && purchasedAttachUrls.value.includes(url))
}

function handleAttachmentClick(block: ContentBlock) {
  if (!block.url) return
  // 已购买 → 弹窗显示信息
  if (isAttachPurchased(block.url)) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const isFree = block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0
  if (isFree) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再下载'); return }
  const unitLabel = block.priceType === 'points' ? '积分' : '余额'
  ElMessageBox.confirm(
    `该附件需要支付 ${block.coin || 0}${unitLabel}，确认购买？`,
    '购买附件',
    { confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning' }
  ).then(async () => {
    try {
      const res = await fetch('/api/community/attach/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken },
        body: JSON.stringify({ postId: post.value?.id, attachUrl: block.url, coinType: block.priceType, amount: block.coin })
      })
      const data = await res.json()
      if (data.code === 200) {
        purchasedAttachUrls.value.push(block.url!)
        ElMessage.success(data.msg)
        attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url!, extractCode: block.extractCode || '' }
      } else {
        ElMessage.error(data.msg || '购买失败')
      }
    } catch {
      ElMessage.error('购买失败')
    }
  }).catch(() => {})
}

async function loadPurchasedAttachments() {
  if (!postId.value) return
  const u = getUserId()
  if (!u) return
  try {
    const res = await fetch(`/api/community/attach/purchased?postId=${postId.value}`, {
      headers: { 'Authorization': userStore.accessToken }
    })
    const data = await res.json()
    if (data.code === 200) {
      purchasedAttachUrls.value = data.data?.urls || []
    }
  } catch {}
}

async function loadCoinLogs() {
  if (!postId.value) return
  try {
    const r: any = await fetchCoinLogs(postId.value)
    coinLogs.value = r.data?.list || r.list || r.data || []
  } catch {}
}
async function toggleCoinLogs() {
  showCoinLogs.value = true
  await loadCoinLogs()
}
function focusCommentInput() { commentInputEl.value?.focus() }
function toggleReplyInput(c: CommunityComment & { _isLiked?: boolean }) { replyingTo.value = replyingTo.value === c.id ? null : c.id; replyText.value = '' }
async function submitReply(pc: CommunityComment & { _isLiked?: boolean }) {
  const t = replyText.value.trim(); if (!t || !postId.value) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再回复'); return }
  try {
    const r: any = await postComment(postId.value, { userId: u, content: t, parent_id: pc.id })
    const nr: any = r.data || r
    if (!pc.replies) pc.replies = []
    pc.replies.push({ id: nr.id || Date.now(), postId: postId.value, parentId: pc.id, userId: u, userName: (userStore.info as any)?.username || '我', userAvatar: '', content: t, likeCount: 0, replyCount: 0, createTime: new Date().toISOString() })
    pc.replyCount = (pc.replyCount || 0) + 1; replyingTo.value = null; replyText.value = ''
  } catch {}
}
async function submitComment() {
  const t = newCommentText.value.trim(); if (!t || !postId.value) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再评论'); return }
  try {
    const r: any = await postComment(postId.value, { userId: u, content: t, parent_id: 0 })
    const nc: any = r.data || r
    comments.value.unshift({ id: nc.id || Date.now(), postId: postId.value, parentId: 0, userId: u, userName: (userStore.info as any)?.username || '我', userAvatar: '', content: t, likeCount: 0, replyCount: 0, createTime: new Date().toISOString(), replies: [], _isLiked: false, _originalLiked: false })
    if (post.value) post.value.commentCount = (post.value.commentCount || 0) + 1; newCommentText.value = ''
  } catch {}
}
function handleCommentLike(c: CommunityComment & { _isLiked?: boolean }) { c._isLiked = !c._isLiked }
async function handleDeleteComment(c: CommunityComment) {
  const u = getUserId(); if (!u) return
  try { await deleteComment(c.id, u); comments.value = comments.value.filter(x => x.id !== c.id); if (post.value) post.value.commentCount = Math.max(0, (post.value.commentCount || 1) - 1 - (c.replyCount||0)) } catch {}
}
async function handlePinPin() {
  if (!post.value) return
  try { const r: any = await pinPost(post.value.id, getUserId()); const d = r.data || r; post.value.isPinned = d.isPinned; ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶') } catch {}
}
async function handleEssence() {
  if (!post.value) return
  try { const r: any = await essencePost(post.value.id, getUserId()); const d = r.data || r; post.value.isEssence = d.isEssence; ElMessage.success(d.isEssence ? '已加精' : '已取消加精') } catch {}
}
async function handleHot() {
  if (!post.value) return
  try { const r: any = await hotPost(post.value.id, getUserId()); const d = r.data || r; post.value.isHot = d.isHot; ElMessage.success(d.isHot ? '已设为热帖' : '已取消热帖') } catch {}
}
async function handleLock() {
  if (!post.value) return
  try { const r: any = await lockPost(post.value.id, getUserId()); const d = r.data || r; (post.value as any).isLocked = d.isLocked; ElMessage.success(d.isLocked ? '已锁定' : '已解锁') } catch {}
}
async function handleDeletePost() {
  if (!post.value) return
  try {
    await ElMessageBox.confirm('确定要删除该帖子吗？删除后不可恢复。', '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    const u = getUserId()
    const res = await fetch(`/api/community/post/${post.value.id}`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken }, body: JSON.stringify({ userId: u }) })
    const data = await res.json()
    if (data.code === 200) { ElMessage.success('删除成功'); router.replace('/community') }
    else { ElMessage.error(data.msg || '删除失败') }
  } catch {}
}
function goEditPost() {
  if (!post.value) return
  router.push(`/community/post/edit/${post.value.id}`)
}
async function handleShare() {
  const url = window.location.href
  try {
    await navigator.clipboard.writeText(url)
    ElMessage.success('链接已复制')
  } catch {
    ElMessage.info(url)
  }
  showMenu.value = false
}
function handleReportPost() {
  if (!post.value) return
  reportTarget.value = 'post'
  reportTargetId.value = post.value.id
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
  showMenu.value = false
}

function handleReportComment(c: CommunityComment & { _isLiked?: boolean }) {
  reportTarget.value = 'comment'
  reportTargetId.value = c.id
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
}

async function doReport() {
  if (!reportReason.value) return
  reporting.value = true
  try {
    if (reportTarget.value === 'post') {
      await reportPost(reportTargetId.value, reportReason.value, reportDetail.value)
    } else {
      await reportComment(reportTargetId.value, reportReason.value, reportDetail.value)
    }
    ElMessage.success('举报成功，管理员将尽快处理')
    showReportDialog.value = false
  } catch { ElMessage.error('举报失败') }
  reporting.value = false
}

async function handleRequestUnlock() {
  if (!post.value) return
  try {
    await requestUnlock(post.value.id)
    ElMessage.success('解锁申请已提交，等待管理员审核')
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || '申请失败，请稍后再试')
  }
}
async function handlePinComment(c: CommunityComment) {
  try {
    const r: any = await pinComment(c.id)
    const d = r.data || r
    c.isPinned = d.isPinned ? 1 : 0
    ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶')
  } catch {}
}
async function handleDeleteReply(parent: CommunityComment, reply: CommunityComment) {
  const u = getUserId(); if (!u) return
  try {
    await deleteComment(reply.id, u)
    if (parent.replies) {
      parent.replies = parent.replies.filter(x => x.id !== reply.id)
      parent.replyCount = Math.max(0, (parent.replyCount || 1) - 1)
    }
    if (post.value) post.value.commentCount = Math.max(0, (post.value.commentCount || 1) - 1)
  } catch {}
}
function gridClassFor(n: number) {
  if (n === 1) return 'img-1'
  if (n <= 3) return 'img-3'
  return 'img-2'
}

function previewBlockImage(images: string[], i: number) {
  previewImages.value = images
  previewIndex.value = i
  previewVisible.value = true
}

function previewImage(idx: number) {
  previewImages.value = post.value?.images || []
  previewIndex.value = idx
  previewVisible.value = true
}

function closePreview() { previewVisible.value = false }
function prevImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value - 1 + previewImages.value.length) % previewImages.value.length }
function nextImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value + 1) % previewImages.value.length }

onMounted(async () => { await loadPost(); loadComments(); loadCoinLogs(); loadPurchasedAttachments() })
</script>

<style scoped>
/* ============ PAGE ============ */
.post-detail-page { display: flex; flex-direction: column; height: 100vh; height: 100dvh; background: #fff; font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans SC', sans-serif; }
.content-scroll { flex: 1; overflow-y: auto; padding: 0 12px; }

/* ============ DROPDOWN MENU ============ */
.menu-overlay {
  position: fixed; inset: 0; z-index: 9999;
  background: transparent;
}
.menu-panel {
  position: absolute;
  top: 50px; right: 12px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,.12), 0 1px 4px rgba(0,0,0,.06);
  min-width: 160px;
  padding: 8px 0;
  overflow: hidden;
  animation: menuIn .18s cubic-bezier(.25,.8,.25,1);
}
@keyframes menuIn {
  from { opacity: 0; transform: translateY(-6px) scale(.95); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}
.menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  font-size: 14px;
  color: #333;
  cursor: pointer;
  transition: background .12s;
  user-select: none;
}
.menu-item:active { background: #f2f3f5; }
.menu-item svg {
  width: 18px; height: 18px;
  flex-shrink: 0;
  color: #888;
}
.menu-item span {
  white-space: nowrap;
}
.menu-item-danger { color: #e44; }
.menu-item-danger svg { color: #e44; }
.menu-item-danger:active { background: #fef0f0; }
.menu-item-locked { color: #9CA3AF; pointer-events: none; }
.menu-item-locked svg { color: #9CA3AF; }
.menu-divider {
  height: 1px;
  background: #eee;
  margin: 4px 12px;
}

/* ============ NAVBAR - WHITE, CLEAN ============ */
.navbar { display: flex; align-items: center; padding: 10px 12px; gap: 8px; background: #fff; flex-shrink: 0; }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; flex-shrink: 0; }
.nav-author { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.nav-avatar { width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 15px; font-weight: 700; flex-shrink: 0; }
.nav-author-info { display: flex; flex-direction: column; gap: 2px; }
.nav-name { font-size: 15px; font-weight: 600; color: #111; }
.nav-time { font-size: 12px; color: #888; }
.nav-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.nav-dots { cursor: pointer; }

/* ============ TITLE ============ */
.post-title { font-size: 20px; font-weight: 700; color: #111; line-height: 1.35; margin: 14px 0 12px; display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
.title-badge { display: inline-block; font-size: 11px; font-weight: 500; padding: 2px 8px; border-radius: 4px; line-height: 18px; white-space: nowrap; flex-shrink: 0; }
.title-badge-pin { background: #FEF3C7; color: #B45309; }
.title-badge-essence { background: #EDE9FE; color: #6D28D9; }
.title-badge-hot { background: #FEE2E2; color: #DC2626; }
.title-badge-lock { background: #F3F4F6; color: #6B7280; }
.status-bar { margin: 8px 0 0; padding: 8px 14px; border-radius: 8px; font-size: 13px; }
.status-pending { background: #FEF3C7; color: #92400E; }
.status-rejected { background: #FEE2E2; color: #991B1B; }
.status-locked { background: #F3F4F6; color: #6B7280; }

/* ============ INFO LIST (【】style) ============ */
.info-list { margin-bottom: 14px; }
.info-row { font-size: 15px; line-height: 1.9; }
.info-label { font-weight: 700; color: #111; }
.info-value { color: #222; }
.info-link { color: #22C3D0; text-decoration: underline; }

/* ============ BODY TEXT ============ */
.post-body { font-size: 15px; color: #222; line-height: 1.65; margin-bottom: 16px; white-space: pre-wrap; word-break: break-word; padding-left: 8px; }

/* ============ IMAGES ============ */
.images-grid { display: grid; gap: 4px; margin-bottom: 14px; }
.images-grid.img-1 { grid-template-columns: 1fr; }
.images-grid.img-2 { grid-template-columns: 1fr 1fr; }
.images-grid.img-3 { grid-template-columns: 1fr 1fr 1fr; }
.image-item { border-radius: 8px; overflow: hidden; aspect-ratio: 1; cursor: pointer; }
.image-item img { width: 100%; height: 100%; object-fit: cover; display: block; }

/* ============ DOWNLOAD SECTION ============ */
.download-block { margin-bottom: 16px; }
.download-heading { font-size: 16px; font-weight: 600; color: #111; margin-bottom: 8px; }
.download-card { background: #f5f5f5; border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 10px; position: relative; }
.download-icon-box { width: 50px; height: 50px; background: #22C3D0; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.download-icon-box svg { width: 22px; height: 22px; }
.download-info { flex: 1; min-width: 0; }
.download-desc { font-size: 13px; color: #333; font-weight: 500; }
.download-hint { font-size: 11px; color: #999; margin-top: 3px; }
.download-btn-wrap { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.download-price-tag { font-size: 14px; font-weight: 700; color: #22C3D0; background: #fff; padding: 3px 10px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.download-btn { background: #fff; border: none; padding: 5px 14px; border-radius: 12px; font-size: 13px; color: #333; font-weight: 500; cursor: pointer; box-shadow: 0 1px 2px rgba(0,0,0,.05); }
.extract-row { margin-top: 8px; font-size: 12px; color: #888; }
.extract-val { font-weight: 600; color: #333; }

/* ============ TAGS ============ */
.tags-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
.tag-pill { display: flex; align-items: center; gap: 5px; background: #f3f3f3; border-radius: 14px; padding: 5px 12px; font-size: 13px; color: #444; }
.tag-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }

/* ============ REWARD ROW ============ */
.reward-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; margin-bottom: 4px; }
.reward-info { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #666; cursor: pointer; }
.reward-info:hover { color: #333; }
.reward-info em { font-style: normal; font-weight: 600; color: #F59E0B; }
.reward-donate-btn { background: #22C3D0; color: #fff; border: none; border-radius: 14px; padding: 5px 16px; font-size: 13px; font-weight: 500; cursor: pointer; }

/* ============ COMMENTS ============ */
.comments-section { padding-bottom: 60px; }

/* header */
.cs-head { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 16px; padding-top: 4px; }
.cs-head-title { font-size: 16px; font-weight: 700; color: #111; }
.cs-head-title em { font-style: normal; color: #22C3D0; margin-left: 2px; }
.cs-sort { display: flex; gap: 2px; }
.cs-sort-btn { padding: 4px 12px; font-size: 12px; color: #999; border-radius: 10px; border: none; background: none; cursor: pointer; transition: all .15s; }
.cs-sort-btn.on { color: #22C3D0; font-weight: 600; background: rgba(34,195,208,.08); }

/* input row */
.cs-input-row { display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
.cs-input-av { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; font-weight: 700; flex-shrink: 0; }
.cs-input-wrap { flex: 1; background: #f2f3f5; border-radius: 20px; padding: 0 14px; transition: background .2s; }
.cs-input-wrap:focus-within { background: #e8e9eb; }
.cs-input { width: 100%; border: none; background: none; font-size: 14px; color: #333; padding: 9px 0; outline: none; }
.cs-input::placeholder { color: #bbb; }
.cs-send { flex-shrink: 0; background: linear-gradient(135deg, #22C3D0, #1EA5B0); color: #fff; border: none; border-radius: 18px; padding: 8px 20px; font-size: 13px; font-weight: 500; cursor: pointer; transition: opacity .15s; }
.cs-send:disabled { opacity: .35; cursor: default; }
.cs-send:not(:disabled):active { opacity: .8; }

/* loading / empty */
.cs-loading { display: flex; justify-content: center; padding: 32px 0; }
.cs-spin { width: 20px; height: 20px; border: 2px solid #e5e7eb; border-top-color: #22C3D0; border-radius: 50%; animation: cs-spin .6s linear infinite; }
@keyframes cs-spin { to { transform: rotate(360deg); } }
.cs-empty { padding: 56px 16px; text-align: center; display: flex; flex-direction: column; align-items: center; }
.cs-empty-icon { display: flex; align-items: center; justify-content: center; width: 72px; height: 72px; border-radius: 50%; background: #f5f5f5; margin-bottom: 16px; }
.cs-empty p { margin: 0 0 4px; font-size: 15px; color: #999; }
.cs-empty span { font-size: 13px; color: #bbb; }

/* item */
.cs-list { }
.cs-item { display: flex; gap: 12px; padding: 18px 0; transition: background .2s; }
.cs-item + .cs-item { border-top: 1px solid #f0f0f0; }
.cs-item.pinned { background: linear-gradient(135deg, rgba(34,195,208,.04), rgba(34,195,208,.01)); border-radius: 10px; margin: 0 -4px; padding-left: 16px; padding-right: 16px; border-bottom: 1px solid rgba(34,195,208,.12); }
.cs-item-av { width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 16px; font-weight: 700; flex-shrink: 0; box-shadow: 0 2px 6px rgba(0,0,0,.08); }
.cs-item-main { flex: 1; min-width: 0; }
.cs-item-meta { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.cs-item-name { font-size: 14px; font-weight: 600; color: #222; }
.cs-item-tag { font-size: 10px; padding: 2px 6px; border-radius: 4px; background: #22C3D0; color: #fff; line-height: 16px; }
.cs-item-tag.pinned-tag { background: linear-gradient(135deg, #F59E0B, #D97706); }
.cs-item-time { font-size: 12px; color: #bbb; margin-left: auto; flex-shrink: 0; }
.cs-item-body { font-size: 15px; color: #333; line-height: 1.65; margin-bottom: 8px; word-break: break-word; }
.cs-item-acts { display: flex; align-items: center; gap: 20px; }

.cs-act { display: inline-flex; align-items: center; gap: 4px; font-size: 13px; color: #aaa; background: none; border: none; cursor: pointer; padding: 0; transition: color .12s; }
.cs-act svg { width: 16px; height: 16px; flex-shrink: 0; }
.cs-act:active { transform: scale(.94); }
.cs-act.on { color: #22C3D0; }
.cs-act.del { color: #d66; }
.cs-act.del:hover { color: #e44; }
.cs-act.report-act { font-size: 12px; color: #888; padding: 2px 4px; }
.cs-act.report-act:active { color: #e88; }
.cs-act.pin-act { font-size: 12px; }
.cs-act.pin-act.on { color: #F59E0B; }

/* reply panel */
.cs-reply-panel { margin-top: 14px; padding: 12px; background: #f8fafc; border-radius: 12px; }
.cs-reply-to { font-size: 12px; color: #999; margin-bottom: 8px; display: block; }
.cs-reply-to b { font-weight: 600; color: #666; }
.cs-reply-row { display: flex; align-items: center; gap: 8px; }
.cs-reply-input { flex: 1; background: #f2f3f5; border: none; border-radius: 16px; padding: 8px 12px; font-size: 13px; color: #333; outline: none; transition: background .15s; }
.cs-reply-input:focus { background: #e8e9eb; }
.cs-reply-input::placeholder { color: #bbb; }
.cs-reply-cancel { flex-shrink: 0; background: none; border: none; color: #aaa; font-size: 13px; cursor: pointer; }
.cs-reply-send { flex-shrink: 0; background: #22C3D0; color: #fff; border: none; border-radius: 14px; padding: 6px 14px; font-size: 13px; cursor: pointer; }

/* sub-replies */
.cs-sub-wrap { margin-top: 12px; background: #f7f8fa; border-radius: 12px; padding: 10px 14px; }
.cs-sub-item { display: flex; gap: 8px; padding: 8px 0; }
.cs-sub-item + .cs-sub-item { border-top: 1px solid #edeeef; }
.cs-sub-item-av { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 700; flex-shrink: 0; }
.cs-sub-item-main { flex: 1; min-width: 0; }
.cs-sub-item-meta { display: flex; align-items: center; gap: 6px; margin-bottom: 4px; }
.cs-sub-item-name { font-size: 13px; font-weight: 600; color: #555; }
.cs-sub-item-time { font-size: 11px; color: #bbb; margin-left: auto; }
.cs-sub-item-body { font-size: 14px; color: #444; line-height: 1.55; word-break: break-word; }
.cs-sub-item-acts { margin-top: 6px; display: flex; align-items: center; gap: 16px; }
.block-attachment-card { display: flex; align-items: center; gap: 10px; background: #f7f8fa; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-attachment-card:hover { background: #eef0f4; }
.bac-icon { width: 42px; height: 42px; border-radius: 10px; background: #E8F5E9; color: #43A047; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.bac-info { flex: 1; min-width: 0; }
.bac-title { font-size: 14px; font-weight: 500; color: #333; }
.bac-desc { font-size: 11px; color: #999; margin-top: 2px; }
.bac-price { flex-shrink: 0; }
.bac-free { font-size: 12px; background: #E8F5E9; color: #43A047; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-coin { font-size: 12px; background: #FFF3E0; color: #E65100; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-purchased { font-size: 12px; background: #E3F2FD; color: #1976D2; padding: 3px 10px; border-radius: 10px; font-weight: 500; }

.block-link-card { display: flex; align-items: center; gap: 10px; background: #E8EAF6; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; }
.blc-icon { width: 42px; height: 42px; border-radius: 10px; background: rgba(63,81,181,.15); color: #3F51B5; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.blc-info { flex: 1; min-width: 0; }
.blc-title { font-size: 14px; font-weight: 500; color: #333; }
.blc-url { font-size: 11px; color: #999; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.block-app-card { display: flex; align-items: center; gap: 10px; background: #FFF8E1; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-app-card:hover { background: #FFECB3; }
.bac-app-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.bac-app-img { width: 100%; height: 100%; object-fit: cover; }
.bac-app-letter { text-transform: uppercase; }
.bac-app-info { flex: 1; min-width: 0; }
.bac-app-name { font-size: 14px; font-weight: 600; color: #333; }
.bac-app-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.bac-app-price { flex-shrink: 0; }

/* ============ SPINNER ============ */
.loading-wrap { display: flex; justify-content: center; padding: 40px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #22C3D0; border-radius: 50%; animation: sp .6s linear infinite; }
@keyframes sp { to { transform: rotate(360deg); } }
.empty-wrap { flex: 1; display: flex; justify-content: center; align-items: center; color: #aaa; font-size: 13px; }

/* ============ IMAGE PREVIEW ============ */
.img-over { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,.95); display: flex; align-items: center; justify-content: center; }
.img-over-close { position: absolute; top: 16px; right: 16px; color: #fff; font-size: 32px; cursor: pointer; z-index: 10; line-height: 1; }
.img-over-idx { position: absolute; top: 20px; left: 16px; color: #fff; font-size: 14px; z-index: 10; }
.img-over-src { max-width: 90vw; max-height: 80vh; object-fit: contain; }
.img-over-prev, .img-over-next { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,.12); border: none; color: #fff; font-size: 36px; padding: 8px 12px; cursor: pointer; border-radius: 8px; z-index: 10; line-height: 1; }
.img-over-prev { left: 8px; }
.img-over-next { right: 8px; }

/* ============ BOTTOM SPACER ============ */
.bottom-spacer { height: 30px; }

/* ============ DONATION HISTORY ============ */
.coin-logs-body { max-height: 50vh; overflow-y: auto; padding: 0 18px 12px; }
.coin-logs-empty { text-align: center; color: #bbb; font-size: 13px; padding: 30px 0; }
.donate-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f3f3f3; }
.donate-item:last-child { border-bottom: none; }
.donate-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 700; flex-shrink: 0; }
.donate-info { flex: 1; display: flex; flex-direction: column; gap: 1px; }
.donate-name { font-size: 12px; font-weight: 600; color: #333; }
.donate-time { font-size: 10px; color: #bbb; }
.donate-amount { display: flex; align-items: baseline; gap: 2px; flex-shrink: 0; }
.donate-val { font-size: 15px; font-weight: 700; color: #F59E0B; }
.donate-unit { font-size: 10px; color: #999; }

/* ============ DONATE MODAL ============ */
.donate-overlay { position: fixed; inset: 0; z-index: 300; background: rgba(0,0,0,.45); display: flex; align-items: flex-end; justify-content: center; }
.donate-modal { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
@keyframes dmUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.dm-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
.dm-title { font-size: 17px; font-weight: 700; color: #222; }
.dm-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.dm-balance-row { display: flex; gap: 12px; margin-bottom: 16px; }
.dm-bal-item { flex: 1; background: #f7f8fa; border-radius: 10px; padding: 10px 14px; display: flex; flex-direction: column; gap: 4px; }
.dm-bal-label { font-size: 11px; color: #999; }
.dm-bal-val { font-size: 16px; font-weight: 700; color: #F59E0B; }
.dm-type-row, .dm-amount-row { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.dm-type-label { font-size: 13px; color: #666; flex-shrink: 0; width: 60px; }
.dm-type-tabs { display: flex; background: #f3f4f6; border-radius: 8px; padding: 2px; }
.dm-type-tab { padding: 6px 18px; font-size: 13px; border: none; background: none; color: #888; cursor: pointer; border-radius: 6px; transition: all .2s; }
.dm-type-tab.active { background: #22C3D0; color: #fff; }
.dm-amount-opts { display: flex; gap: 8px; }
.dm-amt-btn { width: 54px; height: 34px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; font-size: 14px; font-weight: 600; color: #333; cursor: pointer; }
.dm-amt-btn.active { border-color: #22C3D0; background: #e0f7f9; color: #22C3D0; }
.dm-custom-row { margin-bottom: 18px; }
.dm-custom-input { width: 100%; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 15px; color: #333; outline: none; box-sizing: border-box; }
.dm-custom-input:focus { border-color: #22C3D0; }
.dm-footer { display: flex; gap: 10px; }
.dm-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.dm-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #22C3D0; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.dm-confirm:disabled { background: #b0e0e6; cursor: not-allowed; }

/* ============ REPORT DIALOG ============ */
.report-dialog { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
.report-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; font-size: 17px; font-weight: 700; color: #222; }
.report-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.report-body { margin-bottom: 18px; }
.report-label { font-size: 13px; color: #666; margin-bottom: 10px; }
.report-types { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
.report-type-item { display: flex; align-items: center; gap: 5px; padding: 8px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 13px; color: #444; cursor: pointer; transition: all .2s; }
.report-type-item:hover { border-color: #F59E0B; background: #fff8ed; }
.report-type-item.active { border-color: #F59E0B; background: #fff3e0; color: #F59E0B; font-weight: 600; }
.report-type-item input[type="radio"] { display: none; }
.report-detail-row { margin-top: 8px; }
.report-textarea { width: 100%; height: 80px; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; color: #333; resize: none; outline: none; box-sizing: border-box; font-family: inherit; }
.report-textarea:focus { border-color: #F59E0B; }
.report-footer { display: flex; gap: 10px; }
.report-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.report-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #EF4444; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.report-confirm:disabled { background: #fca5a5; cursor: not-allowed; }

/* ============ ATTACH INFO MODAL ============ */
.attach-overlay { position: fixed; inset: 0; z-index: 310; background: rgba(0,0,0,.4); display: flex; align-items: center; justify-content: center; padding: 24px; }
.attach-modal { width: 100%; max-width: 360px; background: #fff; border-radius: 20px; padding: 28px 24px 20px; animation: amPop .2s ease; box-shadow: 0 12px 40px rgba(0,0,0,.12); }
@keyframes amPop { from { transform: scale(.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.attach-modal-icon { width: 56px; height: 56px; border-radius: 16px; background: #e0f7f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 14px; }
.attach-modal-title { font-size: 17px; font-weight: 700; color: #1a1a1a; text-align: center; margin: 0 0 6px; }
.attach-modal-desc { font-size: 13px; color: #888; text-align: center; margin: 0 0 18px; line-height: 1.5; }
.attach-modal-fields { background: #f7f8fa; border-radius: 12px; padding: 14px; margin-bottom: 20px; display: flex; flex-direction: column; gap: 12px; }
.attach-field { display: flex; flex-direction: column; gap: 4px; }
.attach-field-label { font-size: 11px; color: #999; font-weight: 500; text-transform: uppercase; letter-spacing: .5px; }
.attach-field-value { font-size: 14px; color: #333; font-weight: 500; }
.attach-field-url { word-break: break-all; line-height: 1.5; font-size: 13px; color: #555; }
.attach-field-code { font-size: 18px; font-weight: 700; color: #22C3D0; letter-spacing: 2px; }
.attach-modal-actions { display: flex; gap: 10px; }
.attach-btn { flex: 1; height: 44px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all .15s; }
.attach-btn-copy { background: #22C3D0; color: #fff; }
.attach-btn-copy:active { background: #1a9fa8; }
.attach-btn-close { background: #f3f4f6; color: #555; }
.attach-btn-close:active { background: #e5e7eb; }

/* Post action bar */
.post-action-bar { display: flex; justify-content: space-around; align-items: center; padding: 12px 16px; border-top: 1px solid #f0f0f0; margin-top: 8px; }
.action-btn { display: flex; align-items: center; gap: 4px; padding: 6px 12px; border: none; background: none; cursor: pointer; color: #999; font-size: 14px; transition: all .15s; border-radius: 8px; }
.action-btn:hover { background: #f5f5f5; }
.action-btn.active { color: #ef4444; }
.action-btn.active svg { color: #ef4444; }

/* Permission barrier */
.perm-barrier { text-align: center; padding: 32px 24px; margin: 16px 0; background: #f8f9ff; border-radius: 16px; border: 1px dashed #c7d2fe; }
.perm-barrier-icon { margin-bottom: 12px; }
.perm-barrier-text { font-size: 15px; color: #444; margin-bottom: 8px; }
.perm-barrier-price { font-size: 22px; font-weight: 700; color: #6366F1; margin-bottom: 16px; }
.perm-pwd-input { width: 100%; max-width: 240px; height: 40px; border: 1px solid #d1d5db; border-radius: 10px; padding: 0 12px; font-size: 14px; text-align: center; margin-bottom: 12px; }
.perm-buy-btn { height: 40px; padding: 0 28px; border: none; border-radius: 20px; background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.perm-buy-btn:active { opacity: .85; }
</style>
