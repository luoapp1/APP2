<template>
  <div class="min-h-screen bg-[#f5f5f5] flex flex-col">
    <div class="flex-1 overflow-y-auto pb-16">

      <!-- 顶部搜索区 -->
      <div class="flex items-center gap-3 px-4 py-3 bg-white">
        <div class="w-[36px] h-[36px] rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
          <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#d1d5db"/><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" fill="white"/></svg>
        </div>
        <div class="flex-1 flex items-center bg-gray-100 rounded-full px-3 py-2 gap-2">
          <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
          <span class="text-sm text-gray-400">搜索帖子</span>
        </div>
        <svg class="w-5 h-5 text-gray-500 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
        <svg class="w-5 h-5 text-gray-500 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
      </div>

      <!-- 顶部标签 -->
      <div class="bg-white border-b border-gray-50">
        <div class="flex px-4">
          <div
            v-for="tab in tabs"
            :key="tab"
            class="relative py-3 mr-7 text-sm cursor-pointer transition-colors"
            :class="activeTab === tab ? 'font-semibold' : 'text-gray-500'"
            :style="activeTab === tab ? { color: '#22C1C3' } : {}"
            @click="activeTab = tab"
          >
            {{ tab }}
            <div v-if="activeTab === tab" class="absolute bottom-0 left-1/2 -translate-x-1/2 w-5 h-0.5 rounded-full" style="background:#22C1C3" />
          </div>
        </div>
      </div>

      <!-- 全部板块 -->
      <div class="px-4 py-3">
        <div class="text-sm font-semibold text-gray-800">全部板块</div>
      </div>

      <!-- 板块网格卡片 - 数据来自数据库 -->
      <div class="bg-white mx-3 rounded-2xl px-3 pt-3 pb-1">
        <div class="grid grid-cols-2 gap-x-3 gap-y-1">
          <div
            v-for="board in boards"
            :key="board.id"
            class="flex items-center gap-2.5 py-2.5 cursor-pointer active:opacity-70"
            @click="goSection(board.id)"
          >
            <div class="w-[38px] h-[38px] rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: board.iconBgColor || '#14B8A6' }">
              <svg v-if="boardIcon(board.name)" class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="boardIcon(board.name)"/></svg>
              <span v-else class="text-white text-sm font-bold">{{ board.name ? board.name[0] : '?' }}</span>
            </div>
            <div class="min-w-0 flex-1">
              <div class="text-xs text-gray-800 truncate">{{ board.name }}</div>
              <div class="text-[10px] text-gray-400 mt-0.5">热度{{ formatHeat(board.todayHeat) }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 发现更多 -->
      <div class="px-4 pt-4 pb-1">
        <div class="text-sm font-semibold text-gray-800">发现更多</div>
      </div>

      <div class="bg-white mx-3 rounded-2xl overflow-hidden mb-4">
        <div
          v-for="(item, idx) in discoverItems"
          :key="item.label"
          class="flex items-center px-4 py-3.5 cursor-pointer active:bg-gray-50"
          :class="{ 'border-b border-gray-50': idx < discoverItems.length - 1 }"
        >
          <div class="w-[34px] h-[34px] rounded-lg flex items-center justify-center flex-shrink-0 mr-3" :style="{ background: item.bg }">
            <svg v-if="item.icon" class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="item.icon"/></svg>
          </div>
          <span class="flex-1 text-sm text-gray-700">{{ item.label }}</span>
          <svg class="w-4 h-4 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        </div>
      </div>

    </div>

    <!-- 底部5栏Tab -->
    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex items-center justify-around py-1 z-10" style="padding-bottom:max(6px,env(safe-area-inset-bottom))">
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/browse')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span class="text-[10px]">首页</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/category')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        <span class="text-[10px]">应用</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer" style="color:#00BFA5">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <span class="text-[10px]">社区</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/game')">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <span class="text-[10px]">发现</span>
      </div>
      <div class="flex flex-col items-center gap-0.5 cursor-pointer text-gray-400" @click="$router.push('/appstore/mine')">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
        <span class="text-[10px]">我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunitySections } from '@/api/community'

const router = useRouter()
const activeTab = ref('板块')
const tabs = ['板块', '话题', '热门', '关注']
const boards = ref<any[]>([])

const colorPool = ['#14B8A6', '#EC4899', '#22C55E', '#10B981', '#F97316', '#3B82F6', '#8B5CF6', '#84CC16', '#EA580C', '#F43F5E', '#06B6D4', '#0891B2']

onMounted(async () => {
  try {
    const data: any = await fetchCommunitySections()
    const list = Array.isArray(data) ? data : (data?.list || [])
    boards.value = list.map((s: any, i: number) => ({
      ...s,
      bg: s.iconBgColor || colorPool[i % colorPool.length]
    }))
  } catch {}
})

function boardIcon(name: string) {
  const icons: Record<string, string> = {
    '综合讨论': 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
    '实用软件': 'M4 6h16M4 12h16M4 18h16',
    '绿色软件': 'M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z',
    '技术交流': 'M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
    '资源分享': 'M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8m-4-6l-4-4m0 0L8 8m4-4v12',
    '游戏天地': 'M6 11h4m-2-2v4m5-5v6m3-3v6m-7-6h8a2 2 0 012 2v6a2 2 0 01-2 2H7a2 2 0 01-2-2v-6a2 2 0 012-2z'
  }
  return icons[name] || ''
}

function formatHeat(n: number) {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + '万'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

function goSection(id: number) {
  router.push(`/community/section/${id}`)
}

const discoverItems = [
  { label: '邀请好友', bg: '#10B981', icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
  { label: '游戏大厅', bg: 'linear-gradient(135deg, #8B5CF6, #EC4899)', icon: 'M6 11h4m-2-2v4m5-5v6m3-3v6m-7-6h8a2 2 0 012 2v6a2 2 0 01-2 2H7a2 2 0 01-2-2v-6a2 2 0 012-2z' },
]
</script>
