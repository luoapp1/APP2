<template>
  <div class="forum-page min-h-screen bg-[#F8F8F8]">
    <!-- ==================== LOADING ==================== -->
    <div v-if="loading" class="flex justify-center py-24">
      <div class="animate-spin w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full"/>
    </div>

    <template v-else>
      <!-- ==================== STICKY COMPACT BAR (shown after scroll) ==================== -->
      <Transition name="compact-bar">
        <div
          v-show="scrolled"
          class="fixed top-0 left-0 right-0 z-50 bg-gradient-to-br from-[#1E1B2E] via-[#2D2640] to-[#1A2332] backdrop-blur-xl px-4 pt-10 pb-3 flex items-center gap-3 shadow-lg shadow-black/20"
        >
          <svg class="w-5 h-5 text-white/70 flex-shrink-0 cursor-pointer" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" @click="$router.back()">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
          </svg>
          <div class="w-[36px] h-[36px] rounded-xl bg-gradient-to-br from-[#7C5CFC] to-[#A78BFA] flex items-center justify-center flex-shrink-0 ring-1 ring-white/15 overflow-hidden">
            <img v-if="sectionInfo?.avatar" :src="sectionInfo.avatar" class="w-full h-full object-cover"/>
            <span v-else class="text-white text-[15px] font-bold">{{ (sectionName || '?')[0] }}</span>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[15px] text-white font-semibold leading-tight">{{ sectionName }}</div>
          </div>
          <div class="w-[32px] h-[32px] rounded-full bg-white/10 flex items-center justify-center flex-shrink-0 cursor-pointer active:bg-white/20">
            <svg class="w-[14px] h-[14px] text-white/70" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/></svg>
          </div>
          <div class="flex flex-col gap-0.5 flex-shrink-0 cursor-pointer">
            <div class="w-1 h-1 rounded-full bg-white/70"/><div class="w-1 h-1 rounded-full bg-white/70"/><div class="w-1 h-1 rounded-full bg-white/70"/>
          </div>
        </div>
      </Transition>

      <!-- ==================== COMMUNITY PROFILE ==================== -->
      <div class="relative bg-gradient-to-br from-[#1E1B2E] via-[#2D2640] to-[#1A2332] px-5 pt-10 pb-5">
        <div class="flex items-center justify-between mb-4">
          <svg class="w-5 h-5 text-white/60 flex-shrink-0 cursor-pointer" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" @click="$router.back()">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
          </svg>
          <div class="flex items-center gap-3">
            <div class="w-[30px] h-[30px] rounded-full bg-white/10 flex items-center justify-center flex-shrink-0 cursor-pointer active:bg-white/20">
              <svg class="w-[14px] h-[14px] text-white/60" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/></svg>
            </div>
            <div class="flex flex-col gap-0.5 flex-shrink-0 cursor-pointer">
              <div class="w-1 h-1 rounded-full bg-white/70"/><div class="w-1 h-1 rounded-full bg-white/70"/><div class="w-1 h-1 rounded-full bg-white/70"/>
            </div>
          </div>
        </div>

        <div class="flex items-start gap-4">
          <div class="w-[72px] h-[72px] rounded-[22px] bg-gradient-to-br from-[#7C5CFC] to-[#A78BFA] flex items-center justify-center flex-shrink-0 shadow-xl shadow-[#7C5CFC]/30 overflow-hidden ring-1 ring-white/10">
            <img v-if="sectionInfo?.avatar" :src="sectionInfo.avatar" class="w-full h-full object-cover"/>
            <span v-else class="text-white text-[30px] font-bold">{{ (sectionName || '?')[0] }}</span>
          </div>
          <div class="flex-1 min-w-0 pt-0.5">
            <div class="text-[18px] text-[#F0EBFF] font-bold leading-tight">{{ sectionName }}</div>
            <div class="text-[12px] text-[#9E94C0] mt-1">
              今日热度{{ sectionInfo?.todayHeat || 0 }}&nbsp;&nbsp;总热度{{ sectionInfo?.totalHeat || 0 }}
            </div>
            <div
              v-if="moderators.length > 0"
              class="flex items-center gap-2 mt-2 cursor-pointer active:opacity-70"
              @click="showModeratorModal = true"
            >
              <div class="flex -space-x-2">
                <div
                  v-for="(m, i) in moderators.slice(0, 3)"
                  :key="m.userId"
                  class="w-[22px] h-[22px] rounded-full ring-1.5 ring-[#2D2640] flex items-center justify-center text-white text-[10px] font-bold overflow-hidden flex-shrink-0"
                  :style="{ background: avatarColor(m.userName), zIndex: 3-i }"
                >
                  <img v-if="m.userAvatar" :src="m.userAvatar" class="w-full h-full object-cover"/>
                  <span v-else>{{ (m.userName||'?')[0] }}</span>
                </div>
              </div>
              <span class="text-[12px] text-[#B8AEE0]">{{ moderators.length }}人版主</span>
              <svg class="w-3 h-3 text-[#B8AEE0]" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
            </div>
          </div>
          <button class="bg-white/10 text-white text-[14px] font-semibold px-6 py-2.5 rounded-full flex-shrink-0 active:scale-95 transition-transform mt-2 backdrop-blur-sm">
            签到
          </button>
        </div>
      </div>

      <!-- ==================== PINNED POSTS ==================== -->
      <div v-if="pinnedPosts.length > 0" class="bg-white mt-2.5 mx-3 rounded-xl overflow-hidden shadow-sm">
        <div class="flex items-center gap-2 px-4 pt-3.5 pb-2">
          <svg class="w-4 h-4 text-[#EF4444]" fill="currentColor" viewBox="0 0 24 24"><path d="M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/></svg>
          <span class="text-[13px] font-semibold text-[#EF4444]">置顶</span>
          <span class="text-[12px] text-[#bbb] ml-auto">{{ pinnedPosts.length }}条</span>
        </div>
        <div
          v-for="(post, i) in pinnedPosts"
          :key="'pinned-'+post.id"
          class="flex items-center gap-3 mx-4 py-3 cursor-pointer active:bg-[#FAFAFA] transition-colors"
          :class="{ 'border-t border-[#F5F5F5]': i > 0 }"
          @click="openPostDetail(post.id)"
        >
          <span class="text-[14px] text-[#1A1A1A] font-medium flex-1 line-clamp-1 leading-snug">{{ post.title }}</span>
          <div class="flex items-center gap-2 text-[11px] text-[#C0C0C0] flex-shrink-0">
            <span class="flex items-center gap-0.5"><svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>{{ fmtCount(post.viewCount) }}</span>
            <span class="flex items-center gap-0.5"><svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>{{ fmtCount(post.commentCount) }}</span>
          </div>
        </div>
      </div>

      <!-- ==================== TAB BAR ==================== -->
      <div class="bg-white mt-2.5 mx-3 rounded-xl overflow-hidden shadow-sm">
        <div class="flex items-center px-4 overflow-x-auto scrollbar-hide">
          <div
            v-for="tab in tabs"
            :key="tab.key"
            class="relative py-3 px-1 mr-5 text-[14px] cursor-pointer transition-all duration-200 whitespace-nowrap"
            :class="activeTab === tab.key ? 'text-[#1A1A1A] font-semibold' : 'text-[#999]'"
            @click="switchTab(tab.key)"
          >
            {{ tab.label }}
            <div v-if="activeTab === tab.key" class="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-[3px] rounded-full bg-[#6366F1]"/>
          </div>
        </div>
      </div>

      <!-- ==================== POST LIST ==================== -->
      <div class="pb-24 px-3">
        <div v-if="normalPosts.length === 0 && !loading" class="flex flex-col items-center justify-center py-24 text-gray-300">
          <svg class="w-14 h-14 mb-3 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
          </svg>
          <span class="text-[13px]">还没有帖子，来发布第一条吧</span>
        </div>

        <div
          v-for="post in normalPosts"
          :key="post.id"
          class="bg-white mt-2.5 rounded-xl overflow-hidden shadow-sm cursor-pointer active:scale-[0.985] transition-all duration-150"
          @click="openPostDetail(post.id)"
        >
          <div class="px-4 pt-4 pb-3">
            <!-- Author row -->
            <div class="flex items-center gap-3">
              <div
                class="w-[42px] h-[42px] rounded-full flex items-center justify-center flex-shrink-0 text-white text-lg font-bold overflow-hidden ring-2 ring-[#F0F0F0]"
                :style="{ background: avatarColor(post.userName) }"
              >
                <img v-if="post.userAvatar" :src="post.userAvatar" class="w-full h-full object-cover"/>
                <span v-else>{{ (post.userName || '?')[0].toUpperCase() }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1.5">
                  <span class="text-[15px] text-[#222] font-semibold">{{ post.userName }}</span>
                  <span v-if="post.isPinned" class="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-[#FEF2F2] text-[#EF4444]">置顶</span>
                  <span v-if="post.isEssence" class="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-[#FEF3C7] text-[#D97706]">精华</span>
                  <span v-if="post.isHot" class="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-[#FEE2E2] text-[#DC2626]">热帖</span>
                  <span v-if="post.hasResource" class="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-[#DCFCE7] text-[#16A34A]">资源</span>
                  <!-- Tags -->
                  <template v-for="tag in (post.tags || []).slice(0, 2)" :key="tag">
                    <span class="text-[10px] px-1.5 py-0.5 rounded font-medium bg-[#EEF2FF] text-[#6366F1]">{{ tag }}</span>
                  </template>
                </div>
                <div class="text-[11px] text-[#BBB] mt-0.5 flex items-center gap-2">
                  <span>{{ fmtRelativeTime(post.createTime) }}</span>
                  <span v-if="post.device" class="w-0.5 h-0.5 rounded-full bg-[#DDD]"/>
                  <span v-if="post.device">{{ post.device }}</span>
                </div>
              </div>
            </div>

            <!-- Title -->
            <div class="mt-3 text-[17px] text-[#111] font-bold leading-[1.4] line-clamp-2">{{ post.title }}</div>

            <!-- Content preview - strip markdown and code blocks -->
            <div v-if="post.content" class="mt-2 text-[13px] text-[#AAA] leading-[1.6] line-clamp-2">{{ stripContent(post.content) }}</div>

            <!-- Image grid -->
            <div v-if="post.images && post.images.length" class="mt-3">
              <div v-if="post.images.length === 1" class="rounded-xl overflow-hidden" style="max-height:210px">
                <img :src="post.images[0]" class="w-full object-cover" style="max-height:210px" loading="lazy" alt=""/>
              </div>
              <div v-else-if="post.images.length === 2" class="grid grid-cols-2 gap-1.5 rounded-xl overflow-hidden">
                <img v-for="(img, idx) in post.images.slice(0, 2)" :key="idx" :src="img" class="w-full object-cover" style="aspect-ratio:1;max-height:160px" loading="lazy" alt=""/>
              </div>
              <div v-else class="grid grid-cols-3 gap-1.5 rounded-xl overflow-hidden">
                <img v-for="(img, idx) in post.images.slice(0, 3)" :key="idx" :src="img" class="w-full object-cover" style="aspect-ratio:1;max-height:130px" loading="lazy" alt=""/>
              </div>
            </div>

            <!-- Bottom meta -->
            <div class="flex items-center gap-5 mt-3 pt-2">
              <span class="inline-flex items-center gap-1.5 text-[12px]" :class="post.viewCount > 1000 ? 'text-[#6366F1]' : 'text-[#C2C2C2]'">
                <svg class="w-[14px] h-[14px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                {{ fmtCount(post.viewCount) }}
              </span>
              <span class="inline-flex items-center gap-1.5 text-[12px]" :class="post.commentCount > 10 ? 'text-[#6366F1]' : 'text-[#C2C2C2]'">
                <svg class="w-[14px] h-[14px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                {{ fmtCount(post.commentCount) }}
              </span>
              <span class="inline-flex items-center gap-1.5 text-[12px]" :class="post.likeCount > 10 ? 'text-[#EC4899]' : 'text-[#C2C2C2]'">
                <svg class="w-[14px] h-[14px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                {{ fmtCount(post.likeCount) }}
              </span>
              <span v-if="post.coinCount > 0" class="inline-flex items-center gap-1.5 text-[12px] text-[#F59E0B] ml-auto">
                <svg class="w-[14px] h-[14px]" fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#F59E0B" opacity="0.15"/><text x="12" y="16" text-anchor="middle" fill="#F59E0B" font-size="12" font-weight="bold">¥</text></svg>
                {{ fmtCount(post.coinCount) }}
              </span>
            </div>
          </div>
        </div>

        <!-- Load more -->
        <div v-if="loadingMore" class="flex justify-center py-6">
          <div class="animate-spin w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full"/>
        </div>
        <div v-else-if="!noMore && normalPosts.length > 0" class="text-center py-5 text-[12px] text-[#D0D0D0]">上拉加载更多</div>
        <div v-else-if="noMore && normalPosts.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
      </div>
    </template>

    <!-- ==================== MODERATOR MODAL ==================== -->
    <ModeratorModal :visible="showModeratorModal" :section-id="sectionId" @close="showModeratorModal = false"/>

    <!-- ==================== FLOATING PUBLISH BUTTON ==================== -->
    <button
      class="fixed bottom-20 right-5 w-[54px] h-[54px] bg-gradient-to-br from-[#6366F1] to-[#8B5CF6] rounded-2xl shadow-lg shadow-[#6366F1]/30 flex items-center justify-center z-40 active:scale-90 transition-all duration-200"
      @click="goToPublish"
    >
      <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
      </svg>
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators } from '@/api/community'
import ModeratorModal from './ModeratorModal.vue'

const route = useRoute()
const router = useRouter()

const sectionId = computed(() => Number(route.params.id) || 0)
const sectionName = computed(() => (route.query.name as string) || sectionInfo.value?.name || '综合讨论')

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const activeTab = ref('hot')
const showModeratorModal = ref(false)
const scrolled = ref(false)

const tabs = [
  { key: 'hot', label: '热门' },
  { key: 'latest', label: '最新' },
  { key: 'recent_reply', label: '最近回复' },
  { key: 'essence', label: '精华' }
]

const pinnedPosts = computed(() => postList.value.filter(p => p.isPinned))
const normalPosts = computed(() => postList.value.filter(p => !p.isPinned))

function stripContent(text: string) {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) {
      return parsed
        .filter((b: any) => b.type === 'text')
        .map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim())
        .filter(Boolean)
        .join(' ')
    }
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n/1000000).toFixed(1)+'M'
  if (n >= 10000) return (n/10000).toFixed(1)+'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const now = Date.now(); const ts = new Date(time).getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff/60000)+'分钟前'
  if (diff < 86400000) return Math.floor(diff/3600000)+'小时前'
  const d = new Date(time)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

const avatarPalette = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#84CC16','#E11D48','#0EA5E9','#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name||'').length; i++) hash = name.charCodeAt(i) + ((hash<<5)-hash)
  return avatarPalette[Math.abs(hash)%avatarPalette.length]
}

async function loadModerators() {
  if (!sectionId.value) return
  try { const r: any = await fetchModerators(sectionId.value); moderators.value = r?.data || r || [] } catch {}
}

async function loadSection() {
  if (!sectionId.value) return
  try { const r: any = await fetchCommunitySection(sectionId.value); sectionInfo.value = r.data || r } catch {}
}

async function loadPosts(reset = false) {
  if (reset) { page.value = 1; noMore.value = false; loading.value = true }
  else { loadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sectionId: sectionId.value, sort: activeTab.value, page: page.value, pageSize: 20 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p:any) => ({ ...p,
      tags: typeof p.tags==='string' ? JSON.parse(p.tags||'[]') : (p.tags||[]),
      officialTagsStr: typeof p.officialTags==='string' ? p.officialTags : JSON.stringify(p.officialTags||[]),
      images: typeof p.images==='string' ? JSON.parse(p.images||'[]') : (p.images||[])
    }))
    if (reset) { postList.value = parsed } else { postList.value.push(...parsed) }
    if (list.length < 20) noMore.value = true
  } catch {} finally { loading.value = false; loadingMore.value = false }
}

function switchTab(tabKey: string) { if (activeTab.value !== tabKey) { activeTab.value = tabKey; loadPosts(true) } }
function openPostDetail(postId: number) { router.push(`/community/post/${postId}`) }
function goToPublish() { router.push(`/community/post/create/${sectionId.value}`) }

function onScroll() {
  scrolled.value = window.scrollY > 200

  if (loadingMore.value || noMore.value) return
  if (document.documentElement.scrollHeight - document.documentElement.scrollTop - document.documentElement.clientHeight < 80) { page.value++; loadPosts(false) }
}

onMounted(async () => {
  await loadSection()
  loadModerators()
  loadPosts(true)
  window.addEventListener('scroll', onScroll, { passive: true })
})
onUnmounted(() => { window.removeEventListener('scroll', onScroll) })
</script>

<style scoped>
.compact-bar-enter-active { transition: transform 0.25s ease-out, opacity 0.25s ease-out; }
.compact-bar-leave-active { transition: transform 0.2s ease-in, opacity 0.2s ease-in; }
.compact-bar-enter-from { transform: translateY(-100%); opacity: 0; }
.compact-bar-leave-to { transform: translateY(-100%); opacity: 0; }

.line-clamp-1 { display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
</style>
