<template>
  <div class="submission-page">
    <!-- 页面标题区 -->
    <div class="page-header">
      <div class="header-left" @click="handleGoBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 12H5M12 19l-7-7 7-7"/>
        </svg>
      </div>
      <div class="header-center">
        <div class="header-title">应用投稿</div>
        <div class="header-sub">收录{{ stats.totalSubmissions }}个</div>
      </div>
      <div class="header-right" @click="searchFocused = true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/>
          <path d="M21 21l-4.35-4.35"/>
        </svg>
      </div>
    </div>

    <!-- 顶部统计区 -->
    <div class="stats-row">
      <div class="stat-card stat-card--downloads">
        <div class="stat-card-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 12m4-4v12"/></svg>
        </div>
        <div class="stat-card-value">{{ stats.totalDownloads }}</div>
        <div class="stat-card-label">总下载</div>
      </div>
      <div class="stat-card stat-card--reviews">
        <div class="stat-card-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
        </div>
        <div class="stat-card-value">{{ stats.totalReviews }}</div>
        <div class="stat-card-label">评价数</div>
      </div>
      <div class="stat-card stat-card--stars">
        <div class="stat-card-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
        </div>
        <div class="stat-card-value">{{ stats.totalFiveStar }}</div>
        <div class="stat-card-label">五星好评</div>
      </div>
      <div class="stat-card stat-card--coins">
        <div class="stat-card-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 100 4h4a2 2 0 010 4H8m4-12v16"/></svg>
        </div>
        <div class="stat-card-value">{{ stats.totalCoins }}</div>
        <div class="stat-card-label">投币数量</div>
      </div>
    </div>

    <!-- 筛选标签栏 -->
    <div class="filter-tabs">
      <span
        v-for="tab in statusTabs"
        :key="tab.value"
        :class="['filter-tab', { active: activeStatus === tab.value }]"
        @click="activeStatus = tab.value; fetchData()"
      >{{ tab.label }}</span>
    </div>

    <!-- 搜索栏 -->
    <div class="search-bar">
      <input
        ref="searchInputRef"
        v-model="searchKeyword"
        class="search-input"
        placeholder="搜索应用名称"
        @keyup.enter="fetchData"
      />
      <button class="search-btn" @click="fetchData">搜索</button>
    </div>

    <!-- 内容区域 -->
    <div class="content-area">
      <!-- 空状态 -->
      <div v-if="!loading && tableData.length === 0" class="empty-state">
        <svg class="empty-icon" viewBox="0 0 120 120" fill="none">
          <rect x="28" y="24" width="64" height="14" rx="5" fill="#E8EDF5" />
          <path d="M24 48L60 72L96 48" stroke="#E8EDF5" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round" />
          <rect x="32" y="42" width="56" height="48" rx="3" stroke="#CDD6E8" stroke-width="1.5" fill="white" />
          <path d="M56 42L56 82L64 82L64 42" stroke="#CDD6E8" stroke-width="1.5" fill="none" />
          <rect x="40" y="52" width="40" height="4" rx="2" fill="#E8EDF5" />
          <rect x="40" y="60" width="30" height="3" rx="1.5" fill="#E8EDF5" />
          <rect x="40" y="68" width="22" height="3" rx="1.5" fill="#E8EDF5" />
          <rect x="16" y="20" width="88" height="6" rx="3" fill="#E8EDF5" opacity="0.5" />
        </svg>
        <p class="empty-text">暂无内容</p>
      </div>

      <!-- 数据列表 -->
      <div v-else class="submission-list">
        <div
          v-for="group in groupedApps"
          :key="group.packageName"
          class="submission-card"
        >
          <div class="card-top">
            <div class="card-icon" :style="{ background: group.iconBgColor || iconColor(group.name) }">
              <img v-if="group.icon" :src="group.icon" class="icon-img" />
              <span v-else class="card-icon-letter">{{ (group.name || '?')[0] }}</span>
            </div>
            <div class="card-info">
              <div class="card-name">
                {{ group.name }}
                <span class="version-count" @click="toggleVersions(group.packageName)">
                  {{ group.versions.length }}个版本
                  <svg :class="{ rotated: expandedPackages.has(group.packageName) }" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M6 9l6 6 6-6"/></svg>
                </span>
              </div>
              <div class="card-meta">{{ formatCategory(group.category) }} | v{{ group.latestVersion }} | {{ group.sizeMb }}MB</div>
              <div class="card-time">{{ group.createTime }}</div>
            </div>
          </div>
          <div class="card-bottom">
            <div class="card-stats">
              <span class="card-stat"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 12m4-4v12"/></svg>{{ group.downloads || 0 }}</span>
              <span class="card-stat"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>{{ group.reviews || 0 }}</span>
              <span class="card-stat"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 100 4h4a2 2 0 010 4H8m4-12v16"/></svg>{{ group.coins || 0 }}</span>
            </div>
            <div class="card-actions">
              <button class="action-btn action-new-version" @click="handleNewVersion(group)">上传新版本</button>
              <button
                v-if="group.latestApprovedItem"
                class="action-btn action-edit"
                @click="handleEdit(group.latestApprovedItem)"
              >编辑</button>
              <button
                v-if="group.hasApproved"
                class="action-btn action-remove"
                @click="handleRemove(group.latestApprovedItem)"
              >下架</button>
              <button
                v-if="group.hasRemoved"
                class="action-btn action-relist"
                @click="handleRelist(group.latestRemovedItem)"
              >重新上架</button>
            </div>
          </div>
          <!-- 版本列表 -->
          <div v-if="expandedPackages.has(group.packageName)" class="version-list">
            <div class="version-list-title">历史版本</div>
            <div
              v-for="ver in group.versions"
              :key="ver.id"
              class="version-item"
            >
              <div class="version-info">
                <span class="version-num">v{{ ver.version }}</span>
                <span class="price-tag-sm" :style="{ color: priceColor(ver), background: priceColor(ver) + '14' }">
                  {{ formatPrice(ver) }}
                </span>
                <span class="version-time">{{ ver.createTime }}</span>
              </div>
              <div class="version-actions">
                <button
                  v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'approved'"
                  class="action-btn action-edit"
                  @click="handleEdit(ver)"
                >编辑</button>
                <button
                  v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'rejected'"
                  class="action-btn action-submit"
                  @click="handleSubmit(ver)"
                >提交审核</button>
                <button
                  v-if="ver.submissionStatus === 'approved'"
                   class="action-btn action-remove"
                   @click="handleRemove(ver)"
                 >下架</button>
                 <button
                   v-if="ver.submissionStatus === 'removed'"
                   class="action-btn action-relist"
                   @click="handleRelist(ver)"
                 >重新上架</button>
                <button
                  v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'rejected'"
                  class="action-btn action-delete"
                  @click="handleDelete(ver)"
                >删除</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 分页 -->
    <div v-if="total > pageSize" class="pagination-wrap">
      <el-pagination
        v-model:current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="fetchData"
      />
    </div>

    <!-- 悬浮加号按钮 -->
    <button class="fab-button" @click="showDrawer = true">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round">
        <path d="M12 5v14M5 12h14"/>
      </svg>
    </button>

    <!-- 底部弹窗遮罩 -->
    <div v-if="showDrawer" class="drawer-overlay" @click="showDrawer = false" />

    <!-- 底部弹窗面板 -->
    <div :class="['drawer-panel', { 'drawer-panel--open': showDrawer }]">
      <div class="drawer-handle" />
      <div class="drawer-option" @click="handleSubmitFromFile">
        <div class="drawer-option-icon" style="background:#E0F7FA">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22c1-1 4-4 4-10a4 4 0 00-8 0c0 6 3 9 4 10z"/>
            <circle cx="12" cy="8" r="3"/>
          </svg>
        </div>
        <span class="drawer-option-text">选择安装包位置</span>
        <svg class="drawer-option-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
      </div>
      <div class="drawer-option" @click="handleSubmitFromInstalled">
        <div class="drawer-option-icon" style="background:#F3E5F5">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9C27B0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2" y="3" width="20" height="14" rx="2"/>
            <path d="M8 21h8M12 17v4"/>
          </svg>
        </div>
        <span class="drawer-option-text">已安装应用</span>
        <svg class="drawer-option-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
      </div>
      <button class="drawer-cancel" @click="showDrawer = false">取消</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import {
  fetchSubmissionStats,
  fetchSubmissionList,
  fetchSubmitReview,
  fetchUpdateSubmissionStatus,
  fetchDeleteSubmission,
  fetchSubmissionVersions
} from '@/api/submission'

const router = useRouter()
const userStore = useUserStore()
const userId = computed(() => userStore.getUserInfo.userId)
const userName = computed(() => userStore.getUserInfo.userName || userStore.getUserInfo.nickname || '')

const loading = ref(false)
const searchKeyword = ref('')
const searchFocused = ref(false)
const searchInputRef = ref<HTMLInputElement>()
const activeStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const tableData = ref<any[]>([])
const showDrawer = ref(false)
const expandedPackages = reactive(new Set<string>())
const versionCache = reactive<Record<string, any[]>>({})
const versionLoading = reactive<Record<string, boolean>>({})

const colorPool = ['#4F8AF7', '#6C5CE7', '#00BFA5', '#F97316', '#EC4899', '#EF4444', '#8B5CF6', '#10B981', '#3B82F6', '#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const stats = reactive({
  totalSubmissions: 0,
  totalDownloads: 0,
  totalReviews: 0,
  totalFiveStar: 0,
  totalCoins: 0
})

const statusTabs = [
  { label: '全部', value: '' },
  { label: '审核中', value: 'pending' },
  { label: '未通过', value: 'rejected' },
  { label: '下架', value: 'removed' },
  { label: '草稿', value: 'draft' }
]

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    approved: '已分享',
    pending: '审核中',
    rejected: '未通过',
    removed: '下架',
    draft: '草稿'
  }
  return map[status] || status
}

function formatCategory(cat: string): string {
  try {
    const arr = JSON.parse(cat)
    if (Array.isArray(arr)) return arr.join(', ')
  } catch {}
  return cat || ''
}

function formatPrice(item: any): string {
  const pt = item.priceType || item.price_type || 'free'
  const pa = Number(item.priceAmount || item.price_amount || 0)
  if (pt === 'free' || pa <= 0) return '免费'
  if (pt === 'balance') return `${pa} 元`
  if (pt === 'points') return `${pa} 积分`
  return '免费'
}

function priceColor(item: any): string {
  const pt = item.priceType || item.price_type || 'free'
  if (pt === 'free') return '#10B981'
  if (pt === 'balance') return '#F59E0B'
  if (pt === 'points') return '#8B5CF6'
  return '#10B981'
}

async function fetchStats() {
  try {
    const d: any = await fetchSubmissionStats(userId.value)
    if (d) {
      stats.totalSubmissions = d.totalSubmissions || 0
      stats.totalDownloads = d.totalDownloads || 0
      stats.totalReviews = d.totalReviews || 0
      stats.totalFiveStar = d.totalFiveStar || 0
      stats.totalCoins = d.totalCoins || 0
    }
  } catch {}
}

async function fetchData() {
  loading.value = true
  try {
    const data: any = await fetchSubmissionList({
      userId: userId.value,
      status: activeStatus.value,
      keyword: searchKeyword.value,
      page: page.value,
      pageSize: pageSize.value
    })
    if (data) {
      tableData.value = data.list || []
      total.value = data.total || 0
    }
  } catch {} finally {
    loading.value = false
  }
}

const groupedApps = computed(() => {
  const map = new Map<string, any[]>()
  for (const item of tableData.value) {
    const key = item.packageName || item.package_name || ''
    if (!key) { map.set('_single_' + item.id, [item]); continue }
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(item)
  }
  return Array.from(map.entries()).map(([pkg, versions]) => {
    versions.sort((a: any, b: any) => b.id - a.id)
    // Merge version cache — update existing entries, add new ones
    if (versionCache[pkg]) {
      const idMap = new Map<number, any>()
      for (const v of versionCache[pkg]) { idMap.set(v.id, v) }
      for (const v of versions) { idMap.set(v.id, v) }
      versionCache[pkg] = Array.from(idMap.values())
    } else {
      versionCache[pkg] = [...versions]
    }
    versionCache[pkg].sort((a: any, b: any) => b.id - a.id)

    const latest = versions[0]
    const approved = versions.find((v: any) => v.submissionStatus === 'approved')
    const removed = versions.find((v: any) => v.submissionStatus === 'removed')
    return {
      packageName: pkg,
      name: latest.name,
      icon: latest.icon,
      iconBgColor: latest.iconBgColor,
      category: latest.category,
      latestVersion: latest.version,
      latestStatus: latest.submissionStatus,
      sizeMb: latest.sizeMb,
      createTime: latest.createTime,
      downloads: approved ? approved.downloads : 0,
      reviews: approved ? approved.reviews : 0,
      coins: approved ? approved.coins : 0,
      hasApproved: !!approved,
      latestApprovedItem: approved,
      hasRemoved: !!removed && !approved,
      latestRemovedItem: removed,
      versions: versionCache[pkg],
      id: latest.id,
      priceType: latest.priceType || latest.price_type || 'free',
      priceAmount: Number(latest.priceAmount || latest.price_amount || 0),
      isFree: latest.isFree !== undefined ? !!latest.isFree : true
    }
  })
})

async function toggleVersions(packageName: string) {
  if (expandedPackages.has(packageName)) {
    expandedPackages.delete(packageName)
    return
  }
  expandedPackages.add(packageName)
  if (versionLoading[packageName]) return
  versionLoading[packageName] = true
  try {
    const data: any = await fetchSubmissionVersions({ packageName, userId: userId.value })
    if (data?.list) {
      versionCache[packageName] = data.list
    }
  } catch {} finally {
    versionLoading[packageName] = false
  }
}

function handleSubmitFromFile() {
  showDrawer.value = false
  router.push('/appstore/submissions/file-picker')
}

function handleSubmitFromInstalled() {
  showDrawer.value = false
  ElMessage.info('已安装应用选择功能开发中')
}

function handleNewVersion(group: any) {
  showDrawer.value = false
  router.push({
    path: '/appstore/submissions/edit',
    query: {
      newVersion: '1',
      baseId: String(group.id),
      name: group.name,
      packageName: group.packageName || '',
      category: group.category || '工具',
      version: bumpVersion(group.latestVersion || '1.0.0'),
      sizeMb: String(group.sizeMb || 0)
    }
  })
}

function bumpVersion(ver: string): string {
  const parts = ver.split('.').map(Number)
  if (parts.length >= 2) {
    parts[parts.length - 1]++
  }
  return parts.join('.')
}

function handleEdit(item: any) {
  router.push({
    path: '/appstore/submissions/edit',
    query: {
      id: String(item.id),
      name: item.name,
      packageName: item.packageName || '',
      category: item.category || '工具',
      version: item.version || '1.0.0',
      sizeMb: String(item.sizeMb || 0)
    }
  })
}

async function handleSubmit(item: any) {
  try {
    await ElMessageBox.confirm(`确定将「${item.name}」提交审核吗？`, '提交审核', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'info'
    })
    await fetchSubmitReview(item.id)
    ElMessage.success('已提交审核')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData()
    await fetchStats()
  } catch {}
}

async function handleDelete(item: any) {
  try {
    await ElMessageBox.confirm(`确定删除「${item.name}」吗？此操作不可恢复。`, '删除确认', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await fetchDeleteSubmission(item.id)
    ElMessage.success('已删除')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData()
    await fetchStats()
  } catch {}
}

async function handleRemove(item: any) {
  try {
    await ElMessageBox.confirm(`确定下架「${item.name}」吗？`, '下架确认', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'removed',
      reviewBy: userName.value,
      role: '',
      userId: userStore.info?.id || userId.value
    })
    ElMessage.success('已下架')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData()
    await fetchStats()
  } catch {}
}

async function handleRelist(item: any) {
  try {
    await ElMessageBox.confirm(`确定重新上架「${item.name}」吗？`, '重新上架确认', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'info'
    })
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'approved',
      reviewBy: userName.value,
      role: '',
      userId: userStore.info?.id || userId.value
    })
    ElMessage.success('已重新上架')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData()
    await fetchStats()
  } catch {}
}

onMounted(() => {
  fetchStats()
  fetchData()
})

function handleGoBack() {
  if (window.history.length > 1) {
    router.back()
  } else {
    router.push('/appstore/mine')
  }
}

watch(searchFocused, (val) => {
  if (val) {
    nextTick(() => {
      searchInputRef.value?.focus()
      searchInputRef.value?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    })
    searchFocused.value = false
  }
})
</script>

<style lang="scss" scoped>
.submission-page {
  min-height: 100vh;
  background: linear-gradient(180deg, #f0fdf6 0%, #f8fafc 40%, #fff 100%);
  position: relative;
  padding: 0 16px 100px;
}

.page-header {
  display: flex;
  align-items: flex-start;
  padding: 16px 0 8px;
}

.header-left {
  padding: 2px 8px 0 0;
  cursor: pointer;
  flex-shrink: 0;
}

.header-center { flex: 1; }

.header-right {
  padding: 2px 0 0 8px;
  cursor: pointer;
  flex-shrink: 0;
}

.header-title {
  font-size: 20px;
  font-weight: 700;
  color: #0f172a;
  line-height: 1.3;
  letter-spacing: -0.5px;
}

.header-sub {
  font-size: 13px;
  color: #94a3b8;
  margin-top: 2px;
}

/* ===== STATS CARDS ===== */
.stats-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  padding: 0 0 20px;
  margin-bottom: 4px;
}

.stat-card {
  text-align: center;
  padding: 14px 6px;
  border-radius: 16px;
  background: #fff;
  box-shadow: 0 2px 12px rgba(0,0,0,.04);
  border: 1px solid #f1f5f9;
  transition: transform .15s, box-shadow .15s;

  &:active {
    transform: scale(.97);
    box-shadow: 0 1px 6px rgba(0,0,0,.06);
  }
}

.stat-card-icon {
  width: 30px;
  height: 30px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 8px;
}

.stat-card--downloads .stat-card-icon { background: #dbeafe; color: #3B82F6; }
.stat-card--reviews .stat-card-icon { background: #fef3c7; color: #f59e0b; }
.stat-card--stars .stat-card-icon { background: #ede9fe; color: #8b5cf6; }
.stat-card--coins .stat-card-icon { background: #d1fae5; color: #10b981; }

.stat-card-value {
  font-size: 22px;
  font-weight: 800;
  color: #1e293b;
  line-height: 1;
}

.stat-card-label {
  font-size: 11px;
  color: #94a3b8;
  margin-top: 4px;
}

/* ===== FILTER TABS ===== */
.filter-tabs {
  display: flex;
  gap: 8px;
  padding: 4px 0 16px;
  flex-wrap: wrap;
}

.filter-tab {
  font-size: 13px;
  color: #64748b;
  cursor: pointer;
  padding: 7px 16px;
  border-radius: 20px;
  background: #fff;
  border: 1px solid #e2e8f0;
  transition: all .2s;
  white-space: nowrap;

  &.active {
    background: #00BFA5;
    color: #fff;
    border-color: #00BFA5;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(0,191,165,.25);
  }
}

/* ===== SEARCH BAR ===== */
.search-bar {
  display: flex;
  gap: 0;
  margin-bottom: 20px;
}

.search-input {
  flex: 1;
  height: 44px;
  padding: 0 16px;
  border: 1.5px solid #e2e8f0;
  border-right: none;
  border-radius: 12px 0 0 12px;
  font-size: 14px;
  background: #fff;
  outline: none;
  color: #334155;
  box-sizing: border-box;
  transition: border-color .2s;

  &:focus {
    border-color: #00BFA5;
  }

  &::placeholder {
    color: #cbd5e1;
  }
}

.search-btn {
  height: 44px;
  padding: 0 18px;
  border: none;
  border-radius: 0 12px 12px 0;
  background: #00BFA5;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;

  &:active {
    background: #00a690;
  }
}

/* ===== CONTENT ===== */
.content-area {
  min-height: 200px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 0;

  .empty-icon {
    width: 140px;
    height: 140px;
    margin-bottom: 16px;
  }

  .empty-text {
    font-size: 15px;
    color: #cbd5e1;
    margin: 0;
  }
}

/* ===== APP CARDS ===== */
.submission-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.submission-card {
  background: #fff;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 2px 16px rgba(0,0,0,.04);
  border: 1px solid #f1f5f9;
  transition: box-shadow .2s;

  &:hover {
    box-shadow: 0 4px 24px rgba(0,0,0,.06);
  }
}

.card-top {
  display: flex;
  gap: 14px;
}

.card-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0,191,165,.15);

  .icon-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}

.card-icon-letter {
  font-size: 18px;
  font-weight: 700;
  color: #fff;
  line-height: 1;
}

.card-info {
  flex: 1;
  min-width: 0;
}

.card-name {
  font-size: 15px;
  font-weight: 700;
  color: #0f172a;
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.status-badge {
  font-size: 10px;
  font-weight: 600;
  padding: 3px 8px;
  border-radius: 99px;
  flex-shrink: 0;
  display: inline-block;
  letter-spacing: 0.02em;

  &.status-approved {
    background: #d1fae5;
    color: #059669;
  }

  &.status-pending {
    background: #fef3c7;
    color: #d97706;
  }

  &.status-rejected {
    background: #fee2e2;
    color: #dc2626;
  }

  &.status-removed {
    background: #f1f5f9;
    color: #94a3b8;
  }

  &.status-draft {
    background: #f1f5f9;
    color: #64748b;
  }
}

.card-meta {
  font-size: 12px;
  color: #94a3b8;
  margin-top: 4px;
}

.card-time {
  font-size: 11px;
  color: #cbd5e1;
  margin-top: 2px;
}

.card-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px solid #f8fafc;
}

.card-stats {
  display: flex;
  gap: 16px;
}

.card-stat {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #64748b;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  font-size: 12px;
  font-weight: 600;
  padding: 6px 14px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  transition: all .15s;

  &:active {
    transform: scale(.96);
  }

  &.action-new-version {
    background: linear-gradient(135deg, #00BFA5, #00d4b8);
    color: #fff;
    box-shadow: 0 2px 8px rgba(0,191,165,.2);
  }

  &.action-edit {
    background: #eff6ff;
    color: #3B82F6;
  }

  &.action-submit {
    background: #ecfdf5;
    color: #059669;
  }

  &.action-delete {
    background: #fef2f2;
    color: #ef4444;
  }

  &.action-remove {
    background: #fff7ed;
    color: #f97316;
  }

  &.action-relist {
    background: #ecfdf5;
    color: #059669;
  }
}

/* ===== PAGINATION ===== */
.pagination-wrap {
  display: flex;
  justify-content: center;
  padding: 24px 0;
}

/* ===== FAB ===== */
.fab-button {
  position: fixed;
  bottom: 32px;
  right: 20px;
  width: 56px;
  height: 56px;
  border-radius: 18px;
  background: linear-gradient(135deg, #00BFA5, #00d4b8);
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 8px 28px rgba(0,191,165,.3);
  z-index: 100;
  transition: transform .15s, box-shadow .15s;

  &:active {
    transform: scale(.92);
    box-shadow: 0 4px 16px rgba(0,191,165,.25);
  }
}

/* ===== DRAWER ===== */
.drawer-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.5);
  z-index: 200;
  animation: fadeIn .2s;
}

.drawer-panel {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: #fff;
  border-radius: 20px 20px 0 0;
  padding: 14px 16px calc(16px + env(safe-area-inset-bottom));
  z-index: 201;
  transform: translateY(100%);
  transition: transform .35s cubic-bezier(.4,0,.2,1);

  &--open {
    transform: translateY(0);
  }
}

.drawer-handle {
  width: 40px;
  height: 5px;
  background: #e2e8f0;
  border-radius: 3px;
  margin: 0 auto 18px;
}

.drawer-option {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px 6px;
  cursor: pointer;
  border-radius: 14px;
  transition: background .15s;

  &:active {
    background: #f8fafc;
  }
}

.drawer-option-icon {
  width: 46px;
  height: 46px;
  border-radius: 13px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.drawer-option-text {
  font-size: 15px;
  font-weight: 600;
  color: #1e293b;
  flex: 1;
}

.drawer-option-arrow {
  flex-shrink: 0;
}

.drawer-cancel {
  width: 100%;
  padding: 13px;
  margin-top: 10px;
  border: none;
  background: #f8fafc;
  color: #64748b;
  font-size: 14px;
  font-weight: 600;
  border-radius: 14px;
  cursor: pointer;
}

/* ===== VERSION LIST ===== */
.version-count {
  font-size: 11px;
  font-weight: 600;
  color: #059669;
  background: #d1fae5;
  padding: 3px 8px;
  border-radius: 99px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  vertical-align: middle;
  margin-left: 6px;
  transition: background .15s;

  svg { transition: transform .25s; }
  svg.rotated { transform: rotate(180deg); }

  &:hover {
    background: #a7f3d0;
  }
}

.version-list {
  margin-top: 12px;
  border-top: 1.5px dashed #f1f5f9;
  padding-top: 12px;
  animation: slideDown .25s ease;
}

.version-list-title {
  font-size: 11px;
  font-weight: 600;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 10px;
}

.version-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: #f8fafc;
  border-radius: 12px;
  margin-bottom: 8px;
  border: 1px solid #f1f5f9;
  transition: background .15s;

  &:hover {
    background: #f1f5f9;
  }
}

.version-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.version-num {
  font-size: 14px;
  font-weight: 700;
  color: #1e293b;
}

.version-time {
  font-size: 11px;
  color: #cbd5e1;
}

.version-actions {
  display: flex;
  gap: 6px;
}

@keyframes slideDown {
  from { opacity: 0; transform: translateY(-8px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.price-tag {
  display: inline-flex;
  align-items: center;
  padding: 1px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
}

.price-tag-sm {
  display: inline-flex;
  align-items: center;
  padding: 0 6px;
  border-radius: 8px;
  font-size: 10px;
  font-weight: 500;
  line-height: 18px;
}
</style>
