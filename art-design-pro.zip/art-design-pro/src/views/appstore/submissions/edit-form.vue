<template>
  <div class="ef-page">
    <div class="ef-header">
      <div class="ef-back" @click="goBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <div class="ef-title">{{ isNewVersion ? '上传新版本' : '应用信息' }}</div>
    </div>

    <div class="ef-body">
      <!-- APK 文件信息卡 -->
      <div class="apk-card">
        <div class="apk-icon" :style="{ background: iconBgColor }" @click="triggerIconUpload">
          <img v-if="editForm.icon" :src="editForm.icon" class="apk-icon-img" />
          <span v-else class="apk-icon-letter">{{ iconLetter }}</span>
          <div class="apk-icon-overlay">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>
          </div>
        </div>
        <input ref="iconInput" type="file" accept="image/*" class="apk-icon-input" @change="onIconChange" />
        <div class="apk-info">
          <div class="apk-name">{{ editForm.name || fileName }}</div>
          <div class="apk-meta">{{ editForm.packageName || packageName }}</div>
          <div class="apk-meta">v{{ editForm.version }} | {{ editForm.sizeMb }}MB</div>
        </div>
      </div>

      <!-- 表单字段组 -->
      <div class="ef-group">
        <div class="ef-row">
          <span class="ef-label">应用名称</span>
          <input v-model="editForm.name" class="ef-input" placeholder="请输入" />
        </div>
        <div class="ef-row">
          <span class="ef-label">包名</span>
          <input v-model="editForm.packageName" class="ef-input" placeholder="com.example.app" />
        </div>
        <div class="ef-row" @click="showCategoryPicker = true">
          <span class="ef-label">应用分类</span>
          <div class="ef-value-row">
            <span v-if="editForm.categories.length === 0" class="ef-placeholder">请选择</span>
            <span v-else class="ef-tags">
              <span v-for="c in editForm.categories" :key="c" class="ef-tag">{{ c }}</span>
            </span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <div class="ef-row">
          <span class="ef-label">版本号</span>
          <div class="ef-value-row">
            <input v-model="editForm.version" class="ef-input-sm" placeholder="1.0.0" />
          </div>
        </div>
        <div class="ef-row" @click="showVersionTypePicker = true">
          <span class="ef-label">版本类型</span>
          <div class="ef-value-row">
            <span :class="editForm.versionType ? '' : 'ef-placeholder'">{{ editForm.versionType || '请选择' }}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <div class="ef-row">
          <span class="ef-label">应用大小</span>
          <input v-model.number="editForm.sizeMb" class="ef-input" placeholder="0" type="number" />
        </div>
        <div class="ef-row">
          <span class="ef-label">下载地址</span>
          <input v-model="editForm.downloadUrl" class="ef-input" placeholder="下载链接" />
        </div>
      </div>

      <!-- 应用图片 -->
      <div class="ef-section-title">应用图片</div>
      <div class="ef-group ef-images-group">
        <div class="images-grid">
          <div
            v-for="(img, i) in editForm.screenshots"
            :key="i"
            class="img-item"
            :style="{ backgroundImage: 'url(' + img + ')' }"
          >
            <div class="img-remove" @click.stop="removeScreenshot(i)">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </div>
          </div>
          <div class="img-item img-add" @click="triggerImageUpload">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg>
          </div>
        </div>
      </div>

      <!-- 更多信息 -->
      <div class="ef-section-title">更多信息</div>
      <div class="ef-group">
        <div class="ef-row ef-row-desc">
          <span class="ef-label">应用描述</span>
          <textarea v-model="editForm.description" class="ef-textarea" rows="3" placeholder="介绍应用功能特点..." />
        </div>
      </div>

      <!-- 开关选项 -->
      <div class="ef-group ef-switch-group">
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否有广告</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.hasAds" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否需要联网</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.requiresNetwork" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否包含付费内容</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.hasPaidContent" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否免费应用</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.isFree" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-row">
          <span class="ef-label">收费方式</span>
          <div class="ef-price-type">
            <button :class="['ef-price-btn', { active: editForm.price_type !== 'balance' && editForm.price_type !== 'points' }]" @click="editForm.price_type = 'free'">免费</button>
            <button :class="['ef-price-btn', { active: editForm.price_type === 'balance' }]" @click="editForm.price_type = 'balance'">余额</button>
            <button :class="['ef-price-btn', { active: editForm.price_type === 'points' }]" @click="editForm.price_type = 'points'">积分</button>
          </div>
        </div>
        <div class="ef-row" v-if="editForm.price_type === 'balance' || editForm.price_type === 'points'">
          <span class="ef-label">{{ editForm.price_type === 'balance' ? '价格(元)' : '价格(积分)' }}</span>
          <input v-model.number="editForm.price_amount" type="number" class="ef-input" placeholder="请输入金额" min="0" step="0.01" />
        </div>
      </div>
    </div>

    <div class="ef-bottom">
      <button class="ef-submit" @click="handleSubmit">发布应用</button>
    </div>

    <!-- 分类多选弹窗 -->
    <div v-if="showCategoryPicker" class="picker-overlay" @click.self="showCategoryPicker = false">
      <div class="picker-panel">
        <div class="picker-title">选择分类</div>
        <div class="picker-grid">
          <div
            v-for="cat in categories"
            :key="cat"
            :class="['picker-chip', { active: editForm.categories.includes(cat) }]"
            @click="toggleCategory(cat)"
          >{{ cat }}</div>
        </div>
        <button class="picker-confirm" @click="showCategoryPicker = false">确定</button>
      </div>
    </div>

    <!-- 版本类型选择弹窗 -->
    <div v-if="showVersionTypePicker" class="picker-overlay" @click.self="showVersionTypePicker = false">
      <div class="picker-panel">
        <div class="picker-title">选择版本类型</div>
        <div
          v-for="vt in versionTypes"
          :key="vt"
          :class="['picker-item', { active: editForm.versionType === vt }]"
          @click="editForm.versionType = vt; showVersionTypePicker = false"
        >{{ vt }}</div>
        <button class="picker-cancel" @click="showVersionTypePicker = false">取消</button>
      </div>
    </div>

    <input ref="imageInput" type="file" accept="image/*" multiple style="display: none;" @change="onImagesUpload" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import { fetchSaveSubmission } from '@/api/submission'
import { fetchCategoryList } from '@/api/appstore'
import request from '@/utils/http'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const userId = computed(() => userStore.getUserInfo.userId)
const userName = computed(() => userStore.getUserInfo.userName || '')

const fileName = ref(route.query.fileName as string || '')
const packageName = ref(route.query.packageName as string || '')
const sizeMb = ref(route.query.sizeMb as string || '0')
const showCategoryPicker = ref(false)
const showVersionTypePicker = ref(false)
const imageInput = ref<HTMLInputElement | null>(null)

const categories = ref<string[]>([])
const versionTypes = ['官方版', '国际版', '测试版', '灰度版', '汉化版', '破解版', '修改版']

const colorPool = ['#00BFA5', '#3B82F6', '#F97316', '#EF4444', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B']

const editForm = reactive({
  id: Number(route.query.id) || 0,
  name: '',
  packageName: packageName.value || '',
  categories: [] as string[],
  version: '1.0.0',
  versionType: '',
  sizeMb: Number(sizeMb.value) || 0,
  downloadUrl: '',
  description: '',
  icon: '',
  screenshots: [] as string[],
  hasAds: false,
  requiresNetwork: true,
  hasPaidContent: false,
  isFree: true,
  price_type: 'free',
  price_amount: 0
})

const iconBgColor = computed(() => {
  const idx = (editForm.name || '').length % colorPool.length
  return colorPool[idx]
})

const iconLetter = computed(() => (editForm.name || fileName.value || 'A').charAt(0).toUpperCase())

const iconInput = ref<HTMLInputElement | null>(null)

function triggerIconUpload() {
  iconInput.value?.click()
}

async function onIconChange() {
  const file = iconInput.value?.files?.[0]
  if (!file) return
  try {
    const fd = new FormData()
    fd.append('file', file)
    const { default: request } = await import('@/utils/http')
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
    if (res?.url) {
      editForm.icon = res.url
      ElMessage.success('图标已更新')
    }
  } catch {
    ElMessage.error('图标上传失败')
  }
  if (iconInput.value) iconInput.value.value = ''
}

function goBack() {
  if (window.history.length > 1) router.back()
  else router.push('/appstore/submissions')
}

function toggleCategory(cat: string) {
  const idx = editForm.categories.indexOf(cat)
  if (idx > -1) {
    editForm.categories.splice(idx, 1)
  } else {
    editForm.categories.push(cat)
  }
}

function triggerImageUpload() {
  imageInput.value?.click()
}

async function onImagesUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
      if (res?.url) {
        editForm.screenshots.push(res.url)
      }
    } catch {
      ElMessage.error('上传失败')
    }
  }
  // Reset input to allow re-upload of same file
  if (imageInput.value) imageInput.value.value = ''
}

function removeScreenshot(index: number) {
  editForm.screenshots.splice(index, 1)
}

async function handleSubmit() {
  if (!editForm.name) {
    ElMessage.warning('请输入应用名称')
    return
  }
  try {
    const body: any = {
      id: editForm.id || undefined,
      userId: userId.value,
      userName: userName.value,
      name: editForm.name,
      packageName: editForm.packageName,
      category: JSON.stringify(editForm.categories),
      version: editForm.version,
      sizeMb: editForm.sizeMb,
      icon: editForm.icon,
      downloadUrl: editForm.downloadUrl,
      description: editForm.description,
      screenshots: editForm.screenshots,
      versionType: editForm.versionType,
      hasAds: editForm.hasAds,
      requiresNetwork: editForm.requiresNetwork,
      hasPaidContent: editForm.hasPaidContent,
      isFree: editForm.isFree,
      price_type: editForm.price_type,
      price_amount: editForm.price_amount,
      submissionStatus: 'draft'
    }
    const res: any = await fetchSaveSubmission(body)
    if (res) {
      const subId = res.id || editForm.id
      router.replace({
        path: '/appstore/submissions/success',
        query: {
          id: String(subId),
          name: editForm.name,
          packageName: editForm.packageName,
          category: editForm.categories[0] || '',
          version: editForm.version,
          sizeMb: String(editForm.sizeMb),
          icon: editForm.icon,
          draft: '1'
        }
      })
    }
  } catch (err: any) {
    ElMessage.error(err?.message || '保存失败')
  }
}

async function loadDetail() {
  if (!editForm.id) return
  try {
    const { fetchSubmissionDetail } = await import('@/api/submission')
    const d: any = await fetchSubmissionDetail(editForm.id)
    if (d) {
      editForm.name = d.name || ''
      editForm.packageName = d.packageName || ''
      try { editForm.categories = JSON.parse(d.category || '[]') } catch {
        editForm.categories = d.category ? [d.category] : []
      }
      editForm.version = d.version || '1.0.0'
      editForm.versionType = d.versionType || ''
      editForm.sizeMb = d.sizeMb || 0
      editForm.icon = d.icon || ''
      editForm.downloadUrl = d.downloadUrl || ''
      editForm.description = d.description || ''
      editForm.screenshots = d.screenshots || []
      editForm.hasAds = !!d.hasAds
      editForm.requiresNetwork = d.requiresNetwork !== undefined ? !!d.requiresNetwork : true
      editForm.hasPaidContent = !!d.hasPaidContent
      editForm.isFree = d.isFree !== undefined ? !!d.isFree : true
      editForm.price_type = d.priceType || 'free'
      editForm.price_amount = Number(d.priceAmount) || 0
    }
  } catch {}
}

const isNewVersion = ref(route.query.newVersion === '1')

onMounted(async () => {
  // Fetch categories from backend
  try {
    const cats: any = await fetchCategoryList()
    if (Array.isArray(cats)) {
      categories.value = cats.map((c: any) => c.name)
    }
  } catch {}

  if (fileName.value) {
    const baseName = fileName.value.replace(/\.apk$/i, '')
    editForm.name = baseName.replace(/[_-]v?\d[\d.]*/i, '').replace(/[_-]/g, ' ')
    const vMatch = baseName.match(/[_-]?v?(\d+\.\d+(?:\.\d+)?)/i)
    if (vMatch) editForm.version = vMatch[1]
  }
  // Read APK metadata from file-picker upload
  const qIcon = route.query.icon as string
  const qName = route.query.name as string
  const qVersion = route.query.version as string
  if (qIcon) editForm.icon = qIcon
  if (qName) editForm.name = qName
  if (qVersion) editForm.version = qVersion
  // Pre-fill from query params (from new version flow)
  const qCategory = route.query.category as string
  const qSizeMb = route.query.sizeMb as string
  if (isNewVersion.value && qName) {
    editForm.sizeMb = Number(qSizeMb) || 0
    try {
      const arr = JSON.parse(qCategory)
      editForm.categories = Array.isArray(arr) ? arr : (qCategory ? [qCategory] : [])
    } catch {
      editForm.categories = qCategory ? [qCategory] : []
    }
  }
  if (!isNewVersion.value) loadDetail()
})
</script>

<style lang="scss" scoped>
.ef-page {
  min-height: 100vh;
  background: #f5f6fa;
  padding-bottom: 100px;
}

.ef-header {
  display: flex;
  align-items: center;
  padding: 48px 16px 14px;
  background: #fff;
  gap: 12px;
}

.ef-back { cursor: pointer; flex-shrink: 0; }

.ef-title {
  font-size: 17px;
  font-weight: 600;
  color: #1a1a1a;
}

.ef-body { padding: 12px 16px 0; }

/* APK card */
.apk-card {
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 12px;
}

.apk-icon {
  width: 56px; height: 56px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; overflow: hidden;
  position: relative;
  cursor: pointer;
}

.apk-icon-letter {
  color: #fff; font-size: 26px; font-weight: 700;
}

.apk-icon-overlay {
  position: absolute; inset: 0;
  background: rgba(0,0,0,.35);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; transition: opacity .15s;
}

.apk-icon:hover .apk-icon-overlay { opacity: 1; }

.apk-icon-input { display: none; }

.apk-icon-img {
  width: 100%; height: 100%; object-fit: cover;
}

.apk-info { flex: 1; min-width: 0; }

.apk-name {
  font-size: 15px; font-weight: 600; color: #1a1a1a;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.apk-meta {
  font-size: 12px; color: #999; margin-top: 3px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

/* Form group */
.ef-group {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 12px;
}

.ef-section-title {
  font-size: 13px; color: #999;
  padding: 4px 4px 8px; font-weight: 500;
}

.ef-row {
  display: flex; align-items: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;
  min-height: 48px;

  &:last-child { border-bottom: none; }

  &.ef-row-desc {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
}

.ef-label {
  font-size: 14px; color: #333;
  width: 76px; flex-shrink: 0;
}

.ef-input {
  flex: 1; border: none; outline: none;
  font-size: 14px; color: #333;
  text-align: right; background: transparent;

  &::placeholder { color: #ccc; }
}

.ef-input-sm {
  border: none; outline: none;
  font-size: 14px; color: #333;
  text-align: right; background: transparent;
  width: 100%;

  &::placeholder { color: #ccc; }
}

.ef-value-row {
  flex: 1; display: flex; align-items: center; justify-content: flex-end; gap: 6px;
}

.ef-placeholder { color: #ccc; font-size: 14px; }

.ef-tags {
  display: flex; gap: 4px; flex-wrap: wrap; justify-content: flex-end;
  max-width: 200px;
}

.ef-tag {
  font-size: 11px; padding: 2px 8px;
  border-radius: 6px; background: #E0F7FA;
  color: #00BFA5; white-space: nowrap;
}

.ef-textarea {
  width: 100%; border: none; outline: none;
  font-size: 13px; color: #333;
  resize: none; background: transparent; font-family: inherit;

  &::placeholder { color: #ccc; }
}

/* Screenshots */
.ef-images-group { padding: 12px 12px; }

.images-grid {
  display: flex; gap: 10px; flex-wrap: wrap;
}

.img-item {
  width: 80px; height: 80px;
  border-radius: 8px;
  background-size: cover; background-position: center;
  position: relative;
}

.img-add {
  border: 1.5px dashed #d0d5dd;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  background: #fafbfc;

  &:active { background: #f0f2f5; }
}

.img-remove {
  position: absolute; top: -6px; right: -6px;
  width: 18px; height: 18px;
  border-radius: 50%; background: rgba(0,0,0,.55);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
}

/* Toggle switches */
.ef-switch-group { margin-bottom: 12px; }

.ef-switch-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;

  &:last-child { border-bottom: none; }
}

.ef-switch-label { font-size: 14px; color: #333; }

.ef-toggle {
  position: relative; display: inline-block;
  width: 44px; height: 26px;
  cursor: pointer;
}

.ef-toggle input { opacity: 0; width: 0; height: 0; }

.ef-toggle-slider {
  position: absolute; inset: 0;
  background: #e0e0e0;
  border-radius: 999px;
  transition: background .25s;

  &::before {
    content: '';
    position: absolute;
    width: 22px; height: 22px;
    left: 2px; bottom: 2px;
    background: #fff;
    border-radius: 50%;
    transition: transform .25s;
    box-shadow: 0 1px 3px rgba(0,0,0,.15);
  }
}

.ef-toggle input:checked + .ef-toggle-slider {
  background: #24D6C4;

  &::before { transform: translateX(18px); }
}

/* Bottom */
.ef-bottom {
  position: fixed; bottom: 0; left: 0; right: 0;
  padding: 12px 16px calc(12px + env(safe-area-inset-bottom));
  background: #fff;
  border-top: 1px solid #f0f0f0;
}

.ef-submit {
  width: 100%; padding: 14px;
  border: none; border-radius: 12px;
  background: linear-gradient(135deg, #24D6C4, #1BBFAE);
  color: #fff; font-size: 16px; font-weight: 500;
  cursor: pointer;
}

/* Pickers */
.picker-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,.45);
  z-index: 200;
  display: flex; align-items: flex-end;
}

.picker-panel {
  background: #fff;
  border-radius: 16px 16px 0 0;
  width: 100%;
  padding: 16px 16px calc(16px + env(safe-area-inset-bottom));
}

.picker-title {
  font-size: 16px; font-weight: 600; color: #333;
  text-align: center; margin-bottom: 16px;
  padding-bottom: 12px; border-bottom: 1px solid #f0f0f0;
}

.picker-grid {
  display: flex; flex-wrap: wrap; gap: 10px;
  margin-bottom: 16px;
}

.picker-chip {
  padding: 8px 16px; border-radius: 20px;
  font-size: 13px; color: #666;
  background: #f5f5f5; cursor: pointer;
  transition: all .15s;

  &.active {
    background: #E0F7FA; color: #00BFA5; font-weight: 500;
  }

  &:active { transform: scale(.96); }
}

.picker-item {
  padding: 14px 8px; font-size: 15px; color: #333;
  text-align: center; cursor: pointer; border-radius: 8px;

  &:active { background: #f5f6fa; }

  &.active { color: #24D6C4; font-weight: 500; }
}

.picker-confirm {
  width: 100%; padding: 12px; border: none;
  border-radius: 10px;
  background: #24D6C4; color: #fff;
  font-size: 15px; font-weight: 500; cursor: pointer;
}

.picker-cancel {
  width: 100%; padding: 12px; margin-top: 8px;
  border: none; background: #f5f5f5; color: #666;
  font-size: 14px; border-radius: 10px; cursor: pointer;
}

.ef-price-type {
  display: flex; gap: 8px;
}

.ef-price-btn {
  padding: 6px 16px; border-radius: 8px; border: 1px solid #e5e7eb;
  background: #f9fafb; color: #374151; font-size: 13px; cursor: pointer;
  transition: all 0.2s;
}

.ef-price-btn.active {
  background: #e6f9f6; border-color: #00BFA5; color: #00BFA5; font-weight: 600;
}
</style>
