<template>
  <ElRow :gutter="20" class="flex">
    <ElCol v-for="(item, index) in dataList" :key="index" :sm="12" :md="6" :lg="6">
      <div class="art-card relative flex flex-col justify-center h-35 px-5 mb-5 max-sm:mb-4">
        <span class="text-g-700 text-sm">{{ item.des }}</span>
        <ArtCountTo class="text-[26px] font-medium mt-2" :target="item.num" :duration="1300" />
        <div class="flex-c mt-1">
          <span class="text-xs text-g-600">较上周</span>
          <span class="ml-1 text-xs font-semibold" :class="[item.change.indexOf('+') === -1 ? 'text-danger' : 'text-success']">
            {{ item.change }}
          </span>
        </div>
        <div class="absolute top-0 bottom-0 right-5 m-auto size-12.5 rounded-xl flex-cc bg-theme/10">
          <ArtSvgIcon :icon="item.icon" class="text-xl text-theme" />
        </div>
      </div>
    </ElCol>
  </ElRow>
</template>

<script setup lang="ts">
  import { fetchDashboardStats } from '@/api/system-manage'

  interface CardDataItem {
    des: string
    icon: string
    startVal: number
    duration: number
    num: number
    change: string
  }

  const dataList = ref<CardDataItem[]>([
    { des: '总用户数', icon: 'ri:group-line', startVal: 0, duration: 1000, num: 0, change: '+0%' },
    { des: '在线用户', icon: 'ri:user-line', startVal: 0, duration: 1000, num: 0, change: '+0%' },
    { des: '总积分数', icon: 'ri:fire-line', startVal: 0, duration: 1000, num: 0, change: '0%' },
    { des: '可用卡密', icon: 'ri:coupon-2-line', startVal: 0, duration: 1000, num: 0, change: '0%' }
  ])

  onMounted(async () => {
    try {
      const stats = await fetchDashboardStats()
      if (stats) {
        dataList.value[0].num = stats.userCount || 0
        dataList.value[0].change = stats.weeklyNewCount ? `+${((stats.weeklyNewCount / Math.max(stats.userCount, 1)) * 100).toFixed(0)}%` : '+0%'
        dataList.value[1].num = stats.onlineCount || 0
        dataList.value[1].change = stats.weeklyActiveCount ? `+${((stats.weeklyActiveCount / Math.max(stats.onlineCount, 1)) * 100).toFixed(0)}%` : '+0%'
        dataList.value[2].num = stats.totalPoints || 0
        dataList.value[2].change = '+0%'
        dataList.value[3].num = stats.cardCount || 0
        dataList.value[3].change = '+0%'
      }
    } catch {}
  })
</script>
