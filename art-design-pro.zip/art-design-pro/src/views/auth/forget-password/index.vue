<template>
  <div class="flex w-full h-screen">
    <LoginLeftView />

    <div class="relative flex-1">
      <AuthTopBar />

      <div class="auth-right-wrap">
        <div class="form">
          <!-- Step 1: 输入邮箱 -->
          <template v-if="step === 1">
            <h3 class="title">{{ $t('forgetPassword.title') }}</h3>
            <p class="sub-title">{{ $t('forgetPassword.subTitle') }}</p>
            <div class="mt-5">
              <span class="input-label" v-if="showInputLabel">邮箱</span>
              <ElInput
                class="custom-height"
                placeholder="请输入注册邮箱"
                v-model.trim="email"
              />
            </div>

            <div style="margin-top: 15px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="sendCode"
                :loading="loading"
                v-ripple
              >
                {{ countdown > 0 ? countdown + '秒后重试' : $t('forgetPassword.submitBtnText') }}
              </ElButton>
            </div>
          </template>

          <!-- Step 2: 输入验证码和新密码 -->
          <template v-if="step === 2">
            <h3 class="title">重置密码</h3>
            <p class="sub-title">验证码已发送至 {{ email }}</p>
            <div class="mt-5">
              <span class="input-label" v-if="showInputLabel">验证码</span>
              <ElInput
                class="custom-height"
                placeholder="请输入6位验证码"
                v-model.trim="code"
              />
            </div>
            <div class="mt-4">
              <span class="input-label" v-if="showInputLabel">新密码</span>
              <ElInput
                class="custom-height"
                type="password"
                placeholder="请输入新密码（至少6位）"
                v-model.trim="newPassword"
                show-password
              />
            </div>

            <div style="margin-top: 15px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="resetPassword"
                :loading="loading"
                v-ripple
              >
                确认重置
              </ElButton>
            </div>
          </template>

          <!-- 结果 -->
          <template v-if="step === 3">
            <div class="text-center py-8">
              <div class="text-5xl mb-4" :class="resultSuccess ? 'text-green-500' : 'text-red-500'">
                {{ resultSuccess ? '\u2713' : '\u2717' }}
              </div>
              <h3 class="text-lg font-bold text-gray-800 mb-2">{{ resultMessage }}</h3>
              <p class="text-sm text-gray-400 mb-6" v-if="resultSuccess">请使用新密码登录</p>
              <ElButton
                v-if="resultSuccess"
                class="w-full custom-height"
                type="primary"
                @click="toLogin"
              >
                去登录
              </ElButton>
              <ElButton
                v-else
                class="w-full custom-height"
                @click="step = 1"
              >
                重新尝试
              </ElButton>
            </div>
          </template>

          <div v-if="step !== 3" style="margin-top: 15px">
            <ElButton class="w-full custom-height" plain @click="toLogin">
              {{ $t('forgetPassword.backBtnText') }}
            </ElButton>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { ref } from 'vue'
  import request from '@/utils/http'
  import { useRouter } from 'vue-router'

  defineOptions({ name: 'ForgetPassword' })

  const router = useRouter()
  const showInputLabel = ref(false)

  const step = ref(1)
  const email = ref('')
  const code = ref('')
  const newPassword = ref('')
  const loading = ref(false)
  const countdown = ref(0)
  const resultSuccess = ref(false)
  const resultMessage = ref('')
  let countdownTimer: any = null

  const sendCode = async () => {
    if (!email.value) {
      resultSuccess.value = false
      resultMessage.value = '请输入邮箱地址'
      step.value = 3
      return
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
      resultSuccess.value = false
      resultMessage.value = '请输入有效的邮箱地址'
      step.value = 3
      return
    }
    loading.value = true
    try {
      await request.post({ url: '/api/email/send-code', data: { email: email.value, type: 'password_reset' } })
      step.value = 2
      countdown.value = 60
      countdownTimer = setInterval(() => {
        countdown.value--
        if (countdown.value <= 0) {
          clearInterval(countdownTimer)
          countdownTimer = null
        }
      }, 1000)
    } catch (e: any) {
      resultSuccess.value = false
      resultMessage.value = e?.message || e?.msg || '发送失败，请检查邮件服务配置'
      step.value = 3
    }
    loading.value = false
  }

  const resetPassword = async () => {
    if (!code.value) {
      resultSuccess.value = false
      resultMessage.value = '请输入验证码'
      step.value = 3
      return
    }
    if (!newPassword.value || newPassword.value.length < 6) {
      resultSuccess.value = false
      resultMessage.value = '新密码至少6位'
      step.value = 3
      return
    }
    loading.value = true
    try {
      await request.post({
        url: '/api/auth/reset-password',
        data: { email: email.value, code: code.value, password: newPassword.value }
      })
      resultSuccess.value = true
      resultMessage.value = '密码重置成功'
      step.value = 3
    } catch (e: any) {
      resultSuccess.value = false
      resultMessage.value = e?.message || e?.msg || '重置失败，请重试'
      step.value = 3
    }
    loading.value = false
  }

  const toLogin = () => {
    if (countdownTimer) clearInterval(countdownTimer)
    router.push({ name: 'AppStoreLogin' })
  }
</script>

<style scoped>
  @import '../login/style.css';
</style>
