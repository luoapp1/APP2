<!-- 注册页面 -->
<template>
  <div class="flex w-full h-screen">
    <LoginLeftView />

    <div class="relative flex-1">
      <AuthTopBar />

      <div class="auth-right-wrap">
        <div class="form">
          <h3 class="title">{{ $t('register.title') }}</h3>
          <p class="sub-title">{{ $t('register.subTitle') }}</p>
          <ElForm
            class="mt-3"
            ref="formRef"
            :model="formData"
            :rules="rules"
            label-position="top"
            :key="formKey"
          >
            <ElFormItem prop="username">
              <ElInput
                class="custom-height"
                v-model.trim="formData.username"
                :placeholder="$t('register.placeholder.username')"
              />
            </ElFormItem>

            <ElFormItem v-if="verifyType === 'email'" prop="email">
              <ElInput
                class="custom-height"
                v-model.trim="formData.email"
                placeholder="邮箱地址"
              />
            </ElFormItem>

            <ElFormItem v-if="verifyType === 'email'" prop="emailCode">
              <div class="flex gap-2">
                <ElInput
                  class="custom-height flex-1"
                  v-model.trim="formData.emailCode"
                  placeholder="邮箱验证码"
                />
                <ElButton
                  class="custom-height !w-32 shrink-0"
                  :disabled="emailCountdown > 0"
                  @click="sendEmailCode"
                  :loading="emailSending"
                >
                  {{ emailCountdown > 0 ? emailCountdown + 's' : '发送验证码' }}
                </ElButton>
              </div>
            </ElFormItem>

            <ElFormItem v-if="verifyType === 'mobile'" prop="phone">
              <ElInput
                class="custom-height"
                v-model.trim="formData.phone"
                placeholder="手机号码"
              />
            </ElFormItem>

            <ElFormItem v-if="verifyType === 'mobile'" prop="smsCode">
              <div class="flex gap-2">
                <ElInput
                  class="custom-height flex-1"
                  v-model.trim="formData.smsCode"
                  placeholder="短信验证码"
                />
                <ElButton
                  class="custom-height !w-32 shrink-0"
                  :disabled="smsCountdown > 0"
                  @click="sendSmsCode"
                  :loading="smsSending"
                >
                  {{ smsCountdown > 0 ? smsCountdown + 's' : '发送验证码' }}
                </ElButton>
              </div>
            </ElFormItem>

            <ElFormItem prop="password">
              <ElInput
                class="custom-height"
                v-model.trim="formData.password"
                :placeholder="passwordPlaceholder"
                type="password"
                autocomplete="off"
                show-password
              />
            </ElFormItem>

            <ElFormItem prop="confirmPassword">
              <ElInput
                class="custom-height"
                v-model.trim="formData.confirmPassword"
                :placeholder="$t('register.placeholder.confirmPassword')"
                type="password"
                autocomplete="off"
                show-password
              />
            </ElFormItem>

            <ElFormItem prop="inviteCode" v-if="inviteRequired">
              <ElInput
                class="custom-height"
                v-model.trim="formData.inviteCode"
                placeholder="邀请码（必填）"
              />
            </ElFormItem>

            <ElFormItem prop="inviteCode" v-else>
              <ElInput
                class="custom-height"
                v-model.trim="formData.inviteCode"
                placeholder="邀请码（选填）"
              />
            </ElFormItem>

            <ElFormItem prop="agreement">
              <ElCheckbox v-model="formData.agreement">
                {{ $t('register.agreeText') }}
                <RouterLink
                  style="color: var(--theme-color); text-decoration: none"
                  to="/privacy-policy"
                  >{{ $t('register.privacyPolicy') }}</RouterLink
                >
              </ElCheckbox>
            </ElFormItem>

            <div style="margin-top: 15px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="register"
                :loading="loading"
                v-ripple
              >
                {{ $t('register.submitBtnText') }}
              </ElButton>
            </div>

            <div class="mt-5 text-sm text-g-600">
              <span>{{ $t('register.hasAccount') }}</span>
              <RouterLink class="text-theme" :to="{ name: 'AppStoreLogin' }">{{
                $t('register.toLogin')
              }}</RouterLink>
            </div>
          </ElForm>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useI18n } from 'vue-i18n'
  import type { FormInstance, FormRules } from 'element-plus'
  import { fetchRegister } from '@/api/auth'
  import { fetchSendEmailCode } from '@/api/email'
  import request from '@/utils/http'

  defineOptions({ name: 'Register' })

  interface RegisterForm {
    username: string
    password: string
    confirmPassword: string
    inviteCode: string
    agreement: boolean
    email: string
    emailCode: string
    phone: string
    smsCode: string
  }

  const { t, locale } = useI18n()
  const router = useRouter()
  const formRef = ref<FormInstance>()

  const loading = ref(false)
  const formKey = ref(0)
  const inviteRequired = ref(false)
  const verifyType = ref<'none' | 'email' | 'mobile'>('none')
  const usernameMin = ref(3)
  const passwordMin = ref(6)

  const passwordPlaceholder = computed(() => {
    return t('register.placeholder.password') + '（至少' + passwordMin.value + '位）'
  })

  const emailCountdown = ref(0)
  const emailSending = ref(false)
  const smsCountdown = ref(0)
  const smsSending = ref(false)
  let countdownTimer: ReturnType<typeof setInterval> | null = null

  watch(locale, () => {
    formKey.value++
  })

  onMounted(async () => {
    try {
      const { fetchInviteConfig } = await import('@/api/invite')
      const config: any = await fetchInviteConfig()
      inviteRequired.value = config?.register_invite_required === 'true'
    } catch { inviteRequired.value = false }

    try {
      const cfgRes: any = await request.get({ url: '/api/sys-config/list' })
      if (cfgRes && Array.isArray(cfgRes)) {
        const map: Record<string, string> = {}
        for (const item of cfgRes) map[item.config_key] = String(item.config_value)
        if (map.register_verify_type) verifyType.value = map.register_verify_type as any
        if (map.register_username_min) usernameMin.value = parseInt(map.register_username_min) || 3
        if (map.register_password_min) passwordMin.value = parseInt(map.register_password_min) || 6
      }
    } catch {}
  })

  onUnmounted(() => {
    if (countdownTimer) clearInterval(countdownTimer)
  })

  const formData = reactive<RegisterForm>({
    username: '',
    password: '',
    confirmPassword: '',
    inviteCode: '',
    agreement: false,
    email: '',
    emailCode: '',
    phone: '',
    smsCode: ''
  })

  const validatePassword = (_rule: any, value: string, callback: (error?: Error) => void) => {
    if (!value) {
      callback(new Error(t('register.placeholder.password')))
      return
    }
    if (formData.confirmPassword) formRef.value?.validateField('confirmPassword')
    callback()
  }

  const validateConfirmPassword = (
    _rule: any,
    value: string,
    callback: (error?: Error) => void
  ) => {
    if (!value) {
      callback(new Error(t('register.rule.confirmPasswordRequired')))
      return
    }
    if (value !== formData.password) {
      callback(new Error(t('register.rule.passwordMismatch')))
      return
    }
    callback()
  }

  const validateAgreement = (_rule: any, value: boolean, callback: (error?: Error) => void) => {
    if (!value) {
      callback(new Error(t('register.rule.agreementRequired')))
      return
    }
    callback()
  }

  const rules = computed<FormRules<RegisterForm>>(() => {
    const base: FormRules<RegisterForm> = {
      username: [
        { required: true, message: t('register.placeholder.username'), trigger: 'blur' },
        {
          min: usernameMin.value,
          max: 20,
          message: `用户名长度需在${usernameMin.value}-20个字符之间`,
          trigger: 'blur'
        }
      ],
      password: [
        { required: true, validator: validatePassword, trigger: 'blur' },
        { min: passwordMin.value, message: `密码长度不能少于${passwordMin.value}个字符`, trigger: 'blur' }
      ],
      confirmPassword: [{ required: true, validator: validateConfirmPassword, trigger: 'blur' }],
      agreement: [{ validator: validateAgreement, trigger: 'change' }],
      ...(inviteRequired.value ? { inviteCode: [{ required: true, message: '请输入邀请码', trigger: 'blur' }] } : {})
    }

    if (verifyType.value === 'email') {
      base.email = [{ required: true, message: '请输入邮箱地址', trigger: 'blur' }, { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }]
      base.emailCode = [{ required: true, message: '请输入邮箱验证码', trigger: 'blur' }]
    }

    if (verifyType.value === 'mobile') {
      base.phone = [{ required: true, message: '请输入手机号码', trigger: 'blur' }]
      base.smsCode = [{ required: true, message: '请输入短信验证码', trigger: 'blur' }]
    }

    return base
  })

  function startCountdown(field: 'email' | 'sms') {
    if (field === 'email') emailCountdown.value = 60
    else smsCountdown.value = 60
    countdownTimer = setInterval(() => {
      if (field === 'email') {
        if (emailCountdown.value > 0) emailCountdown.value--
        else clearInterval(countdownTimer!)
      } else {
        if (smsCountdown.value > 0) smsCountdown.value--
        else clearInterval(countdownTimer!)
      }
    }, 1000)
  }

  const sendEmailCode = async () => {
    if (!formData.email) {
      ElMessage.warning('请先输入邮箱地址')
      return
    }
    emailSending.value = true
    try {
      await fetchSendEmailCode(formData.email, 'register')
      startCountdown('email')
    } catch {} finally { emailSending.value = false }
  }

  const sendSmsCode = async () => {
    if (!formData.phone) {
      ElMessage.warning('请先输入手机号码')
      return
    }
    smsSending.value = true
    try {
      await request.post({ url: '/api/sms/send-code', data: { phone: formData.phone, type: 'register' } })
      startCountdown('sms')
    } catch {} finally { smsSending.value = false }
  }

  const register = async () => {
    if (!formRef.value) return
    try {
      await formRef.value.validate()
      loading.value = true

      const payload: any = {
        username: formData.username,
        password: formData.password,
        inviteCode: formData.inviteCode || undefined
      }

      if (verifyType.value === 'email') {
        payload.email = formData.email
        payload.emailCode = formData.emailCode
      }
      if (verifyType.value === 'mobile') {
        payload.phone = formData.phone
        payload.smsCode = formData.smsCode
      }

      await fetchRegister(payload)
      ElMessage.success(t('register.success') || '注册成功')
      setTimeout(() => {
        router.push({ name: 'AppStoreLogin' })
      }, 1500)
    } catch (error: any) {
      // HTTP 拦截器已统一显示错误消息
    } finally { loading.value = false }
  }

  const toLogin = () => {
    router.push({ name: 'AppStoreLogin' })
  }
</script>

<style scoped>
  @import '../login/style.css';
</style>
