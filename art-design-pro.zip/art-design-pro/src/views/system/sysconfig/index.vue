<!-- 系统配置页面 -->
<template>
  <div class="sysconfig-page art-full-height">
    <ElRow :gutter="20">
      <ElCol :span="24">
        <ElCard class="art-table-card" header="系统参数配置">
          <ElForm label-width="160px" :disabled="saving">
            <ElFormItem label="系统日志记录">
              <ElSwitch v-model="form.system_log_enabled" active-text="开启" inactive-text="关闭" />
              <div class="form-tip">关闭后系统将不再记录操作日志</div>
            </ElFormItem>
            <ElDivider />
            <ElFormItem label="系统通知操作者">
              <ElSelect
                v-model="form.system_operator_id"
                filterable
                remote
                reserve-keyword
                placeholder="选择或搜索用户账号"
                :remote-method="searchUsers"
                :loading="userSearching"
                clearable
                style="width: 260px"
              >
                <ElOption
                  v-for="u in userOptions"
                  :key="u.id"
                  :label="u.nickname || u.username"
                  :value="u.id"
                >
                  <span style="float:left">{{ u.nickname || u.username }}</span>
                  <span style="float:right;color:#909399;font-size:12px">{{ u.username }}</span>
                </ElOption>
              </ElSelect>
              <div class="form-tip">选择用作系统通知发送者的账号，未选择时显示"系统"</div>
            </ElFormItem>
            <ElDivider />
            <ElFormItem label="用户生成邀请码">
              <ElSwitch v-model="form.invite_user_enabled" active-text="允许" inactive-text="禁止" />
              <div class="form-tip">允许普通用户自行生成邀请码</div>
            </ElFormItem>
            <ElFormItem label="注册必须邀请码">
              <ElSwitch v-model="form.register_invite_required" active-text="是" inactive-text="否" />
              <div class="form-tip">开启后新用户注册必须输入有效邀请码</div>
            </ElFormItem>
            <ElFormItem>
              <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
            </ElFormItem>
          </ElForm>
        </ElCard>
      </ElCol>

      <ElCol :span="24">
        <ElCard class="art-table-card" header="聊天室创建权限">
          <ElForm label-width="160px" :disabled="saving">
            <ElFormItem label="启用条件限制">
              <ElSwitch v-model="chatRoomForm.enabled" active-text="开启" inactive-text="关闭" />
              <div class="form-tip">关闭时不限制，所有用户均可创建聊天室；开启后按下方条件校验</div>
            </ElFormItem>
            <template v-if="chatRoomForm.enabled">
              <ElDivider />
              <ElFormItem label="最低经验等级">
                <ElInputNumber v-model="chatRoomForm.min_experience_level" :min="0" :max="999" :step="1" />
                <div class="form-tip">设为 0 表示不限制此条件</div>
              </ElFormItem>
              <ElFormItem label="最低会员等级">
                <ElInputNumber v-model="chatRoomForm.min_membership_level" :min="0" :max="999" :step="1" />
                <div class="form-tip">设为 0 表示不限制此条件</div>
              </ElFormItem>
              <ElFormItem label="最低发帖数">
                <ElInputNumber v-model="chatRoomForm.min_post_count" :min="0" :max="99999" :step="1" />
                <div class="form-tip">设为 0 表示不限制此条件</div>
              </ElFormItem>
              <ElFormItem label="最低积分">
                <ElInputNumber v-model="chatRoomForm.min_points" :min="0" :max="999999" :step="1" />
                <div class="form-tip">设为 0 表示不限制此条件</div>
              </ElFormItem>
            </template>
            <ElDivider />
            <ElFormItem>
              <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
            </ElFormItem>
          </ElForm>
        </ElCard>
      </ElCol>
    </ElRow>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'

defineOptions({ name: 'SysConfig' })

const saving = ref(false)

const form = reactive({
  system_log_enabled: true,
  invite_user_enabled: false,
  register_invite_required: false,
  system_operator_id: null as number | null
})

const chatRoomForm = reactive({
  enabled: false,
  min_experience_level: 0,
  min_membership_level: 0,
  min_post_count: 0,
  min_points: 0
})

const userOptions = ref<any[]>([])
const userSearching = ref(false)

async function searchUsers(query: string) {
  if (!query || query.length < 1) { userOptions.value = []; return }
  userSearching.value = true
  try {
    const res: any = await request.get({ url: '/api/community/user/search', params: { keyword: query } })
    userOptions.value = res || []
    if (form.system_operator_id && !userOptions.value.find((u: any) => u.id === form.system_operator_id)) {
      const existing = await request.get({ url: `/api/user/${form.system_operator_id}` })
      if (existing) {
        userOptions.value.unshift({ id: existing.id, username: existing.username, nickname: existing.nickname || existing.username, avatar: existing.avatar })
      }
    }
  } catch {}
  userSearching.value = false
}

onMounted(async () => {
  const res: any = await request.get({ url: '/api/sys-config/list' })
  if (res) {
    for (const item of res) {
      if (item.config_key === 'system_log_enabled') {
        form.system_log_enabled = item.config_value === 'true'
      } else if (item.config_key === 'invite_user_enabled') {
        form.invite_user_enabled = item.config_value === 'true'
      } else if (item.config_key === 'register_invite_required') {
        form.register_invite_required = item.config_value === 'true'
      } else if (item.config_key === 'system_operator_id') {
        form.system_operator_id = parseInt(item.config_value) || null
      } else if (item.config_key === 'chat_room_create_condition') {
        try {
          const cfg = JSON.parse(item.config_value)
          chatRoomForm.enabled = cfg.enabled || false
          chatRoomForm.min_experience_level = cfg.min_experience_level || 0
          chatRoomForm.min_membership_level = cfg.min_membership_level || 0
          chatRoomForm.min_post_count = cfg.min_post_count || 0
          chatRoomForm.min_points = cfg.min_points || 0
        } catch {}
      }
    }
  }
  if (form.system_operator_id) {
    try {
      const u: any = await request.get({ url: `/api/user/${form.system_operator_id}` })
      if (u) {
        userOptions.value = [{ id: u.id, username: u.username, nickname: u.nickname || u.username, avatar: u.avatar }]
      }
    } catch {}
  }
})

async function saveConfig() {
  saving.value = true
  try {
    const configs = [
      { config_key: 'system_log_enabled', config_value: String(form.system_log_enabled), description: '系统日志开关' },
      { config_key: 'invite_user_enabled', config_value: String(form.invite_user_enabled), description: '用户生成邀请码开关' },
      { config_key: 'register_invite_required', config_value: String(form.register_invite_required), description: '注册必须邀请码' },
      { config_key: 'system_operator_id', config_value: String(form.system_operator_id || ''), description: '系统通知默认操作者(用户ID)' },
      { config_key: 'chat_room_create_condition', config_value: JSON.stringify({
        enabled: chatRoomForm.enabled,
        min_experience_level: chatRoomForm.min_experience_level,
        min_membership_level: chatRoomForm.min_membership_level,
        min_post_count: chatRoomForm.min_post_count,
        min_points: chatRoomForm.min_points
      }), description: '聊天室创建条件配置' }
    ]
    await request.post({ url: '/api/sys-config/save', data: { configs } })
    ElMessage.success('配置保存成功')
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.form-tip { font-size: 12px; color: #909399; margin-top: 4px; }
.art-table-card { margin-bottom: 20px; }
</style>
