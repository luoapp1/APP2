<!-- 系统配置页面 -->
<template>
  <div class="sysconfig-page art-full-height">
    <ElRow :gutter="20">
      <ElCol :span="16">
        <ElCard header="系统参数配置">
          <ElForm label-width="160px" :disabled="saving">
            <ElFormItem label="系统日志记录">
              <ElSwitch v-model="form.system_log_enabled" active-text="开启" inactive-text="关闭" />
              <div class="form-tip">关闭后系统将不再记录操作日志</div>
            </ElFormItem>
            <ElDivider />
            <ElFormItem label="用户生成邀请码">
              <ElSwitch v-model="form.invite_user_enabled" active-text="允许" inactive-text="禁止" />
              <div class="form-tip">允许普通用户自行生成邀请码</div>
            </ElFormItem>
            <ElFormItem label="用户最大邀请码数">
              <ElInputNumber v-model="form.invite_user_max" :min="1" :max="100" :step="1" />
              <span class="form-tip" style="margin-left:8px">每位用户同时可拥有的有效邀请码上限</span>
            </ElFormItem>
            <ElFormItem label="注册必须邀请码">
              <ElSwitch v-model="form.register_invite_required" active-text="是" inactive-text="否" />
              <div class="form-tip">开启后新用户注册必须输入有效邀请码</div>
            </ElFormItem>
            <ElFormItem>
              <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
            </ElFormItem>
          </ElForm>
        </ElCard>
      </ElCol>
      <ElCol :span="8">
        <ElCard header="配置说明">
          <div class="help-text">
            <h4>系统日志记录</h4>
            <p>记录管理员和用户的关键操作，包括登录、创建、修改、删除、审批等。可在系统日志页面查看。</p>
            <h4 style="margin-top:16px">邀请码配置</h4>
            <p>控制邀请码生成权限和使用策略。管理员始终可以生成邀请码。</p>
            <p>用户生成邀请码功能需要先开启才能使用。</p>
          </div>
        </ElCard>
      </ElCol>
    </ElRow>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'

defineOptions({ name: 'SysConfig' })

const saving = ref(false)

const form = reactive({
  system_log_enabled: true,
  invite_user_enabled: false,
  invite_user_max: 5,
  register_invite_required: false
})

onMounted(async () => {
  const res: any = await request.get({ url: '/sys-config/list' })
  if (res) {
    for (const item of res) {
      if (item.config_key === 'system_log_enabled') {
        form.system_log_enabled = item.config_value === 'true'
      } else if (item.config_key === 'invite_user_enabled') {
        form.invite_user_enabled = item.config_value === 'true'
      } else if (item.config_key === 'invite_user_max') {
        form.invite_user_max = parseInt(item.config_value) || 5
      } else if (item.config_key === 'register_invite_required') {
        form.register_invite_required = item.config_value === 'true'
      }
    }
  }
})

async function saveConfig() {
  saving.value = true
  try {
    const configs = [
      { config_key: 'system_log_enabled', config_value: String(form.system_log_enabled), description: '系统日志开关' },
      { config_key: 'invite_user_enabled', config_value: String(form.invite_user_enabled), description: '用户生成邀请码开关' },
      { config_key: 'invite_user_max', config_value: String(form.invite_user_max), description: '用户最大可生成邀请码数' },
      { config_key: 'register_invite_required', config_value: String(form.register_invite_required), description: '注册必须邀请码' }
    ]
    await request.post({ url: '/sys-config/save', data: { configs } })
    ElMessage.success('配置保存成功')
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.help-text { color: #606266; line-height: 1.8; }
.help-text h4 { margin: 8px 0 4px; }
.help-text p { margin: 2px 0; font-size: 13px; color: #909399; }
.form-tip { font-size: 12px; color: #909399; margin-top: 4px; }
</style>
