<template>
  <ElDialog
    v-model="dialogVisible"
    :title="dialogType === 'add' ? '添加用户' : '编辑用户'"
    width="40%"
    align-center
  >
    <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
      <ElFormItem label="用户名" prop="username">
        <ElInput v-model="formData.username" placeholder="请输入用户名" />
      </ElFormItem>
      <ElFormItem label="手机号" prop="phone">
        <ElInput v-model="formData.phone" placeholder="请输入手机号" />
      </ElFormItem>
      <ElFormItem label="性别" prop="gender">
        <ElSelect v-model="formData.gender">
          <ElOption label="男" value="男" />
          <ElOption label="女" value="女" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem label="角色" prop="role">
        <ElSelect v-model="formData.role" multiple>
          <ElOption
            v-for="role in roleList"
            :key="role.roleCode"
            :value="role.roleCode"
            :label="role.roleName"
          />
        </ElSelect>
      </ElFormItem>

      <ElDivider content-position="left">会员及积分信息</ElDivider>

      <ElFormItem label="头像">
        <div style="display: flex; align-items: center; gap: 12px;">
          <ElImage v-if="formData.avatar" :src="$fixImgUrl(formData.avatar)" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;" />
          <img v-else src="@imgs/user/avatar.webp" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;" />
          <ElInput v-model="formData.avatar" placeholder="头像URL" style="flex: 1;" />
        </div>
      </ElFormItem>
      <ElFormItem label="背景图">
        <ElInput v-model="formData.bgUrl" placeholder="背景图URL" />
      </ElFormItem>
      <ElFormItem label="用户积分">
        <ElInputNumber v-model="formData.points" :min="0" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="昵称" prop="nickname">
        <ElInput v-model="formData.nickname" placeholder="请输入昵称" maxlength="50" />
      </ElFormItem>
      <ElFormItem label="QQ">
        <ElInput v-model="formData.qq" placeholder="请输入QQ号" />
      </ElFormItem>
      <ElFormItem label="邮箱" prop="email">
        <ElInput v-model="formData.email" placeholder="请输入邮箱" />
      </ElFormItem>
      <ElFormItem label="签名">
        <ElInput v-model="formData.signature" placeholder="请输入个人签名" maxlength="100" />
      </ElFormItem>
      <ElFormItem label="个人介绍" prop="bio">
        <ElInput v-model="formData.bio" type="textarea" :rows="2" placeholder="请输入个人介绍" maxlength="200" />
      </ElFormItem>
      <ElFormItem label="余额" prop="balance">
        <ElInputNumber v-model="formData.balance" :min="0" :precision="2" style="width:100%" placeholder="请输入余额" />
      </ElFormItem>
      <ElFormItem label="经验值" prop="experience">
        <ElInputNumber v-model="formData.experience" :min="0" style="width:100%" placeholder="请输入经验值" />
      </ElFormItem>
      <ElFormItem label="会员等级">
        <ElSelect v-model="formData.level" clearable placeholder="不修改则保持原等级">
          <ElOption
            v-for="lv in membershipLevels"
            :key="lv.id"
            :value="lv.id"
            :label="lv.name"
          />
        </ElSelect>
      </ElFormItem>
      <ElFormItem label="会员到期时间">
        <ElDatePicker
          v-model="formData.expireTime"
          type="datetime"
          placeholder="选择到期时间，留空为永久"
          value-format="YYYY-MM-DD HH:mm:ss"
          style="width: 100%"
        />
      </ElFormItem>

      <ElDivider content-position="left">安全设置</ElDivider>

      <ElFormItem label="修改密码">
        <ElInput
          v-model="formData.password"
          type="password"
          placeholder="留空则不修改密码"
          show-password
        />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">提交</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import { fetchGetRoleList } from '@/api/system-manage'
  import { fetchGetMembershipLevelList } from '@/api/operation'
  import type { FormInstance, FormRules } from 'element-plus'
  import { ElImage } from 'element-plus'

  interface Props {
    visible: boolean
    type: string
    userData?: Partial<Api.SystemManage.UserListItem>
  }

  interface Emits {
    (e: 'update:visible', value: boolean): void
    (e: 'submit', data: Record<string, unknown>): void
  }

  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()

  const roleList = ref<Array<{ roleName: string; roleCode: string }>>([])

  const loadRoles = async () => {
    try {
      const data = await fetchGetRoleList({ current: 1, size: 100 })
      if (data && (data as any).records) roleList.value = (data as any).records
    } catch {
      roleList.value = [
        { roleName: '超级管理员', roleCode: 'R_SUPER' },
        { roleName: '管理员', roleCode: 'R_ADMIN' },
        { roleName: '普通用户', roleCode: 'R_USER' }
      ]
    }
  }
  loadRoles()
  const membershipLevels = ref<Array<{ id: number; name: string }>>([])

  const loadLevels = async () => {
    try {
      const data = await fetchGetMembershipLevelList({})
      if (data && (data as any).records) membershipLevels.value = (data as any).records
    } catch {
      membershipLevels.value = [
        { id: 0, name: '普通会员' },
        { id: 1, name: '黄金会员' },
        { id: 2, name: '钻石会员' },
        { id: 3, name: '至尊会员' }
      ]
    }
  }
  loadLevels()

  const dialogVisible = computed({
    get: () => props.visible,
    set: (value) => emit('update:visible', value)
  })

  const dialogType = computed(() => props.type)

  const formRef = ref<FormInstance>()

  const formData = reactive({
    username: '',
    phone: '',
    gender: '男',
    role: [] as string[],
    avatar: '',
    bgUrl: '',
    points: 0,
    nickname: '',
    qq: '',
    email: '',
    signature: '',
    bio: '',
    balance: 0,
    experience: 0,
    level: 0,
    expireTime: '',
    password: ''
  })

  const rules: FormRules = {
    username: [
      { required: true, message: '请输入用户名', trigger: 'blur' },
      { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
    ],
    phone: [
      { required: true, message: '请输入手机号', trigger: 'blur' },
      { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号格式', trigger: 'blur' }
    ],
    gender: [{ required: true, message: '请选择性别', trigger: 'blur' }],
    role: [{ required: true, message: '请选择角色', trigger: 'blur' }]
  }

  const initFormData = () => {
    const isEdit = props.type === 'edit' && props.userData
    const row = props.userData

    Object.assign(formData, {
      username: isEdit && row ? row.userName || '' : '',
      phone: isEdit && row ? row.userPhone || '' : '',
      gender: isEdit && row ? row.userGender || '男' : '男',
      role: isEdit && row ? (Array.isArray(row.userRoles) ? row.userRoles : []) : [],
      avatar: isEdit && row ? (row.avatar || '') : '',
      bgUrl: isEdit && row ? (row.bgUrl || row.bg_url || '') : '',
      points: isEdit && row ? (row.points ?? 0) : 0,
      nickname: isEdit && row ? (row.nickName || '') : '',
      qq: isEdit && row ? (row.qq || '') : '',
      email: isEdit && row ? (row.userEmail || '') : '',
      signature: isEdit && row ? (row.signature || '') : '',
      bio: isEdit && row ? (row.bio || '') : '',
      balance: isEdit && row ? (row.balance ?? 0) : 0,
      experience: isEdit && row ? (row.experience ?? 0) : 0,
      level: isEdit && row ? (row.level ?? 0) : 0,
      expireTime: isEdit && row ? (row.expireTime || '') : '',
      password: ''
    })
  }

  watch(
    () => [props.visible, props.type, props.userData],
    ([visible]) => {
      if (visible) {
        initFormData()
        nextTick(() => {
          formRef.value?.clearValidate()
        })
      }
    },
    { immediate: true }
  )

  const handleSubmit = async () => {
    if (!formRef.value) return

      await formRef.value.validate((valid) => {
      if (valid) {
        const data: Record<string, unknown> = {
          username: formData.username,
          phone: formData.phone,
          gender: formData.gender,
          role: formData.role,
          avatar: formData.avatar,
          bgUrl: formData.bgUrl,
          points: formData.points,
          nickname: formData.nickname,
          qq: formData.qq,
          email: formData.email,
          signature: formData.signature,
          bio: formData.bio,
          balance: formData.balance,
          experience: formData.experience,
          level_id: formData.level,
          expireTime: formData.expireTime
        }
        if (dialogType.value === 'edit') {
          const row = props.userData
          data.id = row?.id
          data.password = formData.password
        }
        dialogVisible.value = false
        emit('submit', data)
      }
    })
  }
</script>
