<template>
  <div class="delete-review-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader :loading="loading" @refresh="loadData" />
      <ArtTable :loading="loading" :data="tableData" :columns="columns" :pagination="pagination" @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange">
      </ArtTable>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, h } from 'vue'
import request from '@/utils/http'
import { ElTag, ElMessage, ElButton, ElMessageBox, ElInput } from 'element-plus'

defineOptions({ name: 'DeleteReview' })

const loading = ref(false)
const tableData = ref<any[]>([])
const pagination = reactive({ current: 1, size: 20, total: 0 })

const columns = [
  { type: 'index', width: 60, label: '序号' },
  { prop: 'id', label: 'ID', width: 70 },
  { prop: 'username', label: '用户名', width: 140 },
  { prop: 'status', label: '状态', width: 100, formatter: (row: any) => {
    const map: Record<string, any> = { pending: { type: 'warning', text: '待审核' }, approved: { type: 'success', text: '已通过' }, rejected: { type: 'danger', text: '已拒绝' } }
    const c = map[row.status] || { type: 'info', text: row.status }
    return h(ElTag, { type: c.type }, () => c.text)
  }},
  { prop: 'create_time', label: '申请时间', width: 170 },
  { prop: 'update_time', label: '处理时间', width: 170 },
  { prop: 'admin_note', label: '备注' },
  { prop: 'operation', label: '操作', width: 200, fixed: 'right', formatter: (row: any) => {
    if (row.status !== 'pending') return h('span', { style: { color: '#ccc' } }, '已处理')
    return h('div', { style: { display: 'flex', gap: '8px' } }, [
      h(ElButton, { type: 'success', size: 'small', onClick: () => handleReview(row.id, 'approved') }, () => '通过'),
      h(ElButton, { type: 'danger', size: 'small', onClick: () => handleReject(row.id) }, () => '拒绝')
    ])
  }}
]

const loadData = async () => {
  loading.value = true
  try {
    const data: any = await request.get({ url: `/api/user/delete-requests?page=${pagination.current}&size=${pagination.size}` })
    tableData.value = data?.records || data?.list || data || []
    pagination.total = data?.total || tableData.value.length
  } catch (e) { console.error(e) }
  finally { loading.value = false }
}

const handleSizeChange = (v: number) => { pagination.size = v; loadData() }
const handleCurrentChange = (v: number) => { pagination.current = v; loadData() }

const handleReview = async (id: number, status: string) => {
  try {
    await request.post({ url: `/api/user/delete-request/${id}/review`, data: { status } })
    ElMessage.success(status === 'approved' ? '已通过注销申请' : '已拒绝注销申请')
    loadData()
  } catch { ElMessage.error('操作失败') }
}

const handleReject = (id: number) => {
  ElMessageBox.prompt('请输入拒绝原因', '拒绝注销', { confirmButtonText: '确定', cancelButtonText: '取消' }).then(async ({ value }) => {
    try {
      await request.post({ url: `/api/user/delete-request/${id}/review`, data: { status: 'rejected', admin_note: value || '' } })
      ElMessage.success('已拒绝注销申请')
      loadData()
    } catch { ElMessage.error('操作失败') }
  }).catch(() => {})
}

onMounted(() => loadData())
</script>
