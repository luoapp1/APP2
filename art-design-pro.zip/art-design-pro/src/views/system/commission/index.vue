<template>
  <div class="commission-page art-full-height">
    <ElTabs v-model="activeTab" type="border-card">
      <ElTabPane label="返佣规则" name="rules">
        <ElCard class="art-table-card">
          <template #header>
            <div class="card-header">
              <span>返佣规则管理</span>
              <ElButton type="primary" @click="showRuleForm(null)">新增规则</ElButton>
            </div>
          </template>
          <ElTable :data="rules" v-loading="loading" stripe>
            <ElTableColumn prop="id" label="ID" width="60" />
            <ElTableColumn prop="name" label="规则名称" minWidth="140" />
            <ElTableColumn prop="order_type" label="订单类型" width="100">
              <template #default="{ row }">
                <ElTag size="small">{{ row.order_type === 'all' ? '全部' : row.order_type }}</ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="rate" label="返佣比例(%)" width="100" />
            <ElTableColumn prop="user_level_name" label="适用等级" width="120">
              <template #default="{ row }">
                {{ row.user_level_name || (row.user_id ? '用户专属' : '全局') }}
              </template>
            </ElTableColumn>
            <ElTableColumn label="状态" width="80">
              <template #default="{ row }">
                <ElTag :type="row.status==='1'?'success':'info'" size="small">{{ row.status==='1'?'启用':'禁用' }}</ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn label="操作" width="140">
              <template #default="{ row }">
                <ElButton size="small" link type="primary" @click="showRuleForm(row)">编辑</ElButton>
                <ElButton size="small" link type="danger" @click="delRule(row)">删除</ElButton>
              </template>
            </ElTableColumn>
          </ElTable>
        </ElCard>
      </ElTabPane>

      <ElTabPane label="返佣记录" name="records">
        <ArtTable :loading="recLoading" :data="records" :columns="recColumns" :pagination="{ currentPage: recPage, pageSize: recPageSize, total: recTotal }"
          @pagination:size-change="handleRecSizeChange" @pagination:current-change="handleRecCurrentChange" />
      </ElTabPane>

      <ElTabPane label="提现审核" name="withdraw">
        <ElCard class="art-table-card">
          <template #header>
            <div class="card-header">
              <span>提现申请列表</span>
              <ElSelect v-model="wdStatus" placeholder="状态筛选" clearable style="width:120px" @change="loadWithdraws">
                <ElOption label="待审核" value="pending" />
                <ElOption label="已通过" value="completed" />
                <ElOption label="已拒绝" value="rejected" />
              </ElSelect>
            </div>
          </template>
          <ElTable :data="withdraws" v-loading="wdLoading" stripe>
            <ElTableColumn prop="id" label="ID" width="60" />
            <ElTableColumn prop="user_name" label="申请人" width="100" />
            <ElTableColumn prop="amount" label="金额" width="100" />
            <ElTableColumn prop="method" label="方式" width="80">
              <template #default="{ row }">
                <ElTag size="small">{{ row.method==='alipay'?'支付宝':row.method==='wechat'?'微信':row.method }}</ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="account" label="账号" width="150" />
            <ElTableColumn prop="real_name" label="真实姓名" width="100" />
            <ElTableColumn prop="status" label="状态" width="90">
              <template #default="{ row }">
                <ElTag :type="row.status==='pending'?'warning':row.status==='completed'?'success':'danger'" size="small">
                  {{ row.status==='pending'?'待审核':row.status==='completed'?'已通过':'已拒绝' }}
                </ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="create_time" label="申请时间" width="170" />
            <ElTableColumn label="操作" width="160" fixed="right">
              <template #default="{ row }">
                <template v-if="row.status==='pending'">
                  <ElButton size="small" type="primary" link @click="review(row,'completed')">通过</ElButton>
                  <ElButton size="small" type="danger" link @click="review(row,'rejected')">拒绝</ElButton>
                </template>
                <span v-else class="text-gray-400">已处理</span>
              </template>
            </ElTableColumn>
          </ElTable>
        </ElCard>
      </ElTabPane>
    </ElTabs>

    <ElDialog v-model="ruleVisible" :title="editRuleId?'编辑规则':'新增规则'" width="500px">
      <ElForm :model="ruleForm" label-width="100px" :disabled="saving">
        <ElFormItem label="规则名称">
          <ElInput v-model="ruleForm.name" placeholder="如: 全局返佣" />
        </ElFormItem>
        <ElFormItem label="订单类型">
          <ElSelect v-model="ruleForm.order_type">
            <ElOption label="全部订单" value="all" />
            <ElOption label="会员购买" value="membership" />
            <ElOption label="应用购买" value="app" />
            <ElOption label="帖子购买" value="post" />
            <ElOption label="帖子资源" value="post_resource" />
            <ElOption label="资源购买" value="resource" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="返佣比例(%)">
          <ElInputNumber v-model="ruleForm.rate" :min="0" :max="100" :precision="1" />
        </ElFormItem>
        <ElFormItem label="适用等级">
          <ElSelect v-model="ruleForm.user_level_id" placeholder="选择会员等级" clearable @change="onRuleLevelChange">
            <ElOption v-for="lv in levelList" :key="lv.id" :label="lv.name" :value="lv.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="专属用户">
          <ElSelect v-model="ruleForm.invite_code_id" placeholder="选择邀请码" clearable filterable @change="onInviteCodeChange">
            <ElOption v-for="inv in inviteList" :key="inv.id" :label="`${inv.code} - ${inv.created_by_name || inv.type || ''}`" :value="inv.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="状态">
          <ElSwitch v-model="ruleForm.status" active-value="1" inactive-value="0" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="ruleVisible=false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="saveRule">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchCommissionRules, saveCommissionRule, deleteCommissionRule, fetchCommissionRecords, fetchWithdrawList, reviewWithdraw } from '@/api/commission'
import { fetchGetUserList } from '@/api/system-manage'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchInviteList } from '@/api/invite'

defineOptions({ name: 'CommissionManage' })

const activeTab = ref('rules')
const rules = ref<any[]>([])
const loading = ref(false)
const saving = ref(false)
const ruleVisible = ref(false)
const editRuleId = ref<number | null>(null)
const wdLoading = ref(false)
const wdStatus = ref('pending')
const withdraws = ref<any[]>([])
const userList = ref<any[]>([])
const levelList = ref<any[]>([])
const inviteList = ref<any[]>([])
const records = ref<any[]>([])
const recLoading = ref(false)
const recTotal = ref(0)
const recPage = ref(1)
const recPageSize = ref(20)

const ruleForm = reactive({
  id: null as number | null, name: '', order_type: 'all', rate: 0,
  user_level_id: 0, user_level_name: '', user_id: 0, invite_code_id: 0, status: '1'
})

const recColumns = [
  { prop: 'id', label: 'ID', width: 60 },
  { prop: 'order_type', label: '订单类型', width: 100 },
  { prop: 'order_amount', label: '订单金额', width: 100 },
  { prop: 'referrer_name', label: '推广人', width: 100 },
  { prop: 'rate', label: '返佣比例', width: 80 },
  { prop: 'amount', label: '返佣金额', width: 100 },
  { prop: 'status', label: '状态', width: 80 },
  { prop: 'create_time', label: '时间', width: 170 }
]

async function loadRecords() {
  recLoading.value = true
  try {
    const res: any = await fetchCommissionRecords({
      page: recPage.value,
      pageSize: recPageSize.value
    })
    records.value = res.list || []
    recTotal.value = res.total || 0
  } finally { recLoading.value = false }
}

function handleRecSizeChange(size: number) {
  recPageSize.value = size
  recPage.value = 1
  loadRecords()
}

function handleRecCurrentChange(page: number) {
  recPage.value = page
  loadRecords()
}

async function loadRules() {
  loading.value = true
  try { const res: any = await fetchCommissionRules(); rules.value = res || [] }
  finally { loading.value = false }
}

async function loadUsers() {
  try {
    const res: any = await fetchGetUserList({ current: 1, size: 200 })
    userList.value = (res && res.records) ? res.records : []
  } catch { userList.value = [] }
}

async function loadLevels() {
  try {
    const res: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
    levelList.value = (res && res.records) ? res.records : []
  } catch { levelList.value = [] }
}

async function loadInvites() {
  try {
    const res: any = await fetchInviteList({ page: 1, pageSize: 200 })
    inviteList.value = (res && res.records) ? res.records : (res?.list || [])
  } catch { inviteList.value = [] }
}

function onRuleLevelChange(val: number | string) {
  const id = Number(val)
  if (id > 0 && levelList.value.length) {
    const lv = levelList.value.find((l: any) => l.id === id)
    ruleForm.user_level_name = lv ? lv.name : ''
  } else {
    ruleForm.user_level_name = ''
  }
}

function onInviteCodeChange(val: number | string) {
  const id = Number(val)
  if (id > 0 && inviteList.value.length) {
    const inv = inviteList.value.find((i: any) => i.id === id)
    ruleForm.user_id = inv ? (inv.created_by || 0) : 0
  } else {
    ruleForm.user_id = 0
  }
}

async function loadWithdraws() {
  wdLoading.value = true
  try {
    const res: any = await fetchWithdrawList({ status: wdStatus.value || undefined })
    withdraws.value = res.list || []
  } finally { wdLoading.value = false }
}

function showRuleForm(row: any) {
  if (row) {
    editRuleId.value = row.id
    Object.assign(ruleForm, {
      id: row.id, name: row.name || '', order_type: row.order_type || 'all',
      rate: row.rate || 0, user_level_id: row.user_level_id || 0,
      user_level_name: row.user_level_name || '',
      user_id: row.user_id || 0, invite_code_id: row.invite_code_id || 0, status: row.status || '1'
    })
  } else {
    editRuleId.value = null
    Object.assign(ruleForm, { id: null, name: '', order_type: 'all', rate: 0, user_level_id: 0, user_level_name: '', user_id: 0, invite_code_id: 0, status: '1' })
  }
  ruleVisible.value = true
}

async function saveRule() {
  saving.value = true
  try {
    await saveCommissionRule(ruleForm)
    ElMessage.success('保存成功')
    ruleVisible.value = false
    loadRules()
  } finally { saving.value = false }
}

async function delRule(row: any) {
  try {
    await ElMessageBox.confirm('确定删除?', '确认', { type: 'warning' })
    await deleteCommissionRule(row.id)
    ElMessage.success('已删除')
    loadRules()
  } catch { /* cancel */ }
}

async function review(row: any, status: string) {
  try {
    const msg = status === 'completed' ? '确认通过此提现申请?' : '确认拒绝此提现申请?'
    await ElMessageBox.confirm(msg, '确认', { type: 'warning' })
    await reviewWithdraw({ id: row.id, status })
    ElMessage.success(status === 'completed' ? '已通过' : '已拒绝')
    loadWithdraws()
  } catch { /* cancel */ }
}

onMounted(() => { loadRules(); loadWithdraws(); loadRecords(); loadUsers(); loadLevels(); loadInvites() })
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
