<template>
  <ElDialog v-model="dialogVisible" title="系统日志开关" width="460px" align-center>
    <div class="mb-2 text-xs text-gray-400">关闭某项后，对应类型的操作将不再记录日志</div>
    <ElForm label-width="140px" label-position="left">
      <ElFormItem label="总开关">
        <ElSwitch v-model="categories.system_log_enabled" @change="(v: any) => saveCategory('system_log_enabled', v)" />
      </ElFormItem>
      <ElDivider />
      <ElFormItem label="登录日志">
        <ElSwitch v-model="categories.log_enabled_login" @change="(v: any) => saveCategory('log_enabled_login', v)" />
      </ElFormItem>
      <ElFormItem label="用户操作日志">
        <ElSwitch v-model="categories.log_enabled_user" @change="(v: any) => saveCategory('log_enabled_user', v)" />
      </ElFormItem>
      <ElFormItem label="运营管理日志">
        <ElSwitch v-model="categories.log_enabled_operation" @change="(v: any) => saveCategory('log_enabled_operation', v)" />
      </ElFormItem>
      <ElFormItem label="内容管理日志">
        <ElSwitch v-model="categories.log_enabled_content" @change="(v: any) => saveCategory('log_enabled_content', v)" />
      </ElFormItem>
      <ElFormItem label="系统配置日志">
        <ElSwitch v-model="categories.log_enabled_system" @change="(v: any) => saveCategory('log_enabled_system', v)" />
      </ElFormItem>
    </ElForm>
  </ElDialog>
</template>

<script setup lang="ts">
import { fetchLogCategories, saveLogCategory } from '@/api/system-log'
import { ElMessage } from 'element-plus'

interface Props { visible: boolean }
interface Emits { (e: 'update:visible', v: boolean): void }
const props = defineProps<Props>()
const emit = defineEmits<Emits>()
const dialogVisible = computed({ get: () => props.visible, set: (v) => emit('update:visible', v) })

const categories = reactive<Record<string, boolean>>({
  system_log_enabled: true,
  log_enabled_login: true,
  log_enabled_user: true,
  log_enabled_operation: true,
  log_enabled_content: true,
  log_enabled_system: true
})

const loadCategories = async () => {
  try {
    const res: any = await fetchLogCategories()
    if (res) {
      for (const k of Object.keys(categories)) {
        if (res[k]) categories[k] = res[k].value === 'true'
      }
    }
  } catch {}
}

const saveCategory = async (key: string, val: boolean) => {
  try {
    await saveLogCategory(key, val)
    ElMessage.success('保存成功')
  } catch {
    categories[key] = !val
    ElMessage.error('保存失败')
  }
}

watch(() => props.visible, (v) => { if (v) loadCategories() })
</script>
