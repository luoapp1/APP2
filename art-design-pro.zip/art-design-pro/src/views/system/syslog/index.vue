<!-- 系统日志页面 -->
<template>
  <div class="syslog-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>系统日志</span>
          <ElSpace wrap>
            <ElButton size="small" @click="showLogCategoryDialog">日志开关</ElButton>
            <ElSelect v-model="filterType" placeholder="日志类型" clearable style="width:140px" @change="refreshData">
              <ElOption v-for="t in logTypes" :key="t.value" :label="t.label" :value="t.value" />
            </ElSelect>
            <ElDatePicker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"
              value-format="YYYY-MM-DD" @change="onDateChange" />
          </ElSpace>
        </div>
      </template>

      <ArtTable :loading="loading" :data="data" :columns="computedColumns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />

      <template v-if="detailVisible">
        <ElDrawer v-model="detailVisible" title="日志详情" size="480px">
          <div v-if="detail" class="log-detail">
            <ElDescriptions :column="1" border>
              <ElDescriptionsItem label="ID">{{ detail.id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="用户ID">{{ detail.user_id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="用户名">{{ detail.user_name }}</ElDescriptionsItem>
              <ElDescriptionsItem label="操作类型">
                <ElTag :type="typeColor(detail.type)">{{ detail.type }}</ElTag>
              </ElDescriptionsItem>
              <ElDescriptionsItem label="目标类型">{{ detail.target_type }}</ElDescriptionsItem>
              <ElDescriptionsItem label="目标ID">{{ detail.target_id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="IP地址">{{ detail.ip }}</ElDescriptionsItem>
              <ElDescriptionsItem label="操作时间">{{ detail.create_time }}</ElDescriptionsItem>
              <ElDescriptionsItem label="详情">{{ detail.detail }}</ElDescriptionsItem>
            </ElDescriptions>
          </div>
        </ElDrawer>
      </template>
    </ElCard>

    <LogCategoryDialog v-model:visible="logCategoryVisible" />
  </div>
</template>

<script setup lang="ts">
import { fetchSystemLogs, fetchLogStats, fetchRestoreMenu } from '@/api/system-log'
import { useTable } from '@/hooks/core/useTable'
import { ElMessage, ElMessageBox, ElButton } from 'element-plus'
import LogCategoryDialog from './modules/log-category-dialog.vue'

defineOptions({ name: 'SystemLog' })

const filterType = ref('')
const dateRange = ref<[string, string] | null>(null)
const detailVisible = ref(false)
const detail = ref<any>(null)
const logCategoryVisible = ref(false)
const showLogCategoryDialog = () => { logCategoryVisible.value = true }

const logTypes = [
  { label: '登录', value: 'login' },
  { label: '登出', value: 'logout' },
  { label: '创建', value: 'create' },
  { label: '更新', value: 'update' },
  { label: '删除', value: 'delete' },
  { label: '回收', value: 'trash' },
  { label: '恢复', value: 'restore' },
  { label: '关注', value: 'follow' },
  { label: '点赞', value: 'like' },
  { label: '收藏', value: 'favorite' },
  { label: '评论', value: 'comment' },
  { label: '兑换', value: 'redeem' },
  { label: '购买', value: 'purchase' },
  { label: '上传', value: 'upload' },
  { label: '审批', value: 'approve' },
  { label: '配置', value: 'config' }
]

const baseColumns = [
  { prop: 'id', label: 'ID', width: 70 },
  { prop: 'user_name', label: '操作用户', width: 120 },
  { prop: 'type', label: '操作类型', width: 100 },
  { prop: 'target_type', label: '目标类型', width: 100 },
  { prop: 'target_id', label: '目标ID', width: 80 },
  { prop: 'detail', label: '详情', minWidth: 200 },
  { prop: 'ip', label: 'IP', width: 130 },
  { prop: 'create_time', label: '时间', width: 170 }
]

const computedColumns = computed(() => {
  return [
    ...baseColumns,
    {
      prop: 'operation',
      label: '操作',
      width: 100,
      formatter: (row: any) => {
        if (row.target_type === 'menu' && (row.type === 'update' || row.type === 'delete')) {
          return h('div', [
            h(ElButton, {
              type: 'primary',
              size: 'small',
              link: true,
              onClick: () => handleRestore(row)
            }, () => '恢复')
          ])
        }
        return ''
      }
    }
  ]
})

function typeColor(type: string) {
  const map: Record<string, string> = {
    login: 'success', logout: 'info', create: 'primary', update: 'warning',
    delete: 'danger', trash: 'danger', restore: 'success',
    follow: 'primary', like: 'warning', favorite: 'warning', comment: 'info',
    approve: 'success', reject: 'danger', config: 'primary'
  }
  return map[type] || 'info'
}

async function handleRestore(row: any) {
  try {
    await ElMessageBox.confirm(`确定要恢复该操作吗？将回滚到操作前的状态。`, '恢复确认', {
      confirmButtonText: '确定恢复',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await fetchRestoreMenu(row.id)
    ElMessage.success('恢复成功')
    refreshData()
  } catch (error: any) {
    if (error !== 'cancel') ElMessage.error(error?.msg || error?.message || '恢复失败')
  }
}

async function fetchData() {
  const params: any = {
    page: pagination.value.currentPage,
    pageSize: pagination.value.pageSize
  }
  if (filterType.value) params.type = filterType.value
  if (dateRange.value) params.dateRange = dateRange.value

  return await fetchSystemLogs(params)
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: fetchData,
    immediate: true
  }
})

function onDateChange() {
  refreshData()
}

function showDetail(row: any) {
  detail.value = row
  detailVisible.value = true
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.log-detail { padding: 12px 0; }
:deep(.el-table__row) { cursor: pointer; }
</style>
