<!-- 系统日志页面 -->
<template>
  <div class="syslog-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>系统日志</span>
          <ElSpace wrap>
            <ElSelect v-model="filterType" placeholder="日志类型" clearable style="width:140px" @change="refreshData">
              <ElOption v-for="t in logTypes" :key="t.value" :label="t.label" :value="t.value" />
            </ElSelect>
            <ElDatePicker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"
              value-format="YYYY-MM-DD" @change="onDateChange" />
          </ElSpace>
        </div>
      </template>

      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />

      <template v-if="detailVisible">
        <ElDrawer v-model="detailVisible" title="日志详情" size="480px">
          <div v-if="detail" class="log-detail">
            <ElDescriptions :column="1" border>
              <ElDescriptionsItem label="ID">{{ detail.id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="用户ID">{{ detail.user_id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="用户名">{{ detail.user_name }}</ElDescriptionsItem>
              <ElDescriptionsItem label="操作类型">
                <ElTag :type="typeColor(detail.type)">{{ detail.type }}</ElTag>
              </ElDescriptionsItem>
              <ElDescriptionsItem label="目标类型">{{ detail.target_type }}</ElDescriptionsItem>
              <ElDescriptionsItem label="目标ID">{{ detail.target_id }}</ElDescriptionsItem>
              <ElDescriptionsItem label="IP地址">{{ detail.ip }}</ElDescriptionsItem>
              <ElDescriptionsItem label="操作时间">{{ detail.create_time }}</ElDescriptionsItem>
              <ElDescriptionsItem label="详情">{{ detail.detail }}</ElDescriptionsItem>
            </ElDescriptions>
          </div>
        </ElDrawer>
      </template>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { fetchSystemLogs, fetchLogStats } from '@/api/system-log'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'SystemLog' })

const filterType = ref('')
const dateRange = ref<[string, string] | null>(null)
const detailVisible = ref(false)
const detail = ref<any>(null)

const logTypes = [
  { label: '登录', value: 'login' },
  { label: '登出', value: 'logout' },
  { label: '创建', value: 'create' },
  { label: '更新', value: 'update' },
  { label: '删除', value: 'delete' },
  { label: '回收', value: 'trash' },
  { label: '恢复', value: 'restore' },
  { label: '关注', value: 'follow' },
  { label: '点赞', value: 'like' },
  { label: '收藏', value: 'favorite' },
  { label: '评论', value: 'comment' },
  { label: '兑换', value: 'redeem' },
  { label: '购买', value: 'purchase' },
  { label: '上传', value: 'upload' },
  { label: '审批', value: 'approve' },
  { label: '配置', value: 'config' }
]

const columns = [
  { prop: 'id', label: 'ID', width: 70 },
  { prop: 'user_name', label: '操作用户', width: 120 },
  { prop: 'type', label: '操作类型', width: 100 },
  { prop: 'target_type', label: '目标类型', width: 100 },
  { prop: 'target_id', label: '目标ID', width: 80 },
  { prop: 'detail', label: '详情', minWidth: 200 },
  { prop: 'ip', label: 'IP', width: 130 },
  { prop: 'create_time', label: '时间', width: 170 }
]

function typeColor(type: string) {
  const map: Record<string, string> = {
    login: 'success', logout: 'info', create: 'primary', update: 'warning',
    delete: 'danger', trash: 'danger', restore: 'success',
    follow: 'primary', like: 'warning', favorite: 'warning', comment: 'info',
    approve: 'success', reject: 'danger', config: 'primary'
  }
  return map[type] || 'info'
}

async function fetchData() {
  const params: any = {
    page: pagination.value.currentPage,
    pageSize: pagination.value.pageSize
  }
  if (filterType.value) params.type = filterType.value
  if (dateRange.value) params.dateRange = dateRange.value

  return await fetchSystemLogs(params)
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable(fetchData)

function onDateChange() {
  refreshData()
}

function showDetail(row: any) {
  detail.value = row
  detailVisible.value = true
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.log-detail { padding: 12px 0; }
:deep(.el-table__row) { cursor: pointer; }
</style>
