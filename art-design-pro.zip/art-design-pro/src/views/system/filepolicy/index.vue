<template>
  <div class="filepolicy-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>文件上传策略</span>
          <ElButton type="primary" @click="showForm(null)">新增策略</ElButton>
        </div>
      </template>

      <ElTable :data="policies" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="name" label="策略名称" minWidth="140" />
        <ElTableColumn prop="user_level_name" label="适用等级/角色" width="160">
          <template #default="{ row }">
            {{ row.role_code === '*' ? '所有角色' : row.role_code ? getRoleName(row.role_code) : (row.user_level_name || '所有用户') }}
          </template>
        </ElTableColumn>
        <ElTableColumn prop="max_file_size_mb" label="最大文件(MB)" width="120" />
        <ElTableColumn prop="allowed_types" label="允许格式" minWidth="150">
          <template #default="{ row }">
            <span class="text-xs text-gray-500">{{ row.allowed_types || '全部' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="banned_types" label="禁止格式" minWidth="150">
          <template #default="{ row }">
            <span class="text-xs text-red-400">{{ row.banned_types || '无' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="状态" width="80">
          <template #default="{ row }">
            <ElTag :type="row.status==='1'?'success':'info'" size="small">{{ row.status==='1'?'启用':'禁用' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="140">
          <template #default="{ row }">
            <ElButton size="small" link type="primary" @click="showForm(row)">编辑</ElButton>
            <ElButton size="small" link type="danger" @click="doDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElDialog v-model="formVisible" :title="editId?'编辑策略':'新增策略'" width="550px">
      <ElForm :model="form" label-width="120px" :disabled="saving">
        <ElFormItem label="策略名称">
          <ElInput v-model="form.name" placeholder="如: 普通用户限制" />
        </ElFormItem>
        <ElFormItem label="适用等级">
          <ElSelect v-model="form.user_level_id" placeholder="选择会员等级（留空=所有用户）" clearable @change="onLevelChange">
            <ElOption label="所有用户" :value="0" />
            <ElOption v-for="lv in levelList" :key="lv.id" :label="lv.name" :value="lv.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="适用角色">
          <ElSelect v-model="form.role_code" placeholder="选择角色（留空=不限角色）" clearable>
            <ElOption label="所有角色" value="*" />
            <ElOption v-for="r in roleList" :key="r.roleCode" :label="r.roleName" :value="r.roleCode" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="最大文件大小(MB)">
          <ElInputNumber v-model="form.max_file_size_mb" :min="1" :max="1024" />
        </ElFormItem>
        <ElFormItem label="允许的文件格式">
          <ElInput v-model="form.allowed_types" placeholder="留空为允许全部，多个用逗号分隔" />
          <div class="form-tip">例如: jpg,png,gif,mp4</div>
        </ElFormItem>
        <ElFormItem label="禁止的文件格式">
          <ElInput v-model="form.banned_types" placeholder="多个用逗号分隔" />
          <div class="form-tip">例如: exe,bat,sh 等危险格式</div>
        </ElFormItem>
        <ElFormItem label="状态">
          <ElSwitch v-model="form.status" active-value="1" inactive-value="0" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="formVisible=false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="doSave">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchFilePolicies, saveFilePolicy, deleteFilePolicy } from '@/api/file-policy'
import { fetchGetRoleList } from '@/api/system-manage'
import { fetchGetMembershipLevelList } from '@/api/operation'

defineOptions({ name: 'FilePolicyManage' })

const policies = ref<any[]>([])
const loading = ref(false)
const saving = ref(false)
const formVisible = ref(false)
const editId = ref<number | null>(null)
const roleList = ref<any[]>([])
const levelList = ref<any[]>([])

const form = reactive({
  id: null as number | null, name: '', user_level_id: 0, user_level_name: '', role_code: '',
  max_file_size_mb: 10, allowed_types: '', banned_types: '', status: '1'
})

async function loadRoles() {
  try {
    const res: any = await fetchGetRoleList({ current: 1, size: 100 })
    roleList.value = (res && res.records) ? res.records : []
  } catch { roleList.value = [] }
}

async function loadLevels() {
  try {
    const res: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
    levelList.value = (res && res.records) ? res.records : []
  } catch { levelList.value = [] }
}

function onLevelChange(val: number | string) {
  const id = Number(val)
  if (id > 0 && levelList.value.length) {
    const lv = levelList.value.find((l: any) => l.id === id)
    form.user_level_name = lv ? lv.name : ''
  } else {
    form.user_level_name = ''
  }
}

async function loadData() {
  loading.value = true
  try { const res: any = await fetchFilePolicies(); policies.value = res || [] }
  finally { loading.value = false }
}

function showForm(row: any) {
  if (row) {
    editId.value = row.id
    Object.assign(form, {
      id: row.id, name: row.name || '', user_level_id: row.user_level_id || 0,
      user_level_name: row.user_level_name || '', role_code: row.role_code || '',
      max_file_size_mb: row.max_file_size_mb || 10,
      allowed_types: row.allowed_types || '', banned_types: row.banned_types || '',
      status: row.status || '1'
    })
  } else {
    editId.value = null
    Object.assign(form, { id: null, name: '', user_level_id: 0, user_level_name: '', role_code: '', max_file_size_mb: 10, allowed_types: '', banned_types: '', status: '1' })
  }
  formVisible.value = true
}

async function doSave() {
  saving.value = true
  try {
    await saveFilePolicy(form)
    ElMessage.success('保存成功')
    formVisible.value = false
    loadData()
  } finally { saving.value = false }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm('确定删除?', '确认', { type: 'warning' })
    await deleteFilePolicy(row.id)
    ElMessage.success('已删除')
    loadData()
  } catch { /* cancel */ }
}

onMounted(() => { loadData(); loadRoles(); loadLevels() })

function getRoleName(code: string) {
  const role = roleList.value.find((r: any) => r.roleCode === code)
  return role ? role.roleName : code
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.form-tip { font-size: 12px; color: #909399; margin-top: 4px; }
</style>
