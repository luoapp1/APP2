<template>
  <div class="filerepo-page art-full-height">
    <ElCard class="mb-4">
      <div class="path-bar">
        <div class="flex items-center gap-2 flex-1 min-w-0">
          <ElIcon :size="18" color="#909399"><FolderOpened /></ElIcon>
          <template v-for="(seg, i) in pathSegments" :key="i">
            <span v-if="i > 0" class="text-gray-400 mx-1">/</span>
            <ElButton
              v-if="i < pathSegments.length - 1"
              :type="i === 0 ? 'primary' : 'default'"
              size="small"
              link
              @click="navigateTo(i)"
            >
              {{ seg }}
            </ElButton>
            <span v-else class="text-sm font-semibold text-gray-800">{{ seg }}</span>
          </template>
        </div>
        <div class="flex items-center gap-3 text-xs text-gray-500 flex-shrink-0">
          <span>{{ stats.dirs }} 个目录</span>
          <ElDivider direction="vertical" />
          <span>{{ stats.files }} 个文件</span>
          <ElDivider direction="vertical" />
          <span>{{ stats.totalSize }}</span>
        </div>
      </div>
    </ElCard>

    <ElCard v-if="dirs.length > 0" class="mb-4">
      <template #header>
        <span class="text-sm font-semibold text-gray-700">子目录</span>
      </template>
      <div class="dir-grid">
        <div
          v-for="d in dirs"
          :key="d.name"
          class="dir-card"
          @click="enterDir(d.name)"
        >
          <ElIcon :size="36" color="#409EFF"><Folder /></ElIcon>
          <span class="dir-name">{{ d.name }}</span>
        </div>
      </div>
    </ElCard>

    <ElCard>
      <template #header>
        <div class="card-header">
          <span class="text-sm font-semibold text-gray-700">文件列表</span>
          <div class="flex items-center gap-3">
            <ElSelect
              v-model="pageSize"
              size="small"
              style="width: 100px"
              @change="onPageSizeChange"
            >
              <ElOption :value="10" label="10条/页" />
              <ElOption :value="20" label="20条/页" />
              <ElOption :value="30" label="30条/页" />
              <ElOption :value="50" label="50条/页" />
            </ElSelect>
          </div>
        </div>
      </template>

      <div v-if="loading" class="flex justify-center py-16">
        <ElIcon :size="28" class="is-loading" color="#409EFF"><Loading /></ElIcon>
      </div>

      <template v-else-if="files.length > 0">
        <div class="file-grid">
          <div
            v-for="f in files"
            :key="f.path"
            class="file-card"
            @click="openDetail(f)"
          >
            <div v-if="f.isImage" class="file-thumb">
              <ElImage
                :src="$fixImgUrl(f.url)"
                fit="cover"
                lazy
                class="thumb-img"
              >
                <template #error>
                  <ElIcon :size="32" color="#c0c4cc"><Picture /></ElIcon>
                </template>
              </ElImage>
            </div>
            <div v-else class="file-thumb file-icon-thumb" :class="fileIconClass(f)">
              <ElIcon :size="32">
                <VideoPlay v-if="f.isVideo" />
                <Headset v-else-if="f.isAudio" />
                <Document v-else />
              </ElIcon>
            </div>
            <div class="file-info">
              <ElTooltip :content="f.name" placement="top" :show-after="500">
                <span class="file-name">{{ f.name }}</span>
              </ElTooltip>
              <span class="file-meta">{{ formatSize(f.size) }}</span>
              <span class="file-meta text-gray-400">{{ formatDate(f.mtime) }}</span>
            </div>
          </div>
        </div>

        <div class="pagination-bar">
          <div class="flex items-center gap-2">
            <ElButton
              size="small"
              :disabled="page <= 1"
              @click="goPage(page - 1)"
            >
              <ElIcon><ArrowLeft /></ElIcon>
              上一页
            </ElButton>
            <span class="px-2 text-sm text-gray-600">
              {{ page }} / {{ totalPages }}
            </span>
            <ElButton
              size="small"
              :disabled="page >= totalPages"
              @click="goPage(page + 1)"
            >
              下一页
              <ElIcon><ArrowRight /></ElIcon>
            </ElButton>
            <ElDivider direction="vertical" />
            <span class="text-xs text-gray-400">共 {{ totalFiles }} 个文件</span>
          </div>
          <div class="flex items-center gap-2 text-xs text-gray-500">
            <span>跳至</span>
            <ElInputNumber
              v-model="jumpPage"
              :min="1"
              :max="totalPages"
              size="small"
              controls-position="right"
              style="width: 80px"
              @keyup.enter="goPage(jumpPage)"
            />
            <span>页</span>
            <ElButton size="small" @click="goPage(jumpPage)">GO</ElButton>
          </div>
        </div>
      </template>

      <div v-else class="flex flex-col items-center py-16 text-gray-400">
        <ElIcon :size="40"><FolderOpened /></ElIcon>
        <span class="mt-2 text-sm">此目录下暂无文件</span>
      </div>
    </ElCard>

    <ElDialog
      v-model="detailVisible"
      :title="detailFile?.name || '文件详情'"
      width="680px"
      destroy-on-close
    >
      <div v-if="detailFile" class="detail-body">
        <div v-if="detailFile.isImage" class="detail-preview">
          <ElImage :src="detailFile.url" fit="contain" style="max-height:360px" />
        </div>
        <div v-else-if="detailFile.isVideo" class="detail-preview bg-black rounded-lg flex items-center justify-center" style="height:240px">
          <video :src="detailFile.url" controls style="max-width:100%;max-height:240px" />
        </div>
        <div v-else class="detail-preview detail-icon-preview">
          <ElIcon :size="64" color="#c0c4cc">
            <VideoPlay v-if="detailFile.isVideo" />
            <Headset v-else-if="detailFile.isAudio" />
            <Document v-else />
          </ElIcon>
          <p class="text-sm text-gray-400 mt-3">非可预览文件</p>
        </div>

        <ElDescriptions :column="2" border size="small" class="mt-4">
          <ElDescriptionsItem label="文件名" :span="2">{{ detailFile.name }}</ElDescriptionsItem>
          <ElDescriptionsItem label="文件大小">{{ formatSize(detailFile.size) }}</ElDescriptionsItem>
          <ElDescriptionsItem label="文件类型">{{ detailFile.ext || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="修改时间" :span="2">{{ formatDate(detailFile.mtime) }}</ElDescriptionsItem>
          <ElDescriptionsItem label="文件路径" :span="2">
            <code class="text-xs bg-gray-100 px-2 py-1 rounded break-all">{{ currentDir }}/{{ detailFile.path }}</code>
          </ElDescriptionsItem>
          <ElDescriptionsItem label="访问URL" :span="2">
            <div class="flex items-center gap-2">
              <code class="text-xs bg-gray-100 px-2 py-1 rounded flex-1 break-all">{{ fullUrl(detailFile.url) }}</code>
              <ElButton size="small" @click="copyUrl(detailFile.url)">复制</ElButton>
            </div>
          </ElDescriptionsItem>
          <template v-if="detailFile.dbRecord">
            <ElDescriptionsItem label="上传者">{{ detailFile.dbRecord.user_name || '-' }}</ElDescriptionsItem>
            <ElDescriptionsItem label="分类">{{ detailFile.dbRecord.category || '-' }}</ElDescriptionsItem>
            <ElDescriptionsItem label="上传时间" :span="2">{{ detailFile.dbRecord.create_time || '-' }}</ElDescriptionsItem>
          </template>
        </ElDescriptions>
      </div>
      <template #footer>
        <ElButton @click="detailVisible = false">关闭</ElButton>
        <ElButton type="primary" @click="openFileUrl">在新窗口打开</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import {
  FolderOpened, Folder, Loading, Picture, VideoPlay,
  Headset, Document, ArrowLeft, ArrowRight
} from '@element-plus/icons-vue'
import { fetchLocalBrowse, fetchLocalDetail } from '@/api/file-repo'

defineOptions({ name: 'FileRepository' })

const loading = ref(false)
const currentDir = ref('')
const dirs = ref<{ name: string; isDir: boolean }[]>([])
const files = ref<any[]>([])
const page = ref(1)
const pageSize = ref(30)
const totalFiles = ref(0)
const totalPages = ref(1)
const jumpPage = ref(1)
const stats = reactive({ dirs: 0, files: 0, totalSize: '' })

const detailVisible = ref(false)
const detailFile = ref<any>(null)

const pathSegments = computed(() => {
  if (!currentDir.value) return ['uploads']
  return ['uploads', ...currentDir.value.split('/')]
})

function formatSize(bytes: number) {
  if (!bytes) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB']
  let i = 0; let v = bytes
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++ }
  return v.toFixed(i > 0 ? 1 : 0) + ' ' + units[i]
}

function formatDate(iso: string) {
  if (!iso) return '-'
  const d = new Date(iso)
  return d.toLocaleString('zh-CN', { hour12: false })
}

function fileIconClass(f: any) {
  if (f.isVideo) return 'icon-video'
  if (f.isAudio) return 'icon-audio'
  return 'icon-doc'
}

function fullUrl(u: string) {
  return window.location.origin + u
}

async function copyUrl(u: string) {
  try {
    await navigator.clipboard.writeText(fullUrl(u))
    ElMessage.success('链接已复制')
  } catch {
    ElMessage.error('复制失败')
  }
}

function openFileUrl() {
  if (detailFile.value) window.open(detailFile.value.url, '_blank')
}

async function loadData(dir?: string) {
  loading.value = true
  try {
    const res: any = await fetchLocalBrowse({
      dir: dir || currentDir.value,
      page: page.value,
      pageSize: pageSize.value
    })
    const d = res?.data || res || {}
    dirs.value = d.dirs || []
    files.value = d.files || []
    totalFiles.value = d.totalFiles || 0
    totalPages.value = d.totalPages || 1
    page.value = d.page || 1
    jumpPage.value = d.page || 1

    let totalBytes = 0
    files.value.forEach((f: any) => { totalBytes += f.size || 0 })
    stats.dirs = dirs.value.length
    stats.files = totalFiles.value
    stats.totalSize = formatSize(totalBytes)
  } catch {
    ElMessage.error('加载失败')
  }
  loading.value = false
}

function navigateTo(segIdx: number) {
  if (segIdx === 0) {
    currentDir.value = ''
    page.value = 1
    loadData()
    return
  }
  const segs = currentDir.value.split('/')
  currentDir.value = segs.slice(0, segIdx).join('/')
  page.value = 1
  loadData()
}

function enterDir(name: string) {
  currentDir.value = currentDir.value ? `${currentDir.value}/${name}` : name
  page.value = 1
  loadData()
}

function goPage(p: number) {
  if (p < 1 || p > totalPages.value) return
  page.value = p
  jumpPage.value = p
  loadData()
}

function onPageSizeChange() {
  page.value = 1
  loadData()
}

async function openDetail(f: any) {
  detailFile.value = f
  detailVisible.value = true
  try {
    const res: any = await fetchLocalDetail(f.path)
    const d = res?.data || res || {}
    if (d && d.name) {
      detailFile.value = { ...f, ...d }
    }
  } catch {}
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.filerepo-page {
  padding: 0;
}

.path-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.dir-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 12px;
}

.dir-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 14px 8px;
  border-radius: 8px;
  background: #f5f7fa;
  cursor: pointer;
  transition: all .2s;
}
.dir-card:hover {
  background: #ecf5ff;
  transform: translateY(-2px);
}
.dir-name {
  font-size: 12px;
  color: #606266;
  text-align: center;
  word-break: break-all;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.file-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 14px;
}

.file-card {
  border: 1px solid #ebeef5;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all .2s;
  background: #fff;
}
.file-card:hover {
  border-color: #409EFF;
  box-shadow: 0 2px 8px rgba(64,158,255,.15);
  transform: translateY(-2px);
}

.file-thumb {
  width: 100%;
  height: 130px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #fafafa;
  overflow: hidden;
}

.thumb-img {
  width: 100%;
  height: 100%;
}
.thumb-img :deep(img) {
  object-fit: cover;
}

.file-icon-thumb {
  background: #f5f7fa;
}
.icon-video { color: #67C23A; }
.icon-audio { color: #E6A23C; }
.icon-doc { color: #909399; }

.file-info {
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.file-name {
  font-size: 12px;
  color: #303133;
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.file-meta {
  font-size: 11px;
  color: #909399;
}

.pagination-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid #ebeef5;
  flex-wrap: wrap;
  gap: 10px;
}

.detail-body {
  max-height: 70vh;
  overflow-y: auto;
}

.detail-preview {
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  overflow: hidden;
  background: #f5f7fa;
  min-height: 120px;
}

.detail-icon-preview {
  flex-direction: column;
  padding: 32px;
}

:deep(.el-descriptions__label) {
  width: 100px;
}

@media (max-width: 768px) {
  .file-grid {
    grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
    gap: 10px;
  }
  .file-thumb {
    height: 100px;
  }
  .pagination-bar {
    flex-direction: column;
    align-items: flex-start;
  }
}
</style>
