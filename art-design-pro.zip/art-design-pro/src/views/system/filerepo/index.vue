<!-- 文件仓库 -->
<template>
  <div class="filerepo-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>文件仓库</span>
          <ElSpace>
            <ElInput v-model="searchKeyword" placeholder="搜索文件名" clearable @change="refreshData" style="width:200px" />
            <ElSelect v-model="filterCategory" placeholder="文件分类" clearable @change="refreshData" style="width:140px">
              <ElOption v-for="c in categories" :key="c.category" :label="`${c.category} (${c.count})`" :value="c.category" />
            </ElSelect>
          </ElSpace>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import { fetchFileRepoList, fetchFileRepoCategories, fetchDeleteFileRepo } from '@/api/file-repo'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'FileRepository' })

const filterCategory = ref('')
const searchKeyword = ref('')
const categories = ref<any[]>([])

const columns = [
  { prop: 'file_name', label: '文件名', minWidth: 200 },
  { prop: 'file_type', label: '类型', width: 80 },
  { prop: 'file_size', label: '大小', width: 100 },
  { prop: 'mime_type', label: 'MIME', width: 150 },
  { prop: 'category', label: '分类', width: 90 },
  { prop: 'user_name', label: '上传者', width: 100 },
  { prop: 'create_time', label: '上传时间', width: 160 },
  {
    label: '操作', width: 80, fixed: 'right' as const,
    formatter: (row: any) =>
      h(ElButton, { size: 'small', type: 'danger', link: true, onClick: () => deleteFile(row) }, () => '删除')
  }
]

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: (params: any) =>
      fetchFileRepoList({
        page: params.current, pageSize: params.size,
        category: filterCategory.value || undefined,
        keyword: searchKeyword.value || undefined
      }),
    apiParams: { current: 1, size: 20 }
  }
})

async function loadCategories() {
  const res: any = await fetchFileRepoCategories()
  categories.value = res || []
}

async function deleteFile(row: any) {
  await ElMessageBox.confirm('确定删除该文件？将同时删除服务器上的文件。', '警告', { type: 'warning' })
  await fetchDeleteFileRepo(row.id)
  ElMessage.success('删除成功')
  refreshData()
  loadCategories()
}

onMounted(() => {
  loadCategories()
})
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
