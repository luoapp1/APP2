<!-- 回收站 -->
<template>
  <div class="recycle-page art-full-height">
    <ElCard>
      <template #header>
        <div class="card-header">
          <span>回收站</span>
          <ElSpace>
            <ElSelect v-model="filterTable" placeholder="按表筛选" clearable @change="fetchData" style="width:160px">
              <ElOption label="社区帖子" value="community_posts" />
              <ElOption label="社区评论" value="community_comments" />
              <ElOption label="应用" value="app_store" />
              <ElOption label="应用评论" value="app_comments" />
            </ElSelect>
            <ElButton type="danger" plain @click="clearRecycle">清空回收站</ElButton>
          </ElSpace>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { fetchRecycleList, fetchRecycleRestore, fetchRecycleDelete, fetchRecycleClear } from '@/api/file-repo'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'RecycleBin' })

const filterTable = ref('')

const columns = [
  { prop: 'original_table', label: '来源表', width: 140 },
  { prop: 'original_id', label: '原ID', width: 80 },
  { prop: 'deleted_by_name', label: '删除者', width: 100 },
  { prop: 'delete_reason', label: '删除原因', minWidth: 150 },
  { prop: 'create_time', label: '删除时间', width: 160 },
  { label: '操作', width: 160, fixed: 'right' as const }
]

async function fetchData() {
  return await fetchRecycleList({ page: pagination.value.currentPage, pageSize: pagination.value.pageSize, table: filterTable.value || undefined })
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange } = useTable(fetchData)

async function restore(row: any) {
  await fetchRecycleRestore(row.id)
  ElMessage.success('恢复成功')
  fetchData()
}

async function deleteForever(row: any) {
  await ElMessageBox.confirm('确定永久删除？此操作不可恢复！', '警告', { type: 'warning' })
  await fetchRecycleDelete(row.id)
  ElMessage.success('已永久删除')
  fetchData()
}

async function clearRecycle() {
  await ElMessageBox.confirm('确定清空回收站？所有数据将无法恢复！', '严重警告', { type: 'warning', confirmButtonClass: 'el-button--danger' })
  await fetchRecycleClear()
  ElMessage.success('回收站已清空')
  fetchData()
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
