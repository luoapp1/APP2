<!-- 回收站 -->
<template>
  <div class="recycle-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>回收站</span>
          <ElSpace>
            <ElSelect v-model="filterTable" placeholder="按表筛选" clearable @change="refreshData" style="width:160px">
              <ElOption label="社区帖子" value="community_posts" />
              <ElOption label="社区评论" value="community_comments" />
              <ElOption label="应用" value="app_store" />
              <ElOption label="应用评论" value="app_comments" />
            </ElSelect>
            <ElButton type="danger" plain @click="clearRecycle">清空回收站</ElButton>
          </ElSpace>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import { fetchRecycleList, fetchRecycleRestore, fetchRecycleDelete, fetchRecycleClear } from '@/api/file-repo'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'RecycleBin' })

const filterTable = ref('')

const columns = [
  { prop: 'original_table', label: '来源表', width: 140 },
  { prop: 'original_id', label: '原ID', width: 80 },
  { prop: 'deleted_by_name', label: '删除者', width: 100 },
  { prop: 'delete_reason', label: '删除原因', minWidth: 150 },
  { prop: 'create_time', label: '删除时间', width: 160 },
  {
    label: '操作', width: 160, fixed: 'right' as const,
    formatter: (row: any) =>
      h('div', { class: 'flex gap-2' }, [
        h(ElButton, { size: 'small', type: 'primary', link: true, onClick: () => restore(row) }, () => '恢复'),
        h(ElButton, { size: 'small', type: 'danger', link: true, onClick: () => deleteForever(row) }, () => '彻底删除')
      ])
  }
]

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: (params: any) =>
      fetchRecycleList({ page: params.current, pageSize: params.size, table: filterTable.value || undefined }),
    apiParams: { current: 1, size: 20 }
  }
})

async function restore(row: any) {
  await fetchRecycleRestore({ ids: [row.id] })
  ElMessage.success('恢复成功')
  refreshData()
}

async function deleteForever(row: any) {
  await ElMessageBox.confirm('确定永久删除？此操作不可恢复！', '警告', { type: 'warning' })
  await fetchRecycleDelete([row.id])
  ElMessage.success('已永久删除')
  refreshData()
}

async function clearRecycle() {
  await ElMessageBox.confirm('确定清空回收站？所有数据将无法恢复！', '严重警告', { type: 'warning', confirmButtonClass: 'el-button--danger' })
  await fetchRecycleClear()
  ElMessage.success('回收站已清空')
  refreshData()
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
