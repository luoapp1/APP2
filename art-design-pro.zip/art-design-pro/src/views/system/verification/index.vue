<!-- 蓝V认证审核 -->
<template>
  <div class="verify-page art-full-height">
    <ElCard>
      <template #header>
        <div class="card-header">
          <span>蓝V认证审核</span>
          <ElRadioGroup v-model="filterStatus" @change="fetchData">
            <ElRadioButton value="pending">待审核</ElRadioButton>
            <ElRadioButton value="approved">已通过</ElRadioButton>
            <ElRadioButton value="rejected">已拒绝</ElRadioButton>
          </ElRadioGroup>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>

    <ElDialog v-model="detailVisible" title="审核详情" width="550px">
      <template v-if="currentReq">
        <ElDescriptions :column="1" border>
          <ElDescriptionsItem label="申请人">{{ currentReq.user_name }} ({{ currentReq.nickname }})</ElDescriptionsItem>
          <ElDescriptionsItem label="真实姓名">{{ currentReq.real_name || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="身份证号">{{ currentReq.id_card || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="所属机构">{{ currentReq.organization || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="申请理由">{{ currentReq.reason || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="申请时间">{{ currentReq.create_time }}</ElDescriptionsItem>
          <ElDescriptionsItem v-if="currentReq.review_comment" label="审核意见">{{ currentReq.review_comment }}</ElDescriptionsItem>
        </ElDescriptions>
        <ElForm v-if="currentReq.status === 'pending'" label-width="80px" style="margin-top:16px">
          <ElFormItem label="审核意见">
            <ElInput v-model="reviewComment" type="textarea" :rows="2" placeholder="可选" />
          </ElFormItem>
        </ElForm>
      </template>
      <template #footer>
        <ElButton @click="detailVisible = false">关闭</ElButton>
        <template v-if="currentReq && currentReq.status === 'pending'">
          <ElButton type="danger" :loading="reviewing" @click="doReview('reject')">拒绝</ElButton>
          <ElButton type="primary" :loading="reviewing" @click="doReview('approve')">通过</ElButton>
        </template>
        <template v-if="currentReq && currentReq.status === 'approved'">
          <ElButton type="warning" @click="cancelVerify">取消认证</ElButton>
        </template>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchVerificationList, fetchReviewVerification, fetchCancelVerification } from '@/api/verification'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'VerificationReview' })

const filterStatus = ref('pending')
const currentReq = ref<any>(null)
const detailVisible = ref(false)
const reviewComment = ref('')
const reviewing = ref(false)

const columns = [
  { prop: 'user_name', label: '用户名', width: 100 },
  { prop: 'nickname', label: '昵称', width: 100 },
  { prop: 'real_name', label: '真实姓名', width: 100 },
  { prop: 'organization', label: '机构', width: 140 },
  { prop: 'reason', label: '理由', minWidth: 150 },
  { prop: 'status', label: '状态', width: 80 },
  { prop: 'create_time', label: '申请时间', width: 160 },
  { label: '操作', width: 100, fixed: 'right' as const }
]

async function fetchData() {
  return await fetchVerificationList({ status: filterStatus.value, page: pagination.value.currentPage, pageSize: pagination.value.pageSize })
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange } = useTable(fetchData)

function showDetail(row: any) {
  currentReq.value = row
  reviewComment.value = ''
  detailVisible.value = true
}

async function doReview(action: string) {
  reviewing.value = true
  try {
    await fetchReviewVerification(currentReq.value.id, { action, comment: reviewComment.value })
    ElMessage.success(action === 'approve' ? '已通过认证' : '已拒绝认证')
    detailVisible.value = false
    fetchData()
  } finally { reviewing.value = false }
}

async function cancelVerify() {
  await ElMessageBox.confirm('确定取消该用户的蓝V认证？', '提示', { type: 'warning' })
  await fetchCancelVerification(currentReq.value.user_id)
  ElMessage.success('认证已取消')
  detailVisible.value = false
  fetchData()
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
