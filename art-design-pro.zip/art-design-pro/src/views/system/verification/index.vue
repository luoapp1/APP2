<!-- 蓝V认证审核 -->
<template>
  <div class="verify-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <div style="display:flex;align-items:center;gap:12px">
            <span>蓝V认证审核</span>
            <ElButton type="primary" size="small" @click="openConfig">
              <ElIcon style="margin-right:4px"><Setting /></ElIcon>
              认证条件配置
            </ElButton>
          </div>
          <ElRadioGroup v-model="filterStatus" @change="refreshData">
            <ElRadioButton value="pending">待审核</ElRadioButton>
            <ElRadioButton value="approved">已通过</ElRadioButton>
            <ElRadioButton value="rejected">已拒绝</ElRadioButton>
          </ElRadioGroup>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>

    <!-- 审核详情弹窗 -->
    <ElDialog v-model="detailVisible" title="审核详情" width="550px">
      <template v-if="currentReq">
        <ElDescriptions :column="1" border>
          <ElDescriptionsItem label="申请人">{{ currentReq.user_name }} ({{ currentReq.nickname }})</ElDescriptionsItem>
          <ElDescriptionsItem label="真实姓名">{{ currentReq.real_name || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="身份证号">{{ currentReq.id_card || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="所属机构">{{ currentReq.organization || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem v-if="currentReq.selected_condition" label="认证条件">
            {{ conditionLabel(currentReq.selected_condition) }}
            <span v-if="currentReq.selected_app_name"> - {{ currentReq.selected_app_name }}</span>
          </ElDescriptionsItem>
          <ElDescriptionsItem label="申请称号">{{ currentReq.reason || '-' }}</ElDescriptionsItem>
          <ElDescriptionsItem label="申请时间">{{ currentReq.create_time }}</ElDescriptionsItem>
          <ElDescriptionsItem v-if="currentReq.review_comment" label="审核意见">{{ currentReq.review_comment }}</ElDescriptionsItem>
        </ElDescriptions>
        <ElForm v-if="currentReq.status === 'pending'" label-width="80px" style="margin-top:16px">
          <ElFormItem label="审核意见">
            <ElInput v-model="reviewComment" type="textarea" :rows="2" placeholder="可选" />
          </ElFormItem>
        </ElForm>
      </template>
      <template #footer>
        <ElButton @click="detailVisible = false">关闭</ElButton>
        <template v-if="currentReq && currentReq.status === 'pending'">
          <ElButton type="danger" :loading="reviewing" @click="doReview('reject')">拒绝</ElButton>
          <ElButton type="primary" :loading="reviewing" @click="doReview('approve')">通过</ElButton>
        </template>
        <template v-if="currentReq && currentReq.status === 'approved'">
          <ElButton type="warning" @click="cancelVerify">取消认证</ElButton>
        </template>
      </template>
    </ElDialog>

    <!-- 认证条件配置弹窗 -->
    <ElDialog v-model="configVisible" title="认证条件配置" width="600px" @close="resetConfig">
      <ElForm label-width="100px">
        <ElFormItem label="申请逻辑">
          <ElRadioGroup v-model="configForm.logic_type">
            <ElRadio value="any">满足任意一项即可</ElRadio>
            <ElRadio value="specific_count" style="margin-left:16px">满足指定数量</ElRadio>
          </ElRadioGroup>
          <div v-if="configForm.logic_type === 'specific_count'" style="margin-top:12px">
            <span style="margin-right:8px">从</span>
            <ElInputNumber v-model="configForm.logic_count" :min="1" :max="configForm.conditions.filter((c: any) => c.is_active).length || 1" size="small" style="width:80px" />
            <span style="margin:0 8px">项中满足</span>
            <ElInputNumber v-model="configForm.min_meet" :min="1" :max="configForm.logic_count" size="small" style="width:80px" />
            <span style="margin-left:8px">项即可</span>
          </div>
        </ElFormItem>

        <ElDivider />

        <div v-for="cond in conditionDefs" :key="cond.type" style="margin-bottom:16px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
            <ElSwitch v-model="cond.is_active" size="small" />
            <span style="font-weight:600;width:100px">{{ cond.label }}</span>
            <template v-if="cond.is_active && cond.type !== 'app_developer'">
              <span style="margin-left:16px;font-size:13px;color:#666">阈值:</span>
              <ElInputNumber v-model="cond.threshold" :min="1" :max="99999" size="small" style="width:120px" />
              <span style="font-size:13px;color:#666">{{ cond.unit }}</span>
            </template>
            <template v-if="cond.is_active && cond.type === 'app_developer'">
              <span style="font-size:13px;color:#666;margin-left:16px">需提供已审核通过的应用作为证明</span>
            </template>
          </div>
        </div>
      </ElForm>
      <template #footer>
        <ElButton @click="configVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="configSaving" @click="saveConfig">保存配置</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import { Setting } from '@element-plus/icons-vue'
import { fetchVerificationList, fetchReviewVerification, fetchCancelVerification, fetchVerificationConfig, fetchSaveVerificationConfig } from '@/api/verification'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'VerificationReview' })

const filterStatus = ref('pending')
const currentReq = ref<any>(null)
const detailVisible = ref(false)
const reviewComment = ref('')
const reviewing = ref(false)

const columns = [
  { prop: 'user_name', label: '用户名', width: 100 },
  { prop: 'nickname', label: '昵称', width: 100 },
  { prop: 'real_name', label: '真实姓名', width: 100 },
  { prop: 'organization', label: '机构', width: 140 },
  { prop: 'reason', label: '申请称号', width: 160, formatter: (row: any) => row.reason ? (row.reason.length > 15 ? row.reason.slice(0, 15) + '...' : row.reason) : '-' },
  { prop: 'selected_condition', label: '认证条件', width: 120,
    formatter: (row: any) => {
      const label = conditionLabel(row.selected_condition)
      if (row.selected_app_name) return `${label} - ${row.selected_app_name}`
      return label || '-'
    }
  },
  {
    prop: 'status', label: '状态', width: 90,
    formatter: (row: any) => {
      const map: Record<string, { type: string; text: string }> = {
        pending: { type: 'warning', text: '待审核' },
        approved: { type: 'success', text: '已通过' },
        rejected: { type: 'danger', text: '已拒绝' }
      }
      const cfg = map[row.status] || { type: 'info', text: row.status }
      return h(ElTag, { type: cfg.type, size: 'small' }, () => cfg.text)
    }
  },
  { prop: 'create_time', label: '申请时间', width: 160 },
  {
    label: '操作', width: 100, fixed: 'right' as const,
    formatter: (row: any) =>
      h(ElButton, { size: 'small', type: 'primary', link: true, onClick: () => showDetail(row) }, () => '审核详情')
  }
]

const conditionDefs = reactive([
  { type: 'follower_count', label: '粉丝数量', unit: '人', threshold: 100, is_active: false },
  { type: 'app_count', label: '上传应用数量', unit: '个', threshold: 3, is_active: false },
  { type: 'app_developer', label: '应用开发者', unit: '', threshold: 0, is_active: false },
  { type: 'post_count', label: '发帖数量', unit: '条', threshold: 10, is_active: false },
])

function conditionLabel(type: string) {
  const def = conditionDefs.find(c => c.type === type)
  return def ? def.label : type || '-'
}

const configVisible = ref(false)
const configSaving = ref(false)
const configForm = reactive({
  logic_type: 'any',
  logic_count: 1,
  min_meet: 1,
  conditions: [] as any[],
})

async function openConfig() {
  configVisible.value = true
  try {
    const data: any = await fetchVerificationConfig()
    if (data && data.conditions) {
      configForm.logic_type = data.logic_type || 'any'
      configForm.logic_count = data.logic_count || 1
      configForm.min_meet = data.logic_count || 1
      data.conditions.forEach((c: any) => {
        const def = conditionDefs.find(d => d.type === c.condition_type)
        if (def) {
          def.is_active = !!c.is_active
          def.threshold = c.threshold || 0
        }
      })
    }
  } catch (e: any) {
    ElMessage.error('加载配置失败: ' + (e.message || '请确认已登录管理员账号'))
  }
}

function resetConfig() {
  conditionDefs.forEach(d => { d.is_active = false; d.threshold = d.type === 'follower_count' ? 100 : d.type === 'app_count' ? 3 : d.type === 'post_count' ? 10 : 0 })
  configForm.logic_type = 'any'
  configForm.logic_count = 1
  configForm.min_meet = 1
}

async function saveConfig() {
  const conditions = conditionDefs.map(c => ({
    condition_type: c.type,
    threshold: c.threshold,
    is_active: c.is_active,
  }))
  const activeCount = conditions.filter(c => c.is_active).length
  if (activeCount === 0) {
    ElMessage.warning('请至少启用一项认证条件')
    configSaving.value = false
    return
  }
  configSaving.value = true
  try {
    const logicCount = configForm.logic_type === 'specific_count' ? Math.max(1, Math.min(activeCount, configForm.logic_count)) : activeCount
    await fetchSaveVerificationConfig({
      conditions,
      logic_type: configForm.logic_type,
      logic_count: configForm.logic_type === 'specific_count' ? configForm.min_meet : logicCount,
    })
    ElMessage.success('配置已保存')
    configVisible.value = false
  } catch (e: any) {
    ElMessage.error('保存失败: ' + (e.message || '请确认已登录管理员账号'))
  } finally { configSaving.value = false }
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: (params: any) =>
      fetchVerificationList({ status: filterStatus.value, page: params.current, pageSize: params.size }),
    apiParams: { current: 1, size: 20 }
  }
})

function showDetail(row: any) {
  currentReq.value = row
  reviewComment.value = ''
  detailVisible.value = true
}

async function doReview(action: string) {
  reviewing.value = true
  try {
    await fetchReviewVerification(currentReq.value.id, { action, comment: reviewComment.value })
    ElMessage.success(action === 'approve' ? '已通过认证' : '已拒绝认证')
    detailVisible.value = false
    refreshData()
  } finally { reviewing.value = false }
}

async function cancelVerify() {
  await ElMessageBox.confirm('确定取消该用户的蓝V认证？', '提示', { type: 'warning' })
  await fetchCancelVerification(currentReq.value.user_id)
  ElMessage.success('认证已取消')
  detailVisible.value = false
  refreshData()
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
