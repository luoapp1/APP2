<template>
  <div class="invite-config-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>邀请码生成配置</span>
          <ElButton type="primary" @click="doSave" :loading="saving">保存配置</ElButton>
        </div>
      </template>

      <ElForm label-width="140px">
        <ElDivider content-position="left">基础设置</ElDivider>
        <ElFormItem label="付费生成开关">
          <ElSwitch v-model="form.enabled" active-text="开启" inactive-text="关闭" />
          <span class="form-hint">开启后，用户生成含奖励的邀请码需支付余额</span>
        </ElFormItem>

        <ElDivider content-position="left">奖励计费标准</ElDivider>
        <ElFormItem label="积分费用">
          <ElInputNumber v-model="form.pointsCost" :min="0" :precision="2" />
          <span class="form-hint">每1积分需支付的余额（0=不允许积分奖励）</span>
        </ElFormItem>
        <ElFormItem label="余额费用">
          <ElInputNumber v-model="form.balanceCost" :min="0" :precision="2" />
          <span class="form-hint">每1余额奖励需支付的余额（0=不允许余额奖励）</span>
        </ElFormItem>
        <ElFormItem label="经验费用">
          <ElInputNumber v-model="form.expCost" :min="0" :precision="2" />
          <span class="form-hint">每1经验需支付的余额（0=不允许经验奖励）</span>
        </ElFormItem>

        <ElDivider content-position="left">会员奖励定价</ElDivider>
        <p class="section-tip">配置不同天数会员的生成费用，用户只能选择已配置的天数</p>
        <ElFormItem label="会员定价列表">
          <div style="width:100%">
            <div v-for="(item, index) in form.membershipPricingList" :key="index"
              style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
              <ElInputNumber v-model="item.days" :min="1" :max="3650" placeholder="天数" style="width:100px" />
              <span style="color:#6b7280">天 =</span>
              <ElInputNumber v-model="item.cost" :min="0" :precision="2" placeholder="费用" style="width:120px" />
              <span style="color:#6b7280">余额</span>
              <ElButton size="small" type="danger" :icon="Delete" circle @click="removeMembershipItem(index)" />
            </div>
            <ElButton size="small" type="primary" @click="addMembershipItem" style="margin-top:4px">+ 添加定价</ElButton>
          </div>
        </ElFormItem>

        <ElDivider content-position="left">VIP折扣设置</ElDivider>
        <ElFormItem label="VIP折扣开关">
          <ElSwitch v-model="form.vipDiscountEnabled" active-text="开启" inactive-text="关闭" />
          <span class="form-hint">开启后，指定等级会员生成邀请码可享受折扣</span>
        </ElFormItem>
        <template v-if="form.vipDiscountEnabled">
          <ElFormItem label="适用会员等级">
            <ElSelect v-model="form.vipDiscountLevelId" placeholder="选择会员等级" style="width:200px">
              <ElOption v-for="lv in levelList" :key="lv.id" :label="lv.name" :value="lv.id" />
            </ElSelect>
          </ElFormItem>
          <ElFormItem label="折扣率">
            <ElInputNumber v-model="form.vipDiscountRate" :min="0.1" :max="1" :precision="2" :step="0.05" />
            <span class="form-hint">例如 0.8 = 8折（支付原价的80%），1.0 = 无折扣</span>
          </ElFormItem>
        </template>
      </ElForm>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { Delete } from '@element-plus/icons-vue'
import { fetchInviteGenerateConfig, saveInviteGenerateConfig } from '@/api/invite'
import { fetchGetMembershipLevelList } from '@/api/operation'

defineOptions({ name: 'InviteConfigManage' })

const saving = ref(false)
const levelList = ref<any[]>([])

const form = reactive({
  enabled: false,
  pointsCost: 1,
  balanceCost: 1,
  expCost: 1,
  membershipPricingList: [] as { days: number; cost: number }[],
  vipDiscountEnabled: false,
  vipDiscountLevelId: null as number | null,
  vipDiscountRate: 0.8
})

function addMembershipItem() {
  form.membershipPricingList.push({ days: 30, cost: 100 })
}

function removeMembershipItem(index: number) {
  form.membershipPricingList.splice(index, 1)
}

async function loadConfig() {
  try {
    const res: any = await fetchInviteGenerateConfig()
    const c = res || {}
    form.enabled = c.enabled || false
    form.pointsCost = c.pointsCost ?? 1
    form.balanceCost = c.balanceCost ?? 1
    form.expCost = c.expCost ?? 1
    const pricing = c.membershipPricing || {}
    form.membershipPricingList = Object.entries(pricing).map(([days, cost]) => ({
      days: Number(days),
      cost: Number(cost)
    }))
    if (form.membershipPricingList.length === 0) {
      form.membershipPricingList.push({ days: 30, cost: 100 })
    }
    form.vipDiscountEnabled = c.vipDiscount?.enabled || false
    form.vipDiscountLevelId = c.vipDiscount?.levelId || null
    form.vipDiscountRate = c.vipDiscount?.rate || 0.8
  } catch {
    form.membershipPricingList = [{ days: 30, cost: 100 }]
  }
}

async function loadLevels() {
  try {
    const res: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
    levelList.value = (res && res.records) ? res.records : []
  } catch { levelList.value = [] }
}

async function doSave() {
  saving.value = true
  try {
    const pricing: Record<string, number> = {}
    for (const item of form.membershipPricingList) {
      if (item.days > 0 && item.cost > 0) {
        pricing[String(item.days)] = item.cost
      }
    }
    const data = {
      enabled: form.enabled,
      pointsCost: form.pointsCost,
      balanceCost: form.balanceCost,
      expCost: form.expCost,
      membershipPricing: pricing,
      vipDiscount: form.vipDiscountEnabled ? {
        enabled: true,
        levelId: form.vipDiscountLevelId,
        rate: form.vipDiscountRate
      } : { enabled: false, levelId: null, rate: 0.8 }
    }
    await saveInviteGenerateConfig(data)
    ElMessage.success('配置已保存')
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '保存失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadConfig()
  loadLevels()
})
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.form-hint { margin-left: 10px; color: #909399; font-size: 12px; }
.section-tip { color: #909399; font-size: 12px; margin: -8px 0 12px 0; padding-left: 140px; }
</style>
