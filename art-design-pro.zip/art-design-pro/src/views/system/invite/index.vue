<!-- 邀请码管理页面 -->
<template>
  <div class="invite-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>邀请码管理</span>
          <ElSpace wrap>
            <ElSelect v-model="filterStatus" placeholder="状态筛选" clearable style="width:120px" @change="loadData">
              <ElOption label="未使用" value="unused" />
              <ElOption label="已使用" value="used" />
            </ElSelect>
            <ElButton type="primary" @click="showGenerate">生成邀请码</ElButton>
          </ElSpace>
        </div>
      </template>
      <ElTable :data="data" v-loading="loading" stripe>
        <ElTableColumn prop="code" label="邀请码" width="140">
          <template #default="{ row }">
            <span style="font-family:monospace;font-size:14px;letter-spacing:1px">{{ row.code }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="created_by_name" label="创建者" width="100" />
        <ElTableColumn prop="type" label="类型" width="80">
          <template #default="{ row }">
            <ElTag :type="row.type==='admin'?'':'success'" size="small">{{ row.type==='admin'?'系统':'用户' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="使用情况" width="100">
          <template #default="{ row }">{{ row.use_count }}/{{ row.max_uses }}</template>
        </ElTableColumn>
        <ElTableColumn prop="used_by_name" label="使用者" width="100">
          <template #default="{ row }">{{ row.used_by_name || '-' }}</template>
        </ElTableColumn>
        <ElTableColumn label="奖励" width="140">
          <template #default="{ row }">
            <span v-if="row.reward_type" class="text-xs" style="color:#409EFF">{{ formatReward(row) }}</span>
            <span v-else class="text-xs" style="color:#909399">无奖励</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="expires_at" label="过期时间" width="140">
          <template #default="{ row }">{{ row.expires_at || '永久' }}</template>
        </ElTableColumn>
        <ElTableColumn prop="used_at" label="使用时间" width="140">
          <template #default="{ row }">{{ row.used_at || '-' }}</template>
        </ElTableColumn>
        <ElTableColumn prop="create_time" label="创建时间" width="140" />
        <ElTableColumn label="状态" width="80">
          <template #default="{ row }">
            <ElTag :type="row.status==='1'?'success':'info'" size="small">{{ row.status==='1'?'有效':'已用' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="80">
          <template #default="{ row }">
            <ElButton size="small" link type="danger" @click="doDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
      <div class="pagination-wrap">
        <ElPagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="total"
          :page-sizes="[10,20,50]" layout="total,sizes,prev,pager,next" @size-change="handleSizeChange"
          @current-change="handleCurrentChange" background />
      </div>
    </ElCard>

    <!-- 生成邀请码对话框 -->
    <ElDialog v-model="generateVisible" title="生成邀请码" width="550px">
      <ElForm label-width="100px">
        <ElFormItem label="生成数量">
          <ElInputNumber v-model="genForm.count" :min="1" :max="100" />
        </ElFormItem>
        <ElFormItem label="最大使用次数">
          <ElInputNumber v-model="genForm.maxUses" :min="1" :max="9999" />
        </ElFormItem>
        <ElFormItem label="有效天数(天)">
          <ElInputNumber v-model="genForm.expiresDays" :min="0" :max="3650" />
          <span class="form-hint">0=永久有效</span>
        </ElFormItem>
        <ElDivider>奖励设置（选填）</ElDivider>
        <ElFormItem label="奖励积分">
          <ElInputNumber v-model="genForm.rewardPoints" :min="0" :max="999999" placeholder="0=不奖励" />
        </ElFormItem>
        <ElFormItem label="奖励余额">
          <ElInputNumber v-model="genForm.rewardBalance" :min="0" :max="999999" :precision="2" placeholder="0=不奖励" />
        </ElFormItem>
        <ElFormItem label="奖励经验">
          <ElInputNumber v-model="genForm.rewardExp" :min="0" :max="999999" placeholder="0=不奖励" />
        </ElFormItem>
        <ElFormItem label="赠送会员">
          <ElSelect v-model="genForm.rewardLevelId" placeholder="不赠送" clearable>
            <ElOption v-for="lv in levelList" :key="lv.id" :label="lv.name" :value="lv.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="会员天数" v-if="genForm.rewardLevelId">
          <ElInputNumber v-model="genForm.rewardDuration" :min="1" :max="3650" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="generateVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="genLoading" @click="doGenerate">生成</ElButton>
      </template>
    </ElDialog>

    <!-- 生成结果 -->
    <ElDialog v-model="resultVisible" title="生成的邀请码" width="500px">
      <div v-for="c in generatedCodes" :key="c"
        style="font-family:monospace;font-size:18px;padding:10px;background:#f0f9ff;margin:6px 0;border-radius:6px;text-align:center;letter-spacing:2px;border:1px dashed #409EFF">
        {{ c }}
      </div>
      <p class="result-warn">请保存以上邀请码，关闭后将无法再次查看。</p>
      <template #footer>
        <ElButton type="primary" @click="resultVisible = false">我已保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchInviteList, fetchGenerateInvite, deleteInvite } from '@/api/invite'
import { fetchGetMembershipLevelList } from '@/api/operation'

defineOptions({ name: 'InviteManage' })

const generateVisible = ref(false)
const resultVisible = ref(false)
const genLoading = ref(false)
const generatedCodes = ref<string[]>([])
const genForm = reactive({
  count: 1, maxUses: 1, expiresDays: 0,
  rewardPoints: 0, rewardBalance: 0, rewardExp: 0,
  rewardLevelId: null as number | null, rewardDuration: 30
})
const filterStatus = ref('')
const data = ref<any[]>([])
const loading = ref(false)
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const levelList = ref<any[]>([])

async function loadLevels() {
  try {
    const res: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
    levelList.value = (res && res.records) ? res.records : []
  } catch { levelList.value = [] }
}

async function loadData() {
  loading.value = true
  try {
    const res: any = await fetchInviteList({ page: currentPage.value, pageSize: pageSize.value, status: filterStatus.value || undefined })
    data.value = res.list || []
    total.value = res.total || 0
  } finally { loading.value = false }
}

function handleSizeChange(size: number) {
  pageSize.value = size
  currentPage.value = 1
  loadData()
}

function handleCurrentChange(page: number) {
  currentPage.value = page
  loadData()
}

function showGenerate() {
  Object.assign(genForm, { count: 1, maxUses: 1, expiresDays: 0, rewardPoints: 0, rewardBalance: 0, rewardExp: 0, rewardLevelId: null, rewardDuration: 30 })
  generateVisible.value = true
}

function formatReward(row: any): string {
  const parts: string[] = []
  const types = String(row.reward_type || '').split(',')
  const values = String(row.reward_value || '').split(',')
  for (let i = 0; i < types.length; i++) {
    const t = types[i].trim()
    const v = values[i] || ''
    if (t === 'points') parts.push(`${v}积分`)
    else if (t === 'balance') parts.push(`${v}元`)
    else if (t === 'experience') parts.push(`${v}经验`)
    else if (t === 'membership') parts.push(`会员${row.reward_duration || 30}天`)
  }
  return parts.join('、') || '-'
}

async function doGenerate() {
  genLoading.value = true
  try {
    const rewardTypes: string[] = []
    const rewardValues: string[] = []
    if (genForm.rewardPoints > 0) { rewardTypes.push('points'); rewardValues.push(String(genForm.rewardPoints)) }
    if (genForm.rewardBalance > 0) { rewardTypes.push('balance'); rewardValues.push(String(genForm.rewardBalance)) }
    if (genForm.rewardExp > 0) { rewardTypes.push('experience'); rewardValues.push(String(genForm.rewardExp)) }
    if (genForm.rewardLevelId) { rewardTypes.push('membership'); rewardValues.push(String(genForm.rewardLevelId)) }

    const res: any = await fetchGenerateInvite({
      ...genForm,
      rewardType: rewardTypes.join(','),
      rewardValue: rewardValues.join(',')
    })
    generatedCodes.value = res.codes || []
    generateVisible.value = false
    resultVisible.value = true
    loadData()
  } finally { genLoading.value = false }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm(`确定删除邀请码 ${row.code}?`, '确认', { type: 'warning' })
    await deleteInvite(row.id)
    ElMessage.success('已删除')
    loadData()
  } catch { /* cancel */ }
}

onMounted(() => { loadData(); loadLevels() })
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.form-hint { margin-left: 8px; color: #909399; font-size: 12px; }
.result-warn { margin-top: 12px; color: #e6a23c; font-size: 13px; text-align: center; }
.pagination-wrap { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
