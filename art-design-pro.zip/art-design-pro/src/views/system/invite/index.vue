<!-- 邀请码管理页面 -->
<template>
  <div class="invite-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>邀请码管理</span>
          <ElSpace wrap>
            <ElButton type="primary" @click="showGenerate">生成邀请码</ElButton>
          </ElSpace>
        </div>
      </template>

      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>

    <ElDialog v-model="generateVisible" title="生成邀请码" width="500px">
      <ElForm label-width="100px">
        <ElFormItem label="生成数量">
          <ElInputNumber v-model="genForm.count" :min="1" :max="100" />
        </ElFormItem>
        <ElFormItem label="使用次数">
          <ElInputNumber v-model="genForm.maxUses" :min="1" :max="9999" />
        </ElFormItem>
        <ElFormItem label="有效天数">
          <ElInputNumber v-model="genForm.expiresDays" :min="0" :max="365" />
          <span style="margin-left:8px;color:#999">0=永久有效</span>
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="generateVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="genLoading" @click="doGenerate">生成</ElButton>
      </template>
    </ElDialog>

    <ElDialog v-model="resultVisible" title="生成的邀请码" width="500px">
      <div v-for="c in generatedCodes" :key="c" style="font-family:monospace;font-size:18px;padding:8px;background:#f5f7fa;margin:4px 0;border-radius:4px;text-align:center;letter-spacing:2px">{{ c }}</div>
      <p style="margin-top:12px;color:#e6a23c">请保存以上邀请码，关闭后将无法再次查看。</p>
      <template #footer>
        <ElButton type="primary" @click="resultVisible = false">我已保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchInviteList, fetchGenerateInvite } from '@/api/invite'
import { useTable } from '@/hooks/core/useTable'

defineOptions({ name: 'InviteManage' })

const generateVisible = ref(false)
const resultVisible = ref(false)
const genLoading = ref(false)
const generatedCodes = ref<string[]>([])
const genForm = reactive({ count: 5, maxUses: 1, expiresDays: 30 })
const filterStatus = ref('')

const columns = [
  { prop: 'code', label: '邀请码', width: 140 },
  { prop: 'created_by_name', label: '创建者', width: 100 },
  { prop: 'use_count', label: '使用次数', width: 80 },
  { prop: 'max_uses', label: '最大次数', width: 80 },
  { prop: 'used_by_name', label: '使用者', width: 100 },
  { prop: 'used_at', label: '使用时间', width: 160 },
  { prop: 'expires_at', label: '过期时间', width: 160 },
  { prop: 'status', label: '状态', width: 80 },
  { prop: 'create_time', label: '创建时间', width: 160 }
]

async function fetchData() {
  return await fetchInviteList({ page: pagination.value.currentPage, pageSize: pagination.value.pageSize, status: filterStatus.value || undefined })
}

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable(fetchData)

function showGenerate() {
  genForm.count = 5
  genForm.maxUses = 1
  genForm.expiresDays = 30
  generateVisible.value = true
}

async function doGenerate() {
  genLoading.value = true
  try {
    const res: any = await fetchGenerateInvite(genForm)
    generatedCodes.value = res.codes
    generateVisible.value = false
    resultVisible.value = true
    refreshData()
  } finally { genLoading.value = false }
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
