<!-- 自定义任务管理页面 -->
<template>
  <div class="task-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>自定义任务管理</span>
          <ElButton type="primary" @click="showForm(null)">新增任务</ElButton>
        </div>
      </template>

      <ElTable :data="taskList" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="name" label="任务名称" minWidth="140" />
        <ElTableColumn prop="task_type" label="周期" width="80">
          <template #default="{ row }">
            <ElTag size="small">{{ typeLabel(row.task_type) }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="action_type" label="动作" width="100">
          <template #default="{ row }">
            {{ actionLabel(row.action_type) }}
          </template>
        </ElTableColumn>
        <ElTableColumn prop="target_count" label="目标次数" width="80" />
        <ElTableColumn prop="points_reward" label="积分奖励" width="80" />
        <ElTableColumn prop="exp_reward" label="经验奖励" width="80" />
        <ElTableColumn prop="balance_reward" label="余额奖励" width="80" />
        <ElTableColumn prop="sort_order" label="排序" width="70" />
        <ElTableColumn label="状态" width="70">
          <template #default="{ row }">
            <ElTag :type="row.status === '1' ? 'success' : 'info'" size="small">
              {{ row.status === '1' ? '启用' : '禁用' }}
            </ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" link type="primary" @click="showForm(row)">编辑</ElButton>
            <ElButton size="small" link type="danger" @click="doDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElDialog v-model="formVisible" :title="editId ? '编辑任务' : '新增任务'" width="600px" @close="resetForm">
      <ElForm :model="taskForm" label-width="110px" :disabled="saving">
        <ElFormItem label="任务名称" required>
          <ElInput v-model="taskForm.name" placeholder="例如: 每日发帖" maxlength="50" />
        </ElFormItem>
        <ElFormItem label="任务描述">
          <ElInput v-model="taskForm.description" type="textarea" :rows="2" placeholder="任务详细描述" />
        </ElFormItem>
        <ElFormItem label="任务图标">
          <ElInput v-model="taskForm.icon" placeholder="图标URL(可选)" />
        </ElFormItem>
        <ElRow :gutter="16">
          <ElCol :span="12">
            <ElFormItem label="任务周期" required>
              <ElSelect v-model="taskForm.task_type" placeholder="选择周期">
                <ElOption label="每日" value="daily" />
                <ElOption label="每周" value="weekly" />
                <ElOption label="每月" value="monthly" />
                <ElOption label="一次性" value="once" />
              </ElSelect>
            </ElFormItem>
          </ElCol>
          <ElCol :span="12">
            <ElFormItem label="动作类型" required>
              <ElSelect v-model="taskForm.action_type" placeholder="选择动作">
                <ElOption label="发帖" value="post" />
                <ElOption label="评论" value="comment" />
                <ElOption label="点赞" value="like" />
                <ElOption label="签到" value="checkin" />
                <ElOption label="分享" value="share" />
                <ElOption label="下载应用" value="download" />
                <ElOption label="注册" value="register" />
                <ElOption label="关注" value="follow" />
                <ElOption label="收藏" value="favorite" />
                <ElOption label="购买" value="purchase" />
                <ElOption label="上传文件" value="upload" />
                <ElOption label="邀请好友" value="invite" />
                <ElOption label="完善资料" value="profile" />
                <ElOption label="浏览帖子" value="view_post" />
              </ElSelect>
            </ElFormItem>
          </ElCol>
        </ElRow>
        <ElFormItem label="目标次数">
          <ElInputNumber v-model="taskForm.target_count" :min="1" :max="9999" />
          <span class="form-tip" style="margin-left:8px">完成该动作所需的次数</span>
        </ElFormItem>
        <ElDivider content-position="left">奖励设置</ElDivider>
        <ElRow :gutter="16">
          <ElCol :span="8">
            <ElFormItem label="积分奖励">
              <ElInputNumber v-model="taskForm.points_reward" :min="0" />
            </ElFormItem>
          </ElCol>
          <ElCol :span="8">
            <ElFormItem label="经验奖励">
              <ElInputNumber v-model="taskForm.exp_reward" :min="0" />
            </ElFormItem>
          </ElCol>
          <ElCol :span="8">
            <ElFormItem label="余额奖励">
              <ElInputNumber v-model="taskForm.balance_reward" :min="0" :precision="2" />
            </ElFormItem>
          </ElCol>
        </ElRow>
        <ElFormItem label="排序">
          <ElInputNumber v-model="taskForm.sort_order" :min="0" :max="999" />
        </ElFormItem>
        <ElFormItem label="状态">
          <ElSwitch v-model="taskForm.status" active-value="1" inactive-value="0" active-text="启用" inactive-text="禁用" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="formVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="doSave">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { fetchTaskList, saveTask, deleteTask } from '@/api/task'

defineOptions({ name: 'CustomTask' })

const taskList = ref<any[]>([])
const loading = ref(false)
const saving = ref(false)
const formVisible = ref(false)
const editId = ref<number | null>(null)

const taskForm = reactive({
  id: null as number | null,
  name: '',
  description: '',
  icon: '',
  task_type: 'daily',
  action_type: 'post',
  target_count: 1,
  points_reward: 0,
  exp_reward: 0,
  balance_reward: 0,
  status: '1',
  sort_order: 0
})

function typeLabel(val: string) {
  const map: Record<string, string> = { daily: '每日', weekly: '每周', monthly: '每月', once: '一次性' }
  return map[val] || val
}

function actionLabel(val: string) {
  const map: Record<string, string> = {
    post: '发帖', comment: '评论', like: '点赞', checkin: '签到', share: '分享', download: '下载应用',
    register: '注册', follow: '关注', favorite: '收藏', purchase: '购买', upload: '上传文件',
    invite: '邀请好友', profile: '完善资料', view_post: '浏览帖子'
  }
  return map[val] || val
}

async function loadList() {
  loading.value = true
  try {
    const res: any = await fetchTaskList()
    taskList.value = res || []
  } finally {
    loading.value = false
  }
}

function showForm(row: any) {
  if (row) {
    editId.value = row.id
    Object.assign(taskForm, {
      id: row.id,
      name: row.name,
      description: row.description || '',
      icon: row.icon || '',
      task_type: row.task_type,
      action_type: row.action_type,
      target_count: row.target_count || 1,
      points_reward: row.points_reward || 0,
      exp_reward: row.exp_reward || 0,
      balance_reward: row.balance_reward || 0,
      status: row.status || '1',
      sort_order: row.sort_order || 0
    })
  } else {
    editId.value = null
    resetForm()
  }
  formVisible.value = true
}

function resetForm() {
  Object.assign(taskForm, {
    id: null, name: '', description: '', icon: '',
    task_type: 'daily', action_type: 'post', target_count: 1,
    points_reward: 0, exp_reward: 0, balance_reward: 0,
    status: '1', sort_order: 0
  })
}

async function doSave() {
  if (!taskForm.name) {
    ElMessage.warning('请输入任务名称')
    return
  }
  saving.value = true
  try {
    await saveTask(taskForm)
    ElMessage.success(editId.value ? '更新成功' : '创建成功')
    formVisible.value = false
    loadList()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    saving.value = false
  }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm(`确定删除任务「${row.name}」?`, '确认删除', { type: 'warning' })
    await deleteTask(row.id)
    ElMessage.success('删除成功')
    loadList()
  } catch { /* 取消 */ }
}

onMounted(loadList)
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.form-tip { font-size: 12px; color: #909399; }
</style>
