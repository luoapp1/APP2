<template>
  <div class="w-full h-full p-0 bg-transparent border-none shadow-none">
    <div class="relative flex-b mt-2.5 max-md:block max-md:mt-1">
      <div class="w-112 mr-5 max-md:w-full max-md:mr-0">
        <div class="art-card-sm relative p-9 pb-6 overflow-hidden text-center">
          <img class="absolute top-0 left-0 w-full h-50 object-cover" src="@imgs/user/bg.webp" />
          <img
            class="relative z-10 w-20 h-20 mt-30 mx-auto object-cover border-2 border-white rounded-full"
            :src="$fixImgUrl(userInfo.avatar || userInfo.dAvatar || defaultAvatar)"
          />
          <h2 class="mt-5 text-xl font-normal">{{ userInfo.nickname || userInfo.userName || '用户' }}</h2>
          <p class="mt-5 text-sm">{{ userInfo.signature || '这个人很懒，什么都没写...' }}</p>

          <div class="w-75 mx-auto mt-7.5 text-left">
            <div class="mt-2.5">
              <ArtSvgIcon icon="ri:mail-line" class="text-g-700" />
              <span class="ml-2 text-sm">{{ userInfo.userEmail || userInfo.email || '未绑定' }}</span>
            </div>
            <div class="mt-2.5">
              <ArtSvgIcon icon="ri:user-3-line" class="text-g-700" />
              <span class="ml-2 text-sm">{{ userInfo.levelName || '普通会员' }}</span>
            </div>
            <div class="mt-2.5">
              <ArtSvgIcon icon="ri:phone-line" class="text-g-700" />
              <span class="ml-2 text-sm">{{ userInfo.userPhone || userInfo.phone || '未绑定' }}</span>
            </div>
            <div class="mt-2.5">
              <ArtSvgIcon icon="ri:dribbble-fill" class="text-g-700" />
              <span class="ml-2 text-sm">{{ userInfo.bio || '这个人很神秘，没有留下任何介绍' }}</span>
            </div>
          </div>

          <div class="mt-10">
            <h3 class="text-sm font-medium">标签</h3>
            <div class="flex flex-wrap justify-center mt-3.5">
              <div v-for="item in lableList" :key="item" class="py-1 px-1.5 mr-2.5 mb-2.5 text-xs border border-g-300 rounded">
                {{ item }}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex-1 overflow-hidden max-md:w-full max-md:mt-3.5">
        <div class="art-card-sm">
          <h1 class="p-4 text-xl font-normal border-b border-g-300">基本设置</h1>
          <ElForm :model="form" class="box-border p-5 [&>.el-row_.el-form-item]:w-[calc(50%-10px)] [&>.el-row_.el-input]:w-full [&>.el-row_.el-select]:w-full" ref="ruleFormRef" :rules="rules" label-width="86px" label-position="top">
            <ElRow>
              <ElFormItem label="昵称" prop="nickname">
                <ElInput v-model="form.nickname" :disabled="!isEdit" />
              </ElFormItem>
              <ElFormItem label="性别" prop="gender" class="ml-5">
                <ElSelect v-model="form.gender" :disabled="!isEdit">
                  <ElOption v-for="item in genderOptions" :key="item.value" :label="item.label" :value="item.value" />
                </ElSelect>
              </ElFormItem>
            </ElRow>
            <ElRow>
              <ElFormItem label="邮箱" prop="email">
                <ElInput v-model="form.email" :disabled="!isEdit" />
              </ElFormItem>
              <ElFormItem label="手机" prop="phone" class="ml-5">
                <ElInput v-model="form.phone" :disabled="!isEdit" />
              </ElFormItem>
            </ElRow>
            <ElRow>
              <ElFormItem label="QQ" prop="qq">
                <ElInput v-model="form.qq" :disabled="!isEdit" />
              </ElFormItem>
              <ElFormItem label="签名" prop="signature" class="ml-5">
                <ElInput v-model="form.signature" :disabled="!isEdit" />
              </ElFormItem>
            </ElRow>
            <ElFormItem label="个人介绍" prop="bio" class="h-32">
              <ElInput type="textarea" :rows="4" v-model="form.bio" :disabled="!isEdit" />
            </ElFormItem>
            <div class="flex-c justify-end [&_.el-button]:!w-27.5">
              <ElButton type="primary" class="w-22.5" v-ripple :loading="saving" @click="handleEditOrSave">
                {{ isEdit ? '保存' : '编辑' }}
              </ElButton>
            </div>
          </ElForm>
        </div>

        <div class="art-card-sm my-5">
          <h1 class="p-4 text-xl font-normal border-b border-g-300">更改密码</h1>
          <ElForm :model="pwdForm" class="box-border p-5" label-width="86px" label-position="top" ref="pwdFormRef" :rules="pwdRules">
            <ElFormItem label="当前密码" prop="password">
              <ElInput v-model="pwdForm.password" type="password" :disabled="!isEditPwd" show-password />
            </ElFormItem>
            <ElFormItem label="新密码" prop="newPassword">
              <ElInput v-model="pwdForm.newPassword" type="password" :disabled="!isEditPwd" show-password />
            </ElFormItem>
            <ElFormItem label="确认新密码" prop="confirmPassword">
              <ElInput v-model="pwdForm.confirmPassword" type="password" :disabled="!isEditPwd" show-password />
            </ElFormItem>
            <div class="flex-c justify-end [&_.el-button]:!w-27.5">
              <ElButton type="primary" class="w-22.5" v-ripple :loading="savingPwd" @click="handleEditPwdOrSave">
                {{ isEditPwd ? '保存' : '修改密码' }}
              </ElButton>
            </div>
          </ElForm>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import defaultAvatarImg from '@imgs/user/avatar.webp'

defineOptions({ name: 'UserCenter' })

const userStore = useUserStore()
const userInfo = computed(() => (userStore as any).info || {})
const defaultAvatar = defaultAvatarImg
const isEdit = ref(false)
const isEditPwd = ref(false)
const saving = ref(false)
const savingPwd = ref(false)
const ruleFormRef = ref<FormInstance>()
const pwdFormRef = ref<FormInstance>()

const form = reactive({
  nickname: '',
  gender: '男',
  email: '',
  phone: '',
  qq: '',
  signature: '',
  bio: ''
})

const pwdForm = reactive({
  password: '',
  newPassword: '',
  confirmPassword: ''
})

const rules: FormRules = {
  nickname: [{ min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur' }],
  email: [{ type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }]
}

const pwdRules: FormRules = {
  password: [{ required: true, message: '请输入当前密码', trigger: 'blur' }],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度在 6 到 20 位', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认新密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== pwdForm.newPassword) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ]
}

const genderOptions = [
  { value: '男', label: '男' },
  { value: '女', label: '女' }
]

const lableList: Array<string> = ['专注设计', '很有想法', '海纳百川']

const loadUserInfo = () => {
  const info = userInfo.value as any
  form.nickname = info.nickname || info.nickName || ''
  form.gender = info.userGender || info.gender || '男'
  form.email = info.userEmail || info.email || ''
  form.phone = info.userPhone || info.phone || ''
  form.qq = info.qq || ''
  form.signature = info.signature || ''
  form.bio = info.bio || ''
}

const handleEditOrSave = async () => {
  if (!isEdit.value) {
    isEdit.value = true
    return
  }
  await ruleFormRef.value?.validate()
  saving.value = true
  try {
    const userId = (userInfo.value as any).userId || (userInfo.value as any).id || 1
    await request.put({
      url: '/api/user/profile',
      data: {
        userId,
        nickname: form.nickname,
        gender: form.gender,
        email: form.email,
        phone: form.phone,
        qq: form.qq,
        signature: form.signature,
        bio: form.bio
      }
    })
    const ui = userInfo.value as any
    if (form.nickname) ui.nickname = form.nickname
    if (form.signature) ui.signature = form.signature
    ElMessage.success('保存成功')
    isEdit.value = false
  } catch { ElMessage.error('保存失败') }
  finally { saving.value = false }
}

const handleEditPwdOrSave = async () => {
  if (!isEditPwd.value) {
    isEditPwd.value = true
    return
  }
  await pwdFormRef.value?.validate()
  savingPwd.value = true
  try {
    const userId = (userInfo.value as any).userId || (userInfo.value as any).id || 1
    await request.post({
      url: '/api/auth/change-pwd',
      data: {
        userId,
        oldPwd: pwdForm.password,
        newPwd: pwdForm.newPassword
      }
    })
    ElMessage.success('密码修改成功')
    isEditPwd.value = false
    pwdForm.password = ''
    pwdForm.newPassword = ''
    pwdForm.confirmPassword = ''
  } catch { ElMessage.error('修改失败，请检查当前密码') }
  finally { savingPwd.value = false }
}

onMounted(() => {
  loadUserInfo()
})
</script>
