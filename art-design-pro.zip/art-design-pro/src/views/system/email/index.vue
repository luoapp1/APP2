<!-- 邮件配置页面 -->
<template>
  <div class="email-page art-full-height">
    <ElRow :gutter="20">
      <ElCol :span="12">
        <ElCard header="SMTP 配置">
          <ElForm :model="form" label-width="100px" :disabled="saving">
            <ElFormItem label="SMTP主机">
              <ElInput v-model="form.host" placeholder="smtp.qq.com" />
            </ElFormItem>
            <ElFormItem label="端口">
              <ElInputNumber v-model="form.port" :min="1" :max="65535" />
            </ElFormItem>
            <ElFormItem label="SSL加密">
              <ElSwitch v-model="form.secure" />
            </ElFormItem>
            <ElFormItem label="邮箱账号">
              <ElInput v-model="form.user" placeholder="your@email.com" />
            </ElFormItem>
            <ElFormItem label="邮箱密码/授权码">
              <ElInput v-model="form.password" type="password" show-password placeholder="SMTP授权码" />
            </ElFormItem>
            <ElFormItem label="发件人名称">
              <ElInput v-model="form.fromName" placeholder="Art Design Pro" />
            </ElFormItem>
            <ElFormItem label="发件人地址">
              <ElInput v-model="form.fromAddress" placeholder="noreply@example.com" />
            </ElFormItem>
            <ElFormItem label="测试收件地址">
              <ElInput v-model="form.testAddress" placeholder="test@example.com" />
            </ElFormItem>
            <ElFormItem label="注册邮箱验证">
              <ElSwitch v-model="form.registerVerify" />
            </ElFormItem>
            <ElFormItem label="启用">
              <ElSwitch v-model="form.enabled" />
            </ElFormItem>
            <ElFormItem>
              <ElSpace>
                <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
                <ElButton :loading="testing" @click="testEmail">发送测试邮件</ElButton>
              </ElSpace>
            </ElFormItem>
          </ElForm>
        </ElCard>
      </ElCol>
      <ElCol :span="12">
        <ElCard header="使用说明">
          <div class="help-text">
            <h4>QQ邮箱配置</h4>
            <p>SMTP主机: smtp.qq.com</p>
            <p>端口: 465 (SSL)</p>
            <p>密码: 在QQ邮箱设置-账户中生成授权码</p>

            <h4 style="margin-top:16px">163邮箱配置</h4>
            <p>SMTP主机: smtp.163.com</p>
            <p>端口: 465 (SSL)</p>
            <p>密码: 在163邮箱设置中开启SMTP并获取授权码</p>

            <h4 style="margin-top:16px">Gmail配置</h4>
            <p>SMTP主机: smtp.gmail.com</p>
            <p>端口: 465 (SSL)</p>
            <p>密码: 需开启两步验证后生成应用专用密码</p>

            <ElDivider />
            <h4>测试发送</h4>
            <p>保存配置后点击"发送测试邮件"按钮，系统将发送一封测试邮件到您填写的"测试收件地址"。</p>
            <p v-if="testResult" :style="{ color: testResult.success ? '#67c23a' : '#f56c6c' }">测试结果: {{ testResult.message }}</p>
          </div>
        </ElCard>
      </ElCol>
    </ElRow>
  </div>
</template>

<script setup lang="ts">
import { fetchEmailConfig, fetchSaveEmailConfig, fetchTestEmail } from '@/api/email'

defineOptions({ name: 'EmailConfig' })

const saving = ref(false)
const testing = ref(false)
const testResult = ref<{ success: boolean; message: string } | null>(null)

const form = reactive({
  host: '',
  port: 465,
  secure: true,
  user: '',
  password: '',
  fromName: '',
  fromAddress: '',
  testAddress: '',
  registerVerify: false,
  enabled: true
})

onMounted(async () => {
  const res: any = await fetchEmailConfig()
  if (res) Object.assign(form, res, { secure: res.secure === 1, registerVerify: res.register_verify === 1, enabled: res.enabled === 1 })
})

async function saveConfig() {
  saving.value = true
  try {
    await fetchSaveEmailConfig(form)
    ElMessage.success('配置保存成功')
  } catch (e: any) { ElMessage.error(e.message) }
  finally { saving.value = false }
}

async function testEmail() {
  testing.value = true
  testResult.value = null
  try {
    const res: any = await fetchTestEmail()
    testResult.value = { success: res.code === 200, message: res.message }
    ElMessage[res.code === 200 ? 'success' : 'error'](res.message)
  } catch (e: any) { testResult.value = { success: false, message: e.message } }
  finally { testing.value = false }
}
</script>

<style scoped>
.help-text { color: #606266; line-height: 1.8; }
.help-text h4 { margin: 8px 0 4px; }
.help-text p { margin: 2px 0; font-size: 13px; color: #909399; }
</style>
