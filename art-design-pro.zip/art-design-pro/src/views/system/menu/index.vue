<!-- 菜单管理页面 -->
<template>
  <div class="menu-page art-full-height">
    <!-- 搜索栏 -->
    <ArtSearchBar
      v-model="formFilters"
      :items="formItems"
      :showExpand="false"
      @reset="handleReset"
      @search="handleSearch"
    />

    <ElCard class="art-table-card">
      <!-- 表格头部 -->
      <ArtTableHeader
        :showZebra="false"
        :loading="loading"
        v-model:columns="columnChecks"
        @refresh="handleRefresh"
      >
        <template #left>
          <ElButton v-auth="'add'" @click="handleAddMenu" v-ripple> 添加菜单 </ElButton>
          <ElButton @click="toggleExpand" v-ripple>
            {{ isExpanded ? '收起' : '展开' }}
          </ElButton>
        </template>
      </ArtTableHeader>

      <ArtTable
        ref="tableRef"
        rowKey="path"
        :loading="loading"
        :columns="columns"
        :data="filteredTableData"
        :stripe="false"
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
        :default-expand-all="false"
      />

      <!-- 菜单弹窗 -->
      <MenuDialog
        v-model:visible="dialogVisible"
        :type="dialogType"
        :editData="editData"
        :lockType="lockMenuType"
        @submit="handleSubmit"
      />

      <!-- 移动菜单弹窗 -->
      <ElDialog v-model="moveDialogVisible" title="移动菜单" width="450px" align-center>
        <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
          将选中的菜单移动到另一个菜单下作为其子菜单，或移到顶层。
        </p>
        <ElForm label-width="80px">
          <ElFormItem label="当前菜单">
            <ElTag type="warning">{{ moveTargetRow?.meta?.title || moveTargetRow?.name }}</ElTag>
          </ElFormItem>
          <ElFormItem label="目标位置">
            <ElSelect
              v-model="selectedMoveParentId"
              placeholder="选择目标父级菜单，或选[顶层]移至根目录"
              filterable
              style="width: 100%"
            >
              <ElOption label="顶层（作为一级菜单）" :value="0" />
              <ElOption
                v-for="item in moveParentOptions"
                :key="item.id"
                :label="item.label"
                :value="item.id"
              />
            </ElSelect>
          </ElFormItem>
        </ElForm>
        <template #footer>
          <ElButton @click="moveDialogVisible = false">取 消</ElButton>
          <ElButton type="primary" @click="handleConfirmMove" :disabled="selectedMoveParentId === null">确 定</ElButton>
        </template>
      </ElDialog>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import { formatMenuTitle } from '@/utils/router'
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTableColumns } from '@/hooks/core/useTableColumns'
  import type { AppRouteRecord } from '@/types/router'
  import MenuDialog from './modules/menu-dialog.vue'
  import { fetchGetMenuList, fetchGetMenuFlatList, fetchSaveMenu, fetchDeleteMenu } from '@/api/system-manage'
  import { ElTag, ElMessageBox, ElMessage } from 'element-plus'

  defineOptions({ name: 'Menus' })

  // 状态管理
  const loading = ref(false)
  const isExpanded = ref(false)
  const tableRef = ref()

  // 弹窗相关
  const dialogVisible = ref(false)
  const dialogType = ref<'menu' | 'button'>('menu')
  const editData = ref<AppRouteRecord | any>(null)
  const lockMenuType = ref(false)
  const currentParent = ref<any>(null)

  // 移动菜单相关
  const moveDialogVisible = ref(false)
  const moveTargetRow = ref<any>(null)
  const selectedMoveParentId = ref<number | null>(null)
  const menuFlatList = ref<any[]>([])

  // 搜索相关
  const initialSearchState = {
    name: '',
    route: ''
  }

  const formFilters = reactive({ ...initialSearchState })
  const appliedFilters = reactive({ ...initialSearchState })

  const formItems = computed(() => [
    {
      label: '菜单名称',
      key: 'name',
      type: 'input',
      props: { clearable: true }
    },
    {
      label: '路由地址',
      key: 'route',
      type: 'input',
      props: { clearable: true }
    }
  ])

  onMounted(() => {
    getMenuList()
  })

  /**
   * 获取菜单列表数据
   */
  const getMenuList = async (): Promise<void> => {
    loading.value = true

    try {
      const list = await fetchGetMenuList()
      tableData.value = list
    } catch (error) {
      throw error instanceof Error ? error : new Error('获取菜单失败')
    } finally {
      loading.value = false
    }
  }

  /**
   * 获取菜单类型标签颜色
   * @param row 菜单行数据
   * @returns 标签颜色类型
   */
  const getMenuTypeTag = (
    row: AppRouteRecord
  ): 'primary' | 'success' | 'warning' | 'info' | 'danger' => {
    if (row.meta?.isAuthButton) return 'danger'
    if (row.children?.length) return 'info'
    if (row.meta?.link && row.meta?.isIframe) return 'success'
    if (row.path) return 'primary'
    if (row.meta?.link) return 'warning'
    return 'info'
  }

  /**
   * 获取菜单类型文本
   * @param row 菜单行数据
   * @returns 菜单类型文本
   */
  const getMenuTypeText = (row: AppRouteRecord): string => {
    if (row.meta?.isAuthButton) return '按钮'
    if (row.children?.length) return '目录'
    if (row.meta?.link && row.meta?.isIframe) return '内嵌'
    if (row.path) return '菜单'
    if (row.meta?.link) return '外链'
    return '未知'
  }

  // 表格列配置
  const { columnChecks, columns } = useTableColumns(() => [
    {
      prop: 'meta.title',
      label: '菜单名称',
      minWidth: 120,
      formatter: (row: AppRouteRecord) => formatMenuTitle(row.meta?.title)
    },
    {
      prop: 'type',
      label: '菜单类型',
      formatter: (row: AppRouteRecord) => {
        return h(ElTag, { type: getMenuTypeTag(row) }, () => getMenuTypeText(row))
      }
    },
    {
      prop: 'path',
      label: '路由',
      formatter: (row: AppRouteRecord) => {
        if (row.meta?.isAuthButton) return ''
        return row.meta?.link || row.path || ''
      }
    },
    {
      prop: 'meta.authList',
      label: '权限标识',
      formatter: (row: AppRouteRecord) => {
        if (row.meta?.isAuthButton) {
          return row.meta?.authMark || ''
        }
        if (!row.meta?.authList?.length) return ''
        return `${row.meta.authList.length} 个权限标识`
      }
    },
    {
      prop: 'updateTime',
      label: '编辑时间',
      formatter: (row: any) => row.updateTime || row.createTime || '-'
    },
    {
      prop: 'enabled',
      label: '状态',
      formatter: (row: any) => {
        const isEnabled = row.enabled !== false
        return h(ElTag, { type: isEnabled ? 'success' : 'danger' }, () => isEnabled ? '启用' : '禁用')
      }
    },
    {
      prop: 'operation',
      label: '操作',
      width: 180,
      align: 'right',
      formatter: (row: AppRouteRecord) => {
        const buttonStyle = { style: 'text-align: right' }

        if (row.meta?.isAuthButton) {
          return h('div', buttonStyle, [
            h(ArtButtonTable, {
              type: 'edit',
              onClick: () => handleEditAuth(row)
            }),
            h(ArtButtonTable, {
              type: 'delete',
              onClick: () => handleDeleteAuth(row)
            })
          ])
        }

        return h('div', buttonStyle, [
          h(ArtButtonTable, {
            type: 'add',
            onClick: () => handleAddChildMenu(row),
            title: '新增子菜单'
          }),
          h(ArtButtonTable, {
            type: 'edit',
            onClick: () => handleEditMenu(row)
          }),
          h(ArtButtonTable, {
            icon: 'ri:arrow-right-circle-line',
            iconColor: '#6366f1',
            buttonBgColor: 'rgba(99,102,241,.08)',
            onClick: () => handleOpenMoveDialog(row),
            title: '移动'
          }),
          h(ArtButtonTable, {
            type: 'delete',
            onClick: () => handleDeleteMenu(row)
          })
        ])
      }
    }
  ])

  // 数据相关
  const tableData = ref<AppRouteRecord[]>([])

  /**
   * 重置搜索条件
   */
  const handleReset = (): void => {
    Object.assign(formFilters, { ...initialSearchState })
    Object.assign(appliedFilters, { ...initialSearchState })
    getMenuList()
  }

  /**
   * 执行搜索
   */
  const handleSearch = (): void => {
    Object.assign(appliedFilters, { ...formFilters })
    getMenuList()
  }

  /**
   * 刷新菜单列表
   */
  const handleRefresh = (): void => {
    getMenuList()
  }

  /**
   * 深度克隆对象
   * @param obj 要克隆的对象
   * @returns 克隆后的对象
   */
  const deepClone = <T,>(obj: T): T => {
    if (obj === null || typeof obj !== 'object') return obj
    if (obj instanceof Date) return new Date(obj) as T
    if (Array.isArray(obj)) return obj.map((item) => deepClone(item)) as T

    const cloned = {} as T
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        cloned[key] = deepClone(obj[key])
      }
    }
    return cloned
  }

  /**
   * 将权限列表转换为子节点
   * @param items 菜单项数组
   * @returns 转换后的菜单项数组
   */
  const convertAuthListToChildren = (items: AppRouteRecord[]): AppRouteRecord[] => {
    return items.map((item) => {
      const clonedItem = deepClone(item)

      if (clonedItem.children?.length) {
        clonedItem.children = convertAuthListToChildren(clonedItem.children)
      }

      if (item.meta?.authList?.length) {
        const authChildren: AppRouteRecord[] = item.meta.authList.map(
          (auth: { title: string; authMark: string }) => ({
            path: `${item.path}_auth_${auth.authMark}`,
            name: `${String(item.name)}_auth_${auth.authMark}`,
            meta: {
              title: auth.title,
              authMark: auth.authMark,
              isAuthButton: true,
              parentPath: item.path
            }
          })
        )

        clonedItem.children = clonedItem.children?.length
          ? [...clonedItem.children, ...authChildren]
          : authChildren
      }

      return clonedItem
    })
  }

  /**
   * 搜索菜单
   * @param items 菜单项数组
   * @returns 搜索结果数组
   */
  const searchMenu = (items: AppRouteRecord[]): AppRouteRecord[] => {
    const results: AppRouteRecord[] = []

    for (const item of items) {
      const searchName = appliedFilters.name?.toLowerCase().trim() || ''
      const searchRoute = appliedFilters.route?.toLowerCase().trim() || ''
      const menuTitle = formatMenuTitle(item.meta?.title || '').toLowerCase()
      const menuPath = (item.path || '').toLowerCase()
      const nameMatch = !searchName || menuTitle.includes(searchName)
      const routeMatch = !searchRoute || menuPath.includes(searchRoute)

      if (item.children?.length) {
        const matchedChildren = searchMenu(item.children)
        if (matchedChildren.length > 0) {
          const clonedItem = deepClone(item)
          clonedItem.children = matchedChildren
          results.push(clonedItem)
          continue
        }
      }

      if (nameMatch && routeMatch) {
        results.push(deepClone(item))
      }
    }

    return results
  }

  // 过滤后的表格数据
  const filteredTableData = computed(() => {
    const searchedData = searchMenu(tableData.value)
    return convertAuthListToChildren(searchedData)
  })

  /**
   * 收集所有子孙节点 ID
   */
  const getDescendantIds = (items: any[], parentId: number): Set<number> => {
    const ids = new Set<number>()
    const stack = [parentId]
    while (stack.length) {
      const pid = stack.pop()!
      items.forEach((item) => {
        if (item.parentId === pid) {
          ids.add(item.id)
          stack.push(item.id)
        }
      })
    }
    return ids
  }

  /**
   * 构建菜单路径标签
   */
  const buildPathLabel = (flatList: any[], itemId: number): string => {
    const parts: string[] = []
    let current = flatList.find((m) => m.id === itemId)
    while (current) {
      parts.unshift(formatMenuTitle(current.title || current.name))
      current = current.parentId ? flatList.find((m) => m.id === current!.parentId) : null
    }
    return parts.join(' / ')
  }

  /**
   * 可选的父级菜单选项（排除自身及子孙节点）
   */
  const moveParentOptions = computed(() => {
    if (!moveTargetRow.value || !menuFlatList.value.length) return []

    const row = moveTargetRow.value as any
    const excludeIds = getDescendantIds(menuFlatList.value, row.id)
    excludeIds.add(row.id)

    return menuFlatList.value
      .filter((m: any) => !excludeIds.has(m.id))
      .map((m: any) => ({
        id: m.id,
        label: buildPathLabel(menuFlatList.value, m.id)
      }))
  })

  /**
   * 打开移动菜单弹窗
   */
  const handleOpenMoveDialog = async (row: any): Promise<void> => {
    moveTargetRow.value = row
    selectedMoveParentId.value = null

    try {
      const flatList = await fetchGetMenuFlatList()
      menuFlatList.value = flatList || []
    } catch {
      menuFlatList.value = []
    }

    moveDialogVisible.value = true
  }

  /**
   * 确认移动菜单
   */
  const handleConfirmMove = async (): Promise<void> => {
    if (selectedMoveParentId.value === null) return
    const row = moveTargetRow.value as any
    if (!row) return

    try {
      await fetchSaveMenu({
        id: row.id,
        parentId: selectedMoveParentId.value,
        name: row.name,
        path: row.path,
        title: row.meta?.title || row.name,
        component: row.component || '',
        icon: row.meta?.icon || '',
        sortOrder: row.sortOrder || (row.meta?.sortOrder ?? 1),
        isHidden: row.meta?.isHide || false,
        isFullPage: row.meta?.isFullPage || false,
        isKeepAlive: row.meta?.keepAlive ?? true,
        isFixedTab: row.meta?.fixedTab || false,
        enabled: row.enabled !== false,
        redirect: row.redirect || row.meta?.link || '',
        roles: row.meta?.roles || null
      })
      ElMessage.success('移动成功')
      moveDialogVisible.value = false
      getMenuList()
    } catch (error) {
      ElMessage.error('移动失败')
    }
  }

  /**
   * 添加菜单
   */
  const handleAddMenu = (): void => {
    dialogType.value = 'menu'
    editData.value = null
    currentParent.value = null
    lockMenuType.value = false
    dialogVisible.value = true
  }

  const handleAddChildMenu = (row: AppRouteRecord): void => {
    dialogType.value = 'menu'
    editData.value = null
    currentParent.value = row
    lockMenuType.value = false
    dialogVisible.value = true
  }

  /**
   * 添加权限按钮
   */
  const handleAddAuth = (): void => {
    dialogType.value = 'menu'
    editData.value = null
    lockMenuType.value = false
    dialogVisible.value = true
  }

  /**
   * 编辑菜单
   * @param row 菜单行数据
   */
  const handleEditMenu = (row: AppRouteRecord): void => {
    dialogType.value = 'menu'
    editData.value = row
    lockMenuType.value = true
    dialogVisible.value = true
  }

  /**
   * 编辑权限按钮
   * @param row 权限行数据
   */
  const handleEditAuth = (row: AppRouteRecord): void => {
    dialogType.value = 'button'
    editData.value = {
      title: row.meta?.title,
      authMark: row.meta?.authMark
    }
    lockMenuType.value = false
    dialogVisible.value = true
  }

  /**
   * 菜单表单数据类型
   */
  interface MenuFormData {
    name: string
    path: string
    component?: string
    icon?: string
    roles?: string[]
    sort?: number
    [key: string]: any
  }

  /**
   * 提交表单数据
   * @param formData 表单数据
   */
  const handleSubmit = async (formData: MenuFormData): Promise<void> => {
    try {
      if ((formData as any).menuType === 'button') {
        const parent = currentParent.value as any
        if (!parent?.id) {
          ElMessage.error('请先选择父级菜单')
          return
        }
        const existingAuthList: any[] = parent.meta?.authList || []
        const newAuth = {
          title: formData.authName,
          authMark: formData.authLabel
        }
        const updatedAuthList = [...existingAuthList, newAuth]

        await fetchSaveMenu({
          id: parent.id,
          parentId: parent.parentId || 0,
          name: parent.name,
          path: parent.path,
          title: parent.meta?.title || parent.name,
          component: parent.component || '',
          sortOrder: parent.sortOrder || 1,
          authList: updatedAuthList
        })

        ElMessage.success('新增按钮权限成功')
        dialogVisible.value = false
        getMenuList()
        return
      }

      const payload: Record<string, unknown> = {
        name: formData.name,
        path: formData.path,
        title: formData.label || formData.name,
        component: formData.component || (formData.path && !currentParent.value ? '/index/index' : ''),
        icon: formData.icon || '',
        sortOrder: formData.sort || 1,
        isHidden: formData.isHide || false,
        isFullPage: formData.isFullPage || false,
        isKeepAlive: formData.keepAlive !== false,
        isFixedTab: formData.fixedTab || false,
        enabled: formData.isEnable !== false,
        redirect: formData.link || '',
        roles: formData.roles && formData.roles.length > 0 ? formData.roles : null
      }
      if ((editData.value as any)?.id) payload.id = (editData.value as any).id
      if (currentParent.value && (currentParent.value as any).id) {
        payload.parentId = (currentParent.value as any).id
      } else {
        payload.parentId = (editData.value as any)?.parentId ?? 0
      }

      if (payload.id && Number(payload.parentId) === Number(payload.id)) {
        ElMessage.error('不能将菜单设置为自己的子菜单')
        return
      }
      await fetchSaveMenu(payload)
      ElMessage.success((editData.value as any)?.id ? '更新成功' : '新增成功')
      dialogVisible.value = false
      getMenuList()
    } catch (error) {
      console.error('保存菜单失败:', error)
    }
  }

  /**
   * 删除菜单
   */
  const handleDeleteMenu = async (row: any): Promise<void> => {
    try {
      await ElMessageBox.confirm('确定要删除该菜单吗？删除后无法恢复', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      if (row.id) await fetchDeleteMenu(row.id)
      ElMessage.success('删除成功')
      getMenuList()
    } catch (error) {
      if (error !== 'cancel') {
        ElMessage.error('删除失败')
      }
    }
  }

  const handleMoveToTop = async (row: any): Promise<void> => {
    try {
      await ElMessageBox.confirm(`确定将"${row.meta?.title || row.name}"移到顶层吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      await fetchSaveMenu({
        id: row.id,
        parentId: 0,
        name: row.name,
        path: row.path,
        title: row.meta?.title || row.name,
        component: row.component || '',
        icon: row.meta?.icon || '',
        sortOrder: row.sortOrder || (row.meta?.sortOrder ?? 1),
        isHidden: row.meta?.isHide || false,
        isFullPage: row.meta?.isFullPage || false,
        isKeepAlive: row.meta?.keepAlive ?? true,
        isFixedTab: row.meta?.fixedTab || false,
        enabled: row.enabled !== false,
        redirect: row.redirect || row.meta?.link || '',
        roles: row.meta?.roles || null
      })
      ElMessage.success('已移到顶层')
      getMenuList()
    } catch (error) {
      if (error !== 'cancel') ElMessage.error('操作失败')
    }
  }

  const handleDeleteAuth = async (row: any): Promise<void> => {
    try {
      await ElMessageBox.confirm('确定要删除该权限吗？删除后无法恢复', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      if (row.meta?.authMark) {
        const parentId = (editData.value as any)?.parentId
      }
      ElMessage.success('删除成功')
      getMenuList()
    } catch (error) {
      if (error !== 'cancel') {
        ElMessage.error('删除失败')
      }
    }
  }

  /**
   * 切换展开/收起所有菜单
   */
  const toggleExpand = (): void => {
    isExpanded.value = !isExpanded.value
    nextTick(() => {
      if (tableRef.value?.elTableRef && filteredTableData.value) {
        const processRows = (rows: AppRouteRecord[]) => {
          rows.forEach((row) => {
            if (row.children?.length) {
              tableRef.value.elTableRef.toggleRowExpansion(row, isExpanded.value)
              processRows(row.children)
            }
          })
        }
        processRows(filteredTableData.value)
      }
    })
  }
</script>
