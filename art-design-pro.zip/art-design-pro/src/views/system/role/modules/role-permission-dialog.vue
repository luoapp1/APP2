<template>
  <ElDialog
    v-model="visible"
    title="菜单权限"
    width="520px"
    align-center
    class="el-dialog-border"
    @close="handleClose"
  >
    <ElScrollbar height="70vh">
      <div
        v-if="processedMenuList.length === 0"
        style="padding: 20px; text-align: center; color: #999"
      >
        菜单数据为空，请刷新页面后重试（数据量：{{ menuList.length }}）
      </div>
      <div
        v-else
        style="padding: 4px 0 8px; font-size: 12px; color: #666"
      >
        共 {{ menuList.length }} 个一级菜单，{{ authNodeCount }} 个按钮权限节点
      </div>
      <ElTree
        ref="treeRef"
        :data="processedMenuList"
        show-checkbox
        node-key="id"
        :default-expand-all="isExpandAll"
        :checked-keys="checkedMenuIds"
        :props="defaultProps"
        @check="handleTreeCheck"
      >
        <template #default="{ data }">
          <div style="display: flex; align-items: center">
            <span v-if="data.isAuth">
              {{ data.label }}
            </span>
            <span v-else>{{ defaultProps.label(data) }}</span>
          </div>
        </template>
      </ElTree>
    </ElScrollbar>
    <template #footer>
      <ElButton @click="toggleExpandAll">{{ isExpandAll ? '全部收起' : '全部展开' }}</ElButton>
      <ElButton @click="toggleSelectAll" style="margin-left: 8px">{{
        isSelectAll ? '取消全选' : '全部选择'
      }}</ElButton>
      <ElButton type="primary" @click="savePermission">保存</ElButton>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import { useMenuStore } from '@/store/modules/menu'
  import { formatMenuTitle } from '@/utils/router'
  import { fetchGetRolePermissions, fetchSaveRolePermissions } from '@/api/system-manage'
  import { nextTick } from 'vue'

  type RoleListItem = Api.SystemManage.RoleListItem

  interface Props {
    modelValue: boolean
    roleData?: RoleListItem
  }

  interface Emits {
    (e: 'update:modelValue', value: boolean): void
    (e: 'success'): void
  }

  const props = withDefaults(defineProps<Props>(), {
    modelValue: false,
    roleData: undefined
  })

  const emit = defineEmits<Emits>()

  const { menuList } = storeToRefs(useMenuStore())
  const treeRef = ref()
  const isExpandAll = ref(true)
  const isSelectAll = ref(false)
  const checkedMenuIds = ref<(string | number)[]>([])

  const visible = computed({
    get: () => props.modelValue,
    set: (value) => emit('update:modelValue', value)
  })

  interface MenuNode {
    id?: string | number
    name?: string
    label?: string
    meta?: {
      title?: string
      authList?: Array<{
        authMark: string
        title: string
        checked?: boolean
      }>
    }
    children?: MenuNode[]
    [key: string]: any
  }

  const processedMenuList = computed(() => {
    const processNode = (node: MenuNode): MenuNode => {
      const processed = { ...node }

      if (node.meta?.authList?.length) {
        const authNodes = node.meta.authList.map((auth) => ({
          id: `${node.id}_${auth.authMark}`,
          name: `${node.name}_${auth.authMark}`,
          label: auth.title,
          authMark: auth.authMark,
          isAuth: true,
          checked: auth.checked || false
        }))

        processed.children = processed.children ? [...processed.children, ...authNodes] : authNodes
      }

      if (processed.children) {
        processed.children = processed.children.map(processNode)
      }

      return processed
    }

    const list = (menuList.value as any[]) || []
    if (list.length === 0) {
      console.warn('[RolePermission] menuList is empty - dynamic routes may not be initialized')
    }
    const result = list.map(processNode)
    return result
  })

  const authNodeCount = computed(() => {
    let count = 0
    const traverse = (nodes: any[]): void => {
      for (const node of nodes) {
        if (node.isAuth) count++
        if (node.children?.length) traverse(node.children)
      }
    }
    traverse(processedMenuList.value)
    return count
  })

  const defaultProps = {
    children: 'children',
    label: (data: any) => formatMenuTitle(data.meta?.title) || data.label || ''
  }

  watch(
    () => props.modelValue,
    async (newVal) => {
      if (newVal && props.roleData) {
        checkedMenuIds.value = []
        try {
          const data = await fetchGetRolePermissions(props.roleData.roleId)
          if (Array.isArray(data)) {
            checkedMenuIds.value = data
            await nextTick()
            treeRef.value?.setCheckedKeys(data)
          }
          isSelectAll.value = false
        } catch {
          checkedMenuIds.value = []
        }
      }
    }
  )

  const handleClose = () => {
    visible.value = false
    checkedMenuIds.value = []
  }

  const savePermission = async () => {
    try {
      const tree = treeRef.value
      if (!tree) return
      const allChecked = tree.getCheckedKeys() as string[]
      const menuIds = allChecked
        .filter((k: string) => typeof k === 'number' || /^\d+$/.test(k))
        .map(Number)

      if (props.roleData?.roleId) {
        await fetchSaveRolePermissions(props.roleData.roleId, menuIds)
        ElMessage.success('权限保存成功')
        emit('success')
        handleClose()
      }
    } catch {
      ElMessage.error('保存失败')
    }
  }

  const toggleExpandAll = () => {
    const tree = treeRef.value
    if (!tree) return
    const nodes = tree.store.nodesMap
    Object.values(nodes).forEach((node: any) => {
      node.expanded = !isExpandAll.value
    })
    isExpandAll.value = !isExpandAll.value
  }

  const toggleSelectAll = () => {
    const tree = treeRef.value
    if (!tree) return
    if (!isSelectAll.value) {
      const allKeys = getAllNodeKeys()
      tree.setCheckedKeys(allKeys)
    } else {
      tree.setCheckedKeys([])
    }
    isSelectAll.value = !isSelectAll.value
  }

  const getAllNodeKeys = (): (string | number)[] => {
    const keys: (string | number)[] = []
    const traverse = (nodeList: MenuNode[]): void => {
      nodeList.forEach((node) => {
        if (node.id !== undefined) keys.push(node.id)
        if (node.children?.length) traverse(node.children)
      })
    }
    traverse(processedMenuList.value)
    return keys
  }

  const handleTreeCheck = () => {
    const tree = treeRef.value
    if (!tree) return
    const checkedKeys = tree.getCheckedKeys()
    const allKeys = getAllNodeKeys()
    isSelectAll.value = checkedKeys.length === allKeys.length && allKeys.length > 0
  }
</script>
