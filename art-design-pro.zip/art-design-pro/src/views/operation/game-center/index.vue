<template>
  <div class="game-center-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="loadData">
        <template #left>
          <ElSpace wrap>
            <span class="text-sm text-gray-500">共 {{ gameList.length }} 款游戏</span>
          </ElSpace>
        </template>
      </ArtTableHeader>

      <ElTable :data="gameList" v-loading="loading" stripe>
        <ElTableColumn label="游戏" min-width="180">
          <template #default="{ row }">
            <div class="flex items-center gap-3">
              <span class="text-2xl">{{ row.icon }}</span>
              <div>
                <div class="font-semibold text-sm">{{ row.name }}</div>
                <div class="text-xs text-gray-400">{{ row.desc }}</div>
              </div>
            </div>
          </template>
        </ElTableColumn>
        <ElTableColumn label="状态" width="100">
          <template #default="{ row }">
            <ElSwitch v-model="row.enabled" :loading="row.switching" @change="toggleGame(row)" />
          </template>
        </ElTableColumn>
        <ElTableColumn label="今日参与" width="100">
          <template #default="{ row }">{{ row.todayCount }} 人次</template>
        </ElTableColumn>
        <ElTableColumn label="今日消耗" width="100">
          <template #default="{ row }">{{ row.todaySpent }} 积分</template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" type="primary" @click="openConfig(row)">配置</ElButton>
            <ElButton size="small" @click="openRecords(row)">记录</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <!-- 配置弹窗 -->
    <ElDialog v-model="configVisible" :title="'配置 - ' + editingGame?.name" width="680px" destroy-on-close>
      <div v-if="editingGame" class="config-body">
        <ElForm label-width="100px" size="small">
          <ElFormItem label="每次消耗积分">
            <ElInputNumber v-model="configForm.cost" :min="1" />
          </ElFormItem>

          <!-- 金币抽奖 -->
          <template v-if="editingGame.gameType === 'lottery'">
            <ElFormItem label="10连抽优惠积分">
              <ElInputNumber v-model="configForm.cost10" :min="1" />
            </ElFormItem>
            <ElFormItem label="保底次数">
              <ElInputNumber v-model="configForm.pityCount" :min="0" />
            </ElFormItem>
            <ElFormItem label="保底目标格子(索引)">
              <ElInputNumber v-model="configForm.pityGridIndex" :min="0" :max="8" />
            </ElFormItem>
            <div class="mb-4">
              <div class="text-sm font-semibold mb-2">9宫格奖励设置</div>
              <div class="grid-config">
                <div v-for="(g, i) in configForm.grids" :key="i" class="grid-item">
                  <div class="grid-index">{{ i + 1 }}</div>
                  <ElInput v-model="g.name" placeholder="名称" size="small" class="mb-1" />
                  <ElSelect v-model="g.type" size="small" class="mb-1">
                    <ElOption label="积分" value="points" />
                    <ElOption label="余额" value="balance" />
                    <ElOption label="优惠券" value="coupon" />
                    <ElOption label="会员" value="membership" />
                    <ElOption label="卡密" value="cardkey" />
                    <ElOption label="谢谢参与" value="thanks" />
                  </ElSelect>
                  <ElInputNumber v-if="g.type === 'points' || g.type === 'balance'" v-model="g.value" :min="1" size="small" class="mb-1" />
                  <template v-if="g.type === 'coupon'">
                    <ElSelect v-model="g.couponId" size="small" class="mb-1" placeholder="选择优惠券" filterable>
                      <ElOption v-for="c in couponList" :key="c.id" :label="c.name" :value="c.id" />
                    </ElSelect>
                  </template>
                  <template v-if="g.type === 'membership'">
                    <ElSelect v-model="g.targetLevelId" size="small" class="mb-1" placeholder="目标等级">
                      <ElOption v-for="lv in levelList" :key="lv.id" :label="lv.name" :value="lv.id" />
                    </ElSelect>
                    <ElInputNumber v-model="g.value" :min="1" size="small" placeholder="天数" />
                  </template>
                  <ElInputNumber v-model="g.probability" :min="0" :max="100" size="small" placeholder="概率%" />
                  <span class="text-xs text-gray-400">%</span>
                </div>
              </div>
            </div>
          </template>

          <!-- 卡片竞猜 -->
          <template v-if="editingGame.gameType === 'card_guess'">
            <ElFormItem label="获胜倍数">
              <ElInputNumber v-model="configForm.winMultiplier" :min="1" :step="0.5" />
            </ElFormItem>
            <ElFormItem label="保底次数">
              <ElInputNumber v-model="configForm.pityCount" :min="0" />
            </ElFormItem>
            <div class="mb-4">
              <div class="text-sm font-semibold mb-2">3张卡片设置</div>
              <div v-for="(c, i) in configForm.cards" :key="i" class="flex items-center gap-2 mb-2">
                <span class="text-xs w-10">卡片{{ i + 1 }}</span>
                <ElInput v-model="c.name" placeholder="名称" size="small" class="flex-1" />
                <ElInput v-model="c.label" placeholder="显示文字" size="small" class="flex-1" />
                <ElCheckbox v-model="c.isWin" label="中奖" size="small" />
                <ElInputNumber v-model="c.probability" :min="0" :max="100" size="small" placeholder="概率" />
                <span class="text-xs text-gray-400">%</span>
              </div>
            </div>
          </template>

          <!-- 大小竞猜 -->
          <template v-if="editingGame.gameType === 'dice'">
            <ElFormItem label="最大点数">
              <ElInputNumber v-model="configForm.maxNumber" :min="2" :max="100" />
            </ElFormItem>
            <ElFormItem label="大小阈值(>=为大)">
              <ElInputNumber v-model="configForm.threshold" :min="2" />
            </ElFormItem>
            <ElFormItem label="获胜倍数">
              <ElInputNumber v-model="configForm.winMultiplier" :min="1" :step="0.5" />
            </ElFormItem>
          </template>

          <!-- 剪刀石头布 -->
          <template v-if="editingGame.gameType === 'rps'">
            <ElFormItem label="获胜倍数">
              <ElInputNumber v-model="configForm.winMultiplier" :min="1" :step="0.5" />
            </ElFormItem>
            <ElFormItem label="平局返还">
              <ElSwitch v-model="configForm.drawRefund" />
            </ElFormItem>
          </template>

          <!-- 会员折扣 -->
          <div class="mb-4">
            <div class="text-sm font-semibold mb-2">会员等级折扣</div>
            <div class="text-xs text-gray-400 mb-2">按会员等级设置抽奖/竞猜折扣比例（如 0.9 表示9折）</div>
            <div v-for="(d, i) in configForm.memberDiscounts" :key="i" class="flex items-center gap-2 mb-2">
              <ElInput v-model="d.levelName" placeholder="等级名称" size="small" class="w-32" disabled />
              <ElInputNumber v-model="d.discount" :min="0.1" :max="1" :step="0.05" size="small" placeholder="折扣" />
              <span class="text-xs text-gray-400">（{{ Math.round(d.discount * 100) }}折）</span>
            </div>
          </div>
        </ElForm>
      </div>
      <template #footer>
        <ElButton @click="configVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
      </template>
    </ElDialog>

    <!-- 记录弹窗 -->
    <ElDialog v-model="recordsVisible" title="参与记录" width="800px" destroy-on-close>
      <div class="flex gap-3 mb-3">
        <ElInput v-model="recordFilter.userId" placeholder="用户ID" size="small" class="w-32" clearable />
        <ElButton size="small" @click="loadRecords">查询</ElButton>
      </div>
      <ElTable :data="records" v-loading="recordLoading" stripe max-height="400">
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="username" label="用户" width="100" />
        <ElTableColumn label="结果" width="70">
          <template #default="{ row }">
            <ElTag :type="row.result === 'win' ? 'success' : row.result === 'draw' ? 'warning' : 'info'" size="small">
              {{ row.result === 'win' ? '胜' : row.result === 'draw' ? '平' : '负' }}
            </ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="消耗" width="70">
          <template #default="{ row }">{{ row.pointsSpent }}</template>
        </ElTableColumn>
        <ElTableColumn label="获得" width="70">
          <template #default="{ row }">
            <span :class="row.pointsWon > 0 ? 'text-green-500' : ''">{{ row.pointsWon }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="详情" min-width="160">
          <template #default="{ row }">{{ formatDetail(row) }}</template>
        </ElTableColumn>
        <ElTableColumn prop="createTime" label="时间" width="160" />
      </ElTable>
      <div class="flex justify-center mt-3">
        <ElPagination
          v-model:current-page="recordPage" :page-size="recordPageSize"
          :total="recordTotal" layout="prev, pager, next" small
          @current-change="loadRecords"
        />
      </div>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from 'axios'

const loading = ref(false)
const saving = ref(false)
const gameList = ref<any[]>([])
const columnChecks = ref<string[]>([])

const configVisible = ref(false)
const editingGame = ref<any>(null)
const couponList = ref<any[]>([])
const levelList = ref<any[]>([])

const recordsVisible = ref(false)
const records = ref<any[]>([])
const recordLoading = ref(false)
const recordPage = ref(1)
const recordPageSize = ref(20)
const recordTotal = ref(0)
const recordFilter = reactive({ userId: '' })

const configForm = reactive<any>({
  cost: 10, cost10: 90, pityCount: 0, pityGridIndex: 0,
  grids: [], cards: [], maxNumber: 6, threshold: 4,
  winMultiplier: 2, drawRefund: true, memberDiscounts: []
})

async function loadData() {
  loading.value = true
  try {
    const { data: res } = await axios.get('/api/game/list')
    gameList.value = (res.data || []).map((g: any) => ({ ...g, switching: false }))
  } catch (e: any) { ElMessage.error(e.message) }
  finally { loading.value = false }
}

async function toggleGame(game: any) {
  game.switching = true
  try {
    const { data: cfg } = await axios.get(`/api/game/config/${game.gameType}`)
    const config = cfg.data?.config || getDefaultConfig(game.gameType)
    await axios.post(`/api/game/config/${game.gameType}`, { enabled: game.enabled ? 1 : 0, config })
    ElMessage.success(game.enabled ? '已启用' : '已停用')
  } catch (e: any) { ElMessage.error(e.message); game.enabled = !game.enabled }
  finally { game.switching = false }
}

async function openConfig(game: any) {
  editingGame.value = game
  if (game.gameType === 'lottery') {
    try {
      const [cpRes, lvRes] = await Promise.all([
        axios.get('/api/operation/coupon/list?status=1'),
        axios.get('/api/operation/membership/list')
      ])
      couponList.value = cpRes.data?.data || cpRes.data?.list || []
      levelList.value = (lvRes.data?.data || lvRes.data?.list || []).filter((l: any) => l.level > 0)
    } catch {}
  }
  try {
    const { data: res } = await axios.get(`/api/game/config/${game.gameType}`)
    const cfg = res.data?.config || getDefaultConfig(game.gameType)
    Object.assign(configForm, {
      cost: cfg.costPerDraw || cfg.costPerFlip || cfg.costPerBet || cfg.costPerPlay || 10,
      cost10: cfg.costPerDraw10 || (cfg.costPerDraw || 10) * 10,
      pityCount: cfg.pityCount || 0,
      pityGridIndex: cfg.pityGridIndex || 0,
      grids: cfg.grids ? [...cfg.grids] : Array.from({ length: 9 }, (_, i) => ({ index: i, name: `奖励${i + 1}`, type: 'points', value: 10, probability: 11 })),
      cards: cfg.cards ? [...cfg.cards] : [
        { name: 'A', label: '奖', isWin: true, probability: 30 },
        { name: 'B', label: '空', isWin: false, probability: 35 },
        { name: 'C', label: '空', isWin: false, probability: 35 }
      ],
      maxNumber: cfg.maxNumber || 6,
      threshold: cfg.threshold || 4,
      winMultiplier: cfg.winMultiplier || 2,
      drawRefund: cfg.drawRefund !== false,
      memberDiscounts: cfg.memberDiscounts ? [...cfg.memberDiscounts] : []
    })
    if (!configForm.memberDiscounts.length) {
      try {
        const { data: lvls } = await axios.get('/api/operation/membership/list')
        configForm.memberDiscounts = (lvls.data || [])
          .filter((l: any) => l.level > 0)
          .map((l: any) => ({ levelId: l.id, levelName: l.name, discount: 1 }))
      } catch {}
    }
  } catch (e: any) { ElMessage.error(e.message) }
  configVisible.value = true
}

async function saveConfig() {
  saving.value = true
  try {
    const cfg: any = {}
    if (editingGame.value.gameType === 'lottery') {
      cfg.costPerDraw = configForm.cost
      cfg.costPerDraw10 = configForm.cost10
      cfg.pityCount = configForm.pityCount
      cfg.pityGridIndex = configForm.pityGridIndex
      cfg.grids = configForm.grids.map((g: any) => ({ ...g, probability: Number(g.probability) || 0 }))
    } else if (editingGame.value.gameType === 'card_guess') {
      cfg.costPerFlip = configForm.cost
      cfg.pityCount = configForm.pityCount
      cfg.winMultiplier = configForm.winMultiplier
      cfg.cards = configForm.cards.map((c: any) => ({ ...c, probability: Number(c.probability) || 0 }))
    } else if (editingGame.value.gameType === 'dice') {
      cfg.costPerBet = configForm.cost
      cfg.maxNumber = configForm.maxNumber
      cfg.threshold = configForm.threshold
      cfg.winMultiplier = configForm.winMultiplier
    } else if (editingGame.value.gameType === 'rps') {
      cfg.costPerPlay = configForm.cost
      cfg.winMultiplier = configForm.winMultiplier
      cfg.drawRefund = configForm.drawRefund
    }
    cfg.memberDiscounts = configForm.memberDiscounts.map((d: any) => ({ ...d, discount: Number(d.discount) }))

    // 校验概率
    if (cfg.grids) {
      const total = cfg.grids.reduce((s: number, g: any) => s + (g.probability || 0), 0)
      if (total > 100) { ElMessage.error('概率总和不能超过100%'); saving.value = false; return }
    }

    await axios.post(`/api/game/config/${editingGame.value.gameType}`, { enabled: editingGame.value.enabled ? 1 : 0, config: cfg })
    ElMessage.success('保存成功')
    configVisible.value = false
    loadData()
  } catch (e: any) { ElMessage.error(e.message) }
  finally { saving.value = false }
}

async function openRecords(game: any) {
  editingGame.value = game
  recordPage.value = 1
  recordsVisible.value = true
  await loadRecords()
}

async function loadRecords() {
  recordLoading.value = true
  try {
    const params: any = { gameType: editingGame.value.gameType, page: recordPage.value, pageSize: recordPageSize.value }
    if (recordFilter.userId) params.userId = recordFilter.userId
    const { data: res } = await axios.get('/api/game/records', { params })
    records.value = res.data.list
    recordTotal.value = res.data.total
  } catch (e: any) { ElMessage.error(e.message) }
  finally { recordLoading.value = false }
}

function formatDetail(row: any) {
  const d = row.detail
  if (!d) return '--'
  if (d.gridName) return `格子:${d.gridName}`
  if (d.cardName) return `翻牌:${d.cardName || d.cardLabel}`
  if (d.number !== undefined) return `竞猜:${d.bet} 点数:${d.number}`
  if (d.userChoiceName) return `${d.userChoiceName} vs ${d.systemChoiceName}`
  return JSON.stringify(d)
}

function getDefaultConfig(gameType: string) {
  return {}
}

onMounted(loadData)
</script>

<style lang="scss" scoped>
.game-center-page { padding: 16px; }
.config-body { max-height: 480px; overflow-y: auto; }
.grid-config { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.grid-item {
  border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px;
  display: flex; flex-direction: column; align-items: center; background: #fafafa;
  .grid-index { font-size: 18px; font-weight: 700; color: #6366f1; margin-bottom: 4px; }
}
</style>
