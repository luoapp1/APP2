<!-- 头像框管理 -->
<template>
  <div class="avatar-frame-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>头像框管理</span>
          <ElButton type="primary" @click="showDialog()">新增头像框</ElButton>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="false" />
    </ElCard>

    <ElDialog v-model="dialogVisible" :title="editingId ? '编辑头像框' : '新增头像框'" width="600px" align-center>
    </ElDialog>

    <ElDialog v-model="grantVisible" title="授予头像框" width="450px" align-center @closed="grantUserId=''">
    </ElDialog>

    <ElDialog v-model="usersVisible" :title="'拥有「' + viewingFrameName + '」的用户'" width="550px" align-center>
      <ElTable :data="frameUsers" v-loading="usersLoading" max-height="400" size="small">
        <ElTableColumn prop="id" label="用户ID" width="70" />
        <ElTableColumn prop="nickname" label="昵称" width="110">
          <template #default="{ row }">
            <span>{{ row.nickname || row.username }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="levelName" label="等级" width="90" />
        <ElTableColumn prop="obtainTime" label="获取时间" min-width="150">
          <template #default="{ row }">
            <span>{{ row.obtainTime ? new Date(row.obtainTime).toLocaleString('zh-CN') : '-' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="obtainType" label="获取方式" width="80">
          <template #default="{ row }">
            <ElTag size="small">{{ row.obtainType === 'experience' ? '经验' : row.obtainType === 'membership' ? '会员' : row.obtainType === 'activity' ? '活动' : '手动' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="70" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" link type="danger" @click="doRevokeUser(row)">撤销</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import { fetchAvatarFrameAll, fetchAvatarFrameSave, fetchAvatarFrameDelete, fetchAvatarFrameUpload, fetchGrantFrame, fetchRevokeFrame, fetchFrameUsers } from '@/api/avatar-frame'
import { fetchExpLevelList, fetchGetMembershipLevelList } from '@/api/operation'
import request from '@/utils/http'

defineOptions({ name: 'AvatarFrameManage' })

const loading = ref(false)
const saving = ref(false)
const granting = ref(false)
const data = ref<any[]>([])
const dialogVisible = ref(false)
const grantVisible = ref(false)
const usersVisible = ref(false)
const usersLoading = ref(false)
const frameUsers = ref<any[]>([])
const viewingFrameName = ref('')
const viewingFrameId = ref(0)
const editingId = ref(0)
const grantUserId = ref('')
const grantFrameId = ref(0)
const expLevels = ref<any[]>([])
const memberLevels = ref<any[]>([])

const form = reactive({
  name: '', imageUrl: '', thumbnailUrl: '', description: '',
  obtainType: 'manual', expLevelRequired: 0, memberLevelRequired: 0,
  sortOrder: 0, status: '1'
})

const columns = [
  {
    prop: 'image_url', label: '预览', width: 90,
    formatter: (row: any) => row.image_url ? h('img', { src: row.image_url, style: { width: '52px', height: '52px', objectFit: 'contain', borderRadius: '8px' } }) : '-'
  },
  {
    prop: 'name', label: '名称', width: 140,
    formatter: (row: any) => h('span', { style: { fontWeight: '600' } }, row.name)
  },
  {
    prop: 'description', label: '描述', minWidth: 150,
    formatter: (row: any) => row.description || '-'
  },
  {
    prop: 'obtain_type', label: '获取方式', width: 100,
    formatter: (row: any) => row.obtain_type === 'experience' ? '经验等级' : row.obtain_type === 'membership' ? '会员等级' : row.obtain_type === 'activity' ? '活动获取' : '手动授予'
  },
  { prop: 'sort_order', label: '排序', width: 60 },
  {
    prop: 'status', label: '状态', width: 70,
    formatter: (row: any) => h(ElTag, { type: row.status === '1' ? 'success' : 'info', size: 'small' }, () => row.status === '1' ? '启用' : '禁用')
  },
  {
    label: '操作', width: 240, fixed: 'right' as const,
    formatter: (row: any) =>
      h('div', { class: 'flex gap-1' }, [
        h(ElButton, { size: 'small', link: true, type: 'primary', onClick: () => showDialog(row) }, () => '编辑'),
        h(ElButton, { size: 'small', link: true, type: 'success', onClick: () => showGrant(row) }, () => '授予'),
        h(ElButton, { size: 'small', link: true, type: 'warning', onClick: () => showUsers(row) }, () => '查看'),
        h(ElButton, { size: 'small', link: true, type: 'danger', onClick: () => doDelete(row) }, () => '删除')
      ])
  }
]

async function fetchData() {
  loading.value = true
  try {
    const res: any = await fetchAvatarFrameAll()
    data.value = res || []
  } finally { loading.value = false }
}

async function loadLevels() {
  try {
    const expRes: any = await fetchExpLevelList()
    expLevels.value = (expRes?.records || expRes || []).sort((a: any, b: any) => a.level - b.level)
  } catch {}
  try {
    const memRes: any = await fetchGetMembershipLevelList()
    memberLevels.value = (memRes?.records || memRes || []).sort((a: any, b: any) => (a.tier || a.tier || 1) - (b.tier || b.tier || 1))
  } catch {}
}

function showDialog(row?: any) {
  editingId.value = row ? row.id : 0
  if (row) {
    Object.assign(form, {
      name: row.name, imageUrl: row.image_url || '', thumbnailUrl: row.thumbnail_url || '',
      description: row.description || '', obtainType: row.obtain_type || 'manual',
      expLevelRequired: row.exp_level_required || 0, memberLevelRequired: row.member_level_required || 0,
      sortOrder: row.sort_order || 0, status: row.status || '1'
    })
  } else {
    Object.assign(form, { name: '', imageUrl: '', thumbnailUrl: '', description: '', obtainType: 'manual', expLevelRequired: 0, memberLevelRequired: 0, sortOrder: 0, status: '1' })
  }
  dialogVisible.value = true
}

async function doSave() {
  if (!form.name) { ElMessage.warning('请输入名称'); return }
  saving.value = true
  try {
    await fetchAvatarFrameSave({ ...form, id: editingId.value || undefined })
    ElMessage.success('保存成功')
    dialogVisible.value = false
    fetchData()
  } finally { saving.value = false }
}

async function doDelete(row: any) {
  await ElMessageBox.confirm('确定删除该头像框？', '提示', { type: 'warning' })
  await fetchAvatarFrameDelete(row.id)
  ElMessage.success('删除成功')
  fetchData()
}

function showGrant(row: any) {
  grantFrameId.value = row.id
  grantUserId.value = ''
  grantVisible.value = true
}

async function doGrant() {
  if (!grantUserId.value) { ElMessage.warning('请输入用户ID'); return }
  granting.value = true
  try {
    await fetchGrantFrame(Number(grantUserId.value), grantFrameId.value)
    ElMessage.success('授予成功')
    grantVisible.value = false
  } finally { granting.value = false }
}

async function showUsers(row: any) {
  viewingFrameName.value = row.name
  viewingFrameId.value = row.id
  usersVisible.value = true
  usersLoading.value = true
  try {
    const res: any = await fetchFrameUsers(row.id)
    frameUsers.value = res || []
  } finally { usersLoading.value = false }
}

async function doRevokeUser(row: any) {
  await ElMessageBox.confirm('确定撤销该用户的头像框？', '提示', { type: 'warning' })
  await fetchRevokeFrame(row.id, viewingFrameId.value)
  ElMessage.success('撤销成功')
  showUsers({ id: viewingFrameId.value, name: viewingFrameName.value })
}

const beforeFrameUpload = (file: File) => {
  const isImage = file.type.startsWith('image/')
  const isLt5M = file.size / 1024 / 1024 < 5
  if (!isImage) ElMessage.error('请上传图片文件')
  if (!isLt5M) ElMessage.error('图片大小不能超过 5MB')
  return isImage && isLt5M
}

async function uploadFrame(options: any) {
  const formData = new FormData()
  formData.append('file', options.file)
  try {
    const res: any = await fetchAvatarFrameUpload(formData)
    const url = res.url || res.data?.url || ''
    form.imageUrl = url
    form.thumbnailUrl = url
    options.onSuccess(res, options.file)
  } catch (e: any) {
    options.onError(e)
    ElMessage.error(e?.message || '上传失败')
  }
}

onMounted(() => {
  fetchData()
  loadLevels()
})
</script>

<style scoped>
.avatar-frame-page { padding: 16px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
:deep(.el-overlay-dialog) {
  display: flex;
  align-items: center;
  justify-content: center;
}
:deep(.el-dialog) {
  margin: 0 !important;
}
</style>
