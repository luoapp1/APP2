<template>
  <div class="payment-config-page art-full-height">
    <ElRow :gutter="20">
      <ElCol :span="24">
        <ElCard class="art-table-card" header="支付接口配置">
          <ElForm label-width="140px" :disabled="saving">
            <ElDivider content-position="left">易支付 (Epay)</ElDivider>
            <ElFormItem label="启用">
              <ElSwitch v-model="form.payment_epay_enabled" active-text="开启" inactive-text="关闭" />
            </ElFormItem>
            <ElFormItem label="商户ID (PID)">
              <ElInput v-model="form.payment_epay_pid" placeholder="易支付商户ID" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="商户密钥 (Key)">
              <ElInput v-model="form.payment_epay_key" placeholder="易支付商户密钥" style="width:400px" type="password" show-password />
            </ElFormItem>
            <ElFormItem label="API地址">
              <ElInput v-model="form.payment_epay_api_url" placeholder="https://pay.example.com" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="异步通知地址">
              <ElInput v-model="form.payment_epay_notify_url" placeholder="https://your-domain.com/api/recharge/callback/epay/notify" style="width:400px" />
              <div class="form-tip">支付成功后的异步回调地址，用于更新用户余额</div>
            </ElFormItem>

            <ElDivider content-position="left">支付宝 (Alipay)</ElDivider>
            <ElFormItem label="启用">
              <ElSwitch v-model="form.payment_alipay_enabled" active-text="开启" inactive-text="关闭" />
            </ElFormItem>
            <ElFormItem label="App ID">
              <ElInput v-model="form.payment_alipay_app_id" placeholder="支付宝应用ID" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="应用私钥">
              <ElInput v-model="form.payment_alipay_private_key" type="textarea" :rows="3" placeholder="支付宝应用私钥" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="支付宝公钥">
              <ElInput v-model="form.payment_alipay_public_key" type="textarea" :rows="3" placeholder="支付宝公钥" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="异步通知地址">
              <ElInput v-model="form.payment_alipay_notify_url" placeholder="https://your-domain.com/api/recharge/callback/alipay" style="width:400px" />
            </ElFormItem>

            <ElDivider content-position="left">微信支付 (WeChat Pay)</ElDivider>
            <ElFormItem label="启用">
              <ElSwitch v-model="form.payment_wechat_enabled" active-text="开启" inactive-text="关闭" />
            </ElFormItem>
            <ElFormItem label="App ID">
              <ElInput v-model="form.payment_wechat_app_id" placeholder="微信公众号/小程序AppID" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="商户号 (Mch ID)">
              <ElInput v-model="form.payment_wechat_mch_id" placeholder="微信支付商户号" style="width:400px" />
            </ElFormItem>
            <ElFormItem label="API密钥">
              <ElInput v-model="form.payment_wechat_api_key" placeholder="微信支付API密钥" style="width:400px" type="password" show-password />
            </ElFormItem>
            <ElFormItem label="异步通知地址">
              <ElInput v-model="form.payment_wechat_notify_url" placeholder="https://your-domain.com/api/recharge/callback/wechat" style="width:400px" />
            </ElFormItem>

            <ElDivider />
            <ElFormItem>
              <ElButton type="primary" :loading="saving" @click="saveConfig">保存配置</ElButton>
            </ElFormItem>
          </ElForm>
        </ElCard>
      </ElCol>
    </ElRow>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

defineOptions({ name: 'PaymentConfig' })

const saving = ref(false)

const form = reactive({
  payment_epay_enabled: false,
  payment_epay_pid: '',
  payment_epay_key: '',
  payment_epay_api_url: '',
  payment_epay_notify_url: '',
  payment_alipay_enabled: false,
  payment_alipay_app_id: '',
  payment_alipay_private_key: '',
  payment_alipay_public_key: '',
  payment_alipay_notify_url: '',
  payment_wechat_enabled: false,
  payment_wechat_app_id: '',
  payment_wechat_mch_id: '',
  payment_wechat_api_key: '',
  payment_wechat_notify_url: ''
})

const fetchConfig = async () => {
  try {
    const cfg: any = await request.get({ url: '/api/admin/payment-config' })
    if (cfg) {
      Object.keys(form).forEach(k => {
        (form as any)[k] = cfg[k] === 'true' ? true : (cfg[k] === 'false' ? false : cfg[k] || '')
      })
    }
  } catch {}
}

const saveConfig = async () => {
  saving.value = true
  try {
    await request.post({ url: '/api/admin/payment-config', data: form })
    ElMessage.success('保存成功')
  } catch (e: any) {
    ElMessage.error(e.message || '保存失败')
  }
  saving.value = false
}

onMounted(() => fetchConfig())
</script>

<style scoped>
.payment-config-page { padding: 20px; }
.form-tip { font-size: 12px; color: #909399; margin-top: 4px; }
</style>
