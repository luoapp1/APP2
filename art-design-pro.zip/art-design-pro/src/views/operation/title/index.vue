<!-- 自定义称号管理 -->
<template>
  <div class="title-page art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>称号管理</span>
          <ElButton type="primary" @click="showDialog()">新增称号</ElButton>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="false" />
    </ElCard>

    <ElDialog v-model="dialogVisible" :title="editingId ? '编辑称号' : '新增称号'" width="550px">
      <ElForm :model="form" label-width="100px">
        <ElFormItem label="称号名称" required>
          <ElInput v-model="form.name" placeholder="如：论坛元老" />
        </ElFormItem>
        <ElFormItem label="图标">
          <ElSpace>
            <ElInput v-model="form.icon" placeholder="图标URL" style="width:260px" />
            <ElUpload
              :show-file-list="false"
              :before-upload="beforeIconUpload"
              :http-request="uploadIcon"
              accept="image/*"
            >
              <ElButton size="small">上传</ElButton>
            </ElUpload>
          </ElSpace>
          <div v-if="form.icon" style="margin-top:6px">
            <img :src="form.icon" style="width:32px;height:32px;border-radius:4px" />
          </div>
        </ElFormItem>
        <ElFormItem label="文字颜色">
          <ElColorPicker v-model="form.color" />
        </ElFormItem>
        <ElFormItem label="背景颜色">
          <ElColorPicker v-model="form.bgColor" />
        </ElFormItem>
        <ElFormItem label="预览">
          <span :style="{ color: form.color, background: form.bgColor, padding: '2px 8px', borderRadius: '4px', fontSize: '13px', fontWeight: 'bold' }">{{ form.name || '称号预览' }}</span>
        </ElFormItem>
        <ElFormItem label="描述">
          <ElInput v-model="form.description" type="textarea" :rows="2" />
        </ElFormItem>
        <ElFormItem label="获取方式">
          <ElRadioGroup v-model="form.conditionType">
            <ElRadio value="manual">手动授予</ElRadio>
            <ElRadio value="auto">自动获得</ElRadio>
          </ElRadioGroup>
        </ElFormItem>
        <ElFormItem v-if="form.conditionType === 'auto'" label="条件值">
          <ElInput v-model="form.conditionValue" placeholder="如：posts>=100" />
        </ElFormItem>
        <ElFormItem label="排序">
          <ElInputNumber v-model="form.sortOrder" :min="0" />
        </ElFormItem>
        <ElFormItem label="状态">
          <ElSwitch v-model="form.status" active-value="1" inactive-value="0" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="saveTitle">保存</ElButton>
      </template>
    </ElDialog>

    <ElDialog v-model="grantVisible" title="授予称号" width="500px">
      <ElForm label-width="100px">
        <ElFormItem label="选择用户">
          <ElInput v-model="grantUserId" placeholder="请输入用户ID" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="grantVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="granting" @click="doGrant">确认授予</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import { fetchTitleAll, fetchSaveTitle, fetchDeleteTitle, fetchGrantTitle, fetchRevokeTitle } from '@/api/social'
import request from '@/utils/http'

defineOptions({ name: 'TitleManage' })

const loading = ref(false)
const saving = ref(false)
const data = ref<any[]>([])
const dialogVisible = ref(false)
const grantVisible = ref(false)
const granting = ref(false)
const editingId = ref(0)
const grantUserId = ref('')
const grantTitleId = ref(0)

const form = reactive({
  name: '', icon: '', color: '#409EFF', bgColor: '#ecf5ff',
  description: '', conditionType: 'manual', conditionValue: '', sortOrder: 0, status: '1'
})

const columns = [
  {
    prop: 'name', label: '称号', width: 120,
    formatter: (row: any) =>
      h('span', { style: { color: row.color || '#409EFF', background: row.bg_color || '#ecf5ff', padding: '2px 8px', borderRadius: '4px', fontSize: '13px', fontWeight: 'bold' } }, row.name)
  },
  {
    prop: 'icon', label: '图标', width: 80,
    formatter: (row: any) => row.icon ? h('img', { src: row.icon, style: { width: '24px', height: '24px' } }) : '-'
  },
  {
    prop: 'condition_type', label: '获取方式', width: 90,
    formatter: (row: any) => row.condition_type === 'manual' ? '手动授予' : '自动获得'
  },
  { prop: 'sort_order', label: '排序', width: 60 },
  {
    prop: 'status', label: '状态', width: 70,
    formatter: (row: any) => h(ElTag, { type: row.status === '1' ? 'success' : 'info', size: 'small' }, () => row.status === '1' ? '启用' : '禁用')
  },
  {
    label: '操作', width: 200, fixed: 'right' as const,
    formatter: (row: any) =>
      h('div', { class: 'flex gap-1' }, [
        h(ElButton, { size: 'small', link: true, type: 'primary', onClick: () => showDialog(row) }, () => '编辑'),
        h(ElButton, { size: 'small', link: true, type: 'success', onClick: () => showGrant(row) }, () => '授予'),
        h(ElButton, { size: 'small', link: true, type: 'danger', onClick: () => deleteTitle(row) }, () => '删除')
      ])
  }
]

async function fetchData() {
  loading.value = true
  try {
    const res: any = await fetchTitleAll()
    data.value = res || []
  } finally { loading.value = false }
}

function showDialog(row?: any) {
  editingId.value = row ? row.id : 0
  if (row) Object.assign(form, {
    name: row.name, icon: row.icon || '', color: row.color || '#409EFF',
    bgColor: row.bg_color || '#ecf5ff', description: row.description || '',
    conditionType: row.condition_type || 'manual', conditionValue: row.condition_value || '',
    sortOrder: row.sort_order || 0, status: row.status || '1'
  })
  else Object.assign(form, { name: '', icon: '', color: '#409EFF', bgColor: '#ecf5ff', description: '', conditionType: 'manual', conditionValue: '', sortOrder: 0, status: '1' })
  dialogVisible.value = true
}

async function saveTitle() {
  saving.value = true
  try {
    await fetchSaveTitle({ ...form, id: editingId.value || undefined })
    ElMessage.success('保存成功')
    dialogVisible.value = false
    fetchData()
  } finally { saving.value = false }
}

async function deleteTitle(row: any) {
  await ElMessageBox.confirm('确定删除该称号？', '提示', { type: 'warning' })
  await fetchDeleteTitle(row.id)
  ElMessage.success('删除成功')
  fetchData()
}

function showGrant(row: any) {
  grantTitleId.value = row.id
  grantUserId.value = ''
  grantVisible.value = true
}

async function doGrant() {
  if (!grantUserId.value) return ElMessage.warning('请输入用户ID')
  granting.value = true
  try {
    await fetchGrantTitle(Number(grantUserId.value), grantTitleId.value)
    ElMessage.success('授予成功')
    grantVisible.value = false
  } finally { granting.value = false }
}

async function doRevoke(row: any, userId: number) {
  await fetchRevokeTitle(userId, row.id)
  ElMessage.success('撤销成功')
}

onMounted(fetchData)

const beforeIconUpload = (file: File) => {
  const isImage = file.type.startsWith('image/')
  if (!isImage) {
    ElMessage.error('只能上传图片文件')
    return false
  }
  const isLt2M = file.size / 1024 / 1024 < 2
  if (!isLt2M) {
    ElMessage.error('图片大小不能超过 2MB')
    return false
  }
  return true
}

const uploadIcon = async (options: any) => {
  const formData = new FormData()
  formData.append('file', options.file)
  try {
    const res: any = await request.post({ url: '/api/upload/file', data: formData, headers: { 'Content-Type': 'multipart/form-data' } })
    if (res?.url) {
      form.icon = res.url
      ElMessage.success('上传成功')
    } else if (res?.data?.url) {
      form.icon = res.data.url
      ElMessage.success('上传成功')
    } else {
      ElMessage.error('上传失败')
    }
  } catch {
    ElMessage.error('上传失败')
  }
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
