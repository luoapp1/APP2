<template>
  <div class="settlement-page art-full-height">
    <ElCard>
      <template #header>
        <div class="card-header">
          <span>结算规则配置</span>
          <ElButton type="primary" @click="showForm(null)">新增规则</ElButton>
        </div>
      </template>
      <ElTable :data="list" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="level_name" label="用户等级" min-width="100" />
        <ElTableColumn label="状态" width="80">
          <template #default="{ row }">
            <ElTag :type="row.enabled ? 'success' : 'danger'" size="small">{{ row.enabled ? '启用' : '禁用' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="余额转出" width="90">
          <template #default="{ row }">
            <ElTag :type="row.balance_transfer_enabled ? 'success' : 'danger'" size="small">{{ row.balance_transfer_enabled ? '开启' : '关闭' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="积分转出" width="90">
          <template #default="{ row }">
            <ElTag :type="row.points_transfer_enabled ? 'success' : 'danger'" size="small">{{ row.points_transfer_enabled ? '开启' : '关闭' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="确认收货(天)" width="100" prop="confirm_days" />
        <ElTableColumn label="余额单次最低" width="110">
          <template #default="{ row }">{{ row.single_min_balance || 0 }}</template>
        </ElTableColumn>
        <ElTableColumn label="余额单次最高" width="110">
          <template #default="{ row }">{{ row.single_max_balance || 0 }}</template>
        </ElTableColumn>
        <ElTableColumn label="余额日限额" width="110">
          <template #default="{ row }">{{ row.daily_limit_balance_amount || 0 }}</template>
        </ElTableColumn>
        <ElTableColumn label="余额手续费(%)" width="110">
          <template #default="{ row }">{{ row.balance_transfer_fee || 0 }}</template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="140" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" link type="primary" @click="showForm(row)">编辑</ElButton>
            <ElButton size="small" link type="danger" @click="doDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElCard style="margin-top:16px">
      <template #header>
        <div class="card-header">
          <span>退款审核（管理员）</span>
          <ElButton size="small" @click="loadReports">刷新</ElButton>
        </div>
      </template>
      <ElTable :data="reports" v-loading="reportsLoading" stripe empty-text="暂无待审核退款">
        <ElTableColumn prop="id" label="订单ID" width="70" />
        <ElTableColumn prop="order_no" label="订单号" min-width="120" />
        <ElTableColumn prop="order_desc" label="描述" min-width="120" />
        <ElTableColumn label="买家" min-width="80">
          <template #default="{ row }">{{ row.buyer_name_full || row.buyer_name }}</template>
        </ElTableColumn>
        <ElTableColumn label="卖家" min-width="80">
          <template #default="{ row }">{{ row.seller_name_full || row.seller_name }}</template>
        </ElTableColumn>
        <ElTableColumn label="金额" width="100">
          <template #default="{ row }">{{ row.pay_type === 'points' ? row.paid_amount + '积分' : '￥' + row.paid_amount }}</template>
        </ElTableColumn>
        <ElTableColumn label="退款原因/上报原因" min-width="200">
          <template #default="{ row }">{{ row.refund_reason || '-' }}</template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="260" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" type="success" @click="adminHandle(row, 'agree')">同意退款</ElButton>
            <ElButton size="small" type="danger" @click="adminHandle(row, 'reject')">驳回</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElDialog v-model="visible" :title="editId ? '编辑规则' : '新增规则'" width="680px" align-center>
      <ElForm :model="form" :disabled="saving" label-width="150px" class="settlement-form">
        <ElDivider content-position="left">基本信息</ElDivider>
        <ElFormItem label="用户等级">
          <ElSelect v-model="form.level_id" placeholder="选择用户等级" style="width:100%">
            <ElOption :value="0" label="普通用户" />
            <ElOption v-for="lv in membershipLevels" :key="lv.id" :value="lv.id" :label="lv.name" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="是否启用">
          <ElSwitch v-model="form.enabled" :active-value="1" :inactive-value="0" />
        </ElFormItem>
        <ElFormItem label="确认收货天数">
          <ElInputNumber v-model="form.confirm_days" :min="1" :max="365" style="width:200px" /> 天
        </ElFormItem>

        <ElDivider content-position="left">转出开关</ElDivider>
        <ElFormItem label="余额转出">
          <ElSwitch v-model="form.balance_transfer_enabled" :active-value="1" :inactive-value="0" />
        </ElFormItem>
        <ElFormItem label="积分转出">
          <ElSwitch v-model="form.points_transfer_enabled" :active-value="1" :inactive-value="0" />
        </ElFormItem>

        <ElDivider content-position="left">余额规则</ElDivider>
        <ElFormItem label="单次最低转出">
          <ElInputNumber v-model="form.single_min_balance" :min="0" :precision="2" style="width:200px" /> 元
        </ElFormItem>
        <ElFormItem label="单次最高转出">
          <ElInputNumber v-model="form.single_max_balance" :min="0" :precision="2" style="width:200px" /> 元（0=不限）
        </ElFormItem>
        <ElFormItem label="每日转出上限">
          <ElInputNumber v-model="form.daily_limit_balance_amount" :min="0" :precision="2" style="width:200px" /> 元（0=不限）
        </ElFormItem>
        <ElFormItem label="转账手续费">
          <ElInputNumber v-model="form.balance_transfer_fee" :min="0" :max="100" :precision="2" style="width:200px" /> %
        </ElFormItem>

        <ElDivider content-position="left">积分规则</ElDivider>
        <ElFormItem label="单次最低转出">
          <ElInputNumber v-model="form.single_min_points" :min="0" style="width:200px" /> 积分
        </ElFormItem>
        <ElFormItem label="单次最高转出">
          <ElInputNumber v-model="form.single_max_points" :min="0" style="width:200px" /> 积分（0=不限）
        </ElFormItem>
        <ElFormItem label="每日转出上限">
          <ElInputNumber v-model="form.daily_limit_points_amount" :min="0" style="width:200px" /> 积分（0=不限）
        </ElFormItem>
        <ElFormItem label="转账手续费">
          <ElInputNumber v-model="form.points_transfer_fee" :min="0" :max="100" :precision="2" style="width:200px" /> %
        </ElFormItem>

        <ElDivider content-position="left">兑换汇率</ElDivider>
        <ElFormItem label="余额兑换积分">
          1 元 = <ElInputNumber v-model="form.balance_to_points_rate" :min="0.01" :precision="2" style="width:150px" /> 积分
        </ElFormItem>
        <ElFormItem label="积分兑换余额">
          <ElInputNumber v-model="form.points_to_balance_rate" :min="0.01" :precision="2" style="width:150px" /> 积分 = 1 元
        </ElFormItem>

        <ElDivider content-position="left">次数限制</ElDivider>
        <ElFormItem label="每日转出次数">
          <ElInputNumber v-model="form.daily_limit_times" :min="0" style="width:200px" /> 次（0=不限）
        </ElFormItem>
        <ElFormItem label="每周转出次数">
          <ElInputNumber v-model="form.weekly_limit_times" :min="0" style="width:200px" /> 次（0=不限）
        </ElFormItem>
        <ElFormItem label="每年转出次数">
          <ElInputNumber v-model="form.yearly_limit_times" :min="0" style="width:200px" /> 次（0=不限）
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="visible = false">取消</ElButton>
        <ElButton type="primary" :loading="saving" @click="doSave">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/modules/user'

defineOptions({ name: 'SettlementManage' })

const userStore = useUserStore()

const loading = ref(false)
const saving = ref(false)
const list = ref<any[]>([])
const membershipLevels = ref<any[]>([])
const visible = ref(false)
const editId = ref<number | null>(null)

const defaultForm = {
  level_id: 0,
  enabled: 1,
  confirm_days: 7,
  balance_transfer_enabled: 1,
  points_transfer_enabled: 1,
  single_min_balance: 0,
  single_max_balance: 0,
  single_min_points: 0,
  single_max_points: 0,
  daily_limit_balance_amount: 0,
  daily_limit_points_amount: 0,
  daily_limit_times: 0,
  weekly_limit_times: 0,
  yearly_limit_times: 0,
  balance_transfer_fee: 0,
  points_transfer_fee: 0,
  balance_to_points_rate: 1,
  points_to_balance_rate: 1
}

const form: any = reactive({ ...defaultForm })

async function loadData() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/settlement/config' })
    list.value = res?.list || res?.data?.list || []
  } catch (e: any) {
    ElMessage.error(e.message || '加载失败')
  }
  loading.value = false
}

async function loadMembershipLevels() {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = res?.records || []
  } catch {}
}

function showForm(row: any) {
  if (row) {
    editId.value = row.id
    Object.keys(defaultForm).forEach(k => {
      form[k] = row[k] !== undefined ? row[k] : (defaultForm as any)[k]
    })
    form.enabled = row.enabled ? 1 : 0
    form.balance_transfer_enabled = row.balance_transfer_enabled ? 1 : 0
    form.points_transfer_enabled = row.points_transfer_enabled ? 1 : 0
  } else {
    editId.value = null
    Object.keys(defaultForm).forEach(k => {
      form[k] = (defaultForm as any)[k]
    })
  }
  visible.value = true
}

async function doSave() {
  saving.value = true
  try {
    if (editId.value) {
      await request.put({ url: `/api/settlement/config/${editId.value}`, data: { ...form } })
      ElMessage.success('规则已更新')
    } else {
      await request.post({ url: '/api/settlement/config', data: { ...form } })
      ElMessage.success('规则已添加')
    }
    visible.value = false
    loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '保存失败')
  }
  saving.value = false
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm(`确定删除「${row.level_name}」的结算规则吗？`, '确认删除', { type: 'warning' })
    await request.del({ url: `/api/settlement/config/${row.id}` })
    ElMessage.success('已删除')
    loadData()
  } catch {}
}

onMounted(() => {
  loadData()
  loadMembershipLevels()
  loadReports()
})

const reports = ref<any[]>([])
const reportsLoading = ref(false)

async function loadReports() {
  reportsLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/settlement/admin-reports' })
    reports.value = res?.list || res?.data?.list || []
  } catch {}
  reportsLoading.value = false
}

async function adminHandle(row: any, action: string) {
  try {
    const { value: reason } = await ElMessageBox.prompt(
      action === 'agree' ? '请输入同意退款的原因（可选）' : '请输入驳回退款的原因（可选）',
      action === 'agree' ? '同意退款' : '驳回退款',
      { confirmButtonText: '确定', cancelButtonText: '取消', inputType: 'textarea' }
    ).catch(() => {})
    await ElMessageBox.confirm(
      `确定${action === 'agree' ? '同意' : '驳回'}该退款申请吗？`,
      '再次确认',
      { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }
    )
    await request.post({ url: '/api/settlement/admin-refund', data: { orderId: row.id, userId: userStore.info?.userId, action, reason: reason || '' } })
    ElMessage.success(action === 'agree' ? '已同意退款' : '已驳回退款')
    loadReports()
  } catch {}
}
</script>

<style scoped>
.settlement-page { padding: 20px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.settlement-form { max-height: 60vh; overflow-y: auto; padding-right: 8px; }
:deep(.el-overlay-dialog) {
  display: flex;
  align-items: center;
  justify-content: center;
}
:deep(.el-dialog) {
  margin: 0 !important;
}
</style>
