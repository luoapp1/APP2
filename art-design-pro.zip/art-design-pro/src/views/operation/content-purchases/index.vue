<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header><div class="card-header"><span>付费内容订单</span></div></template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import request from '@/utils/http'
import { useTable } from '@/hooks/core/useTable'

const columns = [
  { prop: 'id', label: 'ID', width: 60 },
  { prop: 'userName', label: '用户', width: 120 },
  {
    prop: 'content_type', label: '类型', width: 80,
    formatter: (row: any) => row.content_type === 'app' ? '应用' : '帖子'
  },
  { prop: 'content_id', label: '内容ID', width: 80 },
  { prop: 'amount', label: '付款金额', width: 100 },
  { prop: 'pay_type', label: '支付方式', width: 100 },
  { prop: 'commission_amount', label: '分成金额', width: 100 },
  {
    prop: 'commission_rate', label: '分成比例', width: 90,
    formatter: (row: any) => `${row.commission_rate}%`
  },
  { prop: 'create_time', label: '购买时间', minWidth: 170 }
]

const { data, loading, pagination, handleSizeChange, handleCurrentChange } = useTable({
  core: {
    apiFn: (params: any) => request.get({ url: '/api/admin/content/purchases', params: { page: params.current, size: params.size } }),
    apiParams: { current: 1, size: 20 }
  }
})
</script>
