<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header><div class="card-header"><span>付费内容订单</span></div></template>
      <ElTable :data="records" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="userName" label="用户" width="120" />
        <ElTableColumn prop="content_type" label="类型" width="80">
          <template #default="{ row }">{{ row.content_type==='app'?'应用':'帖子' }}</template>
        </ElTableColumn>
        <ElTableColumn prop="content_id" label="内容ID" width="80" />
        <ElTableColumn prop="amount" label="付款金额" width="100" />
        <ElTableColumn prop="pay_type" label="支付方式" width="100" />
        <ElTableColumn prop="commission_amount" label="分成金额" width="100" />
        <ElTableColumn prop="commission_rate" label="分成比例" width="90">
          <template #default="{ row }">{{ row.commission_rate }}%</template>
        </ElTableColumn>
        <ElTableColumn label="购买时间" minWidth="170">
          <template #default="{ row }">{{ row.create_time?.slice(0,16) }}</template>
        </ElTableColumn>
      </ElTable>
      <ElPagination v-if="total>size" :total="total" :page-size="size" :current-page="page" @current-change="p=>{page=p;loadData()}" layout="total,prev,pager,next" style="margin-top:16px;justify-content:flex-end" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const records = ref<any[]>([])
const loading = ref(false)
const page = ref(1)
const size = ref(20)
const total = ref(0)

async function loadData() {
  loading.value = true
  try {
    const r: any = await request.get({ url: '/api/admin/content/purchases', params: { page: page.value, size: size.value } })
    records.value = r.records || r || []
    total.value = r.total || 0
  } catch {} finally { loading.value = false }
}

onMounted(loadData)
</script>
