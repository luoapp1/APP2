<!-- 布局主题管理 -->
<template>
  <div class="layout-themes-page art-full-height">
    <div v-for="group in themeGroups" :key="group.type" style="margin-bottom:24px">
      <ElCard>
        <template #header>
          <div class="card-header">
            <span>{{ group.label }}</span>
            <span class="sub-text">{{ group.themes.length }} 个主题</span>
          </div>
        </template>
        <div class="theme-grid">
          <div
            v-for="theme in group.themes"
            :key="theme.id"
            class="theme-card"
            :class="{ 'is-active': isActive(theme) }"
          >
            <div class="theme-card-header">
              <span class="theme-name">{{ theme.name }}</span>
              <ElTag v-if="isActive(theme)" type="success" size="small">当前使用</ElTag>
            </div>
            <div class="theme-desc">{{ theme.description || '无描述' }}</div>
            <div class="theme-footer">
              <span class="theme-id">ID: {{ theme.id }}</span>
              <ElButton
                v-if="!isActive(theme)"
                size="small"
                type="primary"
                :loading="activating === theme.id"
                @click="doActivate(theme)"
              >
                启用
              </ElButton>
            </div>
          </div>
          <div v-if="group.themes.length === 0" class="theme-empty">
            暂无{{ group.type === 'pc' ? 'PC' : '手机' }}端主题
          </div>
        </div>
      </ElCard>
    </div>
  </div>
</template>

<script setup lang="ts">
import { fetchLayoutThemes, setActiveLayoutTheme } from '@/api/layout-themes'

defineOptions({ name: 'LayoutThemesManage' })

const loading = ref(false)
const activating = ref('')
const themes = ref<any[]>([])
const activePc = ref('pc')
const activeMobile = ref('mobile')

const themeGroups = computed(() => [
  {
    type: 'pc',
    label: 'PC 端布局主题',
    themes: themes.value.filter((t: any) => t.type === 'pc')
  },
  {
    type: 'mobile',
    label: '手机端布局主题',
    themes: themes.value.filter((t: any) => t.type === 'mobile')
  }
])

function isActive(theme: any) {
  return theme.type === 'pc' ? theme.id === activePc.value : theme.id === activeMobile.value
}

async function fetchData() {
  loading.value = true
  try {
    const res: any = await fetchLayoutThemes()
    if (res) {
      themes.value = res.themes || []
      activePc.value = res.activePc || 'pc'
      activeMobile.value = res.activeMobile || 'mobile'
    }
  } finally {
    loading.value = false
  }
}

async function doActivate(theme: any) {
  activating.value = theme.id
  try {
    await setActiveLayoutTheme(theme.type, theme.id)
    ElMessage.success(`已启 ${theme.type === 'pc' ? 'PC' : '手机'} 端主题: ${theme.name}`)
    if (theme.type === 'pc') activePc.value = theme.id
    else activeMobile.value = theme.id
  } catch {
    ElMessage.error('切换失败')
  } finally {
    activating.value = ''
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.layout-themes-page {
  padding: 0;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.sub-text {
  font-size: 12px;
  color: #999;
}

.theme-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}

.theme-card {
  border: 1px solid var(--default-border);
  border-radius: 8px;
  padding: 16px;
  transition: border-color .2s, box-shadow .2s;
}

.theme-card:hover {
  border-color: var(--art-el-active-color);
  box-shadow: 0 2px 8px var(--art-shadow-color);
}

.theme-card.is-active {
  border-color: #22c55e;
  background: #f0fdf4;
}

.theme-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.theme-name {
  font-weight: 600;
  font-size: 15px;
}

.theme-desc {
  color: #666;
  font-size: 13px;
  margin-bottom: 12px;
  line-height: 1.5;
}

.theme-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.theme-id {
  font-size: 12px;
  color: #999;
  font-family: monospace;
}

.theme-empty {
  grid-column: 1 / -1;
  text-align: center;
  color: #999;
  padding: 32px 0;
}
</style>
