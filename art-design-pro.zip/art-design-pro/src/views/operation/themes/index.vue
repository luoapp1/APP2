<!-- 主题管理页面 -->
<template>
  <div class="themes-page art-full-height p-4">
    <div class="mb-4 flex items-center justify-between">
      <h3 class="text-base font-bold">主题管理</h3>
      <ElButton type="primary" size="small" @click="showDialog('add')">新建主题</ElButton>
    </div>

    <el-table :data="themeList" stripe border>
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="name" label="名称" width="120" />
      <el-table-column prop="description" label="描述" min-width="180" show-overflow-tooltip />
      <el-table-column label="状态" width="120" align="center">
        <template #default="{ row }">
          <div class="flex gap-2 justify-center">
            <ElTag v-if="row.isActive" type="success" size="small">已激活</ElTag>
            <ElTag v-if="row.isPreset" type="info" size="small">预设</ElTag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="160" />
      <el-table-column label="操作" width="240" align="center" fixed="right">
        <template #default="{ row }">
          <ElButton size="small" type="primary" link @click="showDialog('edit', row)">编辑</ElButton>
          <ElButton v-if="!row.isActive" size="small" type="success" link @click="handleActivate(row)">激活</ElButton>
          <ElButton v-if="!row.isActive" size="small" type="warning" link @click="handleDelete(row)">删除</ElButton>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '新建主题' : '编辑主题'"
      width="720px"
      destroy-on-close
      :close-on-click-modal="false"
    >
      <el-form :model="formData" label-width="80px">
        <el-form-item label="名称">
          <el-input v-model="formData.name" placeholder="主题名称" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="formData.description" type="textarea" :rows="2" placeholder="主题描述" />
        </el-form-item>

        <el-divider content-position="left">设计令牌编辑</el-divider>

        <el-tabs v-model="activeTab" type="card">
          <el-tab-pane label="PC 亮色" name="vars">
            <TokenEditor v-model="formData.vars" />
          </el-tab-pane>
          <el-tab-pane label="PC 暗色" name="varsDark">
            <TokenEditor v-model="formData.varsDark" />
          </el-tab-pane>
          <el-tab-pane label="手机亮色" name="varsMobile">
            <TokenEditor v-model="formData.varsMobile" />
          </el-tab-pane>
          <el-tab-pane label="手机暗色" name="varsMobileDark">
            <TokenEditor v-model="formData.varsMobileDark" />
          </el-tab-pane>
        </el-tabs>
      </el-form>

      <template #footer>
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSave">保存</ElButton>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { fetchThemes, createTheme, updateTheme, deleteTheme as delTheme, activateTheme } from '@/api/themes'
import type { ThemeData, ThemeTokenSet } from '@/api/themes'
import { ElButton, ElMessage, ElMessageBox } from 'element-plus'
import TokenEditor from './modules/token-editor.vue'
import { fetchAndApplyTheme } from '@/hooks/core/useTheme'

defineOptions({ name: 'ThemesManage' })

const themeList = ref<ThemeData[]>([])
const dialogVisible = ref(false)
const dialogType = ref<'add' | 'edit'>('add')
const activeTab = ref('vars')
const editingId = ref<number>(0)

const formData = reactive({
  name: '',
  description: '',
  vars: {} as ThemeTokenSet,
  varsDark: {} as ThemeTokenSet,
  varsMobile: {} as ThemeTokenSet,
  varsMobileDark: {} as ThemeTokenSet
})

const loadThemes = async () => {
  try {
    const data = await fetchThemes()
    themeList.value = Array.isArray(data) ? data : []
  } catch { themeList.value = [] }
}
loadThemes()

const resetForm = () => {
  formData.name = ''
  formData.description = ''
  formData.vars = {}
  formData.varsDark = {}
  formData.varsMobile = {}
  formData.varsMobileDark = {}
  activeTab.value = 'vars'
  editingId.value = 0
}

const showDialog = (type: 'add' | 'edit', row?: ThemeData) => {
  dialogType.value = type
  resetForm()
  if (type === 'edit' && row) {
    editingId.value = row.id
    formData.name = row.name
    formData.description = row.description
    formData.vars = { ...row.vars }
    formData.varsDark = { ...row.varsDark }
    formData.varsMobile = { ...row.varsMobile }
    formData.varsMobileDark = { ...row.varsMobileDark }
  }
  dialogVisible.value = true
}

const handleSave = async () => {
  if (!formData.name.trim()) {
    ElMessage.warning('请输入主题名称')
    return
  }
  try {
    if (dialogType.value === 'add') {
      await createTheme({
        name: formData.name,
        description: formData.description,
        vars: formData.vars,
        varsDark: formData.varsDark,
        varsMobile: formData.varsMobile,
        varsMobileDark: formData.varsMobileDark
      } as any)
      ElMessage.success('创建成功')
    } else {
      await updateTheme(editingId.value, {
        name: formData.name,
        description: formData.description,
        vars: formData.vars,
        varsDark: formData.varsDark,
        varsMobile: formData.varsMobile,
        varsMobileDark: formData.varsMobileDark
      } as any)
      ElMessage.success('更新成功')
    }
    dialogVisible.value = false
    await loadThemes()
  } catch (e: any) {
    ElMessage.error(e?.message || '保存失败')
  }
}

const handleActivate = async (row: ThemeData) => {
  try {
    await ElMessageBox.confirm(`确定要激活主题「${row.name}」吗？激活后全站用户将立即看到新主题。`, '激活主题', {
      confirmButtonText: '确定激活',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await activateTheme(row.id)
    ElMessage.success(`已激活主题「${row.name}」`)
    await loadThemes()
    await fetchAndApplyTheme()
  } catch {}
}

const handleDelete = async (row: ThemeData) => {
  if (row.isPreset) {
    ElMessage.warning('预设主题不可删除')
    return
  }
  if (row.isActive) {
    ElMessage.warning('激活中的主题不可删除，请先激活其他主题')
    return
  }
  try {
    await ElMessageBox.confirm(`确定要删除主题「${row.name}」吗？此操作不可撤销。`, '删除主题', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      type: 'error'
    })
    await delTheme(row.id)
    ElMessage.success('删除成功')
    await loadThemes()
  } catch {}
}
</script>
