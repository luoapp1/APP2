<!-- 设计令牌编辑器 - 编辑单组 28 个令牌 -->
<template>
  <div class="token-editor">
    <div class="token-grid">
      <div v-for="token in tokenFields" :key="token.key" class="token-field">
        <label class="token-label">{{ token.label }}</label>
        <input
          class="token-input"
          :value="modelValue[token.key] || ''"
          :placeholder="token.placeholder"
          @input="updateToken(token.key, ($event.target as HTMLInputElement).value)"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { ThemeTokenSet } from '@/api/themes'

const props = defineProps<{
  modelValue: ThemeTokenSet
}>()

const emit = defineEmits<{
  'update:modelValue': [value: ThemeTokenSet]
}>()

const tokenFields = [
  { key: 'mainColor', label: '主题色', placeholder: '#5D87FF' },
  { key: 'primary', label: '主色', placeholder: 'oklch(0.7 0.23 260)' },
  { key: 'secondary', label: '辅色', placeholder: 'oklch(0.72 0.19 231.6)' },
  { key: 'gray100', label: '灰阶 100', placeholder: '#f9fafb' },
  { key: 'gray200', label: '灰阶 200', placeholder: '#f2f4f5' },
  { key: 'gray300', label: '灰阶 300', placeholder: '#e6eaeb' },
  { key: 'gray400', label: '灰阶 400', placeholder: '#dbdfe1' },
  { key: 'gray500', label: '灰阶 500', placeholder: '#949eb7' },
  { key: 'gray600', label: '灰阶 600', placeholder: '#7987a1' },
  { key: 'gray700', label: '灰阶 700', placeholder: '#4d5875' },
  { key: 'gray800', label: '灰阶 800', placeholder: '#383853' },
  { key: 'gray900', label: '灰阶 900', placeholder: '#323251' },
  { key: 'bgColor', label: '页面背景', placeholder: '#fafbfc' },
  { key: 'boxColor', label: '组件背景', placeholder: '#ffffff' },
  { key: 'hoverColor', label: '悬停色', placeholder: '#edeff0' },
  { key: 'activeColor', label: '激活色', placeholder: '#f2f4f5' },
  { key: 'elActiveColor', label: '组件激活色', placeholder: '#f2f4f5' },
  { key: 'defaultBorder', label: '默认边框', placeholder: '#e2e8ee' },
  { key: 'dashedBorder', label: '虚线边框', placeholder: '#dbdfe9' },
  { key: 'cardBorder', label: '卡片边框', placeholder: 'rgba(0,0,0,0.08)' },
  { key: 'error', label: '错误色', placeholder: 'oklch(0.73 0.15 25.3)' },
  { key: 'info', label: '信息色', placeholder: 'oklch(0.58 0.03 254.1)' },
  { key: 'success', label: '成功色', placeholder: 'oklch(0.78 0.17 166.1)' },
  { key: 'warning', label: '警告色', placeholder: 'oklch(0.78 0.14 75.5)' },
  { key: 'danger', label: '危险色', placeholder: 'oklch(0.68 0.22 25.3)' },
  { key: 'borderRadius', label: '圆角', placeholder: '0.25' },
  { key: 'shadowColor', label: '阴影色', placeholder: 'rgba(0,0,0,0.08)' },
  { key: 'fontFamily', label: '字体', placeholder: 'system-ui, sans-serif' }
]

function updateToken(key: string, value: string) {
  const updated = { ...props.modelValue, [key]: value }
  emit('update:modelValue', updated)
}
</script>

<style scoped>
.token-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 16px;
}
.token-field {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.token-label {
  font-size: 12px;
  color: var(--art-gray-600);
}
.token-input {
  border: 1px solid var(--default-border);
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 13px;
  background: var(--default-box-color);
  color: var(--art-gray-900);
  outline: none;
  font-family: monospace;
}
.token-input:focus {
  border-color: var(--main-color);
}
</style>
