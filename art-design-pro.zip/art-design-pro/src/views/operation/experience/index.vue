<!-- 经验等级管理页面 -->
<template>
  <div class="experience-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElButton type="primary" @click="showDialog('add')" v-ripple>添加等级</ElButton>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增经验等级' : '编辑经验等级'" width="35%" align-center>
        <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
          <ElFormItem label="等级名称" prop="name">
            <ElInput v-model="formData.name" placeholder="请输入等级名称" />
          </ElFormItem>
          <ElFormItem label="等级数值" prop="level">
            <ElInputNumber v-model="formData.level" :min="1" :max="99" style="width: 100%" />
          </ElFormItem>
          <ElFormItem label="所需经验" prop="expRequired">
            <ElInputNumber v-model="formData.expRequired" :min="0" :step="100" style="width: 100%" />
          </ElFormItem>
          <ElFormItem label="图标色" prop="iconColor">
            <ElColorPicker v-model="formData.iconColor" />
          </ElFormItem>
          <ElFormItem label="权益描述" prop="benefits">
            <ElInput v-model="formData.benefits" type="textarea" :rows="3" placeholder="请输入权益描述" />
          </ElFormItem>
          <ElFormItem label="状态" prop="status">
            <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
          </ElFormItem>
        </ElForm>
        <template #footer>
          <div class="dialog-footer">
            <ElButton @click="dialogVisible = false">取消</ElButton>
            <ElButton type="primary" @click="handleSubmit">保存</ElButton>
          </div>
        </template>
      </ElDialog>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTable } from '@/hooks/core/useTable'
  import { fetchExpLevelList, fetchExpLevelSave, fetchExpLevelDelete } from '@/api/operation'
  import { ElTag, ElButton, ElMessageBox, ElMessage, ElInput, ElInputNumber, ElColorPicker, ElSwitch, ElDialog, ElForm, ElFormItem } from 'element-plus'
  import type { FormInstance, FormRules } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'ExperienceLevel' })

  type ExpLevelRecord = {
    id: number
    name: string
    level: number
    expRequired: number
    iconColor: string
    benefits: string
    status: string
    createTime: string
  }

  const dialogVisible = ref(false)
  const dialogType = ref<DialogType>('add')
  const currentRow = ref<Partial<ExpLevelRecord>>({})
  const formRef = ref<FormInstance>()

  const formData = reactive({
    name: '',
    level: 1,
    expRequired: 0,
    iconColor: '#409eff',
    benefits: '',
    status: '1' as string
  })

  const rules: FormRules = {
    name: [{ required: true, message: '请输入等级名称', trigger: 'blur' }],
    level: [{ required: true, message: '请输入等级数值', trigger: 'blur' }]
  }

  const EXP_STATUS_CONFIG: Record<string, { type: 'success' | 'info'; text: string }> = {
    '1': { type: 'success', text: '启用' },
    '0': { type: 'info', text: '禁用' }
  }
  const getStatusConfig = (status: string) => EXP_STATUS_CONFIG[status] || { type: 'info' as const, text: '未知' }

  const { columns, columnChecks, data, loading, pagination, getData, handleSizeChange, handleCurrentChange, refreshData } = useTable({
    core: {
      apiFn: fetchExpLevelList,
      apiParams: { current: 1, size: 20 },
      columnsFactory: () => [
        { type: 'index', width: 60, label: '序号' },
        { prop: 'name', label: '等级名称', width: 120 },
        { prop: 'level', label: '等级数值', width: 100, sortable: true },
        { prop: 'expRequired', label: '所需经验', width: 110, sortable: true },
        { prop: 'iconColor', label: '图标色', width: 100, formatter: (row: ExpLevelRecord) => h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } }, [h('span', { style: { width: '14px', height: '14px', borderRadius: '50%', backgroundColor: row.iconColor, display: 'inline-block', border: '1px solid var(--el-border-color)' } }), h('span', row.iconColor)]) },
        { prop: 'status', label: '状态', width: 80, formatter: (row: ExpLevelRecord) => { const c = getStatusConfig(row.status); return h(ElTag, { type: c.type, size: 'small' }, () => c.text) } },
        { prop: 'createTime', label: '创建时间', width: 180 },
        { prop: 'operation', label: '操作', width: 140, fixed: 'right', formatter: (row: ExpLevelRecord) => h('div', { style: { display: 'flex', gap: '8px' } }, [h(ArtButtonTable, { type: 'edit', onClick: () => showDialog('edit', row) }), h(ArtButtonTable, { type: 'delete', onClick: () => deleteLevel(row) })]) }
      ]
    },
    transform: {
      dataTransformer: (records) => {
        if (!Array.isArray(records)) return []
        return records
      }
    }
  })

  getData()

  const showDialog = (type: DialogType, row?: ExpLevelRecord) => {
    dialogType.value = type
    if (type === 'edit' && row) {
      currentRow.value = row
      Object.assign(formData, {
        name: row.name || '',
        level: row.level || 1,
        expRequired: row.expRequired || 0,
        iconColor: row.iconColor || '#409eff',
        benefits: row.benefits || '',
        status: row.status || '1'
      })
    } else {
      currentRow.value = {}
      Object.assign(formData, { name: '', level: 1, expRequired: 0, iconColor: '#409eff', benefits: '', status: '1' })
    }
    nextTick(() => { dialogVisible.value = true; formRef.value?.clearValidate() })
  }

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate(async (valid) => {
      if (valid) {
        const data: Record<string, unknown> = {
          name: formData.name,
          level: formData.level,
          expRequired: formData.expRequired,
          iconColor: formData.iconColor,
          benefits: formData.benefits,
          status: formData.status
        }
        if (dialogType.value === 'edit' && currentRow.value.id) {
          data.id = currentRow.value.id
        }
        await fetchExpLevelSave(data)
        ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
        dialogVisible.value = false
        refreshData()
      }
    })
  }

  const deleteLevel = (row: ExpLevelRecord) => {
    ElMessageBox.confirm(`确定要删除等级「${row.name}」吗？`, '删除经验等级', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
      await fetchExpLevelDelete(row.id)
      ElMessage.success('删除成功')
      refreshData()
    }).catch(() => {})
  }
</script>
