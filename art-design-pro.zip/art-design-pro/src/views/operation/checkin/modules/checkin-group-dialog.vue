<template>
  <ElDialog
    v-model="dialogVisible"
    :title="dialogType === 'add' ? '新增签到规则' : '编辑签到规则'"
    width="720px"
    align-center
  >
    <ElForm ref="formRef" :model="formData" :rules="rules" label-width="130px">
      <ElFormItem label="规则名称" prop="name">
        <ElInput v-model="formData.name" placeholder="如：黄金会员签到规则" />
      </ElFormItem>
      <ElFormItem label="关联会员等级" prop="levelId">
        <ElSelect v-model="formData.levelId" placeholder="选择对应的会员等级" style="width:100%" clearable>
          <ElOption v-for="l in membershipLevels" :key="l.id" :label="l.name" :value="l.id" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem label="图标" prop="icon">
        <ElInput v-model="formData.icon" placeholder="emoji 图标，如 🏅" />
      </ElFormItem>
      <ElFormItem label="图标颜色" prop="iconColor">
        <ElColorPicker v-model="formData.iconColor" />
      </ElFormItem>
      <ElFormItem label="排序" prop="sortOrder">
        <ElInputNumber v-model="formData.sortOrder" :min="0" :max="999" style="width: 100%" />
      </ElFormItem>

      <ElDivider content-position="left">基础奖励</ElDivider>

      <ElFormItem label="积分奖励" prop="points">
        <ElInputNumber v-model="formData.points" :min="0" :max="9999" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="经验值奖励" prop="experience">
        <ElInputNumber v-model="formData.experience" :min="0" :max="9999" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="余额奖励" prop="balance">
        <ElInputNumber v-model="formData.balance" :min="0" :max="9999" :step="0.5" :precision="2" style="width: 100%" />
      </ElFormItem>

      <ElDivider content-position="left">连续签到额外奖励 (每天递增)</ElDivider>

      <ElFormItem label="额外积分/天" prop="pointsConsecutive">
        <ElInputNumber v-model="formData.pointsConsecutive" :min="0" :max="999" style="width: 100%" />
        <template #extra><span class="text-xs text-gray-400">每连续签到一天额外增加的积分</span></template>
      </ElFormItem>
      <ElFormItem label="额外经验/天" prop="experienceConsecutive">
        <ElInputNumber v-model="formData.experienceConsecutive" :min="0" :max="999" style="width: 100%" />
        <template #extra><span class="text-xs text-gray-400">每连续签到一天额外增加的经验值</span></template>
      </ElFormItem>
      <ElFormItem label="额外余额/天" prop="balanceConsecutive">
        <ElInputNumber v-model="formData.balanceConsecutive" :min="0" :max="999" :step="0.1" :precision="2" style="width: 100%" />
        <template #extra><span class="text-xs text-gray-400">每连续签到一天额外增加的余额</span></template>
      </ElFormItem>

      <ElDivider content-position="left">
        <span>阶梯奖励</span>
        <ElButton size="small" type="primary" link class="ml-2" @click="addMilestone">
          + 添加阶梯
        </ElButton>
      </ElDivider>

      <div v-if="milestones.length === 0" class="text-xs text-gray-400 mb-2 pl-2">
        暂无阶梯奖励，点击"+ 添加阶梯"设置连续签到满 N 天时的额外奖励
      </div>
      <div v-for="(m, idx) in milestones" :key="idx" class="milestone-item mb-3 p-4 border border-gray-200 rounded-lg bg-gray-50">
        <div class="flex items-center justify-between mb-3">
          <span class="text-sm font-bold">阶梯 {{ idx + 1 }}</span>
          <ElButton size="small" type="danger" link @click="removeMilestone(idx)">删除</ElButton>
        </div>
        <div class="grid grid-cols-2 gap-x-4 gap-y-2">
          <ElFormItem label="连续天数" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.days" :min="1" :max="9999" style="width:100%" placeholder="如 7" />
          </ElFormItem>
          <ElFormItem label="积分奖励" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.points" :min="0" :max="99999" style="width:100%" />
          </ElFormItem>
          <ElFormItem label="经验奖励" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.experience" :min="0" :max="99999" style="width:100%" />
          </ElFormItem>
          <ElFormItem label="余额奖励" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.balance" :min="0" :max="99999" :step="0.5" :precision="2" style="width:100%" />
          </ElFormItem>
          <ElFormItem label="卡密类型" label-width="80px" class="!mb-0">
            <ElSelect v-model="m.cardKeyType" style="width:100%" clearable placeholder="不奖励卡密" @change="(v: any) => onMilestoneCardTypeChange(idx, v)">
              <ElOption label="会员卡" value="membership" />
              <ElOption label="积分卡" value="points" />
              <ElOption label="经验卡" value="experience" />
              <ElOption label="余额卡" value="balance" />
              <ElOption label="补签卡" value="makeup" />
            </ElSelect>
          </ElFormItem>
          <template v-if="m.cardKeyType === 'membership'">
            <ElFormItem label="会员等级" label-width="80px" class="!mb-0">
              <ElSelect v-model="m.cardKeyValue" style="width:100%" placeholder="选择等级">
                <ElOption v-for="l in membershipLevels" :key="l.id" :label="l.name" :value="l.id" />
              </ElSelect>
            </ElFormItem>
            <ElFormItem label="有效期" label-width="80px" class="!mb-0">
              <div class="flex gap-1">
                <ElInputNumber v-model="m.cardKeyDuration" :min="1" :max="3650" style="flex:1" />
                <ElSelect v-model="m.cardKeyDurationUnit" style="width:80px">
                  <ElOption label="天" value="day" />
                  <ElOption label="月" value="month" />
                  <ElOption label="年" value="year" />
                </ElSelect>
              </div>
            </ElFormItem>
          </template>
          <ElFormItem v-else-if="m.cardKeyType === 'points'" label="积分数量" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyValue" :min="100" :max="999999" :step="100" style="width:100%" />
          </ElFormItem>
          <ElFormItem v-else-if="m.cardKeyType === 'experience'" label="经验数量" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyValue" :min="100" :max="999999" :step="100" style="width:100%" />
          </ElFormItem>
          <ElFormItem v-else-if="m.cardKeyType === 'balance'" label="余额金额" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyValue" :min="1" :max="99999" :step="1" style="width:100%" />
          </ElFormItem>
          <ElFormItem v-else-if="m.cardKeyType === 'makeup'" label="补签天数" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyValue" :min="1" :max="365" style="width:100%" />
            <template #extra><span class="text-xs text-gray-400">每张卡可补签最近N天中漏签的日期</span></template>
          </ElFormItem>
          <ElFormItem v-if="m.cardKeyType" label="额外积分" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyExtraPoints" :min="0" :max="99999" :step="100" style="width:100%" />
          </ElFormItem>
          <ElFormItem v-if="m.cardKeyType" label="额外经验" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyExtraExperience" :min="0" :max="99999" :step="100" style="width:100%" />
          </ElFormItem>
          <ElFormItem v-if="m.cardKeyType" label="额外余额" label-width="80px" class="!mb-0">
            <ElInputNumber v-model="m.cardKeyExtraBalance" :min="0" :max="99999" :step="0.5" :precision="2" style="width:100%" />
          </ElFormItem>
        </div>
      </div>

      <ElFormItem label="启用状态" prop="status">
        <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">保存</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import type { FormInstance, FormRules } from 'element-plus'

  interface Props { visible: boolean; type: string; groupData?: Record<string, any> }
  interface Emits { (e: 'update:visible', value: boolean): void; (e: 'submit', data: Record<string, unknown>): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const formRef = ref<FormInstance>()
  const dialogVisible = computed({ get: () => props.visible, set: (value) => emit('update:visible', value) })
  const dialogType = computed(() => props.type)

  const formData = reactive({
    name: '', levelId: 0, icon: '', iconColor: '#409EFF',
    points: 5, experience: 2, balance: 0,
    pointsConsecutive: 2, experienceConsecutive: 1, balanceConsecutive: 0,
    sortOrder: 0, status: '1' as string
  })

  const milestones = ref<any[]>([])
  const membershipLevels = ref<any[]>([])

  const rules: FormRules = {
    name: [{ required: true, message: '请输入规则名称', trigger: 'blur' }]
  }

  const loadMembershipLevels = async () => {
    try {
      const { fetchGetMembershipLevelList } = await import('@/api/operation')
      const r: any = await fetchGetMembershipLevelList({ current: 1, size: 100 })
      membershipLevels.value = (r?.records || r?.list || r || []).filter((l: any) => l.status === '1')
    } catch {}
  }

  const loadMilestones = async () => {
    if (!props.groupData?.id) { milestones.value = []; return }
    try {
      const { fetchGetCheckinMilestoneList } = await import('@/api/operation')
      const r: any = await fetchGetCheckinMilestoneList({ groupId: props.groupData.id })
      milestones.value = (r?.records || []).map((m: any) => ({
        id: m.id,
        days: m.days,
        points: m.points || 0,
        experience: m.experience || 0,
        balance: Number(m.balance) || 0,
        cardKeyType: m.card_key_type || '',
        cardKeyValue: m.card_key_value || 0,
        cardKeyDuration: m.card_key_duration || 0,
        cardKeyDurationUnit: m.card_key_duration_unit || '',
        cardKeyExtraPoints: m.card_key_extra_points || 0,
        cardKeyExtraExperience: m.card_key_extra_experience || 0,
        cardKeyExtraBalance: Number(m.card_key_extra_balance) || 0,
        sortOrder: m.sort_order || 0,
        status: m.status || '1'
      }))
    } catch {}
  }

  const initFormData = () => {
    const isEdit = props.type === 'edit' && props.groupData
    const row = props.groupData
    Object.assign(formData, {
      name: (isEdit && row ? row.name : '') || '',
      levelId: (isEdit && row ? (row.levelId || 0) : 0) ?? 0,
      icon: (isEdit && row ? row.icon : '') || '',
      iconColor: (isEdit && row ? row.iconColor : '#409EFF') || '#409EFF',
      points: (isEdit && row ? row.points : 5) ?? 5,
      experience: (isEdit && row ? row.experience : 2) ?? 2,
      balance: (isEdit && row ? Number(row.balance) : 0) ?? 0,
      pointsConsecutive: (isEdit && row ? row.pointsConsecutive : 2) ?? 2,
      experienceConsecutive: (isEdit && row ? row.experienceConsecutive : 1) ?? 1,
      balanceConsecutive: (isEdit && row ? Number(row.balanceConsecutive) : 0) ?? 0,
      sortOrder: (isEdit && row ? row.sortOrder : 0) ?? 0,
      status: (isEdit && row ? row.status : '1') || '1'
    })
  }

  const addMilestone = () => {
    milestones.value.push({
      id: 0,
      days: 7,
      points: 0,
      experience: 0,
      balance: 0,
      cardKeyType: '',
      cardKeyValue: 0,
      cardKeyDuration: 0,
      cardKeyDurationUnit: '',
      cardKeyExtraPoints: 0,
      cardKeyExtraExperience: 0,
      cardKeyExtraBalance: 0,
      sortOrder: milestones.value.length,
      status: '1'
    })
  }

  const removeMilestone = (idx: number) => {
    milestones.value.splice(idx, 1)
  }

  const onMilestoneCardTypeChange = (idx: number, type: string) => {
    const m = milestones.value[idx]
    if (!m) return
    m.cardKeyValue = 0
    m.cardKeyDuration = 0
    m.cardKeyDurationUnit = ''
    m.cardKeyExtraPoints = 0
    m.cardKeyExtraExperience = 0
    m.cardKeyExtraBalance = 0
    if (type === 'membership') {
      m.cardKeyValue = membershipLevels.value[0]?.id || 1
      m.cardKeyDuration = 1
      m.cardKeyDurationUnit = 'month'
    } else if (type === 'points') {
      m.cardKeyValue = 500
    } else if (type === 'experience') {
      m.cardKeyValue = 500
    } else if (type === 'balance') {
      m.cardKeyValue = 50
    } else if (type === 'makeup') {
      m.cardKeyValue = 1
    }
  }

  watch(
    () => [props.visible, props.type, props.groupData],
    ([visible]) => {
      if (visible) {
        loadMembershipLevels()
        initFormData()
        loadMilestones()
        nextTick(() => formRef.value?.clearValidate())
      }
    },
    { immediate: true }
  )

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate(async (valid) => {
      if (valid) {
        let groupId = props.groupData?.id || 0
        const data: Record<string, unknown> = {
          name: formData.name,
          levelId: formData.levelId,
          icon: formData.icon,
          iconColor: formData.iconColor,
          points: formData.points,
          experience: formData.experience,
          balance: formData.balance,
          pointsConsecutive: formData.pointsConsecutive,
          experienceConsecutive: formData.experienceConsecutive,
          balanceConsecutive: formData.balanceConsecutive,
          sortOrder: formData.sortOrder,
          status: formData.status
        }
        if (dialogType.value === 'edit' && groupId) {
          data.id = groupId
        }

        ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
        dialogVisible.value = false
        emit('submit', { ...data, milestones: milestones.value })
      }
    })
  }
</script>
