<!-- 签到管理页面 -->
<template>
  <div class="checkin-page art-full-height">
    <div class="mb-4 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <h3 class="text-base font-bold">签到设置</h3>
        <ElTag :type="checkinEnabled ? 'success' : 'danger'" size="small">
          {{ checkinEnabled ? '已开启' : '已关闭' }}
        </ElTag>
      </div>
      <ElButton type="primary" size="small" @click="showGroupDialog('add')" v-ripple>
        添加签到规则
      </ElButton>
    </div>

    <ElCard class="mb-4">
      <div class="flex items-center justify-between">
        <div>
          <div class="text-sm font-medium">签到功能</div>
          <div class="text-xs text-gray-400 mt-1">开启后用户可以进行每日签到获取奖励</div>
        </div>
        <ElSwitch v-model="checkinEnabled" @change="toggleCheckin" />
      </div>
    </ElCard>

    <div v-if="groupList.length > 0" class="checkin-groups grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      <div v-for="group in groupList" :key="group.id" class="group-card" :style="{ borderTopColor: group.iconColor }">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2">
            <span class="text-lg" v-if="group.icon">{{ group.icon }}</span>
            <span class="text-base font-bold" :style="{ color: group.iconColor }">{{ group.name }}</span>
          </div>
          <ElTag :type="group.status === '1' ? 'success' : 'info'" size="small">
            {{ group.status === '1' ? '启用' : '禁用' }}
          </ElTag>
        </div>

        <div v-if="group.levelName" class="text-xs text-blue-500 mb-2">关联: {{ group.levelName }}</div>

        <div class="text-sm text-gray-500 mb-3 space-y-1">
          <p>基础积分: <span class="text-orange-500 font-bold">{{ group.points || 0 }}</span></p>
          <p v-if="Number(group.experience) > 0">基础经验: <span class="text-blue-500 font-bold">{{ group.experience }}</span></p>
          <p v-if="Number(group.balance) > 0">基础余额: <span class="text-red-500 font-bold">¥{{ group.balance }}</span></p>
          <div class="border-t border-gray-100 my-1 pt-1">
            <p class="text-xs text-gray-400">连续签到额外 (每天递增)</p>
            <p v-if="Number(group.pointsConsecutive) > 0">积分: <span class="text-orange-500 font-bold">+{{ group.pointsConsecutive }}</span>/天</p>
            <p v-if="Number(group.experienceConsecutive) > 0">经验: <span class="text-blue-500 font-bold">+{{ group.experienceConsecutive }}</span>/天</p>
            <p v-if="Number(group.balanceConsecutive) > 0">余额: <span class="text-red-500 font-bold">+¥{{ group.balanceConsecutive }}</span>/天</p>
          </div>
          <div v-if="group._milestones && group._milestones.length > 0" class="border-t border-gray-100 my-1 pt-1">
            <p class="text-xs text-gray-400">阶梯奖励</p>
            <p v-for="ms in group._milestones" :key="ms.days" class="text-xs">
              连签{{ ms.days }}天:
              <span v-if="ms.points > 0" class="text-orange-500">+{{ ms.points }}积分 </span>
              <span v-if="ms.experience > 0" class="text-blue-500">+{{ ms.experience }}经验 </span>
              <span v-if="ms.balance > 0" class="text-red-500">+¥{{ ms.balance }} </span>
              <span v-if="ms.cardKeyType" class="text-green-500">+卡密</span>
            </p>
          </div>
        </div>

        <div class="mt-3 flex gap-2">
          <ElButton size="small" type="primary" link @click="showGroupDialog('edit', group)">编辑</ElButton>
          <ElButton size="small" type="danger" link @click="deleteGroup(group)">删除</ElButton>
        </div>
      </div>
    </div>

    <ElEmpty v-else description="暂无签到规则，请点击上方按钮添加" />

    <CheckinGroupDialog
      v-model:visible="groupDialogVisible"
      :type="groupDialogType"
      :group-data="currentGroupData"
      @submit="handleGroupSubmit"
    />
  </div>
</template>

<script setup lang="ts">
  import { fetchGetCheckinGroupList, fetchSaveCheckinGroup, fetchDeleteCheckinGroup, fetchGetCheckinMilestoneList, fetchSaveCheckinMilestone, fetchDeleteCheckinMilestone } from '@/api/operation'
  import { fetchGetSysConfig, fetchSaveSysConfig } from '@/api/system-manage'
  import CheckinGroupDialog from './modules/checkin-group-dialog.vue'
  import { ElButton, ElMessageBox, ElMessage } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'CheckinManage' })

  interface CheckinGroupItem {
    id: number; name: string; levelId: number; levelName?: string
    icon: string; iconColor: string
    points: number; experience: number; balance: number
    pointsConsecutive: number; experienceConsecutive: number; balanceConsecutive: number
    sortOrder: number; status: string; createTime: string; updateTime: string
    _milestones?: any[]
  }

  const groupDialogType = ref<DialogType>('add')
  const groupDialogVisible = ref(false)
  const currentGroupData = ref<Partial<CheckinGroupItem>>({})
  const groupList = ref<CheckinGroupItem[]>([])
  const checkinEnabled = ref(true)

  const loadGroups = async () => {
    try {
      const data = await fetchGetCheckinGroupList({ current: 1, size: 100 })
      if (data && (data as any).records) {
        const records = (data as any).records
        for (const g of records) {
          try {
            const mr: any = await fetchGetCheckinMilestoneList({ groupId: g.id })
            g._milestones = mr?.records || []
          } catch { g._milestones = [] }
        }
        groupList.value = records
      }
    } catch {}
  }

  const loadCheckinEnabled = async () => {
    try {
      const res: any = await fetchGetSysConfig('checkin_enabled')
      if (res && res.data) checkinEnabled.value = res.data.config_value === 'true'
    } catch {}
  }

  loadGroups()
  loadCheckinEnabled()

  const toggleCheckin = async (val: boolean) => {
    try {
      await fetchSaveSysConfig([{ config_key: 'checkin_enabled', config_value: val ? 'true' : 'false' }])
      ElMessage.success(val ? '签到功能已开启' : '签到功能已关闭')
    } catch {
      checkinEnabled.value = !val
      ElMessage.error('操作失败')
    }
  }

  const showGroupDialog = (type: DialogType, row?: CheckinGroupItem) => {
    groupDialogType.value = type
    currentGroupData.value = row || {}
    nextTick(() => { groupDialogVisible.value = true })
  }

  const handleGroupSubmit = async (formData?: Record<string, unknown>) => {
    if (!formData) return
    const { milestones, ...groupData } = formData
    let groupId = (groupData as any).id || 0

    const res: any = await fetchSaveCheckinGroup(groupData as any)
    if (!groupId && res && (res as any).data?.id) {
      groupId = (res as any).data.id
    } else if (!groupId && res && res.id) {
      groupId = res.id
    }

    if (groupId && Array.isArray(milestones)) {
      const existingRes: any = await fetchGetCheckinMilestoneList({ groupId })
      const existingIds = ((existingRes?.data?.records) || []).map((m: any) => m.id)
      const submittedIds: number[] = []

      for (const m of milestones as any[]) {
        const msData: any = {
          groupId,
          days: m.days,
          points: m.points || 0,
          experience: m.experience || 0,
          balance: m.balance || 0,
          cardKeyType: m.cardKeyType || '',
          cardKeyValue: m.cardKeyValue || 0,
          cardKeyDuration: m.cardKeyDuration || 0,
          cardKeyDurationUnit: m.cardKeyDurationUnit || '',
          cardKeyExtraPoints: m.cardKeyExtraPoints || 0,
          cardKeyExtraExperience: m.cardKeyExtraExperience || 0,
          cardKeyExtraBalance: m.cardKeyExtraBalance || 0,
          sortOrder: m.sortOrder || 0,
          status: m.status || '1'
        }
        if (m.id && m.id > 0) {
          msData.id = m.id
          submittedIds.push(m.id)
        }
        const sr: any = await fetchSaveCheckinMilestone(msData)
        if (!m.id && sr?.data?.id) submittedIds.push(sr.data.id)
      }

      for (const eid of existingIds) {
        if (!submittedIds.includes(eid)) {
          await fetchDeleteCheckinMilestone(eid)
        }
      }
    }

    groupDialogVisible.value = false
    await loadGroups()
  }

  const deleteGroup = (row: CheckinGroupItem) => {
    ElMessageBox.confirm(`确定要删除签到规则「${row.name}」吗？`, '删除签到规则', {
      confirmButtonText: '确定', cancelButtonText: '取消', type: 'error'
    }).then(async () => {
      await fetchDeleteCheckinGroup(row.id)
      ElMessage.success('删除成功')
      await loadGroups()
    }).catch(() => {})
  }
</script>

<style scoped>
  .group-card {
    border: 1px solid var(--el-border-color-light);
    border-top: 3px solid;
    border-radius: 8px;
    padding: 16px;
    background: var(--el-bg-color);
    transition: box-shadow 0.3s;
  }
  .group-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  }
</style>
