<!-- 会员管理页面 -->
<template>
  <div class="membership-page art-full-height">
    <!-- 会员等级卡片 -->
    <div class="mb-4 flex items-center justify-between">
      <h3 class="text-base font-bold">会员等级</h3>
      <ElButton type="primary" size="small" @click="showLevelDialog('add')" v-ripple>添加等级</ElButton>
    </div>
    <div class="membership-levels mb-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <div v-for="level in levelList" :key="level.id" class="level-card" :style="{ borderTopColor: level.iconColor }">
        <div class="flex items-center justify-between mb-3">
          <span class="text-lg font-bold" :style="{ color: level.iconColor }">{{ level.name }}</span>
          <ElTag :type="level.status === '1' ? 'success' : 'info'" size="small">{{ level.status === '1' ? '启用' : '禁用' }}</ElTag>
        </div>
        <!-- 定价方案 -->
        <div class="pricing-plans mb-2">
          <div v-for="plan in (level as any).pricingPlans" :key="plan.id || plan.durationDays" class="pricing-row-wrap">
            <span class="pricing-label">{{ planLabel(plan.durationDays) }}</span>
            <span v-if="Number(plan.price) > 0" class="pricing-price">¥{{ Number(plan.price).toFixed(0) }}</span>
            <span v-if="plan.originalPrice > plan.price" class="pricing-original">¥{{ Number(plan.originalPrice).toFixed(0) }}</span>
            <span v-if="Number(plan.pointsPrice) > 0" class="pricing-points">
              <span class="pricing-points-tag">积分</span>
              {{ Number(plan.pointsPrice).toFixed(0) }}
            </span>
          </div>
        </div>
        <div class="text-sm text-gray-500 mb-2">
          <p>余额折扣: <span class="text-orange-500 font-bold">{{ (level.discountRate * 10).toFixed(0) }} 折</span></p>
          <p>积分倍率: <span class="text-green-500 font-bold">x{{ level.pointsMultiplier }}</span></p>
        </div>
        <div class="benefits-text text-xs text-gray-400">{{ level.benefits }}</div>
        <div class="mt-3 flex gap-2">
          <ElButton size="small" type="primary" link @click="showLevelDialog('edit', level)">编辑</ElButton>
          <ElButton size="small" type="danger" link @click="deleteLevel(level)">删除</ElButton>
        </div>
      </div>
    </div>

    <MembershipLevelDialog v-model:visible="levelDialogVisible" :type="levelDialogType" :level-data="currentLevelData" @submit="handleLevelSubmit" />
  </div>
</template>

<script setup lang="ts">
  import { fetchGetMembershipLevelList, fetchSaveMembershipLevel, fetchDeleteMembershipLevel } from '@/api/operation'
  import MembershipLevelDialog from './modules/membership-level-dialog.vue'
  import { ElButton, ElMessageBox, ElMessage } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'Membership' })

  type MembershipLevelItem = Api.Operation.MembershipLevelItem

  const levelDialogType = ref<DialogType>('add')
  const levelDialogVisible = ref(false)
  const currentLevelData = ref<Partial<MembershipLevelItem>>({})
  const levelList = ref<MembershipLevelItem[]>([])

  const loadLevels = async () => {
    try {
      const data = await fetchGetMembershipLevelList({ current: 1, size: 100 })
      if (data && (data as any).records) levelList.value = (data as any).records
    } catch {
      levelList.value = []
    }
  }
  loadLevels()

  const showLevelDialog = (type: DialogType, row?: MembershipLevelItem) => { levelDialogType.value = type; currentLevelData.value = row || {}; nextTick(() => { levelDialogVisible.value = true }) }
  const handleLevelSubmit = async (formData?: Record<string, unknown>) => {
    if (formData) {
      await fetchSaveMembershipLevel(formData as any)
      await loadLevels()
    }
    levelDialogVisible.value = false
  }
  const deleteLevel = (row: MembershipLevelItem) => {
    ElMessageBox.confirm(`确定要删除等级「${row.name}」吗？`, '删除会员等级', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
      await fetchDeleteMembershipLevel(row.id)
      ElMessage.success('删除成功')
      await loadLevels()
    }).catch(() => {})
  }

  const planLabel = (days: number) => {
    if (days === 0) return '永久'
    if (days >= 365) return '年'
    if (days >= 180) return '半年'
    if (days >= 90) return '季'
    return days + '天'
  }
</script>

<style scoped>
  .level-card {
    border: 1px solid var(--el-border-color-light);
    border-top: 3px solid;
    border-radius: 8px;
    padding: 16px;
    background: var(--el-bg-color);
    transition: box-shadow 0.3s;
  }
  .level-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  }

  .pricing-plans {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .pricing-row-wrap {
    display: flex;
    align-items: baseline;
    gap: 3px;
    flex-wrap: wrap;
  }

  .pricing-row {
    display: flex;
    align-items: baseline;
    gap: 4px;
    background: #fefce8;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 12px;
  }

  .pricing-label {
    color: #6b7280;
    font-weight: 500;
  }

  .pricing-price {
    color: #ef4444;
    font-weight: 700;
  }

  .pricing-original {
    color: #9ca3af;
    text-decoration: line-through;
    font-size: 10px;
  }

  .pricing-points {
    color: #6366f1;
    font-weight: 700;
    margin-left: 4px;
  }

  .pricing-points-tag {
    font-size: 10px;
    background: #e0e7ff;
    color: #4338ca;
    padding: 1px 4px;
    border-radius: 3px;
    margin-right: 2px;
    font-weight: 600;
  }
</style>
