<template>
  <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增会员等级' : '编辑会员等级'" width="35%" align-center>
    <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
      <ElFormItem label="等级名称" prop="name">
        <ElInput v-model="formData.name" placeholder="请输入等级名称" />
      </ElFormItem>
      <ElFormItem label="等级序号" prop="level">
        <ElInputNumber v-model="formData.level" :min="0" :max="99" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="年费价格" prop="price">
        <ElInputNumber v-model="formData.price" :min="0" :step="10" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="积分兑换所需" prop="pointsRequired">
        <ElInputNumber v-model="formData.pointsRequired" :min="0" :step="100" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="折扣率" prop="discountRate">
        <ElInputNumber v-model="formData.discountRate" :min="0.1" :max="1" :step="0.1" :precision="1" style="width: 100%" />
        <template #label>余额折扣率</template>
      </ElFormItem>
      <ElFormItem label="积分折扣率" prop="pointsDiscountRate">
        <ElInputNumber v-model="formData.pointsDiscountRate" :min="0.1" :max="1" :step="0.1" :precision="1" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="积分倍率" prop="pointsMultiplier">
        <ElInputNumber v-model="formData.pointsMultiplier" :min="1" :max="10" :step="0.5" :precision="1" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="权益描述" prop="benefits">
        <ElInput v-model="formData.benefits" placeholder="请输 入权益描述，用逗号分隔" />
      </ElFormItem>
      <ElFormItem label="状态" prop="status">
        <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">保存</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import type { FormInstance, FormRules } from 'element-plus'

  interface Props { visible: boolean; type: string; levelData?: Partial<Api.Operation.MembershipLevelItem> }
  interface Emits { (e: 'update:visible', value: boolean): void; (e: 'submit', data: Record<string, unknown>): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const formRef = ref<FormInstance>()
  const dialogVisible = computed({ get: () => props.visible, set: (value) => emit('update:visible', value) })
  const dialogType = computed(() => props.type)

  const formData = reactive({ name: '', level: 0, price: 0, pointsRequired: 0, discountRate: 1, pointsMultiplier: 1, pointsDiscountRate: 1, benefits: '', status: '1' as string })

  const rules: FormRules = { name: [{ required: true, message: '请输入等级名称', trigger: 'blur' }] }

  const initFormData = () => {
    const isEdit = props.type === 'edit' && props.levelData
    const row = props.levelData
    const nextLevel = isEdit ? (row?.level ?? 0) : 0
    Object.assign(formData, {
      name: (isEdit && row ? row.name : '') || '',
      level: nextLevel,
      price: (isEdit && row ? row.price : 0) ?? 0,
      pointsRequired: (isEdit && row ? row.pointsRequired : 0) ?? 0,
      discountRate: (isEdit && row ? row.discountRate : 1) ?? 1,
      pointsMultiplier: (isEdit && row ? row.pointsMultiplier : 1) ?? 1,
      pointsDiscountRate: (isEdit && row ? row.pointsDiscountRate : 1) ?? 1,
      benefits: (isEdit && row ? row.benefits : '') || '',
      status: (isEdit && row ? row.status : '1') || '1'
    })
  }

  watch(() => [props.visible, props.type, props.levelData], ([visible]) => { if (visible) { initFormData(); nextTick(() => formRef.value?.clearValidate()) } }, { immediate: true })

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate((valid) => {
      if (valid) {
        const data: Record<string, unknown> = {
          name: formData.name,
          level: formData.level,
          price: formData.price,
          pointsRequired: formData.pointsRequired,
          discountRate: formData.discountRate,
          pointsMultiplier: formData.pointsMultiplier,
          pointsDiscountRate: formData.pointsDiscountRate,
          benefits: formData.benefits,
          icon: '',
          iconColor: '#909399',
          status: formData.status
        }
        if (dialogType.value === 'edit' && props.levelData?.id) {
          data.id = props.levelData.id
        }
        ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
        dialogVisible.value = false
        emit('submit', data)
      }
    })
  }
</script>
