<template>
  <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增会员等级' : '编辑会员等级'" :width="dialogWidth" align-center :close-on-click-modal="false">
    <ElForm ref="formRef" :model="formData" :rules="rules" :label-width="formLabelWidth" label-position="top" class="membership-form">
      <div class="form-grid">
        <ElFormItem label="等级名称" prop="name">
          <ElInput v-model="formData.name" placeholder="请输入等级名称" />
        </ElFormItem>
        <ElFormItem label="等级序号" prop="level">
          <ElInputNumber v-model="formData.level" :min="0" :max="99" style="width: 100%" />
        </ElFormItem>
      </div>
      <ElFormItem label="会员层级" prop="tier">
        <ElRadioGroup v-model="formData.tier">
          <ElRadio :value="1">一级会员</ElRadio>
          <ElRadio :value="2">二级会员</ElRadio>
        </ElRadioGroup>
      </ElFormItem>
      <ElFormItem label="上级等级" prop="parentLevelId" v-if="formData.tier === 2">
        <ElSelect v-model="formData.parentLevelId" placeholder="选择对应的上级等级" style="width:100%">
          <ElOption v-for="l in parentLevels" :key="l.id" :label="l.name" :value="l.id" />
        </ElSelect>
      </ElFormItem>

      <ElDivider content-position="left" style="margin: 8px 0">
        <span style="font-size: 14px; font-weight: 600; color: #374151">定价方案</span>
      </ElDivider>

      <div class="pricing-list">
        <div v-for="(plan, idx) in formData.pricingPlans" :key="idx" class="pricing-row">
          <div class="pricing-row-header">
            <ElInput v-model="plan.label" placeholder="方案名称" class="plan-name-input" size="small" />
            <ElInputNumber v-model="plan.durationDays" :min="0" :step="1" size="small" placeholder="天数" class="plan-days-input" :controls="false" />
            <ElButton type="danger" size="small" circle :icon="Delete" @click="removePlan(idx)" v-if="formData.pricingPlans.length > 1" />
          </div>
          <div class="pricing-inputs">
            <ElInputNumber v-model="plan.price" :min="0" :step="1" :precision="0" style="flex:1; min-width:0" placeholder="余额¥" :controls="false" size="small" />
            <ElInputNumber v-model="plan.originalPrice" :min="0" :step="1" :precision="0" style="flex:1; min-width:0" placeholder="原价" :controls="false" size="small" />
          </div>
          <div class="pricing-labels">
            <span class="pricing-hint">余额</span>
            <span class="pricing-hint">原价</span>
          </div>
          <div class="pricing-inputs" style="margin-top:6px">
            <ElInputNumber v-model="plan.pointsPrice" :min="0" :step="1" :precision="0" style="flex:1; min-width:0" placeholder="积分" :controls="false" size="small" />
            <ElInputNumber v-model="plan.pointsOriginalPrice" :min="0" :step="1" :precision="0" style="flex:1; min-width:0" placeholder="积分原价" :controls="false" size="small" />
          </div>
          <div class="pricing-labels">
            <span class="pricing-hint">积分</span>
            <span class="pricing-hint">积分原价</span>
          </div>
        </div>
        <ElButton type="primary" plain size="small" class="add-plan-btn" @click="addPlan">
          <ElIcon><Plus /></ElIcon>
          添加方案
        </ElButton>
      </div>

      <ElDivider content-position="left" style="margin: 8px 0">
        <span style="font-size: 14px; font-weight: 600; color: #374151">等级属性</span>
      </ElDivider>

      <div class="form-grid">
        <ElFormItem label="文字颜色">
          <ElColorPicker v-model="formData.textColor" />
        </ElFormItem>
        <ElFormItem label="背景颜色">
          <ElColorPicker v-model="formData.bgColor" />
        </ElFormItem>
      </div>
      <div class="form-grid">
        <ElFormItem label="余额折扣率" prop="discountRate">
          <ElInputNumber v-model="formData.discountRate" :min="0.1" :max="1" :step="0.1" :precision="1" style="width: 100%" :controls="false" />
        </ElFormItem>
        <ElFormItem label="积分折扣率" prop="pointsDiscountRate">
          <ElInputNumber v-model="formData.pointsDiscountRate" :min="0.1" :max="1" :step="0.1" :precision="1" style="width: 100%" :controls="false" />
        </ElFormItem>
        <ElFormItem label="积分倍率" prop="pointsMultiplier">
          <ElInputNumber v-model="formData.pointsMultiplier" :min="1" :max="10" :step="0.5" :precision="1" style="width: 100%" :controls="false" />
        </ElFormItem>
      </div>
      <ElFormItem label="权益描述" prop="benefits">
        <ElInput v-model="formData.benefits" placeholder="用逗号分隔" />
      </ElFormItem>
      <ElFormItem label="状态" prop="status">
        <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">保存</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import type { FormInstance, FormRules } from 'element-plus'
  import { Delete, Plus } from '@element-plus/icons-vue'

  interface Props { visible: boolean; type: string; levelData?: Partial<Api.Operation.MembershipLevelItem> & { pricingPlans?: PricingPlanItem[] } }
  interface Emits { (e: 'update:visible', value: boolean): void; (e: 'submit', data: Record<string, unknown>): void }

  interface PricingPlanItem {
    label: string
    durationDays: number
    price: number
    originalPrice: number
    pointsPrice: number
    pointsOriginalPrice: number
  }

  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const formRef = ref<FormInstance>()
  const dialogVisible = computed({ get: () => props.visible, set: (value) => emit('update:visible', value) })
  const dialogType = computed(() => props.type)

  const isMobile = ref(false)
  const dialogWidth = computed(() => isMobile.value ? '96%' : '740px')
  const formLabelWidth = computed(() => isMobile.value ? '80px' : '110px')

  const defaultPlan = (): PricingPlanItem => ({
    label: '', durationDays: 30, price: 0, originalPrice: 0, pointsPrice: 0, pointsOriginalPrice: 0
  })

  const formData = reactive({
    name: '', level: 0, tier: 1, parentLevelId: 0, price: 0,
    discountRate: 1, pointsMultiplier: 1, pointsDiscountRate: 1,
    textColor: '#FFFFFF', bgColor: '#508DFF',
    benefits: '', status: '1' as string,
    pricingPlans: [defaultPlan()]
  })
  const parentLevels = ref<any[]>([])

  const rules: FormRules = { name: [{ required: true, message: '请输入等级名称', trigger: 'blur' }] }

  const initFormData = () => {
    const isEdit = props.type === 'edit' && props.levelData
    const row = props.levelData
    const nextLevel = isEdit ? (row?.level ?? 0) : 0

    let plans: PricingPlanItem[] = [defaultPlan()]
    if (isEdit && row && (row as any).pricingPlans && (row as any).pricingPlans.length > 0) {
      plans = (row as any).pricingPlans.map((p: any) => ({
        label: p.name || p.label || '',
        durationDays: Number(p.durationDays) || 30,
        price: Number(p.price) || 0,
        originalPrice: Number(p.originalPrice || p.original_price) || 0,
        pointsPrice: Number(p.pointsPrice || p.points_price) || 0,
        pointsOriginalPrice: Number(p.pointsOriginalPrice || p.points_original_price) || 0
      }))
      if (!plans.length) plans = [defaultPlan()]
    }

    Object.assign(formData, {
      name: (isEdit && row ? row.name : '') || '',
      level: nextLevel,
      tier: (isEdit && row ? (row as any).tier : 1) || 1,
      parentLevelId: (isEdit && row ? (row as any).parentLevelId : 0) || 0,
      price: (isEdit && row ? row.price : 0) ?? 0,
      discountRate: (isEdit && row ? row.discountRate : 1) ?? 1,
      pointsMultiplier: (isEdit && row ? row.pointsMultiplier : 1) ?? 1,
      pointsDiscountRate: (isEdit && row ? row.pointsDiscountRate : 1) ?? 1,
      textColor: (isEdit && row ? (row as any).textColor : '#FFFFFF') || '#FFFFFF',
      bgColor: (isEdit && row ? (row as any).bgColor : '#508DFF') || '#508DFF',
      benefits: (isEdit && row ? row.benefits : '') || '',
      status: (isEdit && row ? row.status : '1') || '1',
      pricingPlans: plans
    })
  }

  onMounted(() => {
    isMobile.value = window.innerWidth < 768
    window.addEventListener('resize', () => { isMobile.value = window.innerWidth < 768 })
  })

  watch(() => [props.visible, props.type, props.levelData], ([visible]) => { if (visible) { initFormData(); loadParentLevels(); nextTick(() => formRef.value?.clearValidate()) } }, { immediate: true })

  async function loadParentLevels() {
    try {
      const { fetchGetMembershipLevelList } = await import('@/api/operation')
      const r: any = await fetchGetMembershipLevelList()
      parentLevels.value = (r.data?.list || r.data || r.data?.records || []).filter((l: any) => (l.tier || 1) === 1)
    } catch {}
  }

  function addPlan() {
    formData.pricingPlans.push(defaultPlan())
  }

  function removePlan(idx: number) {
    if (formData.pricingPlans.length <= 1) return
    formData.pricingPlans.splice(idx, 1)
  }

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate((valid) => {
      if (valid) {
        const activePlans = formData.pricingPlans.filter(p => p.price > 0 || p.pointsPrice > 0)
        const data: Record<string, unknown> = {
          name: formData.name,
          level: formData.level,
          tier: formData.tier,
          parentLevelId: formData.parentLevelId,
          price: formData.price,
          discountRate: formData.discountRate,
          pointsMultiplier: formData.pointsMultiplier,
          pointsDiscountRate: formData.pointsDiscountRate,
          textColor: formData.textColor,
          bgColor: formData.bgColor,
          benefits: formData.benefits,
          icon: '',
          iconColor: '#909399',
          status: formData.status,
          pricingPlans: activePlans.map(p => ({
            durationDays: p.durationDays,
            name: p.label || formData.name,
            price: p.price,
            originalPrice: p.originalPrice,
            pointsPrice: p.pointsPrice,
            pointsOriginalPrice: p.pointsOriginalPrice
          }))
        }
        if (dialogType.value === 'edit' && props.levelData?.id) {
          data.id = props.levelData.id
        }
        ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
        dialogVisible.value = false
        emit('submit', data)
      }
    })
  }
</script>

<style scoped>
  .form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0 16px;
  }
  @media (max-width: 767px) {
    .form-grid {
      grid-template-columns: 1fr;
    }
  }

  .pricing-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .pricing-row {
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 10px;
  }

  .pricing-row-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .plan-name-input {
    flex: 2;
    min-width: 0;
  }
  .plan-days-input {
    flex: 1;
    min-width: 0;
  }

  .add-plan-btn {
    width: 100%;
    border-style: dashed;
  }

  .pricing-inputs {
    display: flex;
    gap: 6px;
  }

  .pricing-labels {
    display: flex;
    gap: 6px;
    margin-top: 3px;
  }

  .pricing-hint {
    flex: 1;
    font-size: 10px;
    color: #b0b7c3;
    text-align: center;
    min-width: 0;
  }
</style>
