<template>
  <ArtSearchBar ref="searchBarRef" v-model="formData" :items="formItems" :rules="rules" @reset="handleReset" @search="handleSearch" />
</template>

<script setup lang="ts">
  interface Props { modelValue: any }
  interface Emits { (e: 'update:modelValue', value: any): void; (e: 'search', params: any): void; (e: 'reset'): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const searchBarRef = ref()
  const formData = computed({ get: () => props.modelValue, set: (val) => emit('update:modelValue', val) })
  const rules = {}
  const formItems = computed(() => [
    { label: '用户名', key: 'userName', type: 'input', placeholder: '请输入用户名', clearable: true },
    { label: '会员等级', key: 'level', type: 'select', props: { placeholder: '请选择等级', options: [{ label: '普通会员', value: 0 }, { label: '黄金会员', value: 1 }, { label: '钻石会员', value: 2 }, { label: '至尊会员', value: 3 }], clearable: true } }
  ])
  const handleReset = () => emit('reset')
  const handleSearch = async (params: any) => { await searchBarRef.value.validate(); emit('search', params) }
</script>
