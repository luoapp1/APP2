<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header><div class="card-header"><span>会员购买记录</span></div></template>
      <ElTable :data="records" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="userName" label="用户" width="120" />
        <ElTableColumn prop="level_name" label="等级" width="120" />
        <ElTableColumn label="类型" width="90">
          <template #default="{ row }">
            <ElTag size="small" :type="row.purchase_type === 'renew' ? 'success' : row.purchase_type === 'upgrade' ? 'warning' : ''">{{ {buy:'购买',renew:'续费',upgrade:'升级'}[row.purchase_type] || row.purchase_type }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="amount" label="金额" width="100" />
        <ElTableColumn prop="duration_days" label="天数" width="80" />
        <ElTableColumn label="过期时间" width="170">
          <template #default="{ row }">{{ row.expire_time?.slice(0,16) || '-' }}</template>
        </ElTableColumn>
        <ElTableColumn label="购买时间" minWidth="170">
          <template #default="{ row }">{{ row.create_time?.slice(0,16) }}</template>
        </ElTableColumn>
      </ElTable>
      <ElPagination v-if="total>size" :total="total" :page-size="size" :current-page="page" @current-change="p=>{page=p;loadData()}" layout="total,prev,pager,next" style="margin-top:16px;justify-content:flex-end" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const records = ref<any[]>([])
const loading = ref(false)
const page = ref(1)
const size = ref(20)
const total = ref(0)

async function loadData() {
  loading.value = true
  try {
    const r: any = await request.get({ url: '/api/admin/membership/purchases', params: { page: page.value, size: size.value } })
    records.value = r.records || r || []
    total.value = r.total || 0
  } catch {} finally { loading.value = false }
}

onMounted(loadData)
</script>
