<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header><div class="card-header"><span>会员购买记录</span></div></template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import request from '@/utils/http'
import { useTable } from '@/hooks/core/useTable'

const columns = [
  { prop: 'id', label: 'ID', width: 60 },
  { prop: 'userName', label: '用户', width: 120 },
  { prop: 'level_name', label: '等级', width: 120 },
  {
    prop: 'purchase_type', label: '类型', width: 90,
    formatter: (row: any) => {
      const map: Record<string, { type: string; text: string }> = {
        buy: { type: '', text: '购买' },
        renew: { type: 'success', text: '续费' },
        upgrade: { type: 'warning', text: '升级' }
      }
      const cfg = map[row.purchase_type] || { type: '', text: row.purchase_type }
      return h(ElTag, { size: 'small', type: cfg.type as any }, () => cfg.text)
    }
  },
  { prop: 'amount', label: '金额', width: 100 },
  { prop: 'duration_days', label: '天数', width: 80 },
  { prop: 'expire_time', label: '过期时间', width: 170 },
  { prop: 'create_time', label: '购买时间', minWidth: 170 }
]

const { data, loading, pagination, handleSizeChange, handleCurrentChange } = useTable({
  core: {
    apiFn: (params: any) => request.get({ url: '/api/admin/membership/purchases', params: { page: params.current, size: params.size } }),
    apiParams: { current: 1, size: 20 }
  }
})
</script>
