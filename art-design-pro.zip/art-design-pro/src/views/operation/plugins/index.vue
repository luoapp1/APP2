<!-- 插件管理页面 -->
<template>
  <div class="plugins-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElButton type="primary" @click="showDialog('add')" v-ripple>添加插件</ElButton>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增插件' : '编辑插件'" width="35%" align-center>
        <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
          <ElFormItem label="插件名称" prop="name">
            <ElInput v-model="formData.name" placeholder="请输入插件名称" />
          </ElFormItem>
          <ElFormItem label="插件描述" prop="description">
            <ElInput v-model="formData.description" type="textarea" :rows="3" placeholder="请输入插件描述" />
          </ElFormItem>
          <ElFormItem label="版本号" prop="version">
            <ElInput v-model="formData.version" placeholder="如 1.0.0" />
          </ElFormItem>
          <ElFormItem label="作者" prop="author">
            <ElInput v-model="formData.author" placeholder="请输入作者" />
          </ElFormItem>
          <ElFormItem label="组件名" prop="componentName">
            <ElInput v-model="formData.componentName" placeholder="请输入组件名" />
          </ElFormItem>
          <ElFormItem label="入口地址" prop="entryUrl">
            <ElInput v-model="formData.entryUrl" placeholder="请输入入口地址" />
          </ElFormItem>
          <ElFormItem label="状态" prop="status">
            <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
          </ElFormItem>
        </ElForm>
        <template #footer>
          <div class="dialog-footer">
            <ElButton @click="dialogVisible = false">取消</ElButton>
            <ElButton type="primary" @click="handleSubmit">保存</ElButton>
          </div>
        </template>
      </ElDialog>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTable } from '@/hooks/core/useTable'
  import { fetchPluginList, fetchPluginSave, fetchPluginDelete } from '@/api/operation'
  import { PLUGIN_DATA } from '@/mock/temp/operation'
  import { ElTag, ElButton, ElMessageBox, ElMessage, ElInput, ElSwitch, ElDialog, ElForm, ElFormItem } from 'element-plus'
  import type { FormInstance, FormRules } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'Plugins' })

  type PluginRecord = {
    id: number
    name: string
    description: string
    version: string
    author: string
    componentName: string
    entryUrl: string
    status: string
    createTime: string
  }

  const dialogVisible = ref(false)
  const dialogType = ref<DialogType>('add')
  const currentRow = ref<Partial<PluginRecord>>({})
  const formRef = ref<FormInstance>()

  const formData = reactive({
    name: '',
    description: '',
    version: '',
    author: '',
    componentName: '',
    entryUrl: '',
    status: '1' as string
  })

  const rules: FormRules = {
    name: [{ required: true, message: '请输入插件名称', trigger: 'blur' }],
    componentName: [{ required: true, message: '请输入组件名', trigger: 'blur' }]
  }

  const PLUGIN_STATUS_CONFIG: Record<string, { type: 'success' | 'info'; text: string }> = {
    '1': { type: 'success', text: '启用' },
    '0': { type: 'info', text: '禁用' }
  }
  const getStatusConfig = (status: string) => PLUGIN_STATUS_CONFIG[status] || { type: 'info' as const, text: '未知' }

  const { columns, columnChecks, data, loading, pagination, getData, handleSizeChange, handleCurrentChange, refreshData } = useTable({
    core: {
      apiFn: fetchPluginList,
      apiParams: { current: 1, size: 20 },
      columnsFactory: () => [
        { type: 'index', width: 60, label: '序号' },
        { prop: 'name', label: '名称', width: 140 },
        { prop: 'description', label: '描述', minWidth: 200 },
        { prop: 'version', label: '版本', width: 100 },
        { prop: 'author', label: '作者', width: 120 },
        { prop: 'componentName', label: '组件名', width: 140 },
        { prop: 'status', label: '状态', width: 80, formatter: (row: PluginRecord) => { const c = getStatusConfig(row.status); return h(ElTag, { type: c.type, size: 'small' }, () => c.text) } },
        { prop: 'operation', label: '操作', width: 140, fixed: 'right', formatter: (row: PluginRecord) => h('div', { style: { display: 'flex', gap: '8px' } }, [h(ArtButtonTable, { type: 'edit', onClick: () => showDialog('edit', row) }), h(ArtButtonTable, { type: 'delete', onClick: () => deletePlugin(row) })]) }
      ]
    },
    transform: {
      dataTransformer: (records) => {
        if (!Array.isArray(records)) return []
        if (records.length === 0) return PLUGIN_DATA
        return records
      }
    }
  })

  getData()

  const showDialog = (type: DialogType, row?: PluginRecord) => {
    dialogType.value = type
    if (type === 'edit' && row) {
      currentRow.value = row
      Object.assign(formData, {
        name: row.name || '',
        description: row.description || '',
        version: row.version || '',
        author: row.author || '',
        componentName: row.componentName || '',
        entryUrl: row.entryUrl || '',
        status: row.status || '1'
      })
    } else {
      currentRow.value = {}
      Object.assign(formData, { name: '', description: '', version: '', author: '', componentName: '', entryUrl: '', status: '1' })
    }
    nextTick(() => { dialogVisible.value = true; formRef.value?.clearValidate() })
  }

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate(async (valid) => {
      if (valid) {
        const data: Record<string, unknown> = {
          name: formData.name,
          description: formData.description,
          version: formData.version,
          author: formData.author,
          componentName: formData.componentName,
          entryUrl: formData.entryUrl,
          status: formData.status
        }
        if (dialogType.value === 'edit' && currentRow.value.id) {
          data.id = currentRow.value.id
        }
        await fetchPluginSave(data)
        ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
        dialogVisible.value = false
        refreshData()
      }
    })
  }

  const deletePlugin = (row: PluginRecord) => {
    ElMessageBox.confirm(`确定要删除插件「${row.name}」吗？`, '删除插件', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
      await fetchPluginDelete(row.id)
      ElMessage.success('删除成功')
      refreshData()
    }).catch(() => {})
  }
</script>
