<template>
  <div class="plugins-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElSpace wrap>
            <ElButton type="primary" @click="openUploadDialog" v-ripple>
              <span class="i-ep-upload mr-1" />
              上传插件
            </ElButton>
          </ElSpace>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <ElDialog
        v-model="uploadVisible"
        title="上传插件安装包"
        width="520px"
        align-center
        destroy-on-close
        @closed="resetUpload"
      >
        <ElForm ref="uploadFormRef" :model="uploadForm" label-width="100px">
          <ElFormItem label="安装包" required>
            <ElUpload
              ref="uploadRef"
              :auto-upload="false"
              :limit="1"
              accept=".zip"
              :on-change="handleFileChange"
              :on-remove="handleFileRemove"
              drag
            >
              <div class="flex flex-col items-center py-6">
                <span class="i-ep-upload-filled text-4xl text-gray-400 mb-3" />
                <span class="text-sm text-gray-600">将 ZIP 安装包拖到此处，或点击选择</span>
                <span class="text-xs text-gray-400 mt-1">仅支持 .zip 格式，最大 50MB</span>
              </div>
            </ElUpload>
          </ElFormItem>
        </ElForm>
        <template #footer>
          <ElButton @click="uploadVisible = false">取消</ElButton>
          <ElButton type="primary" :loading="uploading" @click="handleUpload">
            {{ uploading ? '安装中...' : '开始安装' }}
          </ElButton>
        </template>
      </ElDialog>

      <ElDialog
        v-model="upgradeVisible"
        title="升级插件"
        width="520px"
        align-center
        destroy-on-close
        @closed="resetUpgrade"
      >
        <div class="mb-4 p-3 bg-blue-50 rounded">
          <div class="text-sm">插件名称: <strong>{{ upgradeTarget?.name }}</strong></div>
          <div class="text-sm mt-1">当前版本: <ElTag size="small" type="info">{{ upgradeTarget?.version }}</ElTag></div>
        </div>
        <ElForm :model="upgradeForm" label-width="100px">
          <ElFormItem label="新安装包" required>
            <ElUpload
              ref="upgradeUploadRef"
              :auto-upload="false"
              :limit="1"
              accept=".zip"
              :on-change="handleUpgradeFileChange"
              :on-remove="handleUpgradeFileRemove"
              drag
            >
              <div class="flex flex-col items-center py-6">
                <span class="i-ep-upload-filled text-4xl text-gray-400 mb-3" />
                <span class="text-sm text-gray-600">将新版本 ZIP 安装包拖到此处</span>
                <span class="text-xs text-gray-400 mt-1">覆盖旧版本，仅支持 .zip 格式</span>
              </div>
            </ElUpload>
          </ElFormItem>
        </ElForm>
        <template #footer>
          <ElButton @click="upgradeVisible = false">取消</ElButton>
          <ElButton type="warning" :loading="upgrading" @click="handleUpgrade">
            {{ upgrading ? '升级中...' : '确认升级' }}
          </ElButton>
        </template>
      </ElDialog>

      <ElDialog
        v-model="configVisible"
        title="插件配置"
        width="720px"
        align-center
        destroy-on-close
      >
        <div class="mb-3 p-2 px-3 bg-blue-50 rounded text-sm">
          正在编辑插件: <strong>{{ configTarget?.name }}</strong>
        </div>

        <div v-if="configFields.length === 0" class="text-sm text-gray-400 py-6 text-center">
          该插件没有可配置项，请在插件 package 中添加 config 到 plugin.json
        </div>

        <template v-for="field in configFields" :key="field.key">
          <!-- 可见性控制 -->
          <template v-if="isFieldVisible(field)">
            <!-- ===== 布尔类 ===== -->
            <template v-if="field.type === 'bool' && !field.uiType">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSwitch v-model="configData[field.key]" size="small" />
                <span v-if="field.tips" class="cfg-tips">{{ field.tips }}</span>
              </div>
            </template>

            <template v-else-if="field.uiType === 'radio-bool'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElRadioGroup v-model="configData[field.key]" size="small">
                  <ElRadio v-for="opt in field.options" :key="String(opt.value)" :value="opt.value">{{ opt.label }}</ElRadio>
                </ElRadioGroup>
              </div>
            </template>

            <template v-else-if="field.uiType === 'confirm-bool'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSwitch v-model="configData[field.key]" size="small" />
              </div>
              <div v-if="field.confirmText" class="cfg-row cfg-row-indent">
                <span class="cfg-tips">{{ field.confirmText }}</span>
              </div>
            </template>

            <!-- ===== 字符串类 ===== -->
            <template v-else-if="field.uiType === 'text' || (field.type === 'string' && !field.uiType)">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" :maxlength="field.maxlength" :placeholder="field.placeholder" />
                <ElButton v-if="field.default !== undefined && configData[field.key] !== field.default" size="small" link type="warning" @click="resetDefault(field)">恢复默认</ElButton>
              </div>
            </template>

            <template v-else-if="field.uiType === 'textarea'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" type="textarea" size="small" :rows="field.rows ?? 3" :maxlength="field.maxlength" class="cfg-input" :placeholder="field.placeholder" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'password'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" type="password" size="small" class="cfg-input" show-password :placeholder="field.placeholder" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'url'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || 'https://'" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'email'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" placeholder="example@mail.com" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'phone'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" placeholder="13800138000" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'textarea-array'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" type="textarea" size="small" :rows="3" class="cfg-input" :placeholder="field.placeholder || '每行一个'" @change="handleTextareaArray(field.key)" />
              </div>
            </template>

            <!-- ===== 数字类 ===== -->
            <template v-else-if="field.uiType === 'number'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInputNumber v-model="configData[field.key]" size="small" :min="field.min" :max="field.max" :precision="field.integer ? 0 : (field.precision ?? 0)" class="cfg-input" />
                <span v-if="field.unit" class="cfg-unit">{{ field.unit }}</span>
              </div>
            </template>

            <template v-else-if="field.uiType === 'slider'">
              <div class="cfg-row" style="flex-wrap:wrap">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSlider v-model="configData[field.key]" :min="field.min ?? 0" :max="field.max ?? 100" :step="field.step ?? 1" :marks="field.marks" style="flex:1;min-width:200px" />
                <span class="cfg-val">{{ configData[field.key] }}{{ field.unit || '' }}</span>
              </div>
            </template>

            <template v-else-if="field.uiType === 'amount'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInputNumber v-model="configData[field.key]" size="small" :min="field.min ?? 0" :precision="field.precision ?? 2" class="cfg-input" />
                <span v-if="field.currency" class="cfg-unit">{{ field.currency }}</span>
              </div>
            </template>

            <!-- ===== 枚举选择类 ===== -->
            <template v-else-if="field.uiType === 'select'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSelect v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || '请选择'">
                  <ElOption v-for="opt in field.options" :key="String(opt.value)" :label="opt.label" :value="opt.value" />
                </ElSelect>
              </div>
            </template>

            <template v-else-if="field.uiType === 'multi-select'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSelect v-model="configData[field.key]" size="small" multiple class="cfg-input" :placeholder="field.placeholder || '请选择'">
                  <ElOption v-for="opt in field.options" :key="String(opt.value)" :label="opt.label" :value="opt.value" />
                </ElSelect>
              </div>
            </template>

            <template v-else-if="field.uiType === 'radio-group'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElRadioGroup v-model="configData[field.key]" size="small">
                  <ElRadio v-for="opt in field.options" :key="String(opt.value)" :value="opt.value">{{ opt.label }}</ElRadio>
                </ElRadioGroup>
              </div>
            </template>

            <template v-else-if="field.uiType === 'tree-select'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElTreeSelect v-model="configData[field.key]" :data="field.treeData" size="small" class="cfg-input" :placeholder="field.placeholder || '请选择'" check-strictly />
              </div>
            </template>

            <!-- ===== 媒体文件类 ===== -->
            <template v-else-if="field.uiType === 'image'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || '图片 URL'" />
              </div>
              <div v-if="configData[field.key]" class="cfg-row cfg-row-indent">
                <img :src="configData[field.key]" class="cfg-img-preview" :style="field.crop === 'circle' ? 'border-radius:50%' : ''" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'images'">
              <div class="mb-2">
                <span class="text-sm font-medium text-gray-600">{{ field.label }}</span>
                <span v-if="field.maxCount" class="text-xs text-gray-400 ml-2">最多 {{ field.maxCount }} 张</span>
              </div>
              <div v-for="(url, idx) in (Array.isArray(configData[field.key]) ? configData[field.key] : [])" :key="idx" class="cfg-array-row">
                <ElInput v-model="configData[field.key][idx]" size="small" class="cfg-array-input" :placeholder="'图片 URL ' + (idx + 1)" />
                <ElButton size="small" type="danger" :icon="Delete" circle link @click="removeArrayItem(field.key, idx)" />
              </div>
              <ElButton v-if="!field.maxCount || (configData[field.key]?.length || 0) < field.maxCount" size="small" type="primary" link class="mt-1" @click="addArrayItem(field.key)">+ 添加图片</ElButton>
            </template>

            <template v-else-if="field.uiType === 'file'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || '文件路径或 URL'" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'color'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElColorPicker v-model="configData[field.key]" size="small" :show-alpha="field.showAlpha ?? false" :predefine="field.presets" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'gradient-color'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" placeholder="linear-gradient(to right, #FF6B35, #FF4500)" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'icon'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSelect v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || '选择图标'" filterable>
                  <ElOption v-for="opt in field.options" :key="String(opt.value)" :label="opt.label" :value="opt.value" />
                </ElSelect>
              </div>
            </template>

            <!-- ===== 富文本/时间类 ===== -->
            <template v-else-if="field.uiType === 'richtext'">
              <div class="mb-1">
                <span class="text-sm font-medium text-gray-600">{{ field.label }}</span>
              </div>
              <ElInput v-model="configData[field.key]" type="textarea" size="small" :rows="field.height ? Math.round(field.height / 20) : 6" class="cfg-input" placeholder="支持 HTML 格式" />
            </template>

            <template v-else-if="field.uiType === 'markdown'">
              <div class="mb-1">
                <span class="text-sm font-medium text-gray-600">{{ field.label }}</span>
              </div>
              <ElInput v-model="configData[field.key]" type="textarea" size="small" :rows="field.height ? Math.round(field.height / 20) : 8" class="cfg-input" placeholder="支持 Markdown 格式" />
            </template>

            <template v-else-if="field.uiType === 'date'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElDatePicker v-model="configData[field.key]" size="small" type="date" class="cfg-input" :placeholder="field.placeholder || '选择日期'" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'datetime'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElDatePicker v-model="configData[field.key]" size="small" type="datetime" class="cfg-input" :placeholder="field.placeholder || '选择日期时间'" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'date-range'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElDatePicker v-model="configData[field.key]" size="small" type="daterange" class="cfg-input" :start-placeholder="field.startPlaceholder || '开始'" :end-placeholder="field.endPlaceholder || '结束'" />
              </div>
            </template>

            <!-- ===== 业务关联类 ===== -->
            <template v-else-if="field.uiType === 'user-select' || field.uiType === 'role-select'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElInput v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || 'ID 或用户名'" />
              </div>
            </template>

            <template v-else-if="field.uiType === 'api-config'">
              <div>
                <span class="text-sm font-semibold text-gray-700">{{ field.label }}</span>
              </div>
              <template v-if="field.fields">
                <div v-for="(subField, subKey) in field.fields" :key="subKey" class="cfg-row cfg-row-indent">
                  <span class="cfg-label">{{ subField.label }}</span>
                  <ElInput v-model="configData[field.key][subKey]" size="small" class="cfg-input" :placeholder="subField.placeholder" :type="subField.uiType === 'password' ? 'password' : 'text'" show-password />
                </div>
              </template>
            </template>

            <template v-else-if="field.uiType === 'template-select'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElRadioGroup v-model="configData[field.key]" size="small">
                  <ElRadio v-for="opt in field.options" :key="String(opt.value)" :value="opt.value">
                    {{ opt.label }}
                    <img v-if="opt.preview" :src="opt.preview" class="cfg-template-preview" />
                  </ElRadio>
                </ElRadioGroup>
              </div>
            </template>

            <template v-else-if="field.uiType === 'cron'">
              <div class="cfg-row">
                <span class="cfg-label">{{ field.label }}</span>
                <ElSelect v-model="configData[field.key]" size="small" class="cfg-input" :placeholder="field.placeholder || '选择或输入 Cron'" filterable allow-create>
                  <ElOption v-for="opt in field.options" :key="String(opt.value)" :label="opt.label + ' (' + opt.value + ')'" :value="opt.value" />
                </ElSelect>
              </div>
            </template>

            <!-- ===== 嵌套对象 ===== -->
            <template v-else-if="field.type === 'object'">
              <!-- 折叠面板模式 -->
              <template v-if="field.collapsible">
                <ElCollapse v-model="collapsedGroups" class="cfg-collapse">
                  <ElCollapseItem :title="field.label" :name="field.key">
                    <template v-for="sf in field.children" :key="sf.key">
                      <RecursiveField :field="sf" :data="configData[field.key]" :field-key="sf.key" :parent-key="field.key" />
                    </template>
                  </ElCollapseItem>
                </ElCollapse>
              </template>
              <!-- 普通分组模式 -->
              <template v-else>
                <ElDivider content-position="left"><span class="text-sm font-semibold text-gray-700">{{ field.label }}</span></ElDivider>
                <template v-for="sf in field.children" :key="sf.key">
                  <RecursiveField :field="sf" :data="configData[field.key]" :field-key="sf.key" :parent-key="field.key" />
                </template>
              </template>
            </template>

            <!-- ===== 数组 ===== -->
            <template v-else-if="field.type === 'array' && !field.uiType">
              <ElDivider content-position="left">
                <span class="text-sm font-semibold text-gray-700">{{ field.label }}</span>
                <ElButton size="small" type="primary" link class="ml-3" @click="addArrayItem(field.key)">+ 添加</ElButton>
              </ElDivider>
              <div v-if="!configData[field.key] || configData[field.key].length === 0" class="text-xs text-gray-400 py-2">暂无数据</div>
              <div v-for="(item, idx) in configData[field.key]" :key="idx" class="cfg-array-row">
                <span class="cfg-array-idx">{{ idx + 1 }}</span>
                <template v-for="af in field.itemFields" :key="af.key">
                  <template v-if="af.type === 'bool' && !af.uiType">
                    <ElSwitch v-model="item[af.key]" size="small" />
                  </template>
                  <template v-else-if="af.uiType === 'select'">
                    <ElSelect v-model="item[af.key]" size="small" class="cfg-array-input">
                      <ElOption v-for="opt in af.options" :key="String(opt.value)" :label="opt.label" :value="opt.value" />
                    </ElSelect>
                  </template>
                  <template v-else-if="af.uiType === 'number'">
                    <ElInputNumber v-model="item[af.key]" size="small" :min="af.min" :max="af.max" class="cfg-array-input" />
                  </template>
                  <template v-else-if="af.uiType === 'color'">
                    <ElColorPicker v-model="item[af.key]" size="small" />
                  </template>
                  <template v-else>
                    <ElInput v-model="item[af.key]" :placeholder="af.label" size="small" class="cfg-array-input" />
                  </template>
                </template>
                <ElButton size="small" type="danger" :icon="Delete" circle link @click="removeArrayItem(field.key, idx)" />
              </div>
            </template>
          </template>
        </template>

        <template #footer>
          <ElButton @click="configVisible = false">取消</ElButton>
          <ElButton type="primary" :loading="savingConfig" @click="handleSaveConfig">
            {{ savingConfig ? '保存中...' : '保存配置' }}
          </ElButton>
        </template>
      </ElDialog>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { defineOptions, reactive, ref, computed, nextTick, h, defineComponent } from 'vue'
import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
import ArtTableHeader from '@/components/core/tables/art-table-header/index.vue'
import ArtTable from '@/components/core/tables/art-table/index.vue'
import { useTable } from '@/hooks/core/useTable'
import {
  fetchPluginUpload,
  fetchPluginToggle,
  fetchPluginDelete,
  fetchPluginUpgrade,
  fetchPluginList,
  fetchPluginUpdateConfig
} from '@/api/operation'
import {
  ElMessageBox,
  ElMessage,
  ElTag,
  ElButton,
  ElDialog,
  ElForm,
  ElFormItem,
  ElUpload,
  ElSpace,
  ElTooltip,
  ElInput,
  ElSwitch,
  ElDivider,
  ElSelect,
  ElOption,
  ElInputNumber,
  ElColorPicker,
  ElCollapse,
  ElCollapseItem,
  ElRadioGroup,
  ElRadio,
  ElDatePicker,
  ElTreeSelect,
  ElSlider
} from 'element-plus'
import { Delete } from '@element-plus/icons-vue'
import type { UploadInstance, UploadFile } from 'element-plus'

defineOptions({ name: 'Plugins' })

type PluginRecord = {
  id: number
  name: string
  description: string
  version: string
  author: string
  componentName: string
  entryUrl: string
  pluginDir: string
  status: string
  installed: boolean
  createTime: string
}

const PLUGIN_STATUS: Record<string, { type: 'success' | 'info' | 'danger'; text: string }> = {
  '1': { type: 'success', text: '已启用' },
  '0': { type: 'info', text: '已禁用' }
}

const getStatusCfg = (status: string) => PLUGIN_STATUS[status] || { type: 'info' as const, text: '未知' }

const { columns, columnChecks, data, loading, pagination, getData, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: fetchPluginList,
    apiParams: { current: 1, size: 20 },
    columnsFactory: () => [
      { type: 'index', width: 60, label: '序号' },
      { prop: 'name', label: '插件名称', width: 160 },
      { prop: 'version', label: '版本', width: 90 },
      { prop: 'author', label: '作者', width: 120 },
      { prop: 'description', label: '描述', minWidth: 200 },
      { prop: 'status', label: '状态', width: 100, formatter: (row: PluginRecord) => {
        const c = getStatusCfg(row.status)
        const installed = row.installed === false ? ' (未部署)' : ''
        return h(ElTag, { type: c.type, size: 'small' }, () => c.text + installed)
      }},
      { prop: 'createTime', label: '安装时间', width: 170 },
      { prop: 'operation', label: '操作', width: 260, fixed: 'right', formatter: (row: PluginRecord) =>
        h('div', { style: { display: 'flex', gap: '4px', flexWrap: 'wrap' } }, [
          h(
            ElButton,
            {
              type: row.status === '1' ? 'warning' : 'success',
              size: 'small',
              link: true,
              onClick: () => togglePlugin(row)
            },
            () => row.status === '1' ? '禁用' : '启用'
          ),
          h(
            ElButton,
            { type: 'primary', size: 'small', link: true, onClick: () => openUpgradeDialog(row) },
            () => '升级'
          ),
          h(
            ElButton,
            { type: 'danger', size: 'small', link: true, onClick: () => deletePlugin(row) },
            () => '删除'
          ),
          h(
            ElButton,
            { type: 'primary', size: 'small', link: true, onClick: () => openConfigDialog(row) },
            () => '配置'
          )
        ])
      }
    ]
  },
  transform: {
    dataTransformer: (records) => {
      if (!Array.isArray(records)) return []
      return records
    }
  }
})

getData()

const uploadVisible = ref(false)
const uploading = ref(false)
const uploadRef = ref<UploadInstance>()
const uploadFormRef = ref()
const uploadForm = reactive({ file: null as File | null })

const upgradeVisible = ref(false)
const upgrading = ref(false)
const upgradeTarget = ref<PluginRecord | null>(null)
const upgradeUploadRef = ref<UploadInstance>()
const upgradeForm = reactive({ file: null as File | null })

const configVisible = ref(false)
const configTarget = ref<PluginRecord | null>(null)
const savingConfig = ref(false)
const configData = reactive<Record<string, any>>({})
const configMeta = ref<Record<string, any>>({})
const collapsedGroups = ref<string[]>([])

type UiType =
  | 'switch' | 'radio-bool' | 'confirm-bool'
  | 'text' | 'textarea' | 'password' | 'url' | 'email' | 'phone' | 'textarea-array'
  | 'number' | 'slider' | 'amount'
  | 'select' | 'multi-select' | 'radio-group' | 'tree-select'
  | 'image' | 'images' | 'file' | 'color' | 'gradient-color' | 'icon'
  | 'richtext' | 'markdown' | 'date' | 'datetime' | 'date-range'
  | 'user-select' | 'role-select' | 'api-config' | 'template-select' | 'cron'

interface FieldDescriptor {
  key: string; label: string; type: 'bool' | 'string' | 'object' | 'array'
  uiType?: UiType
  tips?: string; placeholder?: string; required?: boolean; disabled?: boolean
  default?: any
  rules?: any[]; visible?: VisibilityCondition
  options?: { label: string; value: any; preview?: string }[]
  treeData?: any[]
  min?: number; max?: number; precision?: number; integer?: boolean
  step?: number; marks?: Record<number, string>; unit?: string; currency?: string
  rows?: number; maxlength?: number
  accept?: string; maxSize?: number; maxCount?: number
  crop?: 'circle' | 'square' | null; width?: number; height?: number
  showAlpha?: boolean; presets?: string[]; iconSet?: string
  toolbar?: 'basic' | 'full'; height?: number; preview?: boolean
  apiUrl?: string; multiple?: boolean
  fields?: Record<string, FieldDescriptor>
  startPlaceholder?: string; endPlaceholder?: string
  confirmText?: string; collapsible?: boolean; collapsed?: boolean
  children?: FieldDescriptor[]
  itemFields?: FieldDescriptor[]
}

interface VisibilityCondition {
  dependsOn: string; condition: 'eq' | 'neq' | 'in' | 'gt' | 'gte' | 'lt' | 'lte'
  value: any
}

// RecursiveField 组件：用于递归渲染 object 子字段
const RecursiveField = defineComponent({
  name: 'RecursiveField',
  props: { field: Object, data: Object, fieldKey: String, parentKey: String },
  setup(props) {
    return () => {
      const field = props.field as FieldDescriptor
      const data = props.data as Record<string, any>
      const key = props.fieldKey as string
      if (!field) return null
      if (field.type === 'bool' && !field.uiType) {
        return h('div', { class: 'cfg-row cfg-row-indent' }, [
          h('span', { class: 'cfg-label' }, field.label),
          h(ElSwitch, { modelValue: data[key], 'onUpdate:modelValue': (v: any) => data[key] = v, size: 'small' })
        ])
      }
      return h('div', { class: 'cfg-row cfg-row-indent' }, [
        h('span', { class: 'cfg-label' }, field.label),
        h(ElInput, { modelValue: data[key], 'onUpdate:modelValue': (v: any) => data[key] = v, size: 'small', class: 'cfg-input' })
      ])
    }
  }
})

function keyToLabel(key: string) {
  return key.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim()
}

function getLabel(key: string, meta?: Record<string, any>, parentKey?: string) {
  if (meta?.label) return meta.label
  if (meta?.[key]?.label) return meta[key].label
  if (parentKey) return keyToLabel(key)
  return keyToLabel(key)
}

function inferFieldType(val: any, meta?: Record<string, any>): FieldDescriptor['type'] {
  if (meta?.uiType) {
    if (['select', 'multi-select', 'radio-group', 'tree-select', 'text', 'textarea', 'password', 'url', 'email', 'phone',
         'number', 'slider', 'amount', 'image', 'images', 'file', 'color', 'gradient-color', 'icon',
         'richtext', 'markdown', 'date', 'datetime', 'date-range',
         'user-select', 'role-select', 'api-config', 'template-select', 'cron', 'radio-bool', 'confirm-bool', 'textarea-array'].includes(meta.uiType)) {
      return 'string'
    }
  }
  if (typeof val === 'boolean') return 'bool'
  if (Array.isArray(val)) return 'array'
  if (val && typeof val === 'object') return 'object'
  return 'string'
}

function inferFieldDescriptor(key: string, val: any, meta?: Record<string, any>): FieldDescriptor {
  const type = inferFieldType(val, meta)
  return {
    key, label: getLabel(key, meta), type,
    uiType: meta?.uiType || undefined,
    tips: meta?.tips, placeholder: meta?.placeholder, required: meta?.required, disabled: meta?.disabled,
    default: meta?.default, rules: meta?.rules, visible: meta?.visible,
    options: meta?.options, treeData: meta?.treeData,
    min: meta?.min, max: meta?.max, precision: meta?.precision, integer: meta?.integer,
    step: meta?.step, marks: meta?.marks, unit: meta?.unit, currency: meta?.currency,
    rows: meta?.rows, maxlength: meta?.maxlength,
    accept: meta?.accept, maxSize: meta?.maxSize, maxCount: meta?.maxCount,
    crop: meta?.crop, width: meta?.width, height: meta?.height,
    showAlpha: meta?.showAlpha, presets: meta?.presets, iconSet: meta?.iconSet,
    toolbar: meta?.toolbar, height: meta?.height, preview: meta?.preview,
    apiUrl: meta?.apiUrl, multiple: meta?.multiple,
    fields: meta?.fields,
    startPlaceholder: meta?.startPlaceholder, endPlaceholder: meta?.endPlaceholder,
    confirmText: meta?.confirmText, collapsible: meta?.collapsible, collapsed: meta?.collapsed
  }
}

function buildItemFields(sample: Record<string, any>, itemMeta?: Record<string, any>): FieldDescriptor[] {
  return Object.keys(sample).map(k => inferFieldDescriptor(k, sample[k], itemMeta?.[k]))
}

function isFieldVisible(field: FieldDescriptor): boolean {
  if (!field.visible) return true
  const { dependsOn, condition, value } = field.visible
  const currentVal = configData[dependsOn]
  switch (condition) {
    case 'eq': return currentVal === value
    case 'neq': return currentVal !== value
    case 'in': return Array.isArray(value) && value.includes(currentVal)
    case 'gt': return Number(currentVal) > Number(value)
    case 'gte': return Number(currentVal) >= Number(value)
    case 'lt': return Number(currentVal) < Number(value)
    case 'lte': return Number(currentVal) <= Number(value)
    default: return true
  }
}

function resetDefault(field: FieldDescriptor) {
  if (field.default !== undefined) {
    configData[field.key] = field.default
  }
}

function handleTextareaArray(key: string) {
  // textarea-array: 自动将换行文本拆分为数组
  // 在保存时由 handleSaveConfig 处理
}

const configFields = computed(() => {
  const fields: FieldDescriptor[] = []
  const data = configData
  const meta = configMeta.value
  for (const key of Object.keys(data)) {
    const val = data[key]
    const fieldMeta = meta?.[key]
    const type = inferFieldType(val, fieldMeta)
    const label = getLabel(key, meta)

    if (type === 'object') {
      const children: FieldDescriptor[] = []
      const childrenMeta = fieldMeta?.childrenMeta || {}
      const collapsible = fieldMeta?.collapsible === true
      const collapsed = fieldMeta?.collapsed === true
      if (val) {
        for (const ck of Object.keys(val)) {
          const cv = val[ck]
          children.push(inferFieldDescriptor(ck, cv, childrenMeta?.[ck]))
        }
      }
      fields.push({ key, label, type, children, collapsible, collapsed })
    } else if (type === 'array') {
      const itemMeta = fieldMeta?.itemMeta
      const itemFields = (val && val.length > 0 && typeof val[0] === 'object')
        ? buildItemFields(val[0], itemMeta)
        : []
      fields.push({ key, label, type, itemFields })
    } else {
      fields.push(inferFieldDescriptor(key, val, fieldMeta))
    }
  }
  return fields
})

function defaultArrayItem(fields: FieldDescriptor[]): Record<string, any> {
  const item: Record<string, any> = {}
  for (const f of fields) {
    if (f.type === 'bool') item[f.key] = f.default !== undefined ? f.default : true
    else if (f.type === 'string' || f.uiType) item[f.key] = f.default !== undefined ? f.default : ''
    else item[f.key] = null
  }
  return item
}

function addArrayItem(arrayKey: string) {
  if (!Array.isArray(configData[arrayKey])) configData[arrayKey] = []
  const field = configFields.value.find(f => f.key === arrayKey)
  const itemFields = field?.itemFields || []
  configData[arrayKey].push(defaultArrayItem(itemFields))
}

function removeArrayItem(arrayKey: string, idx: number) {
  configData[arrayKey].splice(idx, 1)
}

async function handleSaveConfig() {
  if (!configTarget.value) return
  try {
    savingConfig.value = true
    // 处理 textarea-array 类型：将换行文本转为数组
    const cfg = JSON.parse(JSON.stringify(configData))
    for (const field of configFields.value) {
      if (field.uiType === 'textarea-array' && typeof cfg[field.key] === 'string') {
        cfg[field.key] = cfg[field.key].split('\n').map((s: string) => s.trim()).filter(Boolean)
      }
    }
    const payload: Record<string, any> = { config: cfg }
    if (Object.keys(configMeta.value).length > 0) {
      payload.configMeta = configMeta.value
    }
    await fetchPluginUpdateConfig(configTarget.value.name, payload)
    ElMessage.success('配置已保存')
    await refreshData()
    configVisible.value = false
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '保存失败')
  } finally {
    savingConfig.value = false
  }
}

function openConfigDialog(row: PluginRecord) {
  configTarget.value = row
  try {
    const listData = data.value as any[]
    const item = listData.find((d: any) => d.id === row.id)
    if (item?.manifest) {
      const manifest = typeof item.manifest === 'string' ? JSON.parse(item.manifest) : item.manifest
      const cfg = manifest.config || {}
      configMeta.value = manifest.configMeta || {}
      Object.keys(configData).forEach(k => delete (configData as any)[k])
      Object.entries(cfg).forEach(([k, v]) => {
        (configData as any)[k] = Array.isArray(v) ? [...v as any[]] : (typeof v === 'object' && v !== null ? { ...v as any } : v)
      })
    } else {
      configMeta.value = {}
      Object.keys(configData).forEach(k => delete (configData as any)[k])
    }
  } catch {
    configMeta.value = {}
    Object.keys(configData).forEach(k => delete (configData as any)[k])
  }
  configVisible.value = true
}

function openUploadDialog() {
  uploadVisible.value = true
}

function resetUpload() {
  uploadForm.file = null
  uploadRef.value?.clearFiles()
}

function handleFileChange(file: UploadFile) {
  uploadForm.file = file.raw as File
}

function handleFileRemove() {
  uploadForm.file = null
}

async function handleUpload() {
  if (!uploadForm.file) {
    ElMessage.warning('请选择 ZIP 安装包')
    return
  }
  uploading.value = true
  try {
    const formData = new FormData()
    formData.append('file', uploadForm.file)
    await fetchPluginUpload(formData)
    ElMessage.success('插件安装成功')
    uploadVisible.value = false
    refreshData()
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '安装失败')
  } finally {
    uploading.value = false
  }
}

function openUpgradeDialog(row: PluginRecord) {
  upgradeTarget.value = row
  upgradeVisible.value = true
}

function resetUpgrade() {
  upgradeForm.file = null
  upgradeTarget.value = null
  upgradeUploadRef.value?.clearFiles()
}

function handleUpgradeFileChange(file: UploadFile) {
  upgradeForm.file = file.raw as File
}

function handleUpgradeFileRemove() {
  upgradeForm.file = null
}

async function handleUpgrade() {
  if (!upgradeForm.file || !upgradeTarget.value) {
    ElMessage.warning('请选择新版本 ZIP 安装包')
    return
  }
  upgrading.value = true
  try {
    const formData = new FormData()
    formData.append('file', upgradeForm.file)
    await fetchPluginUpgrade(upgradeTarget.value.id, formData)
    ElMessage.success('插件升级成功')
    upgradeVisible.value = false
    refreshData()
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '升级失败')
  } finally {
    upgrading.value = false
  }
}

async function togglePlugin(row: PluginRecord) {
  try {
    await fetchPluginToggle(row.id)
    ElMessage.success(row.status === '1' ? '已禁用' : '已启用')
    refreshData()
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '操作失败')
  }
}

function deletePlugin(row: PluginRecord) {
  ElMessageBox.confirm(
    `确定要删除插件「${row.name}」吗？此操作将移除插件目录及所有相关文件，不可恢复。`,
    '删除插件',
    { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' }
  ).then(async () => {
    try {
      await fetchPluginDelete(row.id)
      ElMessage.success('插件已删除')
      refreshData()
    } catch (e: any) {
      ElMessage.error(e?.msg || e?.message || '删除失败')
    }
  }).catch(() => {})
}
</script>

<style scoped>
.cfg-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 0;
}

.cfg-row-indent {
  padding-left: 12px;
}

.cfg-label {
  width: 90px;
  font-size: 13px;
  color: #374151;
  flex-shrink: 0;
}

.cfg-input {
  flex: 1;
}

.cfg-array-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 0;
}

.cfg-array-idx {
  width: 20px;
  text-align: center;
  font-size: 12px;
  color: #9CA3AF;
  flex-shrink: 0;
}

.cfg-array-input {
  flex: 1;
  min-width: 80px;
}
</style>
