<!-- 积分管理页面 -->
<template>
  <div class="points-page art-full-height">
    <PointsSearch v-model="searchForm" @search="handleSearch" @reset="resetSearchParams" />

    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElSpace wrap>
            <ElButton type="primary" @click="showDialog('add')" v-ripple>手动调整积分</ElButton>
          </ElSpace>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <PointsDialog
        v-model:visible="dialogVisible"
        @submit="handleDialogSubmit"
      />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTable } from '@/hooks/core/useTable'
  import { fetchGetPointsRecordList, fetchAdjustPoints } from '@/api/operation'
  import { POINTS_RECORD_DATA } from '@/mock/temp/operation'
  import PointsSearch from './modules/points-search.vue'
  import PointsDialog from './modules/points-dialog.vue'
  import { ElTag } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'Points' })

  type PointsRecordItem = Api.Operation.PointsRecordItem

  const dialogVisible = ref(false)

  const searchForm = ref({ userName: undefined as string | undefined, type: undefined as string | undefined })

  const POINTS_TYPE_CONFIG = { earn: { type: 'success' as const, text: '收入' }, redeem: { type: 'warning' as const, text: '支出' }, expire: { type: 'info' as const, text: '过期' }, adjust: { type: 'primary' as const, text: '调整' } } as const
  const getPointsTypeConfig = (type: string) => POINTS_TYPE_CONFIG[type as keyof typeof POINTS_TYPE_CONFIG] || { type: 'info' as const, text: '未知' }

  const { columns, columnChecks, data, loading, pagination, getData, replaceSearchParams, resetSearchParams, handleSizeChange, handleCurrentChange, refreshData } = useTable({
    core: {
      apiFn: fetchGetPointsRecordList,
      apiParams: { current: 1, size: 20, ...searchForm.value },
      columnsFactory: () => [
        { type: 'index', width: 60, label: '序号' },
        { prop: 'userName', label: '用户名', width: 140 },
        { prop: 'type', label: '类型', width: 100, formatter: (row: PointsRecordItem) => { const c = getPointsTypeConfig(row.type); return h(ElTag, { type: c.type }, () => c.text) } },
        { prop: 'points', label: '积分变动', width: 110, sortable: true, formatter: (row: PointsRecordItem) => row.points > 0 ? `+${row.points}` : `${row.points}` },
        { prop: 'balance', label: '积分余额', width: 110, sortable: true },
        { prop: 'source', label: '来源', width: 140 },
        { prop: 'description', label: '描述', minWidth: 200 },
        { prop: 'createTime', label: '时间', width: 180, sortable: true }
      ]
    },
    transform: {
      dataTransformer: (records) => { if (!Array.isArray(records)) return []; if (records.length === 0) return POINTS_RECORD_DATA; return records }
    }
  })

  const handleSearch = (params: any) => { replaceSearchParams(params); getData() }
  const showDialog = (type: DialogType) => { nextTick(() => { dialogVisible.value = true }) }
  const handleDialogSubmit = async (formData?: Record<string, unknown>) => {
    if (formData) await fetchAdjustPoints(formData as any)
    dialogVisible.value = false
    refreshData()
  }
</script>
