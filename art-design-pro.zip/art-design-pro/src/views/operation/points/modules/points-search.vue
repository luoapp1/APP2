<template>
  <ArtSearchBar ref="searchBarRef" v-model="formData" :items="formItems" :rules="rules" @reset="handleReset" @search="handleSearch" />
</template>

<script setup lang="ts">
  interface Props { modelValue: any }
  interface Emits { (e: 'update:modelValue', value: any): void; (e: 'search', params: any): void; (e: 'reset'): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const searchBarRef = ref()
  const formData = computed({ get: () => props.modelValue, set: (val) => emit('update:modelValue', val) })
  const rules = {}
  const formItems = computed(() => [
    { label: '用户名', key: 'userName', type: 'input', placeholder: '请输入用户名', clearable: true },
    { label: '类 型', key: 'type', type: 'select', props: { placeholder: '请选择类型', options: [{ label: '收入', value: 'earn' }, { label: '支出', value: 'redeem' }, { label: '过期', value: 'expire' }, { label: '调整', value: 'adjust' }], clearable: true } }
  ])
  const handleReset = () => emit('reset')
  const handleSearch = async (params: any) => { await searchBarRef.value.validate(); emit('search', params) }
</script>
