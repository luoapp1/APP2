<template>
  <ElDialog v-model="dialogVisible" title="手动调整积分" width="35%" align-center>
    <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
      <ElFormItem label="目标用户" prop="userId">
        <ElSelect v-model="formData.userId" filterable placeholder="请选择用户">
          <ElOption v-for="m in MEMBER_DATA" :key="m.userId" :label="`${m.userName} (${m.levelName})`" :value="m.userId" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem label="调整类型" prop="adjustType">
        <ElRadioGroup v-model="formData.adjustType">
          <ElRadio value="add">增加积分</ElRadio>
          <ElRadio value="sub">扣除积分</ElRadio>
        </ElRadioGroup>
      </ElFormItem>
      <ElFormItem label="积分数额" prop="points">
        <ElInputNumber v-model="formData.points" :min="1" :max="100000" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="调整原因" prop="description">
        <ElInput v-model="formData.description" type="textarea" :rows="3" placeholder="请输入调整原因" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">确认调整</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import { MEMBER_DATA } from '@/mock/temp/operation'
  import type { FormInstance, FormRules } from 'element-plus'

  interface Props { visible: boolean }
  interface Emits { (e: 'update:visible', value: boolean): void; (e: 'submit', data: Record<string, unknown>): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const formRef = ref<FormInstance>()
  const dialogVisible = computed({ get: () => props.visible, set: (value) => emit('update:visible', value) })

  const formData = reactive({ userId: 1, adjustType: 'add', points: 100, description: '' })
  const rules: FormRules = {
    userId: [{ required: true, message: '请选择目标用户', trigger: 'change' }],
    points: [{ required: true, message: '请输入积分数量', trigger: 'blur' }],
    description: [{ required: true, message: '请输入调整原因', trigger: 'blur' }]
  }

  watch(() => props.visible, (val) => { if (val) { formData.userId = 1; formData.adjustType = 'add'; formData.points = 100; formData.description = ''; nextTick(() => formRef.value?.clearValidate()) } })

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate((valid) => {
      if (valid) {
        const pts = formData.adjustType === 'sub' ? -formData.points : formData.points
        ElMessage.success('积分调整成功')
        dialogVisible.value = false
        emit('submit', { userId: formData.userId, points: pts, description: formData.description })
      }
    })
  }
</script>
