<template>
  <div class="recharge-amounts-page art-full-height">
    <ElRow :gutter="20">
      <ElCol :span="24">
        <ElCard class="art-table-card" header="充值金额管理">
          <template #header>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span>充值金额列表</span>
              <ElButton type="primary" size="small" @click="addAmount">添加金额</ElButton>
            </div>
          </template>
          <ElTable :data="amounts" border stripe style="width:100%">
            <ElTableColumn prop="amount" label="金额 (元)" width="150">
              <template #default="{ row }">
                <span style="font-size:18px;font-weight:600;color:#3b82f6">￥{{ row.amount }}</span>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="label" label="标签" width="180">
              <template #default="{ row }">
                <ElTag v-if="row.label" type="warning" size="small">{{ row.label }}</ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="discount" label="优惠说明" min-width="200">
              <template #default="{ row }">
                <span style="color:#16a34a" v-if="row.discount">{{ row.discount }}</span>
                <span style="color:#909399" v-else>-</span>
              </template>
            </ElTableColumn>
            <ElTableColumn prop="status" label="状态" width="100">
              <template #default="{ row }">
                <ElTag :type="row.status === 1 ? 'success' : 'info'" size="small">
                  {{ row.status === 1 ? '启用' : '禁用' }}
                </ElTag>
              </template>
            </ElTableColumn>
            <ElTableColumn label="操作" width="160" fixed="right">
              <template #default="{ row, $index }">
                <ElButton type="primary" link size="small" @click="editAmount(row, $index)">编辑</ElButton>
                <ElButton type="danger" link size="small" @click="removeAmount($index)">删除</ElButton>
              </template>
            </ElTableColumn>
          </ElTable>
          <div style="margin-top:16px">
            <ElButton type="primary" :loading="saving" @click="saveAmounts">保存</ElButton>
            <span style="margin-left:12px;color:#909399;font-size:12px">修改金额后点击保存生效，前端将实时加载最新配置</span>
          </div>
        </ElCard>
      </ElCol>
    </ElRow>

    <ElDialog v-model="dialogVisible" :title="editingIndex >= 0 ? '编辑金额' : '添加金额'" width="420px" :close-on-click-modal="false">
      <ElForm label-width="100px">
        <ElFormItem label="金额 (元)">
          <ElInputNumber v-model="editForm.amount" :min="0.01" :precision="2" style="width:200px" />
        </ElFormItem>
        <ElFormItem label="标签">
          <ElInput v-model="editForm.label" placeholder="如: 功能体验专用" />
        </ElFormItem>
        <ElFormItem label="优惠说明">
          <ElInput v-model="editForm.discount" placeholder="如: 省0.01元" />
        </ElFormItem>
        <ElFormItem label="状态">
          <ElSwitch v-model="editForm.status" active-text="启用" inactive-text="禁用" :active-value="1" :inactive-value="0" />
        </ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="confirmEdit">确定</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

defineOptions({ name: 'RechargeAmounts' })

const amounts = ref<any[]>([])
const saving = ref(false)
const dialogVisible = ref(false)
const editingIndex = ref(-1)
const editForm = reactive({ amount: 0, label: '', discount: '', status: 1 })

const fetchAmounts = async () => {
  try {
    const data: any = await request.get({ url: '/api/recharge/amounts' })
    amounts.value = (data || []).map((a: any) => ({ ...a, status: Number(a.status) }))
  } catch {}
}

const addAmount = () => {
  editingIndex.value = -1
  editForm.amount = 0
  editForm.label = ''
  editForm.discount = ''
  editForm.status = 1
  dialogVisible.value = true
}

const editAmount = (row: any, index: number) => {
  editingIndex.value = index
  editForm.amount = Number(row.amount)
  editForm.label = row.label || ''
  editForm.discount = row.discount || ''
  editForm.status = row.status
  dialogVisible.value = true
}

const confirmEdit = () => {
  if (!editForm.amount || editForm.amount <= 0) {
    ElMessage.warning('请输入有效金额')
    return
  }
  const item = { ...editForm }
  if (editingIndex.value >= 0) {
    amounts.value[editingIndex.value] = item
  } else {
    amounts.value.push(item)
  }
  amounts.value.sort((a, b) => a.amount - b.amount)
  dialogVisible.value = false
}

const removeAmount = (index: number) => {
  amounts.value.splice(index, 1)
}

const saveAmounts = async () => {
  saving.value = true
  try {
    await request.post({ url: '/api/admin/recharge/amounts', data: { amounts: amounts.value } })
    ElMessage.success('保存成功')
    fetchAmounts()
  } catch (e: any) {
    ElMessage.error(e.message || '保存失败')
  }
  saving.value = false
}

onMounted(() => fetchAmounts())
</script>

<style scoped>
.recharge-amounts-page { padding: 20px; }
</style>
