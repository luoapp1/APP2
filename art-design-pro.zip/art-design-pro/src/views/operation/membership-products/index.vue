<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>会员商品管理</span>
          <ElButton type="primary" @click="showForm(null)">新增商品</ElButton>
        </div>
      </template>
      <ArtTable :loading="loading" :data="data" :columns="columns" :pagination="pagination"
        @pagination:size-change="handleSizeChange" @pagination:current-change="handleCurrentChange" />
    </ElCard>

    <ElDialog v-model="formVisible" :title="editId ? '编辑商品' : '新增商品'" width="520px">
      <ElForm :model="form" label-width="100px" :disabled="saving">
        <ElFormItem label="商品名称"><ElInput v-model="form.name" placeholder="如：月卡" /></ElFormItem>
        <ElFormItem label="会员等级">
          <ElSelect v-model="form.levelId" placeholder="选择等级" style="width:100%">
            <ElOption v-for="l in levels" :key="l.id" :label="`${l.name}${l.tier === 2 ? ' (二级)' : ''}`" :value="l.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="价格"><ElInputNumber v-model="form.price" :min="0" :precision="2" style="width:100%" /></ElFormItem>
        <ElFormItem label="原价"><ElInputNumber v-model="form.originalPrice" :min="0" :precision="2" style="width:100%" /></ElFormItem>
        <ElFormItem label="有效期(天)"><ElInputNumber v-model="form.durationDays" :min="1" style="width:100%" /></ElFormItem>
        <ElFormItem label="促销中"><ElSwitch v-model="form.isPromo" /></ElFormItem>
        <ElFormItem label="促销截止" v-if="form.isPromo">
          <ElDatePicker v-model="form.promoEndTime" type="datetime" placeholder="选择截止时间" style="width:100%" />
        </ElFormItem>
        <ElFormItem label="状态"><ElSwitch v-model="form.status" active-value="1" inactive-value="0" active-text="启用" inactive-text="禁用" /></ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="formVisible = false">取消</ElButton>
        <ElButton type="primary" @click="doSave" :loading="saving">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { h } from 'vue'
import request from '@/utils/http'
import { useTable } from '@/hooks/core/useTable'

const levels = ref<any[]>([])
const saving = ref(false)
const formVisible = ref(false)
const editId = ref(0)
const form = ref({ name: '', levelId: 0, price: 0, originalPrice: 0, durationDays: 30, isPromo: false, promoEndTime: '', status: '1' })

function levelName(id: number) { const l = levels.value.find((x: any) => x.id === id); return l ? l.name : '-' }

const columns = [
  { prop: 'id', label: 'ID', width: 60 },
  { prop: 'name', label: '商品名称', minWidth: 160 },
  {
    prop: 'level_id', label: '会员等级', width: 140,
    formatter: (row: any) => levelName(row.level_id)
  },
  { prop: 'price', label: '价格', width: 100 },
  { prop: 'original_price', label: '原价', width: 80 },
  { prop: 'duration_days', label: '天数', width: 80 },
  {
    prop: 'is_promo', label: '促销', width: 80,
    formatter: (row: any) => h(ElTag, { type: row.is_promo ? 'danger' : '', size: 'small' }, () => row.is_promo ? '是' : '否')
  },
  {
    prop: 'status', label: '状态', width: 80,
    formatter: (row: any) => h(ElTag, { type: row.status === '1' ? 'success' : 'info', size: 'small' }, () => row.status === '1' ? '启用' : '禁用')
  },
  {
    label: '操作', width: 140,
    formatter: (row: any) =>
      h('div', [
        h(ElButton, { size: 'small', link: true, type: 'primary', onClick: () => showForm(row) }, () => '编辑'),
        h(ElButton, { size: 'small', link: true, type: 'danger', onClick: () => doDelete(row) }, () => '删除')
      ])
  }
]

const { data, loading, pagination, handleSizeChange, handleCurrentChange, refreshData } = useTable({
  core: {
    apiFn: (params: any) => request.get({ url: '/api/membership/products' }),
    apiParams: { current: 1, size: 200 },
    immediate: true
  },
  transform: {
    responseAdapter: (res: any) => ({
      records: Array.isArray(res) ? res : (res?.records || res?.data || res?.list || []),
      total: Array.isArray(res) ? res.length : (res?.total || 0),
      current: 1,
      size: 200
    })
  }
})

async function loadLevels() {
  const res: any = await request.get({ url: '/api/operation/membership-level/list' })
  levels.value = (res?.list || res || [])
}

function showForm(row: any) {
  editId.value = row?.id || 0
  if (row) {
    form.value = { name: row.name, levelId: row.level_id, price: row.price, originalPrice: row.original_price, durationDays: row.duration_days, isPromo: !!row.is_promo, promoEndTime: row.promo_end_time || '', status: row.status || '1' }
  } else {
    form.value = { name: '', levelId: 0, price: 0, originalPrice: 0, durationDays: 30, isPromo: false, promoEndTime: '', status: '1' }
  }
  formVisible.value = true
}

async function doSave() {
  saving.value = true
  try {
    await request.post({ url: '/api/membership/product/save', data: { id: editId.value || undefined, ...form.value } })
    ElMessage.success('保存成功')
    formVisible.value = false
    refreshData()
  } catch { ElMessage.error('操作失败') } finally { saving.value = false }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm('确定删除此商品?', '确认', { type: 'warning' })
    await request.del({ url: `/api/membership/product/${row.id}` })
    ElMessage.success('已删除')
    refreshData()
  } catch {}
}

onMounted(() => {
  loadLevels()
})
</script>
