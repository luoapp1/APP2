<template>
  <div class="art-full-height">
    <ElCard class="art-table-card">
      <template #header>
        <div class="card-header">
          <span>会员商品管理</span>
          <ElButton type="primary" @click="showForm(null)">新增商品</ElButton>
        </div>
      </template>

      <ElTable :data="products" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="name" label="商品名称" minWidth="160" />
        <ElTableColumn label="会员等级" width="140">
          <template #default="{ row }">
            {{ levelName(row.level_id) }}
          </template>
        </ElTableColumn>
        <ElTableColumn label="价格" width="100">
          <template #default="{ row }">
            <span v-if="row.is_promo" class="text-red-500 font-bold">{{ row.price }}</span>
            <span v-else>{{ row.price }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="original_price" label="原价" width="80" />
        <ElTableColumn prop="duration_days" label="天数" width="80" />
        <ElTableColumn label="促销" width="80">
          <template #default="{ row }">
            <ElTag :type="row.is_promo?'danger':''" size="small">{{ row.is_promo?'是':'否' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="状态" width="80">
          <template #default="{ row }">
            <ElTag :type="row.status==='1'?'success':'info'" size="small">{{ row.status==='1'?'启用':'禁用' }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="140">
          <template #default="{ row }">
            <ElButton size="small" link type="primary" @click="showForm(row)">编辑</ElButton>
            <ElButton size="small" link type="danger" @click="doDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElDialog v-model="formVisible" :title="editId?'编辑商品':'新增商品'" width="520px">
      <ElForm :model="form" label-width="100px" :disabled="saving">
        <ElFormItem label="商品名称"><ElInput v-model="form.name" placeholder="如：月卡" /></ElFormItem>
        <ElFormItem label="会员等级">
          <ElSelect v-model="form.levelId" placeholder="选择等级" style="width:100%">
            <ElOption v-for="l in levels" :key="l.id" :label="l.name + (l.tier===2?' (二级)':'')" :value="l.id" />
          </ElSelect>
        </ElFormItem>
        <ElFormItem label="价格"><ElInputNumber v-model="form.price" :min="0" :precision="2" style="width:100%" /></ElFormItem>
        <ElFormItem label="原价"><ElInputNumber v-model="form.originalPrice" :min="0" :precision="2" style="width:100%" /></ElFormItem>
        <ElFormItem label="有效期(天)"><ElInputNumber v-model="form.durationDays" :min="1" style="width:100%" /></ElFormItem>
        <ElFormItem label="促销中"><ElSwitch v-model="form.isPromo" /></ElFormItem>
        <ElFormItem label="促销截止" v-if="form.isPromo">
          <ElDatePicker v-model="form.promoEndTime" type="datetime" placeholder="选择截止时间" style="width:100%" />
        </ElFormItem>
        <ElFormItem label="状态"><ElSwitch v-model="form.status" active-value="1" inactive-value="0" active-text="启用" inactive-text="禁用" /></ElFormItem>
      </ElForm>
      <template #footer>
        <ElButton @click="formVisible=false">取消</ElButton>
        <ElButton type="primary" @click="doSave" :loading="saving">保存</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'

const products = ref<any[]>([])
const levels = ref<any[]>([])
const loading = ref(false)
const saving = ref(false)
const formVisible = ref(false)
const editId = ref(0)
const form = ref({ name: '', levelId: 0, price: 0, originalPrice: 0, durationDays: 30, isPromo: false, promoEndTime: '', status: '1' })

function levelName(id: number) { const l = levels.value.find((x: any) => x.id === id); return l ? l.name : '-' }

function showForm(row: any) {
  editId.value = row?.id || 0
  if (row) {
    form.value = { name: row.name, levelId: row.level_id, price: row.price, originalPrice: row.original_price, durationDays: row.duration_days, isPromo: !!row.is_promo, promoEndTime: row.promo_end_time || '', status: row.status || '1' }
  } else {
    form.value = { name: '', levelId: 0, price: 0, originalPrice: 0, durationDays: 30, isPromo: false, promoEndTime: '', status: '1' }
  }
  formVisible.value = true
}

async function loadData() {
  loading.value = true
  try {
    const r: any = await request.get({ url: '/api/membership/products' })
    products.value = r || []
    const r2: any = await request.get({ url: '/api/operation/membership-level/list' })
    levels.value = (r2?.list || r2 || [])
  } catch {} finally { loading.value = false }
}

async function doSave() {
  saving.value = true
  try {
    await request.post({ url: '/api/membership/product/save', data: { id: editId.value || undefined, ...form.value } })
    ElMessage.success('保存成功')
    formVisible.value = false
    loadData()
  } catch { ElMessage.error('操作失败') } finally { saving.value = false }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm('确定删除此商品?', '确认', { type: 'warning' })
    await request.del({ url: `/api/membership/product/${row.id}` })
    ElMessage.success('已删除')
    loadData()
  } catch {}
}

onMounted(loadData)
</script>
