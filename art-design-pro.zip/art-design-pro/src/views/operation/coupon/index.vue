<!-- 优惠券管理页面 -->
<template>
  <div class="coupon-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElSpace wrap>
            <ElButton type="primary" @click="showDialog('add')" v-ripple>添加优惠券</ElButton>
          </ElSpace>
        </template>
        <template #right>
          <ElSpace>
            <ElSelect v-model="filterCategory" placeholder="分类" clearable style="width:120px" @change="refreshData">
              <ElOption label="全部" value="" />
              <ElOption label="通用券" value="general" />
              <ElOption label="会员券" value="member" />
              <ElOption label="商品券" value="product" />
              <ElOption label="活动券" value="event" />
              <ElOption label="新人券" value="new_user" />
              <ElOption label="限时抢券" value="rush" />
            </ElSelect>
            <ElSelect v-model="filterScope" placeholder="使用范围" clearable style="width:120px" @change="refreshData">
              <ElOption label="全部" value="" />
              <ElOption label="通用" value="all" />
              <ElOption label="商品" value="product" />
              <ElOption label="会员" value="membership" />
            </ElSelect>
          </ElSpace>
        </template>
      </ArtTableHeader>

      <ElTable :data="data" v-loading="loading" stripe>
        <ElTableColumn prop="id" label="ID" width="60" />
        <ElTableColumn prop="name" label="名称" min-width="140" />
        <ElTableColumn label="类型" width="90">
          <template #default="{ row }">
            <ElTag :type="row.type === 'fixed' ? 'success' : 'warning'" size="small">
              {{ row.type === 'fixed' ? '固定金额' : '折扣券' }}
            </ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="面值" width="100">
          <template #default="{ row }">
            <span v-if="row.type === 'fixed'" class="text-orange-500 font-bold">¥{{ row.value }}</span>
            <span v-else class="text-orange-500 font-bold">{{ row.value / 10 }}折</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="最低消费" width="90">
          <template #default="{ row }">
            <span v-if="row.minOrder > 0">¥{{ row.minOrder }}</span>
            <span v-else class="text-green-500">无门槛</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="分类" width="90">
          <template #default="{ row }">{{ row.categoryLabel || '--' }}</template>
        </ElTableColumn>
        <ElTableColumn label="范围" width="80">
          <template #default="{ row }">{{ row.scopeLabel || '--' }}</template>
        </ElTableColumn>
        <ElTableColumn label="领取/总数" width="100">
          <template #default="{ row }">{{ row.claimedCount }} / {{ row.totalCount || '∞' }}</template>
        </ElTableColumn>
        <ElTableColumn label="状态" width="70">
          <template #default="{ row }">
            <ElTag :type="row.status === '1' ? 'success' : 'info'" size="small">
              {{ row.status === '1' ? '启用' : '禁用' }}
            </ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="创建时间" width="160">
          <template #default="{ row }">{{ row.createTime }}</template>
        </ElTableColumn>
        <ElTableColumn label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <ElButton size="small" type="primary" link @click="showDialog('edit', row)">编辑</ElButton>
            <ElButton size="small" type="success" link @click="viewClaims(row)">领取</ElButton>
            <ElButton size="small" type="danger" link @click="handleDelete(row)">删除</ElButton>
          </template>
        </ElTableColumn>
      </ElTable>

      <div class="mt-4 flex justify-end">
        <ElPagination
          v-model:current-page="pagination.current"
          v-model:page-size="pagination.size"
          :total="pagination.total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="loadData"
          @current-change="loadData"
        />
      </div>
    </ElCard>

    <CouponDialog v-model:visible="dialogVisible" :type="dialogType" :edit-data="currentData" @submit="handleSubmit" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchCouponList, fetchCreateCoupon, fetchUpdateCoupon, fetchDeleteCoupon } from '@/api/coupon'
import CouponDialog from './modules/coupon-dialog.vue'
import { ElMessageBox, ElMessage } from 'element-plus'
import request from '@/utils/http'

defineOptions({ name: 'CouponManage' })

const loading = ref(false)
const data = ref<any[]>([])
const dialogVisible = ref(false)
const dialogType = ref<'add' | 'edit'>('add')
const currentData = ref<any>({})
const filterCategory = ref('')
const filterScope = ref('')
const columnChecks = ref([])

const pagination = ref({ current: 1, size: 20, total: 0 })

async function loadData() {
  loading.value = true
  try {
    const res: any = await fetchCouponList({
      current: pagination.value.current,
      size: pagination.value.size,
      category: filterCategory.value || undefined,
      scope: filterScope.value || undefined
    })
    data.value = res.records || []
    pagination.value.total = res.total || 0
  } finally {
    loading.value = false
  }
}

function refreshData() {
  pagination.value.current = 1
  loadData()
}

function showDialog(type: 'add' | 'edit', row?: any) {
  dialogType.value = type
  currentData.value = type === 'edit' ? { ...row } : {}
  dialogVisible.value = true
}

async function handleSubmit(form: any) {
  try {
    if (dialogType.value === 'add') {
      await fetchCreateCoupon(form)
      ElMessage.success('创建成功')
    } else {
      await fetchUpdateCoupon(currentData.value.id, form)
      ElMessage.success('更新成功')
    }
    dialogVisible.value = false
    loadData()
  } catch (e: any) {
    ElMessage.error(e?.message || '操作失败')
  }
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm(`确定删除优惠券「${row.name}」？`, '提示', { type: 'warning' })
  try {
    await fetchDeleteCoupon(row.id)
    ElMessage.success('删除成功')
    loadData()
  } catch (e: any) {
    ElMessage.error(e?.message || '删除失败')
  }
}

async function viewClaims(row: any) {
  try {
    const res: any = await request.get({ url: '/api/coupon/claims', params: { couponId: row.id, size: 100 } })
    const records = res?.records || []
    if (records.length === 0) { ElMessage.info('暂无领取记录'); return }
    let text = `优惠券 "${row.name}" 领取记录 (${records.length}条):\n\n`
    records.forEach((r: any, i: number) => {
      text += `${i+1}. 用户: ${r.userName || r.userId} | 状态: ${r.status === 'used' ? '已使用' : r.status === 'unused' ? '未使用' : '已过期'} | 领取: ${r.receiveTime || '-'}\n`
      if (r.useTime) text += `   使用: ${r.useTime} 抵扣: ¥${r.useAmount || 0}\n`
    })
    ElMessageBox.alert(text, '领取记录', { confirmButtonText: '关闭', dangerouslyUseHTMLString: false })
  } catch (e: any) {
    ElMessage.error(e?.message || '查询失败')
  }
}

onMounted(loadData)
</script>
