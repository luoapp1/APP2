<!-- 优惠券创建/编辑弹窗 -->
<template>
  <ElDialog
    :model-value="visible"
    :title="type === 'add' ? '添加优惠券' : '编辑优惠券'"
    width="600px"
    :close-on-click-modal="false"
    @update:model-value="(val) => emit('update:visible', val)"
  >
    <ElForm ref="formRef" :model="form" :rules="rules" label-width="90px">
      <ElFormItem label="名称" prop="name">
        <ElInput v-model="form.name" placeholder="如：618大促优惠券" />
      </ElFormItem>
      <ElFormItem label="简介" prop="description">
        <ElInput v-model="form.description" type="textarea" :rows="2" placeholder="优惠券描述" />
      </ElFormItem>
      <ElRow :gutter="16">
        <ElCol :span="12">
          <ElFormItem label="券类型" prop="type">
            <ElSelect v-model="form.type">
              <ElOption label="固定余额" value="fixed" />
              <ElOption label="余额折扣" value="percent" />
              <ElOption label="固定积分" value="fixed_points" />
              <ElOption label="积分折扣" value="points_percent" />
            </ElSelect>
          </ElFormItem>
        </ElCol>
        <ElCol :span="12">
          <ElFormItem label="面值/折扣" prop="value">
            <ElInputNumber v-model="form.value" :min="0" :precision="0" style="width:100%" :placeholder="form.type === 'percent' ? '如80表示8折' : '金额'" />
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElRow :gutter="16">
        <ElCol :span="12">
          <ElFormItem label="最低消费">
            <ElInputNumber v-model="form.minOrder" :min="0" :precision="0" style="width:100%" placeholder="0表示无门槛" />
          </ElFormItem>
        </ElCol>
        <ElCol :span="12">
          <ElFormItem label="最大折扣" v-if="form.type === 'percent'">
            <ElInputNumber v-model="form.maxDiscount" :min="0" :precision="0" style="width:100%" placeholder="折扣上限金额" />
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElRow :gutter="16">
        <ElCol :span="12">
          <ElFormItem label="使用范围" prop="scope">
            <ElSelect v-model="form.scope">
              <ElOption label="通用" value="all" />
              <ElOption label="商品" value="product" />
              <ElOption label="会员" value="membership" />
            </ElSelect>
          </ElFormItem>
        </ElCol>
        <ElCol :span="12">
          <ElFormItem label="分类" prop="category">
            <ElSelect v-model="form.category">
              <ElOption label="通用券" value="general" />
              <ElOption label="会员券" value="member" />
              <ElOption label="商品券" value="product" />
              <ElOption label="活动券" value="event" />
              <ElOption label="新人券" value="new_user" />
              <ElOption label="限时抢券" value="rush" />
            </ElSelect>
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElFormItem label="发放总数">
        <ElInputNumber v-model="form.totalCount" :min="0" :precision="0" style="width:100%" placeholder="0表示不限量" />
      </ElFormItem>
      <ElFormItem label="每人限领">
        <ElInputNumber v-model="form.perUserLimit" :min="1" :precision="0" style="width:100%" placeholder="每人限领张数" />
      </ElFormItem>
      <ElRow :gutter="16">
        <ElCol :span="12">
          <ElFormItem label="领取开始">
            <ElDatePicker v-model="form.startTime" type="datetime" placeholder="选择开始时间" style="width:100%" />
          </ElFormItem>
        </ElCol>
        <ElCol :span="12">
          <ElFormItem label="领取截止">
            <ElDatePicker v-model="form.expireTime" type="datetime" placeholder="选择截止时间" style="width:100%" />
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElFormItem label="有效天数">
        <ElInputNumber v-model="form.validDays" :min="0" :precision="0" style="width:100%" placeholder="领取后有效天数，0为跟随截止时间" />
      </ElFormItem>
      <ElRow :gutter="16">
        <ElCol :span="8">
          <ElFormItem label="推荐">
            <ElSwitch v-model="form.isRecommend" />
          </ElFormItem>
        </ElCol>
        <ElCol :span="8">
          <ElFormItem label="新人专享">
            <ElSwitch v-model="form.isNewUser" />
          </ElFormItem>
        </ElCol>
        <ElCol :span="8">
          <ElFormItem label="限时抢">
            <ElSwitch v-model="form.isRush" />
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElRow :gutter="16">
        <ElCol :span="8">
          <ElFormItem label="多次使用">
            <ElSwitch v-model="form.isMultiUse" />
          </ElFormItem>
        </ElCol>
        <ElCol :span="16">
          <ElFormItem label="专属会员">
            <ElSelect
              v-model="form.requiredLevelIds"
              multiple
              filterable
              placeholder="留空表示所有会员可领"
              style="width:100%"
              @change="onLevelChange"
            >
              <ElOption
                v-for="lv in levelList"
                :key="lv.id"
                :label="lv.name"
                :value="lv.id"
              />
            </ElSelect>
          </ElFormItem>
        </ElCol>
      </ElRow>
      <ElFormItem label="排序">
        <ElInputNumber v-model="form.sortOrder" :min="0" :precision="0" style="width:100%" placeholder="越小越靠前" />
      </ElFormItem>
      <ElFormItem label="状态">
        <ElSwitch v-model="form.status" active-value="1" inactive-value="0" active-text="启用" inactive-text="禁用" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <ElButton @click="emit('update:visible', false)">取消</ElButton>
      <ElButton type="primary" @click="handleConfirm">确定</ElButton>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
import { ref, watch, reactive, onMounted } from 'vue'
import { fetchGetMembershipLevelList } from '@/api/operation'

const props = defineProps<{
  visible: boolean
  type: 'add' | 'edit'
  editData?: any
}>()

const emit = defineEmits(['update:visible', 'submit'])

const levelList = ref<any[]>([])

const form = reactive<any>({
  name: '',
  description: '',
  type: 'fixed',
  value: 0,
  minOrder: 0,
  maxDiscount: 0,
  scope: 'all',
  category: 'general',
  totalCount: 0,
  perUserLimit: 1,
  startTime: null,
  expireTime: null,
  validDays: 0,
  isRecommend: false,
  isNewUser: false,
  isRush: false,
  isMultiUse: false,
  requiredLevelIds: [],
  requiredLevelNames: [],
  sortOrder: 0,
  status: '1'
})

onMounted(async () => {
  try {
    const res: any = await fetchGetMembershipLevelList()
    levelList.value = res?.records || []
  } catch {}
})

function onLevelChange(ids: number[]) {
  form.requiredLevelNames = ids.map((id: number) => {
    const lv = levelList.value.find((l: any) => l.id === id)
    return lv ? lv.name : ''
  }).filter(Boolean)
}

const rules = {
  name: [{ required: true, message: '请输入名称', trigger: 'blur' }],
  type: [{ required: true }],
  category: [{ required: true }],
  scope: [{ required: true }],
  value: [{ required: true, message: '请输入面值' }]
}

watch(() => props.visible, (val) => {
  if (val && props.type === 'edit' && props.editData) {
    const d = props.editData
    Object.assign(form, {
      name: d.name || '',
      description: d.description || '',
      type: d.type || 'fixed',
      value: d.value || 0,
      minOrder: d.minOrder || 0,
      maxDiscount: d.maxDiscount || 0,
      scope: d.scope || 'all',
      category: d.category || 'general',
      totalCount: d.totalCount || 0,
      perUserLimit: d.perUserLimit || 1,
      startTime: d.startTime || null,
      expireTime: d.expireTime || null,
      validDays: d.validDays || 0,
      isRecommend: d.isRecommend || false,
      isNewUser: d.isNewUser || false,
      isRush: d.isRush || false,
      isMultiUse: d.isMultiUse || false,
      requiredLevelIds: d.requiredLevelIds || [],
      requiredLevelNames: d.requiredLevelNames || [],
      sortOrder: d.sortOrder || 0,
      status: d.status || '1'
    })
  } else if (val) {
    Object.assign(form, {
      name: '', description: '', type: 'fixed', value: 0, minOrder: 0,
      maxDiscount: 0, scope: 'all', category: 'general', totalCount: 0,
      perUserLimit: 1, startTime: null, expireTime: null, validDays: 0,
      isRecommend: false, isNewUser: false, isRush: false,
      isMultiUse: false,
      requiredLevelIds: [], requiredLevelNames: [],
      sortOrder: 0, status: '1'
    })
  }
})

const formRef = ref()

async function handleConfirm() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  const data = { ...form }
  if (data.startTime) data.startTime = new Date(data.startTime).toISOString()
  if (data.expireTime) data.expireTime = new Date(data.expireTime).toISOString()
  emit('submit', data)
}
</script>
