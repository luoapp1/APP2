<!-- 卡密生成页面 -->
<template>
  <div class="cardkey-page art-full-height">
    <CardKeySearch v-model="searchForm" @search="handleSearch" @reset="resetSearchParams" />

    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElSpace wrap>
            <ElButton type="primary" @click="showDialog('add')" v-ripple>生成卡密</ElButton>
            <ElButton type="success" @click="showBatchDialog('add')" v-ripple>批量生成</ElButton>
          </ElSpace>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @selection-change="handleSelectionChange"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <CardKeyDialog
        v-model:visible="dialogVisible"
        :type="dialogType"
        @submit="handleDialogSubmit"
      />

      <BatchCardKeyDialog
        v-model:visible="batchDialogVisible"
        @submit="handleBatchDialogSubmit"
      />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTable } from '@/hooks/core/useTable'
  import { fetchGetCardKeyList, fetchCreateCardKeys, fetchDeleteCardKey } from '@/api/operation'
  import { CARD_KEY_DATA } from '@/mock/temp/operation'
  import CardKeySearch from './modules/cardkey-search.vue'
  import CardKeyDialog from './modules/cardkey-dialog.vue'
  import BatchCardKeyDialog from './modules/batch-dialog.vue'
  import { ElTag, ElMessageBox, ElButton, ElMessage } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'CardKey' })

  type CardKeyItem = Api.Operation.CardKeyItem

  const dialogType = ref<DialogType>('add')
  const dialogVisible = ref(false)
  const batchDialogVisible = ref(false)
  const selectedRows = ref<CardKeyItem[]>([])

  const searchForm = ref({ cardNo: undefined as string | undefined, type: undefined as string | undefined, status: undefined as string | undefined })

  const CARD_KEY_TYPE_CONFIG = { membership: { type: 'primary' as const, text: '会员卡' }, points: { type: 'success' as const, text: '积分卡' }, experience: { type: 'warning' as const, text: '经验卡' }, balance: { type: 'danger' as const, text: '余额卡' } } as const
  const CARD_KEY_STATUS_CONFIG = { '0': { type: 'info' as const, text: '未使用' }, '1': { type: 'success' as const, text: '已使用' } } as const

  const getCardTypeConfig = (type: string) => CARD_KEY_TYPE_CONFIG[type as keyof typeof CARD_KEY_TYPE_CONFIG] || { type: 'info' as const, text: '未知' }
  const getCardStatusConfig = (status: string) => CARD_KEY_STATUS_CONFIG[status as keyof typeof CARD_KEY_STATUS_CONFIG] || { type: 'info' as const, text: '未知' }

  const { columns, columnChecks, data, loading, pagination, getData, replaceSearchParams, resetSearchParams, handleSizeChange, handleCurrentChange, refreshData } = useTable({
    core: {
      apiFn: fetchGetCardKeyList,
      apiParams: { current: 1, size: 20, ...searchForm.value },
      columnsFactory: () => [
        { type: 'selection' },
        { type: 'index', width: 60, label: '序号' },
        { prop: 'cardNo', label: '卡号', width: 220 },
        { prop: 'password', label: '密码', width: 140 },
        { prop: 'type', label: '类型', width: 100, formatter: (row: CardKeyItem) => { const c = getCardTypeConfig(row.type); return h(ElTag, { type: c.type }, () => c.text) } },
        { prop: 'targetName', label: '兑换目标', width: 140 },
        { prop: 'value', label: '面值', width: 100, formatter: (row: CardKeyItem) => {
          if (row.type === 'points') return `${row.value}积分`
          if (row.type === 'experience') return `${row.value}经验`
          return `${row.targetName}`
        } },
        { prop: 'extraPoints', label: '额外积分', width: 90, formatter: (row: CardKeyItem) => row.extraPoints > 0 ? `${row.extraPoints}` : '-' },
        { prop: 'extraExperience', label: '额外经验', width: 90, formatter: (row: CardKeyItem) => row.extraExperience > 0 ? `${row.extraExperience}` : '-' },
        { prop: 'duration', label: '有效时长', width: 100, formatter: (row: CardKeyItem) => row.duration > 0 ? `${row.duration}${row.durationUnit || ''}` : '-' },
        { prop: 'status', label: '状态', width: 100, formatter: (row: CardKeyItem) => { const c = getCardStatusConfig(row.status); return h(ElTag, { type: c.type }, () => c.text) } },
        { prop: 'createTime', label: '创建时间', width: 180 },
        { prop: 'redeemBy', label: '使用者', width: 140, formatter: (row: CardKeyItem) => row.redeemBy || '-' },
        { prop: 'redeemTime', label: '使用时间', width: 180, formatter: (row: CardKeyItem) => row.redeemTime || '-' },
        { prop: 'operation', label: '操作', width: 120, fixed: 'right', formatter: (row: CardKeyItem) => h('div', [h(ArtButtonTable, { type: 'delete', onClick: () => deleteCardKey(row) })]) }
      ]
    },
    transform: {
      dataTransformer: (records) => {
        if (!Array.isArray(records)) return []
        if (records.length === 0) return CARD_KEY_DATA
        return records
      }
    }
  })

  const handleSearch = (params: any) => { replaceSearchParams(params); getData() }
  const showDialog = (type: DialogType) => { dialogType.value = type; nextTick(() => { dialogVisible.value = true }) }
  const showBatchDialog = () => { nextTick(() => { batchDialogVisible.value = true }) }
  const deleteCardKey = (row: CardKeyItem) => {
    ElMessageBox.confirm('确定要删除该卡密吗？', '删除卡密', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
      await fetchDeleteCardKey(row.id)
      ElMessage.success('删除成功')
      refreshData()
    }).catch(() => {})
  }
  const handleDialogSubmit = async (formData?: Record<string, unknown>) => {
    if (formData) await fetchCreateCardKeys(formData as any)
    dialogVisible.value = false
    refreshData()
  }
  const handleBatchDialogSubmit = async (formData?: Record<string, unknown>) => {
    if (formData) await fetchCreateCardKeys(formData as any)
    batchDialogVisible.value = false
    refreshData()
  }
  const handleSelectionChange = (selection: CardKeyItem[]) => { selectedRows.value = selection }
</script>
