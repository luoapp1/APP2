<template>
  <ArtSearchBar ref="searchBarRef" v-model="formData" :items="formItems" :rules="rules" @reset="handleReset" @search="handleSearch" />
</template>

<script setup lang="ts">
  interface Props { modelValue: any }
  interface Emits { (e: 'update:modelValue', value: any): void; (e: 'search', params: any): void; (e: 'reset'): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const searchBarRef = ref()
  const formData = computed({ get: () => props.modelValue, set: (val) => emit('update:modelValue', val) })
  const rules = {}
  const formItems = computed(() => [
    { label: '卡号', key: 'cardNo', type: 'input', placeholder: '请输入卡号', clearable: true },
    { label: '类型', key: 'type', type: 'select', props: { placeholder: '请选择类型', options: [{ label: '会员卡', value: 'membership' }, { label: '积分卡', value: 'points' }], clearable: true } },
    { label: '状态', key: 'status', type: 'select', props: { placeholder: '请选择状态', options: [{ label: '未使用', value: '0' }, { label: '已使用', value: '1' }], clearable: true } }
  ])
  const handleReset = () => emit('reset')
  const handleSearch = async (params: any) => { await searchBarRef.value.validate(); emit('search', params) }
</script>
