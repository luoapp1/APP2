<template>
  <ElDialog v-model="dialogVisible" title="生成卡密" width="35%" align-center>
    <ElForm ref="formRef" :model="formData" :rules="rules" label-width="100px">
      <ElFormItem label="卡密类型" prop="type">
        <ElSelect v-model="formData.type" @change="handleTypeChange">
          <ElOption label="会员卡" value="membership" />
          <ElOption label="积分卡" value="points" />
          <ElOption label="经验卡" value="experience" />
          <ElOption label="余额卡" value="balance" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem v-if="formData.type === 'membership'" label="会员等级" prop="targetId">
        <ElSelect v-model="formData.targetId">
          <ElOption v-for="level in levelList" :key="level.id" :label="level.name" :value="level.id" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem v-if="formData.type === 'membership'" label="有效时长" prop="duration">
        <ElInputNumber v-model="formData.duration" :min="1" :max="3650" style="width: 60%" />
        <ElSelect v-model="formData.durationUnit" style="width: 38%; margin-left: 2%">
          <ElOption label="天" value="day" />
          <ElOption label="周" value="week" />
          <ElOption label="月" value="month" />
          <ElOption label="年" value="year" />
        </ElSelect>
      </ElFormItem>
      <ElFormItem v-if="formData.type === 'points'" label="积分数额" prop="value">
        <ElInputNumber v-model="formData.value" :min="100" :max="100000" :step="100" style="width: 100%" />
      </ElFormItem>
      <ElFormItem v-if="formData.type === 'experience'" label="经验数额" prop="value">
        <ElInputNumber v-model="formData.value" :min="100" :max="100000" :step="100" style="width: 100%" />
      </ElFormItem>
      <ElFormItem v-if="formData.type === 'balance'" label="余额数额" prop="value">
        <ElInputNumber v-model="formData.value" :min="1" :max="10000" :step="1" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="额外积分">
        <ElInputNumber v-model="formData.extraPoints" :min="0" :max="100000" :step="100" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="额外经验">
        <ElInputNumber v-model="formData.extraExperience" :min="0" :max="100000" :step="100" style="width: 100%" />
      </ElFormItem>
      <ElFormItem label="生成数量" prop="count">
        <ElInputNumber v-model="formData.count" :min="1" :max="100" style="width: 100%" />
      </ElFormItem>
    </ElForm>
    <template #footer>
      <div class="dialog-footer">
        <ElButton @click="dialogVisible = false">取消</ElButton>
        <ElButton type="primary" @click="handleSubmit">生成</ElButton>
      </div>
    </template>
  </ElDialog>
</template>

<script setup lang="ts">
  import { fetchGetMembershipLevelList } from '@/api/operation'
  import type { FormInstance, FormRules } from 'element-plus'

  interface Props { visible: boolean; type: string }
  interface Emits { (e: 'update:visible', value: boolean): void; (e: 'submit', data: Record<string, unknown>): void }
  const props = defineProps<Props>()
  const emit = defineEmits<Emits>()
  const formRef = ref<FormInstance>()
  const dialogVisible = computed({ get: () => props.visible, set: (value) => emit('update:visible', value) })

  const levelList = ref<Array<{ id: number; name: string }>>([])
  const loadLevels = async () => {
    try {
      const data = await fetchGetMembershipLevelList({})
      if (data && (data as any).records) levelList.value = (data as any).records
    } catch {}
  }
  loadLevels()

  const formData = reactive({
    type: 'membership', targetId: 1, value: 500, count: 1,
    duration: 12, durationUnit: 'month',
    extraPoints: 0, extraExperience: 0
  })
  const rules: FormRules = { type: [{ required: true, message: '请选择卡密类型', trigger: 'change' }] }

  const handleTypeChange = () => {
    if (formData.type === 'membership') { formData.value = 1 }
    else if (formData.type === 'points') { formData.value = 500 }
    else if (formData.type === 'experience') { formData.value = 500 }
    else if (formData.type === 'balance') { formData.value = 50 }
  }

  watch(() => props.visible, (val) => {
    if (val) {
      formData.type = 'membership'; formData.targetId = 1; formData.value = 500; formData.count = 1
      formData.duration = 12; formData.durationUnit = 'month'
      formData.extraPoints = 0; formData.extraExperience = 0
      nextTick(() => formRef.value?.clearValidate())
    }
  })

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate((valid) => {
      if (valid) {
        ElMessage.success(`成功生成 ${formData.count} 张卡密`)
        dialogVisible.value = false
        emit('submit', {
          type: formData.type,
          targetId: formData.targetId,
          value: formData.value,
          count: formData.count,
          duration: formData.duration,
          durationUnit: formData.durationUnit,
          extraPoints: formData.extraPoints,
          extraExperience: formData.extraExperience
        })
      }
    })
  }
</script>
