/**
 * 主题组件加载工具
 * 根据设备类型（屏幕宽度 >= 800 为 PC，否则为手机）动态加载对应主题的页面组件
 */
export function themeComponent(
  mobileLoader: () => Promise<any>,
  pcLoader: () => Promise<any>
): () => Promise<any> {
  return async () => {
    const isPC = typeof window !== 'undefined' && window.innerWidth >= 800
    if (isPC) {
      try {
        return await pcLoader()
      } catch {
        return await mobileLoader()
      }
    }
    return await mobileLoader()
  }
}

/**
 * 创建仅加载移动端组件的路由配置（无需 PC 版本的组件）
 */
export function mobileComponent(loader: () => Promise<any>): () => Promise<any> {
  return loader
}
