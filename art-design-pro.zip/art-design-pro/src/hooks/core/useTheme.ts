/**
 * useTheme - 系统主题管理
 *
 * 提供完整的主题切换和管理功能，支持亮色、暗色和自动模式。
 * 自动处理主题切换时的过渡效果，确保切换流畅无闪烁。
 *
 * ## 主要功能
 *
 * 1. 主题切换 - 支持亮色、暗色、自动三种主题模式
 * 2. 自动模式 - 根据系统偏好自动切换主题
 * 3. 颜色适配 - 自动调整主题色的明暗变体（9 个层级）
 * 4. 过渡优化 - 切换时临时禁用过渡效果，避免闪烁
 * 5. 状态持久化 - 主题设置自动保存到 store
 *
 * ## 使用示例
 *
 * ```typescript
 * const { switchThemeStyles } = useTheme()
 *
 * // 切换到暗色主题
 * switchThemeStyles(SystemThemeEnum.DARK)
 *
 * // 切换到亮色主题
 * switchThemeStyles(SystemThemeEnum.LIGHT)
 *
 * // 切换到自动模式（跟随系统）
 * switchThemeStyles(SystemThemeEnum.AUTO)
 * ```
 *
 * @module useTheme
 * @author Art Design Pro Team
 */

import { useSettingStore } from '@/store/modules/setting'
import { SystemThemeEnum } from '@/enums/appEnum'
import AppConfig from '@/config'
import { SystemThemeTypes } from '@/types/store'
import { getDarkColor, getLightColor, setElementThemeColor } from '@/utils/ui'
import { usePreferredDark } from '@vueuse/core'
import { watch } from 'vue'
type ThemeTokenSet = Record<string, string>

const TOKEN_CSS_MAP: Record<string, string> = {
  mainColor: '--main-color',
  primary: '--art-primary',
  secondary: '--art-secondary',
  gray100: '--art-gray-100',
  gray200: '--art-gray-200',
  gray300: '--art-gray-300',
  gray400: '--art-gray-400',
  gray500: '--art-gray-500',
  gray600: '--art-gray-600',
  gray700: '--art-gray-700',
  gray800: '--art-gray-800',
  gray900: '--art-gray-900',
  bgColor: '--default-bg-color',
  boxColor: '--default-box-color',
  hoverColor: '--art-hover-color',
  activeColor: '--art-active-color',
  elActiveColor: '--art-el-active-color',
  defaultBorder: '--default-border',
  dashedBorder: '--default-border-dashed',
  cardBorder: '--art-card-border',
  error: '--art-error',
  info: '--art-info',
  success: '--art-success',
  warning: '--art-warning',
  danger: '--art-danger',
  borderRadius: '--custom-radius',
  shadowColor: '--art-shadow-color',
  fontFamily: '--art-font-family'
}

const THEME_CACHE_KEY = 'art_theme_cache'
const SITE_THEME_KEY = 'art_site_theme'

const FALLBACK_DARK_ID = 'art-fallback-dark'

export function injectFallbackDark() {
  const existing = document.getElementById(FALLBACK_DARK_ID)
  if (existing) existing.remove()
  const style = document.createElement('style')
  style.id = FALLBACK_DARK_ID
  style.textContent = `
    .dark .bottom-nav { background: rgba(20,20,40,.95) !important; border-top-color: rgba(255,255,255,.08) !important; }
    .dark .nav-item { color: #666 !important; }
    .dark .nav-item.active { color: #FF4757 !important; }
    .dark { --default-bg-color: #0f0f1a; --default-box-color: #1a1a2e; --default-border: #2a2a4a; --default-border-dashed: #2a2a4a; --app-page-bg: #0f0f1a; }
    .dark body, .dark .min-h-screen { background: #0f0f1a !important; }

    .dark .bg-white,
    .dark .bg-\\[\\#ffffff\\],
    .dark .bg-\\[\\#fff\\] { background: #1a1a2e !important; }

    .dark .bg-\\[\\#f5f6f8\\],
    .dark .bg-gray-50,
    .dark .bg-\\[\\#FAFAFA\\],
    .dark .bg-\\[\\#fafafa\\],
    .dark .bg-\\[\\#f8f9fa\\] { background: #0f0f1a !important; }

    .dark .bg-gray-100,
    .dark .bg-\\[\\#F5F5F5\\],
    .dark .bg-\\[\\#f5f5f5\\],
    .dark .bg-\\[\\#F2F2F2\\],
    .dark .bg-\\[\\#f2f2f2\\],
    .dark .bg-\\[\\#e8eaed\\],
    .dark .bg-\\[\\#e8e8e8\\] { background: #1a1a2e !important; }

    .dark .bg-gray-200,
    .dark .bg-\\[\\#e5e7eb\\],
    .dark .bg-\\[\\#e0e0e0\\] { background: #252540 !important; }

    .dark .bg-red-50,
    .dark .bg-\\[\\#fef2f2\\],
    .dark .bg-\\[\\#fff5f5\\] { background: #2d1b1b !important; }
    .dark .bg-blue-50,
    .dark .bg-\\[\\#eff6ff\\],
    .dark .bg-\\[\\#eef2ff\\] { background: #1b1b2d !important; }
    .dark .bg-green-50,
    .dark .bg-\\[\\#f0fdf4\\] { background: #1b2d1b !important; }
    .dark .bg-yellow-50,
    .dark .bg-\\[\\#fefce8\\] { background: #2d2d1b !important; }
    .dark .bg-purple-50,
    .dark .bg-\\[\\#faf5ff\\] { background: #251b2d !important; }

    .dark .text-gray-900,
    .dark .text-\\[\\#1A1A1A\\],
    .dark .text-\\[\\#1a1a1a\\] { color: #f0f0f0 !important; }
    .dark .text-gray-800,
    .dark .text-\\[\\#333\\],
    .dark .text-\\[\\#333333\\] { color: #e0e0e0 !important; }
    .dark .text-gray-700,
    .dark .text-\\[\\#555\\],
    .dark .text-\\[\\#666\\],
    .dark .text-\\[\\#666666\\] { color: #c0c0c0 !important; }
    .dark .text-gray-600 { color: #b0b0b0 !important; }
    .dark .text-gray-500 { color: #909090 !important; }
    .dark .text-gray-400,
    .dark .text-\\[\\#999\\],
    .dark .text-\\[\\#999999\\] { color: #808080 !important; }
    .dark .text-gray-300 { color: #606060 !important; }

    .dark .border-gray-50,
    .dark .border-gray-100,
    .dark .border-gray-200,
    .dark .border-\\[\\#eee\\],
    .dark .border-\\[\\#e5e7eb\\],
    .dark .border-\\[\\#e2e8f0\\] { border-color: #2a2a4a !important; }

    .dark .shadow-sm,
    .dark .shadow,
    .dark .shadow-md,
    .dark .shadow-\\[0_1px_4px_rgba\\(0\\,0\\,0\\,0\\.04\\)\\],
    .dark .shadow-\\[0_2px_8px_rgba\\(0\\,0\\,0\\,0\\.08\\)\\],
    .dark .shadow-\\[0_1px_2px_rgba\\(0\\,0\\,0\\,0\\.05\\)\\] { box-shadow: 0 1px 4px rgba(0,0,0,0.4) !important; }

    .dark input, .dark textarea, .dark select { color: #e0e0e0 !important; background: #1a1a2e !important; }
    .dark input::placeholder, .dark textarea::placeholder { color: #707070 !important; }
    .dark input:focus, .dark textarea:focus, .dark select:focus { border-color: #FF4757 !important; outline: none !important; }
    .dark .el-input__inner, .dark .el-input__wrapper { background: #1a1a2e !important; color: #e0e0e0 !important; }
    .dark .el-select .el-input__inner { background: #1a1a2e !important; }
    .dark .el-select-dropdown { background: #1a1a2e !important; }
    .dark .el-select-dropdown__item { color: #e0e0e0 !important; }
    .dark .el-select-dropdown__item.hover, .dark .el-select-dropdown__item:hover { background: #252540 !important; }
    .dark .el-switch.is-checked .el-switch__core { border-color: #FF4757 !important; background: #FF4757 !important; }
    .dark .el-dialog { background: #1a1a2e !important; }
    .dark .el-dialog__title { color: #e0e0e0 !important; }
    .dark .el-message-box { background: #1a1a2e !important; }
    .dark .el-message-box__title { color: #e0e0e0 !important; }
    .dark .el-message-box__message { color: #b0b0b0 !important; }
    .dark .el-radio__label { color: #b0b0b0 !important; }

    .dark .divide-gray-100 > * + *,
    .dark .divide-gray-200 > * + * { border-color: #2a2a4a !important; }

    .dark .bg-\\[\\#E5E5E5\\],
    .dark .bg-\\[\\#EDEDED\\],
    .dark .bg-\\[\\#F0F0F0\\],
    .dark .bg-\\[\\#F5F6FA\\] { background: #1a1a2e !important; }
    .dark .bg-\\[\\#E8F8F8\\] { background: #1a2828 !important; }
    .dark .bg-\\[\\#ECFDF5\\],
    .dark .bg-\\[\\#ecfdf5\\] { background: #1a2820 !important; }
    .dark .bg-\\[\\#EEF2FF\\],
    .dark .bg-\\[\\#f0f9ff\\] { background: #1a2030 !important; }
    .dark .bg-\\[\\#FCE4EC\\],
    .dark .bg-\\[\\#FEE2E2\\],
    .dark .bg-\\[\\#FEF2F2\\],
    .dark .bg-\\[\\#fef0f0\\],
    .dark .bg-\\[\\#fef2f2\\] { background: #2a1e20 !important; }
    .dark .bg-\\[\\#FFE5E5\\],
    .dark .bg-\\[\\#FFF0EF\\] { background: #2a1e22 !important; }
    .dark .bg-\\[\\#fdf2f8\\] { background: #2a1e26 !important; }
    .dark .bg-\\[\\#f5f3ff\\] { background: #1e1a2a !important; }
    .dark .bg-\\[\\#fffbeb\\] { background: #2a2a1e !important; }
    .dark .bg-\\[\\#FFF7ED\\] { background: #2a241e !important; }
    .dark .bg-\\[\\#f3f4f6\\] { background: #222236 !important; }
    .dark .bg-\\[\\#6b7280\\] { background: #3a3a55 !important; }
    .dark .bg-\\[\\#222\\] { background: #2a2a44 !important; }

    .dark .text-\\[\\#111\\],
    .dark .text-\\[\\#222\\] { color: #d0d0d0 !important; }

    .dark .border-\\[\\#E5E7EB\\],
    .dark .border-\\[\\#F0F0F0\\],
    .dark .border-\\[\\#F8F8F8\\],
    .dark .border-\\[\\#d1d5db\\] { border-color: #2a2a4a !important; }

    .dark [style*="background: #fff"],
    .dark [style*="background:#fff"],
    .dark [style*="background: #ffffff"],
    .dark [style*="background:#ffffff"],
    .dark [style*="background: #FFF"],
    .dark [style*="background: rgb(255, 255, 255)"],
    .dark [style*="background:rgb(255, 255, 255)"] { background: #1a1a2e !important; }

    .dark [style*="background: #f3f4f6"],
    .dark [style*="background:#f3f4f6"],
    .dark [style*="background: #f9fafb"],
    .dark [style*="background:#f9fafb"],
    .dark [style*="background: #f5f5f5"],
    .dark [style*="background:#f5f5f5"],
    .dark [style*="background: #EEE"],
    .dark [style*="background:#EEE"],
    .dark [style*="background: #eee"] { background: #111118 !important; }

    .dark [style*="background: #e5e7eb"],
    .dark [style*="background:#e5e7eb"] { background: #242436 !important; }

    .dark [style*="background: #dcfce7"],
    .dark [style*="background:#dcfce7"],
    .dark [style*="background: #ecfdf5"],
    .dark [style*="background:#ecfdf5"] { background: #1a281a !important; }

    .dark [style*="background: #dbeafe"],
    .dark [style*="background:#dbeafe"] { background: #1a1a30 !important; }

    .dark [style*="background: #f3e8ff"],
    .dark [style*="background:#f3e8ff"] { background: #1e1a2a !important; }

    .dark [style*="background: #e6f9f6"],
    .dark [style*="background:#e6f9f6"] { background: #1a2828 !important; }

    .dark [style*="color: #374151"],
    .dark [style*="color:#374151"],
    .dark [style*="color: #1f2937"],
    .dark [style*="color:#1f2937"],
    .dark [style*="color: #111827"],
    .dark [style*="color:#111827"] { color: #e0e0e0 !important; }

    .dark [style*="color: #6b7280"],
    .dark [style*="color:#6b7280"],
    .dark [style*="color: #999"],
    .dark [style*="color:#999"],
    .dark [style*="color: #9ca3af"],
    .dark [style*="color:#9ca3af"],
    .dark [style*="color: #d1d5db"],
    .dark [style*="color:#d1d5db"] { color: #707070 !important; }

    .dark [style*="border-top: 1px solid #f3f4f6"],
    .dark [style*="border-bottom: 1px solid #f3f4f6"],
    .dark [style*="border: 1px solid #e5e7eb"],
    .dark [style*="border:1px solid #e5e7eb"],
    .dark [style*="border: 1px solid #eee"],
    .dark [style*="border-bottom: 1px solid #f9fafb"] { border-color: #2a2a4a !important; }

    .dark .post-card, .dark .mall-card, .dark .search-pill, .dark .search-panel,
    .dark .back-top, .dark .dropdown-menu, .dark .sidebar-item.active,
    .dark .banner-install, .dark .app-card { background: #1a1a2e !important; }
    .dark .post-card:active { background: #1a1a2e !important; }
    .dark .search-bar, .dark .mall-cat-pill, .dark .mall-sub-item,
    .dark .list-tag, .dark .mall-card-img-wrap, .dark .post-resource,
    .dark .dropdown-item:hover, .dark .mall-search-box { background: #111118 !important; }
    .dark .update-btn, .dark .install-btn, .dark .dropdown-item.active { background: #1a2030 !important; }
    .dark .post-verified { background: #1a281a !important; }
    .dark .post-badge-essence { background: #2d1b1b !important; }
    .dark .post-badge-hot { background: #2d1b1b !important; }
    .dark .post-badge-custom { background: #2d2222 !important; }
    .dark .post-tag { background: #1a1a30 !important; }
    .dark .mall-card-tag:first-child { background: #2d221a !important; }
    .dark .mall-card-tag:nth-child(2) { background: #1e1a2a !important; }
    .dark .mall-card-tag:nth-child(3) { background: #1a2820 !important; }
    .dark .rank-badge-pin, .dark .rank-badge-feat { background: #2d281a !important; }
    .dark .rank-badge-official { background: #1a1a30 !important; }
    .dark .mall-sub-item.on, .dark .mall-sort-item.on { background: #2d1b1b !important; }

    .dark .post-title, .dark .list-title, .dark .section-title,
    .dark .channel-item.active, .dark .search-field, .dark .main-tab.active,
    .dark .filter-dropdown, .dark .dropdown-item, .dark .app-name { color: #e0e0e0 !important; }
    .dark .post-username, .dark .grid-name, .dark .mall-card-name { color: #d0d0d0 !important; }
    .dark .post-resource-title { color: #c0c0c0 !important; }
    .dark .channel-item, .dark .list-tag, .dark .main-tab { color: #909090 !important; }
    .dark .list-desc, .dark .search-hint, .dark .search-lens,
    .dark .sidebar-item, .dark .rank-num, .dark .loading, .dark .empty,
    .dark .mall-sort-item { color: #707070 !important; }
    .dark .mall-cat-pill { color: #909090 !important; }
    .dark .mall-sub-item { color: #808080 !important; }
    .dark .post-content, .dark .post-device, .dark .post-stats,
    .dark .app-desc, .dark .app-meta { color: #808080 !important; }
    .dark .mall-card-original { color: #666666 !important; }
    .dark .post-meta-dot { color: #555555 !important; }
    .dark .mall-card-sold, .dark .mall-count, .dark .mall-search-placeholder,
    .dark .mall-empty span { color: #666666 !important; }
    .dark .meta-sep { color: #505050 !important; }

    .dark .mall-sort-row { border-color: #2a2a4a !important; }
    .dark .list-card { border-color: rgba(255,255,255,0.06) !important; }
    .dark .post-resource { border-color: #2a2a4a !important; }
    .dark .rank-row { border-color: #2a2a4a !important; }

    .dark .search-page { background: #1a1a2e !important; }
    .dark .topbar { background: #1a1a2e !important; border-bottom-color: #2a2a4a !important; }
    .dark .tb-back { background: #111118 !important; color: #e0e0e0 !important; }
    .dark .tb-input-wrap { background: #111118 !important; }
    .dark svg.tb-search-icon { stroke: #707070 !important; color: #707070 !important; }
    .dark .tb-input { color: #e0e0e0 !important; }
    .dark .tb-input::placeholder { color: #707070 !important; }
    .dark .tb-clear { background: #333 !important; color: #aaa !important; }
    .dark .tabs { border-bottom-color: #2a2a4a !important; }
    .dark .tab-item { color: #707070 !important; }
    .dark .tab-item.active { color: #6366f1 !important; }
    .dark .empty-state { color: #666 !important; }
    .dark .empty-icon { color: #555 !important; }
    .dark .post-detail-page, .dark .search-page, .dark .editor-root { background: #1a1a2e !important; }
    .dark .reply-input, .dark .replies-wrap, .dark .action-input,
    .dark .tb-input-wrap, .dark .comment-bottom-trigger,
    .dark .post-body :deep(blockquote), .dark .block-attachment-card,
    .dark .comment-dialog-textarea, .dark .pb-pwd-input { background: #111118 !important; }
    .dark .tb-clear, .dark .doc-editor .ql-toolbar, .dark .post-item:active { background: #252540 !important; }

    .dark .nav-name, .dark .post-detail-page .post-title,
    .dark .info-label, .dark .download-heading, .dark .dm-title,
    .dark .comment-dialog-title, .dark .mp-title, .dark .mp-hd,
    .dark .report-header, .dark .batt-name { color: #e0e0e0 !important; }
    .dark .nav-time, .dark .comment-time, .dark .reply-time,
    .dark .download-hint, .dark .bac-desc, .dark .reply-cancel,
    .dark .action-input-text, .dark .tb-input::placeholder,
    .dark .comment-bottom-placeholder, .dark .reply-input::placeholder,
    .dark .comments-empty span, .dark .empty-text, .dark .download-desc { color: #808080 !important; }
    .dark .comment-content, .dark .info-value, .dark .download-btn,
    .dark .reply-send, .dark .menu-item, .dark .dm-amt-btn,
    .dark .report-type-item, .dark .comment-menu-item,
    .dark .reply-content, .dark .bac-title, .dark .extract-val,
    .dark .bac-app-name, .dark .donate-name, .dark .dm-custom-input { color: #c0c0c0 !important; }
    .dark .sort-btn, .dark .comment-act, .dark .reward-info,
    .dark .donate-unit, .dark .bp-meta, .dark .report-close,
    .dark .mp-x, .dark .action-icon-btn svg, .dark .action-icon-count,
    .dark .action-btn, .dark .reward-avatar-more, .dark .dm-close,
    .dark .comment-dialog-close, .dark .appsel-close { color: #707070 !important; }
    .dark .post-body { color: #d0d0d0 !important; }

    .dark .topbar, .dark .tabs, .dark .comment-bottom-bar,
    .dark .comment-dialog-header, .dark .comment-dialog-footer,
    .dark .mp-hd, .dark .mp-ft, .dark .post-action-bar,
    .dark .comment-item + .comment-item, .dark .reply-item + .reply-item,
    .dark .post-item, .dark .donate-item, .dark .comment-item.pinned,
    .dark .post-body :deep(hr) { border-color: #2a2a4a !important; }

    .dark .spinner { border-color: #2a2a4a !important; border-top-color: #6366f1 !important; }
    .dark .reply-send, .dark .dm-type-tab.active, .dark .mp-ok,
    .dark .attach-btn-copy, .dark .tb-search-btn { background: #6366f1 !important; color: #fff !important; }
    .dark .comment-dialog-cancel, .dark .attach-btn-close,
    .dark .report-cancel, .dark .dm-cancel, .dark .mp-item { background: #111118 !important; color: #808080 !important; }
    .dark .confirm-btn.cancel, .dark .dm-type-item { background: #1a1a2e !important; color: #909090 !important; }
    .dark .tag-pill { background: #1a1a30 !important; color: #909090 !important; }
    .dark .block-attachment-card:hover, .dark .post-resource:active { background: #252540 !important; }
  `
  document.head.appendChild(style)
}

function removeFallbackDark() {
  const el = document.getElementById(FALLBACK_DARK_ID)
  if (el) el.remove()
  if ((window as any).__darkStyleObserver) {
    (window as any).__darkStyleObserver.disconnect()
    delete (window as any).__darkStyleObserver
  }
}

function hasActiveThemeVars(): boolean {
  const darkStyle = document.getElementById('theme-dark-vars')
  if (!darkStyle || !darkStyle.textContent) return false
  return darkStyle.textContent.replace('.dark {', '').replace('}', '').trim().length > 0
}

function detectDevice(): 'pc' | 'mobile' {
  const ua = navigator.userAgent.toLowerCase()
  if (/mobile|android|iphone|ipad|ipod|blackberry|iemobile|opera mini|webos/.test(ua)) {
    return 'mobile'
  }
  return 'pc'
}

function injectCSSVars(tokens: ThemeTokenSet) {
  const root = document.documentElement
  for (const [tokenKey, cssVar] of Object.entries(TOKEN_CSS_MAP)) {
    if (tokens[tokenKey] !== undefined) {
      root.style.setProperty(cssVar, tokens[tokenKey])
    }
  }
}

function injectDarkStyle(varsDark: ThemeTokenSet) {
  const id = 'theme-dark-vars'
  let styleEl = document.getElementById(id) as HTMLStyleElement | null
  if (!styleEl) {
    styleEl = document.createElement('style')
    styleEl.id = id
    document.head.appendChild(styleEl)
  }
  let css = '.dark {\n'
  for (const [tokenKey, cssVar] of Object.entries(TOKEN_CSS_MAP)) {
    if (varsDark[tokenKey] !== undefined) {
      css += `  ${cssVar}: ${varsDark[tokenKey]};\n`
    }
  }
  css += '}'
  styleEl.textContent = css
}

export function applyThemeTokens(vars: ThemeTokenSet, varsDark: ThemeTokenSet) {
  injectCSSVars(vars)
  injectDarkStyle(varsDark)
}

function applyThemeByDevice(data: { vars: ThemeTokenSet; varsDark: ThemeTokenSet; varsMobile: ThemeTokenSet; varsMobileDark: ThemeTokenSet; device?: string }) {
  const device = data.device || detectDevice()
  if (device === 'mobile') {
    applyThemeTokens(data.varsMobile, data.varsMobileDark)
  } else {
    applyThemeTokens(data.vars, data.varsDark)
  }
}

const DEFAULT_TOKENS: ThemeTokenSet = {
  mainColor: '#FF4757',
  primary: '#FF4757',
  secondary: '#6366F1',
  gray100: '#f3f4f6',
  gray200: '#e5e7eb',
  gray300: '#d1d5db',
  gray400: '#9ca3af',
  gray500: '#6b7280',
  gray600: '#4b5563',
  gray700: '#374151',
  gray800: '#1f2937',
  gray900: '#111827',
  bgColor: '#fafbfc',
  boxColor: '#ffffff',
  hoverColor: '#f3f4f6',
  activeColor: '#e5e7eb',
  elActiveColor: '#FF4757',
  defaultBorder: '#e5e7eb',
  dashedBorder: '#d1d5db',
  cardBorder: '#e5e7eb',
  error: '#ef4444',
  info: '#3b82f6',
  success: '#22c55e',
  warning: '#f59e0b',
  danger: '#ef4444',
  borderRadius: '8px',
  shadowColor: 'rgba(0,0,0,0.08)',
  fontFamily: 'inherit'
}

const DEFAULT_TOKENS_DARK: ThemeTokenSet = {
  mainColor: '#FF4757',
  primary: '#FF4757',
  secondary: '#818CF8',
  gray100: '#1f2937',
  gray200: '#374151',
  gray300: '#4b5563',
  gray400: '#6b7280',
  gray500: '#9ca3af',
  gray600: '#d1d5db',
  gray700: '#e5e7eb',
  gray800: '#f3f4f6',
  gray900: '#f9fafb',
  bgColor: '#0f0f1a',
  boxColor: '#1a1a2e',
  hoverColor: '#252540',
  activeColor: '#2a2a4a',
  elActiveColor: '#FF4757',
  defaultBorder: '#2a2a4a',
  dashedBorder: '#2a2a4a',
  cardBorder: '#2a2a4a',
  error: '#f87171',
  info: '#60a5fa',
  success: '#4ade80',
  warning: '#fbbf24',
  danger: '#f87171',
  borderRadius: '8px',
  shadowColor: 'rgba(0,0,0,0.3)',
  fontFamily: 'inherit'
}

export async function fetchAndApplyTheme(): Promise<void> {
  try {
    const device = detectDevice()
    if (device === 'mobile') {
      applyThemeTokens(DEFAULT_TOKENS, DEFAULT_TOKENS_DARK)
    } else {
      applyThemeTokens(DEFAULT_TOKENS, DEFAULT_TOKENS_DARK)
    }
    localStorage.setItem(THEME_CACHE_KEY, JSON.stringify({
      vars: DEFAULT_TOKENS,
      varsDark: DEFAULT_TOKENS_DARK,
      varsMobile: DEFAULT_TOKENS,
      varsMobileDark: DEFAULT_TOKENS_DARK
    }))
  } catch {}
}

export function useTheme() {
  const settingStore = useSettingStore()

  // 禁用过渡效果
  const disableTransitions = () => {
    const style = document.createElement('style')
    style.setAttribute('id', 'disable-transitions')
    style.textContent = '* { transition: none !important; }'
    document.head.appendChild(style)
  }

  // 启用过渡效果
  const enableTransitions = () => {
    const style = document.getElementById('disable-transitions')
    if (style) {
      style.remove()
    }
  }

  // 设置系统主题
  const setSystemTheme = (theme: SystemThemeEnum, themeMode?: SystemThemeEnum) => {
    // 临时禁用过渡效果
    disableTransitions()

    const el = document.getElementsByTagName('html')[0]
    const isDark = theme === SystemThemeEnum.DARK
    if (!themeMode) { themeMode = theme }
    const currentTheme = AppConfig.systemThemeStyles[theme as keyof SystemThemeTypes]
    if (currentTheme) {
      el.setAttribute('class', currentTheme.className)
    }

    // 设置按钮颜色加深或变浅
    const primary = settingStore.systemThemeColor

    for (let i = 1; i <= 9; i++) {
      document.documentElement.style.setProperty(
        `--el-color-primary-light-${i}`,
        isDark ? `${getDarkColor(primary, i / 10)}` : `${getLightColor(primary, i / 10)}`
      )
    }

    // 更新store中的主题设置
    settingStore.setGlopTheme(theme, themeMode)

    // 使用 requestAnimationFrame 确保在下一帧恢复过渡效果
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        enableTransitions()
      })
    })
  }

  // 使用 VueUse 的 usePreferredDark 检测系统主题偏好
  const prefersDark = usePreferredDark()

  // 自动设置系统主题
  const setSystemAutoTheme = () => {
    const theme = prefersDark.value ? SystemThemeEnum.DARK : SystemThemeEnum.LIGHT
    setSystemTheme(theme, SystemThemeEnum.AUTO)
  }

  // 切换主题
  const switchThemeStyles = (theme: SystemThemeEnum) => {
    if (theme === SystemThemeEnum.AUTO) {
      setSystemAutoTheme()
    } else {
      setSystemTheme(theme)
    }
  }

  return {
    setSystemTheme,
    setSystemAutoTheme,
    switchThemeStyles,
    prefersDark
  }
}

/**
 * 初始化主题系统
 * 1. 从服务端获取管理员激活的主题令牌
 * 2. 应用暗色/亮色模式
 */
export async function initializeTheme() {
  await fetchAndApplyTheme()

  const settingStore = useSettingStore()
  const prefersDark = usePreferredDark()

  try {
    const stored = localStorage.getItem(SITE_THEME_KEY)
    if (stored && ['light', 'dark', 'auto'].includes(stored)) {
      settingStore.systemThemeMode = stored as SystemThemeEnum
    } else {
      const resp = await fetch('/api/sys-config/public/site_theme_mode')
      const json = await resp.json()
      if (json?.data && ['light', 'dark', 'auto'].includes(json.data)) {
        settingStore.systemThemeMode = json.data as SystemThemeEnum
        localStorage.setItem(SITE_THEME_KEY, json.data)
      }
    }
  } catch {}

  const mode = settingStore.systemThemeMode
  if (mode === SystemThemeEnum.DARK || mode === SystemThemeEnum.AUTO) {
    injectFallbackDark()
  }

  const applyThemeByMode = () => {
    const el = document.getElementsByTagName('html')[0]
    const mode = settingStore.systemThemeMode
    let actualTheme = mode

    if (mode === SystemThemeEnum.AUTO) {
      actualTheme = prefersDark.value ? SystemThemeEnum.DARK : SystemThemeEnum.LIGHT
    }

    const currentTheme = AppConfig.systemThemeStyles[actualTheme as keyof SystemThemeTypes]
    if (currentTheme) {
      el.setAttribute('class', currentTheme.className)
    }

    setElementThemeColor(settingStore.systemThemeColor)
  }

  applyThemeByMode()

  if (settingStore.systemThemeMode === SystemThemeEnum.AUTO) {
    watch(
      prefersDark,
      () => {
        if (settingStore.systemThemeMode === SystemThemeEnum.AUTO) {
          applyThemeByMode()
        }
      },
      { immediate: false }
    )
  }
}
