import { fetchPluginInject } from '@/api/operation'

interface PluginResource {
  id: number
  name: string
  version: string
  config?: Record<string, any> | null
  styles: string[]
  scripts: string[]
}

interface FrontendExtras {
  slots: Array<{ name: string; script: string; style?: string; mount?: string; pluginName: string }>
  menus: { adminSidebar: any[]; userDropdown: any[] }
  dashboardWidgets: any[]
  i18nBundles: any[]
  globalStyles: string[]
}

const injectedElements: { style: HTMLStyleElement[]; script: HTMLScriptElement[] } = {
  style: [],
  script: []
}

function removeInjected() {
  injectedElements.style.forEach(el => el.remove())
  injectedElements.script.forEach(el => el.remove())
  injectedElements.style = []
  injectedElements.script = []
}

function injectStyles(cssList: string[], pluginName: string) {
  for (const css of cssList) {
    if (!css || !css.trim()) continue
    const style = document.createElement('style')
    style.setAttribute('data-plugin', pluginName)
    style.textContent = css
    document.head.appendChild(style)
    injectedElements.style.push(style)
  }
}

function injectScripts(jsList: string[], pluginName: string) {
  for (const js of jsList) {
    if (!js || !js.trim()) continue
    const script = document.createElement('script')
    script.setAttribute('data-plugin', pluginName)
    script.textContent = js
    document.head.appendChild(script)
    injectedElements.script.push(script)
  }
}

function injectConfig(plugins: PluginResource[]) {
  const cfg: Record<string, any> = {}
  for (const plugin of plugins) {
    if (plugin.config) {
      cfg[plugin.name] = plugin.config
    }
  }
  ;(window as any).__PLUGIN_CONFIG__ = cfg
}

function injectFrontendExtras(extras: FrontendExtras) {
  if (!extras) return

  // 注入全局样式
  if (extras.globalStyles && extras.globalStyles.length > 0) {
    const style = document.createElement('style')
    style.setAttribute('data-plugin', 'global')
    style.textContent = extras.globalStyles.join('\n')
    document.head.appendChild(style)
    injectedElements.style.push(style)
  }

  // 注入 i18n
  if (extras.i18nBundles && extras.i18nBundles.length > 0) {
    const i18n: Record<string, Record<string, Record<string, string>>> = {}
    for (const bundle of extras.i18nBundles) {
      i18n[bundle.name] = bundle.messages || {}
    }
    ;(window as any).__PLUGIN_I18N__ = i18n
  }

  // 注入 slots 脚本（延迟执行，等 Vue 渲染完成后挂载）
  if (extras.slots && extras.slots.length > 0) {
    ;(window as any).__PLUGIN_SLOTS__ = extras.slots.reduce((acc: any, slot) => {
      acc[slot.name] = slot
      return acc
    }, {})
  }

  // 注入 menus
  ;(window as any).__PLUGIN_MENUS__ = extras.menus || { adminSidebar: [], userDropdown: [] }

  // 注入 dashboard widgets
  ;(window as any).__PLUGIN_DASHBOARD_WIDGETS__ = extras.dashboardWidgets || []
}

/**
 * 执行插槽脚本 — 由 App.vue 在路由切换后调用
 */
function executeSlots() {
  const slots = (window as any).__PLUGIN_SLOTS__
  if (!slots) return

  for (const [slotName, slot] of Object.entries(slots) as [string, any][]) {
    if (!slot.script || document.querySelector(`[data-plugin-slot="${slotName}"]`)) continue
    try {
      const fn = new Function(slot.script)
      fn()
    } catch (e) {
      console.error(`[Plugin] 插槽 "${slotName}" 执行出错:`, e)
    }
  }
}

let injected = false

export function usePluginInject() {
  async function loadPlugins() {
    if (injected) return
    try {
      const response = await fetchPluginInject() as any
      const plugins: PluginResource[] = response?.data || response || []
      const frontendExtras: FrontendExtras = response?.frontend || {}

      if (!plugins || plugins.length === 0) {
        // 即使没有插件也可能有 frontend extras
        injectFrontendExtras(frontendExtras)
        injected = true
        return
      }

      removeInjected()
      injectConfig(plugins)
      injectFrontendExtras(frontendExtras)

      for (const plugin of plugins) {
        if (plugin.styles && plugin.styles.length > 0) {
          injectStyles(plugin.styles, plugin.name)
        }
        if (plugin.scripts && plugin.scripts.length > 0) {
          injectScripts(plugin.scripts, plugin.name)
        }
      }

      injected = true

      // 延迟执行插槽脚本
      setTimeout(() => executeSlots(), 500)
    } catch {
      injected = true
    }
  }

  function refreshPlugins() {
    injected = false
    removeInjected()
    return loadPlugins()
  }

  return { loadPlugins, refreshPlugins, executeSlots }
}
