import request from '@/utils/http'

export { fetchLogin, fetchGetUserInfo } from './auth'

export interface AppItem {
  id: number
  name: string
  packageName: string
  version: string
  versionCode: string
  icon: string
  iconBgColor: string
  sizeMb: number
  downloads: number
  rating: number
  description: string
  updateContent: string
  screenshots: Array<{ image: string; text: string; bgColor: string }>
  tags: string[]
  downloadUrl: string
  coinCount: number
  coinPeople: number
  developer: string
  category: string
  categoryId: number
  isPinned: number
  status: string
  createTime: string
  updateTime: string
}

export interface CommentItem {
  id: number
  appId: number
  userId: number
  userName: string
  userAvatar: string
  device: string
  version: string
  content: string
  likes: number
  replies: number
  rating: number
  createTime: string
}

export interface TipItem {
  id: number
  appId: number
  userId: number
  userName: string
  amount: number
  tipType: string
  message: string
  createTime: string
}

export interface CategoryItem {
  id: number
  name: string
  icon: string
  sortOrder: number
  status: string
  createTime: string
}

export interface AppVersion {
  id: number
  appId: number
  version: string
  versionCode: string
  sizeMb: number
  downloads: number
  rating: number
  updateContent: string
  tags: string[]
  downloadUrl: string
  isCurrent: boolean
  userId: number
  userName: string
  createTime: string
}

export function fetchAppList(params: Record<string, unknown>) {
  return request.get({ url: '/api/app/list', params })
}

export function fetchHotToday(limit?: number) {
  return request.get({ url: '/api/app/hot-today', params: { limit } })
}

export function fetchTrendingWeek(limit?: number) {
  return request.get({ url: '/api/app/trending-week', params: { limit } })
}

export function fetchSaveApp(params: Record<string, unknown>) {
  return request.post({ url: '/api/app/save', data: params })
}

export function fetchDeleteApp(id: number) {
  return request.del({ url: `/api/app/${id}` })
}

export function fetchAppDetail(id: number, userId?: number) {
  const q = userId ? `?userId=${userId}` : ''
  return request.get({ url: `/api/app/${id}/detail${q}` })
}

export function fetchPostComment(appId: number, params: Record<string, unknown>) {
  return request.post({ url: `/api/app/${appId}/comment`, data: params })
}

export function fetchCommentLike(appId: number, cid: number, userId: number) {
  return request.post({ url: `/api/app/${appId}/comment/${cid}/like`, data: { userId } })
}

export function fetchDeleteComment(appId: number, cid: number, userId: number) {
  return request.del({ url: `/api/app/${appId}/comment/${cid}?userId=${userId}` })
}

export function fetchReportComment(appId: number, cid: number, userId: number, reason: string) {
  return request.post({ url: `/api/app/${appId}/comment/${cid}/report`, data: { userId, reason } })
}

export function fetchReplyComment(appId: number, cid: number, params: Record<string, unknown>) {
  return request.post({ url: `/api/app/${appId}/comment/${cid}/reply`, data: params })
}

export function fetchPinComment(appId: number, cid: number, userId: number) {
  return request.post({ url: `/api/app/${appId}/comment/${cid}/pin`, data: { userId } })
}

export function fetchAppVersions(appId: number) {
  return request.get({ url: `/api/app/${appId}/versions` })
}

export function fetchSaveVersion(params: Record<string, unknown>) {
  return request.post({ url: '/api/app/version/save', data: params })
}

export function fetchDeleteVersion(id: number) {
  return request.del({ url: `/api/app/version/${id}` })
}

export function fetchUploadApp(params: Record<string, unknown>) {
  return request.post({ url: '/api/app/upload', data: params })
}

export function fetchUploads(params?: Record<string, unknown>) {
  return request.get({ url: '/api/app/uploads', data: params })
}

export function fetchRecommendApps() {
  return request.get({ url: '/api/app/recommend' })
}

export function fetchCategoryList() {
  return request.get({ url: '/api/category/list' })
}

export function fetchSaveCategory(params: Record<string, unknown>) {
  return request.post({ url: '/api/category/save', data: params })
}

export function fetchDeleteCategory(id: number) {
  return request.del({ url: `/api/category/${id}` })
}

export function fetchPostTip(appId: number, params: Record<string, unknown>) {
  return request.post({ url: `/api/app/${appId}/tip`, data: params })
}

export function fetchAppTips(appId: number) {
  return request.get({ url: `/api/app/${appId}/tips` })
}

export function fetchAdminDeleteComment(id: number) {
  return request.del({ url: `/api/app/comment/${id}` })
}

export function fetchReportList(params?: Record<string, unknown>) {
  return request.get({ url: '/api/app/reports', data: params })
}

export function fetchIgnoreReport(id: number) {
  return request.post({ url: `/api/app/comment/${id}/ignore` })
}

export function fetchPinApp(appId: number, pinned: boolean) {
  return request.post({ url: `/api/app/${appId}/pin`, data: { pinned } })
}

export function fetchToggleOfficial(appId: number, isOfficial: boolean) {
  return request.post({ url: `/api/app/${appId}/official`, data: { isOfficial } })
}

export function fetchToggleFeatured(appId: number, isFeatured: boolean) {
  return request.post({ url: `/api/app/${appId}/featured`, data: { isFeatured } })
}

export function fetchRedeemCardKey(params: Record<string, unknown>) {
  return request.post({ url: '/api/cardkey/redeem', data: params })
}

export function fetchOfficialTags() {
  return request.get({ url: '/api/official-tags/list' })
}

export function fetchSaveOfficialTag(params: Record<string, unknown>) {
  return request.post({ url: '/api/official-tags/save', data: params })
}

export function fetchDeleteOfficialTag(id: number) {
  return request.del({ url: `/api/official-tags/${id}` })
}

export function uploadApk(formData: FormData) {
  return request.post({ url: '/api/upload/apk', data: formData })
}

export function fetchPurchaseApp(appId: number, userId: number, priceType?: string, couponId?: number) {
  return request.post({ url: `/api/app/${appId}/purchase`, data: { userId, priceType, couponId: couponId || 0 } })
}

export function fetchPurchaseStatus(appId: number, userId: number) {
  return request.get({ url: `/api/app/${appId}/purchase-status`, params: { userId } })
}

export function fetchPurchasers(appId: number) {
  return request.get({ url: `/api/app/${appId}/purchasers` })
}

export function fetchMembershipProducts() {
  return request.get({ url: '/api/membership/products' })
}

export function fetchBuyMembership(productId: number, payType?: string, couponId?: number) {
  return request.post({ url: '/api/membership/buy', data: { productId, payType: payType || 'balance', couponId: couponId || 0 } })
}

export function fetchPublicApps() {
  return request.get({ url: '/api/app/public' })
}
