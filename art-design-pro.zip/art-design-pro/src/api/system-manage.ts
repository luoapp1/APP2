import request from '@/utils/http'
import { AppRouteRecord } from '@/types/router'

export function fetchGetUserList(params: Api.SystemManage.UserSearchParams) {
  return request.get<Api.SystemManage.UserList>({
    url: '/api/user/list',
    params
  })
}

export function fetchCreateUser(params: Record<string, unknown>) {
  return request.post({
    url: '/api/user/create',
    data: params
  })
}

export function fetchUpdateUser(params: Record<string, unknown>) {
  return request.post({
    url: '/api/user/update',
    data: params
  })
}

export function fetchDeleteUser(id: number) {
  return request.del({
    url: `/api/user/${id}`
  })
}

export function fetchGetRoleList(params: Api.SystemManage.RoleSearchParams) {
  return request.get<Api.SystemManage.RoleList>({
    url: '/api/role/list',
    params
  })
}

export function fetchSaveRole(params: Record<string, unknown>) {
  return request.post({
    url: '/api/role/save',
    data: params
  })
}

export function fetchDeleteRole(id: number) {
  return request.del({
    url: `/api/role/${id}`
  })
}

export function fetchGetMenuList() {
  return request.get<AppRouteRecord[]>({
    url: '/api/v3/system/menus/simple'
  })
}

export function fetchGetMenuFlatList() {
  return request.get({
    url: '/api/menu/list'
  })
}

export function fetchSaveMenu(params: Record<string, unknown>) {
  return request.post({
    url: '/api/menu/save',
    data: params
  })
}

export function fetchDeleteMenu(id: number) {
  return request.del({
    url: `/api/menu/${id}`
  })
}

export function fetchGetRolePermissions(roleId: number) {
  return request.get({
    url: `/api/role/${roleId}/permissions`
  })
}

export function fetchSaveRolePermissions(roleId: number, menuIds: number[]) {
  return request.post({
    url: `/api/role/${roleId}/permissions`,
    data: { menuIds }
  })
}

export function fetchLogin(username: string, password: string) {
  return request.post({
    url: '/api/auth/login',
    data: { username, password }
  })
}

export function fetchUserInfo() {
  return request.get({
    url: '/api/user/info'
  })
}

export function fetchDashboardStats() {
  return request.get({
    url: '/api/dashboard/stats'
  })
}

export function fetchGetSysConfig(key: string) {
  return request.get({
    url: `/api/sys-config/${key}`
  })
}

export function fetchSaveSysConfig(configs: { config_key: string; config_value: string }[]) {
  return request.post({
    url: '/api/sys-config/save',
    data: { configs }
  })
}

export function fetchAdminCenterCards() {
  return request.get<Record<string, { id: number; label: string; bg: string; icon: string; path: string }[]>>({
    url: '/api/menu/admin-center-cards'
  })
}

export function fetchConsoleStats() {
  return request.get({
    url: '/api/admin/console-stats'
  })
}
