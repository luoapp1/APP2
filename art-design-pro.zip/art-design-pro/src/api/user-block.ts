import request from '@/utils/http'

export const blockUser = (userId: number, reason: string) =>
  request.post({ url: `/api/user/${userId}/block`, data: { reason } })

export const unblockUser = (userId: number) =>
  request.del({ url: `/api/user/${userId}/block` })

export const fetchBlockedList = (params?: { page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/blocked', params })

export const fetchBlockStatus = (userId: number) =>
  request.get({ url: `/api/user/block-status/${userId}` })

export const fetchBlockedByStatus = (userId: number) =>
  request.get({ url: `/api/user/${userId}/blocked-by-me` })

export const fetchAdminBlockList = (params?: { status?: string; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/admin/user-blocks', params })

export const adminReviewBlock = (id: number, notes: string) =>
  request.post({ url: `/api/admin/user-blocks/${id}/review`, data: { notes } })
