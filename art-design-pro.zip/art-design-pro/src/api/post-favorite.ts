import request from '@/utils/http'

export const fetchPostFavorites = (userId: number) =>
  request.get({ url: '/post-favorite/list', params: { userId } })

export const togglePostFavorite = (data: { userId: number; postId: number; postTitle?: string }) =>
  request.post({ url: '/post-favorite/toggle', data })

export const checkPostFavorite = (userId: number, postId: number) =>
  request.get({ url: '/post-favorite/check', params: { userId, postId } })
