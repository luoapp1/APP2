import request from '@/utils/http'

export const fetchSystemLogs = (params: any) =>
  request.get({ url: '/api/system-log/list', params })

export const fetchLogStats = () =>
  request.get({ url: '/api/system-log/stats' })

export const fetchLogDetail = (id: number) =>
  request.get({ url: `/api/system-log/${id}` })

export const fetchRestoreMenu = (logId: number) =>
  request.post({ url: `/api/menu/restore/${logId}` })
