import request from '@/utils/http'

export const fetchSystemLogs = (params: any) =>
  request.get({ url: '/system-log/list', params })

export const fetchLogStats = () =>
  request.get({ url: '/system-log/stats' })

export const fetchLogDetail = (id: number) =>
  request.get({ url: `/system-log/${id}` })
