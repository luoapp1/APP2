import request from '@/utils/http'

export const fetchSystemLogs = (params: any) =>
  request.get({ url: '/api/system-log/list', params })

export const fetchLogStats = () =>
  request.get({ url: '/api/system-log/stats' })

export const fetchLogDetail = (id: number) =>
  request.get({ url: `/api/system-log/${id}` })

export const fetchRestoreMenu = (logId: number) =>
  request.post({ url: `/api/menu/restore/${logId}` })

export const fetchLogCategories = () =>
  request.get({ url: '/api/system-log/categories' })

export const saveLogCategory = (key: string, value: boolean) =>
  request.post({ url: '/api/system-log/categories/save', params: { key, value } })
