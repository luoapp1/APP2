import request from '@/utils/http'

export function fetchLayoutThemes() {
  return request.get({ url: '/api/layout-themes' })
}

export function setActiveLayoutTheme(device: string, themeId: string) {
  return request.post({ url: '/api/layout-themes/active', data: { device, themeId } })
}

export function fetchActiveLayoutTheme(device: string) {
  return request.get({ url: `/api/layout-themes/active?device=${device}` })
}
