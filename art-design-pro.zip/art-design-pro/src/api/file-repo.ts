import request from '@/utils/http'

export const fetchFileRepoList = (params?: any) =>
  request.get({ url: '/api/file-repo/list', params })

export const fetchFileRepoCategories = () =>
  request.get({ url: '/api/file-repo/categories' })

export const fetchDeleteFileRepo = (id: number) =>
  request.del({ url: `/api/file-repo/${id}` })

export const fetchRecycleList = (params?: any) =>
  request.get({ url: '/api/recycle/list', params })

export const fetchRecycleRestore = (data: { ids: number[] }) =>
  request.post({ url: '/api/recycle/trash', data })

export const fetchRecycleDelete = (ids: number[]) =>
  request.del({ url: '/api/recycle/delete', data: { ids } })

export const fetchRecycleClear = () =>
  request.post({ url: '/api/recycle/clear' })
