import request from '@/utils/http'

export const fetchFileRepoList = (params?: any) =>
  request.get({ url: '/file-repo/list', params })

export const fetchFileRepoCategories = () =>
  request.get({ url: '/file-repo/categories' })

export const fetchDeleteFileRepo = (id: number) =>
  request.del({ url: `/file-repo/${id}` })

export const fetchRecycleList = (params?: any) =>
  request.get({ url: '/recycle/list', params })

export const fetchRecycleRestore = (data: { ids: number[] }) =>
  request.post({ url: '/recycle/trash', data })

export const fetchRecycleDelete = (ids: number[]) =>
  request.del({ url: '/recycle/delete', data: { ids } })

export const fetchRecycleClear = () =>
  request.post({ url: '/recycle/clear' })
