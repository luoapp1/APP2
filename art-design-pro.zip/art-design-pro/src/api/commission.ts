import request from '@/utils/http'

export const fetchCommissionRules = () =>
  request.get({ url: '/commission/rules' })

export const saveCommissionRule = (data: any) =>
  request.post({ url: '/commission/rule/save', data })

export const deleteCommissionRule = (id: number) =>
  request.post({ url: '/commission/rule/delete', data: { id } })

export const fetchCommissionRecords = (params: any) =>
  request.get({ url: '/commission/records', params })

export const generateReferral = (data?: { mode?: string; discount?: number }) =>
  request.post({ url: '/commission/referral/generate', data })

export const fetchReferral = () =>
  request.get({ url: '/commission/referral' })

export const bindReferral = (code: string) =>
  request.post({ url: '/commission/referral/bind', data: { code } })

export const fetchWithdrawList = (params: any) =>
  request.get({ url: '/commission/withdraw/list', params })

export const applyWithdraw = (data: { amount: number; method?: string; account?: string; realName?: string }) =>
  request.post({ url: '/commission/withdraw/apply', data })

export const reviewWithdraw = (data: { id: number; status: string; remark?: string }) =>
  request.post({ url: '/commission/withdraw/review', data })
