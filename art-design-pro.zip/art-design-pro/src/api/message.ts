import request from '@/utils/http'

export interface NotificationItem {
  id: number
  title: string
  content: string
  type: string
  isRead: number
  createTime: string
}

export interface ConversationItem {
  userId: number
  userName: string
  userAvatar: string
  lastTime: string
  lastContent: string
  unread: number
}

export interface MessageItem {
  id: number
  fromUserId: number
  fromUserName: string
  fromUserAvatar: string
  toUserId: number
  content: string
  isRead: number
  createTime: string
}

export function fetchNotifications(userId: number, page = 1, type?: string) {
  return request.get({ url: '/api/notifications', params: { userId, page, pageSize: 20, ...(type ? { type } : {}) } })
}

export function fetchMarkNotificationsRead(userId: number, type?: string) {
  return request.post({ url: '/api/notifications/read-all', data: { userId, ...(type ? { type } : {}) } })
}

export function fetchConversations(userId: number) {
  return request.get({ url: '/api/messages/conversations', params: { userId } })
}

export function fetchMessages(userId: number, targetUserId: number) {
  return request.get({ url: `/api/messages/${targetUserId}`, params: { userId } })
}

export function fetchSendMessage(userId: number, userName: string, userAvatar: string, targetUserId: number, content: string) {
  return request.post({ url: `/api/messages/${targetUserId}`, data: { userId, userName, userAvatar, content } })
}

export function fetchHideConversation(partnerId: number, userId: number) {
  return request.del({ url: `/api/messages/conversations/${partnerId}`, params: { userId } })
}
