import request from '@/utils/http'

export interface NotificationItem {
  id: number
  title: string
  content: string
  type: string
  isRead: number
  createTime: string
  fromUserId: number
  fromUserName: string
  fromUserAvatar: string
  fromUserRoles: string
  fromUserTitle: string
  fromUserTitleColor: string
  fromUserTitleBg: string
}

export interface ConversationItem {
  userId: number
  userName: string
  userAvatar: string
  lastTime: string
  lastContent: string
  unread: number
}

export interface MessageItem {
  id: number
  fromUserId: number
  fromUserName: string
  fromUserAvatar: string
  toUserId: number
  content: string
  imageUrl?: string
  messageType?: string
  orderCard?: any
  isRead: number
  isRecalled: number
  reportStatus: string
  createTime: string
}

export function fetchNotifications(userId: number, page = 1, type?: string) {
  return request.get({ url: '/api/notifications', params: { userId, page, pageSize: 20, ...(type ? { type } : {}) } })
}

export function fetchMarkNotificationsRead(userId: number, type?: string) {
  return request.post({ url: '/api/notifications/read-all', data: { userId, ...(type ? { type } : {}) } })
}

export function fetchConversations(userId: number) {
  return request.get({ url: '/api/messages/conversations', params: { userId } })
}

export function fetchMessages(userId: number, targetUserId: number) {
  return request.get({ url: `/api/messages/${targetUserId}`, params: { userId } })
}

export function fetchSendMessage(userId: number, userName: string, userAvatar: string, targetUserId: number, content: string, imageUrl?: string, messageType?: string) {
  return request.post({ url: `/api/messages/${targetUserId}`, data: { userId, userName, userAvatar, content, imageUrl, messageType } })
}

export function fetchHideConversation(partnerId: number, userId: number) {
  return request.del({ url: `/api/messages/conversations/${partnerId}`, params: { userId } })
}

export function fetchUploadChatImage(file: File) {
  const formData = new FormData()
  formData.append('file', file)
  return request.post({ url: '/api/messages/upload-image', data: formData, headers: { 'Content-Type': 'multipart/form-data' } })
}

export function fetchRecallMessage(messageId: number, userId: number) {
  return request.put({ url: `/api/messages/${messageId}/recall`, data: { userId } })
}

export function fetchReportMessage(messageId: number, userId: number, reason: string, detail?: string) {
  return request.post({ url: `/api/messages/${messageId}/report`, data: { userId, reason, detail } })
}

export function fetchSearchMessages(userId: number, keyword: string, page = 1, pageSize = 20) {
  return request.get({ url: '/api/messages/search', params: { userId, keyword, page, pageSize } })
}

export function fetchSensitiveWords(page = 1, pageSize = 50) {
  return request.get({ url: '/api/admin/sensitive-words', params: { page, pageSize } })
}

export function fetchAddSensitiveWords(words: string, category?: string) {
  return request.post({ url: '/api/admin/sensitive-words', data: { words, category } })
}

export function fetchUpdateSensitiveWord(id: number, word: string, category?: string, enabled?: number) {
  return request.put({ url: `/api/admin/sensitive-words/${id}`, data: { word, category, enabled } })
}

export function fetchDeleteSensitiveWord(id: number) {
  return request.del({ url: `/api/admin/sensitive-words/${id}` })
}

export function fetchChatReports(page = 1, pageSize = 20, status?: string) {
  return request.get({ url: '/api/admin/chat-reports', params: { page, pageSize, status } })
}

export function fetchHandleChatReport(reportId: number, status: string, handleNotes?: string, handlerId?: number) {
  return request.put({ url: `/api/admin/chat-reports/${reportId}`, data: { status, handleNotes, handlerId } })
}
