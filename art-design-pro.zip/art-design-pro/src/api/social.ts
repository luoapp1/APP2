import request from '@/utils/http'

export const fetchTitleList = (params?: any) =>
  request.get({ url: '/title/list', params })

export const fetchTitleAll = () =>
  request.get({ url: '/title/all' })

export const fetchSaveTitle = (data: any) =>
  request.post({ url: '/title/save', data })

export const fetchDeleteTitle = (id: number) =>
  request.del({ url: `/title/${id}` })

export const fetchGrantTitle = (data: { userId: number; titleId: number; reason?: string }) =>
  request.post({ url: '/title/grant', data })

export const fetchRevokeTitle = (data: { userId: number; titleId: number }) =>
  request.post({ url: '/title/revoke', data })

export const fetchUserTitles = (userId: number) =>
  request.get({ url: '/title/user-titles', params: { userId } })

export const fetchActiveTitle = (titleId: number) =>
  request.post({ url: '/user/active-title', data: { titleId } })
