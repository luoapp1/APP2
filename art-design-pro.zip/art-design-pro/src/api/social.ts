import request from '@/utils/http'

export const fetchTitleList = (params?: any) =>
  request.get({ url: '/api/title/list', params })

export const fetchTitleAll = () =>
  request.get({ url: '/api/title/all' })

export const fetchSaveTitle = (data: any) =>
  request.post({ url: '/api/title/save', data })

export const fetchDeleteTitle = (id: number) =>
  request.del({ url: `/api/title/${id}` })

export const fetchGrantTitle = (userId: number, titleId: number) =>
  request.post({ url: `/api/user/${userId}/grant-title`, data: { titleId } })

export const fetchRevokeTitle = (userId: number, titleId: number) =>
  request.del({ url: `/api/user/${userId}/revoke-title/${titleId}` })

export const fetchUserTitles = (userId: number) =>
  request.get({ url: `/api/title/user/${userId}` })

export const fetchActiveTitle = (titleId: number) =>
  request.post({ url: '/api/user/active-title', data: { titleId } })
