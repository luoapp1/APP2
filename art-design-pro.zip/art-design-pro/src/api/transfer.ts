import request from '@/utils/http'

export const fetchTransferConfig = () =>
  request.get({ url: '/transfer/config' })

export const transferPoints = (data: { fromUserId: number; toUserId: number; amount: number; remark?: string }) =>
  request.post({ url: '/transfer/points', data })

export const transferBalance = (data: { fromUserId: number; toUserId: number; amount: number; remark?: string }) =>
  request.post({ url: '/transfer/balance', data })

export const purchasePoints = (data: { userId: number; amount: number; payMethod?: string }) =>
  request.post({ url: '/transfer/points/purchase', data })

export const fetchTransferRecords = (params: { userId: number; type?: string }) =>
  request.get({ url: '/transfer/records', params })
