import request from '@/utils/http'

export function fetchGetCardKeyList(params: Api.Operation.CardKeySearchParams) {
  return request.get<Api.Operation.CardKeyList>({ url: '/api/operation/cardkey/list', params })
}

export function fetchCreateCardKeys(params: { count: number; type: string; targetId: number; value: number; duration?: number; durationUnit?: string; prefix?: string; extraPoints?: number; extraExperience?: number }) {
  return request.post<Api.Operation.CardKeyItem[]>({ url: '/api/operation/cardkey/create', params })
}

export function fetchDeleteCardKey(id: number) {
  return request.del({ url: `/api/operation/cardkey/${id}` })
}

export function fetchGetMembershipLevelList(params: Api.Operation.MembershipLevelSearchParams) {
  return request.get<Api.Operation.MembershipLevelList>({ url: '/api/operation/membership-level/list', params })
}

export function fetchSaveMembershipLevel(params: Api.Operation.MembershipLevelItem) {
  return request.post({ url: '/api/operation/membership-level/save', params })
}

export function fetchDeleteMembershipLevel(id: number) {
  return request.del({ url: `/api/operation/membership-level/${id}` })
}

export function fetchGetMemberList(params: Api.Operation.MemberSearchParams) {
  return request.get<Api.Operation.MemberList>({ url: '/api/operation/member/list', params })
}

export function fetchUpdateMemberLevel(params: { userId: number; level: number }) {
  return request.post({ url: '/api/operation/member/update-level', params })
}

export function fetchGetPointsRecordList(params: Api.Operation.PointsRecordSearchParams) {
  return request.get<Api.Operation.PointsRecordList>({ url: '/api/operation/points-record/list', params })
}

export function fetchAdjustPoints(params: { userId: number; points: number; description: string }) {
  return request.post({ url: '/api/operation/points-record/adjust', params })
}

export function fetchExpLevelList(params?: any) {
  return request.get({ url: '/api/operation/experience-level/list', params })
}

export function fetchExpLevelSave(data: any) {
  return request.post({ url: '/api/operation/experience-level/save', params: data })
}

export function fetchExpLevelDelete(id: number) {
  return request.del({ url: `/api/operation/experience-level/${id}` })
}

export function fetchPluginList(params?: any) {
  return request.get({ url: '/api/plugins/list', params })
}

export function fetchPluginSave(data: any) {
  return request.post({ url: '/api/plugins/save', params: data })
}

export function fetchPluginDelete(id: number) {
  return request.del({ url: `/api/plugins/${id}` })
}
