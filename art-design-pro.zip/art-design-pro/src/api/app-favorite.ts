import request from '@/utils/http'

export const fetchAppFavorites = (userId: number) =>
  request.get({ url: '/app-favorite/list', params: { userId } })

export const toggleAppFavorite = (data: { userId: number; appId: number; appName?: string }) =>
  request.post({ url: '/app-favorite/toggle', data })

export const checkAppFavorite = (userId: number, appId: number) =>
  request.get({ url: '/app-favorite/check', params: { userId, appId } })

export const toggleFavorite = toggleAppFavorite
export const checkFavorite = checkAppFavorite
