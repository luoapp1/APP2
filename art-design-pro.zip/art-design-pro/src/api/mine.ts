import request from '@/utils/http'

export { fetchExpLevelList } from './operation'

export const fetchBalanceRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/balance-records', params })

export const fetchPointsRecords = (params: any) =>
  request.get({ url: '/api/operation/points-record/list', params })

export const fetchFollowers = (userId: number, page = 1) =>
  request.get({ url: `/api/user/${userId}/followers`, params: { page, pageSize: 20 } })

export const fetchFollowing = (userId: number, page = 1) =>
  request.get({ url: `/api/user/${userId}/following`, params: { page, pageSize: 20 } })

export const fetchContentPurchases = (userId: number, page = 1) =>
  request.get({ url: '/api/content/purchases/my', params: { userId, page, pageSize: 20 } })

export const fetchOrders = (userId: number, page = 1) =>
  request.get({ url: '/api/settlement/orders', params: { userId, page, pageSize: 20 } })

export const fetchMallOrders = (userId: number, page = 1) =>
  request.get({ url: '/api/mall/orders/my', params: { userId, page, pageSize: 20 } })

export const fetchMallOrderDetail = (orderId: number) =>
  request.get({ url: `/api/mall/orders/${orderId}` })

export const removeFollower = (followerId: number) =>
  request.del({ url: `/api/user/${followerId}/remove-follower` })

export const fetchExperienceRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/experience-records', params })

export const fetchMembershipRecords = (params: { userId: number; page?: number; pageSize?: number }) =>
  request.get({ url: '/api/user/membership-records', params })
