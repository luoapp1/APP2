import request from '@/utils/http'

export function addBrowseHistory(data: {
  userId: number
  itemType: 'post' | 'app'
  itemId: number
  itemTitle?: string
  itemCover?: string
  itemUrl?: string
}) {
  return request.post({ url: '/api/browse-history/add', data, showErrorMessage: false })
}

export function fetchBrowseHistory(params: { userId: number; itemType?: 'post' | 'app' }) {
  return request.get({ url: '/api/browse-history/list', params, showErrorMessage: false })
}
