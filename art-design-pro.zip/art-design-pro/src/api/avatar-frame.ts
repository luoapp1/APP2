import request from '@/utils/http'

export function fetchAvatarFrameList() {
  return request.get({ url: '/api/avatar-frame/list' })
}

export function fetchAvatarFrameAll() {
  return request.get({ url: '/api/avatar-frame/all' })
}

export function fetchAvatarFrameSave(data: any) {
  return request.post({ url: '/api/avatar-frame/save', data })
}

export function fetchAvatarFrameDelete(id: number) {
  return request.del({ url: `/api/avatar-frame/${id}` })
}

export function fetchAvatarFrameUpload(formData: FormData) {
  return request.post({ url: '/api/avatar-frame/upload', data: formData })
}

export function fetchUserAvatarFrames() {
  return request.get({ url: '/api/user/avatar-frames' })
}

export function fetchActiveFrame(frameId: number) {
  return request.post({ url: '/api/user/active-frame', data: { frameId } })
}

export function fetchGrantFrame(userId: number, frameId: number) {
  return request.post({ url: '/api/user/grant-frame', data: { userId, frameId } })
}

export function fetchRevokeFrame(userId: number, frameId: number) {
  return request.del({ url: `/api/user/revoke-frame/${frameId}?userId=${userId}` })
}

export function fetchAutoGrantFrame() {
  return request.post({ url: '/api/avatar-frame/auto-grant' })
}

export function fetchFrameUsers(frameId: number) {
  return request.get({ url: `/api/avatar-frame/${frameId}/users` })
}
