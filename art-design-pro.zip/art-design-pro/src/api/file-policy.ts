import request from '@/utils/http'

export const fetchFilePolicies = () =>
  request.get({ url: '/file-policy/list' })

export const saveFilePolicy = (data: any) =>
  request.post({ url: '/file-policy/save', data })

export const deleteFilePolicy = (id: number) =>
  request.post({ url: '/file-policy/delete', data: { id } })

export const checkFilePolicy = (rules?: string) =>
  request.get({ url: '/file-policy/check', params: rules ? { rules } : undefined })
