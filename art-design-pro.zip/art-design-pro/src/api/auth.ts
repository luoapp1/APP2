import request from '@/utils/http'

export function fetchLogin(params: Api.Auth.LoginParams) {
  return request.post<Api.Auth.LoginResponse>({
    url: '/api/auth/login',
    params
  })
}

export function fetchGetUserInfo() {
  return request.get<Api.Auth.UserInfo>({
    url: '/api/user/info'
  })
}

export function fetchRegister(params: { username: string; password: string; inviteCode?: string }) {
  return request.post({ url: '/api/auth/register', data: params })
}

export function fetchVerifyInviteCode(code: string) {
  return request.post({ url: '/api/invite/verify', data: { code } })
}
