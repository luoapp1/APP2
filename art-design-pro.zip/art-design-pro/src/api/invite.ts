import request from '@/utils/http'

export const fetchGenerateInvite = (data?: any) =>
  request.post({ url: '/invite/generate', data })

export const fetchInviteList = (params: any) =>
  request.get({ url: '/invite/list', params })

export const fetchInviteVerify = (code: string) =>
  request.post({ url: '/invite/verify', data: { code } })

export const fetchInviteUse = (code: string, userId: number, userName: string) =>
  request.post({ url: '/invite/use', data: { code, userId, userName } })

export const fetchInviteRequired = () =>
  request.get({ url: '/invite/required' })

export const fetchMyInvite = () =>
  request.get({ url: '/invite/my' })

export const fetchGenerateUserInvite = () =>
  request.post({ url: '/invite/generate-user' })

export const fetchInviteConfig = () =>
  request.get({ url: '/invite/config' })
