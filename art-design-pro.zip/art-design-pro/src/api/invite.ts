import request from '@/utils/http'

export const fetchGenerateInvite = (data?: any) =>
  request.post({ url: '/api/invite/generate', data })

export const fetchInviteList = (params: any) =>
  request.get({ url: '/api/invite/list', params })

export const fetchInviteVerify = (code: string) =>
  request.post({ url: '/api/invite/verify', data: { code } })

export const fetchInviteUse = (code: string, userId: number, userName: string) =>
  request.post({ url: '/api/invite/use', data: { code, userId, userName } })

export const fetchInviteRequired = () =>
  request.get({ url: '/api/invite/required' })

export const fetchMyInvite = () =>
  request.get({ url: '/api/invite/my' })

export const fetchGenerateUserInvite = () =>
  request.post({ url: '/api/invite/generate-user' })

export const fetchInviteConfig = () =>
  request.get({ url: '/api/invite/config' })
