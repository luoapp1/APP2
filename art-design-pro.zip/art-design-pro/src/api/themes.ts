import request from '@/utils/http'

export interface ThemeTokenSet {
  [key: string]: string
}

export interface ThemeData {
  id: number
  name: string
  description: string
  isPreset: boolean
  isActive: boolean
  thumbnail: string
  vars: ThemeTokenSet
  varsDark: ThemeTokenSet
  varsMobile: ThemeTokenSet
  varsMobileDark: ThemeTokenSet
  device?: 'pc' | 'mobile'
  createTime: string
  updateTime: string
}

export function fetchActiveTheme() {
  return request.get<ThemeData>({ url: '/api/themes/active' })
}

export function fetchThemes() {
  return request.get<ThemeData[]>({ url: '/api/themes' })
}

export function fetchThemeById(id: number) {
  return request.get<ThemeData>({ url: `/api/themes/${id}` })
}

export function createTheme(data: Partial<ThemeData>) {
  return request.post({ url: '/api/themes', data })
}

export function updateTheme(id: number, data: Partial<ThemeData>) {
  return request.put({ url: `/api/themes/${id}`, data })
}

export function deleteTheme(id: number) {
  return request.del({ url: `/api/themes/${id}` })
}

export function activateTheme(id: number) {
  return request.put<ThemeData>({ url: `/api/themes/${id}/activate` })
}
