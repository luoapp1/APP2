import request from '@/utils/http'

export const fetchEmailConfig = () =>
  request.get({ url: '/api/email/config' })

export const fetchSaveEmailConfig = (data: any) =>
  request.post({ url: '/api/email/config', data })

export const fetchTestEmail = (to: string) =>
  request.post({ url: '/api/email/test', data: { to } })

export const fetchSendEmailCode = (email: string, type = 'register') =>
  request.post({ url: '/api/email/send-code', data: { email, type } })

export const fetchVerifyEmailCode = (email: string, code: string, type = 'register') =>
  request.post({ url: '/api/email/verify-code', data: { email, code, type } })
