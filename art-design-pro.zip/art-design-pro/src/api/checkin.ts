import request from '@/utils/http'

export const doCheckin = () =>
  request.post({ url: '/checkin' })

export const fetchCheckinStatus = () =>
  request.get({ url: '/checkin/status' })

export const fetchCheckinHistory = (params?: any) =>
  request.get({ url: '/checkin/history', params })
