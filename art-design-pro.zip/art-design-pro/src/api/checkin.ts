import request from '@/utils/http'

export const doCheckin = () =>
  request.post({ url: '/api/checkin' })

export const fetchCheckinStatus = () =>
  request.get({ url: '/api/checkin/status' })

export const fetchCheckinHistory = (params?: any) =>
  request.get({ url: '/api/checkin/history', params })

export const fetchCheckinRanking = (params?: any) =>
  request.get({ url: '/api/checkin/ranking', params })

export const doMakeupCheckin = (data: { cardNo: string; password: string }) =>
  request.post({ url: '/api/checkin/makeup', data })
