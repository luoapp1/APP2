import request from '@/utils/http'

export const fetchApplyVerification = (data: {
  realName: string
  idCard: string
  organization: string
  reason: string
  proofUrls?: string[]
}) => request.post({ url: '/api/verification/apply', data })

export const fetchVerificationStatus = (userId?: number) =>
  request.get({ url: '/api/verification/status', params: userId ? { userId } : undefined })

export const fetchVerificationList = (params: any) =>
  request.get({ url: '/api/verification/list', params })

export const fetchReviewVerification = (id: number, data: {
  action: string
  comment?: string
}) => request.post({ url: `/api/verification/${id}/review`, data })

export const fetchCancelVerification = (userId: number) =>
  request.post({ url: '/api/verification/cancel', data: { userId } })
