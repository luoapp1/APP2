import request from '@/utils/http'

export const fetchApplyVerification = (data: {
  realName: string
  idCard: string
  organization: string
  reason: string
  proofUrls?: string[]
  selectedCondition?: string
  selectedAppId?: number
}) => request.post({ url: '/api/verification/apply', data })

export const fetchVerificationStatus = (userId?: number) =>
  request.get({ url: '/api/verification/status', params: userId ? { userId } : undefined })

export const fetchPublicVerificationStatus = (userId: number) =>
  request.get({ url: `/api/verification/public-status/${userId}` })

export const fetchVerificationList = (params: any) =>
  request.get({ url: '/api/verification/list', params })

export const fetchReviewVerification = (id: number, data: {
  action: string
  comment?: string
}) => request.post({ url: `/api/verification/${id}/review`, data })

export const fetchCancelVerification = (userId: number) =>
  request.post({ url: '/api/verification/cancel', data: { userId } })

// 认证配置相关
export const fetchVerificationConfig = () =>
  request.get({ url: '/api/verification/config' })

export const fetchSaveVerificationConfig = (data: {
  conditions: Array<{ condition_type: string; threshold: number; is_active: boolean }>
  logic_type: string
  logic_count: number
}) => request.post({ url: '/api/verification/config', data })

export const fetchClientVerificationConfig = () =>
  request.get({ url: '/api/verification/client-config' })

export const fetchUserApprovedApps = () =>
  request.get({ url: '/api/verification/user-apps' })
