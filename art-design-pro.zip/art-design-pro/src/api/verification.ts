import request from '@/utils/http'

export const fetchApplyVerification = (data: {
  userId: number
  userName: string
  realName: string
  idCard?: string
  mobile?: string
  images?: string[]
  type?: string
}) => request.post({ url: '/verification/apply', data })

export const fetchVerificationStatus = (userId?: number) =>
  request.get({ url: '/verification/status', params: userId ? { userId } : undefined })

export const fetchVerificationList = (params: any) =>
  request.get({ url: '/verification/list', params })

export const fetchReviewVerification = (data: {
  id: number
  status: string
  remark?: string
}) => request.post({ url: '/verification/review', data })

export const fetchCancelVerification = (userId: number) =>
  request.post({ url: '/verification/cancel', data: { userId } })
