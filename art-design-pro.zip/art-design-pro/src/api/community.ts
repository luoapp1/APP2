import request from '@/utils/http'

export interface CommunitySection {
  id: number
  name: string
  icon: string
  iconBgColor: string
  description: string
  todayHeat: number
  totalHeat: number
  postCount: number
  viewCount: number
  sortOrder: number
  status: string
  createTime: string
}

export interface CommunityPost {
  id: number
  sectionId: number
  userId: number
  userName: string
  userAvatar: string
  title: string
  content: string
  device: string
  tags: string[]
  officialTags: string[]
  images: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  isPinned: boolean
  isGlobalPinned: boolean
  customBadge?: string
  isEssence: boolean
  isHot: boolean
  isLocked: boolean
  status: string
  rejectReason?: string
  likeCount: number
  commentCount: number
  coinCount: number
  viewCount: number
  favoriteCount: number
  scheduledTime: string
  createTime: string
  updateTime: string
  isLiked?: boolean
  isFavorited?: boolean
  soldCount?: number
  comments?: CommunityComment[]
}

export interface CommunityComment {
  id: number
  postId: number
  parentId: number
  userId: number
  userName: string
  userAvatar: string
  content: string
  images?: string[]
  likeCount: number
  replyCount: number
  isPinned: number
  userIsVerified?: number
  userExpLevelName?: string
  userTitleIcon?: string
  userTitleName?: string
  userTitleColor?: string
  userTitleBgColor?: string
  createTime: string
  replies?: CommunityComment[]
}

export interface CommunityDraft {
  id: number
  userId: number
  sectionId: number
  title: string
  content: string
  images: string[]
  tags: string[]
  officialTags: string[]
  hasResource: boolean
  resourceType: string
  resourceUrl: string
  resourcePrice: number
  resourcePriceType: string
  extractCode: string
  permission: string
  createTime: string
  updateTime: string
}

export interface BannedUser {
  id: number
  userId: number
  userName: string
  reason: string
  bannedUntil: string
  createTime: string
}

export function fetchCommunitySections(all?: boolean) {
  const q = all ? '?all=true' : ''
  return request.get({ url: `/api/community/sections${q}` })
}

export function fetchCommunitySection(id: number) {
  return request.get({ url: `/api/community/section/${id}` })
}

export function createCommunitySection(data: { name: string; icon?: string; iconBgColor?: string; description?: string; sortOrder?: number; status?: string }) {
  return request.post({ url: '/api/community/section', data })
}

export function updateCommunitySection(id: number, data: Record<string, unknown>) {
  return request.post({ url: '/api/community/section', data: { ...data, id } })
}

export function deleteCommunitySection(id: number) {
  return request.del({ url: `/api/community/section/${id}` })
}

export function fetchCommunityPosts(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/posts', params })
}

export function fetchCommunityPost(id: number, userId?: number) {
  const q = userId ? `?userId=${userId}` : ''
  return request.get({ url: `/api/community/post/${id}${q}` })
}

export function createCommunityPost(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/post', data })
}

export function updateCommunityPost(id: number, data: Record<string, unknown>) {
  return request.put({ url: `/api/community/post/${id}`, data })
}

export function deleteCommunityPost(id: number, userId: number) {
  return request.del({ url: `/api/community/post/${id}`, data: { userId } })
}

export function likePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/like`, data: { userId } })
}

export function favoritePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/favorite`, data: { userId } })
}

export function fetchUserFavorites(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/user/favorites', params })
}

export function pinPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/pin`, data: { userId } })
}

export function globalPinPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/global-pin`, data: { userId } })
}

export function setCustomBadge(id: number, badge: string) {
  return request.post({ url: `/api/community/post/${id}/custom-badge`, data: { badge } })
}

export function essencePost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/essence`, data: { userId } })
}

export function hotPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/hot`, data: { userId } })
}

export function lockPost(id: number, userId: number) {
  return request.post({ url: `/api/community/post/${id}/lock`, data: { userId } })
}

export function sendCoin(id: number, data: { userId: number; amount: number; coinType?: string }) {
  return request.post({ url: `/api/community/post/${id}/coin`, data })
}

export function fetchCoinLogs(id: number, page = 1) {
  return request.get({ url: `/api/community/post/${id}/coin-logs`, params: { page, pageSize: 50 } })
}

export function fetchComments(postId: number, params: Record<string, unknown>) {
  return request.get({ url: `/api/community/post/${postId}/comments`, params })
}

export function fetchPostComments(params: Record<string, unknown>) {
  return fetchComments(params.postId as number, params)
}

export function postComment(postId: number, data: Record<string, unknown>) {
  return request.post({ url: `/api/community/post/${postId}/comment`, data })
}

export function createPostComment(data: Record<string, unknown>) {
  return postComment(data.postId as number, data)
}

export function deleteComment(id: number, userId: number) {
  return request.del({ url: `/api/community/comment/${id}`, data: { userId } })
}

export function pinComment(id: number) {
  return request.post({ url: `/api/community/comment/${id}/pin` })
}

export function fetchDrafts(userId: number) {
  return request.get({ url: '/api/community/drafts', params: { userId } })
}

export function saveDraft(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/draft', data })
}

export function deleteDraft(id: number, userId: number) {
  return request.del({ url: `/api/community/draft/${id}`, data: { userId } })
}

export function fetchAdminPosts(params: Record<string, unknown>) {
  return request.get({ url: '/api/community/admin/posts', params })
}

export function updatePostStatus(id: number, data: { userId: number; status: string }) {
  return request.put({ url: `/api/community/admin/post/${id}/status`, data })
}

export function banUser(data: { userId: number; targetUserId: number; reason?: string; duration?: number }) {
  return request.post({ url: '/api/community/admin/ban', data })
}

export function unbanUser(userId: number, targetUserId: number) {
  return request.post({ url: '/api/community/admin/unban', data: { userId, targetUserId } })
}

export function fetchBannedUsers(userId: number) {
  return request.get({ url: '/api/community/admin/banned', params: { userId } })
}

export function fetchModerators(sectionId: number) {
  return request.get({ url: `/api/community/section/${sectionId}/moderators` })
}

export function addModerator(sectionId: number, data: { userId: number; userName: string; userAvatar?: string; role?: string }) {
  return request.post({ url: `/api/community/section/${sectionId}/moderator`, data })
}

export function removeModerator(sectionId: number, userId: number) {
  return request.del({ url: `/api/community/section/${sectionId}/moderator/${userId}` })
}

export function fetchUserModeratorSections(userId: number) {
  return request.get({ url: `/api/community/user/${userId}/moderator-sections` })
}

export function fetchPendingPosts(page = 1, pageSize = 20) {
  return request.get({ url: '/api/community/admin/posts/pending', params: { page, pageSize } })
}

export function approvePost(postId: number) {
  return request.post({ url: `/api/community/admin/post/${postId}/approve` })
}

export function rejectPost(postId: number, reason: string) {
  return request.post({ url: `/api/community/admin/post/${postId}/reject`, data: { reason } })
}

export function searchUsers(keyword: string) {
  return request.get({ url: '/api/community/user/search', params: { keyword } })
}

export function reportPost(postId: number, reason?: string, detail?: string) {
  return request.post({ url: `/api/community/post/${postId}/report`, data: { reportReason: reason, reportDetail: detail } })
}

export function reportComment(commentId: number, reason?: string, detail?: string) {
  return request.post({ url: `/api/community/comment/${commentId}/report`, data: { reportReason: reason, reportDetail: detail } })
}

export function requestUnlock(postId: number, reason?: string) {
  return request.post({ url: `/api/community/post/${postId}/request-unlock`, data: { reason } })
}

export function fetchUnlockRequests() {
  return request.get({ url: '/api/community/admin/unlock-requests' })
}

export function handleUnlockRequest(id: number, action: string, reply?: string) {
  return request.post({ url: `/api/community/admin/unlock-request/${id}/handle`, data: { action, reply } })
}

export function fetchReports() {
  return request.get({ url: '/api/community/admin/reports' })
}

export function ignoreReport(id: number) {
  return request.post({ url: `/api/community/admin/report/ignore/${id}` })
}

export function deleteReportPost(postId: number) {
  return request.del({ url: `/api/community/admin/report/post/${postId}` })
}

export function deleteReportComment(commentId: number) {
  return request.del({ url: `/api/community/admin/report/comment/${commentId}` })
}

export function fetchTopics(params?: Record<string, unknown>) {
  return request.get({ url: '/api/community/topics', params })
}

export function fetchTopicDetail(id: number) {
  return request.get({ url: `/api/community/topics/${id}` })
}

export function createTopic(data: Record<string, unknown>) {
  return request.post({ url: '/api/community/topics', data })
}

export function updateTopic(id: number, data: Record<string, unknown>) {
  return request.put({ url: `/api/community/topics/${id}`, data })
}

export function deleteTopic(id: number) {
  return request.del({ url: `/api/community/topics/${id}` })
}

export function fetchTopicConfig() {
  return request.get({ url: '/api/community/topics/config' })
}

export function updateTopicConfig(data: Record<string, unknown>) {
  return request.put({ url: '/api/community/topics/config', data })
}

export function fetchTopicPosts(id: number, params?: Record<string, unknown>) {
  return request.get({ url: `/api/community/topics/${id}/posts`, params })
}

export function followTopic(id: number) {
  return request.post({ url: `/api/community/topics/${id}/follow` })
}

export function unfollowTopic(id: number) {
  return request.del({ url: `/api/community/topics/${id}/follow` })
}

export function checkTopicFollow(id: number) {
  return request.get({ url: `/api/community/topics/${id}/follow` })
}

export function fetchTopicFollowers(id: number, params?: Record<string, unknown>) {
  return request.get({ url: `/api/community/topics/${id}/followers`, params })
}
