<script setup lang="ts">
import { useRouter } from 'vue-router'
const router = useRouter()
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>选择安装包</h2></div>
    <div class="content-card"><div class="empty">请选择要上传的APK文件</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 600px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .empty { text-align: center; color: #999; font-size: 14px; }</style>
