<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const router = useRouter()
const form = ref({ appName: '', packageName: '', description: '', category: '' })
const loading = ref(false)

async function submit() {
  if (!form.value.appName) { ElMessage.warning('请输入应用名称'); return }
  loading.value = true
  try {
    await request.post('/api/submissions/create', form.value)
    ElMessage.success('提交成功')
    router.push('/appstore/submissions/success')
  } catch (e: any) { ElMessage.error(e.message || '提交失败') }
  finally { loading.value = false }
}
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>应用投稿</h2></div>
    <div class="content-card"><el-form label-position="top">
      <el-form-item label="应用名称"><el-input v-model="form.appName" /></el-form-item>
      <el-form-item label="包名"><el-input v-model="form.packageName" /></el-form-item>
      <el-form-item label="分类"><el-input v-model="form.category" /></el-form-item>
      <el-form-item label="描述"><el-input v-model="form.description" type="textarea" :rows="4" /></el-form-item>
      <el-form-item><el-button type="primary" :loading="loading" @click="submit" size="large">提交</el-button></el-form-item>
    </el-form></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 600px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }</style>
