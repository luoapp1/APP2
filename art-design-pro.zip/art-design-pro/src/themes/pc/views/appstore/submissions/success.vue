<script setup lang="ts">
import { useRouter } from 'vue-router'
const router = useRouter()
</script>
<template>
  <div class="pc-page"><div class="page-header"><h2>投稿成功</h2></div>
    <div class="content-card"><div class="success-icon"><el-icon :size="48" color="#67c23a"><CircleCheckFilled /></el-icon></div>
      <p>您的投稿已提交，请等待审核</p>
      <el-button type="primary" @click="router.push('/appstore/submissions')">查看投稿列表</el-button></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 500px; } .page-header { padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .success-icon { margin-bottom: 16px; } .content-card p { color: #666; margin-bottom: 20px; }</style>
