<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunitySections } from '@/api/community'

const router = useRouter()
const boards = ref<any[]>([])
onMounted(async () => { try { const res = await fetchCommunitySections(); boards.value = res.data || res || [] } catch (e) {} })
</script>
<template>
  <div class="pc-page"><div class="page-header"><h2>发现</h2></div>
    <div class="grid"><div v-for="b in boards" :key="b.id" class="card" @click="router.push(`/s/${b.id}?name=${b.name}`)">
      <div class="card-avatar" :style="{ background: b.iconBgColor || '#667eea' }">{{ b.name?.[0] || '?' }}</div>
      <div class="card-name">{{ b.name }}</div><div class="card-heat">热度 {{ b.todayHeat || 0 }}</div></div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 1000px; } .page-header { padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 14px; } .card { background: #fff; border-radius: 12px; padding: 20px; text-align: center; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; } .card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); } .card-avatar { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 22px; font-weight: 700; margin: 0 auto 12px; } .card-name { font-size: 15px; font-weight: 600; } .card-heat { font-size: 12px; color: #999; margin-top: 4px; }</style>
