<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { fmtRelativeTime } from '@/utils'

const router = useRouter()
const comments = ref<any[]>([])
onMounted(async () => {
  try { const res = await request.get('/api/user/community-comments'); comments.value = res.data?.list || res.list || [] } catch (e) {}
})
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>我的评论</h2></div>
    <div class="content-card"><div v-for="c in comments" :key="c.id" class="item"><div class="item-content" v-html="c.content"></div><div class="item-time">{{ fmtRelativeTime(c.createTime || c.createdAt) }}</div></div>
      <div v-if="!comments.length" class="empty">暂无评论</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 700px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .item { padding: 12px 0; border-bottom: 1px solid #f5f5f5; } .item-content { font-size: 14px; } .item-time { font-size: 12px; color: #999; margin-top: 4px; } .empty { text-align: center; padding: 40px; color: #999; }</style>
