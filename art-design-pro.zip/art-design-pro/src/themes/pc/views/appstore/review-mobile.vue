<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'

const router = useRouter()
const pendingList = ref<any[]>([])
onMounted(async () => { try { const res = await request.get('/api/submissions/pending'); pendingList.value = res.data?.list || res.list || [] } catch (e) {} })
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>投稿审核</h2></div>
    <div class="content-card"><el-table :data="pendingList" v-if="pendingList.length"><el-table-column prop="appName" label="应用名称" /><el-table-column prop="status" label="状态" /><el-table-column label="操作"><template #default><el-button size="small" type="success" plain>通过</el-button><el-button size="small" type="danger" plain>拒绝</el-button></template></el-table-column></el-table>
      <div v-else class="empty">暂无待审投稿</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 900px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; flex: 1; } .content-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .empty { text-align: center; padding: 60px; color: #999; }</style>
