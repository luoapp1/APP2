<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const profileData = ref<any>({})
const showNicknameDialog = ref(false)
const showSignatureDialog = ref(false)
const showQqDialog = ref(false)
const showBirthdayDialog = ref(false)
const editNickname = ref('')
const editSignature = ref('')
const editQq = ref('')
const editBirthday = ref('')
const hideBirthday = ref(false)
const hideQq = ref(false)
const hideEmail = ref(false)
const hideAddress = ref(false)

async function load() {
  if (!userStore.isLogin) {
    router.replace('/appstore/browse/login')
    return
  }
  try { const res = await request.get('/api/user/profile'); profileData.value = res.data || res }
  catch (_e: unknown) { void _e }
  hideBirthday.value = !!profileData.value.hideBirthday
  hideQq.value = !!profileData.value.hideQq
  hideEmail.value = !!profileData.value.hideEmail
  hideAddress.value = !!profileData.value.hideAddress
}

async function saveNickname() {
  try { await request.put('/api/user/profile', { nickname: editNickname.value }); ElMessage.success('保存成功'); showNicknameDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function saveSignature() {
  try { await request.put('/api/user/profile', { signature: editSignature.value }); ElMessage.success('保存成功'); showSignatureDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function saveQq() {
  try { await request.put('/api/user/profile', { qq: editQq.value }); ElMessage.success('保存成功'); showQqDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function saveBirthday() {
  try { await request.put('/api/user/profile', { birthday: editBirthday.value }); ElMessage.success('保存成功'); showBirthdayDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function savePrivacy(key: string, val: boolean) {
  try {
    const body: any = {}
    body[key] = val
    await request.put('/api/user/profile', body)
    ElMessage.success('已更新')
  } catch (_e: unknown) { ElMessage.error('保存失败') }
}

async function handleLogout() {
  userStore.clearUserInfo()
  router.push('/appstore/browse')
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>编辑资料</h2></div>
    <div class="content-card">
      <div class="field-row" @click="editNickname = profileData.nickname; showNicknameDialog = true"><span class="label">昵称</span><span class="value">{{ profileData.nickname || '-' }}</span><el-icon><ArrowRight /></el-icon></div>
      <div class="field-row" @click="editSignature = profileData.signature; showSignatureDialog = true"><span class="label">签名</span><span class="value">{{ profileData.signature || '-' }}</span><el-icon><ArrowRight /></el-icon></div>
      <div class="field-row" @click="editQq = profileData.qq; showQqDialog = true"><span class="label">QQ</span><span class="value">{{ profileData.qq || '-' }}</span><el-icon><ArrowRight /></el-icon></div>
      <div class="field-row" :class="{ disabled: !!profileData.birthday }" @click="if(!profileData.birthday){ editBirthday = profileData.birthday; showBirthdayDialog = true }"><span class="label">生日</span><span class="value">{{ profileData.birthday || '未设置' }}</span><el-icon v-if="!profileData.birthday"><ArrowRight /></el-icon><span v-else class="locked-tip">已设置不可修改</span></div>
      <div class="field-row"><span class="label">用户名</span><span class="value">{{ profileData.username || '-' }}</span></div>
      <div class="field-row"><span class="label">邮箱</span><span class="value">{{ profileData.email || '-' }}</span></div>
    </div>

    <div class="content-card privacy-card">
      <div class="privacy-header"><h4>隐私设置</h4><span class="privacy-tip">开启后他人将看到"未知"</span></div>
      <div class="privacy-row">
        <span>隐藏生日/年龄</span>
        <el-switch v-model="hideBirthday" @change="(v: boolean) => savePrivacy('hideBirthday', v)" />
      </div>
      <div class="privacy-row">
        <span>隐藏QQ</span>
        <el-switch v-model="hideQq" @change="(v: boolean) => savePrivacy('hideQq', v)" />
      </div>
      <div class="privacy-row">
        <span>隐藏邮箱</span>
        <el-switch v-model="hideEmail" @change="(v: boolean) => savePrivacy('hideEmail', v)" />
      </div>
      <div class="privacy-row">
        <span>隐藏注册地址</span>
        <el-switch v-model="hideAddress" @change="(v: boolean) => savePrivacy('hideAddress', v)" />
      </div>
    </div>

    <div class="content-card"><div class="actions"><el-button type="danger" plain @click="handleLogout">退出登录</el-button></div></div>

    <el-dialog v-model="showNicknameDialog" title="修改昵称"><el-input v-model="editNickname" /><template #footer><el-button @click="showNicknameDialog = false">取消</el-button><el-button type="primary" @click="saveNickname">保存</el-button></template></el-dialog>
    <el-dialog v-model="showSignatureDialog" title="修改签名"><el-input v-model="editSignature" type="textarea" :rows="3" /><template #footer><el-button @click="showSignatureDialog = false">取消</el-button><el-button type="primary" @click="saveSignature">保存</el-button></template></el-dialog>
    <el-dialog v-model="showQqDialog" title="修改QQ"><el-input v-model="editQq" /><template #footer><el-button @click="showQqDialog = false">取消</el-button><el-button type="primary" @click="saveQq">保存</el-button></template></el-dialog>
    <el-dialog v-model="showBirthdayDialog" title="设置生日"><el-date-picker v-model="editBirthday" type="date" placeholder="选择日期" value-format="YYYY-MM-DD" /><template #footer><el-button @click="showBirthdayDialog = false">取消</el-button><el-button type="primary" @click="saveBirthday">保存</el-button></template></el-dialog>
  </div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 600px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,.06); margin-bottom: 16px; } .field-row { display: flex; align-items: center; padding: 14px 24px; cursor: pointer; border-bottom: 1px solid #f5f5f5; } .field-row:hover { background: #fafbfc; } .field-row.disabled { cursor: default; } .field-row.disabled:hover { background: transparent; } .label { font-size: 14px; color: #666; width: 80px; } .value { flex: 1; font-size: 14px; } .locked-tip { font-size: 12px; color: #bbb; margin-left: 8px; } .privacy-card { padding: 16px 24px; } .privacy-header { display: flex; align-items: baseline; gap: 8px; margin-bottom: 12px; } .privacy-header h4 { margin: 0; font-size: 15px; color: #333; } .privacy-tip { font-size: 12px; color: #bbb; } .privacy-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-top: 1px solid #f5f5f5; font-size: 14px; color: #333; } .actions { padding: 20px 24px; }</style>
