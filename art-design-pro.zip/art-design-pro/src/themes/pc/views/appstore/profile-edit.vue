<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const profileData = ref<any>({})
const showNicknameDialog = ref(false)
const showSignatureDialog = ref(false)
const editNickname = ref('')
const editSignature = ref('')

async function load() {
  if (!userStore.isLogin) {
    router.replace('/appstore/browse/login')
    return
  }
  try { const res = await request.get('/api/user/profile'); profileData.value = res.data || res }
  catch (e) {}
}

async function saveNickname() {
  try { await request.put('/api/user/profile', { nickname: editNickname.value }); ElMessage.success('保存成功'); showNicknameDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function saveSignature() {
  try { await request.put('/api/user/profile', { signature: editSignature.value }); ElMessage.success('保存成功'); showSignatureDialog.value = false; await load() }
  catch (e: any) { ElMessage.error(e.message || '保存失败') }
}

async function handleLogout() {
  userStore.clearUserInfo()
  router.push('/appstore/browse')
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>编辑资料</h2></div>
    <div class="content-card">
      <div class="field-row" @click="editNickname = profileData.nickname; showNicknameDialog = true"><span class="label">昵称</span><span class="value">{{ profileData.nickname || '-' }}</span><el-icon><ArrowRight /></el-icon></div>
      <div class="field-row" @click="editSignature = profileData.signature; showSignatureDialog = true"><span class="label">签名</span><span class="value">{{ profileData.signature || '-' }}</span><el-icon><ArrowRight /></el-icon></div>
      <div class="field-row"><span class="label">用户名</span><span class="value">{{ profileData.username || '-' }}</span></div>
      <div class="field-row"><span class="label">邮箱</span><span class="value">{{ profileData.email || '-' }}</span></div>
      <div class="actions"><el-button type="danger" plain @click="handleLogout">退出登录</el-button></div>
    </div>
    <el-dialog v-model="showNicknameDialog" title="修改昵称"><el-input v-model="editNickname" /><template #footer><el-button @click="showNicknameDialog = false">取消</el-button><el-button type="primary" @click="saveNickname">保存</el-button></template></el-dialog>
    <el-dialog v-model="showSignatureDialog" title="修改签名"><el-input v-model="editSignature" type="textarea" :rows="3" /><template #footer><el-button @click="showSignatureDialog = false">取消</el-button><el-button type="primary" @click="saveSignature">保存</el-button></template></el-dialog>
  </div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 600px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .field-row { display: flex; align-items: center; padding: 14px 24px; cursor: pointer; border-bottom: 1px solid #f5f5f5; } .field-row:hover { background: #fafbfc; } .label { font-size: 14px; color: #666; width: 80px; } .value { flex: 1; font-size: 14px; } .actions { padding: 20px 24px; }</style>
