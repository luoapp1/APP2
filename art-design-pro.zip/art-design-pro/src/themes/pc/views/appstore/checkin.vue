<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { doCheckin, fetchCheckinHistory, fetchCheckinRanking } from '@/api/checkin'
import { ElMessage } from 'element-plus'

const router = useRouter()
const checkedDays = ref<Set<string>>(new Set())
const consecutiveDays = ref(0)
const ranking = ref<any[]>([])
const loading = ref(false)

const calendarDays = computed(() => {
  const now = new Date()
  const year = now.getFullYear()
  const month = now.getMonth()
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const days = []
  for (let i = 0; i < firstDay; i++) days.push(null)
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`
    days.push({ day: d, date: dateStr, checked: checkedDays.value.has(dateStr), isToday: d === now.getDate() })
  }
  return days
})

async function load() {
  try {
    const [histRes, rankRes] = await Promise.all([fetchCheckinHistory(), fetchCheckinRanking()])
    const hist = histRes.data || histRes
    checkedDays.value = new Set(hist.days || hist.checkedDays || [])
    consecutiveDays.value = hist.consecutiveDays || hist.consecutive || 0
    ranking.value = rankRes.data?.list || rankRes.list || []
  } catch (e) {}
}

async function handleCheckin() {
  loading.value = true
  try {
    await doCheckin()
    ElMessage.success('签到成功')
    await load()
  } catch (e: any) { ElMessage.error(e.message || '签到失败') }
  finally { loading.value = false }
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>每日签到</h2></div>
    <div class="layout"><div class="main-col">
      <div class="status-card"><div class="consecutive">连续签到 <b>{{ consecutiveDays }}</b> 天</div>
        <el-button type="primary" :loading="loading" size="large" @click="handleCheckin">立即签到</el-button></div>
      <div class="calendar"><div class="cal-header"><span v-for="d in ['日','一','二','三','四','五','六']" :key="d">{{ d }}</span></div>
        <div class="cal-grid"><div v-for="(d, i) in calendarDays" :key="i" class="cal-cell"><span v-if="d" :class="{ checked: d.checked, today: d.isToday }">{{ d.day }}</span></div></div></div>
    </div>
    <div class="side-col"><h3>签到排行</h3><div v-for="(r, i) in ranking.slice(0,10)" :key="i" class="rank-row"><span class="rank-pos">{{ i+1 }}</span><el-avatar :size="28" :src="$fixImgUrl(r.avatar)" /><span class="rank-name">{{ r.nickname }}</span><span class="rank-count">{{ r.totalCheckins }}天</span></div></div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 900px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .layout { display: flex; gap: 28px; } .main-col { flex: 1; } .side-col { width: 220px; background: #fff; border-radius: 12px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .side-col h3 { margin: 0 0 12px; font-size: 15px; } .status-card { background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 14px; padding: 28px; text-align: center; color: #fff; margin-bottom: 20px; } .consecutive { font-size: 16px; margin-bottom: 16px; } .consecutive b { font-size: 28px; } .calendar { background: #fff; border-radius: 12px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .cal-header { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; font-size: 13px; color: #999; margin-bottom: 8px; } .cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; } .cal-cell { text-align: center; padding: 8px 0; font-size: 13px; } .checked { background: #67c23a; color: #fff; border-radius: 50%; padding: 2px 6px; } .today { font-weight: 700; color: var(--el-color-primary); } .rank-row { display: flex; align-items: center; gap: 8px; padding: 8px 0; font-size: 13px; } .rank-pos { width: 20px; text-align: center; color: #999; } .rank-name { flex: 1; } .rank-count { color: #999; font-size: 12px; }</style>
