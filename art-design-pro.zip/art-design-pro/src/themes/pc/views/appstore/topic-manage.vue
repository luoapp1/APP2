<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchTopics } from '@/api/community'

const router = useRouter()
const topics = ref<any[]>([])
onMounted(async () => { try { const res = await fetchTopics(); topics.value = res.data?.list || res.list || [] } catch (e) {} })
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>话题管理</h2></div>
    <div class="content-card"><el-table :data="topics" v-if="topics.length"><el-table-column prop="name" label="话题名" /><el-table-column prop="heat" label="热度" /><el-table-column label="操作"><template #default><el-button size="small" type="danger" plain>删除</el-button></template></el-table-column></el-table>
      <div v-else class="empty">暂无话题</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 800px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; flex: 1; } .content-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .empty { text-align: center; padding: 60px; color: #999; }</style>
