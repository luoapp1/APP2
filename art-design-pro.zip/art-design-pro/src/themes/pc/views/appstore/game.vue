<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchConversations, fetchHideConversation } from '@/api/message'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0

const conversations = ref<any[]>([])
const loading = ref(true)
const myRooms = ref<any[]>([])
const loadingRooms = ref(true)

const colorPool = ['#AB47BC', '#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconBg = (id: number) => colorPool[id % colorPool.length]

const unifiedList = computed(() => {
  const items: any[] = []

  for (const r of myRooms.value) {
    items.push({ _type: 'chat', _key: 'chat-' + r.id, _room: r })
  }

  for (const c of conversations.value) {
    items.push({ _type: 'msg', _key: 'msg-' + c.userId, _conv: c })
  }

  return items
})

async function loadConvs() {
  loading.value = true
  try {
    const res = await fetchConversations(myUserId)
    conversations.value = res.data?.list || res.list || []
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function loadMyRooms() {
  loadingRooms.value = true
  try {
    const res: any = await request.get({ url: '/api/chat-rooms/my', params: { userId: myUserId } })
    myRooms.value = Array.isArray(res) ? res : (res.list || [])
  } catch {}
  loadingRooms.value = false
}

function goChat(targetUserId: string) {
  router.push(`/chat/${targetUserId}`)
}

function enterRoom(r: any) {
  router.push(`/chatroom/${r.id}`)
}

const loadingAll = computed(() => loading.value || loadingRooms.value)

onMounted(() => {
  loadConvs()
  loadMyRooms()
})
</script>

<template>
  <div class="pc-messages">
    <div class="page-header"><h2>消息</h2></div>
    <div v-if="loadingAll" class="loading"><el-skeleton :rows="5" animated /></div>
    <div v-else class="msg-list">
      <div v-if="unifiedList.length === 0" class="empty-state">暂无消息</div>
      <div v-for="item in unifiedList" :key="item._key" class="msg-item" @click="item._type === 'chat' ? enterRoom(item._room) : goChat(item._conv.userId)">
        <!-- 聊天室图标 -->
        <div v-if="item._type === 'chat'" class="room-avatar" :style="{ background: iconBg(item._room.id) }">
          <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
          </svg>
        </div>
        <!-- 私信头像 -->
        <template v-else>
          <el-badge :value="item._conv.unread" :hidden="!item._conv.unread">
            <el-avatar :size="44" :src="item._conv.userAvatar" />
          </el-badge>
        </template>
        <div class="msg-body">
          <div class="msg-header">
            <span class="msg-user">{{ item._type === 'chat' ? item._room.name : item._conv.userName }}</span>
            <span class="msg-time">{{ item._type === 'chat' ? (item._room.memberCount + ' 人') : item._conv.lastTime }}</span>
          </div>
          <div class="msg-preview">{{ item._type === 'chat' ? (item._room.description || '群聊') : item._conv.lastContent }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-messages { padding: 0 24px 24px; max-width: 700px; }
.page-header { padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 16px; }
.page-header h2 { margin: 0; font-size: 20px; }
.msg-list { display: flex; flex-direction: column; gap: 2px; }
.msg-item { display: flex; align-items: center; gap: 14px; padding: 14px 16px; cursor: pointer; border-radius: 10px; transition: background .2s; }
.msg-item:hover { background: #f5f7fa; }
.msg-body { flex: 1; min-width: 0; }
.msg-header { display: flex; justify-content: space-between; margin-bottom: 4px; }
.msg-user { font-size: 15px; font-weight: 500; }
.msg-time { font-size: 12px; color: #999; }
.msg-preview { font-size: 13px; color: #888; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.room-avatar { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; }
.empty-state { text-align: center; padding: 60px 0; color: #999; }
.loading { padding: 20px; }
</style>
