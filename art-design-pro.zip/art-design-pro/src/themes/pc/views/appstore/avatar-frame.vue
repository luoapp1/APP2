<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames, fetchActiveFrame, fetchAutoGrantFrame } from '@/api/avatar-frame'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const loading = ref(false)
const switchingId = ref(0)
const frames = ref<any[]>([])
const activeFrameId = ref(0)

const isLogin = computed(() => userStore.isLogin)
const userInfo = computed(() => userStore.info)

async function loadFrames() {
  if (!isLogin.value) return
  loading.value = true
  try {
    const res: any = await fetchUserAvatarFrames()
    frames.value = res.frames || []
    activeFrameId.value = res.activeFrameId || 0
  } catch { ElMessage.error('加载失败') }
  finally { loading.value = false }
}

async function selectFrame(frame: any) {
  if (!frame.owned) {
    ElMessage.warning('您尚未获得该头像框')
    return
  }
  if (frame.isActive) return
  switchingId.value = frame.id
  try {
    await fetchActiveFrame(frame.id)
    activeFrameId.value = frame.id
    frames.value.forEach(f => { f.isActive = f.id === frame.id })
    ElMessage.success('已切换头像框')
  } catch { ElMessage.error('切换失败') }
  finally { switchingId.value = 0 }
}

async function cancelFrame() {
  switchingId.value = -1
  try {
    await fetchActiveFrame(0)
    activeFrameId.value = 0
    frames.value.forEach(f => { f.isActive = false })
    ElMessage.success('已取消头像框')
  } catch { ElMessage.error('操作失败') }
  finally { switchingId.value = 0 }
}

async function handleAutoGrant() {
  try {
    const res: any = await fetchAutoGrantFrame()
    ElMessage.success(res.message || '操作成功')
    loadFrames()
  } catch { ElMessage.error('操作失败') }
}

function getObtainLabel(obtainType: string) {
  if (obtainType === 'experience') return '经验等级获取'
  if (obtainType === 'membership') return '会员等级获取'
  if (obtainType === 'activity') return '活动获取'
  return '手动授予'
}

onMounted(() => {
  if (isLogin.value) loadFrames()
})
</script>

<template>
  <div class="avatar-frame-page">
    <div class="page-header">
      <h2>头像框管理</h2>
      <ElButton type="primary" size="small" :loading="loading" @click="handleAutoGrant">同步获取</ElButton>
    </div>

    <div v-if="!isLogin" class="not-login">
      <p>请先登录后查看</p>
      <ElButton type="primary" @click="router.push('/appstore/browse/login')">去登录</ElButton>
    </div>

    <div v-else class="frame-content">
      <div class="avatar-preview-section">
        <div class="avatar-preview-label">头像预览</div>
        <div class="avatar-preview-wrapper">
          <img :src="$fixImgUrl(userInfo?.avatar || defaultAvatarImg)" class="avatar-img" />
          <img
            v-if="activeFrameId && frames.find(f => f.id === activeFrameId)?.owned"
            :src="$fixImgUrl(frames.find(f => f.id === activeFrameId)?.image_url)"
            class="frame-overlay"
          />
        </div>
        <div v-if="activeFrameId" class="active-frame-name">
          当前：{{ frames.find(f => f.id === activeFrameId)?.name || '' }}
          <ElButton size="small" type="danger" link @click="cancelFrame">取消使用</ElButton>
        </div>
        <div v-else class="active-frame-name" style="color:#999">未使用头像框</div>
      </div>

      <div class="frame-list-section">
        <div class="section-title">头像框列表</div>
        <div v-loading="loading" class="frame-grid">
          <div
            v-for="frame in frames"
            :key="frame.id"
            class="frame-item"
            :class="{ owned: frame.owned, active: frame.isActive, locked: !frame.owned }"
            @click="selectFrame(frame)"
          >
            <div class="frame-thumb">
              <img :src="$fixImgUrl(frame.image_url)" class="frame-thumb-img" />
              <div v-if="!frame.owned" class="lock-overlay">
                <ElIcon :size="24"><Lock /></ElIcon>
              </div>
              <div v-if="frame.isActive" class="active-badge">使用中</div>
            </div>
            <div class="frame-name">{{ frame.name }}</div>
            <div class="frame-obtain">{{ getObtainLabel(frame.obtainType) }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.avatar-frame-page { padding: 0 24px 24px; max-width: 900px; }
.page-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.not-login { text-align: center; padding: 80px 0; color: #999; }
.frame-content { display: flex; gap: 28px; }
.avatar-preview-section { width: 220px; flex-shrink: 0; text-align: center; }
.avatar-preview-label { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 16px; }
.avatar-preview-wrapper { position: relative; width: 120px; height: 120px; margin: 0 auto; }
.avatar-img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }
.frame-overlay { position: absolute; top: -10px; left: -10px; width: calc(100% + 20px); height: calc(100% + 20px); pointer-events: none; }
.active-frame-name { font-size: 13px; color: var(--el-color-primary); margin-top: 12px; }
.frame-list-section { flex: 1; }
.section-title { font-size: 15px; font-weight: 600; color: #333; margin-bottom: 16px; }
.frame-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.frame-item { background: #fff; border-radius: 10px; padding: 16px; text-align: center; cursor: pointer; border: 2px solid transparent; transition: all .2s; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.frame-item:hover { border-color: var(--el-color-primary-light-5); box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.frame-item.locked { opacity: .6; cursor: not-allowed; border-color: #e5e7eb; }
.frame-item.active { border-color: var(--el-color-primary); background: var(--el-color-primary-light-9); }
.frame-thumb { position: relative; width: 72px; height: 72px; margin: 0 auto 10px; }
.frame-thumb-img { width: 100%; height: 100%; object-fit: contain; }
.lock-overlay { position: absolute; inset: 0; background: rgba(0,0,0,.35); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #fff; }
.active-badge { position: absolute; top: -6px; right: -6px; background: var(--el-color-primary); color: #fff; font-size: 10px; padding: 1px 6px; border-radius: 4px; white-space: nowrap; }
.frame-name { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 4px; }
.frame-obtain { font-size: 11px; color: #999; }
</style>
