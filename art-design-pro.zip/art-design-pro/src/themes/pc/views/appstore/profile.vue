<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const activeTab = ref('info')
const profile = ref<any>(null)
const userApps = ref<any[]>([])
const userPosts = ref<any[]>([])
const loading = ref(true)
const isOwner = computed(() => !route.params.userId || route.params.userId === String(userStore.info?.userId))

async function loadProfile() {
  loading.value = true
  try {
    const uid = route.params.userId || userStore.info?.userId
    if (!uid) return
    const res = await request.get(`/api/user/profile/${uid}`)
    profile.value = res.data || res
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function loadApps() {
  try {
    const uid = route.params.userId || userStore.info?.userId
    const res = await request.get(`/api/user/apps/${uid}`)
    userApps.value = res.data?.list || res.list || []
  } catch (e) { /* ignore */ }
}

async function loadPosts() {
  try {
    const res = await request.get('/api/community/posts', { params: { userId: route.params.userId || userStore.info?.userId } })
    userPosts.value = res.data?.list || res.list || []
  } catch (e) { /* ignore */ }
}

function goBack() { router.back() }

onMounted(() => { loadProfile(); loadApps(); loadPosts() })
</script>

<template>
  <div class="pc-profile">
    <div class="page-header"><el-button text @click="goBack">&larr; 返回</el-button></div>
    <div v-if="loading" class="loading"><el-skeleton :rows="6" animated /></div>
    <div v-else-if="profile" class="profile-layout">
      <div class="profile-sidebar">
        <div class="profile-card">
          <el-avatar :size="80" :src="$fixImgUrl(profile.avatar)" />
          <h2>{{ profile.nickname || profile.username }}</h2>
          <p class="bio">{{ profile.signature || '这个人很懒，什么都没写' }}</p>
          <div class="profile-stats">
            <div class="stat"><b>{{ profile.followCount || 0 }}</b><span>关注</span></div>
            <div class="stat"><b>{{ profile.fansCount || 0 }}</b><span>粉丝</span></div>
            <div class="stat"><b>{{ profile.points || 0 }}</b><span>积分</span></div>
          </div>
        </div>
        <div class="info-card">
          <h4>详细信息</h4>
          <div class="info-row" v-if="profile.levelName"><span>等级</span><span>{{ profile.levelName }}</span></div>
          <div class="info-row" v-if="profile.email"><span>邮箱</span><span>{{ profile.email }}</span></div>
          <div class="info-row" v-if="profile.location"><span>地区</span><span>{{ profile.location }}</span></div>
          <div class="info-row"><span>注册时间</span><span>{{ profile.createTime || profile.createdAt }}</span></div>
        </div>
      </div>

      <div class="profile-content">
        <el-tabs v-model="activeTab">
          <el-tab-pane label="资料" name="info">
            <div class="info-section">
              <h4>关于我</h4>
              <p>{{ profile.signature || '暂无简介' }}</p>
            </div>
          </el-tab-pane>
          <el-tab-pane label="应用" name="apps">
            <div class="grid-list">
              <div v-for="app in userApps" :key="app.id" class="grid-item">
                <img :src="$fixImgUrl(app.icon)" class="grid-icon" />
                <div class="grid-name">{{ app.name }}</div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="帖子" name="posts">
            <div class="post-list">
              <div v-for="p in userPosts" :key="p.id" class="post-item" @click="router.push(`/p/${p.id}`)">
                <div class="post-title">{{ p.title }}</div>
                <div class="post-time">{{ p.createTime || p.createdAt }}</div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-profile { padding: 0 24px 24px; max-width: 1000px; }
.page-header { padding: 16px 0; margin-bottom: 20px; }
.profile-layout { display: flex; gap: 28px; }
.profile-sidebar { width: 280px; flex-shrink: 0; }
.profile-content { flex: 1; background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.profile-card { background: #fff; border-radius: 12px; padding: 28px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); margin-bottom: 16px; }
.profile-card h2 { margin: 12px 0 6px; font-size: 18px; }
.bio { color: #888; font-size: 13px; margin: 0; }
.profile-stats { display: flex; justify-content: center; gap: 24px; margin-top: 16px; padding-top: 16px; border-top: 1px solid #f0f0f0; }
.stat { text-align: center; }
.stat b { display: block; font-size: 18px; }
.stat span { font-size: 12px; color: #999; }
.info-card { background: #fff; border-radius: 12px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.info-card h4 { margin: 0 0 12px; font-size: 14px; }
.info-row { display: flex; justify-content: space-between; font-size: 13px; color: #666; padding: 6px 0; }
.info-section h4 { margin: 0 0 12px; }
.grid-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 12px; }
.grid-item { text-align: center; cursor: pointer; }
.grid-icon { width: 56px; height: 56px; border-radius: 12px; }
.grid-name { font-size: 12px; margin-top: 6px; }
.post-list { display: flex; flex-direction: column; gap: 8px; }
.post-item { padding: 12px; background: #f9fafb; border-radius: 8px; cursor: pointer; }
.post-item:hover { background: #f0f2f5; }
.post-title { font-size: 14px; font-weight: 500; }
.post-time { font-size: 12px; color: #999; margin-top: 4px; }
.loading { padding: 40px; }
</style>
