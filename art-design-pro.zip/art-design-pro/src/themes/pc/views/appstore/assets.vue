<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'AppStoreAssets' })
const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('points')
const pointsRecords = ref<any[]>([])
const balanceRecords = ref<any[]>([])

async function load() {
  try {
    const [pRes, bRes] = await Promise.all([
      request.get('/api/operation/points-record/list', { params: { page: 1, pageSize: 50 } }),
      request.get('/api/user/balance-records', { params: { page: 1, pageSize: 50 } })
    ])
    pointsRecords.value = pRes.data?.list || pRes.list || []
    balanceRecords.value = bRes.data?.list || bRes.list || []
  } catch (e) {}
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>我的资产</h2></div>
    <div class="assets-cards"><div class="asset-card balance"><div class="label">余额</div><div class="value">{{ userStore.info?.balance || 0 }}</div></div>
      <div class="asset-card points"><div class="label">积分</div><div class="value">{{ userStore.info?.points || 0 }}</div></div></div>
    <div class="content-card"><el-tabs v-model="activeTab"><el-tab-pane label="积分明细" name="points">
      <div v-for="r in pointsRecords" :key="r.id" class="rec-item"><span>{{ r.type || r.action || '积分变动' }}</span><span class="val" :class="{ plus: r.amount > 0 }">{{ r.amount > 0 ? '+' : '' }}{{ r.amount }}</span><span class="time">{{ r.createTime || r.createdAt }}</span></div>
      <div v-if="!pointsRecords.length" class="empty">暂无记录</div>
    </el-tab-pane><el-tab-pane label="余额明细" name="balance">
      <div v-for="r in balanceRecords" :key="r.id" class="rec-item"><span>{{ r.type || r.action || '余额变动' }}</span><span class="val" :class="{ plus: r.amount > 0 }">{{ r.amount > 0 ? '+' : '' }}{{ r.amount }}</span><span class="time">{{ r.createTime || r.createdAt }}</span></div>
      <div v-if="!balanceRecords.length" class="empty">暂无记录</div>
    </el-tab-pane></el-tabs></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 800px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .assets-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 20px; } .asset-card { border-radius: 12px; padding: 24px; text-align: center; color: #fff; } .balance { background: linear-gradient(135deg, #f093fb, #f5576c); } .points { background: linear-gradient(135deg, #4facfe, #00f2fe); } .label { font-size: 13px; opacity: .85; } .value { font-size: 32px; font-weight: 700; margin-top: 4px; } .content-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .rec-item { display: flex; padding: 10px 0; border-bottom: 1px solid #f8f8f8; font-size: 13px; } .val { margin-left: auto; font-weight: 600; color: #f56c6c; } .val.plus { color: #67c23a; } .time { font-size: 12px; color: #999; margin-left: 12px; } .empty { text-align: center; padding: 40px; color: #999; }</style>
