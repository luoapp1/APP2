<template>
  <div style="padding: 80px 24px; text-align: center; color: #999;">
    <p>浏览足迹功能请在手机上查看</p>
  </div>
</template>

<script setup lang="ts">
defineOptions({ name: 'AppStoreFootprints' })
</script>
