<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchNotifications } from '@/api/message'
import { fmtRelativeTime } from '@/utils'

const router = useRouter()
const notifications = ref<any[]>([])
onMounted(async () => {
  try { const res = await fetchNotifications(); notifications.value = res.data?.list || res.list || [] } catch (e) {}
})
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>系统通知</h2></div>
    <div class="content-card"><div v-for="n in notifications" :key="n.id" class="list-item"><div class="item-title">{{ n.title }}</div><div class="item-desc">{{ n.content }}</div><div class="item-time">{{ fmtRelativeTime(n.createTime || n.createdAt) }}</div></div>
      <div v-if="!notifications.length" class="empty">暂无通知</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 700px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .list-item { padding: 12px 0; border-bottom: 1px solid #f5f5f5; } .item-title { font-size: 15px; font-weight: 500; } .item-desc { font-size: 13px; color: #777; margin: 4px 0; } .item-time { font-size: 12px; color: #aaa; } .empty { text-align: center; padding: 40px; color: #999; }</style>
