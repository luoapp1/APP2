<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchBalanceRecords, fetchPointsRecords, fetchFollowers, fetchContentPurchases, fetchMallOrders, fetchOrders } from '@/api/mine'

const route = useRoute()
const router = useRouter()
const type = computed(() => route.query.type || 'balance')
const records = ref<any[]>([])

const titleMap: Record<string, string> = { balance: '余额明细', points: '积分明细', fans: '粉丝列表', purchases: '付费记录' }

async function load() {
  try {
    if (type.value === 'balance') {
      const res: any = await fetchBalanceRecords({ page: 1, pageSize: 50 })
      records.value = res.data?.list || res.list || []
    } else if (type.value === 'points') {
      const res: any = await fetchPointsRecords({ page: 1, pageSize: 50 })
      records.value = res.data?.list || res.list || []
    } else if (type.value === 'fans') {
      const res: any = await fetchFollowers({ page: 1, pageSize: 50 })
      records.value = res.data?.list || res.list || []
    } else if (type.value === 'purchases') {
      const uid = Number(route.query.userId) || 0
      const [oldRes, mallRes] = await Promise.all([
        fetchOrders(uid).catch(() => ({ list: [] })),
        fetchMallOrders(uid).catch(() => ({ list: [] }))
      ]) as any[]
      const oldOrders = (oldRes?.list || oldRes?.data?.list || []).map((o: any) => ({ ...o, _source: 'settlement' }))
      const mallOrders = (mallRes?.list || mallRes?.data?.list || []).map((o: any) => ({ ...o, _source: 'mall' }))
      records.value = [...oldOrders, ...mallOrders].sort((a, b) => {
        const ta = a.create_time || a.createTime || a.payment_time || ''
        const tb = b.create_time || b.createTime || b.payment_time || ''
        return tb.localeCompare(ta)
      })
    } else { records.value = [] }
  } catch { records.value = [] }
}

onMounted(load)
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>{{ titleMap[type as string] || '明细' }}</h2></div>
    <div class="content-card"><div v-if="!records.length" class="empty">暂无记录</div>
      <div v-for="r in records" :key="r.id" class="rec-item"><div class="rec-title">{{ r.type || r.title || r.action || r.nickname }}</div><div class="rec-amount" :class="{ plus: (r.amount || r.value) > 0 }">{{ r.amount || r.value || r.points || '' }}</div><div class="rec-time">{{ r.createTime || r.createdAt }}</div></div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 700px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .rec-item { display: flex; align-items: center; padding: 12px 0; border-bottom: 1px solid #f5f5f5; } .rec-title { flex: 1; font-size: 14px; } .rec-amount { font-size: 15px; font-weight: 600; color: #f56c6c; } .rec-amount.plus { color: #67c23a; } .rec-time { font-size: 12px; color: #999; margin-left: 16px; } .empty { text-align: center; padding: 60px; color: #999; }</style>
