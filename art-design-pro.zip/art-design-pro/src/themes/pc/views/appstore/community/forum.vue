<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators } from '@/api/community'
import { fmtCount, fmtRelativeTime, stripContent } from '@/utils'

const route = useRoute()
const router = useRouter()

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const activeTab = ref('hot')
const loading = ref(false)
const page = ref(1)
const total = ref(0)

const boardName = computed(() => route.query.name || sectionInfo.value?.name || '板块')

async function loadSection() {
  try {
    const id = route.params.id as string
    const res = await fetchCommunitySection(id)
    sectionInfo.value = res.data || res
  } catch (e) { /* ignore */ }
}

async function loadPosts() {
  loading.value = true
  try {
    const id = route.params.id as string
    const res = await fetchCommunityPosts({
      sectionId: id, sort: activeTab.value,
      page: page.value, pageSize: 20
    })
    postList.value = res.data?.list || res.list || []
    total.value = res.data?.total || res.total || 0
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function loadModerators() {
  try {
    const id = route.params.id as string
    const res = await fetchModerators(id)
    moderators.value = res.data || res || []
  } catch (e) { /* ignore */ }
}

function goPost(id: string) { router.push(`/p/${id}`) }
function goCreate() { router.push(`/p/create/${route.params.id}`) }
function goBack() { router.back() }
function changeTab(tab: string) { activeTab.value = tab; page.value = 1; loadPosts() }

onMounted(() => { loadSection(); loadPosts(); loadModerators() })
</script>

<template>
  <div class="pc-forum-page">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <div>
        <h2>{{ boardName }}</h2>
        <p class="board-stats" v-if="sectionInfo">
          帖子 {{ sectionInfo.postCount || 0 }} · 今日浏览 {{ sectionInfo.todayViewCount || 0 }} · 总浏览 {{ sectionInfo.totalViewCount || 0 }}
        </p>
      </div>
      <el-button type="primary" @click="goCreate">发布帖子</el-button>
    </div>

    <div class="forum-layout">
      <div class="forum-main">
        <div class="tab-bar">
          <el-radio-group v-model="activeTab" size="small" @change="changeTab">
            <el-radio-button value="hot">热门</el-radio-button>
            <el-radio-button value="latest">最新</el-radio-button>
            <el-radio-button value="recent_reply">待回复</el-radio-button>
            <el-radio-button value="essence">精华</el-radio-button>
          </el-radio-group>
        </div>

        <div v-if="loading" class="loading"><el-skeleton :rows="5" animated /></div>
        <div v-else class="post-list">
          <div v-for="p in postList" :key="p.id" class="post-card" @click="goPost(p.id)">
            <el-avatar :size="44" :src="$fixImgUrl(p.avatar || p.user?.avatar)" />
            <div class="post-body">
              <div class="post-header">
                <span class="post-author">{{ p.nickname || p.user?.nickname }}</span>
                <el-tag v-if="p.isPinned" size="small" type="danger">置顶</el-tag>
                <span class="post-time">{{ fmtRelativeTime(p.createTime || p.createdAt) }}</span>
              </div>
              <div class="post-title">{{ p.title }}</div>
              <div class="post-summary">{{ stripContent(p.content || '').slice(0, 150) }}</div>
              <div class="post-stats">
                <span>{{ fmtCount(p.viewCount || 0) }} 浏览</span>
                <span>{{ fmtCount(p.commentCount || 0) }} 回复</span>
                <span>{{ fmtCount(p.likeCount || 0) }} 赞</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="forum-sidebar">
        <div class="sidebar-card" v-if="moderators.length">
          <h4>圈主</h4>
          <div v-for="m in moderators" :key="m.userId || m.id" class="mod-item">
            <el-avatar :size="32" :src="$fixImgUrl(m.avatar)" />
            <span>{{ m.nickname || m.username }}</span>
          </div>
        </div>

        <div class="sidebar-card" v-if="sectionInfo">
          <h4>板块信息</h4>
          <div class="info-row"><span>帖子数</span><span>{{ sectionInfo.postCount || 0 }}</span></div>
          <div class="info-row"><span>今日浏览</span><span>{{ sectionInfo.todayViewCount || 0 }}</span></div>
          <div class="info-row"><span>总浏览</span><span>{{ sectionInfo.totalViewCount || 0 }}</span></div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-forum-page { padding: 0 24px 24px; max-width: 1100px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.board-stats { margin: 4px 0 0; font-size: 12px; color: #999; }
.forum-layout { display: flex; gap: 24px; }
.forum-main { flex: 1; min-width: 0; }
.forum-sidebar { width: 240px; flex-shrink: 0; }
.tab-bar { margin-bottom: 16px; }
.post-list { display: flex; flex-direction: column; gap: 10px; }
.post-card { display: flex; gap: 14px; padding: 16px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; }
.post-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.post-body { flex: 1; min-width: 0; }
.post-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.post-author { font-size: 14px; font-weight: 500; }
.post-time { font-size: 12px; color: #999; margin-left: auto; }
.post-title { font-size: 16px; font-weight: 600; margin-bottom: 6px; }
.post-summary { font-size: 13px; color: #777; line-height: 1.5; margin-bottom: 8px; }
.post-stats { display: flex; gap: 16px; font-size: 12px; color: #aaa; }
.sidebar-card { background: #fff; border-radius: 10px; padding: 16px; margin-bottom: 14px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.sidebar-card h4 { margin: 0 0 12px; font-size: 14px; color: #333; }
.mod-item { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 13px; }
.info-row { display: flex; justify-content: space-between; font-size: 13px; color: #666; padding: 6px 0; }
.loading { padding: 20px; }
</style>
