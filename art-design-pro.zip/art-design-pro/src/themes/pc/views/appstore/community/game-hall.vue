<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const games = ref<any[]>([])

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/list')
    games.value = res.data || []
  } catch {}
})

function enterGame(game: any) {
  if (!game.enabled) return
  const routes: Record<string, string> = {
    lottery: '/community/game-hall/lottery',
    card_guess: '/community/game-hall/card-guess',
    dice: '/community/game-hall/dice',
    rps: '/community/game-hall/rps'
  }
  const path = routes[game.gameType]
  if (path) router.push(path)
}
</script>

<template>
  <div class="pc-game-hall">
    <h2 class="text-2xl font-bold mb-6">游戏大厅</h2>
    <div class="grid grid-cols-2 gap-4">
      <div
        v-for="game in games"
        :key="game.gameType"
        class="p-4 bg-white rounded-xl shadow cursor-pointer hover:shadow-md transition"
        :class="{ 'opacity-50': !game.enabled }"
        @click="enterGame(game)"
      >
        <div class="text-3xl mb-2">{{ game.icon }}</div>
        <div class="font-bold text-lg">{{ game.name }}</div>
        <div class="text-sm text-gray-500">{{ game.desc }}</div>
        <div v-if="!game.enabled" class="text-xs text-red-400 mt-1">维护中</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-game-hall { max-width: 800px; margin: 40px auto; padding: 0 20px; }
</style>
