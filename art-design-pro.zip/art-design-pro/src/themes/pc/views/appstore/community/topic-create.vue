<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { createTopic } from '@/api/community'
import { ElMessage } from 'element-plus'

const router = useRouter()
const form = ref({ name: '', description: '' })
const loading = ref(false)

async function submit() {
  if (!form.value.name.trim()) { ElMessage.warning('请输入话题名称'); return }
  loading.value = true
  try {
    await createTopic(form.value)
    ElMessage.success('创建成功')
    router.back()
  } catch (e: any) { ElMessage.error(e.message || '创建失败') }
  finally { loading.value = false }
}
</script>

<template>
  <div class="pc-topic-create">
    <div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>创建话题</h2></div>
    <div class="form-card">
      <el-form label-position="top">
        <el-form-item label="话题名称"><el-input v-model="form.name" placeholder="输入话题名称" /></el-form-item>
        <el-form-item label="话题描述"><el-input v-model="form.description" type="textarea" :rows="4" placeholder="描述一下这个话题" /></el-form-item>
        <el-form-item><el-button type="primary" :loading="loading" @click="submit" size="large">创建</el-button></el-form-item>
      </el-form>
    </div>
  </div>
</template>

<style scoped>
.pc-topic-create { padding: 0 24px 24px; max-width: 600px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.form-card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
</style>
