<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchCommunityPost, fetchPostComments, createPostComment, likePost, deletePost } from '@/api/community'
import { fmtRelativeTime, fmtCount, stripContent } from '@/utils'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const post = ref<any>(null)
const comments = ref<any[]>([])
const loading = ref(true)
const commentText = ref('')
const submitting = ref(false)

async function loadPost() {
  loading.value = true
  try {
    const id = route.params.id as string
    const res = await fetchCommunityPost(id)
    post.value = res.data || res
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function loadComments() {
  try {
    const id = route.params.id as string
    const res = await fetchPostComments({ postId: id, page: 1, pageSize: 50 })
    comments.value = res.data?.list || res.list || []
  } catch (e) { /* ignore */ }
}

async function submitComment() {
  if (!commentText.value.trim()) return
  submitting.value = true
  try {
    await createPostComment({ postId: route.params.id, content: commentText.value })
    commentText.value = ''
    ElMessage.success('评论成功')
    await loadComments()
  } catch (e: any) { ElMessage.error(e.message || '评论失败') }
  finally { submitting.value = false }
}

async function handleLike() {
  try {
    await likePost(route.params.id as string)
    if (post.value) post.value.isLiked = !post.value.isLiked
  } catch (e) { /* ignore */ }
}

function goBack() { router.back() }

onMounted(() => { loadPost(); loadComments() })
</script>

<template>
  <div class="pc-post-detail">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
    </div>
    <div v-if="loading" class="loading"><el-skeleton :rows="6" animated /></div>
    <div v-else-if="post" class="post-detail-layout">
      <div class="post-main">
        <div class="post-article">
          <h1>{{ post.title }}</h1>
          <div class="post-meta">
            <div class="author">
              <el-avatar :size="36" :src="$fixImgUrl(post.avatar || post.user?.avatar)" />
              <span class="author-name">{{ post.nickname || post.user?.nickname }}</span>
            </div>
            <span class="meta-time">{{ fmtRelativeTime(post.createTime || post.createdAt) }}</span>
          </div>
          <div class="post-content" v-html="post.content || stripContent(post.content || '')"></div>
          <div class="post-actions">
            <el-button :type="post.isLiked ? 'primary' : 'default'" @click="handleLike" :icon="post.isLiked ? 'StarFilled' : 'Star'">
              赞 {{ fmtCount(post.likeCount || 0) }}
            </el-button>
            <span class="stat">{{ fmtCount(post.viewCount || 0) }} 浏览</span>
            <span class="stat">{{ fmtCount(post.commentCount || 0) }} 评论</span>
          </div>
        </div>

        <div class="comment-section">
          <h3>评论 ({{ comments.length }})</h3>
          <div class="comment-input">
            <el-input v-model="commentText" type="textarea" :rows="3" placeholder="写下你的评论..." />
            <div class="comment-submit">
              <el-button type="primary" :loading="submitting" @click="submitComment">发表评论</el-button>
            </div>
          </div>
          <div class="comment-list">
            <div v-for="c in comments" :key="c.id" class="comment-item">
              <el-avatar :size="32" :src="$fixImgUrl(c.avatar || c.user?.avatar)" />
              <div class="comment-body">
                <div class="comment-user">{{ c.nickname || c.user?.nickname }}</div>
                <div class="comment-text" v-html="c.content"></div>
                <div class="comment-time">{{ fmtRelativeTime(c.createTime || c.createdAt) }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-post-detail { padding: 0 24px 24px; max-width: 900px; }
.page-header { padding: 16px 0; margin-bottom: 20px; }
.post-article { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.post-article h1 { margin: 0 0 16px; font-size: 22px; }
.post-meta { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid #f0f0f0; }
.author { display: flex; align-items: center; gap: 10px; }
.author-name { font-size: 14px; font-weight: 500; }
.meta-time { font-size: 13px; color: #999; }
.post-content { font-size: 15px; line-height: 1.8; color: #333; margin-bottom: 20px; }
.post-actions { display: flex; align-items: center; gap: 16px; padding-top: 16px; border-top: 1px solid #f0f0f0; }
.stat { font-size: 13px; color: #999; }
.comment-section { margin-top: 24px; }
.comment-section h3 { margin: 0 0 16px; font-size: 16px; }
.comment-input { margin-bottom: 20px; }
.comment-submit { display: flex; justify-content: flex-end; margin-top: 8px; }
.comment-list { display: flex; flex-direction: column; gap: 14px; }
.comment-item { display: flex; gap: 10px; }
.comment-body { flex: 1; }
.comment-user { font-size: 14px; font-weight: 500; margin-bottom: 4px; }
.comment-text { font-size: 14px; color: #333; line-height: 1.6; }
.comment-time { font-size: 12px; color: #999; margin-top: 4px; }
.loading { padding: 40px; }
</style>
