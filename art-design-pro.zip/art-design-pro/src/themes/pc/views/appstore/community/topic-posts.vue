<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunityPosts } from '@/api/community'
import { fmtCount, fmtRelativeTime } from '@/utils'

const route = useRoute()
const router = useRouter()

const posts = ref<any[]>([])
const loading = ref(true)

async function load() {
  try {
    const res = await fetchCommunityPosts({ topicId: route.params.id, page: 1, pageSize: 30 })
    posts.value = res.data?.list || res.list || []
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

function goPost(id: string) { router.push(`/p/${id}`) }
function goBack() { router.back() }

onMounted(load)
</script>

<template>
  <div class="pc-topic-posts">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <h2>话题帖子</h2>
    </div>
    <div v-if="loading" class="loading"><el-skeleton :rows="5" animated /></div>
    <div v-else class="post-list">
      <div v-for="p in posts" :key="p.id" class="post-card" @click="goPost(p.id)">
        <el-avatar :size="40" :src="$fixImgUrl(p.avatar || p.user?.avatar)" />
        <div class="post-body">
          <div class="post-header">
            <span class="post-author">{{ p.nickname || p.user?.nickname }}</span>
            <span class="post-time">{{ fmtRelativeTime(p.createTime || p.createdAt) }}</span>
          </div>
          <div class="post-title">{{ p.title }}</div>
          <div class="post-stats">
            <span>{{ fmtCount(p.viewCount || 0) }} 浏览</span>
            <span>{{ fmtCount(p.commentCount || 0) }} 回复</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-topic-posts { padding: 0 24px 24px; max-width: 900px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.post-list { display: flex; flex-direction: column; gap: 10px; }
.post-card { display: flex; gap: 14px; padding: 16px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.post-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.post-body { flex: 1; }
.post-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
.post-author { font-size: 14px; font-weight: 500; }
.post-time { font-size: 12px; color: #999; }
.post-title { font-size: 15px; font-weight: 600; }
.post-stats { display: flex; gap: 16px; font-size: 12px; color: #aaa; margin-top: 6px; }
.loading { padding: 20px; }
</style>
