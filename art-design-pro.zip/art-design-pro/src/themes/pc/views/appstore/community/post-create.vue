<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { createCommunityPost, fetchTopics } from '@/api/community'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()

const form = ref({ title: '', content: '', sectionId: route.params.sectionId || '' })
const loading = ref(false)
const showTopicPicker = ref(false)
const topicSearchQuery = ref('')
const availableTopics = ref<any[]>([])
const selectedTopicIds = ref<number[]>([])
const selectedTopicNames = ref<Record<number, string>>({})

const filteredTopics = computed(() => {
  if (!topicSearchQuery.value) return availableTopics.value.slice(0, 20)
  const q = topicSearchQuery.value.toLowerCase()
  return availableTopics.value.filter((t: any) => t.name.toLowerCase().includes(q)).slice(0, 20)
})

async function loadTopics() {
  try {
    const resp = await fetchTopics()
    availableTopics.value = (resp?.list || resp || [])
  } catch {}
}

function toggleTopic(topic: any) {
  const idx = selectedTopicIds.value.indexOf(topic.id)
  if (idx > -1) {
    selectedTopicIds.value.splice(idx, 1)
    delete selectedTopicNames.value[topic.id]
  } else {
    selectedTopicIds.value.push(topic.id)
    selectedTopicNames.value[topic.id] = topic.name
  }
}

function removeTopic(topicId: number) {
  const idx = selectedTopicIds.value.indexOf(topicId)
  if (idx > -1) selectedTopicIds.value.splice(idx, 1)
  delete selectedTopicNames.value[topicId]
}

async function submit() {
  if (!form.value.title.trim()) { ElMessage.warning('请输入标题'); return }
  if (!form.value.content.trim()) { ElMessage.warning('请输入内容'); return }
  loading.value = true
  try {
    await createCommunityPost({
      ...form.value,
      topicId: selectedTopicIds.value[0] || 0,
      topicIds: selectedTopicIds.value
    })
    ElMessage.success('发布成功')
    router.back()
  } catch (e: any) { ElMessage.error(e.message || '发布失败') }
  finally { loading.value = false }
}

function goBack() { router.back() }
onMounted(loadTopics)
</script>

<template>
  <div class="pc-post-create">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <h2>发布帖子</h2>
    </div>
    <div class="form-card">
      <el-form label-position="top">
        <el-form-item label="标题">
          <el-input v-model="form.title" placeholder="请输入帖子标题" maxlength="100" show-word-limit />
        </el-form-item>

        <!-- 话题选择 -->
        <el-form-item label="话题">
          <div class="topic-area">
            <el-tag
              v-for="tid in selectedTopicIds"
              :key="tid"
              closable
              type="info"
              size="small"
              @close="removeTopic(tid)"
              style="margin-right: 6px; margin-bottom: 6px;"
            >
              #{{ selectedTopicNames[tid] || tid }}
            </el-tag>
            <el-popover
              v-model:visible="showTopicPicker"
              placement="bottom-start"
              :width="300"
              trigger="click"
            >
              <template #reference>
                <el-button size="small" @click="showTopicPicker = !showTopicPicker">
                  {{ selectedTopicIds.length > 0 ? '添加话题' : '选择话题' }}
                </el-button>
              </template>
              <el-input v-model="topicSearchQuery" placeholder="搜索话题..." size="small" clearable style="margin-bottom: 8px;" />
              <div style="max-height: 240px; overflow-y: auto;">
                <div
                  v-for="t in filteredTopics"
                  :key="t.id"
                  class="tp-item"
                  :class="{ 'tp-item-on': selectedTopicIds.includes(t.id) }"
                  @click="toggleTopic(t)"
                >
                  <span v-if="t.icon" class="tp-icon">{{ t.icon }}</span>
                  <span class="tp-name">{{ t.name }}</span>
                  <span v-if="t.postCount" class="tp-count">{{ t.postCount }} 帖</span>
                  <el-icon v-if="selectedTopicIds.includes(t.id)" color="#6366f1" style="margin-left: 4px;"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></el-icon>
                </div>
                <div v-if="filteredTopics.length === 0" class="tp-empty">暂无话题</div>
              </div>
            </el-popover>
          </div>
        </el-form-item>

        <el-form-item label="内容">
          <el-input v-model="form.content" type="textarea" :rows="12" placeholder="请输入帖子内容..." />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="loading" @click="submit" size="large">发布</el-button>
          <el-button @click="goBack" size="large">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<style scoped>
.pc-post-create { padding: 0 24px 24px; max-width: 800px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; }
.page-header h2 { margin: 0; font-size: 20px; }
.form-card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.topic-area { display: flex; align-items: center; flex-wrap: wrap; gap: 4px; }
.tp-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; cursor: pointer; border-radius: 6px; transition: background .15s; }
.tp-item:hover { background: #f0f0f0; }
.tp-item-on { background: #edf2ff; color: #6366f1; font-weight: 600; }
.tp-icon { font-size: 16px; }
.tp-name { flex: 1; }
.tp-count { font-size: 11px; color: #adb5bd; }
.tp-empty { padding: 16px; text-align: center; color: #adb5bd; font-size: 13px; }
</style>
