<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { fetchCommunitySections, fetchTopics, fetchCommunityPosts } from '@/api/community'
import { fmtCount, fmtRelativeTime, stripContent } from '@/utils'

const router = useRouter()
const activeTab = ref('boards')
const boards = ref<any[]>([])
const topics = ref<any[]>([])
const hotPosts = ref<any[]>([])
const loading = ref(false)

async function loadData() {
  loading.value = true
  try {
    if (activeTab.value === 'boards') {
      const res = await fetchCommunitySections()
      boards.value = res.data || res || []
    }
    if (activeTab.value === 'topics') {
      const res = await fetchTopics()
      topics.value = res.data?.list || res.list || []
    }
    if (activeTab.value === 'hot') {
      const res = await fetchCommunityPosts({ sort: 'hot', page: 1, pageSize: 20 })
      hotPosts.value = res.data?.list || res.list || []
    }
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

function goBoard(id: string, name: string) { router.push(`/s/${id}?name=${encodeURIComponent(name)}`) }
function goTopic(id: string) { router.push(`/t/${id}`) }
function goPost(id: string) { router.push(`/p/${id}`) }

onMounted(loadData)
</script>

<template>
  <div class="pc-sections-page">
    <div class="page-header"><h2>社区</h2></div>

    <el-tabs v-model="activeTab" @tab-change="loadData">
      <el-tab-pane label="板块" name="boards">
        <div v-if="loading" class="loading"><el-skeleton :rows="4" animated /></div>
        <div v-else class="boards-grid">
          <div v-for="b in boards" :key="b.id" class="board-card" @click="goBoard(b.id, b.name)">
            <div class="board-avatar" :style="{ background: b.iconBgColor || '#667eea' }">
              {{ b.name?.[0] || '?' }}
            </div>
            <div class="board-info">
              <div class="board-name">{{ b.name }}</div>
              <div class="board-heat">今日热度 {{ b.todayHeat || 0 }}</div>
            </div>
          </div>
        </div>
      </el-tab-pane>

      <el-tab-pane label="话题" name="topics">
        <div v-if="loading" class="loading"><el-skeleton :rows="4" animated /></div>
        <div v-else class="boards-grid">
          <div v-for="t in topics" :key="t.id" class="board-card" @click="goTopic(t.id)">
            <div class="board-avatar" :style="{ background: '#67c23a' }">#</div>
            <div class="board-info">
              <div class="board-name">{{ t.name || t.title }}</div>
              <div class="board-heat">{{ fmtCount(t.heat || t.postCount || 0) }} 帖子</div>
            </div>
          </div>
        </div>
      </el-tab-pane>

      <el-tab-pane label="热门帖子" name="hot">
        <div v-if="loading" class="loading"><el-skeleton :rows="4" animated /></div>
        <div v-else class="posts-list">
          <div v-for="p in hotPosts" :key="p.id" class="post-card" @click="goPost(p.id)">
            <el-avatar :size="40" :src="$fixImgUrl(p.avatar || p.user?.avatar)" />
            <div class="post-body">
              <div class="post-header">
                <span class="post-author">{{ p.nickname || p.user?.nickname }}</span>
                <span class="post-time">{{ fmtRelativeTime(p.createTime || p.createdAt) }}</span>
              </div>
              <div class="post-title">{{ p.title }}</div>
              <div class="post-summary">{{ stripContent(p.content || '').slice(0, 120) }}</div>
              <div class="post-stats">
                <span>{{ fmtCount(p.viewCount || 0) }} 浏览</span>
                <span>{{ fmtCount(p.commentCount || 0) }} 评论</span>
                <span>{{ fmtCount(p.likeCount || 0) }} 赞</span>
              </div>
            </div>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<style scoped>
.pc-sections-page { padding: 0 24px 24px; max-width: 1000px; }
.page-header { padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.boards-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px; }
.board-card { display: flex; align-items: center; gap: 14px; padding: 18px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); transition: box-shadow .2s; }
.board-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.board-avatar { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; font-weight: 700; flex-shrink: 0; }
.board-name { font-size: 15px; font-weight: 600; }
.board-heat { font-size: 12px; color: #999; margin-top: 4px; }
.posts-list { display: flex; flex-direction: column; gap: 12px; }
.post-card { display: flex; gap: 14px; padding: 16px; background: #fff; border-radius: 10px; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.post-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.1); }
.post-body { flex: 1; min-width: 0; }
.post-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
.post-author { font-size: 14px; font-weight: 500; color: #333; }
.post-time { font-size: 12px; color: #999; }
.post-title { font-size: 15px; font-weight: 600; margin-bottom: 6px; }
.post-summary { font-size: 13px; color: #777; line-height: 1.5; margin-bottom: 8px; }
.post-stats { display: flex; gap: 16px; font-size: 12px; color: #aaa; }
.loading { padding: 20px; }
</style>
