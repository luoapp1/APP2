<script setup lang="ts">
import { ref } from 'vue'
const msg = ref('PC端暂不支持此游戏，请使用移动端访问')
</script>
<template>
  <div class="p-10 text-center text-gray-500 text-lg">{{ msg }}</div>
</template>
