<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership, fetchRedeemCardKey } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'

const router = useRouter()
const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const activePayMethod = ref('balance')
const agreed = ref(false)
const showCardKeyDialog = ref(false)
const showConfirmModal = ref(false)
const showBenefitsModal = ref(false)
const cardKeyForm = ref({ cardNo: '', password: '' })
const cardKeyMsg = ref('')
const cardKeyLoading = ref(false)
const cardKeyResult = ref<'input' | 'success' | 'fail'>('input')
const showResultModal = ref(false)
const resultSuccess = ref(false)
const resultMsg = ref('')
const pointsMultiplier = ref('1.0')
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)

const isLogin = computed(() => userStore.isLogin)
const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '普通会员')

const expireTimeDisplay = computed(() => {
  const t = userStore.info.expireTime
  if (!t) return ''
  try { const d = new Date(t); if (isNaN(d.getTime())) return ''; return `到期：${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` } catch { return '' }
})

const discountPct = computed(() => { const r = Number(userStore.info.discountRate || 1) * 100; return r % 1 === 0 ? r : r.toFixed(0) })
const balanceStr = computed(() => { const b = Number(userStore.info.balance || 0); return b >= 10000 ? (b/10000).toFixed(2)+'万' : b.toFixed(2) })
const userPointsStr = computed(() => { const p = Number(userStore.info.points || 0); return p >= 10000 ? (p/10000).toFixed(1)+'w' : String(p) })

const availableLevels = computed(() => {
  const cv = currentLevelId.value ? (allLevels.value.find((l:any)=>l.id===currentLevelId.value)?.level??0) : 0
  return allLevels.value.filter((l:any)=>l.status==='1').filter((l:any)=>{ if(!currentLevelId.value) return true; return (l.level||0)>cv||l.id===currentLevelId.value }).sort((a:any,b:any)=>(a.level||0)-(b.level||0))
})

const levelMinPrice = (lvl: any) => { const plans = products.value.filter((p:any)=>p.level_id===lvl.id&&Number(p.price)>0); if(plans.length===0) return lvl.price||0; return Math.min(...plans.map((p:any)=>Number(p.price)||Infinity)) }
const selectedLevelName = computed(() => { const lvl = allLevels.value.find((l:any)=>l.id===selectedLevel.value); return lvl?.name||'' })
const levelPlans = computed(() => { if(!selectedLevel.value) return []; return products.value.filter((p:any)=>p.level_id===selectedLevel.value) })
const selectedPlanInfo = computed(() => { if(!selectedPlan.value) return null; return products.value.find((p:any)=>p.id===selectedPlan.value)||null })

const totalPrice = computed(() => { if(!selectedPlanInfo.value) return '0'; if(activePayMethod.value==='points') return String(selectedPlanInfo.value.points_price||selectedPlanInfo.value.price||0); return String(displayPrice(selectedPlanInfo.value)) })

const couponDiscount = computed(() => {
  if(!selectedCouponInfo.value) return 0; const c = selectedCouponInfo.value; const base = Number(totalPrice.value)
  if(c.type==='fixed'||c.type==='fixed_points') return Math.min(c.value,base)
  if(c.type==='percent'||c.type==='points_percent') { let disc=Math.floor(base*c.value/100*100)/100; if(c.maxDiscount>0&&disc>c.maxDiscount) disc=c.maxDiscount; return Math.min(disc,base) }
  return 0
})
const finalPrice = computed(() => { const tp = Number(totalPrice.value); const d = couponDiscount.value; return String(Math.max(0,tp-d)) })
const selectedCouponName = computed(() => selectedCouponInfo.value?.name||'')
const isPointsCoupon = computed(() => { const t = selectedCouponInfo.value?.type; return t==='fixed_points'||t==='points_percent' })

const expirePreview = computed(() => {
  if(!selectedPlanInfo.value) return '--'; const days = selectedPlanInfo.value.duration_days
  if(days===0) return '永久有效'; const d = new Date(Date.now()+days*86400000)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
})

function displayPrice(p:any) { if(p.is_promo&&(!p.promo_end_time||new Date(p.promo_end_time)>new Date())) return Number(p.price)||0; return Number(p.original_price)||Number(p.price)||0 }
function planPrice(p:any) { return displayPrice(p).toFixed(0) }
function planOriginalPrice(p:any) { if(!(p.is_promo&&(!p.promo_end_time||new Date(p.promo_end_time)>new Date()))) return 0; return Number(p.original_price)||0 }
function durationLabel(days:number) { if(days===0) return '永久'; if(days>=365&&days%365===0) return `${days/365}年`; if(days>=30&&days%30===0) return `${days/30}个月`; return `${days}天` }
function levelShortDesc(lvl:any) { const parts:string[]=[]; if((lvl.discountRate||1)<1) parts.push(`${((lvl.discountRate||1)*10).toFixed(0)}折`); if((lvl.pointsMultiplier||1)>1) parts.push(`${lvl.pointsMultiplier}x积分`); return parts.join(' · ')||'基础权益' }
function isLevelHigher(lvl:any) { if(!currentLevelId.value) return lvl.level===1; return (lvl.level||0)>(allLevels.value.find((l:any)=>l.id===currentLevelId.value)?.level||0) }
function getLevelBenefits(lvl:any) { if(!lvl?.benefits) return ['基础权益']; return lvl.benefits.split(/[,，、]/).filter((b:string)=>b.trim()).map((b:string)=>b.trim()) }

function selectLevel(lvl:any) { selectedLevel.value=lvl.id; const plans=levelPlans.value; if(plans.length>0) selectedPlan.value=plans[0].id; selectedCouponId.value=0; selectedCouponInfo.value=null }
function onCouponSelect(val:number) { if(!val){selectedCouponId.value=0;selectedCouponInfo.value=null}else{const c=usableCoupons.value.find((c:any)=>c.userCouponId===val);selectedCouponId.value=val;selectedCouponInfo.value=c||null} }
function couponLabel(c:any) { const ip=c.type==='fixed_points'||c.type==='points_percent'; const iff=c.type==='fixed'||c.type==='fixed_points'; const pfx=iff?`${ip?'':'¥'}${c.value}${ip?'积分':''}`:`${c.value}折`; const sfx=c.isMultiUse&&c.remainingValue!==null?`(剩${ip?'':'¥'}${c.remainingValue}${ip?'积分':''})`:''; return `${pfx} ${c.name}${sfx}` }
function fmtDate(d:string) { if(!d)return''; try{return new Date(d).toLocaleDateString('zh-CN')}catch{return d} }

async function loadCoupons() {
  if(!isLogin.value||!selectedPlanInfo.value||activePayMethod.value==='cardkey'){usableCoupons.value=[];return}
  try{const res:any=await fetchUsableCoupons({scene:'membership',targetId:selectedLevel.value||0,orderAmount:Number(totalPrice.value),payType:activePayMethod.value});usableCoupons.value=Array.isArray(res)?res:[];if(!usableCoupons.value.find((c:any)=>c.userCouponId===selectedCouponId.value)){selectedCouponId.value=0;selectedCouponInfo.value=null}}catch{usableCoupons.value=[]}
}
watch([selectedPlan,activePayMethod],()=>{selectedCouponId.value=0;selectedCouponInfo.value=null;loadCoupons()})

async function loadProducts() {
  try{const[pr,lr]=await Promise.all([fetchMembershipProducts() as any,fetchGetMembershipLevelList({} as any) as any]);const raw=(pr?.data||pr)||[];const ld=(lr?.data?.records||lr?.records||lr?.data||lr)||[];const ls=Array.isArray(ld)?ld:[];allLevels.value=ls;const en=(Array.isArray(raw)?raw:[]).map((p:any)=>{const lv=ls.find((l:any)=>l.id===p.level_id);return{...p,levelName:lv?.name||''}});if(isLogin.value&&userStore.info.levelId){const cl=ls.find((l:any)=>l.id===userStore.info.levelId);if(cl)pointsMultiplier.value=String(cl.points_multiplier||cl.pointsMultiplier||1.0)}products.value=en;const av=availableLevels.value;if(av.length>0)selectLevel(av[0]);loadCoupons()}catch{}
}

async function showConfirm() { if(!selectedPlan.value||!agreed.value)return; if(!isLogin.value){resultSuccess.value=false;resultMsg.value='请先登录';showResultModal.value=true;return} showConfirmModal.value=true }
async function handleConfirmPay() { showConfirmModal.value=false; await handleBuy() }
async function handleBuy(){
  buyLoading.value=selectedPlan.value
  try{const res:any=await fetchBuyMembership(selectedPlan.value,activePayMethod.value,selectedCouponId.value||undefined);const info=selectedPlanInfo.value;if(info){userStore.info.levelId=info.level_id;userStore.info.levelName=info.levelName||'';userStore.info.expireTime=res?.expireTime||''}resultSuccess.value=true;resultMsg.value='恭喜您成功开通会员，立即享受专属权益';showResultModal.value=true}catch(e:any){resultSuccess.value=false;resultMsg.value=e?.message||e?.msg||e?.data?.msg||'支付失败，请重试';showResultModal.value=true}finally{buyLoading.value=0}
}
async function handleRedeemCardKey(){
  if(!cardKeyForm.value.cardNo||!cardKeyForm.value.password){cardKeyMsg.value='请输入卡号和密码';return}
  cardKeyLoading.value=true;cardKeyMsg.value=''
  try{const data:any=await fetchRedeemCardKey({cardNo:cardKeyForm.value.cardNo,password:cardKeyForm.value.password,userId:userStore.info.userId||0,userName:userStore.info.userName||''});if(data.code===200){cardKeyResult.value='success';cardKeyMsg.value=data.msg||'兑换成功'}else{cardKeyMsg.value=data.msg||'兑换失败'}}catch(e:any){cardKeyMsg.value=e?.message||'兑换失败'}finally{cardKeyLoading.value=false}
}

onMounted(()=>{loadProducts()})
</script>

<template>
  <div class="membership-pc">
    <div class="page-header"><el-button text @click="router.back()"><el-icon><ArrowLeft /></el-icon>返回</el-button><h2>会员中心</h2></div>
    <div class="main-layout">
      <div class="main-content">
        <!-- VIP身份卡 -->
        <div class="hero-card"><div class="hero-bg" /><div class="hero-inner">
          <div class="hero-left">
            <div class="hero-badge"><svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg><span>VIP {{ currentLevelName }}</span></div>
            <div class="hero-sub"><template v-if="isLogin&&userStore.info.expireTime">{{ expireTimeDisplay }}</template><template v-else>开通会员，解锁全部特权</template></div>
          </div>
          <div class="hero-right"><div class="hero-stat"><span class="hs-val">{{ discountPct }}%</span><span class="hs-lbl">折扣率</span></div><div class="hero-vdiv" /><div class="hero-stat"><span class="hs-val">{{ pointsMultiplier }}x</span><span class="hs-lbl">积分加成</span></div><div class="hero-vdiv" /><div class="hero-stat"><span class="hs-val">¥{{ balanceStr }}</span><span class="hs-lbl">账户余额</span></div></div>
        </div></div>

        <!-- 选择等级 -->
        <div class="section"><div class="sec-head"><h3>选择会员等级</h3><el-button text type="primary" @click="showBenefitsModal=true">权益对比</el-button></div>
          <div class="level-grid"><div v-for="lvl in availableLevels" :key="lvl.id" class="level-card" :class="{active:selectedLevel===lvl.id,current:lvl.id===currentLevelId}" @click="selectLevel(lvl)"><div class="lv-head"><span class="lv-name">{{ lvl.name }}</span><span v-if="lvl.id===currentLevelId" class="lv-tag cur">当前</span><span v-else-if="isLevelHigher(lvl)" class="lv-tag rec">推荐</span></div><div class="lv-price"><span class="lv-sym">¥</span><span class="lv-num">{{ levelMinPrice(lvl)||'--' }}</span><span class="lv-per">/起</span></div><div v-if="selectedLevel===lvl.id" class="lv-bar" /></div></div>
        </div>

        <!-- 选择时长 -->
        <div v-if="levelPlans.length>0" class="section"><div class="sec-head"><h3>选择时长</h3></div>
          <div class="plan-grid"><div v-for="p in levelPlans" :key="p.id" class="plan-card" :class="{active:selectedPlan===p.id}" @click="selectedPlan=p.id"><div class="plan-dur">{{ durationLabel(p.duration_days) }}</div><div class="plan-pr"><span class="plan-sym">¥</span><span class="plan-num">{{ planPrice(p) }}</span></div><div v-if="planOriginalPrice(p)>Number(planPrice(p))" class="plan-old">¥{{ planOriginalPrice(p) }}</div><div v-if="p.is_promo&&(!p.promo_end_time||new Date(p.promo_end_time)>new Date())" class="plan-tag">限时</div></div></div>
        </div>

        <!-- 优惠券 -->
        <div v-if="isLogin" class="section"><div class="sec-head"><h3>选择优惠券</h3><span class="sec-sub">{{ usableCoupons.length }}张可用</span></div><el-select v-model="selectedCouponId" placeholder="不使用优惠券" clearable class="coupon-select" @change="onCouponSelect"><el-option :value="0" label="不使用优惠券" /><el-option v-for="c in usableCoupons" :key="c.userCouponId" :value="c.userCouponId" :label="couponLabel(c)"><div class="coupon-option"><span>{{ couponLabel(c) }}</span><span class="coupon-expire">{{ c.expireTime?'到期 '+fmtDate(c.expireTime):'' }}</span></div></el-option></el-select></div>

        <!-- 支付方式 -->
        <div class="section"><div class="sec-head"><h3>支付方式</h3></div>
          <div class="payment-grid"><div class="payment-card" :class="{active:activePayMethod==='balance'}" @click="activePayMethod='balance'"><span class="pay-icon pay-ico-b">¥</span><div><div class="pay-name">余额支付</div><div v-if="isLogin" class="pay-info">余额 ¥{{ balanceStr }}</div></div></div><div class="payment-card" :class="{active:activePayMethod==='points'}" @click="activePayMethod='points'"><span class="pay-icon pay-ico-p">P</span><div><div class="pay-name">积分支付</div><div v-if="isLogin" class="pay-info">积分 {{ userPointsStr }}</div></div></div><div class="payment-card" @click="handleCardKeyClick"><span class="pay-icon pay-ico-k">K</span><div><div class="pay-name">卡密兑换</div><div class="pay-info">使用兑换码开通</div></div></div></div>
        </div>

        <div class="agreement-row" @click="agreed=!agreed"><el-checkbox :model-value="agreed" /><span>已阅读并同意 <span class="link-text">《会员服务协议》</span></span></div>
      </div>

      <!-- 右侧面板 -->
      <div class="side-panel"><div class="side-card">
        <div class="side-title">订单概要</div>
        <div v-if="selectedPlanInfo" class="side-order">
          <div class="so-row"><span>等级</span><span class="so-v">{{ selectedLevelName }}</span></div>
          <div class="so-row"><span>套餐</span><span class="so-v">{{ selectedPlanInfo.name||selectedPlanInfo.levelName }}</span></div>
          <div class="so-row"><span>时长</span><span class="so-v">{{ durationLabel(selectedPlanInfo.duration_days) }}</span></div>
          <div class="so-row"><span>支付方式</span><span class="so-v">{{ activePayMethod==='points'?'积分支付':'余额支付' }}</span></div>
          <div v-if="selectedCouponName" class="so-row"><span>优惠券</span><span class="so-v coupon-v">{{ selectedCouponName }}</span></div>
          <div class="so-div" />
          <div class="so-total"><span>应付</span><span class="so-tv">¥{{ finalPrice }}</span></div>
          <div v-if="couponDiscount>0" class="so-saved">已优惠 {{ isPointsCoupon?'':'¥' }}{{ couponDiscount }}{{ isPointsCoupon?'积分':'' }}</div>
          <div class="so-row"><span>有效期至</span><span class="so-v">{{ expirePreview }}</span></div>
        </div>
        <div v-else class="side-empty">请选择会员等级和套餐</div>
        <el-button type="primary" size="large" class="buy-btn" :disabled="!selectedPlan||!agreed" :loading="buyLoading>0" @click="showConfirm">{{ buyLoading>0?'支付中...':'立即开通' }}</el-button>
      </div></div>
    </div>

    <!-- 权益对比弹窗 -->
    <el-dialog v-model="showBenefitsModal" title="会员权益对比" width="780px">
      <div class="benefits-grid"><div v-for="lvl in availableLevels" :key="lvl.id" class="benefit-card" :class="{current:lvl.id===currentLevelId}"><div class="benefit-card-head"><div class="benefit-level-name">{{ lvl.name }}</div><div class="benefit-level-price"><span class="bp-sym">¥</span><span class="bp-num">{{ levelMinPrice(lvl)||'免费' }}</span><span v-if="levelMinPrice(lvl)" class="bp-unit">/起</span></div></div><div class="benefit-card-desc">{{ levelShortDesc(lvl) }}</div><ul class="benefit-list"><li v-for="(b,idx) in getLevelBenefits(lvl)" :key="idx" class="benefit-item"><el-icon :size="14" class="b-check"><Check /></el-icon><span>{{ b }}</span></li></ul></div></div>
    </el-dialog>

    <!-- 确认支付弹窗 -->
    <el-dialog v-model="showConfirmModal" width="420px" class="pay-dialog" :close-on-click-modal="false">
      <template #header><div class="pay-dlg-title">确认支付</div></template>
      <div class="pay-dlg-body">
        <div class="pay-dlg-product"><div class="pay-dlg-icon"><svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg></div><div class="pay-dlg-name">{{ selectedPlanInfo?.name||selectedPlanInfo?.levelName }}</div><div class="pay-dlg-price">¥{{ totalPrice }}</div></div>
        <div class="pay-dlg-rows"><div class="pdr-item"><span>会员等级</span><span>{{ selectedLevelName }}</span></div><div class="pdr-item"><span>套餐时长</span><span>{{ selectedPlanInfo?durationLabel(selectedPlanInfo.duration_days):'' }}</span></div><div class="pdr-item"><span>支付方式</span><span class="pdr-green">{{ activePayMethod==='points'?'积分支付':'余额支付' }}</span></div><template v-if="selectedCouponName"><div class="pdr-item"><span>优惠券</span><span class="pdr-accent">{{ selectedCouponName }} (-{{ isPointsCoupon?couponDiscount+'积分':'¥'+couponDiscount }})</span></div></template><div class="pdr-item pdr-total"><span>实付金额</span><span class="pdr-red">{{ activePayMethod==='points'?finalPrice+'积分':'¥'+finalPrice }}</span></div><div class="pdr-item"><span>有效期至</span><span>{{ expirePreview }}</span></div></div>
      </div>
      <template #footer><el-button @click="showConfirmModal=false" class="cancel-btn">取消</el-button><el-button type="primary" :loading="buyLoading>0" @click="handleConfirmPay" class="pay-btn-confirm">{{ buyLoading>0?'支付中...':'确认支付 ¥'+finalPrice }}</el-button></template>
    </el-dialog>

    <!-- 结果弹窗 -->
    <el-dialog v-model="showResultModal" width="360px" class="result-dialog" :close-on-click-modal="false">
      <div class="res-body"><div class="res-icon-wrap"><el-icon v-if="resultSuccess" :size="56" class="res-ok"><CircleCheckFilled /></el-icon><el-icon v-else :size="56" class="res-fail"><CircleCloseFilled /></el-icon></div><div class="res-title">{{ resultSuccess?'支付成功':'支付失败' }}</div><div class="res-msg">{{ resultMsg }}</div></div>
      <template #footer><el-button type="primary" @click="showResultModal=false" class="res-btn">我知道了</el-button></template>
    </el-dialog>

    <!-- 卡密兑换 -->
    <el-dialog v-model="showCardKeyDialog" title="卡密兑换" width="400px">
      <template v-if="cardKeyResult==='success'"><div class="res-body"><div class="res-icon-wrap"><el-icon :size="56" class="res-ok"><CircleCheckFilled /></el-icon></div><div class="res-msg">{{ cardKeyMsg }}</div></div><template #footer><el-button type="primary" @click="showCardKeyDialog=false">我知道了</el-button></template></template>
      <template v-else><el-form label-position="top"><el-form-item label="卡号"><el-input v-model="cardKeyForm.cardNo" placeholder="请输入卡号" /></el-form-item><el-form-item label="卡密密码"><el-input v-model="cardKeyForm.password" placeholder="请输入卡密密码" /></el-form-item></el-form><div v-if="cardKeyMsg&&cardKeyResult!=='success'" class="ck-err">{{ cardKeyMsg }}</div><template #footer><el-button @click="showCardKeyDialog=false">取消</el-button><el-button type="primary" :loading="cardKeyLoading" @click="handleRedeemCardKey">确认兑换</el-button></template></template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.membership-pc { padding: 0 24px 40px; max-width: 1140px; }
.page-header { display: flex; align-items: center; gap: 8px; padding: 20px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; h2 { margin: 0; font-size: 20px; font-weight: 600; color: #1a1a1a; } }
.main-layout { display: flex; gap: 24px; align-items: flex-start; }
.main-content { flex: 1; min-width: 0; }

// Hero
.hero-card { background: linear-gradient(135deg,#0f0c29,#302b63,#24243e); border-radius: 16px; position: relative; overflow: hidden; margin-bottom: 18px; }
.hero-bg { position: absolute; right: -40px; top: -40px; width: 220px; height: 220px; border-radius: 50%; background: radial-gradient(circle,rgba(251,191,36,0.06),transparent 70%); pointer-events: none; }
.hero-inner { position: relative; z-index: 1; display: flex; justify-content: space-between; align-items: center; padding: 28px 32px; }
.hero-left { color: #fff; }
.hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(251,191,36,0.15); border: 1px solid rgba(251,191,36,0.25); border-radius: 20px; padding: 5px 16px 5px 8px; color: #fbbf24; font-size: 15px; font-weight: 700; margin-bottom: 8px; }
.hero-sub { font-size: 13px; color: rgba(255,255,255,0.55); }
.hero-right { display: flex; align-items: center; background: rgba(255,255,255,0.05); border-radius: 12px; padding: 14px 24px; }
.hero-stat { text-align: center; padding: 0 18px; }
.hs-val { display: block; font-size: 22px; font-weight: 700; color: #fff; line-height: 1.3; }
.hs-lbl { display: block; font-size: 11px; color: rgba(255,255,255,0.45); margin-top: 2px; }
.hero-vdiv { width: 1px; height: 36px; background: rgba(255,255,255,0.1); }

// Sections
.section { background: #fff; border-radius: 12px; padding: 20px 24px; margin-bottom: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
.sec-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; h3 { margin: 0; font-size: 15px; font-weight: 600; color: #1a1a1a; } }
.sec-sub { font-size: 13px; color: #999; }

// Level grid
.level-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(158px,1fr)); gap: 10px; }
.level-card { position: relative; border: 2px solid #eef0f4; border-radius: 12px; padding: 16px; cursor: pointer; transition: all .2s; overflow: hidden; &:hover{border-color:#ccd0d8} &.active{border-color:var(--el-color-primary);background:rgba(var(--el-color-primary-rgb,64,158,255),0.03)} &.current{border-color:#fbbf24;background:rgba(251,191,36,0.03)} }
.lv-head { display: flex; align-items: center; gap: 6px; margin-bottom: 12px; }
.lv-name { font-size: 14px; font-weight: 600; color: #1a1a1a; }
.lv-tag { font-size: 10px; padding: 1px 7px; border-radius: 8px; font-weight: 500; &.cur{background:rgba(251,191,36,0.15);color:#d97706} &.rec{background:rgba(239,68,68,0.08);color:#ef4444} }
.lv-price { display: flex; align-items: baseline; gap: 1px; }
.lv-sym { font-size: 13px; font-weight: 600; color: #ef4444; }
.lv-num { font-size: 26px; font-weight: 700; color: #1a1a1a; line-height: 1; }
.lv-per { font-size: 11px; color: #999; }
.lv-bar { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: var(--el-color-primary); border-radius: 0 0 12px 12px; }

// Plans
.plan-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(120px,1fr)); gap: 8px; }
.plan-card { position: relative; border: 2px solid #eef0f4; border-radius: 12px; padding: 14px 10px; text-align: center; cursor: pointer; transition: all .2s; &:hover{border-color:#ccd0d8} &.active{border-color:var(--el-color-primary);background:rgba(var(--el-color-primary-rgb,64,158,255),0.04)} }
.plan-dur { font-size: 13px; font-weight: 600; color: #666; margin-bottom: 6px; }
.plan-pr { display: flex; align-items: baseline; justify-content: center; gap: 1px; }
.plan-sym { font-size: 13px; font-weight: 600; color: #ef4444; }
.plan-num { font-size: 24px; font-weight: 700; color: #1a1a1a; line-height: 1; }
.plan-old { font-size: 12px; color: #bbb; text-decoration: line-through; margin-top: 3px; }
.plan-tag { position: absolute; top: -1px; right: -1px; background: #ef4444; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 0 10px 0 10px; }

// Coupon
.coupon-select { width: 100%; }
.coupon-option { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.coupon-expire { font-size: 12px; color: #aaa; white-space: nowrap; }

// Payment
.payment-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; }
.payment-card { display: flex; align-items: center; gap: 12px; border: 2px solid #eef0f4; border-radius: 12px; padding: 16px; cursor: pointer; transition: all .2s; &:hover{border-color:#ccd0d8} &.active{border-color:var(--el-color-primary);background:rgba(var(--el-color-primary-rgb,64,158,255),0.04)} }
.pay-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 700; color: #fff; flex-shrink: 0; }
.pay-ico-b { background: linear-gradient(135deg,#f59e0b,#d97706); }
.pay-ico-p { background: linear-gradient(135deg,#6366f1,#4f46e5); }
.pay-ico-k { background: linear-gradient(135deg,#8b5cf6,#7c3aed); }
.pay-name { font-size: 14px; font-weight: 600; color: #333; }
.pay-info { font-size: 12px; color: #999; margin-top: 2px; }
.agreement-row { display: flex; align-items: center; gap: 6px; padding: 16px 0; cursor: pointer; font-size: 13px; color: #777; user-select: none; }
.link-text { color: var(--el-color-primary); }

// Side panel
.side-panel { width: 300px; flex-shrink: 0; position: sticky; top: 16px; }
.side-card { background: #fff; border-radius: 14px; padding: 22px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
.side-title { font-size: 15px; font-weight: 600; color: #1a1a1a; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #f0f0f0; }
.so-row { display: flex; justify-content: space-between; padding: 7px 0; font-size: 13px; color: #888; }
.so-v { color: #444; font-weight: 500; }
.so-div { height: 1px; background: #f0f0f0; margin: 8px 0; }
.so-total { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; font-size: 14px; font-weight: 600; }
.so-tv { font-size: 22px; color: #ef4444; font-weight: 700; }
.so-saved { text-align: right; font-size: 13px; color: #67c23a; padding: 2px 0; }
.side-empty { text-align: center; color: #bbb; padding: 24px 0; font-size: 13px; }
.buy-btn { width: 100%; height: 44px; font-size: 15px; font-weight: 600; border-radius: 10px; margin-top: 16px; }
.coupon-v { color: #67c23a !important; font-size: 12px; }

// Benefits dialog
.benefits-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(210px,1fr)); gap: 14px; }
.benefit-card { border: 1px solid #eee; border-radius: 12px; padding: 18px; background: #fafbfc; &.current{border-color:#fbbf24;background:rgba(251,191,36,0.03)} }
.benefit-card-head { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
.benefit-level-name { font-size: 15px; font-weight: 600; color: #1a1a1a; }
.benefit-level-price { display: flex; align-items: baseline; gap: 1px; }
.bp-sym { font-size: 12px; color: #ef4444; font-weight: 600; }
.bp-num { font-size: 20px; font-weight: 700; color: #1a1a1a; }
.bp-unit { font-size: 11px; color: #999; }
.benefit-card-desc { font-size: 12px; color: #999; margin-bottom: 14px; }
.benefit-list { list-style: none; padding: 0; margin: 0; }
.benefit-item { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #555; padding: 5px 0; }
.b-check { color: #67c23a; flex-shrink: 0; }

// Confirm dialog
.pay-dialog { :deep(.el-dialog__body){padding:0 24px 10px} :deep(.el-dialog__header){padding:20px 24px 0;margin:0} :deep(.el-dialog__footer){padding:16px 24px 20px} }
.pay-dlg-title { font-size: 17px; font-weight: 600; color: #1a1a1a; }
.pay-dlg-body { text-align: center; }
.pay-dlg-product { display: flex; align-items: center; gap: 12px; padding: 16px; background: #f8f9fb; border-radius: 12px; margin-bottom: 16px; }
.pay-dlg-icon { width: 48px; height: 48px; border-radius: 12px; background: linear-gradient(135deg,#6366f1,#8b5cf6); display: flex; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; }
.pay-dlg-name { flex: 1; text-align: left; font-size: 14px; font-weight: 600; color: #333; }
.pay-dlg-price { font-size: 22px; font-weight: 700; color: #ef4444; }
.pay-dlg-rows { background: #fafbfc; border-radius: 10px; padding: 12px 16px; }
.pdr-item { display: flex; justify-content: space-between; padding: 8px 0; font-size: 13px; color: #999; &:not(:last-child){border-bottom:1px solid #f0f0f0} span:last-child{color:#444;font-weight:500} }
.pdr-total { span{font-size:14px;font-weight:600;color:#1a1a1a!important} .pdr-red{font-size:18px!important;color:#ef4444!important;font-weight:700!important} }
.pdr-green { color: #4ade80 !important; }
.pdr-accent { color: #f59e0b !important; font-size: 12px !important; }
.cancel-btn { border-radius: 8px; }
.pay-btn-confirm { border-radius: 8px; font-weight: 600; }

// Result dialog
.res-body { text-align: center; padding: 10px 0; }
.res-icon-wrap { margin-bottom: 14px; }
.res-ok { color: #4ade80; }
.res-fail { color: #ef4444; }
.res-title { font-size: 17px; font-weight: 600; color: #1a1a1a; margin-bottom: 8px; }
.res-msg { font-size: 14px; color: #888; line-height: 1.6; }
.res-btn { border-radius: 8px; font-weight: 600; width: 100%; }
.ck-err { color: #ef4444; font-size: 13px; padding: 4px 0 8px; }
</style>
