<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'

const router = useRouter()
const userStore = useUserStore()
</script>
<template>
  <div class="pc-page"><div class="page-header"><el-button text @click="router.back()">&larr; 返回</el-button><h2>会员中心</h2></div>
    <div class="content-card"><div class="member-info"><el-avatar :size="64" :src="$fixImgUrl(userStore.info?.avatar)" /><div><h3>{{ userStore.info?.nickname || userStore.info?.username }}</h3><p>{{ userStore.info?.levelName || '普通用户' }} · 到期 {{ userStore.info?.expireTime || '-' }}</p></div></div>
      <div class="empty">会员功能开发中...</div></div></div>
</template>
<style scoped>.pc-page { padding: 0 24px 24px; max-width: 700px; } .page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 24px; } .page-header h2 { margin: 0; font-size: 20px; } .content-card { background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.06); } .member-info { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; } .member-info h3 { margin: 0 0 4px; } .member-info p { margin: 0; font-size: 13px; color: #999; } .empty { text-align: center; padding: 40px; color: #999; }</style>
