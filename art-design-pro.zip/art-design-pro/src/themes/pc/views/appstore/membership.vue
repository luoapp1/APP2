<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership, fetchRedeemCardKey } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'
import request from '@/utils/http'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const activePayMethod = ref('balance')
const agreed = ref(false)
const showCardKeyDialog = ref(false)
const showConfirmModal = ref(false)
const showBenefitsModal = ref(false)
const cardKeyForm = ref({ cardNo: '', password: '' })
const cardKeyMsg = ref('')
const cardKeyLoading = ref(false)
const cardKeyResult = ref<'input' | 'success' | 'fail'>('input')
const showResultModal = ref(false)
const resultSuccess = ref(false)
const resultMsg = ref('')
const pointsMultiplier = ref('1.0')
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)
const claimLoading = ref('')
const claimResult = ref<any>(null)
const showClaimResult = ref(false)

const isLogin = computed(() => userStore.isLogin)
const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '普通会员')

const myMemberships = ref<any[]>([])
const fetchMyMemberships = async () => {
  try {
    const res: any = await request.get({ url: '/api/membership/my-memberships', showErrorMessage: false })
    myMemberships.value = res || []
  } catch {}
}
const expireTimeDisplay = computed(() => {
  if (myMemberships.value.length) {
    return myMemberships.value.map(m => `${m.level_name}: ${formatExp(m.expire_time)}`).join('，')
  }
  const t = userStore.info.expireTime
  if (!t) return ''
  try { const d = new Date(t); if (isNaN(d.getTime())) return ''; return `到期：${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` } catch { return '' }
})
function formatExp(t: string) {
  if (!t) return ''
  try { const d = new Date(t); if (isNaN(d.getTime())) return '永久'; return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` } catch { return '' }
}

const discountPct = computed(() => { const r = Number(userStore.info.discountRate || 1) * 100; return r % 1 === 0 ? r : r.toFixed(0) })
const balanceStr = computed(() => { const b = Number(userStore.info.balance || 0); return b >= 10000 ? (b/10000).toFixed(2)+'万' : b.toFixed(2) })
const userPointsStr = computed(() => { const p = Number(userStore.info.points || 0); return p >= 10000 ? (p/10000).toFixed(1)+'w' : String(p) })

const levelThemeColors: Record<number, { primary: string; gradient: string; bg: string }> = {
  0: { primary: '#6366f1', gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', bg: 'rgba(99,102,241,0.06)' },
  1: { primary: '#6366f1', gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', bg: 'rgba(99,102,241,0.06)' },
  2: { primary: '#f59e0b', gradient: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', bg: 'rgba(245,158,11,0.06)' },
  3: { primary: '#f59e0b', gradient: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', bg: 'rgba(245,158,11,0.06)' },
}

function getLevelTheme(lvl: any) {
  const idx = allLevels.value.filter((l:any)=>l.status==='1').sort((a:any,b:any)=>(a.level||0)-(b.level||0)).findIndex((l:any)=>l.id===lvl.id)
  return levelThemeColors[idx] || levelThemeColors[0]
}

const availableLevels = computed(() => {
  const cv = currentLevelId.value ? (allLevels.value.find((l:any)=>l.id===currentLevelId.value)?.level??0) : 0
  return allLevels.value.filter((l:any)=>l.status==='1').filter((l:any)=>products.value.some((p:any)=>p.level_id===l.id)).filter((l:any)=>{ if(!currentLevelId.value) return true; return (l.level||0)>cv||l.id===currentLevelId.value }).sort((a:any,b:any)=>(a.level||0)-(b.level||0))
})

const benefitsLevels = computed(() => {
  const cv = currentLevelId.value ? (allLevels.value.find((l:any)=>l.id===currentLevelId.value)?.level??0) : 0
  return allLevels.value.filter((l:any)=>l.status==='1').filter((l:any)=>{ if(!currentLevelId.value) return true; return (l.level||0)>=cv }).sort((a:any,b:any)=>(a.level||0)-(b.level||0))
})

const levelMinPrice = (lvl: any) => { const plans = products.value.filter((p:any)=>p.level_id===lvl.id&&Number(p.price)>0); if(plans.length===0) return lvl.price||0; return Math.min(...plans.map((p:any)=>Number(p.price)||Infinity)) }
const selectedLevelName = computed(() => { const lvl = allLevels.value.find((l:any)=>l.id===selectedLevel.value); return lvl?.name||'' })
const levelPlans = computed(() => { if(!selectedLevel.value) return []; return products.value.filter((p:any)=>p.level_id===selectedLevel.value) })
const selectedPlanInfo = computed(() => { if(!selectedPlan.value) return null; return products.value.find((p:any)=>p.id===selectedPlan.value)||null })

const totalPrice = computed(() => { if(!selectedPlanInfo.value) return '0'; if(activePayMethod.value==='points') return String(selectedPlanInfo.value.points_price||selectedPlanInfo.value.price||0); return String(displayPrice(selectedPlanInfo.value)) })

const couponDiscount = computed(() => {
  if(!selectedCouponInfo.value) return 0; const c = selectedCouponInfo.value; const base = Number(totalPrice.value)
  if(c.type==='fixed'||c.type==='fixed_points') return Math.min(c.value,base)
  if(c.type==='percent'||c.type==='points_percent') { let disc=Math.floor(base*c.value/100*100)/100; if(c.maxDiscount>0&&disc>c.maxDiscount) disc=c.maxDiscount; return Math.min(disc,base) }
  return 0
})
const finalPrice = computed(() => { const tp = Number(totalPrice.value); const d = couponDiscount.value; return String(Math.max(0,tp-d)) })
const selectedCouponName = computed(() => selectedCouponInfo.value?.name||'')
const isPointsCoupon = computed(() => { const t = selectedCouponInfo.value?.type; return t==='fixed_points'||t==='points_percent' })

const expirePreview = computed(() => {
  if(!selectedPlanInfo.value) return '--'; const days = selectedPlanInfo.value.duration_days
  if(days===0) return '永久有效'; const d = new Date(Date.now()+days*86400000)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
})

const selectedLevelTheme = computed(() => {
  const lvl = allLevels.value.find((l:any)=>l.id===selectedLevel.value)
  return lvl ? getLevelTheme(lvl) : levelThemeColors[0]
})

function displayPrice(p:any) { if(p.is_promo&&(!p.promo_end_time||new Date(p.promo_end_time)>new Date())) return Number(p.price)||0; return Number(p.original_price)||Number(p.price)||0 }
function planPrice(p:any) { return displayPrice(p).toFixed(0) }
function planOriginalPrice(p:any) { if(!(p.is_promo&&(!p.promo_end_time||new Date(p.promo_end_time)>new Date()))) return 0; return Number(p.original_price)||0 }
function durationLabel(days:number) { if(days===0) return '永久'; if(days>=365&&days%365===0) return `${days/365}年`; if(days>=30&&days%30===0) return `${days/30}个月`; return `${days}天` }
function levelShortDesc(lvl:any) { const parts:string[]=[]; if((lvl.discountRate||1)<1) parts.push(`${((lvl.discountRate||1)*10).toFixed(0)}折`); if((lvl.pointsMultiplier||1)>1) parts.push(`${lvl.pointsMultiplier}x积分`); return parts.join(' · ')||'基础权益' }
function isLevelHigher(lvl:any) { if(!currentLevelId.value) return lvl.level===1; return (lvl.level||0)>(allLevels.value.find((l:any)=>l.id===currentLevelId.value)?.level||0) }
function getLevelBenefits(lvl:any) { if(!lvl?.benefits) return ['基础权益']; return lvl.benefits.split(/[,，、]/).filter((b:string)=>b.trim()).map((b:string)=>b.trim()) }
function handleCardKeyClick() { showCardKeyDialog.value = true }

function selectLevel(lvl:any) { selectedLevel.value=lvl.id; const plans=levelPlans.value; if(plans.length>0) selectedPlan.value=plans[0].id; selectedCouponId.value=0; selectedCouponInfo.value=null }
function onCouponSelect(val:number) { if(!val){selectedCouponId.value=0;selectedCouponInfo.value=null}else{const c=usableCoupons.value.find((c:any)=>c.userCouponId===val);selectedCouponId.value=val;selectedCouponInfo.value=c||null} }
function couponLabel(c:any) { const ip=c.type==='fixed_points'||c.type==='points_percent'; const iff=c.type==='fixed'||c.type==='fixed_points'; const pfx=iff?`${ip?'':'¥'}${c.value}${ip?'积分':''}`:`${c.value}折`; const sfx=c.isMultiUse&&c.remainingValue!==null?`(剩${ip?'':'¥'}${c.remainingValue}${ip?'积分':''})`:''; return `${pfx} ${c.name}${sfx}` }
function fmtDate(d:string) { if(!d)return''; try{return new Date(d).toLocaleDateString('zh-CN')}catch{return d} }

async function loadCoupons() {
  if(!isLogin.value||!selectedPlanInfo.value||activePayMethod.value==='cardkey'){usableCoupons.value=[];return}
  try{const res:any=await fetchUsableCoupons({scene:'membership',targetId:selectedLevel.value||0,orderAmount:Number(totalPrice.value),payType:activePayMethod.value});usableCoupons.value=Array.isArray(res)?res:[];if(!usableCoupons.value.find((c:any)=>c.userCouponId===selectedCouponId.value)){selectedCouponId.value=0;selectedCouponInfo.value=null}}catch{usableCoupons.value=[]}
}
watch([selectedPlan,activePayMethod],()=>{selectedCouponId.value=0;selectedCouponInfo.value=null;loadCoupons()})

async function loadProducts() {
  try{const[pr,lr]=await Promise.all([fetchMembershipProducts() as any,fetchGetMembershipLevelList({} as any) as any]);const raw=(pr?.data||pr)||[];const ld=(lr?.data?.records||lr?.records||lr?.data||lr)||[];const ls=Array.isArray(ld)?ld:[];allLevels.value=ls;const en=(Array.isArray(raw)?raw:[]).map((p:any)=>{const lv=ls.find((l:any)=>l.id===p.level_id);return{...p,levelName:lv?.name||''}});if(isLogin.value&&userStore.info.levelId){const cl=ls.find((l:any)=>l.id===userStore.info.levelId);if(cl)pointsMultiplier.value=String(cl.points_multiplier||cl.pointsMultiplier||1.0)}products.value=en;const av=availableLevels.value;if(av.length>0)selectLevel(av[0]);loadCoupons();fetchMyMemberships()}catch{}
}

async function showConfirm() { if(!selectedPlan.value||!agreed.value)return; if(!isLogin.value){resultSuccess.value=false;resultMsg.value='请先登录';showResultModal.value=true;return} showConfirmModal.value=true }
async function handleConfirmPay() { showConfirmModal.value=false; await handleBuy() }
async function handleBuy(){
  buyLoading.value=selectedPlan.value
  try{const res:any=await fetchBuyMembership(selectedPlan.value,activePayMethod.value,selectedCouponId.value||undefined);await fetchMyMemberships();if(myMemberships.value.length){const top=myMemberships.value[0];userStore.info.levelId=top.level_id;userStore.info.levelName=top.level_name;userStore.info.expireTime=top.expire_time}resultSuccess.value=true;resultMsg.value='恭喜您成功开通会员，立即享受专属权益';showResultModal.value=true}catch(e:any){resultSuccess.value=false;resultMsg.value=e?.message||e?.msg||e?.data?.msg||'支付失败，请重试';showResultModal.value=true}finally{buyLoading.value=0}
}
async function handleRedeemCardKey(){
  if(!cardKeyForm.value.cardNo||!cardKeyForm.value.password){cardKeyMsg.value='请输入卡号和密码';return}
  cardKeyLoading.value=true;cardKeyMsg.value=''
  try{const data:any=await fetchRedeemCardKey({cardNo:cardKeyForm.value.cardNo,password:cardKeyForm.value.password,userId:userStore.info.userId||0,userName:userStore.info.userName||''});if(data.code===200){cardKeyResult.value='success';cardKeyMsg.value=data.msg||'兑换成功'}else{cardKeyMsg.value=data.msg||'兑换失败'}}catch(e:any){cardKeyMsg.value=e?.message||'兑换失败'}finally{cardKeyLoading.value=false}
}

onMounted(()=>{loadProducts()})

const currentLevelInfo = computed(() => allLevels.value.find((l: any) => l.id === currentLevelId.value))

const dailyGiftDesc = computed(() => {
  const lv = currentLevelInfo.value
  if (!lv || !lv.daily_gift_enabled) return ''
  const parts: string[] = []
  if (Number(lv.daily_gift_points)) parts.push(`${lv.daily_gift_points}积分`)
  if (Number(lv.daily_gift_balance)) parts.push(`¥${lv.daily_gift_balance}`)
  if (Number(lv.daily_gift_experience)) parts.push(`${lv.daily_gift_experience}经验`)
  const days = Number(lv.daily_gift_interval_days) || 1
  return `每${days}天可领: ${parts.join(' + ') || '专属礼包'}`
})

const birthdayGiftDesc = computed(() => {
  const lv = currentLevelInfo.value
  if (!lv) return ''
  const parts: string[] = []
  if (Number(lv.birthday_gift_points)) parts.push(`${lv.birthday_gift_points}积分`)
  if (Number(lv.birthday_gift_balance)) parts.push(`¥${lv.birthday_gift_balance}`)
  if (Number(lv.birthday_gift_experience)) parts.push(`${lv.birthday_gift_experience}经验`)
  if (!parts.length) return ''
  return `生日可领: ${parts.join(' + ')}`
})

async function handleClaimDailyGift() {
  claimLoading.value = 'daily'
  try {
    const res: any = await request.post('/api/membership/claim-daily-gift')
    claimResult.value = { success: true, msg: res?.message || '领取成功', items: res?.data || res }
    showClaimResult.value = true
  } catch (e: any) {
    claimResult.value = { success: false, msg: e?.message || e?.msg || '领取失败' }
    showClaimResult.value = true
  } finally { claimLoading.value = '' }
}

async function handleClaimBirthdayGift() {
  claimLoading.value = 'birthday'
  try {
    const res: any = await request.post('/api/membership/claim-birthday-gift')
    claimResult.value = { success: true, msg: res?.message || '领取成功', items: res?.data || res }
    showClaimResult.value = true
  } catch (e: any) {
    claimResult.value = { success: false, msg: e?.message || e?.msg || '领取失败' }
    showClaimResult.value = true
  } finally { claimLoading.value = '' }
}
</script>

<template>
  <div class="membership-pc-new">
    <div class="page-wrap">
      <!-- Header -->
      <div class="top-bar">
        <el-button text class="back-btn" @click="router.back()">
          <el-icon><ArrowLeft /></el-icon>
        </el-button>
        <h2 class="page-title">会员中心</h2>
      </div>

      <!-- Hero Banner -->
      <div class="hero-banner">
        <div class="hero-glow hero-glow-1" />
        <div class="hero-glow hero-glow-2" />
        <div class="hero-content">
          <div class="hero-text">
            <div class="hero-badge">
              <span class="badge-icon">
                <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
              </span>
              <span class="badge-text">VIP {{ currentLevelName }}</span>
            </div>
            <div class="hero-desc">
              <template v-if="isLogin && myMemberships.length">
                <div class="hero-memberships">
                  <div v-for="m in myMemberships" :key="m.id" class="hero-membership-item">
                    <span class="hero-membership-tag" :style="{ background: m.bg_color || '#667eea', color: m.text_color || '#fff' }">{{ m.level_name }}</span>
                    <span class="hero-membership-expiry">{{ formatExp(m.expire_time) }} 到期</span>
                  </div>
                </div>
              </template>
              <template v-else-if="isLogin && userStore.info.expireTime">您的会员将于 {{ expireTimeDisplay.replace('到期：', '') }} 到期</template>
              <template v-else>开通VIP会员，解锁专属特权，畅享无限精彩</template>
            </div>
          </div>
          <div class="hero-stats">
            <div class="hero-stat-item">
              <div class="hsi-icon hsi-icon-discount">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              </div>
              <div class="hsi-info">
                <span class="hsi-val">{{ discountPct }}%</span>
                <span class="hsi-lbl">会员折扣</span>
              </div>
            </div>
            <div class="hero-stat-item">
              <div class="hsi-icon hsi-icon-points">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
              </div>
              <div class="hsi-info">
                <span class="hsi-val">{{ pointsMultiplier }}x</span>
                <span class="hsi-lbl">积分加成</span>
              </div>
            </div>
            <div class="hero-stat-item">
              <div class="hsi-icon hsi-icon-balance">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
              </div>
              <div class="hsi-info">
                <span class="hsi-val">¥{{ balanceStr }}</span>
                <span class="hsi-lbl">账户余额</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="main-grid">
        <div class="content-col">
          <!-- 专属福利 -->
          <div class="card-block" v-if="isLogin && currentLevelId && currentLevelInfo">
            <div class="block-header">
              <h3 class="block-title">专属福利</h3>
              <span class="block-badge">VIP</span>
            </div>
            <div class="gift-rows">
              <div v-if="currentLevelInfo.daily_gift_enabled" class="gift-row" @click="handleClaimDailyGift">
                <div class="gift-row-icon daily-g">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>
                <div class="gift-row-body">
                  <div class="gift-row-title">定时礼包</div>
                  <div class="gift-row-desc">{{ dailyGiftDesc }}</div>
                </div>
                <el-button type="warning" size="small" :loading="claimLoading === 'daily'" round>领取</el-button>
              </div>
              <div v-if="birthdayGiftDesc" class="gift-row" @click="handleClaimBirthdayGift">
                <div class="gift-row-icon bday-g">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                </div>
                <div class="gift-row-body">
                  <div class="gift-row-title">生日礼包</div>
                  <div class="gift-row-desc">{{ birthdayGiftDesc }}</div>
                </div>
                <el-button type="danger" size="small" :loading="claimLoading === 'birthday'" round>领取</el-button>
              </div>
            </div>
          </div>

          <!-- 选择会员等级 -->
          <div class="card-block">
            <div class="block-header">
              <h3 class="block-title">选择会员等级</h3>
              <el-button text type="primary" size="small" @click="showBenefitsModal=true">权益对比 <el-icon><ArrowRight /></el-icon></el-button>
            </div>
            <div class="level-row">
              <div
                v-for="lvl in availableLevels"
                :key="lvl.id"
                class="level-box"
                :class="{ active: selectedLevel === lvl.id, current: lvl.id === currentLevelId }"
                :style="selectedLevel === lvl.id ? { borderColor: getLevelTheme(lvl).primary, background: getLevelTheme(lvl).bg } : {}"
                @click="selectLevel(lvl)"
              >
                <div v-if="selectedLevel === lvl.id" class="level-box-check">
                  <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                </div>
                <div class="lvl-top">
                  <div class="lvl-name-row">
                    <span class="lvl-name">{{ lvl.name }}</span>
                    <span v-if="lvl.id===currentLevelId" class="lvl-tag current-tag">当前</span>
                    <span v-else-if="isLevelHigher(lvl)" class="lvl-tag hot-tag">推荐</span>
                  </div>
                  <div class="lvl-price">
                    <span class="lvl-cur">¥{{ levelMinPrice(lvl) || '--' }}</span>
                    <span class="lvl-unit">/起</span>
                  </div>
                </div>
                <div class="lvl-bar-wrap">
                  <div class="lvl-bar-bg" />
                  <div class="lvl-bar-fill" :style="{ width: selectedLevel === lvl.id ? '100%' : '0%', background: getLevelTheme(lvl).gradient }" />
                </div>
              </div>
            </div>
          </div>

          <!-- 选择时长 -->
          <div v-if="levelPlans.length > 0" class="card-block">
            <div class="block-header">
              <h3 class="block-title">选择时长</h3>
              <span class="block-sub">{{ selectedLevelName }}</span>
            </div>
            <div class="plan-row">
              <div
                v-for="p in levelPlans"
                :key="p.id"
                class="plan-box"
                :class="{ active: selectedPlan === p.id }"
                :style="selectedPlan === p.id ? { borderColor: selectedLevelTheme.primary, boxShadow: '0 0 0 3px ' + selectedLevelTheme.bg } : {}"
                @click="selectedPlan = p.id"
              >
                <div v-if="selectedPlan === p.id" class="plan-box-badge">
                  <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                </div>
                <div class="plan-box-dur">{{ durationLabel(p.duration_days) }}</div>
                <div class="plan-box-price">
                  <span class="p-sym">¥</span>
                  <span class="p-num">{{ planPrice(p) }}</span>
                </div>
                <div v-if="planOriginalPrice(p) > Number(planPrice(p))" class="plan-old-price">¥{{ planOriginalPrice(p) }}</div>
                <div v-if="p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())" class="plan-promo-tag">限时优惠</div>
              </div>
            </div>
          </div>

          <!-- 优惠券 -->
          <div v-if="isLogin" class="card-block">
            <div class="block-header">
              <h3 class="block-title">选择优惠券</h3>
              <span class="block-sub">{{ usableCoupons.length }} 张可用</span>
            </div>
            <el-select v-model="selectedCouponId" placeholder="不使用优惠券" clearable class="w-full" @change="onCouponSelect">
              <el-option :value="0" label="不使用优惠券" />
              <el-option v-for="c in usableCoupons" :key="c.userCouponId" :value="c.userCouponId" :label="couponLabel(c)">
                <div class="flex-between">
                  <span>{{ couponLabel(c) }}</span>
                  <span class="coupon-date">{{ c.expireTime ? '到期 ' + fmtDate(c.expireTime) : '' }}</span>
                </div>
              </el-option>
            </el-select>
          </div>

          <!-- 支付方式 -->
          <div class="card-block">
            <div class="block-header">
              <h3 class="block-title">支付方式</h3>
            </div>
            <div class="pay-row">
              <div class="pay-box" :class="{ active: activePayMethod === 'balance' }" @click="activePayMethod = 'balance'">
                <div class="pay-box-icon pay-balance">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
                </div>
                <div class="pay-box-info">
                  <div class="pay-box-name">余额支付</div>
                  <div v-if="isLogin" class="pay-box-detail">余额 ¥{{ balanceStr }}</div>
                </div>
              </div>
              <div class="pay-box" :class="{ active: activePayMethod === 'points' }" @click="activePayMethod = 'points'">
                <div class="pay-box-icon pay-points">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><polygon points="12 6 13.5 10.5 18 10.5 14.5 13.5 15.5 18 12 15.5 8.5 18 9.5 13.5 6 10.5 10.5 10.5"/></svg>
                </div>
                <div class="pay-box-info">
                  <div class="pay-box-name">积分支付</div>
                  <div v-if="isLogin" class="pay-box-detail">积分 {{ userPointsStr }}</div>
                </div>
              </div>
              <div class="pay-box" @click="handleCardKeyClick">
                <div class="pay-box-icon pay-cardkey">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="3" y="5" width="18" height="14" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                </div>
                <div class="pay-box-info">
                  <div class="pay-box-name">卡密兑换</div>
                  <div class="pay-box-detail">使用兑换码</div>
                </div>
              </div>
            </div>
          </div>

          <div class="agree-row" @click="agreed = !agreed">
            <div class="agree-check" :class="{ on: agreed }">
              <svg v-if="agreed" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
            </div>
            <span>已阅读并同意 <span class="link">《会员服务协议》</span></span>
          </div>
        </div>

        <!-- 右侧订单面板 -->
        <div class="side-col">
          <div class="order-panel">
            <div class="op-header">
              <span class="op-title">订单概要</span>
            </div>
            <div v-if="selectedPlanInfo" class="op-body">
              <div class="op-product">
                <div class="op-product-icon" :style="{ background: selectedLevelTheme.gradient }">
                  <svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                </div>
                <div class="op-product-info">
                  <div class="op-product-name">{{ selectedPlanInfo.name || selectedPlanInfo.levelName }}</div>
                  <div class="op-product-level">{{ selectedLevelName }} · {{ durationLabel(selectedPlanInfo.duration_days) }}</div>
                </div>
              </div>
              <div class="op-rows">
                <div class="op-row"><span class="op-label">支付方式</span><span class="op-value">{{ activePayMethod === 'points' ? '积分支付' : '余额支付' }}</span></div>
                <div v-if="selectedCouponName" class="op-row"><span class="op-label">优惠券</span><span class="op-value op-coupon">{{ selectedCouponName }}</span></div>
                <div class="op-divider" />
                <div class="op-row op-total"><span>应付金额</span><span class="op-price">¥{{ finalPrice }}</span></div>
                <div v-if="couponDiscount > 0" class="op-saved">已优惠 {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }}</div>
                <div class="op-row op-expire"><span>有效期至</span><span>{{ expirePreview }}</span></div>
              </div>
            </div>
            <div v-else class="op-empty">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="40" height="40" opacity="0.2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              <span>请选择会员等级和套餐</span>
            </div>
            <button class="op-btn" :class="{ disabled: !selectedPlan || !agreed }" :disabled="!selectedPlan || !agreed || buyLoading > 0" @click="showConfirm">
              <span v-if="buyLoading > 0" class="op-btn-loading" />
              <span v-else>{{ buyLoading > 0 ? '支付中...' : '立即开通 ¥' + finalPrice }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 权益对比弹窗 -->
    <el-dialog v-model="showBenefitsModal" title="会员权益对比" width="800px" class="dialog-benefits">
      <div class="bf-grid">
        <div v-for="lvl in benefitsLevels" :key="lvl.id" class="bf-card" :class="{ current: lvl.id === currentLevelId }">
          <div class="bf-card-top">
            <div class="bf-card-name">{{ lvl.name }}</div>
            <div v-if="lvl.id === currentLevelId" class="bf-card-cur">当前</div>
          </div>
          <div class="bf-card-price">
            <span class="bf-sym">¥</span>
            <span class="bf-num">{{ levelMinPrice(lvl) || '免费' }}</span>
            <span v-if="levelMinPrice(lvl)" class="bf-unit">/起</span>
          </div>
          <div class="bf-card-desc">{{ levelShortDesc(lvl) }}</div>
          <ul class="bf-list">
            <li v-for="(b, idx) in getLevelBenefits(lvl)" :key="idx" class="bf-item">
              <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14" class="bf-check"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
              <span>{{ b }}</span>
            </li>
          </ul>
        </div>
      </div>
    </el-dialog>

    <!-- 确认支付弹窗 -->
    <el-dialog v-model="showConfirmModal" width="420px" class="dialog-confirm" :close-on-click-modal="false">
      <template #header><div class="dc-title">确认支付</div></template>
      <div class="dc-body">
        <div class="dc-product">
          <div class="dc-product-icon" :style="{ background: selectedLevelTheme.gradient }">
            <svg viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
          </div>
          <div>
            <div class="dc-product-name">{{ selectedPlanInfo?.name || selectedPlanInfo?.levelName }}</div>
            <div class="dc-product-sub">{{ selectedLevelName }} · {{ selectedPlanInfo ? durationLabel(selectedPlanInfo.duration_days) : '' }}</div>
          </div>
          <div class="dc-product-price">¥{{ totalPrice }}</div>
        </div>
        <div class="dc-rows">
          <div class="dc-row"><span>支付方式</span><span class="dc-green">{{ activePayMethod === 'points' ? '积分支付' : '余额支付' }}</span></div>
          <template v-if="selectedCouponName">
            <div class="dc-row"><span>优惠券</span><span class="dc-accent">{{ selectedCouponName }} (-{{ isPointsCoupon ? couponDiscount + '积分' : '¥' + couponDiscount }})</span></div>
          </template>
          <div class="dc-row dc-row-total"><span>实付金额</span><span class="dc-red">{{ activePayMethod === 'points' ? finalPrice + '积分' : '¥' + finalPrice }}</span></div>
          <div class="dc-row"><span>有效期至</span><span>{{ expirePreview }}</span></div>
        </div>
      </div>
      <template #footer>
        <el-button @click="showConfirmModal = false" class="dc-cancel">取消</el-button>
        <el-button type="primary" :loading="buyLoading > 0" @click="handleConfirmPay" class="dc-confirm" :style="{ background: selectedLevelTheme.gradient, border: 'none' }">
          {{ buyLoading > 0 ? '支付中...' : '确认支付 ¥' + finalPrice }}
        </el-button>
      </template>
    </el-dialog>

    <!-- 结果弹窗 -->
    <el-dialog v-model="showResultModal" width="360px" class="dialog-result" :close-on-click-modal="false">
      <div class="dr-body">
        <div class="dr-icon" :class="{ ok: resultSuccess, fail: !resultSuccess }">
          <svg v-if="resultSuccess" viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          <svg v-else viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/></svg>
        </div>
        <div class="dr-title">{{ resultSuccess ? '支付成功' : '支付失败' }}</div>
        <div class="dr-msg">{{ resultMsg }}</div>
      </div>
      <template #footer>
        <el-button type="primary" @click="showResultModal = false" class="dr-btn">我知道了</el-button>
      </template>
    </el-dialog>

    <!-- 卡密兑换 -->
    <el-dialog v-model="showCardKeyDialog" :title="cardKeyResult === 'success' ? '卡密兑换' : '卡密兑换'" width="400px">
      <template v-if="cardKeyResult === 'success'">
        <div class="dr-body">
          <div class="dr-icon ok">
            <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          </div>
          <div class="dr-msg">{{ cardKeyMsg }}</div>
        </div>
      </template>
      <template v-else>
        <el-form label-position="top">
          <el-form-item label="卡号"><el-input v-model="cardKeyForm.cardNo" placeholder="请输入卡号" /></el-form-item>
          <el-form-item label="卡密密码"><el-input v-model="cardKeyForm.password" placeholder="请输入卡密密码" /></el-form-item>
        </el-form>
        <div v-if="cardKeyMsg && cardKeyResult !== 'success'" class="ck-err">{{ cardKeyMsg }}</div>
      </template>
      <template #footer>
        <template v-if="cardKeyResult === 'success'">
          <el-button type="primary" @click="showCardKeyDialog = false">我知道了</el-button>
        </template>
        <template v-else>
          <el-button @click="showCardKeyDialog = false">取消</el-button>
          <el-button type="primary" :loading="cardKeyLoading" @click="handleRedeemCardKey">确认兑换</el-button>
        </template>
      </template>
    </el-dialog>

    <!-- 礼包领取结果 -->
    <el-dialog v-model="showClaimResult" width="360px" class="dialog-result" :close-on-click-modal="false">
      <div class="dr-body">
        <div class="dr-icon" :class="{ ok: claimResult?.success, fail: !claimResult?.success }">
          <svg v-if="claimResult?.success" viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          <svg v-else viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"/></svg>
        </div>
        <div class="dr-title">{{ claimResult?.success ? '领取成功' : '领取失败' }}</div>
        <div class="dr-msg">{{ claimResult?.msg }}</div>
        <div v-if="claimResult?.success && claimResult?.items" class="dr-items">
          <div v-if="claimResult.items.points" class="dr-item">+{{ claimResult.items.points }} 积分</div>
          <div v-if="claimResult.items.balance" class="dr-item">+¥{{ claimResult.items.balance }} 余额</div>
          <div v-if="claimResult.items.experience" class="dr-item">+{{ claimResult.items.experience }} 经验</div>
          <div v-if="claimResult.items.coupons?.length" class="dr-item">+{{ claimResult.items.coupons.length }} 张优惠券</div>
        </div>
      </div>
      <template #footer><el-button type="primary" @click="showClaimResult = false" class="dr-btn">我知道了</el-button></template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
// Colors
$bg: #f5f6fa;
$card: #ffffff;
$text: #1a1a2e;
$text2: #6b7280;
$text3: #9ca3af;
$border: #eef0f6;

.membership-pc-new {
  min-height: 100vh;
  background: $bg;
}

.page-wrap {
  max-width: 1100px;
  margin: 0 auto;
  padding: 0 20px 60px;
}

// Top bar
.top-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 24px 0 16px;
}
.back-btn {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: $card;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  :deep(.el-icon) { font-size: 18px; }
}
.page-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: $text;
  letter-spacing: -0.3px;
}

// Hero Banner
.hero-banner {
  position: relative;
  background: linear-gradient(135deg, #0c0c2d 0%, #1a1040 30%, #1e1145 60%, #0c0c2d 100%);
  border-radius: 20px;
  padding: 44px 48px;
  overflow: hidden;
  margin-bottom: 28px;
}
.hero-glow {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  pointer-events: none;
}
.hero-glow-1 {
  width: 300px;
  height: 300px;
  background: rgba(99, 102, 241, 0.15);
  top: -80px;
  right: -60px;
}
.hero-glow-2 {
  width: 250px;
  height: 250px;
  background: rgba(168, 85, 247, 0.12);
  bottom: -80px;
  left: 20%;
}
.hero-content {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 32px;
}
.hero-text {
  flex-shrink: 0;
}
.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(251, 191, 36, 0.12);
  border: 1px solid rgba(251, 191, 36, 0.2);
  border-radius: 24px;
  padding: 6px 18px 6px 10px;
  margin-bottom: 14px;
}
.badge-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: linear-gradient(135deg, #f59e0b, #d97706);
  color: #fff;
}
.badge-text {
  font-size: 16px;
  font-weight: 700;
  color: #fbbf24;
  letter-spacing: 0.5px;
}
.hero-desc {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.55);
  max-width: 320px;
  line-height: 1.6;
}

.hero-stats {
  display: flex;
  align-items: center;
  gap: 0;
  background: rgba(255, 255, 255, 0.06);
  border-radius: 16px;
  padding: 20px 28px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.06);
}
.hero-stat-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 20px;
  position: relative;
  &:not(:last-child)::after {
    content: '';
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 1px;
    height: 32px;
    background: rgba(255, 255, 255, 0.08);
  }
}
.hsi-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.hsi-icon-discount { background: rgba(250, 204, 21, 0.15); color: #facc15; }
.hsi-icon-points { background: rgba(99, 102, 241, 0.15); color: #818cf8; }
.hsi-icon-balance { background: rgba(52, 211, 153, 0.15); color: #34d399; }
.hsi-info {
  display: flex;
  flex-direction: column;
}
.hsi-val {
  font-size: 20px;
  font-weight: 700;
  color: #fff;
  line-height: 1.2;
}
.hsi-lbl {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.4);
  margin-top: 2px;
}

// Main grid
.main-grid {
  display: flex;
  gap: 24px;
  align-items: flex-start;
}
.content-col {
  flex: 1;
  min-width: 0;
}

// Card block
.card-block {
  background: $card;
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  transition: box-shadow 0.2s;
  &:hover { box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06); }
}
.block-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
}
.block-title {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  color: $text;
}
.block-badge {
  font-size: 11px;
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 10px;
  background: rgba(251, 191, 36, 0.1);
  color: #d97706;
  letter-spacing: 1px;
}
.block-sub {
  font-size: 12px;
  color: $text3;
}

// Gift rows
.gift-rows { display: flex; flex-direction: column; gap: 10px; }
.gift-row {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  background: #f9fafb;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid transparent;
  &:hover { background: #f3f4f6; border-color: #e5e7eb; }
}
.gift-row-icon {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.daily-g { background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #fff; }
.bday-g { background: linear-gradient(135deg, #f472b6, #ec4899); color: #fff; }
.gift-row-body { flex: 1; min-width: 0; }
.gift-row-title { font-size: 14px; font-weight: 600; color: $text; }
.gift-row-desc { font-size: 12px; color: $text2; margin-top: 2px; }

// Level row
.level-row {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 12px;
}
.level-box {
  position: relative;
  border: 2px solid $border;
  border-radius: 16px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.25s;
  background: #fafbfc;
  &:hover { border-color: #d1d5db; transform: translateY(-1px); }
  &.active { transform: translateY(-2px); }
}
.level-box-check {
  position: absolute;
  top: 12px;
  right: 12px;
  color: var(--el-color-primary);
}
.lvl-top {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.lvl-name-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.lvl-name {
  font-size: 15px;
  font-weight: 700;
  color: $text;
}
.lvl-tag {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 8px;
  font-weight: 600;
}
.current-tag { background: rgba(251, 191, 36, 0.12); color: #d97706; }
.hot-tag { background: rgba(239, 68, 68, 0.08); color: #ef4444; }
.lvl-price {
  display: flex;
  align-items: baseline;
  gap: 4px;
}
.lvl-cur {
  font-size: 30px;
  font-weight: 800;
  color: $text;
  line-height: 1;
}
.lvl-unit {
  font-size: 12px;
  color: $text3;
}
.lvl-bar-wrap {
  margin-top: 16px;
  height: 3px;
  border-radius: 2px;
  overflow: hidden;
  position: relative;
}
.lvl-bar-bg {
  position: absolute;
  inset: 0;
  background: #e5e7eb;
  border-radius: 2px;
}
.lvl-bar-fill {
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  border-radius: 2px;
  transition: width 0.3s ease;
}

// Plan row
.plan-row {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
  gap: 10px;
}
.plan-box {
  position: relative;
  border: 2px solid $border;
  border-radius: 14px;
  padding: 18px 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  background: #fafbfc;
  &:hover { border-color: #d1d5db; }
}
.plan-box-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  color: var(--el-color-primary);
}
.plan-box-dur {
  font-size: 14px;
  font-weight: 600;
  color: $text2;
  margin-bottom: 10px;
}
.plan-box-price {
  display: flex;
  align-items: baseline;
  justify-content: center;
  gap: 2px;
}
.p-sym { font-size: 14px; font-weight: 700; color: #ef4444; }
.p-num { font-size: 26px; font-weight: 800; color: $text; line-height: 1; }
.plan-old-price {
  font-size: 12px;
  color: #cbd5e1;
  text-decoration: line-through;
  margin-top: 4px;
}
.plan-promo-tag {
  position: absolute;
  top: 0;
  right: 0;
  background: linear-gradient(135deg, #ef4444, #f97316);
  color: #fff;
  font-size: 10px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 0 12px 0 12px;
}

// Payment row
.pay-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}
.pay-box {
  display: flex;
  align-items: center;
  gap: 14px;
  border: 2px solid $border;
  border-radius: 14px;
  padding: 16px 18px;
  cursor: pointer;
  transition: all 0.2s;
  &:hover { border-color: #d1d5db; }
  &.active {
    border-color: var(--el-color-primary);
    background: rgba(var(--el-color-primary-rgb, 64, 158, 255), 0.04);
  }
}
.pay-box-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: #fff;
}
.pay-balance { background: linear-gradient(135deg, #f59e0b, #d97706); }
.pay-points { background: linear-gradient(135deg, #6366f1, #4f46e5); }
.pay-cardkey { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
.pay-box-info { flex: 1; }
.pay-box-name { font-size: 14px; font-weight: 600; color: $text; }
.pay-box-detail { font-size: 12px; color: $text3; margin-top: 2px; }

// Agree
.agree-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 0;
  cursor: pointer;
  font-size: 13px;
  color: $text2;
  user-select: none;
}
.agree-check {
  width: 18px;
  height: 18px;
  border-radius: 6px;
  border: 2px solid #d1d5db;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all 0.2s;
  &.on {
    border-color: var(--el-color-primary);
    background: var(--el-color-primary);
    color: #fff;
  }
}

// Side panel
.side-col {
  width: 320px;
  flex-shrink: 0;
  position: sticky;
  top: 20px;
}
.order-panel {
  background: $card;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
}
.op-header {
  padding: 22px 24px 14px;
}
.op-title {
  font-size: 16px;
  font-weight: 700;
  color: $text;
}
.op-body {
  padding: 0 24px 20px;
}
.op-product {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  background: #f9fafb;
  border-radius: 14px;
  margin-bottom: 16px;
}
.op-product-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}
.op-product-info { flex: 1; min-width: 0; }
.op-product-name { font-size: 14px; font-weight: 600; color: $text; }
.op-product-level { font-size: 12px; color: $text3; margin-top: 2px; }
.op-rows { background: #f9fafb; border-radius: 12px; padding: 14px 16px; }
.op-row {
  display: flex;
  justify-content: space-between;
  padding: 7px 0;
  font-size: 13px;
  color: $text2;
}
.op-label { color: $text2; }
.op-value { color: $text; font-weight: 500; }
.op-coupon { color: #059669; font-size: 12px; }
.op-divider { height: 1px; background: #e5e7eb; margin: 6px 0; }
.op-total {
  font-size: 14px;
  font-weight: 600;
  color: $text;
  padding: 10px 0;
}
.op-price { font-size: 24px; font-weight: 800; color: #ef4444; }
.op-saved {
  text-align: right;
  font-size: 13px;
  color: #059669;
  padding-bottom: 4px;
}
.op-expire { font-size: 12px; color: $text3; }
.op-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 36px 24px;
  color: $text3;
  font-size: 13px;
}
.op-btn {
  width: 100%;
  height: 52px;
  border: none;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  &:hover:not(.disabled) { filter: brightness(1.1); }
  &:active:not(.disabled) { transform: scale(0.995); }
  &.disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
}
.op-btn-loading {
  width: 20px;
  height: 20px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

// Benefits dialog
.dialog-benefits {
  :deep(.el-dialog__body) { padding: 8px 24px 24px; }
}
.bf-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 14px;
}
.bf-card {
  border: 2px solid #eef0f6;
  border-radius: 16px;
  padding: 22px;
  background: #fafbfc;
  transition: all 0.2s;
  &.current { border-color: #fbbf24; background: rgba(251, 191, 36, 0.03); }
  &:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
}
.bf-card-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.bf-card-name { font-size: 16px; font-weight: 700; color: $text; }
.bf-card-cur { font-size: 11px; padding: 2px 10px; border-radius: 8px; background: rgba(251, 191, 36, 0.15); color: #d97706; font-weight: 600; }
.bf-card-price { display: flex; align-items: baseline; gap: 3px; margin-bottom: 4px; }
.bf-sym { font-size: 13px; font-weight: 700; color: #ef4444; }
.bf-num { font-size: 28px; font-weight: 800; color: $text; }
.bf-unit { font-size: 12px; color: $text3; }
.bf-card-desc { font-size: 12px; color: $text3; margin-bottom: 16px; }
.bf-list { list-style: none; padding: 0; margin: 0; }
.bf-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #4b5563;
  padding: 6px 0;
}
.bf-check { color: #10b981; flex-shrink: 0; }

// Confirm dialog
.dialog-confirm {
  :deep(.el-dialog__body) { padding: 0 24px 10px; }
  :deep(.el-dialog__header) { padding: 20px 24px 0; margin: 0; }
  :deep(.el-dialog__footer) { padding: 16px 24px 22px; }
}
.dc-title { font-size: 17px; font-weight: 700; color: $text; }
.dc-body { text-align: center; }
.dc-product {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px;
  background: #f9fafb;
  border-radius: 14px;
  margin-bottom: 16px;
}
.dc-product-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}
.dc-product-name {
  flex: 1;
  text-align: left;
  font-size: 14px;
  font-weight: 600;
  color: $text;
}
.dc-product-sub { font-size: 12px; color: $text3; text-align: left; }
.dc-product-price { font-size: 24px; font-weight: 800; color: #ef4444; }
.dc-rows { background: #f9fafb; border-radius: 12px; padding: 14px 16px; }
.dc-row {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  font-size: 13px;
  color: $text2;
  &:not(:last-child) { border-bottom: 1px solid #e5e7eb; }
  span:last-child { color: #374151; font-weight: 500; }
}
.dc-row-total {
  span { font-size: 15px; font-weight: 700; color: $text !important; }
}
.dc-red { font-size: 20px; font-weight: 800; color: #ef4444 !important; }
.dc-green { color: #10b981 !important; }
.dc-accent { color: #f59e0b !important; font-size: 12px !important; }
.dc-cancel { border-radius: 10px; font-weight: 600; }
.dc-confirm { border-radius: 10px; font-weight: 700; font-size: 15px; }

// Result dialog
.dialog-result {
  :deep(.el-dialog__body) { padding: 10px 24px; }
}
.dr-body { text-align: center; padding: 10px 0; }
.dr-icon { margin-bottom: 16px; display: inline-flex; }
.dr-icon.ok { color: #10b981; }
.dr-icon.fail { color: #ef4444; }
.dr-title { font-size: 18px; font-weight: 700; color: $text; margin-bottom: 8px; }
.dr-msg { font-size: 14px; color: $text2; line-height: 1.6; }
.dr-btn { border-radius: 10px; font-weight: 600; width: 100%; }
.dr-items { margin-top: 14px; display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; }
.dr-item { font-size: 12px; padding: 5px 14px; background: #fef3c7; color: #92400e; border-radius: 20px; font-weight: 600; }

.ck-err { color: #ef4444; font-size: 13px; padding: 4px 0 8px; }

// Utils
.w-full { width: 100%; }
.flex-between { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.coupon-date { font-size: 12px; color: $text3; white-space: nowrap; }
.link { color: var(--el-color-primary); cursor: pointer; }
</style>
