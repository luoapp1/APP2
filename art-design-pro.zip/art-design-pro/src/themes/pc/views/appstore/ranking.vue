<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('apps')
const list = ref<any[]>([])
const loading = ref(false)

const tabs = [
  { key: 'apps', label: '应用排行', desc: '发布应用数量' },
  { key: 'posts', label: '帖子排行', desc: '发布帖子数量' },
  { key: 'experience', label: '等级排行', desc: '经验值排行' },
  { key: 'points', label: '积分排行', desc: '累计积分数' },
]

const defaultAvatar = defaultAvatarImg

function getAvatar(u: any) {
  if (u.avatar && (u.avatar.startsWith('http') || u.avatar.startsWith('/'))) return u.avatar
  return defaultAvatar
}

function getMedalStyle(rank: number) {
  if (rank === 1) return { bg: '#FFF7E6', color: '#FAAD14', text: '1' }
  if (rank === 2) return { bg: '#F0F0F0', color: '#999', text: '2' }
  if (rank === 3) return { bg: '#FFF0E6', color: '#D4884A', text: '3' }
  return null
}

const currentUserId = () => userStore.info?.userId || 0

async function loadRanking(type: string) {
  loading.value = true
  try {
    const uid = currentUserId()
    const res: any = await request.get({ url: `/api/ranking/${type}?pageSize=50&userId=${uid}` })
    list.value = (res?.list || []).map((item: any) => {
      if (item.level_icon && !(item.level_icon.startsWith('http') || item.level_icon.startsWith('/') || item.level_icon.startsWith('data:'))) {
        return { ...item, level_icon: '' }
      }
      return item
    })
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function handleFollow(item: any, event: Event) {
  event.stopPropagation()
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return
  }
  try {
    if (item.is_followed) {
      await request.post({ url: `/api/user/${item.user_id}/unfollow` })
      item.is_followed = 0
    } else {
      await request.post({ url: `/api/user/${item.user_id}/follow` })
      item.is_followed = 1
    }
  } catch (e: any) {
    ElMessage.warning(e?.message || '操作失败')
  }
}

function switchTab(key: string) {
  activeTab.value = key
  loadRanking(key)
}

function goProfile(uid: number) {
  router.push(`/u/${uid}`)
}

function goBack() { router.back() }

onMounted(() => loadRanking(activeTab.value))
</script>

<template>
  <div class="pc-ranking">
    <div class="page-header">
      <el-button text @click="goBack">&larr; 返回</el-button>
      <h2>排行榜</h2>
    </div>

    <div class="tab-bar">
      <div
        v-for="t in tabs"
        :key="t.key"
        :class="['tab-item', { active: activeTab === t.key }]"
        @click="switchTab(t.key)"
      >
        <div class="tab-label">{{ t.label }}</div>
        <div class="tab-desc">{{ t.desc }}</div>
      </div>
    </div>

    <div class="rank-list" v-loading="loading">
      <div v-if="!list.length && !loading" class="empty">暂无数据</div>
      <div
        v-for="(item, idx) in list"
        :key="item.user_id"
        class="rank-item"
        @click="goProfile(item.user_id)"
      >
        <div class="rank-num">
          <span v-if="getMedalStyle(idx + 1)" class="medal" :style="{ background: getMedalStyle(idx + 1)!.bg, color: getMedalStyle(idx + 1)!.color }">
            {{ getMedalStyle(idx + 1)!.text }}
          </span>
          <span v-else class="num">{{ idx + 1 }}</span>
        </div>
        <el-avatar :size="44" :src="getAvatar(item)" />
        <div class="user-info">
          <div class="user-name">{{ item.nickname || item.username }}</div>
          <div class="user-stat">
            <span v-if="activeTab === 'apps'">{{ item.count }} 个应用</span>
            <span v-else-if="activeTab === 'posts'">{{ item.count }} 篇帖子</span>
            <span v-else-if="activeTab === 'experience'">
              <img v-if="item.level_icon" :src="item.level_icon" style="width:18px;height:18px;object-fit:contain;vertical-align:middle;margin-right:3px;">{{ item.count }} 经验
            </span>
            <span v-else>{{ item.count }} 积分</span>
          </div>
        </div>
        <el-button
          size="small"
          :type="item.is_followed ? 'default' : 'primary'"
          :disabled="item.user_id === currentUserId()"
          @click="(e: Event) => handleFollow(item, e)"
        >
          {{ item.is_followed ? '已关注' : '+ 关注' }}
        </el-button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pc-ranking { padding: 0 24px 24px; max-width: 800px; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; border-bottom: 1px solid var(--el-border-color-light); margin-bottom: 20px; }
.page-header h2 { margin: 0; font-size: 20px; }
.tab-bar { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
.tab-item { background: #fff; border-radius: 12px; padding: 16px 12px; text-align: center; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.06); border: 2px solid transparent; transition: all .2s; }
.tab-item:hover { box-shadow: 0 4px 12px rgba(0,0,0,.08); }
.tab-item.active { border-color: var(--el-color-primary); background: #f0f5ff; }
.tab-label { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 4px; }
.tab-desc { font-size: 11px; color: #999; }
.rank-list { background: #fff; border-radius: 12px; padding: 8px 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06); min-height: 200px; }
.rank-item { display: flex; align-items: center; gap: 14px; padding: 12px 0; border-bottom: 1px solid #f5f5f5; cursor: pointer; transition: background .15s; }
.rank-item:last-child { border-bottom: none; }
.rank-item:hover { background: #fafbfc; margin: 0 -20px; padding: 12px 20px; }
.rank-num { width: 36px; text-align: center; flex-shrink: 0; }
.medal { display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 50%; font-size: 14px; font-weight: 700; }
.num { font-size: 15px; font-weight: 600; color: #aaa; }
.user-info { flex: 1; }
.user-name { font-size: 15px; font-weight: 500; color: #333; }
.user-stat { font-size: 12px; color: #999; margin-top: 2px; }
.empty { text-align: center; padding: 60px 0; color: #999; font-size: 14px; }
</style>
