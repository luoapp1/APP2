<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchLogin, fetchGetUserInfo } from '@/api/appstore'
import { ElMessage } from 'element-plus'

defineOptions({ name: 'AppStoreLogin' })

const router = useRouter()
const userStore = useUserStore()

const formData = ref({ username: '', password: '', rememberPassword: false })
const loading = ref(false)

async function handleLogin() {
  if (!formData.value.username || !formData.value.password) {
    ElMessage.warning('请输入用户名和密码')
    return
  }
  loading.value = true
  try {
    const res = await fetchLogin(formData.value)
    userStore.setToken(res.data?.token || res.token)
    userStore.setLoginStatus(true)
    const userRes = await fetchGetUserInfo()
    userStore.setUserInfo(userRes.data || userRes)
    ElMessage.success('登录成功')
    router.replace('/appstore/mine')
  } catch (e: any) { ElMessage.error(e.message || '登录失败') }
  finally { loading.value = false }
}
</script>

<template>
  <div class="pc-login">
    <div class="login-card">
      <h2>登录</h2>
      <p class="subtitle">欢迎回到应用商店</p>
      <el-form @submit.prevent="handleLogin">
        <el-form-item><el-input v-model="formData.username" placeholder="用户名" size="large" /></el-form-item>
        <el-form-item><el-input v-model="formData.password" type="password" placeholder="密码" size="large" show-password /></el-form-item>
        <el-form-item>
          <el-checkbox v-model="formData.rememberPassword">记住密码</el-checkbox>
          <a class="forgot" @click="router.push('/auth/forget-password')">忘记密码？</a>
        </el-form-item>
        <el-form-item><el-button type="primary" :loading="loading" @click="handleLogin" size="large" class="login-btn">登录</el-button></el-form-item>
        <div class="register-link">还没有账号？<a @click="router.push('/auth/register')">立即注册</a></div>
      </el-form>
    </div>
  </div>
</template>

<style scoped>
.pc-login { display: flex; justify-content: center; align-items: center; min-height: 70vh; padding: 40px; }
.login-card { width: 400px; background: #fff; border-radius: 16px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.login-card h2 { margin: 0 0 4px; font-size: 24px; text-align: center; }
.subtitle { text-align: center; color: #999; margin-bottom: 28px; font-size: 14px; }
.forgot { float: right; font-size: 13px; color: var(--el-color-primary); cursor: pointer; }
.login-btn { width: 100%; }
.register-link { text-align: center; font-size: 13px; color: #999; }
.register-link a { color: var(--el-color-primary); cursor: pointer; }
</style>
