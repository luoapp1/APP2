<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchLogin, fetchGetUserInfo } from '@/api/appstore'
import { http } from '@/utils/http'
import { HttpError } from '@/utils/http/error'
import { ElMessage } from 'element-plus'

defineOptions({ name: 'AppStoreLogin' })

const router = useRouter()
const userStore = useUserStore()

const formData = ref({ username: '', password: '', rememberPassword: false })
const loading = ref(false)

// 封禁申诉
const banAppealVisible = ref(false)
const banMsg = ref('')
const banUserId = ref(0)
const appealReason = ref('')
const appealLoading = ref(false)

async function handleLogin() {
  if (!formData.value.username || !formData.value.password) {
    ElMessage.warning('请输入用户名和密码')
    return
  }
  loading.value = true
  try {
    const res = await fetchLogin(formData.value)
    userStore.setToken(res.data?.token || res.token)
    userStore.setLoginStatus(true)
    const userRes = await fetchGetUserInfo()
    userStore.setUserInfo(userRes.data || userRes)
    ElMessage.success('登录成功')
    router.replace('/appstore/mine')
  } catch (e: any) {
    if (e instanceof HttpError && e.code === 403 && e.data) {
      const respBody = e.data as any
      const innerData = respBody?.data || respBody
      banUserId.value = innerData.userId || 0
      banMsg.value = e.message || '该账号已被封禁'
      banAppealVisible.value = true
      return
    }
    ElMessage.error(e.message || '登录失败')
  }
  finally { loading.value = false }
}

async function submitAppeal() {
  if (!appealReason.value.trim() || !banUserId.value) return
  appealLoading.value = true
  try {
    const res: any = await http.post('/api/user/appeal', {
      userId: banUserId.value,
      reason: appealReason.value
    })
    if (res.code === 200) {
      ElMessage.success('申诉已提交，请耐心等待管理员审核')
      banAppealVisible.value = false
      appealReason.value = ''
    } else {
      ElMessage.error(res.msg || '提交失败')
    }
  } catch {
    ElMessage.error('提交失败，请稍后重试')
  } finally {
    appealLoading.value = false
  }
}
</script>

<template>
  <div class="pc-login">
    <div class="login-card">
      <h2>登录</h2>
      <p class="subtitle">欢迎回到应用商店</p>
      <el-form @submit.prevent="handleLogin">
        <el-form-item><el-input v-model="formData.username" placeholder="用户名" size="large" /></el-form-item>
        <el-form-item><el-input v-model="formData.password" type="password" placeholder="密码" size="large" show-password /></el-form-item>
        <el-form-item>
          <el-checkbox v-model="formData.rememberPassword">记住密码</el-checkbox>
          <a class="forgot" @click="router.push('/auth/forget-password')">忘记密码？</a>
        </el-form-item>
        <el-form-item><el-button type="primary" :loading="loading" @click="handleLogin" size="large" class="login-btn">登录</el-button></el-form-item>
        <div class="register-link">还没有账号？<a @click="router.push('/auth/register')">立即注册</a></div>
      </el-form>
    </div>

    <!-- 封禁申诉弹窗 -->
    <el-dialog v-model="banAppealVisible" title="账号已被封禁" width="460px" :close-on-click-modal="false">
      <div class="ban-appeal-content">
        <p class="ban-msg">{{ banMsg }}</p>
        <p class="ban-tip">如需申诉解封，请在下方填写申诉理由：</p>
        <el-input
          v-model="appealReason"
          type="textarea"
          :rows="4"
          placeholder="请详细说明申诉理由..."
          maxlength="500"
          show-word-limit
        />
      </div>
      <template #footer>
        <el-button @click="banAppealVisible = false">取消</el-button>
        <el-button type="primary" :loading="appealLoading" :disabled="!appealReason.trim()" @click="submitAppeal">
          提交申诉
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.pc-login { display: flex; justify-content: center; align-items: center; min-height: 70vh; padding: 40px; }
.login-card { width: 400px; background: #fff; border-radius: 16px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
.login-card h2 { margin: 0 0 4px; font-size: 24px; text-align: center; }
.subtitle { text-align: center; color: #999; margin-bottom: 28px; font-size: 14px; }
.forgot { float: right; font-size: 13px; color: var(--el-color-primary); cursor: pointer; }
.login-btn { width: 100%; }
.register-link { text-align: center; font-size: 13px; color: #999; }
.register-link a { color: var(--el-color-primary); cursor: pointer; }

.ban-appeal-content .ban-msg { color: #e74c3c; font-weight: 500; margin-bottom: 8px; }
.ban-appeal-content .ban-tip { color: #666; font-size: 13px; margin-bottom: 12px; }
</style>
