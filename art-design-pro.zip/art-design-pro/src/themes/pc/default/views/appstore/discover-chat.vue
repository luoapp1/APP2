<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchMessages, fetchSendMessage, fetchUploadChatImage, fetchRecallMessage, fetchReportMessage } from '@/api/message'
import { ElMessage, ElMessageBox, ElImageViewer } from 'element-plus'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const messages = ref<any[]>([])
const text = ref('')
const targetUser = ref<any>({})
const uploadingImage = ref(false)
const myUserId = userStore.info?.userId || userStore.info?.id || 0
const previewImgUrl = ref('')

const targetUserId = Number(route.params.targetUserId)

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) avatarMap[`avatar:${match[1]}`] = (mod as any).default
}

const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar.startsWith('http') || avatar.startsWith('/uploads')) return avatar.replace(/^http:\/\//i, 'https://')
  return ''
}

async function load() {
  try {
    const res: any = await fetchMessages(myUserId, targetUserId)
    messages.value = Array.isArray(res) ? res : (res.list || [])
    if (messages.value.length > 0) {
      const last = messages.value[messages.value.length - 1]
      if (last.fromUserId === myUserId) {
        const pm = messages.value.find((m: any) => m.fromUserId !== myUserId)
        if (pm) targetUser.value = { username: pm.fromUserName, avatar: pm.fromUserAvatar || '' }
      } else {
        targetUser.value = { username: last.fromUserName, avatar: last.fromUserAvatar || '' }
      }
    }
    if (targetUserId && !targetUser.value._fromApi) {
      try {
        const user: any = await request.get({ url: `/api/user/${targetUserId}`, showErrorMessage: false })
        if (user) {
          targetUser.value = {
            username: user.nickname || user.username || user.userName || targetUser.value?.username || '',
            avatar: user.avatar || targetUser.value?.avatar || '',
            _fromApi: true
          }
        }
      } catch {}
    }
  } catch (e) {}
  scrollTo()
}

function scrollTo() {
  nextTick(() => { const el = document.querySelector('.msg-end'); if (el) el.scrollIntoView() })
}

async function send(imgUrl?: string) {
  const txt = text.value.trim()
  if (!txt && !imgUrl) return
  try {
    const avatar = userStore.info?.avatar || ''
    const res: any = await fetchSendMessage(
      myUserId,
      userStore.info?.userName || userStore.info?.username || '用户',
      avatar,
      targetUserId,
      txt,
      imgUrl || ''
    )
    messages.value.push(res || { id: Date.now(), fromUserId: myUserId, content: txt, imageUrl: imgUrl, createTime: new Date().toISOString(), isRead: 0, isRecalled: 0, reportStatus: 'none' })
    text.value = ''
    scrollTo()
  } catch (e: any) { ElMessage.error(e.message || '发送失败') }
}

async function onImageChange(e: Event) {
  const target = e.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  uploadingImage.value = true
  try {
    const res: any = await fetchUploadChatImage(file)
    const url = res.url || res.data?.url || ''
    if (url) await send(url)
  } catch { ElMessage.error('图片上传失败') }
  uploadingImage.value = false
  target.value = ''
}

async function handleRecall(msg: any) {
  try {
    await ElMessageBox.confirm('确定撤回该消息？', '提示', { confirmButtonText: '撤回', cancelButtonText: '取消', type: 'warning' })
    await fetchRecallMessage(msg.id, myUserId)
    msg.isRecalled = 1
    msg.content = ''
    msg.imageUrl = ''
    ElMessage.success('消息已撤回')
  } catch {}
}

async function handleReport(msg: any) {
  try {
    const { value: reason } = await ElMessageBox.prompt('请选择或输入举报原因', '举报消息', {
      confirmButtonText: '提交',
      cancelButtonText: '取消',
      inputPlaceholder: '骚扰、色情、诈骗等'
    })
    if (reason) {
      await fetchReportMessage(msg.id, myUserId, 'other', reason)
      msg.reportStatus = 'reported'
      ElMessage.success('举报已提交')
    }
  } catch {}
}

async function copyText(msg: any) {
  try {
    await navigator.clipboard.writeText(msg.content)
    ElMessage.success('已复制')
  } catch {
    ElMessage.error('复制失败')
  }
}

let pollTimer: any = null
onMounted(() => { load(); pollTimer = setInterval(load, 3000) })
import { onUnmounted } from 'vue'
onUnmounted(() => { if (pollTimer) clearInterval(pollTimer) })
</script>
<template>
  <div class="pc-chat">
    <div class="page-header">
      <el-button text @click="router.back()">&larr; 返回</el-button>
      <img v-if="resolveAvatar(targetUser?.avatar)" :src="resolveAvatar(targetUser.avatar)" class="h-8 w-8 rounded-full object-cover" />
      <img v-else src="@imgs/user/avatar.webp" class="h-8 w-8 rounded-full object-cover" />
      <h2>{{ targetUser?.username || '聊天' }}</h2>
    </div>
    <div class="chat-card">
      <div class="msg-area">
        <div v-for="(m) in messages" :key="m.id" :class="['msg', m.fromUserId === myUserId ? 'msg-self' : 'msg-other']">
          <div v-if="m.isRecalled" class="msg-bubble msg-recalled">消息已撤回</div>
          <template v-else>
            <img v-if="m.imageUrl" :src="$fixImgUrl(m.imageUrl)" class="msg-img" @click="previewImgUrl = m.imageUrl" />
            <el-dropdown v-if="m.content" trigger="contextmenu">
              <div :class="['msg-bubble', m.fromUserId === myUserId ? 'msg-self-bubble' : 'msg-other-bubble']">{{ m.content }}</div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-if="m.fromUserId === myUserId" @click="handleRecall(m)">撤回</el-dropdown-item>
                  <el-dropdown-item v-if="m.fromUserId !== myUserId" @click="handleReport(m)">举报</el-dropdown-item>
                  <el-dropdown-item @click="copyText(m)">复制</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          <div class="msg-time">
            <span v-if="m.isRecalled" class="mr-1">已撤回</span>
            <span v-if="m.reportStatus === 'reported'" class="text-red-400 mr-1">[已举报]</span>
            {{ m.createTime?.slice(11, 16) || '' }}
            <span v-if="m.fromUserId === myUserId" class="ml-1 text-gray-300">{{ m.isRead ? '已读' : '未读' }}</span>
          </div>
        </div>
        <div class="msg-end"></div>
      </div>
      <div class="input-area">
        <input ref="imageInput" type="file" accept="image/*" class="hidden" @change="onImageChange" />
        <el-button :loading="uploadingImage" circle class="mr-2" @click="($refs.imageInput as any)?.click()">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        </el-button>
        <el-input v-model="text" placeholder="输入消息..." @keyup.enter="send()">
          <template #append><el-button @click="send()" type="primary" :loading="uploadingImage">发送</el-button></template>
        </el-input>
      </div>
    </div>
    <div v-if="previewImgUrl" class="img-preview-mask" @click="previewImgUrl = ''">
      <img :src="$fixImgUrl(previewImgUrl)" class="img-preview-content" />
    </div>
  </div>
</template>
<style scoped>
.pc-chat { padding: 0 24px 24px; max-width: 700px; height: calc(100vh - 80px); display: flex; flex-direction: column; }
.page-header { display: flex; align-items: center; gap: 16px; padding: 16px 0; flex-shrink: 0; }
.page-header h2 { margin: 0; font-size: 20px; }
.chat-card { background: #fff; border-radius: 12px; flex: 1; display: flex; flex-direction: column; box-shadow: 0 1px 3px rgba(0,0,0,.06); overflow: hidden; }
.msg-area { flex: 1; overflow-y: auto; padding: 16px; }
.msg { margin-bottom: 16px; max-width: 70%; }
.msg-self { margin-left: auto; }
.msg-bubble { padding: 10px 14px; border-radius: 12px; font-size: 14px; line-height: 1.5; }
.msg-self-bubble { background: var(--el-color-primary); color: #fff; border-bottom-right-radius: 4px; }
.msg-other-bubble { background: #f0f2f5; color: #333; border-bottom-left-radius: 4px; }
.msg-recalled { background: #f0f0f0; color: #aaa; font-style: italic; }
.msg-img { max-width: 200px; max-height: 200px; border-radius: 8px; cursor: pointer; object-fit: cover; }
.msg-time { font-size: 11px; color: #aaa; margin-top: 4px; }
.input-area { padding: 12px 16px; border-top: 1px solid #f0f0f0; display: flex; align-items: center; }
.hidden { display: none; }
.img-preview-mask { position: fixed; inset: 0; background: rgba(0,0,0,.8); display: flex; align-items: center; justify-content: center; z-index: 9999; }
.img-preview-content { max-width: 90%; max-height: 90%; object-fit: contain; }
</style>