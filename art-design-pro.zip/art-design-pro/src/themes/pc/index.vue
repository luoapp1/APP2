<!-- 电脑版主题布局 - 侧边栏 + 顶栏 + 内容区 -->
<template>
  <div class="pc-theme">
    <template v-if="showSidebar">
      <aside class="pc-sidebar" :class="{ collapsed: !sidebarOpen }">
        <div class="sidebar-header" @click="navigateToHome">
          <div class="logo-icon">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          </div>
          <span class="logo-text" v-show="sidebarOpen">Art Design Pro</span>
        </div>

        <div class="sidebar-menu">
          <div
            v-for="item in navItems"
            :key="item.path"
            class="menu-item"
            :class="{ active: item.active }"
            @click="$router.push(item.path)"
          >
            <span class="menu-icon" v-html="item.icon"></span>
            <span class="menu-label" v-show="sidebarOpen">{{ item.label }}</span>
          </div>
        </div>

        <div class="sidebar-footer" @click="toggleSidebar">
          <svg :class="{ rotated: !sidebarOpen }" fill="currentColor" viewBox="0 0 24 24" width="20" height="20">
            <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
          </svg>
        </div>
      </aside>
    </template>

    <main class="pc-main" :class="{ 'no-sidebar': !showSidebar }">
      <RouterView />
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'

defineOptions({ name: 'PcTheme' })

const route = useRoute()
const router = useRouter()
const sidebarOpen = ref(true)

const navItems = computed(() => [
  {
    path: '/appstore/browse',
    label: '首页',
    active: route.path === '/appstore/browse' || route.path === '/appstore/browse/',
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>'
  },
  {
    path: '/appstore/category',
    label: '应用',
    active: route.path.startsWith('/appstore/category'),
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>'
  },
  {
    path: '/community',
    label: '社区',
    active: route.path.startsWith('/community'),
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>'
  },
  {
    path: '/appstore/updates',
    label: '发现',
    active: route.path.startsWith('/appstore/updates'),
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8.5 12.5l2 2 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  },
  {
    path: '/appstore/game',
    label: '消息',
    active: route.path.startsWith('/appstore/game'),
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z"/></svg>'
  },
  {
    path: '/appstore/mine',
    label: '我的',
    active: route.path.startsWith('/appstore/mine'),
    icon: '<svg fill="currentColor" viewBox="0 0 24 24" width="22" height="22"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>'
  }
])

const hideRoutePrefixes = ['/operation', '/system', '/dashboard', '/result']
const showSidebar = computed(() => {
  return !hideRoutePrefixes.some(p => route.path.startsWith(p))
})

function toggleSidebar() {
  sidebarOpen.value = !sidebarOpen.value
}

function navigateToHome() {
  router.push('/appstore/browse')
}
</script>

<style scoped>
.pc-theme {
  display: flex;
  min-height: 100vh;
  background: var(--default-bg-color, #f5f5f5);
}

.pc-sidebar {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  width: 220px;
  background: #fff;
  border-right: 1px solid var(--default-border, #e5e7eb);
  display: flex;
  flex-direction: column;
  z-index: 100;
  transition: width 0.25s ease;
}

.pc-sidebar.collapsed {
  width: 64px;
}

.sidebar-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px;
  cursor: pointer;
  border-bottom: 1px solid var(--default-border, #e5e7eb);
  min-height: 56px;
}

.logo-icon {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: linear-gradient(135deg, #5D87FF, #6366F1);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  flex-shrink: 0;
}

.logo-icon svg {
  width: 20px;
  height: 20px;
}

.logo-text {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  white-space: nowrap;
}

.sidebar-menu {
  flex: 1;
  padding: 12px 8px;
  overflow-y: auto;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  color: #6b7280;
  transition: all 0.15s;
  margin-bottom: 2px;
  white-space: nowrap;
}

.menu-item:hover {
  background: #f3f4f6;
  color: #374151;
}

.menu-item.active {
  background: #eff6ff;
  color: #3D7BEA;
}

.menu-icon {
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.menu-label {
  font-size: 14px;
  font-weight: 500;
}

.sidebar-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px;
  border-top: 1px solid var(--default-border, #e5e7eb);
  cursor: pointer;
  color: #9ca3af;
  transition: color 0.15s;
}

.sidebar-footer:hover {
  color: #6b7280;
}

.sidebar-footer svg {
  transition: transform 0.25s ease;
}

.sidebar-footer svg.rotated {
  transform: rotate(180deg);
}

.pc-main {
  flex: 1;
  min-width: 0;
  transition: margin-left 0.25s ease;
}

.pc-main:not(.no-sidebar) {
  margin-left: 220px;
}

.pc-sidebar.collapsed ~ .pc-main:not(.no-sidebar) {
  margin-left: 64px;
}

.pc-main.no-sidebar {
  margin-left: 0;
}
</style>
