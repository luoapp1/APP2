import { defineAsyncComponent } from 'vue'

export interface LayoutThemeDef {
  id: string
  name: string
  type: 'pc' | 'mobile'
  description: string
  loader: () => Promise<any>
}

export const LAYOUT_THEMES: LayoutThemeDef[] = [
  {
    id: 'pc',
    name: '默认PC主题',
    type: 'pc',
    description: '经典左侧侧边栏布局，支持折叠/展开，顶部导航',
    loader: () => import('./pc/default/index.vue')
  },
  {
    id: 'mobile',
    name: '默认手机主题',
    type: 'mobile',
    description: '底部固定导航栏布局，适配移动端触屏操作',
    loader: () => import('./mobile/default/index.vue')
  }
]

export function getThemeById(id: string): LayoutThemeDef | undefined {
  return LAYOUT_THEMES.find(t => t.id === id)
}

export function getThemesByType(type: 'pc' | 'mobile'): LayoutThemeDef[] {
  return LAYOUT_THEMES.filter(t => t.type === type)
}

export function createThemeComponent(id: string) {
  const theme = getThemeById(id)
  if (!theme) return null
  return defineAsyncComponent(theme.loader)
}
