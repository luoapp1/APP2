<template>
  <div class="sm-page">
    <!-- ===== NAVBAR ===== -->
    <div class="sm-navbar">
      <button class="sm-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="sm-nav-title">板块管理</span>
      <div style="width:22px" />
    </div>

    <!-- ===== TABS ===== -->
    <div class="sm-tabs">
      <button v-for="t in tabs" :key="t.key" class="sm-tab" :class="{ on: activeTab === t.key }" @click="activeTab = t.key">
        {{ t.label }}
        <span v-if="t.badge && t.badge > 0" class="sm-tab-badge">{{ t.badge }}</span>
      </button>
    </div>

    <!-- ===== TAB: 板块管理 ===== -->
    <div v-if="activeTab === 'sections'" class="sm-content">
      <div class="sm-toolbar">
        <button v-if="hasPermission('add', 'SectionManage')" class="sm-btn sm-btn-primary" @click="openAddSection">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
          添加板块
        </button>
        <button class="sm-btn sm-btn-ghost" @click="loadSections">刷新</button>
      </div>

      <div v-if="sectionsLoading" class="sm-loading"><div class="sm-spin" /></div>
      <div v-else-if="!sections.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 13h6M9 17h4"/></svg>
        </div>
        <p class="sm-empty-title">暂无板块</p>
        <p class="sm-empty-desc">点击上方"添加板块"创建第一个板块</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="s in sections" :key="s.id" class="sm-card" :class="{ off: s.status !== 'active' }">
          <div class="sm-card-body">
            <div class="sm-card-left">
              <img v-if="s.icon" :src="$fixImgUrl(s.icon)" class="sm-card-icon" />
              <span v-else class="sm-card-icon-letter" :style="{ background: s.iconBgColor || '#6366F1' }">{{ s.name?.charAt(0) || '?' }}</span>
              <div class="sm-card-info">
                <div class="sm-card-title">
                  {{ s.name }}
                  <span v-if="s.visibility === 'restricted'" class="sm-tag sm-tag-lock">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                    受限
                  </span>
                  <span v-if="s.status !== 'active'" class="sm-tag sm-tag-off">已关闭</span>
                </div>
                <div class="sm-card-meta">
                  <span class="sm-meta-item">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    {{ s.postCount }} 帖
                  </span>
                  <span class="sm-meta-item">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    {{ s.viewCount }} 浏览
                  </span>
                  <span class="sm-meta-item">{{ s.description || '暂无简介' }}</span>
                </div>
              </div>
            </div>
            <div class="sm-card-acts">
              <button v-if="hasPermission('edit', 'SectionManage')" class="sm-acts-btn" @click="openEditSection(s)">编辑</button>
              <button v-if="hasPermission('moderate', 'SectionManage')" class="sm-acts-btn sm-acts-mod" @click="manageModerators(s)">版主</button>
              <button v-if="hasPermission('toggle', 'SectionManage')" class="sm-acts-btn sm-acts-toggle" @click="toggleSectionStatus(s)">{{ s.status === 'active' ? '关闭' : '启用' }}</button>
              <button v-if="hasPermission('delete', 'SectionManage')" class="sm-acts-btn sm-acts-del" @click="deleteSection(s)">删除</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== TAB: 帖子审核 ===== -->
    <div v-if="activeTab === 'review'" class="sm-content">
      <div class="sm-toolbar">
        <span class="sm-toolbar-label">帖子审核</span>
        <button class="sm-btn sm-btn-ghost" @click="loadPendingPosts">刷新</button>
        <span class="sm-toolbar-hint" v-if="pendingTotal">共 {{ pendingTotal }} 条待审</span>
      </div>
      <div v-if="pendingLoading" class="sm-loading"><div class="sm-spin" /></div>
      <div v-else-if="!pendingPosts.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <p class="sm-empty-title">暂无待审核帖子</p>
        <p class="sm-empty-desc">所有帖子已处理完毕</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="p in pendingPosts" :key="p.id" class="sm-card">
          <div class="sm-card-body">
            <div class="sm-post-info">
              <div class="sm-post-author">
                <span class="sm-post-avatar" :style="{ background: avatarColor(p.userName) }">{{ p.userName?.charAt(0) || '?' }}</span>
                <span class="sm-post-username">{{ p.userName }}</span>
                <span class="sm-post-time">{{ fmtTime(p.createTime) }}</span>
              </div>
              <div class="sm-post-title">{{ p.title || '(无标题)' }}</div>
              <div v-if="p.images?.length" class="sm-thumbs">
                <img v-for="(img,i) in p.images.slice(0,4)" :key="i" :src="img" class="sm-thumb" />
              </div>
            </div>
            <div class="sm-card-acts">
              <button v-if="hasPermission('approve', 'CommunityPostManage')" class="sm-acts-btn sm-acts-ok" @click="handleApprove(p)">通过</button>
              <button v-if="hasPermission('approve', 'CommunityPostManage')" class="sm-acts-btn sm-acts-warn" @click="handleReject(p)">驳回</button>
              <button class="sm-acts-btn" @click="$router.push(`/community/post/${p.id}`)">详情</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== TAB: 举报管理 ===== -->
    <div v-if="activeTab === 'reports'" class="sm-content">
      <div class="sm-toolbar">
        <span class="sm-toolbar-label">举报管理</span>
        <button class="sm-btn sm-btn-ghost" @click="loadReports">刷新</button>
        <span class="sm-toolbar-hint" v-if="reports.length">{{ reports.length }} 条举报</span>
      </div>
      <div v-if="reportsLoading" class="sm-loading"><div class="sm-spin" /></div>
      <div v-else-if="!reports.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>
        </div>
        <p class="sm-empty-title">暂无举报</p>
        <p class="sm-empty-desc">社区环境良好</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="r in reports" :key="'r'+r.id" class="sm-card sm-report-card">
          <div class="sm-card-body">
            <div class="sm-card-left">
              <span class="sm-report-icon" :class="r.targetType">
                <svg v-if="r.targetType === 'post'" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
              </span>
              <div class="sm-card-info">
                <div class="sm-card-title">
                  <span v-if="r.targetType === 'post' && r.targetId" class="sm-link" @click="$router.push(`/community/post/${r.targetId}`)">{{ r.targetTitle?.slice(0, 50) || '(无标题)' }}</span>
                  <span v-else-if="r.targetType === 'comment' && r.postId" class="sm-link" @click="$router.push(`/community/post/${r.postId}`)">{{ r.targetTitle?.slice(0, 50) || '(无内容)' }}</span>
                  <span v-else>{{ r.targetTitle?.slice(0, 50) || '(无内容)' }}</span>
                  <span class="sm-report-type-badge">{{ r.reportReason }}</span>
                </div>
                <div class="sm-card-meta">
                  <span>{{ r.reporterName }}</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ r.targetType === 'comment' ? '评论' : '帖子' }}</span>
                  <template v-if="r.targetUserName">
                    <span class="sm-meta-dot"></span>
                    <span>被举报人: {{ r.targetUserName }}</span>
                  </template>
                  <span class="sm-meta-dot"></span>
                  <span>{{ fmtTime(r.createTime) }}</span>
                </div>
                <div v-if="r.reportDetail" class="sm-report-detail">"{{ r.reportDetail.slice(0, 80) }}"</div>
              </div>
            </div>
            <div class="sm-card-acts">
              <button class="sm-acts-btn" v-if="r.targetType === 'post' && r.targetId" @click="$router.push(`/community/post/${r.targetId}`)">查看</button>
              <button class="sm-acts-btn" v-else-if="r.targetType === 'comment' && r.postId" @click="$router.push(`/community/post/${r.postId}`)">查看</button>
              <button v-if="hasPermission('ignore', 'CommunityReportManage')" class="sm-acts-btn" @click="handleIgnoreReport(r)">忽略</button>
              <button v-if="hasPermission('handle', 'CommunityReportManage')" class="sm-acts-btn sm-acts-del" @click="handleDeleteReport(r)">{{ r.targetType === 'post' ? '下架' : '删除' }}</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== TAB: 解锁申请 ===== -->
    <div v-if="activeTab === 'unlock'" class="sm-content">
      <div class="sm-toolbar">
        <span class="sm-toolbar-label">解锁申请</span>
        <button class="sm-btn sm-btn-ghost" @click="loadUnlockRequests">刷新</button>
        <span class="sm-toolbar-hint" v-if="unlockRequests.length">{{ unlockRequests.length }} 条申请</span>
      </div>
      <div v-if="unlockLoading" class="sm-loading"><div class="sm-spin" /></div>
      <div v-else-if="!unlockRequests.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
        </div>
        <p class="sm-empty-title">暂无解锁申请</p>
        <p class="sm-empty-desc">还没有用户申请解锁帖子</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="ur in unlockRequests" :key="'ur'+ur.id" class="sm-card sm-report-card">
          <div class="sm-card-body">
            <div class="sm-card-left">
              <span class="sm-report-icon unlock">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              </span>
              <div class="sm-card-info">
                <div class="sm-card-title">
                  <span v-if="ur.postId" class="sm-link" @click="$router.push(`/community/post/${ur.postId}`)">{{ ur.postTitle || '(无标题)' }}</span>
                  <span v-else>{{ ur.postTitle || '(无标题)' }}</span>
                  <span :class="ur.status === 'pending' ? 'sm-status-pending' : ur.status === 'approved' ? 'sm-status-ok' : 'sm-status-reject'">
                    {{ ur.status === 'pending' ? '待处理' : ur.status === 'approved' ? '已通过' : '已拒绝' }}
                  </span>
                </div>
                <div class="sm-card-meta">
                  <span>{{ ur.userName }}</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ fmtTime(ur.createTime) }}</span>
                </div>
                <div v-if="ur.reason" class="sm-report-detail">申请原因: {{ ur.reason.slice(0, 80) }}</div>
                <div v-if="ur.adminReply" class="sm-report-detail sm-admin-reply">回复: {{ ur.adminReply.slice(0, 80) }}</div>
              </div>
            </div>
            <div v-if="ur.status === 'pending'" class="sm-card-acts">
              <button v-if="hasPermission('unlock', 'SectionManage')" class="sm-acts-btn sm-acts-ok" @click="openUnlockApprove(ur)">通过</button>
              <button v-if="hasPermission('unlock', 'SectionManage')" class="sm-acts-btn sm-acts-warn" @click="openUnlockReject(ur)">拒绝</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== TAB: 帖子管理 ===== -->
    <div v-if="activeTab === 'posts'" class="sm-content">
      <div class="sm-toolbar">
        <span class="sm-toolbar-label">帖子管理</span>
        <button class="sm-btn sm-btn-ghost" @click="loadAllPosts">刷新</button>
        <span class="sm-toolbar-hint" v-if="allPostsTotal">共 {{ allPostsTotal }} 条</span>
      </div>
      <div v-if="allPostsLoading" class="sm-loading"><div class="sm-spin" /></div>
      <div v-else-if="!allPosts.length" class="sm-empty">
        <div class="sm-empty-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 13h6M9 17h4"/></svg>
        </div>
        <p class="sm-empty-title">暂无帖子</p>
        <p class="sm-empty-desc">还没有任何帖子</p>
      </div>
      <div v-else class="sm-list">
        <div v-for="p in allPosts" :key="p.id" class="sm-card" :class="{ off: p.status === 'locked' }">
          <div class="sm-card-body">
            <div class="sm-card-left">
              <span class="sm-post-avatar" :style="{ background: avatarColor(p.userName) }">{{ p.userName?.charAt(0) || '?' }}</span>
              <div class="sm-card-info">
                <div class="sm-card-title">
                  <span class="sm-link" @click="$router.push(`/community/post/${p.id}`)">{{ p.title || '(无标题)' }}</span>
                  <span v-if="p.isPinned" class="sm-tag sm-tag-pin">置顶</span>
                  <span v-if="p.isGlobalPinned" class="sm-tag sm-tag-gpin">全站</span>
                  <span v-if="p.isEssence" class="sm-tag sm-tag-essence">精华</span>
                  <span v-if="p.isHot" class="sm-tag sm-tag-hot">热帖</span>
                  <span v-if="p.customBadge" class="sm-tag sm-tag-badge">{{ p.customBadge }}</span>
                  <span v-if="p.status === 'locked'" class="sm-tag sm-tag-off">已锁定</span>
                </div>
                <div class="sm-card-meta">
                  <span>{{ p.userName }}</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ fmtTime(p.createTime) }}</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ p.likeCount || 0 }} 赞</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ p.commentCount || 0 }} 评</span>
                  <span class="sm-meta-dot"></span>
                  <span>{{ p.viewCount || 0 }} 浏览</span>
                </div>
              </div>
            </div>
            <div class="sm-card-acts">
              <button v-if="hasPermission('pin', 'SectionManage') && !p.isGlobalPinned && !p.isPinned" class="sm-acts-btn sm-acts-pin" @click="doPinPost(p)">置顶</button>
              <button v-if="hasPermission('pin', 'SectionManage') && p.isPinned" class="sm-acts-btn sm-acts-off" @click="doUnpinPost(p)">取消</button>
              <button v-if="hasPermission('pin', 'SectionManage') && !p.isGlobalPinned" class="sm-acts-btn sm-acts-gpin" @click="doGlobalPinPost(p)">全站</button>
              <button v-if="hasPermission('pin', 'SectionManage') && p.isGlobalPinned" class="sm-acts-btn sm-acts-off" @click="doUnGlobalPinPost(p)">取消全站</button>
              <button v-if="hasPermission('badge', 'SectionManage') && !p.customBadge" class="sm-acts-btn sm-acts-badge" @click="openBadgeDialog(p)">徽章</button>
              <button v-if="hasPermission('badge', 'SectionManage') && p.customBadge" class="sm-acts-btn sm-acts-off" @click="doRemoveBadge(p)">去徽章</button>
              <button v-if="hasPermission('essence', 'SectionManage') && !p.isEssence" class="sm-acts-btn sm-acts-essence" @click="doEssencePost(p)">精华</button>
              <button v-if="hasPermission('essence', 'SectionManage') && p.isEssence" class="sm-acts-btn sm-acts-norm" @click="doUnEssencePost(p)">取消精华</button>
              <button v-if="hasPermission('hot', 'SectionManage') && !p.isHot" class="sm-acts-btn sm-acts-hot" @click="doHotPost(p)">热帖</button>
              <button v-if="hasPermission('hot', 'SectionManage') && p.isHot" class="sm-acts-btn sm-acts-norm" @click="doUnHotPost(p)">取消热帖</button>
              <button v-if="hasPermission('lock', 'SectionManage') && p.status !== 'locked'" class="sm-acts-btn sm-acts-warn" @click="doLockPost(p)">锁定</button>
              <button v-if="hasPermission('lock', 'SectionManage') && p.status === 'locked'" class="sm-acts-btn sm-acts-ok" @click="doUnlockPost(p)">解锁</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===== BADGE DIALOG ===== -->
    <Teleport to="body">
      <div v-if="showBadgeDialog" class="sm-overlay" @click.self="showBadgeDialog = false">
        <div class="sm-dialog" @click.stop>
          <div class="sm-dialog-head">
            <h3>设置自定义徽章</h3>
            <button class="sm-dialog-close" @click="showBadgeDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>徽章文字 *</label>
              <input v-model="badgeText" placeholder="如: 公告、推荐、精选" maxlength="10" />
            </div>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showBadgeDialog = false">取消</button>
            <button class="sm-btn sm-btn-primary" @click="doSetBadge" :disabled="!badgeText">确认</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ===== UNLOCK HANDLE DIALOG ===== -->
    <Teleport to="body">
      <div v-if="showUnlockHandleDialog" class="sm-overlay" @click.self="showUnlockHandleDialog = false">
        <div class="sm-dialog sm-dialog-section" @click.stop>
          <div class="sm-dialog-head">
            <h3>{{ handleUnlockAction === 'approve' ? '通过解锁申请' : '拒绝解锁申请' }}</h3>
            <button class="sm-dialog-close" @click="showUnlockHandleDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>回复（选填）</label>
              <input v-model="handleUnlockReply" placeholder="给申请人的回复说明" />
            </div>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showUnlockHandleDialog = false">取消</button>
            <button class="sm-btn sm-btn-primary" @click="doHandleUnlock" v-if="handleUnlockAction === 'approve'">确认通过</button>
            <button class="sm-btn sm-btn-warn" @click="doHandleUnlock" v-else>确认拒绝</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ===== SECTION ADD/EDIT DIALOG ===== -->
    <Teleport to="body">
      <div v-if="showSectionDialog" class="sm-overlay" @click.self="showSectionDialog = false">
        <div class="sm-dialog sm-dialog-section" @click.stop>
          <div class="sm-dialog-head">
            <h3>{{ editingSection ? '编辑板块' : '添加板块' }}</h3>
            <button class="sm-dialog-close" @click="showSectionDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>板块名称 *</label>
              <input v-model="sectionForm.name" placeholder="请输入板块名称" />
            </div>
            <div class="sm-field">
              <label>图标</label>
              <div class="sm-upload-row">
                <img v-if="sectionForm.icon" :src="$fixImgUrl(sectionForm.icon)" class="sm-upload-preview" />
                <span v-else class="sm-upload-placeholder" :style="{ background: sectionForm.iconBgColor || '#6366F1' }">{{ sectionForm.name?.charAt(0) || '?' }}</span>
                <input ref="iconInput" type="file" accept="image/*" style="display:none" @change="onIconUpload" />
                <button class="sm-btn sm-btn-sm" @click="iconInput?.click()">上传图片</button>
              </div>
            </div>
            <div class="sm-field">
              <label>背景色</label>
              <input v-model="sectionForm.iconBgColor" placeholder="#6366F1" />
            </div>
            <div class="sm-field">
              <label>描述</label>
              <input v-model="sectionForm.description" placeholder="板块简介" />
            </div>
            <div class="sm-field">
              <label>排序</label>
              <input v-model.number="sectionForm.sortOrder" type="number" placeholder="0" />
            </div>
            <div class="sm-field">
              <label>可见性</label>
              <div class="sm-visibility-toggle">
                <button class="sm-vis-opt" :class="{ on: sectionForm.visibility === 'public' }" @click="sectionForm.visibility = 'public'">公开</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.visibility === 'restricted' }" @click="sectionForm.visibility = 'restricted'">受限</button>
              </div>
            </div>
            <div class="sm-field">
              <label>发帖权限</label>
              <div class="sm-visibility-toggle">
                <button class="sm-vis-opt" :class="{ on: !sectionForm.postPermission || sectionForm.postPermission === 'all' }" @click="sectionForm.postPermission = 'all'">所有人</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.postPermission === 'verified_only' }" @click="sectionForm.postPermission = 'verified_only'">已认证</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.postPermission === 'vip_only' }" @click="sectionForm.postPermission = 'vip_only'">VIP</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.postPermission === 'moderator_only' }" @click="sectionForm.postPermission = 'moderator_only'">版主</button>
              </div>
            </div>
            <div class="sm-field">
              <label>浏览权限</label>
              <div class="sm-visibility-toggle">
                <button class="sm-vis-opt" :class="{ on: !sectionForm.viewPermission || sectionForm.viewPermission === 'all' }" @click="sectionForm.viewPermission = 'all'">所有人</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.viewPermission === 'verified_only' }" @click="sectionForm.viewPermission = 'verified_only'">已认证</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.viewPermission === 'vip_only' }" @click="sectionForm.viewPermission = 'vip_only'">VIP</button>
                <button class="sm-vis-opt" :class="{ on: sectionForm.viewPermission === 'moderator_only' }" @click="sectionForm.viewPermission = 'moderator_only'">版主</button>
              </div>
            </div>
            <div class="sm-field" v-if="sectionForm.viewPermission || sectionForm.postPermission">
              <label>等级要求</label>
              <input v-model.number="sectionForm.viewLevelRequired" type="number" placeholder="0 (不限)" min="0" />
            </div>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showSectionDialog = false">取消</button>
            <button class="sm-btn sm-btn-primary" @click="saveSection" :disabled="!sectionForm.name">保存</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ===== MODERATOR DIALOG ===== -->
    <Teleport to="body">
      <div v-if="showModDialog" class="sm-overlay" @click.self="showModDialog = false">
        <div class="sm-dialog sm-dialog-mod" @click.stop>
          <div class="sm-dialog-head">
            <h3>版主管理 · {{ modSection?.name }}</h3>
            <button class="sm-dialog-close" @click="showModDialog = false">&times;</button>
          </div>

          <!-- 添加版主区域 -->
          <div class="sm-mod-add-area">
            <div class="sm-mod-add-title">添加版主</div>
            <div class="sm-mod-role-pick">
              <span class="sm-mod-role-pick-label">角色</span>
              <div class="sm-role-select" @click="showRoleDropdown = !showRoleDropdown">
                <span class="sm-role-select-text">{{ modRole }}</span>
                <svg class="sm-role-select-arrow" :class="{ open: showRoleDropdown }" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                <div v-if="showRoleDropdown" class="sm-role-dropdown" @click.stop>
                  <div v-for="r in modRoles" :key="r" class="sm-role-dropdown-item" :class="{ on: modRole === r }" @click="modRole = r; showRoleDropdown = false">{{ r }}</div>
                </div>
              </div>
            </div>
            <div class="sm-search-row">
              <div class="sm-search-input-wrap">
                <svg class="sm-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
                <input v-model="modSearch" placeholder="输入用户名搜索用户..." @input="searchModUser" class="sm-search-input" />
                <button v-if="modSearch" class="sm-search-clear" @click="modSearch='';modSearchResults=[]">&times;</button>
              </div>
            </div>
            <!-- 搜索结果下拉 - float over everything using position relative to viewport -->
            <div class="sm-search-results-wrap" v-if="modSearchResults.length">
              <div v-for="u in modSearchResults" :key="u.id" class="sm-search-item" @click="selectModUser(u)">
                <span class="sm-search-av" :style="{ background: avatarColor(u.nickname) }">{{ u.nickname?.charAt(0) || '?' }}</span>
                <div class="sm-search-info">
                  <span class="sm-search-name">{{ u.nickname }}</span>
                  <span class="sm-search-id">ID: {{ u.id }}</span>
                </div>
                <span class="sm-search-add">+ 添加</span>
              </div>
            </div>
          </div>

          <!-- 现有版主列表 -->
          <div class="sm-mod-current">
            <div class="sm-mod-current-title">当前版主 ({{ mods.length }})</div>
            <div v-if="modsLoading" class="sm-loading"><div class="sm-spin" /></div>
            <div v-else-if="!mods.length" class="sm-empty-sm">暂无版主，在上方搜索用户添加</div>
            <div v-else class="sm-mod-list">
              <div v-for="m in mods" :key="m.userId" class="sm-mod-item">
                <span class="sm-mod-avatar" :style="{ background: avatarColor(m.userName) }">{{ m.userName?.charAt(0) || '?' }}</span>
                <div class="sm-mod-info">
                  <span class="sm-mod-name">{{ m.userName }}</span>
                  <button class="sm-mod-role-tag" :style="{ background: getRoleColor(m.role) + '18', color: getRoleColor(m.role) }" @click="toggleModRole(m)">{{ m.role || '版主' }}</button>
                </div>
                <button class="sm-acts-btn sm-acts-del sm-acts-xs" @click="removeMod(m)">移除</button>
              </div>
            </div>
          </div>

          <div class="sm-dialog-btns">
            <button class="sm-btn sm-btn-primary" @click="showModDialog = false">完成</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ===== REJECT DIALOG ===== -->
    <Teleport to="body">
      <div v-if="showRejectDialog" class="sm-overlay" @click.self="showRejectDialog = false">
        <div class="sm-dialog" @click.stop>
          <div class="sm-dialog-head">
            <h3>驳回原因</h3>
            <button class="sm-dialog-close" @click="showRejectDialog = false">&times;</button>
          </div>
          <div class="sm-dialog-body">
            <div class="sm-field">
              <label>驳回原因 *</label>
              <textarea v-model="rejectReason" placeholder="请输入驳回原因" class="sm-textarea" rows="3" />
            </div>
          </div>
          <div class="sm-dialog-btns">
            <button class="sm-btn" @click="showRejectDialog = false">取消</button>
            <button class="sm-btn sm-btn-warn" @click="doReject" :disabled="!rejectReason">确认驳回</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/store/modules/user'
import { useMenuStore } from '@/store/modules/menu'
import request from '@/utils/http'
import {
  fetchCommunitySections, createCommunitySection, updateCommunitySection, deleteCommunitySection,
  fetchModerators, addModerator, removeModerator,
  fetchPendingPosts, approvePost, rejectPost,
  searchUsers, fetchReports, ignoreReport, deleteReportPost, deleteReportComment,
  fetchUnlockRequests, handleUnlockRequest,
  fetchAdminPosts, pinPost, globalPinPost, setCustomBadge, essencePost, hotPost, lockPost
} from '@/api/community'
import { fetchGetRoleList } from '@/api/system-manage'

interface Section { id: number; name: string; icon?: string; iconBgColor?: string; description?: string; postCount: number; viewCount: number; sortOrder: number; status: string; visibility?: string; postPermission?: string; viewPermission?: string; viewLevelRequired?: number; createTime: string }
interface Moderator { id: number; sectionId: number; userId: number; userName: string; userAvatar: string; role: string; sortOrder: number; createTime: string }
interface PendingPost { id: number; sectionId: number; userId: number; userName: string; userAvatar: string; title: string; content: string; images: string[]; createTime: string }
interface ReportItem { id: number; reporterId: number; reporterName: string; targetType: string; targetId: number; reportReason: string; reportDetail: string; status: string; createTime: string; targetTitle?: string; targetUserId?: number; targetUserName?: string; targetStatus?: string; postId?: number }
interface UnlockRequest { id: number; postId: number; userId: number; userName: string; reason: string; status: string; adminReply: string; createTime: string; postTitle?: string }
interface UserSearch { id: number; nickname: string; avatar: string }

const avatarColors = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#E11D48','#7C3AED']
const ROLE_TAG_COLORS = ['#6366F1','#EF4444','#F97316','#16A34A','#8B5CF6','#E11D48','#06B6D4','#EC4899','#F59E0B','#14B8A6']
function getRoleColor(role: string): string {
  let h = 0; for (let i = 0; i < (role||'').length; i++) h = role.charCodeAt(i) + ((h<<5)-h)
  return ROLE_TAG_COLORS[Math.abs(h) % ROLE_TAG_COLORS.length]
}

function avatarColor(name: string): string {
  let h = 0; for (let i = 0; i < (name||'').length; i++) h = name.charCodeAt(i) + ((h<<5)-h)
  return avatarColors[Math.abs(h) % avatarColors.length]
}

const tabs = computed(() => [
  { key: 'sections', label: '板块管理', badge: 0 },
  { key: 'review', label: '帖子审核', badge: pendingTotal.value || 0 },
  { key: 'reports', label: '举报管理', badge: reports.value.length || 0 },
  { key: 'unlock', label: '解锁申请', badge: unlockRequests.value.filter(u => u.status === 'pending').length || 0 },
  { key: 'posts', label: '帖子管理', badge: 0 }
])

const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()
const { menuList } = storeToRefs(menuStore)

function userIsAdmin() {
  const u: any = userStore.getUserInfo || {}
  return u.roles?.includes('R_SUPER') || u.roles?.includes('R_ADMIN')
}

function hasPermission(authMark: string, menuName: string): boolean {
  const u: any = userStore.getUserInfo || {}
  if (u.roles?.includes('R_SUPER')) return true
  if (!u.roles?.includes('R_ADMIN')) return false
  for (const m of menuList.value) {
    if (m.name === menuName) {
      const auths = (m as any).authList || []
      if (auths.some((a: any) => a.authMark === authMark)) return true
    }
  }
  return false
}

const activeTab = ref('sections')

const sections = ref<Section[]>([])
const sectionsLoading = ref(false)
const showSectionDialog = ref(false)
const editingSection = ref<Section | null>(null)
const sectionForm = ref({ name: '', icon: '', iconBgColor: '#6366F1', description: '', sortOrder: 0, visibility: 'public', postPermission: 'all', viewPermission: 'all', viewLevelRequired: 0 })
const iconInput = ref<HTMLInputElement | null>(null)

const showModDialog = ref(false)
const modSection = ref<Section | null>(null)
const mods = ref<Moderator[]>([])
const modsLoading = ref(false)
const modSearch = ref('')
const modSearchResults = ref<UserSearch[]>([])
const modRole = ref('版主')
const modRoles = ref<string[]>(['版主'])
const showRoleDropdown = ref(false)

async function loadRoles() {
  try {
    const data: any = await fetchGetRoleList({ current: 1, size: 200 })
    const records = data?.records || []
    modRoles.value = records.filter((r: any) => r.enabled !== 0).map((r: any) => r.roleName)
    if (modRoles.value.length === 0) modRoles.value = ['版主']
  } catch { modRoles.value = ['版主'] }
}

const pendingPosts = ref<PendingPost[]>([])
const pendingTotal = ref(0)
const pendingLoading = ref(false)
const showRejectDialog = ref(false)
const rejectPostId = ref(0)
const rejectReason = ref('')

const reports = ref<ReportItem[]>([])
const reportsLoading = ref(false)

const unlockRequests = ref<UnlockRequest[]>([])
const unlockLoading = ref(false)
const showUnlockHandleDialog = ref(false)
const handleUnlockId = ref(0)
const handleUnlockAction = ref<'approve' | 'reject'>('approve')
const handleUnlockReply = ref('')

const allPosts = ref<any[]>([])
const allPostsLoading = ref(false)
const allPostsTotal = ref(0)
const showBadgeDialog = ref(false)
const badgePostId = ref(0)
const badgeText = ref('')

const adminUserId = computed(() => (userStore.getUserInfo as any)?.userId || 1)

async function loadAllPosts() {
  allPostsLoading.value = true
  try {
    const r: any = await fetchAdminPosts({ limit: 50, offset: 0 })
    const data = r.data || r || {}
    allPosts.value = data.records || data.list || []
    allPostsTotal.value = data.total || allPosts.value.length
  } catch { ElMessage.error('加载帖子列表失败') }
  finally { allPostsLoading.value = false }
}

async function doPinPost(p: any) {
  try { await pinPost(p.id, adminUserId.value); ElMessage.success('已置顶'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doUnpinPost(p: any) {
  try { await pinPost(p.id, adminUserId.value); ElMessage.success('已取消置顶'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doGlobalPinPost(p: any) {
  try { await globalPinPost(p.id, adminUserId.value); ElMessage.success('已全站置顶'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doUnGlobalPinPost(p: any) {
  try { await globalPinPost(p.id, adminUserId.value); ElMessage.success('已取消全站置顶'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
function openBadgeDialog(p: any) { badgePostId.value = p.id; badgeText.value = ''; showBadgeDialog.value = true }
async function doSetBadge() {
  try { await setCustomBadge(badgePostId.value, badgeText.value); ElMessage.success('徽章已设置'); showBadgeDialog.value = false; await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doRemoveBadge(p: any) {
  try { await setCustomBadge(p.id, ''); ElMessage.success('徽章已移除'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doEssencePost(p: any) {
  try { await essencePost(p.id, adminUserId.value); ElMessage.success('已设为精华'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doUnEssencePost(p: any) {
  try { await essencePost(p.id, adminUserId.value); ElMessage.success('已取消精华'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doHotPost(p: any) {
  try { await hotPost(p.id, adminUserId.value); ElMessage.success('已设为热帖'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doUnHotPost(p: any) {
  try { await hotPost(p.id, adminUserId.value); ElMessage.success('已取消热帖'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doLockPost(p: any) {
  try { await lockPost(p.id, adminUserId.value); ElMessage.success('已锁定'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}
async function doUnlockPost(p: any) {
  try { await lockPost(p.id, adminUserId.value); ElMessage.success('已解锁'); await loadAllPosts() } catch { ElMessage.error('操作失败') }
}

let modSearchTimer: ReturnType<typeof setTimeout> | null = null

function fmtTime(t: string) {
  if (!t) return ''
  const dt = new Date(t)
  if (isNaN(dt.getTime())) return t.slice(0, 10)
  const d = Date.now() - dt.getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}

async function loadSections() {
  sectionsLoading.value = true
  try { const r: any = await fetchCommunitySections(true); sections.value = r.data || r || [] } catch {} finally { sectionsLoading.value = false }
}
function openAddSection() {
  editingSection.value = null
  sectionForm.value = { name: '', icon: '', iconBgColor: '#6366F1', description: '', sortOrder: 0, visibility: 'public', postPermission: 'all', viewPermission: 'all', viewLevelRequired: 0 }
  showSectionDialog.value = true
}
function openEditSection(s: Section) {
  editingSection.value = s
  sectionForm.value = { name: s.name, icon: s.icon || '', iconBgColor: s.iconBgColor || '#6366F1', description: s.description || '', sortOrder: s.sortOrder || 0, visibility: s.visibility || 'public', postPermission: s.postPermission || 'all', viewPermission: s.viewPermission || 'all', viewLevelRequired: s.viewLevelRequired || 0 }
  showSectionDialog.value = true
}
async function onIconUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  const fd = new FormData()
  fd.append('file', file)
  try {
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
    const url = res?.url || res?.data?.url
    if (url) sectionForm.value.icon = url
    ElMessage.success('上传成功')
  } catch { ElMessage.error('上传失败') }
}
async function saveSection() {
  try {
    if (editingSection.value) { await updateCommunitySection(editingSection.value.id, sectionForm.value); ElMessage.success('更新成功') }
    else { await createCommunitySection(sectionForm.value); ElMessage.success('创建成功') }
    showSectionDialog.value = false; await loadSections()
  } catch { ElMessage.error('操作失败') }
}
async function deleteSection(s: Section) {
  try {
    await ElMessageBox.confirm(`确定删除「${s.name}」？`, '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    await deleteCommunitySection(s.id); ElMessage.success('删除成功'); await loadSections()
  } catch {}
}
async function toggleSectionStatus(s: Section) {
  try {
    const ns = s.status === 'active' ? 'inactive' : 'active'
    await updateCommunitySection(s.id, { name: s.name, icon: s.icon, iconBgColor: s.iconBgColor, description: s.description, sortOrder: s.sortOrder, visibility: s.visibility || 'public', status: ns }); s.status = ns
    ElMessage.success(ns === 'active' ? '已启用' : '已关闭')
  } catch { ElMessage.error('操作失败') }
}

async function manageModerators(s: Section) {
  modSection.value = s; showModDialog.value = true; modSearch.value = ''; modSearchResults.value = []; modRole.value = modRoles.value[0] || '版主'; showRoleDropdown.value = false
  modsLoading.value = true
  try { const r: any = await fetchModerators(s.id); mods.value = r.data || r || [] } catch {} finally { modsLoading.value = false }
}
async function searchModUser() {
  if (modSearchTimer) clearTimeout(modSearchTimer)
  if (!modSearch.value || modSearch.value.trim().length < 1) { modSearchResults.value = []; return }
  modSearchTimer = setTimeout(async () => {
    try { const r: any = await searchUsers(modSearch.value); modSearchResults.value = r.data || r || [] } catch { modSearchResults.value = [] }
  }, 300)
}
async function selectModUser(u: UserSearch) {
  if (!modSection.value) return
  if (mods.value.some(m => m.userId === u.id)) { ElMessage.warning('该用户已是版主'); modSearchResults.value = []; modSearch.value = ''; return }
  try {
    await addModerator(modSection.value.id, { userId: u.id, userName: u.nickname, role: modRole.value })
    ElMessage.success('添加成功')
    modSearch.value = ''; modSearchResults.value = []
    modsLoading.value = true
    try { const r: any = await fetchModerators(modSection.value.id); mods.value = r.data || r || [] } catch {} finally { modsLoading.value = false }
  } catch { ElMessage.error('添加失败') }
}
async function toggleModRole(m: Moderator) {
  if (!modSection.value) return
  const idx = modRoles.value.indexOf(m.role)
  const newRole = modRoles.value[(idx + 1) % modRoles.value.length]
  try {
    await addModerator(modSection.value.id, { userId: m.userId, userName: m.userName, role: newRole })
    m.role = newRole
    ElMessage.success('角色已更新为 ' + newRole)
  } catch { ElMessage.error('更新失败') }
}
async function removeMod(m: Moderator) {
  if (!modSection.value) return
  try { await removeModerator(modSection.value.id, m.userId); mods.value = mods.value.filter(x => x.userId !== m.userId); ElMessage.success('移除成功') } catch { ElMessage.error('移除失败') }
}

async function loadPendingPosts() {
  pendingLoading.value = true
  try { const r: any = await fetchPendingPosts(); const d = r.data || r; pendingPosts.value = d.list || []; pendingTotal.value = d.total || 0 } catch {} finally { pendingLoading.value = false }
}
async function handleApprove(p: PendingPost) {
  try { await approvePost(p.id); ElMessage.success('已通过'); await loadPendingPosts() } catch { ElMessage.error('操作失败') }
}
function handleReject(p: PendingPost) { rejectPostId.value = p.id; rejectReason.value = ''; showRejectDialog.value = true }
async function doReject() {
  if (!rejectPostId.value || !rejectReason.value) return
  try { await rejectPost(rejectPostId.value, rejectReason.value); ElMessage.success('已驳回'); showRejectDialog.value = false; await loadPendingPosts() } catch { ElMessage.error('操作失败') }
}

async function loadReports() {
  reportsLoading.value = true
  try { const r: any = await fetchReports(); reports.value = r.data || r || [] } catch {} finally { reportsLoading.value = false }
}
async function handleIgnoreReport(r: ReportItem) {
  try { await ignoreReport(r.id); ElMessage.success('已忽略'); await loadReports() } catch { ElMessage.error('操作失败') }
}
async function handleDeleteReport(r: ReportItem) {
  const label = r.targetType === 'post' ? '下架' : '删除'
  try {
    await ElMessageBox.confirm(`确定${label}该${r.targetType === 'post' ? '帖子' : '评论'}？`, '确认', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    if (r.targetType === 'post') await deleteReportPost(r.targetId)
    else await deleteReportComment(r.targetId)
    ElMessage.success('操作成功'); await loadReports()
  } catch {}
}

async function loadUnlockRequests() {
  unlockLoading.value = true
  try { const r: any = await fetchUnlockRequests(); unlockRequests.value = r.data || r || [] } catch {} finally { unlockLoading.value = false }
}
function openUnlockApprove(ur: UnlockRequest) {
  handleUnlockId.value = ur.id
  handleUnlockAction.value = 'approve'
  handleUnlockReply.value = ''
  showUnlockHandleDialog.value = true
}
function openUnlockReject(ur: UnlockRequest) {
  handleUnlockId.value = ur.id
  handleUnlockAction.value = 'reject'
  handleUnlockReply.value = ''
  showUnlockHandleDialog.value = true
}
async function doHandleUnlock() {
  try {
    await handleUnlockRequest(handleUnlockId.value, handleUnlockAction.value, handleUnlockReply.value)
    ElMessage.success(handleUnlockAction.value === 'approve' ? '已通过解锁' : '已拒绝解锁')
    showUnlockHandleDialog.value = false
    await loadUnlockRequests()
  } catch { ElMessage.error('操作失败') }
}

onMounted(() => { loadRoles(); loadSections(); loadPendingPosts(); loadReports(); loadUnlockRequests(); loadAllPosts()
  document.addEventListener('mousedown', onDocMouseDown)
})
onUnmounted(() => { document.removeEventListener('mousedown', onDocMouseDown) })

function onDocMouseDown(e: MouseEvent) {
  if (showRoleDropdown.value) {
    const t = e.target as HTMLElement
    if (!t.closest('.sm-role-select')) showRoleDropdown.value = false
  }
}
</script>

<style scoped>
/* ===== PAGE ===== */
.sm-page { min-height: 100vh; background: #f0f2f5; padding-bottom: 40px; }

/* ===== NAVBAR ===== */
.sm-navbar { display: flex; align-items: center; padding: 10px 12px; background: #fff; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.sm-nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; color: #333; border-radius: 8px; transition: background .15s; }
.sm-nav-back:active { background: #f0f0f0; }
.sm-nav-title { flex: 1; text-align: center; font-size: 17px; font-weight: 700; color: #1a1a1a; }

/* ===== TABS ===== */
.sm-tabs { display: flex; background: #fff; border-bottom: 1px solid #eee; position: sticky; top: 44px; z-index: 9; padding: 0 16px; gap: 4px; }
.sm-tab { flex: 1; padding: 13px 0; font-size: 14px; color: #888; background: none; border: none; border-bottom: 2px solid transparent; cursor: pointer; transition: all .15s; display: flex; align-items: center; justify-content: center; gap: 6px; font-weight: 500; }
.sm-tab.on { color: #6366F1; border-bottom-color: #6366F1; font-weight: 700; }
.sm-tab-badge { display: inline-flex; align-items: center; justify-content: center; min-width: 18px; height: 18px; border-radius: 9px; background: #EF4444; color: #fff; font-size: 11px; font-weight: 600; padding: 0 5px; }

/* ===== CONTENT ===== */
.sm-content { padding: 16px; }

/* ===== TOOLBAR ===== */
.sm-toolbar { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
.sm-toolbar-label { font-size: 15px; font-weight: 700; color: #1a1a1a; }
.sm-toolbar-hint { font-size: 12px; color: #aaa; margin-left: auto; background: #f0f0f0; padding: 3px 10px; border-radius: 10px; }

/* ===== LOADING ===== */
.sm-loading { display: flex; justify-content: center; padding: 48px 0; }
.sm-spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #6366F1; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ===== EMPTY ===== */
.sm-empty { text-align: center; padding: 72px 16px 64px; }
.sm-empty-icon { width: 72px; height: 72px; border-radius: 50%; background: #f2f3f5; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: #c0c4cc; }
.sm-empty-title { margin: 0; font-size: 15px; color: #a0a4ac; font-weight: 600; }
.sm-empty-desc { margin: 6px 0 0; font-size: 12px; color: #c8ccd4; }
.sm-empty-sm { text-align: center; padding: 32px 16px; color: #bbb; font-size: 13px; }

/* ===== BUTTONS ===== */
.sm-btn { display: inline-flex; align-items: center; gap: 5px; padding: 8px 16px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #555; cursor: pointer; transition: all .12s; white-space: nowrap; font-weight: 500; }
.sm-btn:active { background: #f5f5f5; }
.sm-btn-primary { background: #6366F1; color: #fff; border-color: #6366F1; }
.sm-btn-primary:active { background: #4F46E5; }
.sm-btn-warn { background: #F59E0B; color: #fff; border-color: #F59E0B; }
.sm-btn-warn:active { background: #D97706; }
.sm-btn-ghost { border-color: transparent; color: #6366F1; background: transparent; }
.sm-btn-ghost:active { background: #EEF2FF; }
.sm-btn-sm { padding: 6px 12px; font-size: 12px; }

/* ===== CARD LIST ===== */
.sm-list { display: flex; flex-direction: column; gap: 10px; }
.sm-card { background: #fff; border-radius: 12px; overflow: hidden; transition: box-shadow .15s; }
.sm-card:active { box-shadow: 0 2px 8px rgba(0,0,0,.06); }
.sm-card.off { opacity: .45; }
.sm-card-body { padding: 14px 16px; }
.sm-card-left { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; }
.sm-card-icon { width: 44px; height: 44px; border-radius: 12px; object-fit: cover; flex-shrink: 0; }
.sm-card-icon-letter { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; flex-shrink: 0; }
.sm-card-info { flex: 1; min-width: 0; }
.sm-card-title { font-size: 15px; font-weight: 700; color: #1a1a1a; display: flex; align-items: center; gap: 8px; line-height: 1.4; }
.sm-card-meta { font-size: 12px; color: #999; margin-top: 4px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.sm-meta-item { display: inline-flex; align-items: center; gap: 3px; }
.sm-meta-dot { width: 3px; height: 3px; border-radius: 50%; background: #d0d4da; flex-shrink: 0; }
.sm-report-count { color: #EF4444; font-weight: 600; }
.sm-report-type-badge { display: inline-block; font-size: 11px; padding: 1px 7px; border-radius: 10px; background: #FEF2F2; color: #DC2626; font-weight: 600; margin-left: 6px; }
.sm-report-detail { font-size: 12px; color: #888; margin-top: 4px; font-style: italic; }
.sm-admin-reply { color: #6366F1; }

.sm-link { color: #6366F1; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.sm-link:hover { opacity: .8; }

.sm-status-pending { font-size: 10px; padding: 2px 7px; border-radius: 10px; background: #FEF3C7; color: #D97706; font-weight: 600; margin-left: 6px; }
.sm-status-ok { font-size: 10px; padding: 2px 7px; border-radius: 10px; background: #D1FAE5; color: #059669; font-weight: 600; margin-left: 6px; }
.sm-status-reject { font-size: 10px; padding: 2px 7px; border-radius: 10px; background: #FEE2E2; color: #DC2626; font-weight: 600; margin-left: 6px; }

.sm-tag { display: inline-block; font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 600; }
.sm-tag-off { background: #FEE2E2; color: #DC2626; }
.sm-tag-lock { background: #FEF3C7; color: #D97706; display: inline-flex; align-items: center; gap: 3px; }
.sm-tag-pin { background: #DBEAFE; color: #2563EB; margin-left: 6px; }
.sm-tag-gpin { background: #EDE9FE; color: #7C3AED; margin-left: 4px; }
.sm-tag-essence { background: #FEF3C7; color: #D97706; margin-left: 4px; }
.sm-tag-hot { background: #FEE2E2; color: #DC2626; margin-left: 4px; }
.sm-tag-badge { background: #D1FAE5; color: #059669; margin-left: 4px; }

/* ===== CARD ACTIONS ===== */
.sm-card-acts { display: flex; gap: 8px; flex-wrap: wrap; }
.sm-acts-btn { padding: 6px 14px; border-radius: 6px; border: 1px solid #e5e7eb; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all .12s; font-weight: 500; }
.sm-acts-btn:active { background: #f5f5f5; }
.sm-acts-mod { color: #6366F1; border-color: #C7D2FE; }
.sm-acts-mod:active { background: #EEF2FF; }
.sm-acts-toggle { color: #F59E0B; border-color: #FDE68A; }
.sm-acts-toggle:active { background: #FFFBEB; }
.sm-acts-del { color: #EF4444; border-color: #FECACA; }
.sm-acts-del:active { background: #FEF2F2; }
.sm-acts-ok { color: #10B981; border-color: #A7F3D0; }
.sm-acts-ok:active { background: #ECFDF5; }
.sm-acts-warn { color: #F59E0B; border-color: #FDE68A; }
.sm-acts-warn:active { background: #FFFBEB; }
.sm-acts-xs { padding: 3px 10px; font-size: 11px; }
.sm-acts-pin { color: #2563EB; border-color: #BFDBFE; }
.sm-acts-pin:active { background: #EFF6FF; }
.sm-acts-gpin { color: #7C3AED; border-color: #DDD6FE; }
.sm-acts-gpin:active { background: #F5F3FF; }
.sm-acts-badge { color: #059669; border-color: #A7F3D0; }
.sm-acts-badge:active { background: #ECFDF5; }
.sm-acts-essence { color: #D97706; border-color: #FDE68A; }
.sm-acts-essence:active { background: #FFFBEB; }
.sm-acts-hot { color: #DC2626; border-color: #FECACA; }
.sm-acts-hot:active { background: #FEF2F2; }
.sm-acts-norm { color: #9CA3AF; border-color: #E5E7EB; }
.sm-acts-norm:active { background: #F9FAFB; }
.sm-acts-off { color: #9CA3AF; border-color: #E5E7EB; }
.sm-acts-off:active { background: #F9FAFB; }

/* ===== POST ITEM ===== */
.sm-post-info { margin-bottom: 12px; }
.sm-post-author { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.sm-post-avatar { width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 600; flex-shrink: 0; }
.sm-post-username { font-size: 13px; color: #6366F1; font-weight: 600; }
.sm-post-time { font-size: 11px; color: #bbb; margin-left: auto; }
.sm-post-title { font-size: 15px; font-weight: 600; color: #1a1a1a; line-height: 1.5; }
.sm-thumbs { display: flex; gap: 6px; margin-top: 10px; }
.sm-thumb { width: 72px; height: 72px; border-radius: 8px; object-fit: cover; border: 1px solid #f0f0f0; }

/* ===== REPORT ITEM ===== */
.sm-report-card { border-left: 3px solid #EF4444; }
.sm-report-icon { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.sm-report-icon.post { background: #EEF2FF; color: #6366F1; }
.sm-report-icon.comment { background: #FFF7ED; color: #F97316; }
.sm-report-icon.unlock { background: #F0FDF4; color: #16A34A; }

/* ===== OVERLAY & DIALOG ===== */
.sm-overlay { position: fixed; inset: 0; z-index: 999; background: rgba(0,0,0,.4); display: flex; align-items: flex-end; justify-content: center; }
.sm-dialog { background: #fff; border-radius: 16px 16px 0 0; width: 100%; max-width: 480px; max-height: 85vh; display: flex; flex-direction: column; }
.sm-dialog-head { display: flex; align-items: center; justify-content: space-between; padding: 18px 16px 14px; flex-shrink: 0; }
.sm-dialog-head h3 { margin: 0; font-size: 17px; font-weight: 700; color: #1a1a1a; }
.sm-dialog-close { background: #f5f5f5; border: none; width: 28px; height: 28px; border-radius: 50%; font-size: 18px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; }
.sm-dialog-body { padding: 0 16px 16px; overflow-y: auto; flex: 1; }
.sm-dialog-btns { display: flex; gap: 10px; padding: 12px 16px 20px; justify-content: flex-end; flex-shrink: 0; border-top: 1px solid #f5f5f5; }

/* ===== FIELD ===== */
.sm-field { margin-bottom: 14px; }
.sm-field label { display: block; font-size: 13px; color: #666; margin-bottom: 5px; font-weight: 600; }
.sm-field input, .sm-field select { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; color: #333; background: #f9fafb; outline: none; box-sizing: border-box; transition: border .15s; }
.sm-field input:focus { border-color: #6366F1; background: #fff; }
.sm-textarea { width: 100%; padding: 10px 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; color: #333; background: #f9fafb; outline: none; box-sizing: border-box; resize: vertical; font-family: inherit; transition: border .15s; }
.sm-textarea:focus { border-color: #6366F1; background: #fff; }
.sm-visibility-toggle { display: flex; gap: 8px; }
.sm-vis-opt { flex: 1; height: 38px; border-radius: 8px; border: 1px solid #e5e7eb; background: #fff; font-size: 13px; color: #888; cursor: pointer; font-weight: 500; transition: all .12s; }
.sm-vis-opt.on { background: #6366F1; color: #fff; border-color: #6366F1; }
.sm-vis-opt:last-child.on { background: #EF4444; border-color: #EF4444; }

/* ===== UPLOAD ===== */
.sm-upload-row { display: flex; align-items: center; gap: 10px; }
.sm-upload-preview { width: 48px; height: 48px; border-radius: 12px; object-fit: cover; }
.sm-upload-placeholder { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; font-weight: 700; }

/* ===== SECTION DIALOG ===== */
.sm-dialog-section .sm-dialog-body { max-height: 60vh; }

/* ===== MOD DIALOG ===== */
.sm-dialog-mod .sm-dialog-body { max-height: none; padding: 0; }
.sm-dialog-mod { max-height: 80vh; }

/* ===== MOD ADD AREA ===== */
.sm-mod-add-area { padding: 0 16px 14px; border-bottom: 1px solid #f0f0f0; }
.sm-mod-add-title { font-size: 13px; color: #888; font-weight: 600; margin-bottom: 8px; }
.sm-mod-role-pick { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.sm-mod-role-pick-label { font-size: 12px; color: #888; white-space: nowrap; }
.sm-role-select { position: relative; flex: 1; display: flex; align-items: center; justify-content: space-between; height: 36px; padding: 0 12px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; cursor: pointer; font-size: 13px; color: #333; transition: border-color .15s; }
.sm-role-select:active { border-color: #6366F1; }
.sm-role-select-text { font-weight: 500; }
.sm-role-select-arrow { transition: transform .15s; flex-shrink: 0; }
.sm-role-select-arrow.open { transform: rotate(180deg); }
.sm-role-dropdown { position: absolute; top: 42px; left: 0; right: 0; background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.08); z-index: 30; max-height: 200px; overflow-y: auto; }
.sm-role-dropdown-item { padding: 8px 12px; font-size: 13px; color: #555; cursor: pointer; transition: background .1s, color .1s; }
.sm-role-dropdown-item:first-child { border-radius: 8px 8px 0 0; }
.sm-role-dropdown-item:last-child { border-radius: 0 0 8px 8px; }
.sm-role-dropdown-item.on { background: #EEF2FF; color: #6366F1; font-weight: 600; }
.sm-role-dropdown-item:active:not(.on) { background: #f5f5f5; }
.sm-search-row { position: relative; }
.sm-search-input-wrap { display: flex; align-items: center; background: #f5f6f8; border-radius: 8px; border: 1px solid #e5e7eb; padding: 0 10px; transition: border .15s; }
.sm-search-input-wrap:focus-within { border-color: #6366F1; background: #fff; }
.sm-search-icon { flex-shrink: 0; margin-right: 6px; }
.sm-search-input { flex: 1; padding: 10px 0; border: none; background: transparent; font-size: 14px; color: #333; outline: none; }
.sm-search-clear { background: #d0d4da; border: none; width: 20px; height: 20px; border-radius: 50%; color: #fff; font-size: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }

/* ===== SEARCH RESULTS DROPDOWN ===== */
.sm-search-results-wrap { margin-top: 6px; background: #fff; border: 1px solid #e5e7eb; border-radius: 10px; max-height: 180px; overflow-y: auto; box-shadow: 0 4px 12px rgba(0,0,0,.08); }
.sm-search-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; cursor: pointer; transition: background .1s; }
.sm-search-item:active { background: #f5f6f8; }
.sm-search-item + .sm-search-item { border-top: 1px solid #f5f5f5; }
.sm-search-av { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 13px; font-weight: 700; flex-shrink: 0; }
.sm-search-info { flex: 1; min-width: 0; }
.sm-search-name { font-size: 14px; color: #1a1a1a; font-weight: 600; display: block; }
.sm-search-id { font-size: 11px; color: #bbb; }
.sm-search-add { font-size: 12px; color: #6366F1; font-weight: 600; flex-shrink: 0; }

/* ===== MOD CURRENT LIST ===== */
.sm-mod-current { padding: 0 16px; flex: 1; overflow-y: auto; }
.sm-mod-current-title { font-size: 13px; color: #888; font-weight: 600; padding: 14px 0 8px; }
.sm-mod-list { display: flex; flex-direction: column; }
.sm-mod-item { display: flex; align-items: center; gap: 10px; padding: 10px 0; }
.sm-mod-item + .sm-mod-item { border-top: 1px solid #f5f5f5; }
.sm-mod-avatar { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 13px; font-weight: 700; flex-shrink: 0; }
.sm-mod-info { flex: 1; min-width: 0; display: flex; align-items: center; gap: 8px; }
.sm-mod-name { font-size: 14px; color: #1a1a1a; font-weight: 600; }
.sm-mod-role-tag { font-size: 10px; padding: 2px 8px; border-radius: 4px; font-weight: 600; border: none; cursor: pointer; transition: opacity .12s; }
.sm-mod-role-tag:active { opacity: .7; }
</style>
