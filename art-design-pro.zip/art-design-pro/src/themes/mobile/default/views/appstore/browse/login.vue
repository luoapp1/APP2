<template>
  <div class="flex w-full h-screen">
    <LoginLeftView />

    <div class="relative flex-1">
      <AuthTopBar />

      <div class="auth-right-wrap">
        <div class="form">
          <h3 class="title">{{ $t('login.title') }}</h3>
          <p class="sub-title">{{ $t('login.subTitle') }}</p>
          <ElForm
            ref="formRef"
            :model="formData"
            :rules="rules"
            :key="formKey"
            @keyup.enter="handleSubmit"
            style="margin-top: 25px"
          >
            <ElFormItem prop="username">
              <ElInput
                class="custom-height"
                :placeholder="$t('login.placeholder.username')"
                v-model.trim="formData.username"
              />
            </ElFormItem>
            <ElFormItem prop="password">
              <ElInput
                class="custom-height"
                :placeholder="$t('login.placeholder.password')"
                v-model.trim="formData.password"
                type="password"
                autocomplete="off"
                show-password
              />
            </ElFormItem>

            <div class="flex-cb mt-2 text-sm">
              <ElCheckbox v-model="formData.rememberPassword">{{ $t('login.rememberPwd') }}</ElCheckbox>
              <span class="text-theme cursor-pointer" @click="router.push('/auth/forget-password')">{{ $t('login.forgetPwd') }}</span>
            </div>

            <div style="margin-top: 30px">
              <ElButton
                class="w-full custom-height"
                type="primary"
                @click="handleSubmit"
                :loading="loading"
                v-ripple
              >
                {{ $t('login.btnText') }}
              </ElButton>
            </div>

            <div class="mt-5 text-sm text-gray-600">
              <span>{{ $t('login.noAccount') }}</span>
              <span class="text-theme cursor-pointer" @click="router.push('/auth/register')">{{ $t('login.register') }}</span>
            </div>
      </ElForm>
    </div>
      </div>
    </div>

    <!-- 封禁申诉弹窗 -->
    <ElDialog v-model="banAppealVisible" title="账号已被封禁" width="90%" :close-on-click-modal="false">
      <div class="ban-appeal-content">
        <div class="ban-info">
          <p class="ban-msg">{{ banMsg }}</p>
          <p class="ban-tip">如需申诉解封，请在下方填写申诉理由：</p>
        </div>
        <ElInput
          v-model="appealReason"
          type="textarea"
          :rows="4"
          placeholder="请详细说明申诉理由..."
          maxlength="500"
          show-word-limit
        />
      </div>
      <template #footer>
        <ElButton @click="banAppealVisible = false">取消</ElButton>
        <ElButton type="primary" :loading="appealLoading" :disabled="!appealReason.trim()" @click="submitAppeal">
          提交申诉
        </ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { useI18n } from 'vue-i18n'
import { fetchLogin, fetchGetUserInfo } from '@/api/auth'
import { http } from '@/utils/http'
import { HttpError } from '@/utils/http/error'
import { ElMessage } from 'element-plus'
import { type FormInstance, type FormRules } from 'element-plus'

defineOptions({ name: 'AppStoreLogin' })

const { t, locale } = useI18n()
const formKey = ref(0)

watch(locale, () => {
  formKey.value++
})

const userStore = useUserStore()
const router = useRouter()

const formRef = ref<FormInstance>()
const loading = ref(false)

const formData = reactive({
  username: '',
  password: '',
  rememberPassword: true
})

// 封禁申诉相关
const banAppealVisible = ref(false)
const banMsg = ref('')
const banUserId = ref(0)
const appealReason = ref('')
const appealLoading = ref(false)

const rules = computed<FormRules>(() => ({
  username: [{ required: true, message: t('login.placeholder.username'), trigger: 'blur' }],
  password: [{ required: true, message: t('login.placeholder.password'), trigger: 'blur' }]
}))

const handleSubmit = async () => {
  if (!formRef.value) return
  try {
    const valid = await formRef.value.validate()
    if (!valid) return
    loading.value = true

    const { username, password } = formData
    const res: any = await fetchLogin({ userName: username, password })

    if (!res.token) {
      throw new Error('Login failed - no token received')
    }

    userStore.setToken(res.token, res.refreshToken)
    userStore.setLoginStatus(true)

    try {
      const userInfo: any = await fetchGetUserInfo()
      userStore.setUserInfo(userInfo)
    } catch {}

    router.replace('/appstore/mine')
  } catch (error) {
    if (error instanceof HttpError) {
      // 账号被封禁，弹出申诉弹窗
      if (error.code === 403 && error.data) {
        const respBody = error.data as any
        const innerData = respBody?.data || respBody
        banUserId.value = innerData.userId || 0
        banMsg.value = error.message || '该账号已被封禁'
        banAppealVisible.value = true
        return
      }
      console.error('[Login] HTTP Error:', error.code)
    } else {
      console.error('[Login] Error:', error)
    }
  } finally {
    loading.value = false
  }
}

const submitAppeal = async () => {
  if (!appealReason.value.trim() || !banUserId.value) return
  appealLoading.value = true
  try {
    const res: any = await http.post('/api/user/appeal', {
      userId: banUserId.value,
      reason: appealReason.value
    })
    if (res.code === 200) {
      ElMessage.success('申诉已提交，请耐心等待管理员审核')
      banAppealVisible.value = false
      appealReason.value = ''
    } else {
      ElMessage.error(res.msg || '提交失败')
    }
  } catch {
    ElMessage.error('提交失败，请稍后重试')
  } finally {
    appealLoading.value = false
  }
}
</script>

<style scoped>
@reference '@styles/core/tailwind.css';

.auth-right-wrap {
  @apply absolute inset-0 w-[440px] h-[650px] py-[5px] m-auto overflow-hidden
    max-sm:px-7 max-sm:w-full
    animate-[slideInRight_0.6s_cubic-bezier(0.25,0.46,0.45,0.94)_forwards]
    max-md:animate-none;

  .form {
    @apply h-full py-[40px];
  }

  .title {
    @apply text-g-900 text-4xl font-semibold max-md:text-3xl max-sm:pt-10;
  }

  .sub-title {
    @apply mt-[10px] text-g-600 text-sm;
  }

  .custom-height {
    @apply !h-[40px];
  }
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
