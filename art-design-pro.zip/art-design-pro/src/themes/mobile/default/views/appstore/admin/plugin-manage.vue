<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">插件管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <button v-auth="'upload'" class="w-full h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="triggerUpload">上传插件安装包</button>
        <input ref="uploadInput" type="file" accept=".zip" class="hidden" @change="handleUploadPlugin" />
        <div v-if="uploading" class="text-xs text-gray-400 text-center mt-2">正在安装...</div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length>0">
          <div v-for="(item,i) in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">#{{ i+1 }}</span>
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status==='1'?'bg-green-50 text-green-600':'bg-gray-100 text-gray-400'">
                    {{ item.status==='1'?'已启用':'已禁用' }}<template v-if="item.installed===false"> (未部署)</template>
                  </span>
                </div>
                <div class="grid grid-cols-2 gap-x-2 gap-y-0.5 text-xs text-gray-400 mt-1">
                  <div>版本: <span class="text-gray-600">{{ item.version || '-' }}</span></div>
                  <div>作者: <span class="text-gray-600">{{ item.author || '-' }}</span></div>
                  <div class="col-span-2">描述: <span class="text-gray-600">{{ item.description || '-' }}</span></div>
                  <div class="col-span-2">安装: {{ item.createTime }}</div>
                </div>
              </div>
            </div>
            <div class="flex gap-1 mt-2">
              <button v-auth="'toggle'" class="flex-1 h-7 text-xs rounded-lg font-medium" :class="item.status==='1'?'bg-orange-50 text-orange-500 active:bg-orange-100':'bg-green-50 text-green-500 active:bg-green-100'" @click="togglePlugin(item)">{{ item.status==='1'?'禁用':'启用' }}</button>
              <button class="flex-1 h-7 text-xs rounded-lg bg-blue-50 text-blue-500 active:bg-blue-100 font-medium" @click="openUpgradeDialog(item)">升级</button>
              <button v-auth="'delete'" class="flex-1 h-7 text-xs rounded-lg bg-red-50 text-red-400 active:bg-red-100 font-medium" @click="deletePlugin(item)">删除</button>
              <button v-auth="'config'" class="flex-1 h-7 text-xs rounded-lg bg-purple-50 text-purple-500 active:bg-purple-100 font-medium" @click="openConfigDialog(item)">配置</button>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无插件</span></div>
      </div>
    </div>

    <!-- 升级弹窗 -->
    <div v-if="upgradeVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="upgradeVisible=false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="upgradeVisible=false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">升级插件</span>
          <button class="text-sm font-semibold text-[#FF4757]" :disabled="upgrading" @click="doUpgrade">{{ upgrading?'升级中...':'确认升级' }}</button>
        </div>
        <div class="p-4 space-y-3">
          <div class="flex items-center gap-2"><span class="text-sm text-gray-800 font-medium">{{ upgradeTarget?.name }}</span><span class="text-xs px-1.5 py-0.5 rounded bg-blue-50 text-blue-500">v{{ upgradeTarget?.version }}</span></div>
          <button class="w-full h-24 border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center gap-1 active:bg-gray-50" @click="triggerUpgradeUpload">
            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
            <span class="text-xs text-gray-500">{{ upgradeFile ? upgradeFile.name : '选择新版本 .zip 文件' }}</span>
            <span class="text-[10px] text-gray-400">最大 50MB</span>
          </button>
          <input ref="upgradeInput" type="file" accept=".zip" class="hidden" @change="handleUpgradeFile" />
        </div>
      </div>
    </div>

    <!-- 配置弹窗 -->
    <div v-if="configVisible" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" @click.self="configVisible=false">
      <div class="bg-white rounded-3xl shadow-xl w-full max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="configVisible=false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">插件配置 — {{ configTarget?.name }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" :disabled="configSaving" @click="doSaveConfig">{{ configSaving?'保存中...':'保存' }}</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4" v-if="configFields.length>0">
          <template v-for="field in configFields" :key="field.key">
            <!-- 布尔/开关 -->
            <div v-if="field.type==='switch'||field.type==='boolean'" class="flex items-center justify-between py-2">
              <span class="text-sm text-gray-600">{{ field.label }}</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="getVal(field.key)?'bg-[#FF4757]':'bg-gray-200'" @click="setVal(field.key,!getVal(field.key))">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="getVal(field.key)?'translate-x-4.5':'left-0.5'"/>
              </button>
            </div>
            <!-- 嵌套对象 -->
            <div v-else-if="field.type==='object'" class="mb-3">
              <div class="text-xs font-semibold text-gray-500 mb-2 px-1">{{ field.label }}</div>
              <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
                <div v-for="sf in field.children" :key="sf.key">
                  <div v-if="sf.type==='switch'||sf.type==='boolean'" class="flex items-center justify-between py-1">
                    <span class="text-xs text-gray-500">{{ sf.label }}</span>
                    <button class="w-9 h-5 rounded-full transition-colors relative" :class="getNestedVal(field.key,sf.key)?'bg-[#FF4757]':'bg-gray-300'" @click="setNestedVal(field.key,sf.key,!getNestedVal(field.key,sf.key))">
                      <span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="getNestedVal(field.key,sf.key)?'translate-x-4.5':'left-0.5'"/>
                    </button>
                  </div>
                  <div v-else class="space-y-1">
                    <label class="text-[11px] text-gray-400">{{ sf.label }}</label>
                    <input v-if="sf.type==='url'" v-model="cfgObj[field.key][sf.key]" type="url" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" :placeholder="sf.label" />
                    <input v-else v-model="cfgObj[field.key][sf.key]" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" :placeholder="sf.label" />
                  </div>
                </div>
              </div>
            </div>
            <!-- 数组 -->
            <div v-else-if="field.type==='array'" class="mb-3">
              <div class="flex items-center justify-between mb-2 px-1">
                <span class="text-xs font-semibold text-gray-500">{{ field.label }} ({{ cfgArrSize(field.key) }})</span>
                <button class="text-xs text-[#FF4757] font-medium active:opacity-70" @click="addArrayItem(field)">+ 添加</button>
              </div>
              <div v-if="cfgArrSize(field.key)===0" class="text-xs text-gray-400 text-center py-4 bg-[#f5f6f8] rounded-xl">暂无数据</div>
              <div v-for="(itemVal,idx) in cfgArr(field.key)" :key="idx" class="bg-[#f5f6f8] rounded-xl p-3 mb-2 last:mb-0">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[10px] text-gray-400 bg-gray-200 px-1.5 py-0.5 rounded">#{{ idx+1 }}</span>
                  <button class="text-[10px] text-red-400 active:text-red-600" @click="removeArrayItem(field.key,idx)">删除</button>
                </div>
                <div v-for="af in field.itemFields" :key="af.key" class="mb-2 last:mb-0">
                  <div v-if="af.type==='switch'||af.type==='boolean'" class="flex items-center justify-between py-1">
                    <span class="text-xs text-gray-500">{{ af.label }}</span>
                    <button class="w-9 h-5 rounded-full transition-colors relative" :class="getArrItemVal(field.key,idx,af.key)?'bg-[#FF4757]':'bg-gray-300'" @click="setArrItemVal(field.key,idx,af.key,!getArrItemVal(field.key,idx,af.key))">
                      <span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="getArrItemVal(field.key,idx,af.key)?'translate-x-4.5':'left-0.5'"/>
                    </button>
                  </div>
                  <div v-else-if="af.type==='color'" class="flex items-center gap-2">
                    <label class="text-[11px] text-gray-400 flex-shrink-0">{{ af.label }}</label>
                    <input v-model="cfgArr(field.key)[idx][af.key]" type="color" class="w-8 h-7 rounded border-none cursor-pointer" />
                  </div>
                  <div v-else class="space-y-1">
                    <label class="text-[11px] text-gray-400">{{ af.label }}</label>
                    <input v-model="cfgArr(field.key)[idx][af.key]" class="w-full h-9 px-2 text-sm bg-white rounded-lg border-none outline-none" :placeholder="af.label" />
                  </div>
                </div>
              </div>
            </div>
            <!-- 普通字段 -->
            <div v-else-if="field.type==='select'" class="space-y-1">
              <label class="text-xs text-gray-500">{{ field.label }}</label>
              <select v-model="cfgObj[field.key]" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option v-for="opt in field.options" :key="opt" :value="opt">{{ opt }}</option></select>
            </div>
            <div v-else-if="field.type==='color'" class="space-y-1">
              <label class="text-xs text-gray-500">{{ field.label }}</label>
              <input v-model="cfgObj[field.key]" type="color" class="w-full h-10 px-1 rounded-lg border-none cursor-pointer" />
            </div>
            <div v-else-if="field.type==='textarea'" class="space-y-1">
              <label class="text-xs text-gray-500">{{ field.label }}</label>
              <textarea v-model="cfgObj[field.key]" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
            </div>
            <div v-else class="space-y-1">
              <label class="text-xs text-gray-500">{{ field.label }}</label>
              <input v-model="cfgObj[field.key]" :type="field.type==='password'?'password':'text'" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            </div>
          </template>
        </div>
        <div v-else class="flex-1 flex items-center justify-center text-sm text-gray-400">该插件没有可配置项</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'PluginManageMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const loading=ref(false);const data=ref<any[]>([])
const fetchData=async()=>{loading.value=true;try{const res:any=await request.get({url:'/api/plugins/list'});data.value=(res?.records||res?.data?.records||[])||(Array.isArray(res)?res:[])}catch{}loading.value=false}

// Upload
const uploadInput=ref<HTMLInputElement>();const uploading=ref(false)
const triggerUpload=()=>uploadInput.value?.click()
const handleUploadPlugin=async(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;uploading.value=true;try{const fd=new FormData();fd.append('file',file);await request.post({url:'/api/plugins/upload',data:fd});showToast('安装成功');fetchData()}catch(e:any){showToast('安装失败: '+(e.message||''),'error')}uploading.value=false;input.value=''}

// Toggle
const togglePlugin=async(item:any)=>{try{await request.put({url:`/api/plugins/${item.id}/toggle`});showToast(item.status==='1'?'已禁用':'已启用');fetchData()}catch(e:any){showToast('操作失败: '+(e.message||''),'error')}}

// Delete
const deletePlugin=async(item:any)=>{if(!confirm(`确定删除插件 ${item.name}？`))return;try{await request.del({url:`/api/plugins/${item.id}`});showToast('删除成功');fetchData()}catch{showToast('删除失败','error')}}

// Upgrade
const upgradeVisible=ref(false);const upgradeTarget=ref<any>(null);const upgradeFile=ref<File|null>(null);const upgrading=ref(false);const upgradeInput=ref<HTMLInputElement>()
const openUpgradeDialog=(item:any)=>{upgradeTarget.value=item;upgradeFile.value=null;upgradeVisible.value=true}
const triggerUpgradeUpload=()=>upgradeInput.value?.click()
const handleUpgradeFile=(e:Event)=>{const input=e.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;upgradeFile.value=file;input.value=''}
const doUpgrade=async()=>{if(!upgradeFile.value){showToast('请选择文件','error');return};upgrading.value=true;try{const fd=new FormData();fd.append('file',upgradeFile.value);await request.post({url:`/api/plugins/${upgradeTarget.value.id}/upgrade`,data:fd});showToast('升级成功');upgradeVisible.value=false;fetchData()}catch(e:any){showToast('升级失败: '+(e.message||''),'error')}upgrading.value=false}

// Config
const configVisible=ref(false);const configTarget=ref<any>(null)
const cfgObj=reactive<Record<string,any>>({})
const configFields=ref<any[]>([]);const configSaving=ref(false)

type CfgField = { key:string; label:string; type:string; options?:any[]; children?:CfgField[]; itemFields?:CfgField[] }

function guessType(v:any):string{
  if(typeof v==='boolean')return'switch'
  if(typeof v==='number')return'number'
  if(typeof v==='string' && /^#[0-9a-fA-F]{3,8}$/.test(v))return'color'
  if(Array.isArray(v))return'array'
  if(v && typeof v==='object')return'object'
  return'text'
}

function buildItemFields(sample:Record<string,any>, itemMeta?:Record<string,any>):CfgField[]{
  return Object.keys(sample).map(k=>({
    key:k, label:(itemMeta?.[k]?.label) || k,
    type: guessType(sample[k]),
    options: itemMeta?.[k]?.options
  }))
}

function deepClone(v:any):any{
  if(Array.isArray(v)) return v.map(deepClone)
  if(v && typeof v==='object'){ const o:Record<string,any>={}; for(const k of Object.keys(v)) o[k]=deepClone(v[k]); return o }
  return v
}

function getVal(key:string){ return cfgObj[key] }
function setVal(key:string,v:any){ cfgObj[key]=v }

function getNestedVal(parentKey:string,key:string){ return cfgObj[parentKey]?.[key] }
function setNestedVal(parentKey:string,key:string,v:any){ if(cfgObj[parentKey]) cfgObj[parentKey][key]=v }

function cfgArr(key:string):any[]{ return (cfgObj[key] as any[])||[] }
function cfgArrSize(key:string):number{ return (cfgObj[key] as any[])?.length||0 }
function getArrItemVal(key:string,idx:number,fi:string){ return (cfgObj[key] as any[])?.[idx]?.[fi] }
function setArrItemVal(key:string,idx:number,fi:string,v:any){
  const arr=cfgObj[key] as any[]
  if(arr && arr[idx]) arr[idx][fi]=v
}

function addArrayItem(field:CfgField){
  const arr=cfgObj[field.key] as any[]
  const sample:Record<string,any>={}
  if(field.itemFields){
    for(const f of field.itemFields){
      sample[f.key]= f.type==='switch' ? true : ''
    }
  }
  if(!arr){ cfgObj[field.key]=[] }
  ;(cfgObj[field.key] as any[]).push(sample)
}

function removeArrayItem(key:string,idx:number){
  (cfgObj[key] as any[]).splice(idx,1)
}

const openConfigDialog=async(item:any)=>{
  configTarget.value=item
  let manifest=item.manifest||{}
  if(typeof manifest==='string'){try{manifest=JSON.parse(manifest)}catch{}}
  const config=manifest.config||{}
  const schema=manifest.configMeta||{}

  // Clear and rebuild cfgObj
  for(const k of Object.keys(cfgObj)) delete cfgObj[k]
  Object.assign(cfgObj, deepClone(config))

  const fields:CfgField[]=[]
  for(const [key,val] of Object.entries(config)){
    const ui=schema[key]||{}
    const type=ui.uiType||guessType(val)
    const label=ui.label||key
    if(type==='object'){
      const children:CfgField[]=[]
      const childrenMeta=ui.childrenMeta||{}
      if(val && typeof val==='object'){
        for(const ck of Object.keys(val)){
          const cv=val[ck]
          children.push({
            key:ck, label:childrenMeta[ck]?.label||ck,
            type:guessType(cv),
            options:childrenMeta[ck]?.options
          })
        }
      }
      fields.push({key,label,type,children})
    }else if(type==='array'){
      const itemMeta=ui.itemMeta||{}
      const itemFields= (val && val.length>0 && typeof val[0]==='object')
        ? buildItemFields(val[0], itemMeta)
        : []
      fields.push({key,label,type,itemFields})
    }else{
      fields.push({key,label,type,options:ui.options})
    }
  }
  configFields.value=fields
  configVisible.value=true
}

const doSaveConfig=async()=>{
  configSaving.value=true
  try{
    await request.put({
      url:`/api/plugins/${configTarget.value.name}/config`,
      data:{config:cfgObj}
    })
    showToast('配置已保存')
    configVisible.value=false
  }catch(e:any){
    showToast('保存失败: '+(e.message||''),'error')
  }
  configSaving.value=false
}

onMounted(()=>fetchData())
</script>
