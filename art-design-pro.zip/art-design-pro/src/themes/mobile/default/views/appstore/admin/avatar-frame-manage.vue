<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">头像框管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="frames.length > 0">
          <div class="grid grid-cols-2 gap-3 p-3">
            <div v-for="item in frames" :key="item.id" class="bg-[#f5f6f8] rounded-xl p-3 relative">
              <div class="w-full h-24 rounded-lg mb-2 flex items-center justify-center overflow-hidden bg-white">
                <img v-if="item.imageUrl || item.image_url" :src="$fixImgUrl(item.imageUrl || item.image_url)" class="w-full h-full object-contain" />
                <svg v-else class="w-8 h-8 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              </div>
              <div class="text-xs font-medium text-gray-700 truncate mb-1">{{ item.name }}</div>
              <div class="text-[10px] text-gray-400 mb-2">{{ obtainLabel(item.obtainType || item.obtain_type) }}</div>
              <div class="flex gap-1">
                <button class="flex-1 text-[10px] px-1 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click="openGrantDialog(item)">授予</button>
                <button class="flex-1 text-[10px] px-1 py-1 rounded bg-purple-50 text-purple-500 active:bg-purple-100" @click="openUsersDialog(item)">用户</button>
              </div>
              <div class="flex gap-1 mt-1">
                <button v-auth="'edit'" class="flex-1 text-[10px] px-1 py-1 rounded bg-gray-100 text-gray-500 active:bg-gray-200" @click="openDialog(item)">编辑</button>
                <button v-auth="'delete'" class="text-[10px] px-1 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ frames.length }} 个头像框</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无头像框</span></div>
      </div>

      <button v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="dialogVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="dialogVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[90vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3.5 border-b border-gray-100 flex-shrink-0">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="dialogVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span class="text-base font-bold text-gray-800">{{ editId ? '编辑头像框' : '新增头像框' }}</span>
          <button class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-sm font-medium active:opacity-85 shadow-sm shadow-red-200" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto px-4 py-5 space-y-5">
          <!-- 预览区 -->
          <div class="flex flex-col items-center pb-4">
            <div class="w-24 h-24 rounded-2xl bg-gradient-to-br from-gray-100 to-gray-50 flex items-center justify-center overflow-hidden shadow-inner border-2 border-gray-100">
              <img v-if="form.imageUrl" :src="$fixImgUrl(form.imageUrl)" class="w-full h-full object-contain" />
              <svg v-else class="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            </div>
            <div class="flex gap-2 mt-3">
              <button class="h-8 px-4 rounded-full bg-[#FF4757]/10 text-[#FF4757] text-xs font-medium active:bg-[#FF4757]/20 transition-colors" :disabled="uploadingImg" @click="triggerImgUpload">
                <span class="flex items-center gap-1">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                  {{ uploadingImg ? '上传中...' : (form.imageUrl ? '更换图片' : '上传图片') }}
                </span>
              </button>
              <button v-if="form.imageUrl" class="h-8 px-4 rounded-full bg-gray-100 text-gray-400 text-xs active:bg-gray-200 transition-colors" @click="form.imageUrl = ''">移除</button>
            </div>
            <input ref="imgInput" type="file" accept="image/*" class="hidden" @change="handleImgUpload" />
          </div>

          <!-- 基本信息 -->
          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">基本信息</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">名称</label>
              <input v-model="form.name" class="w-full h-11 px-3.5 text-sm bg-white rounded-xl border-none outline-none placeholder:text-gray-300" placeholder="输入头像框名称" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">描述</label>
              <textarea v-model="form.description" rows="2" class="w-full p-3 text-sm bg-white rounded-xl border-none outline-none resize-none placeholder:text-gray-300" placeholder="可选描述" />
            </div>
          </div>

          <!-- 获取设置 -->
          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">获取设置</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">获取方式</label>
              <div class="grid grid-cols-2 gap-2">
                <button v-for="opt in obtainOptions" :key="opt.value" class="h-10 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1.5"
                  :class="form.obtainType === opt.value ? 'bg-[#FF4757] text-white shadow-sm shadow-red-200' : 'bg-white text-gray-500 active:bg-gray-100'"
                  @click="form.obtainType = opt.value">
                  <span v-html="opt.icon"></span>{{ opt.label }}
                </button>
              </div>
            </div>
            <div v-if="form.obtainType === 'experience'">
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">所需经验等级</label>
              <select v-model.number="form.expLevelRequired" class="w-full h-11 px-3.5 text-sm bg-white rounded-xl border-none outline-none">
                <option v-for="lv in experienceLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option>
              </select>
            </div>
            <div v-if="form.obtainType === 'membership'">
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">所需会员等级</label>
              <select v-model.number="form.memberLevelRequired" class="w-full h-11 px-3.5 text-sm bg-white rounded-xl border-none outline-none">
                <option v-for="lv in memberLevels" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
              </select>
            </div>
          </div>

          <!-- 其他设置 -->
          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">其他设置</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">排序</label>
              <input v-model.number="form.sortOrder" type="number" class="w-full h-11 px-3.5 text-sm bg-white rounded-xl border-none outline-none" />
            </div>
            <div class="flex items-center justify-between bg-white rounded-xl px-3.5 py-2.5">
              <span class="text-sm text-gray-700 font-medium">启用状态</span>
              <div class="flex items-center gap-2">
                <span class="text-xs" :class="form.status === '1' ? 'text-green-500' : 'text-gray-400'">{{ form.status === '1' ? '已启用' : '已禁用' }}</span>
                <button class="w-11 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.status = form.status === '1' ? '0' : '1'">
                  <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-5' : 'left-0.5'" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="grantVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="grantVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="grantVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[85vw] overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3.5 border-b border-gray-100">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="grantVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span class="text-base font-bold text-gray-800">授予头像框</span>
          <button class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-sm font-medium active:opacity-85 shadow-sm shadow-red-200" @click="doGrant">确认</button>
        </div>
        <div class="p-5 space-y-3">
          <div class="text-sm text-gray-500 text-center">将 <span class="font-semibold text-gray-800">{{ grantTarget?.name }}</span> 授予指定用户</div>
          <div class="bg-[#f5f6f8] rounded-xl p-3">
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">用户 ID</label>
            <input v-model.number="grantUserId" type="number" min="1" class="w-full h-11 px-3.5 text-sm bg-white rounded-xl border-none outline-none" placeholder="输入用户ID" />
          </div>
        </div>
      </div>
    </div>

    <div v-if="usersVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="usersVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="usersVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[90vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3.5 border-b border-gray-100 flex-shrink-0">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="usersVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <div class="text-center">
            <span class="text-base font-bold text-gray-800">{{ usersTarget?.name }}</span>
            <div class="text-xs text-gray-400">拥有者列表</div>
          </div>
          <span class="w-8" />
        </div>
        <div class="flex-1 overflow-y-auto">
          <div v-if="usersList.length > 0">
            <div v-for="u in usersList" :key="u.id || u.userId" class="px-4 py-3.5 border-b border-gray-50 flex items-center justify-between">
              <div class="flex-1">
                <span class="text-sm text-gray-800">{{ u.nickname || u.username || u.userName || '-' }}</span>
                <span class="text-xs text-gray-400 ml-2">ID:{{ u.id || u.userId }}</span>
              </div>
            </div>
          </div>
          <div v-else class="py-12 text-center text-sm text-gray-400">暂无用户拥有此头像框</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'AvatarFrameManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const obtainMap: Record<string, string> = { manual: '手动授予', experience: '经验等级', membership: '会员等级', activity: '活动获取' }
const obtainLabel = (t: string) => obtainMap[t] || t
const obtainOptions = [
  { value: 'manual', label: '手动授予', icon: '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"/></svg>' },
  { value: 'experience', label: '经验等级', icon: '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>' },
  { value: 'membership', label: '会员等级', icon: '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>' },
  { value: 'activity', label: '活动获取', icon: '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>' },
]

const loading = ref(false); const frames = ref<any[]>([])
const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/avatar-frame/all' })
    frames.value = (res?.records || res?.data?.records || res?.data || res || []).map((f: any) => ({
      ...f,
      imageUrl: f.imageUrl || f.image_url,
      obtainType: f.obtainType || f.obtain_type,
      expLevelRequired: f.expLevelRequired ?? f.exp_level_required,
      memberLevelRequired: f.memberLevelRequired ?? f.member_level_required,
      sortOrder: f.sortOrder ?? f.sort_order,
    }))
  } catch { }
  loading.value = false
}

const memberLevels = ref<any[]>([])
const experienceLevels = ref<any[]>([])
const loadRefs = async () => {
  try {
    const [ml, el]: any[] = await Promise.all([
      request.get({ url: '/api/operation/membership-level/list' }),
      request.get({ url: '/api/operation/experience-level/list' })
    ])
    memberLevels.value = ml?.records || []
    experienceLevels.value = el?.records || []
  } catch {}
}

const imgInput = ref<HTMLInputElement>(); const uploadingImg = ref(false)
const triggerImgUpload = () => imgInput.value?.click()
const handleImgUpload = async (e: Event) => {
  const input = e.target as HTMLInputElement; const file = input.files?.[0]
  if (!file) return; uploadingImg.value = true
  try {
    const fd = new FormData(); fd.append('file', file)
    const res: any = await request.post({ url: '/api/avatar-frame/upload', data: fd })
    form.imageUrl = res?.url || res?.data?.url || res?.data || ''
    showToast('上传成功')
  } catch (e: any) { showToast('上传失败: ' + (e.message || ''), 'error') }
  uploadingImg.value = false; input.value = ''
}

const dialogVisible = ref(false); const editId = ref<number | null>(null)
const formDefault = () => ({ name: '', imageUrl: '', description: '', obtainType: 'manual', expLevelRequired: 0, memberLevelRequired: 0, sortOrder: 0, status: '1' })
const form = reactive(formDefault())

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) {
    form.name = item.name || ''; form.imageUrl = item.imageUrl || item.image_url || ''
    form.description = item.description || ''; form.obtainType = item.obtainType || item.obtain_type || 'manual'
    form.expLevelRequired = item.expLevelRequired || item.exp_level_required || 0
    form.memberLevelRequired = item.memberLevelRequired || item.member_level_required || 0
    form.sortOrder = item.sortOrder || item.sort_order || 0; form.status = item.status || '1'
  } else {
    Object.assign(form, formDefault())
  }
  dialogVisible.value = true
}

const saveItem = async () => {
  try {
    await request.post({ url: '/api/avatar-frame/save', data: { id: editId.value || undefined, ...form } })
    showToast('保存成功'); dialogVisible.value = false; fetchData()
  } catch { showToast('保存失败', 'error') }
}

const deleteItem = async (item: any) => {
  if (!confirm(`确认删除头像框 ${item.name}？`)) return
  try {
    await request.del({ url: `/api/avatar-frame/${item.id}` })
    showToast('删除成功'); fetchData()
  } catch { showToast('删除失败', 'error') }
}

const grantVisible = ref(false); const grantTarget = ref<any>(null); const grantUserId = ref<number>(0)
const openGrantDialog = (item: any) => { grantTarget.value = item; grantUserId.value = 0; grantVisible.value = true }
const doGrant = async () => {
  if (!grantUserId.value) { showToast('请输入用户ID', 'error'); return }
  try {
    await request.post({ url: '/api/user/grant-frame', data: { userId: grantUserId.value, frameId: grantTarget.value.id } })
    showToast('授予成功'); grantVisible.value = false
  } catch { showToast('授予失败', 'error') }
}

const usersVisible = ref(false); const usersTarget = ref<any>(null); const usersList = ref<any[]>([])
const openUsersDialog = async (item: any) => {
  usersTarget.value = item; usersVisible.value = true
  try {
    const res: any = await request.get({ url: `/api/avatar-frame/${item.id}/users` })
    usersList.value = res?.records || res?.data?.records || res?.data || res || []
  } catch { usersList.value = [] }
}

onMounted(() => { fetchData(); loadRefs() })
</script>
