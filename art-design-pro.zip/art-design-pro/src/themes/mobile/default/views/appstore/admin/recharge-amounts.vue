<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">充值金额配置</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
      <template v-else>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div v-for="(item, idx) in amounts" :key="idx" class="px-3 py-3 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center gap-2">
              <span class="text-xs text-gray-400 w-6 shrink-0">{{ idx + 1 }}</span>
              <div class="flex-1 grid grid-cols-3 gap-2">
                <input v-model.number="item.amount" type="number" step="0.01" placeholder="金额" class="h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <input v-model="item.label" placeholder="标签" class="h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <select v-model="item.status" class="h-9 px-1 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600">
                  <option value="1">启用</option>
                  <option value="0">禁用</option>
                </select>
              </div>
              <button v-auth="'delete'" class="w-8 h-8 rounded-lg flex items-center justify-center text-red-400 active:bg-red-50 shrink-0" @click="removeAmount(idx)">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
            <div v-if="item.discount > 0" class="mt-1 ml-8">
              <span class="text-[10px] text-[#FF4757] bg-red-50 px-1.5 py-0.5 rounded">折扣{{ item.discount }}折</span>
            </div>
          </div>
        </div>

        <div class="mx-3 mt-2">
          <button v-auth="'add'" class="w-full h-10 bg-white text-[#FF4757] text-sm rounded-xl border border-dashed border-[#FF4757]/30 font-medium active:bg-red-50" @click="addAmount">+ 添加金额档位</button>
        </div>

        <div class="mx-3 mt-4 mb-8">
          <button v-auth="'edit'" class="w-full h-11 bg-[#FF4757] text-white text-sm rounded-xl font-medium active:opacity-80" :disabled="saving" @click="saveAll">{{ saving ? '保存中...' : '保存全部配置' }}</button>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'RechargeAmountsMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false); const saving = ref(false)
const amounts = ref<{ amount: number; label: string; discount: number; status: string }[]>([])

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/recharge/amounts' })
    const data = res?.records || res?.data?.records || res?.data || res || []
    amounts.value = data.length ? data.map((a: any) => ({
      amount: a.amount || 0, label: a.label || '', discount: a.discount || 0, status: a.status || '1'
    })) : []
  } catch { }
  loading.value = false
}

const addAmount = () => {
  amounts.value.push({ amount: 0, label: '', discount: 0, status: '1' })
}

const removeAmount = (idx: number) => {
  amounts.value.splice(idx, 1)
}

const saveAll = async () => {
  saving.value = true
  try {
    await request.post({ url: '/api/admin/recharge/amounts', data: { amounts: amounts.value } })
    showToast('保存成功')
  } catch { showToast('保存失败', 'error') }
  saving.value = false
}

onMounted(() => fetchData())
</script>
