<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">布局主题</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-for="group in themeGroups" :key="group.type">
        <div class="px-3 mt-3 mb-1.5">
          <span class="text-xs font-semibold text-gray-500 uppercase tracking-wide">{{ group.label }} ({{ group.themes.length }})</span>
        </div>
        <div class="bg-white mx-3 rounded-xl overflow-hidden" :class="group.themes.length === 0 ? '' : ''">
          <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
          <template v-else-if="group.themes.length > 0">
            <div v-for="theme in group.themes" :key="theme.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
              <div class="flex items-center justify-between">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-1">
                    <span class="text-sm font-semibold text-gray-800">{{ theme.name }}</span>
                    <span v-if="isActive(theme)" class="text-[10px] px-1.5 py-0.5 rounded bg-green-50 text-green-600">当前使用</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded bg-gray-50 text-gray-500">{{ theme.id }}</span>
                  </div>
                  <div class="text-xs text-gray-400">{{ theme.description || '无描述' }}</div>
                </div>
                <button
                  v-if="!isActive(theme)"
                  class="flex-shrink-0 ml-3 text-xs px-3 py-1.5 rounded-lg bg-[#FF4757] text-white font-medium active:opacity-80 disabled:opacity-40"
                  :disabled="activating === theme.id"
                  @click="doActivate(theme)"
                >
                  {{ activating === theme.id ? '切换中...' : '启用' }}
                </button>
                <span v-else class="flex-shrink-0 ml-3 text-xs text-green-600 font-medium">已激活</span>
              </div>
            </div>
          </template>
          <div v-else class="flex flex-col items-center py-12 text-gray-400">
            <span class="text-sm">暂无{{ group.type === 'pc' ? 'PC' : '手机' }}端主题</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { fetchLayoutThemes, setActiveLayoutTheme } from '@/api/layout-themes'

defineOptions({ name: 'LayoutThemesManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false)
const activating = ref('')
const themes = ref<any[]>([])
const activePc = ref('pc')
const activeMobile = ref('mobile')

const themeGroups = computed(() => [
  { type: 'pc', label: 'PC 端', themes: themes.value.filter((t: any) => t.type === 'pc') },
  { type: 'mobile', label: '手机端', themes: themes.value.filter((t: any) => t.type === 'mobile') }
])

function isActive(theme: any) {
  return theme.type === 'pc' ? theme.id === activePc.value : theme.id === activeMobile.value
}

async function fetchData() {
  loading.value = true
  try {
    const res: any = await fetchLayoutThemes()
    if (res) {
      themes.value = res.themes || []
      activePc.value = res.activePc || 'pc'
      activeMobile.value = res.activeMobile || 'mobile'
    }
  } finally {
    loading.value = false
  }
}

async function doActivate(theme: any) {
  activating.value = theme.id
  try {
    await setActiveLayoutTheme(theme.type, theme.id)
    showToast(`已启用 ${theme.type === 'pc' ? 'PC' : '手机'} 端主题`)
    if (theme.type === 'pc') activePc.value = theme.id
    else activeMobile.value = theme.id
  } catch {
    showToast('切换失败', 'error')
  } finally {
    activating.value = ''
  }
}

onMounted(() => { fetchData() })
</script>
