<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">注销审核</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>
      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="flex items-center justify-between">
          <div class="text-center flex-1">
            <div class="text-xl font-bold text-[#F59E0B]">{{ stats.pending }}</div>
            <div class="text-[11px] text-gray-400 mt-1">待审核</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#10B981]">{{ stats.approved }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已通过</div>
          </div>
          <div class="text-center flex-1 border-l border-gray-100">
            <div class="text-xl font-bold text-[#EF4444]">{{ stats.rejected }}</div>
            <div class="text-[11px] text-gray-400 mt-1">已拒绝</div>
          </div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="tableData.length > 0">
          <div v-for="item in tableData" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800">{{ item.username }}</span>
                  <span class="text-[10px] text-gray-400">ID:{{ item.id }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="statusTagClass(item.status)">{{ statusText(item.status) }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>申请时间: {{ item.create_time }}</div>
                  <div v-if="item.update_time">处理时间: {{ item.update_time }}</div>
                  <div v-if="item.admin_note" class="text-gray-500">备注: {{ item.admin_note }}</div>
                </div>
              </div>
              <div v-if="item.status === 'pending'" class="flex gap-2 ml-2 flex-shrink-0">
                <button v-auth="'approve'" class="text-xs px-2 py-1 rounded bg-green-50 text-green-600 active:bg-green-100" @click="handleApprove(item.id)">通过</button>
                <button v-auth="'reject'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-500 active:bg-red-100" @click="showRejectDialog(item.id)">拒绝</button>
              </div>
              <span v-else class="text-xs text-gray-300">已处理</span>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="pagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current - 1)">上一页</button>
            <span class="text-xs text-gray-400">{{ pagination.current }}/{{ totalPages }}</span>
            <button :disabled="pagination.current >= totalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current + 1)">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ pagination.total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无注销申请</span>
        </div>
      </div>
    </div>

    <!-- 拒绝原因弹窗 -->
    <div v-if="rejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="rejectVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="rejectVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">拒绝注销</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="handleReject">确认</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">拒绝原因</label>
          <textarea v-model="rejectReason" rows="3" placeholder="请输入拒绝原因(可选)" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'DeleteReviewMobile' })

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

const loading = ref(false)
const tableData = ref<any[]>([])
const pagination = reactive({ current: 1, size: 20, total: 0 })
const totalPages = computed(() => Math.max(1, Math.ceil(pagination.total / pagination.size)))

const stats = reactive({ pending: 0, approved: 0, rejected: 0 })

const statusMap: Record<string, string> = { pending: '待审核', approved: '已通过', rejected: '已拒绝' }
const statusClassMap: Record<string, string> = { pending: 'bg-yellow-50 text-yellow-600', approved: 'bg-green-50 text-green-600', rejected: 'bg-red-50 text-red-600' }

const statusText = (s: string) => statusMap[s] || s
const statusTagClass = (s: string) => statusClassMap[s] || 'bg-gray-100 text-gray-500'

const fetchData = async () => {
  loading.value = true
  try {
    const data: any = await request.get({ url: `/api/user/delete-requests?page=${pagination.current}&size=${pagination.size}` })
    const list = data?.records || data?.list || data || []
    tableData.value = list
    pagination.total = data?.total || list.length
    stats.pending = list.filter((r: any) => r.status === 'pending').length
    stats.approved = list.filter((r: any) => r.status === 'approved').length
    stats.rejected = list.filter((r: any) => r.status === 'rejected').length
  } catch {}
  loading.value = false
}

const goPage = (p: number) => { pagination.current = p; fetchData() }

const handleApprove = async (id: number) => {
  if (!confirm('确定通过该注销申请？')) return
  try {
    await request.post({ url: `/api/user/delete-request/${id}/review`, data: { status: 'approved' } })
    showToast('已通过注销申请')
    fetchData()
  } catch { showToast('操作失败', 'error') }
}

const rejectVisible = ref(false)
const rejectTargetId = ref(0)
const rejectReason = ref('')

const showRejectDialog = (id: number) => {
  rejectTargetId.value = id
  rejectReason.value = ''
  rejectVisible.value = true
}

const handleReject = async () => {
  try {
    await request.post({ url: `/api/user/delete-request/${rejectTargetId.value}/review`, data: { status: 'rejected', admin_note: rejectReason.value || '' } })
    showToast('已拒绝注销申请')
    rejectVisible.value = false
    fetchData()
  } catch { showToast('操作失败', 'error') }
}

onMounted(() => fetchData())
</script>
