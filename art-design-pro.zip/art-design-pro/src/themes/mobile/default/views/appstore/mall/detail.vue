<template>
  <div class="page">
    <main class="main" v-if="product">
      <div class="back-btn" @click="$router.back()">
        <svg viewBox="0 0 24 24" fill="none"><path d="M15 19l-7-7 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </div>

      <!-- Hero Banner -->
      <div class="hero">
        <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="hero-img" />
        <div v-else class="hero-img hero-fb">
          <div class="hero-fb-icon">
            <svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="2"/><path d="M16 24l5 5 11-10" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </div>
          <div class="hero-fb-text">{{ product.name }}</div>
        </div>
      </div>

      <!-- 促销+价格区块 -->
      <div class="promo-block">
        <div class="green-banner">
          <svg class="green-banner-icon" viewBox="0 0 20 20" fill="none"><path d="M10 2l2.5 5 5.5.8-4 3.9.9 5.5L10 14.5l-4.9 2.7.9-5.5-4-3.9 5.5-.8L10 2z" fill="#fff" opacity="0.8"/></svg>
          <span>全网比价 高效快充</span>
        </div>
        <div class="price-card">
          <div class="price-left">
            <div class="price-currency">R币</div>
            <div class="price-num">{{ displayPrice }}</div>
            <div class="price-orig-row">
              <span v-if="product.originalPrice > product.price" class="price-orig">原价 R币{{ product.originalPrice }}</span>
              <span class="price-sold">已售{{ product.salesCount || 0 }}</span>
            </div>
          </div>
          <div class="price-right">
            <div class="price-subsidy">官方补贴</div>
            <div class="price-countdown">
              <svg viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5" stroke="currentColor" stroke-width="1.2"/><path d="M6 3.5v2.5L7.5 7" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>
              <span>倒计时 {{ countdownStr }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 商品标签（对接 tags） -->
      <div class="tag-row" v-if="productTags.length">
        <span v-for="(t, i) in productTags" :key="i" class="tag-item">{{ t }}</span>
      </div>

      <!-- 商品标题 -->
      <div class="product-title">{{ product.name }} <span v-if="product.subtitle" class="product-subtitle">[{{ product.subtitle }}]</span></div>

      <!-- 服务保障标签（对接 services） -->
      <div class="feature-tags" v-if="productServices.length">
        <span v-for="(s, i) in productServices" :key="i" class="feature-tag">{{ s }}</span>
      </div>

      <!-- 服务保障卡片 -->
      <div class="service-card">
        <!-- 售后 -->
        <div class="service-row" v-if="afterSalesText">
          <svg class="service-icon" viewBox="0 0 24 24" fill="none"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span class="service-text">{{ afterSalesText }}</span>
        </div>
        <!-- 限购 -->
        <div class="service-row" v-if="purchaseLimitText">
          <svg class="service-icon" viewBox="0 0 24 24" fill="none"><rect x="1" y="3" width="15" height="13" rx="2" stroke="currentColor" stroke-width="1.8"/><polyline points="16 8 20 8 23 11 23 16 16 16" stroke="currentColor" stroke-width="1.8"/></svg>
          <span class="service-text">{{ purchaseLimitText }}</span>
        </div>
        <!-- 已选规格 -->
        <div class="service-row" @click="showPaySheet = true" v-if="groupedSpecs.length > 0">
          <svg class="service-icon" viewBox="0 0 24 24" fill="none"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" stroke="currentColor" stroke-width="1.8"/><line x1="3" y1="6" x2="21" y2="6" stroke="currentColor" stroke-width="1.8"/><path d="M16 10a4 4 0 01-8 0" stroke="currentColor" stroke-width="1.8"/></svg>
          <span class="service-text">已选：【{{ currentOptionName }}】</span>
          <svg class="service-arrow" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2"/></svg>
        </div>
      </div>

      <!-- 商品参数（对接 productParams） -->
      <div class="info-section" v-if="productParams.length">
        <div class="section-header">
          <span class="section-dot"></span>
          <span class="section-title">商品参数</span>
        </div>
        <div class="param-list">
          <div v-for="(p, i) in productParams" :key="i" class="param-row">
            <span class="param-label">{{ p.name }}</span>
            <span class="param-value">{{ p.value }}</span>
          </div>
        </div>
      </div>

      <!-- 评价区域 -->
      <div class="review-section">
        <div class="review-header" @click="$router.push('/appstore/mall-reviews/' + product.id)">
          <div class="review-header-left">
            <div class="review-score-big">{{ avgRating }}</div>
            <div class="review-score-label-sm">{{ ratingLabel }}</div>
          </div>
          <div class="review-header-center">
            <div class="review-header-title">商品评价（{{ reviewTotal }}）</div>
            <div class="review-stars-row">
              <svg v-for="s in 5" :key="s" class="review-star-sm" :class="{ on: s <= (parseFloat(avgRating) || 0) }" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
            </div>
          </div>
          <svg class="review-header-arrow" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2"/></svg>
        </div>

        <!-- 评论列表 -->
        <div class="review-list-inline" v-if="reviews.length > 0">
          <div v-for="review in reviews" :key="review.id" class="ri-card">
            <div class="ri-user-row">
              <div class="ri-avatar-wrap">
                <img v-if="review.userAvatar && !isBuiltinAvatar(review.userAvatar)" :src="fixImgUrl(review.userAvatar)" class="ri-avatar-img" />
                <div v-else class="ri-avatar-placeholder" :style="{ background: avatarColor(review.userName || '?') }">
                  <span>{{ (review.userName || '?')[0] }}</span>
                </div>
              </div>
              <div class="ri-user-info">
                <div class="ri-user-name-row">
                  <span class="ri-user-name">{{ review.userName || '匿名用户' }}</span>
                  <span class="ri-badge-level">Lv.{{ review.userExpLevel || 1 }}</span>
                  <span class="ri-badge-member" v-if="review.userMemberLevel">{{ review.userMemberLevel }}</span>
                  <span class="ri-badge-title" v-if="review.userTitleName">{{ review.userTitleName }}</span>
                </div>
                <div class="ri-stars-row">
                  <svg v-for="s in 5" :key="s" class="ri-star-sm" :class="{ on: s <= (review.rating || 0) }" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
                </div>
              </div>
              <div class="ri-like-btn" @click="toggleLike(review)">
                <svg viewBox="0 0 24 24" fill="none" :class="{ liked: reviewLikes[String(review.id)] }"><path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3m7-2V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span>{{ review.likeCount || 0 }}</span>
              </div>
            </div>
            <div class="ri-content" v-if="review.content">{{ review.content }}</div>
            <div class="ri-images" v-if="review.images && review.images.length > 0">
              <img v-for="(img, idx) in review.images" :key="idx" :src="img" class="ri-image" />
            </div>
            <div class="ri-footer">
              <span class="ri-time">{{ relativeTime(review.createTime) }}</span>
            </div>
          </div>
        </div>
        <div class="review-list-empty" v-else>
          <span class="ri-empty-text">暂无评价，快来第一个评价吧</span>
        </div>

        <div class="review-divider" />
        <div class="review-write-row">
          <div v-if="reviewWritePerm.canReview" class="review-write-btn" @click="showReviewEditor = true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            写评价
          </div>
          <div class="review-more" @click="$router.push('/appstore/mall-reviews/' + product.id)" v-if="reviewTotal > 3">
            查看全部 {{ reviewTotal }} 条评价 <svg viewBox="0 0 16 16" fill="none"><path d="M6 12l4-4-4-4" stroke="currentColor" stroke-width="1.5"/></svg>
          </div>
        </div>
      </div>

      <!-- 写评价弹出层 -->
      <div class="review-overlay" v-if="showReviewEditor" @click.self="showReviewEditor = false">
        <div class="review-editor">
          <div class="review-editor-header">
            <span class="review-editor-title">写评价</span>
            <svg class="review-editor-close" @click="showReviewEditor = false" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          </div>
          <div class="review-editor-body">
            <div class="review-editor-stars">
              <span class="review-editor-label">评分</span>
              <div class="review-editor-stars-row">
                <svg v-for="s in 5" :key="s" class="review-star-lg" :class="{ on: s <= reviewForm.rating }" @click="reviewForm.rating = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
              </div>
              <span class="review-star-text">{{ reviewForm.rating >= 5 ? '超赞' : reviewForm.rating >= 4 ? '很棒' : reviewForm.rating >= 3 ? '不错' : reviewForm.rating >= 2 ? '一般' : '很差' }}</span>
            </div>
            <div class="review-dim-stars">
              <div class="review-dim-row" v-for="dim in reviewDims" :key="dim.key">
                <span class="review-dim-label">{{ dim.label }}</span>
                <div class="review-dim-stars-row">
                  <svg v-for="s in 5" :key="s" class="review-dim-star" :class="{ on: s <= dim.model.value }" @click="dim.model.value = s" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/></svg>
                </div>
              </div>
            </div>
            <div class="review-editor-field">
              <textarea v-model="reviewForm.content" class="review-editor-textarea" placeholder="分享你的使用感受吧..." maxlength="500" rows="4" />
              <span class="review-editor-count">{{ reviewForm.content.length }}/500</span>
            </div>
            <div class="review-editor-field">
              <span class="review-editor-label">图片 ({{ reviewForm.images.length }}/3)</span>
              <div class="review-editor-imgs">
                <div v-for="(img, idx) in reviewForm.images" :key="idx" class="review-editor-img-wrap">
                  <img :src="img" class="review-editor-img" />
                  <div class="review-editor-img-del" @click="reviewForm.images.splice(idx, 1)">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>
                  </div>
                </div>
                <div v-if="reviewForm.images.length < 3" class="review-editor-add" @click="triggerReviewUpload">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg>
                  <input ref="reviewImgInput" type="file" accept="image/*" style="display:none" @change="onReviewImgPicked" />
                </div>
              </div>
            </div>
          </div>
          <div class="review-editor-footer">
            <button class="review-editor-submit" @click="submitReview" :disabled="reviewSubmitting || reviewForm.rating === 0">
              {{ reviewSubmitting ? '提交中...' : '提交评价' }}
            </button>
          </div>
        </div>
      </div>

      <!-- 商品详情（放到评论下面） -->
      <div class="info-section" v-if="product.description">
        <div class="section-header">
          <span class="section-dot"></span>
          <span class="section-title">商品详情</span>
        </div>
        <div class="info-content" v-html="product.description" />
      </div>

      <div class="bottom-spacer" />
    </main>

    <div v-else-if="loading" class="loading">
      <div class="spinner" />
    </div>
    <div v-else class="empty">商品不存在或已下架</div>

    <!-- 底部栏 -->
    <footer class="footer" v-if="product">
      <div class="footer-left">
        <div class="footer-icon-btn" @click="goShop">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>店铺</span>
        </div>
        <div class="footer-icon-btn" @click="openChat">
          <svg viewBox="0 0 24 24" fill="none"><path d="M3 18v-6a9 9 0 0118 0v6" stroke="currentColor" stroke-width="1.8"/><path d="M21 19a2 2 0 01-2 2h-1a2 2 0 01-2-2v-3a2 2 0 012-2h3v5zM3 19a2 2 0 002 2h1a2 2 0 002-2v-3a2 2 0 00-2-2H3v5z" stroke="currentColor" stroke-width="1.8"/></svg>
          <span>客服</span>
        </div>
      </div>
      <div class="footer-right">
        <button class="footer-btn buy" :disabled="countdownExpired" @click="buyNow">{{ countdownExpired ? '已截止' : '立即购买' }}</button>
      </div>
    </footer>

    <!-- 购买弹窗 -->
    <div class="sheet-overlay" v-if="showPaySheet" @click.self="hidePaySheet">
      <div class="buy-sheet">
        <div class="sheet-tips">
          <div v-for="(tip, ti) in sheetTips" :key="ti" class="tip-item">
            <svg class="tip-icon" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#4CAF50" stroke-width="2"/><path d="M7 12l3 3 7-7" stroke="#4CAF50" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <span>{{ tip }}</span>
          </div>
          <svg class="tip-close" @click="hidePaySheet" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#999" stroke-width="2" stroke-linecap="round"/></svg>
        </div>

        <div class="sheet-divider" />

        <div class="sheet-product">
          <div class="sheet-product-img-wrap">
            <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="sheet-product-img" />
            <div v-else class="sheet-product-img sheet-product-fb">{{ product.name[0] }}</div>
            <div class="sheet-img-badge">全网比价 高效快充</div>
          </div>
          <div class="sheet-product-info">
            <div class="sheet-product-name">{{ product.name }}</div>
            <div class="sheet-product-price-row">
              <span class="sheet-price-label">R币</span>
              <span class="sheet-price-num">{{ displayPrice }}</span>
              <span v-if="product.originalPrice > product.price" class="sheet-price-save">省{{ product.originalPrice - product.price }}</span>
            </div>
            <div class="sheet-tag-row" v-if="productTags.length">
              <span v-for="(t, i) in productTags" :key="i" class="sheet-tag">{{ t }}</span>
            </div>
          </div>
        </div>

        <div class="sheet-section" v-if="groupedSpecs.length > 0">
          <div class="sheet-section-title">规格</div>
          <div class="sheet-spec-tabs">
            <span
              v-for="(spec, si) in groupedSpecs"
              :key="si"
              class="sheet-spec-tab"
              :class="{ active: selectedSpecIndex === si }"
              @click="selectedSpecIndex = si; selectedOptIndex = 0"
            >{{ spec.name }}</span>
          </div>
        </div>

        <div v-if="currentPackages.length" class="sheet-section">
          <div class="sheet-section-title">套餐</div>
          <div class="sheet-opt-grid">
            <div
              v-for="(opt, oi) in currentPackages"
              :key="oi"
              class="sheet-opt-item"
              :class="{ active: selectedOptIndex === oi }"
              @click="selectedOptIndex = oi"
            >
              <div class="sheet-opt-item-name">{{ opt.name || ('套餐' + (oi + 1)) }}</div>
              <div class="sheet-opt-item-price">R币{{ opt.price || 0 }}</div>
            </div>
          </div>
        </div>

        <div class="sheet-section">
          <div class="sheet-section-title">数量</div>
          <div class="qty-stepper">
            <button class="qty-btn" @click="qty > 1 && qty--" :class="{ disabled: qty <= 1 }">-</button>
            <span class="qty-val">{{ qty }}</span>
            <button class="qty-btn" @click="qty++">+</button>
          </div>
        </div>

        <div class="sheet-section" v-if="product.customFields && product.customFields.length > 0">
          <div class="sheet-section-title">填写信息</div>
          <div class="custom-fields">
            <div v-for="(field, fi) in product.customFields" :key="fi" class="custom-field-item">
              <div class="custom-field-label">
                {{ field.name || field.label || ('字段' + (fi + 1)) }}
                <span v-if="field.required !== false" class="custom-field-required">*</span>
              </div>
              <input
                v-if="(field.type || 'text') === 'text'"
                v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]"
                class="custom-field-input"
                :placeholder="field.placeholder || '请输入' + (field.name || field.label || '')"
              />
              <textarea
                v-else-if="(field.type || 'text') === 'textarea'"
                v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]"
                class="custom-field-textarea"
                :placeholder="field.placeholder || '请输入' + (field.name || field.label || '')"
                rows="3"
              />
              <select
                v-else-if="(field.type || 'text') === 'select'"
                v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]"
                class="custom-field-select"
              >
                <option value="">请选择</option>
                <option v-for="(opt, oi2) in (field.options || [])" :key="oi2" :value="typeof opt === 'string' ? opt : opt.value">
                  {{ typeof opt === 'string' ? opt : (opt.label || opt.value) }}
                </option>
              </select>
              <input
                v-else
                v-model="userCustomFieldValues[field.name || field.label || ('field_' + fi)]"
                class="custom-field-input"
                :placeholder="field.placeholder || '请输入' + (field.name || field.label || '')"
              />
            </div>
          </div>
        </div>

        <div class="sheet-btns">
          <button class="sheet-btn-submit" @click="confirmPayFromSheet" :disabled="paying">
            提交订单
          </button>
        </div>
      </div>
    </div>

    <!-- 确认订单支付弹窗 -->
    <div class="confirm-overlay" v-if="showConfirmSheet" @click.self="showConfirmSheet = false">
      <div class="confirm-sheet">
        <div class="confirm-header">
          <span class="confirm-title">确认订单</span>
          <svg class="confirm-close" @click="showConfirmSheet = false" viewBox="0 0 24 24" fill="none">
            <path d="M18 6L6 18M6 6l12 12" stroke="#999" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </div>

        <div class="confirm-body">
          <div class="confirm-section">
            <div class="confirm-section-title">商品信息</div>
            <div class="confirm-product">
              <img v-if="product.coverImage" :src="fixImgUrl(product.coverImage)" class="confirm-product-img" />
              <div v-else class="confirm-product-img confirm-product-fb">{{ product.name[0] }}</div>
              <div class="confirm-product-info">
                <div class="confirm-product-name">{{ product.name }}</div>
                <div v-if="confirmOptionName" class="confirm-product-opt">{{ confirmOptionName }}</div>
                <div class="confirm-product-price">R币{{ confirmPrice }} x {{ confirmQty }}</div>
              </div>
            </div>
          </div>

          <div class="confirm-section" v-if="confirmCustomFields && Object.keys(confirmCustomFields).length > 0">
            <div class="confirm-section-title">填写信息</div>
            <div class="confirm-field-list">
              <div v-for="(val, key) in confirmCustomFields" :key="key" class="confirm-field-row">
                <span class="confirm-field-key">{{ key }}</span>
                <span class="confirm-field-val">{{ val }}</span>
              </div>
            </div>
          </div>

          <div class="confirm-section">
            <div class="confirm-section-title">优惠券</div>
            <select v-model="selectedCouponIndex" class="confirm-coupon-select">
              <option :value="-1">不使用优惠券</option>
              <option v-for="(c, ci) in filteredCoupons" :key="ci" :value="ci">
                {{ c.name }} (-{{ Number(c.value || 0).toFixed(2) }})
              </option>
            </select>
          </div>

          <div class="confirm-section">
            <div class="confirm-section-title">支付方式</div>
            <div class="confirm-pay-methods">
              <div
                v-for="pm in confirmAvailablePayMethods"
                :key="pm.value"
                class="confirm-pay-item"
                :class="{ active: confirmPayMethod === pm.value }"
                @click="confirmPayMethod = pm.value"
              >{{ pm.label }}</div>
            </div>
          </div>

          <div class="confirm-section">
            <div class="confirm-price-breakdown">
              <div class="confirm-price-row">
                <span class="confirm-price-label">商品总价</span>
                <span class="confirm-price-val">{{ confirmPayUnit }}{{ confirmSubtotal.toFixed(2) }}</span>
              </div>
              <div class="confirm-price-row" v-if="confirmCoupon">
                <span class="confirm-price-label">优惠券抵扣</span>
                <span class="confirm-price-val discount">-{{ confirmPayUnit }}{{ Number(confirmCoupon.value || 0).toFixed(2) }}</span>
              </div>
              <div class="confirm-price-divider" />
              <div class="confirm-price-row total">
                <span class="confirm-price-label">合计</span>
                <span class="confirm-price-val total-val">{{ confirmPayUnit }}{{ confirmFinalAmount.toFixed(2) }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="confirm-footer">
          <button class="confirm-btn-submit" @click="doPayOrder" :disabled="paying">
            {{ paying ? '支付中...' : ('立即支付 ' + confirmPayUnit + confirmFinalAmount.toFixed(2)) }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, toRef } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const product = ref<any>(null)
const loading = ref(true)
const reviews = ref<any[]>([])
const reviewTotal = ref(0)
const reviewWritePerm = ref({ canReview: false, hasPurchased: false, hasReviewed: false, orderId: 0 })
const reviewLikes = reactive<Record<string, boolean>>({})
const showReviewEditor = ref(false)
const reviewSubmitting = ref(false)
const reviewImgInput = ref<HTMLInputElement | null>(null)
const reviewForm = reactive({ rating: 0, content: '', images: [] as string[], dimProduct: 5, dimService: 5, dimLogistics: 5 })
const reviewDims = [
  { key: 'dimProduct', label: '商品', model: toRef(reviewForm, 'dimProduct') },
  { key: 'dimService', label: '服务', model: toRef(reviewForm, 'dimService') },
  { key: 'dimLogistics', label: '物流', model: toRef(reviewForm, 'dimLogistics') }
]
const showPaySheet = ref(false)
const paying = ref(false)
const selectedSpecIndex = ref(0)
const selectedOptIndex = ref(0)
const qty = ref(1)
const payMethod = ref('balance')
const userCustomFieldValues = ref<Record<string, string>>({})
const confirmPayMethod = ref('balance')
const confirmCoupons = ref<any[]>([])
const selectedCouponIndex = ref(-1)
const showConfirmSheet = ref(false)
const countdownExpired = ref(false)
const countdownHasEnd = ref(false)
const countdownDays = ref(0)
const countdownHours = ref(0)
const countdownMinutes = ref(0)
const countdownSeconds = ref(0)

const countdownStr = computed(() => {
  if (countdownExpired.value) return '已截止'
  if (!countdownHasEnd.value) return '活动进行中'
  return `${countdownDays.value}天${String(countdownHours.value).padStart(2, '0')}小时${String(countdownMinutes.value).padStart(2, '0')}分${String(countdownSeconds.value).padStart(2, '0')}秒`
})

function updateCountdown() {
  if (!product.value?.saleEndTime) {
    countdownHasEnd.value = false
    countdownExpired.value = false
    return
  }
  countdownHasEnd.value = true
  const end = new Date(product.value.saleEndTime).getTime()
  const diff = end - Date.now()
  if (diff <= 0) {
    countdownExpired.value = true
    return
  }
  countdownExpired.value = false
  countdownDays.value = Math.floor(diff / 86400000)
  countdownHours.value = Math.floor((diff % 86400000) / 3600000)
  countdownMinutes.value = Math.floor((diff % 3600000) / 60000)
  countdownSeconds.value = Math.floor((diff % 60000) / 1000)
}

onMounted(async () => {
  updateCountdown()
  const timer = setInterval(() => {
    if (countdownHasEnd.value && !countdownExpired.value) updateCountdown()
  }, 1000)
  onUnmountedDirect(() => clearInterval(timer))
  await loadProduct()
  updateCountdown()
  await loadReviews()
  await loadCoupons()
})

onUnmountedDirect(() => {})

function onUnmountedDirect(fn: () => void) {
  if (typeof onUnmounted === 'function') {
    try { onUnmounted(fn) } catch {}
  }
}

const loadProduct = async () => {
  try {
    const id = route.params.id as string
    product.value = await request.get({ url: `/api/mall/products/${id}` })
  } finally {
    loading.value = false
  }
}

const groupedSpecs = computed(() => {
  const opts = product.value?.options || []
  const map = new Map<string, any[]>()
  opts.forEach((o: any) => {
    const key = o.specName || ''
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(o)
  })
  return Array.from(map.entries()).map(([name, packages]) => ({
    name: name || '默认规格',
    packages
  }))
})

const currentPackages = computed(() => {
  const spec = groupedSpecs.value[selectedSpecIndex.value]
  return spec?.packages || []
})

const selectedOption = computed(() => {
  return currentPackages.value[selectedOptIndex.value] || null
})

const displayPrice = computed(() => {
  const opt = selectedOption.value
  if (opt) return opt.price || 0
  return product.value?.price || 0
})

const currentOptionName = computed(() => {
  const opt = selectedOption.value
  if (opt) return opt.name || ('套餐' + (selectedOptIndex.value + 1))
  const spec = groupedSpecs.value[selectedSpecIndex.value]
  if (spec?.packages?.[0]) return spec.packages[0].name || '套餐1'
  return '默认'
})

const selectedOptionName = computed(() => {
  const opt = selectedOption.value
  if (opt) return opt.name || ('套餐' + (selectedOptIndex.value + 1))
  return ''
})

// 对接商品 tags 数据
const productTags = computed(() => {
  const tags = product.value?.tags || []
  return Array.isArray(tags) ? tags : []
})

// 对接服务保障 services 数据
const productServices = computed(() => {
  const services = product.value?.services || []
  return Array.isArray(services) ? services : []
})

// 对接售后服务 afterSalesConfig
const afterSalesText = computed(() => {
  const cfg = product.value?.afterSalesConfig
  if (!cfg) return ''
  const parts: string[] = []
  if (cfg.enableRefund) parts.push('支持退款')
  if (cfg.enableReturn) parts.push('支持退货')
  if (cfg.enablePrice) parts.push('支持保价')
  if (cfg.validDays && (cfg.enableRefund || cfg.enableReturn)) {
    parts.push(`售后有效期${cfg.validDays}天`)
  }
  return parts.join(' · ') || '不支持退款'
})

// 对接收购配置 purchaseLimitConfig
const purchaseLimitText = computed(() => {
  const limits = product.value?.purchaseLimitConfig || []
  if (!limits.length) return '不限购'
  const parts = limits.map((l: any) => {
    if (l.type === 'global') return `每用户限购${l.limit}件`
    if (l.type === 'membership') return `会员限购${l.limit}件`
    if (l.type === 'verified') return `认证用户限购${l.limit}件`
    return `限购${l.limit}件`
  })
  return parts.join('、')
})

// 对接商品参数 productParams
const productParams = computed(() => {
  const params = product.value?.productParams || []
  return Array.isArray(params) ? params : []
})

const avgRating = computed(() => {
  if (!reviews.value.length) return '0.0'
  const sum = reviews.value.reduce((s: number, r: any) => s + (r.rating || 0), 0)
  return (sum / reviews.value.length).toFixed(1)
})

const ratingLabel = computed(() => {
  const r = parseFloat(avgRating.value)
  if (r >= 4.5) return '很棒'
  if (r >= 3) return '不错'
  return '一般'
})

const loadReviews = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/reviews', params: { productId: product.value.id, pageSize: 3 } })
    reviews.value = res?.list || []
    reviewTotal.value = res?.total || res?.list?.length || 0
    for (const r of reviews.value) {
      reviewLikes[String(r.id)] = !!r.liked
    }
  } catch {}
  loadReviewPerm()
}

const loadReviewPerm = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/reviews/check', params: { productId: product.value.id } })
    reviewWritePerm.value = res || { canReview: false, hasPurchased: false, hasReviewed: false, orderId: 0 }
  } catch {}
}

const isBuiltinAvatar = (url: string) => !url || url.startsWith('avatar:')
const colorPool = ['#FF6B6B', '#FFA726', '#66BB6A', '#42A5F5', '#AB47BC', '#EF5350', '#26C6DA', '#7E57C2', '#EC407A', '#5C6BC0']
const avatarColor = (name: string) => colorPool[(name || '?').charCodeAt(0) % colorPool.length]

const relativeTime = (t: string) => {
  if (!t) return ''
  const diff = Date.now() - new Date(t).getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)
  const months = Math.floor(days / 30)
  if (months > 0) return `${months}个月前`
  if (days > 0) return `${days}天前`
  if (hours > 0) return `${hours}小时前`
  if (minutes > 0) return `${minutes}分钟前`
  return '刚刚'
}

const toggleLike = async (review: any) => {
  const key = String(review.id)
  const liked = !!reviewLikes[key]
  const action = liked ? 'unlike' : 'like'
  try {
    const res: any = await request.put({ url: `/api/mall/reviews/${review.id}/like`, data: { action } })
    review.likeCount = res?.likeCount ?? review.likeCount
    reviewLikes[key] = res?.liked ?? !liked
  } catch {}
}

const triggerReviewUpload = () => {
  reviewImgInput.value?.click()
}

const onReviewImgPicked = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input?.files?.[0]
  if (!file) return
  const fd = new FormData()
  fd.append('file', file)
  try {
    const res: any = await request.post({ url: '/api/upload/file', data: fd })
    const url = res?.url || res?.data?.url || res?.data || ''
    if (url) reviewForm.images.push(url)
  } catch {}
  input.value = ''
}

const submitReview = async () => {
  if (!reviewForm.rating || reviewSubmitting.value) return
  reviewSubmitting.value = true
  try {
    await request.post({
      url: '/api/mall/reviews',
      data: {
        productId: product.value.id,
        rating: reviewForm.rating,
        content: reviewForm.content,
        images: reviewForm.images,
        orderId: reviewWritePerm.value.orderId,
        dimProductRating: reviewForm.dimProduct,
        dimServiceRating: reviewForm.dimService,
        dimLogisticsRating: reviewForm.dimLogistics
      }
    })
    showReviewEditor.value = false
    reviewForm.rating = 0
    reviewForm.content = ''
    reviewForm.images = []
    loadReviews()
  } catch {} finally { reviewSubmitting.value = false }
}

const previewReviewImage = (images: string[], idx: number) => {
  // TODO: image preview lightbox
}

const goCart = () => {}
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const openChat = () => {
  const uid = product.value?.createdBy
  if (uid) {
    router.push(`/chat/${uid}`)
  } else {
    ElMessage.warning('暂无卖家信息')
  }
}
const goShop = () => {
  const uid = product.value?.createdBy
  if (uid) {
    router.push(`/appstore/profile/${uid}`)
  } else {
    ElMessage.warning('暂无店铺信息')
  }
}
const toggleTheme = () => { ElMessage.info('主题切换功能开发中') }
const scrollToCoupon = () => { ElMessage.info('优惠券中心开发中') }

const confirmOptionName = computed(() => {
  const opt = selectedOption.value
  return opt?.specName ? (opt.specName + ' / ' + opt.name) : (opt?.name || '')
})

const confirmPrice = computed(() => {
  const opt = selectedOption.value
  if (!opt) return product.value?.price || 0
  if (confirmPayMethod.value === 'points' && opt.pointsPrice) return opt.pointsPrice
  if (confirmPayMethod.value === 'points' && product.value?.pointsPrice) return product.value.pointsPrice
  return opt.price || 0
})

const confirmQty = computed(() => qty.value)

const confirmCustomFields = computed(() => userCustomFieldValues.value || {})

const confirmAvailablePayMethods = computed(() => {
  const pms = product.value?.paymentMethods || ['balance']
  const methodLabels: Record<string, string> = {
    balance: '余额支付',
    points: '积分支付',
    alipay: '支付宝',
    wechat: '微信支付',
    epay: '易支付'
  }
  return pms
    .filter((v: string) => methodLabels[v])
    .map((v: string) => ({ value: v, label: methodLabels[v] }))
})

const confirmSubtotal = computed(() => confirmPrice.value * confirmQty.value)

const confirmCoupon = computed(() => {
  const idx = selectedCouponIndex.value
  if (idx >= 0 && idx < filteredCoupons.value.length) return filteredCoupons.value[idx]
  return null
})

const confirmDiscount = computed(() => confirmCoupon.value ? Number(confirmCoupon.value.value || 0) : 0)

const confirmFinalAmount = computed(() => Math.max(0, confirmSubtotal.value - confirmDiscount.value))

const confirmPayUnit = computed(() => confirmPayMethod.value === 'points' ? '积分' : 'R币')

const filteredCoupons = computed(() => {
  const subtotal = confirmSubtotal.value
  return confirmCoupons.value.filter((c: any) => {
    const type = (c.type || '').toLowerCase()
    const scope = (c.scope || '').toLowerCase()
    const minOrder = Number(c.minOrder || 0)
    const isPointsType = type.includes('points')
    if (confirmPayMethod.value === 'points') {
      if (!isPointsType) return false
    } else {
      if (isPointsType) return false
    }
    if (scope && scope !== 'all' && scope !== 'mall' && !isPointsType) return false
    if (minOrder > subtotal) return false
    return true
  })
})

const loadCoupons = async () => {
  try {
    const res: any = await request.get({ url: '/api/coupon/my', params: { status: 'unused' } })
    confirmCoupons.value = res || []
    selectedCouponIndex.value = -1
  } catch {
    confirmCoupons.value = []
    selectedCouponIndex.value = -1
  }
}

const buyNow = () => {
  if (!userStore.getUserInfo.userId) {
    ElMessage.warning('请先登录')
    return
  }
  if (!product.value.options || product.value.options.length === 0) {
    ElMessage.warning('该商品暂无套餐可选')
    return
  }
  if (groupedSpecs.value.length > 0 && selectedOptIndex.value < 0) {
    selectedSpecIndex.value = 0
    selectedOptIndex.value = 0
  }
  qty.value = 1
  userCustomFieldValues.value = {}
  confirmPayMethod.value = (product.value.paymentMethods || ['balance'])[0] || 'balance'
  loadCoupons()
  showPaySheet.value = true
}

const confirmPayFromSheet = () => {
  const opt = selectedOption.value
  if (!opt) {
    ElMessage.warning('请选择套餐')
    return
  }
  const pms = product.value.paymentMethods || ['balance']
  if (!pms.length) {
    ElMessage.warning('该商品未配置支付方式，无法支付')
    return
  }

  const customFields = product.value.customFields || []
  for (const field of customFields) {
    if (field.required !== false) {
      const key = field.name || field.label || ''
      if (!userCustomFieldValues.value[key]) {
        ElMessage.warning('请填写' + key)
        return
      }
    }
  }

  showPaySheet.value = false
  showConfirmSheet.value = true
}

const doPayOrder = async () => {
  const opt = selectedOption.value
  if (!opt) return
  if (!['balance', 'points'].includes(confirmPayMethod.value)) {
    ElMessage.warning('当前仅支持余额支付和积分支付，请切换支付方式')
    return
  }
  paying.value = true
  try {
    const optionId = opt.id || 0
    const payRes: any = await request.post({
      url: '/api/mall/orders',
      data: {
        productId: product.value.id,
        optionId,
        quantity: qty.value,
        paymentMethod: confirmPayMethod.value,
        userCustomFields: { ...userCustomFieldValues.value },
        userCouponId: confirmCoupon.value?.id || undefined
      }
    })

    ElMessage.success(payRes?.productType?.startsWith('virtual') ? '购买成功！' : '支付成功！')
    showConfirmSheet.value = false

    if (payRes?.productType?.startsWith('virtual') && payRes?.deliveryInfo) {
      ElMessageBox.alert(payRes.deliveryInfo, '发货内容', {
        confirmButtonText: '我知道了',
        dangerouslyUseHTMLString: false
      })
    }

    try {
      const userInfo: any = await request.get({ url: '/api/user/info' })
      if (userInfo) userStore.setUserInfo(userInfo)
    } catch {}

    product.value.salesCount = (product.value.salesCount || 0) + qty.value
    qty.value = 1
  } catch (e: any) {
    ElMessage.error(e?.message || '支付失败，请重试')
  } finally {
    paying.value = false
  }
}

const hidePaySheet = () => {
  if (!paying.value) showPaySheet.value = false
}
</script>

<style scoped>
.page { height: 100vh; display: flex; flex-direction: column; background: #f5f5f5; }
.main { flex: 1; overflow-y: auto; }
.loading { display: flex; justify-content: center; align-items: center; height: 60vh; }
.spinner { width: 28px; height: 28px; border: 2px solid #e0e0e0; border-top-color: #00bfa5; border-radius: 50%; animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.empty { text-align: center; padding: 80px 0; font-size: 14px; color: #bbb; }

/* ===== 返回按钮 ===== */
.back-btn {
  position: fixed; top: 12px; left: 12px; z-index: 50;
  width: 32px; height: 32px; border-radius: 50%;
  background: rgba(0,0,0,.35); color: #fff;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; backdrop-filter: blur(8px);
}
.back-btn svg { width: 18px; height: 18px; }

/* ===== Hero Banner ===== */
.hero {
  position: relative; width: 100%; height: 280px;
  background: linear-gradient(160deg, #1a1a2e, #16213e, #0f3460, #1a1a2e);
  overflow: hidden;
}
.hero::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse at 30% 20%, rgba(0,255,200,0.15) 0%, transparent 60%),
              radial-gradient(ellipse at 70% 60%, rgba(100,100,255,0.1) 0%, transparent 50%);
}
.hero-img { width: 100%; height: 100%; object-fit: cover; }
.hero-fb {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 12px; color: rgba(255,255,255,.5);
}
.hero-fb-icon { width: 60px; height: 60px; }
.hero-fb-icon svg { width: 100%; height: 100%; }
.hero-fb-text { font-size: 20px; font-weight: 800; letter-spacing: 2px; }

/* ===== 促销+价格区块 ===== */
.promo-block {
  margin: 0 12px; border-radius: 16px; overflow: hidden;
}
.green-banner {
  height: 32px; display: flex; align-items: center; justify-content: center;
  gap: 6px; background: linear-gradient(90deg, #4caf50, #66bb6a);
  font-size: 12px; font-weight: 700; color: #fff; letter-spacing: 1px;
}
.green-banner-icon { width: 16px; height: 16px; }
.price-card {
  padding: 18px 18px; display: flex; align-items: center; justify-content: space-between;
  background: linear-gradient(135deg, #00bfa5, #009688);
}
.price-left { position: relative; z-index: 1; }
.price-currency { font-size: 13px; color: rgba(255,255,255,.8); margin-bottom: 2px; }
.price-num { font-size: 42px; font-weight: 900; color: #fff; line-height: 1; }
.price-orig-row { display: flex; gap: 10px; margin-top: 4px; }
.price-orig { font-size: 12px; color: rgba(255,255,255,.55); text-decoration: line-through; }
.price-sold { font-size: 12px; color: rgba(255,255,255,.6); }

.price-right { text-align: right; position: relative; z-index: 1; }
.price-subsidy { font-size: 18px; font-weight: 800; color: #fff; letter-spacing: 2px; }
.price-countdown {
  display: flex; align-items: center; gap: 4px; margin-top: 6px;
  font-size: 11px; color: rgba(255,255,255,.7); justify-content: flex-end;
}
.price-countdown svg { width: 12px; height: 12px; }

/* ===== 右侧悬浮按钮 ===== */
.float-btns {
  position: fixed; right: 12px; top: 50%; transform: translateY(-50%);
  z-index: 40; display: flex; flex-direction: column; gap: 10px;
}
.float-btn {
  width: 40px; height: 40px; border-radius: 12px;
  background: rgba(255,255,255,.75); backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center; cursor: pointer;
  box-shadow: 0 2px 8px rgba(0,0,0,.08); transition: all .2s;
}
.float-btn svg { width: 20px; height: 20px; color: #555; }
.float-btn:active { transform: scale(.92); }

/* ===== 商品标签行 ===== */
.tag-row {
  display: flex; gap: 8px; padding: 14px 16px 0; flex-wrap: wrap;
}
.tag-item {
  padding: 3px 10px; border-radius: 12px;
  font-size: 11px; font-weight: 600;
  color: #e91e63; border: 1px solid #f8bbd0; background: #fce4ec;
}

/* ===== 商品标题 ===== */
.product-title {
  padding: 10px 16px 6px; font-size: 18px; font-weight: 800; color: #1a1a1a; line-height: 1.4;
}
.product-subtitle { font-size: 12px; color: #999; font-weight: 400; margin-left: 4px; }

/* ===== 服务保障标签 ===== */
.feature-tags {
  display: flex; gap: 6px; padding: 0 16px 14px; flex-wrap: wrap;
}
.feature-tag {
  padding: 3px 10px; border-radius: 10px;
  font-size: 11px; color: #888; background: #f0f0f0;
}

/* ===== 服务保障卡片 ===== */
.service-card {
  margin: 0 12px 12px; background: #fff; border-radius: 14px; overflow: hidden;
}
.service-row {
  display: flex; align-items: center; gap: 10px; padding: 13px 16px;
  border-bottom: 1px solid #f5f5f5;
}
.service-row:last-child { border-bottom: none; }
.service-row[clickable] { cursor: pointer; }
.service-icon { width: 20px; height: 20px; color: #00bfa5; flex-shrink: 0; }
.service-text { flex: 1; font-size: 13px; color: #444; min-width: 0; }
.service-arrow { width: 16px; height: 16px; color: #ccc; flex-shrink: 0; }

/* ===== Section 通用 ===== */
.section-header {
  display: flex; align-items: center; gap: 8px;
  padding: 0 0 14px;
}
.section-dot {
  width: 4px; height: 16px; border-radius: 2px;
  background: linear-gradient(180deg, #00bfa5, #009688);
}
.section-title { font-size: 16px; font-weight: 700; color: #1a1a1a; }
.section-badge {
  font-size: 12px; color: #00bfa5; background: #e0f2f1;
  padding: 2px 8px; border-radius: 10px; font-weight: 600; margin-left: 8px;
}

/* ===== 商品参数 ===== */
.info-section, .review-section {
  background: #fff; margin: 12px; border-radius: 16px; padding: 18px;
}
.param-list { display: flex; flex-direction: column; }
.param-row {
  display: flex; justify-content: space-between; align-items: center;
  padding: 8px 0; border-bottom: 1px solid #f8f8f8;
}
.param-row:last-child { border-bottom: none; }
.param-label { font-size: 13px; color: #888; }
.param-value { font-size: 13px; color: #333; font-weight: 500; }

/* ===== 评价区域（统一卡片） ===== */
.review-header {
  display: flex; align-items: center; gap: 12px; cursor: pointer; padding-bottom: 14px;
}
.review-header-left {
  display: flex; flex-direction: column; align-items: center; min-width: 50px;
}
.review-score-big {
  font-size: 32px; font-weight: 800; color: #FF6B6B; line-height: 1;
}
.review-score-label-sm {
  font-size: 11px; color: #FF6B6B; font-weight: 600; margin-top: 2px;
}
.review-header-center { flex: 1; min-width: 0; }
.review-header-title { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 6px; }
.review-stars-row { display: flex; gap: 2px; }
.review-star-sm { width: 14px; height: 14px; color: #eee; }
.review-star-sm.on { color: #FF9500; }
.review-header-arrow { width: 18px; height: 18px; color: #ccc; flex-shrink: 0; }

.review-list-inline { }
.ri-card {
  padding: 12px 0; border-top: 1px solid #f5f5f5;
}
.ri-user-row { display: flex; align-items: flex-start; gap: 10px; }
.ri-avatar-wrap { flex-shrink: 0; }
.ri-avatar-img {
  width: 34px; height: 34px; border-radius: 50%; object-fit: cover; background: #f0f0f0;
}
.ri-avatar-placeholder {
  width: 34px; height: 34px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 14px; font-weight: 600;
}
.ri-user-info { flex: 1; min-width: 0; }
.ri-user-name-row { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.ri-user-name { font-size: 13px; color: #333; font-weight: 500; }
.ri-badge-level { font-size: 10px; padding: 1px 5px; border-radius: 3px; color: #FF69B4; background: #FFF0F5; }
.ri-badge-member { font-size: 10px; padding: 1px 5px; border-radius: 3px; color: #FFB800; background: #FFF8E1; }
.ri-badge-title { font-size: 10px; padding: 1px 5px; border-radius: 3px; color: #8B5CF6; background: #F3F0FF; }
.ri-stars-row { display: flex; gap: 1px; margin-top: 2px; }
.ri-star-sm { width: 12px; height: 12px; color: #e8e8e8; }
.ri-star-sm.on { color: #FF69B4; }
.ri-like-btn {
  display: flex; flex-direction: column; align-items: center; gap: 2px;
  cursor: pointer; flex-shrink: 0; padding: 2px 4px;
}
.ri-like-btn svg { width: 16px; height: 16px; color: #ccc; }
.ri-like-btn svg.liked { color: #FF69B4; }
.ri-like-btn span { font-size: 10px; color: #999; }
.ri-content {
  margin-top: 6px; margin-left: 44px; font-size: 13px; color: #333; line-height: 1.5; word-break: break-word;
}
.ri-images {
  display: flex; gap: 6px; margin-top: 6px; margin-left: 44px; flex-wrap: wrap;
}
.ri-image {
  width: 72px; height: 72px; border-radius: 6px; object-fit: cover; cursor: pointer; background: #f5f5f5;
}
.ri-footer { display: flex; margin-top: 4px; margin-left: 44px; }
.ri-time { font-size: 11px; color: #bbb; }

.review-list-empty { padding: 14px 0; text-align: center; border-top: 1px solid #f5f5f5; }
.ri-empty-text { font-size: 13px; color: #bbb; }

.review-divider { height: 1px; background: #f5f5f5; margin: 0; }
.review-write-row {
  display: flex; align-items: center; justify-content: space-between; padding-top: 12px;
}
.review-write-btn {
  display: flex; align-items: center; gap: 4px;
  padding: 6px 14px; border: 1px solid #ff6b6b;
  border-radius: 20px; font-size: 12px; color: #ff6b6b; cursor: pointer;
  transition: background .15s;
}
.review-write-btn:active { background: #fff0f0; }
.review-write-btn svg { width: 14px; height: 14px; }
.review-more {
  display: flex; align-items: center; gap: 2px; font-size: 12px; color: #999; cursor: pointer;
}
.review-more svg { width: 14px; height: 14px; }

/* 写评价弹出层 */
.review-overlay {
  position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,.5);
  display: flex; align-items: flex-end; justify-content: center;
}
.review-editor {
  width: 100%; max-width: 480px; background: #fff;
  border-radius: 16px 16px 0 0; max-height: 85vh; overflow-y: auto;
  display: flex; flex-direction: column;
}
.review-editor-header {
  display: flex; align-items: center; justify-content: center;
  padding: 14px 16px; border-bottom: 1px solid #f0f0f0; position: relative;
}
.review-editor-title { font-size: 16px; font-weight: 700; color: #222; }
.review-editor-close {
  position: absolute; right: 16px; width: 20px; height: 20px;
  color: #999; cursor: pointer;
}
.review-editor-body { padding: 16px; display: flex; flex-direction: column; gap: 18px; }
.review-editor-stars { display: flex; align-items: center; gap: 10px; }
.review-editor-label { font-size: 13px; color: #666; flex-shrink: 0; }
.review-editor-stars-row { display: flex; gap: 5px; }
.review-star-lg { width: 30px; height: 30px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-star-lg.on { color: #FF9500; }
.review-star-lg:active { transform: scale(1.2); }
.review-star-text { font-size: 13px; color: #FF9500; font-weight: 500; }
.review-dim-stars { margin-top: 8px; }
.review-dim-row { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
.review-dim-label { font-size: 12px; color: #999; width: 28px; flex-shrink: 0; }
.review-dim-stars-row { display: flex; gap: 3px; }
.review-dim-star { width: 20px; height: 20px; color: #eee; cursor: pointer; transition: transform .12s; }
.review-dim-star.on { color: #FF9500; }
.review-dim-star:active { transform: scale(1.1); }
.review-editor-field { position: relative; }
.review-editor-textarea {
  width: 100%; border: 1px solid #eee; border-radius: 8px; padding: 10px 12px 28px;
  font-size: 13px; color: #333; outline: none; resize: none; line-height: 1.5;
  box-sizing: border-box; font-family: inherit;
}
.review-editor-textarea:focus { border-color: #ffcdd2; }
.review-editor-count {
  position: absolute; right: 10px; bottom: 8px;
  font-size: 11px; color: #ccc;
}
.review-editor-imgs { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px; }
.review-editor-img-wrap {
  width: 68px; height: 68px; border-radius: 6px; overflow: hidden; position: relative;
}
.review-editor-img { width: 100%; height: 100%; object-fit: cover; }
.review-editor-img-del {
  position: absolute; top: 0; right: 0;
  width: 20px; height: 20px; background: rgba(0,0,0,.5);
  border-radius: 0 6px 0 6px; display: flex; align-items: center;
  justify-content: center; cursor: pointer;
}
.review-editor-img-del svg { width: 12px; height: 12px; }
.review-editor-add {
  width: 68px; height: 68px; border: 1px dashed #ddd; border-radius: 6px;
  display: flex; align-items: center; justify-content: center; cursor: pointer;
  color: #ccc; transition: all .15s;
}
.review-editor-add:active { border-color: #ff6b6b; color: #ff6b6b; }
.review-editor-add svg { width: 24px; height: 24px; }
.review-editor-footer { padding: 0 16px 24px; }
.review-editor-submit {
  width: 100%; height: 44px; border: none; border-radius: 22px;
  background: linear-gradient(135deg, #FF6B6B, #FF8E53);
  color: #fff; font-size: 15px; font-weight: 700; cursor: pointer;
  transition: opacity .15s;
}
.review-editor-submit:disabled { opacity: .5; cursor: not-allowed; }

/* ===== 商品详情 ===== */
.info-content { font-size: 14px; color: #555; line-height: 1.8; }
.info-content :deep(img) { max-width: 100%; border-radius: 8px; margin: 8px 0; }

.bottom-spacer { height: 80px; }

/* ===== 底部栏 ===== */
.footer {
  display: flex; align-items: center; height: 56px; padding: 0 12px;
  background: #fff; border-top: 1px solid #f0f0f0; flex-shrink: 0;
}
.footer-left { display: flex; gap: 4px; }
.footer-icon-btn {
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  padding: 2px 8px; cursor: pointer;
}
.footer-icon-btn svg { width: 22px; height: 22px; color: #777; }
.footer-icon-btn span { font-size: 10px; color: #aaa; }
.footer-right { margin-left: auto; }
.footer-btn {
  height: 40px; border-radius: 20px; padding: 0 32px;
  font-size: 15px; font-weight: 700; border: none; cursor: pointer;
  background: linear-gradient(135deg, #ff5252, #ff1744);
  color: #fff;
}
.footer-btn:active { opacity: .85; }
.footer-btn:disabled { background: #ccc; cursor: not-allowed; opacity: .7; }

/* ====== 弹窗 ====== */
.sheet-overlay {
  position: fixed; inset: 0; z-index: 1000;
  background: rgba(0,0,0,.55);
  display: flex; align-items: flex-end;
  animation: fadeIn .2s ease;
}
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.buy-sheet {
  width: 100%; background: #fff; border-radius: 20px 20px 0 0;
  padding: 0 16px 32px; animation: slideUp .3s ease;
  max-height: 85vh; overflow-y: auto;
}
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }

.sheet-tips {
  display: flex; flex-wrap: wrap; gap: 8px;
  padding: 16px 0; position: relative;
}
.tip-item { display: flex; align-items: center; gap: 4px; font-size: 12px; color: #4CAF50; }
.tip-icon { width: 16px; height: 16px; }
.tip-close {
  position: absolute; right: 0; top: 14px;
  width: 24px; height: 24px; cursor: pointer;
}
.sheet-divider { height: 1px; background: #f0f0f0; margin-bottom: 14px; }

.sheet-product { display: flex; gap: 12px; align-items: flex-start; margin-bottom: 16px; }
.sheet-product-img-wrap {
  position: relative; width: 100px; height: 100px;
  border-radius: 10px; overflow: hidden; flex-shrink: 0;
}
.sheet-product-img { width: 100%; height: 100%; object-fit: cover; }
.sheet-product-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #00bfa5, #009688);
  color: #fff; font-size: 32px; font-weight: 800;
}
.sheet-img-badge {
  position: absolute; bottom: 0; left: 0; right: 0;
  background: linear-gradient(90deg, #a5d6a7, #81c784);
  font-size: 10px; color: #2E7D32; text-align: center;
  padding: 3px 0; font-weight: 700;
}
.sheet-product-info { flex: 1; min-width: 0; }
.sheet-product-name { font-size: 15px; font-weight: 700; color: #111; line-height: 1.4; }
.sheet-product-price-row { display: flex; align-items: baseline; gap: 6px; margin-top: 6px; }
.sheet-price-label { font-size: 13px; color: #FF6B6B; }
.sheet-price-num { font-size: 26px; font-weight: 900; color: #FF4757; line-height: 1; }
.sheet-price-save {
  font-size: 11px; color: #FF8A65; background: #FFF3E0;
  padding: 1px 6px; border-radius: 4px;
}
.sheet-tag-row { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.sheet-tag {
  font-size: 10px; color: #FF6B6B; padding: 1px 6px;
  border: 1px solid #FFCDD2; border-radius: 6px; background: #FFF5F5;
}

.sheet-section { margin-top: 14px; }
.sheet-section-title { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 10px; }

.sheet-spec-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.sheet-spec-tab {
  padding: 6px 16px; border-radius: 20px;
  font-size: 13px; font-weight: 600; color: #666;
  background: #f5f5f5; cursor: pointer; transition: all .2s;
}
.sheet-spec-tab.active {
  background: linear-gradient(135deg, #00bfa5, #009688);
  color: #fff;
}

.sheet-opt-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.sheet-opt-item {
  padding: 8px 16px; border-radius: 8px; border: 1.5px solid #e0e0e0;
  font-size: 13px; color: #666; cursor: pointer; transition: all .2s;
  background: #fff; display: flex; flex-direction: column; gap: 2px;
}
.sheet-opt-item.active {
  border-color: #00bfa5; background: #e0f2f1; color: #009688; font-weight: 600;
}
.sheet-opt-item-name { font-size: 13px; font-weight: 600; }
.sheet-opt-item-price { font-size: 11px; color: #FF6B6B; }

.qty-stepper {
  display: inline-flex; align-items: center; border: 1px solid #e0e0e0;
  border-radius: 8px; overflow: hidden;
}
.qty-btn {
  width: 40px; height: 36px; border: none; background: #f9f9f9;
  font-size: 18px; color: #333; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.qty-btn.disabled { color: #ccc; cursor: not-allowed; }
.qty-val { width: 48px; text-align: center; font-size: 15px; font-weight: 600; color: #333; }

.sheet-btns { margin-top: 20px; }
.sheet-btn-submit {
  width: 100%; height: 48px; border: none; border-radius: 24px;
  background: linear-gradient(135deg, #FF5252, #FF1744);
  color: #fff; font-size: 16px; font-weight: 700; cursor: pointer;
}
.sheet-btn-submit:active { opacity: .85; }

/* ====== 自定义字段 ====== */
.custom-fields { display: flex; flex-direction: column; gap: 12px; }
.custom-field-item { display: flex; flex-direction: column; gap: 4px; }
.custom-field-label {
  font-size: 13px; font-weight: 600; color: #555;
  display: flex; align-items: center; gap: 4px;
}
.custom-field-required { color: #FF4757; font-size: 14px; }
.custom-field-input {
  height: 40px; padding: 0 12px; border: 1.5px solid #e0e0e0;
  border-radius: 8px; font-size: 14px; color: #333;
  outline: none; transition: border-color .2s; background: #fafafa;
}
.custom-field-input:focus { border-color: #00bfa5; background: #fff; }
.custom-field-textarea {
  padding: 10px 12px; border: 1.5px solid #e0e0e0;
  border-radius: 8px; font-size: 14px; color: #333;
  outline: none; resize: none; background: #fafafa;
  transition: border-color .2s;
}
.custom-field-textarea:focus { border-color: #00bfa5; background: #fff; }
.custom-field-select {
  height: 40px; padding: 0 12px; border: 1.5px solid #e0e0e0;
  border-radius: 8px; font-size: 14px; color: #333;
  outline: none; background: #fafafa;
}

/* ====== 确认订单弹窗 ====== */
.confirm-overlay {
  position: fixed; inset: 0; z-index: 1001;
  background: rgba(0,0,0,.55);
  display: flex; align-items: flex-end;
  animation: fadeIn .2s ease;
}
.confirm-sheet {
  width: 100%; background: #fff; border-radius: 20px 20px 0 0;
  max-height: 85vh; display: flex; flex-direction: column;
  animation: slideUp .3s ease;
}
.confirm-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 18px 20px 14px; border-bottom: 1px solid #f0f0f0;
}
.confirm-title { font-size: 18px; font-weight: 700; color: #111; }
.confirm-close { width: 24px; height: 24px; cursor: pointer; }

.confirm-body { flex: 1; overflow-y: auto; padding: 0 20px; }
.confirm-section { padding: 16px 0; border-bottom: 1px solid #f5f5f5; }
.confirm-section:last-child { border-bottom: none; }
.confirm-section-title { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 12px; }

.confirm-product { display: flex; gap: 12px; align-items: center; }
.confirm-product-img {
  width: 64px; height: 64px; border-radius: 10px; object-fit: cover; flex-shrink: 0;
}
.confirm-product-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #00bfa5, #009688);
  color: #fff; font-size: 24px; font-weight: 800;
}
.confirm-product-info { flex: 1; min-width: 0; }
.confirm-product-name { font-size: 14px; font-weight: 600; color: #333; }
.confirm-product-opt { font-size: 12px; color: #999; margin-top: 2px; }
.confirm-product-price { font-size: 16px; font-weight: 700; color: #FF4757; margin-top: 4px; }

.confirm-field-list { background: #fafafa; border-radius: 10px; padding: 12px 14px; }
.confirm-field-row {
  display: flex; justify-content: space-between; align-items: flex-start;
  padding: 6px 0; gap: 12px;
}
.confirm-field-row + .confirm-field-row { border-top: 1px solid #f0f0f0; }
.confirm-field-key { font-size: 13px; color: #666; flex-shrink: 0; }
.confirm-field-val { font-size: 13px; color: #333; font-weight: 500; text-align: right; word-break: break-all; }

.confirm-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 0; cursor: pointer;
}
.confirm-label { font-size: 14px; color: #333; }
.confirm-value-row { display: flex; align-items: center; gap: 4px; }
.confirm-value { font-size: 13px; color: #999; }
.confirm-value.highlight { color: #FF6B6B; font-weight: 600; }
.confirm-arrow { width: 16px; height: 16px; }

.confirm-pay-methods { display: flex; flex-wrap: wrap; gap: 8px; }
.confirm-coupon-select {
  width: 100%; height: 44px; padding: 0 12px;
  border: 1.5px solid #e0e0e0; border-radius: 8px;
  font-size: 14px; color: #333; background: #fff;
  outline: none; appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M6 9l6 6 6-6' stroke='%23999' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat; background-position: right 12px center;
}
.confirm-pay-item {
  padding: 8px 20px; border-radius: 8px; border: 1.5px solid #e0e0e0;
  font-size: 13px; color: #666; cursor: pointer; transition: all .2s; background: #fff;
}
.confirm-pay-item.active {
  border-color: #00bfa5; background: #e0f2f1; color: #009688; font-weight: 600;
}

.confirm-price-breakdown { background: #fafafa; border-radius: 10px; padding: 14px; }
.confirm-price-row { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; }
.confirm-price-label { font-size: 13px; color: #777; }
.confirm-price-val { font-size: 13px; color: #333; font-weight: 500; }
.confirm-price-val.discount { color: #10b981; }
.confirm-price-divider { height: 1px; background: #e8e8e8; margin: 8px 0; }
.confirm-price-row.total .confirm-price-label { font-size: 15px; font-weight: 700; color: #111; }
.confirm-price-row.total .confirm-price-val.total-val { font-size: 18px; font-weight: 800; color: #FF4757; }

.confirm-footer { padding: 12px 20px 32px; }
.confirm-btn-submit {
  width: 100%; height: 48px; border: none; border-radius: 24px;
  background: linear-gradient(135deg, #FF5252, #FF1744);
  color: #fff; font-size: 16px; font-weight: 700; cursor: pointer;
}
.confirm-btn-submit:disabled { opacity: .5; cursor: not-allowed; }
.confirm-btn-submit:active { opacity: .85; }
</style>
