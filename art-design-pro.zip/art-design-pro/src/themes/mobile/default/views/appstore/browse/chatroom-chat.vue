<template>
    <div class="h-screen flex flex-col bg-[#EDEDED]">
    <!-- 顶部提示 -->
    <div v-if="toast" class="fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-5 py-2.5 rounded-full text-[14px] text-white shadow-lg transition-all duration-300" style="background: rgba(74,144,217,0.92)">{{ toast }}</div>
    <!-- 顶部导航栏 -->
    <div class="flex items-center gap-2.5 px-3 py-2 flex-shrink-0 sticky top-0 z-10 bg-white">
      <svg class="w-6 h-6 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="goBack">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <div class="flex-1 min-w-0" @click="loadMembers(); showMemberPanel = true">
        <span class="text-[15px] font-medium text-gray-800 truncate">{{ room.name || '聊天室' }} <span class="text-[12px] text-gray-500 font-normal">({{ memberCount }}人)</span></span>
      </div>
      <svg class="w-6 h-6 text-gray-600 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="showRoomInfo = true">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </div>

    <!-- 禁言通知条 -->
    <div v-if="isMember && !chatEnabled" class="px-4 py-1.5 text-center text-[11px] text-white bg-orange-400">全员禁言中,仅群主和管理员可发言</div>

    <!-- 消息列表 -->
    <div ref="msgListRef" class="flex-1 overflow-y-auto px-3 py-3 space-y-3">
      <div v-for="msg in messages" :key="msg.id">
        <div v-if="msg.messageType === 'system'" class="flex justify-center py-1">
          <span class="text-[10px] bg-black/10 text-gray-600 px-3 py-0.5 rounded-full">{{ msg.content }}</span>
        </div>
        <!-- 订单卡片消息 -->
        <div v-else-if="msg.messageType === 'order_card' && msg.orderCard" class="flex gap-2" :class="msg.fromUserId === myUserId ? 'flex-row-reverse' : ''">
          <img :src="resolveAvatar(msg.fromUserAvatar)" class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0 mt-1" @error="($event.target as any).style.display='none'" />
          <div class="w-[280px]">
            <div v-if="msg.fromUserId !== myUserId" class="text-[10px] text-gray-400 mb-1 ml-1" :style="{ color: memberColor(msg.fromUserId) }">{{ msg.fromUserName }}</div>
            <div class="rounded-2xl overflow-hidden shadow-sm cursor-pointer" @click="viewOrderDetail(msg.orderCard)">
              <div class="px-4 py-3" :class="orderCardBg(msg.orderCard.status)">
                <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-2">
                    <div class="w-[36px] h-[36px] rounded-full bg-white/30 flex items-center justify-center backdrop-blur-sm">
                      <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
                    </div>
                    <div>
                      <div class="text-white text-[13px] font-bold tracking-wide">{{ msg.orderCard.orderNo || '' }}</div>
                      <div class="text-white/70 text-[10px]">订单号</div>
                    </div>
                  </div>
                  <div class="text-right">
                    <div class="text-white text-lg font-bold">{{ msg.orderCard.payType === 'points' ? msg.orderCard.paidAmount : '¥' + Number(msg.orderCard.paidAmount || 0).toFixed(2) }}</div>
                    <div class="text-white/70 text-[10px]">{{ msg.orderCard.payType === 'points' ? '积分支付' : '余额支付' }}</div>
                  </div>
                </div>
              </div>
              <div class="bg-white px-4 py-3">
                <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-1.5">
                    <div class="w-1.5 h-1.5 rounded-full" :class="statusDot(msg.orderCard.status)" />
                    <span class="text-[13px] font-semibold" :class="statusTextClass(msg.orderCard.status)">{{ statusLabel(msg.orderCard.status) }}</span>
                  </div>
                  <span class="text-[10px] text-gray-400">{{ fmtTime(msg.createTime) }}</span>
                </div>
                <div class="text-[12px] text-gray-600 leading-relaxed">{{ msg.orderCard.orderDesc || '暂无描述' }}</div>
                <div class="mt-2 pt-2 border-t border-gray-50 flex justify-between items-center">
                  <span class="text-[10px] text-gray-400">点击查看订单详情</span>
                  <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </div>
              </div>
            </div>
            <div class="text-[10px] text-gray-400 mt-1" :class="msg.fromUserId === myUserId ? 'text-right' : 'text-left'">{{ fmtTime(msg.createTime) }}</div>
          </div>
        </div>
        <div v-else class="flex gap-2" :class="msg.fromUserId === myUserId ? 'flex-row-reverse' : ''">
          <img
            :src="resolveAvatar(msg.fromUserAvatar)"
            class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0"
            :class="msg.fromUserId === myUserId ? 'mt-3' : 'mt-4'"
            @error="($event.target as any).style.display='none'"
            @click="msg.fromUserId !== myUserId && handleAvatarClick(msg)"
          />
          <div class="max-w-[72%]">
            <div
              v-if="msg.fromUserId !== myUserId"
              class="text-[10px] text-gray-400 mb-1 ml-1"
              :style="{ color: memberColor(msg.fromUserId) }"
            >{{ msg.fromUserName }}</div>
            <div v-if="msg.isRecalled" class="px-3 py-2 rounded-xl text-xs bg-gray-100 text-gray-400 italic">消息已撤回</div>
            <template v-else>
              <div v-if="msg.replyTo" class="text-[10px] bg-black/5 text-gray-500 px-2.5 py-1 rounded-lg mb-1 max-w-full truncate" @click="scrollToMsg(msg.replyTo.id)">
                {{ msg.replyTo.userName }}: {{ msg.replyTo.content || '[图片]' }}
              </div>
              <img v-if="msg.imageUrl" :src="$fixImgUrl(msg.imageUrl)" class="max-w-[200px] max-h-[200px] rounded-xl object-cover cursor-pointer mb-1" @click="previewImgUrl = msg.imageUrl" />
              <div
                v-if="msg.content"
                class="px-3 py-2.5 rounded-xl text-[15px] leading-relaxed break-all"
                :class="msg.fromUserId === myUserId ? 'bg-[#FFE5E5] text-gray-800' : 'bg-white text-gray-800'"
                @touchstart="onMsgTouchStart($event, msg)"
                @touchend="onMsgTouchEnd($event)"
                @touchmove="onMsgTouchCancel"
              >{{ msg.content }}</div>
            </template>
            <div class="flex items-center gap-2 mt-0.5" :class="msg.fromUserId === myUserId ? 'justify-end' : 'justify-start'">
              <span class="text-[9px] text-gray-400">{{ fmtTime(msg.createTime) }}</span>
              <span v-if="msg.fromUserId !== myUserId" class="text-[9px] text-gray-400 cursor-pointer" @click="startReply(msg)">回复</span>
              <span v-if="msg.fromUserId === myUserId" class="text-[9px] text-gray-400 cursor-pointer" @click="recallMsg(msg)">撤回</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 图片预览 -->
    <div v-if="previewImgUrl" class="fixed inset-0 bg-black/85 flex items-center justify-center z-[100]" @click="previewImgUrl = ''">
      <img :src="$fixImgUrl(previewImgUrl)" class="max-w-[92%] max-h-[92%] object-contain rounded-lg" />
    </div>

    <!-- 消息操作菜单 -->
    <div v-if="menuMsg" class="fixed inset-0 bg-black/30 flex items-end justify-center z-50" @click="closeMenu">
      <div class="bg-white rounded-t-xl w-full max-w-lg pb-6" @click.stop>
        <div class="text-center text-xs text-gray-400 py-2">{{ menuMsg.fromUserId === myUserId ? '我的消息' : menuMsg.fromUserName }}</div>
        <template v-if="menuMsg.fromUserId === myUserId && !menuMsg.isRecalled">
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-red-500" @click="recallMsg(menuMsg); closeMenu()">撤回</div>
        </template>
        <template v-if="menuMsg.fromUserId !== myUserId">
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-red-500" @click="showReportDialog(menuMsg)">举报</div>
        </template>
        <div v-if="menuMsg.content" class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="copyMsg(menuMsg)">复制</div>
        <div class="pt-2"><div class="py-3 px-6 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="closeMenu">取消</div></div>
      </div>
    </div>

    <!-- 举报对话框 -->
    <div v-if="reportMsg" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="reportMsg = null">
      <div class="bg-white rounded-xl w-80 overflow-hidden" @click.stop>
        <div class="px-6 py-5"><div class="text-base font-semibold text-gray-800 mb-3 text-center">举报消息</div>
          <div class="space-y-2">
            <div v-for="opt in reportOptions" :key="opt.value" class="py-2 px-3 rounded-lg cursor-pointer text-sm border" :class="reportReason === opt.value ? 'border-red-400 text-red-500 bg-red-50' : 'border-gray-200 text-gray-600'" @click="reportReason = opt.value">{{ opt.label }}</div>
          </div>
          <textarea v-model="reportDetail" class="w-full mt-3 px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none resize-none" rows="2" placeholder="补充说明（选填）" />
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="reportMsg = null; reportReason = ''; reportDetail = ''">取消</div>
          <div class="flex-1 py-3 text-center text-base font-medium cursor-pointer active:bg-gray-50" :class="reportReason ? 'text-red-500' : 'text-gray-300'" @click="submitReport">提交</div>
        </div>
      </div>
    </div>

    <!-- 成员面板 -->
    <div v-if="showMemberPanel" class="fixed inset-0 z-40 flex justify-end" @click="showMemberPanel = false">
      <div class="w-72 bg-white h-full overflow-y-auto shadow-2xl" @click.stop>
        <div class="sticky top-0 bg-white z-10 px-4 py-3 border-b border-gray-100 flex items-center justify-between">
          <span class="text-[15px] font-semibold text-gray-800">群成员 ({{ memberCount }})</span>
          <svg class="w-5 h-5 text-gray-400 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="showMemberPanel = false">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </div>
        <div v-if="ownerAndAdmins.length" class="px-4 pb-2">
          <div class="text-[11px] text-gray-400 pt-3 pb-2">管理员</div>
          <div v-for="m in ownerAndAdmins" :key="m.userId" class="flex items-center gap-2.5 py-2 cursor-pointer active:bg-gray-50 rounded-lg px-2 -mx-2" @click="handleMemberClick(m)">
            <img :src="resolveAvatar(m.avatar)" class="w-[34px] h-[34px] rounded-full object-cover flex-shrink-0" @error="($event.target as any).style.display='none'" />
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1.5">
                <span class="text-[13px] text-gray-800 truncate">{{ m.username }}</span>
                <span v-if="m.role === 'owner'" class="text-[9px] bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded font-medium">群主</span>
                <span v-else class="text-[9px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-medium">管理</span>
              </div>
            </div>
          </div>
        </div>
        <div v-if="normalMembers.length" class="px-4 pb-4">
          <div class="text-[11px] text-gray-400 pt-3 pb-2">成员</div>
          <div v-for="m in normalMembers" :key="m.userId" class="flex items-center gap-2.5 py-2 cursor-pointer active:bg-gray-50 rounded-lg px-2 -mx-2" @click="handleMemberClick(m)">
            <img :src="resolveAvatar(m.avatar)" class="w-[34px] h-[34px] rounded-full object-cover flex-shrink-0" @error="($event.target as any).style.display='none'" />
            <div class="flex-1 min-w-0">
              <div class="text-[13px] text-gray-800 truncate">{{ m.username }}</div>
              <div v-if="m.mutedUntil" class="text-[10px] text-orange-400">已禁言</div>
            </div>
          </div>
        </div>
        <div v-if="loadingMembers" class="flex justify-center py-10">
          <div class="animate-spin w-5 h-5 border-2 border-[#4A90D9] border-t-transparent rounded-full" />
        </div>
      </div>
    </div>

    <!-- 管理员操作菜单 -->
    <div v-if="adminTarget" class="fixed inset-0 bg-black/30 flex items-end justify-center z-50" @click="adminTarget = null">
      <div class="bg-white rounded-t-2xl w-full max-w-lg pb-6" @click.stop>
        <div class="text-center text-xs text-gray-400 py-3">{{ adminTarget.username }}</div>
        <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-orange-500" @click="doMuteMember(adminTarget, 10); adminTarget = null">禁言 10 分钟</div>
        <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-orange-500" @click="doMuteMember(adminTarget, 60); adminTarget = null">禁言 1 小时</div>
        <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-orange-500" @click="doMuteMember(adminTarget, 7200); adminTarget = null">永久禁言</div>
        <div v-if="adminTarget.mutedUntil" class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-green-500" @click="doUnmuteMember(adminTarget); adminTarget = null">解除禁言</div>
        <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-red-500" @click="adminTarget = null; kickMember(adminTarget)">踢出聊天室</div>
        <div class="pt-2"><div class="py-3 px-6 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="adminTarget = null">取消</div></div>
      </div>
    </div>

    <!-- QQ风格群资料页 -->
    <div v-if="showRoomInfo" class="fixed inset-0 z-50 flex flex-col" @click.stop>
      <div class="flex-1 overflow-y-auto bg-[#F5F6FA]">
        <!-- 顶栏 -->
        <div class="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-[#F5F6FA]">
          <div class="w-9 h-9 rounded-full bg-white shadow-sm flex items-center justify-center cursor-pointer" @click="showRoomInfo = false">
            <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7"/></svg>
          </div>
          <span class="text-[16px] font-semibold text-gray-800">群资料</span>
          <div class="w-9 h-9 rounded-full bg-white shadow-sm flex items-center justify-center cursor-pointer">
            <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"/></svg>
          </div>
        </div>

        <!-- 群头像 -->
        <div class="px-5 mt-3 flex items-start gap-3">
          <div class="relative flex-shrink-0" :class="{ 'cursor-pointer': myRole === 'owner' || myRole === 'admin' }" @click="(myRole === 'owner' || myRole === 'admin') && editGroupAvatar()">
            <div v-if="room.avatar" class="w-[60px] h-[60px] rounded-full overflow-hidden">
              <img :src="$fixImgUrl(room.avatar)" class="w-full h-full object-cover" />
            </div>
            <div v-else class="w-[60px] h-[60px] rounded-full flex items-center justify-center text-white font-bold text-[26px]" style="background: linear-gradient(135deg, #5BA0E0, #357ABD)">
              {{ (room.name || '?')[0] }}
            </div>
            <div v-if="myRole === 'owner' || myRole === 'admin'" class="absolute -bottom-1 -right-1 w-5 h-5 bg-white rounded-full shadow flex items-center justify-center">
              <svg class="w-3 h-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/></svg>
            </div>
          </div>
          <div class="flex-1 min-w-0 pt-0.5">
            <div class="text-[18px] font-semibold text-gray-900 truncate leading-tight">{{ room.name || '聊天室' }}</div>
            <div class="flex items-center gap-1.5 mt-1.5">
              <span class="text-[13px] text-gray-500">{{ memberCount }}人</span>
              <span class="text-gray-300 text-xs">·</span>
              <span class="text-[13px] text-gray-500">群号 {{ roomId }}</span>
              <span class="text-[11px] text-[#4A90D9] ml-1.5 cursor-pointer active:opacity-70 font-medium bg-[#4A90D9]/8 px-2 py-0.5 rounded-full" @click="copyGroupId">复制</span>
            </div>
          </div>
          <div class="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 mt-1 cursor-pointer active:bg-gray-200">
            <svg class="w-[14px] h-[14px] text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/></svg>
          </div>
        </div>

        <!-- 内容 -->
        <div class="px-4 mt-5">
          <!-- 群介绍 -->
          <div v-if="room.description" class="bg-white rounded-2xl px-4 py-4 mb-3">
            <div class="text-[12px] text-gray-400 mb-2 flex items-center gap-1">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              群介绍
            </div>
            <div class="text-[14px] text-gray-700 leading-[1.8]">{{ room.description }}</div>
          </div>

          <!-- 群公告 -->
          <div class="bg-white rounded-2xl px-4 py-4 mb-3">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-1">
                <svg class="w-3.5 h-3.5 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>
                <span class="text-[13px] font-medium text-gray-800">群公告</span>
              </div>
              <span class="text-[12px] text-[#4A90D9] cursor-pointer font-medium" @click="showAnnouncement = !showAnnouncement">{{ showAnnouncement ? '收起' : '展开' }}</span>
            </div>
            <div v-if="showAnnouncement" class="text-[14px] text-gray-600 leading-[1.8] whitespace-pre-wrap pl-0.5">{{ room.announcement || '欢迎加入！请遵守群规，文明聊天。' }}</div>
            <div v-else class="text-[14px] text-gray-600 truncate pl-0.5">{{ room.announcement || '欢迎加入！请遵守群规，文明聊天。' }}</div>
          </div>

          <!-- 频道入口 -->
          <div class="bg-white rounded-2xl overflow-hidden mb-3">
            <div class="flex items-center justify-between px-4 py-3.5 cursor-pointer active:bg-gray-50" @click="showRoomInfo = false">
              <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-lg bg-[#4A90D9]/10 flex items-center justify-center">
                  <svg class="w-4 h-4 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"/></svg>
                </div>
                <div>
                  <div class="text-[14px] font-medium text-gray-800">聊天室频道</div>
                  <div class="text-[11px] text-gray-400 mt-0.5">#{{ room.name || '聊天室' }}</div>
                </div>
              </div>
              <span class="text-[12px] text-[#4A90D9] font-medium">进入</span>
            </div>
          </div>

          <!-- 群应用 -->
          <div class="bg-white rounded-2xl overflow-hidden mb-3">
            <div class="px-4 py-3.5 border-b border-gray-50 flex items-center gap-2">
              <svg class="w-4 h-4 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
              <span class="text-[14px] font-medium text-gray-800">群应用</span>
            </div>
            <div class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="showFiles = true; collectGroupFiles()">
              <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center">
                  <svg class="w-4 h-4 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                </div>
                <div>
                  <div class="text-[14px] text-gray-800">文件</div>
                  <div class="text-[11px] text-gray-400 mt-0.5">{{ groupFileCount }} 个文件</div>
                </div>
              </div>
              <svg class="w-4 h-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
            <div class="px-4 py-2.5 border-t border-gray-50 grid grid-cols-3 gap-2">
              <div v-for="(img, i) in groupFilePreview.slice(0, 3)" :key="i" class="aspect-square rounded-lg bg-gray-100 overflow-hidden" @click="showFiles = true; collectGroupFiles()">
                <img :src="img" class="w-full h-full object-cover" />
              </div>
            </div>
          </div>

          <!-- 群管理 -->
          <div v-if="myRole === 'owner' || myRole === 'admin'" class="bg-white rounded-2xl overflow-hidden mb-3">
            <div class="px-4 py-3.5 border-b border-gray-50 flex items-center gap-2">
              <svg class="w-4 h-4 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              <span class="text-[14px] font-medium text-gray-800">群管理</span>
            </div>
            <div class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="editNameDialog = true">
              <span class="text-[14px] text-gray-700">群名称</span>
              <div class="flex items-center gap-1.5">
                <span class="text-[12px] text-gray-400 truncate max-w-[120px]">{{ room.name }}</span>
                <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
            <div class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="editDescDialog = true">
              <span class="text-[14px] text-gray-700">群介绍</span>
              <div class="flex items-center gap-1.5">
                <span class="text-[12px] text-gray-400 truncate max-w-[120px]">{{ room.description || '未设置' }}</span>
                <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
            <div class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="toggleChat">
              <span class="text-[14px] text-gray-700">全员禁言</span>
              <div class="relative w-[44px] h-[24px] rounded-full cursor-pointer transition-colors duration-200" :class="!chatEnabled ? 'bg-[#4A90D9]' : 'bg-gray-300'">
                <div class="absolute top-[2px] w-[20px] h-[20px] bg-white rounded-full shadow-md transition-transform duration-200" :class="!chatEnabled ? 'translate-x-[22px]' : 'translate-x-[2px]'" />
              </div>
            </div>
            <div v-if="myRole === 'owner'" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="showJoinModeDialog = true">
              <span class="text-[14px] text-gray-700">加群方式</span>
              <div class="flex items-center gap-1.5">
                <span class="text-[12px] text-gray-400">{{ joinModeLabels[joinMode] || '公开加入' }}</span>
                <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
            <div v-if="myRole === 'owner' || myRole === 'admin'" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50">
              <span class="text-[14px] text-gray-700">成员上限</span>
              <div class="flex items-center gap-1.5">
                <span class="text-[12px] text-gray-400">{{ memberCount }} / {{ memberLimit >= 999999 ? '无限制' : memberLimit }}</span>
                <button v-if="memberLimit < 999999" class="text-[11px] px-2 py-1 rounded-full border" style="border-color:#4A90D9;color:#4A90D9" @click.stop="showUpgradeDialog = true">申请扩容</button>
              </div>
            </div>
            <div v-if="joinMode === 'approval' && (myRole === 'owner' || myRole === 'admin')" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="openApprovalPanel">
              <span class="text-[14px] text-gray-700">入群审批</span>
              <div class="flex items-center gap-1.5">
                <span v-if="pendingRequestCount > 0" class="text-[11px] text-white px-1.5 py-0.5 rounded-full" style="background:#EF4444">{{ pendingRequestCount }}</span>
                <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
            <div v-if="joinMode === 'invite' && (myRole === 'owner' || myRole === 'admin')" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="inviteDialog = true">
              <span class="text-[14px] text-gray-700">邀请成员</span>
              <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
            <div v-if="myRole === 'owner'" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="openManagePanel">
              <span class="text-[14px] text-gray-700">成员管理</span>
              <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
            <div v-if="myRole === 'owner'" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="dissolveGroup">
              <span class="text-[14px] text-red-500">解散群聊</span>
              <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
            <div v-if="myRole === 'owner'" class="flex items-center justify-between px-4 py-3 cursor-pointer active:bg-gray-50" @click="transferOwnership">
              <span class="text-[14px] text-orange-500">转让群主</span>
              <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
          </div>

          <!-- 成员入口 -->
          <div class="bg-white rounded-2xl overflow-hidden mb-3">
            <div class="flex items-center justify-between px-4 py-3.5 cursor-pointer active:bg-gray-50" @click="loadMembers(); showMemberPanel = true">
              <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-lg bg-[#4A90D9]/10 flex items-center justify-center">
                  <svg class="w-4 h-4 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
                <span class="text-[14px] font-medium text-gray-800">群成员</span>
                <span class="text-[11px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full">{{ memberCount }}</span>
              </div>
              <div class="flex items-center gap-2">
                <div class="flex -space-x-1.5">
                  <img v-for="(m, i) in topMembers" :key="i" :src="resolveAvatar(m.avatar)" class="w-[22px] h-[22px] rounded-full border border-white object-cover shadow-sm" @error="($event.target as any).style.display='none'" />
                </div>
                <svg class="w-4 h-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
              </div>
            </div>
          </div>

          <!-- 统计面板 -->
          <div class="bg-white rounded-2xl px-4 py-5 mb-3">
            <div class="flex items-center gap-2.5 mb-4">
              <svg class="w-4 h-4 text-[#4A90D9]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
              <span class="text-[13px] font-medium text-gray-800">群数据</span>
            </div>
            <div class="grid grid-cols-4">
              <div v-for="(s, i) in stats" :key="s.label" class="text-center relative" :class="i < 3 ? 'border-r border-gray-100' : ''">
                <div class="text-[11px] text-gray-400 mb-1.5">{{ s.label }}</div>
                <div class="flex items-baseline justify-center gap-0.5">
                  <span class="text-[24px] font-bold leading-none" :style="{ color: s.color }">{{ s.value }}</span>
                  <span v-if="s.unit === '%'" class="text-[17px] font-bold leading-none" :style="{ color: s.color }">%</span>
                  <span v-else class="text-[11px] text-gray-400 ml-0.5">{{ s.unit }}</span>
                </div>
                <div class="mt-2.5 mx-3 h-[3px] bg-gray-100 rounded-full overflow-hidden">
                  <div class="h-full rounded-full transition-all duration-500" :style="{ width: s.percent + '%', background: s.color }" />
                </div>
              </div>
            </div>
          </div>

          <!-- 建群时间 -->
          <div class="flex items-center justify-center py-3 mb-3">
            <span class="text-[12px] text-gray-400">建群于 {{ room.createdAt ? fmtDate(room.createdAt) : '2026/07/01' }}</span>
          </div>

          <!-- 退出 -->
          <div class="bg-white rounded-2xl overflow-hidden mb-24" @click="leaveRoom">
            <div class="px-4 py-3.5 text-center text-[15px] text-red-500 cursor-pointer active:bg-red-50 font-medium">退出聊天室</div>
          </div>
        </div>
      </div>

      <!-- 群文件浏览器 -->
      <div v-if="showFiles" class="fixed inset-0 z-[60] bg-white flex flex-col">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <div class="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center cursor-pointer" @click="showFiles = false">
            <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7"/></svg>
          </div>
          <span class="text-[16px] font-semibold text-gray-800">群文件</span>
          <div class="w-9 h-9 rounded-full bg-[#4A90D9] flex items-center justify-center cursor-pointer" @click="uploadGroupFile">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
          </div>
        </div>
        <div class="flex-1 overflow-y-auto bg-[#F5F6FA] p-4">
          <div v-if="groupFiles.length === 0" class="flex flex-col items-center justify-center h-full text-gray-400">
            <svg class="w-16 h-16 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
            <span class="text-[13px]">暂无群文件</span>
          </div>
          <div v-else class="grid grid-cols-3 gap-2">
            <div v-for="(f, i) in groupFiles" :key="i" class="bg-white rounded-xl overflow-hidden cursor-pointer active:opacity-70" @click="previewGroupFile(f)">
              <div v-if="f.fileType === 'image'" class="aspect-square bg-gray-100">
                <img :src="$fixImgUrl(f.fileUrl)" class="w-full h-full object-cover" />
              </div>
              <div v-else-if="f.fileType === 'video'" class="aspect-square bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                <svg class="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              </div>
              <div v-else-if="f.fileType === 'audio'" class="aspect-square bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/></svg>
              </div>
              <div v-else-if="f.fileType === 'document'" class="aspect-square bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                <svg class="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              </div>
              <div v-else class="aspect-square bg-gray-100 flex items-center justify-center">
                <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
              </div>
              <div class="px-2 py-1.5">
                <div class="text-[11px] text-gray-700 truncate leading-tight">{{ f.fileName }}</div>
                <div class="text-[9px] text-gray-400 mt-0.5">{{ fmtTime(f.createTime) }} · {{ f.userName }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 底部操作栏 -->
      <div class="bg-white/95 backdrop-blur-xl border-t border-gray-100 px-4 py-3 flex gap-3 shadow-[0_-4px_20px_rgba(0,0,0,0.04)]" style="padding-bottom: max(12px, env(safe-area-inset-bottom))">
        <button class="flex-1 py-2.5 rounded-full text-[15px] font-medium border border-gray-200 text-gray-700 bg-white active:bg-gray-50 shadow-sm" @click="shareGroup">分享群聊</button>
        <button class="flex-1 py-2.5 rounded-full text-[15px] font-medium text-white active:opacity-90 shadow-md shadow-[#4A90D9]/30" style="background: linear-gradient(135deg, #5BA0E0, #4A90D9)" @click="showRoomInfo = false">发消息</button>
      </div>

      <!-- 编辑群名称弹窗 -->
      <div v-if="editNameDialog" class="fixed inset-0 z-[70] bg-black/30 flex items-center justify-center px-8" @click="editNameDialog = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-4">修改群名称</div>
          <input v-model="editName" class="w-full text-[14px] px-4 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30 mb-4" placeholder="输入群名称" />
          <div class="flex gap-3">
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600" @click="editNameDialog = false">取消</button>
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium text-white active:opacity-90" style="background: #4A90D9" @click="updateRoomSettings">确定</button>
          </div>
        </div>
      </div>

      <!-- 加群方式选择弹窗 -->
      <div v-if="showJoinModeDialog" class="fixed inset-0 z-[70] bg-black/30 flex items-center justify-center px-8" @click="showJoinModeDialog = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-4">选择加群方式</div>
          <div v-for="opt in joinModeOptions" :key="opt.value" class="flex items-center justify-between py-3 px-2 cursor-pointer active:bg-gray-50 rounded-lg mb-1" @click="updateJoinMode(opt.value)">
            <div>
              <div class="text-[14px] font-medium" :class="joinMode === opt.value ? 'text-[#4A90D9]' : 'text-gray-700'">{{ opt.label }}</div>
              <div class="text-[11px] text-gray-400 mt-0.5">{{ opt.desc }}</div>
            </div>
            <div v-if="joinMode === opt.value" class="w-5 h-5 rounded-full bg-[#4A90D9] flex items-center justify-center"><svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
            <div v-else class="w-5 h-5 rounded-full border-2 border-gray-300" />
          </div>
          <button class="w-full py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600 mt-3" @click="showJoinModeDialog = false">取消</button>
        </div>
      </div>

      <!-- 禁言自定弹窗 -->
      <div v-if="muteDialogTarget" class="fixed inset-0 z-[70] bg-black/30 flex items-end justify-center" @click="muteDialogTarget = null">
        <div class="bg-white rounded-t-2xl w-full max-w-lg pb-6" @click.stop>
          <div class="text-center text-xs text-gray-400 py-3">{{ muteDialogTarget.username }} 禁言设置</div>
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="doMuteMember(muteDialogTarget, 10)">禁言 10 分钟</div>
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="doMuteMember(muteDialogTarget, 30)">禁言 30 分钟</div>
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="doMuteMember(muteDialogTarget, 60)">禁言 1 小时</div>
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="doMuteMember(muteDialogTarget, 1440)">禁言 1 天</div>
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="customMuteTarget = muteDialogTarget; muteDialogTarget = null; showCustomMute = true">自定义禁言</div>
          <div v-if="muteDialogTarget.mutedUntil" class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-green-500" @click="doUnmuteMember(muteDialogTarget)">解除禁言</div>
          <div class="pt-2"><div class="py-3 px-6 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="muteDialogTarget = null">取消</div></div>
        </div>
      </div>

      <!-- 自定义禁言弹窗 -->
      <div v-if="showCustomMute" class="fixed inset-0 z-[70] bg-black/30 flex items-center justify-center px-8" @click="showCustomMute = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-4">自定义禁言</div>
          <div class="flex items-center gap-2 mb-4">
            <input v-model="customMuteValue" type="number" class="flex-1 text-[14px] px-4 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30" placeholder="输入时长" min="1" />
            <select v-model="customMuteUnit" class="text-[14px] px-3 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30">
              <option value="minute">分钟</option>
              <option value="hour">小时</option>
              <option value="day">天</option>
            </select>
          </div>
          <div class="flex gap-3">
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600" @click="showCustomMute = false">取消</button>
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium text-white active:opacity-90" style="background: #4A90D9" @click="applyCustomMute">确定</button>
          </div>
        </div>
      </div>

      <!-- 邀请弹窗 -->
      <div v-if="inviteDialog" class="fixed inset-0 z-[80] bg-black/30 flex items-center justify-center px-8" @click="inviteDialog = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-4">邀请成员</div>
          <input v-model="inviteAccount" class="w-full text-[14px] px-4 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30 mb-4" placeholder="请输入用户ID或用户名" />
          <div class="flex gap-3">
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600" @click="inviteDialog = false">取消</button>
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium text-white active:opacity-90" style="background: #4A90D9" @click="doInvite">确定邀请</button>
          </div>
        </div>
      </div>

      <!-- 扩容申请弹窗 -->
      <div v-if="showUpgradeDialog" class="fixed inset-0 z-[80] bg-black/30 flex items-center justify-center px-8" @click="showUpgradeDialog = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-2">申请扩容</div>
          <div class="text-[12px] text-gray-400 text-center mb-4">当前上限 {{ memberLimit }} 人</div>
          <input v-model="upgradeLimit" type="number" class="w-full text-[14px] px-4 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30 mb-3" placeholder="目标上限人数" />
          <textarea v-model="upgradeReason" class="w-full text-[14px] px-4 py-3 rounded-xl bg-gray-50 border-0 outline-none focus:ring-2 focus:ring-[#4A90D9]/30 resize-none h-20 mb-4" placeholder="申请理由" />
          <div class="flex gap-3">
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600" @click="showUpgradeDialog = false">取消</button>
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium text-white active:opacity-90" style="background: #4A90D9" @click="doUpgradeRequest">提交申请</button>
          </div>
        </div>
      </div>

      <!-- 确认弹窗 -->
      <div v-if="confirmDialog" class="fixed inset-0 z-[80] bg-black/30 flex items-center justify-center px-8" @click="confirmDialog = false">
        <div class="bg-white rounded-2xl w-full max-w-sm p-6" @click.stop>
          <div class="text-[16px] font-semibold text-gray-800 text-center mb-2">{{ confirmTitle }}</div>
          <div class="text-[13px] text-gray-500 text-center mb-5 leading-relaxed">{{ confirmMsg }}</div>
          <div class="flex gap-3">
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium border border-gray-200 text-gray-600" @click="confirmDialog = false">取消</button>
            <button class="flex-1 py-2.5 rounded-full text-[14px] font-medium text-white active:opacity-90" :style="{ background: confirmAction === 'ban' || confirmAction === 'kick' ? '#EF4444' : '#4A90D9' }" @click="executeConfirm">确定</button>
          </div>
        </div>
      </div>

      <!-- 群管理面板（独立页面） -->
      <div v-if="showManagePanel" class="fixed inset-0 z-[60] bg-white flex flex-col">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <div class="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center cursor-pointer" @click="showManagePanel = false">
            <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7"/></svg>
          </div>
          <span class="text-[16px] font-semibold text-gray-800">成员管理</span>
          <div class="w-9 h-9" />
        </div>
        <div class="pt-1 px-4">
          <div class="text-[12px] text-gray-500 mb-2">点击成员进行操作：禁言、踢出、拉黑、设管理员</div>
        </div>
        <div class="flex-1 overflow-y-auto pb-20">
          <div v-if="loadingMembers" class="flex justify-center py-10">
            <div class="animate-spin w-5 h-5 border-2 border-[#4A90D9] border-t-transparent rounded-full" />
          </div>
          <div v-else>
            <div v-if="manageOwnerAndAdmins.length" class="px-4 pb-2">
              <div class="text-[11px] text-gray-400 pt-2 pb-2">管理员</div>
              <div v-for="m in manageOwnerAndAdmins" :key="m.userId" class="flex items-center gap-2.5 py-2.5 border-b border-gray-50">
                <img :src="resolveAvatar(m.avatar)" class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0" @error="($event.target as any).style.display='none'" />
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-1.5">
                    <span class="text-[13px] text-gray-800 truncate">{{ m.username }}</span>
                    <span v-if="m.role === 'owner'" class="text-[9px] bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded font-medium">群主</span>
                    <span v-else class="text-[9px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-medium">管理</span>
                    <span v-if="m.mutedUntil" class="text-[9px] text-orange-400 bg-orange-50 px-1.5 py-0.5 rounded">已禁言</span>
                  </div>
                </div>
                <div v-if="m.role !== 'owner'" class="flex items-center gap-1 text-[10px]">
                  <span class="text-[#4A90D9] bg-[#4A90D9]/8 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="openMuteDialog(m)">禁言</span>
                  <span class="text-orange-500 bg-orange-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="kickMember(m)">踢出</span>
                  <span class="text-red-500 bg-red-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="banMember(m)">拉黑</span>
                  <span v-if="myRole === 'owner' && m.role === 'admin'" class="text-gray-500 bg-gray-100 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="setAdmin(m, false)">取消管理</span>
                  <span v-if="myRole === 'owner' && m.role !== 'admin'" class="text-gray-500 bg-gray-100 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="setAdmin(m, true)">设管理</span>
                </div>
              </div>
            </div>
            <div v-if="manageNormalMembers.length" class="px-4 pb-4">
              <div class="text-[11px] text-gray-400 pt-2 pb-2">成员</div>
              <div v-for="m in manageNormalMembers" :key="m.userId" class="flex items-center gap-2.5 py-2.5 border-b border-gray-50">
                <img :src="resolveAvatar(m.avatar)" class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0" @error="($event.target as any).style.display='none'" />
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-1.5">
                    <span class="text-[13px] text-gray-800 truncate">{{ m.username }}</span>
                    <span v-if="m.mutedUntil" class="text-[9px] text-orange-400 bg-orange-50 px-1.5 py-0.5 rounded">已禁言</span>
                  </div>
                </div>
                <div class="flex items-center gap-1 text-[10px]">
                  <span class="text-[#4A90D9] bg-[#4A90D9]/8 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="openMuteDialog(m)">禁言</span>
                  <span class="text-orange-500 bg-orange-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="kickMember(m)">踢出</span>
                  <span class="text-red-500 bg-red-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="banMember(m)">拉黑</span>
                  <span v-if="myRole === 'owner'" class="text-purple-500 bg-purple-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="setAdmin(m, true)">设为管理</span>
                  <span v-if="myRole === 'owner'" class="text-orange-500 bg-orange-50 px-2 py-1 rounded cursor-pointer active:opacity-70" @click="doTransferOwnership(m)">转让</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 入群审批面板 -->
    <div v-if="showApprovalPanel" class="fixed inset-0 z-[60] bg-white flex flex-col">
      <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0" style="padding-top: max(12px, env(safe-area-inset-top))">
        <button class="w-9 h-9 flex items-center justify-center rounded-lg" @click="showApprovalPanel = false">
          <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        </button>
        <span class="text-[16px] font-semibold text-gray-800">入群审批</span>
        <div class="w-9 h-9" />
      </div>
      <div v-if="loadingMembers" class="flex justify-center py-10"><div class="animate-spin w-5 h-5 border-2 border-[#4A90D9] border-t-transparent rounded-full" /></div>
      <div v-else-if="joinRequests.length === 0" class="flex-1 flex items-center justify-center text-[14px] text-gray-400">暂无待审批申请</div>
      <div v-else class="flex-1 overflow-y-auto">
        <div v-for="req in joinRequests" :key="req.id" class="flex items-center gap-2.5 px-4 py-3 border-b border-gray-50">
          <img :src="resolveAvatar(req.user_avatar)" class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0" @error="($event.target as any).style.display='none'" />
          <div class="flex-1 min-w-0">
            <div class="text-[13px] text-gray-800">{{ req.user_name }}</div>
            <div class="text-[11px] text-gray-400 mt-0.5">{{ req.reason || '无申请理由' }}</div>
          </div>
          <div class="flex items-center gap-2 flex-shrink-0">
            <button class="text-[12px] px-3 py-1.5 rounded-full text-white" style="background: #4A90D9" @click="handleJoinRequest(req, 'approved')">通过</button>
            <button class="text-[12px] px-3 py-1.5 rounded-full text-gray-500 border border-gray-200" @click="handleJoinRequest(req, 'rejected')">拒绝</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 订单选择弹窗 -->
    <div v-if="showOrderPanel" class="fixed inset-0 bg-black/30 flex items-end justify-center z-50" @click="showOrderPanel = false">
      <div class="bg-white rounded-t-xl w-full max-w-lg max-h-[60vh] overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100 text-center text-sm font-semibold text-gray-800">选择订单</div>
        <div class="overflow-y-auto max-h-[calc(60vh-60px)]">
          <div v-if="loadingOrders" class="flex justify-center py-10"><div class="animate-spin w-5 h-5 border-2 border-[#4A90D9] border-t-transparent rounded-full" /></div>
          <div v-else-if="myOrders.length === 0" class="py-10 text-center text-sm text-gray-400">暂无订单</div>
          <div v-else>
            <div v-for="o in myOrders" :key="o.id" class="flex items-center gap-3 px-5 py-3 cursor-pointer active:bg-gray-50 border-b border-gray-50" @click="sendOrderCard(o)">
              <div class="w-[40px] h-[40px] rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: iconBg(o.orderNo) }">
                <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-sm text-gray-800 truncate" :class="statusClass(o.status)">{{ statusLabel(o.status) }} - {{ o.orderDesc }}</div>
                <div class="text-xs text-gray-400">{{ o.payType === 'points' ? o.paidAmount + ' 积分' : '¥' + o.paidAmount }} · {{ fmtTime(o.createTime) }}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="py-3 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="showOrderPanel = false">取消</div>
      </div>
    </div>

    <!-- 订单详情弹窗 -->
    <div v-if="showOrderDetail" class="fixed inset-0 bg-black/30 flex items-end justify-center z-[80]" @click="showOrderDetail = false">
      <div class="bg-white rounded-t-xl w-full max-w-lg max-h-[80vh] overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100 text-center text-sm font-semibold text-gray-800">订单详情</div>
        <div class="overflow-y-auto max-h-[calc(80vh-60px)] px-5 py-4">
          <template v-if="orderDetail">
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">订单号</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderNo }}</div>
            </div>
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">描述</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderDesc }}</div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">状态</span>
                <div class="text-[14px] font-semibold mt-0.5" :class="statusClass(orderDetail.status)">{{ statusLabel(orderDetail.status) }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">金额</span>
                <div class="text-[14px] font-semibold text-gray-800 mt-0.5">{{ orderDetail.payType === 'points' ? orderDetail.paidAmount + ' 积分' : '¥' + orderDetail.paidAmount }}</div>
              </div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">类型</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderType || '-' }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">支付方式</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.payType === 'points' ? '积分' : '余额' }}</div>
              </div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">买家</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.buyerName || '-' }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">卖家</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.sellerName || '平台' }}</div>
              </div>
            </div>
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">下单时间</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ fmtDateTime(orderDetail.createTime) }}</div>
            </div>
            <div v-if="orderDetail.confirmedAt" class="mb-3">
              <span class="text-[11px] text-gray-400">确认收货时间</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ fmtDateTime(orderDetail.confirmedAt) }}</div>
            </div>
            <!-- 退款/审核信息 -->
            <div v-if="orderDetail.refundReason" class="mb-3 p-3 bg-orange-50 rounded-xl">
              <span class="text-[11px] text-orange-500 font-medium">退款原因</span>
              <div class="text-[13px] text-gray-800 mt-1">{{ orderDetail.refundReason }}</div>
              <div v-if="orderDetail.refundRequestedAt" class="text-[11px] text-gray-400 mt-1">申请时间：{{ fmtDateTime(orderDetail.refundRequestedAt) }}</div>
            </div>
            <div v-if="orderDetail.adminReview" class="mb-3 p-3 bg-blue-50 rounded-xl">
              <span class="text-[11px] text-blue-500 font-medium">管理员审核</span>
              <div class="text-[13px] text-gray-800 mt-1">{{ orderDetail.adminReview === 'pending' ? '待审核' : orderDetail.adminReview === 'reviewed' ? '已审核' : orderDetail.adminReview }}</div>
              <div v-if="orderDetail.refundReviewedByName" class="text-[11px] text-gray-400 mt-1">审核人：{{ orderDetail.refundReviewedByName }}</div>
            </div>
          </template>
        </div>
        <div class="py-3 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="showOrderDetail = false">关闭</div>
      </div>
    </div>

    <!-- 引用回复提示条 -->
    <div v-if="replyTarget" class="bg-white border-t border-gray-100 px-3 py-2 flex items-center gap-2">
      <div class="flex-1 min-w-0 text-[12px] text-gray-500 flex items-center gap-1.5">
        <svg class="w-4 h-4 text-[#4A90D9] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/></svg>
        <span class="truncate">回复 {{ replyTarget.fromUserName }}: {{ replyTarget.content || '[图片]' }}</span>
      </div>
      <svg class="w-5 h-5 text-gray-400 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="replyTarget = null">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    </div>

    <!-- 底部输入区 -->
    <div v-if="isMember" class="bg-white border-t border-gray-200" style="padding-bottom: env(safe-area-inset-bottom)">
      <div class="flex items-center gap-2 px-3 pt-2 pb-1">
        <input ref="inputRef" v-model="inputMsg" class="flex-1 bg-[#F5F5F5] rounded-full h-[38px] px-4 text-[14px] outline-none text-gray-800 placeholder-gray-400" :placeholder="chatEnabled ? '输入消息...' : '全员禁言中'" :disabled="!chatEnabled" @keyup.enter="sendMsg" />
        <button
          class="h-[32px] px-4 rounded-full text-[13px] font-medium flex-shrink-0 transition-colors"
          :class="(inputMsg.trim() && chatEnabled) ? 'text-white' : 'bg-gray-200 text-gray-400'"
          :style="(inputMsg.trim() && chatEnabled) ? { background: '#4A90D9' } : {}"
          :disabled="!chatEnabled"
          @click="sendMsg"
        >发送</button>
      </div>
      <div class="flex items-center justify-around px-2 pb-1">
        <div
          v-for="item in toolbarItems"
          :key="item.key"
          class="flex flex-col items-center gap-0.5 cursor-pointer active:opacity-60 py-1 px-2 min-w-[48px]"
          :class="'text-gray-500'"
          @click="handleToolbarClick(item.key)"
        >
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" :d="item.icon"/></svg>
          <span class="text-[9px]">{{ item.label }}</span>
        </div>
      </div>
    </div>

    <div v-else class="bg-white border-t border-gray-100 px-4 py-3">
      <button class="w-full py-2.5 rounded-full text-[15px] font-medium text-white active:opacity-90" style="background: #4A90D9" @click="joinRoom">加入聊天室</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0
const myAvatar = userStore.info?.avatar || ''
const roomId = Number(route.params.roomId)

const goBack = () => {
  router.push('/appstore/game')
}

const room = ref<any>({})
const messages = ref<any[]>([])
const members = ref<any[]>([])
const memberCount = ref(0)
const myRole = ref('')
const isMember = ref(false)
const chatEnabled = ref(true)
const inputMsg = ref('')
const inputRef = ref<HTMLInputElement | null>(null)
const msgListRef = ref<HTMLElement | null>(null)
const showMemberPanel = ref(false)
const showRoomInfo = ref(false)
const loadingMembers = ref(false)
const adminTarget = ref<any>(null)
const previewImgUrl = ref('')
const editName = ref('')
const replyTarget = ref<any>(null)
const showAnnouncement = ref(false)
const editNameDialog = ref(false)
const editDescDialog = ref(false)
const editDescription = ref('')
const stats = ref<any[]>([])
const showFiles = ref(false)
const groupFiles = ref<any[]>([])
const showManagePanel = ref(false)
const muteDialogTarget = ref<any>(null)
const showCustomMute = ref(false)
const customMuteTarget = ref<any>(null)
const customMuteValue = ref('')
const customMuteUnit = ref('minute')
const confirmDialog = ref(false)
const confirmTitle = ref('')
const confirmMsg = ref('')
const confirmAction = ref('')
const confirmTarget = ref<any>(null)
const confirmAdminValue = ref(false)
const joinMode = ref('public')
const showJoinModeDialog = ref(false)
const memberLimit = ref(50)
const inviteDialog = ref(false)
const inviteAccount = ref('')
const showUpgradeDialog = ref(false)
const upgradeLimit = ref('')
const upgradeReason = ref('')
const showApprovalPanel = ref(false)
const joinRequests = ref<any[]>([])
const joinModeLabels: Record<string, string> = { public: '公开加入', approval: '审核加入', invite: '邀请加入', closed: '禁止加入' }
const toast = ref('')
let toastTimer: any = null
const showToast = (msg: string, duration = 2500) => {
  toast.value = msg
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, duration)
}
const showOrderPanel = ref(false)
const myOrders = ref<any[]>([])
const loadingOrders = ref(false)
const showOrderDetail = ref(false)
const orderDetail = ref<any>(null)

let longPressTimer: any = null

const menuMsg = ref<any>(null)
const reportMsg = ref<any>(null)
const reportReason = ref('')
const reportDetail = ref('')

const reportOptions = [
  { label: '垃圾广告', value: 'spam' },
  { label: '色情低俗', value: 'porn' },
  { label: '政治敏感', value: 'politics' },
  { label: '人身攻击', value: 'harassment' },
  { label: '诈骗信息', value: 'fraud' },
  { label: '其他', value: 'other' },
]
let pollTimer: any = null

const colorPool = ['#8B5CF6', '#EC4899', '#F97316', '#14B8A6', '#3B82F6', '#E11D48', '#6366F1', '#10B981', '#F59E0B']
const memberColorMap: Record<number, string> = {}
const memberColor = (userId: number) => {
  if (!memberColorMap[userId]) memberColorMap[userId] = colorPool[userId % colorPool.length]
  return memberColorMap[userId]
}

const ownerAndAdmins = computed(() => members.value.filter((m: any) => m.role === 'owner' || m.role === 'admin'))
const normalMembers = computed(() => members.value.filter((m: any) => m.role !== 'owner' && m.role !== 'admin'))
const topMembers = computed(() => members.value.slice(0, 5))
const manageOwnerAndAdmins = computed(() => members.value.filter((m: any) => m.role === 'owner' || m.role === 'admin'))
const manageNormalMembers = computed(() => members.value.filter((m: any) => m.role !== 'owner' && m.role !== 'admin'))
const pendingRequestCount = computed(() => joinRequests.value.filter((r: any) => r.status === 'pending').length)
const joinModeOptions = [
  { value: 'public', label: '公开加入', desc: '任何人都可以直接加入' },
  { value: 'approval', label: '审核加入', desc: '需要管理员审核后才能加入' },
  { value: 'invite', label: '邀请加入', desc: '只能通过管理员邀请加入' },
  { value: 'closed', label: '禁止加入', desc: '不允许任何人加入该群聊' },
]

const toolbarItems = [
  { key: 'at', label: '@成员', icon: 'M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207' },
  { key: 'image', label: '照片', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
  { key: 'order', label: '订单', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { key: 'redpacket', label: '红包', icon: 'M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0112 21a9.003 9.003 0 018.354-5.646z' },
  { key: 'report', label: '投诉', icon: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4.5c-.77-.833-2.694-.833-3.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z' },
]

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) avatarMap[`avatar:${match[1]}`] = (mod as any).default
}
const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar?.startsWith('http') || avatar?.startsWith('/uploads')) return avatar.replace(/^http:\/\//i, 'https://')
  return ''
}

const toUtcDate = (t: string) => { if (!t) return new Date(); const s = t.replace(' ', 'T'); if (/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/.test(s)) return new Date(s); return new Date(s + 'Z') }
const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const diff = Date.now() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  const now = new Date()
  if (d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate())
    return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
  return (d.getMonth() + 1) + '/' + d.getDate() + ' ' + d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
}

const fmtDate = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  return d.getFullYear() + '/' + (d.getMonth() + 1).toString().padStart(2, '0') + '/' + d.getDate().toString().padStart(2, '0')
}

const scrollToBottom = () => { nextTick(() => { if (msgListRef.value) msgListRef.value.scrollTop = msgListRef.value.scrollHeight }) }
const scrollToMsg = (msgId: number) => {
  nextTick(() => {
    const el = msgListRef.value?.querySelector(`[data-msg-id="${msgId}"]`)
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
  })
}

const loadRoom = async () => {
  try {
    const [roomRes, statsRes]: any[] = await Promise.all([
      request.get({ url: `/api/chat-rooms/${roomId}`, params: { userId: myUserId } }),
      request.get({ url: `/api/chat-rooms/${roomId}/stats` })
    ])
    room.value = roomRes; memberCount.value = roomRes.memberCount || 0; chatEnabled.value = roomRes.chatEnabled !== false
    if (roomRes.myMembership) { myRole.value = roomRes.myMembership.role || 'member'; isMember.value = roomRes.myMembership.status === 'active' }
    editName.value = roomRes.name || ''; editDescription.value = roomRes.description || ''
    joinMode.value = roomRes.join_mode || 'public'
    memberLimit.value = roomRes.member_limit || 50

    const s = statsRes || {}
    const total = s.totalMembers || memberCount.value || 1
    const malePct = total > 0 ? Math.round((s.maleCount || 0) / total * 100) : 0
    stats.value = [
      { label: '总人数', value: s.totalMembers || 0, unit: '人', percent: 100, color: '#F54545' },
      { label: '男性', value: malePct, unit: '%', percent: malePct, color: '#4A90D9' },
      { label: '今日消息', value: s.todayMessages || 0, unit: '条', percent: Math.min((s.todayMessages || 0) / Math.max(s.weekMessages || 1, 1) * 100, 100), color: '#8B5CF6' },
      { label: '群文件', value: s.fileCount || 0, unit: '个', percent: Math.min((s.fileCount || 0) * 10, 100), color: '#10B981' },
    ]
    if (isMember.value) { loadMessages(true); pollTimer = setInterval(() => loadMessages(), 3000) }
  } catch {}
}

const loadMessages = async (shouldScroll = false) => {
  try {
    const res: any = await request.get({ url: `/api/chat-rooms/${roomId}/messages`, params: { userId: myUserId, pageSize: 100 } })
    messages.value = (Array.isArray(res) ? res : (res.list || [])).map((m: any) => {
      if (m.messageType === 'order_card') {
        if (m.orderCard && typeof m.orderCard === 'string') {
          try { m.orderCard = JSON.parse(m.orderCard) } catch { m.orderCard = null }
        }
        if (!m.orderCard && typeof m.content === 'string') {
          try { m.orderCard = JSON.parse(m.content); m.content = '[订单]' } catch {}
        }
      }
      return m
    })
    if (shouldScroll) { await nextTick(); scrollToBottom() }
  } catch {}
}

const loadMembers = async () => {
  loadingMembers.value = true
  try {
    const res: any = await request.get({ url: `/api/chat-rooms/${roomId}/members`, params: { pageSize: 200 } })
    members.value = Array.isArray(res) ? res : (res.list || [])
    memberCount.value = res.total || members.value.length
  } catch {}
  loadingMembers.value = false
}

const joinRoom = async () => {
  try { 
    const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/join`, data: { userId: myUserId } })
    if (res && res.msg) alert(res.msg)
    if (res && res.code === 400) return
    if (!res || res.code === 200) { isMember.value = true; myRole.value = 'member'; loadMessages(true); pollTimer = setInterval(() => loadMessages(), 3000) }
  } catch {}
}

const sendMsg = async () => {
  const txt = inputMsg.value.trim(); if (!txt || !isMember.value || !chatEnabled.value) return
  const payload: any = { userId: myUserId, userName: userStore.info?.userName || userStore.info?.username || '用户', userAvatar: myAvatar, content: txt }
  if (replyTarget.value) { payload.replyToId = replyTarget.value.id; payload.replyToContent = replyTarget.value.content; payload.replyToUserName = replyTarget.value.fromUserName }
  try {
    const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/messages`, data: payload })
    const newMsg = res || { id: Date.now(), fromUserId: myUserId, content: txt, createTime: new Date().toISOString(), isRecalled: 0 }
    if (replyTarget.value) newMsg.replyTo = { id: replyTarget.value.id, content: replyTarget.value.content, userName: replyTarget.value.fromUserName }
    messages.value.push(newMsg); inputMsg.value = ''; replyTarget.value = null; scrollToBottom()
  } catch {}
}

const startReply = (msg: any) => { replyTarget.value = msg; inputRef.value?.focus() }
const recallMsg = async (msg: any) => {
  try { await request.put({ url: `/api/chat-rooms/${roomId}/messages/${msg.id}/recall`, data: { userId: myUserId } }); msg.isRecalled = 1; msg.content = ''; msg.imageUrl = '' } catch {}
}

const handleToolbarClick = (key: string) => {
  if (key === 'image') {
    const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*'
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0]; if (!file) return
      const fd = new FormData(); fd.append('file', file)
      try {
        const res: any = await request.post({ url: '/api/messages/upload-image', data: fd })
        if (res.url) {
          const payload: any = { userId: myUserId, userName: userStore.info?.userName || userStore.info?.username || '用户', userAvatar: myAvatar, content: '', imageUrl: res.url }
          if (replyTarget.value) { payload.replyToId = replyTarget.value.id; payload.replyToContent = replyTarget.value.content; payload.replyToUserName = replyTarget.value.fromUserName }
          const r: any = await request.post({ url: `/api/chat-rooms/${roomId}/messages`, data: payload })
          const newMsg = r || { id: Date.now(), fromUserId: myUserId, content: '', imageUrl: res.url, createTime: new Date().toISOString(), isRecalled: 0 }
          if (replyTarget.value) newMsg.replyTo = { id: replyTarget.value.id, content: replyTarget.value.content, userName: replyTarget.value.fromUserName }
          messages.value.push(newMsg); replyTarget.value = null; scrollToBottom()
        }
      } catch {}
    }
    input.click()
  } else if (key === 'redpacket') { inputMsg.value = '[恭喜发财，大吉大利]'; sendMsg() }
  else if (key === 'order') { loadMyOrders() }
  else if (key === 'report') { inputMsg.value = '[投诉反馈]' }
  else if (key === 'at') { loadMembers(); showMemberPanel.value = true }
  else if (key === 'announce') { inputMsg.value = '[群公告] '; inputRef.value?.focus() }
  else if (key === 'poll') { inputMsg.value = '[投票] '; inputRef.value?.focus() }
  else { inputMsg.value = '[该功能开发中]' }
}

const openMuteDialog = (m: any) => { muteDialogTarget.value = m }
const doMuteMember = async (m: any, duration: number) => {
  try { await request.put({ url: `/api/chat-rooms/${roomId}/mute/${m.userId}`, data: { operatorId: myUserId, type: duration >= 7200 ? 'permanent' : undefined, duration, operatorName: userStore.info?.userName, targetUserName: m.username } }); muteDialogTarget.value = null; loadMembers() } catch {}
}
const doUnmuteMember = async (m: any) => {
  try { await request.put({ url: `/api/chat-rooms/${roomId}/unmute/${m.userId}`, data: { operatorId: myUserId } }); muteDialogTarget.value = null; loadMembers() } catch {}
}
const applyCustomMute = () => {
  const val = Number(customMuteValue.value)
  if (!val || val <= 0) return
  let duration = val
  if (customMuteUnit.value === 'hour') duration = val * 60
  if (customMuteUnit.value === 'day') duration = val * 1440
  doMuteMember(customMuteTarget.value, duration)
  showCustomMute.value = false
  customMuteValue.value = ''
}

const kickMember = (m: any) => { confirmTarget.value = m; confirmAction.value = 'kick'; confirmTitle.value = `踢出 ${m.username}`; confirmMsg.value = '确定要将该成员踢出群聊吗？'; confirmDialog.value = true }

const banMember = (m: any) => { confirmTarget.value = m; confirmAction.value = 'ban'; confirmTitle.value = `拉黑 ${m.username}`; confirmMsg.value = '确定要永久拉黑该成员吗？拉黑后该用户将无法再加入群聊。'; confirmDialog.value = true }

const setAdmin = (m: any, isAdmin: boolean) => {
  confirmTarget.value = m
  confirmAdminValue.value = isAdmin
  confirmAction.value = 'setAdmin'
  confirmTitle.value = isAdmin ? `设为管理员` : `取消管理员`
  confirmMsg.value = isAdmin ? `确定要将 ${m.username} 设为管理员吗？` : `确定要取消 ${m.username} 的管理员身份吗？`
  confirmDialog.value = true
}

const doKickMember = async (m: any) => {
  try { await request.post({ url: `/api/chat-rooms/${roomId}/kick/${m.userId}`, data: { operatorId: myUserId, reason: '被管理员踢出', operatorName: userStore.info?.userName, targetUserName: m.username } }); loadMembers() } catch {}
}

const doBanMember = async (m: any) => {
  try { await request.post({ url: `/api/chat-rooms/${roomId}/ban/${m.userId}`, data: { operatorId: myUserId, reason: '被管理员拉黑', operatorName: userStore.info?.userName, targetUserName: m.username } }); loadMembers() } catch {}
}

const doSetAdmin = async (m: any, isAdmin: boolean) => {
  try {
    await request.put({ url: `/api/chat-rooms/${roomId}/set-admin/${m.userId}`, data: { operatorId: myUserId, isAdmin, operatorName: userStore.info?.userName, targetUserName: m.username } })
    loadMembers()
  } catch {}
}

const executeConfirm = () => {
  const m = confirmTarget.value
  confirmDialog.value = false
  if (!m) return
  if (confirmAction.value === 'kick') doKickMember(m)
  else if (confirmAction.value === 'ban') doBanMember(m)
  else if (confirmAction.value === 'setAdmin') doSetAdmin(m, confirmAdminValue.value)
  confirmTarget.value = null
  confirmAction.value = ''
}

const dissolveGroup = async () => {
  if (!confirm('确定要解散该群聊吗？此操作不可恢复！')) return
  try {
    await request.del({ url: `/api/chat-rooms/${roomId}/dissolve`, data: { userId: myUserId, userName: userStore.info?.userName } })
    showToast('群聊已解散')
    router.back()
  } catch {}
}

const transferOwnership = () => { loadMembers(); showManagePanel.value = true }

const doTransferOwnership = async (m: any) => {
  if (!confirm(`确定将群主转让给 ${m.username} 吗？`)) return
  try {
    await request.post({ url: `/api/chat-rooms/${roomId}/transfer/${m.userId}`, data: { operatorId: myUserId, operatorName: userStore.info?.userName, targetUserName: m.username } })
    myRole.value = 'member'
    showManagePanel.value = false
    loadMembers()
  } catch {}
}

const editGroupAvatar = () => {
  const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*'
  input.onchange = async (e: any) => {
    const file = e.target.files?.[0]; if (!file) return
    const fd = new FormData(); fd.append('file', file); fd.append('userId', String(myUserId))
    try {
      const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/avatar`, data: fd })
      if (res.avatar) room.value.avatar = res.avatar
    } catch { alert('头像更新失败') }
  }
  input.click()
}

const openManagePanel = () => { loadMembers(); showManagePanel.value = true }

// 订单相关
const iconBg = (s: string) => colorPool[((s || '').length + ((s || '').charCodeAt(0) || 0)) % colorPool.length]

const statusLabel = (s: string) => {
  const map: Record<string, string> = { shipped: '待收货', completed: '已完成', refunding: '退款中', refunded: '已退款' }
  return map[s] || s
}
const statusClass = (s: string) => {
  if (s === 'completed') return 'text-green-600'
  if (s === 'refunding') return 'text-orange-500'
  if (s === 'refunded') return 'text-gray-400'
  return 'text-gray-800'
}

const orderCardBg = (s: string) => {
  if (s === 'completed') return 'bg-gradient-to-r from-emerald-400 to-teal-500'
  if (s === 'shipped') return 'bg-gradient-to-r from-blue-400 to-indigo-500'
  if (s === 'refunding') return 'bg-gradient-to-r from-orange-400 to-red-400'
  if (s === 'refunded') return 'bg-gradient-to-r from-gray-400 to-gray-500'
  return 'bg-gradient-to-r from-purple-400 to-pink-500'
}

const statusDot = (s: string) => {
  if (s === 'completed') return 'bg-emerald-500'
  if (s === 'shipped') return 'bg-blue-500'
  if (s === 'refunding') return 'bg-orange-500'
  if (s === 'refunded') return 'bg-gray-400'
  return 'bg-purple-500'
}

const statusTextClass = (s: string) => {
  if (s === 'completed') return 'text-emerald-600'
  if (s === 'shipped') return 'text-blue-600'
  if (s === 'refunding') return 'text-orange-600'
  if (s === 'refunded') return 'text-gray-500'
  return 'text-purple-600'
}

const fmtDateTime = (t: string) => {
  if (!t) return '-'
  return fmtDate(t) + ' ' + fmtTime(t)
}

const loadMyOrders = async () => {
  showOrderPanel.value = true
  loadingOrders.value = true
  try {
    const res: any = await request.get({ url: '/api/messages/orders', params: { userId: myUserId } })
    const data = res.data || res
    myOrders.value = Array.isArray(data) ? data : (data.list || [])
  } catch {}
  loadingOrders.value = false
}

const sendOrderCard = async (order: any) => {
  try {
    const payload: any = {
      userId: myUserId,
      userName: userStore.info?.userName || userStore.info?.username || '用户',
      userAvatar: myAvatar,
      content: '[订单]',
      messageType: 'order_card',
      orderCard: JSON.stringify(order)
    }
    const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/messages`, data: payload })
    const newMsg = res || { id: Date.now(), fromUserId: myUserId, content: '[订单]', messageType: 'order_card', orderCard: order, createTime: new Date().toISOString(), isRecalled: 0, fromUserName: userStore.info?.userName || '用户', fromUserAvatar: myAvatar }
    if (newMsg.orderCard) {
      messages.value.push(newMsg)
    } else {
      newMsg.orderCard = order
      messages.value.push(newMsg)
    }
    showOrderPanel.value = false
    scrollToBottom()
  } catch {}
}

const viewOrderDetail = (card: any) => {
  orderDetail.value = card
  showOrderDetail.value = true
}

const handleMemberClick = (m: any) => {
  if (m.userId === myUserId) return
  if (['owner', 'admin'].includes(myRole.value) && m.role !== 'owner') { adminTarget.value = m }
  else { inputMsg.value += `@${m.username} `; inputRef.value?.focus() }
  showMemberPanel.value = false
}

const handleAvatarClick = (msg: any) => { inputMsg.value += `@${msg.fromUserName} `; inputRef.value?.focus() }

const leaveRoom = async () => {
  try { await request.post({ url: `/api/chat-rooms/${roomId}/leave`, data: { userId: myUserId } }); isMember.value = false; myRole.value = ''; showRoomInfo.value = false; if (pollTimer) clearInterval(pollTimer) } catch {}
}

const toggleChat = async () => {
  const newVal = !chatEnabled.value
  try { await request.put({ url: `/api/chat-rooms/${roomId}`, data: { userId: myUserId, chatEnabled: newVal, userName: userStore.info?.userName } }); chatEnabled.value = newVal } catch {}
}

const updateRoomSettings = async () => {
  try { await request.put({ url: `/api/chat-rooms/${roomId}`, data: { userId: myUserId, name: editName.value, userName: userStore.info?.userName } }); room.value.name = editName.value; editNameDialog.value = false } catch {}
}

const updateRoomDesc = async () => {
  try { await request.put({ url: `/api/chat-rooms/${roomId}`, data: { userId: myUserId, description: editDescription.value, userName: userStore.info?.userName } }); room.value.description = editDescription.value; editDescDialog.value = false } catch {}
}

const updateJoinMode = async (mode: string) => {
  try {
    await request.put({ url: `/api/chat-rooms/${roomId}`, data: { userId: myUserId, joinMode: mode, userName: userStore.info?.userName } })
    joinMode.value = mode
    showJoinModeDialog.value = false
    showToast('加群方式已更新')
  } catch {}
}

const openApprovalPanel = async () => {
  showApprovalPanel.value = true
  try {
    const res: any = await request.get({ url: `/api/chat-rooms/${roomId}/join-requests`, params: { status: 'pending' } })
    joinRequests.value = res.data || []
  } catch {}
}

const handleJoinRequest = async (req: any, status: string) => {
  try {
    await request.put({ url: `/api/chat-rooms/${roomId}/join-requests/${req.id}`, data: { userId: myUserId, status, reviewComment: '' } })
    req.status = status
    await openApprovalPanel()
  } catch {}
}

const doInvite = async () => {
  if (!inviteAccount.value.trim()) return
  try {
    const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/invite`, data: { userId: myUserId, targetAccount: inviteAccount.value.trim() } })
    showToast(res.msg || '邀请成功')
    if (res.code === 200) inviteDialog.value = false
  } catch {}
}

const doUpgradeRequest = async () => {
  const limit = Number(upgradeLimit.value)
  if (!limit || limit <= memberLimit.value) return alert('请输入大于当前上限的值')
  try {
    const res: any = await request.post({ url: `/api/chat-rooms/${roomId}/limit-upgrade`, data: { userId: myUserId, requestLimit: limit, reason: upgradeReason.value } })
    showToast(res.msg || '已提交申请')
    if (res.code === 200) { showUpgradeDialog.value = false; upgradeLimit.value = ''; upgradeReason.value = '' }
  } catch {}
}

const copyGroupId = () => {
  navigator.clipboard?.writeText(String(roomId)).then(() => { alert('群号已复制') }).catch(() => {})
}

const groupFileCount = computed(() => groupFiles.value.length)
const groupFilePreview = computed(() => groupFiles.value.filter((f: any) => f.fileType === 'image').map((f: any) => f.fileUrl))

const collectGroupFiles = async () => {
  try {
    const res: any = await request.get({ url: `/api/chat-rooms/${roomId}/files`, params: { pageSize: 200 } })
    groupFiles.value = (res.list || [])
  } catch {}
}

const uploadGroupFile = () => {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = '*/*'
  input.onchange = async (e: any) => {
    const file = e.target.files?.[0]
    if (!file) return
    const fd = new FormData()
    fd.append('file', file)
    fd.append('userId', String(myUserId))
    fd.append('userName', userStore.info?.userName || userStore.info?.username || '用户')
    try {
      const res: any = await request.post({
        url: `/api/chat-rooms/${roomId}/files`,
        data: fd
      })
      if (res.code === 200 && res.data) {
        groupFiles.value.unshift(res.data)
      } else {
        alert(res.msg || '上传失败')
      }
    } catch { alert('上传失败') }
  }
  input.click()
}

const previewGroupFile = (f: any) => {
  if (f.fileType === 'image') {
    previewImgUrl.value = f.fileUrl
  } else if (f.fileType === 'video') {
    window.open(f.fileUrl, '_blank')
  } else {
    window.open(f.fileUrl, '_blank')
  }
}

const shareGroup = () => {
  const url = `${window.location.origin}/#/chatroom/${roomId}`
  navigator.clipboard?.writeText(url).then(() => { alert('群链接已复制，可分享给好友') }).catch(() => {})
}

const onMsgTouchStart = (e: TouchEvent, msg: any) => {
  longPressTimer = setTimeout(() => { menuMsg.value = msg }, 500)
}
const onMsgTouchEnd = (_e: TouchEvent) => { if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null } }
const onMsgTouchCancel = () => { if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null } }
const closeMenu = () => { menuMsg.value = null }

const showReportDialog = (msg: any) => { menuMsg.value = null; reportMsg.value = msg; reportReason.value = ''; reportDetail.value = '' }
const submitReport = async () => {
  if (!reportReason.value || !reportMsg.value) return
  try {
    await request.post({ url: `/api/chat-rooms/${roomId}/messages/${reportMsg.value.id}/report`, data: { userId: myUserId, reason: reportReason.value, detail: reportDetail.value } })
    reportMsg.value.reportStatus = 'reported'
  } catch {}
  reportMsg.value = null; reportReason.value = ''; reportDetail.value = ''
}
const copyMsg = async (msg: any) => { try { await navigator.clipboard.writeText(msg.content) } catch {} }

onMounted(() => { loadRoom() })
onUnmounted(() => { if (pollTimer) clearInterval(pollTimer) })
</script>
