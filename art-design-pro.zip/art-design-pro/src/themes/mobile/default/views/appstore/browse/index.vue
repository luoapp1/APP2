<template>
  <div class="page">
    <!-- 搜索 + 投稿按钮 -->
    <div class="search-row">
      <div class="search-pill" @click="$router.push('/community/search')">
        <svg class="search-lens" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
        <span class="search-hint">番茄免费小说 | 233乐园</span>
      </div>
      <div class="update-btn" @click="$router.push('/appstore/submissions')">
        <span>投稿</span>
      </div>
    </div>

    <!-- 频道 Tab -->
    <div class="channel-tabs" ref="channelTabsRef">
      <div
        v-for="tab in channelTabs" :key="tab"
        class="channel-item"
        :class="{ active: activeChannel === tab }"
        @click="activeChannel = tab"
      >{{ tab }}
        <div v-if="activeChannel === tab" class="channel-indicator" />
      </div>
      <div style="flex:1" />
    </div>

    <main class="main" ref="mainRef" @scroll="onScroll">
      <!-- ========== 推荐 Tab: 应用内容 ========== -->
      <template v-if="activeChannel === '推荐'">
      <!-- 精品推荐轮播 -->
       <div v-if="featuredApps.length" class="featured-wrapper">
        <div class="featured-scroll" ref="featuredRef" @scroll="onFeatureScroll">
          <div
            v-for="(app, idx) in featuredApps"
            :key="app.id"
            class="featured-card"
            @click="openDetail(app.id)"
          >
            <div class="featured-bg" />
            <div class="featured-left">
              <span class="banner-badge">精品推荐</span>
              <h2 class="banner-title">{{ app.name }}</h2>
              <p class="banner-sub">{{ app.description || '热门的精品应用' }}</p>
            </div>
            <div class="featured-right">
              <div class="banner-app-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                <img v-if="app.icon" :src="fixImgUrl(app.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
              <button class="banner-install" @click.stop="openDetail(app.id)">安装</button>
            </div>
          </div>
        </div>
        <div class="banner-dots">
          <span v-for="(_, idx) in featuredApps" :key="idx" class="dot" :class="{ active: currentFeature === idx }" />
        </div>
      </div>
      <!-- 默认 Banner（无精品推荐时） -->
      <div v-else class="banner" @click="$router.push('/appstore/category')">
        <div class="banner-bg" />
        <div class="banner-left">
          <span class="banner-badge">发现好应用</span>
          <h2 class="banner-title">探索热门应用</h2>
          <p class="banner-sub">发现更多精彩应用和游戏</p>
        </div>
        <div class="banner-right">
          <div class="banner-app-icon">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          </div>
          <button class="banner-install" @click.stop="$router.push('/appstore/category')">安装</button>
        </div>
      </div>

      <!-- 今日热点 -->
      <section class="section">
        <h3 class="section-title">今日热点</h3>
        <div class="grid-5">
          <div v-for="app in hotApps" :key="app.id" class="grid-card" @click="openDetail(app.id)">
            <div class="grid-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span class="grid-icon-fb">{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="app.icon" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="grid-name">{{ app.name }}</div>
            <button class="install-btn" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
      </section>

      <!-- 流行风向 -->
      <section class="section">
        <h3 class="section-title">流行风向</h3>
        <!-- 上半部分：宫格 -->
        <div class="grid-5">
          <div v-for="app in trendingGrid" :key="'g'+app.id" class="grid-card" @click="openDetail(app.id)">
            <div class="grid-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span class="grid-icon-fb">{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="app.icon" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="grid-name">{{ app.name }}</div>
            <button class="install-btn" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
        <!-- 下半部分：列表 -->
        <div class="list-section">
          <div v-for="app in trendingList" :key="'l'+app.id" class="list-card" @click="openDetail(app.id)">
            <div class="list-icon" style="position:relative" :style="{ background: app.iconBgColor || iconColor(app.name) }">
              <span>{{ (app.name || '?')[0] }}</span>
              <img v-if="app.icon" :src="app.icon" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="list-body">
              <div class="list-title">{{ app.name }}</div>
              <div class="list-desc">{{ app.description || '热门应用推荐' }}</div>
              <div class="list-tags">
                <span class="list-tag" v-for="t in (app.tags || []).slice(0,3)" :key="t">{{ t }}</span>
              </div>
            </div>
            <button class="install-btn list-install" @click.stop="openDetail(app.id)">安装</button>
          </div>
        </div>
      </section>

      <div style="height:80px" />
      </template>

      <!-- ========== 商城 Tab: 商品列表 ========== -->
      <template v-if="activeChannel === '商城'">
        <!-- 商城头图 -->
        <div class="mall-hero">
          <div class="mall-hero-bg" />
          <div class="mall-hero-text">
            <div class="mall-hero-title">好物商城</div>
            <div class="mall-hero-sub">精选好货 · 优惠直达</div>
          </div>
          <div class="mall-hero-icons">
            <div class="mall-hero-icon">🔥</div>
            <div class="mall-hero-icon">⚡</div>
          </div>
        </div>

        <!-- 商城搜索栏 -->
        <div class="mall-search-row">
          <div class="mall-search-box" @click="$router.push('/community/search')">
            <svg class="mall-search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" stroke-width="2"/><path d="M21 21l-4.35-4.35" stroke-width="2" stroke-linecap="round"/></svg>
            <span class="mall-search-placeholder">搜索你想要的商品</span>
          </div>
        </div>

        <!-- 一级分类标签 -->
        <div class="mall-cat-scroll">
          <div
            v-for="c in topCategories" :key="c.id"
            class="mall-cat-pill"
            :class="{ on: activeCatId === c.id }"
            @click="switchCat(c.id)"
          >{{ c.name }}</div>
        </div>

        <!-- 二级分类筛选项 -->
        <div class="mall-sub-scroll" v-if="activeCatId !== 0 && subCategories.length > 1">
          <div
            v-for="s in subCategories" :key="s.id"
            class="mall-sub-item"
            :class="{ on: activeSubId === s.id }"
            @click="activeSubId = s.id; loadMallProducts()"
          >
            <img v-if="s.icon" :src="fixImgUrl(s.icon)" class="mall-sub-icon" @error="($event.target as HTMLImageElement).style.display='none'" />
            <span>{{ s.name }}</span>
          </div>
        </div>

        <!-- 排序栏 -->
        <div class="mall-sort-row">
          <div
            v-for="s in mallSorts" :key="s.key"
            class="mall-sort-item"
            :class="{ on: mallSortKey === s.key }"
            @click="setMallSort(s.key)"
          >{{ s.label }}</div>
          <div style="flex:1" />
          <span class="mall-count">{{ mallProducts.length }}件商品</span>
        </div>

        <!-- 商品列表 -->
        <div v-if="mallLoading" class="flex justify-center py-20">
          <div class="w-6 h-6 border-2 border-[#FF6B6B] border-t-transparent rounded-full animate-spin"/>
        </div>
        <template v-else>
          <div v-if="mallProducts.length === 0" class="mall-empty">
            <svg class="w-14 h-14 text-[#E0E0E0]" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
            </svg>
            <span>暂无商品</span>
          </div>
          <div class="mall-grid">
            <div v-for="p in mallProducts" :key="p.id" class="mall-card" @click="openMallDetail(p.id)">
              <div class="mall-card-img-wrap">
                <div class="mall-card-img mall-card-img-fb">
                  <span class="mall-card-fb-text">{{ p.name }}</span>
                </div>
                <img v-if="p.coverImage" :src="fixImgUrl(p.coverImage)" class="mall-card-img" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
                <div v-if="p.salesCount > 100" class="mall-card-badge hot">热卖</div>
                <div v-else-if="p.originalPrice > p.price" class="mall-card-badge coupon">券</div>
              </div>
              <div class="mall-card-body">
                <div class="mall-card-name">{{ p.name }}</div>
                <div class="mall-card-tags" v-if="(p.tags || []).length">
                  <span v-for="t in (p.tags || []).slice(0,3)" :key="t" class="mall-card-tag">{{ t }}</span>
                </div>
                <div class="mall-card-price-row">
                  <span class="mall-card-price-currency">{{ priceCurrency(p) }}</span>
                  <span class="mall-card-price-num">{{ priceValue(p) }}</span>
                  <span v-if="p.originalPrice > p.price" class="mall-card-original">{{ priceOriginal(p) }}</span>
                </div>
                <div class="mall-card-footer">
                  <span class="mall-card-sold">已售 {{ p.salesCount || 0 }}</span>
                  <span class="mall-card-buy">去购买</span>
                </div>
              </div>
            </div>
          </div>
          <div style="height:20px" />
        </template>
      </template>

      <!-- ========== 广场 Tab: 帖子列表 ========== -->
      <template v-if="activeChannel === '广场'">
        <div v-if="postLoading" class="flex justify-center py-20">
          <div class="w-6 h-6 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
        </div>
        <template v-else>
          <div v-if="postList.length === 0" class="flex flex-col items-center py-20 gap-2">
            <svg class="w-12 h-12 text-[#DDD]" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
            </svg>
            <span class="text-[13px] text-[#BBB]">还没有帖子</span>
          </div>
          <div v-for="(post, i) in postList" :key="post.id">
            <div class="post-card" @click="openPostDetail(post.id)">
              <!-- Author -->
              <div class="post-author">
                <div style="position: relative; width: 52px; height: 52px; flex-shrink: 0;">
                  <img
                    v-if="activeFrameUrl && post.userId === currentUserId"
                    :src="activeFrameUrl"
                    style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
                  />
                  <div class="post-avatar" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1;">
                    <span class="post-avatar-fb" :style="{background:'#508DFF',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',width:'100%',height:'100%',borderRadius:'50%',fontSize:'20px'}">{{ (post.userName||'?')[0] }}</span>
                    <img v-if="post.userAvatar" :src="post.userAvatar" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
                  </div>
                </div>
                <div class="post-author-info">
                  <div class="post-author-row">
                    <span class="post-username">{{ post.userName }}</span>
                    <img v-if="post.userExpLevelIcon" :src="post.userExpLevelIcon" style="width:34px;height:34px;object-fit:contain;flex-shrink:0;" @error="($event.target as HTMLImageElement).style.display='none'" />
                    <span v-else-if="post.userExpLevelName" class="post-level-badge" :style="{ color: post.userExpLevelTextColor || '#FFFFFF', background: post.userExpLevelBgColor || '#508DFF' }">{{ post.userExpLevelName }}</span>
                    <span v-if="post.userIsVerified" class="post-verified">认证</span>
                    <span v-if="post.isEssence" class="post-badge post-badge-essence">精</span>
                    <span v-if="post.isHot" class="post-badge post-badge-hot">热</span>
                    <span v-if="post.customBadge" class="post-badge post-badge-custom">{{ post.customBadge }}</span>
                  </div>
                  <div class="post-author-meta">
                    <span class="post-level-name" :style="{ color: post.userLevelTextColor || '#508DFF' }">{{ post.userLevelName || '普通用户' }}</span>
                    <template v-if="post.userTitleName"><span class="post-meta-dot">·</span><span :style="{ color: post.userTitleColor || '#999' }">{{ post.userTitleName }}</span></template>
                    <template v-if="!post.userTitleName && post.device"><span class="post-meta-dot">·</span><span class="post-device">{{ post.device }}</span></template>
                  </div>
                </div>
              </div>

              <!-- Title -->
              <div class="post-title">{{ post.title }}</div>

              <!-- Content -->
              <div v-if="post.content" class="post-content">{{ stripContent(post.content) }}</div>

              <!-- Images -->
              <div v-if="post.images && post.images.length" class="post-images">
                <div v-if="post.images.length === 1" class="post-img-single">
                  <img :src="fixImgUrl(post.images[0])" class="w-full object-cover" style="max-height:180px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                </div>
                <div v-else-if="post.images.length === 2" class="post-img-grid2">
                  <img v-for="(img, idx) in post.images.slice(0,2)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:140px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                </div>
                <div v-else class="post-img-grid3">
                  <img v-for="(img, idx) in post.images.slice(0,3)" :key="idx" :src="img" class="w-full object-cover aspect-square" style="max-height:110px" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                </div>
              </div>

              <!-- Resource Card -->
              <div v-if="post.hasResource" class="post-resource">
                <div class="post-resource-left">
                  <span class="post-resource-title">{{ post.title }}</span>
                </div>
                <div class="post-resource-right">
                  <span class="post-resource-price">需要支付{{ post.coinCount || 1 }}硬币</span>
                </div>
              </div>

              <!-- Tags + Stats -->
              <div class="post-footer">
                <div v-if="post.tags && post.tags.length" class="post-tags">
                  <span v-for="tag in post.tags.slice(0,3)" :key="tag" class="post-tag">{{ tag }}</span>
                </div>
                <div class="post-stats">
                  <span>{{ fmtRelativeTime(post.createTime) }}</span>
                  <span class="post-stat">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                    {{ fmtCount(post.viewCount) }}
                  </span>
                  <span class="post-stat">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                    {{ fmtCount(post.commentCount) }}
                  </span>
                  <span class="post-stat">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                    {{ fmtCount(post.likeCount) }}
                  </span>
                  <span v-if="post.images && post.images.length" class="post-stat">
                    <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path stroke-linecap="round" stroke-linejoin="round" d="M21 15l-5-5L5 21"/></svg>
                    {{ post.images.length }}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div v-if="postLoadingMore" class="flex justify-center py-6">
            <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
          </div>
          <div v-else-if="!postNoMore && postList.length > 0" class="text-center py-5 text-[12px] text-[#CCC]">上拉加载更多</div>
          <div v-else-if="postNoMore && postList.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
        </template>
      </template>
    </main>

    <!-- 回到顶部 -->
    <transition name="fade-up">
      <div v-if="showBackTop" class="back-top" @click="scrollToTop">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7"/></svg>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import { fetchAppList, fetchHotToday, fetchTrendingWeek, fetchPostComment, fetchPostTip, fetchCategoryList } from '@/api/appstore'
import { fetchCommunityPosts } from '@/api/community'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const keyword = ref('')
const activeChannel = ref('推荐')
const appList = ref<any[]>([])
const total = ref(0)
const loading = ref(true)
const activeFrameUrl = ref('')
const currentUserId = computed(() => userStore.info?.userId || 0)
const showSearch = ref(false)
const searchInput = ref<HTMLInputElement>()
const mainRef = ref<HTMLElement>()
const showBackTop = ref(false)
const featuredApps = ref<any[]>([])
const currentFeature = ref(0)
const featuredRef = ref<HTMLElement>()

// ---- 广场帖子状态 ----
const postList = ref<any[]>([])
const postPage = ref(1)
const postLoading = ref(false)
const postLoadingMore = ref(false)
const postNoMore = ref(false)
const postTotal = ref(0)

// ---- 商城商品状态 ----
const mallProducts = ref<any[]>([])
const mallLoading = ref(false)
const topCategories = ref<any[]>([])
const subCategories = ref<any[]>([])
const activeCatId = ref(0)
const activeSubId = ref(0)
const mallSortKey = ref('newest')
const mallSorts = [
  { key: 'newest', label: '最新' },
  { key: 'hot', label: '最热' },
  { key: 'sales', label: '销量' },
  { key: 'price', label: '售价' },
]
const openMallDetail = (id: number) => router.push(`/appstore/mall-detail/${id}`)
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const priceCurrency = (p: any) => p.priceType === 'points' ? '' : '¥'
const priceValue = (p: any) => p.price
const priceOriginal = (p: any) => p.priceType === 'points' ? p.originalPrice + '积分' : '¥' + p.originalPrice

const loadCategories = async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/categories' })
    const all = res || []
    topCategories.value = [{ id: 0, name: '全部' }, ...all.filter((c: any) => c.parentId === 0)]
    if (topCategories.value.length) activeCatId.value = topCategories.value[0].id
  } catch {}
}

const loadMallProducts = async () => {
  mallLoading.value = true
  try {
    const params: any = { status: 'published', pageSize: 50 }
    if (activeCatId.value) params.categoryId = activeCatId.value
    if (activeSubId.value) params.categoryId = activeSubId.value
    const res: any = await request.get({ url: '/api/mall/products', params })
    mallProducts.value = res?.list || []
    // 按排序
    if (mallSortKey.value === 'sales') mallProducts.value.sort((a:any,b:any)=>(b.salesCount||0)-(a.salesCount||0))
    else if (mallSortKey.value === 'price') mallProducts.value.sort((a:any,b:any)=>(a.price||0)-(b.price||0))
  } catch {} finally { mallLoading.value = false }
}

const switchCat = (cid: number) => {
  activeCatId.value = cid
  activeSubId.value = 0
  if (cid === 0) {
    subCategories.value = []
  } else {
    const all = allSubCats.filter((s: any) => s.parentId === cid)
    subCategories.value = [{ id: 0, name: '全部' }, ...all]
  }
  loadMallProducts()
}

let allSubCats: any[] = []
loadCategories().then(async () => {
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    allSubCats = res || []
    subCategories.value = [{ id: 0, name: '全部' }, ...allSubCats.filter((c: any) => c.parentId === activeCatId.value)]
  } catch {}
  loadMallProducts()
})

const setMallSort = (k: string) => { mallSortKey.value = k; loadMallProducts() }

watch(activeChannel, (ch) => {
  if (ch === '商城' && mallProducts.value.length === 0) loadMallProducts()
  else if (ch === '广场' && postList.value.length === 0) loadPosts(true)
})

const onScroll = () => {
  const el = mainRef.value
  if (!el) return
  showBackTop.value = el.scrollTop > 300
  // 广场模式下滚动加载更多
  if (activeChannel.value === '广场' && !postNoMore.value && !postLoadingMore.value) {
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 80) {
      loadPosts(false)
    }
  }
}

const scrollToTop = () => {
  mainRef.value?.scrollTo({ top: 0, behavior: 'smooth' })
}

const channelTabs = ['推荐', '商城', '广场']


const hotApps = ref<any[]>([])
const trendingGrid = ref<any[]>([])
const trendingList = ref<any[]>([])

const colorPool = ['#4F8AF7','#6C5CE7','#00BFA5','#F97316','#EC4899','#EF4444','#8B5CF6','#10B981','#3B82F6','#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const loadApps = async () => {
  loading.value = true
  try {
    const params: Record<string, any> = { page: 1, pageSize: 100, status: '1' }
    if (keyword.value) params.keyword = keyword.value
    const res: any = await fetchAppList(params)
    appList.value = res.list || []
    total.value = res.total || 0
    loadFeatured()
    const hotRes: any = await fetchHotToday(5)
    hotApps.value = hotRes.list || []
    const trendRes: any = await fetchTrendingWeek(9)
    trendingGrid.value = (trendRes.list || []).slice(0, 5)
    trendingList.value = (trendRes.list || []).slice(5, 9)
  } catch {} finally { loading.value = false }
}

const loadFeatured = () => {
  featuredApps.value = appList.value.filter(a => a.isFeatured).slice(0, 3)
  currentFeature.value = 0
  nextTick(() => {
    if (featuredRef.value) featuredRef.value.scrollLeft = 0
  })
}

const onFeatureScroll = () => {
  if (!featuredRef.value) return
  const container = featuredRef.value
  currentFeature.value = Math.round(container.scrollLeft / container.clientWidth)
}

const doSearch = () => { showSearch.value = false; loadApps() }
const openDetail = (id: number) => router.push(`/appstore/browse/detail/${id}`)

// ---- 广场帖子 ----
function stripContent(text: string) {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

function openPostDetail(postId: number) {
  router.push(`/community/post/${postId}`)
}

watch(activeChannel, (val) => {
  if (val === '广场' && postList.value.length === 0) {
    loadPosts(true)
  }
})

async function loadPosts(reset = false) {
  if (reset) { postPage.value = 1; postNoMore.value = false; postLoading.value = true }
  else { postLoadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sort: 'hot', page: postPage.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => ({
      ...p,
      tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
      images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || [])
    }))
    if (reset) { postList.value = parsed; postTotal.value = res?.data?.total || res?.total || 0 }
    else { postList.value.push(...parsed) }
    if (list.length < 20) postNoMore.value = true
    postPage.value++
  } catch {} finally { postLoading.value = false; postLoadingMore.value = false }
}

onMounted(() => {
  loadApps()
  loadActiveFrame()
})

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}
</script>

<style scoped>
.page {
  min-height: 100vh;
  background: var(--app-page-bg);
  display: flex;
  flex-direction: column;
  padding-bottom: 68px;
}

/* 搜索行 */
.search-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px 14px;
}

.search-pill {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fff;
  border-radius: 24px;
  padding: 11px 16px;
  box-shadow: 0 1px 2px rgba(0,0,0,.04);
  cursor: pointer;
}

.search-lens { width: 18px; height: 18px; color: #9ca3af; flex-shrink: 0; }

.search-hint {
  font-size: 14px;
  color: #9ca3af;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.update-btn {
  position: relative;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 9px 14px;
  border-radius: 22px;
  background: #eaf0fb;
  color: #3D7BEA;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;
}

.update-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 16px;
  height: 16px;
  border-radius: 8px;
  background: #F13A3A;
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 4px;
  line-height: 1;
}

/* 频道 Tab */
.channel-tabs {
  display: flex;
  align-items: center;
  padding: 4px 16px 6px;
  gap: 22px;
  position: sticky;
  top: 0;
  background: var(--app-page-bg);
  z-index: 10;
}

.channel-item {
  position: relative;
  font-size: 16px;
  color: #6b7280;
  cursor: pointer;
  padding-bottom: 8px;
  font-weight: 500;
  transition: color .15s;
}
.channel-item.active { color: #111; font-weight: 700; }

.channel-indicator {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 22px;
  height: 3px;
  border-radius: 2px;
  background: #3D7BEA;
}

/* 主内容 */
.main {
  flex: 1;
  overflow-y: auto;
  padding: 0 16px;
}

/* Banner */
.banner {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  padding: 22px 18px;
  display: flex;
  cursor: pointer;
  margin: 4px 0 14px;
}

.banner-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #1a3a5c 0%, #2d5a87 40%, #c49b7a 100%);
  z-index: 0;
}

.banner-left {
  position: relative;
  z-index: 1;
  flex: 1;
  min-width: 0;
}

.banner-badge {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 5px;
  background: rgba(255,255,255,.25);
  color: #fff;
  font-size: 11px;
  font-weight: 600;
  margin-bottom: 10px;
}

.banner-title {
  font-size: 20px;
  font-weight: 800;
  color: #fff;
  margin: 0 0 6px;
  line-height: 1.3;
}

.banner-sub {
  font-size: 13px;
  color: rgba(255,255,255,.75);
  margin: 0;
}

.banner-right {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: 14px;
}

.banner-app-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  background: rgba(255,255,255,.2);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  overflow: hidden;
}
.banner-app-icon img { width: 100%; height: 100%; object-fit: cover; }
.banner-app-icon svg { width: 26px; height: 26px; }

.banner-install {
  padding: 6px 18px;
  border-radius: 16px;
  background: #fff;
  color: #111;
  font-size: 13px;
  font-weight: 700;
  border: none;
  cursor: pointer;
}

.banner-dots {
  position: absolute;
  bottom: 14px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 6px;
  z-index: 1;
}
.dot {
  width: 6px;
  height: 6px;
  border-radius: 3px;
  background: rgba(255,255,255,.4);
  transition: width .3s ease, background .3s ease;
}
.dot.active { background: #fff; width: 18px; }

/* 精品推荐轮播 */
.featured-wrapper {
  position: relative;
  margin: 4px 0 14px;
  border-radius: 20px;
  overflow: hidden;
}
.featured-scroll {
  display: flex;
  overflow-x: auto;
  scroll-snap-type: x mandatory;
  -webkit-overflow-scrolling: touch;
  border-radius: 20px;
  scroll-behavior: smooth;
}
.featured-scroll::-webkit-scrollbar { display: none; }
.featured-card {
  flex: 0 0 100%;
  scroll-snap-align: start;
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  padding: 22px 18px;
  display: flex;
  cursor: pointer;
  min-width: 100%;
}
.featured-card:not(:last-child)::after {
  content: '';
  position: absolute;
  right: 1px;
  top: 16px;
  bottom: 16px;
  width: 1px;
  background: rgba(0,0,0,.08);
  border-radius: 0.5px;
  z-index: 2;
}
.featured-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #1a3a5c 0%, #2d5a87 40%, #c49b7a 100%);
  z-index: 0;
}
.featured-left {
  position: relative;
  z-index: 1;
  flex: 1;
  min-width: 0;
}
.featured-right {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: 14px;
}
.featured-wrapper .banner-dots {
  position: absolute;
  bottom: 12px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 6px;
  z-index: 2;
}


/* Section */
.section { margin-bottom: 22px; }

.section-title {
  font-size: 19px;
  font-weight: 800;
  color: #111;
  margin: 0 0 12px;
  padding: 0 2px;
}

/* 宫格 */
.grid-5 {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}

.grid-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  transition: transform .12s;
}
.grid-card:active { transform: scale(.95); }

.grid-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: 0 2px 6px rgba(0,0,0,.06);
  margin-bottom: 6px;
}
.grid-icon img { width: 100%; height: 100%; object-fit: cover; }
.grid-icon span { color: #fff; font-size: 20px; font-weight: 700; }

.grid-name {
  font-size: 12px;
  color: #222;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width: 100%;
  line-height: 1.3;
  margin-bottom: 6px;
}

.install-btn {
  padding: 4px 14px;
  border-radius: 12px;
  background: #eaf0fb;
  color: #3D7BEA;
  font-size: 11px;
  font-weight: 600;
  border: none;
  cursor: pointer;
}

/* 列表 */
.list-section {
  margin-top: 14px;
}

.list-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 0;
  cursor: pointer;
  transition: opacity .12s;
  border-bottom: 1px solid rgba(0,0,0,.03);
}
.list-card:last-child { border-bottom: none; }
.list-card:active { opacity: .7; }

.list-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 0 2px 6px rgba(0,0,0,.06);
}
.list-icon img { width: 100%; height: 100%; object-fit: cover; }
.list-icon span { color: #fff; font-size: 22px; font-weight: 700; }

.list-body {
  flex: 1;
  min-width: 0;
}
.list-title {
  font-size: 15px;
  font-weight: 700;
  color: #111;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list-desc {
  font-size: 12px;
  color: #9ca3af;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list-tags {
  display: flex;
  gap: 4px;
  margin-top: 4px;
}
.list-tag {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
  background: #f3f4f6;
  color: #6b7280;
}

.list-install {
  flex-shrink: 0;
}

/* 搜索弹窗 */
.search-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.25);
  z-index: 200;
}
.search-panel { background: #fff; padding: 8px 16px 14px; }
.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #f3f4f6;
  border-radius: 24px;
  padding: 10px 16px;
}
.search-field {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-size: 15px;
  color: #111;
}
.search-field::placeholder { color: #9ca3af; }
.search-close {
  flex-shrink: 0;
  border: none;
  background: none;
  font-size: 14px;
  color: #3D7BEA;
  cursor: pointer;
}

/* 回到顶部 */
.back-top {
  position: fixed;
  bottom: 80px;
  right: 16px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 4px 16px rgba(0,0,0,.12);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #3D7BEA;
  cursor: pointer;
  z-index: 100;
  transition: transform .15s, box-shadow .15s;
}
.back-top:active { transform: scale(.92); box-shadow: 0 2px 8px rgba(0,0,0,.1); }

.fade-up-enter-active,
.fade-up-leave-active { transition: opacity .25s ease, transform .25s ease; }
.fade-up-enter-from,
.fade-up-leave-to { opacity: 0; transform: translateY(12px); }

/* ========== 广场帖子卡片 ========== */
.post-card {
  background: #fff;
  margin: 0 4px 10px;
  border-radius: 16px;
  padding: 16px;
  cursor: pointer;
  transition: background .15s;
}
.post-card:active { background: #FAFAFA; }

.post-author {
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
.post-avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 700;
  font-size: 14px;
  overflow: hidden;
}
.post-author-info { flex: 1; min-width: 0; }
.post-author-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}
.post-username { font-size: 14px; color: #222; font-weight: 600; }
.post-level-badge { font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 700; line-height: 1.4; }
.post-verified { font-size: 9px; padding: 1px 6px; border-radius: 4px; font-weight: 700; color: #059669; background: #ECFDF5; line-height: 1.4; }
.post-badge { font-size: 10px; padding: 1px 6px; border-radius: 4px; font-weight: 700; line-height: 1.4; }
.post-badge-essence { color: #EA580C; background: #FFF7ED; }
.post-badge-hot { color: #DC2626; background: #FEF2F2; }
.post-badge-custom { color: #C62828; background: #FCE4EC; }

.post-author-meta {
  display: flex;
  align-items: center;
  gap: 2px;
  margin-top: 2px;
  font-size: 12px;
}
.post-level-name { color: #508DFF; font-weight: 500; }
.post-meta-dot { color: #DDD; }
.post-device { color: #B0B0B0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.post-title {
  margin-top: 10px;
  font-size: 16px;
  color: #111;
  font-weight: 700;
  line-height: 1.45;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.post-content {
  margin-top: 4px;
  font-size: 13px;
  color: #AAA;
  line-height: 1.6;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.post-images { margin-top: 10px; }
.post-img-single { border-radius: 10px; overflow: hidden; }
.post-img-grid2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px; border-radius: 10px; overflow: hidden; }
.post-img-grid3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; border-radius: 10px; overflow: hidden; }

.post-resource {
  margin-top: 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  background: #F8FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 10px;
}
.post-resource-left { flex: 1; min-width: 0; }
.post-resource-title { font-size: 13px; color: #333; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; }
.post-resource-right { flex-shrink: 0; margin-left: 8px; }
.post-resource-price { font-size: 12px; color: #F97316; font-weight: 600; white-space: nowrap; }

.post-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
}
.post-tags {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
}
.post-tag {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 20px;
  color: #508DFF;
  background: #EEF2FF;
  font-weight: 500;
  flex-shrink: 0;
  max-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.post-stats {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: #B8B8B8;
  margin-left: auto;
  flex-shrink: 0;
}
.post-stat {
  display: inline-flex;
  align-items: center;
  gap: 2px;
}

.post-divider { display: none; }

/* ========== 商城 ========== */
/* 商城头图 */
.mall-hero {
  position: relative; margin: 8px 12px 0; height: 100px;
  border-radius: 16px; overflow: hidden; display: flex;
  align-items: center; justify-content: space-between; padding: 0 20px;
}
.mall-hero-bg {
  position: absolute; inset: 0;
  background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 50%, #FFB347 100%);
}
.mall-hero-text { position: relative; z-index: 1; }
.mall-hero-title { font-size: 22px; font-weight: 800; color: #fff; line-height: 1.2; }
.mall-hero-sub { font-size: 12px; color: rgba(255,255,255,.85); margin-top: 2px; }
.mall-hero-icons { position: relative; z-index: 1; display: flex; gap: 12px; }
.mall-hero-icon { font-size: 28px; filter: drop-shadow(0 2px 4px rgba(0,0,0,.15)); }

.mall-search-row { padding: 10px 12px 0; }
.mall-search-box {
  display: flex; align-items: center; gap: 8px;
  height: 40px; padding: 0 16px; background: #F5F5F5;
  border-radius: 20px; cursor: pointer;
}
.mall-search-icon { width: 18px; height: 18px; color: #999; flex-shrink: 0; }
.mall-search-placeholder { font-size: 14px; color: #BBB; }

.mall-cat-scroll {
  display: flex; gap: 8px; padding: 12px 12px 6px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.mall-cat-scroll::-webkit-scrollbar { display: none; }
.mall-cat-pill {
  flex-shrink: 0; padding: 6px 16px; font-size: 13px;
  color: #666; background: #F5F5F5; border-radius: 20px; cursor: pointer;
  transition: all .15s; white-space: nowrap;
}
.mall-cat-pill.on { color: #fff; background: linear-gradient(135deg, #FF6B6B, #FF8E53); font-weight: 600; }

.mall-sub-scroll {
  display: flex; gap: 8px; padding: 0 12px 10px;
  overflow-x: auto; -webkit-overflow-scrolling: touch;
}
.mall-sub-scroll::-webkit-scrollbar { display: none; }
.mall-sub-item {
  flex-shrink: 0; display: flex; align-items: center; gap: 4px;
  padding: 5px 12px; font-size: 12px; color: #888;
  background: #F5F5F5; border-radius: 14px; cursor: pointer;
  transition: all .15s; white-space: nowrap;
}
.mall-sub-item.on { color: #FF6B6B; background: #FFF0F0; font-weight: 500; }
.mall-sub-icon { width: 18px; height: 18px; border-radius: 4px; object-fit: cover; }

.mall-sort-row {
  display: flex; align-items: center; gap: 6px; padding: 6px 12px 10px;
  border-bottom: 1px solid #f2f2f2;
}
.mall-sort-item {
  padding: 4px 12px; font-size: 12px; color: #999;
  border-radius: 12px; cursor: pointer; transition: all .15s;
}
.mall-sort-item.on { color: #FF6B6B; background: #FFF0F0; font-weight: 600; }
.mall-count { font-size: 11px; color: #BBB; flex-shrink: 0; }

.mall-empty { display: flex; flex-direction: column; align-items: center; padding: 60px 0; gap: 10px; }
.mall-empty span { font-size: 14px; color: #BBB; }

/* 商品网格 */
.mall-grid {
  display: grid; grid-template-columns: repeat(2, 1fr);
  gap: 8px; padding: 8px 10px;
}
.mall-card {
  background: #fff; border-radius: 10px; overflow: hidden;
  box-shadow: 0 0 0 1px rgba(0,0,0,.04), 0 2px 6px rgba(0,0,0,.05);
  cursor: pointer; transition: transform .15s, box-shadow .15s;
}
.mall-card:active { transform: scale(.97); box-shadow: 0 4px 14px rgba(0,0,0,.1); }
.mall-card-img-wrap { position: relative; width: 100%; padding-top: 80%; overflow: hidden; background: #f8f8f8; }
.mall-card-img {
  position: absolute; inset: 0; width: 100%; height: 100%;
  object-fit: cover; transition: transform .25s;
}
.mall-card:active .mall-card-img { transform: scale(1.03); }
.mall-card-img-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(180deg, #FF8A80 0%, #FF5252 50%, #D32F2F 100%);
}
.mall-card-fb-text {
  color: rgba(255,255,255,.55); font-size: 22px; font-weight: 900;
  max-width: 80%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.mall-card-badge {
  position: absolute; top: 0; left: 0;
  font-size: 10px; padding: 3px 8px; border-radius: 0 0 8px 0;
  background: linear-gradient(135deg, #FF4757, #FF6B6B);
  color: #fff; font-weight: 600; letter-spacing: .5px;
}
.mall-card-badge.hot { background: linear-gradient(135deg, #FF4757, #FF6B6B); }
.mall-card-badge.coupon { background: linear-gradient(135deg, #FF9500, #FF6B3D); }
.mall-card-body { padding: 6px 9px 8px; display: flex; flex-direction: column; gap: 3px; }
.mall-card-name {
  font-size: 13px; font-weight: 600; color: #222; line-height: 1.4;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
  overflow: hidden;
}
.mall-card-tags { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 1px; }
.mall-card-tag {
  font-size: 9px; padding: 2px 6px; border-radius: 3px;
  background: #FFF0E6; color: #FF7D37; white-space: nowrap; font-weight: 500;
}
.mall-card-tag:nth-child(2) { background: #F0EBFF; color: #7C5CFC; }
.mall-card-tag:nth-child(3) { background: #E8FAF0; color: #00B578; }
.mall-card-price-row { display: flex; align-items: baseline; gap: 3px; flex-wrap: wrap; }
.mall-card-price-currency { font-size: 12px; font-weight: 700; color: #FF4757; }
.mall-card-price-num { font-size: 18px; font-weight: 800; color: #FF4757; line-height: 1; }
.mall-card-original { font-size: 10px; color: #CCC; text-decoration: line-through; margin-left: 2px; }
.mall-card-footer { display: flex; align-items: center; justify-content: space-between; }
.mall-card-sold { font-size: 10px; color: #BBB; }
.mall-card-buy {
  font-size: 10px; color: #fff; background: linear-gradient(135deg, #FF6B6B, #FF8E53);
  padding: 3px 10px; border-radius: 10px; font-weight: 600;
}
</style>
