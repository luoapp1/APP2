<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">帖子审核</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- 统计 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-center">
          <div class="text-2xl font-bold text-[#F59E0B]">{{ total }}</div>
          <div class="text-[11px] text-gray-400 mt-1">待审核帖子</div>
        </div>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-3 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="showDetail(item)">
            <div class="flex items-start gap-3">
              <img :src="$fixImgUrl(item.userAvatar)" class="w-10 h-10 rounded-full object-cover flex-shrink-0 bg-gray-100" @error="($event.target as HTMLImageElement).src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22%3E%3Ccircle cx=%2212%22 cy=%228%22 r=%224%22 fill=%22%23ccc%22/%3E%3Cpath d=%22M4 20c0-4 4-7 8-7s8 3 8 7%22 fill=%22%23ccc%22/%3E%3C/svg%3E'" />
              <div class="flex-1 min-w-0">
                <div class="text-sm font-semibold text-gray-800 line-clamp-1 mb-1">{{ item.title }}</div>
                <div class="flex items-center gap-2 text-xs text-gray-400 mb-1">
                  <span>{{ item.userName }}</span>
                  <span>ID:{{ item.id }}</span>
                  <span v-if="item.sectionId" class="px-1 py-0.5 bg-gray-100 rounded text-[10px]">板块{{ item.sectionId }}</span>
                  <span v-if="item.hasResource" class="px-1 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">含资源</span>
                  <span v-if="item.contentPermission === 'pay'" class="px-1 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">付费{{ item.contentPrice }}元</span>
                  <span v-if="item.contentPermission === 'vip'" class="px-1 py-0.5 bg-amber-50 text-amber-600 rounded text-[10px]">VIP</span>
                  <span v-if="item.contentPermission === 'points'" class="px-1 py-0.5 bg-green-50 text-green-600 rounded text-[10px]">{{ item.contentPrice }}积分</span>
                </div>
                <div class="text-xs text-gray-300">{{ item.createTime }}</div>
                <div class="text-xs text-gray-500 line-clamp-2 mt-1" v-html="stripHtml(item.content)" />
              </div>
              <div class="flex gap-1 flex-shrink-0" @click.stop>
                <button class="h-7 px-3 text-xs rounded-lg bg-green-50 text-green-600 active:bg-green-100 font-medium" @click="approveItem(item)">通过</button>
                <button class="h-7 px-3 text-xs rounded-lg bg-red-50 text-red-500 active:bg-red-100 font-medium" @click="showReject(item)">驳回</button>
              </div>
            </div>
            <!-- 图片预览 -->
            <div v-if="item.images && item.images.length > 0" class="flex gap-1.5 mt-2 ml-13 overflow-x-auto">
              <img v-for="(img, i) in item.images" :key="i" :src="$fixImgUrl(img)" class="w-16 h-16 rounded-lg object-cover flex-shrink-0 border border-gray-100" />
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="page <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="page--; fetchData()">上一页</button>
            <span class="text-xs text-gray-400">{{ page }}/{{ totalPages }}</span>
            <button :disabled="page >= totalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="page++; fetchData()">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ total }} 条</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <span class="text-sm">暂无待审核帖子</span>
        </div>
      </div>
    </div>

    <!-- 帖子详情弹窗 -->
    <div v-if="detailVisible" class="fixed inset-0 z-50 flex flex-col bg-white" @click.self="detailVisible=false">
      <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
        <button class="text-gray-400" @click="detailVisible=false">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        </button>
        <span class="text-sm font-bold text-gray-800">帖子详情</span>
        <div class="w-5" />
      </div>

      <div class="flex-1 overflow-y-auto" v-if="detailItem">
        <!-- 作者信息 -->
        <div class="p-4 border-b border-gray-50">
          <div class="flex items-center gap-3">
            <img :src="$fixImgUrl(detailItem.userAvatar)" class="w-11 h-11 rounded-full object-cover bg-gray-100" @error="($event.target as HTMLImageElement).src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22%3E%3Ccircle cx=%2212%22 cy=%228%22 r=%224%22 fill=%22%23ccc%22/%3E%3Cpath d=%22M4 20c0-4 4-7 8-7s8 3 8 7%22 fill=%22%23ccc%22/%3E%3C/svg%3E'" />
            <div>
              <div class="text-sm font-semibold text-gray-800">{{ detailItem.userName }}</div>
              <div class="text-xs text-gray-400">用户ID: {{ detailItem.userId }} · 板块ID: {{ detailItem.sectionId || '-' }}</div>
            </div>
          </div>
        </div>

        <!-- 标题 -->
        <div class="px-4 pt-4">
          <h2 class="text-base font-bold text-gray-900 leading-relaxed">{{ detailItem.title }}</h2>
          <div class="flex items-center gap-2 mt-2 text-xs text-gray-400">
            <span>{{ detailItem.createTime }}</span>
            <span v-if="detailItem.hasResource" class="px-1.5 py-0.5 bg-blue-50 text-blue-500 rounded text-[10px]">{{ detailItem.resourceType || '含资源' }}</span>
          </div>
        </div>

        <!-- 付费内容卡片 -->
        <div v-if="detailItem.contentPermission !== 'public'" class="px-4 pt-3">
          <div class="rounded-xl p-3.5 border-2" :class="detailItem.contentPermission === 'vip' ? 'border-amber-200 bg-amber-50' : 'border-blue-200 bg-blue-50'">
            <div class="flex items-center gap-2 mb-2">
              <svg v-if="detailItem.contentPermission === 'vip'" class="w-5 h-5 text-amber-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              <svg v-else class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              <span class="text-sm font-bold" :class="detailItem.contentPermission === 'vip' ? 'text-amber-700' : 'text-blue-700'">
                {{ detailItem.contentPermission === 'vip' ? 'VIP 专属内容' : detailItem.contentPermission === 'pay' ? '付费阅读内容' : detailItem.contentPermission === 'points' ? '积分阅读内容' : '付费内容' }}
              </span>
            </div>
            <div class="space-y-1.5">
              <div class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">内容价格</span>
                <span class="font-semibold" :class="detailItem.contentPermission === 'vip' ? 'text-amber-600' : 'text-blue-600'">
                  <template v-if="detailItem.contentPermission === 'vip'">VIP会员专享</template>
                  <template v-else>{{ detailItem.contentPrice || 0 }} {{ detailItem.contentPriceType === 'money' ? '元' : detailItem.contentPriceType === 'points' ? '积分' : detailItem.contentPriceType }}</template>
                </span>
              </div>
              <div v-if="detailItem.contentPermission === 'pay' || detailItem.contentPermission === 'points'" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">免费预览</span>
                <span class="text-gray-700">{{ detailItem.freeRead ? '前' + detailItem.freeCount + '字免费' : '无免费预览' }}</span>
              </div>
              <div v-if="detailItem.hasResource" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">资源价格</span>
                <span class="font-semibold text-orange-600">{{ detailItem.resourcePrice || 0 }} {{ detailItem.resourcePriceType === 'money' ? '元' : detailItem.resourcePriceType === 'points' ? '积分' : detailItem.resourcePriceType === 'free' ? '免费' : detailItem.resourcePriceType }}</span>
              </div>
              <div v-if="detailItem.extractCode" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">提取码</span>
                <code class="bg-white px-1.5 py-0.5 rounded text-[#FF4757] font-mono text-xs">{{ detailItem.extractCode }}</code>
              </div>
              <div v-if="detailItem.accessPassword" class="flex items-center gap-2 text-xs">
                <span class="text-gray-500 w-16 flex-shrink-0">访问密码</span>
                <code class="bg-white px-1.5 py-0.5 rounded text-[#FF4757] font-mono text-xs">{{ detailItem.accessPassword }}</code>
                <span v-if="detailItem.accessPasswordTips" class="text-gray-400">（{{ detailItem.accessPasswordTips }}）</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 内容 -->
        <div class="px-4 py-3">
          <div class="text-xs text-gray-400 mb-2">正文（免费可见部分）</div>
          <div class="text-sm text-gray-700 leading-relaxed prose prose-sm max-w-none" v-html="detailItem.content || '<span class=\'text-gray-400\'>无正文内容</span>'" />
        </div>

        <!-- 付费隐藏内容 -->
        <div v-if="detailItem.hiddenContent" class="px-4 pb-3">
          <div class="rounded-xl p-3.5 bg-gray-50 border border-dashed border-gray-300">
            <div class="flex items-center gap-1.5 text-xs text-gray-400 mb-2">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
              <span>付费后可见内容</span>
            </div>
            <div class="text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none" v-html="detailItem.hiddenContent" />
          </div>
        </div>

        <!-- 图片 -->
        <div v-if="detailItem.images && detailItem.images.length > 0" class="px-4 pb-3">
          <div class="text-xs text-gray-400 mb-2">附件图片 ({{ detailItem.images.length }})</div>
          <div class="grid grid-cols-3 gap-2">
            <img v-for="(img, i) in detailItem.images" :key="i" :src="$fixImgUrl(img)" class="w-full aspect-square rounded-lg object-cover border border-gray-100" />
          </div>
        </div>
      </div>

      <!-- 操作栏 -->
      <div class="flex gap-3 px-4 py-3 border-t border-gray-100 bg-white flex-shrink-0" v-if="detailItem">
        <button class="flex-1 h-11 rounded-xl bg-green-500 text-white text-sm font-semibold active:opacity-80" @click="approveItem(detailItem)">审核通过</button>
        <button class="flex-1 h-11 rounded-xl bg-red-500 text-white text-sm font-semibold active:opacity-80" @click="showReject(detailItem); detailVisible=false">驳回帖子</button>
      </div>
    </div>

    <!-- 驳回原因弹窗 -->
    <div v-if="rejectVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="rejectVisible=false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <button class="text-gray-400" @click="rejectVisible=false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">驳回帖子</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="doReject">确认驳回</button>
        </div>
        <div class="p-4">
          <label class="text-xs text-gray-500 mb-1 block">驳回原因</label>
          <textarea v-model="rejectReason" rows="3" placeholder="请输入驳回原因（选填）" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'PostReviewMobile' })

const toastMsg = ref('')
const toastType = ref<'success'|'error'>('success')
let toastTimer: any
const showToast = (m: string, t: 'success'|'error'='success') => {
  toastMsg.value = m; toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toastMsg.value = '', 2000)
}

const loading = ref(false)
const list = ref<any[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = 20
const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize)))

const detailVisible = ref(false)
const detailItem = ref<any>(null)

const rejectVisible = ref(false)
const rejectTarget = ref<any>(null)
const rejectReason = ref('')

async function fetchData() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/community/admin/posts/pending', params: { page: page.value, pageSize } })
    list.value = res?.list || []
    total.value = res?.total || 0
  } catch (e: any) {
    showToast('加载失败: ' + (e.message || e), 'error')
  }
  loading.value = false
}

function stripHtml(html: string): string {
  if (!html) return ''
  return html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').substring(0, 100)
}

function showDetail(item: any) {
  detailItem.value = item
  detailVisible.value = true
}

async function approveItem(item: any) {
  try {
    await request.post({ url: `/api/community/admin/post/${item.id}/approve` })
    showToast('已通过审核', 'success')
    detailVisible.value = false
    fetchData()
  } catch (e: any) {
    showToast('操作失败: ' + (e.message || e), 'error')
  }
}

function showReject(item: any) {
  rejectTarget.value = item
  rejectReason.value = ''
  rejectVisible.value = true
}

async function doReject() {
  if (!rejectTarget.value) return
  try {
    await request.post({
      url: `/api/community/admin/post/${rejectTarget.value.id}/reject`,
      data: { reason: rejectReason.value || '内容不符合规范' }
    })
    showToast('已驳回', 'success')
    rejectVisible.value = false
    rejectTarget.value = null
    fetchData()
  } catch (e: any) {
    showToast('操作失败: ' + (e.message || e), 'error')
  }
}

onMounted(() => fetchData())
</script>
