<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">订单管理</span>
    </div>

    <div class="filters">
      <select v-model="filterStatus" @change="loadList" class="filter-select">
        <option value="">全部状态</option>
        <option value="pending">待支付</option>
        <option value="paid">已支付</option>
        <option value="shipped">已发货</option>
        <option value="completed">已完成</option>
        <option value="cancelled">已取消</option>
        <option value="refunding">退款中</option>
        <option value="refunded">已退款</option>
      </select>
      <input v-model="keyword" placeholder="搜索订单号/收货人..." class="search-input" @keydown.enter="loadList" />
    </div>

    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>
    <div v-else class="list">
      <div v-if="orders.length === 0" class="empty">暂无订单</div>
      <div v-for="o in orders" :key="o.id" class="item" @click="selected = o">
        <div class="item-hd">
          <span class="order-no">{{ o.orderNo }}</span>
          <span class="order-status" :class="'st-' + o.status">{{ statusMap[o.status] || o.status }}</span>
        </div>
        <div v-for="it in (o.items || [])" :key="it.id" class="order-item">
          <img v-if="it.image" :src="fixImgUrl(it.image)" class="order-img" />
          <div v-else class="order-img order-img-fb">{{ (it.productName || '?')[0] }}</div>
          <div class="order-info">
            <div class="order-name">{{ it.productName }}</div>
            <div v-if="it.optionName" class="order-opt">{{ it.optionName }}</div>
            <div class="order-price">¥{{ it.price }} x {{ it.quantity }}</div>
          </div>
        </div>
        <div class="item-ft">
          <span>共{{ o.items?.length || 0 }}件 合计: <b>¥{{ o.totalAmount }}</b></span>
          <div class="actions">
            <button v-if="o.status === 'paid'" class="act-btn ship" v-auth="'handle'" @click.stop="showShipDialog(o)">发货</button>
            <button v-if="o.status === 'paid'" class="act-btn cancel" v-auth="'handle'" @click.stop="updateStatus(o, 'cancelled')">取消</button>
            <button v-if="o.status === 'shipped'" class="act-btn complete" v-auth="'handle'" @click.stop="updateStatus(o, 'completed')">确认完成</button>
          </div>
        </div>
        <div v-if="o.receiverName" class="item-addr">
          收货人: {{ o.receiverName }} {{ o.receiverPhone }}<br/>{{ o.receiverAddress }}
        </div>
        <div v-if="o.logisticsCompany" class="item-addr">
          物流: {{ o.logisticsCompany }} - {{ o.logisticsNo }}
        </div>
      </div>
    </div>

    <div v-if="total > pageSize" class="pager">
      <button :disabled="page <= 1" @click="page--; loadList()">上一页</button>
      <span>{{ page }} / {{ Math.ceil(total / pageSize) }}</span>
      <button :disabled="page >= Math.ceil(total / pageSize)" @click="page++; loadList()">下一页</button>
    </div>

    <!-- 发货弹窗 -->
    <div v-if="shipDialog" class="modal-overlay" @click.self="shipDialog = null">
      <div class="modal">
        <div class="modal-title">填写物流信息</div>
        <div class="field">
          <label>物流公司</label>
          <input v-model="shipCompany" placeholder="如：顺丰速运" class="input" />
        </div>
        <div class="field">
          <label>物流单号</label>
          <input v-model="shipNo" placeholder="请输入快递单号" class="input" />
        </div>
        <div class="modal-actions">
          <button @click="shipDialog = null" class="btn-cancel">取消</button>
          <button @click="doShip" v-auth="'handle'" class="btn-confirm">确认发货</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''

const orders = ref<any[]>([])
const loading = ref(true)
const keyword = ref('')
const filterStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const shipDialog = ref<any>(null)
const shipCompany = ref('')
const shipNo = ref('')

const statusMap: Record<string, string> = {
  pending: '待支付', paid: '已支付', shipped: '已发货',
  completed: '已完成', cancelled: '已取消', refunding: '退款中', refunded: '已退款'
}

async function loadList() {
  loading.value = true
  try {
    const params: any = { page: page.value, pageSize: pageSize.value }
    if (keyword.value) params.keyword = keyword.value
    if (filterStatus.value) params.status = filterStatus.value
    const res: any = await request.get({ url: '/api/mall/orders', params })
    orders.value = res?.list || []
    total.value = res?.total || 0
  } catch {} finally { loading.value = false }
}

async function updateStatus(o: any, status: string) {
  try {
    await request.put({ url: `/api/mall/orders/${o.id}/status`, data: { status } })
    o.status = status
  } catch {}
}

function showShipDialog(o: any) {
  shipDialog.value = o
  shipCompany.value = ''
  shipNo.value = ''
}

async function doShip() {
  if (!shipCompany.value || !shipNo.value) return alert('请填写完整的物流信息')
  try {
    await request.put({ url: `/api/mall/orders/${shipDialog.value.id}/status`, data: {
      status: 'shipped', logisticsCompany: shipCompany.value, logisticsNo: shipNo.value
    }})
    shipDialog.value.status = 'shipped'
    shipDialog.value.logisticsCompany = shipCompany.value
    shipDialog.value.logisticsNo = shipNo.value
    shipDialog.value = null
  } catch {}
}

onMounted(loadList)
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }

.filters { display: flex; gap: 8px; padding: 10px 14px; background: #fff; border-bottom: 1px solid #f0f0f0; }
.filter-select { flex: 1; padding: 6px 8px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 12px; background: #fff; }
.search-input { flex: 2; padding: 6px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 12px; }

.loading, .empty { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }

.list { padding: 8px 0; }
.item { background: #fff; margin: 0 10px 8px; border-radius: 12px; padding: 12px; }
.item-hd { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.order-no { font-size: 13px; font-weight: 600; color: #333; }
.order-status { font-size: 11px; padding: 2px 8px; border-radius: 4px; font-weight: 600; }
.st-pending { background: #FFF3E0; color: #E65100; }
.st-paid { background: #E3F2FD; color: #1565C0; }
.st-shipped { background: #E8F5E9; color: #2E7D32; }
.st-completed { background: #F3E5F5; color: #7B1FA2; }
.st-cancelled { background: #EEEEEE; color: #757575; }
.st-refunding { background: #FFF8E1; color: #F57F17; }
.st-refunded { background: #EFEBE9; color: #5D4037; }

.order-item { display: flex; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f5f5f5; }
.order-img { width: 44px; height: 44px; border-radius: 8px; object-fit: cover; flex-shrink: 0; }
.order-img-fb { background: #508DFF; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 16px; }
.order-info { flex: 1; min-width: 0; }
.order-name { font-size: 13px; font-weight: 600; color: #222; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.order-opt { font-size: 11px; color: #999; }
.order-price { font-size: 13px; color: #FF4757; font-weight: 600; margin-top: 2px; }

.item-ft { display: flex; justify-content: space-between; align-items: center; padding-top: 8px; font-size: 12px; color: #666; }
.item-ft b { color: #FF4757; }
.actions { display: flex; gap: 6px; }
.act-btn { border: none; padding: 4px 10px; border-radius: 6px; font-size: 11px; cursor: pointer; }
.act-btn.ship { background: #E3F2FD; color: #1565C0; }
.act-btn.cancel { background: #f5f5f5; color: #999; }
.act-btn.complete { background: #E8F5E9; color: #2E7D32; }

.item-addr { font-size: 11px; color: #999; margin-top: 6px; padding-top: 6px; border-top: 1px solid #f5f5f5; line-height: 1.5; }

.pager { display: flex; justify-content: center; align-items: center; gap: 16px; padding: 16px; font-size: 13px; color: #666; }
.pager button { border: 1px solid #ddd; background: #fff; padding: 6px 14px; border-radius: 8px; cursor: pointer; font-size: 12px; }
.pager button:disabled { opacity: 0.4; cursor: default; }

/* Modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100; }
.modal { background: #fff; width: 100%; max-width: 500px; border-radius: 16px 16px 0 0; padding: 20px; }
.modal-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; }
.modal-actions { display: flex; gap: 10px; margin-top: 16px; }
.btn-cancel { flex: 1; padding: 10px; border: 1px solid #ddd; background: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
.btn-confirm { flex: 1; padding: 10px; border: none; background: #FF6B6B; color: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
</style>
