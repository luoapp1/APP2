<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-2 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">文件仓库</span>
    </div>

    <div v-if="toastMsg" class="fixed top-14 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <!-- 路径面包屑 -->
    <div class="bg-white mx-3 mt-3 rounded-xl px-3 py-2.5 flex items-center gap-1 overflow-x-auto whitespace-nowrap">
      <template v-for="(seg, i) in pathSegments" :key="i">
        <span v-if="i > 0" class="text-gray-300 mx-0.5">/</span>
        <span
          v-if="i < pathSegments.length - 1"
          class="text-xs px-1.5 py-0.5 rounded"
          :class="i === 0 ? 'text-blue-500 bg-blue-50' : 'text-gray-500 bg-gray-100'"
          @click="navigateTo(i)"
        >{{ seg }}</span>
        <span v-else class="text-xs font-semibold text-gray-700">{{ seg }}</span>
      </template>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="loading" class="flex justify-center py-16">
        <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
      </div>
      <template v-else>
        <!-- 子目录 -->
        <div v-if="dirs.length > 0" class="mx-3 mt-3">
          <div class="text-xs font-semibold text-gray-500 mb-2 px-1">子目录 ({{ dirs.length }})</div>
          <div class="flex gap-2 overflow-x-auto pb-1">
            <div
              v-for="d in dirs"
              :key="d.name"
              class="flex-shrink-0 flex flex-col items-center gap-1 px-4 py-3 rounded-xl bg-white shadow-sm active:bg-blue-50 min-w-[80px]"
              @click="enterDir(d.name)"
            >
              <svg class="w-7 h-7 text-blue-500" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>
              <span class="text-[10px] text-gray-600 leading-tight text-center break-all line-clamp-2">{{ d.name }}</span>
            </div>
          </div>
        </div>

        <!-- 统计 -->
        <div class="mx-3 mt-3 flex gap-2 text-[10px] text-gray-400 px-1">
          <span>{{ totalFiles }} 个文件</span>
          <span>|</span>
          <span>第 {{ page }}/{{ totalPages }} 页</span>
        </div>

        <!-- 文件网格（两列） -->
        <div v-if="files.length > 0" class="mx-3 mt-2 grid grid-cols-2 gap-2">
          <div
            v-for="f in files"
            :key="f.path"
            class="bg-white rounded-xl overflow-hidden shadow-sm relative group"
          >
            <button
              v-auth="'delete'"
              class="absolute top-1.5 right-1.5 z-10 w-6 h-6 rounded-full bg-white/80 flex items-center justify-center active:bg-red-50"
              @click.stop="confirmDelete(f)"
            >
              <svg class="w-3.5 h-3.5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
            <div class="w-full aspect-square flex items-center justify-center bg-[#fafafa] relative" @click="openDetail(f)">
              <img v-if="f.isImage" :src="$fixImgUrl(f.url)" class="w-full h-full object-cover" loading="lazy" />
              <svg v-else-if="f.isVideo" class="w-10 h-10 text-green-500" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              <svg v-else-if="f.isAudio" class="w-10 h-10 text-orange-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
              <svg v-else class="w-10 h-10 text-gray-300" fill="currentColor" viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4zM8 13h8v2H8v-2zm0 4h8v2H8v-2zm0-8h3v2H8V9z"/></svg>
              <span class="absolute bottom-1 right-1 text-[9px] text-white bg-black/50 px-1 rounded">{{ f.ext }}</span>
            </div>
            <div class="px-2 py-2">
              <div class="text-[11px] font-medium text-gray-700 truncate">{{ f.name }}</div>
              <div class="text-[10px] text-gray-400 mt-0.5">{{ formatSize(f.size) }}</div>
            </div>
          </div>
        </div>

        <!-- 底部文件信息 -->
        <div v-if="files.length > 0" class="mx-3 mt-3 bg-white rounded-xl px-3 py-2.5">
          <div class="flex items-center justify-between gap-2">
            <span class="text-[11px] text-gray-400">共 {{ totalFiles }} 个文件</span>
            <div class="flex gap-2">
              <button :disabled="page<=1" class="text-[11px] px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 disabled:opacity-30" @click="goPage(page-1)">上一页</button>
              <span class="text-[11px] text-gray-500 self-center font-medium">{{ page }}/{{ totalPages }}</span>
              <button :disabled="page>=totalPages" class="text-[11px] px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 disabled:opacity-30" @click="goPage(page+1)">下一页</button>
            </div>
          </div>
          <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-50">
            <span class="text-[11px] text-gray-400">每页</span>
            <div class="flex gap-1">
              <button
                v-for="ps in [12, 20, 30]"
                :key="ps"
                class="text-[11px] w-8 h-6 rounded-md"
                :class="pageSize === ps ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-500'"
                @click="setPageSize(ps)"
              >{{ ps }}</button>
            </div>
          </div>
        </div>

        <div v-if="files.length === 0 && !loading && dirs.length === 0" class="flex flex-col items-center py-16 text-gray-400">
          <span class="text-sm">此目录下暂无文件</span>
        </div>
      </template>
    </div>

    <!-- 文件详情底部弹窗 -->
    <teleport to="body">
      <div v-if="detailVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="detailVisible = false">
        <div class="bg-white rounded-2xl w-full max-w-lg max-h-[75vh] overflow-y-auto" @click.stop>
          <div class="sticky top-0 bg-white rounded-t-2xl border-b border-gray-100 px-4 py-3 flex items-center justify-between z-10">
            <span class="text-sm font-semibold text-gray-800 truncate pr-4">文件详情</span>
            <svg class="w-5 h-5 text-gray-400 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="detailVisible = false"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </div>
          <div v-if="detailFile" class="p-4 space-y-4">
            <!-- 预览区 -->
            <div v-if="detailFile.isImage" class="rounded-xl overflow-hidden bg-[#fafafa] flex items-center justify-center">
              <img :src="detailFile.url" class="max-w-full max-h-[300px] object-contain" />
            </div>
            <div v-else-if="detailFile.isVideo" class="rounded-xl overflow-hidden bg-black">
              <video :src="detailFile.url" controls class="w-full max-h-[260px]" />
            </div>
            <div v-else class="rounded-xl bg-[#f5f6f8] flex flex-col items-center py-8 gap-2">
              <svg class="w-12 h-12 text-gray-300" fill="currentColor" viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4z"/></svg>
              <span class="text-xs text-gray-400">非图片/视频文件</span>
            </div>

            <!-- 文件信息 -->
            <div class="space-y-2">
              <div class="flex justify-between text-xs">
                <span class="text-gray-400">文件名</span>
                <span class="text-gray-700 font-medium text-right ml-4 break-all">{{ detailFile.name }}</span>
              </div>
              <div class="flex justify-between text-xs">
                <span class="text-gray-400 flex-shrink-0">大小</span>
                <span class="text-gray-700">{{ formatSize(detailFile.size) }}</span>
              </div>
              <div class="flex justify-between text-xs">
                <span class="text-gray-400">类型</span>
                <span class="text-gray-700">{{ detailFile.ext || '-' }}</span>
              </div>
              <div class="flex justify-between text-xs">
                <span class="text-gray-400 flex-shrink-0">修改时间</span>
                <span class="text-gray-700 text-right">{{ formatDate(detailFile.mtime) }}</span>
              </div>
              <div class="border-t border-gray-100 pt-2">
                <span class="text-xs text-gray-400 block mb-1">文件路径</span>
                <code class="text-[11px] bg-gray-100 rounded-lg px-2 py-1.5 block break-all text-gray-600">{{ currentDir }}/{{ detailFile.path }}</code>
              </div>
              <div class="border-t border-gray-100 pt-2">
                <span class="text-xs text-gray-400 block mb-1">访问链接</span>
                <div class="flex items-center gap-2">
                  <code class="text-[11px] bg-gray-100 rounded-lg px-2 py-1.5 flex-1 break-all text-gray-600">{{ fullUrl(detailFile.url) }}</code>
                  <button class="text-[11px] px-3 py-1.5 rounded-lg bg-blue-50 text-blue-500 flex-shrink-0" @click="copyUrl(detailFile.url)">复制</button>
                </div>
              </div>
              <div v-if="detailFile.dbRecord" class="border-t border-gray-100 pt-2 space-y-1.5">
                <div class="text-[11px] text-gray-500">数据库记录</div>
                <div class="flex justify-between text-xs">
                  <span class="text-gray-400">上传者</span>
                  <span class="text-gray-700">{{ detailFile.dbRecord.user_name || '-' }}</span>
                </div>
                <div class="flex justify-between text-xs">
                  <span class="text-gray-400">分类</span>
                  <span class="text-gray-700">{{ detailFile.dbRecord.category || '-' }}</span>
                </div>
                <div class="flex justify-between text-xs">
                  <span class="text-gray-400">上传时间</span>
                  <span class="text-gray-700">{{ detailFile.dbRecord.create_time || '-' }}</span>
                </div>
              </div>
            </div>

            <a :href="detailFile.url" target="_blank" class="block w-full text-center text-sm py-2.5 rounded-xl bg-blue-500 text-white font-medium active:bg-blue-600">在新窗口打开</a>
            <button v-auth="'delete'" class="block w-full text-center text-sm py-2.5 rounded-xl bg-red-50 text-red-500 font-medium active:bg-red-100 mt-2" @click="confirmDelete(detailFile); detailVisible=false">删除此文件</button>
          </div>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'
import { fetchLocalDelete } from '@/api/file-repo'

defineOptions({ name: 'FileRepoManageMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const loading=ref(false)
const currentDir=ref('')
const dirs=ref<{name:string;isDir:boolean}[]>([])
const files=ref<any[]>([])
const page=ref(1)
const pageSize=ref(12)
const totalFiles=ref(0)
const totalPages=ref(1)

const detailVisible=ref(false)
const detailFile=ref<any>(null)

const pathSegments=computed(()=>{
  if(!currentDir.value) return ['uploads']
  return ['uploads', ...currentDir.value.split('/')]
})

const formatSize=(bytes:number)=>{if(!bytes)return'0 B';const units=['B','KB','MB','GB'];let i=0;let v=bytes;while(v>=1024&&i<units.length-1){v/=1024;i++}return v.toFixed(i>0?1:0)+' '+units[i]}
const formatDate=(iso:string)=>{if(!iso)return'-';return new Date(iso).toLocaleString('zh-CN',{hour12:false})}
const fullUrl=(u:string)=>window.location.origin+u

const fetchData=async()=>{
  loading.value=true
  try{
    const res:any=await request.get({url:'/api/file-repo/local-browse',params:{dir:currentDir.value,page:page.value,pageSize:pageSize.value}})
    const d=res?.data||res||{}
    dirs.value=d.dirs||[]
    files.value=d.files||[]
    totalFiles.value=d.totalFiles||0
    totalPages.value=d.totalPages||1
    page.value=d.page||1
  }catch(e){
    showToast('加载失败','error')
  }
  loading.value=false
}

const navigateTo=(idx:number)=>{
  if(idx===0){currentDir.value='';page.value=1;fetchData();return}
  currentDir.value=currentDir.value.split('/').slice(0,idx).join('/')
  page.value=1;fetchData()
}
const enterDir=(name:string)=>{
  currentDir.value=currentDir.value?`${currentDir.value}/${name}`:name
  page.value=1;fetchData()
}
const goPage=(p:number)=>{if(p<1||p>totalPages.value)return;page.value=p;fetchData()}
const setPageSize=(ps:number)=>{pageSize.value=ps;page.value=1;fetchData()}

const openDetail=async(f:any)=>{
  detailFile.value=f
  detailVisible.value=true
  try{
    const res:any=await request.get({url:'/api/file-repo/local-detail',params:{path:f.path}})
    const d=res?.data||res||{}
    if(d&&d.name) detailFile.value={...f,...d}
  }catch{}
}

const copyUrl=async(u:string)=>{
  try{await navigator.clipboard.writeText(fullUrl(u));showToast('链接已复制')}catch{showToast('复制失败','error')}
}

const confirmDelete=async(f:any)=>{
  if(!confirm(`确定删除文件 ${f.name}？将同时删除服务器上的文件。`))return
  try{
    await fetchLocalDelete(f.path)
    showToast('删除成功')
    fetchData()
  }catch{showToast('删除失败','error')}
}

onMounted(()=>fetchData())
</script>

<style scoped>
.animate-slide-up {
  animation: slideUp .25s ease-out;
}
@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
</style>
