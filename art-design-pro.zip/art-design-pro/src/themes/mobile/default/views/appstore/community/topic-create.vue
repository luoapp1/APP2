<template>
  <div class="topic-create-page mx-auto max-w-[430px] shadow-lg relative" style="min-height:100vh;background:var(--default-bg-color)">
    <div class="h-[34px] bg-white"/>
    <div class="nav-bar sticky top-0 z-10 bg-white">
      <div class="flex items-center justify-between h-[40px] px-4">
        <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
          <path d="M15 18l-6-6 6-6"/>
        </svg>
        <span class="text-[17px] text-[#111] font-bold">创建话题</span>
        <div class="w-[32px] h-[32px]"/>
      </div>
    </div>

    <div class="bg-white px-5 py-4">
      <div class="mb-4">
        <div class="text-[13px] text-[#666] mb-2">话题名称 <span class="text-red-400">*</span></div>
        <input v-model="form.name" maxlength="30" placeholder="请输入话题名称" class="w-full h-[42px] px-3 text-[14px] border border-[#E5E7EB] rounded-lg outline-none focus:border-[#22C1C3]" />
      </div>

      <div class="mb-4">
        <div class="text-[13px] text-[#666] mb-2">话题图标</div>
        <div class="flex items-center gap-3">
          <div class="w-[60px] h-[60px] rounded-xl flex items-center justify-center overflow-hidden border border-[#E5E7EB]" :style="{ background: form.icon ? 'transparent' : '#F3F4F6' }">
            <img v-if="form.icon" :src="$fixImgUrl(form.icon)" class="w-full h-full object-cover" />
            <svg v-else class="w-6 h-6 text-[#CCC]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path stroke-linecap="round" stroke-linejoin="round" d="M21 15l-5-5L5 21"/></svg>
          </div>
          <button class="text-[13px] text-[#22C1C3] font-medium" @click="triggerUpload">上传图片</button>
          <input ref="fileInput" type="file" accept="image/*" style="display:none" @change="onFileChange" />
        </div>
      </div>

      <div class="mb-6">
        <div class="text-[13px] text-[#666] mb-2">话题简介</div>
        <textarea v-model="form.description" maxlength="200" rows="3" placeholder="请输入话题简介" class="w-full px-3 py-2 text-[14px] border border-[#E5E7EB] rounded-lg outline-none focus:border-[#22C1C3] resize-none" />
      </div>

      <div v-if="errorMsg" class="text-[13px] text-red-400 mb-3 text-center">{{ errorMsg }}</div>

      <button class="w-full h-[44px] rounded-lg text-[15px] font-semibold text-white" style="background:#22C1C3" @click="handleSubmit" :disabled="submitting">
        {{ submitting ? '创建中...' : '创建话题' }}
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { createTopic } from '@/api/community'
import request from '@/utils/http'

const router = useRouter()
const submitting = ref(false)
const errorMsg = ref('')
const fileInput = ref<any>(null)

const form = ref({ name: '', icon: '', description: '' })

function triggerUpload() {
  fileInput.value?.click()
}

async function onFileChange(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  const fd = new FormData()
  fd.append('file', file)
  try {
    const res: any = await request.post({ url: '/api/upload', data: fd })
    form.value.icon = res?.url || res?.data?.url || ''
  } catch { errorMsg.value = '图片上传失败' }
}

async function handleSubmit() {
  errorMsg.value = ''
  if (!form.value.name.trim()) { errorMsg.value = '请输入话题名称'; return }
  submitting.value = true
  try {
    await createTopic({ name: form.value.name.trim(), icon: form.value.icon, description: form.value.description.trim() })
    router.back()
  } catch (e: any) {
    errorMsg.value = e?.msg || e?.message || '创建失败'
  } finally {
    submitting.value = false
  }
}
</script>
