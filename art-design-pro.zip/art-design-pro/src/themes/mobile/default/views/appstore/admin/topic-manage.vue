<template>
  <div class="topic-manage-page mx-auto max-w-[430px] shadow-lg relative" style="min-height:100vh;background:var(--default-bg-color)">
    <div class="h-[34px] bg-white"/>
    <div class="nav-bar sticky top-0 z-10 bg-white">
      <div class="flex items-center justify-between h-[40px] px-4">
        <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
          <path d="M15 18l-6-6 6-6"/>
        </svg>
        <span class="text-[17px] text-[#111] font-bold">话题管理</span>
        <div class="w-[32px] h-[32px]"/>
      </div>
    </div>

    <div v-if="loading" class="flex justify-center pt-40">
      <div class="w-5 h-5 border-2 border-[#22C1C3] border-t-transparent rounded-full animate-spin"/>
    </div>

    <template v-else>
      <div class="bg-white px-5 py-4 mb-2">
        <button v-auth="'add'" class="w-full h-[42px] rounded-lg text-[14px] font-medium text-white" style="background:#22C1C3" @click="showCreateDialog = true">+ 创建话题</button>
      </div>

      <div class="bg-white px-5 py-3 mb-2">
        <div class="flex items-center justify-between mb-3">
          <div class="text-[14px] font-semibold text-[#333]">创建权限设置</div>
          <button class="text-[12px] text-[#22C1C3]" @click="showConfigDialog = true">设置</button>
        </div>
        <div class="text-[11px] text-[#999]">
          最低经验等级：{{ expLevels.find(e => e.level === config.minExpLevel)?.name || '不限制' }} |
          允许会员等级：{{ config.allowedLevels.length ? config.allowedLevels.map(id => memberLevels.find(m => m.id === id)?.name || id).join('、') : '不限制' }}
        </div>
      </div>

      <div class="bg-white px-5 py-3">
        <div class="flex items-center justify-between mb-3">
          <div class="text-[14px] font-semibold text-[#333]">话题列表 ({{ total }})</div>
        </div>

        <div class="pagination-top">
          <el-pagination
            v-if="total > 0"
            small
            v-model:current-page="page"
            v-model:page-size="pageSize"
            :page-sizes="[10, 20, 50]"
            :total="total"
            layout="total, sizes, prev, pager, next"
            @current-change="loadTopics"
            @size-change="onSizeChange"
          />
        </div>

        <div v-if="topics.length === 0" class="text-center py-8 text-gray-400 text-sm">暂无话题</div>
        <div v-for="t in topics" :key="t.id" class="flex items-center gap-3 py-2.5 border-b border-[#F0F0F0] last:border-0">
          <div class="w-[40px] h-[40px] rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden" :style="{ background: t.icon ? 'transparent' : '#22C1C3' }">
            <img v-if="t.icon" :src="$fixImgUrl(t.icon)" class="w-full h-full object-cover" />
            <span v-else class="text-white font-bold">#</span>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[13px] text-[#333] font-medium truncate">#{{ t.name }}</div>
            <div class="text-[11px] text-[#999]">{{ t.description || '暂无简介' }}</div>
            <div class="text-[11px] text-[#B0B0B0]">{{ t.postCount || 0 }} 帖子 · {{ t.status === '1' ? '显示' : '隐藏' }}</div>
          </div>
          <div class="flex gap-1 flex-shrink-0">
            <button v-auth="'edit'" class="px-2 py-1 text-[11px] rounded text-[#22C1C3] bg-[#E8F8F8]" @click="editTopic(t)">编辑</button>
            <button class="px-2 py-1 text-[11px] rounded" :style="{ color: t.status === '1' ? '#F59E0B' : '#22C1C3', background: t.status === '1' ? '#FEF3C7' : '#E8F8F8' }" @click="toggleStatus(t)">
              {{ t.status === '1' ? '隐藏' : '显示' }}
            </button>
            <button v-auth="'delete'" class="px-2 py-1 text-[11px] rounded text-[#EF4444] bg-[#FEE2E2]" @click="confirmDelete(t)">删除</button>
          </div>
        </div>

        <div class="pagination-bottom" v-if="total > 0">
          <el-pagination
            small
            v-model:current-page="page"
            :page-size="pageSize"
            :total="total"
            layout="prev, pager, next"
            @current-change="loadTopics"
          />
        </div>
      </div>
    </template>

    <!-- 创建/编辑弹窗 -->
    <div v-if="showCreateDialog" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:100" @click.self="closeDialog">
      <div style="background:#fff;border-radius:16px;width:340px;padding:24px 20px 16px;">
        <div style="font-size:16px;font-weight:600;color:#1f2937;margin-bottom:16px;">{{ editingTopic ? '编辑话题' : '创建话题' }}</div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">名称 <span style="color:#EF4444">*</span></div>
          <input v-model="editForm.name" maxlength="30" style="width:100%;height:38px;padding:0 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;box-sizing:border-box" />
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">图标URL</div>
          <input v-model="editForm.icon" placeholder="图片链接" style="width:100%;height:38px;padding:0 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;box-sizing:border-box" />
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">简介</div>
          <textarea v-model="editForm.description" maxlength="200" rows="2" style="width:100%;padding:8px 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;resize:none;box-sizing:border-box" />
        </div>
        <div v-if="dialogMsg" style="font-size:12px;color:#EF4444;margin-bottom:8px;text-align:center;">{{ dialogMsg }}</div>
        <div style="display:flex;gap:10px;">
          <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#F3F4F6;color:#374151;cursor:pointer;" @click="closeDialog">取消</button>
          <button v-auth="editingTopic ? 'edit' : 'add'" style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#22C1C3;color:#fff;cursor:pointer;" @click="handleSave" :disabled="dialogSaving">{{ dialogSaving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>

    <!-- 权限设置弹窗 -->
    <div v-if="showConfigDialog" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:100" @click.self="showConfigDialog = false">
      <div style="background:#fff;border-radius:16px;width:340px;padding:24px 20px 16px;">
        <div style="font-size:16px;font-weight:600;color:#1f2937;margin-bottom:16px;">创建权限设置</div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">最低经验等级要求</div>
          <select v-model.number="config.minExpLevel" style="width:100%;height:38px;padding:0 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;box-sizing:border-box;background:#fff;">
            <option :value="0">不限制</option>
            <option v-for="e in expLevels" :key="e.id" :value="e.level">{{ e.name }} (Lv.{{ e.level }})</option>
          </select>
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">允许的会员等级</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;" class="config-level-check">
            <label style="display:flex;align-items:center;gap:4px;font-size:12px;color:#22C1C3;cursor:pointer;font-weight:600;padding-bottom:6px;border-bottom:1px solid #E5E7EB;margin-bottom:4px;width:100%;">
              <input type="checkbox" :checked="memberLevels.length > 0 && config.allowedLevels.length === memberLevels.length" @change="toggleAllLevels" style="accent-color:#22C1C3;" />
              全部会员
            </label>
            <label v-for="m in memberLevels" :key="m.id" style="display:flex;align-items:center;gap:4px;font-size:12px;color:#555;cursor:pointer;">
              <input type="checkbox" :value="m.id" v-model="config.allowedLevels" style="accent-color:#22C1C3;" />
              {{ m.name }}
            </label>
          </div>
          <div v-if="memberLevels.length === 0" style="font-size:12px;color:#999;padding:8px 0;">暂无会员等级数据</div>
        </div>
        <div v-if="configMsg" style="font-size:12px;margin-bottom:8px;text-align:center;" :style="{ color: configMsgOk ? '#22C1C3' : '#EF4444' }">{{ configMsg }}</div>
        <div style="display:flex;gap:10px;">
          <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#F3F4F6;color:#374151;cursor:pointer;" @click="showConfigDialog = false">取消</button>
          <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#22C1C3;color:#fff;cursor:pointer;" @click="saveConfig" :disabled="savingConfig">{{ savingConfig ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchTopics, createTopic, updateTopic, deleteTopic, fetchTopicConfig, updateTopicConfig } from '@/api/community'
import { fetchExpLevelList, fetchGetMembershipLevelList } from '@/api/operation'

const loading = ref(true)
const topics = ref<any[]>([])
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const expLevels = ref<any[]>([])
const memberLevels = ref<any[]>([])

const savingConfig = ref(false)
const configMsg = ref('')
const configMsgOk = ref(false)
const config = ref({ minExpLevel: 0, allowedLevels: [] as number[] })
const showConfigDialog = ref(false)

const showCreateDialog = ref(false)
const editingTopic = ref<any>(null)
const dialogSaving = ref(false)
const dialogMsg = ref('')
const editForm = ref({ name: '', icon: '', description: '' })

async function loadTopics() {
  loading.value = true
  try {
    const res: any = await fetchTopics({ page: page.value, pageSize: pageSize.value })
    const data = res?.data || res || {}
    topics.value = data.list || data.data?.list || []
    total.value = data.total || 0
  } catch {} finally { loading.value = false }
}

function onSizeChange() {
  page.value = 1
  loadTopics()
}

async function loadConfig() {
  try {
    const res: any = await fetchTopicConfig()
    const data = res?.data || res || {}
    config.value.minExpLevel = data.minExpLevel || 0
    config.value.allowedLevels = data.allowedLevels || []
  } catch {}
}

function toggleAllLevels() {
  if (config.value.allowedLevels.length === memberLevels.value.length) {
    config.value.allowedLevels = []
  } else {
    config.value.allowedLevels = memberLevels.value.map((m: any) => m.id)
  }
}

async function loadExpLevels() {
  try {
    const res: any = await fetchExpLevelList({ pageSize: 100, status: '1' })
    expLevels.value = res?.records || res?.list || res?.data?.records || res?.data || []
  } catch {}
}

async function loadMemberLevels() {
  try {
    const res: any = await fetchGetMembershipLevelList({ pageSize: 100, status: '1' } as any)
    memberLevels.value = res?.records || res?.list || res?.data?.records || res?.data || []
  } catch {}
}

async function saveConfig() {
  savingConfig.value = true
  configMsg.value = ''
  try {
    await updateTopicConfig({ minExpLevel: config.value.minExpLevel, allowedLevels: config.value.allowedLevels })
    configMsg.value = '保存成功'
    configMsgOk.value = true
    showConfigDialog.value = false
  } catch (e: any) {
    configMsg.value = e?.msg || '保存失败'
    configMsgOk.value = false
  } finally { savingConfig.value = false }
}

function editTopic(t: any) {
  editingTopic.value = t
  editForm.value = { name: t.name, icon: t.icon || '', description: t.description || '' }
  showCreateDialog.value = true
}

function closeDialog() {
  showCreateDialog.value = false
  editingTopic.value = null
  editForm.value = { name: '', icon: '', description: '' }
  dialogMsg.value = ''
}

async function handleSave() {
  dialogMsg.value = ''
  if (!editForm.value.name.trim()) { dialogMsg.value = '请输入名称'; return }
  dialogSaving.value = true
  try {
    if (editingTopic.value) {
      await updateTopic(editingTopic.value.id, editForm.value)
    } else {
      await createTopic(editForm.value)
    }
    closeDialog()
    loadTopics()
  } catch (e: any) {
    dialogMsg.value = e?.msg || '操作失败'
  } finally { dialogSaving.value = false }
}

async function toggleStatus(t: any) {
  try {
    await updateTopic(t.id, { status: t.status === '1' ? '0' : '1' })
    loadTopics()
  } catch {}
}

async function confirmDelete(t: any) {
  if (!confirm(`确定删除话题"${t.name}"吗？`)) return
  try {
    await deleteTopic(t.id)
    loadTopics()
  } catch {}
}

onMounted(async () => {
  await Promise.all([loadTopics(), loadConfig(), loadExpLevels(), loadMemberLevels()])
})
</script>

<style scoped>
.pagination-top {
  display: flex;
  justify-content: center;
  padding: 4px 0 8px;
  border-bottom: 1px solid #F0F0F0;
  margin-bottom: 4px;
}
.pagination-bottom {
  display: flex;
  justify-content: center;
  padding: 12px 0 0;
}
.config-level-check {
  max-height: 150px;
  overflow-y: auto;
  padding: 4px 0;
}
</style>
