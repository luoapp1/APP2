<template>
  <div class="min-h-screen flex flex-col bg-[#f0f2f5]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-10">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">会员等级管理</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <!-- 统计头部 -->
      <div class="mx-3 mt-3 bg-gradient-to-br from-[#667eea] via-[#6b43c3] to-[#764ba2] rounded-2xl p-5 text-white shadow-lg relative overflow-hidden">
        <div class="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/3"></div>
        <div class="absolute bottom-0 left-0 w-20 h-20 bg-white/5 rounded-full translate-y-1/3 -translate-x-1/3"></div>
        <div class="relative">
          <div class="flex items-center justify-between">
            <div>
              <div class="text-xs text-white/60 font-medium tracking-wide">会员体系</div>
              <div class="flex items-baseline gap-1 mt-1">
                <span class="text-3xl font-black">{{ levels.length }}</span>
                <span class="text-xs text-white/60">个等级</span>
              </div>
            </div>
            <div class="flex gap-4">
              <div class="text-center">
                <div class="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center mx-auto mb-1">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <div class="text-lg font-bold">{{ levels.filter(l => l.status === '1').length }}</div>
                <div class="text-[10px] text-white/50">已启用</div>
              </div>
              <div class="text-center">
                <div class="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center mx-auto mb-1">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A2 2 0 013 12V7a4 4 0 014-4z"/></svg>
                </div>
                <div class="text-lg font-bold">{{ levels.reduce((s, l) => s + (l.pricingPlans ? l.pricingPlans.length : 0), 0) }}</div>
                <div class="text-[10px] text-white/50">定价方案</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 筛选标签 -->
      <div class="mx-3 mt-3 flex gap-2">
        <span v-for="tab in tabs" :key="tab.key"
          class="text-xs px-3.5 py-1.5 rounded-full font-medium transition-all duration-200 cursor-pointer"
          :class="activeTab === tab.key ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'"
          @click="activeTab = tab.key"
        >{{ tab.label }}</span>
      </div>

      <!-- 等级卡片列表 -->
      <TransitionGroup name="list" tag="div" class="mx-3 mt-2" v-if="filteredLevels.length">
        <div v-for="(lv, idx) in filteredLevels" :key="lv.id" class="rounded-2xl mb-3 p-4 shadow-sm overflow-hidden relative transition-all duration-200 active:scale-[0.98]"
          :style="{ background: `linear-gradient(135deg, ${(lv.bgColor || '#508DFF')}08, ${(lv.bgColor || '#508DFF')}12)` }">
          <div class="absolute left-0 top-0 bottom-0 w-1 rounded-r-full" :style="{ background: lv.bgColor || '#508DFF' }"></div>
          <div class="pl-2">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-3">
                <div class="w-11 h-11 rounded-2xl flex items-center justify-center shadow-md relative overflow-hidden" :style="{ background: `linear-gradient(135deg, ${(lv.bgColor || '#508DFF')}, ${(lv.bgColor || '#508DFF')}dd)` }">
                  <div class="absolute top-0 right-0 w-6 h-6 bg-white/10 rounded-full -translate-y-1/3 translate-x-1/3"></div>
                  <span class="text-white font-black text-sm relative">{{ (lv.name || '?').charAt(0) }}</span>
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] px-2 py-0.5 rounded-md font-bold text-white shadow-sm" :style="{ background: lv.bgColor || '#508DFF' }">Lv.{{ lv.level }}</span>
                    <span class="text-sm font-bold text-gray-800">{{ lv.name }}</span>
                  </div>
                  <div class="flex items-center gap-2 mt-0.5">
                    <span class="w-1.5 h-1.5 rounded-full" :class="lv.status === '1' ? 'bg-green-400' : 'bg-gray-300'"></span>
                    <span class="text-[10px]" :class="lv.status === '1' ? 'text-green-600' : 'text-gray-400'">{{ lv.status === '1' ? '启用中' : '已禁用' }}</span>
                    <span class="text-[10px] text-gray-300">|</span>
                    <span class="text-[10px] text-gray-400">{{ lv.tier === 1 ? '普通' : lv.tier === 2 ? '进阶' : lv.tier === 3 ? '高级' : 'T'+lv.tier }}</span>
                  </div>
                </div>
              </div>
              <div class="flex gap-1.5 flex-shrink-0">
                <span v-auth="'edit'" class="text-[10px] px-2.5 py-1.5 rounded-lg font-medium cursor-pointer active:scale-95 transition-transform" :style="{ background: (lv.bgColor || '#508DFF') + '20', color: lv.bgColor || '#508DFF' }" @click="openLevelDialog(lv)">编辑</span>
                <span v-auth="'delete'" class="text-[10px] px-2.5 py-1.5 rounded-lg bg-red-50 text-red-400 font-medium cursor-pointer active:bg-red-100 active:scale-95 transition-transform" @click="deleteLevel(lv.id)">删除</span>
              </div>
            </div>

            <div class="flex flex-wrap items-center gap-2 mb-2">
              <div v-if="Number(lv.price) > 0" class="flex items-baseline gap-1.5">
                <span class="text-lg font-black" :style="{ color: lv.bgColor || '#508DFF' }">¥{{ lv.price }}</span>
                <span v-if="Number(lv.discountRate || 1) < 1" class="text-[9px] px-1.5 py-0.5 rounded font-bold text-white" :style="{ background: lv.bgColor || '#508DFF' }">{{ (Number(lv.discountRate || 1) * 10).toFixed(1) }}折</span>
              </div>
              <span v-else class="text-xs font-bold text-gray-400">免费</span>
              <div v-if="lv.pricingPlans && lv.pricingPlans.length" class="flex items-center gap-1">
                <span class="w-1 h-1 rounded-full bg-gray-300"></span>
                <span class="text-[10px] text-gray-400">{{ lv.pricingPlans.length }}个方案</span>
              </div>
            </div>

            <div v-if="lv.benefits" class="flex flex-wrap gap-1 mb-2">
              <span v-for="(b, bi) in (lv.benefits || '').split(/[,，、]/).filter(Boolean).slice(0, 4)" :key="bi" class="text-[10px] px-2 py-0.5 rounded-md font-medium bg-white/60" :style="{ color: lv.bgColor || '#508DFF' }">{{ b.trim() }}</span>
              <span v-if="(lv.benefits || '').split(/[,，、]/).filter(Boolean).length > 4" class="text-[10px] text-gray-400 px-1">+{{ (lv.benefits || '').split(/[,，、]/).filter(Boolean).length - 4 }}</span>
            </div>

            <div class="grid grid-cols-4 gap-1.5 mb-2">
              <div class="rounded-xl px-2 py-2 text-center bg-white/70">
                <div class="text-[14px] leading-none mb-0.5">🎯</div>
                <div class="text-[9px] text-gray-400 leading-tight">倍率</div>
                <div class="text-[10px] font-bold text-gray-700">x{{ lv.pointsMultiplier }}</div>
              </div>
              <div class="rounded-xl px-2 py-2 text-center bg-white/70">
                <div class="text-[14px] leading-none mb-0.5">🏷️</div>
                <div class="text-[9px] text-gray-400 leading-tight">折扣</div>
                <div class="text-[10px] font-bold text-gray-700">{{ Number(lv.pointsDiscountRate || 1) * 10 }}折</div>
              </div>
              <div class="rounded-xl px-2 py-2 text-center bg-white/70">
                <div class="text-[14px] leading-none mb-0.5">💾</div>
                <div class="text-[9px] text-gray-400 leading-tight">数据</div>
                <div class="text-[10px] font-bold" :class="(lv.dataLimitMb || 0) > 0 ? 'text-blue-600' : 'text-gray-400'">{{ (lv.dataLimitMb || 0) > 0 ? lv.dataLimitMb + 'M' : '不限' }}</div>
              </div>
              <div class="rounded-xl px-2 py-2 text-center bg-white/70">
                <div class="text-[14px] leading-none mb-0.5">📁</div>
                <div class="text-[9px] text-gray-400 leading-tight">文件</div>
                <div class="text-[10px] font-bold" :class="(lv.fileLimitMb || 0) > 0 ? 'text-green-600' : 'text-gray-400'">{{ (lv.fileLimitMb || 0) > 0 ? lv.fileLimitMb + 'M' : '不限' }}</div>
              </div>
            </div>

            <div v-if="lv.pricingPlans && lv.pricingPlans.length" class="pt-2 border-t border-dashed border-gray-200/60">
              <span class="text-[10px] text-gray-400 font-medium cursor-pointer flex items-center gap-1" @click="toggleExpand(lv.id)">
                <svg class="w-2.5 h-2.5 transition-transform duration-200" :style="{ transform: expanded[lv.id] ? 'rotate(90deg)' : '' }" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
                定价方案 ({{ lv.pricingPlans.length }})
              </span>
              <div v-show="expanded[lv.id]" class="flex gap-2 overflow-x-auto pb-1 mt-2">
                <div v-for="plan in lv.pricingPlans" :key="plan.id" class="flex-shrink-0 rounded-xl px-3 py-2 min-w-[90px] bg-white/70 border" :style="{ borderColor: (lv.bgColor || '#508DFF') + '20' }">
                  <div class="text-[10px] font-bold text-gray-700 truncate">{{ plan.name }}</div>
                  <div class="text-sm font-black mt-0.5" :style="{ color: lv.bgColor || '#508DFF' }">¥{{ plan.price }}</div>
                  <div class="text-[10px] text-gray-400 mt-0.5">{{ plan.durationDays }}天</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </TransitionGroup>

      <div v-else class="mx-3 mt-3">
        <div class="bg-white rounded-2xl p-10 text-center shadow-sm">
          <div class="w-16 h-16 rounded-2xl bg-purple-50 flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8 text-purple-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
          </div>
          <div class="text-sm text-gray-400 mb-1 font-medium">暂无会员等级</div>
          <div class="text-xs text-gray-300">点击右下角按钮创建第一个等级</div>
        </div>
      </div>

      <span v-auth="'add'" class="fixed bottom-16 right-4 w-12 h-12 rounded-2xl text-white flex items-center justify-center z-20 active:scale-90 transition-all duration-200 cursor-pointer" style="background: linear-gradient(135deg, #667eea, #764ba2); box-shadow: 0 4px 20px rgba(102, 126, 234, 0.45);" @click="openLevelDialog()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
      </span>
    </div>

    <!-- ============ 编辑弹窗 ============ -->
    <div v-if="showLevelDialog" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showLevelDialog = false">
      <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto animate-slide-up flex flex-col" @click.stop>
        <div class="flex items-center justify-between px-4 pt-4 pb-3 border-b border-gray-50 flex-shrink-0">
          <span class="text-gray-400 p-1 cursor-pointer" @click="showLevelDialog = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </span>
          <span class="text-sm font-bold text-gray-800">{{ editLevel.id ? '编辑等级' : '新增等级' }}</span>
          <span class="text-sm font-bold px-3 py-1 rounded-lg cursor-pointer" style="background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;" @click="saveLevel">保存</span>
        </div>

        <div class="p-4 space-y-3">
          <div :class="['rounded-2xl p-4 relative overflow-hidden mb-2']" :style="{ background: (editLevel.bgColor || '#508DFF') }">
            <div class="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/3"></div>
            <div class="relative flex items-center gap-3">
              <div class="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center">
                <span class="text-white font-black text-sm">{{ (editLevel.name || '?').charAt(0) }}</span>
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-white/25 text-white font-bold">Lv.{{ editLevel.level }}</span>
                  <span class="text-sm font-bold text-white">{{ editLevel.name || '未命名' }}</span>
                </div>
                <div v-if="Number(editLevel.price) > 0" class="text-white/80 text-xs mt-0.5">¥{{ editLevel.price }}</div>
              </div>
            </div>
          </div>

          <div><div class="text-xs text-gray-500 mb-1">名称</div><input v-model="editLevel.name" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">等级</div><input v-model.number="editLevel.level" type="number" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">Tier</div><input v-model.number="editLevel.tier" type="number" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
          </div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">价格 ¥</div><input v-model.number="editLevel.price" type="number" step="0.01" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">折扣率</div><input v-model.number="editLevel.discountRate" type="number" step="0.1" min="0.1" max="1" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
          </div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">积分倍率</div><input v-model.number="editLevel.pointsMultiplier" type="number" step="0.1" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">积分折扣</div><input v-model.number="editLevel.pointsDiscountRate" type="number" step="0.1" class="w-full h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors"></div>
          </div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">文字颜色</div>
              <div class="flex items-center gap-2">
                <input v-model="editLevel.textColor" class="flex-1 h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors">
                <input type="color" v-model="editLevel.textColor" class="w-10 h-10 rounded-xl border-0 cursor-pointer p-0.5">
              </div>
            </div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">背景颜色</div>
              <div class="flex items-center gap-2">
                <input v-model="editLevel.bgColor" class="flex-1 h-10 border border-gray-200 rounded-xl px-3 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors">
                <input type="color" v-model="editLevel.bgColor" class="w-10 h-10 rounded-xl border-0 cursor-pointer p-0.5">
              </div>
            </div>
          </div>
          <div>
            <div class="text-xs text-gray-500 mb-1">图标</div>
            <div class="flex items-center gap-3">
              <div class="w-11 h-11 rounded-2xl flex items-center justify-center shadow-md overflow-hidden" :style="{ background: editLevel.bgColor || '#508DFF' }">
                <img v-if="editLevel.icon && /^https?:\/\//.test(editLevel.icon)" :src="editLevel.icon" class="w-7 h-7 object-contain" />
                <span v-else class="text-white font-black text-sm">{{ (editLevel.name || '?').charAt(0) }}</span>
              </div>
              <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload">
              <span class="h-9 px-4 bg-white text-xs rounded-lg border border-gray-200 active:bg-gray-50 inline-flex items-center cursor-pointer" :class="{ 'opacity-50': uploadingIcon }" @click="triggerIconUpload">{{ uploadingIcon ? '上传中...' : (editLevel.icon && /^https?:\/\//.test(editLevel.icon) ? '更换图标' : '上传图标') }}</span>
            </div>
          </div>

          <div class="bg-purple-50/50 rounded-2xl p-3 space-y-3">
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2 1 3 3 3h10c2 0 3-1 3-3V7"/></svg>
              <span class="text-xs text-purple-500 font-medium">存储配额</span>
            </div>
            <div class="flex gap-3">
              <div class="flex-1">
                <div class="text-[10px] text-gray-400 mb-1">数据总上限</div>
                <div class="relative">
                  <input v-model.number="editLevel.dataLimitMb" type="number" min="0" class="w-full h-9 pr-12 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors" placeholder="无限制">
                  <span class="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-gray-400">MB</span>
                </div>
              </div>
              <div class="flex-1">
                <div class="text-[10px] text-gray-400 mb-1">文件总上限</div>
                <div class="relative">
                  <input v-model.number="editLevel.fileLimitMb" type="number" min="0" class="w-full h-9 pr-12 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors" placeholder="无限制">
                  <span class="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-gray-400">MB</span>
                </div>
              </div>
            </div>
            <div>
              <div class="text-[10px] text-gray-400 mb-1.5">绑定文件上传策略</div>
              <div class="flex flex-wrap gap-1.5">
                <span
                  v-for="p in policyList" :key="p.id"
                  class="text-[10px] px-2.5 py-1 rounded-full border transition-all duration-150 cursor-pointer"
                  :class="selectedPolicyIds.includes(p.id) ? 'bg-purple-500 text-white border-purple-500 shadow-sm' : 'bg-white text-gray-500 border-gray-200 active:bg-gray-50'"
                  @click="togglePolicy(p.id)"
                >{{ p.name }}</span>
              </div>
              <div v-if="!policyList.length" class="text-[10px] text-gray-400 mt-1">暂无可用策略，请先在"文件上传策略"页面创建</div>
            </div>
          </div>

          <div class="bg-amber-50/50 rounded-2xl p-3 space-y-3">
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"/></svg>
              <span class="text-xs text-amber-600 font-medium">首次开通赠送</span>
              <span class="text-[10px] text-amber-400">(仅该等级首次开通时触发)</span>
            </div>
            <div class="flex gap-3">
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送积分</div><input v-model.number="editLevel.giftPoints" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送余额 ¥</div><input v-model.number="editLevel.giftBalance" type="number" min="0" step="0.01" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送经验</div><input v-model.number="editLevel.giftExperience" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
            </div>
             <div>
               <div class="flex items-center justify-between mb-1.5">
                 <span class="text-[10px] text-gray-400">赠送优惠券</span>
                 <span class="text-[10px] px-2 py-0.5 rounded bg-white text-amber-500 font-medium cursor-pointer border border-amber-200 active:bg-amber-50" @click="addGiftCoupon">+ 添加券</span>
               </div>
               <div v-if="!giftCoupons.length" class="text-[10px] text-gray-300">无需赠送优惠券</div>
               <div v-for="(gc, gi) in giftCoupons" :key="gi" class="bg-white rounded-xl p-2.5 mb-2 border border-amber-100 space-y-1.5 relative">
                 <span class="absolute top-2 right-2 text-[10px] text-red-400 cursor-pointer active:text-red-500" @click="giftCoupons.splice(gi, 1)">删除</span>
                 <div class="flex gap-1.5">
                   <div class="flex-[2]"><div class="text-[9px] text-gray-400 mb-0.5">名称</div><input v-model="gc.name" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="如: 黄金专享券"></div>
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">券类型</div>
                     <select v-model="gc.type" class="w-full h-8 border border-gray-200 rounded-lg px-1.5 text-[10px] bg-gray-50 focus:border-amber-300 outline-none">
                       <option value="fixed">固定金额</option>
                       <option value="percent">百分比</option>
                       <option value="fixed_points">固定积分</option>
                       <option value="points_percent">积分百分比</option>
                     </select>
                   </div>
                 </div>
                 <div class="flex gap-1.5">
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">面值/折扣</div><input v-model.number="gc.value" type="number" step="0.01" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none"></div>
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">最低消费</div><input v-model.number="gc.minOrder" type="number" step="0.01" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="0"></div>
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">最高折扣</div><input v-model.number="gc.maxDiscount" type="number" step="0.01" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="0"></div>
                 </div>
                 <div class="flex gap-1.5">
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">使用范围</div>
                     <select v-model="gc.scope" class="w-full h-8 border border-gray-200 rounded-lg px-1.5 text-[10px] bg-gray-50 focus:border-amber-300 outline-none">
                       <option value="all">全部</option>
                       <option value="product">商品</option>
                       <option value="membership">会员</option>
                     </select>
                   </div>
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">分类</div><input v-model="gc.category" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="如: member"></div>
                   <div class="flex-1"><div class="text-[9px] text-gray-400 mb-0.5">有效天数</div><input v-model.number="gc.validDays" type="number" class="w-full h-8 border border-gray-200 rounded-lg px-2 text-[10px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="30"></div>
                 </div>
               </div>
             </div>
            <div>
              <div class="text-[10px] text-gray-400 mb-1">会员权益 <span class="text-gray-300">(自由文本，如: 生日礼包、年度礼包、专属客服等)</span></div>
              <textarea v-model="editLevel.perks" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm bg-white focus:border-amber-300 outline-none transition-colors" rows="2" placeholder="如: 生日礼包|年度礼包|优先体验新功能"></textarea>
            </div>
          </div>

          <div><div class="text-xs text-gray-500 mb-1">权益说明 <span class="text-gray-300 text-[10px]">(逗号分隔)</span></div><textarea v-model="editLevel.benefits" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm bg-gray-50 focus:bg-white focus:border-purple-300 outline-none transition-colors" rows="2" placeholder="如: 9折优惠,双倍积分,专属客服"></textarea></div>
          <div>
            <div class="text-xs text-gray-500 mb-1">状态</div>
            <div class="flex rounded-xl bg-gray-100 p-0.5">
              <span class="flex-1 py-2 text-xs rounded-lg font-medium text-center cursor-pointer transition-all duration-200" :class="editLevel.status === '1' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'" @click="editLevel.status = '1'">启用</span>
              <span class="flex-1 py-2 text-xs rounded-lg font-medium text-center cursor-pointer transition-all duration-200" :class="editLevel.status === '0' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-400'" @click="editLevel.status = '0'">禁用</span>
            </div>
          </div>

          <div class="bg-green-50/50 rounded-2xl p-3 space-y-2">
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
              <span class="text-xs text-green-600 font-medium">会员专属标识</span>
            </div>
            <div class="flex gap-2">
              <div class="flex-1">
                <div class="text-[10px] text-gray-400 mb-1">专属称号</div>
                <select v-model.number="editLevel.titleId" class="w-full h-9 border border-gray-200 rounded-lg px-2 text-xs bg-white focus:border-green-300 outline-none">
                  <option :value="0">不设置</option>
                  <option v-for="t in titleList" :key="t.id" :value="t.id">{{ t.name }}</option>
                </select>
              </div>
              <div class="flex-1">
                <div class="text-[10px] text-gray-400 mb-1">专属头像框</div>
                <select v-model.number="editLevel.frameId" class="w-full h-9 border border-gray-200 rounded-lg px-2 text-xs bg-white focus:border-green-300 outline-none">
                  <option :value="0">不设置</option>
                  <option v-for="f in frameList" :key="f.id" :value="f.id">{{ f.name }}</option>
                </select>
              </div>
            </div>
          </div>

          <div class="bg-blue-50/50 rounded-2xl p-3 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <svg class="w-3.5 h-3.5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <span class="text-xs text-blue-600 font-medium">定时专属礼包</span>
              </div>
              <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" v-model="editLevel.dailyGiftEnabled" class="sr-only peer">
                <div class="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-500"></div>
              </label>
            </div>
            <template v-if="editLevel.dailyGiftEnabled">
              <div class="flex gap-2">
                <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">领取间隔(天)</div><input v-model.number="editLevel.dailyGiftIntervalDays" type="number" min="1" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-blue-300 outline-none transition-colors" placeholder="1"></div>
                <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送积分</div><input v-model.number="editLevel.dailyGiftPoints" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-blue-300 outline-none transition-colors" placeholder="0"></div>
                <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送余额 ¥</div><input v-model.number="editLevel.dailyGiftBalance" type="number" min="0" step="0.01" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-blue-300 outline-none transition-colors" placeholder="0"></div>
                <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送经验</div><input v-model.number="editLevel.dailyGiftExperience" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-blue-300 outline-none transition-colors" placeholder="0"></div>
              </div>
              <div>
                <div class="flex items-center justify-between mb-1">
                  <span class="text-[10px] text-gray-400">赠送优惠券</span>
                  <span class="text-[9px] px-1.5 py-0.5 rounded bg-white text-blue-500 cursor-pointer border border-blue-200 active:bg-blue-50" @click="dailyGiftCoupons.push({ name: '', type: 'fixed', value: 0, minOrder: 0, maxDiscount: 0, scope: 'all', category: 'member', validDays: 30 })">+ 添加</span>
                </div>
                <div v-if="!dailyGiftCoupons.length" class="text-[9px] text-gray-300">无</div>
                <div v-for="(dc, di) in dailyGiftCoupons" :key="di" class="bg-white rounded-lg p-2 mb-1.5 border border-blue-100 space-y-1 relative">
                  <span class="absolute top-1 right-1.5 text-[9px] text-red-400 cursor-pointer active:text-red-500" @click="dailyGiftCoupons.splice(di, 1)">×</span>
                  <div class="flex gap-1">
                    <div class="flex-[2]"><input v-model="dc.name" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-blue-300 outline-none" placeholder="券名称"></div>
                    <div class="flex-1">
                      <select v-model="dc.type" class="w-full h-7 border border-gray-200 rounded px-0.5 text-[9px] bg-gray-50 focus:border-blue-300 outline-none">
                        <option value="fixed">固定金额</option>
                        <option value="percent">百分比</option>
                      </select>
                    </div>
                  </div>
                  <div class="flex gap-1">
                    <div class="flex-1"><input v-model.number="dc.value" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-blue-300 outline-none" placeholder="面值"></div>
                    <div class="flex-1"><input v-model.number="dc.minOrder" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-blue-300 outline-none" placeholder="最低消费"></div>
                    <div class="flex-1"><input v-model.number="dc.validDays" type="number" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-blue-300 outline-none" placeholder="天数"></div>
                  </div>
                </div>
              </div>
            </template>
          </div>

          <div class="bg-pink-50/50 rounded-2xl p-3 space-y-3">
            <div class="flex items-center gap-2">
              <svg class="w-3.5 h-3.5 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
              <span class="text-xs text-pink-600 font-medium">生日礼包</span>
              <span class="text-[10px] text-pink-400">(用户生日当天可领取，每年一次)</span>
            </div>
            <div class="flex gap-2">
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送积分</div><input v-model.number="editLevel.birthdayGiftPoints" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-pink-300 outline-none transition-colors" placeholder="0"></div>
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送余额 ¥</div><input v-model.number="editLevel.birthdayGiftBalance" type="number" min="0" step="0.01" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-pink-300 outline-none transition-colors" placeholder="0"></div>
              <div class="flex-1"><div class="text-[10px] text-gray-400 mb-1">赠送经验</div><input v-model.number="editLevel.birthdayGiftExperience" type="number" min="0" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-pink-300 outline-none transition-colors" placeholder="0"></div>
            </div>
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[10px] text-gray-400">赠送优惠券</span>
                <span class="text-[9px] px-1.5 py-0.5 rounded bg-white text-pink-500 cursor-pointer border border-pink-200 active:bg-pink-50" @click="birthdayGiftCoupons.push({ name: '', type: 'fixed', value: 0, minOrder: 0, maxDiscount: 0, scope: 'all', category: 'member', validDays: 30 })">+ 添加</span>
              </div>
              <div v-if="!birthdayGiftCoupons.length" class="text-[9px] text-gray-300">无</div>
              <div v-for="(bc, bi) in birthdayGiftCoupons" :key="bi" class="bg-white rounded-lg p-2 mb-1.5 border border-pink-100 space-y-1 relative">
                <span class="absolute top-1 right-1.5 text-[9px] text-red-400 cursor-pointer active:text-red-500" @click="birthdayGiftCoupons.splice(bi, 1)">×</span>
                <div class="flex gap-1">
                  <div class="flex-[2]"><input v-model="bc.name" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-pink-300 outline-none" placeholder="券名称"></div>
                  <div class="flex-1">
                    <select v-model="bc.type" class="w-full h-7 border border-gray-200 rounded px-0.5 text-[9px] bg-gray-50 focus:border-pink-300 outline-none">
                      <option value="fixed">固定金额</option>
                      <option value="percent">百分比</option>
                    </select>
                  </div>
                </div>
                <div class="flex gap-1">
                  <div class="flex-1"><input v-model.number="bc.value" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-pink-300 outline-none" placeholder="面值"></div>
                  <div class="flex-1"><input v-model.number="bc.minOrder" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-pink-300 outline-none" placeholder="最低消费"></div>
                  <div class="flex-1"><input v-model.number="bc.validDays" type="number" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-pink-300 outline-none" placeholder="天数"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="pt-2 border-t border-gray-100">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs text-gray-500 font-medium">定价方案</span>
              <span class="text-[10px] px-2 py-1 rounded-lg bg-purple-50 text-purple-500 font-medium cursor-pointer active:bg-purple-100 transition-colors" @click="addPlan">+ 添加</span>
            </div>
            <div v-if="!plans.length" class="text-center py-4 text-[11px] text-gray-300">暂无方案，点击上方添加</div>
             <div v-for="(plan, idx) in plans" :key="idx" class="bg-gray-50 rounded-xl p-3 mb-2 space-y-2">
               <div class="flex justify-between items-center">
                 <span class="text-[10px] text-gray-400 font-medium">方案 {{ idx + 1 }}</span>
                 <span class="text-[10px] text-red-400 font-medium cursor-pointer active:text-red-500" @click="plans.splice(idx, 1)">移除</span>
               </div>
               <div class="flex gap-2">
                 <div class="flex-[3]"><div class="text-[10px] text-gray-400 mb-0.5">名称</div><input v-model="plan.name" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors" placeholder="如: 月度会员"></div>
                 <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">时长</div><input v-model.number="plan.durationDays" type="number" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors"></div>
               </div>
               <div class="flex gap-2">
                 <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">价格 ¥</div><input v-model.number="plan.price" type="number" step="0.01" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors"></div>
                 <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">原价 ¥</div><input v-model.number="plan.originalPrice" type="number" step="0.01" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors"></div>
               </div>
               <div class="flex gap-2">
                 <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">积分价</div><input v-model.number="plan.pointsPrice" type="number" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors"></div>
                 <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">积分原价</div><input v-model.number="plan.pointsOriginalPrice" type="number" class="w-full h-9 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-purple-300 outline-none transition-colors"></div>
               </div>
               <div class="pt-2 border-t border-dashed border-gray-200">
                 <span class="text-[10px] text-amber-500 font-medium">购买赠送（每次购买时额外赠送）</span>
                 <div class="flex gap-2 mt-1.5">
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">积分</div><input v-model.number="plan.giftPoints" type="number" min="0" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">余额 ¥</div><input v-model.number="plan.giftBalance" type="number" min="0" step="0.01" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">经验</div><input v-model.number="plan.giftExperience" type="number" min="0" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
                 </div>
                 <div class="flex gap-2 mt-1.5">
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">数据(MB)</div><input v-model.number="plan.giftDataLimitMb" type="number" min="0" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">文件(MB)</div><input v-model.number="plan.giftFileLimitMb" type="number" min="0" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0"></div>
                   <div class="flex-1"><div class="text-[10px] text-gray-400 mb-0.5">限购次数</div><input v-model.number="plan.purchaseLimit" type="number" min="0" class="w-full h-8 border border-gray-200 rounded-lg px-2.5 text-xs bg-white focus:border-amber-300 outline-none transition-colors" placeholder="0=不限"></div>
                 </div>
                 <div class="mt-1.5">
                   <div class="flex items-center justify-between mb-0.5">
                     <span class="text-[10px] text-gray-400">赠送优惠券</span>
                     <span class="text-[9px] px-1.5 py-0.5 rounded bg-white text-amber-500 cursor-pointer border border-amber-200 active:bg-amber-50" @click="addPlanCoupon(idx)">+ 添加</span>
                   </div>
                   <div v-if="!plan.giftCoupons || !plan.giftCoupons.length" class="text-[9px] text-gray-300">无</div>
                   <div v-for="(pc, pi) in (plan.giftCoupons || [])" :key="pi" class="bg-white rounded-lg p-2 mb-1.5 border border-amber-100 space-y-1 relative">
                     <span class="absolute top-1 right-1.5 text-[9px] text-red-400 cursor-pointer active:text-red-500" @click="plan.giftCoupons.splice(pi, 1)">×</span>
                     <div class="flex gap-1">
                       <div class="flex-[2]"><input v-model="pc.name" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="券名称"></div>
                       <div class="flex-1">
                         <select v-model="pc.type" class="w-full h-7 border border-gray-200 rounded px-0.5 text-[9px] bg-gray-50 focus:border-amber-300 outline-none">
                           <option value="fixed">固定金额</option>
                           <option value="percent">百分比</option>
                           <option value="fixed_points">固定积分</option>
                           <option value="points_percent">积分%</option>
                         </select>
                       </div>
                     </div>
                     <div class="flex gap-1">
                       <div class="flex-1"><input v-model.number="pc.value" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="面值"></div>
                       <div class="flex-1"><input v-model.number="pc.minOrder" type="number" step="0.01" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="最低消费"></div>
                       <div class="flex-1"><input v-model.number="pc.validDays" type="number" class="w-full h-7 border border-gray-200 rounded px-1.5 text-[9px] bg-gray-50 focus:border-amber-300 outline-none" placeholder="天数"></div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive, computed } from 'vue'
import request from '@/utils/http'

const levels = ref<any[]>([])
const showLevelDialog = ref(false)
const editLevel = reactive<any>({ id: 0, name: '', level: 1, tier: 1, price: 0, discountRate: 1, pointsMultiplier: 1, pointsDiscountRate: 1, textColor: '#FFFFFF', bgColor: '#508DFF', icon: '', benefits: '', dataLimitMb: 0, fileLimitMb: 0, filePolicyIds: '', giftPoints: 0, giftBalance: 0, giftExperience: 0, giftCouponIds: '', perks: '', titleId: 0, frameId: 0, dailyGiftEnabled: false, dailyGiftIntervalDays: 1, dailyGiftPoints: 0, dailyGiftBalance: 0, dailyGiftExperience: 0, dailyGiftCouponIds: '', birthdayGiftPoints: 0, birthdayGiftBalance: 0, birthdayGiftExperience: 0, birthdayGiftCouponIds: '', status: '1' })
const plans = reactive<{name: string; price: number; originalPrice: number; pointsPrice: number; pointsOriginalPrice: number; durationDays: number; giftPoints: number; giftBalance: number; giftExperience: number; giftCoupons: {name: string; type: string; value: number; minOrder: number; validDays: number}[]; giftDataLimitMb: number; giftFileLimitMb: number; purchaseLimit: number}[]>([])

const iconInput = ref<HTMLInputElement>()
const uploadingIcon = ref(false)

const policyList = ref<any[]>([])
const selectedPolicyIds = ref<number[]>([])

const giftCoupons = reactive<{name: string; type: string; value: number; minOrder: number; maxDiscount: number; scope: string; category: string; validDays: number}[]>([])
const dailyGiftCoupons = reactive<{name: string; type: string; value: number; minOrder: number; maxDiscount: number; scope: string; category: string; validDays: number}[]>([])
const birthdayGiftCoupons = reactive<{name: string; type: string; value: number; minOrder: number; maxDiscount: number; scope: string; category: string; validDays: number}[]>([])

const titleList = ref<any[]>([])
const frameList = ref<any[]>([])

const activeTab = ref('all')
const tabs = [
  { key: 'all', label: '全部' },
  { key: 'active', label: '已启用' },
  { key: 'inactive', label: '已禁用' },
]

const expanded = ref<Record<number, boolean>>({})

const filteredLevels = computed(() => {
  if (activeTab.value === 'active') return levels.value.filter(l => l.status === '1')
  if (activeTab.value === 'inactive') return levels.value.filter(l => l.status !== '1')
  return levels.value
})

const toggleExpand = (id: number) => {
  expanded.value = { ...expanded.value, [id]: !expanded.value[id] }
}

const togglePolicy = (id: number) => {
  const idx = selectedPolicyIds.value.indexOf(id)
  if (idx >= 0) selectedPolicyIds.value.splice(idx, 1)
  else selectedPolicyIds.value.push(id)
  editLevel.filePolicyIds = selectedPolicyIds.value.join(',')
}

const addGiftCoupon = () => {
  giftCoupons.push({ name: '', type: 'fixed', value: 0, minOrder: 0, maxDiscount: 0, scope: 'all', category: 'member', validDays: 30 })
}

const loadPolicies = async () => {
  try {
    const res: any = await request.get({ url: '/api/file-policy/list' })
    policyList.value = Array.isArray(res) ? res : (res?.data || res?.records || [])
  } catch (_e: unknown) { void _e }
}

const triggerIconUpload = () => iconInput.value?.click()

const handleIconUpload = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  uploadingIcon.value = true
  try {
    const fd = new FormData()
    fd.append('file', file)
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd })
    editLevel.icon = res?.url || res?.data?.url || res?.data || ''
  } catch (_e: unknown) { void _e }
  uploadingIcon.value = false
  input.value = ''
}

const loadTitles = async () => {
  try {
    const res: any = await request.get({ url: '/api/title/all' })
    titleList.value = Array.isArray(res) ? res : (res?.data || res?.records || [])
  } catch (_e: unknown) { void _e }
}

const loadFrames = async () => {
  try {
    const res: any = await request.get({ url: '/api/avatar-frame/all' })
    frameList.value = Array.isArray(res) ? res : (res?.data || res?.records || [])
  } catch (_e: unknown) { void _e }
}

const loadLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    if (res?.records) levels.value = res.records
    else if (res?.data?.records) levels.value = res.data.records
  } catch (_e: unknown) { void _e }
}

const parseGiftCoupons = (raw: string) => {
  try {
    const parsed = JSON.parse(raw || '[]')
    return Array.isArray(parsed) ? parsed : []
  } catch { return [] }
}

const openLevelDialog = (lv?: any) => {
  if (lv) {
    Object.assign(editLevel, {
      ...lv, id: lv.id,
      giftPoints: lv.giftPoints || 0, giftBalance: Number(lv.giftBalance) || 0,
      giftExperience: lv.giftExperience || 0, giftCouponIds: lv.giftCouponIds || '', perks: lv.perks || '',
      titleId: Number(lv.titleId) || 0, frameId: Number(lv.frameId) || 0,
      dailyGiftEnabled: !!lv.dailyGiftEnabled, dailyGiftIntervalDays: Number(lv.dailyGiftIntervalDays) || 1,
      dailyGiftPoints: Number(lv.dailyGiftPoints) || 0, dailyGiftBalance: Number(lv.dailyGiftBalance) || 0,
      dailyGiftExperience: Number(lv.dailyGiftExperience) || 0, dailyGiftCouponIds: lv.dailyGiftCouponIds || '',
      birthdayGiftPoints: Number(lv.birthdayGiftPoints) || 0, birthdayGiftBalance: Number(lv.birthdayGiftBalance) || 0,
      birthdayGiftExperience: Number(lv.birthdayGiftExperience) || 0, birthdayGiftCouponIds: lv.birthdayGiftCouponIds || ''
    })
    selectedPolicyIds.value = (lv.filePolicyIds || '').split(',').map(Number).filter(Boolean)
    giftCoupons.splice(0, giftCoupons.length, ...parseGiftCoupons(lv.giftCouponIds || ''))
    dailyGiftCoupons.splice(0, dailyGiftCoupons.length, ...parseGiftCoupons(lv.dailyGiftCouponIds || ''))
    birthdayGiftCoupons.splice(0, birthdayGiftCoupons.length, ...parseGiftCoupons(lv.birthdayGiftCouponIds || ''))
    plans.splice(0, plans.length, ...(lv.pricingPlans || []).map((p: any) => ({
      name: p.name || '', price: p.price || 0, originalPrice: p.originalPrice || 0,
      pointsPrice: p.pointsPrice || 0, pointsOriginalPrice: p.pointsOriginalPrice || 0,
      durationDays: p.durationDays || 30,
      giftPoints: p.giftPoints || 0, giftBalance: Number(p.giftBalance) || 0, giftExperience: p.giftExperience || 0,
      giftCoupons: parseGiftCoupons(p.giftCouponIds || ''),
      giftDataLimitMb: p.giftDataLimitMb || 0, giftFileLimitMb: p.giftFileLimitMb || 0, purchaseLimit: p.purchaseLimit || 0
    })))
  } else {
    Object.assign(editLevel, { id: 0, name: '', level: 1, tier: 1, price: 0, discountRate: 1, pointsMultiplier: 1, pointsDiscountRate: 1, textColor: '#FFFFFF', bgColor: '#508DFF', icon: '', benefits: '', dataLimitMb: 0, fileLimitMb: 0, filePolicyIds: '', giftPoints: 0, giftBalance: 0, giftExperience: 0, giftCouponIds: '', perks: '', titleId: 0, frameId: 0, dailyGiftEnabled: false, dailyGiftIntervalDays: 1, dailyGiftPoints: 0, dailyGiftBalance: 0, dailyGiftExperience: 0, dailyGiftCouponIds: '', birthdayGiftPoints: 0, birthdayGiftBalance: 0, birthdayGiftExperience: 0, birthdayGiftCouponIds: '', status: '1' })
    selectedPolicyIds.value = []
    giftCoupons.splice(0)
    dailyGiftCoupons.splice(0)
    birthdayGiftCoupons.splice(0)
    plans.splice(0)
  }
  showLevelDialog.value = true
}

const addPlan = () => {
  plans.push({ name: '', price: 0, originalPrice: 0, pointsPrice: 0, pointsOriginalPrice: 0, durationDays: 30, giftPoints: 0, giftBalance: 0, giftExperience: 0, giftCoupons: [], giftDataLimitMb: 0, giftFileLimitMb: 0, purchaseLimit: 0 })
}

const addPlanCoupon = (planIdx: number) => {
  if (!plans[planIdx].giftCoupons) plans[planIdx].giftCoupons = []
  plans[planIdx].giftCoupons.push({ name: '', type: 'fixed', value: 0, minOrder: 0, validDays: 30 })
}

const saveLevel = async () => {
  try {
    const data = {
      ...editLevel,
      giftCouponIds: JSON.stringify(giftCoupons.filter(c => c.name || c.value)),
      dailyGiftCouponIds: JSON.stringify(dailyGiftCoupons.filter(c => c.name || c.value)),
      birthdayGiftCouponIds: JSON.stringify(birthdayGiftCoupons.filter(c => c.name || c.value)),
      pricingPlans: plans.map(p => ({
        name: p.name, price: p.price, originalPrice: p.originalPrice,
        pointsPrice: p.pointsPrice, pointsOriginalPrice: p.pointsOriginalPrice,
        durationDays: p.durationDays,
        giftPoints: p.giftPoints, giftBalance: p.giftBalance, giftExperience: p.giftExperience,
        giftCouponIds: JSON.stringify((p.giftCoupons || []).filter((c: any) => c.name || c.value)),
        giftDataLimitMb: p.giftDataLimitMb, giftFileLimitMb: p.giftFileLimitMb, purchaseLimit: p.purchaseLimit
      }))
    }
    await request.post({ url: '/api/operation/membership-level/save', data })
    showLevelDialog.value = false
    loadLevels()
  } catch (_e: unknown) { void _e }
}

const deleteLevel = async (id: number) => {
  if (!confirm('确定删除该等级？')) return
  try {
    await request.del({ url: `/api/operation/membership-level/${id}` })
    loadLevels()
  } catch (_e: unknown) { void _e }
}

onMounted(() => { loadLevels(); loadPolicies(); loadTitles(); loadFrames() })
</script>

<style scoped>
.animate-slide-up {
  animation: slideUp 0.25s ease-out;
}
@keyframes slideUp {
  from { opacity: 0; transform: translateY(30px) scale(0.96); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
.list-enter-active {
  transition: all 0.4s cubic-bezier(0.22, 1, 0.36, 1);
}
.list-leave-active {
  transition: all 0.25s ease-in;
  position: absolute;
}
.list-enter-from {
  opacity: 0;
  transform: translateY(20px) scale(0.95);
}
.list-leave-to {
  opacity: 0;
  transform: translateX(-30px);
}
.list-move {
  transition: transform 0.35s ease;
}
</style>
