<template>
  <div class="forum-page mx-auto max-w-[430px] shadow-lg relative" style="min-height:100vh;background:var(--default-bg-color)">
    <!-- LOADING -->
    <div v-if="loading" class="flex justify-center pt-40">
      <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
    </div>

    <template v-else>
      <!-- STATUS BAR -->
      <div class="h-[34px] bg-white"/>

      <!-- NAVIGATION (sticky) -->
      <div class="nav-bar sticky top-0 z-10 bg-white">
        <div class="flex items-center justify-between h-[40px] px-4">
          <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
          <span class="text-[17px] text-[#111] font-bold">{{ sectionName }}</span>
          <div class="w-[32px] h-[32px] rounded-full bg-[#F0F0F0] flex items-center justify-center active:bg-[#E5E5E5]">
            <svg class="w-[16px] h-[16px] text-[#666]" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path stroke-linecap="round" d="M21 21l-4.35-4.35"/></svg>
          </div>
        </div>
      </div>

      <!-- COLLAPSIBLE HEADER AREA -->
      <div class="header-area">
        <!-- SECTION INFO -->
      <div class="bg-white px-5 py-3">
        <div class="flex items-center">
          <!-- Blue circle avatar -->
          <div class="w-[56px] h-[56px] rounded-full flex items-center justify-center flex-shrink-0 mr-2 overflow-hidden" style="position:relative">
            <span class="text-[20px] font-bold text-white w-full h-full flex items-center justify-center rounded-full" style="background:#22C1D0">{{ sectionName[0] }}</span>
            <img v-if="sectionInfo?.icon" :src="$fixImgUrl(sectionInfo.icon)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'"/>
          </div>

          <div class="flex-1 min-w-0">
            <div class="text-[16px] text-[#111] font-bold leading-tight">{{ sectionName }}</div>
            <div class="text-[12px] text-[#999] mt-0.5 leading-tight">
              帖子: {{ sectionInfo?.postCount || 0 }} | 今日浏览: {{ fmtCount(sectionInfo?.todayHeat || 0) }} | 总浏览: {{ fmtCount(sectionInfo?.viewCount || sectionInfo?.totalHeat || 0) }}
            </div>

            <!-- 圈主 -->
            <div v-if="moderators.length > 0" class="flex items-center gap-1 mt-1 active:opacity-70" @click="showModeratorModal = true">
              <span class="text-[12px] text-[#999]">圈主：</span>
              <div class="w-[18px] h-[18px] rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style="position:relative">
                <img src="@imgs/user/avatar.webp" class="w-full h-full object-cover" />
                <img v-if="moderators[0]?.userAvatar" :src="moderators[0].userAvatar" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- SECTION DIVIDER -->
      <div class="h-[14px] bg-white"/>

      <!-- PINNED / ANNOUNCEMENTS -->
      <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="bg-white px-5">
        <div v-if="globalPinnedPosts.length > 0">
          <div v-for="post in globalPinnedPosts" :key="'g-'+post.id"
            class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
            @click="openPostDetail(post.id)">
            <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">全站</span>
            <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
            <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <div v-if="sectionPinnedPosts.length > 0">
          <div v-for="(post, i) in sectionPinnedPosts" :key="'p-'+post.id"
            class="flex items-center gap-2 py-1.5 active:bg-[#FAFAFA] -mx-5 px-5 cursor-pointer"
            @click="openPostDetail(post.id)">
            <span class="text-[11px] px-[7px] py-[2px] rounded font-semibold text-[#D55667] bg-[#FFF0EF] flex-shrink-0">置顶</span>
            <span class="text-[13px] text-[#1A1A1A] font-medium flex-1 truncate">{{ post.title }}</span>
            <svg class="w-[11px] h-[11px] text-[#CCC] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
      </div>

      <!-- DIVIDER after pinned -->
      <div v-if="globalPinnedPosts.length > 0 || sectionPinnedPosts.length > 0" class="h-[8px] bg-white"/>
      </div>
      <!-- /COLLAPSIBLE HEADER AREA -->

      <!-- TAB BAR (sticky below nav when collapsed) -->
      <div class="tab-bar sticky z-10 bg-white px-4 pt-1 pb-1.5" style="top:40px">
        <div class="bg-[#F2F2F2] rounded-[10px] p-[3px] inline-flex">
          <div v-for="tab in tabs" :key="tab.key"
            class="px-3 py-[5px] text-[12px] rounded-[8px] cursor-pointer transition-all duration-200"
            :class="activeTab === tab.key ? 'bg-white text-[#1A1A1A] font-semibold shadow-sm' : 'text-[#999]'"
            @click="switchTab(tab.key)">
            {{ tab.label }}
          </div>
        </div>
      </div>

      <!-- POST LIST -->
      <div class="pb-[140px]">
        <div v-if="normalPosts.length === 0 && !loading" class="flex flex-col items-center justify-center py-32 text-gray-300">
          <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
          </svg>
          <span class="text-[13px]">还没有帖子，来发布第一条吧</span>
        </div>

        <div v-for="(post, i) in normalPosts" :key="post.id">
          <div class="bg-white mx-3 mb-3 rounded-xl px-4 pt-3.5 pb-3.5 cursor-pointer active:bg-[#FAFAFA] transition-colors"
            @click="openPostDetail(post.id)">

            <!-- Author Row -->
            <div class="flex items-start gap-2.5">
              <div class="w-[40px] h-[40px] flex-shrink-0 relative">
                <div class="w-[40px] h-[40px] rounded-full overflow-hidden">
                  <img src="@imgs/user/avatar.webp" class="w-full h-full object-cover rounded-full" />
                  <img v-if="post.userAvatar" :src="post.userAvatar" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'"/>
                </div>
                <img v-if="post.userMemberLevelIcon" :src="post.userMemberLevelIcon" style="position:absolute;right:-6px;bottom:-3px;width:16px;height:16px;border-radius:50%;object-fit:cover;z-index:3;border:2px solid #fff;box-shadow:0 2px 4px rgba(0,0,0,0.2)" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1 flex-wrap">
                  <span class="text-[14px] text-[#1a1a1a] font-semibold">{{ post.userName }}</span>
                  <img v-if="post.userExpLevelIcon && post.userExpLevelIcon.startsWith('http')" :src="post.userExpLevelIcon" style="width:26px;height:26px;object-fit:contain;flex-shrink:0;vertical-align:middle" @error="($event.target as HTMLImageElement).style.display='none'" />
                  <span v-else-if="post.userExpLevelName" class="text-[9px] px-[5px] py-[2px] rounded font-bold flex-shrink-0 leading-none" :style="{ color: post.userExpLevelTextColor || '#FFFFFF', background: post.userExpLevelBgColor || '#508DFF' }">{{ post.userExpLevelName }}</span>
                  <img v-if="post.userMemberLevelIcon" :src="post.userMemberLevelIcon" style="width:24px;height:24px;object-fit:contain;flex-shrink:0;vertical-align:middle" @error="($event.target as HTMLImageElement).style.display='none'" />
                  <img v-for="(icon, idx) in (post.userAllTitleIcons || '').split('|||').filter(Boolean)" :key="idx" :src="icon" style="width:24px;height:24px;object-fit:contain;flex-shrink:0;vertical-align:middle" @error="($event.target as HTMLImageElement).style.display='none'" />
                </div>
                <div class="flex items-center gap-1 text-[11px] text-[#B0B0B0] mt-px">
                  <span v-if="post.userLevelName && post.userLevelName !== '普通用户'" class="text-[9px] px-[5px] py-[1px] rounded font-bold flex-shrink-0 leading-none" :style="{ color: post.userLevelTextColor || '#FFFFFF', background: post.userLevelBgColor || '#508DFF' }">{{ post.userLevelName }}</span>
                  <span v-else class="font-medium" :style="{ color: post.userLevelTextColor || '#508DFF' }">{{ post.userLevelName || '普通用户' }}</span>
                  <template v-if="post.userTitleName"><span class="text-[#DDD]">·</span><span :style="{ color: post.userTitleColor || '#999' }">{{ post.userTitleName }}</span></template>
                  <template v-if="!post.userTitleName && post.device"><span class="text-[#DDD]">·</span><span class="truncate">{{ post.device }}</span></template>
                  <span class="ml-auto">{{ fmtRelativeTime(post.createTime) }}</span>
                </div>
              </div>
            </div>

            <!-- Title -->
            <div class="mt-2.5 text-[16px] text-[#111] font-bold leading-[1.45] line-clamp-2">
              <span v-if="post.isPinned" class="post-header-badge pin">置顶</span>
              <span v-if="post.isEssence" class="post-header-badge essence">精</span>
              <span v-if="post.isHot" class="post-header-badge hot">热</span>
              <span v-if="post.customBadge" class="post-header-badge custom">{{ post.customBadge }}</span>
              <span v-if="post.isLocked" class="post-header-badge lock">锁</span>
              {{ post.title }}
            </div>

            <!-- Content + Thumbnail -->
            <div class="flex gap-3 mt-2" v-if="post.content || (post.images && post.images.length)">
              <div class="flex-1 min-w-0">
                <div v-if="post.contentFiltered" class="text-[12px] text-[#999]">
                  部分内容付费
                  <span v-if="post.contentPrice" class="ml-1 font-semibold" style="color:#D48806">{{ post.contentPriceType === 'points' ? post.contentPrice + '积分' : '￥' + post.contentPrice }}</span>
                </div>
                <div v-else-if="post.content" class="text-[13px] text-[#AAA] leading-[1.5] line-clamp-2" v-html="stripContent(post.content)"></div>
              </div>
              <div v-if="post.images && post.images.length" class="w-[90px] h-[68px] flex-shrink-0 rounded-lg overflow-hidden bg-[#F5F5F5] relative">
                <img :src="$fixImgUrl(post.images[0])" class="w-full h-full object-cover" loading="lazy" alt="" @error="($event.target as HTMLImageElement).style.display='none'"/>
                <span v-if="post.images.length > 1" class="absolute right-1 bottom-1 text-[9px] px-[4px] py-[1px] rounded bg-black/50 text-white leading-tight">{{ post.images.length }}图</span>
              </div>
            </div>

            <!-- Tags + Stats -->
            <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-[#F5F5F5]">
              <div v-if="post.tags && post.tags.length" class="flex items-center gap-1.5 flex-wrap">
                <span v-for="tag in post.tags.slice(0,4)" :key="tag" class="text-[10px] px-2 py-[2px] rounded text-[#666] bg-[#F5F5F5] font-medium flex-shrink-0">{{ tag }}</span>
              </div>
              <div class="flex items-center gap-3 text-[12px] text-[#B0B0B0] ml-auto flex-shrink-0">
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                  {{ fmtCount(post.likeCount || 0) }}
                </span>
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                  {{ fmtCount(post.commentCount || 0) }}
                </span>
                <span class="inline-flex items-center gap-0.5">
                  <svg class="w-[13px] h-[13px]" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/></svg>
                  {{ fmtCount(post.viewCount || 0) }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- Load more -->
        <div v-if="loadingMore" class="flex justify-center py-6">
          <div class="w-5 h-5 border-2 border-[#508DFF] border-t-transparent rounded-full animate-spin"/>
        </div>
        <div v-else-if="!noMore && normalPosts.length > 0" class="text-center py-5 text-[12px] text-[#CCC]">上拉加载更多</div>
        <div v-else-if="noMore && normalPosts.length > 0" class="text-center py-5 text-[12px] text-[#DDD]">- 已加载全部 -</div>
      </div>
    </template>

    <!-- MODERATOR MODAL -->
    <ModeratorModal :visible="showModeratorModal" :section-id="sectionId" @close="showModeratorModal = false"/>

    <!-- FLOATING BUTTON -->
    <button class="publish-float-btn fixed right-[16px] bottom-[130px] w-[48px] h-[48px] rounded-full bg-[#222] flex items-center justify-center z-50 active:scale-90 transition-transform"
      style="box-shadow: 0 2px 12px rgba(0,0,0,0.25)"
      @click="goToPublish">
      <svg class="w-[20px] h-[20px] text-white" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
        <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCommunitySection, fetchCommunityPosts, fetchModerators } from '@/api/community'
import { useUserStore } from '@/store/modules/user'
import ModeratorModal from './ModeratorModal.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const sectionId = computed(() => Number(route.params.id) || 0)
const sectionName = computed(() => (route.query.name as string) || sectionInfo.value?.name || '综合讨论')

const sectionInfo = ref<any>(null)
const postList = ref<any[]>([])
const moderators = ref<any[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const noMore = ref(false)
const page = ref(1)
const activeTab = ref('hot')
const showModeratorModal = ref(false)

const tabs = [
  { key: 'hot', label: '热门' },
  { key: 'latest', label: '最新' },
  { key: 'recent_reply', label: '待回复' },
  { key: 'essence', label: '精华' }
]

const globalPinnedPosts = computed(() => postList.value.filter((p: any) => p.isGlobalPinned))
const sectionPinnedPosts = computed(() => postList.value.filter((p: any) => p.isPinned && !p.isGlobalPinned))
const normalPosts = computed(() => postList.value.filter((p: any) => !p.isPinned && !p.isGlobalPinned))

function stripContent(text: string) {
  if (!text) return ''
  try {
    const parsed = JSON.parse(text)
    if (Array.isArray(parsed)) return parsed.filter((b: any) => b.type === 'text').map((b: any) => (b.value || '').replace(/^#+\s*/gm, '').trim()).filter(Boolean).join(' ')
  } catch {}
  return text.replace(/^#+\s*/gm, '').replace(/[#*_~`\[\]]/g, '').replace(/\n+/g, ' ').trim()
}

function fmtCount(n: number): string {
  if (!n) return '0'
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return String(n)
}

function fmtRelativeTime(time: string): string {
  if (!time) return ''
  const d0 = new Date(time)
  if (isNaN(d0.getTime())) return time.slice(0, 10)
  const now = Date.now(); const ts = d0.getTime(); const diff = now - ts
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`
}

const avatarPalette = ['#508DFF', '#EC4899', '#F97316', '#14B8A6', '#8B5CF6', '#06B6D4', '#84CC16', '#E11D48', '#0EA5E9', '#7C3AED']
function avatarColor(name: string): string {
  let hash = 0; for (let i = 0; i < (name || '').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return avatarPalette[Math.abs(hash) % avatarPalette.length]
}

async function loadModerators() {
  if (!sectionId.value) return
  try { const r: any = await fetchModerators(sectionId.value); moderators.value = r?.data || r || [] } catch {}
}

async function loadSection() {
  if (!sectionId.value) return
  try { const r: any = await fetchCommunitySection(sectionId.value); sectionInfo.value = r.data || r } catch {}
}

async function loadPosts(reset = false) {
  if (reset) { page.value = 1; noMore.value = false; loading.value = true }
  else { loadingMore.value = true }
  try {
    const res: any = await fetchCommunityPosts({ sectionId: sectionId.value, sort: activeTab.value, page: page.value, pageSize: 20, viewerId: userStore.info?.userId || 0 })
    const list: any[] = res?.data?.list || res?.list || res?.data || []
    const parsed = list.map((p: any) => ({
      ...p,
      tags: typeof p.tags === 'string' ? JSON.parse(p.tags || '[]') : (p.tags || []),
      images: typeof p.images === 'string' ? JSON.parse(p.images || '[]') : (p.images || []),
      isGlobalPinned: !!p.isGlobalPinned
    }))
    if (reset) { postList.value = parsed } else { postList.value.push(...parsed) }
    if (list.length < 20) noMore.value = true
  } catch {} finally { loading.value = false; loadingMore.value = false }
}

function switchTab(tabKey: string) { if (activeTab.value !== tabKey) { activeTab.value = tabKey; loadPosts(true) } }
function openPostDetail(postId: number) { router.push(`/community/post/${postId}`) }
function goToPublish() { router.push(`/community/post/create/${sectionId.value}`) }

function onScroll() {
  if (loadingMore.value || noMore.value) return
  const { scrollHeight, clientHeight } = document.documentElement
  const top = window.scrollY || document.documentElement.scrollTop
  if (scrollHeight - top - clientHeight < 80) { page.value++; loadPosts(false) }
}

onMounted(async () => {
  await loadSection()
  loadModerators()
  loadPosts(true)
  window.addEventListener('scroll', onScroll, { passive: true })
})

onUnmounted(() => { window.removeEventListener('scroll', onScroll) })
</script>

<style scoped>
.line-clamp-1 { display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

.post-header-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  padding: 2px 7px;
  border-radius: 3px;
  font-weight: 600;
  margin-right: 5px;
  vertical-align: middle;
}
.post-header-badge.pin { color: #DC2626; background: #FEF2F2; }
.post-header-badge.essence { color: #EA580C; background: #FFF7ED; }
.post-header-badge.hot { color: #DC2626; background: #FEF2F2; }
.post-header-badge.custom { color: #508DFF; background: #F0F5FF; }
.post-header-badge.lock { color: #999; background: #F5F5F5; }

.publish-float-btn {
  right: max(16px, calc((100vw - 430px) / 2 + 16px));
}
</style>

<style>
/* Mobile frame effect on desktop */
@media (min-width: 431px) {
  body {
    background: #E8E8E8 !important;
  }
}
</style>
