<template>
  <div style="min-height: 100vh; background: var(--app-page-bg); display: flex; flex-direction: column">
    <div style="flex: 1; overflow-y: auto; padding-bottom: 64px">
      <!-- 个人信息区 -->
      <div style="display: flex; align-items: center; padding: 16px">
        <div
          style="
            position: relative;
            width: 72px;
            height: 72px;
            flex-shrink: 0;
          "
        >
          <img
            v-if="activeFrameUrl"
            :src="activeFrameUrl"
            style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
          />
          <div
            style="
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              width: 52px;
              height: 52px;
              border-radius: 50%;
              background: #f3f4f6;
              display: flex;
              align-items: center;
              justify-content: center;
              overflow: hidden;
              cursor: pointer;
              z-index: 1;
            "
            @click="handleAvatarClick"
          >
            <img
              v-if="isLogin && userInfo.avatar"
              :src="$fixImgUrl(userInfo.avatar)"
              style="width: 100%; height: 100%; object-fit: cover"
            />
            <img
              v-else
              src="@imgs/user/avatar.webp"
              style="width: 100%; height: 100%; object-fit: cover"
            />
          </div>
        </div>
        <div style="margin-left: 12px; flex: 1; cursor: pointer" @click="goExperience">
          <div
            style="font-size: 16px; font-weight: 600; color: #1f2937; cursor: pointer"
            @click.stop="handleAvatarClick"
          >{{
            isLogin ? (userInfo.nickname || userInfo.userName || '用户') : '请先登录'
          }}</div>
          <div style="display: flex; align-items: center; gap: 8px; margin-top: 2px">
            <img
              v-if="isLogin && expLevelIcon"
              :src="expLevelIcon"
              style="width: 28px; height: 28px; object-fit: contain"
            />
            <span
              v-else
              style="font-size: 12px; font-weight: 500; padding: 2px 8px; border-radius: 4px"
              :style="{ color: expLevelTextColor, background: expLevelBgColor }"
            >{{ isLogin ? levelName : 'Lv.0' }}</span>
            <div
              style="
                flex: 1;
                height: 6px;
                background: #f3f4f6;
                border-radius: 999px;
                overflow: hidden;
                max-width: 180px;
              "
            >
              <div
                style="height: 100%; border-radius: 999px"
                :style="{ width: expPercent + '%', background: expLevelBgColor }"
              />
            </div>
          </div>
        </div>
        <div style="display: flex; align-items: center; gap: 4px; cursor: pointer" @click="goExperience">
          <span style="font-size: 12px; font-weight: 500; color: #9ca3af">{{ expDisplay }}</span>
          <svg
            style="width: 16px; height: 16px; color: #9ca3af"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 会员卡片 -->
      <div
        style="margin: 0 12px; border-radius: 12px; padding: 16px; cursor: pointer; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: #fff; position: relative; overflow: hidden"
        @click="handleMembershipClick"
      >
        <div style="position: absolute; right: -20px; top: -20px; width: 100px; height: 100px; border-radius: 50%; background: rgba(255,255,255,0.05)"/>
        <div style="position: absolute; right: 30px; top: 10px; width: 50px; height: 50px; border-radius: 50%; background: rgba(255,255,255,0.08)"/>
        <div style="position: relative; z-index: 1; display: flex; align-items: center; justify-content: space-between">
          <div>
            <div style="font-size: 12px; opacity: 0.7; margin-bottom: 4px">会员中心</div>
            <div style="font-size: 18px; font-weight: 700; margin-bottom: 6px">{{ isLogin ? memberLevelName : '普通会员' }}</div>
            <div style="font-size: 12px; opacity: 0.75">{{ isLogin ? (membershipExpireStr || '永久有效') : '点击查看会员权益' }}</div>
          </div>
          <svg style="width: 20px; height: 20px; opacity: 0.7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 我的账户卡片 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; padding: 16px">
        <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 12px"
          >我的账户</div
        >
        <div style="display: grid; grid-template-columns: repeat(4, 1fr)">
          <div
            style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer"
            @click="handleAccountItem('balance')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? balanceStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">余额</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('points')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{
              isLogin ? pointsStr : '--'
            }}</span>
            <span style="font-size: 10px; color: #9ca3af">积分</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('fans')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{ isLogin ? (userStore.info.fansCount || userStore.info.fans_count || 0) : '--' }}</span>
            <span style="font-size: 10px; color: #9ca3af">粉丝</span>
          </div>
          <div
            style="
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 2px;
              border-left: 1px solid #f3f4f6; cursor: pointer
            "
            @click="handleAccountItem('purchases')"
          >
            <span style="font-size: 14px; font-weight: 600; color: #1f2937">{{ isLogin ? (userStore.info.purchaseCount || userStore.info.purchase_count || 0) : '--' }}</span>
            <span style="font-size: 10px; color: #9ca3af">付费</span>
          </div>
        </div>
      </div>

      <!-- 功能图标 -->
      <div style="background: #fff; margin: 0 12px; border-radius: 16px; padding: 20px 0 8px 0; overflow: hidden">
        <div
          ref="iconScrollRef"
          style="display: flex; overflow-x: auto; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding: 0 4px"
          @scroll="onIconScroll"
        >
          <div
            v-for="(page, pi) in funcIconPages"
            :key="pi"
            style="flex: 0 0 100%; scroll-snap-align: start; display: grid; grid-template-columns: repeat(4, 1fr); row-gap: 20px; padding: 0 4px"
          >
            <div
              v-for="item in page"
              :key="item.label || ('_empty_'+pi)"
              style="
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 6px;
                cursor: pointer;
              "
              :style="{ visibility: item.label ? 'visible' : 'hidden' }"
              @click="item.label && handleFuncIcon(item)"
            >
              <div
                style="
                  width: 44px;
                  height: 44px;
                  border-radius: 8px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                "
                :style="{ background: item.label ? item.bg : 'transparent' }"
              >
                <svg
                  v-if="item.label"
                  style="width: 20px; height: 20px; color: #fff"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path :d="item.icon" />
                </svg>
              </div>
              <span style="font-size: 11px; color: #374151">{{ item.label }}</span>
            </div>
          </div>
        </div>
        <div
          style="
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            padding: 12px 0;
          "
        >
          <div
            v-for="(_, pi) in funcIconPages"
            :key="pi"
            :style="{
              width: activeIconPage === pi ? '12px' : '6px',
              height: activeIconPage === pi ? '4px' : '6px',
              borderRadius: '999px',
              background: activeIconPage === pi ? '#00bfa5' : '#e5e7eb',
              transition: 'all 0.2s',
            }"
          />
        </div>
        <div
          v-if="bannerConfig.show"
          style="
            margin: 0 4px 12px 4px;
            background: var(--app-page-bg);
            border-radius: 12px;
            display: flex;
            align-items: center;
            padding: 10px 12px;
            gap: 8px;
            cursor: pointer;
          "
          @click="goBannerUrl"
        >
          <svg
            style="width: 16px; height: 16px; color: #6b7280"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fill-rule="evenodd"
              d="M18 3a1 1 0 00-1.447-.894L8.763 6H5a3 3 0 000 6h.28l1.771 5.316A1 1 0 008 18h1a1 1 0 001-1v-4.382l6.553 3.276A1 1 0 0018 15V3z"
              clip-rule="evenodd"
            />
          </svg>
          <span
            style="
              flex: 1;
              font-size: 12px;
              color: #6b7280;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
            "
            >{{ bannerConfig.text }}</span
          >
          <svg
            style="width: 14px; height: 14px; color: #9ca3af"
            fill="none"
            stroke="currentColor"
            stroke-width="2.5"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      <!-- 菜单列表 -->
      <div style="background: #fff; margin: 12px; border-radius: 16px; overflow: hidden">
        <div
          v-for="(item, idx) in computedMenuItems"
          :key="item.label"
          style="display: flex; align-items: center; padding: 14px 16px; cursor: pointer"
          :style="{
            borderBottom: idx < computedMenuItems.length - 1 ? '1px solid #f9fafb' : 'none'
          }"
          @click="handleMenuItem(item)"
        >
          <svg
            style="width: 20px; height: 20px; margin-right: 12px; flex-shrink: 0"
            :style="{ color: item.highlight ? '#00BFA5' : '#9ca3af' }"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path :d="item.icon" />
          </svg>
          <span
            style="flex: 1; font-size: 14px"
            :style="{
              color: item.highlight ? '#00BFA5' : '#374151',
              fontWeight: item.highlight ? '600' : '400'
            }"
            >{{ item.label }}</span
          >
          <svg
            style="width: 16px; height: 16px; color: #d1d5db"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>

    <!-- 卡密兑换弹窗 -->
    <div
      v-if="showCardKeyDialog"
      style="
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
      "
      @click.self="showCardKeyDialog = false"
    >
      <div style="background: #fff; border-radius: 16px; width: 320px; padding: 24px 20px 16px">
        <div style="font-size: 16px; font-weight: 600; color: #1f2937; margin-bottom: 16px"
          >卡密兑换</div
        >
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.cardNo"
            placeholder="请输入卡号"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div style="margin-bottom: 12px">
          <input
            v-model="cardKeyForm.password"
            type="text"
            placeholder="请输入卡密密码"
            style="
              width: 100%;
              padding: 10px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              font-size: 14px;
              outline: none;
              box-sizing: border-box;
            "
          />
        </div>
        <div v-if="cardKeyMsg" style="font-size: 12px; color: #00bfa5; margin-bottom: 8px">{{
          cardKeyMsg
        }}</div>
        <div style="display: flex; gap: 10px">
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #f3f4f6;
              color: #374151;
              cursor: pointer;
            "
            @click="showCardKeyDialog = false"
            >取消</button
          >
          <button
            style="
              flex: 1;
              padding: 10px;
              border-radius: 8px;
              font-size: 14px;
              border: none;
              background: #00bfa5;
              color: #fff;
              cursor: pointer;
            "
            :disabled="cardKeyLoading"
            @click="handleRedeemCardKey"
            >{{ cardKeyLoading ? '兑换中...' : '确认兑换' }}</button
          >
        </div>
      </div>
    </div>

    <!-- 底部5栏Tab -->
    <div
      style="
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: #fff;
        border-top: 1px solid #f3f4f6;
        display: flex;
        align-items: center;
        justify-content: space-around;
        padding: 4px 0 calc(max(6px, env(safe-area-inset-bottom)));
        z-index: 10;
      "
    >
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/browse')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M4 21V9l8-6 8 6v12h-6v-7h-4v7H4z" />
        </svg>
        <span style="font-size: 10px">首页</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/category')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z" />
        </svg>
        <span style="font-size: 10px">应用</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/updates')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM4.5 9c.83 0 1.5-.67 1.5-1.5S5.33 6 4.5 6 3 6.67 3 7.5 3.67 9 4.5 9zm15 0c.83 0 1.5-.67 1.5-1.5S20.33 6 19.5 6 18 6.67 18 7.5 18.67 9 19.5 9zm-15 6c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5zm15 0c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5z" />
        </svg>
        <span style="font-size: 10px">社区</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #9ca3af;
        "
        @click="$router.push('/appstore/game')"
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z" />
        </svg>
        <span style="font-size: 10px">发现</span>
      </div>
      <div
        style="
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          cursor: pointer;
          color: #00bfa5;
        "
      >
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
        </svg>
        <span style="font-size: 10px">我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, onMounted } from 'vue'
  import { useRouter } from 'vue-router'
  import { useUserStore } from '@/store/modules/user'
  import { fetchRedeemCardKey, fetchGetUserInfo } from '@/api/appstore'
  import { fetchPluginInject } from '@/api/operation'
  import { fetchUserAvatarFrames } from '@/api/avatar-frame'

  const router = useRouter()
  const userStore = useUserStore()

  const showCardKeyDialog = ref(false)
  const cardKeyForm = ref({ cardNo: '', password: '' })
  const cardKeyMsg = ref('')
  const cardKeyLoading = ref(false)
  const activeFrameUrl = ref('')

  const isLogin = computed(() => userStore.isLogin)
  const userInfo = computed(() => userStore.info || {})

  const isAdmin = computed(() => {
    const roles: string[] = userStore.info.roles || []
    return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
  })

  const expCurrent = ref(0)
  const expMax = ref(1000)
  const expLevelName = ref('Lv.1')
  const expLevelIcon = ref('')
  const expLevelTextColor = ref('#FFFFFF')
  const expLevelBgColor = ref('#508DFF')

  const bannerConfig = ref<{ show: boolean; text: string; url: string }>({
    show: true,
    text: '全站规则，快来看看，不然就亏大了',
    url: '/help/rules'
  })

  const loadBannerConfig = async () => {
    try {
      const res: any = await fetchPluginInject()
      const plugins = res?.data || res || []
      const fp = Array.isArray(plugins) ? plugins.find((p: any) => p.name === 'feature-panel') : plugins['feature-panel']
      if (fp?.config?.mineBanner) {
        bannerConfig.value = { ...bannerConfig.value, ...fp.config.mineBanner }
      }
    } catch {}
  }

  const goBannerUrl = () => {
    const url = bannerConfig.value.url
    if (!url) return
    if (url.startsWith('http')) {
      window.open(url, '_blank')
    } else {
      router.push(url)
    }
  }

  onMounted(() => {
    loadBannerConfig()
    loadActiveFrame()
    refreshUserInfo()
  })

  const refreshUserInfo = async () => {
    try {
      const data = await fetchGetUserInfo()
      userStore.setUserInfo(data)
    } catch {}
  }

  const loadActiveFrame = async () => {
    if (!isLogin.value) return
    try {
      const res: any = await fetchUserAvatarFrames()
      const active = res.frames?.find((f: any) => f.isActive)
      activeFrameUrl.value = active?.image_url || ''
    } catch {}
  }

  const levelName = computed(() => {
    if (!isLogin.value) return 'Lv.0'
    return expLevelName.value || 'Lv.1'
  })

  const memberLevelName = computed(() => {
    if (!isLogin.value) return '普通会员'
    return userStore.info.levelName || '普通会员'
  })

  const expDisplay = computed(() => {
    if (!isLogin.value) return '0/1000'
    return `${expCurrent.value || 0}/${expMax.value}`
  })

  const expPercent = computed(() => {
    if (!isLogin.value || !expMax.value) return 0
    return Math.min(100, Math.round((expCurrent.value / expMax.value) * 100))
  })

  const fetchExpLevels = async () => {
    try {
      const { fetchExpLevelList } = await import('@/api/operation')
      const data: any = await fetchExpLevelList()
      const levels = data?.records || data || []
      if (levels.length > 0) {
        levels.sort((a: any, b: any) => a.level - b.level)
        const exp = userStore.info.experience || 0
        expCurrent.value = exp
        let current = levels[0]
        let next: any = null
        for (const l of levels) {
          const req = l.expRequired || l.exp_required || 0
          if (req <= exp) current = l
          if (req > exp && !next) next = l
        }
        expLevelName.value = current.name || current.expLevelName || 'Lv.1'
        const icon = current.icon || ''
        expLevelIcon.value = (icon && (icon.startsWith('http') || icon.startsWith('/') || icon.startsWith('data:'))) ? icon : ''
        expLevelTextColor.value = current.textColor || current.text_color || '#FFFFFF'
        expLevelBgColor.value = current.bgColor || current.bg_color || '#508DFF'
        if (next) {
          expMax.value = next.expRequired || next.exp_required || 1000
        } else {
          expMax.value = levels[levels.length - 1].expRequired || levels[levels.length - 1].exp_required || 1000
        }
      }
    } catch (_e: unknown) {
      void _e
    }
  }

  fetchExpLevels()

  const formatNum = (val: number): string => {
    if (val >= 10000) {
      const w = Math.floor(val / 100) / 100
      return w % 1 === 0 ? `${w}万` : `${w.toFixed(2)}万`
    }
    return Number.isInteger(val) ? `${val}` : val.toFixed(2)
  }

  const balanceStr = computed(() => {
    if (!isLogin.value) return '--'
    const b = Number(userStore.info.balance || 0)
    return b >= 10000 ? formatNum(b) : b.toFixed(2)
  })

  const pointsStr = computed(() => {
    if (!isLogin.value) return '--'
    const p = Number(userStore.info.points || 0)
    return formatNum(p)
  })

  const membershipExpireStr = computed(() => {
    const t = userStore.info.expireTime
    if (!t) return ''
    try {
      const d = new Date(t)
      if (isNaN(d.getTime())) return ''
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} 到期`
    } catch { return '' }
  })

  const funcIcons = [
    {
      label: '应用投稿',
      bg: '#3B82F6',
      icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4'
    },
    {
      label: '数据明细',
      bg: '#F97316',
      icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12'
    },
    {
      label: '个人空间',
      bg: '#6366F1',
      icon: 'M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z M12 11v4m-2-2h4'
    },
    {
      label: '签到',
      bg: '#F59E0B',
      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2zm3-6h.01M9 12l2 2 4-4'
    },
    {
      label: '头像管理',
      bg: '#22C55E',
      icon: 'M4 4v3a2 2 0 002 2h9a1 1 0 01.987.839l.73 4A2 2 0 0115.73 16H4a2 2 0 01-2-2V6a2 2 0 012-2m0 0l.804-2.413A1 1 0 015.723 3H18a2 2 0 012 2v8m-5 1h5a2 2 0 012 2v1a2 2 0 01-2 2h-1a2 2 0 01-2-2v-1m0-2h.01'
    },
    {
      label: '排行榜',
      bg: '#EC4899',
      icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'
    },
    {
      label: '邀请福利',
      bg: '#10B981',
      icon: 'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z'
    },
    {
      label: '优惠券中心',
      bg: '#f97316',
      icon: 'M20 12v-1.23a1 1 0 00-1.57-.82L15 12m-1.57 2.82A1 1 0 0112 14V9m0-6a9 9 0 100 18 9 9 0 000-18z M4.93 4.93a9.97 9.97 0 000 14.14M5.64 5.64a8.97 8.97 0 000 12.72M15 19a9.05 9.05 0 013-.41'
    },
    {
      label: '我的认证',
      bg: '#10b981',
      icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z'
    }
  ]

  const iconScrollRef = ref<HTMLElement | null>(null)
  const activeIconPage = ref(0)
  const PAGE_SIZE = 8
  const funcIconPages = computed(() => {
    const pages: any[][] = []
    for (let i = 0; i < funcIcons.length; i += PAGE_SIZE) {
      const chunk = funcIcons.slice(i, i + PAGE_SIZE)
      while (chunk.length < PAGE_SIZE) {
        chunk.push({ label: '', bg: '', icon: '' })
      }
      pages.push(chunk)
    }
    return pages
  })

  function onIconScroll() {
    if (!iconScrollRef.value) return
    const scrollLeft = iconScrollRef.value.scrollLeft
    const pageWidth = iconScrollRef.value.clientWidth
    const page = Math.round(scrollLeft / pageWidth)
    activeIconPage.value = page
  }

  const menuItems = [
    {
      label: '管理中心',
      icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '后台管理',
      icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '板块管理',
      icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10',
      highlight: true,
      adminOnly: true
    },
    {
      label: '话题管理',
      icon: 'M7 20h4m0 0h2m-2 0V8a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zm4-14h6a2 2 0 012 2v2a2 2 0 01-2 2h-6m0-6V4a2 2 0 012-2h4a2 2 0 012 2v2m-6 6h6m0 0a2 2 0 012 2v4a2 2 0 01-2 2h-4a2 2 0 01-2-2v-2',
      highlight: true,
      adminOnly: true
    },
    {
      label: '审核管理',
      icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
      highlight: true,
      adminOnly: true
    },
    {
      label: '浏览足迹',
      icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
    },
    {
      label: '卡密兑换',
      icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'
    },
    {
      label: '主题选择',
      icon: 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01'
    },
    {
      label: '交流群组',
      icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'
    },
    {
      label: '联系我们',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z'
    },
    {
      label: '退出登录',
      icon: 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1',
      loginOnly: true
    },
    {
      label: '我的评论',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
      loginOnly: true
    }
  ]

  const computedMenuItems = computed(() => {
    const items = [...menuItems]
    return items.filter((item) => {
      if (item.adminOnly && !isAdmin.value) return false
      if (item.loginOnly && !isLogin.value) return false
      return true
    })
  })

  const handleAccountItem = (type: string) => {
    if (!isLogin.value) {
      router.push('/appstore/browse/login')
      return
    }
    if (type === 'balance' || type === 'points') {
      router.push('/appstore/assets')
      return
    }
    const uid = userStore.info.userId || 0
    router.push(`/appstore/records?type=${type}&userId=${uid}`)
  }

  const handleFuncIcon = (item: any) => {
    if (item.label === '应用投稿') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/submissions')
    } else if (item.label === '签到') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/checkin')
    } else if (item.label === '邀请福利') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/invite')
    } else if (item.label === '数据明细') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      const uid = userStore.info.userId || 0
      router.push(`/appstore/records?type=overview&userId=${uid}`)
    } else if (item.label === '优惠券中心') {
      router.push('/appstore/coupon')
    } else if (item.label === '排行榜') {
      router.push('/appstore/ranking')
    } else if (item.label === '浏览足迹') {
      router.push('/appstore/footprints')
    } else if (item.label === '头像管理') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/avatar-frame')
    } else if (item.label === '个人空间') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/personal-space')
    } else if (item.label === '我的认证') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      router.push('/appstore/verification')
    }
  }

  const goExperience = () => {
    router.push('/appstore/experience')
  }

  const handleAvatarClick = () => {
    if (!isLogin.value) {
      router.push('/appstore/browse/login')
    } else {
      router.push('/appstore/profile')
    }
  }

  const handleMembershipClick = () => {
    router.push('/appstore/membership')
  }

  const handleMenuItem = (item: any) => {
    if (item.label === '卡密兑换') {
      if (!isLogin.value) {
        router.push('/appstore/browse/login')
        return
      }
      cardKeyForm.value = { cardNo: '', password: '' }
      cardKeyMsg.value = ''
      showCardKeyDialog.value = true
      return
    }
    if (item.label === '管理中心') {
      router.push('/appstore/admin-center')
    } else if (item.label === '后台管理') {
      router.push('/dashboard/console')
    } else if (item.label === '板块管理') {
      router.push('/appstore/section-manage')
    } else if (item.label === '话题管理') {
      router.push('/appstore/topic-manage')
    } else if (item.label === '审核管理') {
      router.push('/appstore/review-mobile')
    } else if (item.label === '退出登录') {
      userStore.logOut()
      router.replace('/appstore/mine')
    } else if (item.label === '我的评论') {
      router.push('/appstore/profile/comments')
    } else if (item.label === '浏览足迹') {
      router.push('/appstore/footprints')
    } else if (item.label === '主题选择') {
      router.push('/appstore/layout-themes')
    } else if (item.label === '联系我们') {
      router.push('/appstore/discover-chat')
    } else if (item.label === '交流群组') {
      router.push('/appstore/chatrooms')
    }
  }

  const handleRedeemCardKey = async () => {
    if (!cardKeyForm.value.cardNo || !cardKeyForm.value.password) {
      cardKeyMsg.value = '请输入卡号和密码'
      return
    }
    cardKeyLoading.value = true
    cardKeyMsg.value = ''
    try {
      const data = await fetchRedeemCardKey({
        cardNo: cardKeyForm.value.cardNo,
        password: cardKeyForm.value.password,
        userId: userStore.info.userId || 0,
        userName: userStore.info.userName || ''
      })
      cardKeyMsg.value = data.msg || '兑换成功'
      if (data.code === 200) {
        showCardKeyDialog.value = false
      }
    } catch (e: any) {
      cardKeyMsg.value = e?.msg || '兑换失败'
    } finally {
      cardKeyLoading.value = false
    }
  }
</script>
