<template>
  <div class="post-detail-page">
    <!-- ==================== TOP NAVBAR (WHITE) ==================== -->
    <div class="navbar">
      <button class="nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <div class="nav-author">
        <div class="nav-avatar" style="position:relative">
          <img src="@imgs/user/avatar.webp" class="nav-avatar-pic" />
          <img v-if="(post as any)?.userAvatar" :src="$fixImgUrl((post as any).userAvatar)" class="nav-avatar-pic" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
        </div>
        <div class="nav-author-info">
          <span class="nav-name">{{ post?.userName || '--' }}</span>
          <span class="nav-time">{{ fmtTime(post?.createTime || '') }}</span>
        </div>
      </div>
      <div class="nav-actions">
        <button v-if="getUserId() && post?.userId !== getUserId()" class="nav-follow-btn" :class="{ 'is-following': following }" @click.stop="handleFollowAuthor">{{ following ? '已关注' : '+ 关注' }}</button>
        <svg class="nav-dots" width="20" height="20" viewBox="0 0 24 24" fill="#333" @click.stop="showMenu = !showMenu"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </div>
      </div>

    <!-- ==================== DROPDOWN MENU ==================== -->
    <Teleport to="body">
      <div v-if="showMenu" class="menu-overlay" @click="showMenu = false">
        <div class="menu-panel" @click.stop>
          <div class="menu-item" @click="handleShare">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/></svg>
            <span>分享</span>
          </div>
          <div v-if="(post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin())" class="menu-item" @click="goEditPost(); showMenu = false">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            <span>编辑</span>
          </div>
          <div v-if="(post as any)?.isLocked" class="menu-item menu-item-locked" @click="showMenu = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            <span>{{ userIsAdmin() ? '已锁定(管理员可管理)' : '已锁定' }}</span>
          </div>
          <template v-if="hasCommunityPermission('pin') || hasCommunityPermission('essence') || hasCommunityPermission('boost') || hasCommunityPermission('lock')">
            <div class="menu-divider" />
            <div v-if="hasCommunityPermission('pin')" class="menu-item" @click="handlePinPin(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 7h6l-4 5 2 8-7-4-7 4 2-8-4-5h6z"/></svg>
              <span>{{ post?.isPinned ? '取消置顶' : '置顶' }}</span>
            </div>
            <div v-if="hasCommunityPermission('pin')" class="menu-item" @click="handleGlobalPin(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              <span>{{ (post as any)?.isGlobalPinned ? '取消全站置顶' : '全站置顶' }}</span>
            </div>
            <div v-if="hasCommunityPermission('essence')" class="menu-item" @click="handleEssence(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26"/></svg>
              <span>{{ post?.isEssence ? '取消加精' : '加精' }}</span>
            </div>
            <div v-if="hasCommunityPermission('boost')" class="menu-item" @click="handleHot(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z"/></svg>
              <span>{{ post?.isHot ? '取消热帖' : '热帖' }}</span>
            </div>
            <div v-if="hasCommunityPermission('boost')" class="menu-item" @click="handleCustomBadge(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 12h8M12 8v8"/></svg>
              <span>{{ (post as any)?.customBadge ? '修改自定义' : '自定义' }}</span>
            </div>
            <div v-if="hasCommunityPermission('lock')" class="menu-item" @click="handleLock(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              <span>{{ (post as any)?.isLocked ? '解锁' : '锁定' }}</span>
            </div>
          </template>
          <template v-if="(post as any)?.isLocked ? userIsAdmin() : (post?.userId === getUserId() || userIsAdmin())">
            <div class="menu-divider" />
            <div class="menu-item menu-item-danger" @click="handleDeletePost(); showMenu = false">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              <span>删除</span>
            </div>
          </template>
          <div v-if="getUserId()" class="menu-item" @click="showReportDialog = true; showMenu = false">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></svg>
            <span>举报</span>
          </div>
          <div v-if="(post as any)?.isLocked && post?.userId === getUserId() && !userIsAdmin()" class="menu-item" @click="handleRequestUnlock(); showMenu = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1"/></svg>
            <span>申请解锁</span>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== LOADING / EMPTY ==================== -->
    <div v-if="loading" class="loading-wrap"><div class="spin"/></div>
    <div v-else-if="!post" class="empty-wrap"><span>帖子不存在或已被删除</span></div>

    <!-- ==================== CONTENT ==================== -->
    <div v-else class="content-scroll">

      <!-- ===== POST INFO AREA ===== -->
      <div class="post-info-area">

      <!-- ===== TITLE ===== -->
      <h1 class="post-title">
        <span class="title-badge title-badge-pin" v-if="post.isPinned">顶</span>
        <span class="title-badge title-badge-essence" v-if="post.isEssence">精</span>
        <span class="title-badge title-badge-hot" v-if="post.isHot">热</span>
        <span class="title-badge title-badge-lock" v-if="(post as any).isLocked">锁</span>
        <span class="title-badge title-badge-custom" v-if="(post as any).customBadge">{{ (post as any).customBadge }}</span>
        <span>{{ post.title }}</span>
      </h1>

      <div v-if="post.status === 'pending'" class="status-bar status-pending">审核中，仅自己可见</div>
      <div v-else-if="post.status === 'rejected'" class="status-bar status-rejected">审核未通过{{ post.rejectReason ? '：' + post.rejectReason : '' }}</div>
      <div v-if="(post as any).isLocked" class="status-bar status-locked">该帖已被管理员锁定，禁止编辑和评论</div>

      <!-- ===== SOFTWARE INFO LIST (【】 format) ===== -->
      <div v-if="post.hasResource || post.content" class="info-list">
        <div class="info-row" v-if="post.title">
          <span class="info-label">【标题】</span><span class="info-value">{{ post.title }}</span>
        </div>
        <div class="info-row" v-if="post.title && post.title.includes('v')">
          <span class="info-label">【软件版本】</span><span class="info-value info-link">{{ post.title.match(/v[\d.]+/)?.[0] || '--' }}</span>
        </div>
        <div class="info-row" v-if="post.resourceType">
          <span class="info-label">【软件大小】</span><span class="info-value">{{ post.resourceType }}</span>
        </div>
        <div class="info-row" v-if="post.device">
          <span class="info-label">【测试系统】</span><span class="info-value">{{ post.device }}</span>
        </div>
      </div>

      <!-- ===== CONTENT BLOCKS WITH PER-BLOCK VISIBILITY ===== -->
      <template v-if="contentBlocks.length">
        <!-- Global login barrier for unauthenticated users -->
        <div v-if="globalLoginBarrier" class="perm-barrier perm-barrier-login">
          <div class="pb-deco">
            <div class="pb-deco-bg"></div>
            <div class="pb-deco-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
          </div>
          <div class="pb-body">
            <div class="pb-title">请登录后查看</div>
            <div class="pb-sub">
              <p class="pb-hint">登录后即可查看此内容</p>
            </div>
            <div class="pb-actions">
              <button class="pb-btn pb-btn-primary" @click="$router.push('/auth/login')">立即登录</button>
              <button class="pb-btn pb-btn-secondary" @click="$router.push('/auth/register')">注册账号</button>
            </div>
          </div>
        </div>
        <!-- Per-block barriers (only when user is authenticated) -->
        <template v-if="!globalLoginBarrier">
        <template v-for="(block, idx) in contentBlocks" :key="idx">
          <!-- Barrier for this block -->
          <div v-if="!globalLoginBarrier && blockBarrier(idx)" class="perm-barrier" :class="'perm-barrier-' + effectiveBlockVisibility(idx)">
            <div class="pb-deco">
              <div class="pb-deco-bg"></div>
              <div class="pb-deco-icon">
                <svg v-if="effectiveBlockVisibility(idx)==='paid'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><ellipse cx="12" cy="5" rx="10" ry="3"/><path d="M2 12c0 1.66 4.48 3 10 3s10-1.34 10-3"/><path d="M2 5v14c0 1.66 4.48 3 10 3s10-1.34 10-3V5"/></svg>
                <svg v-else-if="effectiveBlockVisibility(idx)==='login'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                <svg v-else-if="effectiveBlockVisibility(idx)==='comment'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                <svg v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 15c6.67-4 13.33-4 20 0"/><circle cx="12" cy="7" r="4"/><path d="M9 12l2 2 4-4"/></svg>
                <svg v-else width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/><circle cx="12" cy="16" r="1.2"/></svg>
              </div>
            </div>
            <div class="pb-body">
              <div class="pb-title">{{ blockBarrierText(idx) }}</div>
              <div class="pb-sub" v-if="effectiveBlockVisibility(idx)==='paid'">
                <span class="pb-price-tag">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/><text x="12" y="17" text-anchor="middle" fill="#fff" font-size="12" font-weight="bold">￥</text></svg>
                  {{ blockBarrierPrice(idx)?.price || 0 }} {{ blockBarrierPrice(idx)?.type==='points'?'积分':'余额' }}
                </span>
                <p class="pb-sold" v-if="post?.soldCount != null">已售 {{ post.soldCount }}</p>
              </div>
              <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='password'">
                <input
                  v-model="pwdInput"
                  type="password"
                  placeholder="请输入访问密码"
                  class="pb-pwd-input"
                  @keyup.enter="verifyBlockPassword(idx)"
                />
              </div>
              <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'">
                <p class="pb-hint">{{ levelBarrierDesc(idx) }}</p>
              </div>
              <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='login'">
                <p class="pb-hint">登录后即可查看此内容</p>
              </div>
              <div class="pb-sub" v-else-if="effectiveBlockVisibility(idx)==='comment'">
                <p class="pb-hint">发表评论后即可解锁</p>
              </div>
              <div class="pb-actions">
                <template v-if="effectiveBlockVisibility(idx)==='paid'">
                  <button class="pb-btn pb-btn-primary" @click="openPayDialog(idx)">立即购买</button>
                </template>
                <template v-else-if="effectiveBlockVisibility(idx)==='password'">
                  <button class="pb-btn pb-btn-primary" @click="verifyBlockPassword(idx)">验证密码</button>
                </template>
                <template v-else-if="effectiveBlockVisibility(idx)==='login'">
                  <button class="pb-btn pb-btn-primary" @click="$router.push('/auth/login')">立即登录</button>
                  <button class="pb-btn pb-btn-secondary" @click="$router.push('/auth/register')">注册账号</button>
                </template>
                <template v-else-if="effectiveBlockVisibility(idx)==='comment'">
                  <button class="pb-btn pb-btn-primary" @click="showCommentDialog = true">发表评论</button>
                </template>
                <template v-else-if="effectiveBlockVisibility(idx)==='level' || effectiveBlockVisibility(idx)==='level1' || effectiveBlockVisibility(idx)==='level2'">
                  <button class="pb-btn pb-btn-premium" @click="$router.push('/membership')">开通会员</button>
                </template>
              </div>
            </div>
          </div>
          <!-- Block content (shown when no barrier) -->
          <template v-else>
            <!-- Text Block -->
            <div v-if="block.type === 'text' && block.value" class="post-body" v-html="block.value" @click="handlePostBodyClick"></div>
            <!-- Image Block -->
            <div v-else-if="block.type === 'image' && block.images && block.images.length" class="images-grid" :class="gridClassFor(block.images.length)">
              <div v-for="(img, i) in block.images" :key="i" class="image-item" @click="previewBlockImage(block.images!, i)">
                <img :src="$fixImgUrl(img)" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
            </div>
            <!-- Attachment Block -->
            <div v-else-if="block.type === 'attachment'" class="block-attachment-card" @click="handleAttachmentClick(block)">
              <div class="bac-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
              </div>
              <div class="bac-info">
                <div class="bac-title">{{ block.title || '附件' }}</div>
                <div class="bac-desc">{{ block.desc || '' }}</div>
              </div>
              <div class="bac-price">
                <span v-if="isAttachPurchased(block.url)" class="bac-purchased">已购买</span>
                <span v-else-if="block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0" class="bac-free">免费</span>
                <span v-else class="bac-coin">{{ block.coin || 0 }}{{ block.priceType === 'points' ? '积分' : '余额' }}</span>
              </div>
            </div>
            <!-- Link Block -->
            <div v-else-if="block.type === 'link'" class="block-link-card" @click="block.url && window.open(block.url, '_blank')">
              <div class="blc-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
              </div>
              <div class="blc-info">
                <div class="blc-title">{{ block.title || '链接' }}</div>
                <div class="blc-url">{{ block.url || '' }}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
            </div>
            <!-- App Block -->
            <div v-else-if="block.type === 'app'" class="block-app-card" @click="block.appId && $router.push('/appstore/browse/detail/' + block.appId)">
              <div class="bac-app-icon" :style="{ background: block.appIcon ? undefined : avatarColor(block.appName || 'a') }">
                <img v-if="block.appIcon" :src="$fixImgUrl(block.appIcon)" class="bac-app-img" @error="($event.target as HTMLImageElement).style.display='none'" />
                <span v-else class="bac-app-letter">{{ (block.appName || 'A')[0] }}</span>
              </div>
              <div class="bac-app-info">
                <div class="bac-app-name">{{ block.appName || '应用' }}</div>
                <div class="bac-app-desc">{{ block.desc || '' }}</div>
              </div>
              <div class="bac-app-price">
                <span v-if="!block.coinCount || block.coinCount === 0" class="bac-free">免费</span>
                <span v-else class="bac-coin">{{ block.coinCount }}余额</span>
              </div>
            </div>
          </template>
        </template>
        </template>
      </template>
      <!-- fallback: plain text if no blocks parsed -->
      <div v-else-if="post.content" class="post-body" v-html="post.content"></div>

      <!-- ===== DOWNLOAD SECTION ===== -->
      <div v-if="post.hasResource" class="download-block">
        <div class="download-heading">下载地址</div>
        <div class="download-card">
          <div class="download-icon-box">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
          </div>
          <div class="download-info">
            <div class="download-desc">评论999最高爆100金币</div>
            <div class="download-hint">需要支付 {{ post.resourcePrice || 1 }}余额</div>
          </div>
          <div class="download-btn-wrap">
            <span class="download-price-tag">$ {{ post.resourcePrice || 1 }}</span>
            <button class="download-btn">{{ post.resourcePrice || 1 }}余额</button>
          </div>
        </div>
        <div v-if="post.extractCode" class="extract-row">
          <span>提取码：</span><span class="extract-val">{{ post.extractCode }}</span>
        </div>
      </div>

      <!-- ===== TAGS ===== -->
      <div class="tags-row">
        <span class="tag-pill" v-for="tag in tagsList" :key="tag">
          <span class="tag-dot" :style="{background: tagDotColor(tag)}"/>
          {{ tag }}
        </span>
      </div>


      <!-- ===== DONATE DISPLAY ===== -->
      <div v-if="coinLogs.length > 0" class="reward-display" @click="toggleCoinLogs">
        <div class="reward-avatars">
          <div v-for="(donor, idx) in donorAvatars.slice(0,6)" :key="donor.userId"
            class="reward-avatar" style="position:relative"
            :style="{ marginLeft: idx > 0 ? '-8px' : '0', zIndex: 6 - idx }">
            <img src="@imgs/user/avatar.webp" class="reward-avatar-pic" />
            <img v-if="donor.avatar" :src="$fixImgUrl(donor.avatar)" class="reward-avatar-pic" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
          </div>
          <div v-if="donorAvatars.length > 6" class="reward-avatar reward-avatar-more" style="margin-left:-8px;z-index:0">+{{ donorAvatars.length - 6 }}</div>
        </div>
        <div class="reward-summary">
          <span class="reward-label">{{ coinLogs.length }}次打赏，共{{ getRewardSummary() }}</span>
        </div>
      </div>

    <!-- ==================== COIN LOGS MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showCoinLogs" class="donate-overlay" @click.self="showCoinLogs = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏记录</span>
            <button class="dm-close" @click="showCoinLogs = false">&times;</button>
          </div>
          <div class="coin-logs-body">
            <div v-if="coinLogs.length===0" class="coin-logs-empty">暂无打赏记录</div>
            <div v-else class="donate-item" v-for="log in coinLogs" :key="log.id">
              <div class="donate-avatar" style="position:relative">
                <img src="@imgs/user/avatar.webp" class="donate-avatar-pic" />
                <img v-if="log.fromUserAvatar || log.userAvatar" :src="$fixImgUrl(log.fromUserAvatar || log.userAvatar)" class="donate-avatar-pic" style="position:absolute;inset:0;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
              </div>
              <div class="donate-info">
                <span class="donate-name">{{ log.fromUserName }}</span>
                <span class="donate-time">{{ fmtTime(log.createTime) }}</span>
              </div>
              <div class="donate-amount">
                <span class="donate-val">{{ log.amount }}</span>
                <span class="donate-unit">{{ log.coinType === 'points' ? '积分' : '余额' }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- 附件信息弹窗 -->
    <Teleport to="body">
      <div v-if="attachInfoDialog.show" class="attach-overlay" @click.self="attachInfoDialog.show = false">
        <div class="attach-modal">
          <div class="attach-modal-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22C3D0" stroke-width="2"><path stroke-linecap="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
          </div>
          <h3 class="attach-modal-title">{{ attachInfoDialog.title || '附件信息' }}</h3>
          <p v-if="attachInfoDialog.desc" class="attach-modal-desc">{{ attachInfoDialog.desc }}</p>
          <div class="attach-modal-fields">
            <div v-if="attachInfoDialog.url" class="attach-field">
              <span class="attach-field-label">下载链接</span>
              <span class="attach-field-value attach-field-url">{{ attachInfoDialog.url }}</span>
            </div>
            <div v-if="attachInfoDialog.extractCode" class="attach-field">
              <span class="attach-field-label">提取码</span>
              <span class="attach-field-value attach-field-code">{{ attachInfoDialog.extractCode }}</span>
            </div>
          </div>
          <div class="attach-modal-actions">
            <button class="attach-btn attach-btn-copy" @click="navigator.clipboard?.writeText(attachInfoDialog.url);ElMessage.success('链接已复制')">复制链接</button>
            <button class="attach-btn attach-btn-close" @click="attachInfoDialog.show = false">关闭</button>
          </div>
        </div>
      </div>
    </Teleport>

      </div><!-- /post-info-area -->

      <!-- ===== COMMENT COMPOSE DIALOG ===== -->
      <Teleport to="body">
        <div v-if="showCommentDialog" class="comment-dialog-overlay" @click.self="showCommentDialog = false">
          <div class="comment-dialog">
            <div class="comment-dialog-header">
              <span class="comment-dialog-title">发表评论</span>
              <button class="comment-dialog-close" @click="showCommentDialog = false">&times;</button>
            </div>
            <div class="comment-dialog-body">
              <textarea v-model="newCommentText" placeholder="说说你的看法..." class="comment-dialog-textarea" rows="4"></textarea>
              <div class="comment-dialog-toolbar">
                <label class="comment-dialog-img-btn">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.6" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                  <input type="file" accept="image/*" multiple hidden @change="onCommentImagesSelected"/>
                </label>
              </div>
              <div v-if="commentImages.length > 0" class="comment-dialog-imgs">
                <div v-for="(img, idx) in commentImages" :key="idx" class="comment-dialog-img-item">
                  <img :src="$fixImgUrl(img)" class="comment-dialog-img-thumb" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  <button class="comment-dialog-img-remove" @click="commentImages.splice(idx,1)">&times;</button>
                </div>
              </div>
            </div>
            <div class="comment-dialog-footer">
              <button class="comment-dialog-cancel" @click="showCommentDialog = false">取消</button>
              <button class="comment-dialog-send" :disabled="!newCommentText.trim() && commentImages.length===0" @click="submitComment">发送</button>
            </div>
          </div>
        </div>
      </Teleport>

      <!-- ===== COMMENTS ===== -->
      <div class="comments-section">
        <div class="comments-header">
          <span class="comments-title">共 {{ commentsTotal }} 回复</span>
          <div class="comments-sort">
            <button v-for="s in ['默认','最新','热门','楼主']" :key="s" class="sort-btn" :class="{active: sortBy===s}" @click="changeSortBy(s)">{{ s }}</button>
          </div>
        </div>

        <!-- 列表 -->
        <div v-if="commentsLoading" class="comments-loading"><span class="spin"/></div>
        <div v-else-if="sortedComments.length===0" class="comments-empty">
          <div class="empty-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
          <p>还没有评论</p>
          <span>来说两句吧</span>
        </div>

        <div v-else class="comments-list">
          <div v-for="c in sortedComments" :key="c.id" class="comment-card" :class="{ pinned: c.isPinned, hot: c.likeCount >= 10 && !c.isPinned }">
            <div class="comment-card-inner">
            <div class="comment-avatar-img" style="position:relative">
              <img src="@imgs/user/avatar.webp" class="comment-avatar-pic" />
              <img v-if="c.userAvatar" :src="$fixImgUrl(c.userAvatar)" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;z-index:1" @error="($event.target as HTMLImageElement).style.display='none'" />
            </div>
            <div class="comment-main">
              <div class="comment-meta">
                <span class="comment-username">{{ c.userName }}</span>
                <img v-if="c.userExpLevelIcon && c.userExpLevelIcon.startsWith('http')" :src="c.userExpLevelIcon" style="width:30px;height:30px;object-fit:contain;flex-shrink:0;" @error="($event.target as HTMLImageElement).style.display='none'" />
                <span v-else-if="c.userExpLevelName" class="comment-level-badge" :style="{ color: c.userExpLevelTextColor || '#FFFFFF', background: c.userExpLevelBgColor || '#508DFF' }">{{ c.userExpLevelName }}</span>
                <span v-if="c.userIsVerified" class="comment-verified-badge">认证</span>
                <span v-if="c.userId === post?.userId" class="comment-author-badge">作者</span>
                <span v-if="c.isPinned" class="comment-pinned-badge">置顶</span>
                <span v-if="c.likeCount >= 10 && !c.isPinned" class="comment-hot-badge">热</span>
                <span class="comment-meta-spacer"></span>
                <div class="comment-menu-wrap">
                  <button class="comment-menu-btn" @click.stop="toggleCommentMenu(c.id)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
                  </button>
                  <div v-if="commentMenuId===c.id" class="comment-dropdown">
                    <div v-if="canPinComment(c)" class="comment-menu-item" @click.stop="handlePinComment(c);commentMenuId=null">{{ c.isPinned ? '取消置顶' : '置顶' }}</div>
                    <div v-if="canDeleteComment(c)" class="comment-menu-item" @click.stop="handleDeleteComment(c);commentMenuId=null">删除</div>
                    <div v-if="getUserId()" class="comment-menu-item" @click.stop="handleReportComment(c);commentMenuId=null">举报</div>
                  </div>
                </div>
              </div>
              <div v-if="c.userTitleName" class="comment-title-row">
                <span class="comment-title-badge" :style="{color: c.userTitleColor || '#409EFF', background: c.userTitleBgColor || '#ecf5ff'}">{{ c.userTitleName }}</span>
              </div>
              <div class="comment-content" v-html="c.content"></div>
              <!-- Comment images -->
              <div v-if="c.images && c.images.length" class="comment-imgs">
                <img v-for="(img, idx) in c.images" :key="idx" :src="$fixImgUrl(img)" class="comment-img" @click.stop="previewCommentImage(c.images!, idx)" @error="($event.target as HTMLImageElement).style.display='none'"/>
              </div>
              <div class="comment-footer">
                <span class="comment-time">{{ fmtTime(c.createTime) }}</span>
                <button class="comment-act" @click="toggleReplyInput(c)">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 17 4 12 9 7"/><polyline points="20 17 15 12 20 7"/></svg>
                  <span>{{ c.replyCount || 0 }}</span>
                </button>
                <button class="comment-act" :class="{liked: c._isLiked}" @click="handleCommentLike(c)">
                  <svg width="14" height="14" viewBox="0 0 24 24" :fill="c._isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>
                  <span>{{ c.likeCount || 0 }}</span>
                </button>
              </div>

              <!-- 回复框 -->
              <div v-if="replyingTo===c.id" class="reply-input-area">
                <div class="reply-input-row">
                  <input v-model="replyText" :placeholder="'回复 '+c.userName+'...'" class="reply-input" @keyup.enter="submitReply(c)"/>
                  <label class="reply-img-btn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                    <input type="file" accept="image/*" multiple hidden @change="onReplyImagesSelected"/>
                  </label>
                  <button class="reply-cancel" @click="replyingTo=null;replyText='';replyImages=[]">取消</button>
                  <button class="reply-send" :disabled="!replyText.trim() && replyImages.length===0" @click="submitReply(c)">发送</button>
                </div>
                <div v-if="replyImages.length > 0" class="comment-img-previews">
                  <div v-for="(img, idx) in replyImages" :key="idx" class="comment-img-preview">
                    <img :src="$fixImgUrl(img)" class="comment-img-thumb" @error="($event.target as HTMLImageElement).style.display='none'"/>
                    <button class="comment-img-remove" @click="replyImages.splice(idx,1)">&times;</button>
                  </div>
                </div>
              </div>

              <!-- 子回复 -->
              <div v-if="c.replies&&c.replies.length" class="replies-wrap">
                <div v-for="r in c.replies" :key="r.id" class="reply-item">
                  <div class="reply-meta">
                    <span class="reply-username">{{ r.userName }}</span>
                    <img v-if="r.userExpLevelIcon && r.userExpLevelIcon.startsWith('http')" :src="r.userExpLevelIcon" style="width:30px;height:30px;object-fit:contain;flex-shrink:0;" @error="($event.target as HTMLImageElement).style.display='none'" />
                    <span v-else-if="r.userExpLevelName" class="comment-level-badge sm" :style="{ color: r.userExpLevelTextColor || '#FFFFFF', background: r.userExpLevelBgColor || '#508DFF' }">{{ r.userExpLevelName }}</span>
                    <span v-if="r.userTitleName" class="comment-title-badge" :style="{color: r.userTitleColor || '#409EFF', background: r.userTitleBgColor || '#ecf5ff'}">{{ r.userTitleName }}</span>
                    <span v-if="r.userIsVerified" class="comment-verified-badge sm">认证</span>
                    <span class="reply-colon">：</span>
                    <span class="reply-content" v-html="r.content"></span>
                  </div>
                  <div v-if="r.images && r.images.length" class="comment-imgs" style="margin-top:4px">
                    <img v-for="(img, idx) in r.images" :key="idx" :src="$fixImgUrl(img)" class="comment-img" @click.stop="previewCommentImage(r.images!, idx)" @error="($event.target as HTMLImageElement).style.display='none'"/>
                  </div>
                  <div class="reply-footer">
                    <span class="comment-time">{{ fmtTime(r.createTime) }}</span>
                    <button v-if="canDeleteReply(r)" class="reply-del" @click="handleDeleteReply(c, r)">删除</button>
                    <button v-if="getUserId()" class="reply-del" @click="handleReportComment(r)">举报</button>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
            <div v-if="hasMoreComments" class="load-more-wrap" @click="loadMoreComments">
              <span v-if="loadingMore" class="load-more-spin"></span>
              <span v-else>加载更多评论 ({{ commentsTotal - comments.length }})</span>
            </div>
          </div>
      </div>

    <!-- 底部操作栏 -->
    <div class="comment-bottom-bar" v-if="!(post as any)?.isLocked || userIsAdmin()">
      <button class="comment-bottom-donate" @click="showDonateModal = true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
        <span>打赏</span>
      </button>
      <div class="comment-bottom-trigger" @click="openCommentDialog">
        <span class="comment-bottom-placeholder">{{ (post as any)?.tags?.length ? '#' + (post as any).tags[0] : '' }} 说点什么...</span>
        <svg class="comment-bottom-emoji" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
      </div>
      <div class="comment-bottom-actions">
          <button class="comment-bottom-act" @click="openCommentDialog">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
            <span>{{ post?.commentCount || 0 }}</span>
          </button>
          <button class="comment-bottom-act" :class="{active: post?.isLiked}" @click="toggleLike">
            <svg width="18" height="18" viewBox="0 0 24 24" :fill="post?.isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3m7-2V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z"/></svg>
            <span :class="{active: post?.isLiked}">{{ post?.likeCount || 0 }}</span>
          </button>
          <button class="comment-bottom-act" :class="{active: post?.isFavorited}" @click="toggleFav">
            <svg width="18" height="18" viewBox="0 0 24 24" :fill="post?.isFavorited ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <span :class="{active: post?.isFavorited}">{{ post?.favoriteCount || 0 }}</span>
          </button>
          <button class="comment-bottom-act">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            <span>{{ post?.viewCount || 0 }}</span>
          </button>
      </div>
    </div>
  </div>

    <!-- ==================== DONATE MODAL ==================== -->
    <Teleport to="body">
      <div v-if="showDonateModal" class="donate-overlay" @click.self="showDonateModal = false">
        <div class="donate-modal">
          <div class="dm-header">
            <span class="dm-title">打赏作者</span>
            <button class="dm-close" @click="showDonateModal = false">&times;</button>
          </div>
          <div class="dm-body">
            <!-- Balance + Points -->
            <div class="dm-balance-row">
              <div class="dm-bal-item">
                <span class="dm-bal-label">余额</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.balance || 0 }}</span>
              </div>
              <div class="dm-bal-item">
                <span class="dm-bal-label">积分</span>
                <span class="dm-bal-val">{{ (userStore.info as any)?.points || 0 }}</span>
              </div>
            </div>
            <!-- Payment type -->
            <div class="dm-type-row">
              <span class="dm-type-label">支付方式</span>
              <div class="dm-type-tabs">
                <button class="dm-type-tab" :class="{active: donateType === 'coin'}" @click="donateType = 'coin'">余额</button>
                <button class="dm-type-tab" :class="{active: donateType === 'points'}" @click="donateType = 'points'">积分</button>
              </div>
            </div>
            <!-- Amount selector -->
            <div class="dm-amount-row">
              <span class="dm-type-label">打赏数量</span>
              <div class="dm-amount-opts">
                <button v-for="n in donateType==='coin' ? [1,5,10,50] : [10,50,100,500]" :key="n" class="dm-amt-btn" :class="{active: donateAmount===n}" @click="donateAmount=n">{{ n }}</button>
              </div>
            </div>
            <!-- Custom amount -->
            <div class="dm-custom-row">
              <input v-model.number="donateAmount" type="number" min="1" class="dm-custom-input" placeholder="自定义数量"/>
            </div>
          </div>
          <div class="dm-footer">
            <button class="dm-cancel" @click="showDonateModal = false">取消</button>
            <button class="dm-confirm" :disabled="donating || donateAmount < 1" @click="doDonate">{{ donating ? '打赏中...' : '确认打赏 ' + donateAmount + (donateType==='points'?'积分':'余额') }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== REPORT DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showReportDialog" class="donate-overlay" @click.self="showReportDialog = false">
        <div class="report-dialog">
          <div class="report-header">
            <span>举报{{ reportTarget === 'comment' ? '评论' : '帖子' }}</span>
            <button class="report-close" @click="showReportDialog = false">&times;</button>
          </div>
          <div class="report-body">
            <p class="report-label">请选择举报原因</p>
            <div class="report-types">
              <label v-for="r in reportTypes" :key="r" class="report-type-item" :class="{ active: reportReason === r }">
                <input type="radio" :value="r" v-model="reportReason" />
                <span>{{ r }}</span>
              </label>
            </div>
            <div class="report-detail-row">
              <textarea v-model="reportDetail" class="report-textarea" placeholder="补充详细描述(选填)" maxlength="200"></textarea>
            </div>
          </div>
          <div class="report-footer">
            <button class="report-cancel" @click="showReportDialog = false">取消</button>
            <button class="report-confirm" :disabled="reporting || !reportReason" @click="doReport">{{ reporting ? '提交中...' : '提交举报' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== IMAGE PREVIEW ==================== -->
    <Teleport to="body">
      <div v-if="previewVisible" class="img-over" @click="closePreview">
        <span class="img-over-close" @click="closePreview">&times;</span>
        <span class="img-over-idx">{{ previewIndex+1 }}/{{ previewImages.length }}</span>
        <img v-if="previewImages[previewIndex]" :src="previewImages[previewIndex]" class="img-over-src" @error="($event.target as HTMLImageElement).style.display='none'"/>
        <button class="img-over-prev" @click.stop="prevImage">&lsaquo;</button>
        <button class="img-over-next" @click.stop="nextImage">&rsaquo;</button>
      </div>
    </Teleport>

    <!-- ==================== PAYMENT CONFIRM DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showPayConfirm" class="modal-overlay" @click.self="showPayConfirm = false">
        <div class="confirm-modal">
          <div class="confirm-title">确认支付</div>
          <div class="confirm-detail">
            <div class="confirm-row"><span>内容</span><span class="strong">{{ post?.title || '' }}</span></div>
            <div class="confirm-row"><span>支付方式</span><span class="strong">{{ payBlockPrice.type === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <template v-if="selectedCouponInfo">
              <div class="confirm-row"><span>优惠券</span><span class="accent">{{ selectedCouponInfo.name }} ({{ isPointsCoupon ? '' : '¥' }}{{ payBlockPrice.price }} - {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }})</span></div>
            </template>
            <div class="confirm-row"><span>支付金额</span><span class="accent">{{ payBlockPrice.type === 'points' ? finalPayPrice + '积分' : '¥' + finalPayPrice }}</span></div>
          </div>
          <div class="pay-coupon-section">
            <ElSelect
              v-model="selectedCouponId"
              placeholder="不使用优惠券"
              clearable
              style="width:100%"
              popper-class="coupon-select-popper"
              @change="onPayCouponSelect"
            >
              <ElOption :value="0" label="不使用优惠券" />
              <ElOption
                v-for="c in usableCoupons"
                :key="c.userCouponId"
                :value="c.userCouponId"
                :label="couponLabel(c)"
              >
                <div class="coupon-dd-item">
                  <span class="coupon-dd-left">{{ couponLabel(c) }}</span>
                  <span class="coupon-dd-right">{{ c.expireTime ? '到期 '+fmtDate(c.expireTime) : '' }}</span>
                </div>
              </ElOption>
            </ElSelect>
          </div>
          <div class="confirm-actions">
            <button class="confirm-btn cancel" @click="showPayConfirm = false">取消</button>
            <button class="confirm-btn primary" :disabled="payLoading" @click="handleConfirmPay">
              {{ payLoading ? '支付中...' : '确认支付' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ==================== PAYMENT RESULT DIALOG ==================== -->
    <Teleport to="body">
      <div v-if="showPayResult" class="modal-overlay" @click.self="showPayResult = false">
        <div class="result-modal">
          <div v-if="payResultSuccess" class="result-icon success">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </div>
          <div v-else class="result-icon fail">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M6 18L18 6M6 6l12 12"/></svg>
          </div>
          <div class="result-title">{{ payResultSuccess ? '购买成功' : '购买失败' }}</div>
          <div class="result-msg">{{ payResultMsg }}</div>
          <div v-if="payResultSuccess" class="result-detail">
            <div class="result-row"><span>内容</span><span class="strong">{{ post?.title || '' }}</span></div>
            <div class="result-row"><span>支付方式</span><span class="strong">{{ payBlockPrice.type === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <div class="result-row"><span>金额</span><span class="accent">{{ payBlockPrice.type === 'points' ? payBlockPrice.price + '积分' : '¥' + payBlockPrice.price }}</span></div>
          </div>
          <button class="result-btn primary" @click="showPayResult = false">我知道了</button>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/store/modules/user'
import { useMenuStore } from '@/store/modules/menu'
import { fetchCommunityPost, likePost, favoritePost, sendCoin, fetchCoinLogs, fetchComments, postComment, deleteComment, pinComment, pinPost, essencePost, hotPost, lockPost, globalPinPost, setCustomBadge, reportPost, reportComment, requestUnlock } from '@/api/community'
import { fetchUsableCoupons } from '@/api/coupon'
import { addBrowseHistory } from '@/api/browse-history'
import request from '@/utils/http'
import type { CommunityPost, CommunityComment } from '@/api/community'

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string
  images?: string[]
  title?: string
  desc?: string
  url?: string
  extractCode?: string
  priceType?: string
  coin?: number
  coinCount?: number
  appId?: number
  appName?: string
  appIcon?: string
  fileName?: string
  visibility?: string
  visibilityLevel?: number
  visibilityLevelName?: string
  visibilityPasswordTips?: string
  _filtered?: boolean
}

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const menuStore = useMenuStore()
const { menuList } = storeToRefs(menuStore)
const postId = computed(() => Number(route.params.id) || 0)

const post = ref<CommunityPost | null>(null)
const loading = ref(true)
const comments = ref<(CommunityComment & { _isLiked?: boolean; _originalLiked?: boolean })[]>([])
const commentsLoading = ref(false)
const commentsPage = ref(1)
const commentsTotal = ref(0)
const commentsPageSize = 20
const hasMoreComments = computed(() => comments.value.length < commentsTotal.value)
const loadingMore = ref(false)
const replyingTo = ref<number | null>(null)
const replyText = ref('')
const newCommentText = ref('')
const commentImages = ref<string[]>([])
const showCommentDialog = ref(false)
const openCommentDialog = () => { showCommentDialog.value = true }
const replyImages = ref<string[]>([])
const uploadingImage = ref(false)
const commentInputEl = ref<HTMLInputElement | null>(null)
const previewVisible = ref(false)
const previewIndex = ref(0)
const previewImages = ref<string[]>([])
const sortBy = ref('默认')
const commentMenuId = ref<number | null>(null)

function toggleCommentMenu(id: number) {
  commentMenuId.value = commentMenuId.value === id ? null : id
}

let closeCommentMenuHandler: ((e: MouseEvent) => void) | null = null
watch(commentMenuId, (val) => {
  if (val != null) {
    closeCommentMenuHandler = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (!target.closest('.comment-menu-wrap')) commentMenuId.value = null
    }
    setTimeout(() => document.addEventListener('click', closeCommentMenuHandler!), 0)
  } else if (closeCommentMenuHandler) {
    document.removeEventListener('click', closeCommentMenuHandler)
    closeCommentMenuHandler = null
  }
})
const sortedComments = computed(() => {
  if (sortBy.value === '楼主') {
    return comments.value.filter(c => c.userId === post.value?.userId)
  }
  return comments.value
})

function changeSortBy(s: string) {
  if (sortBy.value === s) return
  sortBy.value = s
  loadComments(true)
}
const showDonateModal = ref(false)
const donateAmount = ref(1)
const donateType = ref('coin')
const donating = ref(false)
const pwdInput = ref('')
const activeBarrierBlockIdx = ref(-1)
const contentPurchased = ref(false)
const blockPassedSet = ref(new Set<number>())
const blockPurchasedSet = ref(new Set<number>())
const membershipLevels = ref<{ id: number; name: string; level: number; discount_rate: number; points_discount_rate: number }[]>([])

function levelName(lv: number): string {
  const found = membershipLevels.value.find(l => l.level === lv)
  return found?.name || `${lv}级会员`
}

async function loadMembershipLevels() {
  try {
    const r: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = (r?.records || []).filter((l: any) => l.status === '1')
  } catch {}
}

function blockVisibility(idx: number): string {
  const block = contentBlocks.value[idx]
  return block?.visibility || (post.value?.contentPermission as string) || 'public'
}

function effectiveBlockVisibility(idx: number): string {
  const vis = blockVisibility(idx)
  if (!getUserId() && (vis === 'paid' || vis === 'comment' || vis === 'level' || vis === 'level1' || vis === 'level2')) {
    return 'login'
  }
  return vis
}

function blockBarrier(idx: number): boolean {
  if (!post.value) return false
  const vis = blockVisibility(idx)
  if (!vis || vis === 'public') return false
  const isAuthor = (post.value as any).userId === getUserId()
  if (isAuthor) return false

  if (vis === 'password' && blockPassedSet.value.has(idx)) return false
  if (vis === 'login' && getUserId()) return false
  if (vis === 'paid' && (blockPurchasedSet.value.has(idx) || contentPurchased.value)) return false
  if (vis === 'comment' && userHasCommented()) return false

  const userLevelId = (userStore.info as any)?.levelId || 0
  const block = contentBlocks.value[idx]
  if (vis === 'level' && block?.visibilityLevel !== undefined && userLevelId >= (block.visibilityLevel || 0)) return false
  if (vis === 'level' && block?.visibilityLevel === undefined && userLevelId >= 1) return false

  // Legacy level support
  if (vis === 'level1' && userLevelId >= 1) return false
  if (vis === 'level2' && userLevelId >= 2) return false

  // Not logged in + paid/comment/level -> force login barrier
  if (!getUserId() && (vis === 'paid' || vis === 'comment' || vis === 'level' || vis === 'level1' || vis === 'level2')) return true

  return true
}

function blockBarrierText(idx: number): string {
  const vis = effectiveBlockVisibility(idx)
  const block = contentBlocks.value[idx]
  const map: Record<string, string> = {
    paid: '此内容需要付费后查看',
    password: '此内容需要密码访问' + (block?.visibilityPasswordTips ? ' (提示: ' + block.visibilityPasswordTips + ')' : (post.value?.accessPasswordTips ? ' (提示: ' + post.value.accessPasswordTips + ')' : '')),
    login: '请登录后查看',
    comment: '评论后即可查看内容',
    level: block?.visibilityLevelName ? `${block.visibilityLevelName}及以上可查看` : (block?.visibilityLevel !== undefined ? `${levelName(block.visibilityLevel)}及以上可查看` : '会员及以上可查看'),
    level1: `${levelName(1)}及以上可查看`,
    level2: `${levelName(2)}及以上可查看`
  }
  return map[vis] || '内容受限'
}

function blockBarrierPrice(idx: number): { price: number; type: string } | null {
  const vis = effectiveBlockVisibility(idx)
  const block = contentBlocks.value[idx]
  if (vis === 'paid') {
    return {
      price: block?.visibilityPrice || post.value?.contentPrice || 0,
      type: block?.visibilityPriceType || (post.value?.contentPriceType as string) || 'balance'
    }
  }
  return null
}

function levelBarrierDesc(idx: number): string {
  const vis = effectiveBlockVisibility(idx)
  const block = contentBlocks.value[idx]
  if (vis === 'level') {
    const lv = block?.visibilityLevel ?? 1
    return `开通${levelName(lv)}即可查看此内容`
  }
  if (vis === 'level1') return `开通${levelName(1)}即可查看此内容`
  if (vis === 'level2') return `开通${levelName(2)}即可查看此内容`
  return '开通会员即可查看此内容'
}

async function openPayDialog(idx: number) {
  const priceData = blockBarrierPrice(idx)
  if (!priceData || priceData.price <= 0) return
  currentPayBlockIdx.value = idx
  selectedCouponId.value = 0
  await loadUsableCoupons(priceData.price, priceData.type)
  showPayConfirm.value = true
}

function onPayCouponSelect(val: number) {
  if (!val) {
    selectedCouponId.value = 0
  } else {
    const c = usableCoupons.value.find((c: any) => c.userCouponId === val)
    selectedCouponId.value = val
  }
}

async function handleConfirmPay() {
  const idx = currentPayBlockIdx.value
  const priceData = payBlockPrice.value
  if (!priceData || idx < 0) return
  payLoading.value = true
  try {
    await request.post({
      url: `/api/content/purchase/post/${postId.value}`,
      data: { price: priceData.price, priceType: priceData.type, blockIndex: idx, couponId: selectedCouponId.value || 0 }
    })
    blockPurchasedSet.value.add(idx)
    payResultSuccess.value = true
    payResultMsg.value = '购买成功，内容已解锁'
    showPayConfirm.value = false
    showPayResult.value = true
    selectedCouponId.value = 0
    await loadPost()
  } catch (e: any) {
    payResultSuccess.value = false
    payResultMsg.value = e?.msg || e?.message || '支付失败，请重试'
    showPayConfirm.value = false
    showPayResult.value = true
  } finally {
    payLoading.value = false
  }
}

async function verifyBlockPassword(idx: number) {
  const block = contentBlocks.value[idx]
  const pwd = block?.visibilityPassword || post.value?.accessPassword
  if (!pwdInput.value || !pwdInput.value.trim()) {
    ElMessage.warning('请输入密码')
    return
  }
  try {
    const res = await request.post({
      url: `/api/content/verify-password/post/${postId.value}`,
      data: { password: pwdInput.value },
      showErrorMessage: false
    })
    const data = res as any
    if (data.valid || data.code === 200 || data.msg === 'ok') {
      blockPassedSet.value.add(idx)
      pwdInput.value = ''
      await loadPost()
    } else {
      ElMessage.error('密码错误')
    }
  } catch (e: any) { ElMessage.error(e?.msg || e?.message || '验证失败') }
}

function userHasCommented(): boolean {
  const uid = getUserId()
  if (!uid) return false
  return comments.value.some(c => c.userId === uid) ||
    comments.value.some(c => (c.replies || []).some((r: any) => r.userId === uid))
}

const showReportDialog = ref(false)
const reportTarget = ref<'post' | 'comment'>('post')
const reportTargetId = ref(0)
const reportReason = ref('')
const reportDetail = ref('')
const reporting = ref(false)
const reportTypes = ['色情低俗', '政治敏感', '垃圾广告', '辱骂攻击', '侵权内容', '其他违规']
const coinLogs = ref<any[]>([])
const showCoinLogs = ref(false)
const lastDonateTime = ref(0)

function fmtDate(d: string) {
  if (!d) return ''
  try {
    const dt = new Date(d)
    if (isNaN(dt.getTime())) return d.slice(0, 10)
    return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`
  } catch { return '' }
}

const donorAvatars = computed(() => {
  const seen = new Set<number>()
  const donors: { userId: number; name: string; avatar: string }[] = []
  for (const log of coinLogs.value) {
    const uid = log.fromUserId || log.userId
    if (uid && !seen.has(uid)) {
      seen.add(uid)
      donors.push({ userId: uid, name: log.fromUserName || log.userName || '', avatar: log.fromUserAvatar || log.userAvatar || '' })
    }
  }
  return donors
})

function getRewardSummary() {
  const parts: string[] = []
  if (coinLogPointsTotal.value) parts.push(`${coinLogPointsTotal.value}积分`)
  if (coinLogCoinTotal.value) parts.push(`${coinLogCoinTotal.value}余额`)
  return parts.length ? parts.join(' ') : '0积分余额'
}
const purchasedAttachUrls = ref<string[]>([])
const attachInfoDialog = ref({ show: false, title: '', desc: '', url: '', extractCode: '' })
const showMenu = ref(false)
const following = ref(false)
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref<number>(0)
const selectedCouponInfo = computed(() => usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value) || null)

const showPayConfirm = ref(false)
const showPayResult = ref(false)
const payResultSuccess = ref(false)
const payResultMsg = ref('')
const payLoading = ref(false)
const currentPayBlockIdx = ref(-1)

const payBlockPrice = computed(() => {
  if (currentPayBlockIdx.value < 0) return { price: 0, type: 'balance' as string }
  return blockBarrierPrice(currentPayBlockIdx.value) || { price: 0, type: 'balance' as string }
})

const isPointsCoupon = computed(() => {
  const c = selectedCouponInfo.value
  return c && (c.type === 'fixed_points' || c.type === 'points_percent')
})

const couponDiscount = computed(() => {
  const c = selectedCouponInfo.value
  if (!c) return 0
  const base = payBlockPrice.value.price
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    let disc = Math.floor(base * c.value / 100 * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPayPrice = computed(() => {
  const priceData = payBlockPrice.value
  const userLevelId = (userStore.info as any)?.levelId || 0
  let discountRate = 1.0
  if (userLevelId && membershipLevels.value.length) {
    const ml = membershipLevels.value.find((l: any) => l.id === userLevelId)
    if (ml) discountRate = priceData.type === 'points' ? (ml.points_discount_rate || 1) : (ml.discount_rate || 1)
  }
  const memberPrice = Math.round(priceData.price * discountRate * 100) / 100
  const cd = couponDiscount.value
  return Math.max(0, memberPrice - cd)
})

function couponLabel(c: any) {
  const isPoints = c.type === 'fixed_points' || c.type === 'points_percent'
  const isFixed = c.type === 'fixed' || c.type === 'fixed_points'
  const prefix = isFixed ? `${isPoints ? '' : '¥'}${c.value}${isPoints ? '积分' : ''}` : `${c.value}折`
  const suffix = c.isMultiUse && c.remainingValue !== null ? `(剩${isPoints ? '' : '¥'}${c.remainingValue}${isPoints ? '积分' : ''})` : ''
  return `${prefix} ${c.name}${suffix}`
}

const contentBlocks = computed<ContentBlock[]>(() => {
  if (!post.value?.content) return []
  try {
    const parsed = JSON.parse(post.value.content)
    if (Array.isArray(parsed)) return parsed as ContentBlock[]
    if (parsed && typeof parsed === 'object' && parsed.type) return [parsed] as ContentBlock[]
  } catch {}
  return []
})

const globalLoginBarrier = computed(() => {
  if (getUserId()) return false
  if (!contentBlocks.value.length) return false
  return contentBlocks.value.some(b => {
    const vis = b?.visibility || (post.value?.contentPermission as string) || 'public'
    return vis === 'paid' || vis === 'comment' || vis === 'level' || vis === 'level1' || vis === 'level2'
  })
})

const coinLogPointsTotal = computed(() => coinLogs.value.filter((l: any) => l.coinType === 'points').reduce((s: number, l: any) => s + l.amount, 0))
const coinLogCoinTotal = computed(() => coinLogs.value.filter((l: any) => l.coinType !== 'points').reduce((s: number, l: any) => s + l.amount, 0))
const coinLogDisplay = computed(() => {
  const parts: string[] = []
  if (coinLogPointsTotal.value) parts.push(`${coinLogPointsTotal.value}积分`)
  if (coinLogCoinTotal.value) parts.push(`${coinLogCoinTotal.value}余额`)
  return parts.length ? `已打赏 ${parts.join(' ')}` : `已打赏 0积分余额`
})

const tagsList = computed(() => {
  const off = (post.value?.officialTags || []).filter(Boolean)
  const user = (post.value?.tags || []).filter(Boolean)
  const seen = new Set<string>()
  return [...off, ...user].filter(t => {
    if (seen.has(t)) return false
    seen.add(t)
    return true
  })
})

const pal = ['#6366F1','#EC4899','#F59E0B','#10B981','#3B82F6','#8B5CF6','#EF4444','#14B8A6','#F97316','#84CC16']
const pal2 = ['#4F46E5','#DB2777','#D97706','#059669','#2563EB','#7C3AED','#DC2626','#0D9488','#EA580C','#65A30D']
function avatarColor(n: string) { let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h); return pal[Math.abs(h) % pal.length] }
function avatarGrad(n: string) { let h = 0; for (let i = 0; i < (n || '').length; i++) h = n.charCodeAt(i) + ((h << 5) - h); const i = Math.abs(h) % pal.length; return `linear-gradient(135deg, ${pal[i]}, ${pal2[i]})` }
function safeContent(c: string) {
  if (!c) return ''
  if (c.length > 10000) return '内容无法显示'
  const t = c.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim()
  if (t.length > 200) return t.slice(0, 200) + '...'
  return t
}

function handlePostBodyClick(e: MouseEvent) {
  const el = (e.target as HTMLElement).closest('a') as HTMLAnchorElement | null
  if (el) {
    const href = el.getAttribute('href') || ''
    const match = href.match(/\/community\/topic\/(\d+)/)
    if (match) {
      e.preventDefault()
      router.push(href)
    }
  }
}
function fmtTime(t: string) {
  if (!t) return ''
  const s = t.replace(' ', 'T')
  const d0 = s.match(/[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$/) ? new Date(s) : new Date(s + 'Z')
  if (isNaN(d0.getTime())) return t.slice(0, 10)
  const d = Date.now() - d0.getTime()
  if (d < 60000) return '刚刚'
  if (d < 3600000) return Math.floor(d / 60000) + '分钟前'
  if (d < 86400000) return Math.floor(d / 3600000) + '小时前'
  if (d < 2592000000) return Math.floor(d / 86400000) + '天前'
  return t.slice(0, 10)
}
function getUserId() { return (userStore.info as any)?.userId || (userStore.info as any)?.id || 0 }
function getUserRoles(): string[] { return (userStore.info as any)?.roles || (userStore.info as any)?.userRoles || [] }
function userIsAdmin(): boolean { return getUserRoles().some((r: string) => r === 'R_SUPER' || r === 'R_ADMIN') }
function canDeleteComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid) return false
  return c.userId === uid || post.value?.userId === uid || userIsAdmin()
}
function canPinComment(c: CommunityComment & { _isLiked?: boolean }) {
  const uid = getUserId()
  if (!uid || c.parentId) return false
  return post.value?.userId === uid || userIsAdmin()
}
function canDeleteReply(r: CommunityComment) {
  const uid = getUserId()
  if (!uid) return false
  return r.userId === uid || post.value?.userId === uid || userIsAdmin()
}

/**
 * Check if current user has the given button-level permission
 * for CommunityPostManage menu via authList
 */
function hasCommunityPermission(authMark: string): boolean {
  const findAuthList = (nodes: any[]): any[] | null => {
    for (const n of nodes) {
      if (n.name === 'CommunityPostManage' && n.meta?.authList?.length) return n.meta.authList
      if (n.children?.length) {
        const result = findAuthList(n.children)
        if (result) return result
      }
    }
    return null
  }
  const authList = findAuthList(menuList.value as any[])
  if (!authList) return userIsAdmin() // fallback: menu not in tree, check admin role
  return authList.some((a: any) => a.authMark === authMark)
}

function tagDotColor(t: string) { return t === '玩机广场' ? '#4BCB73' : t === '资源分享' ? '#999' : '#22C3D0' }

async function loadPost() {
  if (!postId.value) return
  loading.value = true
  try {
    const r: any = await fetchCommunityPost(postId.value, getUserId())
    post.value = r.data || r
    if ((post.value?.contentPermission === 'paid' || post.value?.contentPermission === 'mixed') && getUserId()) {
      try {
        const pur: any = await request.get({ url: `/api/content/purchased/post/${postId.value}` })
        // fullPurchase 或 content_permission='paid' 且有购买记录 → 全帖可见
        contentPurchased.value = (pur?.fullPurchase) || (post.value?.contentPermission === 'paid' && pur?.purchased) || false
        if (pur?.boughtBlocks?.length) {
          blockPurchasedSet.value = new Set(pur.boughtBlocks)
        }
      } catch {}
    }
    checkFollowStatus()
    if (getUserId() && post.value) {
      addBrowseHistory({
        userId: getUserId(),
        itemType: 'post',
        itemId: postId.value,
        itemTitle: post.value.title || '',
        itemCover: post.value.cover || '',
        itemUrl: route.fullPath
      }).catch(() => {})
    }
  } catch (e: any) { console.error(e) } finally { loading.value = false }
}

async function loadUsableCoupons(price: number, priceType: string) {
  if (!getUserId()) return
  try {
    const res: any = await fetchUsableCoupons({ scene: 'content_buy', orderAmount: price, payType: priceType })
    usableCoupons.value = res?.data || res || []
  } catch { usableCoupons.value = [] }
}
function parseCommentImages(list: any[]) {
  for (const c of list) {
    try { c.images = typeof c.images === 'string' ? JSON.parse(c.images) : (c.images || []) } catch { c.images = [] }
    if (c.replies) {
      for (const r of c.replies) {
        try { r.images = typeof r.images === 'string' ? JSON.parse(r.images) : (r.images || []) } catch { r.images = [] }
      }
    }
  }
}

async function loadComments(reset = true) {
  if (!postId.value) return
  if (reset) {
    commentsPage.value = 1
    commentsLoading.value = true
  } else {
    loadingMore.value = true
  }
  try {
    const params: Record<string, unknown> = { page: commentsPage.value, pageSize: commentsPageSize }
    if (sortBy.value === '热门') params.sortBy = 'hot'
    const r: any = await fetchComments(postId.value, params)
    const list = r.data?.list || r.list || r.data || []
    const total = r.data?.total ?? r.total ?? 0
    commentsTotal.value = total
    parseCommentImages(list)
    const mapped = (list as CommunityComment[]).map(c => ({ ...c, _isLiked: false, _originalLiked: false }))
    comments.value = reset ? mapped : [...comments.value, ...mapped]
  } catch {} finally {
    commentsLoading.value = false
    loadingMore.value = false
  }
}

async function loadMoreComments() {
  if (!hasMoreComments.value || loadingMore.value) return
  commentsPage.value++
  await loadComments(false)
}
async function handleLike() {
  const u = getUserId(); if (!u || !post.value) return
  try { await likePost(post.value.id, u); post.value.isLiked = !post.value.isLiked; post.value.likeCount = (post.value.likeCount || 0) + (post.value.isLiked ? 1 : -1) } catch {}
}
async function handleFavorite() {
  const u = getUserId(); if (!u || !post.value) return
  try { await favoritePost(post.value.id, u); post.value.isFavorited = !post.value.isFavorited; post.value.favoriteCount = (post.value.favoriteCount || 0) + (post.value.isFavorited ? 1 : -1) } catch {}
}
const toggleLike = handleLike
const toggleFav = handleFavorite
function scrollToComments() {
  document.querySelector('.comments-section')?.scrollIntoView({ behavior: 'smooth' })
}
async function doDonate() {
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再打赏'); return }
  if (!post.value || donateAmount.value < 1) return
  const elapsed = Date.now() - lastDonateTime.value
  if (elapsed < 30000) {
    const remain = Math.ceil((30000 - elapsed) / 1000)
    ElMessage.warning(`请等待 ${remain} 秒后再打赏`)
    return
  }
  donating.value = true
  try {
    await sendCoin(post.value.id, { userId: u, amount: donateAmount.value, coinType: donateType.value })
    post.value.coinCount = (post.value.coinCount || 0) + donateAmount.value
    lastDonateTime.value = Date.now()
    showDonateModal.value = false
    await loadCoinLogs()
    ElMessage.success('打赏成功')
  } catch {} finally { donating.value = false }
}

async function handleReward() {
  showDonateModal.value = true
}

async function handleSendCoinQuick() {
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再打赏'); return }
  if (!post.value) return
  const elapsed = Date.now() - lastDonateTime.value
  if (elapsed < 30000) {
    const remain = Math.ceil((30000 - elapsed) / 1000)
    ElMessage.warning(`请等待 ${remain} 秒后再打赏`)
    return
  }
  try {
    await sendCoin(post.value.id, { userId: u, amount: 1 })
    post.value.coinCount = (post.value.coinCount || 0) + 1
    lastDonateTime.value = Date.now()
    await loadCoinLogs()
    ElMessage.success('打赏成功')
  } catch {}
}

function isAttachPurchased(url?: string) {
  return !!(url && purchasedAttachUrls.value.includes(url))
}

function handleAttachmentClick(block: ContentBlock) {
  if (!block.url) return
  // 已购买 → 弹窗显示信息
  if (isAttachPurchased(block.url)) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const isFree = block.priceType === 'free' || !block.priceType || (block.coin || 0) <= 0
  if (isFree) {
    attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url, extractCode: block.extractCode || '' }
    return
  }
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再下载'); return }
  const unitLabel = block.priceType === 'points' ? '积分' : '余额'
  ElMessageBox.confirm(
    `该附件需要支付 ${block.coin || 0}${unitLabel}，确认购买？`,
    '购买附件',
    { confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning' }
  ).then(async () => {
    try {
      const res = await fetch('/api/community/attach/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken },
        body: JSON.stringify({ postId: post.value?.id, attachUrl: block.url, coinType: block.priceType, amount: block.coin })
      })
      const data = await res.json()
      if (data.code === 200) {
        purchasedAttachUrls.value.push(block.url!)
        ElMessage.success(data.msg)
        attachInfoDialog.value = { show: true, title: block.title || '附件', desc: block.desc || '', url: block.url!, extractCode: block.extractCode || '' }
      } else {
        ElMessage.error(data.msg || '购买失败')
      }
    } catch {
      ElMessage.error('购买失败')
    }
  }).catch(() => {})
}

async function loadPurchasedAttachments() {
  if (!postId.value) return
  const u = getUserId()
  if (!u) return
  try {
    const res = await fetch(`/api/community/attach/purchased?postId=${postId.value}`, {
      headers: { 'Authorization': userStore.accessToken }
    })
    const data = await res.json()
    if (data.code === 200) {
      purchasedAttachUrls.value = data.data?.urls || []
    }
  } catch {}
}

async function loadCoinLogs() {
  if (!postId.value) return
  try {
    const r: any = await fetchCoinLogs(postId.value)
    coinLogs.value = r.data?.list || r.list || r.data || []
  } catch {}
}
async function toggleCoinLogs() {
  showCoinLogs.value = true
  await loadCoinLogs()
}
function focusCommentInput() { commentInputEl.value?.focus() }
function toggleReplyInput(c: CommunityComment & { _isLiked?: boolean }) { replyingTo.value = replyingTo.value === c.id ? null : c.id; replyText.value = '' }
async function uploadImage(file: File): Promise<string> {
  const formData = new FormData()
  formData.append('file', file)
  const r: any = await request.post({ url: '/api/upload/file', data: formData })
  const data = r?.data || r
  return data?.url || ''
}

function onCommentImagesSelected(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files) return
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    const reader = new FileReader()
    reader.onload = () => { commentImages.value.push(reader.result as string) }
    reader.readAsDataURL(file)
  }
}
function onReplyImagesSelected(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files) return
  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    const reader = new FileReader()
    reader.onload = () => { replyImages.value.push(reader.result as string) }
    reader.readAsDataURL(file)
  }
}

async function submitReply(pc: CommunityComment & { _isLiked?: boolean }) {
  const t = replyText.value.trim()
  if (!t && replyImages.value.length === 0) return
  if (!postId.value) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再回复'); return }
  try {
    // Upload images first
    let uploadedUrls: string[] = []
    if (replyImages.value.length > 0) {
      uploadingImage.value = true
      for (const img of replyImages.value) {
        if (img.startsWith('data:')) {
          const blob = await fetch(img).then(r => r.blob())
          const file = new File([blob], 'reply_image.jpg', { type: 'image/jpeg' })
          const url = await uploadImage(file)
          if (url) uploadedUrls.push(url)
        } else {
          uploadedUrls.push(img)
        }
      }
      uploadingImage.value = false
    }
    const r: any = await postComment(postId.value, { userId: u, content: t || '', parent_id: pc.id, images: uploadedUrls })
    const nr: any = r.data || r
    if (!pc.replies) pc.replies = []
    pc.replies.push({ id: nr.id || Date.now(), postId: postId.value, parentId: pc.id, userId: u, userName: (userStore.info as any)?.username || '我', userAvatar: '', content: t, images: uploadedUrls, likeCount: 0, replyCount: 0, createTime: new Date().toISOString() })
    pc.replyCount = (pc.replyCount || 0) + 1; replyingTo.value = null; replyText.value = ''; replyImages.value = []
  } catch {}
}
async function submitComment() {
  const t = newCommentText.value.trim()
  if (!t && commentImages.value.length === 0) return
  if (!postId.value) return
  const u = getUserId()
  if (!u) { ElMessage.warning('请先登录后再评论'); return }
  try {
    let uploadedUrls: string[] = []
    if (commentImages.value.length > 0) {
      uploadingImage.value = true
      for (const img of commentImages.value) {
        if (img.startsWith('data:')) {
          const blob = await fetch(img).then(r => r.blob())
          const file = new File([blob], 'comment_image.jpg', { type: 'image/jpeg' })
          const url = await uploadImage(file)
          if (url) uploadedUrls.push(url)
        } else {
          uploadedUrls.push(img)
        }
      }
      uploadingImage.value = false
    }
    const r: any = await postComment(postId.value, { userId: u, content: t || '', parent_id: 0, images: uploadedUrls })
    if (post.value) post.value.commentCount = (post.value.commentCount || 0) + 1
    newCommentText.value = ''; commentImages.value = []
    showCommentDialog.value = false
    const fileInput = document.querySelector('.comment-dialog-img-btn input[type=file]') as HTMLInputElement
    if (fileInput) fileInput.value = ''
    await loadComments()
  } catch {}
}

function previewCommentImage(images: string[], idx: number) {
  previewImages.value = images
  previewIndex.value = idx
  previewVisible.value = true
}
function handleCommentLike(c: CommunityComment & { _isLiked?: boolean }) {
  c._isLiked = !c._isLiked
  c.likeCount = Math.max(0, (c.likeCount || 0) + (c._isLiked ? 1 : -1))
}
async function handleDeleteComment(c: CommunityComment) {
  const u = getUserId(); if (!u) return
  try {
    await ElMessageBox.confirm('确定删除这条评论吗？', '确认删除', { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' })
    await deleteComment(c.id, u); comments.value = comments.value.filter(x => x.id !== c.id); if (post.value) post.value.commentCount = Math.max(0, (post.value.commentCount || 1) - 1 - (c.replyCount||0))
  } catch {}
}
async function handlePinPin() {
  if (!post.value) return
  try { const r: any = await pinPost(post.value.id, getUserId()); const d = r.data || r; post.value.isPinned = d.isPinned; ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶') } catch {}
}
async function handleGlobalPin() {
  if (!post.value) return
  try { const r: any = await globalPinPost(post.value.id, getUserId()); const d = r.data || r; (post.value as any).isGlobalPinned = d.isGlobalPinned; ElMessage.success(d.isGlobalPinned ? '已全站置顶' : '已取消全站置顶') } catch {}
}
async function handleEssence() {
  if (!post.value) return
  try { const r: any = await essencePost(post.value.id, getUserId()); const d = r.data || r; post.value.isEssence = d.isEssence; ElMessage.success(d.isEssence ? '已加精' : '已取消加精') } catch {}
}
async function handleHot() {
  if (!post.value) return
  try { const r: any = await hotPost(post.value.id, getUserId()); const d = r.data || r; post.value.isHot = d.isHot; ElMessage.success(d.isHot ? '已设为热帖' : '已取消热帖') } catch {}
}
async function handleCustomBadge() {
  if (!post.value) return
  try {
    const { value } = await ElMessageBox.prompt('请输入自定义徽章文字（留空则清除）', '自定义徽章', {
      confirmButtonText: '确定', cancelButtonText: '取消',
      inputValue: (post.value as any).customBadge || '',
      inputPlaceholder: '最多10个字',
      inputValidator: (v: string) => v.length <= 10 || '最多10个字'
    })
    const badge = value ? value.trim() : ''
    const r: any = await setCustomBadge(post.value.id, badge)
    const d = r.data || r;
    (post.value as any).customBadge = d.customBadge
    ElMessage.success(d.customBadge ? '自定义徽章已设置' : '自定义徽章已清除')
  } catch {}
}
async function handleLock() {
  if (!post.value) return
  try { const r: any = await lockPost(post.value.id, getUserId()); const d = r.data || r; (post.value as any).isLocked = d.isLocked; ElMessage.success(d.isLocked ? '已锁定' : '已解锁') } catch {}
}
async function handleDeletePost() {
  if (!post.value) return
  try {
    await ElMessageBox.confirm('确定要删除该帖子吗？删除后不可恢复。', '确认删除', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    const u = getUserId()
    const res = await fetch(`/api/community/post/${post.value.id}`, { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'Authorization': userStore.accessToken }, body: JSON.stringify({ userId: u }) })
    const data = await res.json()
    if (data.code === 200) { ElMessage.success('删除成功'); router.replace('/community') }
    else { ElMessage.error(data.msg || '删除失败') }
  } catch {}
}
function goEditPost() {
  if (!post.value) return
  router.push(`/community/post/edit/${btoa(String(post.value.id))}`)
}
async function handleShare() {
  const url = window.location.href
  try {
    await navigator.clipboard.writeText(url)
    ElMessage.success('链接已复制')
  } catch {
    ElMessage.info(url)
  }
  showMenu.value = false
}
async function handleFollowAuthor() {
  if (!post.value) return
  const targetId = (post.value as any).userId
  if (!targetId) return
  try {
    if (following.value) {
      await request.del({ url: `/api/user/${targetId}/follow` })
      following.value = false
    } else {
      await request.post({ url: `/api/user/${targetId}/follow` })
      following.value = true
    }
  } catch {}
}
async function checkFollowStatus() {
  if (!post.value) return
  const targetId = (post.value as any).userId
  if (!targetId || !getUserId() || targetId === getUserId()) return
  try {
    const res: any = await request.get({ url: `/api/user/${targetId}/follow-status` })
    following.value = !!res?.isFollowing
  } catch {}
}
function handleReportPost() {
  if (!post.value) return
  reportTarget.value = 'post'
  reportTargetId.value = post.value.id
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
  showMenu.value = false
}

function handleReportComment(c: CommunityComment & { _isLiked?: boolean }) {
  reportTarget.value = 'comment'
  reportTargetId.value = c.id
  reportReason.value = ''
  reportDetail.value = ''
  showReportDialog.value = true
}

async function doReport() {
  if (!reportReason.value) return
  reporting.value = true
  try {
    if (reportTarget.value === 'post') {
      await reportPost(reportTargetId.value, reportReason.value, reportDetail.value)
    } else {
      await reportComment(reportTargetId.value, reportReason.value, reportDetail.value)
    }
    ElMessage.success('举报成功，管理员将尽快处理')
    showReportDialog.value = false
  } catch { ElMessage.error('举报失败') }
  reporting.value = false
}

async function handleRequestUnlock() {
  if (!post.value) return
  try {
    await requestUnlock(post.value.id)
    ElMessage.success('解锁申请已提交，等待管理员审核')
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.msg || '申请失败，请稍后再试')
  }
}
async function handlePinComment(c: CommunityComment) {
  try {
    const action = c.isPinned ? '取消置顶' : '置顶'
    await ElMessageBox.confirm(`确定${action}这条评论吗？`, '确认操作', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'info' })
    const r: any = await pinComment(c.id)
    const d = r.data || r
    c.isPinned = d.isPinned ? 1 : 0
    ElMessage.success(d.isPinned ? '已置顶' : '已取消置顶')
  } catch {}
}
async function handleDeleteReply(parent: CommunityComment, reply: CommunityComment) {
  const u = getUserId(); if (!u) return
  try {
    await deleteComment(reply.id, u)
    if (parent.replies) {
      parent.replies = parent.replies.filter(x => x.id !== reply.id)
      parent.replyCount = Math.max(0, (parent.replyCount || 1) - 1)
    }
    if (post.value) post.value.commentCount = Math.max(0, (post.value.commentCount || 1) - 1)
  } catch {}
}
function gridClassFor(n: number) {
  if (n === 1) return 'img-1'
  if (n <= 3) return 'img-3'
  return 'img-2'
}

function previewBlockImage(images: string[], i: number) {
  previewImages.value = images
  previewIndex.value = i
  previewVisible.value = true
}

function previewImage(idx: number) {
  previewImages.value = post.value?.images || []
  previewIndex.value = idx
  previewVisible.value = true
}

function closePreview() { previewVisible.value = false }
function prevImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value - 1 + previewImages.value.length) % previewImages.value.length }
function nextImage() { if (!previewImages.value.length) return; previewIndex.value = (previewIndex.value + 1) % previewImages.value.length }

onMounted(() => {
  loadPost()
  loadComments()
  loadCoinLogs()
  loadPurchasedAttachments()
  loadMembershipLevels()
})
</script>

<style scoped>
/* ============ PAGE ============ */
.post-detail-page { display: flex; flex-direction: column; height: 100vh; height: 100dvh; background: #fff; font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Noto Sans SC', sans-serif; overscroll-behavior: none; -webkit-overflow-scrolling: touch; }
.content-scroll { flex: 1; overflow-y: auto; padding: 0 12px; overscroll-behavior-y: contain; }

/* ============ DROPDOWN MENU ============ */
.menu-overlay {
  position: fixed; inset: 0; z-index: 9999;
  background: transparent;
}
.menu-panel {
  position: absolute;
  top: 50px; right: 12px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,.12), 0 1px 4px rgba(0,0,0,.06);
  min-width: 160px;
  padding: 8px 0;
  overflow: hidden;
  animation: menuIn .18s cubic-bezier(.25,.8,.25,1);
}
@keyframes menuIn {
  from { opacity: 0; transform: translateY(-6px) scale(.95); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}
.menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  font-size: 14px;
  color: #333;
  cursor: pointer;
  transition: background .12s;
  user-select: none;
}
.menu-item:active { background: #f2f3f5; }
.menu-item svg {
  width: 18px; height: 18px;
  flex-shrink: 0;
  color: #888;
}
.menu-item span {
  white-space: nowrap;
}
.menu-item-danger { color: #e44; }
.menu-item-danger svg { color: #e44; }
.menu-item-danger:active { background: #fef0f0; }
.menu-item-locked { color: #9CA3AF; pointer-events: none; }
.menu-item-locked svg { color: #9CA3AF; }
.menu-divider {
  height: 1px;
  background: #eee;
  margin: 4px 12px;
}

/* ============ NAVBAR - WHITE, CLEAN ============ */
.navbar { display: flex; align-items: center; padding: 10px 12px; gap: 8px; background: #fff; flex-shrink: 0; }
.nav-back { background: none; border: none; padding: 4px; cursor: pointer; display: flex; flex-shrink: 0; }
.nav-author { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.nav-avatar { width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 15px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.nav-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.nav-author-info { display: flex; flex-direction: column; gap: 2px; }
.nav-name { font-size: 15px; font-weight: 600; color: #111; }
.nav-time { font-size: 12px; color: #888; }
.nav-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.nav-dots { cursor: pointer; }
.nav-follow-btn {
  font-size: 13px; font-weight: 500; padding: 4px 12px; border-radius: 16px;
  border: 1px solid #4BCB73; color: #4BCB73; background: #fff;
  cursor: pointer; white-space: nowrap; line-height: 18px;
}
.nav-follow-btn.is-following {
  color: #999; border-color: #ddd; background: #f5f5f5;
}

/* ============ TITLE ============ */
.post-title { font-size: 20px; font-weight: 700; color: #111; line-height: 1.35; margin: 14px 0 12px; display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
.title-badge { display: inline-block; font-size: 11px; font-weight: 500; padding: 2px 8px; border-radius: 4px; line-height: 18px; white-space: nowrap; flex-shrink: 0; }
.title-badge-pin { background: #FEF3C7; color: #B45309; }
.title-badge-essence { background: #EDE9FE; color: #6D28D9; }
.title-badge-hot { background: #FEE2E2; color: #DC2626; }
.title-badge-lock { background: #F3F4F6; color: #6B7280; }
.title-badge-custom { background: #FCE4EC; color: #C62828; }
.status-bar { margin: 8px 0 0; padding: 8px 14px; border-radius: 8px; font-size: 13px; }
.status-pending { background: #FEF3C7; color: #92400E; }
.status-rejected { background: #FEE2E2; color: #991B1B; }
.status-locked { background: #F3F4F6; color: #6B7280; }

/* ============ INFO LIST (【】style) ============ */
.info-list { margin-bottom: 14px; }
.info-row { font-size: 15px; line-height: 1.9; }
.info-label { font-weight: 700; color: #111; }
.info-value { color: #222; }
.info-link { color: #22C3D0; text-decoration: underline; }

/* ============ BODY TEXT ============ */
.post-body { font-size: 15px; color: #222; line-height: 1.75; margin-bottom: 16px; word-break: break-word; padding-left: 8px; }
.post-body :deep(h2) { font-size: 20px; font-weight: 700; line-height: 1.4; margin: .5em 0 .3em; }
.post-body :deep(h3) { font-size: 17px; font-weight: 600; line-height: 1.45; margin: .4em 0 .2em; }
.post-body :deep(strong) { font-weight: 700; }
.post-body :deep(em) { font-style: italic; }
.post-body :deep(u) { text-decoration: underline; }
.post-body :deep(s) { text-decoration: line-through; }
.post-body :deep(blockquote) { border-left: 3px solid #5c7cfa; padding: 6px 0 6px 12px; margin: 8px 0; color: #495057; background: #f8f9fa; border-radius: 0 6px 6px 0; }
.post-body :deep(pre.ql-syntax) { background: #f1f3f5; border-radius: 8px; padding: 10px 12px; font-size: 13px; overflow-x: auto; font-family: 'SF Mono', Monaco, monospace; white-space: pre; }
.post-body :deep(ol), .post-body :deep(ul) { padding-left: 20px; margin: 4px 0; }
.post-body :deep(ol) { list-style-type: decimal; }
.post-body :deep(ul) { list-style-type: disc; }
.post-body :deep(li) { margin: 2px 0; }
.post-body :deep(hr) { border: none; border-top: 1px solid #e9ecef; margin: 10px 0; }
.post-body :deep(p) { margin: 0 0 4px; }
.post-body :deep(.ql-size-12px) { font-size: 12px; }
.post-body :deep(.ql-size-14px) { font-size: 14px; }
.post-body :deep(.ql-size-16px) { font-size: 16px; }
.post-body :deep(.ql-size-18px) { font-size: 18px; }
.post-body :deep(.ql-size-20px) { font-size: 20px; }
.post-body :deep(.ql-size-24px) { font-size: 24px; }
.post-body :deep(.ql-size-28px) { font-size: 28px; }
.post-body :deep(.ql-size-32px) { font-size: 32px; }
.post-body :deep([style*="color"]) { /* inline styles pass through */ }
.post-body :deep(a[href*="/community/topic"]) { color: #6366f1; font-weight: 700; text-decoration: none; cursor: pointer; border-radius: 4px; padding: 0 2px; transition: background .15s; }
.post-body :deep(a[href*="/community/topic"]:hover) { background: #edf2ff; }

/* ============ IMAGES ============ */
.images-grid { display: grid; gap: 4px; margin-bottom: 14px; }
.images-grid.img-1 { grid-template-columns: 1fr; }
.images-grid.img-2 { grid-template-columns: 1fr 1fr; }
.images-grid.img-3 { grid-template-columns: 1fr 1fr 1fr; }
.image-item { border-radius: 8px; overflow: hidden; aspect-ratio: 1; cursor: pointer; }
.image-item img { width: 100%; height: 100%; object-fit: cover; display: block; }

/* ============ DOWNLOAD SECTION ============ */
.download-block { margin-bottom: 16px; }
.download-heading { font-size: 16px; font-weight: 600; color: #111; margin-bottom: 8px; }
.download-card { background: #f5f5f5; border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 10px; position: relative; }
.download-icon-box { width: 50px; height: 50px; background: #22C3D0; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.download-icon-box svg { width: 22px; height: 22px; }
.download-info { flex: 1; min-width: 0; }
.download-desc { font-size: 13px; color: #333; font-weight: 500; }
.download-hint { font-size: 11px; color: #999; margin-top: 3px; }
.download-btn-wrap { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.download-price-tag { font-size: 14px; font-weight: 700; color: #22C3D0; background: #fff; padding: 3px 10px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.download-btn { background: #fff; border: none; padding: 5px 14px; border-radius: 12px; font-size: 13px; color: #333; font-weight: 500; cursor: pointer; box-shadow: 0 1px 2px rgba(0,0,0,.05); }
.extract-row { margin-top: 8px; font-size: 12px; color: #888; }
.extract-val { font-weight: 600; color: #333; }

/* ============ TAGS ============ */
.tags-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
.tag-pill { display: flex; align-items: center; gap: 5px; background: #f3f3f3; border-radius: 14px; padding: 5px 12px; font-size: 13px; color: #444; }
.tag-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }

/* ============ REWARD ROW ============ */
.reward-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; margin-bottom: 4px; }
.reward-info { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #666; cursor: pointer; }
.reward-info:hover { color: #333; }
.reward-info em { font-style: normal; font-weight: 600; color: #F59E0B; }
.reward-donate-btn { background: #22C3D0; color: #fff; border: none; border-radius: 14px; padding: 5px 16px; font-size: 13px; font-weight: 500; cursor: pointer; }

/* ============ COMMENTS ============ */
.comments-section { padding-bottom: 80px; }
.comments-header { display: flex; align-items: center; justify-content: space-between; padding: 12px 8px; }
.comments-title { font-size: 15px; font-weight: 600; color: #333; }
.comments-sort { display: flex; gap: 0; background: #f0f0f0; border-radius: 8px; overflow: hidden; }
.sort-btn { font-size: 12px; color: #666; background: transparent; border: none; padding: 4px 12px; cursor: pointer; transition: all .15s; }
.sort-btn.active { color: #fff; font-weight: 600; background: #508DFF; }
.comments-loading { display: flex; justify-content: center; padding: 40px 0; }
.comments-empty { padding: 56px 16px; text-align: center; display: flex; flex-direction: column; align-items: center; }
.empty-icon { margin-bottom: 12px; }
.comments-empty p { margin: 0 0 4px; font-size: 15px; color: #999; }
.comments-empty span { font-size: 13px; color: #bbb; }
.comments-list { padding: 0; }
.comment-card { padding: 2px 0; position: relative; }
.comment-card:not(:last-child)::after {
  content: '';
  position: absolute; bottom: 0; left: 46px; right: 16px;
  height: 0.5px; background: #eee;
}
.comment-card.pinned {  }
.comment-card.hot { background: linear-gradient(135deg, #fff5f5, transparent); border-radius: 0; }
.comment-card-inner { display: flex; gap: 10px; padding: 8px 0; }
.comment-avatar-img { width: 36px; height: 36px; border-radius: 50%; flex-shrink: 0; overflow: hidden; }
.comment-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.comment-main { flex: 1; min-width: 0; }
.comment-meta { display: flex; align-items: center; gap: 5px; margin-bottom: 1px; flex-wrap: wrap; }
.comment-meta-spacer { flex: 1; }
.comment-menu-wrap { position: relative; flex-shrink: 0; }
.comment-menu-btn {
  background: none; border: none; cursor: pointer;
  padding: 2px 4px; border-radius: 4px; color: #bbb;
  display: flex; align-items: center;
  transition: background .12s;
}
.comment-menu-btn:active { background: #f0f0f0; }
.comment-dropdown {
  position: absolute; right: 0; top: 100%;
  background: #fff; border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,.12);
  min-width: 110px; padding: 6px 0; z-index: 999;
  overflow: hidden;
  animation: cmIn .15s ease;
}
@keyframes cmIn { from { opacity: 0; transform: translateY(-4px) scale(.92); } to { opacity: 1; transform: translateY(0) scale(1); } }
.comment-menu-item {
  padding: 10px 18px; font-size: 14px; color: #333;
  cursor: pointer; white-space: nowrap;
  transition: background .1s;
}
.comment-menu-item:active { background: #f2f3f5; }
.comment-menu-item:nth-child(2) { color: #e44; }
.comment-username { font-size: 13px; font-weight: 600; color: #00BFA5; }
.comment-level-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; font-weight: 600; line-height: 14px; }
.comment-level-badge.sm { font-size: 8px; padding: 0 4px; }
.comment-verified-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #ECFDF5; color: #059669; font-weight: 600; line-height: 14px; }
.comment-verified-badge.sm { font-size: 8px; padding: 0 4px; }
.comment-author-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #E8F5E9; color: #43A047; font-weight: 600; line-height: 14px; }
.comment-pinned-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #FFF3E0; color: #E65100; font-weight: 600; line-height: 14px; }
.comment-hot-badge { font-size: 9px; padding: 1px 5px; border-radius: 3px; background: #FFEDED; color: #E53E3E; font-weight: 600; line-height: 14px; }
.comment-title-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 600; line-height: 14px; white-space: nowrap; }
.comment-title-row { margin: 0; }
.comment-content { font-size: 15px; color: #222; line-height: 1.6; word-break: break-word; }
.comment-imgs { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.comment-img { width: 72px; height: 72px; border-radius: 6px; object-fit: cover; cursor: pointer; }
.comment-footer { display: flex; align-items: center; gap: 16px; margin-top: 8px; }
.comment-time { font-size: 12px; color: #bbb; }
.comment-act { display: inline-flex; align-items: center; gap: 3px; font-size: 12px; color: #aaa; background: none; border: none; cursor: pointer; padding: 0; }
.comment-act svg { flex-shrink: 0; }
.comment-act.liked { color: #ef4444; }
.comment-act.pin-act { color: #999; }
.comment-act.pin-act.pinned { color: #F59E0B; }
.comment-act.del { color: #c99; }
.comment-act.report { color: #bbb; }

/* reply input */
.reply-input-area { margin-top: 10px; }
.reply-input-row { display: flex; align-items: center; gap: 8px; }
.reply-input { flex: 1; background: #F2F3F5; border: none; border-radius: 16px; padding: 8px 12px; font-size: 13px; color: #333; outline: none; }
.reply-input::placeholder { color: #bbb; }
.reply-img-btn { display: flex; align-items: center; cursor: pointer; padding: 4px; flex-shrink: 0; }
.reply-cancel { font-size: 12px; color: #aaa; background: none; border: none; cursor: pointer; white-space: nowrap; }
.reply-send { font-size: 12px; background: #333; color: #fff; border: none; border-radius: 14px; padding: 5px 14px; cursor: pointer; }
.reply-send:disabled { opacity: .3; }

/* sub-replies */
.replies-wrap { margin-top: 8px; background: #F5F6F8; border-radius: 10px; padding: 10px 12px; }
.reply-item { padding: 5px 0; line-height: 1.6; }
.reply-item + .reply-item { border-top: 1px solid #ececec; }
.reply-username { font-size: 13px; font-weight: 600; color: #00BFA5; }
.reply-meta { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.reply-colon { color: #aaa; }
.reply-content { font-size: 14px; color: #333; }
.reply-footer { display: flex; align-items: center; gap: 12px; margin-top: 4px; }
.reply-del { font-size: 11px; color: #bbb; background: none; border: none; cursor: pointer; padding: 0; }

.block-attachment-card { display: flex; align-items: center; gap: 10px; background: #f7f8fa; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-attachment-card:hover { background: #eef0f4; }
.bac-icon { width: 42px; height: 42px; border-radius: 10px; background: #E8F5E9; color: #43A047; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.bac-info { flex: 1; min-width: 0; }
.bac-title { font-size: 14px; font-weight: 500; color: #333; }
.bac-desc { font-size: 11px; color: #999; margin-top: 2px; }
.bac-price { flex-shrink: 0; }
.bac-free { font-size: 12px; background: #E8F5E9; color: #43A047; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-coin { font-size: 12px; background: #FFF3E0; color: #E65100; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
.bac-purchased { font-size: 12px; background: #E3F2FD; color: #1976D2; padding: 3px 10px; border-radius: 10px; font-weight: 500; }

.block-link-card { display: flex; align-items: center; gap: 10px; background: #E8EAF6; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; }
.blc-icon { width: 42px; height: 42px; border-radius: 10px; background: rgba(63,81,181,.15); color: #3F51B5; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.blc-info { flex: 1; min-width: 0; }
.blc-title { font-size: 14px; font-weight: 500; color: #333; }
.blc-url { font-size: 11px; color: #999; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.block-app-card { display: flex; align-items: center; gap: 10px; background: #FFF8E1; border-radius: 12px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: background .15s; }
.block-app-card:hover { background: #FFECB3; }
.bac-app-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.bac-app-img { width: 100%; height: 100%; object-fit: cover; }
.bac-app-letter { text-transform: uppercase; }
.bac-app-info { flex: 1; min-width: 0; }
.bac-app-name { font-size: 14px; font-weight: 600; color: #333; }
.bac-app-desc { font-size: 11px; color: #999; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.bac-app-price { flex-shrink: 0; }

/* ============ SPINNER ============ */
.loading-wrap { display: flex; justify-content: center; padding: 40px 0; }
.spin { width: 22px; height: 22px; border: 2px solid #e5e7eb; border-top-color: #22C3D0; border-radius: 50%; animation: sp .6s linear infinite; }
@keyframes sp { to { transform: rotate(360deg); } }
.empty-wrap { flex: 1; display: flex; justify-content: center; align-items: center; color: #aaa; font-size: 13px; }

/* ============ IMAGE PREVIEW ============ */
.img-over { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,.95); display: flex; align-items: center; justify-content: center; }
.img-over-close { position: absolute; top: 16px; right: 16px; color: #fff; font-size: 32px; cursor: pointer; z-index: 10; line-height: 1; }
.img-over-idx { position: absolute; top: 20px; left: 16px; color: #fff; font-size: 14px; z-index: 10; }
.img-over-src { max-width: 90vw; max-height: 80vh; object-fit: contain; }
.img-over-prev, .img-over-next { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,.12); border: none; color: #fff; font-size: 36px; padding: 8px 12px; cursor: pointer; border-radius: 8px; z-index: 10; line-height: 1; }
.img-over-prev { left: 8px; }
.img-over-next { right: 8px; }

/* ============ BOTTOM SPACER ============ */
.bottom-spacer { height: 80px; }

/* ============ DONATION HISTORY ============ */
.coin-logs-body { max-height: 50vh; overflow-y: auto; padding: 0 18px 12px; }
.coin-logs-empty { text-align: center; color: #bbb; font-size: 13px; padding: 30px 0; }
.donate-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f3f3f3; }
.donate-item:last-child { border-bottom: none; }
.donate-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
.donate-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.donate-info { flex: 1; display: flex; flex-direction: column; gap: 1px; }
.donate-name { font-size: 12px; font-weight: 600; color: #333; }
.donate-time { font-size: 10px; color: #bbb; }
.donate-amount { display: flex; align-items: baseline; gap: 2px; flex-shrink: 0; }
.donate-val { font-size: 15px; font-weight: 700; color: #F59E0B; }
.donate-unit { font-size: 10px; color: #999; }

/* ============ DONATE MODAL ============ */
.donate-overlay { position: fixed; inset: 0; z-index: 300; background: rgba(0,0,0,.45); display: flex; align-items: flex-end; justify-content: center; }
.donate-modal { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
@keyframes dmUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.dm-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
.dm-title { font-size: 17px; font-weight: 700; color: #222; }
.dm-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.dm-balance-row { display: flex; gap: 12px; margin-bottom: 16px; }
.dm-bal-item { flex: 1; background: #f7f8fa; border-radius: 10px; padding: 10px 14px; display: flex; flex-direction: column; gap: 4px; }
.dm-bal-label { font-size: 11px; color: #999; }
.dm-bal-val { font-size: 16px; font-weight: 700; color: #F59E0B; }
.dm-type-row, .dm-amount-row { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.dm-type-label { font-size: 13px; color: #666; flex-shrink: 0; width: 60px; }
.dm-type-tabs { display: flex; background: #f3f4f6; border-radius: 8px; padding: 2px; }
.dm-type-tab { padding: 6px 18px; font-size: 13px; border: none; background: none; color: #888; cursor: pointer; border-radius: 6px; transition: all .2s; }
.dm-type-tab.active { background: #22C3D0; color: #fff; }
.dm-amount-opts { display: flex; gap: 8px; }
.dm-amt-btn { width: 54px; height: 34px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff; font-size: 14px; font-weight: 600; color: #333; cursor: pointer; }
.dm-amt-btn.active { border-color: #22C3D0; background: #e0f7f9; color: #22C3D0; }
.dm-custom-row { margin-bottom: 18px; }
.dm-custom-input { width: 100%; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 15px; color: #333; outline: none; box-sizing: border-box; }
.dm-custom-input:focus { border-color: #22C3D0; }
.dm-footer { display: flex; gap: 10px; }
.dm-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.dm-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #22C3D0; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.dm-confirm:disabled { background: #b0e0e6; cursor: not-allowed; }

/* ============ COMMENT BOTTOM BAR ============ */
.comment-bottom-bar {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: #fff; z-index: 100;
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px calc(8px + env(safe-area-inset-bottom));
  box-shadow: 0 -2px 8px rgba(0,0,0,.06);
  border-top: 1px solid #f0f0f0;
}
.comment-bottom-donate {
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  background: none; border: none; cursor: pointer;
  padding: 4px 6px; border-radius: 8px;
  color: #F59E0B; font-size: 11px; font-weight: 600;
  flex-shrink: 0;
  transition: background .12s;
}
.comment-bottom-donate:hover { background: #fef3c7; }
.comment-bottom-trigger {
  flex: 1;
  display: flex; align-items: center; justify-content: space-between;
  background: #f5f5f5;
  border-radius: 20px;
  padding: 8px 12px;
  cursor: pointer;
  transition: background .12s;
}
.comment-bottom-trigger:hover { background: #eee; }
.comment-bottom-placeholder { font-size: 13px; color: #bbb; }
.comment-bottom-emoji { flex-shrink: 0; }
.comment-bottom-actions { display: flex; align-items: center; gap: 2px; flex-shrink: 0; }
.comment-bottom-act {
  display: inline-flex; flex-direction: column; align-items: center; gap: 1px;
  background: none; border: none; cursor: pointer;
  padding: 4px 5px; border-radius: 6px;
  color: #999; font-size: 11px;
  transition: color .12s, background .12s;
}
.comment-bottom-act:hover { color: #508DFF; background: #f0f4ff; }
.comment-bottom-act.active { color: #508DFF; }
.comment-bottom-act span { text-align: center; }
.comment-bottom-act span.active { color: #508DFF; font-weight: 600; }

/* ============ REPORT DIALOG ============ */
.report-dialog { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 20px 18px 28px; animation: dmUp .25s ease; }
.report-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; font-size: 17px; font-weight: 700; color: #222; }
.report-close { background: none; border: none; font-size: 28px; color: #999; cursor: pointer; padding: 0; line-height: 1; }
.report-body { margin-bottom: 18px; }
.report-label { font-size: 13px; color: #666; margin-bottom: 10px; }
.report-types { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
.report-type-item { display: flex; align-items: center; gap: 5px; padding: 8px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 13px; color: #444; cursor: pointer; transition: all .2s; }
.report-type-item:hover { border-color: #F59E0B; background: #fff8ed; }
.report-type-item.active { border-color: #F59E0B; background: #fff3e0; color: #F59E0B; font-weight: 600; }
.report-type-item input[type="radio"] { display: none; }
.report-detail-row { margin-top: 8px; }
.report-textarea { width: 100%; height: 80px; padding: 10px 14px; border: 1px solid #e5e7eb; border-radius: 10px; font-size: 14px; color: #333; resize: none; outline: none; box-sizing: border-box; font-family: inherit; }
.report-textarea:focus { border-color: #F59E0B; }
.report-footer { display: flex; gap: 10px; }
.report-cancel { flex: 1; height: 44px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; font-size: 15px; color: #666; cursor: pointer; }
.report-confirm { flex: 2; height: 44px; border: none; border-radius: 12px; background: #EF4444; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
.report-confirm:disabled { background: #fca5a5; cursor: not-allowed; }

/* ============ ATTACH INFO MODAL ============ */
.attach-overlay { position: fixed; inset: 0; z-index: 310; background: rgba(0,0,0,.4); display: flex; align-items: center; justify-content: center; padding: 24px; }
.attach-modal { width: 100%; max-width: 360px; background: #fff; border-radius: 20px; padding: 28px 24px 20px; animation: amPop .2s ease; box-shadow: 0 12px 40px rgba(0,0,0,.12); }
@keyframes amPop { from { transform: scale(.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.attach-modal-icon { width: 56px; height: 56px; border-radius: 16px; background: #e0f7f9; display: flex; align-items: center; justify-content: center; margin: 0 auto 14px; }
.attach-modal-title { font-size: 17px; font-weight: 700; color: #1a1a1a; text-align: center; margin: 0 0 6px; }
.attach-modal-desc { font-size: 13px; color: #888; text-align: center; margin: 0 0 18px; line-height: 1.5; }
.attach-modal-fields { background: #f7f8fa; border-radius: 12px; padding: 14px; margin-bottom: 20px; display: flex; flex-direction: column; gap: 12px; }
.attach-field { display: flex; flex-direction: column; gap: 4px; }
.attach-field-label { font-size: 11px; color: #999; font-weight: 500; text-transform: uppercase; letter-spacing: .5px; }
.attach-field-value { font-size: 14px; color: #333; font-weight: 500; }
.attach-field-url { word-break: break-all; line-height: 1.5; font-size: 13px; color: #555; }
.attach-field-code { font-size: 18px; font-weight: 700; color: #22C3D0; letter-spacing: 2px; }
.attach-modal-actions { display: flex; gap: 10px; }
.attach-btn { flex: 1; height: 44px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all .15s; }
.attach-btn-copy { background: #22C3D0; color: #fff; }
.attach-btn-copy:active { background: #1a9fa8; }
.attach-btn-close { background: #f3f4f6; color: #555; }
.attach-btn-close:active { background: #e5e7eb; }

/* Post action bar */
.post-action-bar { position: fixed; bottom: 0; left: 0; right: 0; z-index: 100; display: flex; align-items: center; gap: 10px; padding: 8px 14px calc(8px + env(safe-area-inset-bottom, 0px)); border-top: 1px solid #eee; background: #fff; }
.action-input { flex: 1; display: flex; align-items: center; justify-content: space-between; height: 36px; padding: 0 12px; border-radius: 18px; background: #f5f5f5; cursor: pointer; }
.action-input-text { font-size: 14px; color: #bbb; }
.action-input-emoji { flex-shrink: 0; }
.action-icons { display: flex; align-items: center; gap: 4px; }
.action-icon-btn { display: flex; flex-direction: column; align-items: center; gap: 1px; padding: 2px 8px; border: none; background: none; cursor: pointer; min-width: 38px; }
.action-icon-btn svg { color: #999; transition: color .15s; }
.action-icon-count { font-size: 10px; color: #999; line-height: 1; }
.action-icon-count.active { color: #ef4444; }
.action-icon-btn.active svg { color: #ef4444; }

/* keep old action-btn style for compatibility */
.action-btn { display: flex; align-items: center; gap: 4px; padding: 6px 12px; border: none; background: none; cursor: pointer; color: #999; font-size: 14px; transition: all .15s; border-radius: 8px; }
.action-btn:hover { background: #f5f5f5; }
.action-btn.active { color: #ef4444; }
.action-btn.active svg { color: #ef4444; }

/* ============ REWARD DISPLAY ============ */
.reward-display {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  margin: 16px 0;
  padding: 4px 0;
  cursor: pointer;
  user-select: none;
}
.reward-avatars { display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.reward-avatar {
  width: 32px; height: 32px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 13px; font-weight: 700;
  border: 2px solid #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,.1);
  overflow: hidden;
  flex-shrink: 0;
  position: relative;
}
.reward-avatar-pic { width: 100%; height: 100%; object-fit: cover; }
.reward-avatar-more {
  background: #f0f0f0 !important;
  color: #999 !important;
  font-size: 10px;
  font-weight: 600;
}
.reward-summary { text-align: center; }
.reward-label { font-size: 12px; color: #999; }

/* ============ PERMISSION BARRIER ============ */
.perm-barrier {
  margin: 14px auto;
  border-radius: 12px;
  overflow: hidden;
  background: #f7f8fa;
  box-shadow: 0 2px 4px rgba(0,0,0,.02), 0 4px 10px rgba(0,0,0,.02);
  max-width: 320px;
}
.pb-deco {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 22px 0 0;
}
.pb-deco-bg {
  display: none;
}
.pb-deco-icon {
  width: 38px; height: 38px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.pb-deco-icon svg {
  width: 20px; height: 20px;
}
.pb-body {
  padding: 10px 20px 20px;
  text-align: center;
}
.pb-title {
  font-size: 15px; font-weight: 700;
  color: rgba(0,0,0,.5);
  line-height: 1.3;
  margin-bottom: 0;
}
.pb-sub {
  margin-top: 6px;
  margin-bottom: 0;
}
.pb-price-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 16px; font-weight: 700;
  color: rgba(0,0,0,.5);
}
.pb-hint {
  font-size: 13px; font-weight: 400;
  color: rgba(0,0,0,.5);
  line-height: 19px;
  margin: 0;
}
.pb-pwd-input {
  width: 100%;
  max-width: 200px;
  height: 36px;
  border: 1px solid rgba(0,0,0,.12);
  border-radius: 8px;
  padding: 0 12px;
  font-size: 13px;
  text-align: center;
  outline: none;
  background: #f9fafb;
  color: rgba(0,0,0,.85);
  transition: border-color .2s;
  box-sizing: border-box;
}
.pb-pwd-input::placeholder { color: rgba(0,0,0,.3); }
.pb-pwd-input:focus { border-color: rgba(0,102,255,.5); }
.pb-actions {
  display: flex;
  gap: 8px;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 14px;
}
.pb-btn {
  height: 36px;
  padding: 0 26px;
  border: none;
  border-radius: 18px;
  font-size: 13px; font-weight: 600;
  cursor: pointer;
  transition: all .15s cubic-bezier(.4,0,.2,1);
  white-space: nowrap;
}
.pb-btn:active { opacity: .85; }
.pb-btn-primary {
  background: linear-gradient(94.87deg, #06f .34%, #0085ff 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(0,102,255,.25), 0 1px 2px 0 rgba(0,102,255,.4);
}
.pb-btn-secondary {
  background: #f3f4f6;
  color: rgba(0,0,0,.85);
  box-shadow: none;
}
.pb-btn-secondary:active { background: #e5e7eb; }
.pb-btn-premium {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

/* Paid barrier - exact doubao.com proportions, gold color */
.perm-barrier-paid {
  margin: 14px auto;
  border-radius: 14px;
}
.perm-barrier-paid .pb-deco { padding-top: 24px; }
.perm-barrier-paid .pb-deco-icon { width: 38px; height: 38px; background: rgba(245,158,11,.08); color: #f59e0b; }
.perm-barrier-paid .pb-deco-icon svg { width: 20px; height: 20px; }
.perm-barrier-paid .pb-body { padding: 10px 20px 20px; }
.perm-barrier-paid .pb-title { font-size: 15px; }
.perm-barrier-paid .pb-sub { margin-top: 6px; }
.perm-barrier-paid .pb-price-tag { font-size: 13px; font-weight: 400; color: rgba(0,0,0,.5); gap: 2px; }
.perm-barrier-paid .pb-sold {
  margin: 4px 0 0;
  font-size: 12px; font-weight: 400;
  color: rgba(0,0,0,.35);
  text-align: center;
}
.perm-barrier-paid .pb-actions { margin-top: 14px; }
.perm-barrier-paid .pb-btn {
  height: 36px; padding: 0 26px;
  border-radius: 18px; font-size: 13px;
}
.perm-barrier-paid .pb-btn-primary {
  background: linear-gradient(94.87deg, #f59e0b .34%, #d97706 100.34%);
  color: #fff;
  box-shadow: 0 6px 24px 0 rgba(245,158,11,.25), 0 1px 2px 0 rgba(245,158,11,.4);
}

.perm-barrier-login .pb-deco-icon { background: rgba(0,102,255,.08); color: #06f; }

.perm-barrier-comment .pb-deco-icon { background: rgba(16,185,129,.08); color: #10b981; }

.perm-barrier-level .pb-deco-icon,
.perm-barrier-level1 .pb-deco-icon,
.perm-barrier-level2 .pb-deco-icon { background: rgba(139,92,246,.08); color: #8b5cf6; }

.perm-barrier-password .pb-deco-icon { background: rgba(236,72,153,.08); color: #ec4899; }

/* ===== COMMENT DIALOG ===== */
.comment-dialog-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,.45);
  z-index: 2000;
  display: flex; align-items: flex-end; justify-content: center;
}
.comment-dialog {
  width: 100%; max-width: 480px;
  background: #fff;
  border-radius: 16px 16px 0 0;
  overflow: hidden;
  animation: cdSlideUp .25s ease;
}
@keyframes cdSlideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.comment-dialog-header {
  display: flex; align-items: center; justify-content: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f0f0f0;
  position: relative;
}
.comment-dialog-title { font-size: 16px; font-weight: 600; color: #111; }
.comment-dialog-close {
  position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
  width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;
  font-size: 22px; color: #999; background: none; border: none; cursor: pointer;
}
.comment-dialog-body { padding: 16px; }
.comment-dialog-textarea {
  width: 100%; border: none; outline: none; resize: none;
  font-size: 15px; line-height: 1.6; color: #222;
  background: #f7f7f7; border-radius: 10px; padding: 12px;
  box-sizing: border-box;
}
.comment-dialog-toolbar {
  display: flex; align-items: center; padding: 8px 0 0;
}
.comment-dialog-img-btn {
  display: flex; align-items: center; justify-content: center;
  width: 34px; height: 34px; border-radius: 8px;
  background: #f5f5f5; cursor: pointer;
}
.comment-dialog-imgs {
  display: flex; gap: 8px; flex-wrap: wrap; padding: 8px 0 0;
}
.comment-dialog-img-item {
  position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden;
}
.comment-dialog-img-thumb {
  width: 100%; height: 100%; object-fit: cover;
}
.comment-dialog-img-remove {
  position: absolute; top: 2px; right: 2px;
  width: 18px; height: 18px; border-radius: 50%;
  background: rgba(0,0,0,.5); color: #fff; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
  border: none; cursor: pointer; line-height: 1;
}
.comment-dialog-footer {
  display: flex; gap: 12px; padding: 12px 16px 20px;
  border-top: 1px solid #f0f0f0;
}
.comment-dialog-cancel {
  flex: 1; height: 42px; border-radius: 21px;
  background: #f0f0f0; color: #666; font-size: 15px;
  border: none; cursor: pointer;
}
.comment-dialog-send {
  flex: 1; height: 42px; border-radius: 21px;
  background: linear-gradient(135deg, #508DFF, #3b6fcf); color: #fff; font-size: 15px; font-weight: 600;
  border: none; cursor: pointer;
}
.comment-dialog-send:disabled { opacity: .4; cursor: not-allowed; }

/* ============ PAYMENT DIALOGS ============ */
.modal-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.5);
  display: flex; align-items: center; justify-content: center;
  z-index: 200;
}
.confirm-modal {
  background: #fff; border-radius: 24px; width: 320px;
  padding: 32px 24px 24px; text-align: center;
}
.confirm-title {
  font-size: 18px; font-weight: 700; color: #1a1a2e; margin-bottom: 20px;
}
.confirm-detail {
  background: #f5f6fa; border-radius: 12px; padding: 16px; margin-bottom: 16px;
}
.confirm-row {
  display: flex; justify-content: space-between; align-items: center;
  font-size: 14px; color: #6b7280; padding: 6px 0;
}
.confirm-row + .confirm-row { border-top: 1px solid rgba(0,0,0,.05); }
.confirm-row .strong { color: #1a1a2e; font-weight: 600; }
.confirm-row .accent { color: #ff6b35; font-weight: 600; font-size: 12px; word-break: break-all; }
.pay-coupon-section {
  margin-bottom: 20px;
  text-align: left;
}
.confirm-actions { display: flex; gap: 12px; }
.confirm-btn {
  flex: 1; padding: 12px 0; border-radius: 12px; font-size: 15px;
  font-weight: 600; border: none; cursor: pointer; transition: all .2s;
}
.confirm-btn.cancel { background: #f0f0f5; color: #6b7280; }
.confirm-btn.cancel:hover { background: #e5e5eb; }
.confirm-btn.primary {
  background: linear-gradient(135deg, #ff6b35, #ff3c00); color: #fff;
}
.confirm-btn.primary:hover { opacity: .9; }
.confirm-btn.primary:disabled { opacity: .5; cursor: not-allowed; }

.result-modal {
  background: #fff; border-radius: 24px; width: 300px;
  padding: 32px 24px 24px; text-align: center;
}
.result-icon {
  width: 64px; height: 64px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px;
}
.result-icon svg { width: 32px; height: 32px; color: #fff; }
.result-icon.success {
  background: linear-gradient(135deg, #22c55e, #16a34a);
  box-shadow: 0 8px 24px rgba(34,197,94,.3);
}
.result-icon.fail {
  background: linear-gradient(135deg, #ef4444, #dc2626);
  box-shadow: 0 8px 24px rgba(239,68,68,.3);
}
.result-title { font-size: 18px; font-weight: 700; color: #1f2937; margin-bottom: 6px; }
.result-msg { font-size: 13px; color: #6b7280; margin-bottom: 4px; }
.result-detail {
  background: #f9fafb; border-radius: 14px; padding: 12px; margin: 16px 0;
}
.result-row {
  display: flex; justify-content: space-between; font-size: 12px;
  color: #6b7280; margin-bottom: 6px;
}
.result-row:last-child { margin-bottom: 0; }
.result-row .strong { color: #374151; font-weight: 600; }
.result-row .accent { color: #ef4444; font-weight: 600; }
.result-btn {
  width: 100%; padding: 12px; border-radius: 12px; border: none;
  font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 8px;
  background: #f3f4f6; color: #374151;
}
.result-btn.primary {
  background: linear-gradient(135deg, #f59e0b, #ea580c); color: #fff;
}

.coupon-dd-item {
  display: flex; justify-content: space-between; width: 100%;
}
.coupon-dd-left { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.coupon-dd-right { font-size: 11px; color: #999; margin-left: 8px; white-space: nowrap; }
.load-more-wrap { display: flex; align-items: center; justify-content: center; padding: 16px 0 20px; color: #508DFF; font-size: 14px; cursor: pointer; user-select: none; }
.load-more-wrap:active { opacity: .7; }
.load-more-spin { width: 20px; height: 20px; border: 2px solid #e0e0e0; border-top-color: #508DFF; border-radius: 50%; animation: load-more-rotate .6s linear infinite; }
@keyframes load-more-rotate { to { transform: rotate(360deg); } }
</style>
