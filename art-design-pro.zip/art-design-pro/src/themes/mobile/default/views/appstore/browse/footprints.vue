<template>
  <div style="min-height: 100vh; background: var(--app-page-bg); padding-bottom: 64px;">
    <div style="background: #fff; padding: 12px 16px; display: flex; align-items: center; gap: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); position: sticky; top: 0; z-index: 10;">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">浏览足迹</span>
    </div>

    <div v-if="!isLogin" style="text-align: center; padding: 80px 16px; color: #999;">
      <p>请先登录后查看浏览足迹</p>
    </div>

    <div v-else>
      <div v-if="postList.length === 0 && appList.length === 0" style="text-align: center; padding: 60px 16px; color: #bbb;">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="1.5" style="display: block; margin: 0 auto 12px;"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <p style="font-size: 14px;">暂无浏览记录</p>
        <p style="font-size: 12px; margin-top: 4px;">去逛逛应用和社区吧</p>
      </div>

      <template v-else>
        <div style="display: flex; background: #fff; margin: 12px 16px 0; border-radius: 12px; overflow: hidden;">
          <div
            :style="{ flex: 1, textAlign: 'center', padding: '12px 0', fontSize: '14px', fontWeight: activeTab === 'post' ? 600 : 400, color: activeTab === 'post' ? '#333' : '#999', borderBottom: activeTab === 'post' ? '2px solid #409EFF' : '2px solid transparent', cursor: 'pointer', transition: 'all .2s' }"
            @click="activeTab = 'post'"
          >
            帖子 ({{ postList.length }})
          </div>
          <div
            :style="{ flex: 1, textAlign: 'center', padding: '12px 0', fontSize: '14px', fontWeight: activeTab === 'app' ? 600 : 400, color: activeTab === 'app' ? '#333' : '#999', borderBottom: activeTab === 'app' ? '2px solid #10b981' : '2px solid transparent', cursor: 'pointer', transition: 'all .2s' }"
            @click="activeTab = 'app'"
          >
            应用 ({{ appList.length }})
          </div>
        </div>

        <div style="padding: 12px 16px;">
          <template v-if="activeTab === 'post'">
            <div v-if="postList.length === 0" style="text-align: center; padding: 40px 0; color: #ccc; font-size: 13px;">暂无浏览的帖子</div>
            <div v-for="item in postList" :key="'p'+item.id" style="display: flex; align-items: center; gap: 12px; background: #fff; border-radius: 10px; padding: 10px 12px; margin-bottom: 8px; cursor: pointer;" @click="goPost(item)">
              <img v-if="item.item_cover" :src="item.item_cover" style="width: 44px; height: 44px; border-radius: 8px; object-fit: cover; flex-shrink: 0;" />
              <div v-else style="width: 44px; height: 44px; border-radius: 8px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="2"><path d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 13px; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.item_title || '无标题' }}</div>
                <div style="font-size: 11px; color: #bbb; margin-top: 4px;">{{ fmtTime(item.create_time) }}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </template>

          <template v-if="activeTab === 'app'">
            <div v-if="appList.length === 0" style="text-align: center; padding: 40px 0; color: #ccc; font-size: 13px;">暂无浏览的应用</div>
            <div v-for="item in appList" :key="'a'+item.id" style="display: flex; align-items: center; gap: 12px; background: #fff; border-radius: 10px; padding: 10px 12px; margin-bottom: 8px; cursor: pointer;" @click="goApp(item)">
              <img v-if="item.item_cover" :src="item.item_cover" style="width: 44px; height: 44px; border-radius: 10px; object-fit: cover; flex-shrink: 0;" />
              <div v-else style="width: 44px; height: 44px; border-radius: 10px; background: #f3f4f6; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 13px; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.item_title || '无标题' }}</div>
                <div style="font-size: 11px; color: #bbb; margin-top: 4px;">{{ fmtTime(item.create_time) }}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2.5"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </template>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchBrowseHistory } from '@/api/browse-history'

defineOptions({ name: 'AppStoreFootprints' })

const router = useRouter()
const userStore = useUserStore()
const isLogin = computed(() => userStore.isLogin)

const activeTab = ref('post')
const postList = ref<any[]>([])
const appList = ref<any[]>([])

function fmtTime(t: string) {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return t.slice(0, 10)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  const m = d.getMonth() + 1
  const day = d.getDate()
  return m + '/' + day
}

function goPost(item: any) {
  router.push(item.item_url || '/community')
}

function goApp(item: any) {
  router.push(item.item_url || '/appstore/browse')
}

onMounted(async () => {
  if (!isLogin.value) return
  try {
    const res: any = await fetchBrowseHistory({ userId: userStore.info.userId! })
    const list = res?.data || res || []
    postList.value = list.filter((i: any) => i.item_type === 'post')
    appList.value = list.filter((i: any) => i.item_type === 'app')
  } catch {}
})
</script>
