<!-- 系统日志 - 移动端管理页面 -->
<template>
  <div v-if="!isAdmin" class="min-h-screen flex items-center justify-center bg-[#f5f6f8] p-6">
    <div class="text-center">
      <svg class="mx-auto mb-4" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
        <rect x="3" y="11" width="18" height="11" rx="2" />
        <path d="M7 11V7a5 5 0 0110 0v4" />
      </svg>
      <p class="text-gray-500 text-sm">无权访问此页面</p>
      <button class="mt-4 px-6 py-2 bg-[#FF4757] text-white rounded-lg text-sm" @click="$router.back()">返回</button>
    </div>
  </div>

  <div v-else class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="sticky top-0 z-20 bg-white shadow-sm">
      <div class="flex items-center px-3 py-3">
        <button class="p-1 -ml-1" @click="$router.back()">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6" /></svg>
        </button>
        <h1 class="flex-1 text-center text-base font-bold mr-6">系统日志</h1>
        <button class="p-1" @click="showCategoryPanel = true">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" /></svg>
        </button>
      </div>

      <div class="px-3 pb-3 space-y-2">
        <div class="flex gap-2">
          <select v-model="filterType" class="flex-1 bg-gray-50 rounded-xl px-3 py-2.5 text-sm border-none outline-none appearance-none text-gray-700" @change="onFilterChange">
            <option value="">全部类型</option>
            <option v-for="t in logTypes" :key="t.value" :value="t.value">{{ t.label }}</option>
          </select>
          <select v-model="pageSize" class="w-20 bg-gray-50 rounded-xl px-2 py-2.5 text-sm border-none outline-none appearance-none text-gray-700" @change="onPageSizeChange">
            <option :value="10">10</option>
            <option :value="15">15</option>
            <option :value="20">20</option>
            <option :value="50">50</option>
          </select>
        </div>
        <div class="flex gap-2">
          <input v-model="dateStart" type="date" class="flex-1 bg-gray-50 rounded-xl px-3 py-2.5 text-sm border-none outline-none text-gray-700" placeholder="开始日期" @change="onDateChange" />
          <input v-model="dateEnd" type="date" class="flex-1 bg-gray-50 rounded-xl px-3 py-2.5 text-sm border-none outline-none text-gray-700" placeholder="结束日期" @change="onDateChange" />
        </div>
      </div>
    </div>

    <div v-if="total >= 0" class="px-3 py-2 bg-white border-b border-gray-50">
      <div class="flex items-center justify-between mb-2">
        <span class="text-xs text-gray-400">共 {{ total }} 条，{{ currentPage }}/{{ totalPages }} 页</span>
        <button v-if="filterType || dateStart || dateEnd" class="text-xs text-[#FF4757]" @click="clearFilters">清除筛选</button>
      </div>
      <div class="flex items-center gap-2">
        <button :disabled="currentPage <= 1" class="flex-1 py-2 rounded-lg text-xs font-medium border transition-colors" :class="currentPage <= 1 ? 'text-gray-300 border-gray-200 bg-gray-50' : 'text-gray-600 border-gray-200 active:bg-gray-50'" @click="goPage(currentPage - 1)">上一页</button>
        <div class="flex gap-1">
          <button v-for="p in pageNumbers" :key="p" :class="p === currentPage ? 'bg-[#FF4757] text-white border-[#FF4757]' : 'text-gray-600 border-gray-200 active:bg-gray-50'" class="w-8 h-8 flex items-center justify-center rounded-lg text-xs font-medium border transition-colors" @click="goPage(p)">{{ p }}</button>
        </div>
        <button :disabled="currentPage >= totalPages" class="flex-1 py-2 rounded-lg text-xs font-medium border transition-colors" :class="currentPage >= totalPages ? 'text-gray-300 border-gray-200 bg-gray-50' : 'text-gray-600 border-gray-200 active:bg-gray-50'" @click="goPage(currentPage + 1)">下一页</button>
      </div>
    </div>

    <div class="flex-1 overflow-y-auto px-3 pb-4">
      <div v-if="loading" class="flex items-center justify-center py-20">
        <svg class="animate-spin" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#FF4757" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" /></svg>
      </div>

      <div v-else-if="list.length === 0" class="flex flex-col items-center justify-center py-20">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="3" /><line x1="9" y1="9" x2="15" y2="9" /><line x1="9" y1="13" x2="15" y2="13" /><line x1="9" y1="17" x2="12" y2="17" /></svg>
        <p class="text-gray-400 text-sm mt-3">暂无日志记录</p>
      </div>

      <div v-else class="space-y-2">
        <div v-for="item in list" :key="item.id" class="bg-white rounded-xl p-3 active:bg-gray-50 transition-colors" @click="showDetail(item)">
          <div class="flex items-start justify-between mb-1.5">
            <div class="flex items-center gap-2">
              <span :class="typeBadgeClass(item.type)" class="text-[10px] px-2 py-0.5 rounded-full font-medium">{{ item.type }}</span>
              <span v-if="item.target_type" class="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">{{ item.target_type }}</span>
            </div>
            <span class="text-[10px] text-gray-400 flex-shrink-0 ml-2">{{ formatTime(item.create_time) }}</span>
          </div>
          <div class="flex items-center gap-1.5 text-xs text-gray-600 mb-1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
            <span>{{ item.user_name || 'system' }}</span>
            <span class="text-gray-300">|</span>
            <span class="text-gray-400">IP: {{ item.ip || '-' }}</span>
          </div>
          <p class="text-xs text-gray-500 line-clamp-2">{{ item.detail || '无详情' }}</p>
          <div v-if="canRestore(item)" class="mt-2 flex justify-end">
            <button class="text-xs px-3 py-1 bg-[#FF4757]/10 text-[#FF4757] rounded-lg font-medium" @click.stop="handleRestore(item)">恢复操作</button>
          </div>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <Transition name="slide-up">
        <div v-if="detailVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="closeDetail">
          <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
            <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
              <button @click="closeDetail">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
              </button>
              <span class="text-base font-bold">日志详情</span>
              <div class="w-6" />
            </div>
            <div v-if="detailItem" class="overflow-y-auto px-4 py-3 space-y-3">
              <div class="bg-gray-50 rounded-2xl p-4 space-y-3">
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">ID</span>
                  <span class="text-sm font-medium">#{{ detailItem.id }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">操作用户</span>
                  <span class="text-sm">{{ detailItem.user_name || 'system' }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">用户ID</span>
                  <span class="text-sm text-gray-600">{{ detailItem.user_id }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">操作类型</span>
                  <span :class="typeBadgeClass(detailItem.type)" class="text-xs px-2 py-0.5 rounded-full font-medium">{{ detailItem.type }}</span>
                </div>
                <div class="flex justify-between items-center" v-if="detailItem.target_type">
                  <span class="text-xs text-gray-400">目标类型</span>
                  <span class="text-sm text-gray-600">{{ detailItem.target_type }}</span>
                </div>
                <div class="flex justify-between items-center" v-if="detailItem.target_id">
                  <span class="text-xs text-gray-400">目标ID</span>
                  <span class="text-sm text-gray-600">{{ detailItem.target_id }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">IP地址</span>
                  <span class="text-sm text-gray-600">{{ detailItem.ip || '-' }}</span>
                </div>
                <div class="flex justify-between items-center">
                  <span class="text-xs text-gray-400">操作时间</span>
                  <span class="text-sm text-gray-600">{{ detailItem.create_time }}</span>
                </div>
              </div>
              <div class="bg-gray-50 rounded-2xl p-4">
                <p class="text-xs text-gray-400 mb-1">操作详情</p>
                <p class="text-sm text-gray-700 whitespace-pre-wrap break-all">{{ detailItem.detail || '无详情' }}</p>
              </div>
              <button v-if="canRestore(detailItem)" class="w-full py-3 bg-[#FF4757]/10 text-[#FF4757] rounded-xl text-sm font-medium" @click="handleRestoreFromDetail">恢复此操作</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="slide-up">
        <div v-if="showCategoryPanel" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showCategoryPanel = false">
          <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
            <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
              <button @click="showCategoryPanel = false">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
              </button>
              <span class="text-base font-bold">日志开关</span>
              <div class="w-6" />
            </div>
            <div class="overflow-y-auto px-4 py-3 space-y-4">
              <p class="text-xs text-gray-400">关闭某项后，对应操作将不再记录日志，默认全部开启</p>
              <div v-for="(items, groupName) in categoryGroups" :key="groupName" class="space-y-2">
                <div class="text-xs font-bold text-gray-500 uppercase tracking-wide">{{ groupName }}</div>
                <div v-for="item in items" :key="item.key" class="flex items-center justify-between bg-gray-50 rounded-2xl px-4 py-3">
                  <div class="flex flex-col">
                    <span class="text-sm font-medium">{{ item.label }}</span>
                    <span class="text-[10px] text-gray-400">{{ item.key }}</span>
                  </div>
                  <button :class="item.value ? 'bg-[#FF4757]' : 'bg-gray-300'" class="relative w-12 h-7 rounded-full transition-colors duration-200" @click="toggleCategory(item)">
                    <span :class="item.value ? 'translate-x-[22px]' : 'translate-x-[2px]'" class="absolute top-[3px] w-5 h-5 bg-white rounded-full shadow transition-transform duration-200" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

defineOptions({ name: 'SyslogMobile' })

const userStore = useUserStore()
const isAdmin = computed(() => {
  const roles = userStore.info.roles || []
  return roles.includes('R_SUPER') || roles.includes('R_ADMIN')
})

const logTypes = [
  { label: '登录', value: 'login' },
  { label: '登出', value: 'logout' },
  { label: '创建', value: 'create' },
  { label: '更新', value: 'update' },
  { label: '删除', value: 'delete' },
  { label: '回收', value: 'trash' },
  { label: '恢复', value: 'restore' },
  { label: '关注', value: 'follow' },
  { label: '点赞', value: 'like' },
  { label: '收藏', value: 'favorite' },
  { label: '评论', value: 'comment' },
  { label: '兑换', value: 'redeem' },
  { label: '购买', value: 'purchase' },
  { label: '上传', value: 'upload' },
  { label: '审批', value: 'approve' },
  { label: '配置', value: 'config' }
]

const list = ref<any[]>([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(15)
const total = ref(0)
const filterType = ref('')
const dateStart = ref('')
const dateEnd = ref('')

const detailVisible = ref(false)
const detailItem = ref<any>(null)

const showCategoryPanel = ref(false)
const categoryGroups = ref<Record<string, { key: string; label: string; value: boolean }[]>>({})

const totalPages = computed(() => Math.ceil(total.value / pageSize.value) || 1)

const pageNumbers = computed(() => {
  const pages: number[] = []
  const tp = totalPages.value
  const cp = currentPage.value
  let start = Math.max(1, cp - 2)
  let end = Math.min(tp, cp + 2)
  if (end - start < 4) {
    if (start === 1) end = Math.min(tp, start + 4)
    else start = Math.max(1, end - 4)
  }
  for (let i = start; i <= end; i++) pages.push(i)
  return pages
})

function typeBadgeClass(type: string) {
  const map: Record<string, string> = {
    login: 'bg-green-50 text-green-600',
    logout: 'bg-gray-100 text-gray-500',
    create: 'bg-blue-50 text-blue-600',
    update: 'bg-yellow-50 text-yellow-600',
    delete: 'bg-red-50 text-red-600',
    trash: 'bg-red-50 text-red-600',
    restore: 'bg-green-50 text-green-600',
    follow: 'bg-blue-50 text-blue-600',
    like: 'bg-yellow-50 text-yellow-600',
    favorite: 'bg-yellow-50 text-yellow-600',
    comment: 'bg-gray-100 text-gray-600',
    approve: 'bg-green-50 text-green-600',
    reject: 'bg-red-50 text-red-600',
    config: 'bg-blue-50 text-blue-600',
    redeem: 'bg-purple-50 text-purple-600',
    purchase: 'bg-violet-50 text-violet-600',
    upload: 'bg-cyan-50 text-cyan-600'
  }
  return map[type] || 'bg-gray-100 text-gray-500'
}

function formatTime(time: string) {
  if (!time) return ''
  return time.replace(/^.*?(\d{2}:\d{2}:\d{2}).*$/, '$1')
}

function canRestore(item: any) {
  return item.target_type === 'menu' && (item.type === 'update' || item.type === 'delete')
}

async function fetchLogs() {
  loading.value = true
  try {
    const params: any = {
      page: currentPage.value,
      pageSize: pageSize.value
    }
    if (filterType.value) params.type = filterType.value
    if (dateStart.value || dateEnd.value) {
      params.dateRange = [dateStart.value || '1970-01-01', dateEnd.value || '2099-12-31']
    }
    const res: any = await request.get({ url: '/api/system-log/list', params })
    if (res) {
      list.value = res.list || []
      total.value = res.total || 0
    }
  } finally {
    loading.value = false
  }
}

async function loadCategories() {
  try {
    const res: any = await request.get({ url: '/api/system-log/categories' })
    if (res) {
      categoryGroups.value = res
    }
  } catch {}
}

async function toggleCategory(item: any) {
  const newVal = !item.value
  item.value = newVal
  try {
    await request.post({ url: '/api/system-log/categories/save', data: { key: item.key, value: newVal } })
  } catch {
    item.value = !newVal
    alert('保存失败，请确认登录状态后重试')
  }
}

async function handleRestore(item: any) {
  if (!confirm('确定要恢复该操作吗？将回滚到操作前的状态。')) return
  try {
    await request.post({ url: `/api/menu/restore/${item.id}` })
    alert('恢复成功')
    if (detailVisible.value) closeDetail()
    fetchLogs()
  } catch (e: any) {
    alert(e?.msg || e?.message || '恢复失败')
  }
}

function handleRestoreFromDetail() {
  if (detailItem.value) handleRestore(detailItem.value)
}

function showDetail(item: any) {
  detailItem.value = item
  detailVisible.value = true
}

function closeDetail() {
  detailVisible.value = false
  detailItem.value = null
}

function goPage(p: number) {
  if (p < 1 || p > totalPages.value) return
  currentPage.value = p
  fetchLogs()
}

function onFilterChange() {
  currentPage.value = 1
  fetchLogs()
}

function onDateChange() {
  currentPage.value = 1
  fetchLogs()
}

function onPageSizeChange() {
  currentPage.value = 1
  fetchLogs()
}

function clearFilters() {
  filterType.value = ''
  dateStart.value = ''
  dateEnd.value = ''
  currentPage.value = 1
  fetchLogs()
}

watch(showCategoryPanel, (v) => {
  if (v) loadCategories()
})

onMounted(() => {
  if (isAdmin.value) fetchLogs()
})
</script>

<style scoped>
.slide-up-enter-active,
.slide-up-leave-active {
  transition: opacity 0.25s ease;
}
.slide-up-enter-active > div:last-child,
.slide-up-leave-active > div:last-child {
  transition: transform 0.25s ease;
}
.slide-up-enter-from,
.slide-up-leave-to {
  opacity: 0;
}
.slide-up-enter-from > div:last-child,
.slide-up-leave-to > div:last-child {
  transform: translateY(100%);
}

@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.animate-slide-up {
  animation: slide-up 0.25s ease;
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
