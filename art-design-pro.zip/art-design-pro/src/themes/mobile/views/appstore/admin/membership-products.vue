<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">会员商品管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <select v-model="filterLevelId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="fetchData">
          <option value="">全部等级</option>
          <option v-for="lv in levels" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
        </select>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span v-if="item.isPromo" class="text-[10px] px-1.5 py-0.5 rounded bg-red-50 text-red-500">促销</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                </div>
                <div class="text-xs text-gray-400">
                  <span class="text-[#FF4757] font-medium">¥{{ item.price }}</span>
                  <span v-if="item.originalPrice > 0" class="line-through text-gray-300 ml-1">¥{{ item.originalPrice }}</span>
                  <span class="ml-2">{{ item.durationDays }}天</span>
                </div>
                <div class="text-xs text-gray-400 mt-0.5">等级: {{ item.levelName || levelNameMap[item.levelId] || '-' }}</div>
              </div>
              <div class="flex gap-1 flex-shrink-0 ml-2">
                <button class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click.stop="openDialog(item)">编辑</button>
                <button class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ list.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无商品</span></div>
      </div>

      <button class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑商品' : '新增商品' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">商品名</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">会员等级</label><select v-model="form.levelId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option :value="0">选择等级</option><option v-for="lv in levels" :key="lv.id" :value="lv.id">{{ lv.name }}</option></select></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">价格</label><input v-model.number="form.price" type="number" step="0.01" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">原价</label><input v-model.number="form.originalPrice" type="number" step="0.01" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">时长(天)</label><input v-model.number="form.durationDays" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">促销</label><select v-model="form.isPromo" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option :value="false">否</option><option :value="true">是</option></select></div>
          </div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4.5' : 'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'MembershipProductsMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const levels = ref<any[]>([])
const levelNameMap = computed(() => {
  const map: Record<number, string> = {}
  levels.value.forEach(lv => { map[lv.id] = lv.name })
  return map
})

const loadLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    if (res?.records) levels.value = res.records
  } catch { }
}

const loading = ref(false); const list = ref<any[]>([]); const filterLevelId = ref('')
const fetchData = async () => {
  loading.value = true
  try {
    const params: any = {}
    if (filterLevelId.value) params.levelId = filterLevelId.value
    const res: any = await request.get({ url: '/api/membership/products', params })
    list.value = res?.records || res || []
  } catch { }
  loading.value = false
}

const dialogVisible = ref(false); const editId = ref<number | null>(null)
const formDefault = () => ({ levelId: 0, name: '', price: 0, originalPrice: 0, durationDays: 30, isPromo: false, status: '1' })
const form = reactive({ levelId: 0, name: '', price: 0, originalPrice: 0, durationDays: 30, isPromo: false, status: '1' })

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) {
    form.levelId = item.levelId || 0; form.name = item.name || ''; form.price = item.price || 0
    form.originalPrice = item.originalPrice || 0; form.durationDays = item.durationDays || 30
    form.isPromo = !!item.isPromo; form.status = item.status || '1'
  } else {
    Object.assign(form, formDefault())
  }
  dialogVisible.value = true
}

const saveItem = async () => {
  try {
    await request.post({ url: '/api/membership/product/save', data: { id: editId.value || undefined, ...form } })
    showToast('保存成功'); dialogVisible.value = false; fetchData()
  } catch { showToast('保存失败', 'error') }
}

const deleteItem = async (item: any) => {
  if (!confirm(`确认删除商品 ${item.name}？`)) return
  try {
    await request.delete({ url: `/api/membership/product/${item.id}` })
    showToast('删除成功'); fetchData()
  } catch { showToast('删除失败', 'error') }
}

onMounted(() => { loadLevels(); fetchData() })
</script>
