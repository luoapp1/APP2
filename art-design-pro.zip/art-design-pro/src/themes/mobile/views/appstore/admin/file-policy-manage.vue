<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">文件上传策略</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <button class="w-full h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="openDialog(null)">新增策略</button>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors" @click="openDialog(item)">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">#{{ item.id }}</span>
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status==='1'?'bg-green-50 text-green-600':'bg-gray-100 text-gray-400'">{{ item.status==='1'?'启用':'禁用' }}</span>
                </div>
                <div class="grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs text-gray-400 mt-1">
                  <div>适用: <span class="text-gray-600">{{ scopeLabel(item) }}</span></div>
                  <div>最大: <span class="text-gray-600">{{ item.max_file_size_mb }}MB</span></div>
                  <div class="col-span-2">允许: <span class="text-gray-600">{{ item.allowed_types || '全部' }}</span></div>
                  <div class="col-span-2">禁止: <span class="text-red-400">{{ item.banned_types || '无' }}</span></div>
                </div>
              </div>
              <div class="flex gap-1 flex-shrink-0 ml-2">
                <button class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ data.length }} 条</div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无上传策略</span></div>
      </div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑策略' : '新增策略' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" :disabled="saving" @click="doSave">{{ saving ? '保存中...' : '保存' }}</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">策略名称</label><input v-model="form.name" placeholder="如: 普通用户限制" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">适用等级</label><select v-model="form.user_level_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="onLevelChange"><option :value="0">所有用户</option><option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">适用角色</label><select v-model="form.role_code" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600"><option value="">不限</option><option value="*">所有角色</option><option v-for="r in roleList" :key="r.role_code||r.code" :value="r.role_code||r.code">{{ r.role_name||r.name }}</option></select></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">最大文件大小 (MB)</label><input v-model.number="form.max_file_size_mb" type="number" min="1" max="1024" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>

          <div class="bg-[#f5f6f8] rounded-xl p-3 space-y-3">
            <div class="text-xs text-gray-500 font-medium">文件类型限制</div>
            <div><label class="text-[10px] text-gray-400 mb-1 block">允许的文件格式 (逗号分隔)</label><input v-model="form.allowed_types" placeholder="留空为允许全部，如: jpg,png,gif,mp4" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
            <div><label class="text-[10px] text-gray-400 mb-1 block">禁止的文件格式 (逗号分隔)</label><input v-model="form.banned_types" placeholder="如: exe,bat,sh 等危险格式" class="w-full h-10 px-3 text-sm bg-white rounded-lg border-none outline-none" /></div>
          </div>

          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.status==='1'?'bg-[#FF4757]':'bg-gray-200'" @click="form.status=form.status==='1'?'0':'1'"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status==='1'?'translate-x-4.5':'left-0.5'" /></button></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'FilePolicyManageMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const helper=(res:any)=>{if(!res)return[];if(Array.isArray(res))return res;return res?.records||res?.data?.records||res?.data||[]}

const loading=ref(false);const data=ref<any[]>([])
const fetchData=async()=>{loading.value=true;try{const res:any=await request.get({url:'/api/file-policy/list'});data.value=helper(res)}catch{}loading.value=false}

const scopeLabel=(item:any)=>{
  if(item.role_code==='*')return'所有角色'
  if(item.role_code){const r=roleList.value.find(x=>(x.role_code||x.code)===item.role_code);return r?r.role_name||r.name:item.role_code}
  return item.user_level_name||'所有用户'
}

const levelList=ref<any[]>([]);const roleList=ref<any[]>([])
const loadDeps=async()=>{
  try{const r1:any=await request.get({url:'/api/operation/membership-level/list',params:{current:1,size:100}});levelList.value=helper(r1)}catch{}
  try{const r2:any=await request.get({url:'/api/role/list',params:{current:1,size:100}});roleList.value=helper(r2)}catch{}
}

// Dialog
const dialogVisible=ref(false);const editId=ref<number|null>(null);const saving=ref(false)
const form=reactive({name:'',user_level_id:0,user_level_name:'',role_code:'',max_file_size_mb:10,allowed_types:'',banned_types:'',status:'1'})

const onLevelChange=()=>{const lv=levelList.value.find(x=>x.id===form.user_level_id);form.user_level_name=lv?.name||''}

const openDialog=(item:any|null)=>{
  editId.value=item?.id||null
  if(item){form.name=item.name||'';form.user_level_id=item.user_level_id||0;form.user_level_name=item.user_level_name||'';form.role_code=item.role_code||'';form.max_file_size_mb=item.max_file_size_mb||10;form.allowed_types=item.allowed_types||'';form.banned_types=item.banned_types||'';form.status=item.status||'1'}else{Object.assign(form,{name:'',user_level_id:0,user_level_name:'',role_code:'',max_file_size_mb:10,allowed_types:'',banned_types:'',status:'1'})}
  dialogVisible.value=true
}

const doSave=async()=>{saving.value=true;try{await request.post({url:'/api/file-policy/save',data:{id:editId.value||undefined,...form}});showToast('保存成功');dialogVisible.value=false;fetchData()}catch(e:any){showToast('保存失败: '+(e.message||''),'error')}saving.value=false}
const deleteItem=async(item:any)=>{if(!confirm(`确定删除策略 ${item.name}？`))return;try{await request.post({url:'/api/file-policy/delete',data:{id:item.id}});showToast('删除成功');fetchData()}catch{showToast('删除失败','error')}}

onMounted(()=>{fetchData();loadDeps()})
</script>
