<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">控制台</span>
      <button class="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 active:bg-gray-100" @click="refresh">
        <svg class="w-4 h-4" :class="{ 'animate-spin': loading }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
        </svg>
      </button>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="error" class="mx-3 mt-3">
        <div class="bg-red-50 rounded-2xl px-4 py-5 text-center">
          <svg class="w-10 h-10 mx-auto text-red-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <p class="text-sm text-red-500 mb-3">{{ error }}</p>
          <button class="text-xs px-4 py-1.5 bg-red-100 text-red-600 rounded-full font-medium active:bg-red-200" @click="refresh">重试</button>
        </div>
      </div>

      <div v-if="loading && !data" class="flex justify-center py-20">
        <div class="animate-spin w-7 h-7 border-2 border-[#FF4757] border-t-transparent rounded-full"/>
      </div>

      <template v-if="data">
        <!-- 核心概览卡片 -->
        <div class="mx-3 mt-3">
          <div class="flex items-center justify-between mb-2.5">
            <span class="text-xs font-semibold text-gray-400 uppercase tracking-wider">核心概览</span>
            <span class="text-[10px] text-gray-400">{{ refreshTime }}</span>
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div v-for="card in overviewCards" :key="card.key" class="bg-white rounded-xl px-3 py-3 shadow-[0_1px_4px_rgba(0,0,0,0.03)] card-item">
              <div class="text-[11px] text-gray-400 mb-1">{{ card.label }}</div>
              <div class="text-xl font-bold" :style="{ color: card.color }">{{ card.value }}</div>
              <div v-if="card.sub" class="text-[10px] text-gray-400 mt-0.5">{{ card.sub }}</div>
            </div>
          </div>
        </div>

        <!-- 详细统计 -->
        <div class="mx-3 mt-4 space-y-3">
          <div v-for="(section, si) in sections" :key="section.tag" class="bg-white rounded-2xl shadow-[0_1px_4px_rgba(0,0,0,0.03)] overflow-hidden card-item" :style="{ animationDelay: si * 40 + 'ms' }">
             <div class="flex items-center gap-2 px-4 py-3 border-b border-gray-50 cursor-pointer select-none active:bg-gray-50" @click="toggleSection(section.tag)">
              <div class="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: section.color + '14' }">
                <svg class="w-3.5 h-3.5" :style="{ color: section.color }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="section.icon"/></svg>
              </div>
              <span class="text-sm font-semibold text-gray-700 flex-1">{{ section.title }}</span>
              <svg class="w-3.5 h-3.5 text-gray-400 flex-shrink-0 transition-transform duration-200" :class="{ 'rotate-90': expandedMap[section.tag] }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>
            <div v-if="expandedMap[section.tag]" class="px-4 py-3 grid grid-cols-2 gap-x-4 gap-y-2.5">
              <div v-for="item in section.items" :key="item.key" class="flex items-center justify-between py-0.5">
                <span class="text-[12px] text-gray-500 truncate mr-1">{{ item.label }}</span>
                <span class="text-[13px] font-semibold flex-shrink-0" :style="{ color: item.color || section.color }">{{ item.value }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="h-4"/>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { fetchConsoleStats } from '@/api/system-manage'

const loading = ref(false)
const data = ref<any>(null)
const error = ref('')
const refreshTime = ref('')
const expandedMap = reactive<Record<string, boolean>>({ 'user-detail': true })

function toggleSection(tag: string) {
  expandedMap[tag] = !expandedMap[tag]
}

function fmt(n: number) {
  if (n >= 100000000) return (n / 100000000).toFixed(1) + '亿'
  if (n >= 10000) return (n / 10000).toFixed(n >= 100000 ? 0 : 1) + '万'
  return n.toLocaleString()
}

function fmtSize(bytes: number) {
  if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + ' GB'
  if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB'
  if (bytes >= 1024) return (bytes / 1024).toFixed(0) + ' KB'
  return bytes + ' B'
}

const overviewCards = computed(() => {
  if (!data.value) return []
  const d = data.value
  return [
    { key: 'user', label: '用户总数', value: fmt(d.user.total), sub: `今日 +${fmt(d.user.todayNew)} / 在线 ${fmt(d.user.online)}`, color: '#FF4757' },
    { key: 'member', label: '会员等级', value: fmt(d.membership.levels), sub: `购买记录 ${fmt(d.membership.purchases)} / 商品 ${fmt(d.membership.products)}`, color: '#6C5CE7' },
    { key: 'app', label: '应用商店', value: fmt(d.appStore.total), sub: `已过审 ${fmt(d.appStore.approved)} / 待审 ${fmt(d.appStore.pending)}`, color: '#00B894' },
    { key: 'mall', label: '商城订单', value: fmt(d.mall.orders), sub: `商品 ${fmt(d.mall.products)} / 今日 ¥${fmt(d.mall.todayAmount)}`, color: '#FDCB6E' },
    { key: 'community', label: '社区内容', value: fmt(d.community.posts), sub: `评论 ${fmt(d.community.comments)} / 话题 ${fmt(d.community.topics)}`, color: '#0984E3' },
    { key: 'chat', label: '聊天统计', value: fmt(d.chat.rooms), sub: `消息 ${fmt(d.chat.messages)} / 成员 ${fmt(d.chat.members)}`, color: '#E17055' },
  ]
})

const sections = computed(() => {
  if (!data.value) return []
  const d = data.value
  return [
    {
      tag: 'user-detail', title: '用户与会员', color: '#FF4757',
      icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
      items: [
        { key: 'user-total', label: '总用户', value: fmt(d.user.total), color: '#FF4757' },
        { key: 'user-today', label: '今日新增', value: fmt(d.user.todayNew), color: '#00B894' },
        { key: 'user-online', label: '当前在线', value: fmt(d.user.online), color: '#0984E3' },
        { key: 'user-deleted', label: '已注销', value: fmt(d.user.deleted), color: '#B2BEC3' },
      ]
    },
    {
      tag: 'card-coupon', title: '卡密与优惠券', color: '#FDCB6E',
      icon: 'M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z',
      items: [
        { key: 'card-total', label: '卡密总数', value: fmt(d.cardKey.total) },
        { key: 'card-avail', label: '可用卡密', value: fmt(d.cardKey.available), color: '#00B894' },
        { key: 'card-used', label: '已用卡密', value: fmt(d.cardKey.used), color: '#B2BEC3' },
        { key: 'coupon-total', label: '优惠券种类', value: fmt(d.coupon.total) },
        { key: 'coupon-issued', label: '已发放', value: fmt(d.coupon.issued) },
        { key: 'coupon-used', label: '已核销', value: fmt(d.coupon.used), color: '#00B894' },
      ]
    },
    {
      tag: 'points-exp', title: '积分与经验', color: '#6C5CE7',
      icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6',
      items: [
        { key: 'points-total', label: '系统总积分', value: fmt(d.points.total), color: '#6C5CE7' },
        { key: 'points-records', label: '积分流水', value: fmt(d.points.records) },
        { key: 'exp-levels', label: '经验等级', value: fmt(d.experience.levels) },
        { key: 'exp-records', label: '经验流水', value: fmt(d.experience.records) },
      ]
    },
    {
      tag: 'plugin-title', title: '插件与称号', color: '#00B894',
      icon: 'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4',
      items: [
        { key: 'plugin-total', label: '插件总数', value: fmt(d.plugin.total) },
        { key: 'plugin-active', label: '已启用', value: fmt(d.plugin.active), color: '#00B894' },
        { key: 'title-custom', label: '自定义称号', value: fmt(d.title.custom) },
        { key: 'title-assigned', label: '已分配', value: fmt(d.title.assigned) },
      ]
    },
    {
      tag: 'commission', title: '推广与返佣', color: '#E17055',
      icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z',
      items: [
        { key: 'comm-records', label: '返佣记录', value: fmt(d.commission.records) },
        { key: 'comm-amount', label: '返佣总额', value: '¥' + fmt(d.commission.amount), color: '#E17055' },
        { key: 'comm-rules', label: '返佣规则', value: fmt(d.commission.rules) },
        { key: 'comm-links', label: '推广链接', value: fmt(d.commission.links) },
      ]
    },
    {
      tag: 'order', title: '订单与购买', color: '#0984E3',
      icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z',
      items: [
        { key: 'order-total', label: '总订单', value: fmt(d.order.total) },
        { key: 'order-today', label: '今日订单额', value: '¥' + fmt(d.order.todayAmount), color: '#00B894' },
        { key: 'content-purch', label: '内容购买', value: fmt(d.contentPurchase.total) },
        { key: 'mem-purchases', label: '会员购买', value: fmt(d.membership.purchases) },
        { key: 'mem-products', label: '会员商品', value: fmt(d.membership.products) },
      ]
    },
    {
      tag: 'system', title: '系统管理', color: '#636E72',
      icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
      items: [
        { key: 'roles', label: '角色数', value: fmt(d.role.total) },
        { key: 'menus-total', label: '菜单总数', value: fmt(d.menu.total) },
        { key: 'menus-enabled', label: '已启用菜单', value: fmt(d.menu.enabled), color: '#00B894' },
        { key: 'sys-config', label: '系统配置项', value: fmt(d.sysConfig.total) },
        { key: 'sessions', label: '在线会话', value: fmt(d.session.active), color: '#0984E3' },
      ]
    },
    {
      tag: 'review', title: '审核管理', color: '#D63031',
      icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
      items: [
        { key: 'verify-pending', label: '蓝V认证待审', value: fmt(d.verification.pending), color: '#D63031' },
        { key: 'verify-total', label: '蓝V认证总计', value: fmt(d.verification.total) },
        { key: 'verify-config', label: '认证配置', value: fmt(d.verification.config) },
        { key: 'del-pending', label: '注销待审', value: fmt(d.deleteRequest.pending), color: '#D63031' },
      ]
    },
    {
      tag: 'invite-email', title: '邀请码与邮件', color: '#0984E3',
      icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z',
      items: [
        { key: 'invite-total', label: '邀请码总数', value: fmt(d.inviteCode.total) },
        { key: 'invite-used', label: '已使用', value: fmt(d.inviteCode.used), color: '#00B894' },
        { key: 'email-config', label: '邮件配置', value: fmt(d.email.config) },
        { key: 'email-templates', label: '邮件模板', value: fmt(d.email.templates) },
        { key: 'email-push', label: '推送配置', value: fmt(d.email.push) },
      ]
    },
    {
      tag: 'file-log', title: '文件与日志', color: '#B2BEC3',
      icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      items: [
        { key: 'file-repo', label: '仓库文件', value: fmt(d.fileRepo.total) },
        { key: 'file-size', label: '文件大小', value: fmtSize(d.fileRepo.size), color: '#636E72' },
        { key: 'file-policy', label: '上传策略', value: fmt(d.filePolicy.total) },
        { key: 'settlement', label: '结算规则', value: fmt(d.settlement.total) },
        { key: 'recycle', label: '回收站', value: fmt(d.recycle.total), color: '#D63031' },
        { key: 'syslog-total', label: '系统日志', value: fmt(d.systemLog.total) },
        { key: 'syslog-today', label: '今日日志', value: fmt(d.systemLog.today), color: '#0984E3' },
      ]
    },
    {
      tag: 'task', title: '任务管理', color: '#00CEC9',
      icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4',
      items: [
        { key: 'task-custom', label: '自定义任务', value: fmt(d.task.custom) },
        { key: 'task-records', label: '任务记录', value: fmt(d.task.records) },
        { key: 'storage', label: '存储配置', value: fmt(d.storage.configs) },
      ]
    },
    {
      tag: 'appstore', title: '应用商店', color: '#00B894',
      icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z',
      items: [
        { key: 'apps-total', label: '应用总数', value: fmt(d.appStore.total), color: '#00B894' },
        { key: 'apps-approved', label: '已过审', value: fmt(d.appStore.approved), color: '#00B894' },
        { key: 'apps-pending', label: '待审核', value: fmt(d.appStore.pending), color: '#FDCB6E' },
        { key: 'app-cats', label: '应用分类', value: fmt(d.appStore.categories) },
        { key: 'app-tags', label: '官方标签', value: fmt(d.appStore.tags) },
        { key: 'app-vers', label: '应用版本', value: fmt(d.appStore.versions) },
        { key: 'app-comments', label: '应用评论', value: fmt(d.appStore.comments) },
        { key: 'app-purchases', label: '应用购买', value: fmt(d.appStore.purchases) },
        { key: 'app-favs', label: '收藏数', value: fmt(d.appStore.favorites) },
      ]
    },
    {
      tag: 'community', title: '社区内容', color: '#6C5CE7',
      icon: 'M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z',
      items: [
        { key: 'comm-posts', label: '帖子', value: fmt(d.community.posts), color: '#6C5CE7' },
        { key: 'comm-comments', label: '评论', value: fmt(d.community.comments) },
        { key: 'comm-topics', label: '话题', value: fmt(d.community.topics) },
        { key: 'comm-sections', label: '版块', value: fmt(d.community.sections) },
        { key: 'comm-reports', label: '举报', value: fmt(d.community.reports), color: '#D63031' },
        { key: 'comm-likes', label: '点赞', value: fmt(d.community.likes) },
      ]
    },
    {
      tag: 'mall', title: '商城', color: '#FDCB6E',
      icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z',
      items: [
        { key: 'mall-products', label: '商品', value: fmt(d.mall.products) },
        { key: 'mall-orders', label: '订单', value: fmt(d.mall.orders), color: '#FDCB6E' },
        { key: 'mall-amt', label: '今日交易额', value: '¥' + fmt(d.mall.todayAmount), color: '#00B894' },
        { key: 'mall-cats', label: '商品分类', value: fmt(d.mall.categories) },
        { key: 'mall-reviews', label: '评价', value: fmt(d.mall.reviews) },
        { key: 'mall-promos', label: '促销活动', value: fmt(d.mall.promotions) },
      ]
    },
    {
      tag: 'chat', title: '聊天', color: '#E17055',
      icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
      items: [
        { key: 'chat-rooms', label: '聊天室', value: fmt(d.chat.rooms) },
        { key: 'chat-msgs', label: '消息', value: fmt(d.chat.messages), color: '#E17055' },
        { key: 'chat-members', label: '成员', value: fmt(d.chat.members) },
        { key: 'chat-gifts', label: '礼物/道具', value: fmt(d.chat.gifts) },
      ]
    },
    {
      tag: 'recharge', title: '充值与提现', color: '#00B894',
      icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
      items: [
        { key: 'recharge-orders', label: '充值订单', value: fmt(d.recharge.orders) },
        { key: 'recharge-total', label: '充值总额', value: '¥' + fmt(d.recharge.totalAmount), color: '#00B894' },
        { key: 'recharge-today', label: '今日充值', value: '¥' + fmt(d.recharge.todayAmount) },
        { key: 'withdraw-total', label: '提现申请', value: fmt(d.withdraw.total) },
        { key: 'withdraw-pending', label: '待处理提现', value: fmt(d.withdraw.pending), color: '#FDCB6E' },
        { key: 'withdraw-done', label: '已完成提现', value: '¥' + fmt(d.withdraw.completedAmount), color: '#00B894' },
      ]
    },
    {
      tag: 'social', title: '社交与签到', color: '#0984E3',
      icon: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z',
      items: [
        { key: 'follows', label: '关注关系', value: fmt(d.social.follows) },
        { key: 'blocks', label: '拉黑', value: fmt(d.social.blocks), color: '#D63031' },
        { key: 'pms', label: '私信', value: fmt(d.social.messages) },
        { key: 'checkins', label: '签到记录', value: fmt(d.checkin.records) },
        { key: 'checkin-today', label: '今日签到', value: fmt(d.checkin.today), color: '#00B894' },
        { key: 'checkin-groups', label: '签到分组', value: fmt(d.checkin.groups) },
      ]
    },
    {
      tag: 'other', title: '其他配置', color: '#636E72',
      icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10',
      items: [
        { key: 'avatars', label: '头像框', value: fmt(d.avatarFrame.total) },
        { key: 'user-avatars', label: '已分配', value: fmt(d.avatarFrame.assigned) },
        { key: 'themes', label: '主题', value: fmt(d.theme.total) },
        { key: 'notifications', label: '系统通知', value: fmt(d.notification.total) },
        { key: 'sensitive', label: '敏感词', value: fmt(d.sensitiveWord.total) },
      ]
    },
  ]
})

async function refresh() {
  loading.value = true
  error.value = ''
  try {
    const res: any = await fetchConsoleStats()
    data.value = res
    refreshTime.value = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  } catch (e: any) {
    error.value = e.message || '网络错误'
  } finally {
    loading.value = false
  }
}

onMounted(() => refresh())
</script>

<style scoped>
.card-item {
  animation: cardFadeIn 0.4s ease-out both;
}

@keyframes cardFadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
