<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">{{ isEdit ? '编辑商品' : '新增商品' }}</span>
      <button class="save-btn" @click="save">保存</button>
    </div>

    <div v-if="pageLoading" class="loading"><span class="spinner" />加载中...</div>

    <div v-else class="form">
      <!-- 基本信息 -->
      <div class="section">
        <div class="section-title">基本信息</div>
        <div class="field">
          <label>商品名称 <span class="req">*</span></label>
          <input v-model="form.name" placeholder="请输入商品名称" class="input" />
        </div>
        <div class="field" v-if="isEdit">
          <label>创建账号</label>
          <input :value="form.createdByName || '-'" disabled class="input" style="background:#f5f5f5;color:#999;cursor:not-allowed" />
        </div>
        <div class="field">
          <label>副标题</label>
          <input v-model="form.subtitle" placeholder="请输入副标题" class="input" />
        </div>
        <div class="field">
          <label>商品类型 <span class="req">*</span></label>
          <select v-model="form.productType" class="input">
            <option value="virtual_auto">自动虚拟商品（卡密/邀请码等自动发货）</option>
            <option value="virtual_manual">手动发货虚拟商品</option>
            <option value="physical">实物商品</option>
          </select>
        </div>
        <div class="field">
          <label>价格类型 <span class="req">*</span></label>
          <div class="checkbox-group">
            <label v-for="pm in paymentMethodOptions" :key="pm.value" class="check-label">
              <input type="checkbox" :value="pm.value" v-model="form.paymentMethods" /> {{ pm.label }}
            </label>
          </div>
          <div v-if="!form.paymentMethods.length" class="field-hint-warn">请至少选择一种支付方式，否则商品将无法被购买</div>
        </div>
        <div class="field-row">
          <div class="field">
            <label>余额售价</label>
            <input v-model.number="form.price" type="number" min="0" step="0.01" class="input" />
          </div>
          <div class="field">
            <label>原价</label>
            <input v-model.number="form.originalPrice" type="number" min="0" step="0.01" class="input" />
          </div>
          <div class="field">
            <label>库存</label>
            <input v-model.number="form.stock" type="number" min="0" class="input" />
          </div>
        </div>
        <div class="field" v-if="form.productType === 'physical'">
          <label>运费（元）</label>
          <input v-model.number="form.freight" type="number" min="0" step="0.01" class="input" placeholder="0表示免运费" />
        </div>
        <div class="field">
          <label>分类</label>
          <select v-model="form.categoryId" class="input">
            <option :value="0">未分类</option>
            <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
          </select>
        </div>
        <div class="field">
          <label>销售截止时间 <span class="hint-text">（设置后到期自动下架，留空则不限时）</span></label>
          <input type="datetime-local" v-model="form.saleEndTime" class="input" />
        </div>
      </div>

      <!-- 封面图 -->
      <div class="section">
        <div class="section-title">封面图</div>
        <div class="field">
          <div class="field-row">
            <input v-model="coverImageInput" placeholder="输入封面图URL" class="input" @blur="setCoverImage" />
            <label class="upload-btn">
              <input type="file" accept="image/*" style="display:none" @change="(e) => handleCoverUpload(e)" />
              上传
            </label>
          </div>
          <div v-if="coverUploading" class="upload-progress">上传中...</div>
          <div v-if="form.coverImage" class="cover-preview">
            <img :src="fixImgUrl(form.coverImage)" />
            <button @click="form.coverImage = ''" class="remove-img">&times;</button>
          </div>
        </div>
      </div>

      <!-- 商品图片 -->
      <div class="section">
        <div class="section-title">商品图片</div>
        <div v-if="(form.images || []).length" class="img-list">
          <div v-for="(img, i) in form.images" :key="i" class="img-item">
            <img :src="fixImgUrl(img.url || img)" />
            <button @click="form.images.splice(i, 1)" class="remove-img">&times;</button>
          </div>
        </div>
        <div class="field-row">
          <input v-model="newImageUrl" placeholder="输入图片URL" class="input" />
          <button @click="addImage" class="btn-sm">添加</button>
          <label class="upload-btn btn-sm">
            <input type="file" accept="image/*" style="display:none" @change="(e) => handleImageUpload(e)" />
            上传图片
          </label>
        </div>
        <div v-if="imgUploading" class="upload-progress">上传中...</div>
      </div>

      <!-- 商品规格与套餐管理 -->
      <div class="section">
        <div class="section-title">
          商品规格与套餐
          <span class="section-tip">一个规格下可以有多个套餐，选择不同规格显示对应的套餐</span>
        </div>

        <!-- 规格列表 -->
        <div v-if="(form.specs || []).length" class="spec-list">
          <div v-for="(spec, si) in form.specs" :key="si" class="spec-card">
            <div class="spec-header">
              <div class="spec-label">规格 {{ si + 1 }}</div>
              <div class="spec-header-right">
                <button @click="addPackage(si)" class="btn-spec-action">+ 套餐</button>
                <button @click="form.specs.splice(si, 1)" class="btn-sm del">删规格</button>
              </div>
            </div>
            <div class="field">
              <label>规格名称 <span class="req">*</span></label>
              <input v-model="spec.name" placeholder="如：点券类型" class="input" />
            </div>

            <!-- 该规格下的套餐 -->
            <div v-if="(spec.packages || []).length" class="pkg-list">
              <div v-for="(pkg, pi) in spec.packages" :key="pi" class="pkg-card">
                <div class="pkg-header">
                  <span class="pkg-index">套餐 {{ pi + 1 }}</span>
                  <span v-if="pkg.cardConfig?.enabled" class="pkg-badge auto">自动发货</span>
                  <button @click="spec.packages.splice(pi, 1)" class="btn-sm del">删除</button>
                </div>
                <div class="field">
                  <label>套餐名称 <span class="req">*</span></label>
                  <input v-model="pkg.name" placeholder="如：10000点券" class="input" />
                </div>
                <div class="package-price-row">
                  <div class="field" style="flex:1">
                    <label>余额售价（元）</label>
                    <input v-model.number="pkg.price" type="number" min="0" step="0.01" placeholder="0.00" class="input" />
                  </div>
                  <div class="field" style="flex:1">
                    <label>积分售价</label>
                    <input v-model.number="pkg.pointsPrice" type="number" min="0" placeholder="0" class="input" />
                  </div>
                </div>
                <div class="field">
                  <label>库存</label>
                  <input v-model.number="pkg.stock" type="number" min="0" placeholder="0表示不限库存" class="input" />
                </div>

                <!-- 自动发货配置 -->
                <div v-if="form.productType === 'virtual_auto'" class="package-delivery">
                  <div
                    class="delivery-toggle"
                    :class="{ active: expandedCardConfigKey === `${si}-${pi}`, configured: pkg.cardConfig?.enabled }"
                    @click="toggleCardConfig(`${si}-${pi}`)"
                  >
                    <div class="delivery-toggle-left">
                      <svg class="delivery-icon" viewBox="0 0 24 24" fill="none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg>
                      <span>自动发货</span>
                      <span v-if="pkg.cardConfig?.enabled" class="delivery-status configured">已启用</span>
                      <span v-else class="delivery-status">未启用</span>
                    </div>
                    <span class="toggle-arrow" :class="{ expanded: expandedCardConfigKey === `${si}-${pi}` }">&#9660;</span>
                  </div>
                  <div v-if="expandedCardConfigKey === `${si}-${pi}`" class="delivery-body">
                    <div class="field" style="margin-top:0">
                      <label class="check-label">
                        <input type="checkbox" v-model="pkg.cardConfig.enabled" /> 启用自动发货
                      </label>
                    </div>
                    <template v-if="pkg.cardConfig.enabled">
                      <div class="field">
                        <label>发货类型 <span class="req">*</span></label>
                        <select v-model="pkg.cardConfig.type" class="input">
                          <option value="card_key">卡密</option>
                          <option value="auto_recharge">自动充值</option>
                          <option value="invite_code">邀请码</option>
                          <option value="custom">自定义卡池</option>
                        </select>
                      </div>
                      <template v-if="pkg.cardConfig.type === 'card_key'">
                        <div class="field">
                          <label>卡密子类型 <span class="req">*</span></label>
                          <select v-model="pkg.cardConfig.cardType" class="input">
                            <option value="membership">会员</option>
                            <option value="points">积分</option>
                            <option value="balance">余额</option>
                            <option value="experience">经验</option>
                            <option value="free">通用卡</option>
                          </select>
                        </div>
                        <template v-if="pkg.cardConfig.cardType === 'membership'">
                          <div class="field">
                            <label>会员等级</label>
                            <select v-model="pkg.cardConfig.targetId" class="input">
                              <option :value="0">请选择会员等级</option>
                              <option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option>
                            </select>
                          </div>
                        </template>
                        <div class="field-row">
                          <div class="field">
                            <label>{{ pkg.cardConfig.cardType === 'membership' ? '有效天数' : '发放数量' }}</label>
                            <input v-model.number="pkg.cardConfig.value" type="number" min="0" class="input" />
                          </div>
                          <div class="field" v-if="pkg.cardConfig.cardType === 'membership'">
                            <label>时间单位</label>
                            <select v-model="pkg.cardConfig.durationUnit" class="input">
                              <option value="day">天</option>
                              <option value="month">月</option>
                              <option value="year">年</option>
                            </select>
                          </div>
                        </div>
                        <div class="field-row" v-if="pkg.cardConfig.cardType === 'membership'">
                          <div class="field"><label>额外积分</label><input v-model.number="pkg.cardConfig.extraPoints" type="number" min="0" class="input" /></div>
                          <div class="field"><label>额外余额</label><input v-model.number="pkg.cardConfig.extraBalance" type="number" min="0" step="0.01" class="input" /></div>
                          <div class="field"><label>额外经验</label><input v-model.number="pkg.cardConfig.extraExperience" type="number" min="0" class="input" /></div>
                        </div>
                      </template>
                      <template v-if="pkg.cardConfig.type === 'auto_recharge'">
                        <div class="field"><label>充值类型 <span class="req">*</span></label>
                          <select v-model="pkg.cardConfig.cardType" class="input">
                            <option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option>
                          </select>
                        </div>
                        <template v-if="pkg.cardConfig.cardType === 'membership'">
                          <div class="field"><label>会员等级</label><select v-model="pkg.cardConfig.targetId" class="input"><option :value="0">请选择会员等级</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div>
                        </template>
                        <div class="field-row">
                          <div class="field"><label>{{ pkg.cardConfig.cardType === 'membership' ? '有效天数' : '充值数量' }}</label><input v-model.number="pkg.cardConfig.value" type="number" min="0" class="input" /></div>
                          <div class="field" v-if="pkg.cardConfig.cardType === 'membership'"><label>时间单位</label><select v-model="pkg.cardConfig.durationUnit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div>
                        </div>
                      </template>
                      <template v-if="pkg.cardConfig.type === 'invite_code'">
                        <div class="field"><label>奖励类型</label><select v-model="pkg.cardConfig.rewardType" class="input"><option value="membership">会员</option><option value="points">积分</option><option value="balance">余额</option><option value="experience">经验</option></select></div>
                        <template v-if="pkg.cardConfig.rewardType === 'membership'"><div class="field"><label>目标会员等级</label><select v-model="pkg.cardConfig.targetId" class="input"><option :value="0">请选择会员等级</option><option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }} (Lv.{{ lv.level }})</option></select></div></template>
                        <div class="field-row">
                          <div class="field"><label>{{ pkg.cardConfig.rewardType === 'membership' ? '奖励时长' : '奖励数量' }}</label><input v-model.number="pkg.cardConfig.rewardValue" type="number" min="0" class="input" /></div>
                          <div class="field" v-if="pkg.cardConfig.rewardType === 'membership'"><label>时间单位</label><select v-model="pkg.cardConfig.rewardDurationUnit" class="input"><option value="day">天</option><option value="month">月</option><option value="year">年</option></select></div>
                        </div>
                        <div class="field-row">
                          <div class="field"><label>生成数量</label><input v-model.number="pkg.cardConfig.inviteCodeCount" type="number" min="1" class="input" placeholder="每次发放数量" /></div>
                          <div class="field"><label>最大使用次数</label><input v-model.number="pkg.cardConfig.maxUses" type="number" min="1" class="input" placeholder="每个邀请码可用次数" /></div>
                        </div>
                      </template>
                      <template v-if="pkg.cardConfig.type === 'custom'">
                        <div class="field">
                          <label>卡号密码（一行一个，格式：卡号:密码）</label>
                          <textarea v-model="pkg.cardConfig.customCardsText" class="input textarea" placeholder="AA001:pass123&#10;AA002:pass456" rows="5" @blur="syncCustomCards(si, pi)" />
                          <div class="hint">共 {{ getCustomCardCount(si, pi) }} 张卡，库存自动同步</div>
                        </div>
                      </template>
                    </template>
                  </div>
                </div>
              </div>
            </div>

            <!-- 该规格下暂无套餐 -->
            <div v-if="!(spec.packages || []).length" class="pkg-empty">
              暂无套餐，请点击"+ 套餐"添加
            </div>
          </div>
        </div>

        <button @click="addSpec" class="btn-add-package">+ 添加规格</button>
      </div>

      <!-- 商品参数 -->
      <div class="section">
        <div class="section-title">商品参数</div>
        <div v-if="(form.productParams || []).length" class="param-list">
          <div v-for="(p, i) in form.productParams" :key="i" class="field-row" style="margin-bottom:6px">
            <input v-model="p.name" placeholder="参数名" class="input" style="flex:1" />
            <input v-model="p.value" placeholder="参数值" class="input" style="flex:2" />
            <button @click="form.productParams.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
        <button @click="form.productParams = form.productParams || []; form.productParams.push({ name: '', value: '' })" class="btn-sm">+ 添加参数</button>
      </div>

      <!-- 服务保障 -->
      <div class="section">
        <div class="section-title">服务保障</div>
        <div class="checkbox-group">
          <label v-for="svc in defaultServices" :key="svc" class="check-label">
            <input type="checkbox" :value="svc" v-model="form.services" /> {{ svc }}
          </label>
        </div>
        <div class="field-row" style="margin-top:6px">
          <input v-model="newService" placeholder="自定义服务" class="input" />
          <button @click="addService" class="btn-sm">添加</button>
        </div>
      </div>

      <!-- 标签 -->
      <div class="section">
        <div class="section-title">商品标签</div>
        <div v-if="(form.tags || []).length" class="tag-list">
          <span v-for="(t, i) in form.tags" :key="i" class="tag">
            {{ t }} <button @click="form.tags.splice(i, 1)" class="tag-close">&times;</button>
          </span>
        </div>
        <div class="field-row">
          <input v-model="newTag" placeholder="输入标签" class="input" @keydown.enter="addTag" />
          <button @click="addTag" class="btn-sm">添加</button>
        </div>
      </div>

      <!-- 限购配置 -->
      <div class="section">
        <div class="section-title">限购配置</div>
        <div class="field">
          <label>不限购</label>
          <label class="check-label" style="margin-left: 10px;">
            <input type="checkbox" v-model="noLimit" /> 不限购
          </label>
        </div>
        <div v-if="!noLimit" class="field-row">
          <input v-model.number="globalLimit" type="number" min="1" placeholder="每用户限购数量" class="input" />
          <button @click="addLimit" class="btn-sm">添加</button>
        </div>
        <div v-if="form.purchaseLimitConfig.length" class="opt-list">
          <div v-for="(lc, i) in form.purchaseLimitConfig" :key="i" class="limit-row">
            <span v-if="lc.type === 'global'">全局: {{ lc.limit }}件</span>
            <span v-else-if="lc.type === 'membership'">会员等级{{ lc.levelId }}: {{ lc.limit }}件</span>
            <span v-else-if="lc.type === 'verified'">认证用户: {{ lc.limit }}件</span>
            <button @click="form.purchaseLimitConfig.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 推广返佣 -->
      <div class="section">
        <div class="section-title">推广返佣</div>
        <div class="field-row">
          <select v-model="commissionType" class="input" style="flex:1">
            <option value="">不启用</option>
            <option value="percent">按比例</option>
            <option value="fixed">固定金额</option>
          </select>
          <input v-if="commissionType" v-model.number="commissionValue" type="number" min="0" step="0.01" :placeholder="commissionType === 'percent' ? '百分比%' : '固定金额'" class="input" style="flex:1" />
          <button v-if="commissionType" @click="addCommission" class="btn-sm">添加</button>
        </div>
        <div v-if="form.commissionConfig.length" class="opt-list">
          <div v-for="(cm, i) in form.commissionConfig" :key="i" class="limit-row">
            {{ cm.type === 'percent' ? cm.value + '%' : '¥' + cm.value }}
            <button @click="form.commissionConfig.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 自定义用户必留信息 -->
      <div class="section">
        <div class="section-title">用户必留信息</div>
        <div class="field-row" style="margin-bottom:6px">
          <input v-model="newFieldName" placeholder="字段名（如：手机号）" class="input" style="flex:1" />
          <button @click="addCustomField" class="btn-sm">添加</button>
        </div>
        <div v-if="form.customFields.length" class="opt-list">
          <div v-for="(f, i) in form.customFields" :key="i" class="limit-row">
            <label class="check-label">
              <input type="checkbox" v-model="f.required" /> {{ f.name }}{{ f.required ? '（必填）' : '' }}
            </label>
            <button @click="form.customFields.splice(i, 1)" class="btn-sm del">删</button>
          </div>
        </div>
      </div>

      <!-- 售后服务 -->
      <div class="section">
        <div class="section-title">售后服务</div>
        <div class="checkbox-group">
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enableRefund" /> 支持退款
          </label>
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enableReturn" /> 支持退货
          </label>
          <label class="check-label">
            <input type="checkbox" v-model="form.afterSalesConfig.enablePrice" /> 支持保价
          </label>
        </div>
        <div v-if="form.afterSalesConfig.enableRefund || form.afterSalesConfig.enableReturn" class="field" style="margin-top:8px">
          <label>售后有效期（天）</label>
          <input v-model.number="form.afterSalesConfig.validDays" type="number" min="1" class="input" placeholder="7" />
        </div>
      </div>

      <!-- 商品描述 -->
      <div class="section">
        <div class="section-title">商品描述</div>
        <textarea v-model="form.description" class="input textarea" placeholder="请输入商品描述（支持HTML）" rows="6" />
      </div>

      <!-- 状态 -->
      <div class="section">
        <div class="section-title">发布状态</div>
        <div class="field">
          <select v-model="form.status" class="input">
            <option value="draft">草稿</option>
            <option value="published">上架</option>
            <option value="offline">下架</option>
          </select>
        </div>
      </div>

      <div style="height: 60px" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const isEdit = ref(false)
const pageLoading = ref(false)

const categories = ref<any[]>([])
const membershipLevels = ref<any[]>([])
const newImageUrl = ref('')
const newTag = ref('')
const newService = ref('')
const newFieldName = ref('')
const coverImageInput = ref('')
const noLimit = ref(false)
const globalLimit = ref(1)
const commissionType = ref('')
const commissionValue = ref(0)
const expandedCardConfigKey = ref<string | null>(null)
const coverUploading = ref(false)
const imgUploading = ref(false)

const defaultServices = ['7天无理由退货', '正品保证', '极速发货', '售后无忧', '免费包邮']

const paymentMethodOptions = [
  { label: '余额支付', value: 'balance' },
  { label: '积分支付', value: 'points' },
  { label: '支付宝', value: 'alipay' },
  { label: '微信支付', value: 'wechat' },
  { label: '易支付', value: 'epay' }
]

function defaultCardConfig() {
  return {
    enabled: false,
    type: 'card_key',
    cardType: 'membership',
    targetId: 0,
    targetName: '',
    value: 30,
    durationUnit: 'day',
    extraPoints: 0,
    extraBalance: 0,
    extraExperience: 0,
    rewardType: 'membership',
    rewardValue: 30,
    rewardDurationUnit: 'day',
    inviteCodeCount: 1,
    maxUses: 1,
    customCards: [],
    customCardsText: ''
  }
}

const form = reactive<any>({
  name: '', subtitle: '', description: '', coverImage: '', coverVideo: '',
  priceType: 'balance', price: 0, originalPrice: 0, stock: 0,
  productType: 'virtual_auto', categoryId: 0,
  status: 'draft', freight: 0, isRecommended: false, sortOrder: 0,
  specs: [], images: [], services: [],
  purchaseLimitConfig: [], commissionConfig: [], customFields: [],
  afterSalesConfig: { enableRefund: false, enableReturn: false, enablePrice: false, validDays: 7 },
  tags: [], productParams: [], paymentMethods: ['balance'],
  saleEndTime: '',
  createdByName: ''
})

function toggleCardConfig(key: string) {
  expandedCardConfigKey.value = expandedCardConfigKey.value === key ? null : key
}

function syncCustomCards(si: number, pi: number) {
  const pkg = form.specs[si]?.packages?.[pi]
  if (!pkg || !pkg.cardConfig) return
  const text = (pkg.cardConfig.customCardsText || '').trim()
  const lines = text.split('\n').filter((l: string) => l.trim().includes(':'))
  pkg.cardConfig.customCards = lines.map((l: string) => l.trim())
  pkg.stock = pkg.cardConfig.customCards.length
}

function getCustomCardCount(si: number, pi: number) {
  const pkg = form.specs[si]?.packages?.[pi]
  if (!pkg || !pkg.cardConfig) return 0
  return (pkg.cardConfig.customCards || []).length
}

function addSpec() {
  form.specs = form.specs || []
  form.specs.push({ name: '', packages: [] })
}

function addPackage(si: number) {
  const spec = form.specs[si]
  spec.packages = spec.packages || []
  const cardConfig = defaultCardConfig()
  spec.packages.push({
    name: '', price: 0, pointsPrice: 0, stock: 0,
    image: '', cardConfig
  })
  const pi = spec.packages.length - 1
  expandedCardConfigKey.value = `${si}-${pi}`
}

async function uploadFile(file: File): Promise<string> {
  const fd = new FormData()
  fd.append('file', file)
  const headers: Record<string, string> = {}
  const token = userStore.accessToken
  if (token) headers['Authorization'] = token
  const res = await fetch('/api/upload/background', { method: 'POST', body: fd, headers })
  const json = await res.json()
  if (json.code !== 200) throw new Error(json.msg || 'Upload failed')
  return json.data.url
}

async function handleCoverUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  coverUploading.value = true
  try {
    const url = await uploadFile(file)
    form.coverImage = url
    coverImageInput.value = url
  } catch (err: any) { alert('上传失败: ' + (err.message || '未知错误')) }
  finally { coverUploading.value = false }
}

async function handleImageUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  imgUploading.value = true
  try {
    const url = await uploadFile(file)
    form.images = form.images || []
    form.images.push({ url, sortOrder: form.images.length })
  } catch (err: any) { alert('上传失败: ' + (err.message || '未知错误')) }
  finally { imgUploading.value = false }
}

function setCoverImage() {
  form.coverImage = fixImgUrl(coverImageInput.value.trim())
}
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
function addImage() {
  const url = newImageUrl.value.trim()
  if (url) { form.images = form.images || []; form.images.push({ url, sortOrder: form.images.length }); newImageUrl.value = '' }
}
function addTag() {
  const t = newTag.value.trim()
  if (t) { form.tags = form.tags || []; form.tags.push(t); newTag.value = '' }
}
function addService() {
  const s = newService.value.trim()
  if (s) { form.services = form.services || []; form.services.push(s); newService.value = '' }
}
function addCustomField() {
  const n = newFieldName.value.trim()
  if (n) { form.customFields = form.customFields || []; form.customFields.push({ name: n, required: true }); newFieldName.value = '' }
}
function addLimit() {
  form.purchaseLimitConfig = form.purchaseLimitConfig || []
  form.purchaseLimitConfig.push({ type: 'global', limit: globalLimit.value })
}
function addCommission() {
  form.commissionConfig = form.commissionConfig || []
  form.commissionConfig.push({ type: commissionType.value, value: commissionValue.value })
  commissionType.value = ''; commissionValue.value = 0
}

async function loadProduct(id: number) {
  pageLoading.value = true
  try {
    const res: any = await request.get({ url: `/api/mall/products/${id}` })
    const d = res
    if (d) {
      form.name = d.name || ''
      form.subtitle = d.subtitle || ''
      form.description = d.description || ''
      form.coverImage = d.coverImage || ''
      form.coverVideo = d.coverVideo || ''
      form.priceType = d.priceType || 'balance'
      form.price = d.price || 0
      form.originalPrice = d.originalPrice || 0
      form.stock = d.stock || 0
      form.productType = d.productType || 'virtual_auto'
      form.categoryId = d.categoryId || 0
      form.status = d.status || 'draft'
      form.freight = d.freight || 0
      form.isRecommended = d.isRecommended || false
      form.sortOrder = d.sortOrder || 0

      // 将 options 按 specName 还原为 specs 结构
      const rawOptions = (d.options || []).map((o: any) => {
        const cfg = o.cardConfig ? { ...defaultCardConfig(), ...o.cardConfig } : defaultCardConfig()
        if (cfg.customCards && cfg.customCards.length) {
          cfg.customCardsText = cfg.customCards.join('\n')
        }
        return { ...o, pointsPrice: o.pointsPrice || 0, cardConfig: cfg }
      })

      // 按 specName 分组
      const specMap = new Map<string, any[]>()
      rawOptions.forEach((o: any) => {
        const key = o.specName || ''
        if (!specMap.has(key)) specMap.set(key, [])
        specMap.get(key)!.push(o)
      })

      form.specs = Array.from(specMap.entries()).map(([name, pkgs]) => ({
        name: name || '默认规格',
        packages: pkgs
      }))

      form.images = d.images || []
      form.services = d.services || []
      form.tags = d.tags || []
      form.productParams = d.productParams || []
      form.purchaseLimitConfig = d.purchaseLimitConfig || []
      form.commissionConfig = d.commissionConfig || []
      form.customFields = d.customFields || []
      form.paymentMethods = d.paymentMethods || ['balance']
      form.saleEndTime = d.saleEndTime ? d.saleEndTime.replace(' ', 'T').slice(0, 16) : ''
      form.createdByName = d.createdByName || ''
      Object.assign(form.afterSalesConfig, d.afterSalesConfig || { enableRefund: false, enableReturn: false, enablePrice: false, validDays: 7 })
      form.id = d.id
      coverImageInput.value = form.coverImage || ''
    }
  } catch (e: any) { console.error('加载商品失败:', e) } finally { pageLoading.value = false }
}

async function save() {
  if (!form.name) { ElMessage.warning('请输入商品名称'); return }
  if (!(form.paymentMethods || []).length) { ElMessage.warning('请至少选择一种支付方式'); return }
  try {
    const payload: any = JSON.parse(JSON.stringify(form))
    if (!isEdit.value) delete payload.id

    // 将 specs 结构扁平化为 options
    payload.options = []
    if (payload.specs && payload.specs.length) {
      payload.specs.forEach((spec: any) => {
        if (spec.packages && spec.packages.length) {
          spec.packages.forEach((pkg: any, pi: number) => {
            if (!pkg.name) { ElMessage.warning(`规格「${spec.name || '未命名'}」下存在未命名的套餐`); throw new Error('套餐名称不能为空') }
            if (pkg.cardConfig && pkg.cardConfig.customCardsText !== undefined) {
              delete pkg.cardConfig.customCardsText
            }
            payload.options.push({
              ...pkg,
              specName: spec.name || '',
              sortOrder: pi,
              originalPrice: pkg.originalPrice || 0
            })
          })
        }
      })
    }
    delete payload.specs

    const url = isEdit.value ? `/api/mall/products/${payload.id}` : '/api/mall/products'
    const method = isEdit.value ? request.put : request.post
    await method({ url, data: payload })
    ElMessage.success(isEdit.value ? '更新成功' : '创建成功')
    router.back()
  } catch (e: any) {
    if (e.message === '套餐名称不能为空') return
    ElMessage.error('保存失败: ' + (e.message || '未知错误'))
  }
}

async function loadCategories() {
  try {
    const res: any = await request.get({ url: '/api/mall/categories/all' })
    categories.value = res || []
  } catch {}
}

async function loadMembershipLevels() {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = res || []
  } catch {}
}

onMounted(async () => {
  await loadCategories()
  await loadMembershipLevels()
  const id = route.query.id
  if (id) { isEdit.value = true; await loadProduct(Number(id)) }
})
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; position: sticky; top: 0; z-index: 10; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.save-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 16px; border-radius: 8px; font-size: 13px; cursor: pointer; }

.loading { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }

.form { padding: 0 0 20px; }
.section { background: #fff; margin: 10px 10px 0; border-radius: 12px; padding: 14px; }
.section-title { font-size: 14px; font-weight: 700; color: #333; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; gap: 8px; }
.section-tip { font-size: 11px; color: #999; font-weight: 400; }
.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.req { color: #FF4757; }
.hint-text { font-size: 10px; color: #aaa; font-weight: 400; }
.field-hint-warn { font-size: 11px; color: #FF6B6B; margin-top: 4px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; background: #fff; }
.textarea { resize: vertical; min-height: 60px; }
.field-row { display: flex; gap: 8px; align-items: center; }
.field-row .field { flex: 1; margin-bottom: 0; }
.btn-sm { border: 1px solid #ddd; background: #fff; padding: 6px 14px; border-radius: 8px; font-size: 12px; cursor: pointer; color: #666; flex-shrink: 0; }
.btn-sm.del { color: #FF4757; border-color: #FF4757; }

.cover-preview { position: relative; width: 100px; height: 100px; margin-top: 8px; border-radius: 8px; overflow: hidden; }
.cover-preview img { width: 100%; height: 100%; object-fit: cover; }
.remove-img { position: absolute; top: 2px; right: 2px; width: 20px; height: 20px; border-radius: 50%; border: none; background: rgba(0,0,0,.6); color: #fff; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; }

.img-list { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
.img-item { position: relative; width: 72px; height: 72px; border-radius: 8px; overflow: hidden; }
.img-item img { width: 100%; height: 100%; object-fit: cover; }

/* ====== 规格与套餐管理 ====== */
.spec-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 12px; }
.spec-card {
  background: #fff; border-radius: 12px; padding: 14px;
  border: 1.5px solid #FF6B6B33; border-left: 4px solid #FF6B6B;
}
.spec-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 10px;
}
.spec-label {
  font-size: 14px; font-weight: 800; color: #FF6B6B;
}
.spec-header-right { display: flex; gap: 6px; align-items: center; }
.btn-spec-action {
  font-size: 11px; padding: 4px 10px; border-radius: 6px;
  border: 1px solid #FF6B6B; background: #FFF5F5;
  color: #FF6B6B; cursor: pointer; font-weight: 600;
}

.pkg-list { display: flex; flex-direction: column; gap: 8px; margin-top: 10px; padding-top: 10px; border-top: 1px dashed #FFE0E0; }
.pkg-card {
  background: #f9fafb; border-radius: 10px; padding: 10px;
  border: 1px solid #eee;
}
.pkg-header {
  display: flex; align-items: center; gap: 8px; margin-bottom: 8px;
}
.pkg-index { font-size: 12px; font-weight: 700; color: #666; margin-right: auto; }
.pkg-badge { font-size: 10px; padding: 2px 6px; border-radius: 4px; }
.pkg-badge.auto { background: #E8F5E9; color: #4CAF50; }
.pkg-empty {
  text-align: center; padding: 16px 0; font-size: 13px;
  color: #ccc; background: #fafafa; border-radius: 8px;
  margin-top: 10px;
}

.package-delivery { margin-top: 8px; padding-top: 8px; border-top: 1px dashed #e0e0e0; }
.package-price-row { display: flex; gap: 8px; }
.delivery-toggle {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 12px; border-radius: 8px; cursor: pointer;
  background: #fff; border: 1px solid #e8e8e8;
  transition: all .2s; user-select: none;
}
.delivery-toggle:hover { border-color: #FF6B6B; }
.delivery-toggle.active { border-color: #FF6B6B; }
.delivery-toggle-left { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555; }
.delivery-icon { width: 18px; height: 18px; color: #999; }
.delivery-toggle.active .delivery-icon { color: #FF6B6B; }
.delivery-status {
  font-size: 11px; padding: 2px 8px; border-radius: 10px;
  background: #f0f0f0; color: #999;
}
.delivery-status.configured {
  background: #E8F5E9; color: #4CAF50;
}
.toggle-arrow { font-size: 11px; color: #999; transition: transform .2s; }
.toggle-arrow.expanded { transform: rotate(180deg); color: #FF6B6B; }
.delivery-body {
  margin-top: 8px; padding: 12px; background: #fff;
  border-radius: 8px; border: 1px solid #FFE0E0;
}

.btn-add-package {
  width: 100%; border: 2px dashed #ddd; background: #fff;
  padding: 12px; border-radius: 10px; font-size: 14px;
  cursor: pointer; color: #FF6B6B; font-weight: 600;
  transition: all .2s;
}
.btn-add-package:hover { border-color: #FF6B6B; background: #FFF5F5; }
.hint { font-size: 11px; color: #999; margin-top: 4px; }
.upload-btn { display: inline-block; padding: 6px 14px; border: 1px solid #ddd; border-radius: 8px; font-size: 12px; cursor: pointer; color: #666; background: #fff; white-space: nowrap; }
.upload-progress { font-size: 11px; color: #999; padding: 4px 0; }
.param-list { margin-bottom: 8px; }
.limit-row { display: flex; align-items: center; justify-content: space-between; padding: 6px 8px; background: #f9fafb; border-radius: 6px; margin-bottom: 4px; font-size: 12px; color: #666; }

.checkbox-group { display: flex; flex-wrap: wrap; gap: 12px; }
.check-label { display: flex; align-items: center; gap: 4px; font-size: 12px; color: #555; cursor: pointer; }

.tag-list { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.tag { padding: 4px 10px; background: #EEF2FF; color: #6366F1; border-radius: 20px; font-size: 11px; display: flex; align-items: center; gap: 4px; }
.tag-close { border: none; background: none; color: #6366F1; cursor: pointer; font-size: 14px; padding: 0; line-height: 1; }
</style>
