<script lang="ts">
export default { name: 'GameCenterManage' }
</script>

<template>
  <div class="gcm-page">
    <div class="gcm-header">
      <div class="gcm-back" @click="$router.back()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <h1 class="gcm-title">游戏中心管理</h1>
    </div>

    <div class="gcm-body">
      <div v-if="loading" class="gcm-loading">加载中...</div>
      <div v-else>
        <div class="gcm-card" v-for="game in games" :key="game.gameType">
          <div class="gcm-card-top">
            <div class="gcm-card-icon">
              <span class="gcm-card-emoji">{{ game.icon }}</span>
            </div>
            <div class="gcm-card-info">
              <div class="gcm-card-name">{{ game.name }}</div>
              <div class="gcm-card-desc">{{ game.desc }}</div>
              <div class="gcm-card-stats">
                今日 {{ game.todayCount }} 人次 | 消耗 {{ game.todaySpent }} 积分
              </div>
            </div>
            <div class="gcm-card-toggle">
              <label class="gcm-switch">
                <input type="checkbox" :checked="game.enabled" :disabled="game.switching" @change="toggleGame(game)" />
                <span class="gcm-slider" />
              </label>
            </div>
          </div>

          <div class="gcm-card-expand" v-if="game.expanded">
            <!-- 基础设置 -->
            <div class="gcm-form-group">
              <div class="gcm-form-label">每次消耗积分</div>
              <input v-model.number="game.cfg.cost" type="number" class="gcm-input" />
            </div>

            <!-- 金币抽奖 -->
            <template v-if="game.gameType === 'lottery'">
              <div class="gcm-form-group">
                <div class="gcm-form-label">10连抽优惠积分</div>
                <input v-model.number="game.cfg.cost10" type="number" class="gcm-input" />
              </div>
              <div class="gcm-form-row">
                <div class="gcm-form-group" style="flex:1">
                  <div class="gcm-form-label">保底次数</div>
                  <input v-model.number="game.cfg.pityCount" type="number" class="gcm-input" />
                </div>
                <div class="gcm-form-group" style="flex:1">
                  <div class="gcm-form-label">保底目标格子</div>
                  <input v-model.number="game.cfg.pityGridIndex" type="number" class="gcm-input" min="0" max="8" />
                </div>
              </div>
              <div class="gcm-form-label">9宫格奖励</div>
              <div class="gcm-grids">
                <div v-for="(g, i) in game.cfg.grids" :key="i" class="gcm-grid-item">
                  <div class="gcm-grid-idx">{{ i + 1 }}</div>
                  <input v-model="g.name" class="gcm-input-sm" placeholder="名称" />
                  <select v-model="g.type" class="gcm-select-sm">
                    <option value="points">积分</option>
                    <option value="balance">余额</option>
                    <option value="coupon">优惠券</option>
                    <option value="membership">会员</option>
                    <option value="cardkey">卡密</option>
                    <option value="thanks">谢谢参与</option>
                  </select>
                  <input v-if="g.type === 'points' || g.type === 'balance' || g.type === 'cardkey'" v-model.number="g.value" type="number" class="gcm-input-sm" placeholder="值" />
                  <select v-if="g.type === 'coupon'" v-model.number="g.couponId" class="gcm-select-sm">
                    <option value="">选择优惠券</option>
                    <option v-for="c in couponList" :key="c.id" :value="c.id">{{ c.name }}</option>
                  </select>
                  <template v-if="g.type === 'membership'">
                    <select v-model.number="g.targetLevelId" class="gcm-select-sm">
                      <option value="">目标等级</option>
                      <option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
                    </select>
                    <input v-model.number="g.value" type="number" class="gcm-input-sm" placeholder="天数" />
                  </template>
                  <input v-model.number="g.probability" type="number" class="gcm-input-sm" placeholder="概率%" />
                </div>
              </div>
            </template>

            <!-- 卡片竞猜 -->
            <template v-if="game.gameType === 'card_guess'">
              <div class="gcm-form-group">
                <div class="gcm-form-label">获胜倍数</div>
                <input v-model.number="game.cfg.winMultiplier" type="number" step="0.5" class="gcm-input" />
              </div>
              <div class="gcm-form-group">
                <div class="gcm-form-label">保底次数</div>
                <input v-model.number="game.cfg.pityCount" type="number" class="gcm-input" />
              </div>
              <div class="gcm-form-label">3张卡片</div>
              <div v-for="(c, i) in game.cfg.cards" :key="i" class="gcm-card-row">
                <span class="gcm-card-row-label">卡片{{ i + 1 }}</span>
                <input v-model="c.name" class="gcm-input-sm" placeholder="名称" />
                <input v-model="c.label" class="gcm-input-sm" placeholder="显示" />
                <label class="gcm-check-label"><input type="checkbox" v-model="c.isWin" />中奖</label>
                <input v-model.number="c.probability" type="number" class="gcm-input-sm" placeholder="概率" />
              </div>
            </template>

            <!-- 大小竞猜 -->
            <template v-if="game.gameType === 'dice'">
              <div class="gcm-form-row">
                <div class="gcm-form-group" style="flex:1">
                  <div class="gcm-form-label">最大点数</div>
                  <input v-model.number="game.cfg.maxNumber" type="number" class="gcm-input" />
                </div>
                <div class="gcm-form-group" style="flex:1">
                  <div class="gcm-form-label">大小阈值</div>
                  <input v-model.number="game.cfg.threshold" type="number" class="gcm-input" />
                </div>
              </div>
              <div class="gcm-form-group">
                <div class="gcm-form-label">获胜倍数</div>
                <input v-model.number="game.cfg.winMultiplier" type="number" step="0.5" class="gcm-input" />
              </div>
            </template>

            <!-- 剪刀石头布 -->
            <template v-if="game.gameType === 'rps'">
              <div class="gcm-form-group">
                <div class="gcm-form-label">获胜倍数</div>
                <input v-model.number="game.cfg.winMultiplier" type="number" step="0.5" class="gcm-input" />
              </div>
              <div class="gcm-form-group">
                <label class="gcm-check-label"><input type="checkbox" v-model="game.cfg.drawRefund" />平局返还积分</label>
              </div>
            </template>

            <!-- 会员折扣 -->
            <div class="gcm-form-label">会员折扣</div>
            <div v-for="(d, di) in game.cfg.memberDiscounts" :key="di" class="gcm-card-row">
              <span class="gcm-card-row-label">{{ d.levelName }}</span>
              <input v-model.number="d.discount" type="number" step="0.05" min="0.1" max="1" class="gcm-input-sm" />
              <span class="gcm-card-row-hint">{{ Math.round(d.discount * 100) }}折</span>
            </div>

            <button class="gcm-save-btn" :disabled="game.saving" @click="saveConfig(game)">
              {{ game.saving ? '保存中...' : '保存配置' }}
            </button>
          </div>

          <button class="gcm-expand-btn" @click="toggleExpand(game)">
            {{ game.expanded ? '收起设置' : '展开设置' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'

const loading = ref(true)
const games = ref<any[]>([])
const couponList = ref<any[]>([])
const levelList = ref<any[]>([])

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/list')
    const list = (res.data || []).map((g: any) => ({ ...g, switching: false, saving: false, expanded: false, cfg: {} }))
    games.value = list
  } catch (e: any) { alert(e.message) }
  finally { loading.value = false }
})

function toggleExpand(game: any) {
  game.expanded = !game.expanded
  if (game.expanded && !game.cfg || Object.keys(game.cfg).length === 0) {
    loadConfig(game)
  }
}

async function loadConfig(game: any) {
  if (game.gameType === 'lottery' && couponList.value.length === 0) {
    try {
      const [cpRes, lvRes] = await Promise.all([
        axios.get('/api/operation/coupon/list?status=1'),
        axios.get('/api/operation/membership/list')
      ])
      couponList.value = cpRes.data?.data || cpRes.data?.list || []
      levelList.value = (lvRes.data?.data || lvRes.data?.list || []).filter((l: any) => l.level > 0)
    } catch {}
  }
  try {
    const { data: res } = await axios.get(`/api/game/config/${game.gameType}`)
    const cfg = res.data?.config || {}
    game.cfg = {
      cost: cfg.costPerDraw || cfg.costPerFlip || cfg.costPerBet || cfg.costPerPlay || 10,
      cost10: cfg.costPerDraw10 || (cfg.costPerDraw || 10) * 10,
      pityCount: cfg.pityCount || 0,
      pityGridIndex: cfg.pityGridIndex || 0,
      grids: cfg.grids ? [...cfg.grids] : Array.from({ length: 9 }, (_, i) => ({ index: i, name: '', type: 'points', value: 10, probability: 11 })),
      cards: cfg.cards ? [...cfg.cards] : [
        { name: 'A', label: '奖', isWin: true, probability: 30 },
        { name: 'B', label: '空', isWin: false, probability: 35 },
        { name: 'C', label: '空', isWin: false, probability: 35 }
      ],
      maxNumber: cfg.maxNumber || 6,
      threshold: cfg.threshold || 4,
      winMultiplier: cfg.winMultiplier || 2,
      drawRefund: cfg.drawRefund !== false,
      memberDiscounts: cfg.memberDiscounts ? [...cfg.memberDiscounts] : []
    }
    if (!game.cfg.memberDiscounts.length) {
      try {
        const { data: lvls } = await axios.get('/api/operation/membership/list')
        game.cfg.memberDiscounts = (lvls.data || [])
          .filter((l: any) => l.level > 0)
          .map((l: any) => ({ levelId: l.id, levelName: l.name, discount: 1 }))
      } catch {}
    }
  } catch {}
}

async function toggleGame(game: any) {
  game.switching = true
  const newVal = !game.enabled
  try {
    await loadConfig(game)
    const cfg = buildConfig(game)
    await axios.post(`/api/game/config/${game.gameType}`, { enabled: newVal ? 1 : 0, config: cfg })
    game.enabled = newVal
  } catch (e: any) { alert(e.message) }
  finally { game.switching = false }
}

function buildConfig(game: any) {
  const { cfg } = game
  const c: any = {}
  if (game.gameType === 'lottery') {
    c.costPerDraw = cfg.cost; c.costPerDraw10 = cfg.cost10; c.pityCount = cfg.pityCount
    c.pityGridIndex = cfg.pityGridIndex; c.grids = cfg.grids
  } else if (game.gameType === 'card_guess') {
    c.costPerFlip = cfg.cost; c.pityCount = cfg.pityCount; c.winMultiplier = cfg.winMultiplier; c.cards = cfg.cards
  } else if (game.gameType === 'dice') {
    c.costPerBet = cfg.cost; c.maxNumber = cfg.maxNumber; c.threshold = cfg.threshold; c.winMultiplier = cfg.winMultiplier
  } else if (game.gameType === 'rps') {
    c.costPerPlay = cfg.cost; c.winMultiplier = cfg.winMultiplier; c.drawRefund = cfg.drawRefund
  }
  c.memberDiscounts = cfg.memberDiscounts
  return c
}

async function saveConfig(game: any) {
  game.saving = true
  try {
    const cfg = buildConfig(game)
    if (cfg.grids) {
      const total = cfg.grids.reduce((s: number, g: any) => s + (Number(g.probability) || 0), 0)
      if (total > 100) { alert('概率总和不能超过100%'); game.saving = false; return }
    }
    await axios.post(`/api/game/config/${game.gameType}`, { enabled: game.enabled ? 1 : 0, config: cfg })
    alert('保存成功')
  } catch (e: any) { alert(e.message) }
  finally { game.saving = false }
}
</script>

<style scoped>
.gcm-page { min-height: 100vh; background: #f5f5f7; padding-bottom: 40px; }
.gcm-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #fff; border-bottom: 1px solid #f0f0f0; position: sticky; top: 0; z-index: 10; }
.gcm-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.gcm-back svg { width: 20px; height: 20px; color: #333; }
.gcm-title { font-size: 17px; font-weight: 700; color: #1a1a1a; }
.gcm-body { padding: 12px 16px; }
.gcm-loading { text-align: center; padding: 40px; color: #999; }

.gcm-card { background: #fff; border-radius: 14px; padding: 16px; margin-bottom: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.gcm-card-top { display: flex; align-items: center; gap: 12px; }
.gcm-card-icon { width: 44px; height: 44px; border-radius: 12px; background: linear-gradient(135deg, #f0f0ff, #e8e8ff); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.gcm-card-emoji { font-size: 24px; }
.gcm-card-info { flex: 1; min-width: 0; }
.gcm-card-name { font-size: 15px; font-weight: 700; color: #1a1a1a; }
.gcm-card-desc { font-size: 12px; color: #999; }
.gcm-card-stats { font-size: 11px; color: #6366f1; margin-top: 2px; }
.gcm-card-toggle { flex-shrink: 0; }

.gcm-switch { position: relative; display: inline-block; width: 48px; height: 28px; }
.gcm-switch input { opacity: 0; width: 0; height: 0; }
.gcm-slider { position: absolute; inset: 0; background: #ccc; border-radius: 28px; transition: .3s; cursor: pointer; }
.gcm-slider::before { content: ''; position: absolute; height: 22px; width: 22px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
.gcm-switch input:checked + .gcm-slider { background: #6366f1; }
.gcm-switch input:checked + .gcm-slider::before { transform: translateX(20px); }

.gcm-card-expand { margin-top: 14px; padding-top: 14px; border-top: 1px solid #f0f0f0; }
.gcm-form-group { margin-bottom: 10px; }
.gcm-form-label { font-size: 13px; font-weight: 600; color: #555; margin-bottom: 4px; }
.gcm-input { width: 100%; height: 38px; padding: 0 12px; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 14px; box-sizing: border-box; }
.gcm-input-sm { width: 100%; height: 32px; padding: 0 8px; border: 1.5px solid #e0e0e0; border-radius: 6px; font-size: 12px; box-sizing: border-box; }
.gcm-select-sm { height: 32px; padding: 0 8px; border: 1.5px solid #e0e0e0; border-radius: 6px; font-size: 12px; background: #fff; }
.gcm-form-row { display: flex; gap: 8px; }

.gcm-grids { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin-bottom: 10px; }
.gcm-grid-item { border: 1px solid #e5e7eb; border-radius: 8px; padding: 8px; background: #fafafa; display: flex; flex-direction: column; gap: 4px; }
.gcm-grid-idx { font-size: 14px; font-weight: 700; color: #6366f1; text-align: center; }

.gcm-card-row { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.gcm-card-row-label { font-size: 12px; color: #888; white-space: nowrap; }
.gcm-card-row-hint { font-size: 11px; color: #aaa; white-space: nowrap; }
.gcm-check-label { font-size: 12px; display: flex; align-items: center; gap: 2px; white-space: nowrap; }

.gcm-save-btn { width: 100%; height: 40px; background: #6366f1; color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 8px; }
.gcm-save-btn:disabled { opacity: .5; }

.gcm-expand-btn { width: 100%; height: 36px; background: none; border: 1.5px solid #e0e0e0; border-radius: 8px; font-size: 13px; color: #888; cursor: pointer; margin-top: 10px; }
</style>
