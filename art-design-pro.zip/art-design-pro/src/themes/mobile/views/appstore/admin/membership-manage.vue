<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-10">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">会员管理</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <!-- 等级卡片 -->
      <div class="mx-3 mt-3" v-if="levels.length">
        <div v-for="lv in levels" :key="lv.id" class="bg-white rounded-xl mb-3 p-4 shadow-sm">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-full flex items-center justify-center text-white text-lg font-bold overflow-hidden" :style="{ background: lv.bgColor || '#508DFF' }">
                <img v-if="lv.icon && isImageUrl(lv.icon)" :src="$fixImgUrl(lv.icon)" class="w-full h-full object-cover" />
                <span v-else>{{ lv.icon || lv.name.charAt(0) }}</span>
              </div>
              <div>
                <div class="text-sm font-bold" :style="{ color: lv.textColor || '#333' }">Lv.{{ lv.level }} {{ lv.name }}</div>
                <div class="text-xs text-gray-400">价格: ¥{{ lv.price }} / 折扣: {{ (lv.discountRate * 10).toFixed(1) }}折</div>
              </div>
            </div>
            <div class="flex gap-2">
              <button class="text-xs px-2 py-1 rounded bg-[#FF4757] text-white" @click="openLevelDialog(lv)">编辑</button>
              <button class="text-xs px-2 py-1 rounded bg-gray-200 text-gray-600" @click="deleteLevel(lv.id)">删除</button>
            </div>
          </div>
          <div class="mt-2 flex items-center gap-4 text-xs text-gray-500">
            <span>积分倍率: x{{ lv.pointsMultiplier }}</span>
            <span>状态: {{ lv.status === '1' ? '启用' : '禁用' }}</span>
          </div>
          <div v-if="lv.pricingPlans && lv.pricingPlans.length" class="mt-3 pt-3 border-t border-gray-100">
            <div class="text-xs text-gray-400 mb-2">定价方案</div>
            <div class="flex flex-wrap gap-2">
              <div v-for="plan in lv.pricingPlans" :key="plan.id" class="bg-gray-50 rounded-lg px-2.5 py-1.5 text-xs">
                <span class="font-medium text-gray-700">{{ plan.name }}</span>
                <span class="text-red-400 ml-1">¥{{ plan.price }}</span>
                <span v-if="plan.originalPrice > 0" class="text-gray-300 line-through ml-1">¥{{ plan.originalPrice }}</span>
                <span class="text-gray-400 ml-1">{{ plan.durationDays }}天</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div v-else class="bg-white mx-3 mt-3 rounded-xl p-6 text-center text-gray-400">暂无会员等级</div>

      <button class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openLevelDialog()">+</button>
    </div>

    <!-- 等级编辑弹窗 -->
    <div v-if="showLevelDialog" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showLevelDialog = false">
      <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto px-4 pt-4 pb-6 animate-slide-up" @click.stop>
        <div class="text-base font-bold mb-4 text-center">{{ editLevel.id ? '编辑等级' : '新增等级' }}</div>
        <div class="space-y-3">
          <div><div class="text-xs text-gray-500 mb-1">名称</div><input v-model="editLevel.name" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">等级</div><input v-model.number="editLevel.level" type="number" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">Tier</div><input v-model.number="editLevel.tier" type="number" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
          </div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">价格</div><input v-model.number="editLevel.price" type="number" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">折扣率</div><input v-model.number="editLevel.discountRate" type="number" step="0.1" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
          </div>
          <div class="flex gap-3">
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">积分倍率</div><input v-model.number="editLevel.pointsMultiplier" type="number" step="0.1" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
            <div class="flex-1"><div class="text-xs text-gray-500 mb-1">文字颜色</div><input v-model="editLevel.textColor" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
          </div>
          <div><div class="text-xs text-gray-500 mb-1">背景颜色</div><input v-model="editLevel.bgColor" class="w-full border rounded-lg px-3 py-2 text-sm"></div>
          <div>
            <div class="text-xs text-gray-500 mb-1">图标</div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-full flex items-center justify-center overflow-hidden" :style="{ background: editLevel.bgColor || '#508DFF' }">
                <img v-if="editLevel.icon && isImageUrl(editLevel.icon)" :src="editLevel.icon" class="w-full h-full object-cover" />
                <span v-else class="text-white text-lg font-bold">{{ editLevel.icon || editLevel.name.charAt(0) || '?' }}</span>
              </div>
              <input ref="iconInput" type="file" accept="image/*" class="hidden" @change="handleIconUpload">
              <button class="h-9 px-4 bg-white text-sm text-[#FF4757] rounded-lg border border-[#FF4757]/30 active:bg-red-50" :disabled="uploadingIcon" @click="triggerIconUpload">{{ uploadingIcon ? '上传中...' : (editLevel.icon && isImageUrl(editLevel.icon) ? '重新上传' : '上传图标') }}</button>
            </div>
          </div>
          <div><div class="text-xs text-gray-500 mb-1">权益说明</div><textarea v-model="editLevel.benefits" class="w-full border rounded-lg px-3 py-2 text-sm" rows="2"></textarea></div>
          <div><div class="text-xs text-gray-500 mb-1">状态</div><select v-model="editLevel.status" class="w-full border rounded-lg px-3 py-2 text-sm"><option value="1">启用</option><option value="0">禁用</option></select></div>
          <div class="pt-2 border-t border-gray-100">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs text-gray-500 font-medium">定价方案</span>
              <button class="text-xs text-[#FF4757]" @click="addPlan">+ 添加方案</button>
            </div>
            <div v-for="(plan, idx) in plans" :key="idx" class="bg-gray-50 rounded-lg p-3 mb-2 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-xs text-gray-400">方案 {{ idx + 1 }}</span>
                <button class="text-xs text-red-400" @click="plans.splice(idx, 1)">删除</button>
              </div>
              <div><div class="text-[11px] text-gray-400 mb-0.5">名称</div><input v-model="plan.name" class="w-full border rounded px-2 py-1.5 text-xs"></div>
              <div class="flex gap-2">
                <div class="flex-1"><div class="text-[11px] text-gray-400 mb-0.5">价格 ¥</div><input v-model.number="plan.price" type="number" step="0.01" class="w-full border rounded px-2 py-1.5 text-xs"></div>
                <div class="flex-1"><div class="text-[11px] text-gray-400 mb-0.5">原价 ¥</div><input v-model.number="plan.originalPrice" type="number" step="0.01" class="w-full border rounded px-2 py-1.5 text-xs"></div>
              </div>
              <div class="flex gap-2">
                <div class="flex-1"><div class="text-[11px] text-gray-400 mb-0.5">积分价</div><input v-model.number="plan.pointsPrice" type="number" class="w-full border rounded px-2 py-1.5 text-xs"></div>
                <div class="flex-1"><div class="text-[11px] text-gray-400 mb-0.5">积分原价</div><input v-model.number="plan.pointsOriginalPrice" type="number" class="w-full border rounded px-2 py-1.5 text-xs"></div>
              </div>
              <div><div class="text-[11px] text-gray-400 mb-0.5">时长(天)</div><input v-model.number="plan.durationDays" type="number" class="w-full border rounded px-2 py-1.5 text-xs"></div>
            </div>
          </div>
        </div>
        <div class="flex gap-3 mt-5">
          <button class="flex-1 py-2.5 rounded-lg bg-gray-100 text-gray-600 text-sm" @click="showLevelDialog = false">取消</button>
          <button class="flex-1 py-2.5 rounded-lg bg-[#FF4757] text-white text-sm" @click="saveLevel">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive } from 'vue'
import request from '@/utils/http'

const levels = ref<any[]>([])
const showLevelDialog = ref(false)
const editLevel = reactive<any>({ id: 0, name: '', level: 1, tier: 1, price: 0, discountRate: 1, pointsMultiplier: 1, textColor: '#FFFFFF', bgColor: '#508DFF', icon: '', benefits: '', status: '1' })
const plans = reactive<{name: string; price: number; originalPrice: number; pointsPrice: number; pointsOriginalPrice: number; durationDays: number}[]>([])

const iconInput = ref<HTMLInputElement>()
const uploadingIcon = ref(false)

const isImageUrl = (v: string) => /^https?:\/\//.test(v) || /\.(png|jpe?g|gif|svg|webp|ico)(\?.*)?$/i.test(v)

const triggerIconUpload = () => iconInput.value?.click()

const handleIconUpload = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  uploadingIcon.value = true
  try {
    const fd = new FormData()
    fd.append('file', file)
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd, headers: { 'Content-Type': 'multipart/form-data' } })
    editLevel.icon = res?.url || res?.data?.url || res?.data || ''
  } catch {}
  uploadingIcon.value = false
  input.value = ''
}

const loadLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    if (res?.records) levels.value = res.records
  } catch {}
}

const openLevelDialog = (lv?: any) => {
  if (lv) {
    Object.assign(editLevel, { ...lv, id: lv.id })
    plans.splice(0, plans.length, ...(lv.pricingPlans || []).map((p: any) => ({
      name: p.name || '', price: p.price || 0, originalPrice: p.originalPrice || 0,
      pointsPrice: p.pointsPrice || 0, pointsOriginalPrice: p.pointsOriginalPrice || 0,
      durationDays: p.durationDays || 30
    })))
  } else {
    Object.assign(editLevel, { id: 0, name: '', level: 1, tier: 1, price: 0, discountRate: 1, pointsMultiplier: 1, textColor: '#FFFFFF', bgColor: '#508DFF', icon: '', benefits: '', status: '1' })
    plans.splice(0)
  }
  showLevelDialog.value = true
}

const addPlan = () => {
  plans.push({ name: '', price: 0, originalPrice: 0, pointsPrice: 0, pointsOriginalPrice: 0, durationDays: 30 })
}

const saveLevel = async () => {
  try {
    await request.post({ url: '/api/operation/membership-level/save', data: { ...editLevel, pricingPlans: [...plans] } })
    showLevelDialog.value = false
    loadLevels()
  } catch {}
}

const deleteLevel = async (id: number) => {
  if (!confirm('确定删除该等级？')) return
  try {
    await request.delete({ url: `/api/operation/membership-level/${id}` })
    loadLevels()
  } catch {}
}

onMounted(() => { loadLevels() })
</script>
