<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <!-- 顶部标题栏 -->
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-10">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">管理员中心</span>
      <button class="text-xs px-3 py-1.5 rounded-lg bg-[#FF4757] text-white font-medium active:bg-[#FF3767] flex-shrink-0" @click="$router.push('/appstore/site-config')">基础配置</button>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <!-- 数据概览 -->
      <div v-if="statsLoaded" class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="grid grid-cols-4 gap-2">
          <div class="text-center">
            <div class="text-xl font-bold text-[#FF4757]">{{ stats.posts }}</div>
            <div class="text-[11px] text-gray-400 mt-1">全站文章</div>
          </div>
          <div class="text-center border-l border-gray-100">
            <div class="text-xl font-bold text-[#FF4757]">{{ stats.comments }}</div>
            <div class="text-[11px] text-gray-400 mt-1">全站评论</div>
          </div>
          <div class="text-center border-l border-gray-100">
            <div class="text-xl font-bold text-[#FF4757]">{{ stats.products }}</div>
            <div class="text-[11px] text-gray-400 mt-1">全站商品</div>
          </div>
          <div class="text-center border-l border-gray-100">
            <div class="text-xl font-bold text-[#FF4757]">{{ stats.users }}</div>
            <div class="text-[11px] text-gray-400 mt-1">用户注册</div>
          </div>
        </div>
      </div>
      <div v-else class="bg-white mx-3 mt-3 rounded-xl p-6 flex justify-center">
        <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
      </div>

      <!-- 动态卡片模块（从后端菜单管理加载） -->
      <template v-if="cardsLoaded">
        <div v-for="(items, category) in cardGroups" :key="category" class="bg-white mx-3 mt-3 rounded-xl p-4">
          <div class="text-sm font-bold text-gray-800 mb-3">{{ category }}</div>
          <div class="grid grid-cols-4 gap-y-4 gap-x-2">
            <div v-for="item in items" :key="item.id" class="flex flex-col items-center gap-1.5 cursor-pointer active:opacity-70" @click="handleClick(item)">
              <div class="w-[44px] h-[44px] rounded-full flex items-center justify-center" :style="{ background: item.bg }">
                <svg v-if="item.icon" class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path :d="item.icon"/></svg>
                <span v-else class="text-white text-lg font-bold">{{ item.label.charAt(0) }}</span>
              </div>
              <span class="text-[11px] text-gray-600 text-center leading-tight">{{ item.label }}</span>
            </div>
          </div>
        </div>
      </template>
      <div v-else class="bg-white mx-3 mt-3 rounded-xl p-6 flex justify-center">
        <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
      </div>

      <!-- 版本信息 -->
      <div class="mx-3 mt-3 grid grid-cols-2 gap-3">
        <div class="bg-white rounded-xl p-4">
          <div class="text-[11px] text-gray-400 mb-1">客户端最新版本</div>
          <div class="text-sm font-semibold text-gray-800">{{ appName }}</div>
          <div class="text-xs text-gray-400 mt-0.5">{{ appVersion }}</div>
        </div>
        <div class="bg-white rounded-xl p-4">
          <div class="text-[11px] text-gray-400 mb-1">服务端最新版本</div>
          <div class="text-sm font-semibold text-gray-800">RuleApi</div>
          <div class="text-xs text-gray-400 mt-0.5">V1.0.0 (2026.07.07)</div>
        </div>
      </div>

      <!-- 底部导航栏预留空间 -->
      <div class="h-20" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { fetchAdminCenterCards } from '@/api/system-manage'

const router = useRouter()

const appName = 'ArtDesignPro'
const appVersion = 'v1.0.0 (2026.07.07)'

const statsLoaded = ref(false)
const stats = ref({ posts: 0, comments: 0, products: 0, users: 0 })

const cardsLoaded = ref(false)
const cardGroups = ref<Record<string, { id: number; label: string; bg: string; icon: string; path: string }[]>>({})

interface CardItem {
  id: number
  label: string
  bg: string
  icon: string
  path: string
}

const handleClick = (item: CardItem) => {
  if (item.path) router.push(item.path)
}

const loadStats = async () => {
  try {
    const res: any = await request.get({ url: '/api/admin/stats' })
    if (res) stats.value = res
  } catch {}
  statsLoaded.value = true
}

const loadCards = async () => {
  try {
    const res: any = await fetchAdminCenterCards()
    if (res) cardGroups.value = res
  } catch {}
  cardsLoaded.value = true
}

onMounted(() => {
  loadStats()
  loadCards()
})
</script>
