<template>
  <div class="topic-manage-page mx-auto max-w-[430px] shadow-lg relative" style="min-height:100vh;background:var(--default-bg-color)">
    <div class="h-[34px] bg-white"/>
    <div class="nav-bar sticky top-0 z-10 bg-white">
      <div class="flex items-center justify-between h-[40px] px-4">
        <svg class="w-[22px] h-[22px] text-[#222] flex-shrink-0 active:opacity-50" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" @click="$router.back()">
          <path d="M15 18l-6-6 6-6"/>
        </svg>
        <span class="text-[17px] text-[#111] font-bold">话题管理</span>
        <div class="w-[32px] h-[32px]"/>
      </div>
    </div>

    <div v-if="loading" class="flex justify-center pt-40">
      <div class="w-5 h-5 border-2 border-[#22C1C3] border-t-transparent rounded-full animate-spin"/>
    </div>

    <template v-else>
      <div class="bg-white px-5 py-4 mb-2">
        <button class="w-full h-[42px] rounded-lg text-[14px] font-medium text-white" style="background:#22C1C3" @click="showCreateDialog = true">+ 创建话题</button>
      </div>

      <div class="bg-white px-5 py-3 mb-2">
        <div class="text-[14px] font-semibold text-[#333] mb-3">创建权限设置</div>
        <div class="mb-3">
          <div class="text-[12px] text-[#666] mb-2">最低经验等级要求（0=不限制）</div>
          <input v-model.number="config.minExpLevel" type="number" min="0" class="w-full h-[38px] px-3 text-[13px] border border-[#E5E7EB] rounded-lg outline-none" />
        </div>
        <div class="mb-3">
          <div class="text-[12px] text-[#666] mb-2">允许的会员等级ID（逗号分隔，留空=不限制）</div>
          <input v-model="config.allowedLevelsStr" placeholder="例如: 2,3,5" class="w-full h-[38px] px-3 text-[13px] border border-[#E5E7EB] rounded-lg outline-none" />
        </div>
        <button class="w-full h-[38px] rounded-lg text-[13px] font-medium text-white" style="background:#22C1C3" @click="saveConfig" :disabled="savingConfig">
          {{ savingConfig ? '保存中...' : '保存权限设置' }}
        </button>
        <div v-if="configMsg" class="text-[12px] text-center mt-2" :style="{ color: configMsgOk ? '#22C1C3' : '#EF4444' }">{{ configMsg }}</div>
      </div>

      <div class="bg-white px-5 py-3">
        <div class="text-[14px] font-semibold text-[#333] mb-3">话题列表 ({{ topics.length }})</div>
        <div v-if="topics.length === 0" class="text-center py-8 text-gray-400 text-sm">暂无话题</div>
        <div v-for="t in topics" :key="t.id" class="flex items-center gap-3 py-2.5 border-b border-[#F0F0F0] last:border-0">
          <div class="w-[40px] h-[40px] rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden" :style="{ background: t.icon ? 'transparent' : '#22C1C3' }">
            <img v-if="t.icon" :src="$fixImgUrl(t.icon)" class="w-full h-full object-cover" />
            <span v-else class="text-white font-bold">#</span>
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-[13px] text-[#333] font-medium truncate">#{{ t.name }}</div>
            <div class="text-[11px] text-[#999]">{{ t.description || '暂无简介' }}</div>
            <div class="text-[11px] text-[#B0B0B0]">{{ t.postCount || 0 }} 帖子 · {{ t.status === '1' ? '显示' : '隐藏' }}</div>
          </div>
          <div class="flex gap-1 flex-shrink-0">
            <button class="px-2 py-1 text-[11px] rounded text-[#22C1C3] bg-[#E8F8F8]" @click="editTopic(t)">编辑</button>
            <button class="px-2 py-1 text-[11px] rounded" :style="{ color: t.status === '1' ? '#F59E0B' : '#22C1C3', background: t.status === '1' ? '#FEF3C7' : '#E8F8F8' }" @click="toggleStatus(t)">
              {{ t.status === '1' ? '隐藏' : '显示' }}
            </button>
            <button class="px-2 py-1 text-[11px] rounded text-[#EF4444] bg-[#FEE2E2]" @click="confirmDelete(t)">删除</button>
          </div>
        </div>
      </div>
    </template>

    <div v-if="showCreateDialog" style="position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:100" @click.self="closeDialog">
      <div style="background:#fff;border-radius:16px;width:340px;padding:24px 20px 16px;">
        <div style="font-size:16px;font-weight:600;color:#1f2937;margin-bottom:16px;">{{ editingTopic ? '编辑话题' : '创建话题' }}</div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">名称 <span style="color:#EF4444">*</span></div>
          <input v-model="editForm.name" maxlength="30" style="width:100%;height:38px;padding:0 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;box-sizing:border-box" />
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">图标URL</div>
          <input v-model="editForm.icon" placeholder="图片链接" style="width:100%;height:38px;padding:0 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;box-sizing:border-box" />
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:12px;color:#666;margin-bottom:4px;">简介</div>
          <textarea v-model="editForm.description" maxlength="200" rows="2" style="width:100%;padding:8px 10px;font-size:13px;border:1px solid #E5E7EB;border-radius:8px;outline:none;resize:none;box-sizing:border-box" />
        </div>
        <div v-if="dialogMsg" style="font-size:12px;color:#EF4444;margin-bottom:8px;text-align:center;">{{ dialogMsg }}</div>
        <div style="display:flex;gap:10px;">
          <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#F3F4F6;color:#374151;cursor:pointer;" @click="closeDialog">取消</button>
          <button style="flex:1;padding:10px;border-radius:8px;font-size:14px;border:none;background:#22C1C3;color:#fff;cursor:pointer;" @click="handleSave" :disabled="dialogSaving">{{ dialogSaving ? '保存中...' : '保存' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchTopics, createTopic, updateTopic, deleteTopic, fetchTopicConfig, updateTopicConfig } from '@/api/community'

const loading = ref(true)
const topics = ref<any[]>([])
const savingConfig = ref(false)
const configMsg = ref('')
const configMsgOk = ref(false)
const config = ref({ minExpLevel: 0, allowedLevelsStr: '' })

const showCreateDialog = ref(false)
const editingTopic = ref<any>(null)
const dialogSaving = ref(false)
const dialogMsg = ref('')
const editForm = ref({ name: '', icon: '', description: '' })

async function loadTopics() {
  try {
    const res: any = await fetchTopics({ pageSize: 200 })
    topics.value = res?.data?.list || res?.list || res?.data || []
  } catch {} finally { loading.value = false }
}

async function loadConfig() {
  try {
    const res: any = await fetchTopicConfig()
    const data = res?.data || res || {}
    config.value.minExpLevel = data.minExpLevel || 0
    config.value.allowedLevelsStr = (data.allowedLevels || []).join(',')
  } catch {}
}

async function saveConfig() {
  savingConfig.value = true
  configMsg.value = ''
  try {
    const levels = config.value.allowedLevelsStr ? config.value.allowedLevelsStr.split(',').map(Number).filter(Boolean) : []
    await updateTopicConfig({ minExpLevel: config.value.minExpLevel, allowedLevels: levels })
    configMsg.value = '保存成功'
    configMsgOk.value = true
  } catch (e: any) {
    configMsg.value = e?.msg || '保存失败'
    configMsgOk.value = false
  } finally { savingConfig.value = false }
}

function editTopic(t: any) {
  editingTopic.value = t
  editForm.value = { name: t.name, icon: t.icon || '', description: t.description || '' }
  showCreateDialog.value = true
}

function closeDialog() {
  showCreateDialog.value = false
  editingTopic.value = null
  editForm.value = { name: '', icon: '', description: '' }
  dialogMsg.value = ''
}

async function handleSave() {
  dialogMsg.value = ''
  if (!editForm.value.name.trim()) { dialogMsg.value = '请输入名称'; return }
  dialogSaving.value = true
  try {
    if (editingTopic.value) {
      await updateTopic(editingTopic.value.id, editForm.value)
    } else {
      await createTopic(editForm.value)
    }
    closeDialog()
    loadTopics()
  } catch (e: any) {
    dialogMsg.value = e?.msg || '操作失败'
  } finally { dialogSaving.value = false }
}

async function toggleStatus(t: any) {
  try {
    await updateTopic(t.id, { status: t.status === '1' ? '0' : '1' })
    loadTopics()
  } catch {}
}

async function confirmDelete(t: any) {
  if (!confirm(`确定删除话题"${t.name}"吗？`)) return
  try {
    await deleteTopic(t.id)
    loadTopics()
  } catch {}
}

onMounted(async () => {
  await Promise.all([loadTopics(), loadConfig()])
})
</script>
