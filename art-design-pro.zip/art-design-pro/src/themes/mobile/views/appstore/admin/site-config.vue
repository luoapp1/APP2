<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">基础配置</span>
      <button class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-xs font-medium active:opacity-85 shadow-sm shadow-red-200 flex-shrink-0" :disabled="saving" @click="saveConfig">{{ saving ? '保存中...' : '保存' }}</button>
    </div>

    <div class="flex-1 overflow-y-auto pb-20 p-4 space-y-4">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>

      <template v-else>
        <!-- 主题设置 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">主题设置</div>
          <div class="text-[10px] text-gray-400">日间模式及夜间模式显示效果，默认为自动根据时间切换</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">显示模式</label>
            <select v-model="cfg.theme_mode" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="auto">自动切换（根据时间）</option>
              <option value="light">日间模式</option>
              <option value="dark">夜间模式</option>
            </select>
          </div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">前端显示切换按钮</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.show_theme_switch ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.show_theme_switch = !cfg.show_theme_switch">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.show_theme_switch ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
        </div>

        <!-- 网站信息 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">网站信息</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站名称</label>
            <input v-model="cfg.site_name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="对外全称，用于浏览器标题、邮件、分享卡片" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站副标题</label>
            <input v-model="cfg.site_subtitle" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="补充描述，用于首页SEO、底部说明" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站域名</label>
            <input v-model="cfg.site_domain" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="https://example.com" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">后台入口地址</label>
            <input v-model="cfg.admin_path" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="如 /admin123" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">网站图标 favicon</label>
            <input v-model="cfg.site_favicon" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="32×32px ICO格式URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">PC端LOGO</label>
            <input v-model="cfg.logo_pc" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="透明PNG格式URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">移动端LOGO</label>
            <input v-model="cfg.logo_mobile" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="适配手机端尺寸URL" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">底部版权信息</label>
            <input v-model="cfg.copyright" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="©2026 某某网站 版权所有" />
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">ICP备案号</label>
            <input v-model="cfg.icp" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" placeholder="粤ICP备xxxx号" />
          </div>
        </div>

        <!-- 登录安全 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">登录安全</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">后台登录验证码</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.login_captcha ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.login_captcha = !cfg.login_captcha">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.login_captcha ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">连续错误次数</label>
              <input v-model.number="cfg.login_max_errors" type="number" min="1" max="100" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
              <div class="text-[10px] text-gray-400 mt-0.5">达到后临时封禁</div>
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">封号时长(分钟)</label>
              <input v-model.number="cfg.login_lock_minutes" type="number" min="1" max="1440" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
            </div>
          </div>
        </div>

        <!-- IP安全限制 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">IP安全限制</div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">IP黑名单（每行一个IP）</label>
            <textarea v-model="cfg.ip_blacklist" rows="3" class="w-full px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="192.168.1.100&#10;10.0.0.50" />
            <div class="text-[10px] text-gray-400 mt-0.5">支持批量拉黑恶意攻击IP</div>
          </div>
        </div>

        <!-- 接口安全 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">接口安全</div>
          <div class="flex items-center justify-between">
            <div>
              <span class="text-sm text-gray-600">API请求签名验证</span>
              <div class="text-[10px] text-gray-400">防止恶意调用接口</div>
            </div>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.api_sign_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.api_sign_enabled = !cfg.api_sign_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.api_sign_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">接口请求频率限制</label>
            <div class="flex items-center gap-2">
              <span class="text-xs text-gray-500">单IP 1分钟最多</span>
              <input v-model.number="cfg.api_rate_limit" type="number" min="1" max="9999" class="w-20 h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none" />
              <span class="text-xs text-gray-500">次请求</span>
            </div>
          </div>
        </div>

        <!-- 用户注册设置 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">用户注册设置</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">开启用户注册</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.register_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.register_enabled = !cfg.register_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.register_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">注册验证方式</label>
            <select v-model="cfg.register_verify_type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="none">无需验证</option>
              <option value="phone">手机号验证码</option>
              <option value="email">邮箱验证码</option>
            </select>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">新用户默认角色</label>
            <select v-model="cfg.register_default_group" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="" disabled>请选择角色</option>
              <option v-for="role in roles" :key="role.roleCode" :value="role.roleCode">{{ role.roleName }} ({{ role.roleCode }})</option>
            </select>
            <div class="text-[10px] text-gray-400 mt-0.5">新注册用户默认分配的角色</div>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">密码规则</label>
            <select v-model="cfg.password_rule" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none">
              <option value="any">不限制</option>
              <option value="alphanumeric">6-16位，字母+数字组合</option>
              <option value="complex">8-20位，字母+数字+特殊字符</option>
            </select>
          </div>
        </div>

        <!-- 站点维护 -->
        <div class="bg-white rounded-2xl p-4 space-y-3 shadow-[0_1px_4px_rgba(0,0,0,0.04)]">
          <div class="text-sm font-bold text-gray-800 mb-1">站点维护</div>
          <div class="flex items-center justify-between">
            <span class="text-sm text-gray-600">网站临时关闭</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="cfg.maintenance_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="cfg.maintenance_enabled = !cfg.maintenance_enabled">
              <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="cfg.maintenance_enabled ? 'translate-x-4.5' : 'left-0.5'" />
            </button>
          </div>
          <div>
            <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">维护提示文案</label>
            <textarea v-model="cfg.maintenance_msg" rows="2" class="w-full px-3 py-2 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none resize-none" placeholder="网站升级维护中，预计XX时间恢复" />
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'
import { fetchSaveSysConfig } from '@/api/system-manage'
import { useSettingStore } from '@/store/modules/setting'
import { useTheme as useAppTheme } from '@/hooks/core/useTheme'
import { SystemThemeEnum } from '@/enums/appEnum'

defineOptions({ name: 'SiteConfigMobile' })

const SITE_NAME_KEY = 'art_site_name'

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(true)
const saving = ref(false)
const roles = ref<{ roleCode: string; roleName: string }[]>([])

const settingStore = useSettingStore()
const { switchThemeStyles } = useAppTheme()

const cfg = reactive({
  theme_mode: 'auto',
  show_theme_switch: true,
  site_name: '',
  site_subtitle: '',
  site_domain: '',
  admin_path: '/admin',
  site_favicon: '',
  logo_pc: '',
  logo_mobile: '',
  copyright: '',
  icp: '',
  login_captcha: true,
  login_max_errors: 5,
  login_lock_minutes: 15,
  ip_blacklist: '',
  api_sign_enabled: true,
  api_rate_limit: 60,
  register_enabled: true,
  register_verify_type: 'none',
  register_default_group: '',
  password_rule: 'alphanumeric',
  maintenance_enabled: false,
  maintenance_msg: ''
})

const FALLBACK_DARK_ID = 'art-fallback-dark'

function injectFallbackDark() {
  if (document.getElementById(FALLBACK_DARK_ID)) return
  const style = document.createElement('style')
  style.id = FALLBACK_DARK_ID
  style.textContent = `
    .dark { --default-bg-color: #1a1a2e; --default-box-color: #16213e; --default-border: #2a2a4a; --default-border-dashed: #2a2a4a; }
    .dark body, .dark .min-h-screen { background-color: #1a1a2e !important; }
    .dark .bg-white { background-color: #16213e !important; }
    .dark .bg-\\[\\#f5f6f8\\] { background-color: #1a1a2e !important; }
    .dark .text-gray-800 { color: #e0e0e0 !important; }
    .dark .text-gray-600 { color: #b0b0b0 !important; }
    .dark .text-gray-500 { color: #909090 !important; }
    .dark .text-gray-400 { color: #707070 !important; }
    .dark .border-gray-100 { border-color: #2a2a4a !important; }
    .dark .shadow-sm, .dark .shadow-\\[0_1px_4px_rgba\\(0\\,0\\,0\\,0\\.04\\)\\] { box-shadow: 0 1px 4px rgba(0,0,0,0.3) !important; }
  `
  document.head.appendChild(style)
}

function removeFallbackDark() {
  const el = document.getElementById(FALLBACK_DARK_ID)
  if (el) el.remove()
}

function hasActiveThemeVars(): boolean {
  const darkStyle = document.getElementById('theme-dark-vars')
  if (!darkStyle || !darkStyle.textContent) return false
  return darkStyle.textContent.replace('.dark {', '').replace('}', '').trim().length > 0
}

function applyFavicon(url: string) {
  let link = document.querySelector('link[rel="icon"]') as HTMLLinkElement | null
  if (!link) {
    link = document.createElement('link')
    link.rel = 'icon'
    document.head.appendChild(link)
  }
  link.href = url || ''
}

function applySiteName(name: string) {
  if (name) {
    localStorage.setItem(SITE_NAME_KEY, name)
    document.title = name
    let meta = document.querySelector('meta[name="site-name"]')
    if (!meta) {
      meta = document.createElement('meta')
      meta.setAttribute('name', 'site-name')
      document.head.appendChild(meta)
    }
    meta.setAttribute('content', name)
    document.documentElement.setAttribute('data-site-name', name)
  } else {
    localStorage.removeItem(SITE_NAME_KEY)
  }
}

const themeModeMap: Record<string, SystemThemeEnum> = {
  light: SystemThemeEnum.LIGHT,
  dark: SystemThemeEnum.DARK,
  auto: SystemThemeEnum.AUTO
}

function applyTheme(mode: string) {
  const enumVal = themeModeMap[mode]
  if (enumVal === undefined) return
  switchThemeStyles(enumVal)
  localStorage.setItem('art_site_theme', mode)

  if (!hasActiveThemeVars()) {
    if (enumVal === SystemThemeEnum.DARK || enumVal === SystemThemeEnum.AUTO) {
      injectFallbackDark()
    }
    if (enumVal === SystemThemeEnum.LIGHT) {
      removeFallbackDark()
    }
  }
}

const loadConfig = async () => {
  loading.value = true
  try {
    const [configRes, roleRes]: any[] = await Promise.all([
      request.get({ url: '/api/sys-config/list' }),
      request.get({ url: '/api/role/list' })
    ])

    if (roleRes && roleRes.data && roleRes.data.records) roles.value = roleRes.data.records
    else if (roleRes && roleRes.records) roles.value = roleRes.records

    if (configRes && Array.isArray(configRes)) {
      const map: Record<string, string> = {}
      for (const item of configRes) {
        if (item.config_key && item.config_value !== undefined) {
          map[item.config_key] = String(item.config_value)
        }
      }

      if (map.site_theme_mode) { cfg.theme_mode = map.site_theme_mode; applyTheme(map.site_theme_mode) }
      else cfg.theme_mode = settingStore.systemThemeMode
      if (map.site_show_theme_switch) cfg.show_theme_switch = map.site_show_theme_switch === 'true'
      if (map.site_name) { cfg.site_name = map.site_name; applySiteName(map.site_name) }
      if (map.site_favicon) { cfg.site_favicon = map.site_favicon; applyFavicon(map.site_favicon) }
      if (map.site_subtitle) cfg.site_subtitle = map.site_subtitle
      if (map.site_domain) cfg.site_domain = map.site_domain
      if (map.site_admin_path) cfg.admin_path = map.site_admin_path
      if (map.site_logo_pc) cfg.logo_pc = map.site_logo_pc
      if (map.site_logo_mobile) cfg.logo_mobile = map.site_logo_mobile
      if (map.site_copyright) cfg.copyright = map.site_copyright
      if (map.site_icp) cfg.icp = map.site_icp
      if (map.login_captcha_enabled) cfg.login_captcha = map.login_captcha_enabled === 'true'
      if (map.login_max_errors) cfg.login_max_errors = parseInt(map.login_max_errors) || 5
      if (map.login_lock_minutes) cfg.login_lock_minutes = parseInt(map.login_lock_minutes) || 15
      if (map.ip_blacklist) cfg.ip_blacklist = map.ip_blacklist
      if (map.api_sign_enabled) cfg.api_sign_enabled = map.api_sign_enabled === 'true'
      if (map.api_rate_limit) cfg.api_rate_limit = parseInt(map.api_rate_limit) || 60
      if (map.register_enabled) cfg.register_enabled = map.register_enabled === 'true'
      if (map.register_verify_type) cfg.register_verify_type = map.register_verify_type
      if (map.register_default_group) cfg.register_default_group = map.register_default_group
      if (map.password_rule) cfg.password_rule = map.password_rule
      if (map.site_maintenance_enabled) cfg.maintenance_enabled = map.site_maintenance_enabled === 'true'
      if (map.site_maintenance_msg) cfg.maintenance_msg = map.site_maintenance_msg
    }
  } catch {}
  loading.value = false
}

const saveConfig = async () => {
  saving.value = true
  try {
    const configs = [
      { config_key: 'site_theme_mode', config_value: cfg.theme_mode, description: '主题显示模式' },
      { config_key: 'site_show_theme_switch', config_value: String(cfg.show_theme_switch), description: '前端显示主题切换按钮' },
      { config_key: 'site_name', config_value: cfg.site_name, description: '网站名称' },
      { config_key: 'site_subtitle', config_value: cfg.site_subtitle, description: '网站副标题' },
      { config_key: 'site_domain', config_value: cfg.site_domain, description: '网站域名' },
      { config_key: 'site_admin_path', config_value: cfg.admin_path, description: '后台入口地址' },
      { config_key: 'site_favicon', config_value: cfg.site_favicon, description: '网站favicon' },
      { config_key: 'site_logo_pc', config_value: cfg.logo_pc, description: 'PC端LOGO' },
      { config_key: 'site_logo_mobile', config_value: cfg.logo_mobile, description: '移动端LOGO' },
      { config_key: 'site_copyright', config_value: cfg.copyright, description: '底部版权信息' },
      { config_key: 'site_icp', config_value: cfg.icp, description: 'ICP备案号' },
      { config_key: 'login_captcha_enabled', config_value: String(cfg.login_captcha), description: '后台登录验证码' },
      { config_key: 'login_max_errors', config_value: String(cfg.login_max_errors), description: '连续登录错误次数' },
      { config_key: 'login_lock_minutes', config_value: String(cfg.login_lock_minutes), description: '封号时长(分钟)' },
      { config_key: 'ip_blacklist', config_value: cfg.ip_blacklist, description: 'IP黑名单' },
      { config_key: 'api_sign_enabled', config_value: String(cfg.api_sign_enabled), description: 'API请求签名验证' },
      { config_key: 'api_rate_limit', config_value: String(cfg.api_rate_limit), description: '接口请求频率限制' },
      { config_key: 'register_enabled', config_value: String(cfg.register_enabled), description: '开启用户注册' },
      { config_key: 'register_verify_type', config_value: cfg.register_verify_type, description: '注册验证方式' },
      { config_key: 'register_default_group', config_value: cfg.register_default_group, description: '新用户默认分组' },
      { config_key: 'password_rule', config_value: cfg.password_rule, description: '密码规则' },
      { config_key: 'site_maintenance_enabled', config_value: String(cfg.maintenance_enabled), description: '网站维护开关' },
      { config_key: 'site_maintenance_msg', config_value: cfg.maintenance_msg, description: '维护提示文案' }
    ]
    await fetchSaveSysConfig(configs)

    applyTheme(cfg.theme_mode)
    applySiteName(cfg.site_name)
    applyFavicon(cfg.site_favicon)

    showToast('配置保存成功')
  } catch (e: any) {
    showToast('保存失败: ' + (e?.msg || e?.message || ''), 'error')
  } finally {
    saving.value = false
  }
}

onMounted(() => loadConfig())
</script>
