<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">支付配置</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
      <template v-else>
        <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden p-4">
          <label class="text-xs text-gray-500 mb-1.5 block font-medium">支付方式</label>
          <select v-model="activePayMethod" class="w-full h-11 px-3.5 text-sm bg-[#f5f6f8] rounded-xl border-none outline-none appearance-none">
            <option value="epay">易支付 (Epay)</option>
            <option value="alipay">支付宝 (Alipay)</option>
            <option value="wechat">微信支付 (WeChat Pay)</option>
          </select>
        </div>

        <!-- 易支付 -->
        <div v-show="activePayMethod === 'epay'" class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
            <span class="text-sm font-bold text-gray-800">易支付</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.payment_epay_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.payment_epay_enabled = !form.payment_epay_enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.payment_epay_enabled ? 'translate-x-4.5' : 'left-0.5'" /></button>
          </div>
          <div class="p-4 space-y-3">
            <div><label class="text-xs text-gray-500 mb-1 block">PID</label><input v-model="form.payment_epay_pid" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">Key</label><input v-model="form.payment_epay_key" type="password" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">API URL</label><input v-model="form.payment_epay_api_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">通知URL</label><input v-model="form.payment_epay_notify_url" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
        </div>

        <!-- 支付宝 -->
        <div v-show="activePayMethod === 'alipay'" class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
            <span class="text-sm font-bold text-gray-800">支付宝</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.payment_alipay_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.payment_alipay_enabled = !form.payment_alipay_enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.payment_alipay_enabled ? 'translate-x-4.5' : 'left-0.5'" /></button>
          </div>
          <div class="p-4 space-y-3">
            <div><label class="text-xs text-gray-500 mb-1 block">App ID</label><input v-model="form.payment_alipay_app_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">私钥</label><textarea v-model="form.payment_alipay_private_key" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">公钥</label><textarea v-model="form.payment_alipay_public_key" rows="3" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>
          </div>
        </div>

        <!-- 微信 -->
        <div v-show="activePayMethod === 'wechat'" class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
            <span class="text-sm font-bold text-gray-800">微信支付</span>
            <button class="w-10 h-6 rounded-full transition-colors relative" :class="form.payment_wechat_enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form.payment_wechat_enabled = !form.payment_wechat_enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.payment_wechat_enabled ? 'translate-x-4.5' : 'left-0.5'" /></button>
          </div>
          <div class="p-4 space-y-3">
            <div><label class="text-xs text-gray-500 mb-1 block">App ID</label><input v-model="form.payment_wechat_app_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">商户号</label><input v-model="form.payment_wechat_mch_id" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">Key</label><input v-model="form.payment_wechat_api_key" type="password" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
        </div>
      </template>
    </div>

    <div class="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-100 px-3 py-2.5 z-30">
      <button class="w-full h-11 bg-[#FF4757] text-white text-sm rounded-xl font-medium active:opacity-80" :disabled="saving" @click="saveConfig">{{ saving ? '保存中...' : '保存配置' }}</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'PaymentConfigMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(true); const saving = ref(false)
const activePayMethod = ref('epay')

const form = reactive({
  payment_epay_pid: '', payment_epay_key: '', payment_epay_api_url: '', payment_epay_notify_url: '', payment_epay_enabled: false,
  payment_alipay_app_id: '', payment_alipay_private_key: '', payment_alipay_public_key: '', payment_alipay_enabled: false,
  payment_wechat_app_id: '', payment_wechat_mch_id: '', payment_wechat_api_key: '', payment_wechat_enabled: false,
})

const fetchConfig = async () => {
  loading.value = true
  try {
    const data: any = await request.get({ url: '/api/admin/payment-config' }) || {} as any
    form.payment_epay_pid = data.payment_epay_pid || ''
    form.payment_epay_key = data.payment_epay_key || ''
    form.payment_epay_api_url = data.payment_epay_api_url || ''
    form.payment_epay_notify_url = data.payment_epay_notify_url || ''
    form.payment_epay_enabled = data.payment_epay_enabled === 'true' || data.payment_epay_enabled === true
    form.payment_alipay_app_id = data.payment_alipay_app_id || ''
    form.payment_alipay_private_key = data.payment_alipay_private_key || ''
    form.payment_alipay_public_key = data.payment_alipay_public_key || ''
    form.payment_alipay_enabled = data.payment_alipay_enabled === 'true' || data.payment_alipay_enabled === true
    form.payment_wechat_app_id = data.payment_wechat_app_id || ''
    form.payment_wechat_mch_id = data.payment_wechat_mch_id || ''
    form.payment_wechat_api_key = data.payment_wechat_api_key || ''
    form.payment_wechat_enabled = data.payment_wechat_enabled === 'true' || data.payment_wechat_enabled === true
  } catch { }
  loading.value = false
}

const saveConfig = async () => {
  saving.value = true
  try {
    await request.post({ url: '/api/admin/payment-config', data: { ...form } })
    showToast('保存成功')
  } catch { showToast('保存失败', 'error') }
  saving.value = false
}

onMounted(() => fetchConfig())
</script>
