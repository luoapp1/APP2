<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" @click="$router.back()" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">邮件推送</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg text-white text-sm shadow-lg" :class="toastType==='success'?'bg-[#4ECDC4]':'bg-[#FF4757]'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
          <svg class="w-4 h-4 text-[#FF4757]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          向管理员发送
        </div>
        <div v-for="cfg in adminConfigs" :key="cfg.code" class="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
          <div class="flex-1 min-w-0 pr-3">
            <div class="text-sm text-gray-800">{{ cfg.name }}</div>
            <div class="text-xs text-gray-400 mt-0.5">{{ cfg.description }}</div>
          </div>
          <button :class="cfg.enabled ? 'bg-[#FF4757]' : 'bg-gray-200'" class="relative w-11 h-6 rounded-full transition-colors flex-shrink-0" @click="toggleConfig(cfg)">
            <span :class="cfg.enabled ? 'translate-x-5' : 'translate-x-0.5'" class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform"></span>
          </button>
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
          <svg class="w-4 h-4 text-[#2196F3]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          向用户发送
        </div>
        <div v-for="cfg in userConfigs" :key="cfg.code" class="border-b border-gray-100 last:border-0 py-3">
          <div class="flex items-center justify-between">
            <div class="flex-1 min-w-0 pr-3">
              <div class="text-sm text-gray-800">{{ cfg.name }}</div>
              <div class="text-xs text-gray-400 mt-0.5">{{ cfg.description }}</div>
            </div>
            <button :class="cfg.enabled ? 'bg-[#2196F3]' : 'bg-gray-200'" class="relative w-11 h-6 rounded-full transition-colors flex-shrink-0" @click="toggleConfig(cfg)">
              <span :class="cfg.enabled ? 'translate-x-5' : 'translate-x-0.5'" class="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform"></span>
            </button>
          </div>
          <div v-if="cfg.code === 'private_message' && cfg.enabled" class="mt-3 pl-0">
            <div class="text-xs text-gray-500 mb-2">私信邮件用户组</div>
            <div class="flex gap-2 flex-wrap">
              <button v-for="opt in userGroupOptions" :key="opt.value" @click="updateUserGroup(cfg, opt.value)" :class="cfg.user_group === opt.value ? 'bg-[#2196F3] text-white' : 'bg-gray-100 text-gray-600'" class="px-3 py-1.5 rounded-lg text-xs transition-colors">{{ opt.label }}</button>
            </div>
            <div v-if="cfg.user_group === 'levels'" class="mt-3">
              <div class="text-xs text-gray-500 mb-2">选择会员等级</div>
              <div class="flex gap-2 flex-wrap">
                <button v-for="lv in membershipLevels" :key="lv.id" @click="toggleLevel(cfg, lv.id)" :class="levelSelected(cfg, lv.id) ? 'bg-[#2196F3] text-white' : 'bg-gray-100 text-gray-600'" class="px-3 py-1.5 rounded-lg text-xs transition-colors">{{ lv.name }}</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="px-3 mt-4 flex gap-3">
        <button @click="initConfigs" class="flex-1 py-3 rounded-xl border border-[#FF4757] text-[#FF4757] text-sm font-medium active:opacity-80">
          初始化配置
        </button>
        <button @click="saveAllConfigs" class="flex-1 py-3 rounded-xl bg-[#FF4757] text-white text-sm font-medium active:opacity-80" :disabled="savingAll">
          {{ savingAll ? '保存中...' : '保存全部' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'EmailPushMobile' })

const configs = ref<any[]>([])
const membershipLevels = ref<any[]>([])
const savingAll = ref(false)
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null

const showToast = (m: string, t: 'success' | 'error' = 'success') => {
  toastMsg.value = m
  toastType.value = t
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

const adminConfigs = computed(() => configs.value.filter((c: any) => c.target === 'admin'))
const userConfigs = computed(() => configs.value.filter((c: any) => c.target === 'user' || c.target === 'moderator'))

const userGroupOptions = [
  { label: '所有用户', value: 'all' },
  { label: '指定等级', value: 'levels' },
  { label: '禁用', value: 'none' },
]

const loadConfigs = async () => {
  try {
    const res: any = await request.get({ url: '/api/email-push/configs' })
    configs.value = Array.isArray(res) ? res : (res?.data || [])
  } catch (e: any) { showToast('加载配置失败', 'error') }
}

const loadMembershipLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    membershipLevels.value = Array.isArray(res) ? res : (res?.data || [])
  } catch {}
}

const toggleConfig = async (cfg: any) => {
  const prev = cfg.enabled
  cfg.enabled = cfg.enabled ? 0 : 1
  try {
    await request.post({ url: '/api/email-push/configs', data: { code: cfg.code, enabled: cfg.enabled } })
  } catch (e: any) {
    cfg.enabled = prev
    showToast('操作失败', 'error')
  }
}

const updateUserGroup = async (cfg: any, value: string) => {
  cfg.user_group = value
  if (value !== 'levels') cfg.level_ids = ''
  await saveConfig(cfg)
}

const toggleLevel = async (cfg: any, levelId: number) => {
  const ids = cfg.level_ids ? String(cfg.level_ids).split(',').filter(Boolean) : []
  const idx = ids.indexOf(String(levelId))
  if (idx >= 0) ids.splice(idx, 1)
  else ids.push(String(levelId))
  cfg.level_ids = ids.join(',')
  await saveConfig(cfg)
}

const levelSelected = (cfg: any, levelId: number) => {
  if (!cfg.level_ids) return false
  return String(cfg.level_ids).split(',').includes(String(levelId))
}

const saveConfig = async (cfg: any) => {
  try {
    await request.put({ url: `/api/email-push/configs/${cfg.code}`, data: { enabled: cfg.enabled, user_group: cfg.user_group || '', level_ids: cfg.level_ids || '' } })
  } catch {}
}

const saveAllConfigs = async () => {
  savingAll.value = true
  try {
    const data = configs.value.map((c: any) => ({ code: c.code, enabled: c.enabled }))
    await request.post({ url: '/api/email-push/configs/batch', data: { configs: data } })
    showToast('保存成功')
  } catch (e: any) { showToast('保存失败', 'error') }
  savingAll.value = false
}

const initConfigs = async () => {
  try {
    const res: any = await request.get({ url: '/api/email-push/init' })
    showToast(res?.message || '初始化完成')
    await loadConfigs()
  } catch (e: any) { showToast('初始化失败', 'error') }
}

onMounted(() => {
  loadConfigs()
  loadMembershipLevels()
})
</script>
