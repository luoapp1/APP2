<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">付费内容订单</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center justify-between mb-1">
              <span class="text-sm font-semibold text-gray-800">{{ item.userName || item.user_name || '-' }}</span>
              <span class="text-sm font-bold text-[#FF4757]">¥{{ item.amount || item.price || 0 }}</span>
            </div>
            <div class="text-xs text-gray-400">
              <span>{{ contentLabel(item) }}</span>
              <span class="ml-2">{{ payMethodLabel(item.payMethod || item.pay_method || item.paymentMethod) }}</span>
            </div>
            <div class="text-xs text-gray-400 mt-0.5">{{ item.createTime || item.create_time || item.purchaseTime || item.purchase_time }}</div>
          </div>
          <div class="flex items-center justify-between px-4 py-3">
            <span class="text-xs text-gray-400">共 {{ total }} 条</span>
            <div class="flex gap-1">
              <button :disabled="page <= 1" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="changePage(page - 1)">上一页</button>
              <span class="text-xs text-gray-500 self-center">{{ page }} / {{ Math.max(1, Math.ceil(total / 20)) }}</span>
              <button :disabled="page >= Math.ceil(total / 20)" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="changePage(page + 1)">下一页</button>
            </div>
          </div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无购买记录</span></div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'ContentPurchasesMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const payMethodMap: Record<string, string> = { alipay: '支付宝', wechat: '微信', epay: '易支付', balance: '余额', points: '积分' }
const payMethodLabel = (m: string) => payMethodMap[m] || m || '-'

const contentLabel = (item: any) => {
  const type = item.contentType || item.content_type || ''
  const name = item.contentName || item.content_name || ''
  if (type) return `${type} - ${name || '-'}`
  return name || type || '-'
}

const loading = ref(false); const list = ref<any[]>([]); const total = ref(0); const page = ref(1)
const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/admin/content/purchases', params: { current: page.value, size: 20 } })
    if (res) { list.value = res.records || []; total.value = res.total || 0 }
  } catch { }
  loading.value = false
}

const changePage = (p: number) => { page.value = p; fetchData() }

onMounted(() => fetchData())
</script>
