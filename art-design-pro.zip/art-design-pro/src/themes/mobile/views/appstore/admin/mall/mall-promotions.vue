<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">优惠活动</span>
      <button class="add-btn" @click="showAdd">+ 新增</button>
    </div>
    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>
    <div v-else class="list">
      <div v-if="promotions.length === 0" class="empty">暂无优惠活动</div>
      <div v-for="p in promotions" :key="p.id" class="item">
        <div class="item-hd">
          <span class="promo-name">{{ p.name }}</span>
          <span class="promo-status" :class="p.status === '1' ? 'on' : 'off'">{{ p.status === '1' ? '启用' : '禁用' }}</span>
        </div>
        <div class="item-body">
          <span v-if="p.type === 'discount'" class="promo-tag">立减 ¥{{ p.discountValue }}</span>
          <span v-else class="promo-tag">{{ p.discountValue }}折</span>
          <span v-if="p.minAmount > 0" class="promo-tag">满¥{{ p.minAmount }}</span>
          <span v-if="p.startTime" class="promo-tag">{{ p.startTime }} ~ {{ p.endTime }}</span>
        </div>
        <div class="item-actions">
          <button @click="editItem(p)" class="act-edit">编辑</button>
          <button @click="deleteItem(p)" class="act-del">删除</button>
        </div>
      </div>
    </div>

    <div v-if="showDialog" class="modal-overlay" @click.self="showDialog = false">
      <div class="modal">
        <div class="modal-title">{{ editId ? '编辑活动' : '新增活动' }}</div>
        <div class="field"><label>活动名称</label><input v-model="form.name" placeholder="活动名称" class="input" /></div>
        <div class="field">
          <label>优惠方式</label>
          <select v-model="form.type" class="input">
            <option value="discount">立减</option>
            <option value="percent">折扣</option>
          </select>
        </div>
        <div class="field"><label>{{ form.type === 'discount' ? '立减金额（元）' : '折扣（如8折填8）' }}</label><input v-model.number="form.discountValue" type="number" min="0" step="0.01" class="input" /></div>
        <div class="field"><label>满额可用（元）</label><input v-model.number="form.minAmount" type="number" min="0" step="0.01" class="input" /></div>
        <div class="field"><label>开始时间</label><input v-model="form.startTime" type="datetime-local" class="input" /></div>
        <div class="field"><label>结束时间</label><input v-model="form.endTime" type="datetime-local" class="input" /></div>
        <div class="field"><label>状态</label><select v-model="form.status" class="input"><option value="1">启用</option><option value="0">禁用</option></select></div>

        <div class="modal-actions">
          <button @click="showDialog = false" class="btn-cancel">取消</button>
          <button @click="save" class="btn-confirm">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

const promotions = ref<any[]>([])
const loading = ref(true)
const showDialog = ref(false)
const editId = ref(0)
const form = reactive({ name: '', type: 'discount', discountValue: 0, minAmount: 0, startTime: '', endTime: '', status: '1' })

async function loadList() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/mall/promotions' })
    promotions.value = res || []
  } catch {} finally { loading.value = false }
}

function showAdd() {
  editId.value = 0; Object.assign(form, { name: '', type: 'discount', discountValue: 0, minAmount: 0, startTime: '', endTime: '', status: '1' })
  showDialog.value = true
}

function editItem(p: any) {
  editId.value = p.id
  Object.assign(form, { name: p.name, type: p.type, discountValue: p.discountValue, minAmount: p.minAmount, startTime: p.startTime || '', endTime: p.endTime || '', status: p.status })
  showDialog.value = true
}

async function save() {
  if (!form.name.trim()) return alert('请输入活动名称')
  try {
    const data: any = { ...form, userTypes: [], gifts: [], productIds: [] }
    if (editId.value) {
      await request.put({ url: `/api/mall/promotions/${editId.value}`, data })
    } else {
      await request.post({ url: '/api/mall/promotions', data })
    }
    showDialog.value = false; loadList()
  } catch {}
}

async function deleteItem(p: any) {
  if (!confirm(`确定删除"${p.name}"？`)) return
  try { await request.del({ url: `/api/mall/promotions/${p.id}` }); loadList() } catch {}
}

onMounted(loadList)
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.add-btn { border: none; background: #FF6B6B; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; cursor: pointer; }
.loading, .empty { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }
.list { padding: 8px 0; }
.item { background: #fff; margin: 0 10px 8px; border-radius: 12px; padding: 12px; }
.item-hd { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.promo-name { font-size: 14px; font-weight: 600; color: #222; }
.promo-status { font-size: 10px; padding: 2px 8px; border-radius: 4px; font-weight: 600; }
.promo-status.on { background: #E8F5E9; color: #2E7D32; }
.promo-status.off { background: #f5f5f5; color: #999; }
.item-body { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.promo-tag { font-size: 10px; padding: 2px 8px; border-radius: 12px; background: #EEF2FF; color: #6366F1; }
.item-actions { display: flex; gap: 8px; }
.act-edit { border: none; background: #E3F2FD; color: #1565C0; padding: 4px 10px; border-radius: 6px; font-size: 11px; cursor: pointer; }
.act-del { border: none; background: #FFEBEE; color: #C62828; padding: 4px 10px; border-radius: 6px; font-size: 11px; cursor: pointer; }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100; }
.modal { background: #fff; width: 100%; max-width: 500px; border-radius: 16px 16px 0 0; padding: 20px; max-height: 80vh; overflow-y: auto; }
.modal-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
.field { margin-bottom: 10px; }
.field label { display: block; font-size: 12px; color: #666; margin-bottom: 4px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; background: #fff; }
.modal-actions { display: flex; gap: 10px; margin-top: 16px; }
.btn-cancel { flex: 1; padding: 10px; border: 1px solid #ddd; background: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
.btn-confirm { flex: 1; padding: 10px; border: none; background: #FF6B6B; color: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
</style>
