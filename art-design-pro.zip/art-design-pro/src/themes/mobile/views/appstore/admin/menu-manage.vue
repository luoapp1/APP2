<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">菜单管理</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="mx-3 mt-3 space-y-2.5">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>

        <template v-else-if="groupedList.length > 0">
          <div v-for="(group, gIdx) in groupedList" :key="group.id" class="bg-white rounded-2xl overflow-hidden shadow-[0_1px_4px_rgba(0,0,0,0.04)] menu-item" :style="{ animationDelay: gIdx * 60 + 'ms' }">
            <!-- Group Header -->
            <div class="flex items-center gap-3 px-4 py-3.5 cursor-pointer select-none active:bg-gray-50 transition-colors" @click="group.expanded = !group.expanded">
              <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" :style="{ background: group.accentColor + '14' }">
                <svg v-if="group.iconSvg" class="w-4.5 h-4.5" :style="{ color: group.accentColor }" fill="currentColor" viewBox="0 0 24 24"><path :d="group.iconSvg"/></svg>
                <svg v-else class="w-4.5 h-4.5" :style="{ color: group.accentColor }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2">
                  <span class="text-sm font-semibold text-gray-800">{{ group.title }}</span>
                  <span class="text-[10px] font-medium" :style="{ color: group.accentColor }">({{ group.allChildren.length }})</span>
                </div>
                <div class="text-[11px] text-gray-400 font-mono mt-0.5">{{ group.path || '/' }}</div>
              </div>
              <div class="flex items-center gap-1 flex-shrink-0" @click.stop>
                <button class="w-7 h-7 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(group, -1, gIdx)">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>
                </button>
                <button class="w-7 h-7 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(group, 1, gIdx)">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <button class="w-7 h-7 rounded-lg flex items-center justify-center bg-blue-50 text-blue-500 active:bg-blue-100" @click="openDialog(group)">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                </button>
                <button class="w-7 h-7 rounded-lg flex items-center justify-center bg-red-50 text-red-400 active:bg-red-100" @click="confirmDelete(group)">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>
              </div>
              <svg class="w-4 h-4 text-gray-400 flex-shrink-0 transition-transform duration-200 ml-1" :class="{ 'rotate-90': group.expanded }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </div>

            <!-- Children -->
            <div v-if="group.expanded" class="border-t border-gray-50">
              <template v-for="(child, cIdx) in group.allChildren" :key="child.uid">
                <!-- Child with auth buttons -->
                <template v-if="child.children.length > 0">
                  <div class="flex items-center gap-2.5 pl-6 pr-2 py-3 border-b border-gray-50/60 active:bg-gray-50 transition-colors cursor-pointer" @click="child.expanded = !child.expanded">
                    <div class="w-0.5 h-8 rounded-full flex-shrink-0" :style="{ background: child.accentColor }" />
                    <div class="flex-1 min-w-0">
                      <div class="flex items-center gap-1.5">
                        <span class="text-[13px] font-medium text-gray-700 truncate">{{ child.title }}</span>
                        <span class="text-[10px] px-1.5 py-px rounded-md font-medium" :style="{ background: child.accentColor + '12', color: child.accentColor }">{{ child.typeText }}</span>
                        <span class="text-[10px] text-gray-400">({{ child.children.length }})</span>
                      </div>
                      <div class="flex items-center gap-2 mt-0.5">
                        <span class="text-[11px] text-gray-400 font-mono truncate">{{ child.path || '/' }}</span>
                        <span class="w-1.5 h-1.5 rounded-full flex-shrink-0" :class="child.enabled !== false ? 'bg-emerald-400' : 'bg-gray-300'" />
                        <span class="text-[10px]" :class="child.enabled !== false ? 'text-emerald-500' : 'text-gray-400'">{{ child.enabled !== false ? '启用' : '禁用' }}</span>
                      </div>
                    </div>
                    <div class="flex items-center gap-0.5 flex-shrink-0" @click.stop>
                      <button class="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(child, -1, cIdx, group)">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>
                      </button>
                      <button class="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(child, 1, cIdx, group)">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                      </button>
                      <button class="w-6 h-6 rounded-lg flex items-center justify-center bg-blue-50 text-blue-500 active:bg-blue-100" @click="openDialog(child)">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                      </button>
                      <button class="w-6 h-6 rounded-lg flex items-center justify-center bg-red-50 text-red-400 active:bg-red-100" @click="confirmDelete(child)">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                      </button>
                    </div>
                    <svg class="w-3.5 h-3.5 text-gray-400 flex-shrink-0 transition-transform duration-200 ml-0.5" :class="{ 'rotate-90': child.expanded }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                  </div>
                  <!-- Auth buttons -->
                  <div v-if="child.expanded" class="border-t border-gray-50/40">
                    <div v-for="auth in child.children" :key="auth.uid" class="flex items-center gap-2 pl-10 pr-3 py-2.5 border-b border-red-50/40 last:border-b-0 active:bg-red-50/30 transition-colors cursor-pointer" @click="openDialog(auth)">
                      <div class="w-0.5 h-7 rounded-full flex-shrink-0" style="background:#EF4444" />
                      <svg class="w-3 h-3 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                      <span class="text-xs text-gray-600 flex-1">{{ auth.title }}</span>
                      <span class="text-[10px] text-gray-400 font-mono">{{ auth.meta?.authMark || '' }}</span>
                      <div class="flex items-center gap-0.5 flex-shrink-0 ml-1" @click.stop>
                        <button class="w-5 h-5 rounded flex items-center justify-center bg-blue-50 text-blue-500 active:bg-blue-100" @click="openDialog(auth)">
                          <svg class="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </template>
                <!-- Plain child (no auth buttons) -->
                <div v-else class="flex items-center gap-2.5 pl-6 pr-3 py-3 border-b border-gray-50/60 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer" @click="child.isAuthButton ? openDialog(child) : openDialog(child)">
                  <div class="w-0.5 h-8 rounded-full flex-shrink-0" :style="{ background: child.isAuthButton ? '#EF4444' : child.accentColor }" />
                  <svg v-if="child.isAuthButton" class="w-3.5 h-3.5 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-1.5">
                      <span class="text-[13px] font-medium text-gray-700 truncate">{{ child.title }}</span>
                      <span class="text-[10px] px-1.5 py-px rounded-md font-medium" :style="{ background: (child.isAuthButton ? '#EF4444' : child.accentColor) + '12', color: child.isAuthButton ? '#EF4444' : child.accentColor }">{{ child.isAuthButton ? '按钮' : child.typeText }}</span>
                    </div>
                    <div class="flex items-center gap-2 mt-0.5">
                      <span class="text-[11px] text-gray-400 font-mono truncate">{{ child.isAuthButton ? (child.meta?.authMark || '') : (child.path || '/') }}</span>
                      <span v-if="!child.isAuthButton" class="w-1.5 h-1.5 rounded-full flex-shrink-0" :class="child.enabled !== false ? 'bg-emerald-400' : 'bg-gray-300'" />
                      <span v-if="!child.isAuthButton" class="text-[10px]" :class="child.enabled !== false ? 'text-emerald-500' : 'text-gray-400'">{{ child.enabled !== false ? '启用' : '禁用' }}</span>
                    </div>
                  </div>
                  <div class="flex items-center gap-0.5 flex-shrink-0" @click.stop>
                    <button v-if="!child.isAuthButton" class="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(child, -1, cIdx, group)">
                      <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>
                    </button>
                    <button v-if="!child.isAuthButton" class="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 active:bg-gray-100" @click="moveItem(child, 1, cIdx, group)">
                      <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <button class="w-6 h-6 rounded-lg flex items-center justify-center bg-blue-50 text-blue-500 active:bg-blue-100" @click="openDialog(child)">
                      <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    </button>
                    <button class="w-6 h-6 rounded-lg flex items-center justify-center bg-red-50 text-red-400 active:bg-red-100" @click="confirmDelete(child)">
                      <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                  </div>
                </div>
              </template>
              <div v-if="group.allChildren.length === 0" class="text-center text-xs text-gray-400 py-4">暂无子项</div>
            </div>
          </div>
          <div class="text-center text-xs text-gray-400 py-4">共 {{ groupedList.length }} 个顶级菜单</div>
        </template>

        <div v-else class="bg-white rounded-2xl flex flex-col items-center py-16 text-gray-400">
          <svg class="w-12 h-12 mb-3 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 6h16M4 12h16M4 18h7"/></svg>
          <span class="text-sm">暂无菜单</span>
        </div>
      </div>

      <button class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20 active:scale-95 transition-transform" @click="openAddTopLevel">+</button>
    </div>

    <!-- Delete Confirm -->
    <div v-if="deleteVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="deleteVisible = false">
      <div class="absolute inset-0 bg-black/50"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[80vw] overflow-hidden">
        <div class="p-5 text-center">
          <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">确认删除</div>
          <div class="text-xs text-gray-500">确定要删除「{{ deleteTarget?.title || deleteTarget?.name || '' }}」吗？此操作不可撤销。</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="deleteVisible = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-semibold border-l border-gray-100 active:bg-red-50" @click="doDelete">删除</button>
        </div>
      </div>
    </div>

    <!-- Add/Edit Dialog -->
    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center" @click.self="dialogVisible = false">
      <div class="absolute inset-0 bg-black/40" @click="dialogVisible = false"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-[90vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center active:bg-gray-200" @click="dialogVisible = false">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <span class="text-base font-bold text-gray-800">{{ dialogTitle }}</span>
          <button class="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF4757] to-[#FF6B81] text-white text-sm font-medium active:opacity-85 shadow-sm shadow-red-200" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <!-- 权限按钮编辑模式 -->
          <template v-if="dialogMode === 'button'">
            <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
              <div class="text-xs font-semibold text-red-500 uppercase tracking-wide">权限按钮设置</div>
              <div class="flex items-center gap-2 text-[11px] text-gray-400">
                <span>所属菜单：</span>
                <span class="font-medium text-gray-700">{{ form.parentMetaTitle || '-' }}</span>
                <span class="text-gray-300">|</span>
                <span class="font-mono text-gray-500">{{ form.parentPath || '/' }}</span>
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">按钮名称 *</label>
                <input v-model="form.authName" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：通过" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">权限标识 *</label>
                <input v-model="form.authLabel" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：approve" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">排序</label>
                <input v-model.number="form.authSort" type="number" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" />
              </div>
            </div>
          </template>

          <!-- 菜单编辑模式 -->
          <template v-else>
          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">基本信息</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">菜单名称 *</label>
              <input v-model="form.name" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：用户管理" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">权限标识</label>
              <input v-model="form.label" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：User" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">分类</label>
              <input v-model="form.category" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：用户模块、内容模块" />
            </div>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">路由与组件</div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">路由路径 *</label>
                <input v-model="form.path" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="/dashboard" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">排序</label>
                <input v-model.number="form.sortOrder" type="number" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" />
              </div>
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">组件路径</label>
              <input v-model="form.component" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="/index/index 或留空" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">图标名称</label>
              <input v-model="form.icon" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：ri:user-line" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">外部链接</label>
              <input v-model="form.link" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="https://..." />
            </div>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">移动端设置</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">移动端路径</label>
              <input v-model="form.mobilePath" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="/appstore/user-manage" />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">图标背景色</label>
                <input v-model="form.iconBg" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="#4ECDC4" />
              </div>
              <div>
                <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">图标 SVG</label>
                <input v-model="form.iconSvg" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="SVG path d 值" />
              </div>
            </div>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">其他设置</div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">文本徽章</label>
              <input v-model="form.showTextBadge" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="如：New、Hot" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">激活路径</label>
              <input v-model="form.activePath" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="高亮显示的父级菜单路径" />
            </div>
            <div>
              <label class="text-[11px] text-gray-400 mb-1.5 block font-medium">角色权限（回车添加）</label>
              <div class="flex flex-wrap gap-1.5 mb-1.5">
                <span v-for="(r, i) in form.roles" :key="i" class="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 bg-[#FF4757]/10 text-[#FF4757] rounded-full">
                  {{ r }}
                  <button class="w-3 h-3 rounded-full flex items-center justify-center active:bg-red-100" @click="form.roles.splice(i, 1)">&times;</button>
                </span>
              </div>
              <input v-model="roleInput" class="w-full h-10 px-3 text-sm bg-white rounded-xl border-none outline-none" placeholder="输入后回车添加" @keydown.enter.prevent="addRole" />
            </div>
          </div>

          <div class="bg-[#f5f6f8] rounded-2xl p-4 space-y-3">
            <div class="text-xs font-semibold text-gray-500 uppercase tracking-wide">开关选项</div>
            <div v-for="sw in switches" :key="sw.key" class="flex items-center justify-between">
              <span class="text-xs text-gray-500 font-medium">{{ sw.label }}</span>
              <button class="w-10 h-6 rounded-full transition-colors relative" :class="form[sw.key] ? 'bg-[#FF4757]' : 'bg-gray-200'" @click="form[sw.key] = !form[sw.key]">
                <span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form[sw.key] ? 'translate-x-4.5' : 'left-0.5'" />
              </button>
            </div>
          </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { fetchGetMenuList, fetchSaveMenu, fetchDeleteMenu } from '@/api/system-manage'

defineOptions({ name: 'MenuManageMobile' })

const fmtTitle = (title: string, name: string) => {
  const t = title || name || ''
  if (t.startsWith('menus.')) return name || t.split('.').pop() || t
  return t
}

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false)

const getAccentColor = (item: any) => {
  if (item.meta?.isAuthButton) return '#EF4444'
  if (item.children?.length) return '#6366F1'
  if (item.meta?.link && item.meta?.isIframe) return '#14B8A6'
  if (item.path) return '#3B82F6'
  if (item.meta?.link) return '#F59E0B'
  return '#6B7280'
}

const getTypeText = (item: any) => {
  if (item.meta?.isAuthButton) return '按钮'
  if (item.children?.length) return '目录'
  if (item.meta?.link && item.meta?.isIframe) return '内嵌'
  if (item.path) return '菜单'
  if (item.meta?.link) return '外链'
  return '未知'
}

interface GroupItem {
  id: number
  uid: string
  name: string
  title: string
  path: string
  accentColor: string
  typeText: string
  iconSvg: string
  expanded: boolean
  enabled: boolean
  sortOrder: number
  parentId: number
  meta?: any
  allChildren: TreeItem[]
  [key: string]: any
}

interface TreeItem {
  uid: string
  id: number
  parentId: number
  name: string
  title: string
  path: string
  component: string
  accentColor: string
  typeText: string
  expanded: boolean
  enabled: boolean
  sortOrder: number
  isAuthButton: boolean
  iconSvg: string
  meta: any
  children: TreeItem[]
  [key: string]: any
}

const buildChildren = (childItems: any[], parentId: number): TreeItem[] => {
  return childItems.map(child => {
    const authChildren: TreeItem[] = []
    if (child.meta?.authList?.length) {
      for (const auth of child.meta.authList) {
        authChildren.push({
          uid: 'a-' + child.id + '-' + auth.authMark,
          id: child.id,
          parentId: child.id,
          name: auth.title,
          title: auth.title,
          path: '',
          component: '',
          expanded: false,
          enabled: true,
          sortOrder: 0,
          isAuthButton: true,
          accentColor: '#EF4444',
          typeText: '按钮',
          iconSvg: '',
          meta: { isAuthButton: true, authMark: auth.authMark, title: auth.title },
          children: []
        } as TreeItem)
      }
    }
    return {
      uid: 'c-' + child.id,
      id: child.id,
      parentId,
      name: child.name || '',
      title: fmtTitle(child.meta?.title || '', child.name || ''),
      path: child.path || '',
      component: child.component || '',
      expanded: false,
      enabled: child.enabled !== false,
      sortOrder: child.sortOrder || (child.meta?.sortOrder ?? 1),
      isAuthButton: false,
      accentColor: getAccentColor(child),
      typeText: getTypeText(child),
      iconSvg: child.iconSvg || child.meta?.iconSvg || '',
      meta: child.meta || {},
      children: authChildren
    } as TreeItem
  })
}

const buildGroupedList = (items: any[]): GroupItem[] => {
  const groups: GroupItem[] = []
  for (const item of items) {
    const title = fmtTitle(item.meta?.title || '', item.name || '')

    const allChildren: TreeItem[] = []
    if (item.children?.length) {
      allChildren.push(...buildChildren(item.children, item.id))
    }
    if (item.meta?.authList?.length) {
      for (const auth of item.meta.authList) {
        allChildren.push({
          uid: 'a-' + item.id + '-' + auth.authMark,
          id: item.id,
          parentId: item.id,
          name: auth.title,
          title: auth.title,
          path: '',
          component: '',
          expanded: false,
          enabled: true,
          sortOrder: 0,
          isAuthButton: true,
          accentColor: '#EF4444',
          typeText: '按钮',
          iconSvg: '',
          meta: { isAuthButton: true, authMark: auth.authMark, title: auth.title },
          children: []
        } as TreeItem)
      }
    }

    groups.push({
      ...item,
      uid: 'g-' + item.id,
      title,
      accentColor: getAccentColor(item),
      typeText: getTypeText(item),
      iconSvg: item.iconSvg || item.meta?.iconSvg || '',
      expanded: false,
      allChildren
    } as GroupItem)
  }
  return groups
}

const groupedList = ref<GroupItem[]>([])

const fetchData = async () => {
  loading.value = true
  try {
    const raw = await fetchGetMenuList() || []
    groupedList.value = buildGroupedList(raw)
  } catch { groupedList.value = [] }
  loading.value = false
}

const dialogVisible = ref(false); const editId = ref<number | null>(null)
const dialogMode = ref<'menu' | 'button'>('menu')
const isAddChild = ref(false); const currentParent = ref<any>(null)
const roleInput = ref('')
const formDefault = () => ({
  name: '', path: '', label: '', component: '', icon: '', link: '',
  sortOrder: 1, isHidden: false, isFullPage: false, isKeepAlive: true,
  isFixedTab: false, enabled: true, isIframe: false, showBadge: false,
  isHideTab: false, parentId: 0
})
const form = reactive<Record<string, any>>({
  ...formDefault(),
  mobilePath: '', iconBg: '#4ECDC4', iconSvg: '', category: '',
  showTextBadge: '', activePath: '', roles: [] as string[]
})

const dialogTitle = computed(() => {
  if (dialogMode.value === 'button') return editId.value ? '编辑按钮' : '新增按钮'
  if (isAddChild.value) return '添加子菜单'
  return editId.value ? '编辑菜单' : '新增顶级菜单'
})

const switches = [
  { key: 'enabled', label: '启用' },
  { key: 'isKeepAlive', label: '页面缓存' },
  { key: 'isHidden', label: '隐藏菜单' },
  { key: 'isIframe', label: '是否内嵌' },
  { key: 'showBadge', label: '显示徽章' },
  { key: 'isFixedTab', label: '固定标签页' },
  { key: 'isHideTab', label: '标签隐藏' },
  { key: 'isFullPage', label: '全屏页面' }
]

const addRole = () => {
  const val = roleInput.value.trim()
  if (val && !form.roles.includes(val)) form.roles.push(val)
  roleInput.value = ''
}

const openAddTopLevel = () => {
  editId.value = null
  isAddChild.value = false
  currentParent.value = null
  resetForm()
  dialogVisible.value = true
}

const openDialog = (item: any) => {
  if (item.isAuthButton || item.meta?.isAuthButton) {
    dialogMode.value = 'button'
    const parentId = item.parentId || item.id
    const parent = groupedList.value.find(g => g.id === parentId)
    form.parentId = parentId
    form.authName = item.meta?.authMark ? item.title || item.meta?.title : ''
    form.authLabel = item.meta?.authMark || ''
    form.authSort = item.sortOrder || 1
    if (parent) {
      form.parentName = parent.name || ''
      form.parentPath = parent.path || ''
      form.parentAuthList = parent.meta?.authList || []
      form.parentMetaTitle = parent.meta?.title || parent.name || ''
    }
    editId.value = item.uid?.startsWith('a-') ? parentId : item.id
    roleInput.value = ''
    dialogVisible.value = true
    return
  }

  dialogMode.value = 'menu'
  editId.value = item.id || null
  isAddChild.value = false
  if (item.id) {
    form.name = item.name || ''
    form.path = item.path || ''
    form.label = item.meta?.title || ''
    form.component = item.component || ''
    form.icon = item.meta?.icon || item.icon || ''
    form.link = item.redirect || item.meta?.link || ''
    form.sortOrder = item.sortOrder || (item.meta?.sortOrder ?? 1)
    form.isHidden = item.meta?.isHide || false
    form.isFullPage = item.meta?.isFullPage || false
    form.isKeepAlive = item.meta?.keepAlive ?? true
    form.isFixedTab = item.meta?.fixedTab || false
    form.enabled = item.enabled !== false
    form.parentId = item.parentId ?? 0
    form.mobilePath = item.mobilePath || ''
    form.iconBg = item.iconBg || '#4ECDC4'
    form.iconSvg = item.iconSvg || ''
    form.category = item.category || ''
    form.roles = item.meta?.roles || []
    form.showTextBadge = item.showTextBadge || ''
    form.activePath = item.activePath || ''
    form.isIframe = item.meta?.isIframe || false
    form.showBadge = item.meta?.showBadge || false
    form.isHideTab = item.meta?.isHideTab || false
  } else {
    resetForm()
  }
  roleInput.value = ''
  dialogVisible.value = true
}

const resetForm = () => {
  const d = formDefault()
  Object.keys(d).forEach(k => { form[k] = (d as any)[k] })
  form.mobilePath = ''; form.iconBg = '#4ECDC4'; form.iconSvg = ''; form.category = ''
  form.showTextBadge = ''; form.activePath = ''; form.roles = []
  roleInput.value = ''
}

const saveItem = async () => {
  try {
    if (dialogMode.value === 'button') {
      const parentMenu = groupedList.value.find(g => g.id === form.parentId)
      if (!parentMenu) { showToast('未找到所属菜单', 'error'); return }

      const authList: any[] = [...(parentMenu.meta?.authList || [])]
      const existingIdx = authList.findIndex((a: any) => a.authMark === form.authLabel)

      const newAuth = {
        title: form.authName,
        authMark: form.authLabel,
        sortOrder: form.authSort || 1,
        id: Date.now().toString()
      }

      if (existingIdx >= 0) {
        authList[existingIdx] = { ...authList[existingIdx], ...newAuth }
      } else {
        authList.push(newAuth)
      }

      const parentPayload: Record<string, unknown> = {
        id: parentMenu.id,
        parentId: parentMenu.parentId || 0,
        name: parentMenu.name || '',
        path: parentMenu.path || '',
        title: parentMenu.meta?.title || parentMenu.name || '',
        component: parentMenu.component || '',
        icon: parentMenu.meta?.icon || '',
        sortOrder: parentMenu.sortOrder || 1,
        isHidden: parentMenu.meta?.isHide || false,
        isFullPage: parentMenu.meta?.isFullPage || false,
        isKeepAlive: parentMenu.meta?.keepAlive ?? true,
        isFixedTab: parentMenu.meta?.fixedTab || false,
        enabled: parentMenu.enabled !== false,
        redirect: parentMenu.redirect || parentMenu.meta?.link || '',
        roles: parentMenu.meta?.roles || null,
        authList,
        mobilePath: parentMenu.mobilePath || '',
        iconBg: parentMenu.iconBg || '#4ECDC4',
        iconSvg: parentMenu.iconSvg || '',
        category: parentMenu.category || ''
      }

      await fetchSaveMenu(parentPayload)
      showToast('按钮保存成功')
      dialogVisible.value = false
      fetchData()
      return
    }

    const payload: Record<string, unknown> = {
      name: form.name,
      path: form.path,
      title: form.label || form.name,
      component: form.component || '',
      icon: form.icon || '',
      sortOrder: form.sortOrder || 1,
      isHidden: form.isHidden || false,
      isFullPage: form.isFullPage || false,
      isKeepAlive: form.isKeepAlive !== false,
      isFixedTab: form.isFixedTab || false,
      enabled: form.enabled !== false,
      redirect: form.link || '',
      roles: form.roles && form.roles.length > 0 ? form.roles : null,
      authList: null,
      mobilePath: form.mobilePath || '',
      iconBg: form.iconBg || '#4ECDC4',
      iconSvg: form.iconSvg || '',
      category: form.category || ''
    }
    if (editId.value) payload.id = editId.value
    payload.parentId = editId.value ? form.parentId : 0

    if (payload.id && Number(payload.parentId) === Number(payload.id)) {
      showToast('不能将菜单设置为自己的子菜单', 'error')
      return
    }
    await fetchSaveMenu(payload)
    showToast(editId.value ? '更新成功' : '新增成功')
    dialogVisible.value = false
    fetchData()
  } catch { showToast('保存失败', 'error') }
}

const deleteVisible = ref(false); const deleteTarget = ref<any>(null)
const confirmDelete = (item: any) => { deleteTarget.value = item; deleteVisible.value = true }
const doDelete = async () => {
  if (!deleteTarget.value?.id) return
  deleteVisible.value = false
  try {
    await fetchDeleteMenu(deleteTarget.value.id)
    showToast('删除成功')
    fetchData()
  } catch { showToast('删除失败', 'error') }
}

const moveItem = async (item: TreeItem | GroupItem, direction: number, idx: number, parent?: GroupItem) => {
  const siblings = parent ? parent.allChildren : groupedList.value
  const targetIdx = idx + direction
  if (targetIdx < 0 || targetIdx >= siblings.length) return

  const currentSort = item.sortOrder || idx + 1
  const target = siblings[targetIdx]
  const targetSort = target.sortOrder || targetIdx + 1

  const mkPayload = (src: any, sort: number) => ({
    id: src.id,
    parentId: src.parentId || 0,
    name: src.name || '',
    path: src.path || '',
    title: src.meta?.title || src.title || src.name || '',
    component: src.component || '',
    icon: src.meta?.icon || '',
    sortOrder: sort,
    isHidden: src.meta?.isHide || false,
    isFullPage: src.meta?.isFullPage || false,
    isKeepAlive: src.meta?.keepAlive ?? true,
    isFixedTab: src.meta?.fixedTab || false,
    enabled: src.enabled !== false,
    redirect: src.redirect || src.meta?.link || '',
    roles: src.meta?.roles || null,
    authList: src.meta?.authList || null
  })

  try {
    await fetchSaveMenu(mkPayload(item, targetSort))
    await fetchSaveMenu(mkPayload(target, currentSort))
    fetchData()
  } catch { showToast('排序失败', 'error') }
}

onMounted(() => fetchData())
</script>

<style scoped>
.menu-item {
  animation: menuFadeIn 0.4s ease-out both;
}

@keyframes menuFadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
