<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">卡密管理</span>
    </div>

    <div class="flex-1 overflow-y-auto pb-6">
      <!-- 操作按钮 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="flex gap-2 mb-2">
          <button class="flex-1 h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="showGenerateDialog('single')">生成卡密</button>
          <button class="flex-1 h-10 bg-[#10B981] text-white text-sm rounded-lg font-medium active:opacity-80" @click="showGenerateDialog('batch')">批量生成</button>
        </div>
        <div class="flex gap-2">
          <button class="flex-1 h-9 bg-[#6366F1] text-white text-xs rounded-lg font-medium active:opacity-80" @click="exportExcel">导出Excel</button>
          <button class="flex-1 h-9 bg-[#F59E0B] text-white text-xs rounded-lg font-medium active:opacity-80" @click="triggerImport">导入Excel</button>
          <input ref="fileInput" type="file" accept=".xlsx,.xls" class="hidden" @change="handleImport" />
        </div>
      </div>

      <!-- 搜索 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="flex gap-2 mb-2">
          <input v-model="searchForm.cardNo" type="text" placeholder="卡号" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" @keyup.enter="handleSearch" />
          <select v-model="searchForm.type" class="h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600">
            <option value="">全部类型</option>
            <option value="membership">会员卡</option>
            <option value="points">积分卡</option>
            <option value="experience">经验卡</option>
            <option value="balance">余额卡</option>
            <option value="makeup">补签卡</option>
          </select>
        </div>
        <div class="flex gap-2">
          <select v-model="searchForm.status" class="flex-1 h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600">
            <option value="">全部状态</option>
            <option value="0">未使用</option>
            <option value="1">已使用</option>
          </select>
          <button class="h-9 px-4 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="handleSearch">搜索</button>
          <button class="h-9 px-3 bg-white text-gray-500 text-sm rounded-lg border border-gray-200 active:opacity-80" @click="resetSearch">重置</button>
        </div>
      </div>

      <!-- 分页设置 -->
      <div class="bg-white mx-3 mt-3 rounded-xl px-4 py-2 flex items-center justify-between">
        <div class="flex items-center gap-2 text-xs text-gray-400">
          <span>每页</span>
          <select v-model.number="pagination.size" class="h-7 px-1 text-xs bg-[#f5f6f8] rounded border-none outline-none text-gray-600" @change="handleSizeChange">
            <option :value="10">10</option>
            <option :value="15">15</option>
            <option :value="20">20</option>
            <option :value="30">30</option>
            <option :value="50">50</option>
          </select>
          <span>条</span>
        </div>
        <span class="text-xs text-gray-400">共 {{ pagination.total }} 条</span>
      </div>

      <!-- 列表 -->
      <div class="bg-white mx-3 mt-1 rounded-xl">
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" />
        </div>

        <template v-else-if="data.length > 0">
          <div v-for="item in data" :key="item.id" class="px-4 py-3 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.cardNo }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="typeTagClass(item.type)">{{ typeText(item.type) }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-500'">{{ item.status === '1' ? '已使用' : '未使用' }}</span>
                </div>
                <div class="text-xs text-gray-400 space-y-0.5">
                  <div>密码: {{ item.password }} | 面值: {{ formatValue(item) }}</div>
                  <div>创建者: {{ item.createBy || '-' }}</div>
                  <div v-if="item.redeemBy">使用者: {{ item.redeemBy }} | {{ item.redeemTime }}</div>
                  <div>创建: {{ item.createTime }}</div>
                </div>
              </div>
              <div class="flex flex-col gap-1 ml-2 flex-shrink-0">
                <button class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click="copyCardKey(item)">复制</button>
                <button v-if="item.status === '0'" class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click="deleteCardKey(item)">删除</button>
              </div>
            </div>
          </div>

          <!-- 分页 -->
          <div class="flex items-center justify-center gap-3 py-3">
            <button :disabled="pagination.current <= 1" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current - 1)">上一页</button>
            <span class="text-xs text-gray-400">{{ pagination.current }}/{{ totalPages }}</span>
            <button :disabled="pagination.current >= totalPages" class="h-8 px-3 text-xs rounded-lg bg-white text-gray-500 shadow-sm disabled:opacity-30 active:opacity-70" @click="goPage(pagination.current + 1)">下一页</button>
          </div>
          <div class="text-center text-xs text-gray-400 pb-4">共 {{ pagination.total }} 条 / 第 {{ pagination.current }} 页</div>
        </template>

        <div v-else class="flex flex-col items-center py-12 text-gray-400">
          <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/></svg>
          <span class="text-sm">暂无卡密数据</span>
        </div>
      </div>
    </div>

    <!-- 生成卡密弹窗 -->
    <div v-if="generateVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="generateVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 flex-shrink-0 border-b border-gray-100">
          <button class="text-gray-400" @click="generateVisible = false">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
          <span class="text-sm font-bold text-gray-800">{{ generateMode === 'batch' ? '批量生成卡密' : '生成卡密' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="submitGenerate">生成</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div>
            <label class="text-xs text-gray-500 mb-1 block">卡密类型</label>
            <select v-model="genForm.type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" @change="onGenTypeChange">
              <option value="membership">会员卡</option>
              <option value="points">积分卡</option>
              <option value="experience">经验卡</option>
              <option value="balance">余额卡</option>
              <option value="makeup">补签卡</option>
            </select>
          </div>

          <template v-if="genForm.type === 'membership'">
            <div>
              <label class="text-xs text-gray-500 mb-1 block">会员等级</label>
              <select v-model="genForm.targetId" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none">
                <option v-for="lv in levelList" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
              </select>
            </div>
            <div>
              <label class="text-xs text-gray-500 mb-1 block">有效时长</label>
              <div class="flex gap-2">
                <input v-model.number="genForm.duration" type="number" min="1" class="flex-1 h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
                <select v-model="genForm.durationUnit" class="h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" style="width:80px">
                  <option value="day">天</option>
                  <option value="week">周</option>
                  <option value="month">月</option>
                  <option value="year">年</option>
                </select>
              </div>
            </div>
          </template>

          <div v-if="genForm.type === 'makeup'">
            <label class="text-xs text-gray-500 mb-1 block">补签天数</label>
            <input v-model.number="genForm.value" type="number" min="1" max="365" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
            <span class="text-[10px] text-gray-400 mt-1">用户可使用补签卡补签最近1次错过的签到</span>
          </div>

          <div v-if="genForm.type !== 'makeup' && genForm.type !== 'membership'">
            <label class="text-xs text-gray-500 mb-1 block">{{ genForm.type === 'points' ? '积分数额' : genForm.type === 'experience' ? '经验数额' : '余额数额' }}</label>
            <input v-model.number="genForm.value" type="number" min="1" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>

          <div v-if="genForm.type !== 'makeup'">
            <label class="text-xs text-gray-500 mb-1 block">额外积分</label>
            <input v-model.number="genForm.extraPoints" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>
          <div v-if="genForm.type !== 'makeup'">
            <label class="text-xs text-gray-500 mb-1 block">额外经验</label>
            <input v-model.number="genForm.extraExperience" type="number" min="0" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>

          <div>
            <label class="text-xs text-gray-500 mb-1 block">生成数量</label>
            <input v-model.number="genForm.count" type="number" min="1" :max="generateMode === 'batch' ? 500 : 100" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>

          <div v-if="generateMode === 'batch'">
            <label class="text-xs text-gray-500 mb-1 block">前缀</label>
            <input v-model="genForm.prefix" type="text" placeholder="例如: VIP2024" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" />
          </div>
        </div>
      </div>
    </div>

    <!-- 顶部提示 -->
    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import request from '@/utils/http'
import * as XLSX from 'xlsx'
import FileSaver from 'file-saver'

defineOptions({ name: 'CardKeyMobile' })

interface CardKeyItem {
  id: number
  cardNo: string
  password: string
  type: string
  targetId: number
  targetName: string
  value: number
  extraPoints: number
  extraExperience: number
  extraBalance: number
  duration: number
  durationUnit: string
  status: string
  createBy: string
  createTime: string
  redeemBy: string
  redeemTime: string
}

const loading = ref(false)
const data = ref<CardKeyItem[]>([])
const pagination = reactive({ current: 1, size: 15, total: 0 })
const totalPages = computed(() => Math.max(1, Math.ceil(pagination.total / pagination.size)))
const fileInput = ref<HTMLInputElement>()

const searchForm = reactive({ cardNo: '', type: '', status: '' })

const typeMap: Record<string, string> = { membership: '会员卡', points: '积分卡', experience: '经验卡', balance: '余额卡', makeup: '补签卡' }
const typeColorMap: Record<string, string> = { membership: 'bg-blue-50 text-blue-600', points: 'bg-green-50 text-green-600', experience: 'bg-orange-50 text-orange-600', balance: 'bg-red-50 text-red-600', makeup: 'bg-purple-50 text-purple-600' }

const typeText = (t: string) => typeMap[t] || t
const typeTagClass = (t: string) => typeColorMap[t] || 'bg-gray-100 text-gray-500'

const formatValue = (row: CardKeyItem) => {
  if (row.type === 'points') return `${row.value}积分`
  if (row.type === 'experience') return `${row.value}经验`
  if (row.type === 'makeup') return `补签${row.value || 1}天`
  if (row.type === 'balance') return `${row.value || row.extraBalance || 0}元`
  return row.targetName || '-'
}

// Toast
const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: ReturnType<typeof setTimeout> | null = null
const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, 2000)
}

// Copy
const copyCardKey = async (item: CardKeyItem) => {
  const text = `卡号: ${item.cardNo}\n密码: ${item.password}`
  try {
    await navigator.clipboard.writeText(text)
    showToast('已复制')
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    document.body.removeChild(ta)
    showToast('已复制')
  }
}

// Export
const exportExcel = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/cardkey/list', params: { current: 1, size: 99999 } })
    const list = res?.records || res?.data?.records || []
    if (list.length === 0) { showToast('暂无数据可导出', 'error'); return }
    const rows = list.map((item: CardKeyItem) => ({
      '卡号': item.cardNo,
      '密码': item.password,
      '类型': typeText(item.type),
      '面值': formatValue(item),
      '额外积分': item.extraPoints || 0,
      '额外经验': item.extraExperience || 0,
      '额外余额': item.extraBalance || 0,
      '时长': item.duration > 0 ? `${item.duration}${item.durationUnit || ''}` : '-',
      '状态': item.status === '1' ? '已使用' : '未使用',
      '创建者': item.createBy || '-',
      '创建时间': item.createTime || '',
      '使用者': item.redeemBy || '',
      '使用时间': item.redeemTime || ''
    }))
    const wb = XLSX.utils.book_new()
    const ws = XLSX.utils.json_to_sheet(rows)
    XLSX.utils.book_append_sheet(wb, ws, '卡密管理')
    const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' })
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    FileSaver.saveAs(blob, `卡密管理_${Date.now()}.xlsx`)
    showToast('导出成功')
  } catch { showToast('导出失败', 'error') }
}

// Import
const triggerImport = () => { fileInput.value?.click() }

const handleImport = async (e: Event) => {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  try {
    const data = await file.arrayBuffer()
    const wb = XLSX.read(data)
    const ws = wb.Sheets[wb.SheetNames[0]]
    const rows: any[] = XLSX.utils.sheet_to_json(ws)
    if (rows.length === 0) { showToast('未读取到数据', 'error'); return }

    const typeReverseMap: Record<string, string> = { '会员卡': 'membership', '积分卡': 'points', '经验卡': 'experience', '余额卡': 'balance', '补签卡': 'makeup' }
    const items = rows.map((r: any) => ({
      cardNo: String(r['卡号'] || r['cardNo'] || ''),
      password: String(r['密码'] || r['password'] || ''),
      type: typeReverseMap[r['类型'] || r['type']] || 'membership',
      targetId: 0,
      targetName: r['面值'] || r['目标'] || r['targetName'] || '',
      value: parseInt(r['面值数值'] || r['value']) || 0,
      extraPoints: parseInt(r['额外积分'] || r['extraPoints']) || 0,
      extraExperience: parseInt(r['额外经验'] || r['extraExperience']) || 0,
      extraBalance: parseFloat(r['额外余额'] || r['extraBalance']) || 0,
      duration: parseInt(r['时长数值'] || r['duration']) || 0,
      durationUnit: r['时长单位'] || r['durationUnit'] || ''
    })).filter((r: any) => r.cardNo && r.password)

    if (items.length === 0) { showToast('未读取到有效卡密数据，请确保至少包含卡号和密码列', 'error'); return }

    await request.post({ url: '/api/operation/cardkey/import', data: { items, createBy: '管理员' } })
    showToast(`成功导入 ${items.length} 张卡密`)
    fetchData()
  } catch (e: any) {
    showToast('导入失败: ' + (e.message || '请检查文件格式'), 'error')
  }
  input.value = ''
}

// Generate dialog
const generateVisible = ref(false)
const generateMode = ref<'single' | 'batch'>('single')
const levelList = ref<{ id: number; name: string }[]>([])

const genForm = reactive({
  type: 'membership',
  targetId: 1,
  value: 500,
  count: 1,
  duration: 12,
  durationUnit: 'month',
  extraPoints: 0,
  extraExperience: 0,
  prefix: 'VIP'
})

const loadLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    if (res && res.records) levelList.value = res.records
    if (levelList.value.length > 0) genForm.targetId = levelList.value[0].id
  } catch {}
}

const showGenerateDialog = (mode: 'single' | 'batch') => {
  generateMode.value = mode
  genForm.type = 'membership'
  genForm.value = 500
  genForm.count = mode === 'batch' ? 50 : 1
  genForm.duration = 12
  genForm.durationUnit = 'month'
  genForm.extraPoints = 0
  genForm.extraExperience = 0
  genForm.prefix = 'VIP'
  if (levelList.value.length === 0) loadLevels()
  generateVisible.value = true
}

const onGenTypeChange = () => {
  if (genForm.type === 'membership') genForm.value = 1
  else if (genForm.type === 'points') genForm.value = 500
  else if (genForm.type === 'experience') genForm.value = 500
  else if (genForm.type === 'balance') genForm.value = 50
  else if (genForm.type === 'makeup') genForm.value = 1
}

const submitGenerate = async () => {
  try {
    const params: any = {
      type: genForm.type,
      targetId: genForm.targetId,
      value: genForm.value,
      count: genForm.count,
      duration: genForm.duration,
      durationUnit: genForm.durationUnit,
      extraPoints: genForm.extraPoints,
      extraExperience: genForm.extraExperience
    }
    if (generateMode.value === 'batch') params.prefix = genForm.prefix
    await request.post({ url: '/api/operation/cardkey/create', params })
    showToast('生成成功')
    generateVisible.value = false
    fetchData()
  } catch (e: any) {
    showToast('生成失败: ' + (e.message || '未知错误'), 'error')
  }
}

const fetchData = async () => {
  loading.value = true
  try {
    const params: any = { current: pagination.current, size: pagination.size }
    if (searchForm.cardNo) params.cardNo = searchForm.cardNo
    if (searchForm.type) params.type = searchForm.type
    if (searchForm.status) params.status = searchForm.status
    const res: any = await request.get({ url: '/api/operation/cardkey/list', params })
    data.value = res?.records || res?.data?.records || []
    pagination.total = res?.total || res?.data?.total || data.value.length
  } catch {}
  loading.value = false
}

const handleSearch = () => { pagination.current = 1; fetchData() }
const resetSearch = () => { searchForm.cardNo = ''; searchForm.type = ''; searchForm.status = ''; handleSearch() }
const goPage = (p: number) => { pagination.current = p; fetchData() }
const handleSizeChange = () => { pagination.current = 1; fetchData() }

const deleteCardKey = async (item: CardKeyItem) => {
  if (!confirm(`确认删除卡密 ${item.cardNo}？`)) return
  try {
    await request.del({ url: `/api/operation/cardkey/${item.id}` })
    showToast('删除成功')
    fetchData()
  } catch { showToast('删除失败', 'error') }
}

onMounted(() => { fetchData(); loadLevels() })
</script>
