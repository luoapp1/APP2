<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">优惠券管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="flex gap-2">
          <input v-model="searchName" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="搜索名称" @keyup.enter="fetchData(1)" />
          <select v-model="searchCategory" class="h-9 px-2 text-xs bg-[#f5f6f8] rounded-lg border-none outline-none" @change="fetchData(1)">
            <option value="">全部分类</option>
            <option v-for="(v,k) in categoryMap" :key="k" :value="k">{{ v }}</option>
          </select>
          <button class="h-9 px-3 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="fetchData(1)">搜索</button>
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div class="flex items-center justify-between px-4 py-2.5 border-b border-gray-100">
            <div class="flex items-center gap-2">
              <span class="text-xs text-gray-400">共 {{ total }} 条</span>
              <select v-model.number="pageSize" class="text-xs px-1.5 py-0.5 bg-gray-50 rounded border-none outline-none text-gray-500" @change="fetchData(1)">
                <option :value="10">10条/页</option>
                <option :value="20">20条/页</option>
                <option :value="50">50条/页</option>
              </select>
            </div>
            <div class="flex items-center gap-1">
              <button class="text-xs px-2 py-1 rounded border border-gray-200 text-gray-500 disabled:opacity-30" :disabled="page <= 1" @click="fetchData(page - 1)">上一页</button>
              <span class="text-xs px-1.5 text-gray-500">{{ page }}/{{ Math.ceil(total / pageSize) || 1 }}</span>
              <button class="text-xs px-2 py-1 rounded border border-gray-200 text-gray-500 disabled:opacity-30" :disabled="page >= Math.ceil(total / pageSize)" @click="fetchData(page + 1)">下一页</button>
            </div>
          </div>
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-start justify-between">
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 mb-1">
                  <span class="text-sm font-semibold text-gray-800 truncate">{{ item.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="typeClass(item.type)">{{ typeLabel(item.type) }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-gray-50 text-gray-500">{{ item.categoryLabel || categoryMap[item.category] || item.category }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded" :class="item.status === '1' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-400'">{{ item.status === '1' ? '启用' : '禁用' }}</span>
                </div>
                <div class="text-xs text-gray-400">
                  <span class="text-[#FF4757] font-medium">{{ valueText(item) }}</span>
                  <template v-if="item.minOrder > 0"> | 满{{ item.minOrder }}可用</template>
                  <template v-if="item.maxDiscount > 0"> | 最高减{{ item.maxDiscount }}</template>
                </div>
                <div class="text-xs text-gray-400 mt-0.5">
                  范围: {{ scopeLabel(item.scope) }} | 领取: {{ item.claimedCount || 0 }}/{{ item.totalCount || 0 }} | 有效: {{ item.validDays }}天
                </div>
              </div>
              <div class="flex gap-1 flex-shrink-0 ml-2">
                <button class="text-xs px-2 py-1 rounded bg-blue-50 text-blue-500 active:bg-blue-100" @click.stop="openDialog(item)">编辑</button>
                <button class="text-xs px-2 py-1 rounded bg-red-50 text-red-400 active:bg-red-100" @click.stop="deleteItem(item)">删除</button>
              </div>
            </div>
          </div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无优惠券</span></div>
      </div>

      <button class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openDialog(null)">+</button>
    </div>

    <div v-if="dialogVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="dialogVisible = false">
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] flex flex-col overflow-hidden" @click.stop>
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 flex-shrink-0">
          <button class="text-gray-400" @click="dialogVisible = false"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
          <span class="text-sm font-bold text-gray-800">{{ editId ? '编辑优惠券' : '新增优惠券' }}</span>
          <button class="text-sm font-semibold text-[#FF4757]" @click="saveItem">保存</button>
        </div>
        <div class="flex-1 overflow-y-auto p-4 space-y-4">
          <div><label class="text-xs text-gray-500 mb-1 block">名称 *</label><input v-model="form.name" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">简介</label><textarea v-model="form.description" class="w-full h-16 px-3 py-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" placeholder="优惠券描述信息" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">券类型 *</label><select v-model="form.type" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="fixed">固定金额</option><option value="percent">百分比</option><option value="fixed_points">固定积分</option><option value="points_percent">积分百分比</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">面值/折扣 *</label><input v-model.number="form.value" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">最低消费</label><input v-model.number="form.minOrder" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">最高折扣</label><input v-model.number="form.maxDiscount" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">使用范围</label><select v-model="form.scope" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option value="all">全部</option><option value="product">商品</option><option value="membership">会员</option></select></div>
            <div><label class="text-xs text-gray-500 mb-1 block">分类</label><select v-model="form.category" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none"><option v-for="(v,k) in categoryMap" :key="k" :value="k">{{ v }}</option></select></div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">发放总数</label><input v-model.number="form.totalCount" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">每人限领</label><input v-model.number="form.perUserLimit" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">领取开始</label><input v-model="form.startTime" type="datetime-local" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">领取截止</label><input v-model="form.expireTime" type="datetime-local" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">有效天数</label><input v-model.number="form.validDays" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="0表示永久有效" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">排序</label><input v-model.number="form.sortOrder" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">专属会员</label>
            <div class="flex flex-wrap gap-2 mt-1">
              <span v-for="lv in memberLevels" :key="lv.id" class="text-xs px-2.5 py-1.5 rounded-full cursor-pointer transition-colors" :class="form.requiredLevelIds.includes(lv.id) ? 'bg-[#FF4757] text-white' : 'bg-gray-100 text-gray-500'" @click="toggleLevel(lv.id)">{{ lv.name }}</span>
            </div>
          </div>
          <div class="space-y-2.5 pt-1">
            <div class="grid grid-cols-2 gap-x-4 gap-y-2.5">
              <div class="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                <span class="text-xs text-gray-600">推荐</span>
                <button class="w-9 h-5 rounded-full transition-colors relative" :class="form.isRecommend ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.isRecommend = !form.isRecommend"><span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.isRecommend ? 'translate-x-4' : 'left-0.5'" /></button>
              </div>
              <div class="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                <span class="text-xs text-gray-600">新人专享</span>
                <button class="w-9 h-5 rounded-full transition-colors relative" :class="form.isNewUser ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.isNewUser = !form.isNewUser"><span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.isNewUser ? 'translate-x-4' : 'left-0.5'" /></button>
              </div>
              <div class="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                <span class="text-xs text-gray-600">限时抢</span>
                <button class="w-9 h-5 rounded-full transition-colors relative" :class="form.isRush ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.isRush = !form.isRush"><span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.isRush ? 'translate-x-4' : 'left-0.5'" /></button>
              </div>
              <div class="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                <span class="text-xs text-gray-600">多次使用</span>
                <button class="w-9 h-5 rounded-full transition-colors relative" :class="form.isMultiUse ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.isMultiUse = !form.isMultiUse"><span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.isMultiUse ? 'translate-x-4' : 'left-0.5'" /></button>
              </div>
            </div>
          </div>
          <div class="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
            <span class="text-xs text-gray-600 font-medium">状态</span>
            <div class="flex items-center gap-2">
              <button class="w-9 h-5 rounded-full transition-colors relative" :class="form.status === '1' ? 'bg-[#FF4757]' : 'bg-gray-300'" @click="form.status = form.status === '1' ? '0' : '1'"><span class="w-4 h-4 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.status === '1' ? 'translate-x-4' : 'left-0.5'" /></button>
              <span class="text-xs" :class="form.status === '1' ? 'text-green-600' : 'text-gray-400'">{{ form.status === '1' ? '启用' : '禁用' }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'CouponManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const categoryMap: Record<string, string> = { general: '通用券', member: '会员券', product: '商品券', event: '活动券', new_user: '新人券', rush: '限时抢券' }
const scopeMap: Record<string, string> = { all: '全部', product: '商品', membership: '会员' }
const scopeLabel = (s: string) => scopeMap[s] || s
const typeMap: Record<string, string> = { fixed: '固定金额', percent: '百分比', fixed_points: '固定积分', points_percent: '积分百分比' }
const typeLabel = (t: string) => typeMap[t] || t
const typeClass = (t: string) => {
  if (t === 'fixed') return 'bg-blue-50 text-blue-600'
  if (t === 'percent') return 'bg-purple-50 text-purple-600'
  return 'bg-orange-50 text-orange-600'
}
const valueText = (item: any) => {
  if (item.type === 'fixed') return `-¥${item.value}`
  if (item.type === 'percent') return `-${item.value}%`
  if (item.type === 'fixed_points') return `-${item.value}积分`
  if (item.type === 'points_percent') return `-${item.value}%积分`
  return `-${item.value}`
}

const loading = ref(false); const list = ref<any[]>([]); const searchName = ref(''); const searchCategory = ref('')
const page = ref(1); const pageSize = ref(20); const total = ref(0)
const fetchData = async (pg?: number) => {
  if (pg) page.value = pg
  loading.value = true
  try {
    const params: any = { current: page.value, size: pageSize.value }
    if (searchName.value) params.name = searchName.value
    if (searchCategory.value) params.category = searchCategory.value
    const res: any = await request.get({ url: '/api/coupon/list', params })
    list.value = res?.records || []
    total.value = res?.total || 0
  } catch { }
  loading.value = false
}

const dialogVisible = ref(false); const editId = ref<number | null>(null)
const formDefault = () => ({ name: '', description: '', type: 'fixed', value: 0, minOrder: 0, maxDiscount: 0, scope: 'all', totalCount: 0, perUserLimit: 1, validDays: 7, category: 'general', startTime: '', expireTime: '', sortOrder: 0, isRecommend: false, isNewUser: false, isRush: false, isMultiUse: false, requiredLevelIds: [] as number[], status: '1' })
const form = reactive(formDefault())

const formatDtLocal = (v: string) => { if (!v) return ''; return v.replace(' ', 'T').slice(0, 16) }
const parseDtLocal = (v: string) => { if (!v) return ''; return v.replace('T', ' ') + ':00' }

const openDialog = (item: any | null) => {
  editId.value = item?.id || null
  if (item) {
    form.name = item.name || ''; form.description = item.description || ''; form.type = item.type || 'fixed'; form.value = item.value || 0; form.minOrder = item.minOrder || 0
    form.maxDiscount = item.maxDiscount || 0; form.scope = item.scope || 'all'; form.totalCount = item.totalCount || 0
    form.perUserLimit = item.perUserLimit || 1; form.validDays = item.validDays || 7; form.category = item.category || 'general'
    form.startTime = formatDtLocal(item.startTime || item.start_time)
    form.expireTime = formatDtLocal(item.expireTime || item.expire_time)
    form.sortOrder = item.sortOrder || 0
    form.isRecommend = item.isRecommend || false; form.isNewUser = item.isNewUser || false
    form.isRush = item.isRush || false; form.isMultiUse = item.isMultiUse || false
    form.requiredLevelIds = item.requiredLevelIds || []
    form.status = item.status || '1'
  } else {
    Object.assign(form, formDefault())
  }
  dialogVisible.value = true
}

const saveItem = async () => {
  try {
    const data: any = { ...form, startTime: parseDtLocal(form.startTime), expireTime: parseDtLocal(form.expireTime) }
    if (editId.value) {
      data.id = editId.value
      await request.put({ url: `/api/coupon/${editId.value}`, data })
    } else {
      await request.post({ url: '/api/coupon', data })
    }
    showToast('保存成功'); dialogVisible.value = false; fetchData(1)
  } catch { showToast('保存失败', 'error') }
}

const deleteItem = async (item: any) => {
  if (!confirm(`确认删除优惠券 ${item.name}？`)) return
  try {
    await request.del({ url: `/api/coupon/${item.id}` })
    showToast('删除成功'); fetchData(1)
  } catch { showToast('删除失败', 'error') }
}

const memberLevels = ref<any[]>([])
const loadMemberLevels = async () => {
  try {
    const res: any = await request.get({ url: '/api/operation/membership-level/list' })
    memberLevels.value = res?.records || []
  } catch {}
}
const toggleLevel = (id: number) => {
  const idx = form.requiredLevelIds.indexOf(id)
  if (idx === -1) form.requiredLevelIds.push(id)
  else form.requiredLevelIds.splice(idx, 1)
}

onMounted(() => { fetchData(); loadMemberLevels() })
</script>
