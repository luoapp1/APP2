<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">积分管理</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <div class="bg-white mx-3 mt-3 rounded-xl p-3">
        <div class="flex gap-2">
          <input v-model="search.userName" class="flex-1 h-9 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" placeholder="用户名" @keyup.enter="handleSearch" />
          <select v-model="search.type" class="h-9 px-2 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none text-gray-600" @change="handleSearch">
            <option value="">全部类型</option>
            <option value="earn">获得</option>
            <option value="expense">消费</option>
            <option value="adjust">调整</option>
          </select>
          <button class="h-9 px-3 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" @click="handleSearch">搜索</button>
        </div>
      </div>

      <div class="bg-white mx-3 mt-3 rounded-xl overflow-hidden">
        <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#FF4757] border-t-transparent rounded-full" /></div>
        <template v-else-if="list.length > 0">
          <div v-for="item in list" :key="item.id" class="px-4 py-3.5 border-b border-gray-50 last:border-b-0">
            <div class="flex items-center justify-between mb-1">
              <span class="text-sm font-semibold text-gray-800">{{ item.userName || '-' }}</span>
              <span class="text-sm font-bold" :class="item.points > 0 ? 'text-green-500' : 'text-red-500'">{{ item.points > 0 ? '+' : '' }}{{ item.points }}</span>
            </div>
            <div class="flex items-center justify-between">
              <div class="text-xs text-gray-400">余额: {{ item.balance || item.afterBalance }} | {{ typeMap[item.type] || item.type }}</div>
              <div class="text-xs text-gray-400">{{ item.description || '-' }}</div>
            </div>
            <div class="text-xs text-gray-400 mt-0.5">{{ item.createTime || item.create_time }}</div>
          </div>
          <div class="flex items-center justify-between px-4 py-3">
            <span class="text-xs text-gray-400">共 {{ total }} 条</span>
            <div class="flex gap-1">
              <button :disabled="page <= 1" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="changePage(page - 1)">上一页</button>
              <span class="text-xs text-gray-500 self-center">{{ page }} / {{ Math.max(1, Math.ceil(total / 20)) }}</span>
              <button :disabled="page >= Math.ceil(total / 20)" class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-500 disabled:opacity-30" @click="changePage(page + 1)">下一页</button>
            </div>
          </div>
        </template>
        <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无积分记录</span></div>
      </div>

      <button class="fixed bottom-16 right-4 w-12 h-12 bg-[#FF4757] rounded-full text-white text-2xl flex items-center justify-center shadow-lg z-20" @click="openAdjustDialog">+</button>
    </div>

    <div v-if="adjustVisible" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="adjustVisible = false">
      <div class="bg-white rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto px-4 pt-4 pb-6" @click.stop>
        <div class="text-base font-bold mb-4 text-center">手动调整积分</div>
        <div class="space-y-3">
          <div><div class="text-xs text-gray-500 mb-1">用户ID</div><input v-model.number="adjustForm.userId" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><div class="text-xs text-gray-500 mb-1">积分 (正为增加,负为扣减)</div><input v-model.number="adjustForm.points" type="number" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><div class="text-xs text-gray-500 mb-1">描述</div><textarea v-model="adjustForm.description" rows="2" class="w-full p-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none resize-none" /></div>
        </div>
        <div class="flex gap-3 mt-5">
          <button class="flex-1 py-2.5 rounded-lg bg-gray-100 text-gray-600 text-sm" @click="adjustVisible = false">取消</button>
          <button class="flex-1 py-2.5 rounded-lg bg-[#FF4757] text-white text-sm" @click="doAdjust">确认调整</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'PointsManageMobile' })

const toastMsg = ref(''); const toastType = ref<'success' | 'error'>('success'); let toastTimer: any
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const typeMap: Record<string, string> = { earn: '获得', expense: '消费', adjust: '调整' }

const loading = ref(false); const list = ref<any[]>([]); const total = ref(0); const page = ref(1)
const search = reactive({ userName: '', type: '' })

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/operation/points-record/list', params: { current: page.value, size: 20, userName: search.userName, type: search.type } })
    if (res) { list.value = res.records || []; total.value = res.total || 0 }
  } catch { }
  loading.value = false
}

const handleSearch = () => { page.value = 1; fetchData() }
const changePage = (p: number) => { page.value = p; fetchData() }

const adjustVisible = ref(false)
const adjustForm = reactive({ userId: 0, points: 0, description: '' })

const openAdjustDialog = () => {
  adjustForm.userId = 0; adjustForm.points = 0; adjustForm.description = ''; adjustVisible.value = true
}

const doAdjust = async () => {
  if (!adjustForm.userId || !adjustForm.points) { showToast('请填写用户ID和积分', 'error'); return }
  try {
    await request.post({ url: '/api/operation/points-record/adjust', data: { userId: adjustForm.userId, points: adjustForm.points, description: adjustForm.description } })
    showToast('调整成功'); adjustVisible.value = false; fetchData()
  } catch { showToast('调整失败', 'error') }
}

onMounted(() => fetchData())
</script>
