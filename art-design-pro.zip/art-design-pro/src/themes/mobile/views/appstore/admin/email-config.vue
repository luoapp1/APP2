<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">邮件配置</span>
    </div>
    <div class="flex-1 overflow-y-auto pb-6">
      <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType==='error'?'bg-red-500 text-white':'bg-gray-800 text-white'">{{ toastMsg }}</div>

      <!-- SMTP 配置 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-4 flex items-center gap-2">
          <svg class="w-4 h-4 text-[#FF4757]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
          SMTP 配置
        </div>
        <div class="space-y-3">
          <div><label class="text-xs text-gray-500 mb-1 block">SMTP 主机</label><input v-model="form.host" placeholder="smtp.qq.com" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">端口</label><input v-model.number="form.port" type="number" min="1" max="65535" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div class="flex items-end pb-1"><label class="flex items-center gap-2 cursor-pointer"><span class="text-xs text-gray-500">SSL 加密</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.secure?'bg-[#FF4757]':'bg-gray-200'" @click="form.secure=!form.secure"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.secure?'translate-x-4.5':'left-0.5'" /></button></label></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">邮箱账号</label><input v-model="form.user" placeholder="your@email.com" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div><label class="text-xs text-gray-500 mb-1 block">邮箱密码/授权码</label><input v-model="form.password" type="password" placeholder="授权码" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /><p class="text-[10px] text-gray-400 mt-1">输入后点击保存，出于安全此字段不回显</p></div>
          <div class="grid grid-cols-2 gap-3">
            <div><label class="text-xs text-gray-500 mb-1 block">发件人名称</label><input v-model="form.fromName" placeholder="Art Design Pro" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
            <div><label class="text-xs text-gray-500 mb-1 block">发件人地址</label><input v-model="form.fromAddress" placeholder="noreply@example.com" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          </div>
          <div><label class="text-xs text-gray-500 mb-1 block">测试收件地址</label><input v-model="form.testAddress" placeholder="test@example.com" class="w-full h-10 px-3 text-sm bg-[#f5f6f8] rounded-lg border-none outline-none" /></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">注册邮箱验证</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.registerVerify?'bg-[#FF4757]':'bg-gray-200'" @click="form.registerVerify=!form.registerVerify"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.registerVerify?'translate-x-4.5':'left-0.5'" /></button></div>
          <div class="flex items-center justify-between py-1"><span class="text-sm text-gray-600">启用</span><button class="w-10 h-6 rounded-full transition-colors relative" :class="form.enabled?'bg-[#FF4757]':'bg-gray-200'" @click="form.enabled=!form.enabled"><span class="w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-transform" :class="form.enabled?'translate-x-4.5':'left-0.5'" /></button></div>
        </div>

        <!-- 操作按钮 -->
        <div class="flex gap-2 mt-4">
          <button class="flex-1 h-10 bg-[#FF4757] text-white text-sm rounded-lg font-medium active:opacity-80" :disabled="saving" @click="doSave">{{ saving?'保存中...':'保存配置' }}</button>
          <button class="flex-1 h-10 bg-white text-sm rounded-lg border border-gray-200 font-medium active:bg-gray-50" :disabled="testing" @click="doTest">{{ testing?'发送中...':'发送测试邮件' }}</button>
        </div>

        <!-- 测试结果 -->
        <div v-if="testResult" class="mt-3 p-3 rounded-lg text-xs" :class="testOk?'bg-green-50 text-green-700':'bg-red-50 text-red-500'">{{ testResult }}</div>
      </div>

      <!-- 使用说明 -->
      <div class="bg-white mx-3 mt-3 rounded-xl p-4">
        <div class="text-sm font-bold text-gray-800 mb-3">使用说明</div>
        <div class="space-y-3 text-xs text-gray-500">
          <div>
            <div class="font-medium text-gray-700 mb-1">QQ 邮箱</div>
            <div>SMTP: smtp.qq.com | 端口: 465(SSL)</div>
            <div>在QQ邮箱 设置→账户→POP3/SMTP服务 开启并获取授权码</div>
          </div>
          <div>
            <div class="font-medium text-gray-700 mb-1">163 邮箱</div>
            <div>SMTP: smtp.163.com | 端口: 465(SSL)</div>
            <div>在163邮箱 设置→POP3/SMTP/IMAP 开启并获取授权码</div>
          </div>
          <div>
            <div class="font-medium text-gray-700 mb-1">Gmail</div>
            <div>SMTP: smtp.gmail.com | 端口: 465(SSL)</div>
            <div>需开启两步验证并使用应用专用密码</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import request from '@/utils/http'

defineOptions({ name: 'EmailConfigMobile' })

const toastMsg=ref('');const toastType=ref<'success'|'error'>('success');let toastTimer:any
const showToast=(m:string,t:'success'|'error'='success')=>{toastMsg.value=m;toastType.value=t;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastMsg.value='',2000)}

const testResult=ref('');const testOk=ref(false)
const saving=ref(false);const testing=ref(false)

const form=reactive({host:'',port:465,secure:true,user:'',password:'',fromName:'',fromAddress:'',testAddress:'',registerVerify:false,enabled:true})

const loadConfig=async()=>{
  try{
    const res:any=await request.get({url:'/api/email/config'})
    if(res){
      form.host=res.host||''
      form.port=res.port||465
      form.secure=!!res.secure
      form.user=res.user||''
      form.password=''
      form.fromName=res.from_name||res.fromName||''
      form.fromAddress=res.from_address||res.fromAddress||''
      form.testAddress=res.test_address||res.testAddress||''
      form.registerVerify=!!res.register_verify||!!res.registerVerify
      form.enabled=!!res.enabled
    }
  }catch{}
}

const doSave=async()=>{
  saving.value=true
  try{
    const data:any={
      host:form.host,port:form.port,secure:form.secure,user:form.user,
      fromName:form.fromName,fromAddress:form.fromAddress,testAddress:form.testAddress,
      registerVerify:form.registerVerify,enabled:form.enabled
    }
    if(form.password)data.password=form.password
    await request.post({url:'/api/email/config',data})
    showToast('保存成功')
  }catch(e:any){showToast('保存失败: '+(e.message||''),'error')}
  saving.value=false
}

const doTest=async()=>{
  testing.value=true;testResult.value=''
  try{await request.post({url:'/api/email/test',data:{to:form.testAddress}});testResult.value='测试邮件已发送，请检查收件箱';testOk.value=true}catch(e:any){testResult.value='发送失败: '+(e.message||'请检查配置');testOk.value=false}
  testing.value=false
}

onMounted(()=>loadConfig())
</script>
