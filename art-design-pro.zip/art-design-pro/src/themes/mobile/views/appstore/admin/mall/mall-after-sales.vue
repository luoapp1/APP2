<template>
  <div class="page">
    <div class="topbar">
      <button class="back-btn" @click="$router.back()">&larr;</button>
      <span class="title">售后服务</span>
    </div>
    <div class="filters">
      <select v-model="filterStatus" @change="loadList" class="filter-select">
        <option value="">全部状态</option>
        <option value="pending">待处理</option>
        <option value="approved">已同意</option>
        <option value="rejected">已拒绝</option>
        <option value="completed">已完成</option>
      </select>
    </div>
    <div v-if="loading" class="loading"><span class="spinner" />加载中...</div>
    <div v-else class="list">
      <div v-if="list.length === 0" class="empty">暂无售后申请</div>
      <div v-for="a in list" :key="a.id" class="item">
        <div class="item-hd">
          <span>订单: {{ a.orderNo }}</span>
          <span class="st" :class="'st-' + a.status">{{ statusMap[a.status] }}</span>
        </div>
        <div class="item-body">
          <span class="as-type">{{ a.type === 'refund' ? '退款' : '退货退款' }}</span>
          <span class="as-amount">¥{{ a.amount }}</span>
          <span v-if="a.reason" class="as-reason">{{ a.reason }}</span>
        </div>
        <div v-if="a.description" class="item-desc">{{ a.description }}</div>
        <div v-if="a.sellerReply" class="item-reply">商家回复: {{ a.sellerReply }}</div>
        <div v-if="a.status === 'pending'" class="item-actions">
          <button @click="handle(a, 'approved', '同意售后')" class="act-approve">同意</button>
          <button @click="showReject(a)" class="act-reject">拒绝</button>
        </div>
      </div>
    </div>

    <div v-if="rejectDialog" class="modal-overlay" @click.self="rejectDialog = null">
      <div class="modal">
        <div class="modal-title">拒绝售后</div>
        <div class="field"><textarea v-model="rejectReason" placeholder="请输入拒绝理由" class="input textarea" rows="3" /></div>
        <div class="modal-actions">
          <button @click="rejectDialog = null" class="btn-cancel">取消</button>
          <button @click="handle(rejectDialog, 'rejected', rejectReason)" class="btn-confirm">确认</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const list = ref<any[]>([])
const loading = ref(true)
const filterStatus = ref('')
const rejectDialog = ref<any>(null)
const rejectReason = ref('')

const statusMap: Record<string, string> = { pending: '待处理', approved: '已同意', rejected: '已拒绝', completed: '已完成' }

async function loadList() {
  loading.value = true
  try {
    const params: any = { pageSize: 100 }
    if (filterStatus.value) params.status = filterStatus.value
    const res: any = await request.get({ url: '/api/mall/after-sales', params })
    list.value = res?.list || []
  } catch {} finally { loading.value = false }
}

function showReject(a: any) { rejectDialog.value = a; rejectReason.value = '' }

async function handle(a: any, status: string, sellerReply: string) {
  try {
    await request.put({ url: `/api/mall/after-sales/${a.id}`, data: { status, sellerReply } })
    a.status = status
    a.sellerReply = sellerReply
    rejectDialog.value = null
  } catch {}
}

onMounted(loadList)
</script>

<style scoped>
.page { min-height: 100vh; background: #f5f6f8; font-family: -apple-system, sans-serif; }
.topbar { display: flex; align-items: center; padding: 12px 14px; background: #fff; gap: 10px; border-bottom: 1px solid #eee; }
.back-btn { border: none; background: none; font-size: 18px; cursor: pointer; color: #333; }
.title { font-size: 16px; font-weight: 700; flex: 1; }
.filters { padding: 10px 14px; background: #fff; border-bottom: 1px solid #f0f0f0; }
.filter-select { width: 100%; padding: 6px 8px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 12px; background: #fff; }
.loading, .empty { text-align: center; padding: 40px; color: #999; }
.spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid #e5e7eb; border-top-color: #FF6B6B; border-radius: 50%; animation: spin .6s linear infinite; margin-right: 6px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg) } }
.list { padding: 8px 0; }
.item { background: #fff; margin: 0 10px 8px; border-radius: 12px; padding: 12px; }
.item-hd { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 13px; color: #333; }
.st { font-size: 11px; padding: 2px 8px; border-radius: 4px; font-weight: 600; }
.st-pending { background: #FFF3E0; color: #E65100; }
.st-approved { background: #E8F5E9; color: #2E7D32; }
.st-rejected { background: #FFEBEE; color: #C62828; }
.st-completed { background: #F3E5F5; color: #7B1FA2; }
.item-body { display: flex; gap: 10px; align-items: center; font-size: 13px; color: #555; }
.as-type { font-weight: 600; }
.as-amount { color: #FF4757; font-weight: 600; }
.item-desc { font-size: 12px; color: #999; margin-top: 4px; }
.item-reply { font-size: 12px; color: #2E7D32; margin-top: 4px; background: #f0fdf4; padding: 6px 8px; border-radius: 6px; }
.item-actions { display: flex; gap: 8px; margin-top: 10px; padding-top: 8px; border-top: 1px solid #f0f0f0; }
.act-approve { flex: 1; padding: 8px; border: none; background: #E8F5E9; color: #2E7D32; border-radius: 8px; cursor: pointer; font-size: 13px; }
.act-reject { flex: 1; padding: 8px; border: none; background: #FFEBEE; color: #C62828; border-radius: 8px; cursor: pointer; font-size: 13px; }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: flex; align-items: flex-end; justify-content: center; z-index: 100; }
.modal { background: #fff; width: 100%; max-width: 500px; border-radius: 16px 16px 0 0; padding: 20px; }
.modal-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
.field { margin-bottom: 10px; }
.input { width: 100%; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 13px; box-sizing: border-box; }
.textarea { resize: vertical; }
.modal-actions { display: flex; gap: 10px; margin-top: 16px; }
.btn-cancel { flex: 1; padding: 10px; border: 1px solid #ddd; background: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
.btn-confirm { flex: 1; padding: 10px; border: none; background: #FF6B6B; color: #fff; border-radius: 8px; cursor: pointer; font-size: 14px; }
</style>
