<template>
  <div class="min-h-screen flex flex-col bg-[#f5f6f8]">
    <div class="bg-white px-4 py-3 flex items-center gap-3 shadow-sm sticky top-0 z-20">
      <svg class="w-5 h-5 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <span class="text-base font-bold text-gray-800 flex-1 text-center mr-5">举报列表</span>
    </div>

    <div v-if="toastMsg" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-lg shadow-lg transition-all duration-200" :class="toastType === 'error' ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'">{{ toastMsg }}</div>

    <div class="flex-1 overflow-y-auto pb-20">
      <div v-if="loading" class="flex justify-center py-12"><div class="animate-spin w-5 h-5 border-2 border-[#EC4899] border-t-transparent rounded-full" /></div>

      <template v-else-if="list.length > 0">
        <div v-for="item in list" :key="item.id" class="bg-white mx-3 mt-3 rounded-xl px-4 py-3">
          <div class="flex items-start justify-between gap-3">
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-2 mb-1">
                <span class="text-sm font-semibold text-gray-800 truncate">{{ item.appName || '未知应用' }}</span>
                <span class="text-[11px] text-gray-400">#{{ item.id }}</span>
              </div>
              <div class="text-xs text-gray-400 mb-1.5">{{ item.userName || '匿名' }} · {{ (item.createTime || '').slice(0, 16) || '-' }}</div>
              <div class="text-sm text-gray-600 leading-relaxed line-clamp-3 mb-2">{{ item.content || '-' }}</div>
              <div class="flex items-center gap-2">
                <span class="text-[11px] bg-red-50 text-red-500 rounded-full px-2 py-0.5 font-medium">被举报 {{ item.reported || 0 }} 次</span>
              </div>
            </div>
          </div>
          <div class="flex items-center gap-2 mt-3 pt-3 border-t border-gray-50">
            <button class="flex-1 h-8 text-xs rounded-lg bg-red-50 text-red-500 active:bg-red-100 font-medium" @click="handleDelete(item)">删除评论</button>
            <button class="flex-1 h-8 text-xs rounded-lg bg-gray-100 text-gray-500 active:bg-gray-200" @click="handleIgnore(item)">忽略举报</button>
          </div>
        </div>
        <div class="flex items-center justify-center gap-3 py-4 text-xs text-gray-400">
          <button class="px-3 py-1 rounded-lg bg-white active:bg-gray-100" :disabled="page <= 1" @click="page--; fetchData()">上一页</button>
          <span>第 {{ page }} / {{ totalPages }} 页 ({{ total }}条)</span>
          <button class="px-3 py-1 rounded-lg bg-white active:bg-gray-100" :disabled="page >= totalPages" @click="page++; fetchData()">下一页</button>
        </div>
      </template>
      <div v-else class="flex flex-col items-center py-12 text-gray-400"><span class="text-sm">暂无举报</span></div>
    </div>

    <!-- 确认删除弹窗 -->
    <div v-if="showConfirm" class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" @click.self="showConfirm = false">
      <div class="bg-white rounded-2xl shadow-xl w-72 overflow-hidden" @click.stop>
        <div class="text-center pt-6 pb-2 px-4">
          <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-red-50 flex items-center justify-center">
            <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
          </div>
          <div class="text-sm font-semibold text-gray-800 mb-1">{{ confirmText }}</div>
        </div>
        <div class="flex border-t border-gray-100">
          <button class="flex-1 h-11 text-sm text-gray-500 font-medium active:bg-gray-50" @click="showConfirm = false">取消</button>
          <button class="flex-1 h-11 text-sm text-red-500 font-medium border-l border-gray-100 active:bg-red-50" @click="doConfirmed">删除</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchReportList, fetchAdminDeleteComment, fetchIgnoreReport } from '@/api/appstore'

defineOptions({ name: 'ReportsManageMobile' })

const showConfirm = ref(false)
const confirmText = ref('')
let pendingAction: (() => void) | null = null
const doConfirmed = () => { showConfirm.value = false; if (pendingAction) pendingAction() }
const askConfirm = (text: string, action: () => void) => { confirmText.value = text; pendingAction = action; showConfirm.value = true }

const toastMsg = ref('')
const toastType = ref<'success' | 'error'>('success')
let toastTimer: any = null
const showToast = (m: string, t: 'success' | 'error' = 'success') => { toastMsg.value = m; toastType.value = t; if (toastTimer) clearTimeout(toastTimer); toastTimer = setTimeout(() => toastMsg.value = '', 2000) }

const loading = ref(false)
const list = ref<any[]>([])
const page = ref(1)
const pageSize = 20
const total = ref(0)
const totalPages = ref(0)

const fetchData = async () => {
  loading.value = true
  try {
    const res: any = await fetchReportList({ page: page.value, pageSize })
    list.value = res?.list || res?.records || []
    total.value = res?.total || list.value.length
    totalPages.value = Math.max(1, Math.ceil(total.value / pageSize))
  } catch (e) { console.error('fetchData error:', e) }
  loading.value = false
}

const handleDelete = (item: any) => {
  askConfirm('确定要删除该评论吗？删除后无法恢复。', async () => {
    try {
      await fetchAdminDeleteComment(item.id)
      showToast('已删除')
      fetchData()
    } catch (e) { showToast('删除失败', 'error') }
  })
}

const handleIgnore = async (item: any) => {
  try {
    await fetchIgnoreReport(item.id)
    showToast('已忽略')
    fetchData()
  } catch (e) { showToast('操作失败', 'error') }
}

onMounted(() => fetchData())
</script>
