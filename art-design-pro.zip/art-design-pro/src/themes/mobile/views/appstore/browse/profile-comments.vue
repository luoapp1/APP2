<template>
  <div style="min-height: 100vh; background: var(--default-bg-color);">
    <div style="background: var(--default-bg-color); padding: 48px 16px 12px; display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">我的评论</span>
    </div>

    <div style="padding: 4px 16px;">
      <div v-if="comments.length === 0" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 100px 20px;">
        <div style="color: #c0c4cc; font-size: 14px;">暂无评论</div>
      </div>
      <div v-for="c in comments" :key="c.id" style="padding: 14px 0; border-bottom: 1px solid #f2f3f6; position: relative;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
          <div v-if="Number(c.rating) > 0" style="display: flex; gap: 2px;">
            <svg v-for="s in 5" :key="s" width="13" height="13" viewBox="0 0 24 24" :fill="s <= Number(c.rating||0) ? '#FFB800' : '#e8eaef'"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
          </div>
          <span style="font-size: 12px; color: #bbb;">{{ c.createTime?.slice(0,16) }}</span>
          <span style="font-size: 12px; color: #24D6C4; font-weight: 500;">@{{ c.appName }}</span>
        </div>
        <p style="font-size: 14px; color: #444; line-height: 1.55; margin: 0; padding-right: 50px;" v-html="c.content"></p>
        <div style="font-size: 11px; color: #ccc; margin-top: 4px;">{{ c.likes || 0 }} 赞</div>
        <button @click="handleDelete(c)" style="position: absolute; top: 14px; right: 0; background: none; border: none; cursor: pointer; padding: 4px 8px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { ElMessageBox, ElMessage } from 'element-plus'

const route = useRoute()
const userStore = useUserStore()
const comments = ref<any[]>([])

const loadComments = async () => {
  try {
    const userId = route.query.userId || userStore.info.userId || 1
    const data: any = await request.get({ url: `/api/user/comments?userId=${userId}` })
    comments.value = data?.list || []
  } catch {}
}

const handleDelete = async (c: any) => {
  try {
    await ElMessageBox.confirm('确定要删除这条评论吗？删除后不可恢复。', '删除评论', {
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
      type: 'warning'
    })
    const uid = userStore.info.userId || 1
    await request.del({ url: `/api/app/${c.appId}/comment/${c.id}?userId=${uid}` })
    ElMessage.success('已删除')
    comments.value = comments.value.filter(item => item.id !== c.id)
  } catch {}
}

onMounted(() => loadComments())
</script>
