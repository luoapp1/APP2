<template>
    <div class="h-screen flex flex-col bg-[#EDEDED]">
    <!-- 顶部导航栏 -->
    <div class="flex items-center gap-2.5 px-3 py-2 flex-shrink-0 sticky top-0 z-10 bg-white">
      <svg class="w-6 h-6 text-gray-600 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="goBack">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
      </svg>
      <img
        v-if="resolveAvatar(chatAvatar)"
        :src="resolveAvatar(chatAvatar)"
        class="w-[32px] h-[32px] rounded-full object-cover flex-shrink-0"
      />
      <div v-else class="w-[32px] h-[32px] rounded-full flex items-center justify-center flex-shrink-0" :style="{ background: iconColor(chatName) }">
        <span class="text-white text-xs font-bold">{{ chatName[0] || '?' }}</span>
      </div>
      <span class="text-[15px] font-medium text-gray-800 truncate flex-1">{{ chatName }}</span>
      <svg class="w-6 h-6 text-gray-600 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="showSearchBar = !showSearchBar">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
      </svg>
    </div>

    <!-- 搜索栏 -->
    <div v-if="showSearchBar" class="px-3 py-2 bg-white border-b border-gray-100">
      <div class="flex items-center gap-2">
        <input v-model="searchKeyword" class="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm outline-none text-gray-700" placeholder="搜索聊天记录..." @keyup.enter="doSearch" />
        <span class="text-xs text-blue-500 font-medium flex-shrink-0 cursor-pointer" @click="doSearch">搜索</span>
        <span class="text-xs text-gray-400 flex-shrink-0 cursor-pointer" @click="showSearchBar = false; searchKeyword = ''; searchResults = []">取消</span>
      </div>
      <div v-if="searchResults.length" class="mt-2 max-h-40 overflow-y-auto space-y-1">
        <div v-for="sr in searchResults" :key="sr.id" class="text-xs text-gray-600 py-1.5 px-2 rounded cursor-pointer active:bg-gray-100" @click="scrollToMsg(sr.id); showSearchBar = false">{{ fmtTime(sr.createTime) }} {{ sr.content }}</div>
      </div>
      <div v-else-if="searchKeyword && searched" class="text-xs text-gray-400 py-2 text-center">未找到相关消息</div>
    </div>

    <!-- 消息列表 -->
    <div ref="msgListRef" class="flex-1 overflow-y-auto px-3 py-3 space-y-3">
      <div v-for="msg in messages" :key="msg.id" :data-msg-id="msg.id">
        <!-- 订单卡片消息 -->
        <div v-if="msg.messageType === 'order_card' && msg.orderCard" class="flex gap-2" :class="msg.fromUserId === myUserId ? 'flex-row-reverse' : ''">
          <img :src="resolveAvatar(msg.fromUserId === myUserId ? myAvatar : msg.fromUserAvatar)" class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0 mt-1" @error="($event.target as any).style.display='none'" />
          <div class="w-[280px]">
            <div v-if="msg.fromUserId !== myUserId" class="text-[10px] text-gray-400 mb-1 ml-1">{{ msg.fromUserName }}</div>
            <div class="rounded-2xl overflow-hidden shadow-sm cursor-pointer" @click="viewOrder(msg.orderCard)">
              <div class="px-4 py-3" :class="orderCardBg(msg.orderCard.status)">
                <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-2">
                    <div class="w-[36px] h-[36px] rounded-full bg-white/30 flex items-center justify-center backdrop-blur-sm">
                      <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
                    </div>
                    <div>
                      <div class="text-white text-[13px] font-bold tracking-wide">{{ msg.orderCard.orderNo || '' }}</div>
                      <div class="text-white/70 text-[10px]">订单号</div>
                    </div>
                  </div>
                  <div class="text-right">
                    <div class="text-white text-lg font-bold">{{ msg.orderCard.payType === 'points' ? msg.orderCard.paidAmount : '¥' + Number(msg.orderCard.paidAmount || 0).toFixed(2) }}</div>
                    <div class="text-white/70 text-[10px]">{{ msg.orderCard.payType === 'points' ? '积分支付' : '余额支付' }}</div>
                  </div>
                </div>
              </div>
              <div class="bg-white px-4 py-3">
                <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-1.5">
                    <div class="w-1.5 h-1.5 rounded-full" :class="statusDot(msg.orderCard.status)" />
                    <span class="text-[13px] font-semibold" :class="statusTextClass(msg.orderCard.status)">{{ statusLabel(msg.orderCard.status) }}</span>
                  </div>
                  <span class="text-[10px] text-gray-400">{{ fmtTime(msg.createTime) }}</span>
                </div>
                <div class="text-[12px] text-gray-600 leading-relaxed">{{ msg.orderCard.orderDesc || '暂无描述' }}</div>
                <div class="mt-2 pt-2 border-t border-gray-50 flex justify-between items-center">
                  <span class="text-[10px] text-gray-400">点击查看订单详情</span>
                  <svg class="w-3.5 h-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </div>
              </div>
            </div>
            <div class="text-[10px] text-gray-400 mt-1" :class="msg.fromUserId === myUserId ? 'text-right' : 'text-left'">{{ fmtTime(msg.createTime) }}</div>
          </div>
        </div>
        <div v-else class="flex gap-2" :class="msg.fromUserId === myUserId ? 'flex-row-reverse' : ''">
          <img
            :src="resolveAvatar(msg.fromUserId === myUserId ? myAvatar : msg.fromUserAvatar)"
            class="w-[36px] h-[36px] rounded-full object-cover flex-shrink-0"
            :class="msg.fromUserId === myUserId ? 'mt-3' : 'mt-4'"
            @error="($event.target as any).style.display='none'"
          />
          <div class="max-w-[72%]">
            <div v-if="msg.fromUserId !== myUserId" class="text-[10px] text-gray-400 mb-1 ml-1">{{ msg.fromUserName }}</div>
            <div v-if="msg.isRecalled" class="px-3 py-2 rounded-xl text-xs bg-gray-100 text-gray-400 italic">消息已撤回</div>
            <template v-else>
              <img v-if="msg.imageUrl" :src="$fixImgUrl(msg.imageUrl)" class="max-w-[200px] max-h-[200px] rounded-xl object-cover cursor-pointer mb-1" @click="previewImgUrl = msg.imageUrl" />
              <div
                v-if="msg.content"
                class="px-3 py-2.5 rounded-xl text-[15px] leading-relaxed break-all"
                :class="msg.fromUserId === myUserId ? 'bg-[#FFE5E5] text-gray-800' : 'bg-white text-gray-800'"
                @touchstart="onMsgTouchStart($event, msg)"
                @touchend="onMsgTouchEnd($event)"
                @touchmove="onMsgTouchCancel"
                v-html="linkifyText(msg.content)"
              />
            </template>
            <div class="flex items-center gap-2 mt-0.5" :class="msg.fromUserId === myUserId ? 'justify-end' : 'justify-start'">
              <span v-if="msg.fromUserId === myUserId" class="text-[9px]" :class="msg.isRead ? 'text-gray-300' : 'text-gray-400'">{{ msg.isRead ? '已读' : '未读' }}</span>
              <span v-if="msg.reportStatus === 'reported'" class="text-[9px] text-red-400">已举报</span>
              <span class="text-[9px] text-gray-400">{{ fmtTime(msg.createTime) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 图片预览 -->
    <div v-if="previewImgUrl" class="fixed inset-0 bg-black/85 flex items-center justify-center z-[100]" @click="previewImgUrl = ''">
      <img :src="$fixImgUrl(previewImgUrl)" class="max-w-[92%] max-h-[92%] object-contain rounded-lg" />
    </div>

    <!-- 消息操作菜单 -->
    <div v-if="menuMsg" class="fixed inset-0 bg-black/30 flex items-end justify-center z-50" @click="closeMenu">
      <div class="bg-white rounded-t-xl w-full max-w-lg pb-6" @click.stop>
        <div class="text-center text-xs text-gray-400 py-2">{{ menuMsg.fromUserId === myUserId ? '我的消息' : chatName }}</div>
        <template v-if="menuMsg.fromUserId === myUserId && !menuMsg.isRecalled">
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-red-500" @click="recallMsg(menuMsg)">撤回</div>
        </template>
        <template v-if="menuMsg.fromUserId !== myUserId">
          <div class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50 text-red-500" @click="showReportDialog(menuMsg)">举报</div>
        </template>
        <div v-if="menuMsg.content" class="py-3 px-6 text-center text-base cursor-pointer active:bg-gray-50" @click="copyMsg(menuMsg)">复制</div>
        <div class="pt-2"><div class="py-3 px-6 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="closeMenu">取消</div></div>
      </div>
    </div>

    <!-- 举报对话框 -->
    <div v-if="reportMsg" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="reportMsg = null">
      <div class="bg-white rounded-xl w-80 overflow-hidden" @click.stop>
        <div class="px-6 py-5"><div class="text-base font-semibold text-gray-800 mb-3 text-center">举报消息</div>
          <div class="space-y-2">
            <div v-for="opt in reportOptions" :key="opt.value" class="py-2 px-3 rounded-lg cursor-pointer text-sm border" :class="reportReason === opt.value ? 'border-red-400 text-red-500 bg-red-50' : 'border-gray-200 text-gray-600'" @click="reportReason = opt.value">{{ opt.label }}</div>
          </div>
          <textarea v-model="reportDetail" class="w-full mt-3 px-3 py-2 text-sm border border-gray-200 rounded-lg outline-none resize-none" rows="2" placeholder="补充说明（选填）" />
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="reportMsg = null; reportReason = ''; reportDetail = ''">取消</div>
          <div class="flex-1 py-3 text-center text-base font-medium cursor-pointer active:bg-gray-50" :class="reportReason ? 'text-red-500' : 'text-gray-300'" @click="submitReport">提交</div>
        </div>
      </div>
    </div>

    <!-- 订单分享弹窗 -->
    <div v-if="showOrderPanel" class="fixed inset-0 bg-black/30 flex items-end justify-center z-50" @click="showOrderPanel = false">
      <div class="bg-white rounded-t-xl w-full max-w-lg max-h-[60vh] overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100 text-center text-sm font-semibold text-gray-800">选择订单</div>
        <div class="overflow-y-auto max-h-[calc(60vh-60px)]">
          <div v-if="loadingOrders" class="flex justify-center py-10"><div class="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full" /></div>
          <div v-else-if="myOrders.length === 0" class="py-10 text-center text-sm text-gray-400">暂无订单</div>
          <div v-else>
            <div
              v-for="o in myOrders"
              :key="o.id"
              class="flex items-center gap-3 px-5 py-3 cursor-pointer active:bg-gray-50 border-b border-gray-50"
              @click="sendOrderCard(o); showOrderPanel = false"
            >
              <div class="w-[40px] h-[40px] rounded-lg flex items-center justify-center flex-shrink-0" :style="{ background: iconBg(o.orderNo) }">
                <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4z"/></svg>
              </div>
              <div class="flex-1 min-w-0">
                <div class="text-sm text-gray-800 truncate" :class="o.status === 'completed' ? 'text-green-600' : o.status === 'refunding' ? 'text-orange-500' : ''">{{ statusLabel(o.status) }} - {{ o.orderDesc }}</div>
                <div class="text-xs text-gray-400">{{ o.payType === 'points' ? o.paidAmount + ' 积分' : '¥' + o.paidAmount }} · {{ fmtTime(o.createTime) }}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="py-3 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="showOrderPanel = false">取消</div>
      </div>
    </div>

    <!-- 订单详情弹窗 -->
    <div v-if="showOrderDetail" class="fixed inset-0 bg-black/30 flex items-end justify-center z-[80]" @click="showOrderDetail = false">
      <div class="bg-white rounded-t-xl w-full max-w-lg max-h-[80vh] overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100 text-center text-sm font-semibold text-gray-800">订单详情</div>
        <div class="overflow-y-auto max-h-[calc(80vh-60px)] px-5 py-4">
          <template v-if="orderDetail">
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">订单号</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderNo }}</div>
            </div>
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">描述</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderDesc }}</div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">状态</span>
                <div class="text-[14px] font-semibold mt-0.5" :class="statusClass(orderDetail.status)">{{ statusLabel(orderDetail.status) }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">金额</span>
                <div class="text-[14px] font-semibold text-gray-800 mt-0.5">{{ orderDetail.payType === 'points' ? orderDetail.paidAmount + ' 积分' : '¥' + orderDetail.paidAmount }}</div>
              </div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">类型</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.orderType || '-' }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">支付方式</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.payType === 'points' ? '积分' : '余额' }}</div>
              </div>
            </div>
            <div class="flex gap-4 mb-3">
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">买家</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.buyerName || '-' }}</div>
              </div>
              <div class="flex-1">
                <span class="text-[11px] text-gray-400">卖家</span>
                <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.sellerName || '平台' }}</div>
              </div>
            </div>
            <div class="mb-3">
              <span class="text-[11px] text-gray-400">下单时间</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.createTime || '-' }}</div>
            </div>
            <div v-if="orderDetail.confirmedAt" class="mb-3">
              <span class="text-[11px] text-gray-400">确认收货时间</span>
              <div class="text-[14px] text-gray-800 mt-0.5">{{ orderDetail.confirmedAt }}</div>
            </div>
            <div v-if="orderDetail.refundReason" class="mb-3 p-3 bg-orange-50 rounded-xl">
              <span class="text-[11px] text-orange-500 font-medium">退款原因</span>
              <div class="text-[13px] text-gray-800 mt-1">{{ orderDetail.refundReason }}</div>
            </div>
            <div v-if="orderDetail.adminReview" class="mb-3 p-3 bg-blue-50 rounded-xl">
              <span class="text-[11px] text-blue-500 font-medium">管理员审核</span>
              <div class="text-[13px] text-gray-800 mt-1">{{ orderDetail.adminReview === 'pending' ? '待审核' : orderDetail.adminReview === 'reviewed' ? '已审核' : orderDetail.adminReview }}</div>
            </div>
          </template>
        </div>
        <div class="py-3 text-center text-base text-gray-400 cursor-pointer active:bg-gray-50 border-t border-gray-100" @click="showOrderDetail = false">关闭</div>
      </div>
    </div>

    <!-- 底部输入区 -->
    <div class="bg-white border-t border-gray-200 flex-shrink-0" style="padding-bottom: env(safe-area-inset-bottom)">
      <div class="flex items-center gap-2 px-3 pt-2 pb-1">
        <input v-model="inputMsg" class="flex-1 bg-[#F5F5F5] rounded-full h-[38px] px-4 text-[14px] outline-none text-gray-800 placeholder-gray-400" placeholder="输入消息..." @keyup.enter="sendMsg()" />
        <button
          class="h-[32px] px-4 rounded-full text-[13px] font-medium flex-shrink-0 transition-colors"
          :class="inputMsg.trim() ? 'text-white' : 'bg-gray-200 text-gray-400'"
          :style="inputMsg.trim() ? { background: '#4A90D9' } : {}"
          @click="sendMsg()"
        >发送</button>
      </div>
      <div class="flex items-center justify-around px-2 pb-1">
        <div
          v-for="item in toolbarItems"
          :key="item.key"
          class="flex flex-col items-center gap-0.5 cursor-pointer active:opacity-60 py-1 px-2 min-w-[48px] text-gray-500"
          @click="handleToolbarClick(item.key)"
        >
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" :d="item.icon"/></svg>
          <span class="text-[9px]">{{ item.label }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import { fetchMessages, fetchSendMessage, fetchUploadChatImage, fetchRecallMessage, fetchReportMessage, fetchSearchMessages } from '@/api/message'
import type { MessageItem } from '@/api/message'
import request from '@/utils/http'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0
const myAvatar = userStore.info?.avatar || ''

const targetUserId = Number(route.params.targetUserId)
const chatName = ref('')
const chatAvatar = ref('')

const goBack = () => {
  router.push('/appstore/game')
}

const messages = ref<MessageItem[]>([])
const inputMsg = ref('')
const msgListRef = ref<HTMLElement | null>(null)

const menuMsg = ref<MessageItem | null>(null)
const reportMsg = ref<MessageItem | null>(null)
const reportReason = ref('')
const reportDetail = ref('')
const previewImgUrl = ref('')
const showOrderPanel = ref(false)
const myOrders = ref<any[]>([])
const loadingOrders = ref(false)
const showOrderDetail = ref(false)
const orderDetail = ref<any>(null)

const showSearchBar = ref(false)
const searchKeyword = ref('')
const searchResults = ref<any[]>([])
const searched = ref(false)

let longPressTimer: any = null

const toolbarItems = [
  { key: 'image', label: '照片', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
  { key: 'order', label: '订单', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { key: 'redpacket', label: '红包', icon: 'M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0112 21a9.003 9.003 0 018.354-5.646z' },
  { key: 'report', label: '投诉', icon: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4.5c-.77-.833-2.694-.833-3.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z' },
]

const reportOptions = [
  { label: '垃圾广告', value: 'spam' },
  { label: '色情低俗', value: 'porn' },
  { label: '政治敏感', value: 'politics' },
  { label: '人身攻击', value: 'harassment' },
  { label: '诈骗信息', value: 'fraud' },
  { label: '其他', value: 'other' },
]

const colorPool = ['#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#AB47BC', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconColor = (name: string) => colorPool[((name || '?').charCodeAt(0) || 0) % colorPool.length]
const iconBg = (s: string) => colorPool[((s || '').length + ((s || '').charCodeAt(0) || 0)) % colorPool.length]

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) avatarMap[`avatar:${match[1]}`] = (mod as any).default
}
const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar?.startsWith('http') || avatar?.startsWith('/uploads')) return avatar.replace(/^http:\/\//i, 'https://')
  return ''
}

const linkifyText = (text: string) => {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/(https?:\/\/[^\s]+)/g, '<a class="text-blue-500 underline" href="$1" target="_blank">$1</a>')
    .replace(/(\d{11})/g, '<span class="text-blue-500 cursor-pointer">$1</span>')
}

const statusLabel = (s: string) => {
  const map: Record<string, string> = { shipped: '待收货', completed: '已完成', refunding: '退款中', refunded: '已退款' }
  return map[s] || s
}
const statusClass = (s: string) => {
  if (s === 'completed') return 'text-green-600'
  if (s === 'refunding') return 'text-orange-500'
  return 'text-gray-800'
}

const orderCardBg = (s: string) => {
  if (s === 'completed') return 'bg-gradient-to-r from-emerald-400 to-teal-500'
  if (s === 'shipped') return 'bg-gradient-to-r from-blue-400 to-indigo-500'
  if (s === 'refunding') return 'bg-gradient-to-r from-orange-400 to-red-400'
  if (s === 'refunded') return 'bg-gradient-to-r from-gray-400 to-gray-500'
  return 'bg-gradient-to-r from-purple-400 to-pink-500'
}

const statusDot = (s: string) => {
  if (s === 'completed') return 'bg-emerald-500'
  if (s === 'shipped') return 'bg-blue-500'
  if (s === 'refunding') return 'bg-orange-500'
  if (s === 'refunded') return 'bg-gray-400'
  return 'bg-purple-500'
}

const statusTextClass = (s: string) => {
  if (s === 'completed') return 'text-emerald-600'
  if (s === 'shipped') return 'text-blue-600'
  if (s === 'refunding') return 'text-orange-600'
  if (s === 'refunded') return 'text-gray-500'
  return 'text-purple-600'
}

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  return new Date(t.replace(' ', 'T') + 'Z')
}
const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const diff = Date.now() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
}

const scrollToBottom = () => { nextTick(() => { if (msgListRef.value) msgListRef.value.scrollTop = msgListRef.value.scrollHeight }) }
const scrollToMsg = (msgId: number) => { nextTick(() => { const el = msgListRef.value?.querySelector(`[data-msg-id="${msgId}"]`); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('bg-yellow-50'); setTimeout(() => el.classList.remove('bg-yellow-50'), 2000) } }) }

const doSearch = async () => {
  const kw = searchKeyword.value.trim(); if (!kw) return
  try { const res: any = await fetchSearchMessages(myUserId, kw); searchResults.value = Array.isArray(res) ? res : (res.list || []); searched.value = true } catch { searchResults.value = []; searched.value = true }
}

const handleToolbarClick = async (key: string) => {
  if (key === 'image') {
    const input = document.createElement('input')
    input.type = 'file'; input.accept = 'image/*'
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0]; if (!file) return
      const fd = new FormData(); fd.append('file', file)
      try {
        const res: any = await request.post({ url: '/api/messages/upload-image', data: fd, headers: { 'Content-Type': 'multipart/form-data' } })
        const url = res.url || ''
        if (url) await sendMsg(url)
      } catch {}
    }
    input.click()
  } else if (key === 'order') {
    showOrderPanel.value = true
    loadingOrders.value = true
    try {
      const res: any = await request.get({ url: '/api/messages/orders', params: { userId: myUserId } })
      myOrders.value = Array.isArray(res) ? res : (res.list || [])
    } catch {}
    loadingOrders.value = false
  } else if (key === 'redpacket') {
    inputMsg.value = '[红包]'
    sendMsg()
  } else if (key === 'report') {
    inputMsg.value = '[投诉反馈]'
  }
}

const sendOrderCard = async (order: any) => {
  try {
    const avatar = myAvatar || ''
    const res: any = await request.post({
      url: `/api/messages/${targetUserId}`,
      data: {
        userId: myUserId,
        userName: userStore.info?.userName || userStore.info?.username || '用户',
        userAvatar: avatar,
        content: '[订单]',
        messageType: 'order_card',
        orderCard: JSON.stringify(order)
      }
    })
    messages.value.push(res || { id: Date.now(), fromUserId: myUserId, content: '[订单]', messageType: 'order_card', orderCard: order, createTime: new Date().toISOString(), isRecalled: 0 })
    scrollToBottom()
  } catch {}
}

const sendMsg = async (imgUrl?: string) => {
  const txt = inputMsg.value.trim()
  if (!txt && !imgUrl) return; if (!targetUserId) return
  try {
    const avatar = myAvatar || ''
    const res: any = await fetchSendMessage(myUserId, userStore.info?.userName || userStore.info?.username || '用户', avatar, targetUserId, txt, imgUrl || '')
    messages.value.push(res || { id: Date.now(), fromUserId: myUserId, content: txt, imageUrl: imgUrl, createTime: new Date().toISOString(), isRead: 0, isRecalled: 0, reportStatus: 'none' })
    inputMsg.value = ''; scrollToBottom()
  } catch {}
}

const onMsgTouchStart = (e: TouchEvent, msg: MessageItem) => { longPressTimer = setTimeout(() => { menuMsg.value = msg }, 500) }
const onMsgTouchEnd = (_e: TouchEvent) => { if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null } }
const onMsgTouchCancel = () => { if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null } }
const closeMenu = () => { menuMsg.value = null }

const recallMsg = async (msg: MessageItem) => {
  try { await fetchRecallMessage(msg.id, myUserId); msg.isRecalled = 1; msg.content = ''; msg.imageUrl = ''; closeMenu() } catch (e: any) { alert(e?.msg || '撤回失败'); closeMenu() }
}

const showReportDialog = (msg: MessageItem) => { menuMsg.value = null; reportMsg.value = msg; reportReason.value = ''; reportDetail.value = '' }
const submitReport = async () => {
  if (!reportReason.value || !reportMsg.value) return
  try { await fetchReportMessage(reportMsg.value.id, myUserId, reportReason.value, reportDetail.value); reportMsg.value.reportStatus = 'reported'; reportMsg.value = null; reportReason.value = ''; reportDetail.value = '' } catch (e: any) { alert(e?.msg || '举报提交失败') }
}

const copyMsg = async (msg: MessageItem) => { try { await navigator.clipboard.writeText(msg.content); closeMenu() } catch { closeMenu() } }
const viewOrder = (card: any) => {
  orderDetail.value = card
  showOrderDetail.value = true
}

watch(() => route.params.targetUserId, () => { if (route.params.targetUserId) loadMessages(true) })

const loadMessages = async (shouldScroll = false) => {
  if (!targetUserId) return
  try {
    const res: any = await fetchMessages(myUserId, targetUserId)
    const list = Array.isArray(res) ? res : (res.list || [])
    messages.value = list.map((m: any) => {
      if (m.messageType === 'order_card') {
        if (m.orderCard && typeof m.orderCard === 'string') {
          try { m.orderCard = JSON.parse(m.orderCard) } catch { m.orderCard = null }
        }
        m.content = '[订单]'
      }
      if (m.messageType === 'order_card' && typeof m.content === 'string' && m.content.startsWith('{')) {
        try { m.orderCard = JSON.parse(m.content); m.content = '[订单]' } catch {}
      }
      return m
    })
    if (list.length > 0) {
      const last = list[list.length - 1]
      if (last.fromUserId === myUserId) {
        const pm = list.find((m: MessageItem) => m.fromUserId !== myUserId)
        if (pm) { chatName.value = pm.fromUserName; chatAvatar.value = pm.fromUserAvatar || '' }
      } else { chatName.value = last.fromUserName; chatAvatar.value = last.fromUserAvatar || '' }
    }
    if (!chatName.value && targetUserId) {
      try {
        const user: any = await request.get({ url: `/api/user/${targetUserId}`, showErrorMessage: false })
        if (user) {
          chatName.value = user.nickname || user.username || ''
          chatAvatar.value = user.avatar || ''
        }
      } catch {}
    }
    if (shouldScroll) { await nextTick(); scrollToBottom() }
  } catch {}
}

let pollTimer: any = null
onMounted(() => { loadMessages(true); pollTimer = setInterval(() => loadMessages(), 3000) })
onUnmounted(() => { if (pollTimer) clearInterval(pollTimer) })
</script>
