<template>
  <div class="ps-page">
    <div class="ps-header">
      <button class="ps-back" @click="goBack">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="ps-title">{{ currentFolder ? currentFolderName : '个人空间' }}</span>
      <div style="width:28px"></div>
    </div>

    <div class="ps-storage-card">
      <div class="ps-storage-label">存储空间</div>
      <div class="ps-storage-bar"><div class="ps-storage-fill" :style="{ width: storagePercent + '%' }"></div></div>
      <div class="ps-storage-text">{{ usedStr }} / {{ totalStr }}</div>
    </div>

    <!-- 文件夹视图 -->
    <div class="ps-list" v-if="!currentFolder">
      <div class="ps-list-header"><span>文件分类</span></div>
      <div v-if="loading" class="ps-loading">加载中...</div>
      <div v-else-if="folders.length === 0" class="ps-empty">暂无上传文件</div>
      <div v-else v-for="f in folders" :key="f.prefix" class="ps-file-item ps-folder" @click="enterFolder(f)">
        <div class="ps-file-icon">
          <svg v-if="f.name === 'img'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          <svg v-else-if="f.name === 'apk'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          <svg v-else-if="f.name === 'video'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
          <svg v-else-if="f.name === 'audio'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          <svg v-else-if="f.name === 'zip'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="1.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
          <svg v-else-if="f.name === 'doc'" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          <svg v-else width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        </div>
        <div class="ps-file-info">
          <div class="ps-file-name">{{ folderLabel(f.name) }}</div>
          <div class="ps-file-meta">{{ f.name }}/</div>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </div>
    </div>

    <!-- 文件视图 -->
    <div class="ps-list" v-else>
      <div class="ps-list-header ps-list-header-row">
        <span>{{ currentFolderName }} ({{ filesTotal }})</span>
        <div class="ps-page-btns">
          <button :disabled="page <= 1" @click="changePage(page - 1)">上一页</button>
          <span class="ps-page-num">{{ page }}/{{ totalPages }}</span>
          <button :disabled="page >= totalPages" @click="changePage(page + 1)">下一页</button>
        </div>
      </div>
      <div v-if="filesLoading" class="ps-loading">加载中...</div>
      <template v-else>
        <div class="ps-back-folder" @click="goBack">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
          返回上一页文件夹
        </div>
        <div v-if="files.length === 0" class="ps-empty">暂无文件</div>
        <template v-else>
          <div v-for="f in files" :key="f.key" class="ps-file-item" @click="showDetail(f)">
        <div class="ps-file-icon">
          <svg v-if="isImage(f)" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          <svg v-else-if="isVideo(f)" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
          <svg v-else-if="isAudio(f)" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
          <svg v-else-if="isApk(f)" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          <svg v-else width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
        </div>
        <div class="ps-file-info">
          <div class="ps-file-name">{{ f.name }}</div>
          <div class="ps-file-meta">{{ formatSize(f.size) }} / {{ formatTime(f.time) }}</div>
        </div>
        <button class="ps-file-del" :class="{ 'ps-file-locked': f.dbId }" @click.stop="f.dbId ? null : handleDelete(f)" :title="f.dbId ? '被引用，不可删除' : '删除'">
          <svg v-if="f.dbId" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          <svg v-else-if="deleting !== f.key" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          <span v-else class="ps-deleting">...</span>
        </button>
      </div>
      </template>
      </template>
    </div>

    <!-- 详情弹窗 -->
    <div v-if="detailVisible" class="ps-detail-overlay" @click.self="detailVisible = false">
      <div class="ps-detail-panel">
        <div class="ps-detail-header">
          <span class="ps-detail-title">文件详情</span>
          <button class="ps-detail-close" @click="detailVisible = false">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="ps-detail-body" v-if="detail">
          <div class="ps-detail-row"><span class="ps-dk">文件名</span><span class="ps-dv">{{ detail.name }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">大小</span><span class="ps-dv">{{ formatSize(detail.size) }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">类型</span><span class="ps-dv">{{ detail.type || '-' }}</span></div>
          <div class="ps-detail-row" v-if="detail.mime"><span class="ps-dk">MIME</span><span class="ps-dv">{{ detail.mime }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">分类</span><span class="ps-dv">{{ detail.category || '-' }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">上传时间</span><span class="ps-dv">{{ formatTime(detail.time) }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">数据库记录</span><span class="ps-dv">{{ detail.inDb ? '是（被引用，不可删）' : '否（可删除）' }}</span></div>
          <div class="ps-detail-row" v-if="detail.appName"><span class="ps-dk">所属应用</span><span class="ps-dv">{{ detail.appName }}</span></div>
          <div class="ps-detail-row" v-if="detail.appPackage"><span class="ps-dk">包名</span><span class="ps-dv">{{ detail.appPackage }}</span></div>
          <div class="ps-detail-row"><span class="ps-dk">路径</span><span class="ps-dv ps-dv-mono">{{ detail.key }}</span></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { ElMessage, ElMessageBox } from 'element-plus'

interface FileEntry {
  name: string; key: string; size: number; url: string; time: string; type: string;
  isFolder?: boolean; prefix?: string; dbId?: string | null;
}

interface DetailInfo {
  key: string; name: string; size: number; type: string; mime: string; category: string;
  time: string; inDb: boolean; appName: string; appPackage: string;
}

const router = useRouter()

const folders = ref<FileEntry[]>([])
const files = ref<FileEntry[]>([])
const allCloudFiles = ref<FileEntry[]>([])
const loading = ref(true)
const filesLoading = ref(false)
const usedBytes = ref(0)
const totalDataLimitMb = ref(200)
const currentFolder = ref('')
const deleting = ref<string | null>(null)
const page = ref(1)
const pageSize = 15
const detailVisible = ref(false)
const detail = ref<DetailInfo | null>(null)
const detailLoading = ref(false)

const currentFolderName = computed(() => currentFolder.value.replace(/\/$/, '').split('/').pop() || '')
const usedStr = computed(() => formatSize(usedBytes.value))
const totalStr = computed(() => formatSize(totalDataLimitMb.value * 1024 * 1024))
const storagePercent = computed(() => totalDataLimitMb.value > 0 ? Math.min(100, usedBytes.value / (totalDataLimitMb.value * 1024 * 1024) * 100) : 0)
const filesTotal = computed(() => allCloudFiles.value.length)
const totalPages = computed(() => Math.max(1, Math.ceil(allCloudFiles.value.length / pageSize)))

watch(page, () => {
  const start = (page.value - 1) * pageSize
  files.value = allCloudFiles.value.slice(start, start + pageSize)
})

function formatSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B'
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0, v = bytes
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(i > 0 ? 1 : 0) + ' ' + u[i]
}
function formatTime(t: string): string { return t ? t.replace('T', ' ').substring(0, 16) : '' }
function folderLabel(n: string) { return ({ img: '图片', apk: '应用安装包', video: '视频', audio: '音频', zip: '压缩包', doc: '文档', other: '其他' } as any)[n] || n }
function isImage(f: FileEntry) { return f.type && /^(jpg|jpeg|png|gif|webp|bmp|svg|ico)$/i.test(f.type) }
function isVideo(f: FileEntry) { return f.type && /^(mp4|avi|mov|wmv|flv|mkv|webm)$/i.test(f.type) }
function isAudio(f: FileEntry) { return f.type && /^(mp3|wav|ogg|aac|flac|m4a)$/i.test(f.type) }
function isApk(f: FileEntry) { return f.type === 'apk' }

async function loadFolders() {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/file-repo/my-files', showErrorMessage: false })
    if (res) {
      folders.value = (res.list || []).filter((f: FileEntry) => f.isFolder)
      usedBytes.value = res.usedBytes || 0
      totalDataLimitMb.value = res.totalDataLimitMb || 200
    }
  } catch {} finally { loading.value = false }
}

async function enterFolder(f: FileEntry) {
  currentFolder.value = f.prefix || ''
  page.value = 1
  filesLoading.value = true
  try {
    const res: any = await request.get({ url: '/api/file-repo/my-files', showErrorMessage: false, params: { prefix: f.prefix } })
    if (res) {
      allCloudFiles.value = (res.list || []).filter((item: FileEntry) => !item.isFolder)
      files.value = allCloudFiles.value.slice(0, pageSize)
    }
  } catch {} finally { filesLoading.value = false }
}

function changePage(p: number) {
  if (p < 1 || p > totalPages.value) return
  page.value = p
}

function goBack() {
  if (currentFolder.value) {
    currentFolder.value = ''
    files.value = []
    allCloudFiles.value = []
    page.value = 1
  } else {
    router.replace('/appstore/mine')
  }
}

async function handleDelete(file: FileEntry) {
  if (file.dbId) {
    ElMessage.warning('该文件被应用引用，不能直接删除')
    return
  }
  try { await ElMessageBox.confirm(`确定删除「${file.name}」？`, '确认删除', { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }) } catch { return }
  deleting.value = file.key
  try {
    const res: any = await request.post({ url: '/api/file-repo/my-file', data: { key: file.key } })
    if (res) {
      allCloudFiles.value = allCloudFiles.value.filter(f => f.key !== file.key)
      files.value = files.value.filter(f => f.key !== file.key)
      usedBytes.value = Math.max(0, usedBytes.value - (file.size || 0))
      ElMessage.success('删除成功')
    }
  } catch (err: any) { ElMessage.error(err?.message || '删除失败') }
  finally { deleting.value = null }
}

async function showDetail(f: FileEntry) {
  detailVisible.value = true
  detailLoading.value = true
  detail.value = null
  try {
    const res: any = await request.get({ url: '/api/file-repo/file-detail', showErrorMessage: false, params: { key: f.key } })
    if (res) detail.value = res
  } catch {} finally { detailLoading.value = false }
}

onMounted(() => { loadFolders() })
</script>

<style scoped lang="scss">
.ps-page { min-height: 100vh; background: #f5f7fa; }
.ps-header { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #fff; position: sticky; top: 0; z-index: 10; }
.ps-back { background: none; border: none; cursor: pointer; padding: 4px; color: #333; display: flex; align-items: center; }
.ps-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
.ps-storage-card { margin: 12px 16px; padding: 16px; background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.ps-storage-label { font-size: 14px; color: #666; margin-bottom: 8px; }
.ps-storage-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; }
.ps-storage-fill { height: 100%; background: linear-gradient(90deg, #6366F1, #8B5CF6); border-radius: 4px; transition: width .3s; }
.ps-storage-text { font-size: 12px; color: #999; margin-top: 6px; text-align: right; }
.ps-list { margin: 0 16px 24px; background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.06); overflow: hidden; }
.ps-list-header { padding: 14px 16px; font-size: 15px; font-weight: 600; color: #1a1a2e; border-bottom: 1px solid #f0f0f0; }
.ps-list-header-row { display: flex; align-items: center; justify-content: space-between; }
.ps-page-btns { display: flex; align-items: center; gap: 8px; }
.ps-page-btns button { padding: 4px 10px; font-size: 12px; border: 1px solid #d0d5dd; border-radius: 6px; background: #fff; color: #333; cursor: pointer; &:disabled { color: #ccc; cursor: not-allowed; } }
.ps-page-num { font-size: 12px; color: #999; min-width: 40px; text-align: center; }
.ps-loading, .ps-empty { padding: 40px 16px; text-align: center; color: #999; font-size: 14px; }
.ps-file-item { display: flex; align-items: center; padding: 12px 16px; border-bottom: 1px solid #f5f5f5; cursor: pointer; &:last-child { border-bottom: none; } &:active { background: #f8f9ff; } }
.ps-folder { cursor: pointer; }
.ps-file-icon { width: 40px; height: 40px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
.ps-file-info { flex: 1; margin-left: 12px; min-width: 0; }
.ps-file-name { font-size: 14px; color: #1a1a2e; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ps-file-meta { font-size: 12px; color: #999; margin-top: 2px; }
.ps-file-del { background: none; border: none; cursor: pointer; padding: 6px; flex-shrink: 0; opacity: .6; &:hover { opacity: 1; } &:disabled { cursor: not-allowed; } }
.ps-file-locked { cursor: default; opacity: .3; &:hover { opacity: .3; } }
.ps-deleting { color: #EF4444; font-size: 12px; }
.ps-back-folder { display: flex; align-items: center; gap: 6px; padding: 12px 16px; color: #6366F1; font-size: 13px; font-weight: 500; cursor: pointer; border-bottom: 1px solid #f0f0f0; &:active { background: #f8f9ff; } }
.ps-detail-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.4); z-index: 100; display: flex; align-items: flex-end; justify-content: center; }
.ps-detail-panel { width: 100%; max-width: 500px; background: #fff; border-radius: 16px 16px 0 0; padding: 0 0 24px; max-height: 70vh; overflow-y: auto; }
.ps-detail-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid #f0f0f0; }
.ps-detail-title { font-size: 16px; font-weight: 600; }
.ps-detail-close { background: none; border: none; cursor: pointer; padding: 4px; }
.ps-detail-body { padding: 16px 20px; }
.ps-detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f5f5f5; &:last-child { border: none; } }
.ps-dk { width: 80px; color: #999; font-size: 13px; flex-shrink: 0; }
.ps-dv { flex: 1; color: #333; font-size: 13px; word-break: break-all; }
.ps-dv-mono { font-family: monospace; font-size: 11px; }
</style>
