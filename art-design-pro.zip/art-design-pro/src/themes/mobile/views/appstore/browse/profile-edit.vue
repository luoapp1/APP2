<template>
  <div style="min-height: 100vh; background: var(--default-bg-color);">
    <div style="background: var(--default-bg-color); padding: 48px 16px 12px; display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="goBack" style="cursor: pointer; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg></div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">编辑资料</span>
    </div>

    <!-- 头图+头像区 -->
    <div style="background: linear-gradient(135deg, #0a1628 0%, #1e3265 100%); margin: 8px 16px 0; border-radius: 14px; padding: 24px 16px 18px; display: flex; flex-direction: column; align-items: center; position: relative; overflow: hidden;" :style="profileData.bgUrl ? { backgroundImage: 'url('+getBgUrl(profileData.bgUrl)+')', backgroundSize: 'cover', backgroundPosition: 'center' } : {}">
      <div @click="triggerBgUpload" style="position: absolute; top: 0; right: 0; font-size: 11px; color: rgba(255,255,255,0.5); padding: 8px 12px; cursor: pointer; background: rgba(0,0,0,0.2); border-radius: 0 14px 0 8px;" v-text="'更换背景'"></div>
      <div style="position: relative;" @click="triggerAvatarUpload">
        <div style="width: 72px; height: 72px; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; border: 3px solid rgba(255,255,255,0.3); box-shadow: 0 4px 16px rgba(255,100,80,0.4);">
          <img v-if="profileData.avatar" :src="$fixImgUrl(profileData.avatar)" style="width: 100%; height: 100%; object-fit: cover;" />
          <img v-else src="@imgs/user/avatar.webp" style="width: 100%; height: 100%; object-fit: cover;" />
        </div>
        <div style="position: absolute; bottom: 0; right: -2px; width: 22px; height: 22px; background: #24D6C4; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #fff; cursor: pointer;"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></div>
      </div>
      <div style="color: rgba(255,255,255,0.7); font-size: 12px; margin-top: 8px;">点击更换头像</div>
    </div>

    <!-- 信息列表 -->
    <div style="background: #fff; margin: 8px 16px; border-radius: 14px; overflow: hidden;">
      <div v-for="item in fields" :key="item.key"
        style="display: flex; align-items: center; padding: 0 16px; min-height: 50px; border-bottom: 1px solid #f5f6fa; cursor: pointer; transition: background 0.15s;"
        :style="{ cursor: item.editable || item.action ? 'pointer' : 'default' }"
        @click="handleFieldClick(item)">
        <span style="width: 68px; font-size: 14px; color: #333; flex-shrink: 0;">{{ item.label }}</span>
        <div style="flex: 1; display: flex; align-items: center; justify-content: flex-end; gap: 6px; min-width: 0;">
          <span style="font-size: 14px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" :style="{ color: item.danger ? '#FF4D4F' : item.editable ? '#999' : '#bbb' }">{{ item.value }}</span>
          <svg v-if="item.editable && !item.danger" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
        </div>
      </div>
    </div>

    <!-- 隐私设置 -->
    <div style="background: #fff; margin: 8px 16px; border-radius: 14px; padding: 8px 16px;">
      <div style="font-size: 13px; color: #999; padding: 6px 0 2px;">隐私设置</div>
      <div style="font-size: 11px; color: #bbb; margin-bottom: 8px;">开启后他人将看到"未知"</div>
      <div v-for="item in privacyItems" :key="item.key" style="display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-top: 1px solid #f5f6fa;">
        <span style="font-size: 13px; color: #333;">{{ item.label }}</span>
        <label class="privacy-switch">
          <input type="checkbox" v-model="item.value" @change="savePrivacy(item.key, item.value)">
          <span class="privacy-slider"></span>
        </label>
      </div>
      <div style="font-size: 11px; color: #ccc; padding: 8px 0 12px;">设置隐身后需返回个人主页刷新查看效果</div>
    </div>

    <!-- 底部操作 -->
    <div style="background: #fff; margin: 8px 16px; border-radius: 14px; overflow: hidden;">
      <div @click="showPwd = true" style="padding: 14px; text-align: center; border-bottom: 1px solid #f5f6fa; cursor: pointer; font-size: 14px; color: #333;">修改密码</div>
      <div @click="handleLogout" style="padding: 14px; text-align: center; border-bottom: 1px solid #f5f6fa; cursor: pointer; font-size: 14px; color: #FF4D4F;">退出登录</div>
      <div @click="handleDeleteAccount" style="padding: 14px; text-align: center; cursor: pointer; font-size: 14px; color: #bbb;">注销账号</div>
    </div>

    <!-- 编辑弹窗 -->
    <div v-if="editing" style="position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="closeEdit">
      <div style="background: #fff; border-radius: 16px; width: 310px; padding: 24px; box-shadow: 0 12px 40px rgba(0,0,0,0.12);">
        <div style="font-size: 17px; font-weight: 600; margin-bottom: 20px; color: #222; text-align: center;">修改{{ editing.label }}</div>
        <input v-if="editing.isDate" v-model="editValue" type="date" style="width: 100%; padding: 11px 14px; border: 1px solid #e8eaef; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 20px; background: #f8f9fb;" />
        <input v-else v-model="editValue" :placeholder="'请输入' + editing.label" style="width: 100%; padding: 11px 14px; border: 1px solid #e8eaef; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 20px; background: #f8f9fb;" />
        <div style="display: flex; gap: 12px;">
          <button @click="closeEdit" style="flex: 1; padding: 11px; border-radius: 12px; border: 1px solid #e8eaef; background: #fff; color: #666; font-size: 14px; cursor: pointer;">取消</button>
          <button @click="doSave" style="flex: 1; padding: 11px; border-radius: 12px; border: none; background: linear-gradient(135deg, #24D6C4, #1BBFAE); color: #fff; font-size: 14px; font-weight: 500; cursor: pointer;">保存</button>
        </div>
      </div>
    </div>

    <!-- 修改密码 -->
    <div v-if="showPwd" style="position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showPwd = false">
      <div style="background: #fff; border-radius: 16px; width: 310px; padding: 24px; box-shadow: 0 12px 40px rgba(0,0,0,0.12);">
        <div style="font-size: 17px; font-weight: 600; margin-bottom: 20px; color: #222; text-align: center;">修改密码</div>
        <input v-model="oldPwd" type="password" placeholder="原密码" style="width: 100%; padding: 11px 14px; border: 1px solid #e8eaef; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 12px; background: #f8f9fb;" />
        <input v-model="newPwd" type="password" placeholder="新密码" style="width: 100%; padding: 11px 14px; border: 1px solid #e8eaef; border-radius: 12px; font-size: 14px; outline: none; box-sizing: border-box; margin-bottom: 20px; background: #f8f9fb;" />
        <div style="display: flex; gap: 12px;">
          <button @click="showPwd = false" style="flex: 1; padding: 11px; border-radius: 12px; border: 1px solid #e8eaef; background: #fff; color: #666; font-size: 14px; cursor: pointer;">取消</button>
          <button @click="doChangePwd" style="flex: 1; padding: 11px; border-radius: 12px; border: none; background: linear-gradient(135deg, #24D6C4, #1BBFAE); color: #fff; font-size: 14px; font-weight: 500; cursor: pointer;">确定</button>
        </div>
      </div>
    </div>

    <!-- 注销确认 -->
    <div v-if="showDeleteConfirm" style="position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 100;" @click.self="showDeleteConfirm = false">
      <div style="background: #fff; border-radius: 16px; width: 310px; padding: 24px; box-shadow: 0 12px 40px rgba(0,0,0,0.12);">
        <div style="font-size: 17px; font-weight: 600; margin-bottom: 12px; color: #222; text-align: center;">注销账号</div>
        <div style="font-size: 13px; color: #999; text-align: center; margin-bottom: 20px; line-height: 1.6;">确定要注销账号吗？申请后需等待管理员审核。</div>
        <div style="display: flex; gap: 12px;">
          <button @click="showDeleteConfirm = false" style="flex: 1; padding: 11px; border-radius: 12px; border: 1px solid #e8eaef; background: #fff; color: #666; font-size: 14px; cursor: pointer;">取消</button>
          <button @click="doDeleteAccount" style="flex: 1; padding: 11px; border-radius: 12px; border: none; background: #FF4D4F; color: #fff; font-size: 14px; font-weight: 500; cursor: pointer;">确定注销</button>
        </div>
      </div>
    </div>

    <input ref="avatarInput" type="file" accept="image/*" style="display: none;" @change="onAvatarUpload" />
    <input ref="bgInput" type="file" accept="image/*" style="display: none;" @change="onBgUpload" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import request from '@/utils/http'
import { useUserStore } from '@/store/modules/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

const goBack = () => {
  if (window.history.length > 2) {
    router.back()
  } else {
    router.replace('/appstore/profile/' + (userStore.info.userId || ''))
  }
}

interface Field { key: string; label: string; value: string; editable: boolean; danger?: boolean; isDate?: boolean }
const fields = ref<Field[]>([])
const editing = ref<Field | null>(null)
const editValue = ref('')
const showPwd = ref(false)
const showDeleteConfirm = ref(false)
const hideBirthday = ref(false)
const hideQq = ref(false)
const hideEmail = ref(false)
const hideAddress = ref(false)

const privacyItems = [
  { key: 'hideBirthday', label: '隐藏生日/年龄', value: hideBirthday },
  { key: 'hideQq', label: '隐藏QQ', value: hideQq },
  { key: 'hideEmail', label: '隐藏邮箱', value: hideEmail },
  { key: 'hideAddress', label: '隐藏注册地址', value: hideAddress },
]

const savePrivacy = async (key: string, val: boolean) => {
  try {
    const body: any = { userId: userStore.info.userId || 1 }
    body[key] = val
    await request.put({ url: '/api/user/profile', data: body })
    ElMessage.success('已更新')
  } catch { ElMessage.error('保存失败') }
}
const oldPwd = ref('')
const newPwd = ref('')
const profileData = ref<any>({})
const avatarInput = ref<HTMLInputElement | null>(null)
const bgInput = ref<HTMLInputElement | null>(null)

const getBgUrl = (url: string) => url.startsWith('http') ? url : (url.startsWith('/uploads/') ? url : '')

const loadProfile = async () => {
  try {
    if (!userStore.isLogin) {
      router.replace('/appstore/browse/login')
      return
    }
    const userId = userStore.info.userId
    const d: any = await request.get({ url: '/api/user/profile?userId=' + userId })
    profileData.value = d
    if (d.avatar) userStore.info.avatar = d.avatar
    if (d.nickname) userStore.info.nickname = d.nickname
    if (d.bg_url !== undefined) (userStore.info as any).bg_url = d.bg_url
    fields.value = [
      { key: 'nickname', label: '名称', value: d.nickname || d.username || '', editable: true },
      { key: 'account', label: '账号', value: d.username || '', editable: false },
      { key: 'signature', label: '签名', value: d.signature || '这个人很懒，什么都没写...', editable: true },
      { key: 'qq', label: 'QQ', value: d.qq || '未绑定', editable: true },
      { key: 'email', label: '邮箱', value: d.email || '未绑定', editable: true },
      { key: 'birthday', label: '生日', value: d.birthday || '未设置', editable: !d.birthday, isDate: true },
      { key: 'phone', label: '手机', value: d.phone ? d.phone.slice(0,3)+'****'+d.phone.slice(-4) : '未绑定', editable: false },
      { key: 'id', label: 'ID', value: String(d.id || ''), editable: false },
    ]
    // 隐私设置
    hideBirthday.value = !!d.hideBirthday
    hideQq.value = !!d.hideQq
    hideEmail.value = !!d.hideEmail
    hideAddress.value = !!d.hideAddress
  } catch (e) { console.error(e) }
}

const triggerAvatarUpload = () => avatarInput.value?.click()
const triggerBgUpload = () => bgInput.value?.click()

const uploadFile = async (file: File, type: 'avatar' | 'background'): Promise<string> => {
  const fd = new FormData()
  fd.append('file', file)
  const res: any = await request.post({ url: `/api/upload/${type}`, data: fd })
  return res?.url || ''
}

const onAvatarUpload = async (e: Event) => {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  try {
    const url = await uploadFile(file, 'avatar')
    await request.put({ url: '/api/user/profile', data: { userId: userStore.info.userId || 1, avatar: url } })
    ElMessage.success('头像已更新')
    loadProfile()
  } catch { ElMessage.error('上传失败') }
}

const onBgUpload = async (e: Event) => {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  try {
    const url = await uploadFile(file, 'background')
    await request.put({ url: '/api/user/profile', data: { userId: userStore.info.userId || 1, bgUrl: url } })
    ElMessage.success('背景已更新')
    loadProfile()
  } catch { ElMessage.error('上传失败') }
}

const handleFieldClick = (item: Field) => {
  if (!item.editable) return
  editing.value = item
  editValue.value = item.value
}

const closeEdit = () => { editing.value = null; editValue.value = '' }

const doSave = async () => {
  if (!editing.value) return
  try {
    const body: any = { userId: userStore.info.userId || 1 }
    body[editing.value.key] = editValue.value
    await request.put({ url: '/api/user/profile', data: body })
    closeEdit()
    ElMessage.success('保存成功')
    loadProfile()
  } catch { ElMessage.error('保存失败') }
}

const doChangePwd = async () => {
  if (!oldPwd.value || !newPwd.value) return
  try {
    await request.post({ url: '/api/auth/change-pwd', data: { userId: userStore.info.userId || 1, oldPwd: oldPwd.value, newPwd: newPwd.value } })
    showPwd.value = false; oldPwd.value = ''; newPwd.value = ''
    ElMessage.success('密码已修改')
  } catch { ElMessage.error('修改失败') }
}

const handleLogout = () => { userStore.logOut?.(); router.push('/appstore/browse/login') }
const handleDeleteAccount = () => { showDeleteConfirm.value = true }
const doDeleteAccount = async () => {
  try {
    await request.post({ url: '/api/user/delete-request', data: { userId: userStore.info.userId || 1 } })
    showDeleteConfirm.value = false
    ElMessage.success('注销申请已提交，请等待管理员审核')
  } catch { ElMessage.error('提交失败') }
}

onMounted(() => loadProfile())
</script>
<style scoped>
.privacy-switch {
  position: relative; display: inline-block; width: 44px; height: 24px;
}
.privacy-switch input { opacity: 0; width: 0; height: 0; }
.privacy-slider {
  position: absolute; cursor: pointer; inset: 0;
  background: #ccc; border-radius: 24px; transition: 0.3s;
}
.privacy-slider:before {
  content: ""; position: absolute; height: 18px; width: 18px;
  left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: 0.3s;
}
.privacy-switch input:checked + .privacy-slider { background: #24D6C4; }
.privacy-switch input:checked + .privacy-slider:before { transform: translateX(20px); }
</style>
