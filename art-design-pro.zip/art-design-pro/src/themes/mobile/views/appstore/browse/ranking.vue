<template>
  <div style="min-height: 100vh; background: var(--default-bg-color); padding-bottom: 64px;">
    <div style="background: var(--default-bg-color); padding: 48px 16px 12px; display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">排行榜</span>
    </div>

    <div style="padding: 12px 16px;">
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 16px;">
        <div
          v-for="t in tabs"
          :key="t.key"
          @click="switchTab(t.key)"
          style="padding: 12px 6px; border-radius: 10px; text-align: center; cursor: pointer; transition: all .2s; border: 1.5px solid transparent;"
          :style="activeTab === t.key ? { background: '#f0f5ff', borderColor: '#409EFF' } : { background: '#fff' }"
        >
          <div style="font-size: 13px; font-weight: 600; color: #333;">{{ t.label }}</div>
          <div style="font-size: 10px; color: #999; margin-top: 2px;">{{ t.desc }}</div>
        </div>
      </div>

      <div v-if="loading" style="text-align: center; padding: 60px 0; color: #999;">加载中...</div>
      <div v-else-if="!list.length" style="text-align: center; padding: 60px 0; color: #999;">暂无数据</div>
      <div v-else>
        <div
          v-for="(item, idx) in list"
          :key="item.user_id"
          @click="goProfile(item.user_id)"
          style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #fff; border-radius: 10px; margin-bottom: 8px; cursor: pointer;"
        >
          <div style="width: 30px; text-align: center; flex-shrink: 0;">
            <span v-if="idx === 0" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #FFF7E6; color: #FAAD14; font-size: 13px; font-weight: 700;">1</span>
            <span v-else-if="idx === 1" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #F0F0F0; color: #999; font-size: 13px; font-weight: 700;">2</span>
            <span v-else-if="idx === 2" style="display: inline-flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #FFF0E6; color: #D4884A; font-size: 13px; font-weight: 700;">3</span>
            <span v-else style="font-size: 14px; font-weight: 600; color: #aaa;">{{ idx + 1 }}</span>
          </div>
          <div style="position: relative; width: 56px; height: 56px; flex-shrink: 0;">
            <img
              v-if="activeFrameUrl && item.user_id === currentUserId()"
              :src="activeFrameUrl"
              style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
            />
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; border-radius: 50%; overflow: hidden; background: #f3f4f6; z-index: 1;">
              <img :src="getAvatar(item)" style="width: 100%; height: 100%; object-fit: cover;" />
            </div>
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-size: 14px; font-weight: 500; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ item.nickname || item.username }}</div>
            <div style="font-size: 11px; color: #999; margin-top: 2px;">
              <span v-if="activeTab === 'apps'">{{ item.count }} 个应用</span>
              <span v-else-if="activeTab === 'posts'">{{ item.count }} 篇帖子</span>
              <span v-else-if="activeTab === 'experience'">
                <img v-if="item.level_icon" :src="item.level_icon" style="width:28px;height:28px;object-fit:contain;vertical-align:middle;margin-right:3px;display:inline;" />{{ item.count }} 经验
              </span>
              <span v-else>{{ item.count }} 积分</span>
            </div>
          </div>
          <button
            v-if="item.user_id !== currentUserId()"
            @click="(e) => handleFollow(item, e)"
            style="flex-shrink: 0; padding: 4px 12px; border-radius: 14px; font-size: 12px; border: none; cursor: pointer; font-weight: 500;"
            :style="item.is_followed ? { background: '#f0f0f0', color: '#999' } : { background: '#409EFF', color: '#fff' }"
          >
            {{ item.is_followed ? '已关注' : '+ 关注' }}
          </button>
          <svg style="width: 14px; height: 14px; color: #ccc; flex-shrink: 0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        </div>
      </div>
    </div>

    <div style="position: fixed; bottom: 0; left: 0; right: 0; background: #fff; border-top: 1px solid #f3f4f6; display: flex; align-items: center; justify-content: space-around; padding: 4px 0 calc(max(6px, env(safe-area-inset-bottom))); z-index: 10;">
      <div style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; color: #9ca3af;" @click="$router.push('/appstore/browse')">
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24"><path d="M4 21V9l8-6 8 6v12h-6v-7h-4v7H4z"/></svg>
        <span style="font-size: 10px">首页</span>
      </div>
      <div style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; color: #9ca3af;" @click="$router.push('/appstore/category')">
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/></svg>
        <span style="font-size: 10px">应用</span>
      </div>
      <div style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; color: #9ca3af;" @click="$router.push('/appstore/updates')">
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zM4.5 9c.83 0 1.5-.67 1.5-1.5S5.33 6 4.5 6 3 6.67 3 7.5 3.67 9 4.5 9zm15 0c.83 0 1.5-.67 1.5-1.5S20.33 6 19.5 6 18 6.67 18 7.5 18.67 9 19.5 9zm-15 6c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5zm15 0c-.83 0-1.5.67-1.5 1.5V18h3v-1.5c0-.83-.67-1.5-1.5-1.5z"/></svg>
        <span style="font-size: 10px">社区</span>
      </div>
      <div style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; color: #9ca3af;" @click="$router.push('/appstore/game')">
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24"><path d="M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z"/></svg>
        <span style="font-size: 10px">发现</span>
      </div>
      <div style="display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; color: #00bfa5;">
        <svg style="width: 20px; height: 20px" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <span style="font-size: 10px">我的</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'

const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('apps')
const list = ref<any[]>([])
const loading = ref(false)
const activeFrameUrl = ref('')
const defaultAvatar = defaultAvatarImg

const tabs = [
  { key: 'apps', label: '应用排行', desc: '发布数' },
  { key: 'posts', label: '帖子排行', desc: '帖子数' },
  { key: 'experience', label: '等级排行', desc: '经验值' },
  { key: 'points', label: '积分排行', desc: '积分数' },
]

const currentUserId = () => userStore.info?.userId || 0

function getAvatar(u: any) {
  if (u.avatar && (u.avatar.startsWith('http') || u.avatar.startsWith('/'))) return u.avatar
  return defaultAvatar
}

async function loadRanking(type: string) {
  loading.value = true
  try {
    const uid = currentUserId()
    const res: any = await request.get({ url: `/api/ranking/${type}?pageSize=50&userId=${uid}` })
    list.value = (res?.list || []).map((item: any) => {
      if (item.level_icon && !(item.level_icon.startsWith('http') || item.level_icon.startsWith('/') || item.level_icon.startsWith('data:'))) {
        return { ...item, level_icon: '' }
      }
      return item
    })
  } catch (e) { /* ignore */ }
  finally { loading.value = false }
}

async function handleFollow(item: any, event: Event) {
  event.stopPropagation()
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return
  }
  try {
    if (item.is_followed) {
      await request.post({ url: `/api/user/${item.user_id}/unfollow` })
      item.is_followed = 0
    } else {
      await request.post({ url: `/api/user/${item.user_id}/follow` })
      item.is_followed = 1
    }
  } catch (e: any) {
    // ignore
  }
}

function switchTab(key: string) {
  activeTab.value = key
  loadRanking(key)
}

function goProfile(uid: number) {
  router.push(`/u/${uid}`)
}

onMounted(() => {
  loadRanking(activeTab.value)
  loadActiveFrame()
})

async function loadActiveFrame() {
  if (!userStore.isLogin) return
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}
</script>
