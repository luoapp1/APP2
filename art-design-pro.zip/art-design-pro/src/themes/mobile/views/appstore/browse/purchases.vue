<template>
  <div class="ph-page">
    <div class="ph-navbar">
      <button class="ph-nav-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="ph-nav-title">购买记录</span>
      <div style="width:22px" />
    </div>

    <div class="ph-tabs">
      <button class="ph-tab" :class="{on:tab==='content'}" @click="tab='content'">付费内容</button>
      <button class="ph-tab" :class="{on:tab==='membership'}" @click="tab='membership'">会员</button>
    </div>

    <div v-if="tab==='content'" class="ph-list">
      <div v-if="!cpRecords.length" class="ph-empty">暂无购买记录</div>
      <div v-for="r in cpRecords" :key="'c'+r.id" class="ph-item">
        <div class="pi-left">
          <div class="pi-title">{{ r.content_title || '内容 #'+r.content_id }}</div>
          <div class="pi-meta">{{ r.content_type==='app'?'应用':'帖子' }} · {{ r.create_time?.slice(0,16) }}</div>
        </div>
        <div class="pi-right">
          <span class="pi-amount">{{ r.amount }}</span>
          <span class="pi-type">{{ r.pay_type==='balance'?'余额':'积分' }}</span>
        </div>
      </div>
    </div>

    <div v-else class="ph-list">
      <div v-if="!mpRecords.length" class="ph-empty">暂无会员购买记录</div>
      <div v-for="r in mpRecords" :key="'m'+r.id" class="ph-item">
        <div class="pi-left">
          <div class="pi-title">{{ r.level_name }}</div>
          <div class="pi-meta">{{ {buy:'购买',renew:'续费',upgrade:'升级'}[r.purchase_type] }} · {{ r.create_time?.slice(0,16) }}</div>
        </div>
        <div class="pi-right">
          <span class="pi-amount">{{ r.amount }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import request from '@/utils/http'

const tab = ref('content')
const cpRecords = ref<any[]>([])
const mpRecords = ref<any[]>([])

async function loadData() {
  try {
    const r1: any = await request.get({ url: '/api/content/purchases/my' })
    cpRecords.value = (r1.data?.records || r1.data || [])
    const r2: any = await request.get({ url: '/api/membership/purchases/my' })
    mpRecords.value = r2.data || r2 || []
  } catch {}
}

onMounted(loadData)
</script>

<style scoped>
.ph-page { min-height: 100vh; background: var(--app-page-bg); }
.ph-navbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: var(--default-bg-color); border-bottom: 1px solid #eee; }
.ph-nav-back { border: none; background: none; cursor: pointer; padding: 4px; }
.ph-nav-title { font-size: 17px; font-weight: 600; }
.ph-tabs { display: flex; background: var(--default-bg-color); padding: 0 16px; border-bottom: 1px solid #eee; }
.ph-tab { flex: 1; padding: 12px 0; border: none; background: none; font-size: 14px; color: #999; cursor: pointer; border-bottom: 2px solid transparent; }
.ph-tab.on { color: #6366F1; border-bottom-color: #6366F1; font-weight: 600; }
.ph-list { padding: 12px 16px; }
.ph-empty { text-align: center; padding: 32px; color: #999; }
.ph-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #fff; border-radius: 10px; margin-bottom: 8px; }
.pi-left { flex: 1; }
.pi-title { font-size: 14px; font-weight: 500; }
.pi-meta { font-size: 12px; color: #999; margin-top: 2px; }
.pi-right { text-align: right; }
.pi-amount { font-size: 16px; font-weight: 600; color: #EF4444; }
.pi-type { font-size: 12px; color: #999; }
</style>
