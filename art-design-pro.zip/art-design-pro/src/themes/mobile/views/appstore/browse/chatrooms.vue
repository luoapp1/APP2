<template>
  <div class="min-h-screen flex flex-col" style="background:var(--default-bg-color)">
    <div class="px-4 py-3 flex items-center justify-between border-b border-gray-100">
      <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-gray-700 cursor-pointer flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" @click="$router.back()">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
        <span class="text-base font-bold text-gray-800">聊天室</span>
      </div>
      <div v-if="canCreate" class="bg-[#AB47BC] text-white text-xs rounded-full w-[32px] h-[32px] flex items-center justify-center font-bold cursor-pointer active:opacity-80" @click="showCreate = true">+</div>
    </div>

    <div class="flex-1 overflow-y-auto">
      <!-- 我的聊天室 -->
      <div v-if="myRooms.length && !loading" class="px-4 pt-3">
        <div class="text-xs text-gray-400 mb-2 font-medium">我的聊天室</div>
        <div class="space-y-2 mb-3">
          <div
            v-for="r in myRooms"
            :key="r.id"
            class="flex items-center gap-3 bg-white rounded-xl p-3 cursor-pointer active:bg-gray-50"
            @click="enterRoom(r)"
          >
            <img
              v-if="resolveAvatar(r.avatar)"
              :src="resolveAvatar(r.avatar)"
              class="w-[44px] h-[44px] rounded-xl object-cover flex-shrink-0"
            />
            <div v-else class="w-[44px] h-[44px] rounded-xl flex items-center justify-center flex-shrink-0 text-white font-bold text-lg" :style="{ background: iconBg(r.id) }">
              {{ r.name[0] }}
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1">
                <span class="text-sm font-semibold text-gray-800">{{ r.name }}</span>
                <span v-if="r.myRole === 'owner'" class="text-[9px] bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded">群主</span>
                <span v-else-if="r.myRole === 'admin'" class="text-[9px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">管理</span>
              </div>
              <div class="text-xs text-gray-400 mt-0.5 truncate">{{ r.lastMsg || r.description || '暂无消息' }}</div>
              <div class="flex items-center justify-between mt-0.5">
                <span class="text-[10px] text-gray-300">{{ r.memberCount }} 人</span>
                <span v-if="r.lastMsgTime" class="text-[10px] text-gray-300">{{ fmtTime(r.lastMsgTime) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 发现聊天室 -->
      <div class="px-4 pt-3">
        <div class="flex items-center justify-between mb-1">
          <div class="text-xs text-gray-400 font-medium">发现聊天室</div>
          <div class="relative">
            <input
              v-model="keyword"
              class="text-xs bg-white rounded-full px-3 py-1.5 outline-none border border-gray-100 w-32"
              placeholder="搜索..."
              @keyup.enter="loadRooms"
            />
          </div>
        </div>
        <div v-if="loading" class="flex justify-center py-10">
          <div class="animate-spin w-5 h-5 border-2 border-[#AB47BC] border-t-transparent rounded-full" />
        </div>
        <div v-else-if="rooms.length === 0" class="flex flex-col items-center justify-center py-16">
          <svg class="w-14 h-14 text-gray-200 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
          </svg>
          <span class="text-sm text-gray-400">暂无聊天室</span>
        </div>
        <div v-else class="space-y-2 pb-4">
          <div
            v-for="r in rooms"
            :key="r.id"
            class="flex items-center gap-3 bg-white rounded-xl p-3 cursor-pointer active:bg-gray-50"
            @click="handleRoomClick(r)"
          >
            <img
              v-if="resolveAvatar(r.avatar)"
              :src="resolveAvatar(r.avatar)"
              class="w-[44px] h-[44px] rounded-xl object-cover flex-shrink-0"
            />
            <div v-else class="w-[44px] h-[44px] rounded-xl flex items-center justify-center flex-shrink-0 text-white font-bold text-lg" :style="{ background: iconBg(r.id) }">
              {{ r.name[0] }}
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1">
                <span class="text-sm font-semibold text-gray-800">{{ r.name }}</span>
                <svg v-if="r.hasPassword" class="w-3 h-3 text-gray-400" fill="currentColor" viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2z"/></svg>
              </div>
              <div class="text-xs text-gray-400 mt-0.5 truncate">{{ r.lastMsg || r.description || '暂无消息' }}</div>
              <div class="flex items-center justify-between mt-0.5">
                <span class="text-[10px] text-gray-300">{{ r.memberCount }} 人</span>
                <span v-if="r.lastMsgTime" class="text-[10px] text-gray-300">{{ fmtTime(r.lastMsgTime) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 创建聊天室弹窗 -->
    <div v-if="showCreate" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="showCreate = false">
      <div class="bg-white rounded-xl w-[85%] max-w-sm overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100">
          <div class="text-base font-semibold text-gray-800 text-center">创建聊天室</div>
        </div>
        <div class="px-5 py-4 space-y-3">
          <input v-model="createName" class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 outline-none text-gray-700" placeholder="聊天室名称" />
          <input v-model="createDesc" class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 outline-none text-gray-700" placeholder="聊天室简介（选填）" />
          <input v-model="createPassword" class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 outline-none text-gray-700" placeholder="入群密码（选填）" />
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="showCreate = false">取消</div>
          <div class="flex-1 py-3 text-center text-base font-medium cursor-pointer active:bg-gray-50" :class="createName.trim() ? 'text-[#AB47BC]' : 'text-gray-300'" @click="doCreate">创建</div>
        </div>
      </div>
    </div>

    <!-- 加入密码弹窗 -->
    <div v-if="showPwd" class="fixed inset-0 bg-black/40 flex items-center justify-center z-50" @click="showPwd = false">
      <div class="bg-white rounded-xl w-[85%] max-w-sm overflow-hidden" @click.stop>
        <div class="px-5 py-4 border-b border-gray-100">
          <div class="text-base font-semibold text-gray-800 text-center">请输入入群密码</div>
        </div>
        <div class="px-5 py-4">
          <input v-model="pwdInput" class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 outline-none text-gray-700" placeholder="输入密码" @keyup.enter="doJoin" />
        </div>
        <div class="flex border-t border-gray-100">
          <div class="flex-1 py-3 text-center text-base text-gray-500 cursor-pointer active:bg-gray-50 border-r border-gray-100" @click="showPwd = false">取消</div>
          <div class="flex-1 py-3 text-center text-base font-medium text-[#AB47BC] cursor-pointer active:bg-gray-50" @click="doJoin">加入</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import request from '@/utils/http'

const router = useRouter()
const userStore = useUserStore()
const myUserId = userStore.info?.userId || userStore.info?.id || 0

const rooms = ref<any[]>([])
const myRooms = ref<any[]>([])
const loading = ref(true)
const keyword = ref('')
const showCreate = ref(false)
const showPwd = ref(false)
const createName = ref('')
const createDesc = ref('')
const createPassword = ref('')
const pwdInput = ref('')
const pendingRoom = ref<any>(null)
const canCreate = ref(true)

const avatarModules = import.meta.glob('@/assets/images/avatar/*.webp', { eager: true })
const avatarMap: Record<string, string> = {}
for (const [path, mod] of Object.entries(avatarModules)) {
  const match = path.match(/avatar(\d+)\.webp$/)
  if (match) avatarMap[`avatar:${match[1]}`] = (mod as any).default
}
const resolveAvatar = (avatar: string) => {
  if (!avatar) return ''
  if (avatarMap[avatar]) return avatarMap[avatar]
  if (avatar?.startsWith('http') || avatar?.startsWith('/uploads')) return avatar.replace(/^http:\/\//i, 'https://')
  return ''
}

const toUtcDate = (t: string) => {
  if (!t) return new Date()
  return new Date(t.replace(' ', 'T') + 'Z')
}
const fmtTime = (t: string) => {
  if (!t) return ''
  const d = toUtcDate(t)
  const diff = Date.now() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
  return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
}

const colorPool = ['#AB47BC', '#FF5777', '#448AFF', '#FFB74D', '#66BB6A', '#26C6DA', '#00BFA5', '#F97316', '#8B5CF6', '#EC4899']
const iconBg = (id: number) => colorPool[id % colorPool.length]

const loadRooms = async () => {
  loading.value = true
  try {
    const res: any = await request.get({ url: '/api/chat-rooms', params: { keyword: keyword.value, pageSize: 100 } })
    rooms.value = Array.isArray(res) ? res : (res.list || [])
  } catch {}
  loading.value = false
}

const loadMyRooms = async () => {
  try {
    const res: any = await request.get({ url: '/api/chat-rooms/my', params: { userId: myUserId } })
    myRooms.value = Array.isArray(res) ? res : (res.list || [])
  } catch {}
}

const handleRoomClick = (r: any) => {
  if (r.password) {
    pendingRoom.value = r
    pwdInput.value = ''
    showPwd.value = true
  } else {
    doJoinRoom(r, '')
  }
}

const doJoin = () => {
  if (!pendingRoom.value) return
  doJoinRoom(pendingRoom.value, pwdInput.value)
  showPwd.value = false
}

const doJoinRoom = async (r: any, pwd: string) => {
  try {
    await request.post({ url: `/api/chat-rooms/${r.id}/join`, data: { userId: myUserId, password: pwd } })
    enterRoom(r)
  } catch {}
}

const enterRoom = (r: any) => {
  router.push(`/appstore/discover/chatroom/${r.id}`)
}

const doCreate = async () => {
  const name = createName.value.trim()
  if (!name) return
  try {
    const res: any = await request.post({
      url: '/api/chat-rooms',
      data: {
        userId: myUserId,
        userName: userStore.info?.userName || userStore.info?.username || '用户',
        name,
        description: createDesc.value.trim(),
        password: createPassword.value
      }
    })
    showCreate.value = false
    createName.value = ''
    createDesc.value = ''
    createPassword.value = ''
    enterRoom({ id: res.id || res.data?.id })
  } catch {}
}

const checkCanCreate = async () => {
  if (!myUserId) return
  try {
    const res: any = await request.get({ url: '/api/chat-rooms/can-create', params: { userId: myUserId } })
    canCreate.value = res.data?.canCreate ?? true
  } catch {}
}

onMounted(() => {
  loadRooms()
  if (myUserId) loadMyRooms()
  checkCanCreate()
})
</script>