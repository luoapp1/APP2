<template>
  <div style="min-height: 100vh; background: var(--app-page-bg); display: flex; flex-direction: column">
    <!-- 顶部导航栏 -->
    <div style="background: #fff; padding: 12px 16px; display: flex; align-items: center; gap: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">头像管理</span>
    </div>

    <div style="flex: 1; overflow-y: auto; padding-bottom: 16px">
      <!-- 顶部头像预览 -->
      <div
        style="display: flex; flex-direction: column; align-items: center; padding: 24px 16px 16px; background: #fff; margin: 0 0 12px 0; border-radius: 0 0 20px 20px"
      >
        <div style="position: relative; width: 120px; height: 120px; margin: 0 auto 12px">
          <img
            v-if="activeFrameUrl"
            :src="activeFrameUrl"
            style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none"
          />
          <img
            :src="userAvatar"
            style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 80px; height: 80px; border-radius: 50%; object-fit: cover"
          />
        </div>
        <div style="font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 4px">
          {{ activeFrameName || '未使用头像框' }}
        </div>
        <div style="display: flex; gap: 8px">
          <button
            v-if="activeFrameId"
            style="font-size: 12px; color: #ef4444; border: none; background: none; cursor: pointer"
            @click="handleCancelFrame"
          >取消使用</button>
          <button
            style="font-size: 12px; color: #00bfa5; border: none; background: none; cursor: pointer"
            :disabled="autoGrantLoading"
            @click="handleAutoGrant"
          >{{ autoGrantLoading ? '同步中...' : '同步获取' }}</button>
        </div>
      </div>

      <!-- 未登录 -->
      <div v-if="!isLogin" style="text-align: center; padding: 40px; color: #9ca3af">
        <p style="margin-bottom: 16px">请先登录后查看</p>
        <button
          style="padding: 10px 32px; border-radius: 8px; border: none; background: #00bfa5; color: #fff; font-size: 14px; cursor: pointer"
          @click="$router.push('/appstore/browse/login')"
        >去登录</button>
      </div>

      <!-- 头像框列表 -->
      <div v-else style="padding: 0 16px">
        <div style="font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 12px">
          头像框列表
          <span style="font-size: 12px; color: #9ca3af; margin-left: 4px">(点击使用)</span>
        </div>

        <div v-if="loading" style="text-align: center; padding: 40px; color: #9ca3af">加载中...</div>

        <div v-else-if="grantMsg" style="text-align: center; color: #00bfa5; font-size: 13px; padding: 8px 0">{{ grantMsg }}</div>

        <div
          v-else
          style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px"
        >
          <div
            v-for="frame in frames"
            :key="frame.id"
            style="background: #fff; border-radius: 14px; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; cursor: pointer; border: 2px solid transparent; position: relative"
            :style="{
              borderColor: frame.isActive ? '#00bfa5' : 'transparent',
              opacity: frame.owned ? '1' : '0.55'
            }"
            @click="handleSelectFrame(frame)"
          >
            <div style="position: relative; width: 52px; height: 52px; margin-bottom: 8px">
              <img
                :src="$fixImgUrl(frame.image_url)"
                style="width: 100%; height: 100%; object-fit: contain; border-radius: 8px"
              />
              <div
                v-if="!frame.owned"
                style="position: absolute; inset: 0; background: rgba(0,0,0,.3); border-radius: 8px; display: flex; align-items: center; justify-content: center"
              >
                <svg style="width: 20px; height: 20px; color: #fff" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM12 17c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
                </svg>
              </div>
            </div>
            <div style="font-size: 13px; font-weight: 600; color: #1f2937; text-align: center; margin-bottom: 4px; line-height: 1.2">
              {{ frame.name }}
            </div>
            <div style="font-size: 10px; color: #9ca3af; text-align: center">
              {{ (frame.owned ? '' : '(未获取) ') + getObtainLabel(frame.obtain_type || frame.obtainType) }}
            </div>
            <div v-if="frame.isActive" style="position: absolute; top: 4px; right: 4px; background: #00bfa5; color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px">使用中</div>
          </div>
        </div>

        <div v-if="!loading && frames.length === 0" style="text-align: center; padding: 40px; color: #9ca3af">
          暂未上传头像框
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import defaultAvatarImg from '@imgs/user/avatar.webp'
import { useUserStore } from '@/store/modules/user'
import { fetchUserAvatarFrames, fetchActiveFrame, fetchAutoGrantFrame } from '@/api/avatar-frame'

const router = useRouter()
const userStore = useUserStore()

const loading = ref(false)
const autoGrantLoading = ref(false)
const frames = ref<any[]>([])
const activeFrameId = ref(0)
const activeFrameName = ref('')
const activeFrameUrl = ref('')
const switchingId = ref(0)
const grantMsg = ref('')

const isLogin = computed(() => userStore.isLogin)
const userInfo = computed(() => userStore.info || {})
const userAvatar = computed(() => userInfo.value.avatar || defaultAvatarImg)

function getObtainLabel(type: string) {
  if (type === 'experience') return '经验等级获取'
  if (type === 'membership') return '会员等级获取'
  if (type === 'activity') return '活动获取'
  return '手动授予'
}

function formatDate(d: string) {
  try { return new Date(d).toLocaleDateString('zh-CN') } catch { return '' }
}

async function loadFrames() {
  if (!isLogin.value) return
  loading.value = true
  try {
    const res: any = await fetchUserAvatarFrames()
    frames.value = (res.frames || []).sort((a: any, b: any) => {
      if (a.owned === b.owned) return 0
      return a.owned ? -1 : 1
    })
    activeFrameId.value = res.activeFrameId || 0
    const activeFrame = frames.value.find((f: any) => f.isActive)
    activeFrameName.value = activeFrame?.name || ''
    activeFrameUrl.value = activeFrame?.image_url || ''
  } catch {} finally { loading.value = false }
}

async function handleSelectFrame(frame: any) {
  if (!frame.owned) {
    // 提示
    return
  }
  if (frame.isActive) return
  switchingId.value = frame.id
  try {
    await fetchActiveFrame(frame.id)
    activeFrameId.value = frame.id
    activeFrameName.value = frame.name
    activeFrameUrl.value = frame.image_url
    frames.value.forEach((f: any) => { f.isActive = f.id === frame.id })
  } catch {} finally { switchingId.value = 0 }
}

async function handleCancelFrame() {
  switchingId.value = -1
  try {
    await fetchActiveFrame(0)
    activeFrameId.value = 0
    activeFrameName.value = ''
    activeFrameUrl.value = ''
    frames.value.forEach((f: any) => { f.isActive = false })
  } catch {} finally { switchingId.value = 0 }
}

async function handleAutoGrant() {
  autoGrantLoading.value = true
  grantMsg.value = ''
  try {
    const res: any = await fetchAutoGrantFrame()
    grantMsg.value = res.message || '操作成功'
    loadFrames()
  } catch { grantMsg.value = '操作失败，请重试' }
  finally {
    autoGrantLoading.value = false
    setTimeout(() => { grantMsg.value = '' }, 3000)
  }
}

onMounted(() => {
  if (isLogin.value) loadFrames()
})
</script>
