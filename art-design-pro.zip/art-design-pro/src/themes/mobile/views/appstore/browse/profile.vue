<template>
  <div class="pg">

    <!-- ===== 封面 220px ===== -->
    <div class="cover" :class="{ coverLight: !profile.bgUrl }" :style="profile.bgUrl ? { backgroundImage: 'url('+profile.bgUrl+')', backgroundSize:'cover', backgroundPosition:'center' } : {}">
      <canvas ref="starCanvas" class="stars"></canvas>
      <div v-if="profile.bgUrl" style="position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(180deg,rgba(26,26,46,0.3),rgba(48,48,80,0.6));z-index:2;pointer-events:none;"></div>

      <!-- 顶部导航 -->
      <div class="nav">
        <div class="navL">
          <div class="navBack" @click="goBack">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
          </div>
          <!-- 自己：显示用户名 -->
          <span v-if="isSelf" class="navTitle">{{ profile.nickname || profile.username || '个人主页' }}</span>
        </div>
        <div class="navR">
          <template v-if="!isSelf">
            <div class="navAct" @click="handleReport">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              <span>{{ isBlocked ? '已拉黑' : '举报/拉黑' }}</span>
            </div>
            <div class="navAct" @click="handleReward">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
              <span>打赏</span>
            </div>
            <div class="navAct" :class="{ followed: isFollowing }" @click="handleProfileFollow">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.5"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
              <span>{{ isFollowing ? '已关注' : '关注' }}</span>
            </div>
          </template>
          <!-- 他人：显示取消 -->
          <span v-if="!isSelf" class="navCancel" @click="$router.back()">取消</span>
        </div>
      </div>

      <!-- 头像 -->
      <div
        v-if="isSelf"
        style="position: absolute; bottom: -36px; left: 20px; z-index: 11; width: 116px; height: 116px;"
        @click="goAvatarFrame"
      >
        <img
          v-if="activeFrameUrl"
          :src="activeFrameUrl"
          style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; z-index: 0"
        />
        <div class="avt"
          style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); bottom: auto; cursor: pointer; z-index: 1;"
        >
          <img v-if="profile.avatar && (profile.avatar.startsWith('http')||profile.avatar.startsWith('/'))" :src="fixImgUrl(profile.avatar)" class="avtImg" />
          <img v-else src="@imgs/user/avatar.webp" class="avtImg" />
        </div>
      </div>
      <div v-else class="avt">
        <img v-if="profile.avatar && (profile.avatar.startsWith('http')||profile.avatar.startsWith('/'))" :src="fixImgUrl(profile.avatar)" class="avtImg" />
        <img v-else src="@imgs/user/avatar.webp" class="avtImg" />
      </div>

      <!-- 右下悬浮按钮 -->
      <button v-if="isSelf" class="rBtn editBtn" @click="goEdit">编辑</button>
      <button v-else class="rBtn msgBtn" @click="handleMessage">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
        私信
      </button>
    </div>

    <!-- ===== 白色信息卡 ===== -->
    <div class="card">

      <!-- 用户信息区 -->
      <div class="info">
        <div class="nameRow">
          <span class="name">{{ profile.nickname || profile.username || '用户' }}</span>
          <span class="vipBadge">{{ profile.levelName || '黄金会员' }}</span>
        </div>

        <!-- 官方认证 -->
        <div v-if="certification.verified" class="verifyRow">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="#4E8CFF"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          <span>官方认证: {{ certification.verified ? (certification.title || '已认证') : '未认证' }}</span>
        </div>

        <div class="sig">{{ profile.signature || '这个人很懒，什么都没写...' }}</div>

        <!-- 统计行：空格分隔，无竖线 -->
        <div class="statRow">
          <div class="statBox">
            <span class="statNum">{{ formatNum(userPosts.length) }}</span>
            <span class="statLbl">动态</span>
          </div>
          <div class="statBox statLink" @click="switchTab('关注')">
            <span class="statNum">{{ formatNum(profile.followCount || 0) }}</span>
            <span class="statLbl">关注</span>
          </div>
          <div class="statBox statLink" @click="switchTab('粉丝')">
            <span class="statNum">{{ formatNum(profile.fansCount || 0) }}</span>
            <span class="statLbl">粉丝</span>
          </div>
          <div class="statBox">
            <span class="statNum">{{ formatNum(profile.points || profile.balance || 0) }}</span>
            <span class="statLbl">积分</span>
          </div>
        </div>
      </div>

      <!-- Tab栏 -->
      <div class="tabs">
        <div
          v-for="t in tabs"
          :key="t"
          class="tab"
          :class="{ on: activeTab === t }"
          @click="switchTab(t)"
        >
          <span class="tabTxt">{{ t }}</span>
          <span v-if="activeTab === t" class="tabDot"></span>
        </div>
      </div>

      <!-- Tab内容 -->
      <div class="content" v-loading="tabLoading">

        <!-- ===== 资料 Tab ===== -->
        <div v-if="activeTab==='资料'" class="plist">
          <!-- App ID -->
          <div class="prow">
            <span class="pl">App ID</span>
            <span class="pv">{{ profile.id || '-' }}</span>
          </div>
          <!-- 经验称号 -->
          <div class="prow">
            <span class="pl">经验等级</span>
            <span class="pv">
              <span class="expCard" :style="levelCardStyle">
                <span class="expLvl">{{ profile.expLevelName || 'Lv.1' }}</span>
              </span>
            </span>
          </div>
          <!-- 称号名称 -->
          <div class="prow" v-if="profile.activeTitleName">
            <span class="pl">称号名称</span>
            <span class="pv">
              <span class="titleLabel" :style="titleStyle">{{ profile.activeTitleName }}</span>
            </span>
          </div>
          <!-- 称号图标 -->
          <div class="prow">
            <span class="pl">称号图标</span>
            <span class="pv pvBadges">
              <span v-if="profile.activeTitleName" class="titleIconOnly" :style="{background:profile.activeTitleBgColor||'#ecf5ff'}" :title="profile.activeTitleName">
                <img v-if="profile.activeTitleIcon" :src="profile.activeTitleIcon" class="titleIconImg" />
                <svg v-else width="20" height="20" viewBox="0 0 24 24" :fill="profile.activeTitleColor||'#F9A825'"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
              </span>
              <span v-else class="titleIconOnly" style="background:#EEE;" title="暂无称号">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="#999"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
              </span>
            </span>
          </div>
          <!-- 他的身份 -->
          <div class="prow">
            <span class="pl">{{ isSelf ? '我的身份' : '他的身份' }}</span>
            <span class="pv">
              <template v-if="identityTags.length">
                <span v-for="(r, i) in identityTags" :key="'r'+i" class="idTag" :style="r.style">{{ r.label }}</span>
              </template>
              <span v-else class="idTag">普通用户</span>
            </span>
          </div>
          <!-- 年龄 -->
          <div class="prow">
            <span class="pl">{{ isSelf ? '我的年龄' : '他的年龄' }}</span>
            <span class="pv">{{ showField('hideBirthday', profile.birthday ? (profile.age != null ? profile.age + '岁' : '') : '') }}</span>
          </div>
          <!-- 交友QQ (带右箭头) -->
          <div class="prow prowLink">
            <span class="pl">交友QQ</span>
            <span class="pv">{{ showField('hideQq', profile.qq) }}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
          </div>
          <!-- 邮箱 -->
          <div class="prow">
            <span class="pl">邮箱</span>
            <span class="pv">{{ showField('hideEmail', profile.email) }}</span>
          </div>
          <!-- 注册地址 -->
          <div class="prow">
            <span class="pl">注册地址</span>
            <span class="pv">{{ showField('hideAddress', profile.registerAddress) }}</span>
          </div>
          <!-- 活跃状态 -->
          <div class="prow">
            <span class="pl">活跃状态</span>
            <span class="pv">
              <span v-if="profile.banUntil && new Date(profile.banUntil) > new Date()" class="sdot ban"></span>
              <span v-else-if="profile.status === '1'" class="sdot onl"></span>
              <span v-else class="sdot off"></span>
              {{ statusText }}
            </span>
          </div>
          <!-- 注册时间 -->
          <div class="prow">
            <span class="pl">注册时间</span>
            <span class="pv">{{ formatDate(profile.createTime) }}</span>
          </div>
        </div>

        <!-- ===== 应用 ===== -->
        <div v-if="activeTab==='应用'" class="aplist">
          <div v-if="blockedByUser" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg></div>
            <div class="empTxt" style="color:#e74c3c">你已被对方拉黑，无法查看内容</div>
          </div>
          <div v-else-if="userApps.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/></svg></div>
            <div class="empTxt">暂无应用</div>
          </div>
          <div v-for="a in userApps" :key="a.id" class="acard" @click="goAppDetail(a.id)">
            <div class="aicon" :style="{background:a.iconBg||'#22C1D0'}">
              <img v-if="a.icon" :src="fixImgUrl(a.icon)" class="aiconImg" />
              <svg v-else width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/></svg>
            </div>
            <div class="ainfo">
              <div class="aname">{{ a.name }}</div>
              <div class="ameta">{{ a.category||'应用' }} · {{ formatNum(a.downloadCount||0) }} 次下载</div>
            </div>
            <div class="arate">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="#FFB800"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span>{{ a.rating||5.0 }}</span>
            </div>
          </div>
        </div>

        <!-- ===== 帖子 ===== -->
        <div v-if="activeTab==='帖子'" class="plst">
          <div v-if="blockedByUser" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg></div>
            <div class="empTxt" style="color:#e74c3c">你已被对方拉黑，无法查看内容</div>
          </div>
          <div v-else-if="userPosts.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></div>
            <div class="empTxt">暂无帖子</div>
          </div>
          <div v-for="p in userPosts" :key="'p'+p.id" class="pcard" @click="goPostDetail(p.id)">
            <div class="pauth">
              <div class="paavt">
                <img v-if="profile.avatar&&(profile.avatar.startsWith('http')||profile.avatar.startsWith('/'))" :src="fixImgUrl(profile.avatar)" class="paavtImg" />
                <img v-else src="@imgs/user/avatar.webp" class="paavtImg" />
              </div>
              <div class="pauinfo">
                <div class="pauname">{{ profile.nickname||profile.username }}</div>
                <div class="paumeta">{{ formatTime(p.createTime) }} · {{ p.views||0 }} 阅读</div>
              </div>
            </div>
            <div class="ptitle">{{ p.title||'无标题' }}</div>
            <!-- JSON内容块渲染 -->
            <div v-if="p.content" class="pcontent">
              <template v-if="parseContent(p.content).type==='blocks'">
                <template v-for="(blk, bi) in parseContent(p.content).blocks" :key="'b'+bi">
                  <!-- 文本 -->
                  <div v-if="blk.type==='text' && blk.value" class="pcontent-text">{{ blk.value }}</div>
                  <!-- 应用卡片 -->
                  <div v-else-if="blk.type==='app'" class="pcontent-app" @click.stop="goAppDetail(blk.appId)">
                    <div class="papp-icon" :style="{background:blk.appIcon?'':'#22C1D0'}">
                      <img v-if="blk.appIcon" :src="blk.appIcon" style="width:100%;height:100%;object-fit:cover;border-radius:8px;" />
                      <svg v-else width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/></svg>
                    </div>
                    <div class="papp-info">
                      <div class="papp-name">{{ blk.appName }}</div>
                      <div class="papp-desc">{{ blk.desc || '' }}</div>
                    </div>
                    <span v-if="blk.coinCount" class="papp-price">{{ blk.coinCount }}积分</span>
                  </div>
                  <!-- 链接卡片 -->
                  <div v-else-if="blk.type==='link'" class="pcontent-link" @click.stop="openLink(blk.url)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4E8CFF" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                    <div class="plink-info">
                      <div class="plink-title">{{ blk.title || blk.url }}</div>
                      <div class="plink-url">{{ blk.url }}</div>
                    </div>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                  </div>
                  <!-- 附件卡片 -->
                  <div v-else-if="blk.type==='attachment'" class="pcontent-attach">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FF9800" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    <div class="pattach-info">
                      <div class="pattach-name">{{ blk.title }}</div>
                      <div class="pattach-meta">
                        <span v-if="blk.desc">{{ blk.desc }}</span>
                        <span v-if="blk.priceType==='free'" class="pattach-tag free">免费</span>
                        <span v-else-if="blk.coin" class="pattach-tag coin">{{ blk.coin }}积分</span>
                        <span v-if="blk.extractCode" class="pattach-code">提取码:{{ blk.extractCode }}</span>
      </div>
    </div>

                  </div>
                  <!-- 图片块 -->
                  <div v-else-if="blk.type==='image' && blk.images && blk.images.length" class="pcontent-imgs">
                    <img v-for="(img, ii) in blk.images.slice(0,3)" :key="'img'+ii" :src="img" class="pcontent-img" />
                    <span v-if="blk.images.length>3" class="pimgcnt">+{{ blk.images.length-3 }}</span>
                  </div>
                </template>
              </template>
              <div v-else class="pexcerpt">{{ parseContent(p.content).text }}</div>
            </div>
            <div v-if="p.images&&p.images.length" class="pimgs">
              <img :src="p.images[0]" class="pimg" />
              <span v-if="p.images.length>1" class="pimgcnt">{{ p.images.length }}图</span>
            </div>
            <div v-if="p.tags&&p.tags.length" class="ptags">
              <span v-for="(tg,i) in p.tags" :key="'tg'+i" class="ptag">{{ tg }}</span>
            </div>
            <div class="pacts">
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
                <span>{{ formatNum(p.likeCount||0) }}</span>
              </div>
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                <span>{{ formatNum(p.commentCount||0) }}</span>
              </div>
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <span>{{ formatNum(p.favoriteCount||0) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- ===== 回复 ===== -->
        <div v-if="activeTab==='回复'" class="clist">
          <div v-if="communityComments.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg></div>
            <div class="empTxt">暂无回复</div>
          </div>
          <div v-for="c in communityComments" :key="'cc'+c.id" class="ccard" @click="c.postId&&goPostDetail(c.postId)">
            <div class="chead">
              <div class="cavt">
                <img v-if="profile.avatar&&(profile.avatar.startsWith('http')||profile.avatar.startsWith('/'))" :src="fixImgUrl(profile.avatar)" class="cavtImg" />
                <img v-else src="@imgs/user/avatar.webp" class="cavtImg" />
              </div>
              <div class="cname">{{ profile.nickname||profile.username }}</div>
              <span class="ctime">{{ formatTime(c.createTime) }}</span>
            </div>
            <div class="cbody" v-html="c.content||''"></div>
            <div v-if="c.postTitle" class="cref">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              <span>{{ c.postTitle }}</span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          </div>
        </div>

        <!-- ===== 关注 ===== -->
        <div v-if="activeTab==='关注'" class="flist">
          <div v-if="followings.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><circle cx="12" cy="8" r="5"/><path d="M3 21v-1c0-3.87 3.58-7 8-7s8 3.13 8 7v1"/></svg></div>
            <div class="empTxt">暂无关注</div>
          </div>
          <div v-for="f in followings" :key="'fg'+f.id" class="frow" @click="goUserProfile(f.id)">
            <div class="favt">
              <img v-if="f.avatar&&(f.avatar.startsWith('http')||f.avatar.startsWith('/'))" :src="fixImgUrl(f.avatar)" class="favtImg" />
              <img v-else src="@imgs/user/avatar.webp" class="favtImg" />
            </div>
            <div class="finfo">
              <div class="fname">{{ f.nickname||f.username }}</div>
              <div class="fdesc">{{ f.signature||'' }}</div>
            </div>
            <button class="fbtn fed" @click.stop="handleUnfollow(f.id)">已关注</button>
          </div>
        </div>

        <!-- ===== 粉丝 ===== -->
        <div v-if="activeTab==='粉丝'" class="flist">
          <div v-if="followers.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><circle cx="12" cy="8" r="5"/><path d="M3 21v-1c0-3.87 3.58-7 8-7s8 3.13 8 7v1"/></svg></div>
            <div class="empTxt">暂无粉丝</div>
          </div>
          <div v-for="f in followers" :key="'ff'+f.id" class="frow" @click="goUserProfile(f.id)">
            <div class="favt">
              <img v-if="f.avatar&&(f.avatar.startsWith('http')||f.avatar.startsWith('/'))" :src="fixImgUrl(f.avatar)" class="favtImg" />
              <img v-else src="@imgs/user/avatar.webp" class="favtImg" />
            </div>
            <div class="finfo">
              <div class="fname">{{ f.nickname||f.username }}</div>
              <div class="fdesc">{{ f.signature||'' }}</div>
            </div>
            <button v-if="!followingIds.has(f.id)" class="fbtn" @click.stop="handleFollow(f.id)">关注</button>
            <button v-else class="fbtn fed" @click.stop="handleUnfollow(f.id)">已关注</button>
          </div>
        </div>

        <!-- ===== 收藏 ===== -->
        <div v-if="activeTab==='收藏'" class="plst">
          <div v-if="userFavorites.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div>
            <div class="empTxt">暂无收藏</div>
          </div>
          <div v-for="p in userFavorites" :key="'f'+p.id" class="pcard" @click="goPostDetail(p.id)">
            <div class="pauth">
              <div class="paavt">
                <img v-if="p.userAvatar&&(p.userAvatar.startsWith('http')||p.userAvatar.startsWith('/'))" :src="p.userAvatar" class="paavtImg" />
                <img v-else src="@imgs/user/avatar.webp" class="paavtImg" />
              </div>
              <div class="pauinfo">
                <div class="pauname">{{ p.userName }}</div>
                <div class="paumeta">{{ formatTime(p.createTime) }}</div>
              </div>
            </div>
            <div class="ptitle">{{ p.title||'无标题' }}</div>
            <div v-if="p.content" class="pcontent">
               <div class="pcontent-text">{{ getContentText(p) }}</div>
            </div>
            <div class="pacts">
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
                <span>{{ formatNum(p.likeCount||0) }}</span>
              </div>
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                <span>{{ formatNum(p.commentCount||0) }}</span>
              </div>
              <div class="pact">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#B7C0C8" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <span>{{ formatNum(p.favoriteCount||0) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- ===== 商品 ===== -->
        <div v-if="activeTab==='商品'" style="padding:6px 10px">
          <div v-if="userProducts.length===0" class="empty">
            <div class="empIcon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#c8ccd4" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg></div>
            <div class="empTxt">暂无商品</div>
          </div>
          <div class="mall-grid">
            <div v-for="p in userProducts" :key="'mp'+p.id" class="mall-card" @click="goMallDetail(p.id)">
              <div class="mall-card-img-wrap">
                <img v-if="p.coverImage" :src="fixImgUrl(p.coverImage)" class="mall-card-img" />
                <div v-else class="mall-card-img mall-card-img-fb">
                  <span class="mall-card-fb-text">{{ p.name }}</span>
                </div>
                <div v-if="p.salesCount > 100" class="mall-card-badge hot">热卖</div>
                <div v-else-if="p.originalPrice > p.price" class="mall-card-badge coupon">券</div>
              </div>
              <div class="mall-card-body">
                <div class="mall-card-name">{{ p.name }}</div>
                <div class="mall-card-tags" v-if="(p.tags || []).length">
                  <span v-for="t in (p.tags || []).slice(0,3)" :key="t" class="mall-card-tag">{{ t }}</span>
                </div>
                <div class="mall-card-price-row">
                  <span class="mall-card-price-currency">{{ priceCurrency(p) }}</span>
                  <span class="mall-card-price-num">{{ priceValue(p) }}</span>
                  <span v-if="p.originalPrice > p.price" class="mall-card-original">{{ priceOriginal(p) }}</span>
                </div>
                <div class="mall-card-footer">
                  <span class="mall-card-sold">已售 {{ p.salesCount || 0 }}</span>
                  <span class="mall-card-buy">去购买</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- 举报/拉黑弹窗 -->
    <div v-if="showReportDialog" class="reportOverlay" @click.self="showReportDialog = false">
      <div class="reportDialog">
        <div class="reportTitle">{{ isBlocked ? '取消拉黑' : '举报并拉黑' }}</div>
        <template v-if="!isBlocked">
          <textarea v-model="reportReason" class="reportInput" placeholder="请描述举报原因（选填）" maxlength="200"></textarea>
          <div style="display:flex;gap:10px;margin-top:16px">
            <button class="reportBtn cancel" @click="showReportDialog = false">取消</button>
            <button class="reportBtn confirm" :disabled="reportLoading" @click="submitReport">{{ reportLoading ? '提交中...' : '确认拉黑' }}</button>
          </div>
        </template>
        <template v-else>
          <div style="color:#666;font-size:14px;margin-bottom:12px">已拉黑该用户，取消拉黑后对方将能重新看到你的内容。</div>
          <div style="display:flex;gap:10px">
            <button class="reportBtn cancel" @click="showReportDialog = false">关闭</button>
            <button class="reportBtn confirm" :disabled="reportLoading" @click="submitUnblock">{{ reportLoading ? '处理中...' : '取消拉黑' }}</button>
          </div>
        </template>
      </div>
    </div>
  </div>

  <!-- 打赏弹窗 -->
  <div v-if="showRewardDialog" class="reportOverlay" @click.self="showRewardDialog = false">
    <div class="reportDialog" style="width:340px">
      <div class="reportTitle" style="text-align:center;margin-bottom:12px">打赏</div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;padding:10px;background:#f8f9fb;border-radius:10px">
        <img v-if="profile.avatar && (profile.avatar.startsWith('http')||profile.avatar.startsWith('/'))" :src="fixImgUrl(profile.avatar)" style="width:40px;height:40px;border-radius:50%;object-fit:cover" />
        <img v-else src="@imgs/user/avatar.webp" style="width:40px;height:40px;border-radius:50%;object-fit:cover" />
        <div>
          <div style="font-size:14px;font-weight:600;color:#1a1a1a">{{ profile.nickname || profile.username || '用户' }}</div>
          <div style="font-size:12px;color:#999">向该用户打赏积分或余额</div>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-bottom:16px">
        <button class="rewardTab" :class="{ on: rewardType === 'points' }" @click="rewardType = 'points'">积分</button>
        <button class="rewardTab" :class="{ on: rewardType === 'balance' }" @click="rewardType = 'balance'">余额</button>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <button v-for="amt in quickAmounts" :key="amt" class="quickAmtBtn" :class="{ on: rewardAmount === String(amt) }" @click="rewardAmount = String(amt); handleQuickReward(amt)">
          {{ rewardType === 'points' ? amt + '积分' : amt + '元' }}
        </button>
      </div>
      <input v-model="rewardAmount" class="reportInput" type="number" placeholder="自定义金额" style="min-height:44px" />
      <div style="font-size:12px;color:#999;margin-top:6px">{{ rewardType === 'points' ? '单位：积分' : '单位：元' }}</div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="reportBtn cancel" @click="showRewardDialog = false">取消</button>
        <button class="reportBtn confirm" :disabled="rewardLoading" @click="submitReward" style="background:#4E8CFF">{{ rewardLoading ? '处理中...' : '确认打赏' }}</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import request from '@/utils/http'
import { fetchUserFavorites } from '@/api/community'
import { useUserStore } from '@/store/modules/user'
import { ElMessage } from 'element-plus'
import { fetchUserAvatarFrames } from '@/api/avatar-frame'
import { fetchPublicVerificationStatus } from '@/api/verification'
import { blockUser, unblockUser, fetchBlockStatus, fetchBlockedByStatus } from '@/api/user-block'

const certification = ref({ verified: false, title: '' })
const loadCertification = async (userId: number) => {
  try {
    const data: any = await fetchPublicVerificationStatus(userId)
    if (data && data.isVerified) {
      certification.value = { verified: true, title: data.certificationTitle || '' }
    }
  } catch {}
}

const activeFrameUrl = ref('')
const loadActiveFrame = async () => {
  try {
    const res: any = await fetchUserAvatarFrames()
    const active = res.frames?.find((f: any) => f.isActive)
    activeFrameUrl.value = active?.image_url || ''
  } catch {}
}

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const profile = ref<any>({})
const userApps = ref<any[]>([])
const userPosts = ref<any[]>([])
const communityComments = ref<any[]>([])
const userFavorites = ref<any[]>([])
const userProducts = ref<any[]>([])
const followers = ref<any[]>([])
const followings = ref<any[]>([])
const followingIds = ref<Set<number>>(new Set())
const roleMap = ref<Record<string,string>>({})
const activeTab = ref('资料')
const tabs = ref(['资料', '应用', '帖子', '回复', '粉丝', '关注', '收藏', '商品'])
const starCanvas = ref<HTMLCanvasElement|null>(null)
const tabLoading = ref(false)
const loadedTabs = ref<Set<string>>(new Set(['资料']))

const isSelf = computed(() => {
  const pid = String(route.params.userId || '')
  const mid = String(userStore.info.userId || '')
  return !pid || pid === mid
})

const showField = (hideKey: string, value: any) => {
  if (profile.value[hideKey] && !isSelf.value) return '未知'
  return value || '未知'
}

const statusText = computed(() => {
  const p = profile.value
  if (p.banUntil && new Date(p.banUntil) > new Date()) return '封禁中'
  if (p.status === '1') return '正常'
  if (p.status === '0') return '已禁用'
  return '未知'
})

const levelCardStyle = computed(() => {
  const color = profile.value.expIconColor || '#00BFA5'
  return { background: hexToRgba(color, 0.1), color, borderColor: color }
})
const hexToRgba = (hex: string, alpha: number) => {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `rgba(${r},${g},${b},${alpha})`
}
const titleStyle = computed(() => ({
  background: profile.value.activeTitleBgColor || '#ecf5ff',
  color: profile.value.activeTitleColor || '#409EFF'
}))

const identityTags = computed(() => {
  const roles = profile.value.roles
  if (!roles || !Array.isArray(roles) || roles.length === 0) return []
  const colors = ['#E3F2FD:#1565C0', '#FFF3E0:#E65100', '#E8F5E9:#2E7D32', '#F3E5F5:#7B1FA2', '#FCE4EC:#C62828']
  return roles.map((r: string, i: number) => {
    const [bg, c] = (colors[i] || '#f0f0f0:#666').split(':')
    const label = roleMap.value[r] || r
    return { label, style: { background: bg, color: c } }
  })
})

const formatNum = (n:number) => {
  if(n>=10000) return (n/10000).toFixed(1)+'w'
  if(n>=1000) return (n/1000).toFixed(1)+'k'
  return String(n)
}
const formatDate = (d:string) => {
  if(!d) return '未知'
  const t = new Date(d)
  return t.getFullYear()+'年'+String(t.getMonth()+1).padStart(2,'0')+'月'+String(t.getDate()).padStart(2,'0')+'日'
}
const formatTime = (d:string) => {
  if(!d) return ''
  const n=new Date(),t=new Date(d),m=Math.floor((n.getTime()-t.getTime())/60000)
  if(m<1)return'刚刚'
  if(m<60)return m+'分钟前'
  const h=Math.floor(m/60)
  if(h<24)return h+'小时前'
  const dy=Math.floor(h/24)
  if(dy<30)return dy+'天前'
  return d.slice(0,10)
}
const stripHtml = (h:string) => {
  if(!h) return ''
  const t = h.replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').trim()
  return t.length>120?t.slice(0,120)+'...':t
}

const parseContent = (content: string) => {
  if (!content) return { type: 'text', text: '' }
  try {
    const parsed = JSON.parse(content)
    if (Array.isArray(parsed)) {
      let cardShown = false
      const blocks = parsed.map((b: any) => {
        if (b.type === 'text' && b.value && b.value.length > 80) {
          return { ...b, value: b.value.slice(0, 80) + '...' }
        }
        return b
      }).filter((b: any) => {
        if (b.type === 'text') return true
        if (b.type === 'image' || b.type === 'link' || b.type === 'app' || b.type === 'attachment') {
          if (cardShown) return false
          cardShown = true
          return true
        }
        return true
      })
      return { type: 'blocks', blocks }
    }
    if (parsed && typeof parsed === 'object' && parsed.type) {
      if (parsed.type === 'text' && parsed.value && parsed.value.length > 80) {
        return { type: 'blocks', blocks: [{ ...parsed, value: parsed.value.slice(0, 80) + '...' }] }
      }
      return { type: 'blocks', blocks: [parsed] }
    }
  } catch {}
  if (content.length > 5000) return { type: 'text', text: '内容无法预览' }
  return { type: 'text', text: stripHtml(content) }
}

const getContentText = (p: any) => {
  const content = p?.content || ''
  if (!content) return ''

  const perm = p?.contentPermission || ''
  const userStore = useUserStore()
  const uid = (userStore.info as any)?.userId || (userStore.info as any)?.id || 0

  if (p?.postUserId === uid) {
    const parsed = parseContent(content)
    if (parsed.type === 'blocks') {
      return (parsed.blocks as any[]).filter((b: any) => b.type === 'text').map((b: any) => b.value || '').join(' ')
    }
    return parsed.text || ''
  }

  if (perm === 'paid') return '[付费内容]'
  if (perm === 'password') return '[需要密码]'
  if (perm === 'login') return '[登录后可见]'
  if (perm === 'comment') return '[评论后可见]'
  if (perm && perm.startsWith('level')) return '[特定等级可见]'

  if (perm === 'mixed') {
    try {
      const blocks = JSON.parse(content)
      if (Array.isArray(blocks)) {
        const publicText = blocks.filter((b: any) => {
          const v = b.visibility || 'public'
          return b.type === 'text' && v === 'public' && b.value
        }).map((b: any) => b.value).join(' ')
        if (publicText) return publicText
        const hasPaid = blocks.some((b: any) => b.visibility === 'paid')
        if (hasPaid) return '[付费内容]'
        const typeBlocks = blocks.filter((b: any) => b.type === 'text')
        if (typeBlocks.length > 0) return typeBlocks.map((b: any) => b.value || '').join(' ')
      }
    } catch {}
    const parsed = parseContent(content)
    if (parsed.type === 'blocks') {
      return (parsed.blocks as any[]).filter((b: any) => b.type === 'text').map((b: any) => b.value || '').join(' ')
    }
    return parsed.text || ''
  }

  const parsed = parseContent(content)
  if (parsed.type === 'blocks') {
    return (parsed.blocks as any[])
      .filter((b: any) => b.type === 'text')
      .map((b: any) => b.value || '')
      .join(' ')
  }
  return parsed.text || ''
}

const buildIds = () => { const s=new Set<number>(); followings.value.forEach((f:any)=>s.add(f.id)); followingIds.value=s }

const handleFollow = async (uid:number) => {
  try{ await request.post({url:`/api/user/${uid}/follow`}); followingIds.value.add(uid); ElMessage.success('已关注') } catch{ ElMessage.error('操作失败') }
}
const handleUnfollow = async (uid:number) => {
  try{ await request.del({url:`/api/user/${uid}/follow`}); followingIds.value.delete(uid); followings.value=followings.value.filter((f:any)=>f.id!==uid); ElMessage.success('已取消关注') } catch{ ElMessage.error('操作失败') }
}

const loadProfile = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:'/api/user/profile?userId='+uid})
    profile.value = d
  } catch {}
}
const loadRoleMap = async () => {
  try {
    const d:any = await request.get({url:'/api/role/list'})
    const records = d?.records || d?.data?.records || []
    const map: Record<string,string> = {}
    records.forEach((r:any) => { map[r.roleCode] = r.roleName })
    roleMap.value = map
  } catch {}
}
const loadApps = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:'/api/user/apps?userId='+uid})
    userApps.value = d?.list||[]
  } catch {}
}
const loadPosts = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:`/api/community/posts?userId=${uid}&pageSize=20`})
    userPosts.value = d?.list||[]
  } catch {}
}
const loadCComments = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:`/api/user/community-comments?userId=${uid}&pageSize=20`})
    communityComments.value = d?.list||[]
  } catch {}
}
const loadFavorites = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await fetchUserFavorites({ pageSize: 20 })
    userFavorites.value = d?.data?.list || d?.list || []
  } catch {}
}
const loadUserProducts = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:`/api/mall/products?userId=${uid}&pageSize=50`})
    userProducts.value = d?.list||[]
  } catch {}
}
const priceCurrency = (p: any) => p.priceType === 'points' ? '' : '¥'
const priceValue = (p: any) => p.price
const priceOriginal = (p: any) => p.priceType === 'points' ? p.originalPrice + '积分' : '¥' + p.originalPrice
const fixImgUrl = (url: string) => url ? url.replace(/^http:\/\//i, 'https://') : ''
const loadFollowers = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:`/api/user/${uid}/followers?pageSize=20`})
    followers.value = d?.list||[]
    if(followers.value.length>0&&followingIds.value.size===0) loadFollowings()
  } catch {}
}
const loadFollowings = async () => {
  try {
    const uid = route.params.userId||userStore.info.userId||1
    const d:any = await request.get({url:`/api/user/${uid}/following?pageSize=20`})
    followings.value = d?.list||[]
    buildIds()
  } catch {}
}

const switchTab = async (t:string) => {
  activeTab.value=t
  if(loadedTabs.value.has(t)) return
  tabLoading.value=true
  try {
    if(t==='帖子') await loadPosts()
    else if(t==='应用') await loadApps()
    else if(t==='回复') await loadCComments()
    else if(t==='粉丝') await loadFollowers()
    else if(t==='关注') await loadFollowings()
    else if(t==='收藏') await loadFavorites()
    else if(t==='商品') await loadUserProducts()
    loadedTabs.value.add(t)
  } finally { tabLoading.value=false }
}

const drawStars = () => {
  nextTick(()=>{
    const c=starCanvas.value; if(!c) return
    const x=c.getContext('2d'); if(!x) return
    c.width=c.offsetWidth; c.height=c.offsetHeight
    for(let i=0;i<50;i++){
      const px=Math.random()*c.width, py=Math.random()*c.height, r=Math.random()*1.5+0.3
      x.beginPath(); x.arc(px,py,r,0,Math.PI*2)
      x.fillStyle=`rgba(255,255,255,${Math.random()*0.5+0.15})`
      x.fill()
    }
  })
}

const goEdit = () => router.push('/appstore/profile/edit')
const goAvatarFrame = () => router.push('/appstore/avatar-frame')
const goBack = () => {
  if (window.history.length > 1) {
    router.back()
  } else {
    router.push('/appstore/mine')
  }
}
const goAppDetail = (id:number) => router.push(`/appstore/browse/detail/${id}`)
const goPostDetail = (id:number) => router.push(`/community/post/${id}`)
const goUserProfile = (id:number) => router.push(`/appstore/profile/${id}`)
const goMallDetail = (id:number) => router.push(`/appstore/mall-detail/${id}`)
const handleMessage = () => {
  const targetId = Number(route.params.userId) || profile.value.id
  if (targetId) {
    router.push(`/chat/${targetId}`)
  } else {
    ElMessage.warning('暂无法发起私信')
  }
}
const showReportDialog = ref(false)
const reportReason = ref('')
const reportLoading = ref(false)
const isBlocked = ref(false)
const handleReport = async () => {
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return ElMessage.warning('暂无法获取用户信息')
  try {
    const res: any = await fetchBlockStatus(targetId)
    isBlocked.value = !!(res && res.isBlocked)
  } catch { isBlocked.value = false }
  showReportDialog.value = true
}
const submitReport = async () => {
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return
  reportLoading.value = true
  try {
    await blockUser(targetId, reportReason.value)
    ElMessage.success('拉黑成功')
    isBlocked.value = true
  } catch { ElMessage.error('操作失败') }
  reportLoading.value = false
}
const submitUnblock = async () => {
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return
  reportLoading.value = true
  try {
    await unblockUser(targetId)
    ElMessage.success('取消拉黑成功')
    showReportDialog.value = false
    isBlocked.value = false
  } catch { ElMessage.error('操作失败') }
  reportLoading.value = false
}
const showRewardDialog = ref(false)
const rewardType = ref<'points'|'balance'>('points')
const rewardAmount = ref('')
const rewardLoading = ref(false)
const quickAmounts = [1, 5, 10, 50, 100]
const handleReward = () => {
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return ElMessage.warning('暂无法获取用户信息')
  rewardAmount.value = ''
  rewardType.value = 'points'
  showRewardDialog.value = true
}
const handleQuickReward = (amt: number) => {
  rewardAmount.value = String(amt)
}
const submitReward = async () => {
  const targetId = Number(route.params.userId) || 0
  const amount = Number(rewardAmount.value)
  if (!amount || amount <= 0) return ElMessage.warning('请输入有效的金额')
  rewardLoading.value = true
  try {
    const isPoints = rewardType.value === 'points'
    await request.post({
      url: isPoints ? '/api/transfer/points' : '/api/transfer/balance',
      data: { toUserId: targetId, amount, remark: '打赏' }
    })
    ElMessage.success(`成功打赏 ${amount} ${isPoints ? '积分' : '元余额'}`)
    showRewardDialog.value = false
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '打赏失败')
  }
  rewardLoading.value = false
}

const isFollowing = ref(false)
const followLoading = ref(false)

const checkFollowStatus = async () => {
  if (isSelf.value) return
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return
  try {
    const res: any = await request.get({ url: `/api/user/${targetId}/follow-status` })
    isFollowing.value = !!(res && res.isFollowing)
  } catch {}
}

const handleProfileFollow = async () => {
  if (!userStore.isLogin) {
    router.push('/appstore/browse/login')
    return
  }
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return
  followLoading.value = true
  try {
    if (isFollowing.value) {
      await request.del({ url: `/api/user/${targetId}/follow` })
      isFollowing.value = false
      ElMessage.success('已取消关注')
    } else {
      await request.post({ url: `/api/user/${targetId}/follow` })
      isFollowing.value = true
      ElMessage.success('关注成功')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || e?.msg || '操作失败')
  }
  followLoading.value = false
}

const blockedByUser = ref(false)
const checkBlockStatus = async () => {
  if (isSelf.value) return
  const targetId = Number(route.params.userId) || 0
  if (!targetId) return
  try {
    const [resBy, resBlock] = await Promise.all([
      fetchBlockedByStatus(targetId),
      fetchBlockStatus(targetId)
    ])
    blockedByUser.value = !!(resBy && (resBy as any).isBlockedBy)
    isBlocked.value = !!(resBlock && (resBlock as any).isBlocked)
  } catch {}
}
const openLink = (url: string) => { if (url) window.open(url, '_blank') }

onMounted(()=>{ loadProfile(); loadRoleMap(); loadApps(); loadPosts(); drawStars(); loadActiveFrame(); loadCertification(Number(route.params.userId || userStore.info.userId || 0)); checkBlockStatus(); checkFollowStatus() })

watch(() => route.params.userId, (newId, oldId) => {
  if (newId && newId !== oldId) {
    activeTab.value = '资料'
    loadedTabs.value = new Set(['资料'])
    followers.value = []
    followings.value = []
    userApps.value = []
    userPosts.value = []
    userFavorites.value = []
    userProducts.value = []
    communityComments.value = []
    loadProfile()
    loadApps()
    loadPosts()
    loadActiveFrame()
    loadCertification(Number(newId))
    checkBlockStatus()
    checkFollowStatus()
    isFollowing.value = false
    isBlocked.value = false
    blockedByUser.value = false
  }
})
</script>

<style scoped>
.pg { position:relative; min-height:100vh; background:var(--default-bg-color); overflow-x:hidden; }

/* ===== 封面 ===== */
.cover {
  position:relative; height:220px;
  background: #fff;
  overflow:hidden;
}
.coverLight .navTitle { color: #333 !important; }
.coverLight .navBack svg { stroke: #333 !important; }
.coverLight .navAct svg { stroke: #333 !important; }
.coverLight .navAct span { color: #333 !important; }
.coverLight .navCancel { color: #333 !important; }
.coverLight .editBtn,
.coverLight .msgBtn { box-shadow: 0 2px 8px rgba(0,0,0,0.15); }
.stars { position:absolute; top:0;left:0;width:100%;height:100%;z-index:1;pointer-events:none; }

.nav {
  position:absolute; top:0;left:0;right:0;z-index:10;
  padding:42px 14px 0;
  display:flex; align-items:flex-start; justify-content:space-between;
}
.navL { display:flex; align-items:center; gap:10px; }
.navBack { width:20px;height:20px; display:flex;align-items:center;justify-content:center; cursor:pointer; }
.navTitle { color:#fff; font-size:16px; font-weight:600; }
.navR { display:flex; align-items:center; gap:14px; }
.navAct { display:flex; align-items:center; gap:3px; cursor:pointer; }
.navAct span { color:rgba(255,255,255,0.9); font-size:13px; }
.navAct.followed span { color:#ffe082; }
.navCancel { color:rgba(255,255,255,0.9); font-size:13px; cursor:pointer; }

/* 头像 */
.avt {
  position:absolute; bottom:-36px; left:20px; z-index:11;
  width:96px; height:96px; border-radius:50%; overflow:hidden;
  box-shadow: 0 0 0 5px #448AFF, 0 0 0 7px rgba(68,138,255,0.3), 0 6px 20px rgba(0,0,0,0.25);
}
.avtImg { width:100%;height:100%;object-fit:cover; }
.avtPlh {
  width:100%;height:100%;
  background:radial-gradient(circle at 50% 50%,#FFC107 0%,#FF5252 70%);
  display:flex;align-items:center;justify-content:center;
}

/* 右下悬浮按钮 */
.rBtn {
  position:absolute; bottom:-14px; right:16px; z-index:11;
  border:none; border-radius:18px;
  padding:8px 18px; font-size:14px; font-weight:600; cursor:pointer;
}
.editBtn { background:#2979FF; color:#fff; box-shadow:0 2px 6px rgba(41,121,255,0.25); }
.msgBtn {
  background:linear-gradient(135deg,#4E8CFF,#2D6BFF); color:#fff;
  display:flex; align-items:center; gap:5px;
  box-shadow:0 3px 10px rgba(45,107,255,0.3);
}

/* ===== 白色信息卡 ===== */
.card {
  position:relative; z-index:5;
  background:#fff; border-radius:20px 20px 0 0;
  margin-top:-16px; padding-top:44px;
  min-height:calc(100vh - 204px);
}

/* 用户信息 */
.info { padding:0 16px; }
.nameRow { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.name { color:#D81B60; font-size:22px; font-weight:700; line-height:1.2; }
.vipBadge {
  background:#00BFA5; color:#fff;
  font-size:11px; font-weight:500;
  padding:3px 6px; border-radius:10px;
}
.certBadge {
  background:linear-gradient(135deg,#3b82f6,#6366f1); color:#fff;
  font-size:11px; font-weight:500;
  padding:3px 8px; border-radius:10px;
}

/* 勋章图标 (他人) */
.medalIcon {
  width:20px; height:20px; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
}
.genderIcon {
  width:20px; height:20px; border-radius:50%;
  background:#E3F2FD;
  display:flex; align-items:center; justify-content:center;
}

/* 官方认证 (他人) */
.verifyRow {
  display:flex; align-items:center; gap:6px;
  margin-top:2px;
}
.verifyRow span { font-size:13px; color:#666; }

.sig { font-size:13px; color:#9E9E9E; margin-top:4px; line-height:1.4; }

/* 统计行：空格分隔 */
.statRow {
  display:flex; align-items:center;
  margin-top:6px; padding:8px 0;
}
.statBox { display:flex; align-items:center; gap:3px; margin-right:28px; }
.statLink { cursor:pointer; }
.statLink:active { opacity:0.6; }
.statNum { color:#212121; font-size:16px; font-weight:700; }
.statLbl { color:#757575; font-size:12px; }

/* ===== Tab ===== */
.tabs {
  display:flex; padding:0 6px;
  border-bottom:1px solid #F0F0F0;
  margin-top:2px;
}
.tab {
  position:relative; padding:10px 8px 8px; cursor:pointer;
  display:flex; flex-direction:column; align-items:center;
}
.tabTxt { font-size:13px; color:#9E9E9E; font-weight:400; }
.tab.on .tabTxt { color:#000; font-weight:700; font-size:14px; }
.tabDot {
  position:absolute; bottom:1px;
  width:5px; height:5px; border-radius:50%; background:#F44336;
}

/* 内容区 */
.content { min-height:300px; }

/* ===== 资料列表 ===== */
.prow {
  display:flex; align-items:center;
  padding:5px 16px;
}
.prowLink { cursor:pointer; }
.pl { width:70px; font-size:13px; color:#9E9E9E; flex-shrink:0; }
.pv {
  flex:1; font-size:13px; color:#212121;
  display:flex; align-items:center; gap:4px;
}
.pvBadges { gap:3px; }

/* 经验称号卡片 */
.expCard {
  display:flex; align-items:center; gap:6px;
  padding:3px 10px; border-radius:10px;
  border:1.5px solid;
}
.expLvl { font-size:12px; font-weight:700; }
.expTitleTag { font-size:11px; font-weight:500; opacity:0.85; }
/* 称号图标（纯图标） */
.titleIconOnly {
  width:36px; height:36px; border-radius:10px;
  display:flex; align-items:center; justify-content:center;
  cursor:pointer;
  transition: transform 0.2s ease;
}
.titleIconOnly:hover { transform: scale(1.3); }
.titleIconImg { width:100%;height:100%;object-fit:cover;border-radius:10px; }
.titleLabel {
  font-size:12px; font-weight:600;
  padding:3px 10px; border-radius:8px;
}
.idTag {
  font-size:11px; font-weight:500;
  padding:2px 8px; border-radius:8px;
  background:#E8F5E9; color:#2E7D32;
}
.sdot { display:inline-block; width:7px;height:7px;border-radius:50%; vertical-align:middle; margin-right:3px; }
.sdot.onl { background:#22d160; }
.sdot.off { background:#ccc; }
.sdot.ban { background:#ff3860; }

/* ===== 空状态 ===== */
.empty {
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  padding:60px 20px;
}
.empIcon { width:60px;height:48px;border-radius:10px;background:#f2f3f5;display:flex;align-items:center;justify-content:center; }
.empTxt { color:#c0c4cc; font-size:13px; margin-top:10px; }

/* ===== 应用 ===== */
.aplist { padding:6px 12px; }
.acard {
  display:flex; align-items:center; gap:10px;
  padding:12px; background:#fff; border-radius:14px;
  margin-bottom:6px; box-shadow:0 1px 2px rgba(0,0,0,.03); cursor:pointer;
}
.aicon { width:42px;height:42px;border-radius:10px;flex-shrink:0;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 6px rgba(0,0,0,.06); }
.aiconImg { width:100%;height:100%;object-fit:cover;border-radius:10px; }
.ainfo { flex:1;min-width:0; }
.aname { font-size:13px;font-weight:500;color:#222; }
.ameta { font-size:11px;color:#aaa;margin-top:2px; }
.arate { display:flex;align-items:center;gap:2px;color:#FFB800;font-size:12px;font-weight:500; }

/* ===== 帖子 ===== */
.plst { padding:6px 12px; }
.pcard {
  background:#fff;border-radius:14px;padding:14px;
  margin-bottom:8px;box-shadow:0 1px 8px rgba(0,0,0,.03);cursor:pointer;
}
.pauth { display:flex;align-items:center;gap:8px;margin-bottom:12px; }
.paavt { width:32px;height:32px;border-radius:50%;flex-shrink:0;overflow:hidden; }
.paavtImg { width:100%;height:100%;object-fit:cover;border-radius:50%; }
.paavtPlh { width:100%;height:100%;background:linear-gradient(135deg,#FF6B6B,#E8443A,#FF8E53);display:flex;align-items:center;justify-content:center; }
.pauinfo { flex:1; }
.pauname { font-size:13px;font-weight:500;color:#222; }
.paumeta { font-size:10px;color:#b0b0b0;margin-top:1px; }
.ptitle { font-size:16px;font-weight:600;color:#1a1a1a;line-height:1.35;margin-bottom:6px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical; }
.pexcerpt { font-size:13px;color:#8a8a8a;line-height:1.5;margin-bottom:8px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical; }

/* JSON内容块 */
.pcontent { margin-bottom:8px; }
.pcontent-text { font-size:13px; color:#333; line-height:1.5; margin-bottom:4px; overflow:hidden; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; }
.pcontent-app {
  display:flex; align-items:center; gap:10px;
  background:#f5f6f8; border-radius:10px; padding:10px 12px;
  margin-bottom:6px; cursor:pointer;
}
.papp-icon {
  width:40px; height:40px; border-radius:8px; flex-shrink:0;
  display:flex; align-items:center; justify-content:center;
  box-shadow:0 1px 4px rgba(0,0,0,.08);
}
.papp-info { flex:1; min-width:0; }
.papp-name { font-size:13px; font-weight:500; color:#222; }
.papp-desc { font-size:11px; color:#999; margin-top:2px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }
.papp-price {
  flex-shrink:0; font-size:11px; font-weight:600;
  color:#fff; background:#22C1D0; padding:3px 8px; border-radius:8px;
}

/* 链接卡片 */
.pcontent-link {
  display:flex; align-items:center; gap:10px;
  background:#EEF2FF; border-radius:10px; padding:10px 12px;
  margin-bottom:6px; cursor:pointer;
}
.plink-info { flex:1; min-width:0; }
.plink-title { font-size:13px; font-weight:500; color:#333; }
.plink-url { font-size:11px; color:#999; margin-top:2px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }

/* 附件卡片 */
.pcontent-attach {
  display:flex; align-items:center; gap:10px;
  background:#FFF3E0; border-radius:10px; padding:10px 12px;
  margin-bottom:6px;
}
.pattach-info { flex:1; min-width:0; }
.pattach-name { font-size:13px; font-weight:500; color:#333; }
.pattach-meta { font-size:11px; color:#999; margin-top:2px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.pattach-tag { font-size:10px; padding:1px 6px; border-radius:4px; font-weight:500; }
.pattach-tag.free { background:#E8F5E9; color:#2E7D32; }
.pattach-tag.coin { background:#FFF3E0; color:#E65100; }
.pattach-code { font-size:10px; color:#999; }

/* JSON内嵌图片 */
.pcontent-imgs {
  position:relative; margin-bottom:6px; border-radius:8px; overflow:hidden;
  display:flex; gap:4px; flex-wrap:wrap;
}
.pcontent-img {
  width:calc(33.33% - 3px); height:80px; object-fit:cover; border-radius:4px;
}
.pimgs { position:relative;margin-bottom:8px;border-radius:8px;overflow:hidden; }
.pimg { width:100%;max-height:140px;object-fit:cover;border-radius:8px; }
.pimgcnt { position:absolute;bottom:6px;right:6px;background:rgba(0,0,0,.55);color:#fff;font-size:10px;padding:2px 6px;border-radius:8px; }
.ptags { display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap; }
.ptag { background:#f0f2f5;color:#666;font-size:11px;padding:3px 8px;border-radius:10px; }
.pacts { display:flex;justify-content:space-around;padding-top:8px;border-top:1px solid #f0f2f5; }
.pact { display:flex;align-items:center;gap:4px;font-size:12px;color:#B7C0C8; }

/* ===== 回复 ===== */
.clist { padding:6px 12px; }
.ccard { background:#fff;border-radius:14px;padding:14px;margin-bottom:6px;box-shadow:0 1px 2px rgba(0,0,0,.03);cursor:pointer; }
.chead { display:flex;align-items:center;gap:8px;margin-bottom:10px; }
.cavt { width:30px;height:30px;border-radius:50%;overflow:hidden;flex-shrink:0; }
.cavtImg { width:100%;height:100%;object-fit:cover;border-radius:50%; }
.cavtPlh { width:100%;height:100%;background:linear-gradient(135deg,#FF6B6B,#E8443A);display:flex;align-items:center;justify-content:center; }
.cname { font-size:13px;font-weight:500;color:#222;flex:1; }
.ctime { font-size:10px;color:#b2b2b2; }
.cbody { font-size:13px;color:#333;line-height:1.5;margin-bottom:10px; }
.cref { background:#f5f6f8;border-radius:8px;padding:8px 10px;display:flex;align-items:center;gap:6px; }
.cref span { font-size:11px;color:#666;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }

/* ===== 关注/粉丝 ===== */
.flist { padding:6px 12px; }
.frow { display:flex;align-items:center;gap:10px;padding:12px 0;cursor:pointer;border-bottom:1px solid #F5F5F5; }
.favt { width:42px;height:42px;border-radius:50%;flex-shrink:0;overflow:hidden; }
.favtImg { width:100%;height:100%;object-fit:cover;border-radius:50%; }
.favtPlh { width:100%;height:100%;background:linear-gradient(135deg,#FF6B6B,#E8443A,#FF8E53);border-radius:50%;display:flex;align-items:center;justify-content:center; }
.finfo { flex:1;min-width:0; }
.fname { font-size:14px;font-weight:600;color:#1a1a1a; }
.fdesc { font-size:11px;color:#b0b0b0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:2px; }
.fbtn { flex-shrink:0;background:#e8e6ed;color:#1a1a1a;border:none;border-radius:16px;padding:5px 14px;font-size:12px;font-weight:500;cursor:pointer; }
.fbtn.fed { background:#e0e0e0;color:#999; }

/* ===== 举报弹窗 ===== */
.reportOverlay {
  position: fixed; inset: 0; z-index: 999;
  background: rgba(0,0,0,0.5);
  display: flex; align-items: center; justify-content: center;
}
.reportDialog {
  background: #fff; border-radius: 12px;
  padding: 24px; width: 300px; max-width: 90vw;
}
.reportTitle { font-size: 17px; font-weight: 700; color: #1a1a1a; margin-bottom: 16px; }
.reportInput {
  width: 100%; min-height: 80px; border: 1px solid #e0e0e0;
  border-radius: 8px; padding: 10px; font-size: 14px; resize: vertical;
  outline: none; box-sizing: border-box;
}
.reportInput:focus { border-color: #4E8CFF; }
.reportBtn {
  flex: 1; border: none; border-radius: 8px; padding: 10px;
  font-size: 14px; font-weight: 600; cursor: pointer;
}
.reportBtn.cancel { background: #f5f5f5; color: #666; }
.reportBtn.confirm { background: #FF4757; color: #fff; }
.reportBtn:disabled { opacity: 0.6; cursor: not-allowed; }

.rewardTab {
  flex: 1; border: 1px solid #e0e0e0; border-radius: 8px; padding: 8px;
  background: #fff; font-size: 14px; color: #666; cursor: pointer;
}
.rewardTab.on { border-color: #4E8CFF; color: #4E8CFF; font-weight: 600; }

.quickAmtBtn {
  border: 1px solid #e0e0e0; border-radius: 8px; padding: 6px 12px;
  background: #fff; font-size: 13px; color: #666; cursor: pointer;
  white-space: nowrap;
}
.quickAmtBtn.on { border-color: #4E8CFF; color: #4E8CFF; font-weight: 600; }

/* ===== 商品网格 ===== */
.mall-grid {
  display: grid; grid-template-columns: repeat(2, 1fr);
  gap: 8px; padding: 0;
}
.mall-card {
  background: #fff; border-radius: 10px; overflow: hidden;
  box-shadow: 0 0 0 1px rgba(0,0,0,.04), 0 2px 6px rgba(0,0,0,.05);
  cursor: pointer; transition: transform .15s, box-shadow .15s;
}
.mall-card:active { transform: scale(.97); box-shadow: 0 4px 14px rgba(0,0,0,.1); }
.mall-card-img-wrap { position: relative; width: 100%; padding-top: 80%; overflow: hidden; background: #f8f8f8; }
.mall-card-img {
  position: absolute; inset: 0; width: 100%; height: 100%;
  object-fit: cover; transition: transform .25s;
}
.mall-card:active .mall-card-img { transform: scale(1.03); }
.mall-card-img-fb {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(180deg, #FF8A80 0%, #FF5252 50%, #D32F2F 100%);
}
.mall-card-fb-text {
  color: rgba(255,255,255,.55); font-size: 22px; font-weight: 900;
  max-width: 80%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.mall-card-badge {
  position: absolute; top: 0; left: 0;
  font-size: 10px; padding: 3px 8px; border-radius: 0 0 8px 0;
  background: linear-gradient(135deg, #FF4757, #FF6B6B);
  color: #fff; font-weight: 600; letter-spacing: .5px;
}
.mall-card-badge.hot { background: linear-gradient(135deg, #FF4757, #FF6B6B); }
.mall-card-badge.coupon { background: linear-gradient(135deg, #FF9500, #FF6B3D); }
.mall-card-body { padding: 6px 9px 8px; display: flex; flex-direction: column; gap: 3px; }
.mall-card-name {
  font-size: 13px; font-weight: 600; color: #222; line-height: 1.4;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
  overflow: hidden;
}
.mall-card-tags { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 1px; }
.mall-card-tag {
  font-size: 9px; padding: 2px 6px; border-radius: 3px;
  background: #FFF0E6; color: #FF7D37; white-space: nowrap; font-weight: 500;
}
.mall-card-tag:nth-child(2) { background: #F0EBFF; color: #7C5CFC; }
.mall-card-tag:nth-child(3) { background: #E8FAF0; color: #00B578; }
.mall-card-price-row { display: flex; align-items: baseline; gap: 3px; flex-wrap: wrap; }
.mall-card-price-currency { font-size: 12px; font-weight: 700; color: #FF4757; }
.mall-card-price-num { font-size: 18px; font-weight: 800; color: #FF4757; line-height: 1; }
.mall-card-original { font-size: 10px; color: #CCC; text-decoration: line-through; margin-left: 2px; }
.mall-card-footer { display: flex; align-items: center; justify-content: space-between; }
.mall-card-sold { font-size: 10px; color: #BBB; }
.mall-card-buy {
  font-size: 10px; color: #fff; background: linear-gradient(135deg, #FF6B6B, #FF8E53);
  padding: 3px 10px; border-radius: 10px; font-weight: 600;
}
</style>
