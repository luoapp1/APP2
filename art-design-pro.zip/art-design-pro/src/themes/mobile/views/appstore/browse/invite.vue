<template>
  <div style="min-height:100vh;background:var(--app-page-bg);display:flex;flex-direction:column">
    <div style="position:sticky;top:0;z-index:10;background:var(--default-bg-color);display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f3f4f6">
      <div style="cursor:pointer;padding:4px" @click="$router.back()">
        <svg style="width:22px;height:22px;color:#374151" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </div>
      <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#1f2937">邀请福利</div>
      <div style="width:30px" />
    </div>

    <div style="flex:1;overflow-y:auto;padding:12px">

      <!-- 生成按钮 -->
      <div style="background:#fff;border-radius:12px;padding:16px;margin-bottom:12px">
        <div v-if="!configLoaded" style="text-align:center;padding:20px;color:#9ca3af">加载配置中...</div>
        <div v-else-if="activeCount >= maxCount" style="text-align:center;padding:16px;color:#e6a23c">
          已达到最大数量（{{ maxCount }}个），请先撤回或删除未使用的邀请码
        </div>
        <template v-else>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <div style="font-size:13px;color:#6b7280">剩余可生成 {{ remainingSlots }} 个 / 最多 {{ maxUsesLimit }} 次使用</div>
          </div>
          <ElButton type="primary" style="width:100%" @click="genVisible = true">生成邀请码</ElButton>
        </template>
      </div>

      <!-- 我的邀请码 -->
      <div style="background:#fff;border-radius:12px;padding:16px;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <div style="font-size:15px;font-weight:600;color:#1f2937">我的邀请码</div>
          <div style="font-size:12px;color:#9ca3af">{{ activeCount }} / {{ maxCount }} 个</div>
        </div>

        <div v-if="loading" style="text-align:center;padding:20px;color:#9ca3af">加载中...</div>
        <div v-else-if="myCodes.length === 0" style="text-align:center;padding:30px 0;color:#9ca3af">
          <div style="font-size:40px;margin-bottom:8px">?</div>
          <div>暂无邀请码</div>
        </div>
        <div v-else>
          <div v-for="c in myCodes" :key="c.id"
            style="background:#f9fafb;border-radius:10px;padding:12px;margin-bottom:8px">
            <div style="display:flex;align-items:center;justify-content:space-between">
              <div :style="{fontFamily:'monospace',fontSize:'16px',fontWeight:700,letterSpacing:'2px',color:c.status==='3'?'#9ca3af':'#1f2937',textDecoration:c.status==='3'?'line-through':'none'}">{{ c.code }}</div>
              <ElTag :type="statusTagType(c)" size="small">{{ statusLabel(c) }}</ElTag>
            </div>
            <div style="display:flex;align-items:center;gap:16px;margin-top:6px;font-size:11px;color:#9ca3af">
              <span>使用: {{ c.use_count }}/{{ c.max_uses }}</span>
              <span v-if="c.reward_type">奖励: {{ formatReward(c) }}</span>
              <span>{{ c.create_time }}</span>
              <div style="flex:1" />
              <template v-if="c.status === '1' && c.use_count === 0">
                <ElButton size="small" type="danger" link @click="doRevoke(c)">撤回</ElButton>
              </template>
              <template v-else-if="c.status === '3'">
                <ElButton size="small" type="info" link @click="doDelete(c)">删除</ElButton>
              </template>
            </div>
          </div>
        </div>
      </div>

      <!-- 生成弹窗 -->
      <ElDialog v-model="genVisible" title="生成邀请码" width="90%" top="5vh">
        <div v-if="!hasRewardConfig" style="text-align:center;padding:20px;color:#6b7280">
          免费生成邀请码（当前未配置奖励定价）
        </div>

        <div style="margin-bottom:16px">
          <div class="gen-item">
            <span class="gen-label">生成数量</span>
            <ElInputNumber v-model="genCount" :min="1" :max="remainingSlots" size="small" controls-position="right" style="width:100px" />
          </div>
          <div class="gen-item">
            <span class="gen-label">最大使用次数</span>
            <ElInputNumber v-model="maxUses" :min="1" :max="maxUsesLimit" size="small" controls-position="right" style="width:100px" />
          </div>
        </div>

        <div v-if="hasRewardConfig" style="margin-bottom:14px">
          <div style="font-size:13px;color:#6b7280;margin-bottom:8px">奖励设置（选填，含奖励需支付余额）</div>

          <div class="gen-item" v-if="hasPointsPricing">
            <div>
              <span class="gen-label">奖励积分</span>
              <span v-if="pointsPricingInfo" style="font-size:10px;color:#9ca3af;display:block">{{ pointsPricingInfo }}</span>
            </div>
            <ElInputNumber v-model="rewardForm.points" :min="0" :max="9999999" size="small" style="width:110px" controls-position="right" />
          </div>

          <div class="gen-item" v-if="hasBalancePricing">
            <div>
              <span class="gen-label">奖励余额</span>
              <span v-if="balancePricingInfo" style="font-size:10px;color:#9ca3af;display:block">{{ balancePricingInfo }}</span>
            </div>
            <ElInputNumber v-model="rewardForm.balance" :min="0" :max="9999999" :precision="2" size="small" style="width:120px" controls-position="right" />
          </div>

          <div class="gen-item" v-if="hasExpPricing">
            <div>
              <span class="gen-label">奖励经验</span>
              <span v-if="expPricingInfo" style="font-size:10px;color:#9ca3af;display:block">{{ expPricingInfo }}</span>
            </div>
            <ElInputNumber v-model="rewardForm.exp" :min="0" :max="9999999" size="small" style="width:110px" controls-position="right" />
          </div>

          <div class="gen-item" v-if="hasMembershipPricing">
            <div>
              <span class="gen-label">赠送会员天数</span>
              <span style="font-size:10px;color:#9ca3af;display:block">可选: {{ membershipOptions }}</span>
            </div>
            <ElInputNumber v-model="rewardForm.memberDays" :min="0" :max="36500" size="small" style="width:110px" controls-position="right" />
          </div>
        </div>

        <div v-if="hasRewardConfig && totalCost > 0" style="background:#fffbeb;border-radius:8px;padding:10px 12px;margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
            <span style="font-size:13px;color:#92400e">费用明细</span>
            <span style="font-size:12px;color:#92400e">
              {{ perCodeCost.toFixed(2) }} x {{ genCount }}码 x {{ maxUses }}次 = {{ totalCost.toFixed(2) }} 余额
            </span>
          </div>
          <div v-if="hasVipDiscount && isVipUser" style="font-size:11px;color:#92400e;margin-top:2px">
            已享VIP折扣（{{ (vipDiscountRate * 100).toFixed(0) }}%）
          </div>
          <div v-if="userBalance < totalCost" style="font-size:11px;color:#dc2626;margin-top:2px">
            余额不足（当前: {{ userBalance.toFixed(2) }}）
          </div>
        </div>

        <template #footer>
          <ElButton @click="genVisible = false">取消</ElButton>
          <ElButton type="primary" :loading="genLoading" :disabled="userBalance < totalCost && totalCost > 0" @click="preConfirm">
            {{ totalCost > 0 ? '支付 ' + totalCost.toFixed(2) + ' 余额' : '确认生成' }}
          </ElButton>
        </template>
      </ElDialog>

      <!-- 确认弹窗 -->
      <ElDialog v-model="confirmVisible" title="确认生成" width="85%">
        <div style="margin-bottom:12px">
          <div class="confirm-row"><span>生成数量</span><span>{{ genCount }} 个</span></div>
          <div class="confirm-row"><span>使用次数</span><span>{{ maxUses }} 次/码</span></div>
          <div v-if="rewardForm.points > 0" class="confirm-row"><span>积分奖励</span><span>{{ rewardForm.points }}</span></div>
          <div v-if="rewardForm.balance > 0" class="confirm-row"><span>余额奖励</span><span>{{ rewardForm.balance }} 元</span></div>
          <div v-if="rewardForm.exp > 0" class="confirm-row"><span>经验奖励</span><span>{{ rewardForm.exp }}</span></div>
          <div v-if="rewardForm.memberDays > 0" class="confirm-row"><span>会员奖励</span><span>{{ rewardForm.memberDays }} 天</span></div>
          <div class="confirm-row total-row"><span>合计</span><span>{{ totalCost.toFixed(2) }} 余额</span></div>
        </div>
        <template #footer>
          <ElButton @click="confirmVisible = false">取消</ElButton>
          <ElButton type="primary" :loading="genLoading" @click="execGenerate">确认支付</ElButton>
        </template>
      </ElDialog>

      <!-- 生成结果 -->
      <ElDialog v-model="resultVisible" title="邀请码已生成" width="90%">
        <div v-for="c in generatedCodes" :key="c"
          style="font-family:monospace;font-size:18px;padding:12px;background:#f0fdf4;margin:6px 0;border-radius:8px;text-align:center;letter-spacing:2px;border:1px dashed #22c55e;color:#166534;font-weight:700">
          {{ c }}
        </div>
        <p style="margin-top:12px;color:#e6a23c;font-size:13px;text-align:center">请保存以上邀请码，关闭后将无法再次查看。</p>
        <template #footer>
          <ElButton type="primary" @click="resultVisible = false">我已保存</ElButton>
        </template>
      </ElDialog>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchMyInvite, fetchGenerateUserInvite, fetchInviteConfig, fetchInviteGenerateConfig, revokeMyInvite, deleteMyInvite } from '@/api/invite'
import { useUserStore } from '@/store/modules/user'

defineOptions({ name: 'InviteUser' })

const userStore = useUserStore()
const loading = ref(false)
const genLoading = ref(false)
const configLoaded = ref(false)
const genVisible = ref(false)
const confirmVisible = ref(false)
const resultVisible = ref(false)
const generatedCodes = ref<string[]>([])
const myCodes = ref<any[]>([])
const maxCount = ref(5)
const maxUsesLimit = ref(10)
const genCount = ref(1)
const maxUses = ref(1)

const rewardForm = reactive({ points: 0, balance: 0, exp: 0, memberDays: null as number | null })

const costConfig = ref<any>({})
const hasRewardConfig = computed(() => {
  const c = costConfig.value
  return (c.pointsPricing && c.pointsPricing.length > 0) ||
    (c.balancePricing && c.balancePricing.length > 0) ||
    (c.expPricing && c.expPricing.length > 0) ||
    (c.membershipPricing && Object.keys(c.membershipPricing).length > 0)
})
const hasPointsPricing = computed(() => costConfig.value.pointsPricing?.length > 0)
const hasBalancePricing = computed(() => costConfig.value.balancePricing?.length > 0)
const hasExpPricing = computed(() => costConfig.value.expPricing?.length > 0)
const pointsPricingInfo = computed(() => tierInfo(costConfig.value.pointsPricing))
const balancePricingInfo = computed(() => tierInfo(costConfig.value.balancePricing))
const expPricingInfo = computed(() => tierInfo(costConfig.value.expPricing))

function tierInfo(tiers: any[]): string {
  if (!tiers?.length) return ''
  return tiers.map((t: any) => `≤${t.maxAmount}:${t.totalCost}/${t.quantity}`).join(', ')
}

const membershipPricing = computed(() => costConfig.value.membershipPricing || {})
const membershipOptions = computed(() => {
  const keys = Object.keys(membershipPricing.value).map(Number).sort((a, b) => a - b)
  return keys.map(k => `${k}天(${membershipPricing.value[String(k)]}余额)`).join(', ')
})
const hasMembershipPricing = computed(() => Object.keys(membershipPricing.value).length > 0)
const hasVipDiscount = computed(() => costConfig.value.vipDiscount?.enabled)
const vipDiscountRate = computed(() => Number(costConfig.value.vipDiscountRate) || 1)
const isVipUser = ref(false)
const userBalance = computed(() => Number(userStore.info.balance || 0))

const activeCount = computed(() =>
  myCodes.value.filter(c => c.status === '1' && c.use_count < c.max_uses).length
)
const remainingSlots = computed(() => Math.max(0, maxCount.value - activeCount.value))

function statusTagType(c: any): 'success' | 'info' | 'danger' {
  if (c.status === '3') return 'danger'
  if (c.use_count >= c.max_uses) return 'info'
  return 'success'
}
function statusLabel(c: any): string {
  if (c.status === '3') return '已撤回'
  if (c.use_count >= c.max_uses) return '已用完'
  return '有效'
}

function calcTieredCost(amount: number, tiers: any[]): number {
  if (!tiers?.length || amount <= 0) return 0
  const sorted = [...tiers].sort((a, b) => (Number(a.maxAmount) || 0) - (Number(b.maxAmount) || 0))
  let cost = 0
  let prevMax = 0
  for (const tier of sorted) {
    const max = Number(tier.maxAmount) || 999999
    const qty = Number(tier.quantity) || 1
    const tc = Number(tier.totalCost) || 0
    const unit = tc / qty
    if (amount <= prevMax) break
    const inTier = Math.min(amount, max) - prevMax
    if (inTier > 0) cost += inTier * unit
    prevMax = max
    if (amount <= max) break
  }
  if (amount > prevMax) {
    const last = sorted[sorted.length - 1]
    const unit = (Number(last.totalCost) || 0) / (Number(last.quantity) || 1)
    cost += (amount - prevMax) * unit
  }
  return Math.round(cost * 100) / 100
}

const perCodeCost = computed(() => {
  let cost = 0
  const c = costConfig.value
  if (rewardForm.points > 0 && hasPointsPricing.value) cost += calcTieredCost(rewardForm.points, c.pointsPricing)
  if (rewardForm.balance > 0 && hasBalancePricing.value) cost += calcTieredCost(rewardForm.balance, c.balancePricing)
  if (rewardForm.exp > 0 && hasExpPricing.value) cost += calcTieredCost(rewardForm.exp, c.expPricing)
  if (rewardForm.memberDays && hasMembershipPricing.value) {
    const dur = rewardForm.memberDays
    const pricing = c.membershipPricing
    const durKey = String(dur)
    if (pricing[durKey] !== undefined) {
      cost += Number(pricing[durKey])
    } else {
      const keys = Object.keys(pricing).map(Number).sort((a, b) => a - b)
      if (keys.length > 0) {
        const perDay = Number(pricing[String(keys[0])]) / keys[0]
        cost += Math.round(perDay * dur * 100) / 100
      }
    }
  }
  if (hasVipDiscount.value && isVipUser.value) {
    cost = Math.round(cost * vipDiscountRate.value * 100) / 100
  }
  return cost
})

const totalCost = computed(() => Math.round(perCodeCost.value * genCount.value * maxUses.value * 100) / 100)

function formatReward(row: any): string {
  const parts: string[] = []
  const types = String(row.reward_type || '').split(',')
  const values = String(row.reward_value || '').split(',')
  for (let i = 0; i < types.length; i++) {
    const t = types[i].trim()
    const v = values[i] || ''
    if (t === 'points') parts.push(`${v}积分`)
    else if (t === 'balance') parts.push(`${v}元`)
    else if (t === 'experience') parts.push(`${v}经验`)
    else if (t === 'membership') parts.push(`会员${row.reward_duration || 30}天`)
  }
  return parts.join('、') || '-'
}

async function loadMyCodes() {
  loading.value = true
  try {
    const res: any = await fetchMyInvite()
    myCodes.value = (res.list || []).sort((a: any, b: any) => {
      if (a.status === '1' && b.status !== '1') return -1
      if (a.status !== '1' && b.status === '1') return 1
      return 0
    })
  } catch { myCodes.value = [] }
  finally { loading.value = false }
}

async function loadConfig() {
  try {
    const res: any = await fetchInviteConfig()
    maxCount.value = parseInt(res.invite_user_max) || 5
    maxUsesLimit.value = parseInt(res.invite_user_max_uses) || 10

    const genRes: any = await fetchInviteGenerateConfig()
    costConfig.value = genRes || {}

    if (hasVipDiscount.value) {
      const levelId = costConfig.value.vipDiscount?.levelId
      const userLevelId = userStore.info.levelId || 0
      isVipUser.value = userLevelId === levelId
    }
    configLoaded.value = true
  } catch {
    costConfig.value = {}
    configLoaded.value = true
  }
}

function preConfirm() {
  if (totalCost.value > 0) {
    confirmVisible.value = true
  } else {
    execGenerate()
  }
}

async function execGenerate() {
  genLoading.value = true
  confirmVisible.value = false
  try {
    const rewardTypes: string[] = []
    const rewardValues: string[] = []
    if (rewardForm.points > 0) { rewardTypes.push('points'); rewardValues.push(String(rewardForm.points)) }
    if (rewardForm.balance > 0) { rewardTypes.push('balance'); rewardValues.push(String(rewardForm.balance)) }
    if (rewardForm.exp > 0) { rewardTypes.push('experience'); rewardValues.push(String(rewardForm.exp)) }
    if (rewardForm.memberDays && rewardForm.memberDays > 0) {
      rewardTypes.push('membership')
      rewardValues.push(String(rewardForm.memberDays))
    }

    const res: any = await fetchGenerateUserInvite({
      rewardType: rewardTypes.join(','),
      rewardValue: rewardValues.join(','),
      rewardDuration: rewardForm.memberDays || 0,
      count: genCount.value,
      maxUses: maxUses.value
    })
    generatedCodes.value = res.codes || [res.code]
    genVisible.value = false
    resultVisible.value = true
    Object.assign(rewardForm, { points: 0, balance: 0, exp: 0, memberDays: null })
    genCount.value = 1
    maxUses.value = 1
    loadMyCodes()
  } catch (e: any) {
    ElMessage.error(e?.msg || e?.message || '生成失败')
  }
  finally { genLoading.value = false }
}

async function doRevoke(row: any) {
  try {
    await ElMessageBox.confirm(`确定撤回邀请码 ${row.code}？撤回后将无法使用。`, '确认撤回', { type: 'warning', confirmButtonText: '撤回', cancelButtonText: '取消' })
    await revokeMyInvite(row.id)
    ElMessage.success('已撤回')
    loadMyCodes()
  } catch { /* cancel */ }
}

async function doDelete(row: any) {
  try {
    await ElMessageBox.confirm(`确定删除邀请码 ${row.code}？`, '确认删除', { type: 'warning', confirmButtonText: '删除', cancelButtonText: '取消' })
    await deleteMyInvite(row.id)
    ElMessage.success('已删除')
    loadMyCodes()
  } catch { /* cancel */ }
}

onMounted(() => {
  loadMyCodes()
  loadConfig()
})
</script>

<style scoped>
.gen-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 0; border-bottom: 1px solid #f3f4f6;
}
.gen-label { font-size: 13px; color: #374151; }
.confirm-row {
  display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px;
}
.confirm-row span:first-child { color: #6b7280; }
.total-row {
  border-top: 1px solid #f3f4f6; margin-top: 8px; padding-top: 8px;
  font-size: 15px; font-weight: 700;
}
.total-row span:last-child { color: #dc2626; }
</style>
