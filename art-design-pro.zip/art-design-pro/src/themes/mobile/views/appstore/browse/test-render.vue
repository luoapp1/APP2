<template>
  <div style="padding: 50px; font-size: 30px; color: red;">HELLO WORLD - 测试渲染</div>
</template>
