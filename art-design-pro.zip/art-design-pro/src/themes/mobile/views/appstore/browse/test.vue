<template>
  <div class="min-h-screen bg-gray-50 flex items-center justify-center">
    <div class="text-center">
      <h1 class="text-4xl font-bold text-teal-600 mb-4">Test Page Working!</h1>
      <p class="text-gray-500">Static route with param: {{ $route.params.id }}</p>
      <p class="text-gray-400 text-sm mt-2">If you see this, static routes work.</p>
    </div>
  </div>
</template>
