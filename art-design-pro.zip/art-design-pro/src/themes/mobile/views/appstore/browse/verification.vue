<template>
  <div style="min-height: 100vh; background: var(--app-page-bg); display: flex; flex-direction: column">
    <!-- 顶部导航栏 -->
    <div style="background: #fff; padding: 12px 16px; display: flex; align-items: center; gap: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
      <div @click="$router.back()" style="cursor: pointer;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <span style="font-size: 17px; font-weight: 600; color: #222;">我的认证</span>
    </div>

    <div style="flex: 1; overflow-y: auto; padding: 16px">
      <!-- 已认证 -->
      <div v-if="verificationStatus === 'approved'" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 16px">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="1.5">
          <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <div style="font-size:18px;font-weight:600;color:#10b981;margin-top:16px">已通过认证</div>
        <div style="font-size:14px;color:#666;margin-top:8px">您的蓝V认证申请已审核通过</div>
      </div>

      <!-- 审核中 -->
      <div v-else-if="verificationStatus === 'pending'" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 16px">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"/>
          <line x1="12" y1="6" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <div style="font-size:18px;font-weight:600;color:#f59e0b;margin-top:16px">审核中</div>
        <div style="font-size:14px;color:#666;margin-top:8px">您的认证申请正在审核中，请耐心等待</div>
      </div>

      <!-- 被拒绝 -->
      <div v-else-if="verificationStatus === 'rejected'" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 16px">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"/>
          <line x1="15" y1="9" x2="9" y2="15"/>
          <line x1="9" y1="9" x2="15" y2="15"/>
        </svg>
        <div style="font-size:18px;font-weight:600;color:#ef4444;margin-top:16px">申请未通过</div>
        <div v-if="lastReviewComment" style="font-size:14px;color:#666;margin-top:8px">{{ lastReviewComment }}</div>
        <ElButton type="primary" style="margin-top:20px" @click="verificationStatus = ''">重新申请</ElButton>
      </div>

      <!-- 暂未开放 -->
      <div v-else-if="!clientConfig || clientConfig.conditions.length === 0" style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 16px">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"/>
          <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
        </svg>
        <div style="font-size:16px;color:#9ca3af;margin-top:16px">认证功能暂未开放</div>
      </div>

      <!-- 申请表单 -->
      <div v-else>
        <!-- 条件说明卡片 -->
        <div v-if="clientConfig && clientConfig.conditions.length > 0" style="background: #fff; border-radius: 12px; padding: 16px; margin-bottom: 12px">
          <div style="font-size: 15px; font-weight: 600; color: #1f2937; margin-bottom: 8px">申请条件</div>
          <div style="font-size: 13px; color: #6b7280; margin-bottom: 12px">{{ conditionDesc }}</div>
          <div style="display: flex; flex-wrap: wrap; gap: 8px">
            <span v-for="c in clientConfig.conditions" :key="c.condition_type"
              style="font-size: 12px; padding: 4px 10px; border-radius: 6px; background: #eff6ff; color: #3b82f6; border: 1px solid #bfdbfe">
              {{ c.label }}{{ c.threshold > 0 ? ' ≥ ' + c.threshold : '' }}
            </span>
          </div>
        </div>

        <!-- 申请表单卡片 -->
        <div style="background: #fff; border-radius: 12px; padding: 16px">
          <div style="font-size: 15px; font-weight: 600; color: #1f2937; margin-bottom: 16px">提交申请</div>

          <!-- 选择条件 -->
          <div v-if="clientConfig && clientConfig.conditions.length > 0" style="margin-bottom: 16px">
            <div style="font-size: 13px; color: #666; margin-bottom: 6px">选择认证条件</div>
            <ElSelect v-model="selectedCondition" placeholder="请选择要满足的认证条件" style="width: 100%">
              <ElOption v-for="c in clientConfig.conditions" :key="c.condition_type"
                :label="c.label + (c.threshold > 0 ? ' (≥' + c.threshold + ')' : '')"
                :value="c.condition_type" />
            </ElSelect>
          </div>

          <!-- 应用开发者 - 选择应用 -->
          <div v-if="selectedCondition === 'app_developer'" style="margin-bottom: 16px">
            <div style="font-size: 13px; color: #666; margin-bottom: 6px">选择已审核通过的应用</div>
            <div v-if="approvedApps.length === 0" style="font-size: 13px; color: #999; padding: 12px; background: #f9fafb; border-radius: 8px">
              您还没有已审核通过的应用，请先在「应用投稿」中上传并等待审核
            </div>
            <div v-else style="display: flex; flex-direction: column; gap: 8px">
              <div v-for="app in approvedApps" :key="app.id"
                :style="{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px', borderRadius: '8px', cursor: 'pointer',
                  border: selectedAppId === app.id ? '2px solid #3b82f6' : '1px solid #e5e7eb',
                  background: selectedAppId === app.id ? '#eff6ff' : '#fff' }"
                @click="selectedAppId = app.id">
                <img v-if="app.icon" :src="$fixImgUrl(app.icon)" style="width: 36px; height: 36px; border-radius: 8px; object-fit: cover" />
                <div v-else style="width: 36px; height: 36px; border-radius: 8px; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; font-weight: 600">
                  {{ (app.name || '?')[0] }}
                </div>
                <span style="font-size: 14px; color: #1f2937; flex: 1">{{ app.name }}</span>
                <svg v-if="selectedAppId === app.id" width="20" height="20" viewBox="0 0 24 24" fill="#3b82f6"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
              </div>
            </div>
          </div>

          <!-- 真实姓名 -->
          <div style="margin-bottom: 16px">
            <div style="font-size: 13px; color: #666; margin-bottom: 6px">真实姓名</div>
            <ElInput v-model="realName" placeholder="请输入真实姓名" maxlength="20" />
          </div>

          <!-- 申请称号 -->
          <div style="margin-bottom: 16px">
            <div style="font-size: 13px; color: #666; margin-bottom: 6px">申请称号</div>
            <ElInput v-model="reason" type="textarea" :rows="2" placeholder="如：Java工程师、Go工作者" maxlength="15" show-word-limit />
          </div>

          <ElButton type="primary" :loading="submitting" style="width: 100%; height: 44px; font-size: 15px" @click="submitApply">
            提交申请
          </ElButton>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { fetchClientVerificationConfig, fetchApplyVerification, fetchVerificationStatus, fetchUserApprovedApps } from '@/api/verification'

defineOptions({ name: 'AppStoreVerification' })

const clientConfig = ref<any>(null)
const verificationStatus = ref('')
const lastReviewComment = ref('')
const selectedCondition = ref('')
const selectedAppId = ref(0)
const realName = ref('')
const reason = ref('')
const submitting = ref(false)
const approvedApps = ref<any[]>([])

const conditionDesc = computed(() => {
  if (!clientConfig.value) return ''
  const cfg = clientConfig.value
  const count = cfg.conditions.length
  if (cfg.logic_type === 'any' || cfg.logic_count >= count) return '满足上述任意一项条件即可申请认证'
  return `从 ${count} 项条件中满足 ${cfg.logic_count} 项即可申请认证`
})

onMounted(async () => {
  try {
    const data: any = await fetchClientVerificationConfig()
    if (data && data.conditions) clientConfig.value = data
  } catch {}

  try {
    const data: any = await fetchVerificationStatus()
    if (data) {
      if (data.isVerified) {
        verificationStatus.value = 'approved'
      } else if (data.lastRequest) {
        verificationStatus.value = data.lastRequest.status
        lastReviewComment.value = data.lastRequest.review_comment || ''
      }
    }
  } catch {}
})

watch(selectedCondition, async (val) => {
  if (val === 'app_developer') {
    try {
      const data: any = await fetchUserApprovedApps()
      if (data) approvedApps.value = data || []
    } catch {}
  } else {
    selectedAppId.value = 0
  }
})

async function submitApply() {
  if (!selectedCondition.value) {
    ElMessage.warning('请选择认证条件')
    return
  }
  if (selectedCondition.value === 'app_developer' && !selectedAppId.value) {
    ElMessage.warning('请选择已审核通过的应用')
    return
  }
  if (!realName.value.trim()) {
    ElMessage.warning('请输入真实姓名')
    return
  }
  if (!reason.value.trim()) {
    ElMessage.warning('请输入申请称号')
    return
  }
  submitting.value = true
  try {
    await fetchApplyVerification({
      realName: realName.value.trim(),
      idCard: '',
      organization: '',
      reason: reason.value.trim(),
      selectedCondition: selectedCondition.value,
      selectedAppId: selectedAppId.value,
    })
    ElMessage.success('申请已提交，请等待审核')
    verificationStatus.value = 'pending'
  } catch (e: any) {
    ElMessage.error(e.message || '提交失败')
  } finally { submitting.value = false }
}
</script>
