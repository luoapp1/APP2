<template>
  <div class="membership-page">
    <!-- 顶部导航栏 -->
    <header class="nav-bar">
      <div class="nav-inner">
        <div class="nav-back" @click="$router.back()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 19l-7-7 7-7" />
          </svg>
        </div>
        <h1 class="nav-title">会员中心</h1>
        <div class="nav-placeholder" />
      </div>
    </header>

    <div class="page-content">
      <!-- 会员身份卡 -->
      <div class="vip-card">
        <div class="vip-card-bg" />
        <div class="vip-card-inner">
          <div class="vip-card-top">
            <div>
              <div class="vip-badge">
                <span class="vip-dot" />
                <span class="vip-level-text">VIP {{ currentLevelName }}</span>
              </div>
              <div class="vip-expire">
                <template v-if="isLogin && userStore.info.expireTime">{{ expireTimeDisplay }}</template>
                <template v-else>开通会员解锁全部特权</template>
              </div>
            </div>
            <div class="vip-status-tag" :class="{ active: currentLevelId }">
              {{ currentLevelId ? '已开通' : '未开通' }}
            </div>
          </div>
          <div class="vip-stats">
            <div class="vip-stat-item">
              <div class="vip-stat-label">折扣率</div>
              <div class="vip-stat-value accent-gold">{{ discountPct }}%</div>
            </div>
            <div class="vip-stat-item">
              <div class="vip-stat-label">积分加成</div>
              <div class="vip-stat-value accent-amber">{{ pointsMultiplier }}x</div>
            </div>
            <div class="vip-stat-item">
              <div class="vip-stat-label">余额</div>
              <div class="vip-stat-value accent-blue">¥{{ balanceStr }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 会员等级选择 -->
      <section class="section-card">
        <div class="section-header">
          <div class="section-icon icon-amber">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
          </div>
          <span class="section-title">选择会员等级</span>
        </div>

        <div class="level-list">
          <div
            v-for="lvl in availableLevels"
            :key="lvl.id"
            class="level-card"
            :class="{
              selected: selectedLevel === lvl.id,
              current: lvl.id === currentLevelId
            }"
            @click="selectLevel(lvl)"
          >
            <div class="level-card-header">
              <div class="level-card-name">{{ lvl.name }}</div>
              <span v-if="lvl.id === currentLevelId" class="level-tag current-tag">当前</span>
              <span v-else-if="isLevelHigher(lvl)" class="level-tag recommend-tag">推荐</span>
            </div>
            <div class="level-card-price">
              <span class="price-symbol">¥</span>
              <span class="price-value">{{ levelMinPrice(lvl) || '--' }}</span>
              <span class="price-unit">起</span>
            </div>
            <div
              v-if="selectedLevel === lvl.id"
              class="level-card-bar"
              :class="{ 'bar-reverse': lvl.id === currentLevelId }"
            />
          </div>
        </div>

        <div v-if="levelPlans.length > 0" class="plan-section">
          <div class="plan-section-title">选择时长</div>
          <div class="plan-grid">
            <div
              v-for="p in levelPlans"
              :key="p.id"
              class="plan-item"
              :class="{ active: selectedPlan === p.id }"
              @click="selectedPlan = p.id"
            >
              <div class="plan-duration">{{ durationLabel(p.duration_days) }}</div>
              <div class="plan-price-row">
                <span class="plan-symbol">¥</span>
                <span class="plan-amount">{{ planPrice(p) }}</span>
              </div>
              <div v-if="planOriginalPrice(p) > Number(planPrice(p))" class="plan-original">¥{{ planOriginalPrice(p) }}</div>
            </div>
          </div>
        </div>
      </section>

      <!-- 会员权益对比 -->
      <section class="section-card">
        <div class="section-header">
          <div class="section-icon icon-green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </div>
          <span class="section-title">会员权益</span>
        </div>
        <div class="benefits-compare">
          <div
            v-for="(lvl, lvlIdx) in availableLevels"
            :key="lvl.id"
            class="benefit-level-col"
            :class="[`blc-scheme-${lvlIdx % 5}`, { cur: lvl.id === currentLevelId }]"
          >
            <div class="blc-ribbon" v-if="lvl.id === currentLevelId">当前</div>
            <div class="blc-header">
              <div class="blc-icon" :class="`blc-icon-${lvlIdx % 5}`">
                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              </div>
              <span class="blc-name">{{ lvl.name }}</span>
            </div>
            <div class="blc-badge-row" v-if="lvl.name.includes('黄金') || lvl.name.includes('铂金')">
              <span class="blc-hot">人气推荐</span>
            </div>
            <div class="blc-items">
              <div v-for="(b, idx) in getLevelBenefits(lvl)" :key="idx" class="blc-item">
                <span class="blc-dot" :class="`blc-dot-${lvlIdx % 5}`" />
                <span>{{ b }}</span>
              </div>
            </div>
            <div class="blc-footer">
              <div class="blc-price">
                <span class="blc-sym">¥</span>
                <span class="blc-num">{{ levelMinPrice(lvl) || '免费' }}</span>
                <span v-if="levelMinPrice(lvl)" class="blc-unit">/起</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- 协议勾选 -->
      <div class="agreement" @click="agreed = !agreed">
        <div class="agree-check" :class="{ checked: agreed }">
          <svg v-if="agreed" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
        </div>
        <span class="agree-text">已阅读并同意<span class="agree-link">《会员服务协议》</span></span>
      </div>
    </div>

    <!-- 底部支付栏 -->
    <footer class="pay-bar">
      <div class="pay-bar-inner">
        <div class="pay-bar-left">
          <div class="pay-bar-price">
            <span class="pay-bar-unit">¥</span>
            <span class="pay-bar-total">{{ totalPrice }}</span>
          </div>
          <div v-if="selectedPlanInfo" class="pay-bar-expire">到期：{{ expirePreview }}</div>
        </div>
        <button
          class="pay-button"
          :class="{ disabled: !selectedPlan || !agreed }"
          :disabled="!selectedPlan || !agreed || buyLoading > 0"
          @click="showConfirm"
        >
          {{ buyLoading > 0 ? '支付中...' : '立即开通' }}
        </button>
      </div>
    </footer>

    <!-- 支付确认面板 -->
    <div class="confirm-overlay" v-if="showConfirmModal" @click.self="showConfirmModal = false">
      <div class="confirm-sheet">
        <div class="confirm-header">
          <span class="confirm-title">确认支付</span>
          <svg class="confirm-close" @click="showConfirmModal = false" viewBox="0 0 24 24" fill="none">
            <path d="M18 6L6 18M6 6l12 12" stroke="#999" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </div>
        <div class="confirm-body">
          <div class="confirm-section">
            <div class="confirm-product">
              <div class="confirm-product-icon">
                <svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
              </div>
              <div class="confirm-product-info">
                <div class="confirm-product-name">{{ selectedPlanInfo?.name || selectedPlanInfo?.levelName }}</div>
                <div class="confirm-product-sub">{{ selectedLevelName }} · {{ selectedPlanInfo ? durationLabel(selectedPlanInfo.duration_days) : '' }}</div>
                <div class="confirm-product-price">¥{{ totalPrice }}</div>
              </div>
            </div>
          </div>
          <div class="confirm-section">
            <div class="confirm-section-title">优惠券</div>
            <select v-if="usableCoupons.length > 0" class="confirm-coupon-select" @change="onCouponSelect">
              <option :value="0">不使用优惠券</option>
              <option v-for="c in usableCoupons" :key="c.userCouponId" :value="c.userCouponId">{{ couponLabel(c) }}</option>
            </select>
            <div v-else class="confirm-coupon-empty">暂无可用优惠券</div>
          </div>
          <div class="confirm-section">
            <div class="confirm-section-title">支付方式</div>
            <div class="confirm-pay-methods">
              <div class="confirm-pay-item" :class="{ active: confirmPayMethod === 'balance' }" @click="confirmPayMethod = 'balance'">余额支付</div>
              <div class="confirm-pay-item" :class="{ active: confirmPayMethod === 'points' }" @click="confirmPayMethod = 'points'">积分支付</div>
            </div>
          </div>
          <div class="confirm-section">
            <div class="confirm-price-breakdown">
              <div class="confirm-price-row">
                <span class="confirm-price-label">商品总价</span>
                <span class="confirm-price-val">{{ confirmPayMethod === 'points' ? '积分' : '¥' }}{{ totalPrice }}</span>
              </div>
              <div class="confirm-price-row" v-if="couponDiscount > 0">
                <span class="confirm-price-label">优惠券抵扣</span>
                <span class="confirm-price-val discount">-{{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }}</span>
              </div>
              <div class="confirm-price-divider" />
              <div class="confirm-price-row total">
                <span class="confirm-price-label">应付金额</span>
                <span class="confirm-price-val total-val">{{ confirmPayMethod === 'points' ? '' : '¥' }}{{ finalPrice }}{{ confirmPayMethod === 'points' ? '积分' : '' }}</span>
              </div>
              <div class="confirm-price-row">
                <span class="confirm-price-label">有效期至</span>
                <span class="confirm-price-val">{{ expirePreview }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="confirm-footer">
          <button class="confirm-btn-submit" :disabled="buyLoading > 0" @click="handleConfirmPay">
            {{ buyLoading > 0 ? '支付中...' : '立即支付 ' + (confirmPayMethod === 'points' ? '' : '¥') + finalPrice + (confirmPayMethod === 'points' ? '积分' : '') }}
          </button>
        </div>
      </div>
    </div>

    <!-- 支付结果 -->
    <div v-if="showResultModal" class="modal-overlay" @click.self="showResultModal = false">
      <div class="result-modal">
        <div v-if="resultSuccess" class="result-icon success">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
        </div>
        <div v-else class="result-icon fail">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M6 18L18 6M6 6l12 12" /></svg>
        </div>
        <div class="result-title">{{ resultSuccess ? '开通成功' : '开通失败' }}</div>
        <div class="result-msg">{{ resultMsg }}</div>
        <div v-if="resultSuccess && selectedPlanInfo" class="result-detail">
          <div class="result-row"><span>套餐</span><span class="strong">{{ selectedPlanInfo.name || selectedPlanInfo.levelName }}</span></div>
          <div class="result-row"><span>金额</span><span class="accent">¥{{ totalPrice }}</span></div>
          <div class="result-row"><span>有效期至</span><span class="strong">{{ expirePreview }}</span></div>
        </div>
        <button class="result-btn" @click="showResultModal = false">我知道了</button>
      </div>
    </div>

    <!-- 卡密兑换弹窗 -->
    <div v-if="showCardKeyDialog" class="modal-overlay" @click.self="showCardKeyDialog = false">
      <div class="cardkey-modal">
        <template v-if="cardKeyResult === 'success'">
          <div class="result-icon success small">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
          </div>
          <div class="result-title">兑换成功</div>
          <div class="result-msg">{{ cardKeyMsg }}</div>
          <button class="result-btn primary" @click="showCardKeyDialog = false">我知道了</button>
        </template>
        <template v-else>
          <div class="cardkey-title">卡密兑换</div>
          <input v-model="cardKeyForm.cardNo" class="cardkey-input" placeholder="请输入卡号" />
          <input v-model="cardKeyForm.password" type="text" class="cardkey-input" placeholder="请输入卡密密码" />
          <div v-if="cardKeyMsg && cardKeyResult !== 'success'" class="cardkey-error">{{ cardKeyMsg }}</div>
          <div class="cardkey-actions">
            <button class="cardkey-btn cancel" @click="showCardKeyDialog = false">取消</button>
            <button class="cardkey-btn confirm" :disabled="cardKeyLoading" @click="handleRedeemCardKey">
              {{ cardKeyLoading ? '兑换中...' : '确认兑换' }}
            </button>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'

const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const agreed = ref(false)
const showCardKeyDialog = ref(false)
const showConfirmModal = ref(false)
const showResultModal = ref(false)
const cardKeyForm = ref({ cardNo: '', password: '' })
const cardKeyMsg = ref('')
const cardKeyLoading = ref(false)
const cardKeyResult = ref<'input' | 'success' | 'fail'>('input')
const resultSuccess = ref(false)
const resultMsg = ref('')
const pointsMultiplier = ref('1.0')

const confirmPayMethod = ref('balance')
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)

const isLogin = computed(() => userStore.isLogin)
const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '普通会员')

const expireTimeDisplay = computed(() => {
  const t = userStore.info.expireTime
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return ''
    return `到期：${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  } catch { return '' }
})

const discountPct = computed(() => {
  const r = Number(userStore.info.discountRate || 1) * 100
  return r % 1 === 0 ? r : r.toFixed(0)
})

const balanceStr = computed(() => {
  const b = Number(userStore.info.balance || 0)
  return b >= 10000 ? (b / 10000).toFixed(2) + '万' : b.toFixed(2)
})

const availableLevels = computed(() => {
  const currentLevelVal = currentLevelId.value
    ? (allLevels.value.find((l: any) => l.id === currentLevelId.value)?.level ?? 0)
    : 0
  return allLevels.value
    .filter((l: any) => l.status === '1')
    .filter((l: any) => {
      if (!currentLevelId.value) return true
      return (l.level || 0) > currentLevelVal || l.id === currentLevelId.value
    })
    .sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const levelMinPrice = (lvl: any) => {
  const plans = products.value.filter((p: any) => p.level_id === lvl.id && Number(p.price) > 0)
  if (plans.length === 0) return lvl.price || 0
  return Math.min(...plans.map((p: any) => Number(p.price) || Infinity))
}

const selectedLevelName = computed(() => {
  const lvl = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  return lvl?.name || ''
})

const levelPlans = computed(() => {
  if (!selectedLevel.value) return []
  return products.value.filter((p: any) => p.level_id === selectedLevel.value)
})

const selectedPlanInfo = computed(() => {
  if (!selectedPlan.value) return null
  return products.value.find((p: any) => p.id === selectedPlan.value) || null
})

const totalPrice = computed(() => {
  if (!selectedPlanInfo.value) return '0'
  if (confirmPayMethod.value === 'points') return String(selectedPlanInfo.value.points_price || selectedPlanInfo.value.price || 0)
  return String(displayPrice(selectedPlanInfo.value))
})

const couponDiscount = computed(() => {
  if (!selectedCouponInfo.value) return 0
  const c = selectedCouponInfo.value
  const base = Number(totalPrice.value)
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    let disc = Math.floor(base * c.value / 100 * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPrice = computed(() => {
  const tp = Number(totalPrice.value)
  const d = couponDiscount.value
  return String(Math.max(0, tp - d))
})

const isPointsCoupon = computed(() => {
  const t = selectedCouponInfo.value?.type
  return t === 'fixed_points' || t === 'points_percent'
})

const expirePreview = computed(() => {
  if (!selectedPlanInfo.value) return '--'
  const days = selectedPlanInfo.value.duration_days
  if (days === 0) return '永久有效'
  const d = new Date(Date.now() + days * 86400000)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
})

function displayPrice(p: any) {
  if (p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())) return Number(p.price) || 0
  return Number(p.original_price) || Number(p.price) || 0
}

function planPrice(p: any) { return displayPrice(p).toFixed(0) }

function planOriginalPrice(p: any) {
  if (!(p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()))) return 0
  return Number(p.original_price) || 0
}

function durationLabel(days: number) {
  if (days === 0) return '永久'
  if (days >= 365 && days % 365 === 0) return `${days / 365}年`
  if (days >= 30 && days % 30 === 0) return `${days / 30}个月`
  return `${days}天`
}

function isLevelHigher(lvl: any) {
  if (!currentLevelId.value) return lvl.level === 1
  return (lvl.level || 0) > (allLevels.value.find((l: any) => l.id === currentLevelId.value)?.level || 0)
}

function getLevelBenefits(lvl: any) {
  if (!lvl?.benefits) return []
  return lvl.benefits.split(/[,，、]/).filter((b: string) => b.trim()).map((b: string) => b.trim())
}

function selectLevel(lvl: any) {
  selectedLevel.value = lvl.id
  const plans = levelPlans.value
  if (plans.length > 0) selectedPlan.value = plans[0].id
}

function couponLabel(c: any) {
  const ip = c.type === 'fixed_points' || c.type === 'points_percent'
  const iff = c.type === 'fixed' || c.type === 'fixed_points'
  const pfx = iff ? `${ip ? '' : '¥'}${c.value}${ip ? '积分' : ''}` : `${c.value}折`
  const sfx = c.isMultiUse && c.remainingValue !== null ? `(剩${ip ? '' : '¥'}${c.remainingValue}${ip ? '积分' : ''})` : ''
  return `${pfx} ${c.name}${sfx}`
}

function onCouponSelect(e: Event) {
  const val = Number((e.target as HTMLSelectElement).value)
  if (!val) { selectedCouponId.value = 0; selectedCouponInfo.value = null }
  else { const c = usableCoupons.value.find((c: any) => c.userCouponId === val); selectedCouponId.value = val; selectedCouponInfo.value = c || null }
}

async function loadCoupons() {
  if (!isLogin.value || !selectedPlanInfo.value) { usableCoupons.value = []; return }
  try {
    const res: any = await fetchUsableCoupons({
      scene: 'membership', targetId: selectedLevel.value || 0,
      orderAmount: Number(totalPrice.value), payType: confirmPayMethod.value
    })
    usableCoupons.value = Array.isArray(res) ? res : []
    if (!usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value)) {
      selectedCouponId.value = 0; selectedCouponInfo.value = null
    }
  } catch { usableCoupons.value = [] }
}

watch([selectedPlan, confirmPayMethod], () => { selectedCouponId.value = 0; selectedCouponInfo.value = null })

async function loadProducts() {
  try {
    const [prodRes, levelRes] = await Promise.all([
      fetchMembershipProducts() as any,
      fetchGetMembershipLevelList({} as any) as any,
    ])
    const raw = (prodRes?.data || prodRes) || []
    const levelsData = (levelRes?.data?.records || levelRes?.records || levelRes?.data || levelRes) || []
    const levels = Array.isArray(levelsData) ? levelsData : []
    allLevels.value = levels
    const enriched = (Array.isArray(raw) ? raw : []).map((p: any) => {
      const level = levels.find((l: any) => l.id === p.level_id)
      return { ...p, levelName: level?.name || '' }
    })
    if (isLogin.value && userStore.info.levelId) {
      const currentLevel = levels.find((l: any) => l.id === userStore.info.levelId)
      if (currentLevel) pointsMultiplier.value = String(currentLevel.points_multiplier || currentLevel.pointsMultiplier || 1.0)
    }
    products.value = enriched
    const avail = availableLevels.value
    if (avail.length > 0) selectLevel(avail[0])
  } catch { /* ignore */ }
}

async function showConfirm() {
  if (!selectedPlan.value || !agreed.value) return
  if (!isLogin.value) {
    resultSuccess.value = false
    resultMsg.value = '请先登录'
    showResultModal.value = true
    return
  }
  confirmPayMethod.value = 'balance'
  selectedCouponId.value = 0
  selectedCouponInfo.value = null
  showConfirmModal.value = true
  loadCoupons()
}

async function handleConfirmPay() {
  showConfirmModal.value = false
  buyLoading.value = selectedPlan.value
  try {
    const res: any = await fetchBuyMembership(selectedPlan.value, confirmPayMethod.value, selectedCouponId.value || undefined)
    const info = selectedPlanInfo.value
    if (info) {
      userStore.info.levelId = info.level_id
      userStore.info.levelName = info.levelName || ''
      userStore.info.expireTime = res?.expireTime || ''
    }
    resultSuccess.value = true
    resultMsg.value = '恭喜您成功开通会员，立即享受专属权益'
    showResultModal.value = true
  } catch (e: any) {
    resultSuccess.value = false
    resultMsg.value = e?.message || e?.msg || e?.data?.msg || '支付失败，请重试'
    showResultModal.value = true
  } finally { buyLoading.value = 0 }
}

async function handleRedeemCardKey() {
  if (!cardKeyForm.value.cardNo || !cardKeyForm.value.password) { cardKeyMsg.value = '请输入卡号和密码'; return }
  cardKeyLoading.value = true; cardKeyMsg.value = ''
  try {
    const { fetchRedeemCardKey } = await import('@/api/appstore')
    const data: any = await fetchRedeemCardKey({
      cardNo: cardKeyForm.value.cardNo, password: cardKeyForm.value.password,
      userId: userStore.info.userId || 0, userName: userStore.info.userName || '',
    })
    if (data.code === 200) { cardKeyResult.value = 'success'; cardKeyMsg.value = data.msg || '兑换成功' }
    else { cardKeyMsg.value = data.msg || '兑换失败' }
  } catch (e: any) { cardKeyMsg.value = e?.message || '兑换失败' }
  finally { cardKeyLoading.value = false }
}

onMounted(() => { loadProducts() })
</script>

<style lang="scss" scoped>
.membership-page { min-height: 100vh; background: #f0f2f5; }

.nav-bar { position: sticky; top: 0; z-index: 50; background: var(--default-bg-color); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.06); }
.nav-inner { display: flex; align-items: center; justify-content: space-between; max-width: 480px; margin: 0 auto; padding: 12px 16px; }
.nav-back { width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: #333; svg { width: 20px; height: 20px; } }
.nav-title { font-size: 17px; font-weight: 600; color: #1a1a1a; margin: 0; }
.nav-placeholder { width: 28px; }

.page-content { max-width: 480px; margin: 0 auto; padding: 0 16px 120px; }

// VIP card
.vip-card { margin-top: 16px; background: linear-gradient(135deg, #1e1b4b, #312e81, #4338ca, #4f46e5); border-radius: 20px; padding: 24px 20px; position: relative; overflow: hidden; box-shadow: 0 8px 32px rgba(79,70,229,0.28); }
.vip-card-bg { position: absolute; right: -40px; top: -50px; width: 180px; height: 180px; border-radius: 50%; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); &::after { content: ''; position: absolute; right: -60px; bottom: -60px; width: 200px; height: 200px; border-radius: 50%; background: rgba(255,255,255,0.04); } }
.vip-card-inner { position: relative; z-index: 1; }
.vip-card-top { display: flex; justify-content: space-between; align-items: flex-start; }
.vip-badge { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.vip-dot { width: 8px; height: 8px; border-radius: 50%; background: #facc15; box-shadow: 0 0 8px rgba(250,204,21,0.5); }
.vip-level-text { font-size: 13px; color: rgba(255,255,255,0.7); font-weight: 500; }
.vip-expire { font-size: 12px; color: rgba(255,255,255,0.45); line-height: 1.5; }
.vip-status-tag { padding: 4px 12px; border-radius: 12px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); font-size: 11px; font-weight: 600; color: rgba(255,255,255,0.5); &.active { background: rgba(250,204,21,0.12); border-color: rgba(250,204,21,0.2); color: #facc15; } }
.vip-stats { display: flex; gap: 12px; margin-top: 16px; }
.vip-stat-item { flex: 1; background: rgba(255,255,255,0.06); border-radius: 12px; padding: 10px; text-align: center; border: 1px solid rgba(255,255,255,0.04); }
.vip-stat-label { font-size: 10px; color: rgba(255,255,255,0.4); }
.vip-stat-value { font-size: 18px; font-weight: 700; margin-top: 3px; &.accent-gold { color: #facc15; } &.accent-amber { color: #f59e0b; } &.accent-blue { color: #60a5fa; } }

// Sections
.section-card { background: #fff; border-radius: 16px; padding: 20px; margin-top: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
.section-header { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.section-icon { width: 32px; height: 32px; border-radius: 10px; display: flex; align-items: center; justify-content: center; svg { width: 18px; height: 18px; } }
.icon-amber { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #d97706; }
.icon-green { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #059669; }
.section-title { font-size: 16px; font-weight: 600; color: #1a1a1a; flex: 1; }

// Level cards
.level-list { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; -webkit-overflow-scrolling: touch; &::-webkit-scrollbar { display: none; } }
.level-card { flex: 0 0 46%; border: 2px solid #f0f0f0; border-radius: 16px; padding: 14px; cursor: pointer; transition: all .2s; position: relative; overflow: hidden; background: #fafbfc; &.selected { border-color: #6366f1; background: linear-gradient(135deg, rgba(99,102,241,0.04), rgba(99,102,241,0.01)); } &.current { border-color: #fbbf24; background: linear-gradient(135deg, rgba(251,191,36,0.04), rgba(251,191,36,0.01)); } }
.level-card-header { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.level-card-name { font-size: 15px; font-weight: 600; }
.level-tag { font-size: 10px; padding: 2px 8px; border-radius: 8px; font-weight: 600; }
.current-tag { background: rgba(251,191,36,0.15); color: #d97706; }
.recommend-tag { background: rgba(239,68,68,0.1); color: #ef4444; }
.level-card-price { display: flex; align-items: baseline; gap: 2px; }
.price-symbol { font-size: 14px; font-weight: 700; color: #ef4444; }
.price-value { font-size: 28px; font-weight: 800; color: #1a1a1a; line-height: 1; }
.price-unit { font-size: 12px; color: #999; }
.level-card-bar { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #6366f1, #8b5cf6); }

// Plans
.plan-section { margin-top: 16px; padding-top: 16px; border-top: 1px solid #f0f0f0; }
.plan-section-title { font-size: 14px; font-weight: 600; color: #666; margin-bottom: 10px; }
.plan-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.plan-item { border: 2px solid #f0f0f0; border-radius: 14px; padding: 12px 8px; text-align: center; cursor: pointer; transition: all .2s; &.active { border-color: #6366f1; background: linear-gradient(135deg, rgba(99,102,241,0.06), rgba(99,102,241,0.02)); } }
.plan-duration { font-size: 12px; font-weight: 600; color: #888; margin-bottom: 4px; }
.plan-price-row { display: flex; align-items: baseline; justify-content: center; gap: 1px; }
.plan-symbol { font-size: 12px; font-weight: 700; color: #ef4444; }
.plan-amount { font-size: 22px; font-weight: 800; color: #1a1a1a; line-height: 1; }
.plan-original { font-size: 11px; color: #ccc; text-decoration: line-through; margin-top: 2px; }

// Benefits compare
$blc-colors: (
  0: (#6366f1, #a5b4fc, #eef2ff),
  1: (#f59e0b, #fcd34d, #fffbeb),
  2: (#10b981, #6ee7b7, #ecfdf5),
  3: (#ec4899, #f9a8d4, #fdf2f8),
  4: (#06b6d4, #67e8f9, #ecfeff),
);

.benefits-compare {
  display: flex; gap: 10px; overflow-x: auto; padding: 6px 0 16px;
  -webkit-overflow-scrolling: touch; scroll-snap-type: x mandatory;
  &::-webkit-scrollbar { display: none; }
}

.benefit-level-col {
  flex: 0 0 52%; border-radius: 18px; padding: 0;
  background: #fafbfc; box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 6px 24px rgba(0,0,0,0.06);
  border: 1.5px solid #eef0f4; scroll-snap-align: start;
  position: relative; overflow: hidden; transition: transform .25s, box-shadow .25s;
  display: flex; flex-direction: column;
  &:active { transform: scale(0.985); }

  @each $i, $c in $blc-colors {
    &.blc-scheme-#{$i} {
      .blc-header { background: linear-gradient(160deg, nth($c,1), darken(nth($c,1), 8%)); }
      .blc-dot { background: nth($c,1); }
      .blc-hot { background: rgba(nth($c,1), 0.12); color: nth($c,1); }
      &.cur {
        border-color: nth($c,1);
        box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 8px 32px rgba(nth($c,1), 0.22);
      }
    }
  }

  &.cur {
    background: #fff;
    .blc-header { &::after { opacity: 0.15; } }
  }
}

.blc-ribbon {
  position: absolute; top: 10px; right: -28px; z-index: 2;
  background: linear-gradient(135deg, #f59e0b, #fbbf24);
  color: #7c2d12; font-size: 11px; font-weight: 700; padding: 3px 32px;
  transform: rotate(45deg); letter-spacing: 1px;
  box-shadow: 0 2px 6px rgba(245,158,11,.35);
}

.blc-header {
  padding: 20px 16px 16px; display: flex; align-items: center; gap: 10px;
  position: relative; overflow: hidden;
  &::after {
    content: ''; position: absolute; right: -16px; top: -16px;
    width: 80px; height: 80px; border-radius: 50%;
    background: #fff; opacity: 0.08; transition: opacity .3s;
  }
}

.blc-icon {
  width: 36px; height: 36px; border-radius: 10px;
  background: rgba(255,255,255,.22); display: flex;
  align-items: center; justify-content: center;
  svg { width: 18px; height: 18px; color: #fff; }
}

.blc-name {
  font-size: 16px; font-weight: 700; color: #fff; letter-spacing: 0.5px;
  text-shadow: 0 1px 2px rgba(0,0,0,.1);
}

.blc-badge-row { padding: 0 16px 8px; }
.blc-hot {
  display: inline-block; font-size: 10px; font-weight: 600;
  padding: 2px 10px; border-radius: 10px; letter-spacing: 0.5px;
}

.blc-items {
  padding: 0 16px; flex: 1;
  display: flex; flex-direction: column; gap: 4px;
}

.blc-item {
  display: flex; align-items: flex-start; gap: 10px;
  font-size: 13px; color: #555; line-height: 1.55;
  padding: 8px 10px; border-radius: 8px;
  background: rgba(0,0,0,0.015);
  transition: background .2s;
  &:hover { background: rgba(0,0,0,0.035); }
}

.blc-dot {
  width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0;
  margin-top: 7px; opacity: 0.7;
}

.blc-footer {
  padding: 14px 16px 18px; display: flex; justify-content: center;
  border-top: 1px solid rgba(0,0,0,0.05); margin-top: auto;
}

.blc-price { display: flex; align-items: baseline; gap: 2px; }
.blc-sym { font-size: 14px; color: #ef4444; font-weight: 700; }
.blc-num { font-size: 26px; font-weight: 800; color: #1a1a1a; line-height: 1; letter-spacing: -1px; }
.blc-unit { font-size: 12px; color: #bbb; margin-left: 1px; font-weight: 500; }

// Agreement
.agreement { display: flex; align-items: center; gap: 8px; padding: 16px 0; cursor: pointer; }
.agree-check { width: 20px; height: 20px; border-radius: 50%; border: 2px solid #d1d5db; display: flex; align-items: center; justify-content: center; flex-shrink: 0; svg { width: 12px; height: 12px; } &.checked { background: #6366f1; border-color: #6366f1; color: #fff; } }
.agree-text { font-size: 13px; color: #999; }
.agree-link { color: #6366f1; }

// Bottom pay bar
.pay-bar { position: fixed; bottom: 0; left: 0; right: 0; z-index: 40; background: var(--default-bg-color); border-top: 1px solid rgba(0,0,0,0.06); padding: 10px 16px 24px; }
.pay-bar-inner { max-width: 480px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.pay-bar-price { display: flex; align-items: baseline; gap: 2px; }
.pay-bar-unit { font-size: 14px; font-weight: 700; color: #ef4444; }
.pay-bar-total { font-size: 24px; font-weight: 800; color: #ef4444; line-height: 1; }
.pay-bar-expire { font-size: 11px; color: #999; margin-top: 2px; }
.pay-button { padding: 12px 28px; border: none; border-radius: 24px; background: linear-gradient(135deg, #6366f1, #4f46e5); color: #fff; font-size: 15px; font-weight: 700; cursor: pointer; white-space: nowrap; &:active { opacity: 0.85; } &.disabled { opacity: 0.5; pointer-events: none; } }

// Confirm sheet (mall style)
.confirm-overlay { position: fixed; inset: 0; z-index: 1001; background: rgba(0,0,0,0.55); display: flex; align-items: flex-end; }
.confirm-sheet { width: 100%; background: #fff; border-radius: 20px 20px 0 0; max-height: 85vh; display: flex; flex-direction: column; animation: slideUp .3s ease; }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
.confirm-header { display: flex; align-items: center; justify-content: space-between; padding: 18px 20px 14px; border-bottom: 1px solid #f0f0f0; }
.confirm-title { font-size: 18px; font-weight: 700; color: #111; }
.confirm-close { width: 24px; height: 24px; cursor: pointer; }
.confirm-body { flex: 1; overflow-y: auto; padding: 0 20px; }
.confirm-section { padding: 16px 0; border-bottom: 1px solid #f5f5f5; &:last-child { border-bottom: none; } }
.confirm-section-title { font-size: 14px; font-weight: 700; color: #111; margin-bottom: 12px; }
.confirm-product { display: flex; gap: 12px; align-items: center; }
.confirm-coupon-select {
  width: 100%; height: 44px; padding: 0 12px;
  border: 1.5px solid #e0e0e0; border-radius: 8px;
  font-size: 14px; color: #333; background: #fff;
  outline: none; appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M6 9l6 6 6-6' stroke='%23999' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat; background-position: right 12px center;
}
.confirm-coupon-empty { font-size: 13px; color: #bbb; padding: 4px 0; }
.confirm-pay-methods { display: flex; flex-wrap: wrap; gap: 8px; }
.confirm-pay-item { padding: 8px 20px; border-radius: 8px; border: 1.5px solid #e0e0e0; font-size: 13px; color: #666; cursor: pointer; transition: all .2s; background: #fff; &.active { border-color: #00bfa5; background: #e0f2f1; color: #009688; font-weight: 600; } }
.confirm-product-info { flex: 1; min-width: 0; }
.confirm-product-name { font-size: 15px; font-weight: 600; color: #333; }
.confirm-product-sub { font-size: 12px; color: #999; margin-top: 2px; }
.confirm-product-price { font-size: 20px; font-weight: 700; color: #FF4757; margin-top: 4px; }
.confirm-price-breakdown { background: #fafafa; border-radius: 10px; padding: 14px; }
.confirm-price-row { display: flex; justify-content: space-between; align-items: center; padding: 5px 0; }
.confirm-price-label { font-size: 13px; color: #777; }
.confirm-price-val { font-size: 13px; color: #333; font-weight: 500; &.discount { color: #10b981; } }
.confirm-price-divider { height: 1px; background: #e8e8e8; margin: 8px 0; }
.confirm-price-row.total .confirm-price-label { font-size: 15px; font-weight: 700; color: #111; }
.confirm-price-row.total .confirm-price-val.total-val { font-size: 20px; font-weight: 800; color: #FF4757; }
.confirm-footer { padding: 12px 20px 32px; }
.confirm-btn-submit { width: 100%; height: 48px; border: none; border-radius: 24px; background: linear-gradient(135deg, #FF5252, #FF1744); color: #fff; font-size: 16px; font-weight: 700; cursor: pointer; &:disabled { opacity: 0.5; cursor: not-allowed; } &:active { opacity: 0.85; } }

// Result modal
.modal-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; }
.result-modal { background: #fff; border-radius: 24px; width: 300px; padding: 32px 24px 24px; text-align: center; }
.result-icon { width: 56px; height: 56px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; svg { width: 28px; height: 28px; } &.success { background: #ecfdf5; color: #10b981; } &.fail { background: #fef2f2; color: #ef4444; } &.small { width: 40px; height: 40px; svg { width: 20px; height: 20px; } } }
.result-title { font-size: 18px; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; }
.result-msg { font-size: 13px; color: #888; line-height: 1.6; margin-bottom: 16px; }
.result-detail { background: #f8f9fb; border-radius: 12px; padding: 14px 16px; margin-bottom: 16px; }
.result-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; color: #888; .strong { color: #333; font-weight: 600; } .accent { color: #ef4444; font-weight: 700; } }
.result-row + .result-row { border-top: 1px solid #eee; }
.result-btn { width: 100%; height: 44px; border: none; border-radius: 22px; background: #f3f4f6; color: #666; font-size: 15px; font-weight: 600; cursor: pointer; &.primary { background: linear-gradient(135deg, #6366f1, #4f46e5); color: #fff; } }

// Card key modal
.cardkey-modal { background: #fff; border-radius: 24px; width: 300px; padding: 32px 24px 24px; text-align: center; }
.cardkey-title { font-size: 18px; font-weight: 700; color: #1a1a1a; margin-bottom: 20px; }
.cardkey-input { width: 100%; height: 44px; border: 1.5px solid #e5e7eb; border-radius: 12px; padding: 0 14px; font-size: 14px; margin-bottom: 12px; outline: none; box-sizing: border-box; &:focus { border-color: #6366f1; } }
.cardkey-error { color: #ef4444; font-size: 12px; padding: 4px 0; text-align: left; }
.cardkey-actions { display: flex; gap: 10px; margin-top: 16px; }
.cardkey-btn { flex: 1; height: 44px; border: none; border-radius: 22px; font-size: 15px; font-weight: 600; cursor: pointer; &.cancel { background: #f3f4f6; color: #666; } &.confirm { background: linear-gradient(135deg, #6366f1, #4f46e5); color: #fff; } &:disabled { opacity: 0.5; } }
</style>
