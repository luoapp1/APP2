<template>
  <div class="vip-page">
    <header class="vip-nav">
      <div class="vip-nav-back" @click="$router.back()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M15 19l-7-7 7-7"/></svg>
      </div>
      <h1 class="vip-nav-title">会员中心</h1>
    </header>

    <div class="vip-hero">
      <div class="vip-hero-deco d1" />
      <div class="vip-hero-deco d2" />
      <div class="vip-hero-content">
        <div class="vip-hero-user">
          <div class="vip-hero-avatar">
            <img v-if="avatarUrl" :src="avatarUrl" />
            <svg v-else viewBox="0 0 24 24" fill="currentColor" width="24" height="24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v1.2c0 .66.54 1.2 1.2 1.2h16.8c.66 0 1.2-.54 1.2-1.2v-1.2c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
          </div>
          <div class="vip-hero-info">
            <div class="vip-hero-nick">{{ userDisplayName }}</div>
            <div class="vip-hero-badge-row">
              <span v-if="isLogin && currentLevelName" class="vip-hero-badge">
                <svg viewBox="0 0 24 24" fill="currentColor" width="13" height="13"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                {{ currentLevelName }}
              </span>
              <span v-else class="vip-hero-badge guest">普通用户</span>
            </div>
          </div>
        </div>
        <div v-if="isLogin" class="vip-hero-expire">
          <div v-if="myMemberships.length">
            <div v-for="m in myMemberships" :key="m.id" class="vip-membership-row">
              <span class="vip-membership-tag" :style="{ background: m.bg_color || '#333', color: m.text_color || '#fff' }">{{ m.level_name }}</span>
              <span class="vip-membership-expiry">到期 {{ formatExpire(m.expire_time) }}</span>
            </div>
          </div>
          <div v-else-if="userStore.info.expireTime">到期：{{ expireTimeDisplay }}</div>
        </div>
      </div>
    </div>

    <div class="vip-body">
      <div class="vip-section">
        <div class="vip-sec-title">会员购买</div>

        <div class="vip-seg" v-if="availableLevels.length > 1">
          <div
            v-for="lvl in availableLevels" :key="lvl.id"
            class="vip-seg-item" :class="{ active: selectedLevel === lvl.id }"
            @click="selectLevel(lvl)"
          >{{ lvl.name }}</div>
        </div>

        <div class="vip-plan-cards" v-if="levelPlans.length > 0">
          <div
            v-for="p in levelPlans" :key="p.id"
            class="vip-pcard" :class="{ active: selectedPlan === p.id }"
            @click="selectedPlan = p.id"
          >
            <div class="vip-pcard-badge" v-if="p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())">限时特惠</div>
            <div class="vip-pcard-dur">{{ durationLabel(p.duration_days) }}</div>
            <div class="vip-pcard-price">
              <span class="vip-pcard-sym">&#165;</span>
              <span class="vip-pcard-val">{{ planPrice(p) }}</span>
            </div>
            <div v-if="planOriginalPrice(p) > Number(planPrice(p))" class="vip-pcard-old">&#165;{{ planOriginalPrice(p) }}</div>
            <div v-else class="vip-pcard-old-placeholder" />
            <div class="vip-pcard-bar">{{ capacityLabel || selectedLevelName + '会员' }}</div>
          </div>
        </div>
      </div>

      <div class="vip-section" v-if="compareLevels.length >= 2">
        <div class="vip-sec-title">权益对比</div>
        <div class="vip-compare-scroll">
          <table class="vip-compare-table">
            <thead>
              <tr>
                <th class="vip-cth-label"></th>
                <th v-for="cl in compareLevels" :key="cl.id"
                  class="vip-cth" :class="{ highlight: cl.id === highlightLevelId }">
                  <div class="vip-cth-badge" v-if="cl.id === highlightLevelId">
                    <svg viewBox="0 0 24 24" fill="currentColor" width="12" height="12"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                  </div>
                  <div class="vip-cth-name">{{ cl.name }}</div>
                </th>
              </tr>
            </thead>
            <tbody>
              <template v-for="(row, ri) in allLevelCompareRows" :key="ri">
                <tr :class="{ alt: ri % 2 === 1, expandable: isGiftRow(row.label) }">
                  <td class="vip-ctd-label"
                    :class="{ clickable: isGiftRow(row.label) }"
                    @click="isGiftRow(row.label) && toggleGiftRow(row.label)"
                  >
                    <span>{{ row.label }}</span>
                    <svg v-if="isGiftRow(row.label)" class="vip-ctd-arrow" :class="{ open: expandedGiftRows.has(row.label) }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="10" height="10"><path d="M6 9l6 6 6-6"/></svg>
                  </td>
                  <td v-for="cell in row.cells" :key="cell.levelId"
                    class="vip-ctd" :class="{ highlight: cell.levelId === highlightLevelId }">
                    <template v-if="!isGiftRow(row.label) || !expandedGiftRows.has(row.label)">
                      <template v-if="cell.type === 'check'">
                        <svg v-if="cell.value" class="vip-ctd-ico chk" viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                        <svg v-else class="vip-ctd-ico cross" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><path d="M6 18L18 6M6 6l12 12"/></svg>
                      </template>
                      <template v-else>
                        <span class="vip-ctd-txt">{{ cell.value }}</span>
                      </template>
                    </template>
                    <template v-else>
                      <span class="vip-ctd-txt gift-detail">{{ getGiftDetail(cell.levelId, row.label) || '无' }}</span>
                    </template>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>

      <div class="vip-bottom-safe" />
    </div>

    <footer class="vip-bottom">
      <button
        class="vip-bottom-btn"         :class="{ disabled: !selectedPlan }"
        :disabled="!selectedPlan || buyLoading > 0"
        @click="showConfirm"
      >
        <span v-if="buyLoading > 0" class="vip-btn-spinner" /> 确认协议并支付 &#165;{{ totalPrice }}
      </button>
    </footer>

    <div class="vip-overlay" v-if="showConfirmModal" @click.self="showConfirmModal = false">
      <div class="vip-sheet">
        <div class="vip-sheet-bar" />
        <div class="vip-sheet-head">
          <span class="vip-sheet-title">确认支付</span>
          <svg class="vip-sheet-close" @click="showConfirmModal = false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </div>
        <div class="vip-sheet-body">
          <div class="vip-sheet-prod">
            <div class="vip-sheet-prod-icon">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
            </div>
            <div class="vip-sheet-prod-info">
              <div class="vip-sheet-prod-name">{{ selectedPlanInfo?.name || selectedPlanInfo?.levelName || selectedLevelName }}</div>
              <div class="vip-sheet-prod-sub">{{ selectedPlanInfo ? durationLabel(selectedPlanInfo.duration_days) : '' }}</div>
            </div>
            <div class="vip-sheet-prod-price">&#165;{{ totalPrice }}</div>
          </div>
          <div class="vip-sheet-row">
            <span class="vip-sr-label">支付方式</span>
            <div class="vip-sr-pays">
              <div class="vip-sr-pay" :class="{ active: confirmPayMethod === 'balance' }" @click="confirmPayMethod = 'balance'">余额</div>
              <div class="vip-sr-pay" :class="{ active: confirmPayMethod === 'points' }" @click="confirmPayMethod = 'points'">积分</div>
            </div>
          </div>
          <div class="vip-sheet-row" v-if="isLogin && effectiveCoupons.length > 0">
            <span class="vip-sr-label">优惠券</span>
            <div class="vip-cp-trigger" @click="showCouponPicker = !showCouponPicker">
              <span v-if="selectedCouponId" class="vip-cp-selected">{{ selectedCouponInfo?.name }} ({{ selectedCouponInfo?.type === 'fixed' ? '¥' + selectedCouponInfo?.value : selectedCouponInfo?.type === 'fixed_points' ? selectedCouponInfo?.value + '积分' : (selectedCouponInfo?.value / 10) + '折' }})</span>
              <span v-else class="vip-cp-placeholder">不使用优惠券</span>
              <svg class="vip-cp-arrow" :class="{ open: showCouponPicker }" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><path d="M6 9l6 6 6-6"/></svg>
            </div>
          </div>
          <div class="vip-cp-dropdown" v-if="showCouponPicker">
            <div
              class="vip-cp-opt"
              :class="{ active: selectedCouponId === 0 }"
              @click="selectCoupon(null)"
            >不使用优惠券</div>
            <div
              v-for="c in effectiveCoupons" :key="c.userCouponId"
              class="vip-cp-opt"
              :class="{ active: selectedCouponId === c.userCouponId }"
              @click="selectCoupon(c)"
            >
              <span>{{ c.name }}</span>
              <span v-if="c.type === 'fixed' || c.type === 'fixed_points'" class="vip-cp-val">{{ c.type === 'fixed_points' ? c.value + '积分' : '¥' + c.value }}</span>
              <span v-else class="vip-cp-val">{{ c.value / 10 }}折</span>
            </div>
          </div>
          <div class="vip-sheet-total">
            <div class="vip-st-row"><span>应付金额</span><span class="vip-st-red">&#165;{{ finalPrice }}</span></div>
            <div v-if="couponDiscount > 0" class="vip-st-row sub"><span>已优惠</span><span class="vip-cp-saved">-&#165;{{ couponDiscount }}</span></div>
            <div v-if="selectedPlanInfo" class="vip-st-row sub"><span>有效期至</span><span>{{ expirePreview }}</span></div>
          </div>
        </div>
        <button class="vip-sheet-pay-btn" :disabled="buyLoading > 0" @click="handleConfirmPay">
          {{ buyLoading > 0 ? '支付中...' : '立即支付' }}
        </button>
      </div>
    </div>

    <div v-if="showResultModal" class="vip-overlay center" @click.self="showResultModal = false">
      <div class="vip-toast">
        <div class="vip-toast-icon" :class="resultSuccess ? 'ok' : 'fail'">
          <svg v-if="resultSuccess" viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="28" height="28"><path d="M6 18L18 6M6 6l12 12"/></svg>
        </div>
        <div class="vip-toast-title">{{ resultSuccess ? '支付成功' : '支付失败' }}</div>
        <div class="vip-toast-msg">{{ resultMsg }}</div>
        <button class="vip-toast-btn" @click="showResultModal = false">我知道了</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'
import request from '@/utils/http'

const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const showConfirmModal = ref(false)
const showResultModal = ref(false)
const resultSuccess = ref(false)
const resultMsg = ref('')
const confirmPayMethod = ref('balance')
const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)
const showCouponPicker = ref(false)

const isLogin = computed(() => userStore.isLogin)

const avatarUrl = computed(() => {
  const av = userStore.info.avatar
  if (!av) return ''
  if (av.startsWith('http')) return av
  return av
})

const userDisplayName = computed(() => {
  return userStore.info.nickname || userStore.info.userName || userStore.info.phone || '未登录'
})

const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '')

const myMemberships = ref<any[]>([])
const fetchMyMemberships = async () => {
  try {
    const res: any = await request.get({ url: '/api/membership/my-memberships', showErrorMessage: false })
    myMemberships.value = res || []
  } catch {}
}
const currentMembershipLabel = computed(() => {
  if (!myMemberships.value.length) return ''
  return myMemberships.value.map(m => `${m.level_name}(${formatExpire(m.expire_time)})`).join(' | ')
})

function formatExpire(t: string) {
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return '永久'
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
  } catch { return '' }
}

const expireTimeDisplay = computed(() => {
  const t = userStore.info.expireTime
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return ''
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  } catch { return '' }
})

const availableLevels = computed(() => {
  return allLevels.value
    .filter((l: any) => l.status === '1')
    .filter((l: any) => products.value.some((p: any) => p.level_id === l.id))
    .sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const selectedLevelName = computed(() => allLevels.value.find((l: any) => l.id === selectedLevel.value)?.name || '')

const levelMinPrice = (lvl: any) => {
  const plans = products.value.filter((p: any) => p.level_id === lvl.id && Number(p.price) > 0)
  if (plans.length === 0) return lvl.price || 0
  return Math.min(...plans.map((p: any) => Number(p.price) || Infinity))
}

const levelPlans = computed(() => {
  if (!selectedLevel.value) return []
  return products.value.filter((p: any) => p.level_id === selectedLevel.value)
})

const selectedPlanInfo = computed(() => {
  if (!selectedPlan.value) return null
  return products.value.find((p: any) => p.id === selectedPlan.value) || null
})

const totalPrice = computed(() => {
  if (!selectedPlanInfo.value) return '0'
  if (confirmPayMethod.value === 'points') return String(selectedPlanInfo.value.points_price || selectedPlanInfo.value.price || 0)
  return String(displayPrice(selectedPlanInfo.value))
})

const couponDiscount = computed(() => {
  if (!selectedCouponInfo.value) return 0
  const c = selectedCouponInfo.value
  const base = Number(totalPrice.value)
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    const pct = Math.max(0, (10 - c.value) / 10)
    let disc = Math.floor(base * pct * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPrice = computed(() => String(Math.max(0, Number(totalPrice.value) - couponDiscount.value)))

const expirePreview = computed(() => {
  if (!selectedPlanInfo.value) return '--'
  const days = selectedPlanInfo.value.duration_days
  if (days === 0) return '永久有效'
  const d = new Date(Date.now() + days * 86400000)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
})

function displayPrice(p: any) {
  if (p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())) return Number(p.price) || 0
  return Number(p.original_price) || Number(p.price) || 0
}
function planPrice(p: any) { return displayPrice(p).toFixed(0) }
function planOriginalPrice(p: any) {
  if (!(p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()))) return 0
  return Number(p.original_price) || 0
}
function durationLabel(days: number) {
  if (days === 0) return '永久'
  if (days >= 365 && days % 365 === 0) return `${days / 365}年`
  if (days >= 30 && days % 30 === 0) return `${days / 30}个月`
  return `${days}天`
}

const capacityLabel = computed(() => {
  const lv = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  if (!lv) return ''
  const dl = Number(lv.dataLimitMb || 0)
  if (dl <= 0) return ''
  if (dl >= 1048576) return `${(dl / 1048576).toFixed(0)}TB大容量`
  if (dl >= 1024) return `${(dl / 1024).toFixed(0)}GB大容量`
  return `${dl}MB`
})

function selectLevel(lvl: any) {
  selectedLevel.value = lvl.id
  const plans = products.value.filter((p: any) => p.level_id === lvl.id)
  if (plans.length > 0) selectedPlan.value = plans[0].id
  else selectedPlan.value = 0
}

const compareLevels = computed(() => {
  return allLevels.value.filter((l: any) => l.status === '1').sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const highlightLevelId = computed(() => {
  const levels = compareLevels.value
  if (levels.length === 0) return 0
  const maxLvl = levels.reduce((max: any, l: any) => (l.level || 0) > (max.level || 0) ? l : max, levels[0])
  return maxLvl.id
})

const giftRowLabels = new Set(['生日礼包', '定时专属礼包', '首次开通赠送'])
const expandedGiftRows = ref(new Set<string>())

function isGiftRow(label: string) { return giftRowLabels.has(label) }
function toggleGiftRow(label: string) {
  const s = new Set(expandedGiftRows.value)
  if (s.has(label)) s.delete(label); else s.add(label)
  expandedGiftRows.value = s
}

const giftDetailMap: Record<string, [string, string]> = {
  '生日礼包': ['birthday_gift', 'birthdayGift'],
  '定时专属礼包': ['daily_gift', 'dailyGift'],
  '首次开通赠送': ['gift', 'gift'],
}

function giftValFromLevel(lvl: any, snakePrefix: string, camelPrefix: string) {
  const v = (key: string) => Number(lvl[key] || 0)
  return {
    pts: v(`${snakePrefix}_points`) || v(camelPrefix + 'Points'),
    bal: v(`${snakePrefix}_balance`) || v(camelPrefix + 'Balance'),
    exp: v(`${snakePrefix}_experience`) || v(camelPrefix + 'Experience'),
  }
}

function getGiftDetail(levelId: number, label: string): string {
  const key = giftDetailMap[label]
  if (!key) return ''
  const lvl = compareLevels.value.find((l: any) => l.id === levelId)
  if (!lvl) return ''
  const g = giftValFromLevel(lvl, key[0], key[1])
  const parts: string[] = []
  if (g.pts > 0) parts.push(`+${g.pts}积分`)
  if (g.bal > 0) parts.push(`+¥${g.bal}`)
  if (g.exp > 0) parts.push(`+${g.exp}经验`)
  return parts.length > 0 ? parts.join(' ') : ''
}

interface CompareCell {
  levelId: number
  type: 'check' | 'text'
  value: string | boolean
}

interface CompareRow {
  label: string
  cells: CompareCell[]
}

const allLevelCompareRows = computed((): CompareRow[] => {
  const levels = compareLevels.value
  if (levels.length < 2) return []

  const checkBy = (lvl: any, cond: boolean): CompareCell => ({
    levelId: lvl.id,
    type: 'check' as const,
    value: cond
  })

  const textBy = (lvl: any, text: string): CompareCell => ({
    levelId: lvl.id,
    type: 'text' as const,
    value: text
  })

  const fmtSize = (mb: number): string => {
    if (mb <= 0) return '不限'
    if (mb >= 1048576) return `${(mb / 1048576).toFixed(0)}TB`
    if (mb >= 1024) return `${(mb / 1024).toFixed(0)}GB`
    return `${mb}MB`
  }

  const hasGiftVal = (lvl: any, snakePrefix: string, camelPrefix: string): { pts: number; bal: number; exp: number } => {
    return giftValFromLevel(lvl, snakePrefix, camelPrefix)
  }

  const giftDetail = (lvl: any, snakePrefix: string, camelPrefix: string): string => {
    const g = hasGiftVal(lvl, snakePrefix, camelPrefix)
    const parts: string[] = []
    if (g.pts > 0) parts.push(`+${g.pts}积分`)
    if (g.bal > 0) parts.push(`+¥${g.bal}`)
    if (g.exp > 0) parts.push(`+${g.exp}经验`)
    return parts.length > 0 ? parts.join(' ') : ''
  }

  const hasGift = (lvl: any, snakePrefix: string, camelPrefix: string): boolean => {
    const g = hasGiftVal(lvl, snakePrefix, camelPrefix)
    return g.pts > 0 || g.bal > 0 || g.exp > 0
      || !!(lvl[`${snakePrefix}_coupon_ids`] || lvl[camelPrefix + 'CouponIds'])
  }

  const benefitMap = new Map<number, string[]>()
  for (const lv of levels) {
    benefitMap.set(lv.id, (lv.benefits || '').split(/[,，、]/).filter((s: string) => s.trim()).map((s: string) => s.trim()))
  }

  const hasBenefit = (lvl: any, keyword: string): boolean => {
    const bs = benefitMap.get(lvl.id) || []
    return bs.some((b: string) => b.includes(keyword) || keyword.includes(b))
  }

  type RowDef = { label: string; cell: (lvl: any) => CompareCell }

  const rowDefs: RowDef[] = [
    {
      label: '基础权益',
      cell: (lvl) => checkBy(lvl, (benefitMap.get(lvl.id) || []).length > 0)
    },
    {
      label: '商品折扣',
      cell: (lvl) => {
        const dr = Number(lvl.discountRate || lvl.discount_rate || 1)
        return textBy(lvl, dr < 1 ? `${(dr * 10).toFixed(0)}折` : '原价')
      }
    },
    {
      label: '积分倍数',
      cell: (lvl) => textBy(lvl, `${lvl.pointsMultiplier || lvl.points_multiplier || 1}倍`)
    },
    {
      label: '数据空间',
      cell: (lvl) => textBy(lvl, fmtSize(Number(lvl.dataLimitMb || lvl.data_limit_mb || 0)))
    },
    {
      label: '文件空间',
      cell: (lvl) => textBy(lvl, fmtSize(Number(lvl.fileLimitMb || lvl.file_limit_mb || 0)))
    },
    {
      label: '专属称号',
      cell: (lvl) => checkBy(lvl, !!(lvl.titleId || lvl.title_id || lvl.titleName))
    },
    {
      label: '生日礼包',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'birthday_gift', 'birthdayGift'))
    },
    {
      label: '年度礼品',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '年度礼品'))
    },
    {
      label: '优先发货',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '优先发货'))
    },
    {
      label: '专属客服',
      cell: (lvl) => checkBy(lvl, hasBenefit(lvl, '专属客服'))
    },
    {
      label: '专属头像框',
      cell: (lvl) => checkBy(lvl, !!(lvl.frameId || lvl.frame_id || lvl.frameName))
    },
    {
      label: '首次开通赠送',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'gift', 'gift'))
    },
    {
      label: '定时专属礼包',
      cell: (lvl) => checkBy(lvl, hasGift(lvl, 'daily_gift', 'dailyGift') || !!(lvl.dailyGiftEnabled || lvl.daily_gift_enabled))
    },
  ]

  return rowDefs.map(def => ({
    label: def.label,
    cells: levels.map(l => def.cell(l))
  }))
})

async function loadCoupons() {
  if (!isLogin.value || !selectedPlanInfo.value) { usableCoupons.value = []; return }
  try {
    const res: any = await fetchUsableCoupons({ scene: 'membership', targetId: selectedLevel.value || 0, orderAmount: Number(totalPrice.value), payType: confirmPayMethod.value })
    usableCoupons.value = Array.isArray(res) ? res : []
    if (!usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value)) { selectedCouponId.value = 0; selectedCouponInfo.value = null }
  } catch { usableCoupons.value = [] }
}

function selectCoupon(c: any) {
  selectedCouponId.value = c ? c.userCouponId : 0
  selectedCouponInfo.value = c || null
  showCouponPicker.value = false
}

const effectiveCoupons = computed(() => {
  const base = Number(totalPrice.value)
  return usableCoupons.value.filter((c: any) => {
    if (c.type === 'fixed' || c.type === 'fixed_points') return c.value > 0 && c.value < base
    if (c.type === 'percent' || c.type === 'points_percent') return c.value < 10
    return false
  })
})

watch([selectedPlan, confirmPayMethod], () => { selectedCouponId.value = 0; selectedCouponInfo.value = null; loadCoupons() })

async function loadProducts() {
  try {
    const [prodRes, levelRes] = await Promise.all([
      fetchMembershipProducts() as any,
      fetchGetMembershipLevelList({} as any) as any
    ])
    const raw = (prodRes?.data || prodRes) || []
    const levelsData = (levelRes?.data?.records || levelRes?.records || levelRes?.data || levelRes) || []
    const levels = Array.isArray(levelsData) ? levelsData : []
    allLevels.value = levels
    const enriched = (Array.isArray(raw) ? raw : []).map((p: any) => {
      const level = levels.find((l: any) => l.id === p.level_id)
      return { ...p, levelName: level?.name || '' }
    })
    products.value = enriched
    const avail = availableLevels.value
    if (avail.length > 0) selectLevel(avail[0])
  } catch { /* ignore */ }
}

async function showConfirm() {
  if (!selectedPlan.value) return
  if (!isLogin.value) { resultSuccess.value = false; resultMsg.value = '请先登录'; showResultModal.value = true; return }
  confirmPayMethod.value = 'balance'
  selectedCouponId.value = 0
  selectedCouponInfo.value = null
  showConfirmModal.value = true
  loadCoupons()
}

async function handleConfirmPay() {
  showConfirmModal.value = false
  buyLoading.value = selectedPlan.value
  try {
    const res: any = await fetchBuyMembership(selectedPlan.value, confirmPayMethod.value, selectedCouponId.value || undefined)
    await fetchMyMemberships()
    if (myMemberships.value.length) {
      const top = myMemberships.value[0]
      userStore.info.levelId = top.level_id
      userStore.info.levelName = top.level_name
      userStore.info.expireTime = top.expire_time
    }
    resultSuccess.value = true
    resultMsg.value = '恭喜您成功开通会员，立即享受专属权益'
    showResultModal.value = true
  } catch (e: any) {
    resultSuccess.value = false
    resultMsg.value = e?.message || e?.msg || e?.data?.msg || '支付失败，请重试'
    showResultModal.value = true
  } finally { buyLoading.value = 0 }
}

onMounted(() => { loadProducts(); fetchMyMemberships() })
</script>

<style lang="scss" scoped>
$blue: #3b6df0;
$blue-light: #5b8af7;
$blue-bg: #eef3ff;
$gold: #e8b44b;
$gold-light: #fef8eb;
$bg: #f2f5fa;
$card: #ffffff;
$text: #1a1a2e;
$text2: #505568;
$text3: #949aad;
$border: #eceff5;

.vip-page {
  min-height: 100vh;
  background: $bg;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', sans-serif;
  -webkit-font-smoothing: antialiased;
}

// ── Nav ──
.vip-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba($bg, 0.9);
  backdrop-filter: saturate(180%) blur(20px);
  -webkit-backdrop-filter: saturate(180%) blur(20px);
}
.vip-nav-back {
  width: 34px; height: 34px;
  display: flex; align-items: center; justify-content: center;
  color: $text2; cursor: pointer;
  background: $card; border-radius: 10px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  svg { width: 18px; height: 18px; }
}
.vip-nav-title {
  font-size: 16px; font-weight: 700; color: $text; margin: 0;
  letter-spacing: 0.3px;
}
.vip-nav-right {
  display: flex; align-items: center; gap: 3px;
  font-size: 12px; color: $text3; cursor: pointer;
  padding: 6px 10px; border-radius: 8px;
  background: $card;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  svg { color: $text3; width: 14px; height: 14px; }
}

// ── Hero ──
.vip-hero {
  position: relative;
  margin: 12px 16px 0;
  padding: 24px 20px;
  background: linear-gradient(150deg, #e0ecff 0%, #f0e8ff 45%, #eaf3ff 100%);
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(99,132,241,0.06);
}
.vip-hero-deco {
  position: absolute; border-radius: 50%; pointer-events: none; opacity: 0.6;
  &.d1 {
    width: 160px; height: 160px;
    background: radial-gradient(circle, rgba(99,132,241,0.12), transparent 70%);
    top: -50px; right: -30px;
  }
  &.d2 {
    width: 100px; height: 100px;
    background: radial-gradient(circle, rgba(168,85,247,0.1), transparent 70%);
    bottom: -25px; left: 30%;
  }
}
.vip-hero-content {
  position: relative; z-index: 1;
  display: flex; align-items: center; justify-content: space-between;
}
.vip-hero-user {
  display: flex; align-items: center; gap: 14px; flex: 1; min-width: 0;
}
.vip-hero-avatar {
  width: 50px; height: 50px; border-radius: 50%;
  background: linear-gradient(135deg, #c7d2fe, #a5b4fc);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; overflow: hidden;
  box-shadow: 0 2px 8px rgba(99,132,241,0.2);
  img { width: 100%; height: 100%; object-fit: cover; }
  svg { color: #6366f1; }
}
.vip-hero-info { flex: 1; min-width: 0; }
.vip-hero-nick {
  font-size: 17px; font-weight: 700; color: $text;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.vip-hero-badge-row { margin-top: 3px; }
.vip-hero-badge {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: 11px; font-weight: 600;
  padding: 3px 10px; border-radius: 10px;
  background: linear-gradient(135deg, #fde68a, #fcd34d);
  color: #92400e;
  svg { flex-shrink: 0; }
  &.guest {
    background: #e2e4ea; color: $text3;
  }
}
.vip-hero-expire {
  position: relative; z-index: 1;
  margin-top: 12px;
  font-size: 11px; color: $text3; text-align: right;
  padding-right: 4px;
}

// ── Body ──
.vip-body {
  padding: 16px 16px 100px;
  display: flex; flex-direction: column; gap: 12px;
}

// ── Section ──
.vip-section {
  background: $card;
  border-radius: 18px;
  padding: 18px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02);
}
.vip-sec-title {
  font-size: 15px; font-weight: 700; color: $text;
  margin-bottom: 16px;
  display: flex; align-items: center; gap: 8px;
  &::before {
    content: '';
    width: 3px; height: 16px;
    background: $blue; border-radius: 2px;
  }
}

// ── Segment Control ──
.vip-seg {
  display: flex;
  background: #f2f4f8;
  border-radius: 26px;
  padding: 4px;
  margin-bottom: 18px;
}
.vip-seg-item {
  flex: 1; text-align: center;
  padding: 10px 0; border-radius: 23px;
  font-size: 15px; font-weight: 400; color: $text3;
  cursor: pointer; transition: all 0.25s;
  &.active {
    background: #fff;
    color: $blue; font-weight: 600;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
  }
}

// ── Plan Cards ──
.vip-plan-cards {
  display: flex; gap: 8px; padding: 0 8px;
}
.vip-pcard {
  flex: 1; max-width: 98px;
  background: #fff;
  border-radius: 14px;
  padding: 14px 6px 0;
  text-align: center;
  position: relative;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  cursor: pointer;
  transition: all 0.2s;
  overflow: hidden;
  &:active { transform: scale(0.95); }
  &.active {
    box-shadow: 0 0 0 2px $blue, 0 3px 12px rgba($blue, 0.18);
  }
}
.vip-pcard-badge {
  position: absolute; top: 0; left: 0;
  background: linear-gradient(135deg, #f97316, #ef4444);
  color: #fff;
  font-size: 8px; font-weight: 700;
  padding: 2px 7px;
  border-radius: 0 0 10px 0;
  line-height: 1.3;
}
.vip-pcard-dur {
  font-size: 12px; font-weight: 500; color: $text3;
  margin-bottom: 6px;
}
.vip-pcard-price {
  display: flex; align-items: baseline; justify-content: center; gap: 1px;
}
.vip-pcard-sym {
  font-size: 12px; font-weight: 700; color: $blue;
}
.vip-pcard-val {
  font-size: 28px; font-weight: 800; color: $text;
  line-height: 1; letter-spacing: -1px;
}
.vip-pcard-old {
  font-size: 10px; color: #c4cad6; text-decoration: line-through;
  margin-top: 3px; line-height: 1;
}
.vip-pcard-old-placeholder {
  height: 16px;
}
.vip-pcard-bar {
  margin: 10px -6px 0;
  padding: 7px 0;
  background: #8593ab;
  color: #fff;
  font-size: 10px; font-weight: 600;
  border-radius: 0 0 12px 12px;
}
.vip-no-plans {
  text-align: center; font-size: 13px; color: $text3; padding: 20px 0;
}

// ── Compare Table ──
.vip-compare-scroll {
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  margin: 0 -18px;
  padding: 0 18px;
  &::-webkit-scrollbar { display: none; }
}
.vip-compare-table {
  width: 100%; min-width: max-content;
  border-collapse: separate; border-spacing: 0;
}

// sticky left label column
.vip-cth-label {
  position: sticky; left: 0; z-index: 3;
  background: $card;
  width: 84px; min-width: 84px;
  border-radius: 12px 0 0 0;
}

// header cells
.vip-cth {
  padding: 14px 10px 12px; text-align: center;
  min-width: 74px; vertical-align: top;
  background: #f3f5f9;
  &:first-of-type { border-radius: 12px 0 0 0; }
  &:last-of-type { border-radius: 0 12px 0 0; }
  &.highlight {
    background: linear-gradient(180deg, #fef3d5, #fef9ee);
    position: relative;
  }
}
.vip-cth-badge {
  display: flex; justify-content: center; margin-bottom: 2px;
  svg { color: #f59e0b; width: 14px; height: 14px; }
}
.vip-cth-name {
  font-size: 13px; font-weight: 700; color: $text;
}

// body label cells
.vip-ctd-label {
  position: sticky; left: 0; z-index: 2;
  background: #fff; padding: 13px 12px;
  font-size: 12px; font-weight: 500; color: $text2;
  white-space: nowrap; text-align: left;
  border-bottom: 1px solid $border;
  &.clickable {
    cursor: pointer; color: $blue;
    display: flex; align-items: center; gap: 2px;
    &:active { background: $blue-bg; }
    .vip-ctd-arrow {
      flex-shrink: 0; color: $text3; transition: transform 0.2s;
      &.open { transform: rotate(180deg); }
    }
  }
}
tr:last-child .vip-ctd-label {
  border-radius: 0 0 0 12px;
}

// body value cells
.vip-ctd {
  padding: 13px 8px; text-align: center;
  background: #fff; vertical-align: middle;
  border-bottom: 1px solid $border;
  &.highlight {
    background: $gold-light;
  }
}
tr:last-child .vip-ctd:last-child {
  border-radius: 0 0 12px 0;
}

.vip-ctd-ico {
  &.chk { color: $blue; }
  &.cross { color: #e0e3eb; }
}
.vip-ctd-txt {
  font-size: 12px; font-weight: 600; color: $text;
  &.gift-detail {
    font-size: 10px; font-weight: 500; color: $blue;
    line-height: 1.4; white-space: normal; word-break: break-all;
  }
}

// ── Agree ──
.vip-agree {
  display: flex; align-items: center; gap: 8px;
  font-size: 12px; color: $text3; cursor: pointer;
  padding: 2px 0;
}
.vip-agree-box {
  width: 18px; height: 18px; border-radius: 50%;
  border: 2px solid #d0d5e0;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; transition: all 0.2s;
  &.on { border-color: $blue; background: $blue; color: #fff; }
}
.vip-agree-link { color: $blue; font-weight: 500; }

// ── Bottom ──
.vip-bottom-safe { height: 90px; }

.vip-bottom {
  position: fixed; bottom: 0; left: 0; right: 0;
  padding: 14px 16px;
  padding-bottom: max(14px, env(safe-area-inset-bottom));
  background: rgba(255,255,255,0.94);
  backdrop-filter: saturate(180%) blur(20px);
  -webkit-backdrop-filter: saturate(180%) blur(20px);
  border-top: 1px solid rgba(0,0,0,0.04);
  z-index: 40;
}
.vip-bottom-btn {
  width: 100%; padding: 15px;
  border: none; border-radius: 16px;
  background: linear-gradient(135deg, $blue, $blue-light);
  color: #fff;
  font-size: 16px; font-weight: 700;
  cursor: pointer;
  box-shadow: 0 6px 24px rgba($blue, 0.4);
  display: flex; align-items: center; justify-content: center; gap: 8px;
  transition: all 0.2s cubic-bezier(0.4,0,0.2,1);
  letter-spacing: 0.5px;
  &:active:not(.disabled) { transform: scale(0.98); box-shadow: 0 3px 12px rgba($blue, 0.3); }
  &.disabled { background: #d4d8e4; box-shadow: none; cursor: not-allowed; }
}
.vip-btn-spinner {
  width: 18px; height: 18px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

// ── Overlay ──
.vip-overlay {
  position: fixed; inset: 0; z-index: 100;
  background: rgba(0,0,0,0.45);
  display: flex; align-items: flex-end; justify-content: center;
  &.center { align-items: center; }
}

// ── Payment Sheet ──
.vip-sheet {
  width: 100%; max-width: 480px;
  background: $card;
  border-radius: 22px 22px 0 0;
  padding: 0 20px 28px;
  max-height: 72vh; overflow-y: auto;
  animation: slideUp 0.3s cubic-bezier(0.4,0,0.2,1);
}
@keyframes slideUp { from { transform: translateY(100%); opacity: 0.5; } to { transform: translateY(0); opacity: 1; } }
.vip-sheet-bar {
  width: 40px; height: 5px; background: #e0e4ef;
  border-radius: 3px; margin: 14px auto 10px;
}
.vip-sheet-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 18px;
}
.vip-sheet-title { font-size: 17px; font-weight: 700; color: $text; }
.vip-sheet-close { cursor: pointer; color: $text3; }
.vip-sheet-body { display: flex; flex-direction: column; gap: 16px; }
.vip-sheet-prod {
  display: flex; align-items: center; gap: 14px;
  padding: 16px; background: $blue-bg; border-radius: 16px;
}
.vip-sheet-prod-icon {
  width: 48px; height: 48px; border-radius: 14px;
  background: linear-gradient(135deg, $blue, $blue-light);
  display: flex; align-items: center; justify-content: center;
  color: #fff; flex-shrink: 0;
  box-shadow: 0 3px 10px rgba($blue, 0.25);
}
.vip-sheet-prod-info { flex: 1; min-width: 0; }
.vip-sheet-prod-name { font-size: 14px; font-weight: 600; color: $text; }
.vip-sheet-prod-sub { font-size: 11px; color: $text3; margin-top: 2px; }
.vip-sheet-prod-price { font-size: 20px; font-weight: 800; color: $blue; flex-shrink: 0; }
.vip-sheet-row { display: flex; flex-direction: column; gap: 8px; }
.vip-sr-label { font-size: 13px; font-weight: 600; color: $text2; }
.vip-sr-pays { display: flex; gap: 10px; }
.vip-sr-pay {
  flex: 1; text-align: center;
  padding: 12px; border-radius: 12px;
  border: 2px solid $border;
  font-size: 14px; font-weight: 600; color: $text2;
  cursor: pointer; transition: all 0.2s;
  &.active {
    border-color: $blue; color: $blue;
    background: $blue-bg;
    box-shadow: 0 0 0 3px rgba($blue, 0.06);
  }
}
.vip-sheet-total {
  background: #f8f9fc; border-radius: 14px; padding: 16px;
}
.vip-st-row {
  display: flex; justify-content: space-between; align-items: center;
  font-size: 14px; color: $text; padding: 5px 0;
  &.sub { font-size: 12px; color: $text3; }
}
.vip-st-red { font-size: 22px; font-weight: 800; color: $blue; }
.vip-cp-trigger {
  display: flex; align-items: center; justify-content: space-between;
  flex: 1; padding: 10px 14px; border-radius: 10px;
  background: #f8f9fc; border: 1.5px solid transparent;
  font-size: 13px; cursor: pointer; margin-top: 8px;
}
.vip-cp-selected { color: $blue; font-weight: 600; }
.vip-cp-placeholder { color: $text3; }
.vip-cp-arrow { flex-shrink: 0; color: $text3; transition: transform 0.2s; &.open { transform: rotate(180deg); } }
.vip-cp-dropdown {
  background: #f8f9fc; border-radius: 12px; padding: 6px;
  margin-top: 6px; max-height: 220px; overflow-y: auto;
}
.vip-cp-opt {
  display: flex; justify-content: space-between; align-items: center;
  padding: 10px 14px; border-radius: 8px;
  font-size: 13px; color: $text; cursor: pointer;
  &.active { background: rgba($blue, 0.08); color: $blue; font-weight: 600; }
}
.vip-cp-val { font-size: 12px; color: $blue; font-weight: 600; }
.vip-cp-saved { font-size: 12px; color: #10b981; font-weight: 600; }
.vip-sheet-pay-btn {
  width: 100%; margin-top: 18px; padding: 15px;
  border-radius: 16px; border: none;
  background: linear-gradient(135deg, $blue, $blue-light);
  color: #fff; font-size: 16px; font-weight: 700;
  cursor: pointer;
  box-shadow: 0 6px 24px rgba($blue, 0.4);
  letter-spacing: 0.5px;
  transition: all 0.2s cubic-bezier(0.4,0,0.2,1);
  &:active:not(:disabled) { transform: scale(0.98); }
  &:disabled { background: #d4d8e4; box-shadow: none; cursor: not-allowed; }
}

// ── Toast ──
.vip-toast {
  background: $card; border-radius: 22px;
  padding: 32px 28px; width: 290px;
  text-align: center;
  box-shadow: 0 20px 60px rgba(0,0,0,0.15);
}
.vip-toast-icon {
  width: 60px; height: 60px; border-radius: 50%;
  margin: 0 auto 14px;
  display: flex; align-items: center; justify-content: center;
  &.ok { background: #d1fae5; color: #10b981; }
  &.fail { background: #fee2e2; color: #ef4444; }
}
.vip-toast-title { font-size: 17px; font-weight: 700; color: $text; margin-bottom: 6px; }
.vip-toast-msg { font-size: 13px; color: $text2; line-height: 1.6; }
.vip-toast-btn {
  margin-top: 20px; padding: 11px 40px;
  border-radius: 14px; border: none;
  background: $blue;
  color: #fff; font-size: 14px; font-weight: 600;
  cursor: pointer;
  box-shadow: 0 3px 14px rgba($blue, 0.3);
  transition: all 0.2s;
  &:active { transform: scale(0.97); }
}
</style>
