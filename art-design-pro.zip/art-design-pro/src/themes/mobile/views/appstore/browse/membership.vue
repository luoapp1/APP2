<template>
  <div class="membership-page">
    <!-- 顶部导航栏 -->
    <header class="nav-bar">
      <div class="nav-inner">
        <div class="nav-back" @click="$router.back()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 19l-7-7 7-7" />
          </svg>
        </div>
        <h1 class="nav-title">会员中心</h1>
        <div class="nav-placeholder" />
      </div>
    </header>

    <div class="page-content">
      <!-- 会员身份卡 -->
      <div class="vip-card">
        <div class="vip-card-bg" />
        <div class="vip-card-inner">
          <div class="vip-card-top">
            <div>
              <div class="vip-badge">
                <span class="vip-dot" />
                <span class="vip-level-text">VIP {{ currentLevelName }}</span>
              </div>
              <div class="vip-expire">
                <template v-if="isLogin && userStore.info.expireTime">{{ expireTimeDisplay }}</template>
                <template v-else>开通会员解锁全部特权</template>
              </div>
            </div>
            <div class="vip-status-tag" :class="{ active: currentLevelId }">
              {{ currentLevelId ? '已开通' : '未开通' }}
            </div>
          </div>
          <div class="vip-stats">
            <div class="vip-stat-item">
              <div class="vip-stat-label">折扣率</div>
              <div class="vip-stat-value accent-gold">{{ discountPct }}%</div>
            </div>
            <div class="vip-stat-item">
              <div class="vip-stat-label">积分加成</div>
              <div class="vip-stat-value accent-amber">{{ pointsMultiplier }}x</div>
            </div>
            <div class="vip-stat-item">
              <div class="vip-stat-label">余额</div>
              <div class="vip-stat-value accent-blue">¥{{ balanceStr }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 会员等级选择 -->
      <section class="section-card">
        <div class="section-header">
          <div class="section-icon icon-amber">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
          </div>
          <span class="section-title">选择会员等级</span>
          <span class="section-tip link" @click="showBenefitsModal = true">权益对比</span>
        </div>

        <!-- 等级卡片列表 -->
        <div class="level-list">
          <div
            v-for="lvl in availableLevels"
            :key="lvl.id"
            class="level-card"
            :class="{
              selected: selectedLevel === lvl.id,
              current: lvl.id === currentLevelId
            }"
            @click="selectLevel(lvl)"
          >
            <div class="level-card-header">
              <div class="level-card-name">{{ lvl.name }}</div>
              <span v-if="lvl.id === currentLevelId" class="level-tag current-tag">当前</span>
              <span v-else-if="isLevelHigher(lvl)" class="level-tag recommend-tag">推荐</span>
            </div>
            <div class="level-card-desc">{{ levelShortDesc(lvl) }}</div>
            <div class="level-card-price">
              <span class="price-symbol">¥</span>
              <span class="price-value">{{ levelMinPrice(lvl) || '--' }}</span>
              <span class="price-unit">起</span>
            </div>
            <div
              v-if="selectedLevel === lvl.id"
              class="level-card-bar"
              :class="{ 'bar-reverse': lvl.id === currentLevelId }"
            />
          </div>
        </div>

        <!-- 时长选择 -->
        <div v-if="levelPlans.length > 0" class="plan-section">
          <div class="plan-section-title">选择时长</div>
          <div class="plan-grid">
            <div
              v-for="p in levelPlans"
              :key="p.id"
              class="plan-item"
              :class="{ active: selectedPlan === p.id }"
              @click="selectedPlan = p.id"
            >
              <div class="plan-duration">{{ durationLabel(p.duration_days) }}</div>
              <div class="plan-price-row">
                <span class="plan-symbol">¥</span>
                <span class="plan-amount">{{ planPrice(p) }}</span>
              </div>
              <div v-if="planOriginalPrice(p) > Number(planPrice(p))" class="plan-original">¥{{ planOriginalPrice(p) }}</div>
            </div>
          </div>
        </div>
      </section>

      <!-- 选择优惠券 -->
      <section v-if="isLogin" class="section-card">
        <div class="section-header">
          <div class="section-icon icon-purple">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" /><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" /></svg>
          </div>
          <span class="section-title">选择优惠券</span>
          <span v-if="usableCoupons.length" class="section-tip">{{ usableCoupons.length }}张可用</span>
          <span v-else class="section-tip none">暂无可用</span>
        </div>
        <ElSelect
          v-model="selectedCouponId"
          placeholder="不使用优惠券"
          clearable
          style="width:100%"
          popper-class="coupon-select-popper"
          @change="onCouponSelect"
        >
          <ElOption :value="0" label="不使用优惠券" />
          <ElOption
            v-for="c in usableCoupons"
            :key="c.userCouponId"
            :value="c.userCouponId"
            :label="`${couponLabel(c)}`"
          >
            <div class="coupon-dd-item">
              <span class="coupon-dd-left">{{ couponLabel(c) }}</span>
              <span class="coupon-dd-right">{{ c.expireTime ? '到期 '+fmtDate(c.expireTime) : '' }}</span>
            </div>
          </ElOption>
        </ElSelect>
      </section>

      <!-- 支付方式 -->
      <section class="section-card">
        <div class="section-header">
          <div class="section-icon icon-green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" /><line x1="7" y1="15" x2="7.01" y2="15" /><line x1="11" y1="15" x2="13" y2="15" /></svg>
          </div>
          <span class="section-title">支付方式</span>
        </div>
        <div class="pay-grid">
          <div
            v-for="m in payMethods"
            :key="m.key"
            class="pay-method"
            :class="{ active: activePayMethod === m.key }"
            @click="m.key !== 'cardkey' ? activePayMethod = m.key : handleCardKeyClick()"
          >
            <div class="pay-icon" :style="{ background: activePayMethod === m.key ? m.bg : '#e5e7eb' }">
              <svg viewBox="0 0 24 24" fill="currentColor" :style="{ color: activePayMethod === m.key ? '#fff' : '#9ca3af' }"><path :d="m.icon" /></svg>
            </div>
            <div class="pay-label">{{ m.label }}</div>
            <div v-if="m.key === 'balance' && isLogin" class="pay-sub">¥{{ balanceStr }}</div>
            <div v-if="m.key === 'points' && isLogin" class="pay-sub">{{ userPointsStr }}</div>
          </div>
        </div>
      </section>

      <!-- 协议勾选 -->
      <div class="agreement" @click="agreed = !agreed">
        <div class="agree-check" :class="{ checked: agreed }">
          <svg v-if="agreed" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
        </div>
        <span class="agree-text">已阅读并同意<span class="agree-link">《会员服务协议》</span></span>
      </div>
    </div>

    <!-- 底部支付栏 -->
    <footer class="pay-bar">
      <div class="pay-bar-inner">
        <div class="pay-bar-left">
          <div class="pay-bar-price">
            <span v-if="couponDiscount > 0" class="pay-bar-original">¥{{ totalPrice }}</span>
            <span class="pay-bar-unit">{{ activePayMethod === 'points' ? '' : '¥' }}</span>
            <span class="pay-bar-total">{{ finalPrice }}</span>
            <span v-if="activePayMethod === 'points'" class="pay-bar-points">积分</span>
          </div>
          <div v-if="selectedPlanInfo" class="pay-bar-expire">到期：{{ expirePreview }}</div>
          <div v-if="selectedCouponName" class="pay-bar-coupon">
            <span class="coupon-tag-s">券</span>已优惠 {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }}
          </div>
        </div>
        <button
          class="pay-button"
          :class="{ disabled: !selectedPlan || !agreed }"
          :disabled="!selectedPlan || !agreed || buyLoading > 0"
          @click="showConfirm"
        >
          {{ buyLoading > 0 ? '支付中...' : '立即支付开通' }}
        </button>
      </div>
    </footer>

    <!-- 支付确认弹窗 -->
    <teleport to="body">
      <div v-if="showConfirmModal" class="modal-overlay" @click.self="showConfirmModal = false">
        <div class="confirm-modal">
          <div class="confirm-title">确认支付</div>
          <div class="confirm-detail">
            <div class="confirm-row"><span>套餐</span><span class="strong">{{ selectedPlanInfo?.name || selectedPlanInfo?.levelName || '' }}</span></div>
            <div class="confirm-row"><span>等级</span><span class="strong">{{ selectedLevelName }}</span></div>
            <div class="confirm-row"><span>支付方式</span><span class="strong">{{ activePayMethod === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <template v-if="selectedCouponName">
              <div class="confirm-row"><span>优惠券</span><span class="accent">{{ selectedCouponName }} ({{ isPointsCoupon ? '' : '¥' }}{{ totalPrice }} - {{ isPointsCoupon ? '' : '¥' }}{{ couponDiscount }}{{ isPointsCoupon ? '积分' : '' }})</span></div>
            </template>
            <div class="confirm-row"><span>支付金额</span><span class="accent">{{ activePayMethod === 'points' ? finalPrice + '积分' : '¥' + finalPrice }}</span></div>
            <div class="confirm-row"><span>有效期至</span><span class="strong">{{ expirePreview }}</span></div>
          </div>
          <div class="confirm-actions">
            <button class="confirm-btn cancel" @click="showConfirmModal = false">取消</button>
            <button class="confirm-btn primary" :disabled="buyLoading > 0" @click="handleConfirmPay">
              {{ buyLoading > 0 ? '支付中...' : '确认支付' }}
            </button>
          </div>
        </div>
      </div>
    </teleport>

    <!-- 支付结果弹窗 -->
    <teleport to="body">
      <div v-if="showResultModal" class="modal-overlay" @click.self="showResultModal = false">
        <div class="result-modal">
          <div v-if="resultSuccess" class="result-icon success">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
          </div>
          <div v-else class="result-icon fail">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M6 18L18 6M6 6l12 12" /></svg>
          </div>
          <div class="result-title">{{ resultSuccess ? '开通成功' : '开通失败' }}</div>
          <div class="result-msg">{{ resultMsg }}</div>
          <div v-if="resultSuccess && selectedPlanInfo" class="result-detail">
            <div class="result-row"><span>套餐</span><span class="strong">{{ selectedPlanInfo.name || selectedPlanInfo.levelName }}</span></div>
            <div class="result-row"><span>支付方式</span><span class="strong">{{ activePayMethod === 'points' ? '积分支付' : '余额支付' }}</span></div>
            <div class="result-row"><span>金额</span><span class="accent">{{ activePayMethod === 'points' ? totalPrice + '积分' : '¥' + totalPrice }}</span></div>
            <div class="result-row"><span>有效期至</span><span class="strong">{{ expirePreview }}</span></div>
          </div>
          <button class="result-btn" :class="{ primary: resultSuccess }" @click="showResultModal = false">
            {{ resultSuccess ? '我知道了' : '关闭' }}
          </button>
        </div>
      </div>

      <!-- 卡密兑换弹窗 -->
      <div v-if="showCardKeyDialog" class="modal-overlay" @click.self="showCardKeyDialog = false">
        <div class="cardkey-modal">
          <template v-if="cardKeyResult === 'success'">
            <div class="result-icon success small">
              <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
            </div>
            <div class="result-title">兑换成功</div>
            <div class="result-msg">{{ cardKeyMsg }}</div>
            <button class="result-btn primary" @click="showCardKeyDialog = false">我知道了</button>
          </template>
          <template v-else>
            <div class="cardkey-title">卡密兑换</div>
            <input v-model="cardKeyForm.cardNo" class="cardkey-input" placeholder="请输入卡号" />
            <input v-model="cardKeyForm.password" type="text" class="cardkey-input" placeholder="请输入卡密密码" />
            <div v-if="cardKeyMsg && cardKeyResult !== 'success'" class="cardkey-error">{{ cardKeyMsg }}</div>
            <div class="cardkey-actions">
              <button class="cardkey-btn cancel" @click="showCardKeyDialog = false">取消</button>
              <button class="cardkey-btn confirm" :disabled="cardKeyLoading" @click="handleRedeemCardKey">
                {{ cardKeyLoading ? '兑换中...' : '确认兑换' }}
              </button>
            </div>
          </template>
        </div>
      </div>
    </teleport>

    <!-- 会员权益对比弹窗 -->
    <teleport to="body">
      <div v-if="showBenefitsModal" class="modal-overlay" @click.self="showBenefitsModal = false">
        <div class="benefits-modal">
          <div class="benefits-modal-title">会员权益对比</div>
          <div class="benefits-modal-list">
            <div
              v-for="lvl in availableLevels"
              :key="lvl.id"
              class="benefits-level-card"
              :class="{ current: lvl.id === currentLevelId }"
            >
              <div class="benefits-level-header">
                <span class="benefits-level-name">
                  {{ lvl.name }}
                  <span v-if="lvl.id === currentLevelId" class="level-tag current-tag">当前</span>
                  <span v-else-if="isLevelHigher(lvl)" class="level-tag recommend-tag">推荐</span>
                </span>
                <span class="benefits-level-price">
                  <span class="price-symbol">¥</span>
                  <span class="price-value">{{ levelMinPrice(lvl) || '免费' }}</span>
                  <span v-if="levelMinPrice(lvl)" class="price-unit">起</span>
                </span>
              </div>
              <div class="benefits-level-desc">{{ levelShortDesc(lvl) }}</div>
              <div class="benefits-items">
                <div v-for="(b, idx) in getLevelBenefits(lvl)" :key="idx" class="benefit-row">
                  <div class="benefit-dot" :style="{ background: benefitIcons[idx % benefitIcons.length].dotColor }" />
                  <span class="benefit-text">{{ b }}</span>
                </div>
              </div>
            </div>
          </div>
          <button class="benefits-close-btn" @click="showBenefitsModal = false">关闭</button>
        </div>
      </div>
    </teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useUserStore } from '@/store/modules/user'
import { fetchMembershipProducts, fetchBuyMembership, fetchRedeemCardKey } from '@/api/appstore'
import { fetchGetMembershipLevelList } from '@/api/operation'
import { fetchUsableCoupons } from '@/api/coupon'

const userStore = useUserStore()

const products = ref<any[]>([])
const allLevels = ref<any[]>([])
const buyLoading = ref(0)
const selectedPlan = ref(0)
const selectedLevel = ref(0)
const activePayMethod = ref('balance')
const agreed = ref(false)
const showCardKeyDialog = ref(false)
const showConfirmModal = ref(false)
const showBenefitsModal = ref(false)
const cardKeyForm = ref({ cardNo: '', password: '' })
const cardKeyMsg = ref('')
const cardKeyLoading = ref(false)
const cardKeyResult = ref<'input' | 'success' | 'fail'>('input')
const showResultModal = ref(false)
const resultSuccess = ref(false)
const resultMsg = ref('')
const pointsMultiplier = ref('1.0')

const usableCoupons = ref<any[]>([])
const selectedCouponId = ref(0)
const selectedCouponInfo = ref<any>(null)

const isLogin = computed(() => userStore.isLogin)
const currentLevelId = computed(() => userStore.info.levelId || 0)
const currentLevelName = computed(() => userStore.info.levelName || '普通会员')

const expireTimeDisplay = computed(() => {
  const t = userStore.info.expireTime
  if (!t) return ''
  try {
    const d = new Date(t)
    if (isNaN(d.getTime())) return ''
    return `到期：${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  } catch {
    return ''
  }
})

const discountPct = computed(() => {
  const r = Number(userStore.info.discountRate || 1) * 100
  return r % 1 === 0 ? r : r.toFixed(0)
})

const userPointsStr = computed(() => {
  const p = Number(userStore.info.points || 0)
  return p >= 10000 ? (p / 10000).toFixed(1) + 'w' : String(p)
})

const balanceStr = computed(() => {
  const b = Number(userStore.info.balance || 0)
  return b >= 10000 ? (b / 10000).toFixed(2) + '万' : b.toFixed(2)
})

const availableLevels = computed(() => {
  const currentLevelVal = currentLevelId.value
    ? (allLevels.value.find((l: any) => l.id === currentLevelId.value)?.level ?? 0)
    : 0
  return allLevels.value
    .filter((l: any) => l.status === '1')
    .filter((l: any) => {
      if (!currentLevelId.value) return true
      return (l.level || 0) > currentLevelVal || l.id === currentLevelId.value
    })
    .sort((a: any, b: any) => (a.level || 0) - (b.level || 0))
})

const levelMinPrice = (lvl: any) => {
  const plans = products.value.filter((p: any) => p.level_id === lvl.id && Number(p.price) > 0)
  if (plans.length === 0) return lvl.price || 0
  return Math.min(...plans.map((p: any) => Number(p.price) || Infinity))
}

const selectedLevelName = computed(() => {
  const lvl = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  return lvl?.name || ''
})

const selectedLevelBenefits = computed(() => {
  const lvl = allLevels.value.find((l: any) => l.id === selectedLevel.value)
  if (!lvl?.benefits) return []
  return lvl.benefits.split(/[,，、]/).filter((b: string) => b.trim()).map((b: string) => b.trim())
})

function getLevelBenefits(lvl: any) {
  if (!lvl?.benefits) return ['基础权益']
  return lvl.benefits.split(/[,，、]/).filter((b: string) => b.trim()).map((b: string) => b.trim())
}

const levelPlans = computed(() => {
  if (!selectedLevel.value) return []
  return products.value.filter((p: any) => p.level_id === selectedLevel.value)
})

const selectedPlanInfo = computed(() => {
  if (!selectedPlan.value) return null
  return products.value.find((p: any) => p.id === selectedPlan.value) || null
})

const totalPrice = computed(() => {
  if (!selectedPlanInfo.value) return '0'
  if (activePayMethod.value === 'points') return String(selectedPlanInfo.value.points_price || selectedPlanInfo.value.price || 0)
  return String(price(selectedPlanInfo.value))
})

const couponDiscount = computed(() => {
  if (!selectedCouponInfo.value) return 0
  const c = selectedCouponInfo.value
  const base = Number(totalPrice.value)
  if (c.type === 'fixed' || c.type === 'fixed_points') return Math.min(c.value, base)
  if (c.type === 'percent' || c.type === 'points_percent') {
    let disc = Math.floor(base * c.value / 100 * 100) / 100
    if (c.maxDiscount > 0 && disc > c.maxDiscount) disc = c.maxDiscount
    return Math.min(disc, base)
  }
  return 0
})

const finalPrice = computed(() => {
  const tp = Number(totalPrice.value)
  const d = couponDiscount.value
  return String(Math.max(0, tp - d))
})

const selectedCouponName = computed(() => {
  return selectedCouponInfo.value?.name || ''
})

const isPointsCoupon = computed(() => {
  const t = selectedCouponInfo.value?.type
  return t === 'fixed_points' || t === 'points_percent'
})

const expirePreview = computed(() => {
  if (!selectedPlanInfo.value) return '--'
  const days = selectedPlanInfo.value.duration_days
  if (days === 0) return '永久有效'
  const d = new Date(Date.now() + days * 86400000)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
})

const benefitIcons = [
  { bg: 'linear-gradient(135deg, #f59e0b, #ea580c)', dotColor: '#f59e0b', icon: 'M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z' },
  { bg: 'linear-gradient(135deg, #6366f1, #8b5cf6)', dotColor: '#6366f1', icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6' },
  { bg: 'linear-gradient(135deg, #22c55e, #16a34a)', dotColor: '#22c55e', icon: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z' },
  { bg: 'linear-gradient(135deg, #ec4899, #db2777)', dotColor: '#ec4899', icon: 'M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z' },
  { bg: 'linear-gradient(135deg, #06b6d4, #0891b2)', dotColor: '#06b6d4', icon: 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z' },
  { bg: 'linear-gradient(135deg, #84cc16, #65a30d)', dotColor: '#84cc16', icon: 'M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm0 8a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zm12 0a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z' },
  { bg: 'linear-gradient(135deg, #f97316, #ea580c)', dotColor: '#f97316', icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12' },
  { bg: 'linear-gradient(135deg, #8b5cf6, #7c3aed)', dotColor: '#8b5cf6', icon: 'M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
]

const payMethods = [
  { key: 'balance', label: '余额支付', bg: '#f59e0b', icon: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z' },
  { key: 'points', label: '积分支付', bg: '#6366f1', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
  { key: 'cardkey', label: '卡密兑换', bg: '#8b5cf6', icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
]

function price(p: any) {
  if (p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date())) return Number(p.price) || 0
  return Number(p.original_price) || Number(p.price) || 0
}

function planPrice(p: any) {
  return price(p).toFixed(0)
}

function planOriginalPrice(p: any) {
  if (!(p.is_promo && (!p.promo_end_time || new Date(p.promo_end_time) > new Date()))) return 0
  return Number(p.original_price) || 0
}

function durationLabel(days: number) {
  if (days === 0) return '永久'
  if (days >= 365 && days % 365 === 0) return `${days / 365}年`
  if (days >= 90 && days % 30 === 0) return `${days / 30}个月`
  if (days >= 30 && days % 30 === 0) return `${days / 30}个月`
  return `${days}天`
}

function levelShortDesc(lvl: any) {
  const parts: string[] = []
  if ((lvl.discountRate || 1) < 1) parts.push(`${((lvl.discountRate || 1) * 10).toFixed(0)}折`)
  if ((lvl.pointsMultiplier || 1) > 1) parts.push(`${lvl.pointsMultiplier}x积分`)
  return parts.join(' · ') || '基础权益'
}

function isLevelHigher(lvl: any) {
  if (!currentLevelId.value) return lvl.level === 1
  return (lvl.level || 0) > (allLevels.value.find((l: any) => l.id === currentLevelId.value)?.level || 0)
}

function selectLevel(lvl: any) {
  selectedLevel.value = lvl.id
  const plans = levelPlans.value
  if (plans.length > 0) {
    selectedPlan.value = plans[0].id
  }
  selectedCouponId.value = 0
  selectedCouponInfo.value = null
}

function toggleCoupon(c: any) {
  if (selectedCouponId.value === c.userCouponId) {
    selectedCouponId.value = 0
    selectedCouponInfo.value = null
  } else {
    selectedCouponId.value = c.userCouponId
    selectedCouponInfo.value = c
  }
}

function onCouponSelect(val: number) {
  if (!val) {
    selectedCouponId.value = 0
    selectedCouponInfo.value = null
  } else {
    const c = usableCoupons.value.find((c: any) => c.userCouponId === val)
    selectedCouponId.value = val
    selectedCouponInfo.value = c || null
  }
}

function couponLabel(c: any) {
  const isPoints = c.type === 'fixed_points' || c.type === 'points_percent'
  const isFixed = c.type === 'fixed' || c.type === 'fixed_points'
  const prefix = isFixed ? `${isPoints ? '' : '¥'}${c.value}${isPoints ? '积分' : ''}` : `${c.value}折`
  const suffix = c.isMultiUse && c.remainingValue !== null ? `(剩${isPoints ? '' : '¥'}${c.remainingValue}${isPoints ? '积分' : ''})` : ''
  return `${prefix} ${c.name}${suffix}`
}

function couponDesc(c: any) {
  const isPoints = c.type === 'fixed_points' || c.type === 'points_percent'
  const isFixed = c.type === 'fixed' || c.type === 'fixed_points'
  const parts: string[] = []
  const unit = isPoints ? '积分' : '¥'
  if (c.minOrder > 0) parts.push(`满${unit}${c.minOrder}`)
  else parts.push('无门槛')
  if (isFixed) parts.push(`减${unit}${c.value}`)
  else parts.push(`${c.value}折`)
  if (c.maxDiscount > 0) parts.push(`最高减${unit}${c.maxDiscount}`)
  return parts.join(' · ')
}

function fmtDate(d: string) {
  if (!d) return ''
  try { return new Date(d).toLocaleDateString('zh-CN') } catch { return d }
}

async function loadCoupons() {
  if (!isLogin.value || !selectedPlanInfo.value || activePayMethod.value === 'cardkey') {
    usableCoupons.value = []
    return
  }
  try {
    const res: any = await fetchUsableCoupons({
      scene: 'membership',
      targetId: selectedLevel.value || 0,
      orderAmount: Number(totalPrice.value),
      payType: activePayMethod.value
    })
    usableCoupons.value = Array.isArray(res) ? res : []
    if (!usableCoupons.value.find((c: any) => c.userCouponId === selectedCouponId.value)) {
      selectedCouponId.value = 0
      selectedCouponInfo.value = null
    }
  } catch {
    usableCoupons.value = []
  }
}

watch([selectedPlan, activePayMethod], () => {
  selectedCouponId.value = 0
  selectedCouponInfo.value = null
  loadCoupons()
})

function handleCardKeyClick() {
  showCardKeyDialog.value = true
  cardKeyResult.value = 'input'
  cardKeyForm.value = { cardNo: '', password: '' }
  cardKeyMsg.value = ''
}

async function loadProducts() {
  try {
    const [prodRes, levelRes] = await Promise.all([
      fetchMembershipProducts() as any,
      fetchGetMembershipLevelList({} as any) as any,
    ])
    const raw = (prodRes?.data || prodRes) || []
    const levelsData = (levelRes?.data?.records || levelRes?.records || levelRes?.data || levelRes) || []
    const levels = Array.isArray(levelsData) ? levelsData : []
    allLevels.value = levels

    const enriched = (Array.isArray(raw) ? raw : []).map((p: any) => {
      const level = levels.find((l: any) => l.id === p.level_id)
      return { ...p, levelName: level?.name || '' }
    })

    if (isLogin.value && userStore.info.levelId) {
      const currentLevel = levels.find((l: any) => l.id === userStore.info.levelId)
      if (currentLevel) {
        pointsMultiplier.value = String(currentLevel.points_multiplier || currentLevel.pointsMultiplier || 1.0)
      }
    }

    products.value = enriched

    const avail = availableLevels.value
    if (avail.length > 0) selectLevel(avail[0])
    loadCoupons()
  } catch {
    /* ignore */
  }
}

async function showConfirm() {
  if (!selectedPlan.value || !agreed.value) return
  if (!isLogin.value) {
    resultSuccess.value = false
    resultMsg.value = '请先登录'
    showResultModal.value = true
    return
  }
  showConfirmModal.value = true
}

async function handleConfirmPay() {
  showConfirmModal.value = false
  await handleBuy()
}

async function handleBuy() {
  buyLoading.value = selectedPlan.value
  try {
    const res: any = await fetchBuyMembership(
      selectedPlan.value,
      activePayMethod.value,
      selectedCouponId.value || undefined
    )
    const info = selectedPlanInfo.value
    if (info) {
      userStore.info.levelId = info.level_id
      userStore.info.levelName = info.levelName || ''
      userStore.info.expireTime = res?.expireTime || ''
    }
    resultSuccess.value = true
    resultMsg.value = '恭喜您成功开通会员，立即享受专属权益'
    showResultModal.value = true
  } catch (e: any) {
    resultSuccess.value = false
    resultMsg.value = e?.message || e?.msg || e?.data?.msg || '支付失败，请重试'
    showResultModal.value = true
  } finally {
    buyLoading.value = 0
  }
}

async function handleRedeemCardKey() {
  if (!cardKeyForm.value.cardNo || !cardKeyForm.value.password) {
    cardKeyMsg.value = '请输入卡号和密码'
    return
  }
  cardKeyLoading.value = true
  cardKeyMsg.value = ''
  try {
    const data: any = await fetchRedeemCardKey({
      cardNo: cardKeyForm.value.cardNo,
      password: cardKeyForm.value.password,
      userId: userStore.info.userId || 0,
      userName: userStore.info.userName || '',
    })
    if (data.code === 200) {
      cardKeyResult.value = 'success'
      cardKeyMsg.value = data.msg || '兑换成功'
    } else {
      cardKeyMsg.value = data.msg || '兑换失败'
    }
  } catch (e: any) {
    cardKeyMsg.value = e?.message || '兑换失败'
  } finally {
    cardKeyLoading.value = false
  }
}

onMounted(() => {
  loadProducts()
})
</script>

<style lang="scss" scoped>
.membership-page {
  min-height: 100vh;
  background: #f0f2f5;
}

// 导航栏
.nav-bar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: var(--default-bg-color);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(0, 0, 0, 0.06);
}

.nav-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 480px;
  margin: 0 auto;
  padding: 12px 16px;
}

.nav-back {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #333;

  svg {
    width: 20px;
    height: 20px;
  }
}

.nav-title {
  font-size: 17px;
  font-weight: 600;
  color: #1a1a1a;
  margin: 0;
}

.nav-placeholder {
  width: 28px;
}

// 页面内容
.page-content {
  max-width: 480px;
  margin: 0 auto;
  padding: 0 16px 120px;
}

// VIP 身份卡
.vip-card {
  margin-top: 16px;
  background: linear-gradient(135deg, #1e1b4b 0%, #312e81 25%, #4338ca 50%, #4f46e5 100%);
  border-radius: 20px;
  padding: 24px 20px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(79, 70, 229, 0.28);
}

.vip-card-bg {
  position: absolute;
  right: -40px;
  top: -50px;
  width: 180px;
  height: 180px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.06);

  &::after {
    content: '';
    position: absolute;
    right: -60px;
    bottom: -60px;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.04);
  }
}

.vip-card-inner {
  position: relative;
  z-index: 1;
}

.vip-card-top {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.vip-badge {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.vip-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #facc15;
  box-shadow: 0 0 8px rgba(250, 204, 21, 0.5);
}

.vip-level-text {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.7);
  font-weight: 500;
}

.vip-expire {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.45);
  line-height: 1.5;
}

.vip-status-tag {
  padding: 4px 12px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.5);

  &.active {
    background: rgba(250, 204, 21, 0.12);
    border-color: rgba(250, 204, 21, 0.2);
    color: #facc15;
  }
}

.vip-stats {
  display: flex;
  gap: 12px;
  margin-top: 16px;
}

.vip-stat-item {
  flex: 1;
  background: rgba(255, 255, 255, 0.06);
  border-radius: 12px;
  padding: 10px;
  text-align: center;
  border: 1px solid rgba(255, 255, 255, 0.04);
}

.vip-stat-label {
  font-size: 10px;
  color: rgba(255, 255, 255, 0.4);
}

.vip-stat-value {
  font-size: 18px;
  font-weight: 700;
  margin-top: 3px;

  &.accent-gold {
    color: #facc15;
  }

  &.accent-amber {
    color: #fbbf24;
  }

  &.accent-blue {
    color: #93c5fd;
  }
}

// 通用区块卡片
.section-card {
  background: #fff;
  border-radius: 16px;
  padding: 20px;
  margin-top: 12px;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.04);
}

.section-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.section-icon {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);

  svg {
    width: 16px;
    height: 16px;
    color: #fff;
  }
}

.icon-amber {
  background: linear-gradient(135deg, #f59e0b, #d97706);
  box-shadow: 0 3px 10px rgba(245, 158, 11, 0.25);
}

.icon-green {
  background: linear-gradient(135deg, #22c55e, #16a34a);
  box-shadow: 0 3px 10px rgba(34, 197, 94, 0.25);
}

.icon-purple {
  background: linear-gradient(135deg, #8b5cf6, #7c3aed);
  box-shadow: 0 3px 10px rgba(139, 92, 246, 0.25);
}

.section-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
}

// 等级卡片列表
.level-list {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
  padding: 4px 12px;

  &::-webkit-scrollbar {
    display: none;
  }
}

.level-card {
  flex-shrink: 0;
  width: 130px;
  background: #f9fafb;
  border: 1.5px solid #e5e7eb;
  border-radius: 14px;
  padding: 16px 12px 14px;
  cursor: pointer;
  position: relative;
  transition: all 0.25s ease;

  &.selected {
    background: linear-gradient(135deg, #fff7ed, #fffbeb);
    border-color: #f59e0b;
    box-shadow: 0 4px 20px rgba(245, 158, 11, 0.12);
  }

  &.current {
    background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
    border-color: #22c55e;

    &.selected {
      background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
      border-color: #22c55e;
      box-shadow: 0 4px 20px rgba(34, 197, 94, 0.12);
    }
  }
}

.level-card-header {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
}

.level-card-name {
  font-size: 14px;
  font-weight: 700;
  color: #1f2937;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.level-tag {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 6px;
  font-weight: 600;
  white-space: nowrap;

  &.current-tag {
    background: #dcfce7;
    color: #16a34a;
  }

  &.recommend-tag {
    background: #fef3c7;
    color: #d97706;
    animation: pulse 2s ease-in-out infinite;
  }
}

.level-card-desc {
  font-size: 11px;
  color: #9ca3af;
  margin-bottom: 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.level-card-price {
  display: flex;
  align-items: baseline;
  gap: 1px;

  .price-symbol {
    font-size: 11px;
    font-weight: 600;
  }

  .price-value {
    font-size: 22px;
    font-weight: 800;
    line-height: 1;
  }

  .price-unit {
    font-size: 10px;
    margin-left: 2px;
  }

  .selected & {
    .price-symbol,
    .price-value {
      color: #f59e0b;
    }

    .price-unit {
      color: #9ca3af;
    }
  }

  .current.selected & {
    .price-symbol,
    .price-value {
      color: #22c55e;
    }
  }

  .level-card:not(.selected) & {
    .price-symbol {
      color: #d1d5db;
    }

    .price-value {
      color: #d1d5db;
    }

    .price-unit {
      color: #9ca3af;
    }
  }
}

.level-card-bar {
  margin-top: 8px;
  height: 3px;
  background: linear-gradient(90deg, #f59e0b, #fbbf24, #f59e0b);
  border-radius: 2px;
  animation: shimmer 2s ease-in-out infinite;

  &.bar-reverse {
    background: linear-gradient(90deg, #22c55e, #4ade80, #22c55e);
  }
}

// 时长选择
.plan-section {
  margin-top: 18px;
}

.plan-section-title {
  font-size: 13px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 10px;
}

.plan-grid {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
  padding: 4px 12px;

  &::-webkit-scrollbar {
    display: none;
  }
}

.plan-item {
  flex-shrink: 0;
  width: 90px;
  background: #fff;
  border: 1.5px solid #e5e7eb;
  border-radius: 12px;
  padding: 12px 10px;
  cursor: pointer;
  text-align: center;
  transition: all 0.25s ease;

  &:hover {
    border-color: #fbbf24;
  }

  &.active {
    background: linear-gradient(135deg, #fffbeb, #fef3c7);
    border-color: #f59e0b;
    box-shadow: 0 2px 10px rgba(245, 158, 11, 0.1);
    transform: scale(1.03);
  }
}

.plan-duration {
  font-size: 13px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 4px;
}

.plan-price-row {
  display: flex;
  align-items: baseline;
  justify-content: center;
  gap: 2px;
}

.plan-symbol {
  font-size: 11px;
  font-weight: 600;
  color: #9ca3af;

  .active & {
    color: #f59e0b;
  }
}

.plan-amount {
  font-size: 20px;
  font-weight: 800;
  line-height: 1;
  color: #374151;

  .active & {
    color: #f59e0b;
  }
}

.plan-original {
  font-size: 10px;
  color: #b0b7c3;
  text-decoration: line-through;
  margin-top: 2px;
}

// 会员权益
.benefits-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.benefit-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 12px;
  background: #f9fafb;
  border-radius: 12px;
}

.benefit-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.12);
}

.benefit-text {
  font-size: 14px;
  color: #374151;
  font-weight: 500;
}

// 支付方式
.pay-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}

.pay-method {
  background: #f9fafb;
  border: 2px solid transparent;
  border-radius: 14px;
  padding: 14px 8px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s ease;

  &.active {
    background: #fffbeb;
    border-color: #f59e0b;
    box-shadow: 0 2px 8px rgba(245, 158, 11, 0.1);
  }
}

.pay-icon {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 8px;

  svg {
    width: 20px;
    height: 20px;
  }
}

.pay-label {
  font-size: 12px;
  font-weight: 600;
  color: #6b7280;

  .active & {
    color: #f59e0b;
  }
}

.pay-sub {
  font-size: 10px;
  color: #9ca3af;
  margin-top: 4px;
}

// 优惠券
.section-tip {
  font-size: 12px;
  color: #9ca3af;
  font-weight: 400;

  &.none { color: #d1d5db; }
}

// 优惠券下拉
.coupon-dd-item {
  display: flex; justify-content: space-between; align-items: center;
  width: 100%; gap: 8px;
}
.coupon-dd-left { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.coupon-dd-right { font-size: 11px; color: #9ca3af; flex-shrink: 0; }

.coupon-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.coupon-option {
  display: flex;
  align-items: center;
  padding: 12px;
  border-radius: 12px;
  border: 2px solid #e5e7eb;
  cursor: pointer;
  transition: all 0.2s;
  gap: 10px;

  &.active {
    border-color: #8b5cf6;
    background: #faf5ff;
  }
}

.coupon-left {
  flex-shrink: 0;
  text-align: center;
  min-width: 64px;
  padding-right: 10px;
  border-right: 1px dashed #d1d5db;
}

.coupon-value {
  font-size: 12px;
  font-weight: 700;
  color: #8b5cf6;

  .c-num {
    font-size: 20px;
  }
}

.coupon-name {
  font-size: 11px;
  color: #6b7280;
  margin-top: 2px;
}

.coupon-right {
  flex: 1;
  min-width: 0;
}

.coupon-desc {
  font-size: 12px;
  color: #374151;
  font-weight: 500;
}

.coupon-expire {
  font-size: 10px;
  color: #9ca3af;
  margin-top: 2px;
}

.coupon-check {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;

  svg { width: 24px; height: 24px; color: #8b5cf6; }

  .check-circle {
    width: 20px;
    height: 20px;
    border: 2px solid #d1d5db;
    border-radius: 50%;
  }
}

// 协议勾选
.agreement {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px;
  margin-top: 14px;
  cursor: pointer;
}

.agree-check {
  width: 18px;
  height: 18px;
  border-radius: 5px;
  border: 2px solid #d1d5db;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all 0.2s;

  svg {
    width: 11px;
    height: 11px;
  }

  &.checked {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    border-color: transparent;

    svg {
      color: #fff;
    }
  }
}

.agree-text {
  font-size: 12px;
  color: #6b7280;
}

.agree-link {
  color: #6366f1;
  font-weight: 500;
}

// 底部支付栏
.pay-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid rgba(0, 0, 0, 0.06);
  padding: 12px 16px;
  padding-bottom: calc(12px + env(safe-area-inset-bottom));
  z-index: 40;
  box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.06);
}

.pay-bar-inner {
  max-width: 480px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.pay-bar-label {
  font-size: 11px;
  color: #9ca3af;
}

.pay-bar-left {
  flex: 1;
  min-width: 0;
}

.pay-bar-price {
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.pay-bar-original {
  font-size: 13px;
  color: #9ca3af;
  text-decoration: line-through;
}

.pay-bar-amount {
  display: flex;
  align-items: baseline;
  gap: 2px;
}

.pay-bar-unit {
  font-size: 14px;
  font-weight: 700;
  color: #ef4444;
}

.pay-bar-total {
  font-size: 24px;
  font-weight: 800;
  color: #ef4444;
}

.pay-bar-points {
  font-size: 12px;
  color: #9ca3af;
  margin-left: 4px;
}

.pay-bar-expire {
  font-size: 10px;
  color: #9ca3af;
  margin-top: 2px;
}

.pay-bar-coupon {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  color: #92400e;
  margin-top: 2px;
}

.coupon-tag-s {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: 3px;
  background: #f59e0b;
  color: #fff;
  font-size: 10px;
  font-weight: 700;
}

.pay-button {
  padding: 14px 32px;
  border-radius: 26px;
  border: none;
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  background: linear-gradient(135deg, #f59e0b, #ea580c);
  color: #fff;
  box-shadow: 0 4px 16px rgba(245, 158, 11, 0.35);
  transition: all 0.2s;
  white-space: nowrap;

  &:hover {
    box-shadow: 0 6px 20px rgba(245, 158, 11, 0.45);
    transform: translateY(-1px);
  }

  &.disabled {
    background: #e5e7eb;
    color: #fff;
    box-shadow: none;
    opacity: 0.5;
    cursor: default;
    transform: none;
  }
}

// 弹窗通用
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 200;
}

// 确认弹窗
.confirm-modal {
  background: #fff;
  border-radius: 24px;
  width: 320px;
  padding: 32px 24px 24px;
  text-align: center;
}
.confirm-title {
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 20px;
}
.confirm-detail {
  background: #f5f6fa;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 20px;
}
.confirm-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  color: #6b7280;
  padding: 6px 0;
  & + & { border-top: 1px solid rgba(0,0,0,.05); }
  .strong { color: #1a1a2e; font-weight: 600; }
  .accent { color: #ff6b35; font-weight: 600; font-size: 12px; word-break: break-all; }
}
.confirm-actions {
  display: flex;
  gap: 12px;
}
.confirm-btn {
  flex: 1;
  padding: 12px 0;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all .2s;
  &.cancel {
    background: #f0f0f5;
    color: #6b7280;
    &:hover { background: #e5e5eb; }
  }
  &.primary {
    background: linear-gradient(135deg, #ff6b35, #ff3c00);
    color: #fff;
    &:hover { opacity: .9; }
    &:disabled { opacity: .5; cursor: not-allowed; }
  }
}

// 结果弹窗
.result-modal {
  background: #fff;
  border-radius: 24px;
  width: 300px;
  padding: 32px 24px 24px;
  text-align: center;
}

.result-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;

  svg {
    width: 32px;
    height: 32px;
    color: #fff;
  }

  &.success {
    background: linear-gradient(135deg, #22c55e, #16a34a);
    box-shadow: 0 8px 24px rgba(34, 197, 94, 0.3);
  }

  &.fail {
    background: linear-gradient(135deg, #ef4444, #dc2626);
    box-shadow: 0 8px 24px rgba(239, 68, 68, 0.3);
  }

  &.small {
    width: 56px;
    height: 56px;

    svg {
      width: 28px;
      height: 28px;
    }
  }
}

.result-title {
  font-size: 18px;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 6px;
}

.result-msg {
  font-size: 13px;
  color: #6b7280;
  margin-bottom: 4px;
}

.result-detail {
  background: #f9fafb;
  border-radius: 14px;
  padding: 12px;
  margin: 16px 0;
}

.result-row {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #6b7280;
  margin-bottom: 6px;

  &:last-child {
    margin-bottom: 0;
  }

  .strong {
    color: #374151;
    font-weight: 600;
  }

  .accent {
    color: #ef4444;
    font-weight: 600;
  }
}

.result-btn {
  width: 100%;
  padding: 12px;
  border-radius: 12px;
  border: none;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 8px;
  background: #f3f4f6;
  color: #374151;

  &.primary {
    background: linear-gradient(135deg, #f59e0b, #ea580c);
    color: #fff;
  }
}

// 卡密弹窗
.cardkey-modal {
  background: #fff;
  border-radius: 24px;
  width: 320px;
  padding: 28px 24px 24px;
}

.cardkey-title {
  font-size: 18px;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 20px;
}

.cardkey-input {
  width: 100%;
  padding: 12px 14px;
  border: 1.5px solid #e5e7eb;
  border-radius: 12px;
  font-size: 14px;
  outline: none;
  box-sizing: border-box;
  background: #f9fafb;
  margin-bottom: 12px;
  transition: border-color 0.2s;

  &:focus {
    border-color: #f59e0b;
    background: #fff;
  }
}

.cardkey-error {
  font-size: 12px;
  color: #ef4444;
  margin-bottom: 10px;
}

.cardkey-actions {
  display: flex;
  gap: 10px;
}

.cardkey-btn {
  flex: 1;
  padding: 12px;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  border: none;
  cursor: pointer;

  &.cancel {
    background: #f3f4f6;
    color: #374151;
  }

  &.confirm {
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: #fff;

    &:disabled {
      opacity: 0.5;
      cursor: default;
    }
  }
}

// 动画
@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.6;
  }
}

@keyframes shimmer {
  0%,
  100% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }
}

// 权益对比弹窗
.benefits-modal {
  background: #fff;
  border-radius: 24px;
  width: 90vw;
  max-width: 420px;
  max-height: 80vh;
  padding: 24px 20px 20px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.benefits-modal-title {
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
  text-align: center;
  margin-bottom: 16px;
  flex-shrink: 0;
}
.benefits-modal-list {
  overflow-y: auto;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding-right: 4px;
}
.benefits-level-card {
  background: #f5f6fa;
  border-radius: 16px;
  padding: 16px;
  border: 2px solid transparent;
  transition: border-color .2s;

  &.current {
    border-color: #f59e0b;
    background: #fff8e6;
  }
}
.benefits-level-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.benefits-level-name {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
  display: flex;
  align-items: center;
  gap: 6px;
}
.benefits-level-price {
  color: #f59e0b;
  font-weight: 700;
  font-size: 14px;
  white-space: nowrap;

  .price-symbol { font-size: 12px; }
  .price-value { font-size: 16px; }
  .price-unit { font-size: 11px; font-weight: 400; }
}
.benefits-level-desc {
  font-size: 12px;
  color: #6b7280;
  margin-bottom: 10px;
}
.benefits-close-btn {
  width: 100%;
  margin-top: 16px;
  padding: 12px;
  border: none;
  background: #f59e0b;
  color: #fff;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  flex-shrink: 0;
  transition: opacity .2s;

  &:active { opacity: .8; }
}

.section-tip.link {
  color: #f59e0b;
  cursor: pointer;
  font-weight: 500;
}

</style>
