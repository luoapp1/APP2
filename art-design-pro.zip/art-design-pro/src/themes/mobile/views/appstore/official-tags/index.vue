<template>
  <div class="official-tags-page">
    <div class="page-card">
      <div class="card-header">
        <div class="card-title">应用官方标签</div>
        <el-button type="primary" size="small" @click="handleAdd">新增标签</el-button>
      </div>
      <el-table :data="tagList" border stripe v-loading="loading">
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column label="标签名称" min-width="140">
          <template #default="{ row }">
            <span class="tag-preview-chip" :style="{ background: row.bgColor, color: row.color }">{{ row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column label="文字颜色" width="110">
          <template #default="{ row }">
            <div class="color-cell">
              <span class="color-dot" :style="{ background: row.color }" />
              <code>{{ row.color }}</code>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="背景颜色" width="110">
          <template #default="{ row }">
            <div class="color-cell">
              <span class="color-dot" :style="{ background: row.bgColor }" />
              <code>{{ row.bgColor }}</code>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="sortOrder" label="排序" width="70" />
        <el-table-column label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === '1' ? 'success' : 'info'" size="small">{{ row.status === '1' ? '启用' : '停用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" align="center">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog v-model="dialogVisible" :title="editId ? '编辑标签' : '新增标签'" width="420px" destroy-on-close append-to-body>
      <el-form :model="form" label-width="100px">
        <el-form-item label="标签名称">
          <el-input v-model="form.name" placeholder="如: 无广告" maxlength="10" />
        </el-form-item>
        <el-form-item label="文字颜色">
          <el-color-picker v-model="form.color" show-alpha />
          <span class="ml-2 text-xs text-gray-400">选填, 默认蓝色</span>
        </el-form-item>
        <el-form-item label="背景颜色">
          <el-color-picker v-model="form.bgColor" show-alpha />
          <span class="ml-2 text-xs text-gray-400">选填, 默认浅蓝</span>
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sortOrder" :min="0" :max="999" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.statusBool" active-text="启用" inactive-text="停用" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchOfficialTags, fetchSaveOfficialTag, fetchDeleteOfficialTag } from '@/api/appstore'

const loading = ref(false)
const tagList = ref<any[]>([])
const dialogVisible = ref(false)
const editId = ref(0)

const form = reactive({
  name: '',
  color: '#2563eb',
  bgColor: '#dbeafe',
  sortOrder: 0,
  statusBool: true
})

async function loadData() {
  loading.value = true
  try {
    const data: any = await fetchOfficialTags()
    tagList.value = data || []
  } catch { /* ignore */ } finally { loading.value = false }
}

function handleAdd() {
  editId.value = 0
  form.name = ''
  form.color = '#2563eb'
  form.bgColor = '#dbeafe'
  form.sortOrder = 0
  form.statusBool = true
  dialogVisible.value = true
}

function handleEdit(row: any) {
  editId.value = row.id
  form.name = row.name
  form.color = row.color || '#2563eb'
  form.bgColor = row.bgColor || '#dbeafe'
  form.sortOrder = row.sortOrder || 0
  form.statusBool = row.status === '1'
  dialogVisible.value = true
}

async function handleSave() {
  try {
    await fetchSaveOfficialTag({
      id: editId.value || undefined,
      name: form.name,
      color: form.color,
      bgColor: form.bgColor,
      sortOrder: form.sortOrder,
      status: form.statusBool ? '1' : '0'
    })
    ElMessage.success(editId.value ? '更新成功' : '新增成功')
    dialogVisible.value = false
    loadData()
  } catch { ElMessage.error('保存失败') }
}

async function handleDelete(row: any) {
  try {
    await ElMessageBox.confirm(`确定删除标签「${row.name}」吗？`, '提示', { type: 'warning' })
    await fetchDeleteOfficialTag(row.id)
    ElMessage.success('删除成功')
    loadData()
  } catch { /* cancelled */ }
}

onMounted(loadData)
</script>

<style scoped>
.official-tags-page { padding: 20px; }
.page-card { background: #fff; border-radius: 12px; padding: 20px; }
.card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.card-title { font-size: 17px; font-weight: 600; color: #1f2937; }
.tag-preview-chip { display: inline-block; padding: 3px 12px; border-radius: 12px; font-size: 12px; font-weight: 500; }
.color-cell { display: flex; align-items: center; gap: 6px; }
.color-dot { width: 14px; height: 14px; border-radius: 4px; border: 1px solid #e5e7eb; flex-shrink: 0; }
.color-cell code { font-size: 12px; color: #6b7280; }
</style>
