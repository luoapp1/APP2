<template>
  <div class="appstore-list">
    <div class="flex justify-between items-center mb-4">
      <div class="flex gap-3">
        <el-input v-model="searchKeyword" placeholder="搜索应用名称" clearable class="!w-[240px]" @keyup.enter="handleSearch" />
        <el-select v-model="searchStatus" placeholder="状态" clearable class="!w-[120px]" @change="handleSearch">
          <el-option label="上架" value="1" />
          <el-option label="下架" value="0" />
        </el-select>
        <el-button type="primary" @click="handleSearch">搜索</el-button>
      </div>
      <el-button type="primary" @click="handleAdd">添加应用</el-button>
    </div>

    <el-table :data="tableData" border stripe v-loading="loading" max-height="calc(100vh - 220px)">
      <el-table-column prop="id" label="ID" width="70" align="center" />
      <el-table-column label="应用图标" width="80" align="center">
        <template #default="{ row }">
          <div class="flex justify-center">
            <div
              class="flex items-center justify-center rounded-xl text-white font-bold text-xs"
              :style="{ width: '42px', height: '42px', background: row.iconBgColor || '#00BFA5' }"
            >
              <svg v-if="!row.icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
              <img v-else :src="$fixImgUrl(row.icon)" class="w-full h-full object-cover rounded-xl" />
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="应用名称" min-width="100" />
      <el-table-column prop="userId" label="上传者ID" width="90" align="center" />
      <el-table-column prop="packageName" label="包名" min-width="180" show-overflow-tooltip />
      <el-table-column prop="version" label="版本" width="90" />
      <el-table-column prop="sizeMb" label="大小" width="90" align="center">
        <template #default="{ row }">{{ row.sizeMb }} MB</template>
      </el-table-column>
      <el-table-column label="收费" width="100" align="center">
        <template #default="{ row }">
          <span v-if="row.priceType === 'free' || !row.priceType" class="text-green-500">免费</span>
          <span v-else>{{ row.priceType === 'balance' ? '¥' : '' }}{{ row.priceAmount }}{{ row.priceType === 'points' ? '积分' : '' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="downloads" label="下载" width="80" align="center" />
      <el-table-column prop="rating" label="评分" width="80" align="center" />
      <el-table-column label="标签" min-width="200">
        <template #default="{ row }">
          <el-tag
            v-for="tag in (row.tags || [])"
            :key="tag"
            size="small"
            class="mr-1"
            type="info"
          >{{ tag }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="80" align="center">
        <template #default="{ row }">
          <el-tag :type="row.status === '1' ? 'success' : 'info'" size="small">
            {{ row.status === '1' ? '上架' : '下架' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="420" align="center" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
          <el-button link type="success" size="small" @click="openDemo(row)">预览</el-button>
          <el-button link type="warning" size="small" @click="openVersions(row)">版本</el-button>
          <el-button link size="small" @click="handlePin(row)">{{ row.isPinned ? '取消置顶' : '置顶' }}</el-button>
          <el-button link type="primary" size="small" @click="openComments(row)">评论</el-button>
          <el-button link type="success" size="small" @click="openTips(row)">打赏</el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="flex justify-end mt-4">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @change="getList"
      />
    </div>

    <AppFormDialog
      v-model:visible="dialogVisible"
      :edit-data="editData"
      @submit="handleSubmit"
    />

    <VersionDialog
      v-model:visible="versionDialogVisible"
      :app-id="versionAppId"
    />

    <!-- 评论管理弹窗 -->
    <el-dialog v-model="commentDialogVisible" title="评论管理" width="700px" top="5vh">
      <el-table :data="commentList" max-height="500" border stripe v-loading="commentLoading">
        <el-table-column prop="id" label="ID" width="70" align="center" />
        <el-table-column prop="userName" label="用户" width="100" />
        <el-table-column prop="content" label="内容" min-width="200" show-overflow-tooltip />
        <el-table-column prop="rating" label="评分" width="80" align="center">
          <template #default="{ row }">
            <span style="color: #f59e0b;">{{ '★'.repeat(row.rating || 0) }}{{ '☆'.repeat(5 - (row.rating || 0)) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="时间" width="180" />
        <el-table-column label="操作" width="80" align="center">
          <template #default="{ row }">
            <el-button link type="danger" size="small" @click="handleDeleteComment(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <!-- 打赏管理弹窗 -->
    <el-dialog v-model="tipDialogVisible" title="打赏记录" width="600px" top="5vh">
      <div v-if="tipStats" style="margin-bottom: 12px; display: flex; gap: 16px; font-size: 14px;">
        <span>余额打赏: <b style="color: #00BFA5;">{{ tipStats.totalBalance || 0 }}元</b></span>
        <span>积分打赏: <b style="color: #00BFA5;">{{ tipStats.totalPoints || 0 }}积分</b></span>
      </div>
      <el-table :data="tipList" max-height="500" border stripe v-loading="tipLoading">
        <el-table-column prop="id" label="ID" width="70" align="center" />
        <el-table-column prop="userName" label="用户" width="120" />
        <el-table-column label="类型" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.tipType === 'balance' ? 'success' : 'warning'" size="small">{{ row.tipType === 'balance' ? '余额' : '积分' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="金额" width="120" align="center" />
        <el-table-column prop="message" label="留言" min-width="160" show-overflow-tooltip />
        <el-table-column prop="createTime" label="时间" width="180" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchAppList, fetchSaveApp, fetchDeleteApp, fetchPinApp, fetchAppDetail, fetchAppTips, fetchAdminDeleteComment } from '@/api/appstore'
import { fetchSubmissionList, fetchDeleteSubmission } from '@/api/submission'
import { useUserStore } from '@/store/modules/user'
import VersionDialog from './modules/version-dialog.vue'
import AppFormDialog from './modules/app-form-dialog.vue'

const router = useRouter()
const userStore = useUserStore()

const tableData = ref([])
const loading = ref(false)
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const searchKeyword = ref('')
const searchStatus = ref('')
const dialogVisible = ref(false)
const editData = ref(null)
const versionDialogVisible = ref(false)
const versionAppId = ref(0)

const commentDialogVisible = ref(false)
const commentList = ref<any[]>([])
const commentLoading = ref(false)
const tipDialogVisible = ref(false)
const tipList = ref<any[]>([])
const tipLoading = ref(false)

const getList = async () => {
  loading.value = true
  try {
    const res = await fetchAppList({
      keyword: searchKeyword.value,
      status: searchStatus.value,
      page: currentPage.value,
      pageSize: pageSize.value
    })
    tableData.value = res.list || []
    total.value = res.total || 0
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

const handleSearch = () => {
  currentPage.value = 1
  getList()
}

const handleAdd = () => {
  editData.value = null
  dialogVisible.value = true
}

const handleEdit = (row: any) => {
  editData.value = { ...row }
  dialogVisible.value = true
}

const handleSubmit = async (formData: any) => {
  try {
    if (!formData.id && !formData.userId) formData.userId = userStore.info.userId
    await fetchSaveApp(formData)
    ElMessage.success(editData.value?.id ? '更新成功' : '新增成功')
    dialogVisible.value = false
    getList()
  } catch (e: any) {
    ElMessage.error(e?.message || e?.msg || '操作失败，请重试')
  }
}

const handleDelete = async (row: any) => {
  try {
    await ElMessageBox.confirm('确定要删除该应用吗？删除后对应的投稿记录也将一并删除。', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await fetchDeleteApp(row.id)
    try {
      const subRes = await fetchSubmissionList({ appId: row.id })
      const subItem = subRes?.list?.[0]
      if (subItem) await fetchDeleteSubmission(subItem.id)
    } catch {}
    ElMessage.success('删除成功')
    getList()
  } catch {}
}

const openDemo = (row: any) => {
  router.push(`/appstore/detail/${row.id}`)
}

const openVersions = (row: any) => {
  versionAppId.value = row.id
  versionDialogVisible.value = true
}

const handlePin = async (row: any) => {
  try {
    await fetchPinApp(row.id, !row.isPinned)
    ElMessage.success(row.isPinned ? '已取消置顶' : '已置顶')
    getList()
  } catch {}
}

const openComments = async (row: any) => {
  commentDialogVisible.value = true
  commentLoading.value = true
  try {
    const data = await fetchAppDetail(row.id)
    commentList.value = data.comments || []
  } catch {}
  commentLoading.value = false
}

const handleDeleteComment = async (row: any) => {
  try {
    await ElMessageBox.confirm('确定要删除该评论吗？', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    await fetchAdminDeleteComment(row.id)
    ElMessage.success('删除成功')
    commentList.value = commentList.value.filter((c: any) => c.id !== row.id)
  } catch {}
}

const tipStats = ref<any>(null)

const openTips = async (row: any) => {
  tipDialogVisible.value = true
  tipLoading.value = true
  try {
    const data = await fetchAppTips(row.id)
    tipList.value = data.list || data || []
    tipStats.value = data.stats || null
  } catch {}
  tipLoading.value = false
}

onMounted(() => {
  getList()
})
</script>
