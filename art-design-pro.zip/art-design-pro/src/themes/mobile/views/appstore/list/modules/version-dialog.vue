<template>
  <el-dialog
    v-model="visible"
    :title="`版本管理 - ${appName}`"
    width="700px"
    destroy-on-close
  >
    <div class="flex justify-end mb-3">
      <el-button type="primary" size="small" @click="handleAdd">+ 添加版本</el-button>
    </div>
    <el-table :data="versionList" border stripe max-height="400">
      <el-table-column prop="version" label="版本号" width="100" />
      <el-table-column prop="sizeMb" label="大小(MB)" width="90" />
      <el-table-column prop="downloads" label="下载量" width="90" />
      <el-table-column prop="rating" label="评分" width="70" />
        <el-table-column label="标签" min-width="120">
          <template #default="{ row }">
            <el-tag v-for="t in (row.tags || [])" :key="t" size="small" class="mr-1">{{ t }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="官方标签" min-width="100">
          <template #default="{ row }">
            <span v-for="ot in (row.officialTags || [])" :key="ot.id" class="inline-block px-2 py-0.5 rounded-full text-[11px] font-medium mr-1" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
          </template>
        </el-table-column>
      <el-table-column label="当前" width="65" align="center">
        <template #default="{ row }">
          <el-tag v-if="row.isCurrent" type="success" size="small">当前</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="userName" label="上传者" width="100" />
      <el-table-column label="操作" width="150" align="center">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 版本编辑 -->
    <el-dialog v-model="versionDialogVisible" :title="versionEditData?.id ? '编辑版本' : '添加版本'" width="550px" destroy-on-close append-to-body>
      <el-form ref="verFormRef" :model="verForm" label-width="100px">
        <el-form-item label="版本号" prop="version">
          <el-input v-model="verForm.version" placeholder="1.3.0" />
        </el-form-item>
        <el-form-item label="版本代码" prop="versionCode">
          <el-input v-model="verForm.versionCode" placeholder="130" />
        </el-form-item>
        <el-form-item label="大小(MB)" prop="sizeMb">
          <el-input-number v-model="verForm.sizeMb" :min="0" :precision="1" />
        </el-form-item>
        <el-form-item label="下载量" prop="downloads">
          <el-input-number v-model="verForm.downloads" :min="0" />
        </el-form-item>
        <el-form-item label="评分" prop="rating">
          <el-input-number v-model="verForm.rating" :min="0" :max="5" :precision="1" />
        </el-form-item>
        <el-form-item label="标签">
          <el-select v-model="verForm.tags" multiple allow-create filterable placeholder="选择标签">
            <el-option label="官方" value="官方" />
            <el-option label="星选" value="星选" />
            <el-option label="64Bit" value="64Bit" />
          </el-select>
        </el-form-item>
        <el-form-item label="官方标签">
          <el-select v-model="verForm.officialTags" multiple placeholder="选择官方标签" value-key="id">
            <el-option v-for="ot in officialTagList" :key="ot.id" :label="ot.name" :value="{ id: ot.id, name: ot.name, color: ot.color, bgColor: ot.bgColor }">
              <span class="inline-block px-2 py-0.5 rounded-full text-xs font-medium" :style="{ background: ot.bgColor, color: ot.color }">{{ ot.name }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="标志选项">
          <div class="flex flex-col gap-2">
            <div class="flex items-center gap-2">
              <el-switch v-model="verForm.hasAds" size="small" />
              <span class="text-sm text-gray-600">是否有广告</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="verForm.requiresNetwork" size="small" />
              <span class="text-sm text-gray-600">是否需要联网</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="verForm.hasPaidContent" size="small" />
              <span class="text-sm text-gray-600">是否包含付费内容</span>
            </div>
            <div class="flex items-center gap-2">
              <el-switch v-model="verForm.isFree" size="small" />
              <span class="text-sm text-gray-600">是否免费应用</span>
            </div>
          </div>
        </el-form-item>
        <el-form-item label="更新内容">
          <el-input v-model="verForm.updateContent" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="下载链接" prop="downloadUrl">
          <el-input v-model="verForm.downloadUrl" placeholder="https://example.com/app-v1.3.0.apk" />
        </el-form-item>
        <el-form-item label="设为当前">
          <el-switch v-model="verForm.isCurrent" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="versionDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveVersion">确定</el-button>
      </template>
    </el-dialog>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchAppVersions, fetchSaveVersion, fetchDeleteVersion, fetchOfficialTags } from '@/api/appstore'

const props = defineProps<{ visible: boolean; appId: number }>()
const emit = defineEmits<{ 'update:visible': [value: boolean] }>()

const visible = ref(false)
watch(() => props.visible, (v) => { visible.value = v; if (v) { loadVersions(); loadOfficialTags() } })
watch(visible, (v) => { emit('update:visible', v) })

const appName = ref('')
const versionList = ref<any[]>([])
const versionDialogVisible = ref(false)
const versionEditData = ref<any>(null)
const verFormRef = ref()
const officialTagList = ref<any[]>([])

const verForm = reactive({
  id: 0,
  version: '',
  versionCode: '',
  sizeMb: 0,
  downloads: 0,
  rating: 0,
  updateContent: '',
  downloadUrl: '',
  tags: [] as string[],
  officialTags: [] as any[],
  hasAds: false,
  requiresNetwork: true,
  hasPaidContent: false,
  isFree: true,
  isCurrent: false
})

const loadVersions = async () => {
  if (!props.appId) return
  try {
    const res = await fetchAppVersions(props.appId)
    versionList.value = res || []
    if (versionList.value.length > 0) {
      appName.value = '应用'
    }
  } catch {}
}

const loadOfficialTags = async () => {
  try {
    const data: any = await fetchOfficialTags()
    officialTagList.value = (data || []).filter((t: any) => t.status === '1')
  } catch {}
}

const handleAdd = () => {
  versionEditData.value = null
  verForm.id = 0
  verForm.version = ''
  verForm.versionCode = ''
  verForm.sizeMb = 0
  verForm.downloads = 0
  verForm.rating = 0
  verForm.updateContent = ''
  verForm.downloadUrl = ''
  verForm.tags = []
  verForm.officialTags = []
  verForm.hasAds = false
  verForm.requiresNetwork = true
  verForm.hasPaidContent = false
  verForm.isFree = true
  verForm.isCurrent = false
  versionDialogVisible.value = true
}

const handleEdit = (row: any) => {
  versionEditData.value = row
  verForm.id = row.id
  verForm.version = row.version
  verForm.versionCode = row.versionCode || ''
  verForm.sizeMb = row.sizeMb || 0
  verForm.downloads = row.downloads || 0
  verForm.rating = row.rating || 0
  verForm.updateContent = row.updateContent || ''
  verForm.downloadUrl = row.downloadUrl || ''
  verForm.tags = row.tags ? [...row.tags] : []
  verForm.officialTags = row.officialTags ? (Array.isArray(row.officialTags) ? [...row.officialTags] : []) : []
  verForm.hasAds = !!row.hasAds
  verForm.requiresNetwork = row.requiresNetwork !== undefined ? !!row.requiresNetwork : true
  verForm.hasPaidContent = !!row.hasPaidContent
  verForm.isFree = row.isFree !== undefined ? !!row.isFree : true
  verForm.isCurrent = !!row.isCurrent
  versionDialogVisible.value = true
}

const saveVersion = async () => {
  try {
    await fetchSaveVersion({
      id: verForm.id || undefined,
      appId: props.appId,
      version: verForm.version,
      versionCode: verForm.versionCode,
      sizeMb: verForm.sizeMb,
      downloads: verForm.downloads,
      rating: verForm.rating,
      downloadUrl: verForm.downloadUrl,
      updateContent: verForm.updateContent,
      tags: verForm.tags,
      officialTags: verForm.officialTags,
      hasAds: verForm.hasAds,
      requiresNetwork: verForm.requiresNetwork,
      hasPaidContent: verForm.hasPaidContent,
      isFree: verForm.isFree,
      isCurrent: verForm.isCurrent,
      userName: '管理员'
    })
    ElMessage.success('保存成功')
    versionDialogVisible.value = false
    loadVersions()
  } catch (e) {
    ElMessage.error('保存失败')
  }
}

const handleDelete = async (row: any) => {
  try {
    await ElMessageBox.confirm('确定删除该版本？', '提示', { type: 'warning' })
    await fetchDeleteVersion(row.id)
    ElMessage.success('删除成功')
    loadVersions()
  } catch {}
}
</script>
