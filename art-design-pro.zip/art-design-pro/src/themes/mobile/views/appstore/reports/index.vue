<template>
  <div class="art-full-height">
    <ElCard>
      <template #header>
        <span style="font-weight: 600;">举报列表</span>
      </template>
      <ArtTable :data="list" :columns="columns" :loading="loading" :pagination="pagination" @pagination:size-change="(v: number) => { pagination.pageSize = v; loadData() }" @pagination:current-change="(v: number) => { pagination.current = v; loadData() }">
        <template #appName="{ row }">
          <span>{{ row.appName || '-' }}</span>
        </template>
        <template #content="{ row }">
          <span style="max-width:300px;display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ row.content || '-' }}</span>
        </template>
        <template #reported="{ row }">
          <ElTag type="danger">{{ row.reported || 0 }}</ElTag>
        </template>
        <template #createTime="{ row }">
          <span>{{ (row.createTime || '').slice(0, 16) || '-' }}</span>
        </template>
        <template #op="{ row }">
          <ElSpace>
            <ElButton size="small" type="danger" @click="handleDelete(row)">删除评论</ElButton>
            <ElButton size="small" @click="handleIgnore(row)">忽略</ElButton>
          </ElSpace>
        </template>
      </ArtTable>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, h } from 'vue'
import { fetchReportList, fetchAdminDeleteComment } from '@/api/appstore'
import { ElTag, ElMessage, ElButton, ElMessageBox } from 'element-plus'

defineOptions({ name: 'AppReports' })

const loading = ref(false)
const list = ref<any[]>([])
const pagination = ref({ current: 1, pageSize: 20, total: 0 })

const columns = [
  { type: 'index', width: 60, label: '序号' },
  { prop: 'id', label: 'ID', width: 70 },
  { prop: 'appName', label: '应用' },
  { prop: 'userName', label: '评论用户', width: 120 },
  { prop: 'content', label: '评论内容', 'show-overflow-tooltip': true },
  { prop: 'reported', label: '被举报次数', width: 110 },
  { prop: 'createTime', label: '发布时间', width: 160 },
  { prop: 'op', label: '操作', width: 180, fixed: 'right' }
]

const loadData = async () => {
  loading.value = true
  try {
    const data: any = await fetchReportList({ page: pagination.value.current, pageSize: pagination.value.pageSize })
    list.value = data.records || data.list || []
    pagination.value.total = data.total || list.value.length
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

const handleDelete = async (row: any) => {
  try {
    await ElMessageBox.confirm('确定要删除该评论吗？', '删除评论', { type: 'warning' })
    await fetchAdminDeleteComment(row.id)
    ElMessage.success('已删除')
    loadData()
  } catch {
    // cancelled or error
  }
}

const handleIgnore = async (row: any) => {
  try {
    const { fetchIgnoreReport } = await import('@/api/appstore')
    await fetchIgnoreReport(row.id)
    ElMessage.success('已忽略')
    loadData()
  } catch {
    ElMessage.error('操作失败')
  }
}

onMounted(() => loadData())
</script>
