<template>
  <div class="category-page art-full-height">
    <ElCard class="art-table-card">
      <ArtTableHeader v-model:columns="columnChecks" :loading="loading" @refresh="refreshData">
        <template #left>
          <ElButton type="primary" @click="showDialog('add')" v-ripple>添加分类</ElButton>
        </template>
      </ArtTableHeader>

      <ArtTable
        :loading="loading"
        :data="data"
        :columns="columns"
        :pagination="pagination"
        @pagination:size-change="handleSizeChange"
        @pagination:current-change="handleCurrentChange"
      />

      <ElDialog v-model="dialogVisible" :title="dialogType === 'add' ? '新增分类' : '编辑分类'" width="30%" align-center>
        <ElForm ref="formRef" :model="formData" :rules="rules" label-width="80px">
          <ElFormItem label="分类名称" prop="name">
            <ElInput v-model="formData.name" placeholder="请输入分类名称" />
          </ElFormItem>
          <ElFormItem label="图标">
            <ElInput v-model="formData.icon" placeholder="图标URL（可选）" />
          </ElFormItem>
          <ElFormItem label="排序">
            <ElInputNumber v-model="formData.sortOrder" :min="0" :max="999" style="width:100%" />
          </ElFormItem>
          <ElFormItem label="状态">
            <ElSwitch v-model="formData.status" active-value="1" inactive-value="0" />
          </ElFormItem>
        </ElForm>
        <template #footer>
          <ElButton @click="dialogVisible = false">取消</ElButton>
          <ElButton type="primary" @click="handleSubmit">保存</ElButton>
        </template>
      </ElDialog>
    </ElCard>
  </div>
</template>

<script setup lang="ts">
  import ArtButtonTable from '@/components/core/forms/art-button-table/index.vue'
  import { useTable } from '@/hooks/core/useTable'
  import { fetchCategoryList, fetchSaveCategory, fetchDeleteCategory } from '@/api/appstore'
  import { ElTag, ElButton, ElMessageBox, ElMessage, ElInput, ElInputNumber, ElSwitch, ElDialog, ElForm, ElFormItem } from 'element-plus'
  import type { FormInstance, FormRules } from 'element-plus'
  import { DialogType } from '@/types'

  defineOptions({ name: 'CategoryManage' })

  type CategoryRecord = {
    id: number
    name: string
    icon: string
    sortOrder: number
    status: string
    createTime: string
  }

  const dialogVisible = ref(false)
  const dialogType = ref<DialogType>('add')
  const currentRow = ref<Partial<CategoryRecord>>({})
  const formRef = ref<FormInstance>()
  const formData = reactive({ name: '', icon: '', sortOrder: 0, status: '1' as string })
  const rules: FormRules = { name: [{ required: true, message: '请输入分类名称', trigger: 'blur' }] }

  const STATUS_CONFIG: Record<string, { type: 'success' | 'info'; text: string }> = { '1': { type: 'success', text: '启用' }, '0': { type: 'info', text: '禁用' } }

  const { columns, columnChecks, data, loading, pagination, getData, handleSizeChange, handleCurrentChange, refreshData } = useTable({
    core: {
      apiFn: fetchCategoryList,
      apiParams: {},
      columnsFactory: () => [
        { type: 'index', width: 60, label: '序号' },
        { prop: 'name', label: '分类名称', width: 150 },
        { prop: 'icon', label: '图标', width: 120, formatter: (row: CategoryRecord) => row.icon || '-' },
        { prop: 'sortOrder', label: '排序', width: 80, align: 'center' },
        { prop: 'status', label: '状态', width: 80, formatter: (row: CategoryRecord) => { const c = STATUS_CONFIG[row.status] || { type: 'info' as const, text: '未知' }; return h(ElTag, { type: c.type, size: 'small' }, () => c.text) } },
        { prop: 'createTime', label: '创建时间', width: 180 },
        { prop: 'operation', label: '操作', width: 140, fixed: 'right', formatter: (row: CategoryRecord) => h('div', { style: { display: 'flex', gap: '8px' } }, [h(ArtButtonTable, { type: 'edit', onClick: () => showDialog('edit', row) }), h(ArtButtonTable, { type: 'delete', onClick: () => deleteCategory(row) })]) }
      ]
    }
  })

  getData()

  const showDialog = (type: DialogType, row?: CategoryRecord) => {
    dialogType.value = type
    if (type === 'edit' && row) {
      currentRow.value = row
      Object.assign(formData, { name: row.name, icon: row.icon || '', sortOrder: row.sortOrder || 0, status: row.status || '1' })
    } else {
      currentRow.value = {}
      Object.assign(formData, { name: '', icon: '', sortOrder: 0, status: '1' })
    }
    nextTick(() => { dialogVisible.value = true; formRef.value?.clearValidate() })
  }

  const handleSubmit = async () => {
    if (!formRef.value) return
    await formRef.value.validate(async (valid) => {
      if (!valid) return
      const params: Record<string, unknown> = { name: formData.name, icon: formData.icon, sortOrder: formData.sortOrder, status: formData.status }
      if (dialogType.value === 'edit' && currentRow.value.id) params.id = currentRow.value.id
      await fetchSaveCategory(params)
      ElMessage.success(dialogType.value === 'add' ? '添加成功' : '更新成功')
      dialogVisible.value = false
      refreshData()
    })
  }

  const deleteCategory = (row: CategoryRecord) => {
    ElMessageBox.confirm(`确定要删除分类「${row.name}」吗？`, '删除分类', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'error' }).then(async () => {
      await fetchDeleteCategory(row.id)
      ElMessage.success('删除成功')
      refreshData()
    }).catch(() => {})
  }
</script>
