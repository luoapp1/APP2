<script lang="ts">
export default { name: 'GameRpsPage' }
</script>

<template>
  <div class="game-page">
    <div class="gp-header">
      <div class="gp-back" @click="$router.back()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg></div>
      <h1 class="gp-title">剪刀石头布</h1>
    </div>

    <div class="gp-toast" v-if="toastMsg" :class="toastType">{{ toastMsg }}</div>

    <div class="gp-body">
      <div class="rps-info">
        <span class="rps-label">我的积分</span>
        <span class="rps-val">{{ userPoints }}</span>
        <span class="rps-cost">每局 {{ playCost }} 积分</span>
      </div>

      <div class="rps-arena">
        <div class="rps-system-choice">
          <div class="rps-system-label">对手</div>
          <div class="rps-system-hand" :class="{ reveal: showResult }">
            <span v-if="!showResult" class="rps-system-question">?</span>
            <span v-else class="rps-system-emoji">{{ handEmoji(systemChoice) }}</span>
          </div>
        </div>

        <div class="rps-vs">VS</div>

        <div class="rps-my-choice">
          <div class="rps-my-label">我</div>
          <div class="rps-my-hand">
            <span class="rps-my-emoji">{{ showResult ? handEmoji(myChoice) : '?' }}</span>
          </div>
        </div>
      </div>

      <div class="rps-result" v-if="showResult">
        <div :class="['rps-result-text', resultType]">
          {{ resultType === 'win' ? '你赢了！' : resultType === 'draw' ? '平局' : '你输了' }}
        </div>
        <div v-if="lastWon > 0" class="rps-result-won">获得 +{{ lastWon }} 积分</div>
      </div>

      <div class="rps-choices">
        <button
          v-for="opt in choices"
          :key="opt.key"
          class="rps-choice-btn"
          :class="{ selected: myChoice === opt.key && !showResult }"
          :disabled="playing"
          @click="play(opt.key)"
        >
          <span class="rps-choice-emoji">{{ opt.emoji }}</span>
          <span class="rps-choice-name">{{ opt.name }}</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import axios from 'axios'

const userStore = useUserStore()
const config = ref<any>({})
const playing = ref(false)
const showResult = ref(false)
const myChoice = ref('')
const systemChoice = ref('')
const resultType = ref('')
const lastWon = ref(0)
const toastMsg = ref('')
const toastType = ref('info')

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg
  toastType.value = type
  setTimeout(() => { toastMsg.value = '' }, 2500)
}

const choices = [
  { key: 'rock', name: '石头', emoji: '✊' },
  { key: 'scissors', name: '剪刀', emoji: '✌️' },
  { key: 'paper', name: '布', emoji: '✋' }
]

const userPoints = computed(() => userStore.info?.points || 0)
const playCost = computed(() => config.value.costPerPlay || 10)

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/config/rps')
    if (res.data?.config) config.value = res.data.config
  } catch {}
})

function handEmoji(key: string) {
  const map: Record<string, string> = { rock: '✊', scissors: '✌️', paper: '✋' }
  return map[key] || '?'
}
async function refreshUserInfo() {
  try {
    const { data: res } = await axios.get('/api/user/info')
    if (res.code === 200) userStore.setUserInfo(res.data)
  } catch {}
}

async function play(choice: string) {
  if (playing.value) return
  if (userPoints.value < playCost.value) { showToast('积分不足', 'error'); return }

  playing.value = true
  showResult.value = false
  myChoice.value = choice

  try {
    const { data: res } = await axios.post('/api/game/rps/play', {
      userId: userStore.info?.userId,
      choice
    })
    if (res.code !== 200) { showToast(res.msg, 'error'); playing.value = false; return }

    systemChoice.value = res.data.systemChoice
    resultType.value = res.data.result
    lastWon.value = res.data.wonPoints
    showResult.value = true

    await refreshUserInfo()
  } catch (e: any) { showToast(e.message, 'error') }
  finally {
    playing.value = false
    setTimeout(() => { showResult.value = false; myChoice.value = ''; systemChoice.value = '' }, 2500)
  }
}
</script>

<style lang="scss" scoped>
.game-page { min-height: 100vh; background: linear-gradient(180deg, #1a1a2e, #16213e); padding-bottom: 40px; }
.gp-toast { position: fixed; top: 56px; left: 16px; right: 16px; z-index: 100; padding: 12px 16px; border-radius: 10px; font-size: 14px; font-weight: 600; text-align: center; animation: toastIn .3s ease; }
.gp-toast.error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
.gp-toast.info { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
@keyframes toastIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.gp-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; }
.gp-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; svg { width: 20px; height: 20px; color: #fff; } }
.gp-title { font-size: 17px; font-weight: 700; color: #fff; }
.gp-body { padding: 0 16px; display: flex; flex-direction: column; align-items: center; }

.rps-info { text-align: center; margin-bottom: 20px; }
.rps-label { font-size: 13px; color: rgba(255,255,255,0.6); display: block; }
.rps-val { font-size: 36px; font-weight: 800; color: #fbbf24; }
.rps-cost { font-size: 12px; color: rgba(255,255,255,0.4); margin-top: 4px; display: block; }

.rps-arena { display: flex; align-items: center; gap: 20px; margin-bottom: 24px; }
.rps-system-choice, .rps-my-choice { text-align: center; }
.rps-system-label, .rps-my-label { font-size: 12px; color: rgba(255,255,255,0.5); margin-bottom: 8px; }
.rps-system-hand, .rps-my-hand {
  width: 80px; height: 80px; border-radius: 20px; display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,0.08); font-size: 40px;
}
.rps-system-hand.reveal { background: rgba(248,113,113,0.2); }
.rps-system-question { font-size: 32px; font-weight: 800; color: rgba(255,255,255,0.3); }
.rps-vs { font-size: 20px; font-weight: 800; color: rgba(255,255,255,0.3); }

.rps-result { text-align: center; margin-bottom: 24px; }
.rps-result-text { font-size: 22px; font-weight: 800; &.win { color: #4ade80; } &.lose { color: #f87171; } &.draw { color: #fbbf24; } }
.rps-result-won { font-size: 14px; color: #4ade80; margin-top: 4px; }

.rps-choices { display: flex; gap: 12px; }
.rps-choice-btn {
  width: 90px; padding: 16px 0; border: 2px solid rgba(255,255,255,0.15); border-radius: 16px;
  background: rgba(255,255,255,0.06); display: flex; flex-direction: column; align-items: center; gap: 6px;
  cursor: pointer; transition: all .2s;
  &:hover { background: rgba(255,255,255,0.12); }
  &:disabled { opacity: 0.5; cursor: not-allowed; }
  &.selected { border-color: #6366f1; background: rgba(99,102,241,0.2); }
}
.rps-choice-emoji { font-size: 32px; }
.rps-choice-name { font-size: 12px; color: rgba(255,255,255,0.6); font-weight: 600; }
</style>
