<script lang="ts">
export default { name: 'GameLotteryPage' }
</script>

<template>
  <div class="game-page">
    <div class="gp-header">
      <div class="gp-back" @click="$router.back()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg></div>
      <h1 class="gp-title">金币抽奖</h1>
    </div>

    <div class="gp-toast" v-if="toastMsg" :class="toastType">{{ toastMsg }}</div>

    <div class="gp-body">
      <div class="lottery-info">
        <div class="lottery-points">
          <span class="lottery-label">我的积分</span>
          <span class="lottery-val">{{ userPoints }}</span>
        </div>
        <div class="lottery-cost">单抽 {{ drawCost }} 积分 | 10连抽 {{ draw10Cost }} 积分</div>
      </div>

      <div class="lottery-grid">
        <template v-if="displayGrids.length === 9">
          <div
            v-for="(g, i) in displayGrids"
            :key="i"
            class="lottery-cell"
            :class="{
              active: activeIndex === i,
              won: lastResults.includes(i)
            }"
          >
            <span class="lottery-cell-name">{{ g.name }}</span>
            <span v-if="g.type === 'points'" class="lottery-cell-val">{{ g.value }}积分</span>
          </div>
        </template>
      </div>

      <div class="lottery-actions">
        <button class="lottery-btn draw1" :disabled="drawing || userPoints < drawCost" @click="doDraw(1)">
          {{ drawing && drawTimes === 1 ? '抽奖中...' : `抽奖一次 (${drawCost}积分)` }}
        </button>
        <button class="lottery-btn draw10" :disabled="drawing || userPoints < draw10Cost" @click="doDraw(10)">
          {{ drawing && drawTimes === 10 ? '抽奖中...' : `10连抽 (${draw10Cost}积分)` }}
        </button>
      </div>

      <div class="lottery-results" v-if="drawResults.length">
        <div class="lottery-results-title">抽奖结果</div>
        <div class="lottery-results-list">
          <div v-for="(r, i) in drawResults" :key="i" class="lottery-result-item" :class="{ win: r.type !== 'thanks' }">
            <span class="lr-name">{{ r.name }}</span>
            <span v-if="r.type === 'points'" class="lr-val">+{{ r.value }}积分</span>
            <span v-else-if="r.type === 'balance'" class="lr-val">+{{ r.value }}元</span>
            <span v-else-if="r.type === 'coupon'" class="lr-val coupon">优惠券</span>
            <span v-else-if="r.type === 'membership'" class="lr-val member">会员{{ r.value }}天</span>
            <span v-else-if="r.type === 'cardkey'" class="lr-val key">获得卡密</span>
            <span v-else class="lr-val thanks">谢谢参与</span>
          </div>
        </div>
        <div class="lottery-result-summary">
          消耗 {{ lastCost }} 积分，获得 {{ lastWon }} 积分
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import axios from 'axios'

const userStore = useUserStore()

const drawing = ref(false)
const drawTimes = ref(1)
const activeIndex = ref(-1)
const lastResults = ref<number[]>([])
const drawResults = ref<any[]>([])
const lastCost = ref(0)
const lastWon = ref(0)
const config = ref<any>({})
const displayGrids = ref<any[]>([])

const userPoints = computed(() => userStore.info?.points || 0)
const toastMsg = ref('')
const toastType = ref('info')

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg
  toastType.value = type
  setTimeout(() => { toastMsg.value = '' }, 2500)
}
const draw10Cost = computed(() => config.value.costPerDraw10 || config.value.costPerDraw * 10 || 100)

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/config/lottery')
    if (res.data?.config) {
      config.value = res.data.config
      displayGrids.value = res.data.config.grids || Array.from({ length: 9 }, (_, i) => ({ index: i, name: `奖励${i + 1}`, type: 'points', value: 10 }))
    }
  } catch {}
})

async function doDraw(times: number) {
  if (drawing.value) return
  drawing.value = true
  drawTimes.value = times
  drawResults.value = []
  lastResults.value = []

  try {
    const { data: res } = await axios.post('/api/game/lottery/draw', {
      userId: userStore.info?.userId,
      times
    })
    if (res.code !== 200) { showToast(res.msg, 'error'); drawing.value = false; return }

    // 动画展示
    const results = res.data.results
    for (let i = 0; i < results.length; i++) {
      for (let j = 0; j < 15 + i * 3; j++) {
        activeIndex.value = j % 9
        await sleep(60 + j * 8)
      }
      const resultIdx = results[i].gridIndex
      activeIndex.value = resultIdx
      lastResults.value.push(resultIdx)
      await sleep(400)
    }

    drawResults.value = results
    lastCost.value = res.data.cost
    lastWon.value = res.data.won
    await refreshUserInfo()
  } catch (e: any) { showToast(e.message, 'error') }
  finally {
    drawing.value = false
    activeIndex.value = -1
    setTimeout(() => { lastResults.value = [] }, 2000)
  }
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }
async function refreshUserInfo() {
  try {
    const { data: res } = await axios.get('/api/user/info')
    if (res.code === 200) userStore.setUserInfo(res.data)
  } catch {}
}
</script>

<style lang="scss" scoped>
.game-page { min-height: 100vh; background: linear-gradient(180deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding-bottom: 40px; }
.gp-toast { position: fixed; top: 56px; left: 16px; right: 16px; z-index: 100; padding: 12px 16px; border-radius: 10px; font-size: 14px; font-weight: 600; text-align: center; animation: toastIn .3s ease; }
.gp-toast.error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
.gp-toast.info { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
@keyframes toastIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.gp-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; }
.gp-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; svg { width: 20px; height: 20px; color: #fff; } }
.gp-title { font-size: 17px; font-weight: 700; color: #fff; }
.gp-body { padding: 0 16px; display: flex; flex-direction: column; align-items: center; }

.lottery-info { text-align: center; margin-bottom: 20px; }
.lottery-label { font-size: 13px; color: rgba(255,255,255,0.6); display: block; }
.lottery-val { font-size: 36px; font-weight: 800; color: #fbbf24; }
.lottery-cost { font-size: 12px; color: rgba(255,255,255,0.5); margin-top: 4px; }

.lottery-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px;
  width: 300px; margin-bottom: 20px;
}
.lottery-cell {
  aspect-ratio: 1; border-radius: 12px; background: rgba(255,255,255,0.08);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  border: 2px solid transparent; transition: all .15s;
  .lottery-cell-name { font-size: 13px; color: rgba(255,255,255,0.7); font-weight: 600; }
  .lottery-cell-val { font-size: 11px; color: rgba(255,255,255,0.4); margin-top: 2px; }
  &.active { border-color: #fbbf24; background: rgba(251,191,36,0.2); transform: scale(1.05); box-shadow: 0 0 20px rgba(251,191,36,.4); }
  &.won { border-color: #4ade80; background: rgba(74,222,128,0.15); }
}

.lottery-actions { display: flex; gap: 12px; margin-bottom: 20px; }
.lottery-btn {
  padding: 12px 28px; border-radius: 25px; border: none; font-size: 14px; font-weight: 700; cursor: pointer; transition: all .2s;
  &:disabled { opacity: 0.5; cursor: not-allowed; }
}
.draw1 { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; }
.draw10 { background: linear-gradient(135deg, #f59e0b, #fbbf24); color: #1a1a1a; }

.lottery-results { width: 100%; max-width: 340px; margin-top: 16px; }
.lottery-results-title { font-size: 15px; font-weight: 700; color: #fff; margin-bottom: 8px; text-align: center; }
.lottery-results-list { display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; margin-bottom: 8px; }
.lottery-result-item {
  padding: 6px 14px; border-radius: 16px; background: rgba(255,255,255,0.1); font-size: 12px; color: rgba(255,255,255,.7);
  display: flex; align-items: center; gap: 4px;
  &.win .lr-val { color: #4ade80; }
  .lr-val.coupon { color: #a78bfa; }
  .lr-val.member { color: #fbbf24; }
  .lr-val.key { color: #38bdf8; }
  .lr-val.thanks { color: rgba(255,255,255,.3); }
}
.lottery-result-summary { text-align: center; font-size: 13px; color: rgba(255,255,255,.5); }
</style>
