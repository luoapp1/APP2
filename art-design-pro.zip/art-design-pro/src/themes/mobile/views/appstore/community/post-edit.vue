<template>
  <div class="editor-root">
    <!-- Top Bar -->
    <div class="topbar">
      <button class="tb-back" @click="$router.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="tb-title">{{ isEditMode ? '编辑帖子' : '发布帖子' }}</span>
      <button
        class="tb-publish"
        :disabled="submitting || !form.title.trim() || !formContent.trim()"
        @click="handlePublish"
      >{{ submitting ? '发布中...' : '发布' }}</button>
    </div>

    <!-- Main Scroll -->
    <div class="editor-main">
      <!-- Title -->
      <div class="title-section">
        <textarea
          v-model="form.title"
          rows="1"
          maxlength="100"
          placeholder="添加标题"
          class="title-input"
          @input="resizeTextarea($event)"
        ></textarea>
      </div>

      <!-- Meta Row (below title) -->
      <div class="meta-bar">
        <button class="meta-btn" @click="showSectionPicker = true">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
          <span>{{ selectedSectionName || '选择板块' }}</span>
        </button>
        <button class="meta-btn" @click="showTopicPicker = true; loadTopics()">
          <span v-if="selectedTopicIds.length > 0">
            <span v-for="tid in selectedTopicIds" :key="tid" style="margin-right:4px">#{{ selectedTopicNames[tid] || tid }}</span>
          </span>
          <span v-else>选择话题</span>
        </button>
        <button class="meta-btn" @click="showTagPicker = true">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7" stroke-width="2.5" stroke-linecap="round"/></svg>
          <span>{{ subSectionTags.length ? `${subSectionTags.length} 个标签` : '添加标签' }}</span>
        </button>
        <span class="meta-cc">{{ form.title.length }}/100</span>
      </div>

      <!-- Tags -->
      <div v-if="subSectionTags.length" class="tags-row">
        <span v-for="(t, i) in subSectionTags" :key="i" class="tag-chip">
          #{{ t }}
          <button class="tag-x" @click="removeSubTag(i)">&times;</button>
        </span>
      </div>

      <!-- Blocks -->
      <div class="blocks-area">
        <template v-for="(block, idx) in contentBlocks" :key="idx">
          <!-- Inserter -->
          <div class="inserter-wrap">
            <div class="inserter-pop" @click.stop>
              <button class="inserter-btn" @click="openInserter(idx)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
              </button>
              <div class="inserter-menu" v-if="inserterIdx === idx">
                <button class="im-item" @click="insertTextBlock(idx)">
                  <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M4 7V4h16v3M9 4v16M15 4v16"/></svg></span>
                  <span class="im-label">文本</span>
                </button>
                <button class="im-item" @click="insertImageBlock(idx)">
                  <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M2 16l5-4 3 2 2-3 5 5"/></svg></span>
                  <span class="im-label">图片</span>
                </button>
                <button class="im-item" @click="insertLinkBlockAt(idx)">
                  <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg></span>
                  <span class="im-label">链接</span>
                </button>
                <button class="im-item" @click="insertAttachmentBlockAt(idx)">
                  <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg></span>
                  <span class="im-label">附件</span>
                </button>
                <button class="im-item" @click="insertAppBlockAt(idx)">
                  <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="3"/></svg></span>
                  <span class="im-label">应用</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Block -->
          <div
            class="block-unit"
            :class="{
              'block-selected': activeBlockIdx === idx,
            }"
            @click="focusBlock(idx)"
          >
            <!-- Block Toolbar (always visible, but styled subtly when not selected) -->
            <div class="block-tb" :class="{ 'block-tb-on': activeBlockIdx === idx }">
              <button class="btb-type" @click.stop>
                <svg v-if="block.type==='text'" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M4 7V4h16v3M9 4v16M15 4v16"/></svg>
                <svg v-else-if="block.type==='image'" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M2 16l5-4 3 2 2-3 5 5"/></svg>
                <svg v-else-if="block.type==='attachment'" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                <svg v-else-if="block.type==='link'" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                <svg v-else-if="block.type==='app'" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
              <button
                class="btb-btn btb-vis"
                :style="{ color: visibilityColor(currentBlockVisibility(idx)), borderColor: visibilityColor(currentBlockVisibility(idx)) + '50' }"
                @click.stop="toggleBlockVisibility(idx)"
              >
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
                <span>{{ visibilityLabel(currentBlockVisibility(idx)) }}</span>
              </button>
              <div class="btb-spacer"></div>
              <template v-if="activeBlockIdx === idx">
                <button class="btb-btn" @click.stop="moveBlockUp(idx)" :disabled="idx === 0">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 15l-6-6-6 6"/></svg>
                </button>
                <button class="btb-btn" @click.stop="moveBlockDown(idx)" :disabled="idx === contentBlocks.length - 1">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 9l6 6 6-6"/></svg>
                </button>
                <button class="btb-btn btb-del" @click.stop="removeBlock(idx)" v-if="contentBlocks.length > 1">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
              </template>
            </div>

            <!-- Visibility Picker -->
            <div class="vis-panel" v-if="blockVisibilityIdx === idx">
              <div class="vis-list">
                <button
                  v-for="opt in visibilityOptions"
                  :key="opt.value"
                  class="vis-row"
                  :class="{ 'vis-row-sel': currentBlockVisibility(idx) === opt.value }"
                  :style="{ '--c': opt.color }"
                  @click.stop="pickBlockVis(idx, opt.value)"
                >
                  <span class="vis-row-dot" :style="{ background: opt.color }"></span>
                  <span class="vis-row-label">{{ opt.label }}</span>
                  <span class="vis-row-desc">{{ opt.desc }}</span>
                  <svg v-if="currentBlockVisibility(idx) === opt.value" class="vis-row-check" width="14" height="14" viewBox="0 0 24 24" fill="none" :stroke="opt.color" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </button>
              </div>
              <div class="vis-conf" v-if="currentBlockVisibility(idx) === 'paid'">
                <div class="vis-conf-row">
                  <input v-model.number="block.visibilityPrice" type="number" min="0" placeholder="金额" class="vis-input" />
                  <select v-model="block.visibilityPriceType" class="vis-input" style="width:72px">
                    <option value="balance">余额</option>
                    <option value="points">积分</option>
                  </select>
                </div>
              </div>
              <div class="vis-conf" v-if="currentBlockVisibility(idx) === 'level'">
                <select class="vis-input" style="width:100%" :value="block.visibilityLevelId || ''" @change="onLevelSelect(idx, $event)">
                  <option value="" disabled>选择会员等级</option>
                  <option v-for="lv in membershipLevels" :key="lv.id" :value="lv.id">{{ lv.name }}</option>
                </select>
              </div>
              <div class="vis-conf" v-if="currentBlockVisibility(idx) === 'password'">
                <input v-model="block.visibilityPassword" type="text" placeholder="访问密码" class="vis-input" style="margin-bottom:8px" />
                <input v-model="block.visibilityPasswordTips" placeholder="密码提示" class="vis-input" />
              </div>
            </div>

            <!-- TEXT -->
            <div v-if="block.type==='text'" class="block-body block-body-text" @click.stop="focusBlock(idx)">
              <RichTextEditor
                v-model="block.value"
                :placeholder="'写点什么...'"
                :active="activeBlockIdx === idx"
                @focus="focusBlock(idx)"
                @topic-selected="onTopicSelected"
              />
            </div>

            <!-- IMAGE -->
            <div v-else-if="block.type==='image'" class="block-body block-body-img">
              <div class="bimg-wrap" v-for="(img, i) in block.images" :key="i">
                <img :src="img" class="bimg-img" />
                <button class="bimg-del" @click.stop="removeBlockImage(idx, i)">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
              </div>
              <label v-if="block.images && block.images.length < 9" class="bimg-add">
                <div class="bimg-add-inner">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
                  <span class="bimg-add-txt">添加图片</span>
                </div>
                <input type="file" accept="image/*" multiple style="display:none" @change="(e: any) => handleBlockImageUpload(e, idx)" />
              </label>
            </div>

            <!-- ATTACHMENT -->
            <div v-else-if="block.type==='attachment'" class="block-body block-body-att" @click.stop="openAttachmentModal(idx)">
              <div class="batt-left">
                <div class="batt-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                </div>
                <div class="batt-info">
                  <div class="batt-name">{{ block.title || '未命名附件' }}</div>
                  <div class="batt-desc">{{ block.desc || '点击编辑附件信息' }}</div>
                </div>
              </div>
              <div class="batt-right">
                <span class="batt-price" :class="{ 'batt-price-free': (block.priceType || 'free') === 'free' }">{{ priceTypeLabelFull(block.priceType || 'free', block.coin || 0) }}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
              </div>
            </div>

            <!-- LINK -->
            <div v-else-if="block.type==='link'" class="block-body block-body-link">
              <div class="blink-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
              </div>
              <div class="blink-fields">
                <input v-model="block.title" type="text" placeholder="链接标题" class="blink-title" @click.stop />
                <input v-model="block.url" type="text" placeholder="粘贴链接地址" class="blink-url" @click.stop />
              </div>
              <button class="blink-del" @click.stop="removeBlock(idx)" v-if="contentBlocks.length > 1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
              </button>
            </div>

            <!-- APP -->
            <div v-else-if="block.type==='app'" class="block-body block-body-app">
              <div class="bapp-left">
                <div class="bapp-av" :style="{ background: avatarColor(block.appName || 'A') }">
                  <img v-if="block.appIcon" :src="block.appIcon" class="bapp-av-img" />
                  <span v-else class="bapp-av-txt">{{ (block.appName || 'A').charAt(0) }}</span>
                </div>
                <div class="bapp-info">
                  <div class="bapp-name">{{ block.appName || '应用' }}</div>
                  <div class="bapp-desc">{{ block.desc || '' }}</div>
                </div>
              </div>
              <span class="bapp-price" :class="{ 'bapp-free': !block.coinCount }">{{ (!block.coinCount || block.coinCount === 0) ? '免费' : `${block.coinCount} 硬币` }}</span>
            </div>
          </div>
        </template>

        <!-- Bottom Inserter -->
        <div class="inserter-wrap bottom-inserter">
          <div class="inserter-pop" @click.stop>
            <button class="inserter-btn" @click="bottomInserterOpen = !bottomInserterOpen; inserterIdx = -1">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
            </button>
            <div class="inserter-menu" v-if="bottomInserterOpen">
              <button class="im-item" @click="insertTextBlock(contentBlocks.length)">
                <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M4 7V4h16v3M9 4v16M15 4v16"/></svg></span>
                <span class="im-label">文本</span>
              </button>
              <button class="im-item" @click="insertImageBlock(contentBlocks.length)">
                <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="3"/><circle cx="8.5" cy="10" r="1.5"/><path d="M2 16l5-4 3 2 2-3 5 5"/></svg></span>
                <span class="im-label">图片</span>
              </button>
              <button class="im-item" @click="insertLinkBlockAt(contentBlocks.length)">
                <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg></span>
                <span class="im-label">链接</span>
              </button>
              <button class="im-item" @click="insertAttachmentBlockAt(contentBlocks.length)">
                <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg></span>
                <span class="im-label">附件</span>
              </button>
              <button class="im-item" @click="insertAppBlockAt(contentBlocks.length)">
                <span class="im-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="3"/></svg></span>
                <span class="im-label">应用</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- App Selector -->
      <div v-if="showAppSelector" class="appsel">
        <div class="appsel-hd">
          <span class="appsel-title">插入应用</span>
          <button class="appsel-close" @click="showAppSelector = false">&times;</button>
        </div>
        <div class="appsel-tabs">
          <button :class="{ 'appsel-tab-on': appSourceTab === 'submission' }" @click="switchAppTab('submission')">我的投稿</button>
          <button :class="{ 'appsel-tab-on': appSourceTab === 'store' }" @click="switchAppTab('store')">本站应用</button>
        </div>
        <div class="appsel-search">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input v-model="appSearchQuery" type="text" placeholder="搜索应用..." class="appsel-input" @input="filterApps" />
        </div>
        <div v-if="appLoading" class="appsel-msg">加载中...</div>
        <div v-else-if="filteredAppList.length === 0" class="appsel-msg">暂无结果</div>
        <div v-else class="appsel-list">
          <button v-for="app in filteredAppList" :key="app.id" class="appsel-item" @click="selectApp(app)">
            <div class="appsel-av" :style="{ background: avatarColor(app.name) }">
              <img v-if="app.icon" :src="$fixImgUrl(app.icon)" class="appsel-av-img" />
              <span v-else>{{ app.name?.charAt(0) || 'A' }}</span>
            </div>
            <div class="appsel-info">
              <div class="appsel-name">{{ app.name }}</div>
              <div class="appsel-meta">{{ app.category || '' }} · {{ app.version || '' }}</div>
            </div>
            <span class="appsel-price" :class="{ 'appsel-price-free': !app.coinCount }">{{ (!app.coinCount || app.coinCount === 0) ? '免费' : app.coinCount + '硬币' }}</span>
          </button>
        </div>
      </div>

      <!-- Bottom padding -->
      <div class="editor-pad"></div>
    </div>

    <!-- Bottom Toolbar -->
    <!-- Bottom bar removed -->

    <!-- ===== MODALS ===== -->

    <!-- Section Picker -->
    <Teleport to="body">
      <div v-if="showSectionPicker" class="mo" @click.self="showSectionPicker = false">
        <div class="mp">
          <div class="mp-hd">
            <span class="mp-title">选择板块</span>
            <button class="mp-x" @click="showSectionPicker = false">&times;</button>
          </div>
          <div class="mp-bd">
            <button v-for="sec in sections" :key="sec.id" class="mp-item" :class="{ 'mp-item-on': form.sectionId === sec.id }" @click="selectSection(sec)">
              <div class="mp-av" :style="{ background: avatarColor(sec.name) }">{{ sec.name?.charAt(0) || '?' }}</div>
              <div class="mp-info">
                <div class="mp-name">{{ sec.name }}</div>
                <div class="mp-desc">{{ sec.description || '暂无描述' }}</div>
              </div>
              <svg v-if="form.sectionId === sec.id" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            </button>
          </div>
          <div class="mp-ft">
            <button class="mp-ok" @click="showSectionPicker = false">确定</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Tag Picker -->
    <Teleport to="body">
      <div v-if="showTagPicker" class="mo" @click.self="showTagPicker = false">
        <div class="mp">
          <div class="mp-hd">
            <span class="mp-title">添加标签</span>
            <button class="mp-x" @click="showTagPicker = false">&times;</button>
          </div>
          <div class="mp-bd">
            <div class="tp-row">
              <input v-model="tagPickerInput" type="text" placeholder="输入标签，回车添加" class="tp-input" @keydown.enter.prevent="addTagFromPicker" />
              <button class="tp-btn" @click="addTagFromPicker" :disabled="!tagPickerInput.trim()">添加</button>
            </div>
            <div class="tp-label">常用标签</div>
            <div class="tp-chips">
              <button v-for="tag in presetTags" :key="tag" class="tp-chip" :class="{ 'tp-chip-off': subSectionTags.includes(tag) }" :disabled="subSectionTags.includes(tag)" @click="addPresetTag(tag)">{{ tag }}</button>
            </div>
          </div>
          <div class="mp-ft">
            <button class="mp-ok" @click="showTagPicker = false">完成</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Topic Picker -->
    <Teleport to="body">
      <div v-if="showTopicPicker" class="mo" @click.self="showTopicPicker = false">
        <div class="mp">
          <div class="mp-hd">
            <span class="mp-title">选择话题</span>
            <button class="mp-x" @click="showTopicPicker = false">&times;</button>
          </div>
          <div class="mp-bd">
            <input v-model="topicSearchQuery" type="text" placeholder="搜索话题..." class="tp-input" />
            <div v-if="filteredTopics.length > 0" class="tp-list">
              <button v-for="t in filteredTopics" :key="t.id" class="tp-item" :class="{ 'tp-item-on': selectedTopicIds.includes(t.id) }" @click="selectTopic(t)">
                <span v-if="t.icon" class="tp-icon">{{ t.icon }}</span>
                <span class="tp-name">{{ t.name }}</span>
                <span v-if="t.postCount" class="tp-count">{{ t.postCount }} 帖</span>
                <span v-if="selectedTopicIds.includes(t.id)" class="tp-check">&check;</span>
              </button>
            </div>
            <div v-else class="tp-empty">暂无话题</div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Attachment Settings -->
    <Teleport to="body">
      <div v-if="attachmentModalVisible" class="mo" @click.self="closeAttachmentModal">
        <div class="mp">
          <div class="mp-hd">
            <span class="mp-title">附件设置</span>
            <button class="mp-x" @click="closeAttachmentModal">&times;</button>
          </div>
          <div class="mp-bd">
            <div class="fg">
              <label class="fg-l">附件标题</label>
              <input v-model="editingAttachment.title" placeholder="输入附件标题" class="fg-inp" />
            </div>
            <div class="fg">
              <label class="fg-l">描述</label>
              <input v-model="editingAttachment.desc" placeholder="附件描述（选填）" class="fg-inp" />
            </div>
            <div class="fg">
              <label class="fg-l">资源链接</label>
              <input v-model="editingAttachment.url" placeholder="输入链接地址" class="fg-inp" />
            </div>
            <div class="fg">
              <label class="fg-l">提取码（选填）</label>
              <input v-model="editingAttachment.extractCode" placeholder="选填" class="fg-inp" />
            </div>
            <div class="fg">
              <label class="fg-l">价格类型</label>
              <div class="fg-btns">
                <button v-for="pt in attachmentPriceTypes" :key="pt.value" class="fg-btn" :class="{ 'fg-btn-on': editingAttachment.priceType === pt.value }" @click="editingAttachment.priceType = pt.value">{{ pt.label }}</button>
              </div>
            </div>
            <div v-if="editingAttachment.priceType !== 'free'" class="fg">
              <label class="fg-l">{{ editingAttachment.priceType === 'balance' ? '余额数量' : '积分数量' }}</label>
              <input v-model.number="editingAttachment.coin" type="number" min="0" placeholder="0" class="fg-inp" />
            </div>
          </div>
          <div class="mp-ft">
            <button class="mp-ok" @click="saveAttachment">保存</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/store/modules/user'
import RichTextEditor from '@/components/editor/RichTextEditor.vue'
import {
  fetchCommunitySections,
  fetchCommunitySection,
  fetchCommunityPost,
  fetchModerators,
  createCommunityPost,
  updateCommunityPost,
  fetchTopics
} from '@/api/community'
import { fetchSubmissionList } from '@/api/submission'
import { fetchAppList } from '@/api/appstore'
import type { CommunitySection } from '@/api/community'
import type { SubmissionItem } from '@/api/submission'
import type { AppItem } from '@/api/appstore'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const editPostId = computed(() => {
  const id = route.params.id
  if (!id) return 0
  try { return Number(atob(id as string)) } catch { return 0 }
})
const isEditMode = computed(() => editPostId.value > 0)

const sections = ref<CommunitySection[]>([])
const sectionInfo = ref<any>(null)
const submitting = ref(false)
const activeBlockIdx = ref(-1)
const showSectionPicker = ref(false)
const showTagPicker = ref(false)
const showTopicPicker = ref(false)
const topicSearchQuery = ref('')
const availableTopics = ref<any[]>([])
const selectedTopicIds = ref<number[]>([])
const selectedTopicNames = ref<Record<number, string>>({})
const showAppSelector = ref(false)
const appSourceTab = ref<'submission' | 'store'>('submission')
const appList = ref<(SubmissionItem | AppItem)[]>([])
const filteredAppList = ref<(SubmissionItem | AppItem)[]>([])
const appSearchQuery = ref('')
const appLoading = ref(false)
const tagPickerInput = ref('')

const presetTags = ['闲聊', '新人报道', '技术问答', '资源分享', '作品展示', '问题求助', '经验分享', '其他']
const subSectionTags = ref<string[]>([])
const attachmentPriceTypes = [
  { value: 'free', label: '免费' },
  { value: 'balance', label: '余额' },
  { value: 'points', label: '积分' }
]

const selectedSectionName = computed(() => {
  if (!form.sectionId) return ''
  return sections.value.find(s => s.id === form.sectionId)?.name || ''
})

const filteredTopics = computed(() => {
  if (!topicSearchQuery.value) return availableTopics.value.slice(0, 20)
  const q = topicSearchQuery.value.toLowerCase()
  return availableTopics.value.filter((t: any) => t.name.toLowerCase().includes(q)).slice(0, 20)
})

function priceTypeLabelFull(type: string, amount: number) {
  if (type === 'free' || !type) return '免费'
  const pt = attachmentPriceTypes.find(p => p.value === type)
  if (amount && amount > 0) return `${amount}${pt?.label || ''}`
  return pt?.label || '免费'
}

function addTagFromPicker() {
  const v = tagPickerInput.value.trim()
  if (v && !subSectionTags.value.includes(v)) subSectionTags.value.push(v)
  tagPickerInput.value = ''
}
function addPresetTag(tag: string) {
  if (!subSectionTags.value.includes(tag)) subSectionTags.value.push(tag)
}
function removeSubTag(idx: number) { subSectionTags.value.splice(idx, 1) }
function selectSection(sec: CommunitySection) { form.sectionId = sec.id }

async function loadTopics() {
  try {
    const resp = await fetchTopics()
    availableTopics.value = (resp?.list || resp || [])
  } catch {}
}
function selectTopic(topic: any) {
  const idx = selectedTopicIds.value.indexOf(topic.id)
  if (idx > -1) {
    selectedTopicIds.value.splice(idx, 1)
    delete selectedTopicNames.value[topic.id]
  } else {
    selectedTopicIds.value.push(topic.id)
    selectedTopicNames.value[topic.id] = topic.name
  }
}
function removeTopic(topicId: number) {
  const idx = selectedTopicIds.value.indexOf(topicId)
  if (idx > -1) selectedTopicIds.value.splice(idx, 1)
  delete selectedTopicNames.value[topicId]
}
function onTopicSelected(topicId: number, topicName: string) {
  const idx = selectedTopicIds.value.indexOf(topicId)
  if (idx > -1) {
    selectedTopicIds.value.splice(idx, 1)
    delete selectedTopicNames.value[topicId]
  } else {
    selectedTopicIds.value.push(topicId)
    selectedTopicNames.value[topicId] = topicName
  }
}
const form = reactive({ sectionId: 0, title: '', tags: [] as string[], contentPermission: 'public', contentPrice: 0, contentPriceType: 'balance', accessPassword: '', accessPasswordTips: '' })

interface ContentBlock {
  type: 'text' | 'image' | 'attachment' | 'link' | 'app'
  value?: string; images?: string[]; title?: string; desc?: string; url?: string
  extractCode?: string; priceType?: string; coin?: number; coinCount?: number
  appId?: number; appName?: string; appIcon?: string; fileName?: string
  visibility?: 'public' | 'login' | 'comment' | 'paid' | 'level' | 'password'
  visibilityPrice?: number; visibilityPriceType?: 'balance' | 'points'
  visibilityLevelId?: number; visibilityLevelName?: string; visibilityLevel?: number
  visibilityPassword?: string; visibilityPasswordTips?: string
}

const contentBlocks = ref<ContentBlock[]>([{ type: 'text', value: '', visibility: 'public' }])
const attachmentModalVisible = ref(false)
const editingBlockIdx = ref(-1)
const blockVisibilityIdx = ref(-1)
const editingAttachment = reactive({ title: '', desc: '', url: '', extractCode: '', priceType: 'free', coin: 0 })
const membershipLevels = ref<{ id: number; name: string; level: number; icon?: string; iconColor?: string }[]>([])

async function loadMembershipLevels() {
  try {
    const resp = await fetch('/api/operation/membership-level/list')
    const json = await resp.json()
    membershipLevels.value = (json.data && json.data.records) || []
  } catch {}
}

const visibilityOptions = [
  { value: 'public', label: '公开', color: '#22c55e', desc: '所有用户可见' },
  { value: 'login', label: '登录可见', color: '#3b82f6', desc: '需登录后查看' },
  { value: 'paid', label: '付费可见', color: '#f59e0b', desc: '支付后方可查看' },
  { value: 'level', label: '会员可见', color: '#8b5cf6', desc: '指定会员等级可见' },
  { value: 'password', label: '密码可见', color: '#ef4444', desc: '输入密码后查看' },
  { value: 'comment', label: '评论可见', color: '#06b6d4', desc: '评论后方可查看' }
]

function blockTypeName(t: string) { const m: Record<string,string> = { text:'段落', image:'图片', attachment:'附件', link:'链接', app:'应用' }; return m[t]||t }
function visibilityLabel(v: string) { return visibilityOptions.find(o=>o.value===v)?.label||'公开' }
function visibilityColor(v: string) { return visibilityOptions.find(o=>o.value===v)?.color||'#22c55e' }
function currentBlockVisibility(idx: number) { return contentBlocks.value[idx]?.visibility||'public' }
function toggleBlockVisibility(idx: number) { blockVisibilityIdx.value = blockVisibilityIdx.value === idx ? -1 : idx }
function focusBlock(idx: number) { activeBlockIdx.value = idx }

function resizeTextarea(e: Event) {
  const el = e.target as HTMLTextAreaElement
  el.style.height = 'auto'
  el.style.height = el.scrollHeight + 'px'
}

const inserterIdx = ref(-1)
const bottomInserterOpen = ref(false)

function openInserter(idx: number) { bottomInserterOpen.value = false; inserterIdx.value = inserterIdx.value === idx ? -1 : idx }

function insertTextBlock(idx: number) {
  contentBlocks.value.splice(idx, 0, { type: 'text', value: '', visibility: 'public' })
  inserterIdx.value = -1; bottomInserterOpen.value = false
  activeBlockIdx.value = idx
  nextTick(() => { const el = document.querySelector('.block-selected .ql-editor') as HTMLElement; if (el) el.focus() })
}
function insertImageBlock(idx: number) {
  contentBlocks.value.splice(idx, 0, { type: 'image', images: [], visibility: 'public' })
  inserterIdx.value = -1; bottomInserterOpen.value = false
  activeBlockIdx.value = idx
}
function insertLinkBlockAt(idx: number) {
  contentBlocks.value.splice(idx, 0, { type: 'link', title: '', url: '', visibility: 'public' })
  inserterIdx.value = -1; bottomInserterOpen.value = false
  activeBlockIdx.value = idx
}
function insertAttachmentBlockAt(idx: number) {
  contentBlocks.value.splice(idx, 0, { type: 'attachment', title: '', desc: '', url: '', extractCode: '', priceType: 'free', coin: 0, visibility: 'public' })
  inserterIdx.value = -1; bottomInserterOpen.value = false
  activeBlockIdx.value = idx
}
function insertAppBlockAt(idx: number) {
  showAppSelector.value = true
  inserterIdx.value = -1; bottomInserterOpen.value = false
}

function moveBlockUp(idx: number) { if(idx<=0) return; const [b]=contentBlocks.value.splice(idx,1); contentBlocks.value.splice(idx-1,0,b); activeBlockIdx.value=idx-1 }
function moveBlockDown(idx: number) { if(idx>=contentBlocks.value.length-1) return; const [b]=contentBlocks.value.splice(idx,1); contentBlocks.value.splice(idx+1,0,b); activeBlockIdx.value=idx+1 }

function pickBlockVis(idx: number, vis: string) {
  const block = contentBlocks.value[idx]; if(!block) return
  block.visibility = vis as ContentBlock['visibility']
  if(vis==='paid'){ block.visibilityPrice=block.visibilityPrice||5; block.visibilityPriceType=block.visibilityPriceType||'points' }
  if(vis==='password'){ block.visibilityPassword=block.visibilityPassword||''; block.visibilityPasswordTips=block.visibilityPasswordTips||'' }
  if(vis!=='level'){ block.visibilityLevelId=undefined; block.visibilityLevelName=undefined }
  if(vis==='login'||vis==='comment'||vis==='public') blockVisibilityIdx.value=-1
}

function onLevelSelect(idx: number, e: Event) {
  const v = (e.target as HTMLSelectElement).value; if(!v) return
  const lv = membershipLevels.value.find(l=>String(l.id)===v)
  const block = contentBlocks.value[idx]; if(!block||!lv) return
  block.visibilityLevelId=lv.id; block.visibilityLevelName=lv.name; block.visibilityLevel=lv.level
  blockVisibilityIdx.value=-1
}

function onBlockResize(e: Event) { const el=e.target as HTMLTextAreaElement; el.style.height='auto'; el.style.height=el.scrollHeight+'px' }

function insertEmoji() { const b=ensureTextBlockAtEnd(); b.value=(b.value||'')+' :)' }

function addAttachmentBlock() {
  contentBlocks.value.push({ type:'attachment', title:'', desc:'', url:'', extractCode:'', priceType:'free', coin:0, visibility:'public' })
  contentBlocks.value.push({ type:'text', value:'', visibility:'public' })
}
function addLinkBlock() {
  contentBlocks.value.push({ type:'link', title:'', url:'', visibility:'public' })
  contentBlocks.value.push({ type:'text', value:'', visibility:'public' })
}
async function toggleAppSelector() { showAppSelector.value=!showAppSelector.value; appSearchQuery.value=''; filteredAppList.value=[]; appList.value=[] }
async function switchAppTab(tab: 'submission'|'store') { appSourceTab.value=tab; appSearchQuery.value=''; filteredAppList.value=[]; appList.value=[] }

async function loadAppsBySearch() {
  const q=appSearchQuery.value.trim(); if(!q){ filteredAppList.value=[]; return }
  appLoading.value=true
  try {
    if(appSourceTab.value==='submission'){
      const res:any=await fetchSubmissionList({page:1,pageSize:200,keyword:q})
      const list=Array.isArray(res)?res:(res.list||res.data||[])
      appList.value=list; filteredAppList.value=list.filter((a:any)=>a.name.toLowerCase().includes(q.toLowerCase())||(a.category&&a.category.toLowerCase().includes(q.toLowerCase()))||(a.packageName&&a.packageName.toLowerCase().includes(q.toLowerCase())))
    }else{
      const res:any=await fetchAppList({page:1,pageSize:200})
      const list=Array.isArray(res)?res:(res.list||res.data||[])
      appList.value=list; filteredAppList.value=list.filter((a:any)=>a.name.toLowerCase().includes(q.toLowerCase())||(a.category&&a.category.toLowerCase().includes(q.toLowerCase()))||(a.packageName&&a.packageName.toLowerCase().includes(q.toLowerCase())))
    }
  }catch{}finally{appLoading.value=false}
}
function filterApps(){ loadAppsBySearch() }

function selectApp(app: any) {
  contentBlocks.value.push({ type:'app', appId:app.id, appName:app.name, appIcon:app.icon, desc:app.description||app.category||'', coinCount:app.coinCount||0, visibility:'public' })
  contentBlocks.value.push({ type:'text', value:'', visibility:'public' })
  showAppSelector.value=false; appSearchQuery.value=''; filteredAppList.value=[]
}

function removeBlock(idx: number) {
  contentBlocks.value.splice(idx,1)
  if(contentBlocks.value.length===0) contentBlocks.value.push({ type:'text', value:'', visibility:'public' })
  mergeConsecutiveTextBlocks()
}
function removeBlockImage(bi: number, ii: number) {
  const b=contentBlocks.value[bi]; if(b&&b.images){ b.images.splice(ii,1); if(b.images.length===0){ contentBlocks.value.splice(bi,1); if(contentBlocks.value.length===0) contentBlocks.value.push({ type:'text', value:'', visibility:'public' }); mergeConsecutiveTextBlocks() } }
}
function handleBlockImageUpload(e: Event, bi: number) {
  const files=(e.target as HTMLInputElement).files; if(!files) return
  const b=contentBlocks.value[bi]; if(!b||!b.images) return
  const r=9-b.images.length; Array.from(files).slice(0,r).forEach(f=>{ const rd=new FileReader(); rd.onload=()=>{ if(rd.result&&b.images) b.images.push(rd.result as string) }; rd.readAsDataURL(f) })
  ;(e.target as HTMLInputElement).value=''
}
function handleGlobalImageUpload(e: Event) {
  const files=(e.target as HTMLInputElement).files; if(!files||files.length===0) return
  const du:string[]=[]; let ld=0
  Array.from(files).forEach(f=>{ const rd=new FileReader(); rd.onload=()=>{ ld++; if(rd.result) du.push(rd.result as string); if(ld===files.length){ contentBlocks.value.push({ type:'image', images:du, visibility:'public' }); contentBlocks.value.push({ type:'text', value:'', visibility:'public' }) } }; rd.readAsDataURL(f) })
  ;(e.target as HTMLInputElement).value=''
}
function ensureTextBlockAtEnd(): ContentBlock { const l=contentBlocks.value[contentBlocks.value.length-1]; if(l&&l.type==='text') return l; const nb:ContentBlock={ type:'text', value:'', visibility:'public' }; contentBlocks.value.push(nb); return nb }
function mergeConsecutiveTextBlocks() {
  for(let i=contentBlocks.value.length-2;i>=0;i--){
    const a=contentBlocks.value[i],b=contentBlocks.value[i+1]
    if(a&&b&&a.type==='text'&&b.type==='text'){
      const aHas = (a.value || '').replace(/<[^>]*>/g, '').trim()
      const bHas = (b.value || '').replace(/<[^>]*>/g, '').trim()
      if(aHas && bHas) continue
      a.value=(a.value||'')+'\n'+(b.value||'')
      if(a.visibility==='public'&&b.visibility&&b.visibility!=='public'){ a.visibility=b.visibility; a.visibilityPrice=b.visibilityPrice; a.visibilityPriceType=b.visibilityPriceType; a.visibilityPassword=b.visibilityPassword; a.visibilityPasswordTips=b.visibilityPasswordTips; a.visibilityLevelId=b.visibilityLevelId; a.visibilityLevelName=b.visibilityLevelName; a.visibilityLevel=b.visibilityLevel }
      contentBlocks.value.splice(i+1,1)
    }
  }
}
function openAttachmentModal(idx: number) {
  editingBlockIdx.value=idx; const b=contentBlocks.value[idx]
  if(b&&b.type==='attachment'){ editingAttachment.title=b.title||''; editingAttachment.desc=b.desc||''; editingAttachment.url=b.url||''; editingAttachment.extractCode=b.extractCode||''; editingAttachment.priceType=b.priceType||'balance'; editingAttachment.coin=b.coin||0 }
  attachmentModalVisible.value=true
}
function closeAttachmentModal(){ attachmentModalVisible.value=false }
function saveAttachment() {
  const idx=editingBlockIdx.value; const b=contentBlocks.value[idx]
  if(b&&b.type==='attachment'){ b.title=editingAttachment.title; b.desc=editingAttachment.desc; b.url=editingAttachment.url; b.extractCode=editingAttachment.extractCode; b.priceType=editingAttachment.priceType; b.coin=editingAttachment.coin }
  attachmentModalVisible.value=false
}

const formContent = computed(() => {
  const texts = contentBlocks.value.filter(b => b.type === 'text').map(b => (b.value || '').replace(/<[^>]*>/g, '').trim()).filter(Boolean)
  return texts.join('\n')
})
const allImages = computed(() => { const im:string[]=[]; contentBlocks.value.forEach(b=>{ if(b.type==='image'&&b.images) im.push(...b.images) }); return im })

const avatarPalette = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#84CC16','#E11D48','#0EA5E9','#7C3AED']
function avatarColor(n: string): string { let h=0; for(let i=0;i<(n||'').length;i++) h=n.charCodeAt(i)+((h<<5)-h); return avatarPalette[Math.abs(h)%avatarPalette.length] }

async function loadSections() { try{ const res:any=await fetchCommunitySections(); sections.value=Array.isArray(res)?res:(res.list||[]) }catch{} }
async function loadSectionInfo() {
  const sid=route.query.sectionId||route.params.sectionId; if(!sid) return
  try{ const r:any=await fetchCommunitySection(Number(sid)); sectionInfo.value=r.data||r }catch{}
}

async function loadExistingPost() {
  if(!editPostId.value) return
  try{
    const res:any=await fetchCommunityPost(editPostId.value, getUserId())
    const post=res.data||res; if(!post) return

    // 权限检查：仅作者可编辑
    const uid = getUserId()
    if (!uid || (post.userId && post.userId !== uid)) {
      router.replace(`/community/post/${editPostId.value}`)
      return
    }

    form.sectionId=post.sectionId||0; form.title=post.title||''
    if(post.topicIds && post.topicIds.length > 0){ selectedTopicIds.value=post.topicIds; post.topicIds.forEach((tid: number)=>{ const t=availableTopics.value.find((t2: any)=>t2.id===tid); if(t) selectedTopicNames.value[tid]=t.name }) }
    else if(post.topicId){ selectedTopicIds.value=[post.topicId]; if(post.topicName) selectedTopicNames.value[post.topicId]=post.topicName }
    const gv=post.contentPermission||'public'
    if(post.content){ try{ const p=JSON.parse(post.content); if(Array.isArray(p)&&p.length>0){ contentBlocks.value=p.map((b:any)=>({...b,visibility:b.visibility||gv})); form.tags=post.tags||[]; return } }catch{} contentBlocks.value=[{ type:'text', value:post.content, visibility:gv }] }
    if(post.images&&post.images.length>0){ contentBlocks.value.push({ type:'image', images:post.images, visibility:gv }); contentBlocks.value.push({ type:'text', value:'', visibility:gv }) }
    form.tags=post.tags||[]
  }catch{}
}

function getUserId(): number { return (userStore.info as any)?.userId||(userStore.info as any)?.id||0 }

async function buildPayload(): Promise<Record<string,unknown>> {
  const mixed=contentBlocks.value.some(b=>b.visibility&&b.visibility!=='public')
  return { sectionId:form.sectionId, topicId: selectedTopicIds.value[0] || 0, topicIds: selectedTopicIds.value, title:form.title.trim(), content:JSON.stringify(contentBlocks.value), images:allImages.value, tags:subSectionTags.value.concat(form.tags), contentPermission:mixed?'mixed':'public', contentPrice:form.contentPrice, contentPriceType:form.contentPriceType, accessPassword:form.accessPassword, accessPasswordTips:form.accessPasswordTips }
}

async function handlePublish() {
  if(!form.title.trim()||!formContent.value.trim()) return
  submitting.value=true
  try{ const p=await buildPayload(); if(isEditMode.value) await updateCommunityPost(editPostId.value,p); else await createCommunityPost(p); router.back() }catch{}finally{submitting.value=false}
}

onMounted(async()=>{
  await loadSections(); await loadMembershipLevels()
  if(isEditMode.value) await loadExistingPost()
  else{ const sid=route.query.sectionId; if(sid) form.sectionId=Number(sid)||0 }
  loadSectionInfo()
})
</script>

<style scoped>
.editor-root { display:flex; flex-direction:column; height:100vh; height:100dvh; background:#fff; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }

/* Top */
.topbar { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; padding-top:calc(10px + env(safe-area-inset-top,0px)); background:#fff; border-bottom:1px solid #f0f0f0; flex-shrink:0; z-index:10; }
.tb-back { width:34px; height:34px; border-radius:10px; border:none; background:#f5f5f5; display:flex; align-items:center; justify-content:center; color:#333; cursor:pointer; }
.tb-title { font-size:16px; font-weight:700; color:#111; }
.tb-publish { border:none; padding:7px 18px; border-radius:18px; font-size:13px; font-weight:600; color:#fff; background:#6366f1; cursor:pointer; }
.tb-publish:disabled { opacity:0.4; cursor:not-allowed; }
.tb-publish:active:not(:disabled) { transform:scale(.96); }

/* Main */
.editor-main { flex:1; overflow-y:auto; -webkit-overflow-scrolling:touch; }

/* Title */
.title-section { padding:24px 20px 16px; }
.title-input { width:100%; border:none; outline:none; font-size:22px; font-weight:700; color:#111; line-height:1.35; resize:none; background:transparent; font-family:inherit; padding:0; }
.title-input::placeholder { color:#ccc; }

/* Blocks Area */
.blocks-area { padding:0 20px; }

/* Inserter */
.inserter-wrap { display:flex; align-items:center; justify-content:center; padding:4px 0; }
.inserter-pop { position:relative; }
.inserter-btn { width:26px; height:26px; border-radius:50%; border:1.5px solid #dee2e6; background:#fff; color:#adb5bd; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .15s; }
.inserter-btn:hover { border-color:#5c7cfa; color:#5c7cfa; background:#edf2ff; }
.inserter-menu { position:absolute; top:100%; left:50%; transform:translateX(-50%); margin-top:4px; background:#fff; border:1px solid #e9ecef; border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,.08); padding:6px; display:flex; gap:2px; z-index:20; white-space:nowrap; animation:imIn .15s ease; }
@keyframes imIn { from{opacity:0;transform:translateX(-50%) translateY(-4px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }
.im-item { display:flex; flex-direction:column; align-items:center; gap:4px; padding:8px 10px; border:none; border-radius:8px; background:transparent; cursor:pointer; transition:all .12s; min-width:52px; }
.im-item:hover { background:#f1f3f5; }
.im-item:active { background:#e9ecef; }
.im-icon { width:36px; height:36px; border-radius:8px; background:#f1f3f5; display:flex; align-items:center; justify-content:center; color:#495057; }
.im-item:hover .im-icon { background:#edf2ff; color:#5c7cfa; }
.im-label { font-size:10px; font-weight:500; color:#868e96; }

/* Block Unit */
.block-unit { position:relative; padding:6px 0; border-left:3px solid transparent; padding-left:12px; margin-left:-15px; border-radius:0 6px 6px 0; transition:all .15s; }
.block-selected { border-left-color:#6366f1; background:rgba(99,102,241,.03); }

/* Block Toolbar */
.block-tb { display:flex; align-items:center; gap:4px; padding-bottom:6px; opacity:.5; transition:opacity .15s; }
.block-tb-on { opacity:1; }
.btb-type { width:26px; height:26px; border-radius:6px; border:none; background:transparent; color:#adb5bd; display:flex; align-items:center; justify-content:center; cursor:default; }
.btb-spacer { flex:1; }
.btb-btn { width:26px; height:26px; border-radius:6px; border:none; background:transparent; color:#adb5bd; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .12s; }
.btb-btn:hover { background:#e9ecef; color:#495057; }
.btb-btn:disabled { opacity:.2; cursor:default; }
.btb-del:hover { background:#fff5f5; color:#e03131; }
.btb-vis { width:auto; padding:2px 8px; gap:4px; font-size:10px; font-weight:600; border:1px solid #e9ecef; background:#fff; border-radius:10px; }
.btb-vis:hover { opacity:.8; }

/* Visibility Panel */
.vis-panel { margin-bottom:8px; border:1px solid #eee; border-radius:14px; background:#fff; overflow:hidden; animation:visIn .15s ease; }
@keyframes visIn { from{opacity:0;transform:translateY(-4px)} to{opacity:1;transform:translateY(0)} }
.vis-list { display:grid; grid-template-columns:1fr 1fr; gap:6px; padding:10px; }
.vis-row { display:flex; flex-direction:column; align-items:center; gap:3px; padding:8px 6px; border:2px solid #f0f0f0; border-radius:10px; background:#fff; cursor:pointer; position:relative; transition:all .12s; }
.vis-row:hover { border-color:#ddd; }
.vis-row-sel { border-color:var(--c); background:color-mix(in srgb, var(--c) 4%, #fff); }
.vis-row-dot { width:6px; height:6px; border-radius:50%; }
.vis-row-label { font-size:11px; font-weight:600; color:#333; }
.vis-row-desc { font-size:9px; color:#aaa; }
.vis-row-sel .vis-row-label { color:var(--c); }
.vis-row-check { position:absolute; top:4px; right:4px; }
.vis-conf { padding:10px; border-top:1px solid #f0f0f0; background:#fafafa; }
.vis-conf-row { display:flex; gap:8px; }
.vis-input { height:34px; border:2px solid #e5e7eb; border-radius:8px; padding:0 10px; font-size:12px; outline:none; background:#fff; }
.vis-input:focus { border-color:#6366f1; }

/* Block Body */
.block-body { }

/* Block Body - Text */
.block-body-text { padding: 4px 0 0; min-height: 50px; }

/* Block Body - Image */
.block-body-img { display:flex; flex-wrap:wrap; gap:8px; }
.bimg-wrap { position:relative; width:calc((100% - 16px)/3); aspect-ratio:1; border-radius:10px; overflow:hidden; background:#f5f5f5; }
.bimg-img { width:100%; height:100%; object-fit:cover; }
.bimg-del { position:absolute; top:5px; right:5px; width:22px; height:22px; border-radius:6px; border:none; background:rgba(0,0,0,.5); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); color:#fff; display:flex; align-items:center; justify-content:center; cursor:pointer; padding:0; }
.bimg-add { width:calc((100% - 16px)/3); aspect-ratio:1; border-radius:10px; border:2px dashed #dee2e6; display:flex; align-items:center; justify-content:center; cursor:pointer; background:#fafbfc; transition:all .15s; }
.bimg-add:active { background:#f1f3f5; border-color:#adb5bd; }
.bimg-add-inner { display:flex; flex-direction:column; align-items:center; gap:4px; color:#adb5bd; }
.bimg-add-txt { font-size:10px; font-weight:500; }

/* Block Body - Attachment */
.block-body-att { display:flex; align-items:center; justify-content:space-between; padding:12px 14px; background:#f8f9fa; border-radius:10px; border:1px solid #e9ecef; cursor:pointer; transition:all .12s; }
.block-body-att:active { background:#f1f3f5; transform:scale(.99); }
.batt-left { display:flex; align-items:center; gap:10px; flex:1; min-width:0; }
.batt-icon { width:42px; height:42px; border-radius:10px; background:linear-gradient(135deg,#748ffc,#5c7cfa); display:flex; align-items:center; justify-content:center; color:#fff; flex-shrink:0; }
.batt-info { min-width:0; }
.batt-name { font-size:14px; font-weight:600; color:#212529; }
.batt-desc { font-size:11px; color:#868e96; margin-top:1px; }
.batt-right { display:flex; align-items:center; gap:6px; color:#adb5bd; flex-shrink:0; }
.batt-price { font-size:11px; font-weight:600; color:#868e96; }
.batt-price-free { color:#40c057; }

/* Block Body - Link */
.block-body-link { display:flex; align-items:center; gap:10px; padding:12px 14px; background:#f8f9fa; border-radius:10px; border:1px solid #e9ecef; }
.blink-icon { width:40px; height:40px; border-radius:10px; background:#edf2ff; display:flex; align-items:center; justify-content:center; color:#5c7cfa; flex-shrink:0; }
.blink-fields { flex:1; min-width:0; }
.blink-title { width:100%; border:none; outline:none; font-size:14px; font-weight:600; color:#212529; background:transparent; padding:0; }
.blink-title::placeholder { color:#adb5bd; }
.blink-url { width:100%; border:none; outline:none; font-size:12px; color:#5c7cfa; background:transparent; padding:0; margin-top:4px; }
.blink-url::placeholder { color:#ced4da; }
.blink-del { width:28px; height:28px; border-radius:6px; border:none; background:transparent; color:#adb5bd; display:flex; align-items:center; justify-content:center; cursor:pointer; flex-shrink:0; transition:all .12s; }
.blink-del:hover { background:#fff5f5; color:#e03131; }

/* Block Body - App */
.block-body-app { display:flex; align-items:center; gap:10px; padding:12px 14px; background:#f8f9fa; border-radius:10px; border:1px solid #e9ecef; }
.bapp-left { display:flex; align-items:center; gap:10px; flex:1; min-width:0; }
.bapp-av { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:17px; font-weight:700; flex-shrink:0; overflow:hidden; }
.bapp-av-img { width:100%; height:100%; object-fit:cover; }
.bapp-av-txt { }
.bapp-info { min-width:0; }
.bapp-name { font-size:14px; font-weight:600; color:#212529; }
.bapp-desc { font-size:11px; color:#868e96; margin-top:1px; }
.bapp-price { font-size:11px; font-weight:600; color:#5c7cfa; flex-shrink:0; }
.bapp-free { color:#40c057; }

/* Spacer */
.blocks-spacer { height:16px; }

/* Meta Bar */
.meta-bar { display:flex; align-items:center; gap:8px; padding:0 20px 12px; }
.meta-btn { display:inline-flex; align-items:center; gap:5px; padding:6px 14px; border-radius:20px; border:1px solid #e9ecef; background:#fff; color:#868e96; font-size:12px; font-weight:500; cursor:pointer; transition:all .12s; }
.meta-btn:active { background:#f8f9fa; }
.meta-cc { margin-left:auto; font-size:11px; color:#ced4da; font-weight:500; }

/* Tags */
.tags-row { display:flex; flex-wrap:wrap; gap:6px; padding:0 20px 12px; }
.tag-chip { display:inline-flex; align-items:center; gap:3px; padding:4px 10px; border-radius:12px; font-size:11px; font-weight:600; color:#5c7cfa; background:#edf2ff; }
.tag-x { width:16px; height:16px; border-radius:50%; border:none; background:rgba(92,124,250,.2); color:#5c7cfa; font-size:10px; display:flex; align-items:center; justify-content:center; cursor:pointer; padding:0; line-height:1; }

/* App Selector */
.appsel { margin:0 20px 12px; border:1px solid #eee; border-radius:14px; overflow:hidden; }
.appsel-hd { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; }
.appsel-title { font-size:13px; font-weight:700; color:#111; }
.appsel-close { width:26px; height:26px; border-radius:50%; border:none; background:#f5f5f5; font-size:16px; color:#999; display:flex; align-items:center; justify-content:center; cursor:pointer; }
.appsel-tabs { display:flex; border-bottom:1px solid #eee; }
.appsel-tabs button { flex:1; padding:10px; border:none; background:none; font-size:12px; font-weight:600; color:#999; cursor:pointer; border-bottom:2px solid transparent; }
.appsel-tab-on { color:#6366f1!important; border-bottom-color:#6366f1!important; }
.appsel-search { display:flex; align-items:center; gap:6px; padding:8px 12px; margin:8px 12px; background:#f5f5f5; border-radius:8px; }
.appsel-input { flex:1; border:none; outline:none; background:transparent; font-size:12px; color:#333; }
.appsel-msg { padding:20px; text-align:center; font-size:12px; color:#bbb; }
.appsel-list { max-height:220px; overflow-y:auto; }
.appsel-item { display:flex; align-items:center; gap:10px; width:100%; padding:10px 14px; border:none; background:none; cursor:pointer; }
.appsel-item:active { background:#f5f5f5; }
.appsel-av { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:13px; font-weight:700; flex-shrink:0; overflow:hidden; }
.appsel-av-img { width:100%; height:100%; object-fit:cover; }
.appsel-info { flex:1; min-width:0; text-align:left; }
.appsel-name { font-size:13px; font-weight:600; color:#222; }
.appsel-meta { font-size:10px; color:#999; }
.appsel-price { font-size:11px; font-weight:600; color:#6366f1; }
.appsel-price-free { color:#22c55e; }

/* Bottom Pad */
.editor-pad { height:20px; }

/* Bottom Bar */
.bottombar { display:flex; align-items:center; justify-content:center; gap:2px; padding:8px 16px; padding-bottom:calc(8px + env(safe-area-inset-bottom,0px)); background:#fff; border-top:1px solid #f0f0f0; flex-shrink:0; }
.bb-btn { width:38px; height:38px; border-radius:10px; border:none; background:transparent; color:#999; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:18px; }
.bb-btn:active { background:#f0f0f0; color:#555; }

/* Modal overlay */
.mo { position:fixed; inset:0; z-index:1000; background:rgba(0,0,0,.35); display:flex; align-items:flex-end; justify-content:center; }
.mp { width:100%; max-width:430px; background:#fff; border-radius:20px 20px 0 0; max-height:80vh; display:flex; flex-direction:column; animation:slideUp .25s ease; }
@keyframes slideUp { from{transform:translateY(100%)} to{transform:translateY(0)} }
.mp-hd { display:flex; align-items:center; justify-content:space-between; padding:16px 18px; border-bottom:1px solid #f0f0f0; flex-shrink:0; }
.mp-title { font-size:16px; font-weight:700; color:#111; }
.mp-x { width:30px; height:30px; border-radius:50%; border:none; background:#f5f5f5; font-size:18px; color:#999; display:flex; align-items:center; justify-content:center; cursor:pointer; }
.mp-bd { flex:1; overflow-y:auto; padding:12px 14px; }
.mp-ft { padding:12px 14px; padding-bottom:calc(12px + env(safe-area-inset-bottom,0px)); border-top:1px solid #f0f0f0; flex-shrink:0; }
.mp-ok { width:100%; padding:12px; border:none; border-radius:14px; background:#6366f1; color:#fff; font-size:15px; font-weight:700; cursor:pointer; }
.mp-ok:active { opacity:.85; }
.mp-item { display:flex; align-items:center; gap:10px; width:100%; padding:12px; border:2px solid #f0f0f0; border-radius:14px; background:#fff; margin-bottom:8px; cursor:pointer; }
.mp-item-on { border-color:#6366f1; background:#fafafe; }
.mp-av { width:40px; height:40px; border-radius:12px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:15px; font-weight:700; flex-shrink:0; }
.mp-info { flex:1; min-width:0; text-align:left; }
.mp-name { font-size:14px; font-weight:600; color:#222; }
.mp-desc { font-size:11px; color:#999; margin-top:2px; }

/* Tag Picker */
.tp-row { display:flex; gap:8px; margin-bottom:12px; }
.tp-input { flex:1; height:40px; border:2px solid #e5e7eb; border-radius:10px; padding:0 12px; font-size:13px; outline:none; }
.tp-input:focus { border-color:#6366f1; }
.tp-btn { padding:0 16px; border:none; border-radius:10px; background:#6366f1; color:#fff; font-size:13px; font-weight:600; cursor:pointer; }
.tp-btn:disabled { opacity:.4; cursor:default; }
.tp-label { font-size:12px; color:#999; margin-bottom:8px; }
.tp-chips { display:flex; flex-wrap:wrap; gap:6px; }
.tp-chip { padding:6px 12px; border:1px solid #e5e5e5; border-radius:14px; background:#fafafa; font-size:12px; color:#555; cursor:pointer; }
.tp-chip:hover:not(:disabled) { border-color:#6366f1; color:#6366f1; }
.tp-chip-off { opacity:.4; cursor:default; }
.tp-list { display:flex; flex-direction:column; gap:4px; max-height:260px; overflow-y:auto; margin-top:8px; }
.tp-item { display:flex; align-items:center; gap:8px; width:100%; padding:10px 12px; border:1px solid #eee; border-radius:10px; background:#fafbfc; font-size:13px; cursor:pointer; text-align:left; transition:all .1s; }
.tp-item:hover { border-color:#c7d2fe; background:#f5f6ff; }
.tp-item-on { border-color:#6366f1; background:#edf2ff; color:#6366f1; font-weight:600; }
.tp-icon { font-size:16px; }
.tp-name { flex:1; }
.tp-count { font-size:11px; color:#adb5bd; }
.tp-empty { padding:20px; text-align:center; color:#adb5bd; font-size:13px; }

/* Form */
.fg { margin-bottom:14px; }
.fg-l { display:block; font-size:12px; font-weight:600; color:#666; margin-bottom:6px; }
.fg-inp { width:100%; height:40px; border:2px solid #e5e7eb; border-radius:10px; padding:0 12px; font-size:13px; outline:none; }
.fg-inp:focus { border-color:#6366f1; }
.fg-btns { display:flex; gap:8px; }
.fg-btn { flex:1; padding:10px; border:2px solid #e5e7eb; border-radius:10px; background:#fff; font-size:13px; font-weight:500; color:#666; cursor:pointer; }
.fg-btn-on { border-color:#6366f1; color:#6366f1; background:#fafafe; }

.hidden { display:none; }
</style>
