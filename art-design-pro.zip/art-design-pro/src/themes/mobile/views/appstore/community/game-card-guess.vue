<script lang="ts">
export default { name: 'GameCardGuessPage' }
</script>

<template>
  <div class="game-page">
    <div class="gp-header">
      <div class="gp-back" @click="$router.back()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg></div>
      <h1 class="gp-title">卡片竞猜</h1>
    </div>

    <div class="gp-toast" v-if="toastMsg" :class="toastType">{{ toastMsg }}</div>

    <div class="gp-body">
      <div class="cg-info">
        <span class="cg-label">我的积分</span>
        <span class="cg-val">{{ userPoints }}</span>
        <span class="cg-cost">每次竞猜 {{ flipCost }} 积分</span>
      </div>

      <div class="cg-cards">
        <div
          v-for="(card, i) in cards"
          :key="i"
          class="cg-card"
          :class="{
            flipped: flippedCards[i],
            win: flippedCards[i] && card.isWin,
            lose: flippedCards[i] && !card.isWin
          }"
          @click="flipCard(i)"
        >
          <div class="cg-card-inner">
            <div class="cg-card-front">
              <span class="cg-card-question">?</span>
            </div>
            <div class="cg-card-back">
              <span class="cg-card-back-label">{{ card.label || card.name }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="cg-result" v-if="lastResult !== null">
        <div :class="['cg-result-text', lastResult ? 'win' : 'lose']">
          {{ lastResult ? '恭喜！翻到了中奖卡' : '很遗憾，未中奖' }}
        </div>
        <div v-if="lastResult" class="cg-result-won">获得 +{{ lastWon }} 积分</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import axios from 'axios'

const userStore = useUserStore()
const config = ref<any>({})
const cards = ref<any[]>([])
const flippedCards = ref<boolean[]>([false, false, false])
const lastResult = ref<boolean | null>(null)
const lastWon = ref(0)
const flipping = ref(false)
const toastMsg = ref('')
const toastType = ref('info')

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg
  toastType.value = type
  setTimeout(() => { toastMsg.value = '' }, 2500)
}

const userPoints = computed(() => userStore.info?.points || 0)
const flipCost = computed(() => config.value.costPerFlip || 10)

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/config/card_guess')
    if (res.data?.config) {
      config.value = res.data.config
      cards.value = res.data.config.cards || [
        { name: 'A', label: '奖', isWin: true },
        { name: 'B', label: '空', isWin: false },
        { name: 'C', label: '空', isWin: false }
      ]
    }
  } catch {}
})

async function flipCard(index: number) {
  if (flipping.value || flippedCards.value[index]) return
  if (userPoints.value < flipCost.value) { showToast('积分不足', 'error'); return }

  flipping.value = true
  flippedCards.value = [false, false, false]
  flippedCards.value[index] = true

  try {
    const { data: res } = await axios.post('/api/game/card-guess/flip', {
      userId: userStore.info?.userId,
      cardIndex: index
    })
    if (res.code !== 200) { showToast(res.msg, 'error'); flipping.value = false; flippedCards.value = [false, false, false]; return }

    cards.value = cards.value.map((c, i) => ({
      ...c,
      isWin: i === index ? res.data.isWin : c.isWin
    }))

    lastResult.value = res.data.isWin
    lastWon.value = res.data.wonPoints
    await refreshUserInfo()
  } catch (e: any) { showToast(e.message, 'error') }
  finally {
    flipping.value = false
    setTimeout(() => {
      flippedCards.value = [false, false, false]
      lastResult.value = null
    }, 2000)
  }
}
async function refreshUserInfo() {
  try {
    const { data: res } = await axios.get('/api/user/info')
    if (res.code === 200) userStore.setUserInfo(res.data)
  } catch {}
}
</script>

<style lang="scss" scoped>
.game-page { min-height: 100vh; background: linear-gradient(180deg, #0f172a, #1e293b); padding-bottom: 40px; }
.gp-toast { position: fixed; top: 56px; left: 16px; right: 16px; z-index: 100; padding: 12px 16px; border-radius: 10px; font-size: 14px; font-weight: 600; text-align: center; animation: toastIn .3s ease; }
.gp-toast.error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
.gp-toast.info { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
@keyframes toastIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.gp-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; }
.gp-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; svg { width: 20px; height: 20px; color: #fff; } }
.gp-title { font-size: 17px; font-weight: 700; color: #fff; }
.gp-body { padding: 0 16px; display: flex; flex-direction: column; align-items: center; }

.cg-info { text-align: center; margin-bottom: 30px; }
.cg-label { font-size: 13px; color: rgba(255,255,255,0.6); display: block; }
.cg-val { font-size: 36px; font-weight: 800; color: #fbbf24; }
.cg-cost { font-size: 12px; color: rgba(255,255,255,0.4); margin-top: 4px; display: block; }

.cg-cards { display: flex; gap: 12px; margin-bottom: 24px; }
.cg-card {
  width: 90px; height: 120px; perspective: 600px; cursor: pointer;
  &.flipped .cg-card-inner { transform: rotateY(180deg); }
}
.cg-card-inner {
  width: 100%; height: 100%; position: relative; transition: transform .5s; transform-style: preserve-3d;
}
.cg-card-front, .cg-card-back {
  position: absolute; inset: 0; backface-visibility: hidden;
  border-radius: 12px; display: flex; align-items: center; justify-content: center;
}
.cg-card-front {
  background: linear-gradient(135deg, #6366f1, #8b5cf6); border: 2px solid rgba(255,255,255,.2);
}
.cg-card-question { font-size: 36px; font-weight: 800; color: rgba(255,255,255,.6); }
.cg-card-back {
  background: #fff; transform: rotateY(180deg);
  &.cg-card-back { border: 2px solid #e5e7eb; }
}
.cg-card-back-label { font-size: 20px; font-weight: 700; color: #333; }
.cg-card.win .cg-card-back { border-color: #4ade80; background: #ecfdf5; }
.cg-card.lose .cg-card-back { border-color: #fca5a5; background: #fef2f2; }

.cg-result { text-align: center; }
.cg-result-text { font-size: 18px; font-weight: 700; &.win { color: #4ade80; } &.lose { color: #f87171; } }
.cg-result-won { font-size: 14px; color: #4ade80; margin-top: 4px; }
</style>
