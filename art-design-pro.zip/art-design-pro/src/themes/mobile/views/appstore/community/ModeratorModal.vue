<template>
  <Teleport to="body">
    <div v-if="visible" class="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 p-4" @click.self="close">
      <div class="bg-white rounded-2xl w-full max-w-md max-h-[75vh] overflow-y-auto" @click.stop>
        <!-- Header -->
        <div class="sticky top-0 bg-white z-10 flex items-center justify-between px-5 pt-5 pb-3 border-b border-gray-100">
          <div class="flex items-center gap-2.5">
            <div class="w-[28px] h-[28px] rounded-lg bg-gradient-to-br from-[#6366F1] to-[#8B5CF6] flex items-center justify-center">
              <svg class="w-3.5 h-3.5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M3 3h18v18H3V3zm4 4v2h2V7H7zm0 4v2h2v-2H7zm0 4v2h2v-2H7zm4-8v2h6V7h-6zm0 4v2h6v-2h-6zm0 4v2h6v-2h-6z"/></svg>
            </div>
            <span class="text-[17px] text-[#1A1A1A] font-bold">版主团队</span>
          </div>
          <div class="w-[32px] h-[32px] rounded-full bg-[#F5F5F5] flex items-center justify-center cursor-pointer active:bg-gray-200" @click="close">
            <svg class="w-4 h-4 text-[#888]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M18 6L6 18M6 6l12 12"/></svg>
          </div>
        </div>

        <!-- Loading -->
        <div v-if="loading" class="flex justify-center py-12">
          <div class="animate-spin w-5 h-5 border-2 border-[#6366F1] border-t-transparent rounded-full"/>
        </div>

        <!-- Empty -->
        <div v-else-if="moderators.length === 0" class="flex flex-col items-center py-16 text-gray-400">
          <svg class="w-14 h-14 mb-3 opacity-25" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
          </svg>
          <span class="text-sm">暂无版主</span>
          <span class="text-xs mt-1 text-gray-300">该板块暂未设置版主</span>
        </div>

        <!-- Moderator list -->
        <div v-else class="px-5 pt-4">
          <div class="text-xs text-gray-400 font-medium mb-3">共 {{ moderators.length }} 位版主</div>
          <div class="space-y-1">
            <div
              v-for="(mod, idx) in moderators"
              :key="mod.userId"
              class="flex items-center gap-3 px-2 py-3 rounded-xl transition-colors"
              :class="{ 'bg-gray-50/50': idx % 2 === 0 }"
            >
              <!-- Avatar -->
              <div class="relative flex-shrink-0">
                <div
                  class="w-[44px] h-[44px] rounded-full flex items-center justify-center font-bold overflow-hidden"
                >
                  <img v-if="mod.userAvatar" :src="mod.userAvatar" class="w-full h-full object-cover"/>
                  <img v-else src="@imgs/user/avatar.webp" class="w-full h-full object-cover" />
                </div>
                <div
                  class="absolute -bottom-0.5 -right-0.5 w-[16px] h-[16px] rounded-full flex items-center justify-center ring-2 ring-white"
                  :style="badgeClass(mod.role)"
                >
                  <svg class="w-[9px] h-[9px] text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                </div>
              </div>

              <!-- Info -->
              <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2">
                  <span class="text-[15px] text-[#1A1A1A] font-semibold">{{ mod.userName }}</span>
                </div>
                <span
                  class="inline-block text-[11px] px-2.5 py-0.5 rounded-full mt-0.5 font-medium"
                  :style="roleClass(mod.role)"
                >{{ mod.role }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { fetchModerators } from '@/api/community'

const props = defineProps<{ visible: boolean; sectionId: number }>()
const emit = defineEmits<{ (e: 'close'): void }>()

const moderators = ref<any[]>([])
const loading = ref(false)

const avatarColors = ['#6366F1','#EC4899','#F97316','#14B8A6','#8B5CF6','#06B6D4','#E11D48','#7C3AED']
function avatarColor(name: string): string {
  let h = 0; for (let i = 0; i < (name||'').length; i++) h = name.charCodeAt(i) + ((h<<5)-h)
  return avatarColors[Math.abs(h) % avatarColors.length]
}

const ROLE_TAG_COLORS = ['#6366F1','#EF4444','#F97316','#16A34A','#8B5CF6','#E11D48','#06B6D4','#EC4899','#F59E0B','#14B8A6']
function roleColor(role: string): string {
  let h = 0; for (let i = 0; i < (role||'').length; i++) h = role.charCodeAt(i) + ((h<<5)-h)
  return ROLE_TAG_COLORS[Math.abs(h) % ROLE_TAG_COLORS.length]
}

function roleClass(role: string) {
  const c = roleColor(role)
  return { background: c + '18', color: c }
}

function badgeClass(role: string) {
  const c = roleColor(role)
  const r = parseInt(c.slice(1,3), 16)
  const g = parseInt(c.slice(3,5), 16)
  const b = parseInt(c.slice(5,7), 16)
  const darken = (v: number) => Math.max(0, Math.round(v * 0.75)).toString(16).padStart(2, '0')
  return { background: `linear-gradient(135deg, ${c}, #${darken(r)}${darken(g)}${darken(b)})` }
}

async function load() {
  if (!props.sectionId) return
  loading.value = true
  try {
    const res: any = await fetchModerators(props.sectionId)
    moderators.value = res?.data || res || []
  } catch {} finally { loading.value = false }
}

function close() { emit('close') }

watch(() => props.visible, (v) => { if (v && props.sectionId) load() })
</script>

<style scoped>
@keyframes slide-up {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.animate-slide-up { animation: slide-up 0.25s ease-out; }
</style>
