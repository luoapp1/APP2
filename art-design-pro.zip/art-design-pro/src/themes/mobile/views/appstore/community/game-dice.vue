<script lang="ts">
export default { name: 'GameDicePage' }
</script>

<template>
  <div class="game-page">
    <div class="gp-header">
      <div class="gp-back" @click="$router.back()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg></div>
      <h1 class="gp-title">大小竞猜</h1>
    </div>

    <div class="gp-toast" v-if="toastMsg" :class="toastType">{{ toastMsg }}</div>

    <div class="gp-body">
      <div class="dice-info">
        <span class="dice-label">我的积分</span>
        <span class="dice-val">{{ userPoints }}</span>
        <span class="dice-cost">每次竞猜 {{ betCost }} 积分</span>
      </div>

      <div class="dice-board">
        <div class="dice-number" :class="{ rolling: rolling }">{{ displayNumber }}</div>
        <div class="dice-range">范围: 1-{{ maxNum }} | {{ threshold }}及以上为大</div>
      </div>

      <div class="dice-actions">
        <button class="dice-btn big" :disabled="rolling || userPoints < betCost" @click="bet('big')">
          押大
        </button>
        <button class="dice-btn small" :disabled="rolling || userPoints < betCost" @click="bet('small')">
          押小
        </button>
      </div>

      <div class="dice-result" v-if="showResult">
        <div :class="['dice-result-text', resultWin ? 'win' : 'lose']">
          {{ resultMsg }}
        </div>
        <div v-if="lastWon > 0" class="dice-result-won">获得 +{{ lastWon }} 积分</div>
      </div>

      <div class="dice-history" v-if="history.length">
        <div class="dice-history-title">最近记录</div>
        <div class="dice-history-list">
          <span v-for="(h, i) in history" :key="i" :class="['dice-history-item', h.win ? 'win' : 'lose']">
            {{ h.number }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/store/modules/user'
import axios from 'axios'

const userStore = useUserStore()
const config = ref<any>({})
const rolling = ref(false)
const displayNumber = ref('?')
const showResult = ref(false)
const resultWin = ref(false)
const resultMsg = ref('')
const lastWon = ref(0)
const history = ref<{ number: number; win: boolean }[]>([])
const toastMsg = ref('')
const toastType = ref('info')

function showToast(msg: string, type = 'info') {
  toastMsg.value = msg
  toastType.value = type
  setTimeout(() => { toastMsg.value = '' }, 2500)
}

const userPoints = computed(() => userStore.info?.points || 0)
const betCost = computed(() => config.value.costPerBet || 10)
const maxNum = computed(() => config.value.maxNumber || 6)
const threshold = computed(() => config.value.threshold || 4)

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/config/dice')
    if (res.data?.config) config.value = res.data.config
  } catch {}
})

async function bet(choice: string) {
  if (rolling.value) return
  if (userPoints.value < betCost.value) { showToast('积分不足', 'error'); return }

  rolling.value = true
  showResult.value = false

  // 滚动动画
  for (let i = 0; i < 15; i++) {
    displayNumber.value = String(Math.floor(Math.random() * maxNum.value) + 1)
    await sleep(40 + i * 8)
  }

  try {
    const { data: res } = await axios.post('/api/game/dice/bet', {
      userId: userStore.info?.userId,
      bet: choice
    })
    if (res.code !== 200) { showToast(res.msg, 'error'); rolling.value = false; return }

    displayNumber.value = String(res.data.number)
    resultWin.value = res.data.isWin
    lastWon.value = res.data.wonPoints
    resultMsg.value = `开出 ${res.data.number} (${res.data.isBig ? '大' : '小'})，你押了${choice === 'big' ? '大' : '小'}`
    showResult.value = true

    history.value.unshift({ number: res.data.number, win: res.data.isWin })
    if (history.value.length > 20) history.value.pop()

    await refreshUserInfo()
  } catch (e: any) { showToast(e.message, 'error') }
  finally { rolling.value = false }
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }
async function refreshUserInfo() {
  try {
    const { data: res } = await axios.get('/api/user/info')
    if (res.code === 200) userStore.setUserInfo(res.data)
  } catch {}
}
</script>

<style lang="scss" scoped>
.game-page { min-height: 100vh; background: linear-gradient(180deg, #1a1a2e, #16213e); padding-bottom: 40px; }
.gp-toast { position: fixed; top: 56px; left: 16px; right: 16px; z-index: 100; padding: 12px 16px; border-radius: 10px; font-size: 14px; font-weight: 600; text-align: center; animation: toastIn .3s ease; }
.gp-toast.error { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
.gp-toast.info { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
@keyframes toastIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.gp-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; }
.gp-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; svg { width: 20px; height: 20px; color: #fff; } }
.gp-title { font-size: 17px; font-weight: 700; color: #fff; }
.gp-body { padding: 0 16px; display: flex; flex-direction: column; align-items: center; }

.dice-info { text-align: center; margin-bottom: 24px; }
.dice-label { font-size: 13px; color: rgba(255,255,255,0.6); display: block; }
.dice-val { font-size: 36px; font-weight: 800; color: #fbbf24; }
.dice-cost { font-size: 12px; color: rgba(255,255,255,0.4); margin-top: 4px; display: block; }

.dice-board { text-align: center; margin-bottom: 28px; }
.dice-number {
  font-size: 80px; font-weight: 900; color: #fff; width: 140px; height: 140px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 28px;
  display: flex; align-items: center; justify-content: center; margin: 0 auto 12px;
  &.rolling { animation: shake .15s infinite; }
}
@keyframes shake { 0%,100% { transform: translateX(0) } 25% { transform: translateX(-4px) } 75% { transform: translateX(4px) } }
.dice-range { font-size: 13px; color: rgba(255,255,255,0.45); }

.dice-actions { display: flex; gap: 16px; margin-bottom: 20px; }
.dice-btn {
  width: 120px; padding: 14px 0; border: none; border-radius: 16px;
  font-size: 18px; font-weight: 800; cursor: pointer; transition: all .2s;
  &:disabled { opacity: 0.5; cursor: not-allowed; }
}
.dice-btn.big { background: linear-gradient(135deg, #ef4444, #dc2626); color: #fff; }
.dice-btn.small { background: linear-gradient(135deg, #3b82f6, #2563eb); color: #fff; }

.dice-result { text-align: center; margin-bottom: 20px; }
.dice-result-text { font-size: 18px; font-weight: 700; &.win { color: #4ade80; } &.lose { color: #f87171; } }
.dice-result-won { font-size: 14px; color: #4ade80; margin-top: 4px; }

.dice-history { width: 100%; max-width: 300px; }
.dice-history-title { font-size: 13px; color: rgba(255,255,255,0.4); margin-bottom: 8px; }
.dice-history-list { display: flex; flex-wrap: wrap; gap: 6px; }
.dice-history-item {
  width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 600;
  &.win { background: rgba(74,222,128,0.2); color: #4ade80; }
  &.lose { background: rgba(248,113,113,0.15); color: #f87171; }
}
</style>
