<script lang="ts">
export default { name: 'GameHallPage' }
</script>

<template>
  <div class="game-hall-page">
    <div class="gh-header">
      <div class="gh-back" @click="$router.back()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6" /></svg>
      </div>
      <h1 class="gh-title">游戏大厅</h1>
    </div>

    <div class="gh-banner">
      <div class="gh-banner-bg" />
      <div class="gh-banner-content">
        <div class="gh-banner-title">畅玩游戏 赢取积分</div>
        <div class="gh-banner-sub">多种趣味游戏等你来挑战</div>
      </div>
    </div>

    <div class="gh-games">
      <div
        v-for="game in games"
        :key="game.gameType"
        class="gh-game-card"
        :class="{ disabled: !game.enabled }"
        @click="enterGame(game)"
      >
        <div class="gh-game-icon">
          <span class="gh-game-emoji">{{ game.icon }}</span>
        </div>
        <div class="gh-game-info">
          <div class="gh-game-name">{{ game.name }}</div>
          <div class="gh-game-desc">{{ game.desc }}</div>
          <div class="gh-game-stats" v-if="game.enabled">
            <span>{{ game.todayCount || 0 }}人参与</span>
          </div>
          <div class="gh-game-disabled" v-else>维护中</div>
        </div>
        <div class="gh-game-arrow">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6" /></svg>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const games = ref<any[]>([])

onMounted(async () => {
  try {
    const { data: res } = await axios.get('/api/game/list')
    games.value = res.data || []
  } catch {}
})

function enterGame(game: any) {
  if (!game.enabled) return
  const routes: Record<string, string> = {
    lottery: '/community/game-hall/lottery',
    card_guess: '/community/game-hall/card-guess',
    dice: '/community/game-hall/dice',
    rps: '/community/game-hall/rps'
  }
  const path = routes[game.gameType]
  if (path) router.push(path)
}
</script>

<style lang="scss" scoped>
.game-hall-page { min-height: 100vh; background: #f5f5f7; padding-bottom: 40px; }
.gh-header {
  position: sticky; top: 0; z-index: 10;
  display: flex; align-items: center; gap: 12px; padding: 12px 16px;
  background: #fff; border-bottom: 1px solid #f0f0f0;
}
.gh-back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; svg { width: 20px; height: 20px; color: #333; } }
.gh-title { font-size: 17px; font-weight: 700; color: #1a1a1a; }
.gh-banner {
  margin: 12px 16px; border-radius: 16px; overflow: hidden; position: relative; height: 120px;
  display: flex; align-items: center; padding: 0 24px;
}
.gh-banner-bg {
  position: absolute; inset: 0;
  background: linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899);
  &::after { content: ''; position: absolute; right: -30px; top: -30px; width: 140px; height: 140px; border-radius: 50%; background: rgba(255,255,255,0.1); }
}
.gh-banner-content { position: relative; z-index: 1; }
.gh-banner-title { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 4px; }
.gh-banner-sub { font-size: 13px; color: rgba(255,255,255,0.75); }
.gh-games { margin: 0 16px; display: flex; flex-direction: column; gap: 10px; }
.gh-game-card {
  display: flex; align-items: center; gap: 14px;
  background: #fff; border-radius: 16px; padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04); cursor: pointer;
  transition: transform .15s, box-shadow .15s;
  &:active { transform: scale(0.985); }
  &.disabled { opacity: 0.55; cursor: not-allowed; }
}
.gh-game-icon { width: 52px; height: 52px; border-radius: 14px; background: linear-gradient(135deg, #f0f0ff, #e8e8ff); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.gh-game-emoji { font-size: 28px; line-height: 1; }
.gh-game-info { flex: 1; min-width: 0; }
.gh-game-name { font-size: 15px; font-weight: 700; color: #1a1a1a; margin-bottom: 2px; }
.gh-game-desc { font-size: 12px; color: #999; margin-bottom: 4px; }
.gh-game-stats { font-size: 11px; color: #6366f1; }
.gh-game-disabled { font-size: 11px; color: #ccc; }
.gh-game-arrow { flex-shrink: 0; svg { width: 18px; height: 18px; color: #ccc; } }
</style>
