<template>
  <div class="success-page">
    <div class="su-header">
      <div class="su-back" @click="goBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <div class="su-title">提交完成</div>
    </div>

    <div class="su-content">
      <!-- 成功图标 -->
      <div class="su-icon-wrap">
        <div class="su-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 6L9 17l-5-5"/>
          </svg>
        </div>
        <div class="su-title-text">发布成功</div>
        <div class="su-sub-text">{{ savingDraft ? '已保存为草稿，请提交审核' : '已提交审核，请等待管理员审核' }}</div>
        <div class="su-sub-text su-sub-wait">审核通过后将会在应用商店中展示</div>
      </div>

      <!-- 应用预览卡 -->
      <div class="su-app-card">
        <div class="su-app-icon" :style="{ background: preview.bgColor || '#00BFA5' }">
          <img v-if="preview.icon" :src="$fixImgUrl(preview.icon)" style="width: 100%; height: 100%; object-fit: cover;" />
          <svg v-else width="28" height="28" viewBox="0 0 24 24" fill="currentColor" style="color:#fff"><path d="M8 5v14l11-7z"/></svg>
        </div>
        <div class="su-app-info">
          <div class="su-app-name">
            {{ preview.name || '未命名应用' }}
            <span :class="['su-app-status', savingDraft ? 'status-draft' : 'status-pending']">{{ savingDraft ? '草稿' : '审核中' }}</span>
          </div>
          <div class="su-app-meta">{{ preview.packageName }}</div>
          <div class="su-app-meta">{{ preview.category }} | v{{ preview.version }} | {{ preview.sizeMb }}MB</div>
        </div>
      </div>

      <!-- 底部操作 -->
    </div>

    <div class="su-bottom-bar">
      <button class="su-btn-back" @click="goList">返回投稿列表</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { fetchSubmitReview } from '@/api/submission'

const router = useRouter()
const route = useRoute()

const savingDraft = ref(route.query.draft === '1')
const preview = reactive({
  id: Number(route.query.id) || 0,
  name: (route.query.name as string) || '',
  packageName: (route.query.packageName as string) || '',
  category: (route.query.category as string) || '',
  version: (route.query.version as string) || '',
  sizeMb: (route.query.sizeMb as string) || '0',
  icon: (route.query.icon as string) || '',
  bgColor: '#00BFA5'
})

function goBack() {
  if (window.history.length > 1) {
    router.back()
  } else {
    router.push('/appstore/submissions')
  }
}

function goList() {
  router.push('/appstore/submissions')
}

async function handleSubmitReview() {
  if (!preview.id) return
  try {
    await fetchSubmitReview(preview.id)
    ElMessage.success('已提交审核')
    savingDraft.value = false
  } catch {
    ElMessage.error('提交失败')
  }
}

onMounted(() => {
  if (!preview.name && !preview.id) {
    // 没有数据，返回列表
    // goList()
  }
})
</script>

<style lang="scss" scoped>
.success-page {
  min-height: 100vh;
  background: #f5f6fa;
  display: flex;
  flex-direction: column;
}

.su-header {
  display: flex;
  align-items: center;
  padding: 48px 16px 14px;
  background: #fff;
  gap: 12px;
}

.su-back {
  cursor: pointer;
  flex-shrink: 0;
}

.su-title {
  font-size: 17px;
  font-weight: 600;
  color: #1a1a1a;
}

.su-content {
  flex: 1;
  padding-bottom: 100px;
}

.su-icon-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 40px 0 24px;
}

.su-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #24D6C4, #1BBFAE);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 24px rgba(36, 214, 196, 0.35);
  margin-bottom: 16px;
}

.su-title-text {
  font-size: 20px;
  font-weight: 600;
  color: #1a1a1a;
}

.su-sub-text {
  font-size: 13px;
  color: #999;
  margin-top: 6px;
}

.su-sub-wait {
  color: #bbb;
  margin-top: 4px;
}

.su-app-card {
  background: #fff;
  margin: 0 16px;
  border-radius: 14px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 14px;
}

.su-app-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
}

.su-app-info {
  flex: 1;
  min-width: 0;
}

.su-app-name {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a1a;
  display: flex;
  align-items: center;
  gap: 8px;
}

.su-app-status {
  font-size: 11px;
  font-weight: 500;
  padding: 2px 8px;
  border-radius: 10px;

  &.status-draft {
    background: #fff7e6;
    color: #fa8c16;
  }

  &.status-pending {
    background: #e6f0ff;
    color: #3B82F6;
  }
}

.su-app-meta {
  font-size: 12px;
  color: #999;
  margin-top: 3px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.su-bottom-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 12px 16px calc(12px + env(safe-area-inset-bottom));
  background: #fff;
  display: flex;
  gap: 10px;
}

.su-btn-review {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 12px;
  background: linear-gradient(135deg, #24D6C4, #1BBFAE);
  color: #fff;
  font-size: 15px;
  font-weight: 500;
  cursor: pointer;

  &:disabled {
    opacity: 0.6;
  }
}

.su-btn-back {
  flex: 1;
  padding: 14px;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  background: #fff;
  color: #666;
  font-size: 15px;
  cursor: pointer;
}
</style>
