<template>
  <div class="page">
    <div class="header">
      <div class="header-back" @click="handleGoBack">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <div class="header-title">我的投稿</div>
      <div class="header-action" @click="searchFocused = true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      </div>
    </div>

    <div class="stats">
      <div class="stat">
        <div class="stat-num">{{ stats.totalDownloads }}</div>
        <div class="stat-label">总下载</div>
      </div>
      <div class="stat">
        <div class="stat-num">{{ stats.totalReviews }}</div>
        <div class="stat-label">评价</div>
      </div>
      <div class="stat">
        <div class="stat-num">{{ stats.totalFiveStar }}</div>
        <div class="stat-label">五星</div>
      </div>
      <div class="stat">
        <div class="stat-num">{{ stats.totalSubmissions }}</div>
        <div class="stat-label">投稿</div>
      </div>
      <div class="stat">
        <div class="stat-num">{{ stats.totalCoins }}</div>
        <div class="stat-label">投币</div>
      </div>
    </div>

    <div class="tabs">
      <button v-for="tab in statusTabs" :key="tab.value" :class="['tab', { active: activeStatus === tab.value }]" @click="activeStatus = tab.value; fetchData()">{{ tab.label }}</button>
    </div>

    <div class="search-box">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      <input ref="searchInputRef" v-model="searchKeyword" class="search-inp" placeholder="搜索应用名称" @keyup.enter="fetchData" />
      <button v-if="searchKeyword" class="search-clear" @click="searchKeyword = ''; fetchData()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    </div>

    <div class="list">
      <div v-if="!loading && tableData.length === 0" class="empty">
        <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
          <rect x="16" y="10" width="48" height="48" rx="10" stroke="#e2e8f0" stroke-width="2" fill="#f8fafc"/>
          <rect x="24" y="22" width="32" height="4" rx="2" fill="#e2e8f0"/>
          <rect x="30" y="30" width="20" height="3" rx="1.5" fill="#e2e8f0"/>
          <rect x="33" y="37" width="14" height="3" rx="1.5" fill="#e2e8f0"/>
          <circle cx="40" cy="50" r="12" stroke="#e2e8f0" stroke-width="1.5" fill="white"/>
          <path d="M40 44v12M34 50h12" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <p>暂无投稿</p>
        <button class="empty-btn" @click="showDrawer = true">立即投稿</button>
      </div>

      <div v-else class="cards">
        <div v-for="group in groupedApps" :key="group.packageName" class="card">
          <div class="card-main">
            <div class="card-icon" :style="{ background: group.iconBgColor || iconColor(group.name) }">
              <img v-if="group.icon" :src="$fixImgUrl(group.icon)" />
              <span v-else>{{ (group.name || '?')[0] }}</span>
            </div>
            <div class="card-body">
              <div class="card-name">{{ group.name }}</div>
              <div class="card-meta">{{ formatCategory(group.category) }} &middot; v{{ group.latestVersion }} &middot; {{ group.sizeMb }}MB</div>
              <div class="card-row">
                <span class="card-stat-item">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 12m4-4v12"/></svg>
                  {{ group.downloads || 0 }}
                </span>
                <span class="card-stat-item">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                  {{ group.reviews || 0 }}
                </span>
                <span class="card-stat-item">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 100 4h4a2 2 0 010 4H8m4-12v16"/></svg>
                  {{ group.coins || 0 }}
                </span>
                <span class="card-time">{{ group.createTime }}</span>
              </div>
            </div>
            <div class="card-actions">
              <button class="btn btn-primary" @click="handleNewVersion(group)">上传新版本</button>
              <button v-if="group.latestApprovedItem" class="btn btn-outline" @click="handleEdit(group.latestApprovedItem)">编辑</button>
              <div class="ver-row">
                <button class="ver-toggle-inline" @click="toggleVersions(group.packageName)">
                  {{ group.versions.length }} 个版本
                  <svg :class="{ open: expandedPackages.has(group.packageName) }" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>
                </button>
                <button v-if="group.hasApproved" class="btn btn-warn" @click="handleRemove(group.latestApprovedItem)">下架</button>
              </div>
              <button v-if="group.hasRemoved" class="btn btn-outline" @click="handleRelist(group.latestRemovedItem)">上架</button>
            </div>
          </div>

          <div v-if="expandedPackages.has(group.packageName)" class="ver-list">
            <div v-for="ver in group.versions" :key="ver.id" class="ver-item">
              <div class="ver-left">
                <span class="ver-dot" :style="{ background: priceColor(ver) }" />
                <span class="ver-v">v{{ ver.version }}</span>
                <span class="ver-tag" :style="{ color: priceColor(ver), background: priceColor(ver) + '14' }">{{ formatPrice(ver) }}</span>
                <span class="ver-time">{{ ver.createTime }}</span>
              </div>
              <div class="ver-actions">
                <button v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'approved'" class="btn-sm btn-outline" @click="handleEdit(ver)">编辑</button>
                <button v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'rejected'" class="btn-sm btn-primary" @click="handleSubmit(ver)">提交</button>
                <button v-if="ver.submissionStatus === 'approved'" class="btn-sm btn-warn" @click="handleRemove(ver)">下架</button>
                <button v-if="ver.submissionStatus === 'removed'" class="btn-sm btn-outline" @click="handleRelist(ver)">上架</button>
                <button v-if="ver.submissionStatus === 'draft' || ver.submissionStatus === 'rejected'" class="btn-sm btn-danger" @click="handleDelete(ver)">删除</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="total > pageSize" class="pager">
      <el-pagination v-model:current-page="page" :page-size="pageSize" :total="total" layout="prev, pager, next" @current-change="fetchData" />
    </div>

    <button class="fab" @click="showDrawer = true">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
    </button>

    <div v-if="showDrawer" class="overlay" @click="showDrawer = false" />
    <div :class="['sheet', { open: showDrawer }]">
      <div class="sheet-bar" />
      <div class="sheet-item" @click="handleSubmitFromFile">
        <div class="sheet-icon" style="background:#e6f9f6">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#00BFA5" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>
        </div>
        <span>选择安装包文件</span>
      </div>
      <div class="sheet-item" @click="handleSubmitFromInstalled">
        <div class="sheet-icon" style="background:#f3e8ff">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9333ea" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
        </div>
        <span>已安装的应用</span>
      </div>
      <button class="sheet-cancel" @click="showDrawer = false">取消</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/modules/user'
import {
  fetchSubmissionStats,
  fetchSubmissionList,
  fetchSubmitReview,
  fetchUpdateSubmissionStatus,
  fetchDeleteSubmission,
  fetchSubmissionVersions
} from '@/api/submission'

const router = useRouter()
const userStore = useUserStore()
const userId = computed(() => userStore.getUserInfo.userId)
const userName = computed(() => userStore.getUserInfo.userName || userStore.getUserInfo.nickname || '')

const loading = ref(false)
const searchKeyword = ref('')
const searchFocused = ref(false)
const searchInputRef = ref<HTMLInputElement>()
const activeStatus = ref('')
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const tableData = ref<any[]>([])
const showDrawer = ref(false)
const expandedPackages = reactive(new Set<string>())
const versionCache = reactive<Record<string, any[]>>({})
const versionLoading = reactive<Record<string, boolean>>({})

const colorPool = ['#4F8AF7', '#6C5CE7', '#00BFA5', '#F97316', '#EC4899', '#EF4444', '#8B5CF6', '#10B981', '#3B82F6', '#F59E0B']
const iconColor = (name: string) => {
  const hash = (name || '').split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
}

const stats = reactive({
  totalSubmissions: 0, totalDownloads: 0, totalReviews: 0, totalFiveStar: 0, totalCoins: 0
})

const statusTabs = [
  { label: '全部', value: '' },
  { label: '审核中', value: 'pending' },
  { label: '未通过', value: 'rejected' },
  { label: '下架', value: 'removed' },
  { label: '草稿', value: 'draft' }
]

function formatCategory(cat: string): string {
  try {
    const arr = JSON.parse(cat)
    if (Array.isArray(arr)) return arr.join(', ')
  } catch {}
  return cat || ''
}

function statusLabel(s: string): string {
  const map: Record<string, string> = { pending: '审核中', approved: '已通过', rejected: '未通过', removed: '已下架', draft: '草稿' }
  return map[s] || s || ''
}
function statusStyle(s: string) {
  const map: Record<string, Record<string, string>> = {
    pending: { color: '#d97706', background: '#fffbeb' },
    approved: { color: '#059669', background: '#ecfdf5' },
    rejected: { color: '#dc2626', background: '#fef2f2' },
    removed: { color: '#6b7280', background: '#f3f4f6' },
    draft: { color: '#6366f1', background: '#eef2ff' }
  }
  return map[s] || { color: '#6b7280', background: '#f3f4f6' }
}

function formatPrice(item: any): string {
  const pt = item.priceType || item.price_type || 'free'
  const pa = Number(item.priceAmount || item.price_amount || 0)
  if (pt === 'free' || pa <= 0) return '免费'
  if (pt === 'balance') return `${pa} 元`
  if (pt === 'points') return `${pa} 积分`
  return '免费'
}

function priceColor(item: any): string {
  const pt = item.priceType || item.price_type || 'free'
  if (pt === 'free') return '#10B981'
  if (pt === 'balance') return '#F59E0B'
  if (pt === 'points') return '#8B5CF6'
  return '#10B981'
}

async function fetchStats() {
  try {
    const d: any = await fetchSubmissionStats(userId.value)
    if (d) {
      stats.totalSubmissions = d.totalSubmissions || 0
      stats.totalDownloads = d.totalDownloads || 0
      stats.totalReviews = d.totalReviews || 0
      stats.totalFiveStar = d.totalFiveStar || 0
      stats.totalCoins = d.totalCoins || 0
    }
  } catch {}
}

async function fetchData() {
  loading.value = true
  try {
    const data: any = await fetchSubmissionList({
      userId: userId.value, status: activeStatus.value, keyword: searchKeyword.value,
      page: page.value, pageSize: pageSize.value
    })
    if (data) { tableData.value = data.list || []; total.value = data.total || 0 }
  } catch {} finally { loading.value = false }
}

const groupedApps = computed(() => {
  const map = new Map<string, any[]>()
  for (const item of tableData.value) {
    const key = item.packageName || item.package_name || ''
    if (!key) { map.set('_single_' + item.id, [item]); continue }
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(item)
  }
  return Array.from(map.entries()).map(([pkg, versions]) => {
    versions.sort((a: any, b: any) => b.id - a.id)
    if (versionCache[pkg]) {
      const idMap = new Map<number, any>()
      for (const v of versionCache[pkg]) { idMap.set(v.id, v) }
      for (const v of versions) { idMap.set(v.id, v) }
      versionCache[pkg] = Array.from(idMap.values())
    } else {
      versionCache[pkg] = [...versions]
    }
    versionCache[pkg].sort((a: any, b: any) => b.id - a.id)

    const latest = versions[0]
    const approved = versions.find((v: any) => v.submissionStatus === 'approved')
    const removed = versions.find((v: any) => v.submissionStatus === 'removed')
    return {
      packageName: pkg, name: latest.name, icon: latest.icon,
      iconBgColor: latest.iconBgColor, category: latest.category,
      latestVersion: latest.version, latestStatus: latest.submissionStatus,
      sizeMb: latest.sizeMb, createTime: latest.createTime,
      downloads: approved ? approved.downloads : 0,
      reviews: approved ? approved.reviews : 0,
      coins: approved ? approved.coins : 0,
      hasApproved: !!approved, latestApprovedItem: approved,
      hasRemoved: !!removed && !approved, latestRemovedItem: removed,
      versions: versionCache[pkg], id: latest.id,
      priceType: latest.priceType || latest.price_type || 'free',
      priceAmount: Number(latest.priceAmount || latest.price_amount || 0),
      isFree: latest.isFree !== undefined ? !!latest.isFree : true
    }
  })
})

async function toggleVersions(packageName: string) {
  if (expandedPackages.has(packageName)) { expandedPackages.delete(packageName); return }
  expandedPackages.add(packageName)
  if (versionLoading[packageName]) return
  versionLoading[packageName] = true
  try {
    const data: any = await fetchSubmissionVersions({ packageName, userId: userId.value })
    if (data?.list) { versionCache[packageName] = data.list }
  } catch {} finally { versionLoading[packageName] = false }
}

function handleSubmitFromFile() { showDrawer.value = false; router.push('/appstore/submissions/file-picker') }
function handleSubmitFromInstalled() { showDrawer.value = false; ElMessage.info('已安装应用选择功能开发中') }

function handleNewVersion(group: any) {
  showDrawer.value = false
  router.push({
    path: '/appstore/submissions/edit',
    query: {
      newVersion: '1', baseId: String(group.id), name: group.name,
      packageName: group.packageName || '', category: group.category || '工具',
      version: bumpVersion(group.latestVersion || '1.0.0'), sizeMb: String(group.sizeMb || 0)
    }
  })
}

function bumpVersion(ver: string): string {
  const parts = ver.split('.').map(Number)
  if (parts.length >= 2) { parts[parts.length - 1]++ }
  return parts.join('.')
}

function handleEdit(item: any) {
  router.push({
    path: '/appstore/submissions/edit',
    query: { id: String(item.id), name: item.name, packageName: item.packageName || '',
      category: item.category || '工具', version: item.version || '1.0.0', sizeMb: String(item.sizeMb || 0) }
  })
}

async function handleSubmit(item: any) {
  try {
    await ElMessageBox.confirm(`确定将「${item.name}」提交审核吗？`, '提交审核', {
      confirmButtonText: '确定', cancelButtonText: '取消', type: 'info'
    })
    await fetchSubmitReview(item.id)
    ElMessage.success('已提交审核')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData(); await fetchStats()
  } catch {}
}

async function handleDelete(item: any) {
  try {
    await ElMessageBox.confirm(`确定删除「${item.name}」吗？此操作不可恢复。`, '删除确认', {
      confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'warning'
    })
    await fetchDeleteSubmission(item.id)
    ElMessage.success('已删除')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData(); await fetchStats()
  } catch {}
}

async function handleRemove(item: any) {
  try {
    await ElMessageBox.confirm(`确定下架「${item.name}」吗？`, '下架确认', {
      confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning'
    })
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'removed', reviewBy: userName.value, role: '', userId: userStore.info?.id || userId.value
    })
    ElMessage.success('已下架')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData(); await fetchStats()
  } catch {}
}

async function handleRelist(item: any) {
  try {
    await ElMessageBox.confirm(`确定重新上架「${item.name}」吗？`, '重新上架确认', {
      confirmButtonText: '确定', cancelButtonText: '取消', type: 'info'
    })
    await fetchUpdateSubmissionStatus(item.id, {
      submissionStatus: 'approved', reviewBy: userName.value, role: '', userId: userStore.info?.id || userId.value
    })
    ElMessage.success('已重新上架')
    const pkg = item.packageName || item.package_name
    if (pkg) delete versionCache[pkg]
    await fetchData(); await fetchStats()
  } catch {}
}

onMounted(() => { fetchStats(); fetchData() })

function handleGoBack() {
  if (window.history.length > 1) { router.back() } else { router.push('/appstore/mine') }
}

watch(searchFocused, (val) => {
  if (val) { nextTick(() => { searchInputRef.value?.focus() }); searchFocused.value = false }
})
</script>

<style lang="scss" scoped>
.page {
  min-height: 100vh;
  background: #f5f7fa;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: 120px;
  -webkit-tap-highlight-color: transparent;
  * { -webkit-tap-highlight-color: transparent; outline: none; }
}

.header {
  display: flex;
  align-items: center;
  padding: 16px 16px 12px;
  gap: 8px;
  background: #fff;
  margin-top: calc(-1 * env(safe-area-inset-top, 0px));
  padding-top: calc(16px + env(safe-area-inset-top, 0px));
  position: sticky;
  top: 0;
  z-index: 50;
}
.header-back, .header-action {
  width: 36px; height: 36px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; color: #333; border-radius: 10px;
  &:active { background: #f3f4f6; }
}
.header-title {
  flex: 1; font-size: 18px; font-weight: 700; color: #111;
}

.stats {
  display: flex;
  padding: 12px 16px 16px;
  gap: 8px;
  background: #fff;
}
.stat {
  flex: 1; text-align: center;
}
.stat-num {
  font-size: 18px; font-weight: 800; color: #1e293b; line-height: 1.2;
}
.stat-label {
  font-size: 11px; color: #94a3b8; margin-top: 2px;
}

.tabs {
  display: flex;
  gap: 6px;
  padding: 0 16px 12px;
  background: #fff;
  overflow-x: auto;
  position: sticky;
  top: calc(64px + env(safe-area-inset-top, 0px));
  z-index: 49;
  will-change: transform;
}
.tab {
  padding: 6px 14px;
  border-radius: 20px;
  border: 1px solid #e5e7eb;
  background: #fff;
  font-size: 13px;
  color: #64748b;
  cursor: pointer;
  white-space: nowrap;
  transition: all .15s;
  &.active {
    background: #111;
    color: #fff;
    border-color: #111;
  }
}

.search-box {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 16px 14px;
  padding: 10px 14px;
  background: #fff;
  border-radius: 10px;
  border: 1.5px solid transparent;
  transition: all .2s;
  &:focus-within {
    border-color: #d1d5db;
  }
}
.search-inp {
  flex: 1; border: none; outline: none; background: transparent;
  font-size: 14px; color: #333; -webkit-appearance: none;
  &::placeholder { color: #b0b8c1; }
}
.search-clear {
  width: 20px; height: 20px;
  display: flex; align-items: center; justify-content: center;
  border: none; background: none; cursor: pointer; padding: 0;
  border-radius: 50%;
  &:active { background: #e5e7eb; }
}

.list { padding: 0 16px; }

.empty {
  text-align: center; padding: 80px 0;
  svg { display: block; margin: 0 auto 16px; }
  p { font-size: 14px; color: #94a3b8; margin: 0 0 16px; }
}
.empty-btn {
  padding: 10px 32px; border-radius: 24px; background: #111; color: #fff;
  font-size: 14px; font-weight: 600; border: none; cursor: pointer;
}

.cards { display: flex; flex-direction: column; gap: 10px; }

.card {
  background: #fff; border-radius: 12px; padding: 16px;
  box-shadow: 0 1px 2px rgba(0,0,0,.04);
}
.card-main { display: flex; gap: 12px; }
.card-icon {
  width: 48px; height: 48px; border-radius: 13px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; overflow: hidden;
  img { width: 100%; height: 100%; object-fit: cover; }
  span { color: #fff; font-size: 18px; font-weight: 700; }
}
.card-body { flex: 1; min-width: 0; }
.card-name {
  font-size: 15px; font-weight: 700; color: #0f172a;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.card-meta {
  font-size: 12px; color: #94a3b8; margin-top: 2px;
}
.card-row {
  display: flex; align-items: center; gap: 12px; margin-top: 6px;
}
.card-stat-item {
  display: flex; align-items: center; gap: 3px;
  font-size: 11px; color: #94a3b8;
}
.card-time {
  font-size: 11px; color: #cbd5e1; margin-left: auto;
}

.card-actions {
  display: flex; flex-direction: column; gap: 5px; flex-shrink: 0; align-items: stretch;
  margin-top: 2px;
}

.card-actions .btn {
  padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 500;
}

.ver-row {
  display: flex; gap: 5px; align-items: center;
}
.ver-toggle-inline {
  display: flex; align-items: center; gap: 3px;
  padding: 4px 8px; border-radius: 6px; border: none;
  background: #f5f7fa; color: #64748b;
  font-size: 11px; font-weight: 500; cursor: pointer;
  svg { transition: transform .2s; }
  svg.open { transform: rotate(180deg); }
  &:active { background: #eef0f5; }
}

.btn {
  padding: 7px 16px; border-radius: 10px; border: none;
  font-size: 12px; font-weight: 600; cursor: pointer;
  &:active { transform: scale(.96); }
}
.btn-primary { background: #111; color: #fff; }
.btn-outline { background: #f5f7fa; color: #374151; }
.btn-warn { background: #fff7ed; color: #ea580c; }
.btn-danger { background: #fef2f2; color: #ef4444; }

.ver-list {
  margin-top: 6px; padding-top: 4px;
  animation: slideIn .2s ease;
}
.ver-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 14px; border-radius: 10px; background: #f8fafc; margin-bottom: 6px;
}
.ver-left { display: flex; align-items: center; gap: 8px; }
.ver-dot {
  width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0;
}
.ver-v { font-size: 13px; font-weight: 700; color: #1e293b; }
.ver-tag {
  font-size: 10px; font-weight: 600; padding: 1px 6px; border-radius: 6px;
}
.ver-time { font-size: 11px; color: #94a3b8; }
.ver-actions { display: flex; gap: 6px; }

.btn-sm {
  padding: 5px 10px; border-radius: 8px; border: none;
  font-size: 11px; font-weight: 600; cursor: pointer;
  &:active { transform: scale(.96); }
}

.pager { display: flex; justify-content: center; padding: 20px 0; }

.fab {
  position: fixed; bottom: 80px; right: 20px;
  width: 54px; height: 54px; border-radius: 16px;
  background: #111; border: none;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; z-index: 1000;
  box-shadow: 0 4px 20px rgba(0,0,0,.15);
  &:active { transform: scale(.92); }
}

.overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,.4); z-index: 2000;
}

.sheet {
  position: fixed; bottom: 0; left: 0; right: 0;
  background: #fff; border-radius: 20px 20px 0 0;
  padding: 16px 20px calc(20px + env(safe-area-inset-bottom));
  z-index: 2001;
  transform: translateY(100%);
  transition: transform .3s cubic-bezier(.4,0,.2,1);
  &.open { transform: translateY(0); }
}
.sheet-bar {
  width: 36px; height: 5px; background: #e5e7eb;
  border-radius: 3px; margin: 0 auto 20px;
}
.sheet-item {
  display: flex; align-items: center; gap: 14px;
  padding: 14px 6px; cursor: pointer; border-radius: 14px;
  font-size: 15px; font-weight: 600; color: #1e293b;
  &:active { background: #f8fafc; }
}
.sheet-icon {
  width: 46px; height: 46px; border-radius: 13px;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.sheet-cancel {
  width: 100%; padding: 14px; margin-top: 12px;
  border: none; background: #f5f7fa; color: #64748b;
  font-size: 15px; font-weight: 600; border-radius: 14px; cursor: pointer;
}

@keyframes slideIn {
  from { opacity: 0; transform: translateY(-6px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
