<template>
  <div class="ef-page">
    <div class="ef-header">
      <div class="ef-back" @click="goBack">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </div>
      <div class="ef-title">{{ isNewVersion ? '上传新版本' : '发布应用' }}</div>
    </div>

    <div class="ef-body">
      <!-- APK 文件选择 / 信息卡 -->
      <div class="apk-section">
        <label v-if="!apkParsing && !apkData" class="apk-dropzone" @click="triggerApkInput">
          <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#3DDC84" stroke-width="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          <span class="apk-dropzone-title">选择 .apk 安装文件</span>
          <span class="apk-dropzone-sub">最大 200MB</span>
        </label>
        <input ref="apkInput" type="file" accept=".apk,application/vnd.android.package-archive" class="apk-file-input" @change="onApkSelect" />
        <input ref="iconInput" type="file" accept="image/*" class="apk-file-input" @change="onIconSelect" />

        <div v-if="apkParsing && !apkData" class="apk-parsing">
          <div class="apk-spinner" />
          <span>解析中...</span>
        </div>

        <div v-if="apkData" class="apk-card">
          <div class="apk-card-icon" :style="{ background: apkIconBg }" @click="triggerIconInput">
            <img v-if="editForm.icon" :src="$fixImgUrl(editForm.icon)" class="apk-card-icon-img" />
            <span v-else class="apk-card-icon-letter">{{ apkFirstLetter }}</span>
            <div class="apk-card-icon-edit">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M15 3l6 6-15 15H3v-3L18 3z"/><path d="M13 7l4 4"/></svg>
            </div>
          </div>
          <div class="apk-card-body">
            <div class="apk-card-name">{{ apkData.appName }}</div>
            <div class="apk-card-pkg">{{ apkData.packageName }}</div>
            <div class="apk-card-meta">
              <span v-if="apkData.version">v{{ apkData.version }}</span>
              <span>{{ apkData.sizeMb }} MB</span>
            </div>
          </div>
          <div class="apk-card-actions">
            <button class="apk-card-repick" @click="resetFileState">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
            </button>
          </div>
        </div>

        <div v-if="apkData" class="upload-options">
          <div class="apk-toggle-row" @click="enableCloudUpload = !enableCloudUpload">
            <span class="apk-toggle-label">上传到云存储</span>
            <span class="apk-toggle-switch" :class="{ active: enableCloudUpload }"><span class="apk-toggle-knob" /></span>
          </div>
          <template v-if="enableCloudUpload">
            <div v-if="uploadState === 'uploading'" class="apk-progress-bar">
              <div class="apk-progress-fill" :style="{ width: uploadProgress + '%' }" />
            </div>
            <div class="upload-status">
              <span v-if="uploadState === 'uploading' && uploadProgress < 100" class="apk-card-uploading">{{ uploadProgress }}%</span>
              <span v-else-if="uploadState === 'uploading'" class="apk-card-uploading">处理中...</span>
              <span v-else-if="uploadState === 'done'" class="apk-card-done">已上传</span>
              <span v-else-if="uploadState === 'error'" class="apk-card-fail">上传失败</span>
              <button v-if="uploadState === 'uploading'" class="apk-card-cancel" @click="cancelUpload">取消上传</button>
              <button v-if="uploadState === 'error'" class="apk-card-cancel" @click="retryUpload">重试</button>
            </div>
          </template>
        </div>
      </div>

      <div class="storage-bar" v-if="storageTotal > 0">
        <span class="storage-bar-label">存储空间</span>
        <div class="storage-bar-track">
          <div class="storage-bar-fill" :style="{ width: storagePercent + '%' }" :class="{ 'storage-bar-fill-warn': storagePercent > 80 }" />
        </div>
        <span class="storage-bar-text">{{ storageUsedMb }}MB / {{ storageTotal }}MB</span>
      </div>

      <!-- 表单字段组 -->
      <div class="ef-group">
        <div class="ef-row">
          <span class="ef-label">应用名称</span>
          <input v-model="editForm.name" class="ef-input" placeholder="请输入" />
        </div>
        <div class="ef-row">
          <span class="ef-label">包名</span>
          <input v-model="editForm.packageName" class="ef-input" placeholder="com.example.app" />
        </div>
        <div class="ef-row" @click="showCategoryPicker = true">
          <span class="ef-label">应用分类</span>
          <div class="ef-value-row">
            <span v-if="editForm.categories.length === 0" class="ef-placeholder">请选择</span>
            <span v-else class="ef-tags">
              <span v-for="c in editForm.categories" :key="c" class="ef-tag">{{ c }}</span>
            </span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <div class="ef-row">
          <span class="ef-label">版本号</span>
          <div class="ef-value-row">
            <input v-model="editForm.version" class="ef-input-sm" placeholder="1.0.0" />
          </div>
        </div>
        <div class="ef-row" @click="showVersionTypePicker = true">
          <span class="ef-label">版本类型</span>
          <div class="ef-value-row">
            <span :class="editForm.versionType ? '' : 'ef-placeholder'">{{ editForm.versionType || '请选择' }}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
          </div>
        </div>
        <div class="ef-row">
          <span class="ef-label">应用大小</span>
          <input v-model.number="editForm.sizeMb" class="ef-input" placeholder="0" type="number" />
        </div>
        <div class="ef-row">
          <span class="ef-label">下载地址</span>
          <input v-model="editForm.downloadUrl" class="ef-input" placeholder="下载链接" />
        </div>
      </div>

      <!-- 应用图片 -->
      <div class="ef-section-title">应用图片</div>
      <div class="ef-group ef-images-group">
        <div class="images-grid">
          <div
            v-for="(img, i) in screenshotPreviewUrls"
            :key="i"
            class="img-item"
            :style="{ backgroundImage: 'url(' + img + ')' }"
          >
            <div class="img-remove" @click.stop="removeScreenshot(i)">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </div>
          </div>
          <div class="img-item img-add" @click="triggerImageUpload">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg>
          </div>
        </div>
      </div>

      <!-- 更多信息 -->
      <div class="ef-section-title">更多信息</div>
      <div class="ef-group">
        <div class="ef-row ef-row-desc">
          <span class="ef-label">应用描述</span>
          <textarea v-model="editForm.description" class="ef-textarea" rows="3" placeholder="介绍应用功能特点..." />
        </div>
      </div>

      <!-- 开关选项 -->
      <div class="ef-group ef-switch-group">
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否有广告</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.hasAds" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否需要联网</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.requiresNetwork" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否包含付费内容</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.hasPaidContent" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-switch-row">
          <span class="ef-switch-label">是否免费应用</span>
          <label class="ef-toggle">
            <input type="checkbox" v-model="editForm.isFree" />
            <span class="ef-toggle-slider" />
          </label>
        </div>
        <div class="ef-row">
          <span class="ef-label">收费方式</span>
          <div class="ef-price-type">
            <button :class="['ef-price-btn', { active: editForm.price_type !== 'balance' && editForm.price_type !== 'points' }]" @click="editForm.price_type = 'free'">免费</button>
            <button :class="['ef-price-btn', { active: editForm.price_type === 'balance' }]" @click="editForm.price_type = 'balance'">余额</button>
            <button :class="['ef-price-btn', { active: editForm.price_type === 'points' }]" @click="editForm.price_type = 'points'">积分</button>
          </div>
        </div>
        <div class="ef-row" v-if="editForm.price_type === 'balance' || editForm.price_type === 'points'">
          <span class="ef-label">{{ editForm.price_type === 'balance' ? '价格(元)' : '价格(积分)' }}</span>
          <input v-model.number="editForm.price_amount" type="number" class="ef-input" placeholder="请输入金额" min="0" step="0.01" />
        </div>
      </div>
    </div>

    <div class="ef-bottom">
      <button class="ef-submit" :disabled="submitting" @click="handleSubmit">
        {{ submitting ? (uploadState === 'uploading' ? '上传中...' : '提交中...') : '发布应用' }}
      </button>
    </div>

    <!-- 分类多选弹窗 -->
    <div v-if="showCategoryPicker" class="picker-overlay" @click.self="showCategoryPicker = false">
      <div class="picker-panel">
        <div class="picker-title">选择分类</div>
        <div class="picker-grid">
          <div
            v-for="cat in categories"
            :key="cat"
            :class="['picker-chip', { active: editForm.categories.includes(cat) }]"
            @click="toggleCategory(cat)"
          >{{ cat }}</div>
        </div>
        <button class="picker-confirm" @click="showCategoryPicker = false">确定</button>
      </div>
    </div>

    <!-- 版本类型选择弹窗 -->
    <div v-if="showVersionTypePicker" class="picker-overlay" @click.self="showVersionTypePicker = false">
      <div class="picker-panel">
        <div class="picker-title">选择版本类型</div>
        <div
          v-for="vt in versionTypes"
          :key="vt"
          :class="['picker-item', { active: editForm.versionType === vt }]"
          @click="editForm.versionType = vt; showVersionTypePicker = false"
        >{{ vt }}</div>
        <button class="picker-cancel" @click="showVersionTypePicker = false">取消</button>
      </div>
    </div>

    <input ref="imageInput" type="file" accept="image/*" multiple style="display: none;" @change="onImagesUpload" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import JSZip from 'jszip'
import { useUserStore } from '@/store/modules/user'
import { fetchSaveSubmission, fetchSubmissionDetail } from '@/api/submission'
import { fetchCategoryList } from '@/api/appstore'
import request from '@/utils/http'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const userId = computed(() => userStore.getUserInfo.userId)
const userName = computed(() => userStore.getUserInfo.userName || '')

const isNewVersion = computed(() => route.query.mode === 'new-version')

const showCategoryPicker = ref(false)
const showVersionTypePicker = ref(false)
const imageInput = ref<HTMLInputElement | null>(null)
const apkInput = ref<HTMLInputElement | null>(null)
const iconInput = ref<HTMLInputElement | null>(null)

function triggerApkInput() {
  apkInput.value?.click()
}

function triggerIconInput() {
  iconInput.value?.click()
}

function onIconSelect() {
  const files = iconInput.value?.files
  if (!files || files.length === 0) return
  const file = files[0]
  const reader = new FileReader()
  reader.onload = () => {
    editForm.icon = reader.result as string
  }
  reader.readAsDataURL(file)
  if (iconInput.value) iconInput.value.value = ''
}

const editForm = reactive({
  id: 0,
  name: '',
  packageName: '',
  categories: [] as string[],
  version: '',
  versionType: '',
  sizeMb: 0,
  downloadUrl: '',
  icon: '',
  screenshots: [] as (string | File)[],
  description: '',
  hasAds: false,
  requiresNetwork: true,
  hasPaidContent: false,
  isFree: true,
  price_type: 'free',
  price_amount: 0
})

const screenshotPreviewUrls = computed(() =>
  editForm.screenshots.map(s => (s instanceof File ? URL.createObjectURL(s) : s))
)

const apkData = ref<ApkData | null>(null)
const apkParsing = ref(false)
const selectedFile = ref<File | null>(null)
const uploadState = ref<'idle' | 'uploading' | 'done' | 'error'>('idle')
const uploadProgress = ref(0)
const submitting = ref(false)
const maxApkFileMb = ref(0)
const storageUsed = ref(0)
const storageTotal = ref(0)

const enableCloudUpload = ref(false)

const storageUsedMb = computed(() => (storageUsed.value / (1024 * 1024)).toFixed(1))
const storagePercent = computed(() => storageTotal.value > 0 ? Math.min(100, (storageUsed.value / (storageTotal.value * 1024 * 1024)) * 100) : 0)

const apkFirstLetter = computed(() => {
  if (!apkData.value) return 'A'
  return apkData.value.appName.charAt(0).toUpperCase()
})

const apkIconBg = computed(() => {
  if (!apkData.value) return colorPool[0]
  const hash = apkData.value.appName.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  return colorPool[hash % colorPool.length]
})

async function fetchStorageInfo() {
  try {
    const res: any = await request.get({ url: '/api/upload/storage-quota', showErrorMessage: false })
    if (res) {
      storageTotal.value = Number(res.totalFileLimitMb) || 0
      storageUsed.value = Number(res.usedBytes) || 0
    }
  } catch {}
}

function cancelUpload() {
  if (uploadXhr.value) {
    uploadXhr.value.abort()
    uploadXhr.value = null
  }
  uploadState.value = 'idle'
  uploadProgress.value = 0
  enableCloudUpload.value = false
  fetchStorageInfo()
  ElMessage.info('已取消上传')
}

function retryUpload() {
  if (!selectedFile.value) return
  uploadState.value = 'idle'
  startBackgroundUpload(selectedFile.value)
}

function resetFileState() {
  apkData.value = null
  selectedFile.value = null
  enableCloudUpload.value = false
  editForm.downloadUrl = ''
  editForm.icon = ''
  uploadState.value = 'idle'
  uploadProgress.value = 0
  fetchStorageInfo()
}

// JSZip helper: guess package name from file tree
function guessPackageName(zipFiles: string[], fileName: string): string {
  const manifest = zipFiles.find(f => /AndroidManifest\.xml$/i.test(f))
  if (!manifest) return fileName.replace(/\.apk$/i, '')
  const parts = manifest.replace(/\/AndroidManifest\.xml$/i, '')
    .split('/')
    .filter(p => p && !p.startsWith('res') && !p.startsWith('META-INF') && p !== 'original')
  if (parts.length >= 3) {
    if (parts[0] === 'unknown' || parts[0] === 'sources') return parts.slice(-2).join('.')
    return parts.slice(0, 3).join('.')
  }
  if (parts.length === 2) return parts.join('.')
  return fileName.replace(/\.apk$/i, '')
}

// JSZip helper: extract version info
async function extractVersion(zip: JSZip, zipFiles: string[]): Promise<{ versionName: string; versionCode: string }> {
  try {
    const mf = zipFiles.find(f => /AndroidManifest\.xml$/i.test(f))
    if (!mf) return { versionName: '', versionCode: '' }
    const xmlFile = zip.file(mf.replace(/^\//, ''))
    if (!xmlFile) return { versionName: '', versionCode: '' }
    const raw = await xmlFile.async('uint8array')
    const text = new TextDecoder('utf-8', { fatal: false }).decode(raw)
    const vnMatch = text.match(/versionName[=&"']{1,3}([^"&']+)/i)
    const vcMatch = text.match(/versionCode[=&"']{1,3}(\d+)/i)
    return { versionName: vnMatch?.[1] || '', versionCode: vcMatch?.[1] || '' }
  } catch {
    return { versionName: '', versionCode: '' }
  }
}

async function onApkSelect() {
  const files = apkInput.value?.files
  if (!files || files.length === 0) return

  const file = files[0]

  const sizeMb = file.size / (1024 * 1024)
  if (maxApkFileMb.value > 0 && sizeMb > maxApkFileMb.value) {
    ElMessage.error(`文件大小超出限制（最大 ${maxApkFileMb.value}MB，当前 ${sizeMb.toFixed(1)}MB）`)
    if (apkInput.value) apkInput.value.value = ''
    return
  }

  selectedFile.value = file
  apkParsing.value = true
  enableCloudUpload.value = false
  uploadState.value = 'idle'
  uploadProgress.value = 0

  try {
    const buffer = await file.arrayBuffer()
    const zip = await JSZip.loadAsync(buffer)
    const allFiles = Object.keys(zip.files)
    const pkg = guessPackageName(allFiles, file.name)
    const ver = await extractVersion(zip, allFiles)

    const appName = file.name.replace(/\.apk$/i, '').replace(/[_-]v?\d[\d.]*/i, '').replace(/[_-]/g, ' ')

    apkData.value = {
      fileName: file.name,
      appName,
      packageName: pkg,
      version: ver.versionName,
      versionCode: ver.versionCode,
      sizeMb: (file.size / (1024 * 1024)).toFixed(1),
      file
    }

    editForm.name = appName
    editForm.packageName = pkg
    editForm.version = ver.versionName || '1.0.0'
    editForm.sizeMb = Number((file.size / (1024 * 1024)).toFixed(1))

    await extractApkIcon(zip, allFiles)

  } catch (err: any) {
    ElMessage.error('解析失败: ' + (err?.message || '无效的 APK 文件'))
  } finally {
    apkParsing.value = false
    if (apkInput.value) apkInput.value.value = ''
  }
}

async function extractApkIcon(zip: JSZip, allFiles: string[]) {
  try {
    const iconPatterns = ['ic_launcher', 'ic_launcher_round', 'icon', 'logo']
    const iconDirRegex = /^res\/(mipmap|drawable)-/i
    const candidates: { path: string; width: number; height: number }[] = []
    for (const name of allFiles) {
      if (!name.endsWith('.png') && !name.endsWith('.webp')) continue
      if (!iconDirRegex.test(name)) continue
      const baseName = name.split('/').pop()!.replace(/\.(png|webp)$/i, '').toLowerCase()
      if (!iconPatterns.some(pat => baseName.includes(pat))) continue
      const dimMatch = name.match(/(\d+)x(\d+)/)
      let w = dimMatch ? parseInt(dimMatch[1]) : 0
      let h = dimMatch ? parseInt(dimMatch[2]) : 0
      if (!w) {
        const densityMatch = name.match(/mipmap-([a-z]+)/i)
        const densities: Record<string, number> = { 'xxxhdpi': 192, 'xxhdpi': 144, 'xhdpi': 96, 'hdpi': 72, 'mdpi': 48, 'ldpi': 36 }
        w = densities[densityMatch?.[1]?.toLowerCase()] || 48
        h = w
      }
      candidates.push({ path: name, width: w, height: h })
    }
    const best = candidates.sort((a, b) => (b.width * b.height) - (a.width * a.height))[0]
    if (best) {
      const iconFile = zip.file(best.path)
      if (iconFile) {
        const base64 = await iconFile.async('base64')
        const ext = best.path.endsWith('.webp') ? 'webp' : 'png'
        editForm.icon = `data:image/${ext};base64,${base64}`
      }
    }
  } catch {}
}

// 打开云上传开关时自动开始上传
watch(enableCloudUpload, async (val) => {
  if (!val) {
    if (uploadState.value === 'uploading' && uploadXhr.value) {
      uploadXhr.value.abort()
      uploadXhr.value = null
    }
    if (uploadState.value === 'done' && editForm.downloadUrl) {
      try {
        await request.post({ url: '/api/upload/delete-uploaded', data: { downloadUrl: editForm.downloadUrl }, showErrorMessage: false })
      } catch {}
      editForm.downloadUrl = ''
      editForm.icon = ''
    }
    uploadState.value = 'idle'
    uploadProgress.value = 0
    fetchStorageInfo()
    return
  }
  if (!selectedFile.value || uploadState.value !== 'idle') return
  if (storageTotal.value > 0) {
    const afterUpload = storageUsed.value + selectedFile.value.size
    if (afterUpload > storageTotal.value * 1024 * 1024) {
      ElMessage.error(`存储空间不足（${storageUsedMb.value}MB / ${storageTotal.value}MB）`)
      enableCloudUpload.value = false
      return
    }
  }
  storageUsed.value += selectedFile.value.size
  startBackgroundUpload(selectedFile.value)
})

function startBackgroundUpload(file: File) {
  uploadState.value = 'uploading'
  uploadProgress.value = 0

  const fd = new FormData()
  fd.append('file', file)

  const xhr = new XMLHttpRequest()
  uploadXhr.value = xhr

  xhr.upload.addEventListener('progress', (e) => {
    if (e.lengthComputable) {
      uploadProgress.value = Math.round((e.loaded / e.total) * 100)
    }
  })

  xhr.addEventListener('load', () => {
    if (xhr.status >= 200 && xhr.status < 300) {
      try {
        const res = JSON.parse(xhr.responseText)
        if (res.code === 200) {
          const data = res.data
          editForm.downloadUrl = data.downloadUrl || ''
          editForm.icon = data.icon || ''
          if (data.name) editForm.name = data.name
          if (data.version) editForm.version = data.version
          uploadState.value = 'done'
        } else {
          uploadState.value = 'error'
          ElMessage.error(res.msg || '上传失败')
        }
      } catch {
        uploadState.value = 'error'
      }
    } else {
      uploadState.value = 'error'
    }
  })

  xhr.addEventListener('error', () => {
    uploadState.value = 'error'
    ElMessage.error('上传失败，请检查网络连接')
  })

  xhr.addEventListener('abort', () => {
    uploadState.value = 'error'
  })

  xhr.addEventListener('timeout', () => {
    uploadState.value = 'error'
    ElMessage.error('上传超时，服务端处理时间过长，请尝试较小的文件')
  })

  xhr.addEventListener('loadend', () => {
    uploadXhr.value = null
    handlePendingLeave()
  })

  xhr.open('POST', '/api/upload/apk')
  const token = userStore.accessToken
  if (token) xhr.setRequestHeader('Authorization', token)
  xhr.timeout = 600000
  xhr.send(fd)
}

// ---------- 其他文件上传 ----------
function triggerImageUpload() {
  imageInput.value?.click()
}

async function onImagesUpload(e: Event) {
  const files = (e.target as HTMLInputElement).files
  if (!files || files.length === 0) return
  for (let i = 0; i < files.length; i++) {
    editForm.screenshots.push(files[i])
  }
  if (imageInput.value) imageInput.value.value = ''
}

function removeScreenshot(index: number) {
  const item = editForm.screenshots[index]
  editForm.screenshots.splice(index, 1)
}

async function uploadScreenshots(): Promise<string[]> {
  const urls: string[] = []
  const pending: { file: File; idx: number }[] = []
  editForm.screenshots.forEach((s, i) => {
    if (s instanceof File) pending.push({ file: s, idx: i })
    else urls[i] = s as string
  })
  for (const { file, idx } of pending) {
    const fd = new FormData()
    fd.append('file', file)
    const token = userStore.accessToken
    const headers: Record<string, string> = {}
    if (token) headers['Authorization'] = token
    const res: any = await request.post({ url: '/api/upload/avatar', data: fd, headers })
    urls[idx] = res?.url || ''
  }
  return urls.filter(Boolean)
}

// ---------- 表单操作 ----------
function goBack() {
  doGoBack()
}

function doGoBack() {
  if (window.history.length > 1) router.back()
  else router.push('/appstore/submissions')
}

let removeRouteGuard: (() => void) | null = null
let leavingConfirmed = false
const leavingPending = ref(false)
const uploadXhr = ref<XMLHttpRequest | null>(null)

const hasActiveFile = computed(() => !!apkData.value || !!editForm.downloadUrl)

onMounted(() => {
  removeRouteGuard = router.beforeEach(async (to, from, next) => {
    if (leavingConfirmed) return next()
    if (from.path === '/appstore/submissions/edit' && hasActiveFile.value) {
      try {
        await showLeaveConfirm()
        await doLeaveCleanup(next)
      } catch {
        next(false)
      }
    } else {
      next()
    }
  })
})

onBeforeUnmount(() => {
  if (removeRouteGuard) removeRouteGuard()
})

async function showLeaveConfirm(): Promise<void> {
  let msg = '返回将放弃当前应用信息，确定要返回吗？'
  if (enableCloudUpload.value) {
    if (uploadState.value === 'uploading') {
      msg = '返回将等待上传完成后自动删除文件，确定要返回吗？'
    } else if (uploadState.value === 'done') {
      msg = '返回将删除已上传的安装包文件，确定要返回吗？'
    } else {
      msg = '返回将放弃当前文件，确定要返回吗？'
    }
  }
  await ElMessageBox.confirm(msg, '提示', {
    confirmButtonText: '确定返回',
    cancelButtonText: '取消',
    type: 'warning'
  })
}

async function doLeaveCleanup(next?: (v?: any) => void) {
  if (enableCloudUpload.value && uploadXhr.value && uploadState.value === 'uploading') {
    leavingPending.value = true
    ElMessage.info('等待上传完成以清理文件...')
    return
  }

  if (enableCloudUpload.value && editForm.downloadUrl) {
    try {
      await request.post({ url: '/api/upload/delete-uploaded', data: { downloadUrl: editForm.downloadUrl }, showErrorMessage: false })
    } catch {}
  }

  proceedWithLeave(next)
}

function proceedWithLeave(next?: (v?: any) => void) {
  leavingConfirmed = true
  if (removeRouteGuard) { removeRouteGuard(); removeRouteGuard = null }
  if (next) next()
}

async function handlePendingLeave() {
  if (!leavingPending.value) return
  leavingPending.value = false

  if (editForm.downloadUrl) {
    try {
      await request.post({ url: '/api/upload/delete-uploaded', data: { downloadUrl: editForm.downloadUrl }, showErrorMessage: false })
    } catch {}
  }

  leavingConfirmed = true
  if (removeRouteGuard) { removeRouteGuard(); removeRouteGuard = null }
  doGoBack()
}

function toggleCategory(cat: string) {
  const idx = editForm.categories.indexOf(cat)
  if (idx > -1) {
    editForm.categories.splice(idx, 1)
  } else {
    editForm.categories.push(cat)
  }
}

async function handleSubmit() {
  if (!apkData.value && !editForm.id) {
    ElMessage.warning('请先选择 APK 安装文件')
    return
  }
  if (!editForm.name) {
    ElMessage.warning('请输入应用名称')
    return
  }

  // 如果还在上传中，等待完成（文件模式）
  if (enableCloudUpload.value && uploadState.value === 'uploading') {
    ElMessage.warning('文件上传中，请稍候...')
    return
  }

  if (enableCloudUpload.value && uploadState.value === 'error') {
    ElMessage.warning('文件上传失败，请重新选择 APK')
    return
  }

  submitting.value = true
  try {
    const screenshotUrls = await uploadScreenshots()

    const body: any = {
      id: editForm.id || undefined,
      userId: userId.value,
      userName: userName.value,
      name: editForm.name,
      packageName: editForm.packageName,
      category: JSON.stringify(editForm.categories),
      version: editForm.version,
      sizeMb: editForm.sizeMb,
      icon: editForm.icon,
      downloadUrl: editForm.downloadUrl,
      description: editForm.description,
      screenshots: screenshotUrls,
      versionType: editForm.versionType,
      hasAds: editForm.hasAds,
      requiresNetwork: editForm.requiresNetwork,
      hasPaidContent: editForm.hasPaidContent,
      isFree: editForm.isFree,
      price_type: editForm.price_type,
      price_amount: editForm.price_amount,
      submissionStatus: 'draft'
    }
    const res: any = await fetchSaveSubmission(body)
    if (res) {
      const subId = res.id || editForm.id
      router.replace({
        path: '/appstore/submissions/success',
        query: {
          id: String(subId),
          name: editForm.name,
          packageName: editForm.packageName,
          category: editForm.categories[0] || '',
          version: editForm.version,
          sizeMb: String(editForm.sizeMb),
          icon: editForm.icon,
          draft: '1'
        }
  })
    }
  } catch (err: any) {
    ElMessage.error(err?.message || '保存失败')
  } finally {
    submitting.value = false
  }
}

async function loadDetail() {
  if (!editForm.id) return
  try {
    const { fetchSubmissionDetail } = await import('@/api/submission')
    const d: any = await fetchSubmissionDetail(editForm.id)
    if (d) {
      editForm.name = d.name || ''
      editForm.packageName = d.packageName || ''
      try { editForm.categories = JSON.parse(d.category || '[]') } catch {
        editForm.categories = d.category ? [d.category] : []
      }
      editForm.version = d.version || '1.0.0'
      editForm.versionType = d.versionType || ''
      editForm.sizeMb = d.sizeMb || 0
      editForm.icon = d.icon || ''
      editForm.downloadUrl = d.downloadUrl || ''
      editForm.description = d.description || ''
      editForm.screenshots = d.screenshots || []
      editForm.hasAds = !!d.hasAds
      editForm.requiresNetwork = d.requiresNetwork !== undefined ? !!d.requiresNetwork : true
      editForm.hasPaidContent = !!d.hasPaidContent
      editForm.isFree = d.isFree !== undefined ? !!d.isFree : true
      editForm.price_type = d.priceType || 'free'
      editForm.price_amount = Number(d.priceAmount) || 0
    }
  } catch {}
}

onMounted(async () => {
  try {
    const cats: any = await fetchCategoryList()
    if (Array.isArray(cats)) {
      categories.value = cats.map((c: any) => c.name)
    }
  } catch {}

  try {
    const quota: any = await request.get({ url: '/api/upload/quota', showErrorMessage: false })
    if (quota && quota.max_size_mb) {
      maxApkFileMb.value = Number(quota.max_size_mb) || 0
    }
  } catch {}

  fetchStorageInfo()

  // 从 file-picker 跳转过来的参数
  const qPackageName = route.query.packageName as string
  const qSizeMb = route.query.sizeMb as string
  const qVersion = route.query.version as string
  const qIcon = route.query.icon as string
  const qDownloadUrl = route.query.downloadUrl as string
  const qCategory = route.query.category as string

  if (qIcon) editForm.icon = qIcon
  if (qDownloadUrl) editForm.downloadUrl = qDownloadUrl
  // 标记为已上传完成，允许直接提交
  if (qDownloadUrl && qIcon) {
    uploadState.value = 'done'
  }

  if (isNewVersion.value) {
    editForm.sizeMb = Number(qSizeMb) || 0
    editForm.version = qVersion || editForm.version
    editForm.packageName = qPackageName || editForm.packageName
    try {
      const arr = JSON.parse(qCategory)
      editForm.categories = Array.isArray(arr) ? arr : (qCategory ? [qCategory] : [])
    } catch {
      editForm.categories = qCategory ? [qCategory] : []
    }
  }

  if (!isNewVersion.value) loadDetail()
})
</script>

<style lang="scss" scoped>
.ef-page {
  min-height: 100vh;
  background: #f5f6fa;
  padding-bottom: 80px;
}

.ef-header {
  display: flex;
  align-items: center;
  padding: 48px 16px 14px;
  background: #fff;
  gap: 12px;
}

.ef-back { cursor: pointer; flex-shrink: 0; }

.ef-title {
  font-size: 17px;
  font-weight: 600;
  color: #1a1a1a;
}

.ef-body { padding: 12px 16px 0; }

/* APK dropzone & card */
.apk-section {
  margin-bottom: 12px;
}

.apk-dropzone {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #fff;
  border-radius: 14px;
  border: 2px dashed #d0d5dd;
  cursor: pointer;
  gap: 10px;
  padding: 50px 20px;
  transition: border-color .15s;

  &:hover { border-color: #3DDC84; }
}

.apk-dropzone-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
}

.apk-dropzone-sub {
  font-size: 12px;
  color: #aaa;
}

.apk-file-input { display: none; }

.apk-parsing {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 20px;
  color: #999;
  font-size: 14px;
  background: #fff;
  border-radius: 14px;
}

.apk-spinner {
  width: 18px;
  height: 18px;
  border: 2px solid #e0e0e0;
  border-top-color: #3DDC84;
  border-radius: 50%;
  animation: spin .6s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

.apk-card {
  background: #fff;
  border-radius: 14px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 14px;
  position: relative;
}

.apk-card-icon {
  width: 56px; height: 56px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; overflow: hidden;
  position: relative;
  cursor: pointer;
}

.apk-card-icon-letter {
  color: #fff; font-size: 26px; font-weight: 700;
}

.apk-card-icon-img {
  width: 100%; height: 100%; object-fit: cover;
}

.apk-card-icon-edit {
  position: absolute;
  bottom: 0; right: 0;
  width: 22px; height: 22px;
  background: rgba(0,0,0,.45);
  border-radius: 8px 0 8px 0;
  display: flex; align-items: center; justify-content: center;
  opacity: 0;
  transition: opacity .2s;
}

.apk-card-icon:hover .apk-card-icon-edit,
.apk-card-icon:active .apk-card-icon-edit {
  opacity: 1;
}

.apk-card-body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.apk-card-name {
  font-size: 15px; font-weight: 600;
  color: #111;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.apk-card-pkg {
  font-size: 12px; color: #999;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.apk-card-meta {
  display: flex; gap: 8px;
  font-size: 12px; color: #666;
  align-items: center;
}

.apk-card-uploading { color: #3B82F6; font-weight: 500; }
.apk-card-done { color: #10B981; font-weight: 500; }
.apk-card-fail { color: #EF4444; font-weight: 500; }

.apk-progress-bar {
  width: 100%;
  height: 4px;
  background: #eee;
  border-radius: 2px;
  overflow: hidden;
  margin-top: 6px;
}

.apk-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #3DDC84, #1BBFAE);
  border-radius: 2px;
  transition: width .3s ease;
}

.apk-card-repick {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 30px; height: 30px;
  border-radius: 50%;
  background: #f5f5f5;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
}

.apk-card-repick:disabled {
  opacity: .4;
  cursor: not-allowed;
}

/* Storage bar */
.storage-bar {
  background: #fff;
  border-radius: 12px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}

.storage-bar-label {
  font-size: 12px;
  color: #999;
  white-space: nowrap;
}

.storage-bar-track {
  flex: 1;
  height: 6px;
  background: #eee;
  border-radius: 3px;
  overflow: hidden;
}

.storage-bar-fill {
  height: 100%;
  background: #3DDC84;
  border-radius: 3px;
  transition: width .4s ease;
}

.storage-bar-fill-warn {
  background: #F59E0B;
}

.storage-bar-text {
  font-size: 11px;
  color: #999;
  white-space: nowrap;
}

/* Card actions */
.apk-card-actions {
  display: flex;
  flex-direction: column;
  gap: 6px;
  align-items: center;
  min-width: 56px;
}

.apk-card-cancel {
  padding: 6px 10px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  color: #EF4444;
  font-size: 12px;
  cursor: pointer;
  white-space: nowrap;

  &:active { background: #fef2f2; }
}

/* Upload options (below card) */
.upload-options {
  background: #fff;
  border-radius: 12px;
  padding: 12px 14px;
  margin-bottom: 12px;

  .apk-progress-bar {
    margin-top: 8px;
  }
}

.upload-status {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 6px;
}

.apk-toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 0;
  cursor: pointer;
  user-select: none;
}

.apk-toggle-label {
  font-size: 13px;
  color: #333;
}

.apk-toggle-switch {
  width: 44px;
  height: 24px;
  border-radius: 12px;
  background: #d1d5db;
  position: relative;
  transition: background .2s;

  &.active {
    background: #3DDC84;
  }
}

.apk-toggle-knob {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #fff;
  position: absolute;
  top: 2px;
  left: 2px;
  transition: left .2s;
  box-shadow: 0 1px 3px rgba(0,0,0,.15);

  .apk-toggle-switch.active & {
    left: 22px;
  }
}

/* Form group */
.ef-group {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 12px;
}

.ef-section-title {
  font-size: 13px; color: #999;
  padding: 4px 4px 8px; font-weight: 500;
}

.ef-row {
  display: flex; align-items: center;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;
  min-height: 48px;

  &:last-child { border-bottom: none; }

  &.ef-row-desc {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
}

.ef-label {
  font-size: 14px; color: #333;
  width: 76px; flex-shrink: 0;
}

.ef-input {
  flex: 1; border: none; outline: none;
  font-size: 14px; color: #333;
  text-align: right; background: transparent;

  &::placeholder { color: #ccc; }
}

.ef-input-sm {
  border: none; outline: none;
  font-size: 14px; color: #333;
  text-align: right; background: transparent;
  width: 100%;

  &::placeholder { color: #ccc; }
}

.ef-value-row {
  flex: 1; display: flex; align-items: center; justify-content: flex-end; gap: 6px;
}

.ef-placeholder { color: #ccc; font-size: 14px; }

.ef-tags {
  display: flex; gap: 4px; flex-wrap: wrap; justify-content: flex-end;
  max-width: 200px;
}

.ef-tag {
  font-size: 11px; padding: 2px 8px;
  border-radius: 6px; background: #E0F7FA;
  color: #00BFA5; white-space: nowrap;
}

.ef-textarea {
  width: 100%; border: none; outline: none;
  font-size: 13px; color: #333;
  resize: none; background: transparent; font-family: inherit;

  &::placeholder { color: #ccc; }
}

/* Screenshots */
.ef-images-group { padding: 12px 12px; }

.images-grid {
  display: flex; gap: 10px; flex-wrap: wrap;
}

.img-item {
  width: 80px; height: 80px;
  border-radius: 8px;
  background-size: cover; background-position: center;
  position: relative;
}

.img-add {
  border: 1.5px dashed #d0d5dd;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  background: #fafbfc;

  &:active { background: #f0f2f5; }
}

.img-remove {
  position: absolute; top: -6px; right: -6px;
  width: 18px; height: 18px;
  border-radius: 50%; background: rgba(0,0,0,.55);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
}

/* Toggle switches */
.ef-switch-group { margin-bottom: 12px; }

.ef-switch-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #f5f5f5;

  &:last-child { border-bottom: none; }
}

.ef-switch-label { font-size: 14px; color: #333; }

.ef-toggle {
  position: relative; display: inline-block;
  width: 44px; height: 26px;
  cursor: pointer;
}

.ef-toggle input { opacity: 0; width: 0; height: 0; }

.ef-toggle-slider {
  position: absolute; inset: 0;
  background: #e0e0e0;
  border-radius: 999px;
  transition: background .25s;

  &::before {
    content: '';
    position: absolute;
    width: 22px; height: 22px;
    left: 2px; bottom: 2px;
    background: #fff;
    border-radius: 50%;
    transition: transform .25s;
    box-shadow: 0 1px 3px rgba(0,0,0,.15);
  }
}

.ef-toggle input:checked + .ef-toggle-slider {
  background: #24D6C4;

  &::before { transform: translateX(18px); }
}

/* Bottom */
.ef-bottom {
  position: fixed; bottom: 0; left: 0; right: 0;
  padding: 12px 16px calc(12px + env(safe-area-inset-bottom, 0px));
  background: #fff;
  border-top: 1px solid #f0f0f0;
  z-index: 1000;
}

.ef-submit {
  width: 100%; padding: 14px;
  border: none; border-radius: 12px;
  background: linear-gradient(135deg, #24D6C4, #1BBFAE);
  color: #fff; font-size: 16px; font-weight: 500;
  cursor: pointer;

  &:disabled {
    background: #e0e0e0;
    color: #bbb;
    cursor: not-allowed;
  }
}

/* Pickers */
.picker-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,.45);
  z-index: 1001;
  display: flex; align-items: flex-end;
}

.picker-panel {
  background: #fff;
  border-radius: 16px 16px 0 0;
  width: 100%;
  padding: 16px 16px calc(16px + env(safe-area-inset-bottom));
}

.picker-title {
  font-size: 16px; font-weight: 600; color: #333;
  text-align: center; margin-bottom: 16px;
  padding-bottom: 12px; border-bottom: 1px solid #f0f0f0;
}

.picker-grid {
  display: flex; flex-wrap: wrap; gap: 10px;
  margin-bottom: 16px;
}

.picker-chip {
  padding: 8px 16px; border-radius: 20px;
  font-size: 13px; color: #666;
  background: #f5f5f5; cursor: pointer;
  transition: all .15s;

  &.active {
    background: #E0F7FA; color: #00BFA5; font-weight: 500;
  }

  &:active { transform: scale(.96); }
}

.picker-item {
  padding: 14px 8px; font-size: 15px; color: #333;
  text-align: center; cursor: pointer; border-radius: 8px;

  &:active { background: #f5f6fa; }

  &.active { color: #24D6C4; font-weight: 500; }
}

.picker-confirm {
  width: 100%; padding: 12px; border: none;
  border-radius: 10px;
  background: #24D6C4; color: #fff;
  font-size: 15px; font-weight: 500; cursor: pointer;
}

.picker-cancel {
  width: 100%; padding: 12px; margin-top: 8px;
  border: none; background: #f5f5f5; color: #666;
  font-size: 14px; border-radius: 10px; cursor: pointer;
}

.ef-price-type {
  display: flex; gap: 8px;
}

.ef-price-btn {
  padding: 6px 16px; border-radius: 8px; border: 1px solid #e5e7eb;
  background: #f9fafb; color: #374151; font-size: 13px; cursor: pointer;
  transition: all 0.2s;
}

.ef-price-btn.active {
  background: #e6f9f6; border-color: #00BFA5; color: #00BFA5; font-weight: 600;
}
</style>
