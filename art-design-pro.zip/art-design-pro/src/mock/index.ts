/**
 * 开发环境 Mock 数据拦截器
 * 拦截 Axios 请求并返回本地 mock 数据
 */

import { AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import type { AxiosInstance } from 'axios'
import {
  CARD_KEY_DATA,
  MEMBER_DATA,
  MEMBERSHIP_LEVEL_DATA,
  POINTS_RECORD_DATA
} from './temp/operation'
import { ACCOUNT_TABLE_DATA } from './temp/formData'

const MOCK_DELAY = 200

let nextLevelId = 99
let latestLevelId = 99

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function createMockResponse<T>(data: any, config: InternalAxiosRequestConfig): AxiosResponse {
  return {
    data: { code: 200, msg: 'success', data },
    status: 200,
    statusText: 'OK',
    headers: {},
    config
  } as AxiosResponse
}

function paginateData<T>(data: T[], current = 1, size = 20) {
  const start = (current - 1) * size
  const records = data.slice(start, start + size)
  return {
    records,
    current,
    size,
    total: data.length
  }
}

function getRouteTree(): any[] {
  return [
    {
      name: 'Dashboard',
      path: '/dashboard',
      component: '/index/index',
      redirect: '/dashboard/console',
      meta: { title: 'menus.dashboard.title', icon: 'ri:pie-chart-line', roles: ['R_SUPER', 'R_ADMIN'] },
      children: [
        { name: 'Console', path: 'console', component: '/dashboard/console', meta: { title: 'menus.dashboard.console', keepAlive: false, fixedTab: true } }
      ]
    },
    {
      name: 'Operation',
      path: '/operation',
      component: '/index/index',
      meta: { title: 'menus.operation.title', icon: 'ri:settings-3-line', roles: ['R_SUPER', 'R_ADMIN'] },
      children: [
        { name: 'CardKey', path: 'cardkey', component: '/operation/cardkey/index', meta: { title: 'menus.operation.cardkey', keepAlive: true, roles: ['R_SUPER', 'R_ADMIN'] } },
        { name: 'Membership', path: 'membership', component: '/operation/membership/index', meta: { title: 'menus.operation.membership', keepAlive: true, roles: ['R_SUPER', 'R_ADMIN'] } },
        { name: 'Coupon', path: 'coupon', component: '/operation/coupon/index', meta: { title: 'menus.operation.coupon', keepAlive: true, roles: ['R_SUPER', 'R_ADMIN'] } },
        { name: 'Points', path: 'points', component: '/operation/points/index', meta: { title: 'menus.operation.points', keepAlive: true, roles: ['R_SUPER', 'R_ADMIN'] } }
      ]
    },
    {
      name: 'System',
      path: '/system',
      component: '/index/index',
      meta: { title: 'menus.system.title', icon: 'ri:user-3-line', roles: ['R_SUPER', 'R_ADMIN'] },
      children: [
        { name: 'User', path: 'user', component: '/system/user', meta: { title: 'menus.system.user', keepAlive: true, roles: ['R_SUPER', 'R_ADMIN'] } },
        { name: 'Role', path: 'role', component: '/system/role', meta: { title: 'menus.system.role', keepAlive: true, roles: ['R_SUPER'] } },
        { name: 'UserCenter', path: 'user-center', component: '/system/user-center', meta: { title: 'menus.system.userCenter', isHide: true, keepAlive: true, isHideTab: true } },
        { name: 'Menus', path: 'menu', component: '/system/menu', meta: { title: 'menus.system.menu', keepAlive: true, roles: ['R_SUPER'], authList: [{ title: '新增', authMark: 'add' }, { title: '编辑', authMark: 'edit' }, { title: '删除', authMark: 'delete' }] } }
      ]
    },
    {
      name: 'Result',
      path: '/result',
      component: '/index/index',
      meta: { title: 'menus.result.title', icon: 'ri:checkbox-circle-line' },
      children: [
        { name: 'Success', path: 'success', component: '/result/success/index', meta: { title: 'menus.result.success', isFullPage: true } },
        { name: 'Fail', path: 'fail', component: '/result/fail/index', meta: { title: 'menus.result.fail', isFullPage: true } }
      ]
    },
    {
      name: 'Exception',
      path: '/exception',
      component: '/index/index',
      meta: { title: 'menus.exception.title', icon: 'ri:error-warning-line' },
      children: [
        { name: 'Exception403', path: '403', component: '/exception/403/index', meta: { title: 'menus.exception.forbidden', isFullPage: true } },
        { name: 'Exception404', path: '404', component: '/exception/404/index', meta: { title: 'menus.exception.notFound', isFullPage: true } },
        { name: 'Exception500', path: '500', component: '/exception/500/index', meta: { title: 'menus.exception.serverError', isFullPage: true } }
      ]
    }
  ]
}

const mockHandlers: Record<string, (config: InternalAxiosRequestConfig) => Promise<AxiosResponse>> = {
  '/api/operation/cardkey/list': async (config) => {
    await delay(MOCK_DELAY)
    const params = config.params || {}
    const current = params.current || 1
    const size = params.size || 20
    const { cardNo, type, status } = params

    let filtered = [...CARD_KEY_DATA]
    if (cardNo) filtered = filtered.filter((c) => c.cardNo.includes(cardNo))
    if (type) filtered = filtered.filter((c) => c.type === type)
    if (status) filtered = filtered.filter((c) => c.status === status)

    return createMockResponse(paginateData(filtered, current, size), config)
  },
  '/api/operation/membership-level/list': async (config) => {
    await delay(MOCK_DELAY)
    return createMockResponse(paginateData(MEMBERSHIP_LEVEL_DATA), config)
  },
  '/api/operation/member/list': async (config) => {
    await delay(MOCK_DELAY)
    const params = config.params || {}
    const current = params.current || 1
    const size = params.size || 20
    const { userName, level } = params

    let filtered = [...MEMBER_DATA]
    if (userName) filtered = filtered.filter((m) => m.userName.includes(userName))
    if (level !== undefined && level !== '') filtered = filtered.filter((m) => m.level === Number(level))

    return createMockResponse(paginateData(filtered, current, size), config)
  },
  '/api/operation/points-record/list': async (config) => {
    await delay(MOCK_DELAY)
    const params = config.params || {}
    const current = params.current || 1
    const size = params.size || 20
    const { userName, type } = params

    let filtered = [...POINTS_RECORD_DATA]
    if (userName) filtered = filtered.filter((p) => p.userName.includes(userName))
    if (type) filtered = filtered.filter((p) => p.type === type)

    return createMockResponse(paginateData(filtered, current, size), config)
  },
  '/api/v3/system/menus/simple': async (config) => {
    await delay(MOCK_DELAY)
    return createMockResponse(getRouteTree(), config)
  },
  '/api/user/list': async (config) => {
    await delay(MOCK_DELAY)
    const params = config.params || {}
    const current = params.current || 1
    const size = params.size || 20
    const { userName, userPhone } = params

    let filtered = ACCOUNT_TABLE_DATA.map((u, i) => {
      const member = MEMBER_DATA.find((m) => m.userId === u.id)
      return {
        id: u.id,
        avatar: u.avatar,
        status: u.status,
        userName: u.username,
        userGender: u.gender === 1 ? '男' : '女',
        nickName: u.username,
        userPhone: u.mobile,
        userEmail: u.email,
        userRoles: i === 0 ? ['R_SUPER'] : ['R_ADMIN'],
        points: member?.points ?? 0,
        level: member?.level ?? 0,
        levelName: member?.levelName ?? '普通会员',
        expireTime: member?.expireTime ?? '',
        createBy: '系统',
        createTime: u.create_time,
        updateBy: '系统',
        updateTime: u.create_time
      }
    })

    if (userName) filtered = filtered.filter((u) => u.userName.includes(userName))
    if (userPhone) filtered = filtered.filter((u) => u.userPhone.includes(userPhone))

    return createMockResponse(paginateData(filtered, current, size), config)
  },
  '/api/user/update': async (config) => {
    await delay(MOCK_DELAY)
    const body = JSON.parse(config.data || '{}')
    return createMockResponse({ success: true, ...body }, config)
  },
  '/api/operation/cardkey/create': async (config) => {
    await delay(MOCK_DELAY)
    const body = config.data || {}
    return createMockResponse({ success: true, ids: [Date.now()] }, config)
  },
  '/api/operation/membership-level/save': async (config) => {
    await delay(MOCK_DELAY)
    const body = JSON.parse(config.data || '{}')
    if (!body.id) {
      body.id = ++nextLevelId
      MEMBERSHIP_LEVEL_DATA.push(body)
    } else {
      const idx = MEMBERSHIP_LEVEL_DATA.findIndex((l) => l.id === body.id)
      if (idx >= 0) Object.assign(MEMBERSHIP_LEVEL_DATA[idx], body)
    }
    latestLevelId = body.id
    return createMockResponse({ success: true, id: body.id }, config)
  }
}

export function setupMockInterceptor(instance: AxiosInstance) {
  instance.interceptors.request.use(async (config) => {
    const url = config.url || ''
    const handler = mockHandlers[url]

    if (handler) {
      config.adapter = async () => {
        const mockResponse = await handler(config)
        return mockResponse
      }
      return config
    }

    if (config.method === 'delete' && url.startsWith('/api/operation/membership-level/')) {
      const id = url.split('/').pop()
      config.adapter = async () => {
        await delay(MOCK_DELAY)
        const idx = MEMBERSHIP_LEVEL_DATA.findIndex((l) => l.id === Number(id))
        if (idx >= 0) MEMBERSHIP_LEVEL_DATA.splice(idx, 1)
        return createMockResponse({ success: true }, config)
      }
    }

    return config
  })
}
