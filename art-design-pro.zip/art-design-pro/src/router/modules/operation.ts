import { AppRouteRecord } from '@/types/router'

export const operationRoutes: AppRouteRecord = {
  path: '/operation',
  name: 'Operation',
  component: '/index/index',
  meta: {
    title: 'menus.operation.title',
    icon: 'ri:settings-3-line',
    roles: ['R_SUPER', 'R_ADMIN']
  },
  children: [
    {
      path: 'cardkey',
      name: 'CardKey',
      component: '/operation/cardkey/index',
      meta: {
        title: 'menus.operation.cardkey',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'membership',
      name: 'Membership',
      component: '/operation/membership/index',
      meta: {
        title: 'menus.operation.membership',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'coupon',
      name: 'Coupon',
      component: '/operation/coupon/index',
      meta: {
        title: 'menus.operation.coupon',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'points',
      name: 'Points',
      component: '/operation/points/index',
      meta: {
        title: 'menus.operation.points',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'experience',
      name: 'ExperienceLevel',
      component: '/operation/experience/index',
      meta: {
        title: 'menus.operation.experience',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'plugins',
      name: 'Plugins',
      component: '/operation/plugins/index',
      meta: {
        title: 'menus.operation.plugins',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'title',
      name: 'TitleManage',
      component: '/operation/title/index',
      meta: {
        title: '称号管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'commission',
      name: 'CommissionManage',
      component: '/system/commission/index',
      meta: {
        title: '推广返佣',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'filepolicy',
      name: 'FilePolicyManage',
      component: '/system/filepolicy/index',
      meta: {
        title: '文件上传策略',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'membership-products',
      name: 'MembershipProducts',
      component: '/operation/membership-products/index',
      meta: {
        title: '会员商品',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'membership-purchases',
      name: 'MembershipPurchases',
      component: '/operation/membership-purchases/index',
      meta: {
        title: '购买记录',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'content-purchases',
      name: 'ContentPurchases',
      component: '/operation/content-purchases/index',
      meta: {
        title: '付费内容订单',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'checkin',
      name: 'CheckinManage',
      component: '/operation/checkin/index',
      meta: {
        title: '签到管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'settlement',
      name: 'SettlementManage',
      component: '/operation/settlement/index',
      meta: {
        title: '结算规则',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'themes',
      name: 'ThemesManage',
      component: '/operation/themes/index',
      meta: {
        title: '主题管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'avatar-frame',
      name: 'AvatarFrameManage',
      component: '/operation/avatar-frame/index',
      meta: {
        title: '头像框管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'payment-config',
      name: 'PaymentConfig',
      component: '/operation/payment-config/index',
      meta: {
        title: '支付配置',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'recharge-amounts',
      name: 'RechargeAmounts',
      component: '/operation/recharge-amounts/index',
      meta: {
        title: '充值金额配置',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    }
  ]
}
