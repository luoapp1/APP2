import { AppRouteRecord } from '@/types/router'

export const operationRoutes: AppRouteRecord = {
  path: '/operation',
  name: 'Operation',
  component: '/index/index',
  meta: {
    title: 'menus.operation.title',
    icon: 'ri:settings-3-line',
    roles: ['R_SUPER', 'R_ADMIN']
  },
  children: [
    {
      path: 'cardkey',
      name: 'CardKey',
      component: '/operation/cardkey/index',
      meta: {
        title: 'menus.operation.cardkey',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'membership',
      name: 'Membership',
      component: '/operation/membership/index',
      meta: {
        title: 'menus.operation.membership',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'points',
      name: 'Points',
      component: '/operation/points/index',
      meta: {
        title: 'menus.operation.points',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'experience',
      name: 'ExperienceLevel',
      component: '/operation/experience/index',
      meta: {
        title: 'menus.operation.experience',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'plugins',
      name: 'Plugins',
      component: '/operation/plugins/index',
      meta: {
        title: 'menus.operation.plugins',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    }
  ]
}
