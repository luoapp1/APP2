import { AppRouteRecord } from '@/types/router'

export const appstoreRoutes: AppRouteRecord = {
  path: '/appstore',
  name: 'AppStore',
  component: '/index/index',
  meta: {
    title: 'menus.appstore.title',
    icon: 'ri:apps-2-line',
    roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
  },
  children: [
    {
      path: 'list',
      name: 'AppStoreList',
      component: '/appstore/list',
      meta: {
        title: 'menus.appstore.list',
        keepAlive: true
      }
    },
    {
      path: 'detail/:id',
      name: 'AppStoreDetail',
      component: '/appstore/detail',
      meta: {
        title: 'menus.appstore.detail',
        isHide: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER'],
        keepAlive: false
      }
    },
    {
      path: 'category-manage',
      name: 'AppCategory',
      component: '/appstore/category',
      meta: {
        title: 'menus.appstore.category',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'reports',
      name: 'AppReports',
      component: '/appstore/reports',
      meta: {
        title: 'menus.appstore.reports',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'my-submissions',
      name: 'MySubmissions',
      component: '/appstore/submissions',
      meta: {
        title: 'menus.appstore.mySubmissions',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    },
    {
      path: 'review',
      name: 'SubmissionReview',
      component: '/appstore/review',
      meta: {
        title: 'menus.appstore.review',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'review-mobile',
      name: 'SubmissionReviewMobile',
      component: '/appstore/review/mobile',
      meta: {
        title: 'menus.appstore.review',
        isHide: true,
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'official-tags',
      name: 'OfficialTags',
      component: '/appstore/official-tags',
      meta: {
        title: 'menus.appstore.officialTags',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    }
  ]
}
