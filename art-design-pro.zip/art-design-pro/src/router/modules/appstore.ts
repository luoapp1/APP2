import { AppRouteRecord } from '@/types/router'

export const appstoreRoutes: AppRouteRecord = {
  path: '/appstore',
  name: 'AppStore',
  component: '/index/index',
  meta: {
    title: 'menus.appstore.title',
    icon: 'ri:apps-2-line',
    roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
  },
  children: [
    {
      path: 'list',
      name: 'AppStoreList',
      component: '/appstore/list',
      meta: {
        title: 'menus.appstore.list',
        keepAlive: true
      }
    },
    {
      path: 'detail/:id',
      name: 'AppStoreDetail',
      component: '/appstore/detail',
      meta: {
        title: 'menus.appstore.detail',
        isHide: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER'],
        keepAlive: false
      }
    },
    {
      path: 'category-manage',
      name: 'AppCategory',
      component: '/appstore/category',
      meta: {
        title: 'menus.appstore.category',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'reports',
      name: 'AppReports',
      component: '/appstore/reports',
      meta: {
        title: 'menus.appstore.reports',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'my-submissions',
      name: 'MySubmissions',
      component: '/appstore/submissions',
      meta: {
        title: 'menus.appstore.mySubmissions',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN', 'R_USER']
      }
    },
    {
      path: 'review',
      name: 'SubmissionReview',
      component: '/appstore/review',
      meta: {
        title: 'menus.appstore.review',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'review-mobile',
      name: 'SubmissionReviewMobile',
      component: '/appstore/review/mobile',
      meta: {
        title: 'menus.appstore.review',
        isHide: true,
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'official-tags',
      name: 'OfficialTags',
      component: '/appstore/official-tags',
      meta: {
        title: 'menus.appstore.officialTags',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-manage',
      name: 'MallManage',
      component: '/appstore/admin/mall/mall-manage',
      meta: {
        title: '商品管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-product-create',
      name: 'MallProductCreate',
      component: '/appstore/admin/mall/mall-product-create',
      meta: {
        title: '商品编辑',
        isHide: true,
        keepAlive: false,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-orders',
      name: 'MallOrders',
      component: '/appstore/admin/mall/mall-orders',
      meta: {
        title: '订单管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-categories',
      name: 'MallCategories',
      component: '/appstore/admin/mall/mall-categories',
      meta: {
        title: '分类管理',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-after-sales',
      name: 'MallAfterSales',
      component: '/appstore/admin/mall/mall-after-sales',
      meta: {
        title: '售后服务',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    },
    {
      path: 'mall-promotions',
      name: 'MallPromotions',
      component: '/appstore/admin/mall/mall-promotions',
      meta: {
        title: '优惠活动',
        keepAlive: true,
        roles: ['R_SUPER', 'R_ADMIN']
      }
    }
  ]
}
