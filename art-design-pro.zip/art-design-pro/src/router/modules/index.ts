import { AppRouteRecord } from '@/types/router'
import { dashboardRoutes } from './dashboard'
import { systemRoutes } from './system'
import { resultRoutes } from './result'
import { exceptionRoutes } from './exception'
import { operationRoutes } from './operation'
import { appstoreRoutes } from './appstore'

/**
 * 导出所有模块化路由
 */
export const routeModules: AppRouteRecord[] = [
  dashboardRoutes,
  systemRoutes,
  operationRoutes,
  appstoreRoutes,
  resultRoutes,
  exceptionRoutes
]
