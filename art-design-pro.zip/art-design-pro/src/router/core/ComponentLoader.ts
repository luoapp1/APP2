/**
 * 组件加载器
 *
 * 负责动态加载 Vue 组件
 *
 * @module router/core/ComponentLoader
 * @author Art Design Pro Team
 */

import { h } from 'vue'

export class ComponentLoader {
  private modules: Record<string, () => Promise<any>>

  constructor() {
    this.modules = {
      ...import.meta.glob('../../views/**/*.vue'),
      ...import.meta.glob('../../themes/mobile/views/**/*.vue'),
      ...import.meta.glob('../../themes/pc/views/**/*.vue')
    }
  }

  /**
   * 加载组件
   */
  load(componentPath: string): () => Promise<any> {
    if (!componentPath) {
      return this.createEmptyComponent()
    }

    const paths = [
      `../../views${componentPath}.vue`,
      `../../views${componentPath}/index.vue`,
      `../../themes/mobile/views${componentPath}.vue`,
      `../../themes/mobile/views${componentPath}/index.vue`,
      `../../themes/pc/views${componentPath}.vue`,
      `../../themes/pc/views${componentPath}/index.vue`
    ]

    for (const p of paths) {
      if (this.modules[p]) return this.modules[p]
    }
  }

  /**
   * 加载布局组件
   */
  loadLayout(): () => Promise<any> {
    return () => import('@/views/index/index.vue')
  }

  /**
   * 加载 iframe 组件
   */
  loadIframe(): () => Promise<any> {
    return () => import('@/views/outside/Iframe.vue')
  }

  /**
   * 创建空组件
   */
  private createEmptyComponent(): () => Promise<any> {
    return () =>
      Promise.resolve({
        render() {
          return h('div', {})
        }
      })
  }

  /**
   * 创建错误提示组件
   */
  private createErrorComponent(componentPath: string): () => Promise<any> {
    return () =>
      Promise.resolve({
        render() {
          return h('div', { class: 'route-error' }, `组件未找到: ${componentPath}`)
        }
      })
  }
}
