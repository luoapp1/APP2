import { AppRouteRecordRaw } from '@/utils/router'

/**
 * 静态路由配置（不需要权限就能访问的路由）
 *
 * 属性说明：
 * isHideTab: true 表示不在标签页中显示
 *
 * 注意事项：
 * 1、path、name 不要和动态路由冲突，否则会导致路由冲突无法访问
 * 2、静态路由不管是否登录都可以访问
 */
export const staticRoutes: AppRouteRecordRaw[] = [
  // 公开应用商店浏览页（无需登录）
  {
    path: '/appstore/browse',
    name: 'AppStoreBrowse',
    component: () => import('@views/appstore/browse/index.vue'),
    meta: { title: '应用商店', isHideTab: true }
  },
  // 公开应用详情页（无需登录）
  {
    path: '/appstore/browse/detail/:id',
    name: 'AppStoreBrowseDetail',
    component: () => import('@views/appstore/browse/detail.vue'),
    meta: { title: '应用详情', isHideTab: true }
  },
  // 公开应用分类页（无需登录）
  {
    path: '/appstore/category',
    name: 'AppStoreCategory',
    component: () => import('@views/appstore/browse/category.vue'),
    meta: { title: '应用分类', isHideTab: true }
  },
  // 公开登录页（无需登录）
  {
    path: '/appstore/browse/login',
    name: 'AppStoreLogin',
    component: () => import('@views/appstore/browse/login.vue'),
    meta: { title: '登录', isHideTab: true }
  },
  // 发现页（通知/私信）
  {
    path: '/appstore/game',
    name: 'AppStoreDiscover',
    component: () => import('@views/appstore/browse/game.vue'),
    meta: { title: '发现', isHideTab: true }
  },
  // 系统通知页
  {
    path: '/appstore/discover/system',
    name: 'DiscoverSystem',
    component: () => import('@views/appstore/browse/discover-system.vue'),
    meta: { title: '系统通知', isHideTab: true }
  },
  // 评论消息页
  {
    path: '/appstore/discover/comments',
    name: 'DiscoverComments',
    component: () => import('@views/appstore/browse/discover-system.vue'),
    meta: { title: '评论消息', isHideTab: true }
  },
  // 私信聊天页
  {
    path: '/appstore/discover/chat/:targetUserId',
    name: 'DiscoverChat',
    component: () => import('@views/appstore/browse/discover-chat.vue'),
    meta: { title: '聊天', isHideTab: true }
  },
  // 公开应用更新页（无需登录）
  {
    path: '/appstore/updates',
    name: 'AppStoreUpdates',
    component: () => import('@views/appstore/browse/updates.vue'),
    meta: { title: '应用更新', isHideTab: true }
  },
  // 公开我的页（无需登录）
  {
    path: '/appstore/mine',
    name: 'AppStoreMine',
    component: () => import('@views/appstore/browse/mine.vue'),
    meta: { title: '我的', isHideTab: true }
  },
  // 前台我的投稿页（登录后可用）
  {
    path: '/appstore/submissions',
    name: 'AppStoreSubmissions',
    component: () => import('@views/appstore/submissions/index.vue'),
    meta: { title: '我的投稿', isHideTab: true }
  },
  // 文件选择页
  {
    path: '/appstore/submissions/file-picker',
    name: 'AppStoreFilePicker',
    component: () => import('@views/appstore/submissions/file-picker.vue'),
    meta: { title: '选择安装包', isHideTab: true }
  },
  // 投稿编辑页
  {
    path: '/appstore/submissions/edit',
    name: 'AppStoreSubmissionEdit',
    component: () => import('@views/appstore/submissions/edit-form.vue'),
    meta: { title: '应用信息', isHideTab: true }
  },
  // 投稿成功页
  {
    path: '/appstore/submissions/success',
    name: 'AppStoreSubmissionSuccess',
    component: () => import('@views/appstore/submissions/success.vue'),
    meta: { title: '提交完成', isHideTab: true }
  },
  // 用户个人主页
  {
    path: '/appstore/profile/:userId?',
    name: 'AppStoreProfile',
    component: () => import('@views/appstore/browse/profile.vue'),
    meta: { title: '个人主页', isHideTab: true }
  },
  // 编辑个人信息
  {
    path: '/appstore/profile/edit',
    name: 'AppStoreProfileEdit',
    component: () => import('@views/appstore/browse/profile-edit.vue'),
    meta: { title: '编辑资料', isHideTab: true }
  },
  // 用户评论记录
  {
    path: '/appstore/profile/comments',
    name: 'AppStoreProfileComments',
    component: () => import('@views/appstore/browse/profile-comments.vue'),
    meta: { title: '我的评论', isHideTab: true }
  },
  // 测试页面
  {
    path: '/test-detail/:id',
    name: 'TestDetail',
    component: () => import('@views/appstore/browse/test.vue'),
    meta: { title: '测试', isHideTab: true }
  },
  // 社区板块列表
  {
    path: '/community',
    name: 'CommunitySections',
    component: () => import('@views/appstore/community/sections.vue'),
    meta: { title: '社区', isHideTab: true }
  },
  // 社区板块帖子列表
  {
    path: '/community/section/:id',
    name: 'CommunityForum',
    component: () => import('@views/appstore/community/forum.vue'),
    meta: { title: '板块', isHideTab: true }
  },
  // 社区帖子详情
  {
    path: '/community/post/:id',
    name: 'CommunityPostDetail',
    component: () => import('@views/appstore/community/post-detail.vue'),
    meta: { title: '帖子详情', isHideTab: true }
  },
  // 社区发帖/编辑
  {
    path: '/community/post/create/:sectionId?',
    name: 'CommunityPostCreate',
    component: () => import('@views/appstore/community/post-edit.vue'),
    meta: { title: '发帖', isHideTab: true }
  },
  // 社区编辑帖子
  {
    path: '/community/post/edit/:id',
    name: 'CommunityPostEdit',
    component: () => import('@views/appstore/community/post-edit.vue'),
    meta: { title: '编辑帖子', isHideTab: true }
  },
  // 投稿审核页（手机端，仅管理员可访问）
  {
    path: '/appstore/review-mobile',
    name: 'AppStoreReviewMobile',
    component: () => import('@views/appstore/review/mobile.vue'),
    meta: { title: '投稿审核', isHideTab: true }
  },
  // 板块管理
  {
    path: '/appstore/section-manage',
    name: 'SectionManage',
    component: () => import('@views/appstore/section-manage/index.vue'),
    meta: { title: '板块管理', isHideTab: true }
  },
  // 不需要登录就能访问的路由示例
  // {
  //   path: '/welcome',
  //   name: 'WelcomeStatic',
  //   component: () => import('@views/dashboard/console/index.vue'),
  //   meta: { title: 'menus.dashboard.title' }
  // },
  {
    path: '/auth/login',
    name: 'Login',
    component: () => import('@views/auth/login/index.vue'),
    meta: { title: 'menus.login.title', isHideTab: true }
  },
  {
    path: '/auth/register',
    name: 'Register',
    component: () => import('@views/auth/register/index.vue'),
    meta: { title: 'menus.register.title', isHideTab: true }
  },
  {
    path: '/auth/forget-password',
    name: 'ForgetPassword',
    component: () => import('@views/auth/forget-password/index.vue'),
    meta: { title: 'menus.forgetPassword.title', isHideTab: true }
  },
  {
    path: '/403',
    name: 'Exception403',
    component: () => import('@views/exception/403/index.vue'),
    meta: { title: '403', isHideTab: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'Exception404',
    component: () => import('@views/exception/404/index.vue'),
    meta: { title: '404', isHideTab: true }
  },
  {
    path: '/500',
    name: 'Exception500',
    component: () => import('@views/exception/500/index.vue'),
    meta: { title: '500', isHideTab: true }
  },
  {
    path: '/outside',
    component: () => import('@views/index/index.vue'),
    name: 'Outside',
    meta: { title: 'menus.outside.title' },
    children: [
      // iframe 内嵌页面
      {
        path: '/outside/iframe/:path',
        name: 'Iframe',
        component: () => import('@/views/outside/Iframe.vue'),
        meta: { title: 'iframe' }
      }
    ]
  }
]
