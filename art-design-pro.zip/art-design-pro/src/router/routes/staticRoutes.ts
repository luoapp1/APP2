import { AppRouteRecordRaw } from '@/utils/router'
import { themeComponent } from '@/utils/theme'

/**
 * 静态路由配置（不需要权限就能访问的路由）
 */
export const staticRoutes: AppRouteRecordRaw[] = [
  {
    path: '/appstore/browse',
    name: 'AppStoreBrowse',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/index.vue'),
      () => import('@/themes/pc/views/browse/index.vue')
    ),
    meta: { title: '应用市场', isHideTab: true }
  },
  {
    path: '/appstore/ranking',
    name: 'AppStoreRanking',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/ranking.vue'),
      () => import('@/themes/pc/views/appstore/ranking.vue')
    ),
    meta: { title: '排行榜', isHideTab: true }
  },
  {
    path: '/appstore/browse/detail/:id',
    name: 'AppStoreBrowseDetail',
    alias: '/a/:id',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/detail.vue'),
      () => import('@/themes/pc/views/appstore/browse/detail.vue')
    ),
    meta: { title: '应用详情', isHideTab: true }
  },
  {
    path: '/appstore/category',
    name: 'AppStoreCategory',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/category.vue'),
      () => import('@/themes/pc/views/appstore/category.vue')
    ),
    meta: { title: '应用分类', isHideTab: true }
  },
  {
    path: '/appstore/browse/login',
    name: 'AppStoreLogin',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/login.vue'),
      () => import('@/themes/pc/views/appstore/browse/login.vue')
    ),
    meta: { title: '登录', isHideTab: true }
  },
  {
    path: '/appstore/game',
    name: 'AppStoreDiscover',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/game.vue'),
      () => import('@/themes/pc/views/appstore/game.vue')
    ),
    meta: { title: '发现', isHideTab: true }
  },
  {
    path: '/appstore/discover/system',
    name: 'DiscoverSystem',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/discover-system.vue'),
      () => import('@/themes/pc/views/appstore/discover-system.vue')
    ),
    meta: { title: '系统通知', isHideTab: true }
  },
  {
    path: '/appstore/discover/comments',
    name: 'DiscoverComments',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/discover-system.vue'),
      () => import('@/themes/pc/views/appstore/discover-comments.vue')
    ),
    meta: { title: '评论消息', isHideTab: true }
  },
  {
    path: '/appstore/discover/chat/:targetUserId',
    name: 'DiscoverChat',
    alias: '/chat/:targetUserId',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/discover-chat.vue'),
      () => import('@/themes/pc/views/appstore/discover-chat.vue')
    ),
    meta: { title: '聊天', isHideTab: true }
  },
  {
    path: '/appstore/discover/chatrooms',
    name: 'ChatRooms',
    alias: '/chatrooms',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/chatrooms.vue'),
      () => import('@/themes/pc/views/appstore/discover-chat.vue')
    ),
    meta: { title: '聊天室', isHideTab: true }
  },
  {
    path: '/appstore/discover/chatroom/:roomId',
    name: 'ChatRoomChat',
    alias: '/chatroom/:roomId',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/chatroom-chat.vue'),
      () => import('@/themes/pc/views/appstore/discover-chat.vue')
    ),
    meta: { title: '聊天室', isHideTab: true }
  },
  {
    path: '/appstore/updates',
    name: 'AppStoreUpdates',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/updates.vue'),
      () => import('@/themes/pc/views/appstore/updates.vue')
    ),
    meta: { title: '应用更新', isHideTab: true }
  },
  {
    path: '/appstore/mine',
    name: 'AppStoreMine',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/mine.vue'),
      () => import('@/themes/pc/views/appstore/mine.vue')
    ),
    meta: { title: '我的', isHideTab: true }
  },
  {
    path: '/appstore/admin-center',
    name: 'AdminCenter',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/admin-center.vue'),
      () => import('@/themes/mobile/views/appstore/admin/admin-center.vue')
    ),
    meta: { title: '管理员中心', isHideTab: true }
  },
  {
    path: '/appstore/site-config',
    name: 'SiteConfig',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/site-config.vue'),
      () => import('@/themes/mobile/views/appstore/admin/site-config.vue')
    ),
    meta: { title: '基础配置', isHideTab: true }
  },
  {
    path: '/appstore/experience',
    name: 'AppStoreExperience',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/experience.vue'),
      () => import('@/themes/pc/views/appstore/experience.vue')
    ),
    meta: { title: '经验详情', isHideTab: true }
  },
  {
    path: '/appstore/footprints',
    name: 'AppStoreFootprints',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/footprints.vue'),
      () => import('@/themes/pc/views/appstore/footprints.vue')
    ),
    meta: { title: '浏览足迹', isHideTab: true }
  },
  {
    path: '/appstore/avatar-frame',
    name: 'AppStoreAvatarFrame',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/avatar-frame.vue'),
      () => import('@/themes/pc/views/appstore/avatar-frame.vue')
    ),
    meta: { title: '头像管理', isHideTab: true }
  },
  {
    path: '/appstore/verification',
    name: 'AppStoreVerification',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/verification.vue'),
      () => import('@/themes/mobile/views/appstore/browse/verification.vue')
    ),
    meta: { title: '我的认证', isHideTab: true }
  },
  {
    path: '/appstore/invite',
    name: 'AppStoreInvite',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/invite.vue'),
      () => import('@/themes/pc/views/appstore/invite.vue')
    ),
    meta: { title: '邀请福利', isHideTab: true }
  },
  {
    path: '/appstore/checkin',
    name: 'AppStoreCheckin',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/checkin.vue'),
      () => import('@/themes/pc/views/appstore/checkin.vue')
    ),
    meta: { title: '签到', isHideTab: true }
  },
  {
    path: '/appstore/records',
    name: 'AppStoreRecords',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/records.vue'),
      () => import('@/themes/pc/views/appstore/records.vue')
    ),
    meta: { title: '明细', isHideTab: true }
  },
  {
    path: '/appstore/assets',
    name: 'AppStoreAssets',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/assets.vue'),
      () => import('@/themes/pc/views/appstore/assets.vue')
    ),
    meta: { title: '我的资产', isHideTab: true }
  },
  {
    path: '/appstore/membership',
    name: 'AppStoreMembership',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/membership.vue'),
      () => import('@/themes/pc/views/appstore/membership.vue')
    ),
    meta: { title: '会员中心', isHideTab: true }
  },
  {
    path: '/appstore/coupon',
    name: 'AppStoreCoupon',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/coupon.vue'),
      () => import('@/themes/pc/views/appstore/coupon.vue')
    ),
    meta: { title: '优惠券中心', isHideTab: true }
  },
  {
    path: '/appstore/submissions',
    name: 'AppStoreSubmissions',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/submissions/index.vue'),
      () => import('@/themes/pc/views/appstore/submissions/index.vue')
    ),
    meta: { title: '我的投稿', isHideTab: true }
  },
  {
    path: '/appstore/submissions/file-picker',
    name: 'AppStoreFilePicker',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/submissions/file-picker.vue'),
      () => import('@/themes/pc/views/appstore/submissions/file-picker.vue')
    ),
    meta: { title: '选择安装包', isHideTab: true }
  },
  {
    path: '/appstore/submissions/edit',
    name: 'AppStoreSubmissionEdit',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/submissions/edit-form.vue'),
      () => import('@/themes/pc/views/appstore/submissions/edit.vue')
    ),
    meta: { title: '应用信息', isHideTab: true }
  },
  {
    path: '/appstore/submissions/success',
    name: 'AppStoreSubmissionSuccess',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/submissions/success.vue'),
      () => import('@/themes/pc/views/appstore/submissions/success.vue')
    ),
    meta: { title: '提交完成', isHideTab: true }
  },
  {
    path: '/appstore/profile/edit',
    name: 'AppStoreProfileEdit',
    alias: '/u/edit',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/profile-edit.vue'),
      () => import('@/themes/pc/views/appstore/profile-edit.vue')
    ),
    meta: { title: '编辑资料', isHideTab: true }
  },
  {
    path: '/appstore/profile/comments',
    name: 'AppStoreProfileComments',
    alias: '/u/comments',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/profile-comments.vue'),
      () => import('@/themes/pc/views/appstore/profile-comments.vue')
    ),
    meta: { title: '我的评论', isHideTab: true }
  },
  {
    path: '/appstore/profile/:userId?',
    name: 'AppStoreProfile',
    alias: '/u/:userId?',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/profile.vue'),
      () => import('@/themes/pc/views/appstore/profile.vue')
    ),
    meta: { title: '个人主页', isHideTab: true }
  },
  {
    path: '/test-detail/:id',
    name: 'TestDetail',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/browse/test.vue'),
      () => import('@/themes/pc/views/appstore/test-detail.vue')
    ),
    meta: { title: '测试', isHideTab: true }
  },
  {
    path: '/community',
    name: 'CommunitySections',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/sections.vue'),
      () => import('@/themes/pc/views/appstore/community/sections.vue')
    ),
    meta: { title: '社区', isHideTab: true }
  },
  {
    path: '/community/search',
    name: 'CommunitySearch',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/search.vue'),
      () => import('@/themes/pc/views/appstore/community/search.vue')
    ),
    meta: { title: '搜索', isHideTab: true }
  },
  {
    path: '/community/section/:id',
    name: 'CommunityForum',
    alias: '/s/:id',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/forum.vue'),
      () => import('@/themes/pc/views/appstore/community/forum.vue')
    ),
    meta: { title: '板块', isHideTab: true }
  },
  {
    path: '/community/post/create/:sectionId?',
    name: 'CommunityPostCreate',
    alias: '/p/create/:sectionId?',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/post-edit.vue'),
      () => import('@/themes/pc/views/appstore/community/post-create.vue')
    ),
    meta: { title: '发帖', isHideTab: true }
  },
  {
    path: '/community/post/edit/:id',
    name: 'CommunityPostEdit',
    alias: '/p/edit/:id',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/post-edit.vue'),
      () => import('@/themes/pc/views/appstore/community/post-edit.vue')
    ),
    meta: { title: '编辑帖子', isHideTab: true }
  },
  {
    path: '/community/post/:id',
    name: 'CommunityPostDetail',
    alias: '/p/:id',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/post-detail.vue'),
      () => import('@/themes/pc/views/appstore/community/post-detail.vue')
    ),
    meta: { title: '帖子详情', isHideTab: true }
  },
  {
    path: '/community/topic/create',
    name: 'CommunityTopicCreate',
    alias: '/t/create',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/topic-create.vue'),
      () => import('@/themes/pc/views/appstore/community/topic-create.vue')
    ),
    meta: { title: '创建话题', isHideTab: true }
  },
  {
    path: '/community/topic/:id',
    name: 'CommunityTopicPosts',
    alias: '/t/:id',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/topic-posts.vue'),
      () => import('@/themes/pc/views/appstore/community/topic-posts.vue')
    ),
    meta: { title: '话题', isHideTab: true }
  },
  {
    path: '/community/game-hall',
    name: 'CommunityGameHall',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/game-hall.vue'),
      () => import('@/themes/pc/views/appstore/community/game-hall.vue')
    ),
    meta: { title: '游戏大厅', isHideTab: true }
  },
  {
    path: '/community/game-hall/lottery',
    name: 'CommunityGameLottery',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/game-lottery.vue'),
      () => import('@/themes/pc/views/appstore/community/game-lottery.vue')
    ),
    meta: { title: '金币抽奖', isHideTab: true }
  },
  {
    path: '/community/game-hall/card-guess',
    name: 'CommunityGameCardGuess',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/game-card-guess.vue'),
      () => import('@/themes/pc/views/appstore/community/game-card-guess.vue')
    ),
    meta: { title: '卡片竞猜', isHideTab: true }
  },
  {
    path: '/community/game-hall/dice',
    name: 'CommunityGameDice',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/game-dice.vue'),
      () => import('@/themes/pc/views/appstore/community/game-dice.vue')
    ),
    meta: { title: '大小竞猜', isHideTab: true }
  },
  {
    path: '/community/game-hall/rps',
    name: 'CommunityGameRps',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/community/game-rps.vue'),
      () => import('@/themes/pc/views/appstore/community/game-rps.vue')
    ),
    meta: { title: '剪刀石头布', isHideTab: true }
  },
  {
    path: '/appstore/topic-manage',
    name: 'AppStoreTopicManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/topic-manage.vue'),
      () => import('@/themes/pc/views/appstore/topic-manage.vue')
    ),
    meta: { title: '话题管理', isHideTab: true }
  },
  {
    path: '/appstore/review-mobile',
    name: 'AppStoreReviewMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/review-mobile.vue'),
      () => import('@/themes/pc/views/appstore/review-mobile.vue')
    ),
    meta: { title: '投稿审核', isHideTab: true }
  },
  {
    path: '/appstore/section-manage',
    name: 'SectionManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/section-manage.vue'),
      () => import('@/themes/pc/views/appstore/section-manage.vue')
    ),
    meta: { title: '板块管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/membership',
    name: 'MembershipManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/membership-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/membership-manage.vue')
    ),
    meta: { title: '会员管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/points',
    name: 'PointsManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/points-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/points-manage.vue')
    ),
    meta: { title: '积分管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/coupon',
    name: 'CouponManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/coupon-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/coupon-manage.vue')
    ),
    meta: { title: '优惠券管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/checkin',
    name: 'CheckinManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/checkin-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/checkin-manage.vue')
    ),
    meta: { title: '签到管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/membership-products',
    name: 'MembershipProductsMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/membership-products.vue'),
      () => import('@/themes/mobile/views/appstore/admin/membership-products.vue')
    ),
    meta: { title: '会员商品', isHideTab: true }
  },
  {
    path: '/appstore/operation/purchase-records',
    name: 'PurchaseRecordsMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/purchase-records.vue'),
      () => import('@/themes/mobile/views/appstore/admin/purchase-records.vue')
    ),
    meta: { title: '购买记录', isHideTab: true }
  },
  {
    path: '/appstore/operation/avatar-frame',
    name: 'AvatarFrameManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/avatar-frame-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/avatar-frame-manage.vue')
    ),
    meta: { title: '头像框管理', isHideTab: true }
  },
  {
    path: '/appstore/operation/content-purchases',
    name: 'ContentPurchasesMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/content-purchases.vue'),
      () => import('@/themes/mobile/views/appstore/admin/content-purchases.vue')
    ),
    meta: { title: '付费内容订单', isHideTab: true }
  },
  {
    path: '/appstore/operation/payment-config',
    name: 'PaymentConfigMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/payment-config.vue'),
      () => import('@/themes/mobile/views/appstore/admin/payment-config.vue')
    ),
    meta: { title: '支付配置', isHideTab: true }
  },
  {
    path: '/appstore/operation/settlement',
    name: 'SettlementMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/settlement.vue'),
      () => import('@/themes/mobile/views/appstore/admin/settlement.vue')
    ),
    meta: { title: '结算规则', isHideTab: true }
  },
  {
    path: '/appstore/operation/recharge-amounts',
    name: 'RechargeAmountsMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/recharge-amounts.vue'),
      () => import('@/themes/mobile/views/appstore/admin/recharge-amounts.vue')
    ),
    meta: { title: '充值金额配置', isHideTab: true }
  },
  {
    path: '/appstore/operation/game-center',
    name: 'GameCenterMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/game-center-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/game-center-manage.vue')
    ),
    meta: { title: '游戏中心', isHideTab: true }
  },
  {
    path: '/appstore/user-manage',
    name: 'UserManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/user-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/user-manage.vue')
    ),
    meta: { title: '用户管理', isHideTab: true }
  },
  {
    path: '/appstore/role-manage',
    name: 'RoleManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/role-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/role-manage.vue')
    ),
    meta: { title: '角色管理', isHideTab: true }
  },
  {
    path: '/appstore/cardkey-manage',
    name: 'CardKeyManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/cardkey-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/cardkey-manage.vue')
    ),
    meta: { title: '卡密管理', isHideTab: true }
  },
  {
    path: '/appstore/delete-review',
    name: 'DeleteReviewMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/delete-review.vue'),
      () => import('@/themes/mobile/views/appstore/admin/delete-review.vue')
    ),
    meta: { title: '注销审核', isHideTab: true }
  },
  {
    path: '/appstore/verification-manage',
    name: 'VerificationManage',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/verification-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/verification-manage.vue')
    ),
    meta: { title: '蓝V认证审核', isHideTab: true }
  },
  {
    path: '/appstore/syslog',
    name: 'SyslogMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/syslog.vue'),
      () => import('@/themes/mobile/views/appstore/admin/syslog.vue')
    ),
    meta: { title: '系统日志', isHideTab: true }
  },
  {
    path: '/appstore/recycle',
    name: 'RecycleBinMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/recycle.vue'),
      () => import('@/themes/mobile/views/appstore/admin/recycle.vue')
    ),
    meta: { title: '回收站', isHideTab: true }
  },
  {
    path: '/appstore/task-manage',
    name: 'TaskManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/task-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/task-manage.vue')
    ),
    meta: { title: '任务管理', isHideTab: true }
  },
  {
    path: '/appstore/experience-manage',
    name: 'ExperienceMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/experience-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/experience-manage.vue')
    ),
    meta: { title: '经验等级', isHideTab: true }
  },
  {
    path: '/appstore/title-manage',
    name: 'TitleManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/title-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/title-manage.vue')
    ),
    meta: { title: '称号管理', isHideTab: true }
  },
  {
    path: '/appstore/commission-manage',
    name: 'CommissionManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/commission-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/commission-manage.vue')
    ),
    meta: { title: '推广返佣', isHideTab: true }
  },
  {
    path: '/appstore/file-repo-manage',
    name: 'FileRepoManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/file-repo-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/file-repo-manage.vue')
    ),
    meta: { title: '文件仓库', isHideTab: true }
  },
  {
    path: '/appstore/file-policy-manage',
    name: 'FilePolicyManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/file-policy-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/file-policy-manage.vue')
    ),
    meta: { title: '文件上传策略', isHideTab: true }
  },
  {
    path: '/appstore/plugin-manage',
    name: 'PluginManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/plugin-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/plugin-manage.vue')
    ),
    meta: { title: '插件管理', isHideTab: true }
  },
  {
    path: '/appstore/email-config',
    name: 'EmailConfigMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/email-config.vue'),
      () => import('@/themes/mobile/views/appstore/admin/email-config.vue')
    ),
    meta: { title: '邮件配置', isHideTab: true }
  },
  {
    path: '/appstore/email-templates',
    name: 'EmailTemplatesMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/email-templates.vue'),
      () => import('@/themes/mobile/views/appstore/admin/email-templates.vue')
    ),
    meta: { title: '邮件卡片', isHideTab: true }
  },
  {
    path: '/appstore/email-push',
    name: 'EmailPushMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/email-push.vue'),
      () => import('@/themes/mobile/views/appstore/admin/email-push.vue')
    ),
    meta: { title: '邮件推送', isHideTab: true }
  },
  {
    path: '/appstore/menu-manage',
    name: 'MenuManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/menu-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/menu-manage.vue')
    ),
    meta: { title: '菜单管理', isHideTab: true }
  },
  {
    path: '/appstore/invite-manage',
    name: 'InviteManageMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/invite-manage.vue'),
      () => import('@/themes/mobile/views/appstore/admin/invite-manage.vue')
    ),
    meta: { title: '邀请码管理', isHideTab: true }
  },
  {
    path: '/appstore/storage-config',
    name: 'StorageConfigMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/storage-config.vue'),
      () => import('@/themes/mobile/views/appstore/admin/storage-config.vue')
    ),
    meta: { title: '对象存储', isHideTab: true }
  },
  {
    path: '/appstore/storage-files',
    name: 'StorageFilesMobile',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/storage-files.vue'),
      () => import('@/themes/mobile/views/appstore/admin/storage-files.vue')
    ),
    meta: { title: '存储文件', isHideTab: true }
  },
  {
    path: '/auth/login',
    name: 'Login',
    component: () => import('@views/auth/login/index.vue'),
    meta: { title: 'menus.login.title', isHideTab: true }
  },
  {
    path: '/auth/register',
    name: 'Register',
    component: () => import('@views/auth/register/index.vue'),
    meta: { title: 'menus.register.title', isHideTab: true }
  },
  {
    path: '/auth/forget-password',
    name: 'ForgetPassword',
    component: () => import('@views/auth/forget-password/index.vue'),
    meta: { title: 'menus.forgetPassword.title', isHideTab: true }
  },
  {
    path: '/appstore/mall-detail/:id',
    name: 'MallDetail',
    component: () => import('@/themes/mobile/views/appstore/mall/detail.vue'),
    meta: { title: '商品详情', isHideTab: true }
  },
  {
    path: '/appstore/mall-reviews/:id',
    name: 'MallReviews',
    component: () => import('@/themes/mobile/views/appstore/mall/reviews.vue'),
    meta: { title: '商品评价', isHideTab: true }
  },
  // 商城管理
  {
    path: '/appstore/mall-manage',
    name: 'MallManage',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-manage.vue'),
    meta: { title: '商品管理', isHideTab: true }
  },
  {
    path: '/appstore/mall-product-create',
    name: 'MallProductCreate',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-product-create.vue'),
    meta: { title: '商品编辑', isHideTab: true }
  },
  {
    path: '/appstore/mall-orders',
    name: 'MallOrders',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-orders.vue'),
    meta: { title: '订单管理', isHideTab: true }
  },
  {
    path: '/appstore/mall-categories',
    name: 'MallCategories',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-categories.vue'),
    meta: { title: '分类管理', isHideTab: true }
  },
  {
    path: '/appstore/mall-after-sales',
    name: 'MallAfterSales',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-after-sales.vue'),
    meta: { title: '售后服务', isHideTab: true }
  },
  {
    path: '/appstore/mall-promotions',
    name: 'MallPromotions',
    component: () => import('@/themes/mobile/views/appstore/admin/mall/mall-promotions.vue'),
    meta: { title: '优惠活动', isHideTab: true }
  },
  {
    path: '/403',
    name: 'Exception403',
    component: () => import('@views/exception/403/index.vue'),
    meta: { title: '403', isHideTab: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'Exception404',
    component: () => import('@views/exception/404/index.vue'),
    meta: { title: '404', isHideTab: true }
  },
  {
    path: '/500',
    name: 'Exception500',
    component: () => import('@views/exception/500/index.vue'),
    meta: { title: '500', isHideTab: true }
  },
  {
    path: '/appstore/mobile-console',
    name: 'MobileConsole',
    component: themeComponent(
      () => import('@/themes/mobile/views/appstore/admin/mobile-console.vue'),
      () => import('@/themes/mobile/views/appstore/admin/mobile-console.vue')
    ),
    meta: { title: '控制台', isHideTab: true }
  },
  {
    path: '/outside',
    component: () => import('@views/index/index.vue'),
    name: 'Outside',
    meta: { title: 'menus.outside.title' },
    children: [
      {
        path: '/outside/iframe/:path',
        name: 'Iframe',
        component: () => import('@/views/outside/Iframe.vue'),
        meta: { title: 'iframe' }
      }
    ]
  }
]
