<template>
  <ElConfigProvider
    size="default"
    :locale="locales[language]"
    :z-index="3000"
    :card="{
      shadow: 'never'
    }"
  >
    <component :is="layoutComponent" v-if="layoutComponent" />
    <MobileTheme v-else-if="isMobile" />
    <PcTheme v-else />
  </ElConfigProvider>
</template>

<script setup lang="ts">
  import { computed, watch, nextTick, ref, onBeforeMount, onMounted } from 'vue'
  import { useRoute } from 'vue-router'
  import { useUserStore } from './store/modules/user'
  import zh from 'element-plus/es/locale/lang/zh-cn'
  import en from 'element-plus/es/locale/lang/en'
  import { systemUpgrade } from './utils/sys'
  import { toggleTransition } from './utils/ui/animation'
  import { checkStorageCompatibility } from './utils/storage'
  import { initializeTheme } from './hooks/core/useTheme'
  import { usePluginInject } from './hooks/core/usePluginInject'
  import { useWindowSize } from '@vueuse/core'
  import MobileTheme from './themes/mobile/default/index.vue'
  import PcTheme from './themes/pc/default/index.vue'

  const route = useRoute()
  const userStore = useUserStore()
  const { language } = storeToRefs(userStore)
  const { loadPlugins, refreshPlugins } = usePluginInject()

  const { width } = useWindowSize()
  const isMobile = computed(() => width.value < 800)
  const layoutComponent = ref<any>(null)

  const locales = {
    zh: zh,
    en: en
  }

  async function loadActiveLayout() {
    layoutComponent.value = null
  }

  watch(isMobile, () => {
    loadActiveLayout()
  })

  watch(() => route.path, () => {
    nextTick(() => {
      document.querySelectorAll('script[data-plugin]').forEach(s => {
        const clone = document.createElement('script')
        clone.setAttribute('data-plugin', s.getAttribute('data-plugin')!)
        clone.textContent = s.textContent
        s.replaceWith(clone)
      })
    })
  })

  onBeforeMount(() => {
    toggleTransition(true)
    initializeTheme()
    loadActiveLayout()
  })

  const publicPages = ['AppStoreLogin', 'Login', 'Register', 'ForgetPassword', 'Exception403', 'Exception404', 'Exception500', 'MobileConsole']

  onMounted(() => {
    checkStorageCompatibility()
    toggleTransition(false)
    if (!publicPages.includes(route.name as string)) {
      systemUpgrade()
      loadPlugins()
    }
  })
</script>
