<template>
  <div class="rte-root" ref="rootRef">
    <div class="rte-toolbar" v-if="active">
      <div class="rt-group">
        <button class="rt-btn" :class="{ 'rt-btn-on': isH2 }" @mousedown.prevent="toggleFormat('header', '2')" title="标题 H2">H2</button>
        <button class="rt-btn" :class="{ 'rt-btn-on': isH3 }" @mousedown.prevent="toggleFormat('header', '3')" title="标题 H3">H3</button>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <select class="rt-select" :value="fontSize" @change="setFontSize" title="字号">
          <option value="">字号</option>
          <option value="12px">12</option>
          <option value="14px">14</option>
          <option value="16px">16</option>
          <option value="18px">18</option>
          <option value="20px">20</option>
          <option value="24px">24</option>
          <option value="28px">28</option>
          <option value="32px">32</option>
        </select>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('bold') }" @mousedown.prevent="toggleFormat('bold')" title="加粗"><b>B</b></button>
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('italic') }" @mousedown.prevent="toggleFormat('italic')" title="斜体"><i>I</i></button>
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('underline') }" @mousedown.prevent="toggleFormat('underline')" title="下划线"><u>U</u></button>
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('strike') }" @mousedown.prevent="toggleFormat('strike')" title="删除线"><s>S</s></button>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('blockquote') }" @mousedown.prevent="toggleFormat('blockquote')" title="引用">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/></svg>
        </button>
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('list', 'ordered') }" @mousedown.prevent="toggleFormat('list', 'ordered')" title="有序列表">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="10" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="18" x2="21" y2="18"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/></svg>
        </button>
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('list', 'bullet') }" @mousedown.prevent="toggleFormat('list', 'bullet')" title="无序列表">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
        </button>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <button class="rt-btn" :class="{ 'rt-btn-on': editorHas('code-block') }" @mousedown.prevent="toggleFormat('code-block')" title="代码块">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
        </button>
        <button class="rt-btn" @mousedown.prevent="insertDivider" title="分割线">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="4" y1="12" x2="20" y2="12"/></svg>
        </button>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <span class="rt-color-wrap" title="文字颜色">
          <input type="color" class="rt-color" v-model="textColor" @change="setColor" />
          <span class="rt-color-label">A</span>
        </span>
        <button class="rt-btn" @mousedown.prevent="removeFormat" title="清除格式">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        </button>
      </div>
      <div class="rt-sep"></div>
      <div class="rt-group">
        <button class="rt-btn" @mousedown.prevent="undo" title="撤销">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 104.61-10.97L1 10"/></svg>
        </button>
        <button class="rt-btn" @mousedown.prevent="redo" title="重做">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-4.61-10.97L23 10"/></svg>
        </button>
      </div>
    </div>
    <div class="rte-editor" ref="editorRef"></div>
    <div v-if="showTopicMenu && topicMenuItems.length > 0" class="rte-topic-menu" :style="{ top: topicMenuPos.top + 'px', left: topicMenuPos.left + 'px' }">
      <button
        v-for="t in topicMenuItems"
        :key="t.id"
        class="rtm-item"
        @mousedown.prevent="selectTopicSuggest(t)"
      >
        <span v-if="t.icon" class="rtm-icon">{{ t.icon }}</span>
        <span class="rtm-name">#{{ t.name }}</span>
        <span v-if="t.postCount" class="rtm-count">{{ t.postCount }} 帖</span>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch, nextTick, computed } from 'vue'
import Quill from 'quill'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import { fetchTopics } from '@/api/community'

const props = defineProps<{
  modelValue: string
  placeholder?: string
  active: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string]
  focus: []
  'topic-selected': [topicId: number, topicName: string]
}>()

const rootRef = ref<HTMLElement>()
const editorRef = ref<HTMLElement>()
const textColor = ref('#343a40')
const fontSize = ref('')

const showTopicMenu = ref(false)
const topicMenuQuery = ref('')
const topicMenuItems = ref<any[]>([])
const topicMenuRange = ref<{ index: number; length: number } | null>(null)
const topicMenuPos = ref({ top: 0, left: 0 })
let skipNextDetect = false

let quill: Quill | null = null
let savedRange: { index: number; length: number } | null = null

const isH2 = computed(() => editorHas('header', '2'))
const isH3 = computed(() => editorHas('header', '3'))

function editorHas(format: string, value?: string): boolean {
  if (!quill) return false
  const range = savedRange || quill.getSelection()
  if (!range) return false
  const formats = quill.getFormat(range)
  if (value) return formats[format] === value
  return !!formats[format]
}

function toggleFormat(format: string, value?: string | boolean) {
  if (!quill) return
  const range = savedRange || quill.getSelection()
  if (!range) return
  const current = quill.getFormat(range)

  if (format === 'header') {
    if (current.header === Number(value)) {
      quill.format('header', false)
    } else {
      quill.format('header', Number(value))
    }
  } else if (format === 'code-block') {
    if (current['code-block']) {
      quill.format('code-block', false)
    } else {
      quill.format('code-block', true)
    }
  } else if (format === 'blockquote') {
    if (current.blockquote) {
      quill.format('blockquote', false)
    } else {
      quill.format('blockquote', true)
    }
  } else if (format === 'list') {
    if (current.list === value) {
      quill.format('list', false)
    } else {
      quill.format('list', value)
    }
  } else {
    const fmt: Record<string, any> = {}
    fmt[format] = !current[format]
    quill.format(format, !current[format])
  }
}

function setColor() {
  if (!quill) return
  let range = savedRange || quill.getSelection()
  if (!range) { quill.focus(); return }
  if (range.length > 0) {
    const text = quill.getText(range.index, range.length)
    quill.deleteText(range.index, range.length)
    quill.clipboard.dangerouslyPasteHTML(range.index, `<span style="color:${textColor.value}">${escapeHtml(text)}</span>`)
  } else {
    quill.format('color', textColor.value)
  }
}

function setFontSize(e: Event) {
  const v = (e.target as HTMLSelectElement).value
  fontSize.value = v
  if (!quill || !v) return
  let range = savedRange || quill.getSelection()
  if (!range) { quill.focus(); return }
  quill.formatText(range.index, Math.max(range.length, 1), 'size', v)
  quill.setSelection(range.index, range.length, 'silent')
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
}

function undo() { if (quill) quill.history.undo() }
function redo() { if (quill) quill.history.redo() }

function removeFormat() {
  if (!quill) return
  const range = savedRange || quill.getSelection()
  if (!range || range.length === 0) return
  quill.removeFormat(range.index, range.length)
}

function insertDivider() {
  if (!quill) return
  const range = savedRange || quill.getSelection()
  if (!range) return
  quill.insertEmbed(range.index, 'divider', true)
  quill.insertText(range.index + 1, '\n')
  quill.setSelection(range.index + 2)
}

const BlockEmbed = Quill.import('blots/block/embed')

class DividerBlot extends BlockEmbed {
  static blotName = 'divider'
  static tagName = 'hr'
}
Quill.register(DividerBlot)

const SizeClass = Quill.import('attributors/class/size')
SizeClass.whitelist = ['12px', '14px', '16px', '18px', '20px', '24px', '28px', '32px']
Quill.register('formats/size', SizeClass, true)

let cachedTopics: any[] | null = null

async function fetchTopicSuggestions(query: string) {
  if (!cachedTopics) {
    try {
      const resp = await fetchTopics({ pageSize: 20 })
      cachedTopics = resp?.list || resp || []
    } catch {
      cachedTopics = []
    }
  }
  const list = cachedTopics
  if (!query) {
    topicMenuItems.value = list.slice(0, 10)
  } else {
    const q = query.toLowerCase()
    topicMenuItems.value = list.filter((t: any) => t.name.toLowerCase().includes(q)).slice(0, 10)
  }
}

function selectTopicSuggest(topic: any) {
  if (!quill || !topicMenuRange.value) return
  const { index, length } = topicMenuRange.value
  quill.deleteText(index, length)
  const topicHref = `/community/topic/${topic.id}`
  quill.insertText(index, `#${topic.name} `, { bold: true, link: topicHref }, 'user')
  quill.setSelection(index + topic.name.length + 2, 0)
  emit('topic-selected', topic.id, topic.name)
  showTopicMenu.value = false
  topicMenuQuery.value = ''
  topicMenuRange.value = null
  skipNextDetect = true
}

function detectTopicTrigger() {
  if (skipNextDetect) { skipNextDetect = false; return }
  if (!quill || !props.active) {
    showTopicMenu.value = false
    return
  }
  const sel = quill.getSelection()
  if (!sel || sel.length > 0) {
    showTopicMenu.value = false
    return
  }
  const startIdx = Math.max(0, sel.index - 50)
  const text = quill.getText(startIdx, sel.index - startIdx)
  const lines = text.split('\n')
  const lastLine = lines[lines.length - 1]
  const match = lastLine.match(/(?:^|\s)#([^\s#]{0,20})$/)
  if (match) {
    const hashIdx = sel.index - match[1].length - 1
    topicMenuQuery.value = match[1]
    topicMenuRange.value = { index: hashIdx, length: match[0].trimStart().length }
    const bounds = quill.getBounds(hashIdx, 0)
    if (bounds) {
      const editorEl = editorRef.value?.querySelector('.ql-editor')
      const rect = editorEl?.getBoundingClientRect()
      if (rect) {
        topicMenuPos.value = {
          top: bounds.bottom + rect.top + 4 - (editorEl?.scrollTop || 0),
          left: bounds.left + rect.left
        }
      }
    }
    fetchTopicSuggestions(match[1])
    showTopicMenu.value = true
  } else {
    showTopicMenu.value = false
    topicMenuQuery.value = ''
    topicMenuRange.value = null
  }
}

onMounted(() => {
  if (!editorRef.value) return

  quill = new Quill(editorRef.value, {
    theme: 'snow',
    modules: {
      toolbar: false
    },
    placeholder: props.placeholder || '写点什么...'
  })

  if (props.modelValue) {
    quill.clipboard.dangerouslyPasteHTML(props.modelValue)
  }

  quill.on('text-change', () => {
    if (!quill) return
    const html = editorRef.value!.querySelector('.ql-editor')?.innerHTML || ''
    emit('update:modelValue', html)
    detectTopicTrigger()
  })

  quill.on('selection-change', (range: any) => {
    if (range) {
      savedRange = { index: range.index, length: range.length }
      const fmt = quill!.getFormat(range)
      const colorMatch = fmt.color
      if (colorMatch) textColor.value = colorMatch
    }
    if (range) {
      emit('focus')
    }
  })

  watch(() => props.modelValue, (val) => {
    if (!quill || !editorRef.value) return
    const current = editorRef.value.querySelector('.ql-editor')?.innerHTML || ''
    if (val !== current) {
      quill.clipboard.dangerouslyPasteHTML(val || '')
    }
  })
})

onBeforeUnmount(() => {
  quill = null
})
</script>

<style scoped>
.rte-root {
  position: relative;
  background: #fafbfc;
  border: 1.5px solid #e9ecef;
  border-radius: 12px;
  padding: 2px;
  transition: border-color .2s, box-shadow .2s;
}
.rte-root:focus-within {
  border-color: #c7d2fe;
  box-shadow: 0 0 0 3px rgba(99,102,241,.08);
}
.rte-topic-menu {
  position: fixed;
  z-index: 9999;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,.12);
  padding: 6px;
  min-width: 200px;
  max-height: 260px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.rtm-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 8px 10px;
  border: none;
  border-radius: 8px;
  background: transparent;
  font-size: 13px;
  color: #333;
  cursor: pointer;
  text-align: left;
  transition: background .1s;
}
.rtm-item:hover {
  background: #f4f5f7;
}
.rtm-icon { font-size: 16px; flex-shrink: 0; }
.rtm-name { flex: 1; font-weight: 500; }
.rtm-count { font-size: 11px; color: #adb5bd; flex-shrink: 0; }
.rte-toolbar {
  display: flex;
  align-items: center;
  gap: 0;
  padding: 4px 8px;
  flex-wrap: wrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  background: transparent;
  border-radius: 10px 10px 0 0;
  border-bottom: 1px solid #eef0f2;
}
.rt-group {
  display: flex;
  align-items: center;
  gap: 1px;
  padding: 0 3px;
}
.rt-sep {
  width: 1px;
  height: 16px;
  background: #e5e7eb;
  margin: 0 4px;
  flex-shrink: 0;
}
.rt-btn {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  border: none;
  background: transparent;
  color: #868e96;
  font-size: 12px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  transition: all .15s ease;
}
.rt-btn:hover {
  background: #f4f5f7;
  color: #495057;
}
.rt-btn:active {
  transform: scale(.93);
}
.rt-btn-on {
  background: #edf2ff;
  color: #5c7cfa;
}
.rt-select {
  border: 1.5px solid transparent;
  background: transparent;
  font-size: 11px;
  font-weight: 600;
  color: #868e96;
  cursor: pointer;
  padding: 4px 3px;
  border-radius: 6px;
  outline: none;
  min-width: 40px;
  transition: all .15s ease;
}
.rt-select:hover {
  background: #f4f5f7;
  color: #495057;
}
.rt-select:focus {
  background: #f4f5f7;
  border-color: #c7d2fe;
}
.rt-select option {
  background: #fff;
  color: #212529;
}
.rt-color-wrap {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  position: relative;
}
.rt-color {
  width: 20px;
  height: 20px;
  border: 1.5px solid #dee2e6;
  border-radius: 4px;
  padding: 0;
  cursor: pointer;
  flex-shrink: 0;
  transition: border-color .15s;
}
.rt-color:hover {
  border-color: #c7d2fe;
}
.rt-color-label {
  font-size: 10px;
  font-weight: 700;
  color: #868e96;
  user-select: none;
  pointer-events: none;
}
.rt-color::-webkit-color-swatch-wrapper { padding: 0; }
.rt-color::-webkit-color-swatch { border: none; border-radius: 3px; }

.rte-editor :deep(.ql-editor h2) {
  font-size: 20px;
  font-weight: 700;
  line-height: 1.4;
  margin: 0.5em 0 0.3em;
}
.rte-editor :deep(.ql-editor h3) {
  font-size: 17px;
  font-weight: 600;
  line-height: 1.45;
  margin: 0.4em 0 0.2em;
}
.rte-editor :deep(.ql-editor blockquote) {
  border-left: 3px solid #5c7cfa;
  padding: 6px 0 6px 12px;
  margin: 6px 0;
  color: #495057;
  background: #f8f9fa;
  border-radius: 0 6px 6px 0;
}
.rte-editor :deep(.ql-editor pre.ql-syntax) {
  background: #f1f3f5;
  border-radius: 8px;
  padding: 10px 12px;
  font-size: 13px;
  overflow-x: auto;
  font-family: 'SF Mono', Monaco, monospace;
}
.rte-editor :deep(.ql-editor ol),
.rte-editor :deep(.ql-editor ul) {
  padding-left: 20px;
}
.rte-editor :deep(.ql-editor hr) {
  border: none;
  border-top: 1px solid #e9ecef;
  margin: 10px 0;
}
.rte-editor :deep(.ql-container) {
  font-size: 15px;
  line-height: 1.75;
  color: #343a40;
  border: none !important;
  border-radius: 0 0 10px 10px;
  overflow: hidden;
}
.rte-editor :deep(.ql-editor) {
  padding: 12px 16px;
  min-height: 100px;
  outline: none;
  transition: background .2s;
  background: #fcfcfd;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'PingFang SC', 'Microsoft YaHei', sans-serif;
}
.rte-editor :deep(.ql-editor:focus) {
  background: #fff;
}
.rte-editor :deep(.ql-editor.ql-blank::before) {
  font-style: normal;
  color: #adb5bd;
  left: 16px;
  right: 16px;
}
.rte-editor :deep(.ql-size-12px) { font-size: 12px; }
.rte-editor :deep(.ql-size-14px) { font-size: 14px; }
.rte-editor :deep(.ql-size-16px) { font-size: 16px; }
.rte-editor :deep(.ql-size-18px) { font-size: 18px; }
.rte-editor :deep(.ql-size-20px) { font-size: 20px; }
.rte-editor :deep(.ql-size-24px) { font-size: 24px; }
.rte-editor :deep(.ql-size-28px) { font-size: 28px; }
.rte-editor :deep(.ql-size-32px) { font-size: 32px; }
</style>
