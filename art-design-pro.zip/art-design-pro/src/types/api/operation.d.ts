declare namespace Api.Operation {
  type CardKeyList = Api.Common.PaginatedResponse<CardKeyItem>
  interface CardKeyItem {
    id: number
    cardNo: string
    password: string
    type: 'membership' | 'points' | 'experience' | 'balance' | string
    targetId: number
    targetName: string
    value: number
    extraPoints: number
    extraExperience: number
    duration: number
    durationUnit: string
    status: '0' | '1'
    createBy: string
    createTime: string
    redeemBy: string
    redeemTime: string
  }
  type CardKeySearchParams = Partial<Pick<CardKeyItem, 'cardNo' | 'type' | 'status'>> & Api.Common.CommonSearchParams

  type MemberList = Api.Common.PaginatedResponse<MemberItem>
  interface MemberItem {
    id: number
    userId: number
    userName: string
    level: number
    levelName: string
    points: number
    totalPoints: number
    expireTime: string
    createTime: string
    updateTime: string
  }
  type MemberSearchParams = Partial<Pick<MemberItem, 'userName' | 'level'>> & Api.Common.CommonSearchParams

  type MembershipLevelList = Api.Common.PaginatedResponse<MembershipLevelItem>
  interface MembershipLevelItem {
    id: number
    name: string
    level: number
    price: number
    discountRate: number
    pointsMultiplier: number
    pointsDiscountRate: number
    benefits: string
    icon: string
    iconColor: string
    status: '0' | '1'
    createTime: string
  }
  type MembershipLevelSearchParams = Partial<Pick<MembershipLevelItem, 'name' | 'status'>> & Api.Common.CommonSearchParams

  type PointsRecordList = Api.Common.PaginatedResponse<PointsRecordItem>
  interface PointsRecordItem {
    id: number
    userId: number
    userName: string
    type: 'earn' | 'redeem' | 'expire' | 'adjust'
    points: number
    balance: number
    source: string
    description: string
    createTime: string
  }
  type PointsRecordSearchParams = Partial<Pick<PointsRecordItem, 'userName' | 'type'>> & Api.Common.CommonSearchParams
}
